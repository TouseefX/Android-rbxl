# RCCService — Team Create networking extraction

This folder contains a **partial static reverse-engineering extract**, focused on Team Create / CloudEdit session networking. It is **not** the complete decompiled application, original C++ source, a buildable project, or a working Team Create client/server implementation.

## Source and scope

- Source: `RCCService.exe` inside the user-provided `RCCService.tar.gz` archive.
- SHA-256 of executable: `43d750e43397674f4121614cfd60b9f808790a784a77126a58d1a8aa93c44768`
- Format: PE32 x86 native Windows executable; PE linker timestamp: 2021-01-07 (not a reliable indication of present-day compatibility).
- Analyzed statically; the EXE was **not run**. No Roblox credentials, sessions, or live network traffic were used.

## Files

- `teamcreate_session_pseudocode.c`: Ghidra-generated *partial* C-like pseudocode for 24 inferred functions around CloudEdit message names, Team Create session indicators, networking startup, server replicator authentication, and collaboration history.
- `publish_and_misc_pseudocode.c`: additional partial pseudocode near Team Create publish/save and related references. Some referenced addresses resolve to the same inferred function and may be repeated.
- `disassembly_excerpts.asm`: 180 x86 instruction windows beginning at verified references to network-related strings, **not complete function disassemblies**.
- `teamcreate_network_strings.csv`: 1,051 matched ASCII / UTF-16 string fragments (including incidental names/paths), addresses, and verified immediate-operand code references.
- `code_reference_index.csv`: flattened address-to-string lookup for 1,106 verified code references.
- `network_imports.csv`: imported networking, certificate, crypto, and IP-helper APIs with import-table virtual addresses.
- `related_url_strings.csv`: potentially related URL literals; they are not proof that any particular Team Create path connects to those URLs.
- `extract.py`: reproducible PE/string/reference/disassembly extraction script (requires `pefile` and `capstone`; expects the original EXE at `/home/user/rcc_work/RCCService.exe`).

## Useful starting points (virtual addresses)

- `0x0064aaab`: reference to `NetworkServer:Start`.
- `0x0066271d` and `0x00662758`: `ServerReplicator:preauthenticatePlayer` missing/duplicate ticket diagnostics.
- `0x00691e93`: `RequestTeamCreateImmediateSave` message name.
- `0x00691f0d`: `CloudEditApplyEditsMessage` message name.
- `0x00628e7f` / `0x00629006`: Team Create replicator join-time snapshot references.
- `0x005e748a`: Team Create save/publish diagnostic.

Search the CSV index for a message name, then use the code address to find the corresponding pseudocode (where exported) or disassembly excerpt. The addresses above identify **references**, not necessarily function starts or protocol message IDs.

## Important limitations

The executable is a large native C++ program. Whole-program Ghidra auto-analysis ran out of workspace memory; a targeted pass instead decompiled functions beginning at selected code references **without full analysis**. Those entries and control-flow boundaries are inferred and can be wrong; types, variable names, arguments, call targets, and even some control flow are incomplete. The files are evidence and research leads, not a faithful or compilable reconstruction. The string/reference scan is keyword-based and cannot guarantee it captured every path involved in a Team Create session. Additional dependencies and original debug symbols/PDB were not included in the supplied archive. This package deliberately omits the original 29 MB EXE because it is available at the user-provided source URL.
