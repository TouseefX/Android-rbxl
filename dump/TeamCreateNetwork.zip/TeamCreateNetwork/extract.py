import os,re,struct,csv,hashlib,collections
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_32, CS_OP_IMM
src='/home/user/rcc_work/RCCService.exe'; root='/home/user/TeamCreateNetwork'
os.makedirs(root,exist_ok=True)
pe=pefile.PE(src,fast_load=True); pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_IMPORT']]); base=pe.OPTIONAL_HEADER.ImageBase
raw=open(src,'rb').read(); text=next(x for x in pe.sections if x.Name.rstrip(b'\x00')==b'.text'); code=text.get_data(); tva=base+text.VirtualAddress
pattern=re.compile(r'team.?create|cloud.?edit|replicat|network(server|client)|session|publish|preauth|ticket|peer.?id|raknet|signalr|join.?data|game.?server|place.?id',re.I)
focus=re.compile(r'team.?create|cloud.?edit|preauth|ticket|join.?data|network(server|client)|signalr',re.I)
strings=[]
for sec in pe.sections:
 if sec.Name.rstrip(b'\x00') not in [b'.rdata',b'.data',b'.rodata',b'_RDATA']: continue
 data=sec.get_data(); va=base+sec.VirtualAddress
 for m in re.finditer(rb'[\x20-\x7e]{5,}',data):
  s=m.group().decode('ascii','replace')
  if pattern.search(s): strings.append((va+m.start(),s,'ascii'))
 # UTF16-LE
 for m in re.finditer(rb'(?:[\x20-\x7e]\x00){5,}',data):
  s=m.group().decode('utf-16le','replace')
  if pattern.search(s): strings.append((va+m.start(),s,'utf16'))
strings=sorted(set(strings)); md=Cs(CS_ARCH_X86,CS_MODE_32); md.detail=True
rows=[]; valid_refs={}
for addr,s,enc in strings:
 needle=struct.pack('<I',addr); pos=code.find(needle); found=[]
 while pos>=0:
  for delta in range(1,10):
   st=pos-delta
   if st<0: continue
   try:
    ins=next(md.disasm(code[st:pos+5],tva+st,count=1),None)
    if ins and ins.address <= tva+pos < ins.address+ins.size and any(o.type==CS_OP_IMM and o.imm==addr for o in ins.operands):
     found.append((ins.address,ins.mnemonic+' '+ins.op_str));break
   except Exception:pass
  pos=code.find(needle,pos+1)
 found=list(dict.fromkeys(found))
 for ref in found:
  valid_refs.setdefault(ref[0],[]).append((addr,s))
 rows.append([f'0x{addr:08x}',enc,s,len(found),'; '.join(f'0x{x:08x} {y}' for x,y in found[:50])])
with open(root+'/teamcreate_network_strings.csv','w',newline='',encoding='utf-8') as f:
 w=csv.writer(f); w.writerow(['virtual_address','encoding','string','xref_count','code_references']); w.writerows(rows)
# All references are indexed; disassembly excerpts are sampled by keyword relevance.
ranked=sorted(valid_refs.items(),key=lambda kv:(-max((7 if focus.search(s) else 1)+(3 if re.search('team.?create|cloud.?edit',s,re.I) else 0) for a,s in kv[1]),kv[0]))
with open(root+'/code_reference_index.csv','w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['code_va','string_va','string'])
 for addr,pairs in sorted(valid_refs.items()):
  for sva,s in pairs:w.writerow([f'0x{addr:08x}',f'0x{sva:08x}',s])
with open(root+'/disassembly_excerpts.asm','w',encoding='utf-8') as f:
 f.write('; Partial x86 disassembly starting at verified references (NOT full functions).\n; Addresses are image-base virtual addresses. Sample: up to 180 highest-ranked unique code references.\n')
 for idx,(addr,pairs) in enumerate(ranked[:180]):
  off=addr-tva
  f.write('\n; === %03d | %s | %s ===\n'%(idx+1,hex(addr),' | '.join(s[:160] for a,s in pairs[:4]).replace('\n',' ')))
  for ins in md.disasm(code[off:off+200],addr):
   f.write('%08x: %-12s %-8s %s\n'%(ins.address,ins.bytes.hex(),ins.mnemonic,ins.op_str))
   if ins.address-addr>=160:break
with open(root+'/network_imports.csv','w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['dll','function','iat_va'])
 for entry in pe.DIRECTORY_ENTRY_IMPORT:
  dll=entry.dll.decode(errors='replace')
  if dll.lower() not in ['winhttp.dll','ws2_32.dll','crypt32.dll','advapi32.dll','iphlpapi.dll']:continue
  for item in entry.imports:w.writerow([dll,(item.name or b'').decode(errors='replace'),f'0x{item.address:08x}'])
urls=[]
for sec in pe.sections:
 if sec.Name.rstrip(b'\x00') not in [b'.rdata',b'.data']:continue
 data=sec.get_data();va=base+sec.VirtualAddress
 for m in re.finditer(rb'https?://[^\x00\s\x22\x27<>]{5,300}',data,re.I):
  s=m.group().decode('ascii','replace')
  if re.search('roblox|teamcreate|cloudedit|game|api',s,re.I):urls.append((f'0x{va+m.start():08x}',s))
with open(root+'/related_url_strings.csv','w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['virtual_address','url_string']);w.writerows(sorted(set(urls)))
print('strings',len(strings),'string refs',sum(len(v) for v in valid_refs.values()),'unique code refs',len(valid_refs),'related urls',len(urls),'excerpts',min(180,len(ranked)))
print('top strings with refs:')
for row in sorted(rows,key=lambda x:-x[3])[:25]:print(row[:4])
