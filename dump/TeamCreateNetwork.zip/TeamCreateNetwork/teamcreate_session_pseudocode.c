// Ghidra-derived partial pseudocode. Inferred function entries, no whole-program analysis.

// Code reference: 0x0061c074 ; inferred entry: 0061c074

undefined * FUN_0061c074(void)

{
  undefined *puVar1;
  int unaff_EBP;
  
  puVar1 = *(undefined **)(unaff_EBP + 8);
  *(undefined4 *)(puVar1 + 0x10) = 0;
  *(undefined4 *)(puVar1 + 0x14) = 0xf;
  *puVar1 = 0;
  func_0x005542c0(&UNK_018cccc8);
  return puVar1;
}



// Code reference: 0x00628e7f ; inferred entry: 00628e7f

int FUN_00628e7f(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_018cdc04);
  *(undefined *)(unaff_EBP + -4) = 4;
  func_0x01520d20(unaff_EBP + -0x2c);
  func_0x005507b0();
  func_0x0151f7f0();
  iVar4 = func_0x0056d3e0();
  piVar3 = *(int **)(unaff_EBP + -0x3c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + unaff_EDI;
    UNLOCK();
    if (iVar2 + unaff_EDI == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + unaff_EDI;
      UNLOCK();
      if (iVar2 + unaff_EDI == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(unaff_EBP + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + unaff_EDI;
    UNLOCK();
    if (iVar2 == 1) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar4;
}



// Code reference: 0x00629006 ; inferred entry: 00629006

int FUN_00629006(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_018cdc04);
  *(undefined *)(unaff_EBP + -4) = 7;
  func_0x01520d20(unaff_EBP + -0x2c);
  func_0x005507b0();
  func_0x0151f7f0();
  func_0x0151f7f0();
  iVar4 = func_0x0056d3e0();
  piVar3 = *(int **)(unaff_EBP + -0x3c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + unaff_EDI;
    UNLOCK();
    if (iVar2 + unaff_EDI == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + unaff_EDI;
      UNLOCK();
      if (iVar2 + unaff_EDI == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(unaff_EBP + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + unaff_EDI;
    UNLOCK();
    if (iVar2 == 1) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar4;
}



// Code reference: 0x0062af65 ; inferred entry: 0062af65

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0062af65(void)

{
  undefined4 uVar1;
  int iVar2;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_018cd970);
  uVar1 = _DAT_01eace44;
  iVar2 = unaff_EBP + -0x58;
  if (0xf < *(uint *)(unaff_EBP + -0x44)) {
    iVar2 = *(int *)(unaff_EBP + -0x58);
  }
  func_0x0054eff0(iVar2);
  *(undefined *)(unaff_EBP + -4) = 0x31;
  func_0x01520d20(unaff_EBP + -200,uVar1,0);
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  func_0x0151f7f0();
  func_0x0056d3e0();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00640b85 ; inferred entry: 00640b85

void FUN_00640b85(void)

{
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x016774b0();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00641358 ; inferred entry: 00641358

void FUN_00641358(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int unaff_EBX;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x016774b0();
  uVar4 = *(undefined4 *)(unaff_EBX + 0x484);
  piVar2 = (int *)(unaff_EBX + 0x484);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x00576720();
  *(undefined4 *)(*piVar2 + 4) = uVar4;
  *(undefined4 *)*piVar2 = uVar4;
  *(undefined4 *)(*piVar2 + 8) = uVar4;
  *(undefined4 *)(unaff_EBX + 0x488) = 0;
  func_0x01674ea0(*piVar2,0x28);
  iVar5 = *(int *)(unaff_EBX + 0x47c);
  piVar2 = (int *)(unaff_EBX + 0x47c);
  uVar4 = *(undefined4 *)(iVar5 + 4);
  *(undefined4 *)(unaff_EBP + -4) = 1;
  func_0x00576720(uVar4);
  *(int *)(*piVar2 + 4) = iVar5;
  *(int *)*piVar2 = iVar5;
  *(int *)(*piVar2 + 8) = iVar5;
  *(undefined4 *)(unaff_EBX + 0x480) = 0;
  func_0x01674ea0(*piVar2,0x28);
  func_0x016790b0();
  LOCK();
  iVar5 = *(int *)(unaff_EBX + 0x464);
  *(int *)(unaff_EBX + 0x464) = 0;
  UNLOCK();
  if (iVar5 != 0) {
    CloseHandle(iVar5);
  }
  func_0x0056cd30();
  func_0x0056cd30();
  func_0x0056cd30();
  func_0x0056cd30();
  piVar2 = *(int **)(unaff_EBX + 0x444);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBX + 0x430);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  func_0x00640ec0();
  func_0x0056d250();
  LOCK();
  iVar5 = *(int *)(unaff_EBX + 0x3f8);
  *(int *)(unaff_EBX + 0x3f8) = 0;
  UNLOCK();
  if (iVar5 != 0) {
    CloseHandle(iVar5);
  }
  func_0x00640e30();
  func_0x00640e30();
  func_0x00640fb0();
  *(undefined4 *)(unaff_EBP + -4) = 2;
  func_0x01679490();
  iVar5 = *(int *)(unaff_EBX + 0x3a0);
  if (iVar5 != 0) {
    piVar2 = (int *)(iVar5 + 4);
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      func_0x01674ea0(iVar5);
    }
  }
  *(undefined4 *)(unaff_EBP + -4) = 3;
  func_0x01679490();
  iVar5 = *(int *)(unaff_EBX + 0x39c);
  if (iVar5 != 0) {
    piVar2 = (int *)(iVar5 + 4);
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      func_0x01674ea0(iVar5);
    }
  }
  *(undefined4 *)(unaff_EBP + -4) = 4;
  func_0x01679490();
  iVar5 = *(int *)(unaff_EBX + 0x398);
  if (iVar5 != 0) {
    piVar2 = (int *)(iVar5 + 4);
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      func_0x01674ea0(iVar5);
    }
  }
  func_0x006d21e0();
  piVar2 = *(int **)(unaff_EBX + 0x120);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBX + 0x118);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBX + 0x110);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  func_0x006c4520();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x0064239a ; inferred entry: 0064239a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0064239a(void)

{
  undefined *puVar1;
  int *piVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_EAX;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined *puVar10;
  int iVar11;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  float10 fVar12;
  undefined8 uVar13;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  undefined *puStack_10;
  float fStack_c;
  uint uStack_8;
  undefined *puStack_4;
  
  puStack_4 = &UNK_018d0700;
  fStack_c = 9.196336e-39;
  uStack_8 = in_EAX;
  func_0x016774b0();
  if (DAT_01ee4213 != 0) {
    fVar12 = (float10)func_0x01683110();
    uStack_14 = (uint)DAT_01ee4213;
    *(double *)(unaff_EBP + -0x28) = (double)fVar12;
    fStack_c = (float)*(double *)(unaff_EBP + -0x28);
    puStack_4 = (undefined *)0x0;
    uStack_8 = 0;
    puStack_10 = &UNK_018d0724;
    uStack_18 = 0x6423f4;
    func_0x016774d0();
  }
  if (DAT_01d84e8d != 0) {
    puStack_4 = (undefined *)0x1;
    uStack_8 = *(undefined4 *)(unaff_EBP + 8);
    fStack_c = (float)(unaff_EBP + -0x50);
    puStack_10 = (undefined *)0x642410;
    func_0x006b1620();
    *(undefined *)(unaff_EBP + -4) = 4;
    uStack_8 = (uint)DAT_01d84e8d;
    puStack_4 = &UNK_018d074c;
    fStack_c = 9.196534e-39;
    func_0x01677520();
    *(undefined *)(unaff_EBP + -4) = 3;
    if (0xf < *(uint *)(unaff_EBP + -0x3c)) {
      puVar1 = *(undefined **)(unaff_EBP + -0x50);
      puVar10 = puVar1;
      if ((0xfff < *(uint *)(unaff_EBP + -0x3c) + 1) &&
         (puVar10 = *(undefined **)(puVar1 + -4), (undefined *)0x1f < puVar1 + (-4 - (int)puVar10)))
      {
        func_0x017167a3();
        goto LAB_00642816;
      }
      uStack_8 = 0x64246a;
      puStack_4 = puVar10;
      func_0x01674ea0();
    }
  }
  *(undefined4 *)(unaff_EBP + -0x88) = 0xffffffff;
  func_0x005f7140();
  *(undefined4 *)(unaff_EBP + -100) = 0;
  *(undefined4 *)(unaff_EBP + -0x60) = 0;
  iVar11 = *(int *)(unaff_EDI + 0xb4);
  *(undefined *)(unaff_EBP + -4) = 5;
  *(int *)(unaff_EBP + -0x88) = iVar11;
  *(int *)(unaff_EDI + 0xb4) = iVar11 + 1;
  if (DAT_01ee420a != 0) {
    uStack_8 = (uint)DAT_01ee420a;
    puStack_4 = &UNK_018d0764;
    fStack_c = 9.196734e-39;
    func_0x016774b0();
  }
  puStack_4 = (undefined *)0x6424d2;
  func_0x005f7170();
  iVar11 = *(int *)(unaff_EDI + 0x78);
  if (iVar11 != 0) {
    LOCK();
    *(int *)(iVar11 + 4) = *(int *)(iVar11 + 4) + 1;
    UNLOCK();
    iVar11 = *(int *)(unaff_EDI + 0x78);
  }
  puVar8 = *(undefined4 **)(unaff_EBP + -0x60);
  *(undefined4 *)(unaff_EBP + -100) = *(undefined4 *)(unaff_EDI + 0x74);
  *(undefined4 **)(unaff_EBP + -0x14) = puVar8;
  *(int *)(unaff_EBP + -0x60) = iVar11;
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    iVar11 = puVar8[1] + -1;
    puVar8[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      puStack_4 = (undefined *)0x642503;
      (**(code **)*puVar8)();
      piVar2 = *(int **)(unaff_EBP + -0x14);
      LOCK();
      piVar7 = piVar2 + 2;
      iVar11 = *piVar7 + -1;
      *piVar7 = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        puStack_4 = (undefined *)0x642514;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  puStack_4 = (undefined *)0x64251f;
  piVar7 = (int *)func_0x0054db20();
  *(int **)(unaff_EBP + -0x14) = piVar7;
  puVar8 = *(undefined4 **)(unaff_EBP + 8);
  uStack_20 = *puVar8;
  uStack_1c = puVar8[1];
  uStack_18 = puVar8[2];
  uStack_14 = puVar8[3];
  puStack_10 = (undefined *)puVar8[4];
  fStack_c = (float)puVar8[5];
  uStack_8 = puVar8[6];
  puStack_4 = (undefined *)puVar8[7];
  iStack_24 = 0x642545;
  uVar13 = (**(code **)(*piVar7 + 0x150))();
  *(undefined8 *)(unaff_EBP + -0x58) = uVar13;
  uVar9 = *(undefined4 *)(*(int *)(unaff_EBP + -0x20) + 0x354);
  *(int *)(unaff_EBP + -0x14) = *(int *)(unaff_EBP + -0x20) + -0x54;
  iStack_24 = unaff_EBP + -0x88;
  *(undefined4 *)(unaff_EBP + -0x18) = uVar9;
  uStack_28 = 0x64256f;
  func_0x005ef5c0();
  uVar6 = _DAT_01ead770;
  *(undefined *)(unaff_EBP + -4) = 6;
  if (uVar6 != 0) {
    uStack_28 = *(undefined4 *)(unaff_EBP + -0x18);
    uStack_2c = *(undefined4 *)(unaff_EBP + -0x14);
    pcVar3 = *(code **)((uVar6 & 0xfffffffe) + 4);
    uVar9 = *(undefined4 *)(unaff_EBP + -0x9c);
    uVar4 = *(undefined4 *)(unaff_EBP + -0x98);
    *(undefined4 *)(unaff_EBP + -0x9c) = 0;
    *(undefined4 *)(unaff_EBP + -0x98) = 0;
    puVar8 = (undefined4 *)
             (*pcVar3)(unaff_EBP + -0x40,0x1ead778,*(undefined4 *)(unaff_EBP + -0xc0),
                       *(undefined4 *)(unaff_EBP + -0xbc),*(undefined4 *)(unaff_EBP + -0xb8),
                       *(undefined4 *)(unaff_EBP + -0xb4),*(undefined4 *)(unaff_EBP + -0xb0),
                       *(undefined4 *)(unaff_EBP + -0xac),*(undefined4 *)(unaff_EBP + -0xa8),
                       *(undefined4 *)(unaff_EBP + -0xa4),*(undefined4 *)(unaff_EBP + -0xa0),uVar9,
                       uVar4);
    *(undefined4 *)(unaff_EBP + -0x18) = *puVar8;
    uVar9 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    puVar8 = *(undefined4 **)(unaff_EBP + -0x3c);
    *(undefined4 *)(unaff_EBP + -0x1c) = uVar9;
    *(undefined4 **)(unaff_EBP + -0x24) = puVar8;
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      iVar11 = puVar8[1] + -1;
      puVar8[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_28 = 0x642635;
        (**(code **)*puVar8)();
        piVar2 = *(int **)(unaff_EBP + -0x24);
        LOCK();
        piVar7 = piVar2 + 2;
        iVar11 = *piVar7 + -1;
        *piVar7 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          uStack_28 = 0x642646;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    puVar8 = *(undefined4 **)(unaff_EBP + -0x98);
    *(undefined *)(unaff_EBP + -4) = 5;
    *(undefined4 **)(unaff_EBP + -0x24) = puVar8;
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      iVar11 = puVar8[1] + -1;
      puVar8[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_28 = 0x642664;
        (**(code **)*puVar8)();
        piVar2 = *(int **)(unaff_EBP + -0x24);
        LOCK();
        piVar7 = piVar2 + 2;
        iVar11 = *piVar7 + -1;
        *piVar7 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          uStack_28 = 0x642675;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x18);
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x1c);
    uStack_28 = 0x64268c;
    piVar7 = (int *)func_0x0054db20();
    *(int **)(unaff_EBP + -0x24) = piVar7;
    puVar8 = *(undefined4 **)(unaff_EBP + 8);
    (**(code **)(*piVar7 + 0x158))
              (&uStack_2c,*puVar8,puVar8[1],puVar8[2],puVar8[3],puVar8[4],puVar8[5],puVar8[6],
               puVar8[7]);
    iVar11 = *(int *)(unaff_EBP + -0x18);
    func_0x006307a0();
    if (*(char *)(iVar11 + 0x3860) != '\0') {
      iVar5 = *(int *)(unaff_EBP + 8);
      (**(code **)(*(int *)(iVar11 + 0x5c) + 0x20))
                (iVar5,*(undefined4 *)(iVar5 + 0x20),*(undefined4 *)(iVar5 + 0x24),
                 *(undefined4 *)(iVar5 + 0x28),*(undefined4 *)(iVar5 + 0x2c),1);
    }
    func_0x008a5700(*(undefined4 *)(unaff_EBP + -0x14));
    puVar8 = *(undefined4 **)(unaff_EBP + -0x60);
    *(undefined4 **)(unaff_EBP + 8) = puVar8;
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      iVar11 = puVar8[1] + -1;
      puVar8[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*puVar8)();
        piVar2 = *(int **)(unaff_EBP + 8);
        LOCK();
        piVar7 = piVar2 + 2;
        iVar11 = *piVar7 + -1;
        *piVar7 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    puVar8 = *(undefined4 **)(unaff_EBP + -0x1c);
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      iVar11 = puVar8[1] + -1;
      puVar8[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*puVar8)();
        piVar2 = *(int **)(unaff_EBP + -0x1c);
        LOCK();
        piVar7 = piVar2 + 2;
        iVar11 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar11 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    *(undefined4 *)(unaff_EBP + -4) = 9;
    func_0x01675290();
    *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
    return 1;
  }
LAB_00642816:
  uStack_28 = 0x64281e;
  uStack_28 = func_0x0054fda0();
  *(undefined *)(unaff_EBP + -4) = 7;
  uStack_2c = 0x642828;
  func_0x0054e5e0();
  pcVar3 = (code *)swi(3);
  uVar9 = (*pcVar3)();
  return uVar9;
}



// Code reference: 0x0064aaab ; inferred entry: 0064aaab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0064aaab(void)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  double *pdVar8;
  int iVar9;
  undefined4 uVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  int unaff_EBP;
  int unaff_ESI;
  undefined2 *puVar14;
  undefined4 *puVar15;
  undefined4 *unaff_FS_OFFSET;
  bool bVar16;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [12];
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined *puStack_38;
  undefined *puStack_34;
  uint uStack_30;
  undefined *puStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  int iStack_18;
  uint uStack_14;
  undefined2 *puStack_10;
  undefined4 *puStack_c;
  undefined4 uStack_8;
  undefined *puStack_4;
  
  puStack_4 = &UNK_018d0540;
  puStack_c = (undefined4 *)0x64aab6;
  func_0x016774b0();
  if (DAT_01d59d40 != '\0') {
    piVar4 = (int *)func_0x0054db20();
    puStack_4 = (undefined *)0x64aadc;
    (**(code **)(*piVar4 + 0x170))();
  }
  *(undefined4 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  bVar16 = DAT_01d5a538 == '\0';
  *(undefined *)(unaff_EBP + -4) = 1;
  if (bVar16) {
    iVar7 = *(int *)(unaff_EBP + 8);
    puStack_4 = (undefined *)iVar7;
    if (DAT_01d5a530 == '\0') {
      uStack_8 = 0x64ac95;
      func_0x005f70d0();
      uStack_8 = 0x64aca0;
      piVar4 = (int *)func_0x0054db20();
      uStack_8 = 0xfffe7961;
      puStack_c = (undefined4 *)0x1;
      puStack_10 = (undefined2 *)(unaff_EBP + -0x1d0);
      uStack_14 = (uint)_DAT_01d5a400;
      iStack_18 = 0x64acbf;
      puStack_1c = (undefined *)(**(code **)(*piVar4 + 4))();
      *(undefined **)(unaff_EBP + 0x10) = puStack_1c;
      goto LAB_0064acc2;
    }
    uStack_8 = 0x64ac58;
    func_0x005f70d0();
    uStack_8 = 0x64ac63;
    piVar4 = (int *)func_0x0054db20();
    uStack_8 = 0xfffe7961;
    puStack_c = (undefined4 *)0x1;
    puStack_10 = (undefined2 *)(unaff_EBP + -0x188);
    uStack_14 = (uint)_DAT_01d5a400;
    iStack_18 = 0x64ac82;
    puStack_1c = (undefined *)(**(code **)(*piVar4 + 4))();
    unaff_ESI = *(int *)(unaff_EBP + -0x14);
    *(undefined **)(unaff_EBP + 0x10) = puStack_1c;
  }
  else {
    puStack_4 = (undefined *)0x64ab0b;
    puVar5 = (undefined4 *)func_0x00644030();
    *(undefined4 *)(unaff_EBP + 0x10) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0;
    puVar15 = (undefined4 *)0x0;
    if ((undefined4 *)(unaff_EBP + -0x24) != puVar5) {
      func_0x00577a40();
      uVar6 = puVar5[1];
      puVar15 = (undefined4 *)*puVar5;
      uVar10 = puVar5[2];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(undefined4 **)(unaff_EBP + -0x24) = puVar15;
      *(undefined4 *)(unaff_EBP + 0x10) = uVar6;
      *(undefined4 *)(unaff_EBP + -0x20) = uVar6;
      *(undefined4 *)(unaff_EBP + -0x1c) = uVar10;
      puVar5[2] = 0;
      *(undefined4 *)(unaff_EBP + -0x10) = uVar6;
    }
    func_0x00577a40();
    iVar7 = (*(int *)(unaff_EBP + 0x10) - (int)puVar15) / 0x18;
    uStack_8 = 0x64ab82;
    puStack_4 = (undefined *)iVar7;
    func_0x006401b0();
    *(undefined *)(unaff_EBP + -4) = 2;
    *(undefined4 *)(unaff_EBP + 0x10) = 0;
    if (iVar7 != 0) {
      puVar14 = *(undefined2 **)(unaff_EBP + -0x3c);
      *(int *)(unaff_EBP + -0x10) = (*(int *)(unaff_EBP + -0x10) - (int)puVar15) / 0x18;
      do {
        *puVar14 = (short)*(undefined4 *)(unaff_EBP + 8);
        puStack_c = puVar15;
        if (0xf < (uint)puVar15[5]) {
          puStack_c = (undefined4 *)*puVar15;
        }
        uStack_8 = 0x41;
        puStack_10 = puVar14 + 1;
        uStack_14 = 0x64abcc;
        func_0x0171dd10();
        uVar11 = *(int *)(unaff_EBP + 0x10) + 1;
        puVar14 = puVar14 + 0x23;
        puVar15 = puVar15 + 6;
        *(uint *)(unaff_EBP + 0x10) = uVar11;
      } while (uVar11 < *(uint *)(unaff_EBP + -0x10));
    }
    uStack_8 = 0x64abef;
    piVar4 = (int *)func_0x0054db20();
    uStack_8 = 0xfffe7961;
    uStack_14 = (uint)_DAT_01d5a400;
    puStack_c = (undefined4 *)((*(int *)(unaff_EBP + -0x38) - *(int *)(unaff_EBP + -0x3c)) / 0x46);
    puStack_10 = *(undefined2 **)(unaff_EBP + -0x3c);
    iStack_18 = 0x64ac24;
    uVar6 = (**(code **)(*piVar4 + 4))();
    *(undefined4 *)(unaff_EBP + 0x10) = uVar6;
    *(undefined *)(unaff_EBP + -4) = 1;
    iStack_18 = 0x64ac33;
    func_0x00642960();
    unaff_ESI = *(int *)(unaff_EBP + -0x14);
    puStack_1c = *(undefined **)(unaff_EBP + 0x10);
LAB_0064acc2:
    iVar7 = *(int *)(unaff_EBP + 8);
  }
  if (puStack_1c == (undefined *)0x0) {
    iStack_18 = 0x64acf3;
    piVar4 = (int *)func_0x0054db20();
    iStack_18 = 0;
    puStack_1c = (undefined *)(unaff_EBP + -0x120);
    uStack_24 = (double)CONCAT44(0x64ad08,(undefined4)uStack_24);
    (**(code **)(*piVar4 + 0xbc))();
    uStack_24 = (double)CONCAT44(0x64ad0f,(undefined4)uStack_24);
    uVar11 = func_0x005f7810();
    *(uint *)(unaff_ESI + 0x104) = uVar11 & 0xffff;
    if (DAT_01d84e8d != 0) {
      uStack_24 = (double)CONCAT44(0x64ad30,(undefined4)uStack_24);
      piVar4 = (int *)func_0x0054db20();
      uStack_24 = 2.63127478080188e-312;
      puStack_28 = (undefined4 *)0x0;
      puStack_2c = (undefined *)(unaff_EBP + -0x140);
      uStack_30 = 0x64ad49;
      uStack_30 = (**(code **)(*piVar4 + 0xbc))();
      puStack_34 = (undefined *)(unaff_EBP + -0xa8);
      puStack_38 = (undefined *)0x64ad56;
      puStack_28 = (undefined4 *)func_0x006b1620();
      uVar11 = puStack_28[5];
      *(undefined *)(unaff_EBP + -4) = 5;
      if (0xf < uVar11) {
        puStack_28 = (undefined4 *)*puStack_28;
      }
      uStack_30 = (uint)DAT_01d84e8d;
      puStack_2c = &UNK_018d05c0;
      puStack_34 = (undefined *)0x64ad78;
      func_0x01677520();
      uVar11 = *(uint *)(unaff_EBP + -0x94);
      *(undefined *)(unaff_EBP + -4) = 1;
      if (0xf < uVar11) {
        iVar7 = *(int *)(unaff_EBP + -0xa8);
        uVar13 = uVar11 + 1;
        iVar12 = iVar7;
        if (0xfff < uVar13) {
          iVar12 = *(int *)(iVar7 + -4);
          uVar13 = uVar11 + 0x24;
          if (0x1f < (iVar7 - iVar12) - 4U) goto LAB_0064b165;
        }
        uStack_24 = (double)CONCAT44(uVar13,iVar12);
        puStack_28 = (undefined4 *)0x64adb6;
        func_0x01674ea0();
      }
    }
    uStack_24._0_4_ = 0x64adbf;
    uStack_24._4_4_ = unaff_ESI;
    iVar7 = func_0x008f7870();
    uStack_24 = (double)CONCAT44(uStack_24._4_4_,unaff_EBP + -0x90);
    *(int *)(unaff_EBP + -0x2c) = iVar7;
    *(undefined4 *)(unaff_EBP + -0x44) = *(undefined4 *)(iVar7 + 600);
    *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(iVar7 + 0x25c);
    puStack_28 = (undefined4 *)0x64ade2;
    pdVar8 = (double *)func_0x016830f0();
    puStack_28 = (undefined4 *)0x0;
    puStack_2c = &UNK_018ccd30;
    uStack_30 = (uint)((*pdVar8 - *(double *)(unaff_EBP + -0x44)) * _DAT_018c0d70);
    puStack_34 = &UNK_018d05dc;
    puStack_38 = &UNK_018c5f98;
    uStack_3c = 0x64ae0e;
    func_0x0087c7b0();
    if (DAT_01d65328 != '\0') {
      uStack_24 = (double)CONCAT44(0x64ae25,(undefined4)uStack_24);
      piVar4 = (int *)func_0x0054db20();
      iStack_40 = 600000;
      uStack_3c = _DAT_01ead6cc;
      puStack_38 = puRam01ead6d0;
      puStack_34 = puRam01ead6d4;
      uStack_30 = uRam01ead6d8;
      puStack_2c = _DAT_01ead6dc;
      puStack_28 = puRam01ead6e0;
      uStack_24 = (double)CONCAT44(uRam01ead6e8,uRam01ead6e4);
      uStack_44 = 0x64ae50;
      (**(code **)(*piVar4 + 0xcc))();
    }
    if (*(int *)(unaff_ESI + 0x124) == 2) {
      uStack_24 = (double)CONCAT44(0x64ae64,(undefined4)uStack_24);
      piVar4 = (int *)func_0x0054db20();
      iStack_40 = _DAT_01d5afc4 * 1000;
      uStack_3c = _DAT_01ead6cc;
      puStack_38 = puRam01ead6d0;
      puStack_34 = puRam01ead6d4;
      uStack_30 = uRam01ead6d8;
      puStack_2c = _DAT_01ead6dc;
      puStack_28 = puRam01ead6e0;
      uStack_24 = (double)CONCAT44(uRam01ead6e8,uRam01ead6e4);
      uStack_44 = 0x64ae95;
      (**(code **)(*piVar4 + 0xcc))();
    }
    uStack_24 = (double)CONCAT44(iVar7,0x64ae9b);
    func_0x00646d00();
    *(int *)(unaff_EBP + -0x28) = iVar7 + 0xc;
    uStack_24 = (double)CONCAT44(0x64aeab,(undefined4)uStack_24);
    uVar6 = func_0x005cf2a0();
    uStack_24 = (double)_DAT_01d5a40c;
    *(undefined4 *)(unaff_EBP + 8) = uVar6;
    uStack_48 = 0;
    func_0x0060e0c0(&piStack_5c,*(undefined4 *)(unaff_EBP + -0x14));
    func_0x0063edb0(auStack_54,&UNK_006480d0);
    uStack_58 = 0x64aef3;
    func_0x0063d3f0();
    uStack_58 = 0x64aefb;
    func_0x009eef30();
    iVar7 = *(int *)(unaff_EBP + -0x14);
    uStack_58 = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0;
    iVar12 = *(int *)(iVar7 + 0x42c);
    *(int *)(unaff_EBP + -0x10) = iVar12;
    iVar12 = *(int *)(iVar12 + 4);
    if (iVar12 != 0) {
      piVar4 = (int *)(iVar12 + 4);
      iVar12 = *(int *)(iVar12 + 4);
      while (iVar12 != 0) {
        LOCK();
        iVar9 = *piVar4;
        if (iVar12 == iVar9) {
          *piVar4 = iVar12 + 1;
          iVar9 = iVar12;
        }
        UNLOCK();
        if (iVar9 == iVar12) {
          uVar6 = **(undefined4 **)(unaff_EBP + -0x10);
          piVar4 = (int *)(*(undefined4 **)(unaff_EBP + -0x10))[1];
          *(undefined4 *)(unaff_EBP + -0x18) = uVar6;
          *(int **)(unaff_EBP + -0x14) = piVar4;
          *(undefined *)(unaff_EBP + -4) = 6;
          if (piVar4 != (int *)0x0) {
            LOCK();
            piVar4[2] = piVar4[2] + 1;
            UNLOCK();
          }
          piStack_5c = piVar4;
          func_0x0063d040(&UNK_007190d0,uVar6);
          *(undefined *)(unaff_EBP + -4) = 7;
          func_0x016899e0();
          puVar15 = *(undefined4 **)(unaff_EBP + 8);
          *(undefined4 **)(unaff_EBP + 0x10) = puVar15;
          if (puVar15 != (undefined4 *)0x0) {
            LOCK();
            iVar12 = puVar15[1] + -1;
            puVar15[1] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)*puVar15)(0);
              uVar6 = GetProcessHeap(0,*(undefined4 *)(unaff_EBP + 0x10));
              HeapFree(uVar6);
            }
          }
          *(undefined *)(unaff_EBP + -4) = 1;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar12 = piVar4[1] + -1;
            piVar4[1] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar12 = piVar4[2] + -1;
              piVar4[2] = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          piVar4 = (int *)func_0x00564130();
          if (*piVar4 != 0) {
            *(undefined8 *)(iVar7 + 0x3b0) = *(undefined8 *)(*piVar4 + 0x80);
          }
          iVar12 = *(int *)(unaff_EBP + -0x2c);
          uVar6 = func_0x008f7c50();
          *(undefined4 *)(iVar7 + 0x3ac) = uVar6;
          cVar2 = *(char *)(*(int *)(iVar12 + 0x1b8) + 0x300);
          *(int *)(unaff_EBP + 0x10) = iVar7 + 0x128;
          if (cVar2 != '\0') {
            func_0x006d9900(iVar12);
          }
          func_0x006448b0(unaff_EBP + -0x4c);
          piVar4 = *(int **)(unaff_EBP + -0x4c);
          *(undefined *)(unaff_EBP + -4) = 8;
          uVar6 = (**(code **)(*piVar4 + 8))();
          uVar10 = (**(code **)(*piVar4 + 4))();
          func_0x006ab380(uVar10,uVar6,0);
          *(undefined *)(unaff_EBP + -4) = 9;
          func_0x006d98e0(unaff_EBP + -0xd0);
          func_0x00613200();
          piVar4 = *(int **)(unaff_EBP + -0x48);
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar7 = piVar4[1] + -1;
            piVar4[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar7 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          func_0x00577a40();
          *(undefined4 *)(unaff_EBP + -4) = 10;
          func_0x01675290(*(undefined4 *)(unaff_EBP + -0x30));
          *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
          return;
        }
        iVar12 = *piVar4;
      }
    }
  }
  else {
    uStack_24 = (double)CONCAT44(0x64acd0,(undefined4)uStack_24);
    iStack_18 = iVar7;
    func_0x00647e60();
    iStack_18 = *(int *)(unaff_EBP + 0x10);
    if (DAT_01d5b140 != '\0') {
      iStack_18 = *(undefined4 *)(iStack_18 * 4 + 0x1d5a468);
      uStack_24 = (double)CONCAT44(&UNK_018d0554,unaff_EBP + -0xe8);
      puStack_28 = (undefined4 *)0x64b116;
      puStack_1c = (undefined *)iVar7;
      iStack_18 = func_0x01675640();
      *(undefined *)(unaff_EBP + -4) = 3;
      puStack_1c = (undefined *)0x64b126;
      func_0x005500e0();
      puStack_1c = &UNK_01c17198;
      uStack_24 = (double)CONCAT44(unaff_EBP + -0x70,0x64b134);
      iStack_18 = func_0x0170c2a8();
    }
    uStack_24 = (double)CONCAT44(&UNK_018d0588,unaff_EBP + -0x100);
    puStack_28 = (undefined4 *)0x64b147;
    puStack_1c = (undefined *)iVar7;
    iStack_18 = func_0x01675640();
    *(undefined *)(unaff_EBP + -4) = 4;
    puStack_1c = (undefined *)0x64b157;
    func_0x005500e0();
    puStack_1c = &UNK_01c17198;
    uStack_24 = (double)CONCAT44(unaff_EBP + -0x7c,0x64b165);
    func_0x0170c2a8();
LAB_0064b165:
    uStack_24 = (double)CONCAT44(0x64b16a,(undefined4)uStack_24);
    func_0x017167a3();
  }
  piStack_5c = (int *)0x64b175;
  func_0x005c47d0();
  piStack_5c = (int *)&UNK_01c21d80;
  func_0x0170c2a8(unaff_EBP + -0x88);
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}



// Code reference: 0x0064b3bd ; inferred entry: 0064b3bd

void FUN_0064b3bd(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  undefined4 unaff_EBX;
  int unaff_EBP;
  int unaff_EDI;
  
  func_0x016774b0();
  puVar4 = *(undefined4 **)(unaff_EDI + 0x2c);
  if (puVar4 != (undefined4 *)0x0) {
    piVar6 = *(int **)(unaff_EDI + 0x30);
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      puVar4 = *(undefined4 **)(unaff_EDI + 0x2c);
      piVar6 = *(int **)(unaff_EDI + 0x30);
    }
    piVar1 = (int *)puVar4[1];
    for (piVar5 = (int *)*puVar4; piVar5 != piVar1; piVar5 = piVar5 + 2) {
      *(undefined *)(*piVar5 + 0x22) = 0;
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
      unaff_EBX = *(undefined4 *)(unaff_EBP + 8);
    }
  }
  func_0x008a50b0();
  piVar6 = (int *)func_0x0054db20();
  cVar3 = (**(code **)(*piVar6 + 0x38))();
  if (cVar3 != '\0') {
    piVar6 = (int *)func_0x0054db20();
    (**(code **)(*piVar6 + 0x34))(unaff_EBX,0);
  }
  return;
}



// Code reference: 0x0066271d ; inferred entry: 0066271d

void FUN_0066271d(void)

{
  code *pcVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  func_0x016774b0();
  func_0x016756b0(unaff_EBP + -0x2c);
  func_0x0170c2a8(unaff_EBP + -0x2c);
  if (DAT_01d84e8e != '\0') {
    func_0x016774b0(DAT_01d84e8e,&UNK_018d1ce4,0);
  }
  uVar2 = func_0x005543f0();
  func_0x016756b0(unaff_EBP + -0x38,&UNK_018d1d20,uVar2);
  func_0x0170c2a8(unaff_EBP + -0x38,&UNK_01c17198);
  func_0x016757c0(&UNK_018d1d44);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



// Code reference: 0x00688775 ; inferred entry: 00688775

void FUN_00688775(void)

{
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x016774b0();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00688898 ; inferred entry: 00688898

void FUN_00688898(void)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x016774b0();
  func_0x00637860();
  func_0x016790b0();
  func_0x016790b0();
  func_0x016790b0();
  func_0x0056e380();
  func_0x0056e380();
  func_0x006d21e0();
  if (0xf < *(uint *)(unaff_EDI + 0x1b4)) {
    iVar2 = *(int *)(unaff_EDI + 0x1a0);
    iVar4 = iVar2;
    if ((0xfff < *(uint *)(unaff_EDI + 0x1b4) + 1) &&
       (iVar4 = *(int *)(iVar2 + -4), 0x1f < (iVar2 - iVar4) - 4U)) goto LAB_00688aff;
    func_0x01674ea0(iVar4);
  }
  *(undefined4 *)(unaff_EDI + 0x1b0) = 0;
  *(undefined4 *)(unaff_EDI + 0x1b4) = 0xf;
  *(undefined *)(unaff_EDI + 0x1a0) = 0;
  if (0xf < *(uint *)(unaff_EDI + 0x194)) {
    iVar2 = *(int *)(unaff_EDI + 0x180);
    iVar4 = iVar2;
    if ((0xfff < *(uint *)(unaff_EDI + 0x194) + 1) &&
       (iVar4 = *(int *)(iVar2 + -4), 0x1f < (iVar2 - iVar4) - 4U)) goto LAB_00688aff;
    func_0x01674ea0(iVar4);
  }
  *(undefined4 *)(unaff_EDI + 400) = 0;
  *(undefined4 *)(unaff_EDI + 0x194) = 0xf;
  *(undefined *)(unaff_EDI + 0x180) = 0;
  if (0xf < *(uint *)(unaff_EDI + 0x178)) {
    iVar2 = *(int *)(unaff_EDI + 0x164);
    iVar4 = iVar2;
    if ((0xfff < *(uint *)(unaff_EDI + 0x178) + 1) &&
       (iVar4 = *(int *)(iVar2 + -4), 0x1f < (iVar2 - iVar4) - 4U)) goto LAB_00688aff;
    func_0x01674ea0(iVar4);
  }
  *(undefined4 *)(unaff_EDI + 0x174) = 0;
  *(undefined4 *)(unaff_EDI + 0x178) = 0xf;
  *(undefined *)(unaff_EDI + 0x164) = 0;
  if (0xf < *(uint *)(unaff_EDI + 0x14c)) {
    iVar2 = *(int *)(unaff_EDI + 0x138);
    iVar4 = iVar2;
    if ((0xfff < *(uint *)(unaff_EDI + 0x14c) + 1) &&
       (iVar4 = *(int *)(iVar2 + -4), 0x1f < (iVar2 - iVar4) - 4U)) {
LAB_00688aff:
      func_0x017167a3();
      pcVar3 = (code *)swi(3);
      (*pcVar3)();
      return;
    }
    func_0x01674ea0(iVar4);
  }
  *(undefined4 *)(unaff_EDI + 0x148) = 0;
  *(undefined4 *)(unaff_EDI + 0x14c) = 0xf;
  *(undefined *)(unaff_EDI + 0x138) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x01679490();
  if (*(int *)(unaff_EDI + 0x10c) != 0) {
    piVar1 = (int *)(*(int *)(unaff_EDI + 0x10c) + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      func_0x01674ea0();
    }
  }
  *(undefined4 *)(unaff_EBP + -4) = 1;
  func_0x01679490();
  if (*(int *)(unaff_EDI + 0x108) != 0) {
    piVar1 = (int *)(*(int *)(unaff_EDI + 0x108) + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      func_0x01674ea0();
    }
  }
  *(undefined4 *)(unaff_EBP + -4) = 2;
  func_0x01679490();
  if (*(int *)(unaff_EDI + 0x104) != 0) {
    piVar1 = (int *)(*(int *)(unaff_EDI + 0x104) + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      func_0x01674ea0();
    }
  }
  func_0x006c4520();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00691ddc ; inferred entry: 00691ddc

void FUN_00691ddc(void)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  uVar1 = func_0x0086e8f0(&UNK_018d81ac);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00961580();
  uVar1 = func_0x0086e8f0(&UNK_018d81c4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00961580();
  uVar1 = func_0x0086e8f0(&UNK_018d81e0);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00961580();
  uVar1 = func_0x0086e8f0(&UNK_018d8204);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00961580();
  uVar1 = func_0x0086e8f0(&UNK_018d8224);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00961580();
  uVar1 = func_0x0086e8f0(&UNK_018d823c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00961580();
  uVar1 = func_0x0086e8f0(&UNK_018d8258);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  if (DAT_01d656d0 != '\0') {
    func_0x009ef640();
    uVar1 = func_0x0086e8f0(&UNK_018d8270);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x009ef640();
    uVar1 = func_0x0086e8f0(&UNK_018d8280);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x009ef640();
    uVar1 = func_0x0086e8f0(&UNK_018d8290);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    if (DAT_01d656d8 != '\0') {
      func_0x0068f950(&UNK_018d82a4,1);
    }
    if (DAT_01d65700 != '\0') {
      func_0x0068f950(&UNK_018d82bc,1);
    }
    if (DAT_01d65718 != '\0') {
      func_0x0068f950(&UNK_018d82d0,1);
    }
  }
  func_0x00c8d8e0();
  uVar1 = func_0x0086e8f0(&UNK_018d82e8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c8d8e0();
  uVar1 = func_0x0086e8f0(&UNK_018d8300);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c88fe0();
  uVar1 = func_0x0086e8f0(&UNK_018d82e8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c88fe0();
  uVar1 = func_0x0086e8f0(&UNK_018d8300);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c86e90();
  uVar1 = func_0x0086e8f0(&UNK_018d8314);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c86e90();
  uVar1 = func_0x0086e8f0(&UNK_018d832c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c63380();
  uVar1 = func_0x0086e8f0(&UNK_018d8314);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c63380();
  uVar1 = func_0x0086e8f0(&UNK_018d832c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x0099be20();
  uVar1 = func_0x0086e8f0(&UNK_018d8344);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 2;
  }
  if (DAT_01ee37b0 == '\0') {
    func_0x0099be20();
    uVar1 = func_0x0086e8f0(&UNK_018d8354);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 3;
    }
  }
  func_0x00ae6b40();
  uVar1 = func_0x0086e8f0(&UNK_018d8370);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 4;
  }
  func_0x00c55950();
  uVar1 = func_0x0086e8f0(&UNK_018d8384);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  if (DAT_01d68228 != '\0') {
    func_0x00c51e00();
    uVar1 = func_0x0086e8f0(&UNK_018d839c);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c51e00();
    uVar1 = func_0x0086e8f0(&UNK_018d83b8);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    if (DAT_01d68824 != '\0') {
      func_0x0068f900(&UNK_018d83d8,1);
      func_0x0068f900(&UNK_018d83f8,1);
    }
  }
  func_0x00ac0f70();
  uVar1 = func_0x0086e8f0(&UNK_018d8418);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00ac0f70();
  uVar1 = func_0x0086e8f0(&UNK_018d842c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8440);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bd5c00();
  uVar1 = func_0x0086e8f0(&UNK_018d8448);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bd5c00();
  uVar1 = func_0x0086e8f0(&UNK_018d8468);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bd5c00();
  uVar1 = func_0x0086e8f0(&UNK_018d8484);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bd5c00();
  uVar1 = func_0x0086e8f0(&UNK_018d84a4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c58700();
  uVar1 = func_0x0086e8f0(&UNK_018d84c4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c58700();
  uVar1 = func_0x0086e8f0(&UNK_018d84dc);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c58700();
  uVar1 = func_0x0086e8f0(&UNK_018d84f4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c58700();
  uVar1 = func_0x0086e8f0(&UNK_018d850c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c8dce0();
  uVar1 = func_0x0086e8f0(&UNK_018d8520);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c8dce0();
  uVar1 = func_0x0086e8f0(&UNK_018d8538);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00add460();
  uVar1 = func_0x0086e8f0(&UNK_018d8554);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 6;
  }
  func_0x00add460();
  uVar1 = func_0x0086e8f0(&UNK_018d8574);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 6;
  }
  func_0x00add460();
  uVar1 = func_0x0086e8f0(&UNK_018d8590);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 6;
  }
  func_0x00a75310();
  uVar1 = func_0x0086e8f0(&UNK_018d85a4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00a75310();
  uVar1 = func_0x0086e8f0(&UNK_018d85c8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00a75310();
  uVar1 = func_0x0086e8f0(&UNK_018d85f8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00a75310();
  uVar1 = func_0x0086e8f0(&UNK_018d8620);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bea180();
  uVar1 = func_0x0086e8f0(&UNK_018d8644);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bea180();
  uVar1 = func_0x0086e8f0(&UNK_018d8660);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00bd37d0();
  uVar1 = func_0x0086e8f0(&UNK_018d8678);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00b85410();
  uVar1 = func_0x0086e8f0(&UNK_018d868c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00b85410();
  uVar1 = func_0x0086e8f0(&UNK_018d86a0);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00b85410();
  uVar1 = func_0x0086e8f0(&UNK_018d86bc);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00b85410();
  uVar1 = func_0x0086e8f0(&UNK_018d86c8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00b85410();
  uVar1 = func_0x0086e8f0(&UNK_018d86d4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00aff8c0();
  uVar1 = func_0x0086e8f0(&UNK_018d86e4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00aff8c0();
  uVar1 = func_0x0086e8f0(&UNK_018d8704);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c4b970();
  uVar1 = func_0x0086e8f0(&UNK_018d8718);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c4b970();
  uVar1 = func_0x0086e8f0(&UNK_018d8730);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8748);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8764);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8780);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8794);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d87a8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d87b8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d87c8);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d87e4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8800);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8814);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00913630();
  uVar1 = func_0x0086e8f0(&UNK_018d8834);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00a36d80();
  uVar1 = func_0x0086e8f0(&UNK_018d8844);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c2a7d0();
  uVar1 = func_0x0086e8f0(&UNK_018d8870);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  if (DAT_01d5b0b8 != '\0') {
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d8888);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d8894);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d88a0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d88ac);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d88c0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d8888);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d8894);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d88d0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d88dc);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d88f0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d8904);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d8910);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d891c);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d8930);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d88ac);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d88c0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d8944);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d8958);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d8888);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d8894);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d88a0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d88ac);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d88c0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00693a56 ; inferred entry: 00693a56

void FUN_00693a56(void)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  uVar1 = func_0x0086e8f0(&UNK_018d7ce4);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 5;
  }
  func_0x00aff8c0();
  uVar1 = func_0x0086e8f0(&UNK_018d7d04);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c68a10();
  uVar1 = func_0x0086e8f0(&UNK_018d7d18);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c68a10();
  uVar1 = func_0x0086e8f0(&UNK_018d7d30);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c88fe0();
  uVar1 = func_0x0086e8f0(&UNK_018d7d4c);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c8dce0();
  uVar1 = func_0x0086e8f0(&UNK_018d7d58);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  func_0x00c809f0();
  uVar1 = func_0x0086e8f0(&UNK_018d7d74);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  if (DAT_01d5b0c0 == '\0') {
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d7d7c);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d7d98);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d7db4);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d7dd0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c7e1e0();
    uVar1 = func_0x0086e8f0(&UNK_018d7df0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7d7c);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7d98);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7e10);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7e2c);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7e50);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7e74);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6de80();
    uVar1 = func_0x0086e8f0(&UNK_018d7e90);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d7eac);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d7ed0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d7dd0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d7df0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d7ef4);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6dcc0();
    uVar1 = func_0x0086e8f0(&UNK_018d7f14);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d7d7c);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d7d98);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d7db4);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d7dd0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
    func_0x00c6ac40();
    uVar1 = func_0x0086e8f0(&UNK_018d7df0);
    piVar2 = (int *)func_0x00691400(uVar1);
    if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0)
       ) {
      iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
      *(undefined4 *)(iVar3 + 4) = 1;
    }
  }
  func_0x00894100();
  uVar1 = func_0x0086e8f0(&UNK_018d7f34);
  piVar2 = (int *)func_0x00691400(uVar1);
  if ((piVar2 != (int *)0x0) && (iVar3 = *piVar2, *(int *)(unaff_EBP + -0x14) = iVar3, iVar3 != 0))
  {
    iVar3 = func_0x0068fd30(unaff_EBP + -0x14);
    *(undefined4 *)(iVar3 + 4) = 1;
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x009f70ab ; inferred entry: 009f70ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_009f70ab(void)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  char unaff_BL;
  uint uVar7;
  int unaff_EBP;
  undefined *puVar8;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar9;
  undefined8 uVar10;
  
  *(char *)(unaff_EBP + 8) = unaff_BL;
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  func_0x005542c0(&UNK_0193d618);
  *(undefined4 *)(unaff_EBP + -4) = 3;
  puVar8 = &UNK_0191f6a0;
  if (unaff_BL == '\0') {
    puVar8 = &UNK_0191f658;
  }
  uVar3 = func_0x00558c80(unaff_EBP + -0x68,unaff_EBP + -0x38,puVar8);
  *(undefined *)(unaff_EBP + -4) = 4;
  func_0x008783f0(uVar3,1,0);
  func_0x005507b0();
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  func_0x005507b0();
  func_0x0087c450(&UNK_018c8444,&UNK_0193d638,puVar8,1,0,0);
  func_0x009facc0(*(undefined4 *)(unaff_EBP + 8));
  uVar3 = *(undefined4 *)(unaff_EBP + 0xc);
  if ((DAT_01d65710 != '\0') && (DAT_01d65708 != '\0')) {
    if ((DAT_01d65720 != '\0') ||
       (bVar9 = DAT_01d65728 != '\0', *(undefined *)(unaff_EBP + 0xc) = 0, bVar9)) {
      *(undefined *)(unaff_EBP + 0xc) = 1;
    }
    if (DAT_01d65a50 != '\0') {
      iVar4 = func_0x008f7870(uVar3);
      *(int *)(unaff_EBP + -0x18) = iVar4;
      if (iVar4 != 0) {
        *(int *)(unaff_EBP + 8) = iVar4 + 0xd4;
        uVar3 = _DAT_02110da8;
        *(undefined4 *)(unaff_EBP + -4) = 5;
        uVar5 = func_0x01675290(uVar3);
        *(undefined4 *)(unaff_EBP + -0x1c) = uVar5;
        *(undefined *)(unaff_EBP + -4) = 6;
        puVar6 = (undefined4 *)func_0x01674e20(0x1c);
        uVar3 = *(undefined4 *)(unaff_EBP + 8);
        *(undefined4 **)(unaff_EBP + -0x20) = puVar6;
        if (puVar6 == (undefined4 *)0x0) {
          puVar6 = (undefined4 *)0x0;
        }
        else {
          *puVar6 = 0;
          puVar6[1] = 1;
          puVar6[2] = &UNK_009f5330;
          puVar6[3] = _guard_check_icall;
          puVar6[4] = 0;
          puVar6[5] = uVar3;
          puVar6[6] = unaff_EDI;
        }
        func_0x016797d0(puVar6);
        *(undefined4 **)(unaff_EBP + -0x14) = puVar6;
        if (puVar6 != (undefined4 *)0x0) {
          LOCK();
          puVar6[1] = puVar6[1] + 1;
          UNLOCK();
        }
        *(undefined4 *)(unaff_EBP + -0x10) = 2;
        *(undefined *)(unaff_EBP + -4) = 7;
        func_0x01675290(uVar5);
        *(undefined *)(unaff_EBP + -4) = 5;
        func_0x00614020(unaff_EBP + -0x14);
        *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
        func_0x0056e750();
        piVar2 = *(int **)(*(int *)(unaff_EBP + -0x18) + 0x43c);
        iVar4 = piVar2[1];
        uVar7 = *piVar2 - (int)piVar2;
        uVar10 = func_0x016f3900(uVar7,iVar4 - (int)piVar2,10000,0);
        uVar10 = func_0x016f39b0(uVar10,10000,0);
        iVar4 = ((iVar4 - (int)piVar2) - (int)((ulonglong)uVar10 >> 0x20)) -
                (uint)(uVar7 < (uint)uVar10);
        if ((iVar4 <= (int)_DAT_01ee5c3c >> 0x1f) &&
           ((iVar4 < (int)_DAT_01ee5c3c >> 0x1f || (uVar7 - (uint)uVar10 < _DAT_01ee5c3c)))) {
          *(undefined *)(unaff_EBP + 0xc) = 1;
        }
      }
    }
    *(undefined4 *)(unaff_EBP + -0x40) = 0;
    *(undefined4 *)(unaff_EBP + -0x3c) = 0xf;
    *(undefined *)(unaff_EBP + -0x50) = 0;
    func_0x005542c0(&UNK_0193d644,0x2b);
    cVar1 = *(char *)(unaff_EBP + 0xc);
    *(undefined4 *)(unaff_EBP + -4) = 8;
    puVar8 = &UNK_0191f6a0;
    if (cVar1 == '\0') {
      puVar8 = &UNK_0191f658;
    }
    uVar3 = func_0x00558c80(unaff_EBP + -0x80,unaff_EBP + -0x50,puVar8);
    *(undefined *)(unaff_EBP + -4) = 9;
    func_0x008783f0(uVar3,1,0);
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
    func_0x005507b0();
    func_0x0087c450(&UNK_018c8444,&UNK_0193d670,puVar8,1,0,0);
    func_0x009facf0(*(undefined4 *)(unaff_EBP + 0xc));
    if ((DAT_01d65a50 == '\0') && (cVar1 != '\0')) {
      func_0x009f2120();
    }
  }
  if ((DAT_01d656e0 != '\0') && (*(char *)(unaff_EDI + 0xec) != DAT_01d656e8)) {
    *(char *)(unaff_EDI + 0xec) = DAT_01d656e8;
    func_0x008a4940(0x21252c8);
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00a052dc ; inferred entry: 00a052dc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00a052dc(void)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  double *pdVar6;
  int unaff_EBP;
  int *piVar7;
  undefined4 *unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  double dVar8;
  
  func_0x005542c0(&UNK_0193f168);
  *(undefined *)(unaff_EBP + -4) = 2;
  func_0x008783f0(unaff_EBP + -0x34,1,0);
  *(undefined *)(unaff_EBP + -4) = 0;
  func_0x005507b0();
  func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193f154,1,0,0);
  iVar5 = *(int *)(unaff_EBP + -0x14);
  if ((DAT_01d65a40 == '\0') || (*(char *)(iVar5 + 0x8d) != '\0')) {
    if (*(int *)(unaff_EBP + -0x10) != 0) {
      LOCK();
      piVar7 = (int *)(*(int *)(unaff_EBP + -0x10) + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    iVar5 = func_0x00a06980(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x10));
  }
  else {
    pdVar6 = (double *)func_0x016830f0(unaff_EBP + -0x1c);
    *(undefined4 *)(unaff_EBP + -0x24) = 0;
    *(undefined4 *)(unaff_EBP + -0x20) = 0xf;
    *(undefined *)(unaff_EBP + -0x34) = 0;
    *(int *)(*(int *)(unaff_EBP + -0x14) + 0xbc) =
         (int)((*pdVar6 - *(double *)(iVar5 + 0xa0)) * _DAT_018c0d70);
    dVar8 = (double)*(int *)(*(int *)(unaff_EBP + -0x14) + 0xbc);
    if (DAT_01d65a40 == '\0') {
      *(double *)(unaff_EBP + -0x1c) = dVar8;
      func_0x005542c0(&UNK_0193f1bc,0x37);
      *(undefined *)(unaff_EBP + -4) = 4;
      func_0x00878cf0(unaff_EBP + -0x34,*(undefined8 *)(unaff_EBP + -0x1c),0);
    }
    else {
      uVar3 = *(undefined *)(*(int *)(unaff_EBP + -0x14) + 0x8d);
      *(double *)(unaff_EBP + -0x1c) = dVar8;
      func_0x005542c0(&UNK_0193f1a8,0x10);
      *(undefined *)(unaff_EBP + -4) = 3;
      func_0x00a11480(unaff_EBP + -0x34,*(undefined8 *)(unaff_EBP + -0x1c),uVar3);
    }
    *(undefined *)(unaff_EBP + -4) = 0;
    func_0x005507b0();
    piVar7 = (int *)unaff_EDI[1];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
      piVar7 = (int *)unaff_EDI[1];
    }
    uVar4 = *unaff_EDI;
    piVar1 = piVar7 + 2;
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    func_0x00a02100(uVar4,piVar7,0);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
    iVar5 = func_0x0090ca30();
  }
  piVar7 = *(int **)(unaff_EBP + -0x10);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar5;
}



// Code reference: 0x00a0611d ; inferred entry: 00a0611d

int FUN_00a0611d(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_0193f09c);
  *(undefined *)(unaff_EBP + -4) = 8;
  func_0x008783f0(unaff_EBP + -0x40,1,0);
  *(undefined *)(unaff_EBP + -4) = 0;
  func_0x005507b0();
  iVar4 = func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193f08c,1,0,0);
  piVar3 = *(int **)(unaff_EBP + -0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar4;
}



// Code reference: 0x00a063c8 ; inferred entry: 00a063c8

int FUN_00a063c8(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_0193f09c);
  *(undefined *)(unaff_EBP + -4) = 6;
  func_0x008783f0(unaff_EBP + -0x34,1,0);
  *(undefined *)(unaff_EBP + -4) = 0;
  func_0x005507b0();
  iVar4 = func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193f08c,1,0,0);
  piVar3 = *(int **)(unaff_EBP + -0x18);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar4;
}



// Code reference: 0x00a06b4b ; inferred entry: 00a06b4b

void FUN_00a06b4b(void)

{
  uint uVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x005542c0(&UNK_0193e9b8);
  *(undefined4 *)(unaff_EBP + -4) = 1;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  uVar1 = *(uint *)(unaff_EBP + -0x18);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x2c);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
        func_0x017167a3();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
      }
    }
    func_0x01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193e99c,1,0,0);
  func_0x00a07430();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00a0b4cb ; inferred entry: 00a0b4cb

void FUN_00a0b4cb(void)

{
  uint uVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x005542c0(&UNK_0193e960);
  *(undefined4 *)(unaff_EBP + -4) = 1;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  uVar1 = *(uint *)(unaff_EBP + -0x18);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x2c);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
        func_0x017167a3();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
      }
    }
    func_0x01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193e950,1,0,0);
  func_0x00a09180();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00a0b6dc ; inferred entry: 00a0b6dc

int FUN_00a0b6dc(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_0193f388);
  *(undefined *)(unaff_EBP + -4) = 2;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  *(undefined *)(unaff_EBP + -4) = 0;
  func_0x005507b0();
  iVar4 = func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193f36c,1,0,0);
  piVar3 = *(int **)(unaff_EBP + -0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar4;
}



// Code reference: 0x00a0bd59 ; inferred entry: 00a0bd59

int FUN_00a0bd59(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x005542c0(&UNK_0193ea0c);
  *(undefined *)(unaff_EBP + -4) = 2;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  *(undefined *)(unaff_EBP + -4) = 0;
  func_0x005507b0();
  iVar4 = func_0x0087c450(&UNK_018c8444,&UNK_0193d670,&UNK_0193e9fc,1,0,0);
  piVar3 = *(int **)(unaff_EBP + -0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return iVar4;
}



// Code reference: 0x00a1138f ; inferred entry: 00a1138f

void FUN_00a1138f(void)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  char *pcVar5;
  int iVar6;
  char *pcVar7;
  uint uVar8;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  bool in_ZF;
  
  pcVar7 = "Studio.TeamCreate.CollabEditVersionHistory.";
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  if (in_ZF) {
    pcVar7 = "Studio.NonTeamCreate.VersionHistory.";
  }
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  pcVar5 = pcVar7;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  func_0x005542c0(pcVar7,(int)pcVar5 - (int)(pcVar7 + 1));
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x005f3cd0(unaff_EBP + -0x24,unaff_EBP + -0x3c,*(undefined4 *)(unaff_EBP + 8));
  *(undefined *)(unaff_EBP + -4) = 1;
  func_0x008783f0(unaff_EBP + -0x24,1,0);
  uVar2 = *(uint *)(unaff_EBP + -0x10);
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EBP + -0x24);
    uVar8 = uVar2 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar8 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
        func_0x017167a3();
        goto LAB_00a11478;
      }
    }
    func_0x01674ea0(iVar6,uVar8);
  }
  uVar2 = *(uint *)(unaff_EBP + -0x28);
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EBP + -0x3c);
    uVar8 = uVar2 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar8 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
LAB_00a11478:
        func_0x017167a3();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
      }
    }
    func_0x01674ea0(iVar6,uVar8);
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// Code reference: 0x00f5774a ; inferred entry: 00f5774a

undefined4 FUN_00f5774a(void)

{
  uint uVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  
  *(undefined *)(unaff_EBP + -4) = 1;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  func_0x005542c0(&UNK_0192a40c);
  *(undefined *)(unaff_EBP + -4) = 2;
  uVar4 = func_0x0151ed70(unaff_EBP + -0x84);
  *(undefined *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c59b4,5);
  *(undefined *)(unaff_EBP + -4) = 4;
  func_0x0151bcc0(unaff_EBP + -0xfc,unaff_EBP + -0x24,uVar4,unaff_EBP + -0x3c,unaff_EBP + -0x54,
                  unaff_EBP + -0x6c);
  uVar4 = *(undefined4 *)(unaff_EBP + 8);
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x0151bb70(uVar4);
  func_0x0056d9d0();
  uVar1 = *(uint *)(unaff_EBP + -0x10);
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x24);
    uVar6 = uVar1 + 1;
    iVar5 = iVar2;
    if (uVar6 < 0x1000) {
LAB_00f5780f:
      func_0x01674ea0(iVar5,uVar6);
      goto LAB_00f57819;
    }
    iVar5 = *(int *)(iVar2 + -4);
    uVar6 = uVar1 + 0x24;
    if ((iVar2 - iVar5) - 4U < 0x20) goto LAB_00f5780f;
    func_0x017167a3();
LAB_00f57945:
    func_0x017167a3();
LAB_00f5794a:
    func_0x017167a3();
LAB_00f5794f:
    func_0x017167a3();
LAB_00f57954:
    func_0x017167a3();
    pcVar3 = (code *)swi(3);
    uVar4 = (*pcVar3)();
    return uVar4;
  }
LAB_00f57819:
  uVar1 = *(uint *)(unaff_EBP + -0x70);
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x84);
    uVar6 = uVar1 + 1;
    iVar5 = iVar2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar6 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00f57945;
    }
    func_0x01674ea0(iVar5,uVar6);
  }
  uVar1 = *(uint *)(unaff_EBP + -0x28);
  *(undefined4 *)(unaff_EBP + -0x74) = 0;
  *(undefined4 *)(unaff_EBP + -0x70) = 0xf;
  *(undefined *)(unaff_EBP + -0x84) = 0;
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x3c);
    uVar6 = uVar1 + 1;
    iVar5 = iVar2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar6 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00f5794a;
    }
    func_0x01674ea0(iVar5,uVar6);
  }
  uVar1 = *(uint *)(unaff_EBP + -0x40);
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x54);
    uVar6 = uVar1 + 1;
    iVar5 = iVar2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar6 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00f5794f;
    }
    func_0x01674ea0(iVar5,uVar6);
  }
  uVar1 = *(uint *)(unaff_EBP + -0x58);
  *(undefined4 *)(unaff_EBP + -0x44) = 0;
  *(undefined4 *)(unaff_EBP + -0x40) = 0xf;
  *(undefined *)(unaff_EBP + -0x54) = 0;
  if (0xf < uVar1) {
    iVar2 = *(int *)(unaff_EBP + -0x6c);
    uVar6 = uVar1 + 1;
    iVar5 = iVar2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar6 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00f57954;
    }
    func_0x01674ea0(iVar5,uVar6);
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar4;
}


