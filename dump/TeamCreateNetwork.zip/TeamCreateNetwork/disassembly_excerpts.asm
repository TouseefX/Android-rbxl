; Partial x86 disassembly starting at verified references (NOT full functions).
; Addresses are image-base virtual addresses. Sample: up to 180 highest-ranked unique code references.

; === 001 | 0x4719a7 | RCCTeamCreateSaveOnZeroPlayers ===
004719a7: 68d8568c01   push     0x18c56d8
004719ac: e89f652001   call     0x1677f50
004719b1: 83c40c       add      esp, 0xc
004719b4: a3908dea01   mov      dword ptr [0x1ea8d90], eax
004719b9: c3           ret      
004719ba: cc           int3     
004719bb: cc           int3     
004719bc: cc           int3     
004719bd: cc           int3     
004719be: cc           int3     
004719bf: cc           int3     
004719c0: b9a08dea01   mov      ecx, 0x1ea8da0
004719c5: e976571800   jmp      0x5f7140
004719ca: cc           int3     
004719cb: cc           int3     
004719cc: cc           int3     
004719cd: cc           int3     
004719ce: cc           int3     
004719cf: cc           int3     
004719d0: 6a24         push     0x24
004719d2: 68d8e38b01   push     0x18be3d8
004719d7: b9a097d501   mov      ecx, 0x1d597a0
004719dc: e8df280e00   call     0x5542c0
004719e1: 6870b88701   push     0x187b870
004719e6: e8691c2801   call     0x16f3654
004719eb: 59           pop      ecx
004719ec: c3           ret      
004719ed: cc           int3     
004719ee: cc           int3     
004719ef: cc           int3     
004719f0: e88b392101   call     0x1685380
004719f5: a3988dea01   mov      dword ptr [0x1ea8d98], eax
004719fa: c3           ret      
004719fb: cc           int3     
004719fc: cc           int3     
004719fd: cc           int3     
004719fe: cc           int3     
004719ff: cc           int3     
00471a00: e82b3d2101   call     0x1685730
00471a05: a3348dea01   mov      dword ptr [0x1ea8d34], eax
00471a0a: c3           ret      
00471a0b: cc           int3     
00471a0c: cc           int3     
00471a0d: cc           int3     
00471a0e: cc           int3     
00471a0f: cc           int3     
00471a10: e86b392101   call     0x1685380
00471a15: a3308dea01   mov      dword ptr [0x1ea8d30], eax
00471a1a: c3           ret      
00471a1b: cc           int3     
00471a1c: cc           int3     
00471a1d: cc           int3     
00471a1e: cc           int3     
00471a1f: cc           int3     
00471a20: e85b392101   call     0x1685380
00471a25: a3208eea01   mov      dword ptr [0x1ea8e20], eax
00471a2a: c3           ret      
00471a2b: cc           int3     
00471a2c: cc           int3     
00471a2d: cc           int3     
00471a2e: cc           int3     
00471a2f: cc           int3     
00471a30: e8fb3c2101   call     0x1685730
00471a35: a3188eea01   mov      dword ptr [0x1ea8e18], eax
00471a3a: c3           ret      
00471a3b: cc           int3     
00471a3c: cc           int3     
00471a3d: cc           int3     
00471a3e: cc           int3     
00471a3f: cc           int3     
00471a40: e83b392101   call     0x1685380
00471a45: a3148eea01   mov      dword ptr [0x1ea8e14], eax
00471a4a: c3           ret      

; === 002 | 0x471f07 | CloudEditGARespectsThrottling ===
00471f07: 6808828c01   push     0x18c8208
00471f0c: e83f602001   call     0x1677f50
00471f11: 83c40c       add      esp, 0xc
00471f14: a3a893ea01   mov      dword ptr [0x1ea93a8], eax
00471f19: c3           ret      
00471f1a: cc           int3     
00471f1b: cc           int3     
00471f1c: cc           int3     
00471f1d: cc           int3     
00471f1e: cc           int3     
00471f1f: cc           int3     
00471f20: 6a02         push     2
00471f22: 68709ad501   push     0x1d59a70
00471f27: 6828828c01   push     0x18c8228
00471f2c: e81f602001   call     0x1677f50
00471f31: 83c40c       add      esp, 0xc
00471f34: a3b093ea01   mov      dword ptr [0x1ea93b0], eax
00471f39: c3           ret      
00471f3a: cc           int3     
00471f3b: cc           int3     
00471f3c: cc           int3     
00471f3d: cc           int3     
00471f3e: cc           int3     
00471f3f: cc           int3     
00471f40: 6a02         push     2
00471f42: 68789ad501   push     0x1d59a78
00471f47: 6848828c01   push     0x18c8248
00471f4c: e8ff5f2001   call     0x1677f50
00471f51: 83c40c       add      esp, 0xc
00471f54: a3ac93ea01   mov      dword ptr [0x1ea93ac], eax
00471f59: c3           ret      
00471f5a: cc           int3     
00471f5b: cc           int3     
00471f5c: cc           int3     
00471f5d: cc           int3     
00471f5e: cc           int3     
00471f5f: cc           int3     
00471f60: 6a02         push     2
00471f62: 68b898d501   push     0x1d598b8
00471f67: 6898818c01   push     0x18c8198
00471f6c: e81f602001   call     0x1677f90
00471f71: 83c40c       add      esp, 0xc
00471f74: a39893ea01   mov      dword ptr [0x1ea9398], eax
00471f79: c3           ret      
00471f7a: cc           int3     
00471f7b: cc           int3     
00471f7c: cc           int3     
00471f7d: cc           int3     
00471f7e: cc           int3     
00471f7f: cc           int3     
00471f80: 6a02         push     2
00471f82: 68c098d501   push     0x1d598c0
00471f87: 68bc818c01   push     0x18c81bc
00471f8c: e8ff5f2001   call     0x1677f90
00471f91: 83c40c       add      esp, 0xc
00471f94: a3a493ea01   mov      dword ptr [0x1ea93a4], eax
00471f99: c3           ret      
00471f9a: cc           int3     
00471f9b: cc           int3     
00471f9c: cc           int3     
00471f9d: cc           int3     
00471f9e: cc           int3     
00471f9f: cc           int3     
00471fa0: 6a02         push     2
00471fa2: 68a898d501   push     0x1d598a8
00471fa7: 6854818c01   push     0x18c8154

; === 003 | 0x471f27 | CloudEditSaveFailureExtraInfo ===
00471f27: 6828828c01   push     0x18c8228
00471f2c: e81f602001   call     0x1677f50
00471f31: 83c40c       add      esp, 0xc
00471f34: a3b093ea01   mov      dword ptr [0x1ea93b0], eax
00471f39: c3           ret      
00471f3a: cc           int3     
00471f3b: cc           int3     
00471f3c: cc           int3     
00471f3d: cc           int3     
00471f3e: cc           int3     
00471f3f: cc           int3     
00471f40: 6a02         push     2
00471f42: 68789ad501   push     0x1d59a78
00471f47: 6848828c01   push     0x18c8248
00471f4c: e8ff5f2001   call     0x1677f50
00471f51: 83c40c       add      esp, 0xc
00471f54: a3ac93ea01   mov      dword ptr [0x1ea93ac], eax
00471f59: c3           ret      
00471f5a: cc           int3     
00471f5b: cc           int3     
00471f5c: cc           int3     
00471f5d: cc           int3     
00471f5e: cc           int3     
00471f5f: cc           int3     
00471f60: 6a02         push     2
00471f62: 68b898d501   push     0x1d598b8
00471f67: 6898818c01   push     0x18c8198
00471f6c: e81f602001   call     0x1677f90
00471f71: 83c40c       add      esp, 0xc
00471f74: a39893ea01   mov      dword ptr [0x1ea9398], eax
00471f79: c3           ret      
00471f7a: cc           int3     
00471f7b: cc           int3     
00471f7c: cc           int3     
00471f7d: cc           int3     
00471f7e: cc           int3     
00471f7f: cc           int3     
00471f80: 6a02         push     2
00471f82: 68c098d501   push     0x1d598c0
00471f87: 68bc818c01   push     0x18c81bc
00471f8c: e8ff5f2001   call     0x1677f90
00471f91: 83c40c       add      esp, 0xc
00471f94: a3a493ea01   mov      dword ptr [0x1ea93a4], eax
00471f99: c3           ret      
00471f9a: cc           int3     
00471f9b: cc           int3     
00471f9c: cc           int3     
00471f9d: cc           int3     
00471f9e: cc           int3     
00471f9f: cc           int3     
00471fa0: 6a02         push     2
00471fa2: 68a898d501   push     0x1d598a8
00471fa7: 6854818c01   push     0x18c8154
00471fac: e8df5f2001   call     0x1677f90
00471fb1: 83c40c       add      esp, 0xc
00471fb4: a39c93ea01   mov      dword ptr [0x1ea939c], eax
00471fb9: c3           ret      
00471fba: cc           int3     
00471fbb: cc           int3     
00471fbc: cc           int3     
00471fbd: cc           int3     
00471fbe: cc           int3     
00471fbf: cc           int3     
00471fc0: 6a02         push     2
00471fc2: 68b098d501   push     0x1d598b0
00471fc7: 6878818c01   push     0x18c8178

; === 004 | 0x471f47 | CloudEditSendPublishAnalyticsToDiag ===
00471f47: 6848828c01   push     0x18c8248
00471f4c: e8ff5f2001   call     0x1677f50
00471f51: 83c40c       add      esp, 0xc
00471f54: a3ac93ea01   mov      dword ptr [0x1ea93ac], eax
00471f59: c3           ret      
00471f5a: cc           int3     
00471f5b: cc           int3     
00471f5c: cc           int3     
00471f5d: cc           int3     
00471f5e: cc           int3     
00471f5f: cc           int3     
00471f60: 6a02         push     2
00471f62: 68b898d501   push     0x1d598b8
00471f67: 6898818c01   push     0x18c8198
00471f6c: e81f602001   call     0x1677f90
00471f71: 83c40c       add      esp, 0xc
00471f74: a39893ea01   mov      dword ptr [0x1ea9398], eax
00471f79: c3           ret      
00471f7a: cc           int3     
00471f7b: cc           int3     
00471f7c: cc           int3     
00471f7d: cc           int3     
00471f7e: cc           int3     
00471f7f: cc           int3     
00471f80: 6a02         push     2
00471f82: 68c098d501   push     0x1d598c0
00471f87: 68bc818c01   push     0x18c81bc
00471f8c: e8ff5f2001   call     0x1677f90
00471f91: 83c40c       add      esp, 0xc
00471f94: a3a493ea01   mov      dword ptr [0x1ea93a4], eax
00471f99: c3           ret      
00471f9a: cc           int3     
00471f9b: cc           int3     
00471f9c: cc           int3     
00471f9d: cc           int3     
00471f9e: cc           int3     
00471f9f: cc           int3     
00471fa0: 6a02         push     2
00471fa2: 68a898d501   push     0x1d598a8
00471fa7: 6854818c01   push     0x18c8154
00471fac: e8df5f2001   call     0x1677f90
00471fb1: 83c40c       add      esp, 0xc
00471fb4: a39c93ea01   mov      dword ptr [0x1ea939c], eax
00471fb9: c3           ret      
00471fba: cc           int3     
00471fbb: cc           int3     
00471fbc: cc           int3     
00471fbd: cc           int3     
00471fbe: cc           int3     
00471fbf: cc           int3     
00471fc0: 6a02         push     2
00471fc2: 68b098d501   push     0x1d598b0
00471fc7: 6878818c01   push     0x18c8178
00471fcc: e8bf5f2001   call     0x1677f90
00471fd1: 83c40c       add      esp, 0xc
00471fd4: a3a093ea01   mov      dword ptr [0x1ea93a0], eax
00471fd9: c3           ret      
00471fda: cc           int3     
00471fdb: cc           int3     
00471fdc: cc           int3     
00471fdd: cc           int3     
00471fde: cc           int3     
00471fdf: cc           int3     
00471fe0: 6a02         push     2
00471fe2: 68c898d501   push     0x1d598c8
00471fe7: 68e0818c01   push     0x18c81e0

; === 005 | 0x471fe7 | ReportTeamCreatePublishFailurePermyriad ===
00471fe7: 68e0818c01   push     0x18c81e0
00471fec: e89f5f2001   call     0x1677f90
00471ff1: 83c40c       add      esp, 0xc
00471ff4: a3b493ea01   mov      dword ptr [0x1ea93b4], eax
00471ff9: c3           ret      
00471ffa: cc           int3     
00471ffb: cc           int3     
00471ffc: cc           int3     
00471ffd: cc           int3     
00471ffe: cc           int3     
00471fff: cc           int3     
00472000: 6a02         push     2
00472002: 687e93ea01   push     0x1ea937e
00472007: 68ac828c01   push     0x18c82ac
0047200c: e89f5f2001   call     0x1677fb0
00472011: 83c40c       add      esp, 0xc
00472014: a3bc93ea01   mov      dword ptr [0x1ea93bc], eax
00472019: c3           ret      
0047201a: cc           int3     
0047201b: cc           int3     
0047201c: cc           int3     
0047201d: cc           int3     
0047201e: cc           int3     
0047201f: cc           int3     
00472020: 6a02         push     2
00472022: 687c93ea01   push     0x1ea937c
00472027: 686c828c01   push     0x18c826c
0047202c: e87f5f2001   call     0x1677fb0
00472031: 83c40c       add      esp, 0xc
00472034: a3c093ea01   mov      dword ptr [0x1ea93c0], eax
00472039: c3           ret      
0047203a: cc           int3     
0047203b: cc           int3     
0047203c: cc           int3     
0047203d: cc           int3     
0047203e: cc           int3     
0047203f: cc           int3     
00472040: 6a02         push     2
00472042: 687d93ea01   push     0x1ea937d
00472047: 6888828c01   push     0x18c8288
0047204c: e85f5f2001   call     0x1677fb0
00472051: 83c40c       add      esp, 0xc
00472054: a39093ea01   mov      dword ptr [0x1ea9390], eax
00472059: c3           ret      
0047205a: cc           int3     
0047205b: cc           int3     
0047205c: cc           int3     
0047205d: cc           int3     
0047205e: cc           int3     
0047205f: cc           int3     
00472060: e81b332101   call     0x1685380
00472065: a3b893ea01   mov      dword ptr [0x1ea93b8], eax
0047206a: c3           ret      
0047206b: cc           int3     
0047206c: cc           int3     
0047206d: cc           int3     
0047206e: cc           int3     
0047206f: cc           int3     
00472070: 6a0b         push     0xb
00472072: 68f4828c01   push     0x18c82f4
00472077: b9509ad501   mov      ecx, 0x1d59a50
0047207c: e83f220e00   call     0x5542c0
00472081: 6890bb8701   push     0x187bb90
00472086: e8c9152801   call     0x16f3654
0047208b: 59           pop      ecx

; === 006 | 0x472007 | TeamCreatePublishExtraInfo ===
00472007: 68ac828c01   push     0x18c82ac
0047200c: e89f5f2001   call     0x1677fb0
00472011: 83c40c       add      esp, 0xc
00472014: a3bc93ea01   mov      dword ptr [0x1ea93bc], eax
00472019: c3           ret      
0047201a: cc           int3     
0047201b: cc           int3     
0047201c: cc           int3     
0047201d: cc           int3     
0047201e: cc           int3     
0047201f: cc           int3     
00472020: 6a02         push     2
00472022: 687c93ea01   push     0x1ea937c
00472027: 686c828c01   push     0x18c826c
0047202c: e87f5f2001   call     0x1677fb0
00472031: 83c40c       add      esp, 0xc
00472034: a3c093ea01   mov      dword ptr [0x1ea93c0], eax
00472039: c3           ret      
0047203a: cc           int3     
0047203b: cc           int3     
0047203c: cc           int3     
0047203d: cc           int3     
0047203e: cc           int3     
0047203f: cc           int3     
00472040: 6a02         push     2
00472042: 687d93ea01   push     0x1ea937d
00472047: 6888828c01   push     0x18c8288
0047204c: e85f5f2001   call     0x1677fb0
00472051: 83c40c       add      esp, 0xc
00472054: a39093ea01   mov      dword ptr [0x1ea9390], eax
00472059: c3           ret      
0047205a: cc           int3     
0047205b: cc           int3     
0047205c: cc           int3     
0047205d: cc           int3     
0047205e: cc           int3     
0047205f: cc           int3     
00472060: e81b332101   call     0x1685380
00472065: a3b893ea01   mov      dword ptr [0x1ea93b8], eax
0047206a: c3           ret      
0047206b: cc           int3     
0047206c: cc           int3     
0047206d: cc           int3     
0047206e: cc           int3     
0047206f: cc           int3     
00472070: 6a0b         push     0xb
00472072: 68f4828c01   push     0x18c82f4
00472077: b9509ad501   mov      ecx, 0x1d59a50
0047207c: e83f220e00   call     0x5542c0
00472081: 6890bb8701   push     0x187bb90
00472086: e8c9152801   call     0x16f3654
0047208b: 59           pop      ecx
0047208c: c3           ret      
0047208d: cc           int3     
0047208e: cc           int3     
0047208f: cc           int3     
00472090: 6a04         push     4
00472092: 68ec828c01   push     0x18c82ec
00472097: b9389ad501   mov      ecx, 0x1d59a38
0047209c: e81f220e00   call     0x5542c0
004720a1: 68f0bb8701   push     0x187bbf0
004720a6: e8a9152801   call     0x16f3654
004720ab: 59           pop      ecx

; === 007 | 0x472047 | TrackTeamCreateSaveMD5HashOutput ===
00472047: 6888828c01   push     0x18c8288
0047204c: e85f5f2001   call     0x1677fb0
00472051: 83c40c       add      esp, 0xc
00472054: a39093ea01   mov      dword ptr [0x1ea9390], eax
00472059: c3           ret      
0047205a: cc           int3     
0047205b: cc           int3     
0047205c: cc           int3     
0047205d: cc           int3     
0047205e: cc           int3     
0047205f: cc           int3     
00472060: e81b332101   call     0x1685380
00472065: a3b893ea01   mov      dword ptr [0x1ea93b8], eax
0047206a: c3           ret      
0047206b: cc           int3     
0047206c: cc           int3     
0047206d: cc           int3     
0047206e: cc           int3     
0047206f: cc           int3     
00472070: 6a0b         push     0xb
00472072: 68f4828c01   push     0x18c82f4
00472077: b9509ad501   mov      ecx, 0x1d59a50
0047207c: e83f220e00   call     0x5542c0
00472081: 6890bb8701   push     0x187bb90
00472086: e8c9152801   call     0x16f3654
0047208b: 59           pop      ecx
0047208c: c3           ret      
0047208d: cc           int3     
0047208e: cc           int3     
0047208f: cc           int3     
00472090: 6a04         push     4
00472092: 68ec828c01   push     0x18c82ec
00472097: b9389ad501   mov      ecx, 0x1d59a38
0047209c: e81f220e00   call     0x5542c0
004720a1: 68f0bb8701   push     0x187bbf0
004720a6: e8a9152801   call     0x16f3654
004720ab: 59           pop      ecx
004720ac: c3           ret      
004720ad: cc           int3     
004720ae: cc           int3     
004720af: cc           int3     
004720b0: 6a12         push     0x12
004720b2: 68d8828c01   push     0x18c82d8
004720b7: b9089ad501   mov      ecx, 0x1d59a08
004720bc: e8ff210e00   call     0x5542c0
004720c1: 6850bc8701   push     0x187bc50
004720c6: e889152801   call     0x16f3654
004720cb: 59           pop      ecx
004720cc: c3           ret      
004720cd: cc           int3     
004720ce: cc           int3     
004720cf: cc           int3     
004720d0: 6a07         push     7
004720d2: 68185e8c01   push     0x18c5e18
004720d7: b9209ad501   mov      ecx, 0x1d59a20
004720dc: e8df210e00   call     0x5542c0
004720e1: 68b0bc8701   push     0x187bcb0
004720e6: e869152801   call     0x16f3654
004720eb: 59           pop      ecx

; === 008 | 0x472617 | DontLoadCloudLocalizationSettingsOnCloudEditMode ===
00472617: 6814908c01   push     0x18c9014
0047261c: e82f592001   call     0x1677f50
00472621: 83c40c       add      esp, 0xc
00472624: a34cadea01   mov      dword ptr [0x1eaad4c], eax
00472629: c3           ret      
0047262a: cc           int3     
0047262b: cc           int3     
0047262c: cc           int3     
0047262d: cc           int3     
0047262e: cc           int3     
0047262f: cc           int3     
00472630: 6a01         push     1
00472632: 68189cd501   push     0x1d59c18
00472637: 68f08f8c01   push     0x18c8ff0
0047263c: e80f592001   call     0x1677f50
00472641: 83c40c       add      esp, 0xc
00472644: a344adea01   mov      dword ptr [0x1eaad44], eax
00472649: c3           ret      
0047264a: cc           int3     
0047264b: cc           int3     
0047264c: cc           int3     
0047264d: cc           int3     
0047264e: cc           int3     
0047264f: cc           int3     
00472650: 6a23         push     0x23
00472652: 686c908c01   push     0x18c906c
00472657: b9d89bd501   mov      ecx, 0x1d59bd8
0047265c: e85f1c0e00   call     0x5542c0
00472661: 6870c38701   push     0x187c370
00472666: e8e90f2801   call     0x16f3654
0047266b: 59           pop      ecx
0047266c: c3           ret      
0047266d: cc           int3     
0047266e: cc           int3     
0047266f: cc           int3     
00472670: 6a01         push     1
00472672: 68d89bd501   push     0x1d59bd8
00472677: 68808f8c01   push     0x18c8f80
0047267c: e84f592001   call     0x1677fd0
00472681: 83c40c       add      esp, 0xc
00472684: a334adea01   mov      dword ptr [0x1eaad34], eax
00472689: c3           ret      
0047268a: cc           int3     
0047268b: cc           int3     
0047268c: cc           int3     
0047268d: cc           int3     
0047268e: cc           int3     
0047268f: cc           int3     
00472690: 6a15         push     0x15
00472692: 6890908c01   push     0x18c9090
00472697: b9f09bd501   mov      ecx, 0x1d59bf0
0047269c: e81f1c0e00   call     0x5542c0
004726a1: 68d0c38701   push     0x187c3d0
004726a6: e8a90f2801   call     0x16f3654
004726ab: 59           pop      ecx
004726ac: c3           ret      
004726ad: cc           int3     
004726ae: cc           int3     
004726af: cc           int3     
004726b0: 6a01         push     1
004726b2: 68f09bd501   push     0x1d59bf0
004726b7: 689c8f8c01   push     0x18c8f9c

; === 009 | 0x472c87 | CheckTeamCreateReplicatorQueue ===
00472c87: 6874a98c01   push     0x18ca974
00472c8c: e8bf522001   call     0x1677f50
00472c91: 83c40c       add      esp, 0xc
00472c94: a318d0ea01   mov      dword ptr [0x1ead018], eax
00472c99: c3           ret      
00472c9a: cc           int3     
00472c9b: cc           int3     
00472c9c: cc           int3     
00472c9d: cc           int3     
00472c9e: cc           int3     
00472c9f: cc           int3     
00472ca0: 6a02         push     2
00472ca2: 68649ed501   push     0x1d59e64
00472ca7: 680ca48c01   push     0x18ca40c
00472cac: e8df522001   call     0x1677f90
00472cb1: 83c40c       add      esp, 0xc
00472cb4: a364cfea01   mov      dword ptr [0x1eacf64], eax
00472cb9: c3           ret      
00472cba: cc           int3     
00472cbb: cc           int3     
00472cbc: cc           int3     
00472cbd: cc           int3     
00472cbe: cc           int3     
00472cbf: cc           int3     
00472cc0: 6a02         push     2
00472cc2: 686c9ed501   push     0x1d59e6c
00472cc7: 6824a48c01   push     0x18ca424
00472ccc: e8bf522001   call     0x1677f90
00472cd1: 83c40c       add      esp, 0xc
00472cd4: a368cfea01   mov      dword ptr [0x1eacf68], eax
00472cd9: c3           ret      
00472cda: cc           int3     
00472cdb: cc           int3     
00472cdc: cc           int3     
00472cdd: cc           int3     
00472cde: cc           int3     
00472cdf: cc           int3     
00472ce0: 6a01         push     1
00472ce2: 6898a0d501   push     0x1d5a098
00472ce7: 684ca38c01   push     0x18ca34c
00472cec: e85f522001   call     0x1677f50
00472cf1: 83c40c       add      esp, 0xc
00472cf4: a350cfea01   mov      dword ptr [0x1eacf50], eax
00472cf9: c3           ret      
00472cfa: cc           int3     
00472cfb: cc           int3     
00472cfc: cc           int3     
00472cfd: cc           int3     
00472cfe: cc           int3     
00472cff: cc           int3     
00472d00: 6a02         push     2
00472d02: 68a0a0d501   push     0x1d5a0a0
00472d07: 6890a38c01   push     0x18ca390
00472d0c: e83f522001   call     0x1677f50
00472d11: 83c40c       add      esp, 0xc
00472d14: a358cfea01   mov      dword ptr [0x1eacf58], eax
00472d19: c3           ret      
00472d1a: cc           int3     
00472d1b: cc           int3     
00472d1c: cc           int3     
00472d1d: cc           int3     
00472d1e: cc           int3     
00472d1f: cc           int3     
00472d20: 6a02         push     2
00472d22: 68c09fd501   push     0x1d59fc0
00472d27: 6878a38c01   push     0x18ca378

; === 010 | 0x4737b7 | TeamCreateServerScriptChanges ===
004737b7: 68949d8c01   push     0x18c9d94
004737bc: e8ef472001   call     0x1677fb0
004737c1: 83c40c       add      esp, 0xc
004737c4: a3b0ceea01   mov      dword ptr [0x1eaceb0], eax
004737c9: c3           ret      
004737ca: cc           int3     
004737cb: cc           int3     
004737cc: cc           int3     
004737cd: cc           int3     
004737ce: cc           int3     
004737cf: cc           int3     
004737d0: 6a02         push     2
004737d2: 6820a0d501   push     0x1d5a020
004737d7: 68cc9f8c01   push     0x18c9fcc
004737dc: e86f472001   call     0x1677f50
004737e1: 83c40c       add      esp, 0xc
004737e4: a3f4ceea01   mov      dword ptr [0x1eacef4], eax
004737e9: c3           ret      
004737ea: cc           int3     
004737eb: cc           int3     
004737ec: cc           int3     
004737ed: cc           int3     
004737ee: cc           int3     
004737ef: cc           int3     
004737f0: 6a02         push     2
004737f2: 68709fd501   push     0x1d59f70
004737f7: 6858a98c01   push     0x18ca958
004737fc: e88f472001   call     0x1677f90
00473801: 83c40c       add      esp, 0xc
00473804: a314d0ea01   mov      dword ptr [0x1ead014], eax
00473809: c3           ret      
0047380a: cc           int3     
0047380b: cc           int3     
0047380c: cc           int3     
0047380d: cc           int3     
0047380e: cc           int3     
0047380f: cc           int3     
00473810: b980ceea01   mov      ecx, 0x1eace80
00473815: e926391800   jmp      0x5f7140
0047381a: cc           int3     
0047381b: cc           int3     
0047381c: cc           int3     
0047381d: cc           int3     
0047381e: cc           int3     
0047381f: cc           int3     
00473820: 6a04         push     4
00473822: 68fc9dd501   push     0x1d59dfc
00473827: 68aca08c01   push     0x18ca0ac
0047382c: e83f472001   call     0x1677f70
00473831: 83c40c       add      esp, 0xc
00473834: a308cfea01   mov      dword ptr [0x1eacf08], eax
00473839: c3           ret      
0047383a: cc           int3     
0047383b: cc           int3     
0047383c: cc           int3     
0047383d: cc           int3     
0047383e: cc           int3     
0047383f: cc           int3     
00473840: 6a24         push     0x24
00473842: 68d8e38b01   push     0x18be3d8
00473847: b9a09fd501   mov      ecx, 0x1d59fa0
0047384c: e86f0a0e00   call     0x5542c0
00473851: 68a0c58701   push     0x187c5a0
00473856: e8f9fd2701   call     0x16f3654
0047385b: 59           pop      ecx

; === 011 | 0x4737d7 | TeamCreateServerTrackScriptChangesFullSource ===
004737d7: 68cc9f8c01   push     0x18c9fcc
004737dc: e86f472001   call     0x1677f50
004737e1: 83c40c       add      esp, 0xc
004737e4: a3f4ceea01   mov      dword ptr [0x1eacef4], eax
004737e9: c3           ret      
004737ea: cc           int3     
004737eb: cc           int3     
004737ec: cc           int3     
004737ed: cc           int3     
004737ee: cc           int3     
004737ef: cc           int3     
004737f0: 6a02         push     2
004737f2: 68709fd501   push     0x1d59f70
004737f7: 6858a98c01   push     0x18ca958
004737fc: e88f472001   call     0x1677f90
00473801: 83c40c       add      esp, 0xc
00473804: a314d0ea01   mov      dword ptr [0x1ead014], eax
00473809: c3           ret      
0047380a: cc           int3     
0047380b: cc           int3     
0047380c: cc           int3     
0047380d: cc           int3     
0047380e: cc           int3     
0047380f: cc           int3     
00473810: b980ceea01   mov      ecx, 0x1eace80
00473815: e926391800   jmp      0x5f7140
0047381a: cc           int3     
0047381b: cc           int3     
0047381c: cc           int3     
0047381d: cc           int3     
0047381e: cc           int3     
0047381f: cc           int3     
00473820: 6a04         push     4
00473822: 68fc9dd501   push     0x1d59dfc
00473827: 68aca08c01   push     0x18ca0ac
0047382c: e83f472001   call     0x1677f70
00473831: 83c40c       add      esp, 0xc
00473834: a308cfea01   mov      dword ptr [0x1eacf08], eax
00473839: c3           ret      
0047383a: cc           int3     
0047383b: cc           int3     
0047383c: cc           int3     
0047383d: cc           int3     
0047383e: cc           int3     
0047383f: cc           int3     
00473840: 6a24         push     0x24
00473842: 68d8e38b01   push     0x18be3d8
00473847: b9a09fd501   mov      ecx, 0x1d59fa0
0047384c: e86f0a0e00   call     0x5542c0
00473851: 68a0c58701   push     0x187c5a0
00473856: e8f9fd2701   call     0x16f3654
0047385b: 59           pop      ecx
0047385c: c3           ret      
0047385d: cc           int3     
0047385e: cc           int3     
0047385f: cc           int3     
00473860: 55           push     ebp
00473861: 8bec         mov      ebp, esp
00473863: 6aff         push     -1
00473865: 68bada7901   push     0x179daba
0047386a: 64a100000000 mov      eax, dword ptr fs:[0]
00473870: 50           push     eax
00473871: 64892500000000 mov      dword ptr fs:[0], esp
00473878: 83ec0c       sub      esp, 0xc

; === 012 | 0x474277 | RCCSupportCloudEdit ===
00474277: 686cf18c01   push     0x18cf16c
0047427c: e8cf3c2001   call     0x1677f50
00474281: 83c40c       add      esp, 0xc
00474284: a3fcd6ea01   mov      dword ptr [0x1ead6fc], eax
00474289: c3           ret      
0047428a: cc           int3     
0047428b: cc           int3     
0047428c: cc           int3     
0047428d: cc           int3     
0047428e: cc           int3     
0047428f: cc           int3     
00474290: 6a01         push     1
00474292: 68d8a4d501   push     0x1d5a4d8
00474297: 6880f18c01   push     0x18cf180
0047429c: e8af3c2001   call     0x1677f50
004742a1: 83c40c       add      esp, 0xc
004742a4: a300d7ea01   mov      dword ptr [0x1ead700], eax
004742a9: c3           ret      
004742aa: cc           int3     
004742ab: cc           int3     
004742ac: cc           int3     
004742ad: cc           int3     
004742ae: cc           int3     
004742af: cc           int3     
004742b0: 6a02         push     2
004742b2: 6840a5d501   push     0x1d5a540
004742b7: 6898f48c01   push     0x18cf498
004742bc: e88f3c2001   call     0x1677f50
004742c1: 83c40c       add      esp, 0xc
004742c4: a368d7ea01   mov      dword ptr [0x1ead768], eax
004742c9: c3           ret      
004742ca: cc           int3     
004742cb: cc           int3     
004742cc: cc           int3     
004742cd: cc           int3     
004742ce: cc           int3     
004742cf: cc           int3     
004742d0: 6a02         push     2
004742d2: 68a0d6ea01   push     0x1ead6a0
004742d7: 6820f18c01   push     0x18cf120
004742dc: e8cf3c2001   call     0x1677fb0
004742e1: 83c40c       add      esp, 0xc
004742e4: a3f0d6ea01   mov      dword ptr [0x1ead6f0], eax
004742e9: c3           ret      
004742ea: cc           int3     
004742eb: cc           int3     
004742ec: cc           int3     
004742ed: cc           int3     
004742ee: cc           int3     
004742ef: cc           int3     
004742f0: 6a02         push     2
004742f2: 68a4d6ea01   push     0x1ead6a4
004742f7: 68bcf18c01   push     0x18cf1bc
004742fc: e88f3c2001   call     0x1677f90
00474301: 83c40c       add      esp, 0xc
00474304: a30cd7ea01   mov      dword ptr [0x1ead70c], eax
00474309: c3           ret      
0047430a: cc           int3     
0047430b: cc           int3     
0047430c: cc           int3     
0047430d: cc           int3     
0047430e: cc           int3     
0047430f: cc           int3     
00474310: 6a02         push     2
00474312: 68f0a4d501   push     0x1d5a4f0
00474317: 688cf28c01   push     0x18cf28c

; === 013 | 0x476987 | TeamCreateTimeOutInSec ===
00476987: 684c6d8d01   push     0x18d6d4c
0047698c: e8ff152001   call     0x1677f90
00476991: 83c40c       add      esp, 0xc
00476994: a36cdfea01   mov      dword ptr [0x1eadf6c], eax
00476999: c3           ret      
0047699a: cc           int3     
0047699b: cc           int3     
0047699c: cc           int3     
0047699d: cc           int3     
0047699e: cc           int3     
0047699f: cc           int3     
004769a0: 6a02         push     2
004769a2: 68e8afd501   push     0x1d5afe8
004769a7: 68206e8d01   push     0x18d6e20
004769ac: e8df152001   call     0x1677f90
004769b1: 83c40c       add      esp, 0xc
004769b4: a388dfea01   mov      dword ptr [0x1eadf88], eax
004769b9: c3           ret      
004769ba: cc           int3     
004769bb: cc           int3     
004769bc: cc           int3     
004769bd: cc           int3     
004769be: cc           int3     
004769bf: cc           int3     
004769c0: b940dfea01   mov      ecx, 0x1eadf40
004769c5: e976071800   jmp      0x5f7140
004769ca: cc           int3     
004769cb: cc           int3     
004769cc: cc           int3     
004769cd: cc           int3     
004769ce: cc           int3     
004769cf: cc           int3     
004769d0: 6a24         push     0x24
004769d2: 68d8e38b01   push     0x18be3d8
004769d7: b910b0d501   mov      ecx, 0x1d5b010
004769dc: e8dfd80d00   call     0x5542c0
004769e1: 68a0db8701   push     0x187dba0
004769e6: e869cc2701   call     0x16f3654
004769eb: 59           pop      ecx
004769ec: c3           ret      
004769ed: cc           int3     
004769ee: cc           int3     
004769ef: cc           int3     
004769f0: 55           push     ebp
004769f1: 8bec         mov      ebp, esp
004769f3: 6aff         push     -1
004769f5: 68be557a01   push     0x17a55be
004769fa: 64a100000000 mov      eax, dword ptr fs:[0]
00476a00: 50           push     eax
00476a01: 64892500000000 mov      dword ptr fs:[0], esp
00476a08: 81eccc010000 sub      esp, 0x1cc
00476a0e: 56           push     esi
00476a0f: c645d800     mov      byte ptr [ebp - 0x28], 0
00476a13: c745dc00000000 mov      dword ptr [ebp - 0x24], 0
00476a1a: e8f1711700   call     0x5edc10
00476a1f: f30f7e45d8   movq     xmm0, qword ptr [ebp - 0x28]
00476a24: 83ec0c       sub      esp, 0xc
00476a27: 8bcc         mov      ecx, esp

; === 014 | 0x4771d7 | ReplicatorJDIv2NoOrderInfoCloudEdit ===
004771d7: 683c978d01   push     0x18d973c
004771dc: e86f0d2001   call     0x1677f50
004771e1: 83c40c       add      esp, 0xc
004771e4: a338e5ea01   mov      dword ptr [0x1eae538], eax
004771e9: c3           ret      
004771ea: cc           int3     
004771eb: cc           int3     
004771ec: cc           int3     
004771ed: cc           int3     
004771ee: cc           int3     
004771ef: cc           int3     
004771f0: 6a02         push     2
004771f2: 6868b2d501   push     0x1d5b268
004771f7: 6814978d01   push     0x18d9714
004771fc: e84f0d2001   call     0x1677f50
00477201: 83c40c       add      esp, 0xc
00477204: a334e5ea01   mov      dword ptr [0x1eae534], eax
00477209: c3           ret      
0047720a: cc           int3     
0047720b: cc           int3     
0047720c: cc           int3     
0047720d: cc           int3     
0047720e: cc           int3     
0047720f: cc           int3     
00477210: 6a02         push     2
00477212: 68b4e4ea01   push     0x1eae4b4
00477217: 6824958d01   push     0x18d9524
0047721c: e86f0d2001   call     0x1677f90
00477221: 83c40c       add      esp, 0xc
00477224: a3f4e4ea01   mov      dword ptr [0x1eae4f4], eax
00477229: c3           ret      
0047722a: cc           int3     
0047722b: cc           int3     
0047722c: cc           int3     
0047722d: cc           int3     
0047722e: cc           int3     
0047722f: cc           int3     
00477230: 6a02         push     2
00477232: 6838b2d501   push     0x1d5b238
00477237: 6854968d01   push     0x18d9654
0047723c: e80f0d2001   call     0x1677f50
00477241: 83c40c       add      esp, 0xc
00477244: a31ce5ea01   mov      dword ptr [0x1eae51c], eax
00477249: c3           ret      
0047724a: cc           int3     
0047724b: cc           int3     
0047724c: cc           int3     
0047724d: cc           int3     
0047724e: cc           int3     
0047724f: cc           int3     
00477250: 6a02         push     2
00477252: 6898b2d501   push     0x1d5b298
00477257: 6804988d01   push     0x18d9804
0047725c: e8ef0c2001   call     0x1677f50
00477261: 83c40c       add      esp, 0xc
00477264: a354e5ea01   mov      dword ptr [0x1eae554], eax
00477269: c3           ret      
0047726a: cc           int3     
0047726b: cc           int3     
0047726c: cc           int3     
0047726d: cc           int3     
0047726e: cc           int3     
0047726f: cc           int3     
00477270: 6a02         push     2
00477272: 6808b2d501   push     0x1d5b208
00477277: 6854958d01   push     0x18d9554

; === 015 | 0x4771f7 | ReplicatorJDIv2NoOrderInfoNonCloudEdit ===
004771f7: 6814978d01   push     0x18d9714
004771fc: e84f0d2001   call     0x1677f50
00477201: 83c40c       add      esp, 0xc
00477204: a334e5ea01   mov      dword ptr [0x1eae534], eax
00477209: c3           ret      
0047720a: cc           int3     
0047720b: cc           int3     
0047720c: cc           int3     
0047720d: cc           int3     
0047720e: cc           int3     
0047720f: cc           int3     
00477210: 6a02         push     2
00477212: 68b4e4ea01   push     0x1eae4b4
00477217: 6824958d01   push     0x18d9524
0047721c: e86f0d2001   call     0x1677f90
00477221: 83c40c       add      esp, 0xc
00477224: a3f4e4ea01   mov      dword ptr [0x1eae4f4], eax
00477229: c3           ret      
0047722a: cc           int3     
0047722b: cc           int3     
0047722c: cc           int3     
0047722d: cc           int3     
0047722e: cc           int3     
0047722f: cc           int3     
00477230: 6a02         push     2
00477232: 6838b2d501   push     0x1d5b238
00477237: 6854968d01   push     0x18d9654
0047723c: e80f0d2001   call     0x1677f50
00477241: 83c40c       add      esp, 0xc
00477244: a31ce5ea01   mov      dword ptr [0x1eae51c], eax
00477249: c3           ret      
0047724a: cc           int3     
0047724b: cc           int3     
0047724c: cc           int3     
0047724d: cc           int3     
0047724e: cc           int3     
0047724f: cc           int3     
00477250: 6a02         push     2
00477252: 6898b2d501   push     0x1d5b298
00477257: 6804988d01   push     0x18d9804
0047725c: e8ef0c2001   call     0x1677f50
00477261: 83c40c       add      esp, 0xc
00477264: a354e5ea01   mov      dword ptr [0x1eae554], eax
00477269: c3           ret      
0047726a: cc           int3     
0047726b: cc           int3     
0047726c: cc           int3     
0047726d: cc           int3     
0047726e: cc           int3     
0047726f: cc           int3     
00477270: 6a02         push     2
00477272: 6808b2d501   push     0x1d5b208
00477277: 6854958d01   push     0x18d9554
0047727c: e8cf0c2001   call     0x1677f50
00477281: 83c40c       add      esp, 0xc
00477284: a3f8e4ea01   mov      dword ptr [0x1eae4f8], eax
00477289: c3           ret      
0047728a: cc           int3     
0047728b: cc           int3     
0047728c: cc           int3     
0047728d: cc           int3     
0047728e: cc           int3     
0047728f: cc           int3     
00477290: 6a02         push     2
00477292: 68aee4ea01   push     0x1eae4ae
00477297: 6844968d01   push     0x18d9644

; === 016 | 0x478c77 | ReportTeamCreateReplicatorShutdownMetrics ===
00478c77: 689c028e01   push     0x18e029c
00478c7c: e8cff21f01   call     0x1677f50
00478c81: 83c40c       add      esp, 0xc
00478c84: a3c8f3ea01   mov      dword ptr [0x1eaf3c8], eax
00478c89: c3           ret      
00478c8a: cc           int3     
00478c8b: cc           int3     
00478c8c: cc           int3     
00478c8d: cc           int3     
00478c8e: cc           int3     
00478c8f: cc           int3     
00478c90: 6a02         push     2
00478c92: 68e4b9d501   push     0x1d5b9e4
00478c97: 6838018e01   push     0x18e0138
00478c9c: e8eff21f01   call     0x1677f90
00478ca1: 83c40c       add      esp, 0xc
00478ca4: a398f3ea01   mov      dword ptr [0x1eaf398], eax
00478ca9: c3           ret      
00478caa: cc           int3     
00478cab: cc           int3     
00478cac: cc           int3     
00478cad: cc           int3     
00478cae: cc           int3     
00478caf: cc           int3     
00478cb0: 6a01         push     1
00478cb2: 686cbad501   push     0x1d5ba6c
00478cb7: 6894018e01   push     0x18e0194
00478cbc: e88ff21f01   call     0x1677f50
00478cc1: 83c40c       add      esp, 0xc
00478cc4: a3a4f3ea01   mov      dword ptr [0x1eaf3a4], eax
00478cc9: c3           ret      
00478cca: cc           int3     
00478ccb: cc           int3     
00478ccc: cc           int3     
00478ccd: cc           int3     
00478cce: cc           int3     
00478ccf: cc           int3     
00478cd0: b96cf3ea01   mov      ecx, 0x1eaf36c
00478cd5: e966e41700   jmp      0x5f7140
00478cda: cc           int3     
00478cdb: cc           int3     
00478cdc: cc           int3     
00478cdd: cc           int3     
00478cde: cc           int3     
00478cdf: cc           int3     
00478ce0: 6a24         push     0x24
00478ce2: 68d8e38b01   push     0x18be3d8
00478ce7: b948bad501   mov      ecx, 0x1d5ba48
00478cec: e8cfb50d00   call     0x5542c0
00478cf1: 6820e28701   push     0x187e220
00478cf6: e859a92701   call     0x16f3654
00478cfb: 59           pop      ecx
00478cfc: c3           ret      
00478cfd: cc           int3     
00478cfe: cc           int3     
00478cff: cc           int3     
00478d00: 55           push     ebp
00478d01: 8bec         mov      ebp, esp
00478d03: 6aff         push     -1
00478d05: 68c39c7a01   push     0x17a9cc3
00478d0a: 64a100000000 mov      eax, dword ptr fs:[0]
00478d10: 50           push     eax
00478d11: 64892500000000 mov      dword ptr fs:[0], esp
00478d18: 81ecf4000000 sub      esp, 0xf4

; === 017 | 0x487d57 | CleanTeamCreateFlyweightServiceOnDMClose ===
00487d57: 68cc9d9201   push     0x1929dcc
00487d5c: e8ef011f01   call     0x1677f50
00487d61: 83c40c       add      esp, 0xc
00487d64: a38005ee01   mov      dword ptr [0x1ee0580], eax
00487d69: c3           ret      
00487d6a: cc           int3     
00487d6b: cc           int3     
00487d6c: cc           int3     
00487d6d: cc           int3     
00487d6e: cc           int3     
00487d6f: cc           int3     
00487d70: 6a01         push     1
00487d72: 680c36d601   push     0x1d6360c
00487d77: 68d89e9201   push     0x1929ed8
00487d7c: e8cf011f01   call     0x1677f50
00487d81: 83c40c       add      esp, 0xc
00487d84: a3a805ee01   mov      dword ptr [0x1ee05a8], eax
00487d89: c3           ret      
00487d8a: cc           int3     
00487d8b: cc           int3     
00487d8c: cc           int3     
00487d8d: cc           int3     
00487d8e: cc           int3     
00487d8f: cc           int3     
00487d90: 6a08         push     8
00487d92: 6894a39201   push     0x192a394
00487d97: b98434d601   mov      ecx, 0x1d63484
00487d9c: e81fc50c00   call     0x5542c0
00487da1: 6840288801   push     0x1882840
00487da6: e8a9b82601   call     0x16f3654
00487dab: 59           pop      ecx
00487dac: c3           ret      
00487dad: cc           int3     
00487dae: cc           int3     
00487daf: cc           int3     
00487db0: 6a02         push     2
00487db2: 688434d601   push     0x1d63484
00487db7: 68a49a9201   push     0x1929aa4
00487dbc: e80f021f01   call     0x1677fd0
00487dc1: 83c40c       add      esp, 0xc
00487dc4: a30405ee01   mov      dword ptr [0x1ee0504], eax
00487dc9: c3           ret      
00487dca: cc           int3     
00487dcb: cc           int3     
00487dcc: cc           int3     
00487dcd: cc           int3     
00487dce: cc           int3     
00487dcf: cc           int3     
00487dd0: 6a08         push     8
00487dd2: 68a0a39201   push     0x192a3a0
00487dd7: b99c34d601   mov      ecx, 0x1d6349c
00487ddc: e8dfc40c00   call     0x5542c0
00487de1: 68a0288801   push     0x18828a0
00487de6: e869b82601   call     0x16f3654
00487deb: 59           pop      ecx
00487dec: c3           ret      
00487ded: cc           int3     
00487dee: cc           int3     
00487def: cc           int3     
00487df0: 6a02         push     2
00487df2: 689c34d601   push     0x1d6349c
00487df7: 68b49a9201   push     0x1929ab4

; === 018 | 0x487ed2 | /ide/publish/UploadFromCloudEdit ===
00487ed2: 680ca49201   push     0x192a40c
00487ed7: b98c35d601   mov      ecx, 0x1d6358c
00487edc: e8dfc30c00   call     0x5542c0
00487ee1: 68c0298801   push     0x18829c0
00487ee6: e869b72601   call     0x16f3654
00487eeb: 59           pop      ecx
00487eec: c3           ret      
00487eed: cc           int3     
00487eee: cc           int3     
00487eef: cc           int3     
00487ef0: 6a01         push     1
00487ef2: 688c35d601   push     0x1d6358c
00487ef7: 680c9d9201   push     0x1929d0c
00487efc: e8cf001f01   call     0x1677fd0
00487f01: 83c40c       add      esp, 0xc
00487f04: a36805ee01   mov      dword ptr [0x1ee0568], eax
00487f09: c3           ret      
00487f0a: cc           int3     
00487f0b: cc           int3     
00487f0c: cc           int3     
00487f0d: cc           int3     
00487f0e: cc           int3     
00487f0f: cc           int3     
00487f10: 55           push     ebp
00487f11: 8bec         mov      ebp, esp
00487f13: 6aff         push     -1
00487f15: 68aa2f7c01   push     0x17c2faa
00487f1a: 64a100000000 mov      eax, dword ptr fs:[0]
00487f20: 50           push     eax
00487f21: 64892500000000 mov      dword ptr fs:[0], esp
00487f28: 83ec0c       sub      esp, 0xc
00487f2b: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
00487f32: c645e801     mov      byte ptr [ebp - 0x18], 1
00487f36: e825504500   call     0x8dcf60
00487f3b: f30f7e45e8   movq     xmm0, qword ptr [ebp - 0x18]
00487f40: 83ec0c       sub      esp, 0xc
00487f43: 8bcc         mov      ecx, esp
00487f45: 6a00         push     0
00487f47: 660fd601     movq     qword ptr [ecx], xmm0
00487f4b: 6848cf1102   push     0x211cf48
00487f50: c7410800000000 mov      dword ptr [ecx + 8], 0
00487f57: b9e0c21102   mov      ecx, 0x211c2e0
00487f5c: 50           push     eax
00487f5d: e82e385400   call     0x9cb790
00487f62: c745fc00000000 mov      dword ptr [ebp - 4], 0
00487f69: c705e0c211029ca49201 mov      dword ptr [0x211c2e0], 0x192a49c
00487f73: c70518c31102405a5800 mov      dword ptr [0x211c318], 0x585a40

; === 019 | 0x487ef7 | DEPRECATED_ServerConfigCloudEditServerSaveUrl ===
00487ef7: 680c9d9201   push     0x1929d0c
00487efc: e8cf001f01   call     0x1677fd0
00487f01: 83c40c       add      esp, 0xc
00487f04: a36805ee01   mov      dword ptr [0x1ee0568], eax
00487f09: c3           ret      
00487f0a: cc           int3     
00487f0b: cc           int3     
00487f0c: cc           int3     
00487f0d: cc           int3     
00487f0e: cc           int3     
00487f0f: cc           int3     
00487f10: 55           push     ebp
00487f11: 8bec         mov      ebp, esp
00487f13: 6aff         push     -1
00487f15: 68aa2f7c01   push     0x17c2faa
00487f1a: 64a100000000 mov      eax, dword ptr fs:[0]
00487f20: 50           push     eax
00487f21: 64892500000000 mov      dword ptr fs:[0], esp
00487f28: 83ec0c       sub      esp, 0xc
00487f2b: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
00487f32: c645e801     mov      byte ptr [ebp - 0x18], 1
00487f36: e825504500   call     0x8dcf60
00487f3b: f30f7e45e8   movq     xmm0, qword ptr [ebp - 0x18]
00487f40: 83ec0c       sub      esp, 0xc
00487f43: 8bcc         mov      ecx, esp
00487f45: 6a00         push     0
00487f47: 660fd601     movq     qword ptr [ecx], xmm0
00487f4b: 6848cf1102   push     0x211cf48
00487f50: c7410800000000 mov      dword ptr [ecx + 8], 0
00487f57: b9e0c21102   mov      ecx, 0x211c2e0
00487f5c: 50           push     eax
00487f5d: e82e385400   call     0x9cb790
00487f62: c745fc00000000 mov      dword ptr [ebp - 4], 0
00487f69: c705e0c211029ca49201 mov      dword ptr [0x211c2e0], 0x192a49c
00487f73: c70518c31102405a5800 mov      dword ptr [0x211c318], 0x585a40
00487f7d: c7051cc3110200000000 mov      dword ptr [0x211c31c], 0
00487f87: e8645b4000   call     0x88daf0
00487f8c: 68202a8801   push     0x1882a20
00487f91: a304c31102   mov      dword ptr [0x211c304], eax
00487f96: e8b9b62601   call     0x16f3654
00487f9b: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]

; === 020 | 0x488637 | ServerConfigCloudEditSavePeriodSeconds ===
00488637: 681c9a9201   push     0x1929a1c
0048863c: e84ff91e01   call     0x1677f90
00488641: 83c40c       add      esp, 0xc
00488644: a3f404ee01   mov      dword ptr [0x1ee04f4], eax
00488649: c3           ret      
0048864a: cc           int3     
0048864b: cc           int3     
0048864c: cc           int3     
0048864d: cc           int3     
0048864e: cc           int3     
0048864f: cc           int3     
00488650: 6a01         push     1
00488652: 685435d601   push     0x1d63554
00488657: 68509c9201   push     0x1929c50
0048865c: e8eff81e01   call     0x1677f50
00488661: 83c40c       add      esp, 0xc
00488664: a34405ee01   mov      dword ptr [0x1ee0544], eax
00488669: c3           ret      
0048866a: cc           int3     
0048866b: cc           int3     
0048866c: cc           int3     
0048866d: cc           int3     
0048866e: cc           int3     
0048866f: cc           int3     
00488670: 6a01         push     1
00488672: 687c35d601   push     0x1d6357c
00488677: 68d49c9201   push     0x1929cd4
0048867c: e8cff81e01   call     0x1677f50
00488681: 83c40c       add      esp, 0xc
00488684: a35805ee01   mov      dword ptr [0x1ee0558], eax
00488689: c3           ret      
0048868a: cc           int3     
0048868b: cc           int3     
0048868c: cc           int3     
0048868d: cc           int3     
0048868e: cc           int3     
0048868f: cc           int3     
00488690: 6a01         push     1
00488692: 686435d601   push     0x1d63564
00488697: 68889c9201   push     0x1929c88
0048869c: e8aff81e01   call     0x1677f50
004886a1: 83c40c       add      esp, 0xc
004886a4: a34c05ee01   mov      dword ptr [0x1ee054c], eax
004886a9: c3           ret      
004886aa: cc           int3     
004886ab: cc           int3     
004886ac: cc           int3     
004886ad: cc           int3     
004886ae: cc           int3     
004886af: cc           int3     
004886b0: b9bc04ee01   mov      ecx, 0x1ee04bc
004886b5: e986ea1600   jmp      0x5f7140
004886ba: cc           int3     
004886bb: cc           int3     
004886bc: cc           int3     
004886bd: cc           int3     
004886be: cc           int3     
004886bf: cc           int3     
004886c0: 6860408900   push     0x894060
004886c5: b9ae05ee01   mov      ecx, 0x1ee05ae
004886ca: e851974000   call     0x891e20
004886cf: c3           ret      
004886d0: 55           push     ebp
004886d1: 8bec         mov      ebp, esp
004886d3: 6aff         push     -1
004886d5: 682a307c01   push     0x17c302a
004886da: 64a100000000 mov      eax, dword ptr fs:[0]

; === 021 | 0x496a17 | TeamCreatePlayerConnectionsToEventIngest ===
00496a17: 68d0519301   push     0x19351d0
00496a1c: e82f151e01   call     0x1677f50
00496a21: 83c40c       add      esp, 0xc
00496a24: a37830ee01   mov      dword ptr [0x1ee3078], eax
00496a29: c3           ret      
00496a2a: cc           int3     
00496a2b: cc           int3     
00496a2c: cc           int3     
00496a2d: cc           int3     
00496a2e: cc           int3     
00496a2f: cc           int3     
00496a30: 6a02         push     2
00496a32: 681047d601   push     0x1d64710
00496a37: 68b0519301   push     0x19351b0
00496a3c: e80f151e01   call     0x1677f50
00496a41: 83c40c       add      esp, 0xc
00496a44: a37430ee01   mov      dword ptr [0x1ee3074], eax
00496a49: c3           ret      
00496a4a: cc           int3     
00496a4b: cc           int3     
00496a4c: cc           int3     
00496a4d: cc           int3     
00496a4e: cc           int3     
00496a4f: cc           int3     
00496a50: 6a02         push     2
00496a52: 68a046d601   push     0x1d646a0
00496a57: 68b04f9301   push     0x1934fb0
00496a5c: e8ef141e01   call     0x1677f50
00496a61: 83c40c       add      esp, 0xc
00496a64: a32430ee01   mov      dword ptr [0x1ee3024], eax
00496a69: c3           ret      
00496a6a: cc           int3     
00496a6b: cc           int3     
00496a6c: cc           int3     
00496a6d: cc           int3     
00496a6e: cc           int3     
00496a6f: cc           int3     
00496a70: 6a02         push     2
00496a72: 689046d601   push     0x1d64690
00496a77: 689c4e9301   push     0x1934e9c
00496a7c: e8cf141e01   call     0x1677f50
00496a81: 83c40c       add      esp, 0xc
00496a84: a30430ee01   mov      dword ptr [0x1ee3004], eax
00496a89: c3           ret      
00496a8a: cc           int3     
00496a8b: cc           int3     
00496a8c: cc           int3     
00496a8d: cc           int3     
00496a8e: cc           int3     
00496a8f: cc           int3     
00496a90: 6a02         push     2
00496a92: 68c445d601   push     0x1d645c4
00496a97: 6864509301   push     0x1935064
00496a9c: e8ef141e01   call     0x1677f90
00496aa1: 83c40c       add      esp, 0xc
00496aa4: a33c30ee01   mov      dword ptr [0x1ee303c], eax
00496aa9: c3           ret      
00496aaa: cc           int3     
00496aab: cc           int3     
00496aac: cc           int3     
00496aad: cc           int3     
00496aae: cc           int3     
00496aaf: cc           int3     
00496ab0: b9c82fee01   mov      ecx, 0x1ee2fc8
00496ab5: e986061600   jmp      0x5f7140
00496aba: cc           int3     

; === 022 | 0x496a37 | TeamCreatePublishToEventIngest ===
00496a37: 68b0519301   push     0x19351b0
00496a3c: e80f151e01   call     0x1677f50
00496a41: 83c40c       add      esp, 0xc
00496a44: a37430ee01   mov      dword ptr [0x1ee3074], eax
00496a49: c3           ret      
00496a4a: cc           int3     
00496a4b: cc           int3     
00496a4c: cc           int3     
00496a4d: cc           int3     
00496a4e: cc           int3     
00496a4f: cc           int3     
00496a50: 6a02         push     2
00496a52: 68a046d601   push     0x1d646a0
00496a57: 68b04f9301   push     0x1934fb0
00496a5c: e8ef141e01   call     0x1677f50
00496a61: 83c40c       add      esp, 0xc
00496a64: a32430ee01   mov      dword ptr [0x1ee3024], eax
00496a69: c3           ret      
00496a6a: cc           int3     
00496a6b: cc           int3     
00496a6c: cc           int3     
00496a6d: cc           int3     
00496a6e: cc           int3     
00496a6f: cc           int3     
00496a70: 6a02         push     2
00496a72: 689046d601   push     0x1d64690
00496a77: 689c4e9301   push     0x1934e9c
00496a7c: e8cf141e01   call     0x1677f50
00496a81: 83c40c       add      esp, 0xc
00496a84: a30430ee01   mov      dword ptr [0x1ee3004], eax
00496a89: c3           ret      
00496a8a: cc           int3     
00496a8b: cc           int3     
00496a8c: cc           int3     
00496a8d: cc           int3     
00496a8e: cc           int3     
00496a8f: cc           int3     
00496a90: 6a02         push     2
00496a92: 68c445d601   push     0x1d645c4
00496a97: 6864509301   push     0x1935064
00496a9c: e8ef141e01   call     0x1677f90
00496aa1: 83c40c       add      esp, 0xc
00496aa4: a33c30ee01   mov      dword ptr [0x1ee303c], eax
00496aa9: c3           ret      
00496aaa: cc           int3     
00496aab: cc           int3     
00496aac: cc           int3     
00496aad: cc           int3     
00496aae: cc           int3     
00496aaf: cc           int3     
00496ab0: b9c82fee01   mov      ecx, 0x1ee2fc8
00496ab5: e986061600   jmp      0x5f7140
00496aba: cc           int3     
00496abb: cc           int3     
00496abc: cc           int3     
00496abd: cc           int3     
00496abe: cc           int3     
00496abf: cc           int3     
00496ac0: 6a02         push     2
00496ac2: 681c46d601   push     0x1d6461c
00496ac7: 6878529301   push     0x1935278
00496acc: e8bf141e01   call     0x1677f90
00496ad1: 83c40c       add      esp, 0xc
00496ad4: a38c30ee01   mov      dword ptr [0x1ee308c], eax
00496ad9: c3           ret      

; === 023 | 0x496a57 | TeamCreateStopSendingOldPublishFinishedSignal ===
00496a57: 68b04f9301   push     0x1934fb0
00496a5c: e8ef141e01   call     0x1677f50
00496a61: 83c40c       add      esp, 0xc
00496a64: a32430ee01   mov      dword ptr [0x1ee3024], eax
00496a69: c3           ret      
00496a6a: cc           int3     
00496a6b: cc           int3     
00496a6c: cc           int3     
00496a6d: cc           int3     
00496a6e: cc           int3     
00496a6f: cc           int3     
00496a70: 6a02         push     2
00496a72: 689046d601   push     0x1d64690
00496a77: 689c4e9301   push     0x1934e9c
00496a7c: e8cf141e01   call     0x1677f50
00496a81: 83c40c       add      esp, 0xc
00496a84: a30430ee01   mov      dword ptr [0x1ee3004], eax
00496a89: c3           ret      
00496a8a: cc           int3     
00496a8b: cc           int3     
00496a8c: cc           int3     
00496a8d: cc           int3     
00496a8e: cc           int3     
00496a8f: cc           int3     
00496a90: 6a02         push     2
00496a92: 68c445d601   push     0x1d645c4
00496a97: 6864509301   push     0x1935064
00496a9c: e8ef141e01   call     0x1677f90
00496aa1: 83c40c       add      esp, 0xc
00496aa4: a33c30ee01   mov      dword ptr [0x1ee303c], eax
00496aa9: c3           ret      
00496aaa: cc           int3     
00496aab: cc           int3     
00496aac: cc           int3     
00496aad: cc           int3     
00496aae: cc           int3     
00496aaf: cc           int3     
00496ab0: b9c82fee01   mov      ecx, 0x1ee2fc8
00496ab5: e986061600   jmp      0x5f7140
00496aba: cc           int3     
00496abb: cc           int3     
00496abc: cc           int3     
00496abd: cc           int3     
00496abe: cc           int3     
00496abf: cc           int3     
00496ac0: 6a02         push     2
00496ac2: 681c46d601   push     0x1d6461c
00496ac7: 6878529301   push     0x1935278
00496acc: e8bf141e01   call     0x1677f90
00496ad1: 83c40c       add      esp, 0xc
00496ad4: a38c30ee01   mov      dword ptr [0x1ee308c], eax
00496ad9: c3           ret      
00496ada: cc           int3     
00496adb: cc           int3     
00496adc: cc           int3     
00496add: cc           int3     
00496ade: cc           int3     
00496adf: cc           int3     
00496ae0: 6a02         push     2
00496ae2: 681446d601   push     0x1d64614
00496ae7: 6858529301   push     0x1935258
00496aec: e89f141e01   call     0x1677f90
00496af1: 83c40c       add      esp, 0xc
00496af4: a38830ee01   mov      dword ptr [0x1ee3088], eax
00496af9: c3           ret      

; === 024 | 0x4a90f7 | VersionHistoryTeamCreateRolloutHundredthPercent ===
004a90f7: 68d0d19301   push     0x193d1d0
004a90fc: e88fee1c01   call     0x1677f90
004a9101: 83c40c       add      esp, 0xc
004a9104: a3785cee01   mov      dword ptr [0x1ee5c78], eax
004a9109: c3           ret      
004a910a: cc           int3     
004a910b: cc           int3     
004a910c: cc           int3     
004a910d: cc           int3     
004a910e: cc           int3     
004a910f: cc           int3     
004a9110: 6880df6600   push     0x66df80
004a9115: b9815cee01   mov      ecx, 0x1ee5c81
004a911a: e8018d3e00   call     0x891e20
004a911f: c3           ret      
004a9120: 55           push     ebp
004a9121: 8bec         mov      ebp, esp
004a9123: 6aff         push     -1
004a9125: 68f3887d01   push     0x17d88f3
004a912a: 64a100000000 mov      eax, dword ptr fs:[0]
004a9130: 50           push     eax
004a9131: 64892500000000 mov      dword ptr fs:[0], esp
004a9138: 81ecf8000000 sub      esp, 0xf8
004a913e: 56           push     esi
004a913f: c645d400     mov      byte ptr [ebp - 0x2c], 0
004a9143: c745d800000000 mov      dword ptr [ebp - 0x28], 0
004a914a: e8f1645400   call     0x9ef640
004a914f: f30f7e45d4   movq     xmm0, qword ptr [ebp - 0x2c]
004a9154: 83ec0c       sub      esp, 0xc
004a9157: 8bcc         mov      ecx, esp
004a9159: 6a03         push     3
004a915b: 660fd601     movq     qword ptr [ecx], xmm0
004a915f: 682c571202   push     0x212572c
004a9164: c7410800000000 mov      dword ptr [ecx + 8], 0
004a916b: b9f0541202   mov      ecx, 0x21254f0
004a9170: 50           push     eax
004a9171: e8fa275200   call     0x9cb970
004a9176: c7052455120274000000 mov      dword ptr [0x2125524], 0x74
004a9180: 6820991102   push     0x2119920
004a9185: c745fc00000000 mov      dword ptr [ebp - 4], 0
004a918c: c705f05412025cd59301 mov      dword ptr [0x21254f0], 0x193d55c
004a9196: e835523c00   call     0x86e3d0
004a919b: 83c404       add      esp, 4

; === 025 | 0x4c14e7 | FixWeldConstraintTeamCreateReplication ===
004c14e7: 6828299501   push     0x1952928
004c14ec: e85f6a1b01   call     0x1677f50
004c14f1: 83c40c       add      esp, 0xc
004c14f4: a390e6ee01   mov      dword ptr [0x1eee690], eax
004c14f9: c3           ret      
004c14fa: cc           int3     
004c14fb: cc           int3     
004c14fc: cc           int3     
004c14fd: cc           int3     
004c14fe: cc           int3     
004c14ff: cc           int3     
004c1500: 6a02         push     2
004c1502: 68fc6fd601   push     0x1d66ffc
004c1507: 6890299501   push     0x1952990
004c150c: e83f6a1b01   call     0x1677f50
004c1511: 83c40c       add      esp, 0xc
004c1514: a39ce6ee01   mov      dword ptr [0x1eee69c], eax
004c1519: c3           ret      
004c151a: cc           int3     
004c151b: cc           int3     
004c151c: cc           int3     
004c151d: cc           int3     
004c151e: cc           int3     
004c151f: cc           int3     
004c1520: 6a02         push     2
004c1522: 680470d601   push     0x1d67004
004c1527: 68ac299501   push     0x19529ac
004c152c: e81f6a1b01   call     0x1677f50
004c1531: 83c40c       add      esp, 0xc
004c1534: a3a0e6ee01   mov      dword ptr [0x1eee6a0], eax
004c1539: c3           ret      
004c153a: cc           int3     
004c153b: cc           int3     
004c153c: cc           int3     
004c153d: cc           int3     
004c153e: cc           int3     
004c153f: cc           int3     
004c1540: 6a02         push     2
004c1542: 680c70d601   push     0x1d6700c
004c1547: 68d0299501   push     0x19529d0
004c154c: e8ff691b01   call     0x1677f50
004c1551: 83c40c       add      esp, 0xc
004c1554: a3a4e6ee01   mov      dword ptr [0x1eee6a4], eax
004c1559: c3           ret      
004c155a: cc           int3     
004c155b: cc           int3     
004c155c: cc           int3     
004c155d: cc           int3     
004c155e: cc           int3     
004c155f: cc           int3     
004c1560: 6a01         push     1
004c1562: 68c86fd601   push     0x1d66fc8
004c1567: 6800299501   push     0x1952900
004c156c: e81f6a1b01   call     0x1677f90
004c1571: 83c40c       add      esp, 0xc
004c1574: a38ce6ee01   mov      dword ptr [0x1eee68c], eax
004c1579: c3           ret      
004c157a: cc           int3     
004c157b: cc           int3     
004c157c: cc           int3     
004c157d: cc           int3     
004c157e: cc           int3     
004c157f: cc           int3     
004c1580: 6a01         push     1
004c1582: 68c06fd601   push     0x1d66fc0
004c1587: 68e8289501   push     0x19528e8

; === 026 | 0x4c1547 | SimFixWeldConstraintTeamCreateBug ===
004c1547: 68d0299501   push     0x19529d0
004c154c: e8ff691b01   call     0x1677f50
004c1551: 83c40c       add      esp, 0xc
004c1554: a3a4e6ee01   mov      dword ptr [0x1eee6a4], eax
004c1559: c3           ret      
004c155a: cc           int3     
004c155b: cc           int3     
004c155c: cc           int3     
004c155d: cc           int3     
004c155e: cc           int3     
004c155f: cc           int3     
004c1560: 6a01         push     1
004c1562: 68c86fd601   push     0x1d66fc8
004c1567: 6800299501   push     0x1952900
004c156c: e81f6a1b01   call     0x1677f90
004c1571: 83c40c       add      esp, 0xc
004c1574: a38ce6ee01   mov      dword ptr [0x1eee68c], eax
004c1579: c3           ret      
004c157a: cc           int3     
004c157b: cc           int3     
004c157c: cc           int3     
004c157d: cc           int3     
004c157e: cc           int3     
004c157f: cc           int3     
004c1580: 6a01         push     1
004c1582: 68c06fd601   push     0x1d66fc0
004c1587: 68e8289501   push     0x19528e8
004c158c: e8ff691b01   call     0x1677f90
004c1591: 83c40c       add      esp, 0xc
004c1594: a388e6ee01   mov      dword ptr [0x1eee688], eax
004c1599: c3           ret      
004c159a: cc           int3     
004c159b: cc           int3     
004c159c: cc           int3     
004c159d: cc           int3     
004c159e: cc           int3     
004c159f: cc           int3     
004c15a0: 6a04         push     4
004c15a2: 68d46fd601   push     0x1d66fd4
004c15a7: 6850299501   push     0x1952950
004c15ac: e8bf691b01   call     0x1677f70
004c15b1: 83c40c       add      esp, 0xc
004c15b4: a394e6ee01   mov      dword ptr [0x1eee694], eax
004c15b9: c3           ret      
004c15ba: cc           int3     
004c15bb: cc           int3     
004c15bc: cc           int3     
004c15bd: cc           int3     
004c15be: cc           int3     
004c15bf: cc           int3     
004c15c0: 6a02         push     2
004c15c2: 68f46fd601   push     0x1d66ff4
004c15c7: 6870299501   push     0x1952970
004c15cc: e87f691b01   call     0x1677f50
004c15d1: 83c40c       add      esp, 0xc
004c15d4: a398e6ee01   mov      dword ptr [0x1eee698], eax
004c15d9: c3           ret      
004c15da: cc           int3     
004c15db: cc           int3     
004c15dc: cc           int3     
004c15dd: cc           int3     
004c15de: cc           int3     
004c15df: cc           int3     
004c15e0: 68b0b38500   push     0x85b3b0
004c15e5: b9a8e6ee01   mov      ecx, 0x1eee6a8
004c15ea: e831083d00   call     0x891e20

; === 027 | 0x4f1247 | TeamCreateDataStorePerKeyThrottleFixEnabled ===
004f1247: 68f88f9701   push     0x1978ff8
004f124c: e8ff6c1801   call     0x1677f50
004f1251: 83c40c       add      esp, 0xc
004f1254: a32c48f001   mov      dword ptr [0x1f0482c], eax
004f1259: c3           ret      
004f125a: cc           int3     
004f125b: cc           int3     
004f125c: cc           int3     
004f125d: cc           int3     
004f125e: cc           int3     
004f125f: cc           int3     
004f1260: 6a02         push     2
004f1262: 68bc8fd601   push     0x1d68fbc
004f1267: 68f8909701   push     0x19790f8
004f126c: e8df6c1801   call     0x1677f50
004f1271: 83c40c       add      esp, 0xc
004f1274: a35048f001   mov      dword ptr [0x1f04850], eax
004f1279: c3           ret      
004f127a: cc           int3     
004f127b: cc           int3     
004f127c: cc           int3     
004f127d: cc           int3     
004f127e: cc           int3     
004f127f: cc           int3     
004f1280: 68f0438900   push     0x8943f0
004f1285: b9da47f001   mov      ecx, 0x1f047da
004f128a: e8910b3a00   call     0x891e20
004f128f: c3           ret      
004f1290: 55           push     ebp
004f1291: 8bec         mov      ebp, esp
004f1293: 6aff         push     -1
004f1295: 68ec388101   push     0x18138ec
004f129a: 64a100000000 mov      eax, dword ptr fs:[0]
004f12a0: 50           push     eax
004f12a1: 64892500000000 mov      dword ptr fs:[0], esp
004f12a8: 81ecb0010000 sub      esp, 0x1b0
004f12ae: 56           push     esi
004f12af: c745f000000000 mov      dword ptr [ebp - 0x10], 0
004f12b6: 57           push     edi
004f12b7: c645e400     mov      byte ptr [ebp - 0x1c], 0
004f12bb: c745e800000000 mov      dword ptr [ebp - 0x18], 0
004f12c2: e8a9d07d00   call     0xcce370
004f12c7: f30f7e45e4   movq     xmm0, qword ptr [ebp - 0x1c]
004f12cc: 83ec0c       sub      esp, 0xc
004f12cf: 8bcc         mov      ecx, esp
004f12d1: 6a00         push     0
004f12d3: 660fd601     movq     qword ptr [ecx], xmm0
004f12d7: 6814cb1302   push     0x213cb14
004f12dc: c7410800000000 mov      dword ptr [ecx + 8], 0
004f12e3: b9c0c91302   mov      ecx, 0x213c9c0
004f12e8: 50           push     eax

; === 028 | 0x4f27d7 | FixRenderFidelityTeamCreateReplication ===
004f27d7: 6860ad9701   push     0x197ad60
004f27dc: e86f571801   call     0x1677f50
004f27e1: 83c40c       add      esp, 0xc
004f27e4: a34c4ff001   mov      dword ptr [0x1f04f4c], eax
004f27e9: c3           ret      
004f27ea: cc           int3     
004f27eb: cc           int3     
004f27ec: cc           int3     
004f27ed: cc           int3     
004f27ee: cc           int3     
004f27ef: cc           int3     
004f27f0: 6a01         push     1
004f27f2: 68e4c7d601   push     0x1d6c7e4
004f27f7: 68a4ac9701   push     0x197aca4
004f27fc: e84f571801   call     0x1677f50
004f2801: 83c40c       add      esp, 0xc
004f2804: a3304ff001   mov      dword ptr [0x1f04f30], eax
004f2809: c3           ret      
004f280a: cc           int3     
004f280b: cc           int3     
004f280c: cc           int3     
004f280d: cc           int3     
004f280e: cc           int3     
004f280f: cc           int3     
004f2810: 6a01         push     1
004f2812: 68fcc7d601   push     0x1d6c7fc
004f2817: 68f8ac9701   push     0x197acf8
004f281c: e82f571801   call     0x1677f50
004f2821: 83c40c       add      esp, 0xc
004f2824: a33c4ff001   mov      dword ptr [0x1f04f3c], eax
004f2829: c3           ret      
004f282a: cc           int3     
004f282b: cc           int3     
004f282c: cc           int3     
004f282d: cc           int3     
004f282e: cc           int3     
004f282f: cc           int3     
004f2830: 6a01         push     1
004f2832: 6804c8d601   push     0x1d6c804
004f2837: 681cad9701   push     0x197ad1c
004f283c: e80f571801   call     0x1677f50
004f2841: 83c40c       add      esp, 0xc
004f2844: a3404ff001   mov      dword ptr [0x1f04f40], eax
004f2849: c3           ret      
004f284a: cc           int3     
004f284b: cc           int3     
004f284c: cc           int3     
004f284d: cc           int3     
004f284e: cc           int3     
004f284f: cc           int3     
004f2850: 6a01         push     1
004f2852: 6814c8d601   push     0x1d6c814
004f2857: 684cad9701   push     0x197ad4c
004f285c: e8ef561801   call     0x1677f50
004f2861: 83c40c       add      esp, 0xc
004f2864: a3484ff001   mov      dword ptr [0x1f04f48], eax
004f2869: c3           ret      
004f286a: cc           int3     
004f286b: cc           int3     
004f286c: cc           int3     
004f286d: cc           int3     
004f286e: cc           int3     
004f286f: cc           int3     
004f2870: 6a01         push     1
004f2872: 68ccc7d601   push     0x1d6c7cc
004f2877: 6840ac9701   push     0x197ac40

; === 029 | 0x5d471b | isCloudEdit ===
005d471b: 68f85e8c01   push     0x18c5ef8
005d4720: 8d4dc0       lea      ecx, [ebp - 0x40]
005d4723: e8e86ff400   call     0x151b710
005d4728: 8d45a8       lea      eax, [ebp - 0x58]
005d472b: 50           push     eax
005d472c: e8cfd93300   call     0x912100
005d4731: 83c404       add      esp, 4
005d4734: 83781410     cmp      dword ptr [eax + 0x14], 0x10
005d4738: c645fc01     mov      byte ptr [ebp - 4], 1
005d473c: 7202         jb       0x5d4740
005d473e: 8b00         mov      eax, dword ptr [eax]
005d4740: 50           push     eax
005d4741: 68045f8c01   push     0x18c5f04
005d4746: 8d4dc0       lea      ecx, [ebp - 0x40]
005d4749: e8c26ff400   call     0x151b710
005d474e: 8b55bc       mov      edx, dword ptr [ebp - 0x44]
005d4751: c645fc00     mov      byte ptr [ebp - 4], 0
005d4755: 83fa10       cmp      edx, 0x10
005d4758: 722c         jb       0x5d4786
005d475a: 8b4da8       mov      ecx, dword ptr [ebp - 0x58]
005d475d: 42           inc      edx
005d475e: 8bc1         mov      eax, ecx
005d4760: 81fa00100000 cmp      edx, 0x1000
005d4766: 7214         jb       0x5d477c
005d4768: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005d476b: 83c223       add      edx, 0x23
005d476e: 2bc1         sub      eax, ecx
005d4770: 83c0fc       add      eax, -4
005d4773: 83f81f       cmp      eax, 0x1f
005d4776: 0f870d010000 ja       0x5d4889
005d477c: 52           push     edx
005d477d: 51           push     ecx
005d477e: e81d070a01   call     0x1674ea0
005d4783: 83c408       add      esp, 8
005d4786: 8b4514       mov      eax, dword ptr [ebp + 0x14]
005d4789: 83781410     cmp      dword ptr [eax + 0x14], 0x10
005d478d: 7202         jb       0x5d4791
005d478f: 8b00         mov      eax, dword ptr [eax]
005d4791: 50           push     eax
005d4792: 68105f8c01   push     0x18c5f10
005d4797: 8d4dc0       lea      ecx, [ebp - 0x40]
005d479a: e8716ff400   call     0x151b710
005d479f: 8b4518       mov      eax, dword ptr [ebp + 0x18]
005d47a2: 8b08         mov      ecx, dword ptr [eax]
005d47a4: 85c9         test     ecx, ecx
005d47a6: 7421         je       0x5d47c9
005d47a8: e8933b3500   call     0x928340
005d47ad: 52           push     edx
005d47ae: 50           push     eax
005d47af: 83ec08       sub      esp, 8
005d47b2: 8d4dc0       lea      ecx, [ebp - 0x40]
005d47b5: 8bc4         mov      eax, esp
005d47b7: c7001c5f8c01 mov      dword ptr [eax], 0x18c5f1c
005d47bd: c7400413000000 mov      dword ptr [eax + 4], 0x13

; === 030 | 0x5d5ee3 | Cloud Edit path - register 'playerConnectingSignal'. ===
005d5ee3: 68d8658c01   push     0x18c65d8
005d5ee8: 50           push     eax
005d5ee9: e8c2150a01   call     0x16774b0
005d5eee: 8b4dec       mov      ecx, dword ptr [ebp - 0x14]
005d5ef1: 83c40c       add      esp, 0xc
005d5ef4: 8d83c8020000 lea      eax, [ebx + 0x2c8]
005d5efa: 8945e8       mov      dword ptr [ebp - 0x18], eax
005d5efd: 85ff         test     edi, edi
005d5eff: 7406         je       0x5d5f07
005d5f01: 8d4708       lea      eax, [edi + 8]
005d5f04: f0ff00       lock inc dword ptr [eax]
005d5f07: 894dc4       mov      dword ptr [ebp - 0x3c], ecx
005d5f0a: 897dc8       mov      dword ptr [ebp - 0x38], edi
005d5f0d: ff35a80d1102 push     dword ptr [0x2110da8]
005d5f13: c645fc03     mov      byte ptr [ebp - 4], 3
005d5f17: e874f30901   call     0x1675290
005d5f1c: 8bf0         mov      esi, eax
005d5f1e: 8975dc       mov      dword ptr [ebp - 0x24], esi
005d5f21: 6a20         push     0x20
005d5f23: c645fc04     mov      byte ptr [ebp - 4], 4
005d5f27: e8f4ee0901   call     0x1674e20
005d5f2c: 8b4de8       mov      ecx, dword ptr [ebp - 0x18]
005d5f2f: 8bd8         mov      ebx, eax
005d5f31: 83c408       add      esp, 8
005d5f34: 895de0       mov      dword ptr [ebp - 0x20], ebx
005d5f37: 85db         test     ebx, ebx
005d5f39: 7448         je       0x5d5f83
005d5f3b: c70300000000 mov      dword ptr [ebx], 0
005d5f41: c7430401000000 mov      dword ptr [ebx + 4], 1
005d5f48: c7430840325d00 mov      dword ptr [ebx + 8], 0x5d3240
005d5f4f: c7430c60365d00 mov      dword ptr [ebx + 0xc], 0x5d3660
005d5f56: c7431000000000 mov      dword ptr [ebx + 0x10], 0
005d5f5d: 894b14       mov      dword ptr [ebx + 0x14], ecx
005d5f60: c7431800000000 mov      dword ptr [ebx + 0x18], 0
005d5f67: c7431c00000000 mov      dword ptr [ebx + 0x1c], 0
005d5f6e: 85ff         test     edi, edi
005d5f70: 7406         je       0x5d5f78
005d5f72: 8d4708       lea      eax, [edi + 8]
005d5f75: f0ff00       lock inc dword ptr [eax]
005d5f78: 8b45ec       mov      eax, dword ptr [ebp - 0x14]
005d5f7b: 894318       mov      dword ptr [ebx + 0x18], eax
005d5f7e: 897b1c       mov      dword ptr [ebx + 0x1c], edi
005d5f81: eb02         jmp      0x5d5f85
005d5f83: 33db         xor      ebx, ebx

; === 031 | 0x5d946b | isCloudEdit ===
005d946b: 68f85e8c01   push     0x18c5ef8
005d9470: 8d4ddc       lea      ecx, [ebp - 0x24]
005d9473: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
005d947a: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
005d9481: c645dc00     mov      byte ptr [ebp - 0x24], 0
005d9485: e836aef7ff   call     0x5542c0
005d948a: 56           push     esi
005d948b: 8d45dc       lea      eax, [ebp - 0x24]
005d948e: c645fc1d     mov      byte ptr [ebp - 4], 0x1d
005d9492: 50           push     eax
005d9493: 8d4dc4       lea      ecx, [ebp - 0x3c]
005d9496: e83581ffff   call     0x5d15d0
005d949b: 8d4818       lea      ecx, [eax + 0x18]
005d949e: e8bd7df7ff   call     0x551260
005d94a3: 8d4ddc       lea      ecx, [ebp - 0x24]
005d94a6: c645fc01     mov      byte ptr [ebp - 4], 1
005d94aa: e80173f7ff   call     0x5507b0
005d94af: 8d45ac       lea      eax, [ebp - 0x54]
005d94b2: 50           push     eax
005d94b3: e8488c3300   call     0x912100
005d94b8: 83c404       add      esp, 4
005d94bb: 8bf0         mov      esi, eax
005d94bd: 837e1410     cmp      dword ptr [esi + 0x14], 0x10
005d94c1: c645fc1e     mov      byte ptr [ebp - 4], 0x1e
005d94c5: 7202         jb       0x5d94c9
005d94c7: 8b36         mov      esi, dword ptr [esi]
005d94c9: 6a0a         push     0xa
005d94cb: 68045f8c01   push     0x18c5f04
005d94d0: 8d4ddc       lea      ecx, [ebp - 0x24]
005d94d3: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
005d94da: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
005d94e1: c645dc00     mov      byte ptr [ebp - 0x24], 0
005d94e5: e8d6adf7ff   call     0x5542c0
005d94ea: 56           push     esi
005d94eb: 8d45dc       lea      eax, [ebp - 0x24]
005d94ee: c645fc1f     mov      byte ptr [ebp - 4], 0x1f
005d94f2: 50           push     eax
005d94f3: 8d4dc4       lea      ecx, [ebp - 0x3c]
005d94f6: e8d580ffff   call     0x5d15d0
005d94fb: 8d4818       lea      ecx, [eax + 0x18]
005d94fe: e85d7df7ff   call     0x551260
005d9503: 8d4ddc       lea      ecx, [ebp - 0x24]
005d9506: e8a572f7ff   call     0x5507b0
005d950b: 8d4dac       lea      ecx, [ebp - 0x54]

; === 032 | 0x5da95d | RCCMonitoring::teamCreateSaveOnZeroPlayers started. ===
005da95d: 687c6c8c01   push     0x18c6c7c
005da962: 50           push     eax
005da963: e848cb0901   call     0x16774b0
005da968: 83c40c       add      esp, 0xc
005da96b: 53           push     ebx
005da96c: 8d45dc       lea      eax, [ebp - 0x24]
005da96f: 8d4e18       lea      ecx, [esi + 0x18]
005da972: 50           push     eax
005da973: e818cbfaff   call     0x587490
005da978: 8b5ddc       mov      ebx, dword ptr [ebp - 0x24]
005da97b: 83cfff       or       edi, 0xffffffff
005da97e: c745fc00000000 mov      dword ptr [ebp - 4], 0
005da985: 85db         test     ebx, ebx
005da987: 7518         jne      0x5da9a1
005da989: a0f096d501   mov      al, byte ptr [0x1d596f0]
005da98e: 84c0         test     al, al
005da990: 0f84d5010000 je       0x5dab6b
005da996: 53           push     ebx
005da997: 68b06c8c01   push     0x18c6cb0
005da99c: e9be010000   jmp      0x5dab5f
005da9a1: 8d730c       lea      esi, [ebx + 0xc]
005da9a4: 8bce         mov      ecx, esi
005da9a6: e8a54dffff   call     0x5cf750
005da9ab: 85c0         test     eax, eax
005da9ad: 7519         jne      0x5da9c8
005da9af: a0f096d501   mov      al, byte ptr [0x1d596f0]
005da9b4: 84c0         test     al, al
005da9b6: 0f84af010000 je       0x5dab6b
005da9bc: 6a00         push     0
005da9be: 68086d8c01   push     0x18c6d08
005da9c3: e997010000   jmp      0x5dab5f
005da9c8: 8b88b8000000 mov      ecx, dword ptr [eax + 0xb8]
005da9ce: 8b4104       mov      eax, dword ptr [ecx + 4]
005da9d1: 2b01         sub      eax, dword ptr [ecx]
005da9d3: 83f808       cmp      eax, 8
005da9d6: 0f8d73010000 jge      0x5dab4f
005da9dc: 803d505ad60100 cmp      byte ptr [0x1d65a50], 0
005da9e3: 0f8439010000 je       0x5dab22
005da9e9: 85f6         test     esi, esi
005da9eb: 0f84a8000000 je       0x5daa99
005da9f1: 68d0f15c00   push     0x5cf1d0
005da9f6: 68fc8dea01   push     0x1ea8dfc
005da9fb: e8c0dff9ff   call     0x5789c0
005daa00: 83c408       add      esp, 8

; === 033 | 0x5da997 | RCCMonitoring::teamCreateSaveOnZeroPlayers did early return due to invalid DataModel. ===
005da997: 68b06c8c01   push     0x18c6cb0
005da99c: e9be010000   jmp      0x5dab5f
005da9a1: 8d730c       lea      esi, [ebx + 0xc]
005da9a4: 8bce         mov      ecx, esi
005da9a6: e8a54dffff   call     0x5cf750
005da9ab: 85c0         test     eax, eax
005da9ad: 7519         jne      0x5da9c8
005da9af: a0f096d501   mov      al, byte ptr [0x1d596f0]
005da9b4: 84c0         test     al, al
005da9b6: 0f84af010000 je       0x5dab6b
005da9bc: 6a00         push     0
005da9be: 68086d8c01   push     0x18c6d08
005da9c3: e997010000   jmp      0x5dab5f
005da9c8: 8b88b8000000 mov      ecx, dword ptr [eax + 0xb8]
005da9ce: 8b4104       mov      eax, dword ptr [ecx + 4]
005da9d1: 2b01         sub      eax, dword ptr [ecx]
005da9d3: 83f808       cmp      eax, 8
005da9d6: 0f8d73010000 jge      0x5dab4f
005da9dc: 803d505ad60100 cmp      byte ptr [0x1d65a50], 0
005da9e3: 0f8439010000 je       0x5dab22
005da9e9: 85f6         test     esi, esi
005da9eb: 0f84a8000000 je       0x5daa99
005da9f1: 68d0f15c00   push     0x5cf1d0
005da9f6: 68fc8dea01   push     0x1ea8dfc
005da9fb: e8c0dff9ff   call     0x5789c0
005daa00: 83c408       add      esp, 8
005daa03: e8784bffff   call     0x5cf580
005daa08: 50           push     eax
005daa09: 8bce         mov      ecx, esi
005daa0b: e830f72c00   call     0x8aa140
005daa10: 8945f0       mov      dword ptr [ebp - 0x10], eax
005daa13: 833800       cmp      dword ptr [eax], 0
005daa16: 757d         jne      0x5daa95
005daa18: e8234d4100   call     0x9ef740
005daa1d: 50           push     eax
005daa1e: 8d45e4       lea      eax, [ebp - 0x1c]
005daa21: 8bce         mov      ecx, esi
005daa23: 50           push     eax
005daa24: e877f12c00   call     0x8a9ba0
005daa29: 8b08         mov      ecx, dword ptr [eax]
005daa2b: 8b5004       mov      edx, dword ptr [eax + 4]
005daa2e: c70000000000 mov      dword ptr [eax], 0
005daa34: c7400400000000 mov      dword ptr [eax + 4], 0
005daa3b: 8b45f0       mov      eax, dword ptr [ebp - 0x10]

; === 034 | 0x5da9be | RCCMonitoring::teamCreateSaveOnZeroPlayers did early return due to invalid Players object. ===
005da9be: 68086d8c01   push     0x18c6d08
005da9c3: e997010000   jmp      0x5dab5f
005da9c8: 8b88b8000000 mov      ecx, dword ptr [eax + 0xb8]
005da9ce: 8b4104       mov      eax, dword ptr [ecx + 4]
005da9d1: 2b01         sub      eax, dword ptr [ecx]
005da9d3: 83f808       cmp      eax, 8
005da9d6: 0f8d73010000 jge      0x5dab4f
005da9dc: 803d505ad60100 cmp      byte ptr [0x1d65a50], 0
005da9e3: 0f8439010000 je       0x5dab22
005da9e9: 85f6         test     esi, esi
005da9eb: 0f84a8000000 je       0x5daa99
005da9f1: 68d0f15c00   push     0x5cf1d0
005da9f6: 68fc8dea01   push     0x1ea8dfc
005da9fb: e8c0dff9ff   call     0x5789c0
005daa00: 83c408       add      esp, 8
005daa03: e8784bffff   call     0x5cf580
005daa08: 50           push     eax
005daa09: 8bce         mov      ecx, esi
005daa0b: e830f72c00   call     0x8aa140
005daa10: 8945f0       mov      dword ptr [ebp - 0x10], eax
005daa13: 833800       cmp      dword ptr [eax], 0
005daa16: 757d         jne      0x5daa95
005daa18: e8234d4100   call     0x9ef740
005daa1d: 50           push     eax
005daa1e: 8d45e4       lea      eax, [ebp - 0x1c]
005daa21: 8bce         mov      ecx, esi
005daa23: 50           push     eax
005daa24: e877f12c00   call     0x8a9ba0
005daa29: 8b08         mov      ecx, dword ptr [eax]
005daa2b: 8b5004       mov      edx, dword ptr [eax + 4]
005daa2e: c70000000000 mov      dword ptr [eax], 0
005daa34: c7400400000000 mov      dword ptr [eax + 4], 0
005daa3b: 8b45f0       mov      eax, dword ptr [ebp - 0x10]
005daa3e: 8908         mov      dword ptr [eax], ecx
005daa40: 8b7004       mov      esi, dword ptr [eax + 4]
005daa43: 895004       mov      dword ptr [eax + 4], edx
005daa46: 85f6         test     esi, esi
005daa48: 7422         je       0x5daa6c
005daa4a: 8bc7         mov      eax, edi
005daa4c: f00fc14604   lock xadd dword ptr [esi + 4], eax
005daa51: 7516         jne      0x5daa69
005daa53: 8b06         mov      eax, dword ptr [esi]
005daa55: 8bce         mov      ecx, esi
005daa57: ff10         call     dword ptr [eax]
005daa59: 8bc7         mov      eax, edi
005daa5b: f00fc14608   lock xadd dword ptr [esi + 8], eax
005daa60: 7507         jne      0x5daa69

; === 035 | 0x5dab06 | RCCMonitoring::teamCreateSaveOnZeroPlayers TeamCreate DataModel saved with place version number = %d. ===
005dab06: 68686d8c01   push     0x18c6d68
005dab0b: 50           push     eax
005dab0c: e89fc90901   call     0x16774b0
005dab11: 83c40c       add      esp, 0xc
005dab14: 8d4de4       lea      ecx, [ebp - 0x1c]
005dab17: c645fc00     mov      byte ptr [ebp - 4], 0
005dab1b: e81060f7ff   call     0x550b30
005dab20: eb2d         jmp      0x5dab4f
005dab22: 6a00         push     0
005dab24: 6a00         push     0
005dab26: 6a00         push     0
005dab28: 8bcb         mov      ecx, ebx
005dab2a: e821bd0000   call     0x5e6850
005dab2f: 84c0         test     al, al
005dab31: 741c         je       0x5dab4f
005dab33: a01c8dea01   mov      al, byte ptr [0x1ea8d1c]
005dab38: 84c0         test     al, al
005dab3a: 742f         je       0x5dab6b
005dab3c: 6a00         push     0
005dab3e: 0fb6c0       movzx    eax, al
005dab41: 68d06d8c01   push     0x18c6dd0
005dab46: 50           push     eax
005dab47: e864c90901   call     0x16774b0
005dab4c: 83c40c       add      esp, 0xc
005dab4f: a01c8dea01   mov      al, byte ptr [0x1ea8d1c]
005dab54: 84c0         test     al, al
005dab56: 7413         je       0x5dab6b
005dab58: 6a00         push     0
005dab5a: 68186e8c01   push     0x18c6e18
005dab5f: 0fb6c0       movzx    eax, al
005dab62: 50           push     eax
005dab63: e848c90901   call     0x16774b0
005dab68: 83c40c       add      esp, 0xc
005dab6b: 8b75e0       mov      esi, dword ptr [ebp - 0x20]
005dab6e: 5b           pop      ebx
005dab6f: 85f6         test     esi, esi
005dab71: 741e         je       0x5dab91
005dab73: 8bc7         mov      eax, edi
005dab75: f00fc14604   lock xadd dword ptr [esi + 4], eax
005dab7a: 7515         jne      0x5dab91
005dab7c: 8b06         mov      eax, dword ptr [esi]
005dab7e: 8bce         mov      ecx, esi
005dab80: ff10         call     dword ptr [eax]
005dab82: f00fc17e08   lock xadd dword ptr [esi + 8], edi
005dab87: 4f           dec      edi
005dab88: 7507         jne      0x5dab91
005dab8a: 8b06         mov      eax, dword ptr [esi]
005dab8c: 8bce         mov      ecx, esi
005dab8e: ff5004       call     dword ptr [eax + 4]
005dab91: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
005dab94: 5f           pop      edi
005dab95: 5e           pop      esi
005dab96: 64890d00000000 mov      dword ptr fs:[0], ecx
005dab9d: 8be5         mov      esp, ebp
005dab9f: 5d           pop      ebp
005daba0: c20400       ret      4
005daba3: cc           int3     
005daba4: cc           int3     
005daba5: cc           int3     
005daba6: cc           int3     

; === 036 | 0x5dab41 | RCCMonitoring::teamCreateSaveOnZeroPlayers TeamCreate DataModel saved. ===
005dab41: 68d06d8c01   push     0x18c6dd0
005dab46: 50           push     eax
005dab47: e864c90901   call     0x16774b0
005dab4c: 83c40c       add      esp, 0xc
005dab4f: a01c8dea01   mov      al, byte ptr [0x1ea8d1c]
005dab54: 84c0         test     al, al
005dab56: 7413         je       0x5dab6b
005dab58: 6a00         push     0
005dab5a: 68186e8c01   push     0x18c6e18
005dab5f: 0fb6c0       movzx    eax, al
005dab62: 50           push     eax
005dab63: e848c90901   call     0x16774b0
005dab68: 83c40c       add      esp, 0xc
005dab6b: 8b75e0       mov      esi, dword ptr [ebp - 0x20]
005dab6e: 5b           pop      ebx
005dab6f: 85f6         test     esi, esi
005dab71: 741e         je       0x5dab91
005dab73: 8bc7         mov      eax, edi
005dab75: f00fc14604   lock xadd dword ptr [esi + 4], eax
005dab7a: 7515         jne      0x5dab91
005dab7c: 8b06         mov      eax, dword ptr [esi]
005dab7e: 8bce         mov      ecx, esi
005dab80: ff10         call     dword ptr [eax]
005dab82: f00fc17e08   lock xadd dword ptr [esi + 8], edi
005dab87: 4f           dec      edi
005dab88: 7507         jne      0x5dab91
005dab8a: 8b06         mov      eax, dword ptr [esi]
005dab8c: 8bce         mov      ecx, esi
005dab8e: ff5004       call     dword ptr [eax + 4]
005dab91: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
005dab94: 5f           pop      edi
005dab95: 5e           pop      esi
005dab96: 64890d00000000 mov      dword ptr fs:[0], ecx
005dab9d: 8be5         mov      esp, ebp
005dab9f: 5d           pop      ebp
005daba0: c20400       ret      4
005daba3: cc           int3     
005daba4: cc           int3     
005daba5: cc           int3     
005daba6: cc           int3     
005daba7: cc           int3     
005daba8: cc           int3     
005daba9: cc           int3     
005dabaa: cc           int3     
005dabab: cc           int3     
005dabac: cc           int3     
005dabad: cc           int3     
005dabae: cc           int3     
005dabaf: cc           int3     
005dabb0: 55           push     ebp
005dabb1: 8bec         mov      ebp, esp
005dabb3: 64a100000000 mov      eax, dword ptr fs:[0]
005dabb9: 6aff         push     -1
005dabbb: 6810a87901   push     0x179a810
005dabc0: 50           push     eax
005dabc1: 64892500000000 mov      dword ptr fs:[0], esp
005dabc8: 83ec30       sub      esp, 0x30
005dabcb: 56           push     esi
005dabcc: 8b7508       mov      esi, dword ptr [ebp + 8]
005dabcf: 8bc6         mov      eax, esi
005dabd1: 837e1410     cmp      dword ptr [esi + 0x14], 0x10
005dabd5: 7202         jb       0x5dabd9
005dabd7: 8b06         mov      eax, dword ptr [esi]
005dabd9: 50           push     eax
005dabda: 8d45dc       lea      eax, [ebp - 0x24]
005dabdd: 68c4588c01   push     0x18c58c4
005dabe2: 50           push     eax

; === 037 | 0x5dab5a | RCCMonitoring::teamCreateSaveOnZeroPlayers finished. ===
005dab5a: 68186e8c01   push     0x18c6e18
005dab5f: 0fb6c0       movzx    eax, al
005dab62: 50           push     eax
005dab63: e848c90901   call     0x16774b0
005dab68: 83c40c       add      esp, 0xc
005dab6b: 8b75e0       mov      esi, dword ptr [ebp - 0x20]
005dab6e: 5b           pop      ebx
005dab6f: 85f6         test     esi, esi
005dab71: 741e         je       0x5dab91
005dab73: 8bc7         mov      eax, edi
005dab75: f00fc14604   lock xadd dword ptr [esi + 4], eax
005dab7a: 7515         jne      0x5dab91
005dab7c: 8b06         mov      eax, dword ptr [esi]
005dab7e: 8bce         mov      ecx, esi
005dab80: ff10         call     dword ptr [eax]
005dab82: f00fc17e08   lock xadd dword ptr [esi + 8], edi
005dab87: 4f           dec      edi
005dab88: 7507         jne      0x5dab91
005dab8a: 8b06         mov      eax, dword ptr [esi]
005dab8c: 8bce         mov      ecx, esi
005dab8e: ff5004       call     dword ptr [eax + 4]
005dab91: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
005dab94: 5f           pop      edi
005dab95: 5e           pop      esi
005dab96: 64890d00000000 mov      dword ptr fs:[0], ecx
005dab9d: 8be5         mov      esp, ebp
005dab9f: 5d           pop      ebp
005daba0: c20400       ret      4
005daba3: cc           int3     
005daba4: cc           int3     
005daba5: cc           int3     
005daba6: cc           int3     
005daba7: cc           int3     
005daba8: cc           int3     
005daba9: cc           int3     
005dabaa: cc           int3     
005dabab: cc           int3     
005dabac: cc           int3     
005dabad: cc           int3     
005dabae: cc           int3     
005dabaf: cc           int3     
005dabb0: 55           push     ebp
005dabb1: 8bec         mov      ebp, esp
005dabb3: 64a100000000 mov      eax, dword ptr fs:[0]
005dabb9: 6aff         push     -1
005dabbb: 6810a87901   push     0x179a810
005dabc0: 50           push     eax
005dabc1: 64892500000000 mov      dword ptr fs:[0], esp
005dabc8: 83ec30       sub      esp, 0x30
005dabcb: 56           push     esi
005dabcc: 8b7508       mov      esi, dword ptr [ebp + 8]
005dabcf: 8bc6         mov      eax, esi
005dabd1: 837e1410     cmp      dword ptr [esi + 0x14], 0x10
005dabd5: 7202         jb       0x5dabd9
005dabd7: 8b06         mov      eax, dword ptr [esi]
005dabd9: 50           push     eax
005dabda: 8d45dc       lea      eax, [ebp - 0x24]
005dabdd: 68c4588c01   push     0x18c58c4
005dabe2: 50           push     eax
005dabe3: e858aa0901   call     0x1675640
005dabe8: 6a00         push     0
005dabea: 6a01         push     1
005dabec: 50           push     eax
005dabed: c745fc00000000 mov      dword ptr [ebp - 4], 0
005dabf4: e8f7d72900   call     0x8783f0
005dabf9: 8b55f0       mov      edx, dword ptr [ebp - 0x10]
005dabfc: 83c418       add      esp, 0x18

; === 038 | 0x5dafce | CloudEdit ===
005dafce: ba8c5f8c01   mov      edx, 0x18c5f8c
005dafd3: 8bca         mov      ecx, edx
005dafd5: c745d400000000 mov      dword ptr [ebp - 0x2c], 0
005dafdc: c745d80f000000 mov      dword ptr [ebp - 0x28], 0xf
005dafe3: c645c400     mov      byte ptr [ebp - 0x3c], 0
005dafe7: 8d7901       lea      edi, [ecx + 1]
005dafea: 660f1f440000 nop      word ptr [eax + eax]
005daff0: 8a01         mov      al, byte ptr [ecx]
005daff2: 41           inc      ecx
005daff3: 84c0         test     al, al
005daff5: 75f9         jne      0x5daff0
005daff7: 2bcf         sub      ecx, edi
005daff9: 51           push     ecx
005daffa: 52           push     edx
005daffb: 8d4dc4       lea      ecx, [ebp - 0x3c]
005daffe: e8bd92f7ff   call     0x5542c0
005db003: 8b4e40       mov      ecx, dword ptr [esi + 0x40]
005db006: 8d55c4       lea      edx, [ebp - 0x3c]
005db009: 837dd810     cmp      dword ptr [ebp - 0x28], 0x10
005db00d: 8d4148       lea      eax, [ecx + 0x48]
005db010: c645fc05     mov      byte ptr [ebp - 4], 5
005db014: 0f4355c4     cmovae   edx, dword ptr [ebp - 0x3c]
005db018: 83781410     cmp      dword ptr [eax + 0x14], 0x10
005db01c: 7202         jb       0x5db020
005db01e: 8b00         mov      eax, dword ptr [eax]
005db020: 52           push     edx
005db021: 50           push     eax
005db022: ff7104       push     dword ptr [ecx + 4]
005db025: 8d4594       lea      eax, [ebp - 0x6c]
005db028: ff31         push     dword ptr [ecx]
005db02a: 68a05f8c01   push     0x18c5fa0
005db02f: 50           push     eax
005db030: e80ba60901   call     0x1675640
005db035: 83c418       add      esp, 0x18
005db038: 83781410     cmp      dword ptr [eax + 0x14], 0x10
005db03c: 8b4810       mov      ecx, dword ptr [eax + 0x10]
005db03f: c645fc06     mov      byte ptr [ebp - 4], 6
005db043: 7202         jb       0x5db047
005db045: 8b00         mov      eax, dword ptr [eax]
005db047: 51           push     ecx
005db048: 50           push     eax
005db049: 8d8d7cffffff lea      ecx, [ebp - 0x84]
005db04f: e8fc90f7ff   call     0x554150
005db054: 8b55a8       mov      edx, dword ptr [ebp - 0x58]
005db057: c645fc05     mov      byte ptr [ebp - 4], 5
005db05b: 83fa10       cmp      edx, 0x10
005db05e: 722c         jb       0x5db08c
005db060: 8b4d94       mov      ecx, dword ptr [ebp - 0x6c]
005db063: 42           inc      edx
005db064: 8bc1         mov      eax, ecx
005db066: 81fa00100000 cmp      edx, 0x1000
005db06c: 7214         jb       0x5db082
005db06e: 8b49fc       mov      ecx, dword ptr [ecx - 4]

; === 039 | 0x5e68a1 | TeamCreate.Publish.Attempt ===
005e68a1: 6834838c01   push     0x18c8334
005e68a6: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e68a9: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
005e68b0: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
005e68b7: c645d400     mov      byte ptr [ebp - 0x2c], 0
005e68bb: e800daf6ff   call     0x5542c0
005e68c0: 6a00         push     0
005e68c2: 8d45d4       lea      eax, [ebp - 0x2c]
005e68c5: c745fc00000000 mov      dword ptr [ebp - 4], 0
005e68cc: 6a01         push     1
005e68ce: 50           push     eax
005e68cf: e81c1b2900   call     0x8783f0
005e68d4: 8b55e8       mov      edx, dword ptr [ebp - 0x18]
005e68d7: 83c40c       add      esp, 0xc
005e68da: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
005e68e1: 83fa10       cmp      edx, 0x10
005e68e4: 722c         jb       0x5e6912
005e68e6: 8b4dd4       mov      ecx, dword ptr [ebp - 0x2c]
005e68e9: 42           inc      edx
005e68ea: 8bc1         mov      eax, ecx
005e68ec: 81fa00100000 cmp      edx, 0x1000
005e68f2: 7214         jb       0x5e6908
005e68f4: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005e68f7: 83c223       add      edx, 0x23
005e68fa: 2bc1         sub      eax, ecx
005e68fc: 83c0fc       add      eax, -4
005e68ff: 83f81f       cmp      eax, 0x1f
005e6902: 0f87d6180000 ja       0x5e81de
005e6908: 52           push     edx
005e6909: 51           push     ecx
005e690a: e891e50801   call     0x1674ea0
005e690f: 83c408       add      esp, 8
005e6912: 8b45cc       mov      eax, dword ptr [ebp - 0x34]
005e6915: c78550ffffff00000000 mov      dword ptr [ebp - 0xb0], 0
005e691f: c78554ffffff0f000000 mov      dword ptr [ebp - 0xac], 0xf
005e6929: c68540ffffff00 mov      byte ptr [ebp - 0xc0], 0
005e6930: c745fc01000000 mov      dword ptr [ebp - 4], 1
005e6937: c645fc02     mov      byte ptr [ebp - 4], 2
005e693b: 85c0         test     eax, eax
005e693d: 0f84f8000000 je       0x5e6a3b
005e6943: 807d0800     cmp      byte ptr [ebp + 8], 0

; === 040 | 0x5e6be3 | CloudEditAbortPublishDueToUnpublishedPackage ===
005e6be3: 6814848c01   push     0x18c8414
005e6be8: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e6beb: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
005e6bf2: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
005e6bf9: c645d400     mov      byte ptr [ebp - 0x2c], 0
005e6bfd: e8bed6f6ff   call     0x5542c0
005e6c02: 6a00         push     0
005e6c04: 8d45d4       lea      eax, [ebp - 0x2c]
005e6c07: c645fc06     mov      byte ptr [ebp - 4], 6
005e6c0b: 6a01         push     1
005e6c0d: 50           push     eax
005e6c0e: e8dd172900   call     0x8783f0
005e6c13: 83c40c       add      esp, 0xc
005e6c16: c645fc02     mov      byte ptr [ebp - 4], 2
005e6c1a: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e6c1d: e88e9bf6ff   call     0x5507b0
005e6c22: 6a00         push     0
005e6c24: 6a00         push     0
005e6c26: 6a00         push     0
005e6c28: 6800818c01   push     0x18c8100
005e6c2d: 68e0808c01   push     0x18c80e0
005e6c32: 6844848c01   push     0x18c8444
005e6c37: e814582900   call     0x87c450
005e6c3c: 83c418       add      esp, 0x18
005e6c3f: e9c8fdffff   jmp      0x5e6a0c
005e6c44: 52           push     edx
005e6c45: 51           push     ecx
005e6c46: e855e20801   call     0x1674ea0
005e6c4b: 83c408       add      esp, 8
005e6c4e: 803d7c93ea0100 cmp      byte ptr [0x1ea937c], 0
005e6c55: 0f8487000000 je       0x5e6ce2
005e6c5b: 83bd54ffffff10 cmp      dword ptr [ebp - 0xac], 0x10
005e6c62: 8d8d40ffffff lea      ecx, [ebp - 0xc0]
005e6c68: 8b8550ffffff mov      eax, dword ptr [ebp - 0xb0]
005e6c6e: 0f438d40ffffff cmovae   ecx, dword ptr [ebp - 0xc0]
005e6c75: 03c1         add      eax, ecx
005e6c77: 83bd54ffffff10 cmp      dword ptr [ebp - 0xac], 0x10
005e6c7e: 8d8d40ffffff lea      ecx, [ebp - 0xc0]
005e6c84: 8bd0         mov      edx, eax

; === 041 | 0x5e735b | TeamCreate ===
005e735b: 680c858c01   push     0x18c850c
005e7360: 8d8d60ffffff lea      ecx, [ebp - 0xa0]
005e7366: c645fc13     mov      byte ptr [ebp - 4], 0x13
005e736a: c78570ffffff00000000 mov      dword ptr [ebp - 0x90], 0
005e7374: c78574ffffff0f000000 mov      dword ptr [ebp - 0x8c], 0xf
005e737e: c68560ffffff00 mov      byte ptr [ebp - 0xa0], 0
005e7385: e836cff6ff   call     0x5542c0
005e738a: 6a03         push     3
005e738c: 689cde8b01   push     0x18bde9c
005e7391: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7394: c645fc14     mov      byte ptr [ebp - 4], 0x14
005e7398: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
005e739f: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
005e73a6: c645d400     mov      byte ptr [ebp - 0x2c], 0
005e73aa: e811cff6ff   call     0x5542c0
005e73af: 8d4590       lea      eax, [ebp - 0x70]
005e73b2: c645fc15     mov      byte ptr [ebp - 4], 0x15
005e73b6: 50           push     eax
005e73b7: 8d8578ffffff lea      eax, [ebp - 0x88]
005e73bd: 50           push     eax
005e73be: 8d8560ffffff lea      eax, [ebp - 0xa0]
005e73c4: 50           push     eax
005e73c5: 8d45d4       lea      eax, [ebp - 0x2c]
005e73c8: 50           push     eax
005e73c9: e8b2212900   call     0x879580
005e73ce: 83c410       add      esp, 0x10
005e73d1: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e73d4: e8d793f6ff   call     0x5507b0
005e73d9: 8d8d60ffffff lea      ecx, [ebp - 0xa0]
005e73df: e8cc93f6ff   call     0x5507b0
005e73e4: 8d8d78ffffff lea      ecx, [ebp - 0x88]
005e73ea: e8c193f6ff   call     0x5507b0
005e73ef: 8d4d90       lea      ecx, [ebp - 0x70]
005e73f2: c645fc07     mov      byte ptr [ebp - 4], 7
005e73f6: e8d55bf8ff   call     0x56cfd0
005e73fb: 803d7e93ea0100 cmp      byte ptr [0x1ea937e], 0

; === 042 | 0x5e748a | TeamCreate SaveOrPublish Roblox-Place-Id: [%s] Roblox-Game-Id: [%s] isPublish: [%d] first 16 bits of md5: [%s] ===
005e748a: 6818858c01   push     0x18c8518
005e748f: 50           push     eax
005e7490: c645fc16     mov      byte ptr [ebp - 4], 0x16
005e7494: e887000901   call     0x1677520
005e7499: 83c418       add      esp, 0x18
005e749c: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e749f: e80c93f6ff   call     0x5507b0
005e74a4: 8d8d28ffffff lea      ecx, [ebp - 0xd8]
005e74aa: e80193f6ff   call     0x5507b0
005e74af: 8d45a0       lea      eax, [ebp - 0x60]
005e74b2: c745fc01000000 mov      dword ptr [ebp - 4], 1
005e74b9: 6a00         push     0
005e74bb: 50           push     eax
005e74bc: c645fc2c     mov      byte ptr [ebp - 4], 0x2c
005e74c0: e89b28ee00   call     0x14c9d60
005e74c5: 83c408       add      esp, 8
005e74c8: 8b855cffffff mov      eax, dword ptr [ebp - 0xa4]
005e74ce: 83ec08       sub      esp, 8
005e74d1: 8b4da0       mov      ecx, dword ptr [ebp - 0x60]
005e74d4: 0524040000   add      eax, 0x424
005e74d9: c645fc2d     mov      byte ptr [ebp - 4], 0x2d
005e74dd: 8bd4         mov      edx, esp
005e74df: 83781410     cmp      dword ptr [eax + 0x14], 0x10
005e74e3: 8b7010       mov      esi, dword ptr [eax + 0x10]
005e74e6: 7202         jb       0x5e74ea
005e74e8: 8b00         mov      eax, dword ptr [eax]
005e74ea: 8902         mov      dword ptr [edx], eax
005e74ec: 897204       mov      dword ptr [edx + 4], esi
005e74ef: e8cc46ee00   call     0x14cbbc0
005e74f4: 8b45a0       mov      eax, dword ptr [ebp - 0x60]
005e74f7: 6a01         push     1
005e74f9: c780b000000000000000 mov      dword ptr [eax + 0xb0], 0
005e7503: 8d8540ffffff lea      eax, [ebp - 0xc0]
005e7509: 8b4da0       mov      ecx, dword ptr [ebp - 0x60]
005e750c: 50           push     eax
005e750d: e86e42ee00   call     0x14cb780
005e7512: 8b15fc9bd701 mov      edx, dword ptr [0x1d79bfc]
005e7518: 83ec08       sub      esp, 8
005e751b: 8b45a0       mov      eax, dword ptr [ebp - 0x60]
005e751e: 8bf4         mov      esi, esp
005e7520: 8945d0       mov      dword ptr [ebp - 0x30], eax
005e7523: 85d2         test     edx, edx
005e7525: 7415         je       0x5e753c
005e7527: 8bca         mov      ecx, edx
005e7529: 8d4101       lea      eax, [ecx + 1]
005e752c: 8945c8       mov      dword ptr [ebp - 0x38], eax

; === 043 | 0x5e7a09 | TeamCreateServerPublishFailure ===
005e7a09: 6854878c01   push     0x18c8754
005e7a0e: e8dd75f6ff   call     0x54eff0
005e7a13: 6a00         push     0
005e7a15: 56           push     esi
005e7a16: 8d8578ffffff lea      eax, [ebp - 0x88]
005e7a1c: c645fc39     mov      byte ptr [ebp - 4], 0x39
005e7a20: 50           push     eax
005e7a21: 8d8dbcfeffff lea      ecx, [ebp - 0x144]
005e7a27: e8f492f300   call     0x1520d20
005e7a2c: 8d8d78ffffff lea      ecx, [ebp - 0x88]
005e7a32: e8798df6ff   call     0x5507b0
005e7a37: 8d8dbcfeffff lea      ecx, [ebp - 0x144]
005e7a3d: c645fc35     mov      byte ptr [ebp - 4], 0x35
005e7a41: e8aa7df300   call     0x151f7f0
005e7a46: 8b4dcc       mov      ecx, dword ptr [ebp - 0x34]
005e7a49: 85c9         test     ecx, ecx
005e7a4b: 740b         je       0x5e7a58
005e7a4d: 8d4590       lea      eax, [ebp - 0x70]
005e7a50: 50           push     eax
005e7a51: 6a03         push     3
005e7a53: e868483a00   call     0x98c2c0
005e7a58: 803d709ad50100 cmp      byte ptr [0x1d59a70], 0
005e7a5f: 0f84de000000 je       0x5e7b43
005e7a65: 6874878c01   push     0x18c8774
005e7a6a: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7a6d: e87e75f6ff   call     0x54eff0
005e7a72: 8bf8         mov      edi, eax
005e7a74: 8b8d58ffffff mov      ecx, dword ptr [ebp - 0xa8]
005e7a7a: c645fc3a     mov      byte ptr [ebp - 4], 0x3a
005e7a7e: 8b11         mov      edx, dword ptr [ecx]
005e7a80: 8b5204       mov      edx, dword ptr [edx + 4]
005e7a83: ffd2         call     edx
005e7a85: 687c878c01   push     0x18c877c
005e7a8a: 8d8d78ffffff lea      ecx, [ebp - 0x88]
005e7a90: 8bf0         mov      esi, eax
005e7a92: e85975f6ff   call     0x54eff0
005e7a97: 56           push     esi
005e7a98: 50           push     eax
005e7a99: 8d85f8feffff lea      eax, [ebp - 0x108]
005e7a9f: c645fc3b     mov      byte ptr [ebp - 4], 0x3b
005e7aa3: 50           push     eax
005e7aa4: e8d711f7ff   call     0x558c80
005e7aa9: 57           push     edi

; === 044 | 0x5e7b2b | Team Create ===
005e7b2b: 68c4858c01   push     0x18c85c4
005e7b30: 68985f8c01   push     0x18c5f98
005e7b35: e8b64b2900   call     0x87c6f0
005e7b3a: 8bbd58ffffff mov      edi, dword ptr [ebp - 0xa8]
005e7b40: 83c41c       add      esp, 0x1c
005e7b43: 803d1047d60100 cmp      byte ptr [0x1d64710], 0
005e7b4a: 0f84c0020000 je       0x5e7e10
005e7b50: 8d45ef       lea      eax, [ebp - 0x11]
005e7b53: 50           push     eax
005e7b54: 8d45ef       lea      eax, [ebp - 0x11]
005e7b57: 50           push     eax
005e7b58: 8d45ef       lea      eax, [ebp - 0x11]
005e7b5b: 50           push     eax
005e7b5c: 6a0b         push     0xb
005e7b5e: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7b61: e8da8ffeff   call     0x5d0b40
005e7b66: 8d857cfeffff lea      eax, [ebp - 0x184]
005e7b6c: c645fc3e     mov      byte ptr [ebp - 4], 0x3e
005e7b70: 50           push     eax
005e7b71: e8aa81f400   call     0x152fd20
005e7b76: 83c404       add      esp, 4
005e7b79: 8bf0         mov      esi, eax
005e7b7b: 68a4848c01   push     0x18c84a4
005e7b80: 8d8d78ffffff lea      ecx, [ebp - 0x88]
005e7b86: c645fc3f     mov      byte ptr [ebp - 4], 0x3f
005e7b8a: e86174f6ff   call     0x54eff0
005e7b8f: 56           push     esi
005e7b90: 8d8578ffffff lea      eax, [ebp - 0x88]
005e7b96: c645fc40     mov      byte ptr [ebp - 4], 0x40
005e7b9a: 50           push     eax
005e7b9b: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7b9e: e82d9afeff   call     0x5d15d0
005e7ba3: 8d4818       lea      ecx, [eax + 0x18]
005e7ba6: e84596f6ff   call     0x5511f0
005e7bab: 8d8d78ffffff lea      ecx, [ebp - 0x88]
005e7bb1: e8fa8bf6ff   call     0x5507b0
005e7bb6: 8d8d7cfeffff lea      ecx, [ebp - 0x184]
005e7bbc: c645fc3e     mov      byte ptr [ebp - 4], 0x3e
005e7bc0: e8eb8bf6ff   call     0x5507b0
005e7bc5: 68ac848c01   push     0x18c84ac
005e7bca: 8d8d60ffffff lea      ecx, [ebp - 0xa0]
005e7bd0: e81b74f6ff   call     0x54eff0

; === 045 | 0x5e7d9c | TeamCreate ===
005e7d9c: 680c858c01   push     0x18c850c
005e7da1: 8d8df8feffff lea      ecx, [ebp - 0x108]
005e7da7: c645fc49     mov      byte ptr [ebp - 4], 0x49
005e7dab: e84072f6ff   call     0x54eff0
005e7db0: 689cde8b01   push     0x18bde9c
005e7db5: 8d8d10ffffff lea      ecx, [ebp - 0xf0]
005e7dbb: c645fc4a     mov      byte ptr [ebp - 4], 0x4a
005e7dbf: e82c72f6ff   call     0x54eff0
005e7dc4: 8d45d4       lea      eax, [ebp - 0x2c]
005e7dc7: c645fc4b     mov      byte ptr [ebp - 4], 0x4b
005e7dcb: 50           push     eax
005e7dcc: 8d45a8       lea      eax, [ebp - 0x58]
005e7dcf: 50           push     eax
005e7dd0: 8d85f8feffff lea      eax, [ebp - 0x108]
005e7dd6: 50           push     eax
005e7dd7: 8d8510ffffff lea      eax, [ebp - 0xf0]
005e7ddd: 50           push     eax
005e7dde: e89d172900   call     0x879580
005e7de3: 83c410       add      esp, 0x10
005e7de6: 8d8d10ffffff lea      ecx, [ebp - 0xf0]
005e7dec: e8bf89f6ff   call     0x5507b0
005e7df1: 8d8df8feffff lea      ecx, [ebp - 0x108]
005e7df7: e8b489f6ff   call     0x5507b0
005e7dfc: 8d4da8       lea      ecx, [ebp - 0x58]
005e7dff: e8ac89f6ff   call     0x5507b0
005e7e04: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7e07: c645fc35     mov      byte ptr [ebp - 4], 0x35
005e7e0b: e8c051f8ff   call     0x56cfd0
005e7e10: 803d789ad50100 cmp      byte ptr [0x1d59a78], 0
005e7e17: 7429         je       0x5e7e42
005e7e19: 68a8878c01   push     0x18c87a8
005e7e1e: 8d4da8       lea      ecx, [ebp - 0x58]
005e7e21: e8ca71f6ff   call     0x54eff0
005e7e26: 6a00         push     0
005e7e28: 8d45a8       lea      eax, [ebp - 0x58]
005e7e2b: c645fc4c     mov      byte ptr [ebp - 4], 0x4c
005e7e2f: 6a01         push     1
005e7e31: 50           push     eax
005e7e32: e8b9052900   call     0x8783f0
005e7e37: 83c40c       add      esp, 0xc
005e7e3a: 8d4da8       lea      ecx, [ebp - 0x58]
005e7e3d: e86e89f6ff   call     0x5507b0

; === 046 | 0x5e7e19 | TeamCreate.Publish.Failed.Request ===
005e7e19: 68a8878c01   push     0x18c87a8
005e7e1e: 8d4da8       lea      ecx, [ebp - 0x58]
005e7e21: e8ca71f6ff   call     0x54eff0
005e7e26: 6a00         push     0
005e7e28: 8d45a8       lea      eax, [ebp - 0x58]
005e7e2b: c645fc4c     mov      byte ptr [ebp - 4], 0x4c
005e7e2f: 6a01         push     1
005e7e31: 50           push     eax
005e7e32: e8b9052900   call     0x8783f0
005e7e37: 83c40c       add      esp, 0xc
005e7e3a: 8d4da8       lea      ecx, [ebp - 0x58]
005e7e3d: e86e89f6ff   call     0x5507b0
005e7e42: 8d4d90       lea      ecx, [ebp - 0x70]
005e7e45: e86689f6ff   call     0x5507b0
005e7e4a: b8507e5e00   mov      eax, 0x5e7e50
005e7e4f: c3           ret      
005e7e50: e9b7ebffff   jmp      0x5e6a0c
005e7e55: 8bbda0feffff mov      edi, dword ptr [ebp - 0x160]
005e7e5b: 8bcf         mov      ecx, edi
005e7e5d: 8b07         mov      eax, dword ptr [edi]
005e7e5f: 8b4004       mov      eax, dword ptr [eax + 4]
005e7e62: ffd0         call     eax
005e7e64: 6888858c01   push     0x18c8588
005e7e69: 8d8ddcfeffff lea      ecx, [ebp - 0x124]
005e7e6f: 8bf0         mov      esi, eax
005e7e71: e87a71f6ff   call     0x54eff0
005e7e76: 56           push     esi
005e7e77: 50           push     eax
005e7e78: 8d8578ffffff lea      eax, [ebp - 0x88]
005e7e7e: c645fc18     mov      byte ptr [ebp - 4], 0x18
005e7e82: 50           push     eax
005e7e83: e8f80df7ff   call     0x558c80
005e7e88: 83c40c       add      esp, 0xc
005e7e8b: 8d8ddcfeffff lea      ecx, [ebp - 0x124]
005e7e91: c645fc1a     mov      byte ptr [ebp - 4], 0x1a
005e7e95: e81689f6ff   call     0x5507b0
005e7e9a: 837d8c10     cmp      dword ptr [ebp - 0x74], 0x10
005e7e9e: 8d8578ffffff lea      eax, [ebp - 0x88]
005e7ea4: 6a03         push     3
005e7ea6: 0f438578ffffff cmovae   eax, dword ptr [ebp - 0x88]
005e7ead: 6a00         push     0
005e7eaf: 6a00         push     0
005e7eb1: 6a00         push     0
005e7eb3: 50           push     eax
005e7eb4: 68c4858c01   push     0x18c85c4
005e7eb9: 68985f8c01   push     0x18c5f98

; === 047 | 0x5e7eb4 | Team Create ===
005e7eb4: 68c4858c01   push     0x18c85c4
005e7eb9: 68985f8c01   push     0x18c5f98
005e7ebe: e82d482900   call     0x87c6f0
005e7ec3: 83c41c       add      esp, 0x1c
005e7ec6: 803d1047d60100 cmp      byte ptr [0x1d64710], 0
005e7ecd: 0f8481020000 je       0x5e8154
005e7ed3: 8d45ef       lea      eax, [ebp - 0x11]
005e7ed6: 50           push     eax
005e7ed7: 8d45ef       lea      eax, [ebp - 0x11]
005e7eda: 50           push     eax
005e7edb: 8d45ef       lea      eax, [ebp - 0x11]
005e7ede: 50           push     eax
005e7edf: 6a0b         push     0xb
005e7ee1: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7ee4: e8578cfeff   call     0x5d0b40
005e7ee9: 8d85a4feffff lea      eax, [ebp - 0x15c]
005e7eef: c645fc1b     mov      byte ptr [ebp - 4], 0x1b
005e7ef3: 50           push     eax
005e7ef4: e8277ef400   call     0x152fd20
005e7ef9: 83c404       add      esp, 4
005e7efc: 8bf0         mov      esi, eax
005e7efe: 68a4848c01   push     0x18c84a4
005e7f03: 8d4da8       lea      ecx, [ebp - 0x58]
005e7f06: c645fc1c     mov      byte ptr [ebp - 4], 0x1c
005e7f0a: e8e170f6ff   call     0x54eff0
005e7f0f: 56           push     esi
005e7f10: 8d45a8       lea      eax, [ebp - 0x58]
005e7f13: c645fc1d     mov      byte ptr [ebp - 4], 0x1d
005e7f17: 50           push     eax
005e7f18: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e7f1b: e8b096feff   call     0x5d15d0
005e7f20: 8d4818       lea      ecx, [eax + 0x18]
005e7f23: e8c892f6ff   call     0x5511f0
005e7f28: 8d4da8       lea      ecx, [ebp - 0x58]
005e7f2b: e88088f6ff   call     0x5507b0
005e7f30: 8d8da4feffff lea      ecx, [ebp - 0x15c]
005e7f36: c645fc1b     mov      byte ptr [ebp - 4], 0x1b
005e7f3a: e87188f6ff   call     0x5507b0
005e7f3f: 68ac848c01   push     0x18c84ac
005e7f44: 8d4da8       lea      ecx, [ebp - 0x58]
005e7f47: e8a470f6ff   call     0x54eff0
005e7f4c: 68809cd701   push     0x1d79c80
005e7f51: 8d45a8       lea      eax, [ebp - 0x58]
005e7f54: c645fc1e     mov      byte ptr [ebp - 4], 0x1e

; === 048 | 0x5e80e3 | TeamCreate ===
005e80e3: 680c858c01   push     0x18c850c
005e80e8: 8d8d10ffffff lea      ecx, [ebp - 0xf0]
005e80ee: c645fc26     mov      byte ptr [ebp - 4], 0x26
005e80f2: e8f96ef6ff   call     0x54eff0
005e80f7: 689cde8b01   push     0x18bde9c
005e80fc: 8d4da8       lea      ecx, [ebp - 0x58]
005e80ff: c645fc27     mov      byte ptr [ebp - 4], 0x27
005e8103: e8e86ef6ff   call     0x54eff0
005e8108: 8d45d4       lea      eax, [ebp - 0x2c]
005e810b: c645fc28     mov      byte ptr [ebp - 4], 0x28
005e810f: 50           push     eax
005e8110: 8d85f8feffff lea      eax, [ebp - 0x108]
005e8116: 50           push     eax
005e8117: 8d8510ffffff lea      eax, [ebp - 0xf0]
005e811d: 50           push     eax
005e811e: 8d45a8       lea      eax, [ebp - 0x58]
005e8121: 50           push     eax
005e8122: e859142900   call     0x879580
005e8127: 83c410       add      esp, 0x10
005e812a: 8d4da8       lea      ecx, [ebp - 0x58]
005e812d: e87e86f6ff   call     0x5507b0
005e8132: 8d8d10ffffff lea      ecx, [ebp - 0xf0]
005e8138: e87386f6ff   call     0x5507b0
005e813d: 8d8df8feffff lea      ecx, [ebp - 0x108]
005e8143: e86886f6ff   call     0x5507b0
005e8148: 8d4dd4       lea      ecx, [ebp - 0x2c]
005e814b: c645fc1a     mov      byte ptr [ebp - 4], 0x1a
005e814f: e87c4ef8ff   call     0x56cfd0
005e8154: 8b75cc       mov      esi, dword ptr [ebp - 0x34]
005e8157: 85f6         test     esi, esi
005e8159: 7440         je       0x5e819b
005e815b: 807d0800     cmp      byte ptr [ebp + 8], 0
005e815f: 8d4da8       lea      ecx, [ebp - 0x58]
005e8162: 7410         je       0x5e8174
005e8164: 681c868c01   push     0x18c861c
005e8169: e8826ef6ff   call     0x54eff0
005e816e: c645fc29     mov      byte ptr [ebp - 4], 0x29
005e8172: eb0e         jmp      0x5e8182
005e8174: 6854868c01   push     0x18c8654
005e8179: e8726ef6ff   call     0x54eff0
005e817e: c645fc2a     mov      byte ptr [ebp - 4], 0x2a
005e8182: 8d45a8       lea      eax, [ebp - 0x58]
005e8185: 8bce         mov      ecx, esi

; === 049 | 0x5e81a4 | TeamCreate.Publish.Failed.Serialize ===
005e81a4: 6888868c01   push     0x18c8688
005e81a9: 8d4da8       lea      ecx, [ebp - 0x58]
005e81ac: e83f6ef6ff   call     0x54eff0
005e81b1: 6a00         push     0
005e81b3: 8d45a8       lea      eax, [ebp - 0x58]
005e81b6: c645fc2b     mov      byte ptr [ebp - 4], 0x2b
005e81ba: 6a01         push     1
005e81bc: 50           push     eax
005e81bd: e82e022900   call     0x8783f0
005e81c2: 83c40c       add      esp, 0xc
005e81c5: 8d4da8       lea      ecx, [ebp - 0x58]
005e81c8: e8e385f6ff   call     0x5507b0
005e81cd: 8d8d78ffffff lea      ecx, [ebp - 0x88]
005e81d3: e8d885f6ff   call     0x5507b0
005e81d8: b80c6a5e00   mov      eax, 0x5e6a0c
005e81dd: c3           ret      
005e81de: e8c0e51201   call     0x17167a3
005e81e3: e8bbe51201   call     0x17167a3
005e81e8: e8b6e51201   call     0x17167a3
005e81ed: e8b1e51201   call     0x17167a3
005e81f2: e8ace51201   call     0x17167a3
005e81f7: e8a7e51201   call     0x17167a3
005e81fc: e8a2e51201   call     0x17167a3
005e8201: e89de51201   call     0x17167a3
005e8206: e898e51201   call     0x17167a3
005e820b: e893e51201   call     0x17167a3
005e8210: e88ee51201   call     0x17167a3
005e8215: e889e51201   call     0x17167a3
005e821a: 8d8560ffffff lea      eax, [ebp - 0xa0]
005e8220: 50           push     eax
005e8221: 8d8d94feffff lea      ecx, [ebp - 0x16c]
005e8227: e8b47ef6ff   call     0x5500e0
005e822c: 689871c101   push     0x1c17198
005e8231: 8d8594feffff lea      eax, [ebp - 0x16c]
005e8237: 50           push     eax
005e8238: e86b401201   call     0x170c2a8
005e823d: 6a00         push     0
005e823f: 6a00         push     0
005e8241: e862401201   call     0x170c2a8
005e8246: cc           int3     

; === 050 | 0x5e82ab | TeamCreate.Publish.Attempt ===
005e82ab: 6834838c01   push     0x18c8334
005e82b0: 8d8d64ffffff lea      ecx, [ebp - 0x9c]
005e82b6: c78574ffffff00000000 mov      dword ptr [ebp - 0x8c], 0
005e82c0: c78578ffffff0f000000 mov      dword ptr [ebp - 0x88], 0xf
005e82ca: c68564ffffff00 mov      byte ptr [ebp - 0x9c], 0
005e82d1: e8eabff6ff   call     0x5542c0
005e82d6: 6a00         push     0
005e82d8: 8d8564ffffff lea      eax, [ebp - 0x9c]
005e82de: c745fc00000000 mov      dword ptr [ebp - 4], 0
005e82e5: 6a01         push     1
005e82e7: 50           push     eax
005e82e8: e803012900   call     0x8783f0
005e82ed: 8b9578ffffff mov      edx, dword ptr [ebp - 0x88]
005e82f3: 83c40c       add      esp, 0xc
005e82f6: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
005e82fd: 83fa10       cmp      edx, 0x10
005e8300: 722f         jb       0x5e8331
005e8302: 8b8d64ffffff mov      ecx, dword ptr [ebp - 0x9c]
005e8308: 42           inc      edx
005e8309: 8bc1         mov      eax, ecx
005e830b: 81fa00100000 cmp      edx, 0x1000
005e8311: 7214         jb       0x5e8327
005e8313: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005e8316: 83c223       add      edx, 0x23
005e8319: 2bc1         sub      eax, ecx
005e831b: 83c0fc       add      eax, -4
005e831e: 83f81f       cmp      eax, 0x1f
005e8321: 0f873e170000 ja       0x5e9a65
005e8327: 52           push     edx
005e8328: 51           push     ecx
005e8329: e872cb0801   call     0x1674ea0
005e832e: 83c408       add      esp, 8
005e8331: 85ff         test     edi, edi
005e8333: 0f842f010000 je       0x5e8468
005e8339: 807d0c00     cmp      byte ptr [ebp + 0xc], 0
005e833d: 0f8425010000 je       0x5e8468
005e8343: ff75b8       push     dword ptr [ebp - 0x48]
005e8346: e865de4200   call     0xa161b0
005e834b: 83c404       add      esp, 4

; === 051 | 0x5e83ae | CloudEditAbortPublishDueToUnpublishedPackage ===
005e83ae: 6814848c01   push     0x18c8414
005e83b3: 8d8d64ffffff lea      ecx, [ebp - 0x9c]
005e83b9: c78574ffffff00000000 mov      dword ptr [ebp - 0x8c], 0
005e83c3: c78578ffffff0f000000 mov      dword ptr [ebp - 0x88], 0xf
005e83cd: c68564ffffff00 mov      byte ptr [ebp - 0x9c], 0
005e83d4: e8e7bef6ff   call     0x5542c0
005e83d9: 6a00         push     0
005e83db: 8d8564ffffff lea      eax, [ebp - 0x9c]
005e83e1: c745fc02000000 mov      dword ptr [ebp - 4], 2
005e83e8: 6a01         push     1
005e83ea: 50           push     eax
005e83eb: e800002900   call     0x8783f0
005e83f0: 83c40c       add      esp, 0xc
005e83f3: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
005e83fa: 8d8d64ffffff lea      ecx, [ebp - 0x9c]
005e8400: e8ab83f6ff   call     0x5507b0
005e8405: 6a00         push     0
005e8407: 6a00         push     0
005e8409: 6a00         push     0
005e840b: 6800818c01   push     0x18c8100
005e8410: 68e0808c01   push     0x18c80e0
005e8415: 6844848c01   push     0x18c8444
005e841a: e831402900   call     0x87c450
005e841f: 83c418       add      esp, 0x18
005e8422: 32c0         xor      al, al
005e8424: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
005e8427: 64890d00000000 mov      dword ptr fs:[0], ecx
005e842e: 5f           pop      edi
005e842f: 5e           pop      esi
005e8430: 8be5         mov      esp, ebp
005e8432: 5d           pop      ebp
005e8433: c21000       ret      0x10
005e8436: 807d0c00     cmp      byte ptr [ebp + 0xc], 0
005e843a: 742c         je       0x5e8468
005e843c: ff75b8       push     dword ptr [ebp - 0x48]
005e843f: e8fcdd4200   call     0xa16240
005e8444: 83c404       add      esp, 4
005e8447: 84c0         test     al, al
005e8449: 741d         je       0x5e8468
005e844b: 6a00         push     0
005e844d: 6a00         push     0
005e844f: 6a00         push     0

; === 052 | 0x5e8a6f | TeamCreate ===
005e8a6f: 680c858c01   push     0x18c850c
005e8a74: 8d4dc0       lea      ecx, [ebp - 0x40]
005e8a77: c645fc11     mov      byte ptr [ebp - 4], 0x11
005e8a7b: c745d000000000 mov      dword ptr [ebp - 0x30], 0
005e8a82: c745d40f000000 mov      dword ptr [ebp - 0x2c], 0xf
005e8a89: c645c000     mov      byte ptr [ebp - 0x40], 0
005e8a8d: e82eb8f6ff   call     0x5542c0
005e8a92: 6a03         push     3
005e8a94: 689cde8b01   push     0x18bde9c
005e8a99: 8d4d9c       lea      ecx, [ebp - 0x64]
005e8a9c: c645fc12     mov      byte ptr [ebp - 4], 0x12
005e8aa0: c745ac00000000 mov      dword ptr [ebp - 0x54], 0
005e8aa7: c745b00f000000 mov      dword ptr [ebp - 0x50], 0xf
005e8aae: c6459c00     mov      byte ptr [ebp - 0x64], 0
005e8ab2: e809b8f6ff   call     0x5542c0
005e8ab7: 8d852cffffff lea      eax, [ebp - 0xd4]
005e8abd: c645fc13     mov      byte ptr [ebp - 4], 0x13
005e8ac1: 50           push     eax
005e8ac2: 8d8544ffffff lea      eax, [ebp - 0xbc]
005e8ac8: 50           push     eax
005e8ac9: 8d45c0       lea      eax, [ebp - 0x40]
005e8acc: 50           push     eax
005e8acd: 8d459c       lea      eax, [ebp - 0x64]
005e8ad0: 50           push     eax
005e8ad1: e8aa0a2900   call     0x879580
005e8ad6: 83c410       add      esp, 0x10
005e8ad9: 8d4d9c       lea      ecx, [ebp - 0x64]
005e8adc: e8cf7cf6ff   call     0x5507b0
005e8ae1: 8d4dc0       lea      ecx, [ebp - 0x40]
005e8ae4: e8c77cf6ff   call     0x5507b0
005e8ae9: 8d8d44ffffff lea      ecx, [ebp - 0xbc]
005e8aef: e8bc7cf6ff   call     0x5507b0
005e8af4: 8d8d2cffffff lea      ecx, [ebp - 0xd4]
005e8afa: c645fc05     mov      byte ptr [ebp - 4], 5
005e8afe: e8cd44f8ff   call     0x56cfd0
005e8b03: b904000000   mov      ecx, 4
005e8b08: 803d7e93ea0100 cmp      byte ptr [0x1ea937e], 0
005e8b0f: 0f84ce000000 je       0x5e8be3

; === 053 | 0x5e8b99 | TeamCreate BlockingSaveOrPublish Roblox-Place-Id: [%s] Roblox-Game-Id: [%s] isPublish: [%d] first 16 bits of md5: [%s] authorId: [%lld] ===
005e8b99: 68e8878c01   push     0x18c87e8
005e8b9e: 50           push     eax
005e8b9f: c645fc14     mov      byte ptr [ebp - 4], 0x14
005e8ba3: e878e90801   call     0x1677520
005e8ba8: 8b55d4       mov      edx, dword ptr [ebp - 0x2c]
005e8bab: 83c420       add      esp, 0x20
005e8bae: c645fc05     mov      byte ptr [ebp - 4], 5
005e8bb2: 83fa10       cmp      edx, 0x10
005e8bb5: 722c         jb       0x5e8be3
005e8bb7: 8b4dc0       mov      ecx, dword ptr [ebp - 0x40]
005e8bba: 42           inc      edx
005e8bbb: 8bc1         mov      eax, ecx
005e8bbd: 81fa00100000 cmp      edx, 0x1000
005e8bc3: 7214         jb       0x5e8bd9
005e8bc5: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005e8bc8: 83c223       add      edx, 0x23
005e8bcb: 2bc1         sub      eax, ecx
005e8bcd: 83c0fc       add      eax, -4
005e8bd0: 83f81f       cmp      eax, 0x1f
005e8bd3: 0f879b0e0000 ja       0x5e9a74
005e8bd9: 52           push     edx
005e8bda: 51           push     ecx
005e8bdb: e8c0c20801   call     0x1674ea0
005e8be0: 83c408       add      esp, 8
005e8be3: a1cc58d601   mov      eax, dword ptr [0x1d658cc]
005e8be8: 85c0         test     eax, eax
005e8bea: 7e0c         jle      0x5e8bf8
005e8bec: c645bf01     mov      byte ptr [ebp - 0x41], 1
005e8bf0: 3b05f858d601 cmp      eax, dword ptr [0x1d658f8]
005e8bf6: 7e04         jle      0x5e8bfc
005e8bf8: c645bf00     mov      byte ptr [ebp - 0x41], 0
005e8bfc: 6a18         push     0x18
005e8bfe: e81dc20801   call     0x1674e20
005e8c03: 8bf0         mov      esi, eax
005e8c05: 83c404       add      esp, 4
005e8c08: 8975f0       mov      dword ptr [ebp - 0x10], esi
005e8c0b: 85f6         test     esi, esi
005e8c0d: 744e         je       0x5e8c5d
005e8c0f: 8d45f0       lea      eax, [ebp - 0x10]
005e8c12: c60600       mov      byte ptr [esi], 0
005e8c15: 50           push     eax
005e8c16: 6898e18b01   push     0x18be198
005e8c1b: 6800e18b01   push     0x18be100
005e8c20: c745f00b000000 mov      dword ptr [ebp - 0x10], 0xb
005e8c27: e814b1f7ff   call     0x563d40
005e8c2c: 83c40c       add      esp, 0xc
005e8c2f: 3d98e18b01   cmp      eax, 0x18be198
005e8c34: 8d48fc       lea      ecx, [eax - 4]
005e8c37: 0f45c8       cmovne   ecx, eax
005e8c3a: 8b01         mov      eax, dword ptr [ecx]

; === 054 | 0x5e95a7 | Team Create ===
005e95a7: 68c4858c01   push     0x18c85c4
005e95ac: 68985f8c01   push     0x18c5f98
005e95b1: e83a312900   call     0x87c6f0
005e95b6: 83c41c       add      esp, 0x1c
005e95b9: c645fc27     mov      byte ptr [ebp - 4], 0x27
005e95bd: 8d4d9c       lea      ecx, [ebp - 0x64]
005e95c0: e8eb71f6ff   call     0x5507b0
005e95c5: 803d1047d60100 cmp      byte ptr [0x1d64710], 0
005e95cc: 0f8496030000 je       0x5e9968
005e95d2: 8d450b       lea      eax, [ebp + 0xb]
005e95d5: 50           push     eax
005e95d6: 8d450b       lea      eax, [ebp + 0xb]
005e95d9: 50           push     eax
005e95da: 8d450b       lea      eax, [ebp + 0xb]
005e95dd: 50           push     eax
005e95de: 6a0b         push     0xb
005e95e0: 8d4dc0       lea      ecx, [ebp - 0x40]
005e95e3: e85875feff   call     0x5d0b40
005e95e8: 8d857cffffff lea      eax, [ebp - 0x84]
005e95ee: c645fc35     mov      byte ptr [ebp - 4], 0x35
005e95f2: 50           push     eax
005e95f3: e82867f400   call     0x152fd20
005e95f8: 83c404       add      esp, 4
005e95fb: 8bf0         mov      esi, eax
005e95fd: 6a06         push     6
005e95ff: 68a4848c01   push     0x18c84a4
005e9604: 8d4dd8       lea      ecx, [ebp - 0x28]
005e9607: c645fc36     mov      byte ptr [ebp - 4], 0x36
005e960b: c745e800000000 mov      dword ptr [ebp - 0x18], 0
005e9612: c745ec0f000000 mov      dword ptr [ebp - 0x14], 0xf
005e9619: c645d800     mov      byte ptr [ebp - 0x28], 0
005e961d: e89eacf6ff   call     0x5542c0
005e9622: 56           push     esi
005e9623: 8d45d8       lea      eax, [ebp - 0x28]
005e9626: c645fc37     mov      byte ptr [ebp - 4], 0x37
005e962a: 50           push     eax
005e962b: 8d4dc0       lea      ecx, [ebp - 0x40]
005e962e: e89d7ffeff   call     0x5d15d0
005e9633: 8d4818       lea      ecx, [eax + 0x18]
005e9636: e8b57bf6ff   call     0x5511f0
005e963b: 8d4dd8       lea      ecx, [ebp - 0x28]
005e963e: e86d71f6ff   call     0x5507b0
005e9643: 8d8d7cffffff lea      ecx, [ebp - 0x84]
005e9649: c645fc35     mov      byte ptr [ebp - 4], 0x35

; === 055 | 0x5e98ce | TeamCreate ===
005e98ce: 680c858c01   push     0x18c850c
005e98d3: 8d8d44ffffff lea      ecx, [ebp - 0xbc]
005e98d9: c645fc40     mov      byte ptr [ebp - 4], 0x40
005e98dd: c78554ffffff00000000 mov      dword ptr [ebp - 0xac], 0
005e98e7: c78558ffffff0f000000 mov      dword ptr [ebp - 0xa8], 0xf
005e98f1: c68544ffffff00 mov      byte ptr [ebp - 0xbc], 0
005e98f8: e8c3a9f6ff   call     0x5542c0
005e98fd: 6a03         push     3
005e98ff: 689cde8b01   push     0x18bde9c
005e9904: 8d4dd8       lea      ecx, [ebp - 0x28]
005e9907: c645fc41     mov      byte ptr [ebp - 4], 0x41
005e990b: c745e800000000 mov      dword ptr [ebp - 0x18], 0
005e9912: c745ec0f000000 mov      dword ptr [ebp - 0x14], 0xf
005e9919: c645d800     mov      byte ptr [ebp - 0x28], 0
005e991d: e89ea9f6ff   call     0x5542c0
005e9922: 8d45c0       lea      eax, [ebp - 0x40]
005e9925: c645fc42     mov      byte ptr [ebp - 4], 0x42
005e9929: 50           push     eax
005e992a: 8d459c       lea      eax, [ebp - 0x64]
005e992d: 50           push     eax
005e992e: 8d8544ffffff lea      eax, [ebp - 0xbc]
005e9934: 50           push     eax
005e9935: 8d45d8       lea      eax, [ebp - 0x28]
005e9938: 50           push     eax
005e9939: e842fc2800   call     0x879580
005e993e: 83c410       add      esp, 0x10
005e9941: 8d4dd8       lea      ecx, [ebp - 0x28]
005e9944: e8676ef6ff   call     0x5507b0
005e9949: 8d8d44ffffff lea      ecx, [ebp - 0xbc]
005e994f: e85c6ef6ff   call     0x5507b0
005e9954: 8d4d9c       lea      ecx, [ebp - 0x64]
005e9957: e8546ef6ff   call     0x5507b0
005e995c: 8d4dc0       lea      ecx, [ebp - 0x40]
005e995f: c645fc27     mov      byte ptr [ebp - 4], 0x27
005e9963: e86836f8ff   call     0x56cfd0
005e9968: 803d789ad50100 cmp      byte ptr [0x1d59a78], 0
005e996f: 743d         je       0x5e99ae

; === 056 | 0x5e9973 | TeamCreate.Publish.Failed.Request ===
005e9973: 68a8878c01   push     0x18c87a8
005e9978: 8d4dd8       lea      ecx, [ebp - 0x28]
005e997b: c745e800000000 mov      dword ptr [ebp - 0x18], 0
005e9982: c745ec0f000000 mov      dword ptr [ebp - 0x14], 0xf
005e9989: c645d800     mov      byte ptr [ebp - 0x28], 0
005e998d: e82ea9f6ff   call     0x5542c0
005e9992: 6a00         push     0
005e9994: 8d45d8       lea      eax, [ebp - 0x28]
005e9997: c645fc43     mov      byte ptr [ebp - 4], 0x43
005e999b: 6a01         push     1
005e999d: 50           push     eax
005e999e: e84dea2800   call     0x8783f0
005e99a3: 83c40c       add      esp, 0xc
005e99a6: 8d4dd8       lea      ecx, [ebp - 0x28]
005e99a9: e8026ef6ff   call     0x5507b0
005e99ae: c6450b00     mov      byte ptr [ebp + 0xb], 0
005e99b2: 8d8dfcfeffff lea      ecx, [ebp - 0x104]
005e99b8: e8f36df6ff   call     0x5507b0
005e99bd: 8d8dbcfeffff lea      ecx, [ebp - 0x144]
005e99c3: e80871f6ff   call     0x550ad0
005e99c8: 8b7598       mov      esi, dword ptr [ebp - 0x68]
005e99cb: 83cfff       or       edi, 0xffffffff
005e99ce: 85f6         test     esi, esi
005e99d0: 741f         je       0x5e99f1
005e99d2: 8bc7         mov      eax, edi
005e99d4: f00fc14604   lock xadd dword ptr [esi + 4], eax
005e99d9: 7516         jne      0x5e99f1
005e99db: 8b06         mov      eax, dword ptr [esi]
005e99dd: 8bce         mov      ecx, esi
005e99df: ff10         call     dword ptr [eax]
005e99e1: 8bc7         mov      eax, edi
005e99e3: f00fc14608   lock xadd dword ptr [esi + 8], eax
005e99e8: 7507         jne      0x5e99f1
005e99ea: 8b06         mov      eax, dword ptr [esi]
005e99ec: 8bce         mov      ecx, esi
005e99ee: ff5004       call     dword ptr [eax + 4]
005e99f1: 8d8dc4feffff lea      ecx, [ebp - 0x13c]
005e99f7: e8b46df6ff   call     0x5507b0
005e99fc: 8d8da4feffff lea      ecx, [ebp - 0x15c]
005e9a02: e8a96df6ff   call     0x5507b0
005e9a07: 8bb5f8feffff mov      esi, dword ptr [ebp - 0x108]
005e9a0d: 85f6         test     esi, esi
005e9a0f: 741e         je       0x5e9a2f
005e9a11: 8bc7         mov      eax, edi
005e9a13: f00fc14604   lock xadd dword ptr [esi + 4], eax

; === 057 | 0x5ea8fc | TeamCreate.Publish.Attempt ===
005ea8fc: 6834838c01   push     0x18c8334
005ea901: 8d4ddc       lea      ecx, [ebp - 0x24]
005ea904: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
005ea90b: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
005ea912: c645dc00     mov      byte ptr [ebp - 0x24], 0
005ea916: e8a599f6ff   call     0x5542c0
005ea91b: 6a00         push     0
005ea91d: 8d45dc       lea      eax, [ebp - 0x24]
005ea920: c745fc00000000 mov      dword ptr [ebp - 4], 0
005ea927: 6a01         push     1
005ea929: 50           push     eax
005ea92a: e8c1da2800   call     0x8783f0
005ea92f: 8b55f0       mov      edx, dword ptr [ebp - 0x10]
005ea932: 83c40c       add      esp, 0xc
005ea935: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
005ea93c: 83fa10       cmp      edx, 0x10
005ea93f: 722c         jb       0x5ea96d
005ea941: 8b4ddc       mov      ecx, dword ptr [ebp - 0x24]
005ea944: 42           inc      edx
005ea945: 8bc1         mov      eax, ecx
005ea947: 81fa00100000 cmp      edx, 0x1000
005ea94d: 7214         jb       0x5ea963
005ea94f: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005ea952: 83c223       add      edx, 0x23
005ea955: 2bc1         sub      eax, ecx
005ea957: 83c0fc       add      eax, -4
005ea95a: 83f81f       cmp      eax, 0x1f
005ea95d: 0f87461a0000 ja       0x5ec3a9
005ea963: 52           push     edx
005ea964: 51           push     ecx
005ea965: e836a50801   call     0x1674ea0
005ea96a: 83c408       add      esp, 8
005ea96d: 85ff         test     edi, edi
005ea96f: 0f8408010000 je       0x5eaa7d
005ea975: 807d0c00     cmp      byte ptr [ebp + 0xc], 0
005ea979: 0f84fe000000 je       0x5eaa7d
005ea97f: 803df05cd60100 cmp      byte ptr [0x1d65cf0], 0
005ea986: ff75b0       push     dword ptr [ebp - 0x50]
005ea989: 0f8458020000 je       0x5eabe7
005ea98f: e8acb84200   call     0xa16240
005ea994: 83c404       add      esp, 4
005ea997: 84c0         test     al, al
005ea999: 0f84de000000 je       0x5eaa7d
005ea99f: 56           push     esi

; === 058 | 0x5eac3d | CloudEditAbortPublishDueToUnpublishedPackage ===
005eac3d: 6814848c01   push     0x18c8414
005eac42: 8d4ddc       lea      ecx, [ebp - 0x24]
005eac45: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
005eac4c: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
005eac53: c645dc00     mov      byte ptr [ebp - 0x24], 0
005eac57: e86496f6ff   call     0x5542c0
005eac5c: 6a00         push     0
005eac5e: 8d45dc       lea      eax, [ebp - 0x24]
005eac61: c745fc04000000 mov      dword ptr [ebp - 4], 4
005eac68: 6a01         push     1
005eac6a: 50           push     eax
005eac6b: e880d72800   call     0x8783f0
005eac70: 83c40c       add      esp, 0xc
005eac73: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
005eac7a: 8d4ddc       lea      ecx, [ebp - 0x24]
005eac7d: e82e5bf6ff   call     0x5507b0
005eac82: 6a00         push     0
005eac84: 6a00         push     0
005eac86: 6a00         push     0
005eac88: 6800818c01   push     0x18c8100
005eac8d: 68e0808c01   push     0x18c80e0
005eac92: 6844848c01   push     0x18c8444
005eac97: e8b4172900   call     0x87c450
005eac9c: 8b4508       mov      eax, dword ptr [ebp + 8]
005eac9f: 0f57c0       xorps    xmm0, xmm0
005eaca2: 83c418       add      esp, 0x18
005eaca5: 660fd600     movq     qword ptr [eax], xmm0
005eaca9: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
005eacac: 64890d00000000 mov      dword ptr fs:[0], ecx
005eacb3: 5f           pop      edi
005eacb4: 5e           pop      esi
005eacb5: 8be5         mov      esp, ebp
005eacb7: 5d           pop      ebp
005eacb8: c21400       ret      0x14
005eacbb: 52           push     edx
005eacbc: 51           push     ecx
005eacbd: e8dea10801   call     0x1674ea0
005eacc2: 83c408       add      esp, 8
005eacc5: ff750c       push     dword ptr [ebp + 0xc]
005eacc8: 83bd04ffffff10 cmp      dword ptr [ebp - 0xfc], 0x10
005eaccf: 8d8db4feffff lea      ecx, [ebp - 0x14c]
005eacd5: 51           push     ecx
005eacd6: ffb500ffffff push     dword ptr [ebp - 0x100]
005eacdc: 8d85f0feffff lea      eax, [ebp - 0x110]
005eace2: 0f4385f0feffff cmovae   eax, dword ptr [ebp - 0x110]

; === 059 | 0x5eb3c5 | TeamCreate ===
005eb3c5: 680c858c01   push     0x18c850c
005eb3ca: 8d8d6cffffff lea      ecx, [ebp - 0x94]
005eb3d0: c645fc13     mov      byte ptr [ebp - 4], 0x13
005eb3d4: c7857cffffff00000000 mov      dword ptr [ebp - 0x84], 0
005eb3de: c745800f000000 mov      dword ptr [ebp - 0x80], 0xf
005eb3e5: c6856cffffff00 mov      byte ptr [ebp - 0x94], 0
005eb3ec: e8cf8ef6ff   call     0x5542c0
005eb3f1: 6a03         push     3
005eb3f3: 689cde8b01   push     0x18bde9c
005eb3f8: 8d4ddc       lea      ecx, [ebp - 0x24]
005eb3fb: c645fc14     mov      byte ptr [ebp - 4], 0x14
005eb3ff: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
005eb406: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
005eb40d: c645dc00     mov      byte ptr [ebp - 0x24], 0
005eb411: e8aa8ef6ff   call     0x5542c0
005eb416: 8d4590       lea      eax, [ebp - 0x70]
005eb419: c645fc15     mov      byte ptr [ebp - 4], 0x15
005eb41d: 50           push     eax
005eb41e: 8d8538ffffff lea      eax, [ebp - 0xc8]
005eb424: 50           push     eax
005eb425: 8d856cffffff lea      eax, [ebp - 0x94]
005eb42b: 50           push     eax
005eb42c: 8d45dc       lea      eax, [ebp - 0x24]
005eb42f: 50           push     eax
005eb430: e84be12800   call     0x879580
005eb435: 83c410       add      esp, 0x10
005eb438: 8d4ddc       lea      ecx, [ebp - 0x24]
005eb43b: e87053f6ff   call     0x5507b0
005eb440: 8d8d6cffffff lea      ecx, [ebp - 0x94]
005eb446: e86553f6ff   call     0x5507b0
005eb44b: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
005eb451: e85a53f6ff   call     0x5507b0
005eb456: 8d4d90       lea      ecx, [ebp - 0x70]
005eb459: c645fc07     mov      byte ptr [ebp - 4], 7
005eb45d: e86e1bf8ff   call     0x56cfd0
005eb462: b904000000   mov      ecx, 4
005eb467: 803d7e93ea0100 cmp      byte ptr [0x1ea937e], 0

; === 060 | 0x5eb4f8 | TeamCreate BlockingSaveOrPublish Roblox-Place-Id: [%s] Roblox-Game-Id: [%s] isPublish: [%d] first 16 bits of md5: [%s] authorId: [%lld] ===
005eb4f8: 68e8878c01   push     0x18c87e8
005eb4fd: 50           push     eax
005eb4fe: c645fc16     mov      byte ptr [ebp - 4], 0x16
005eb502: e819c00801   call     0x1677520
005eb507: 83c420       add      esp, 0x20
005eb50a: c645fc07     mov      byte ptr [ebp - 4], 7
005eb50e: 8d4ddc       lea      ecx, [ebp - 0x24]
005eb511: e89a52f6ff   call     0x5507b0
005eb516: a1cc58d601   mov      eax, dword ptr [0x1d658cc]
005eb51b: 85c0         test     eax, eax
005eb51d: 7e0c         jle      0x5eb52b
005eb51f: c645bf01     mov      byte ptr [ebp - 0x41], 1
005eb523: 3b05f858d601 cmp      eax, dword ptr [0x1d658f8]
005eb529: 7e04         jle      0x5eb52f
005eb52b: c645bf00     mov      byte ptr [ebp - 0x41], 0
005eb52f: 6a18         push     0x18
005eb531: e8ea980801   call     0x1674e20
005eb536: 83c404       add      esp, 4
005eb539: 898568ffffff mov      dword ptr [ebp - 0x98], eax
005eb53f: 85c0         test     eax, eax
005eb541: 7417         je       0x5eb55a
005eb543: 8d4ddb       lea      ecx, [ebp - 0x25]
005eb546: 51           push     ecx
005eb547: 8d4ddb       lea      ecx, [ebp - 0x25]
005eb54a: 51           push     ecx
005eb54b: 8d4ddb       lea      ecx, [ebp - 0x25]
005eb54e: 51           push     ecx
005eb54f: 6a0b         push     0xb
005eb551: 8bc8         mov      ecx, eax
005eb553: e888def7ff   call     0x5693e0
005eb558: eb02         jmp      0x5eb55c
005eb55a: 33c0         xor      eax, eax
005eb55c: ff750c       push     dword ptr [ebp + 0xc]
005eb55f: 8d8d7cffffff lea      ecx, [ebp - 0x84]
005eb565: c7857cffffff00000000 mov      dword ptr [ebp - 0x84], 0
005eb56f: 50           push     eax
005eb570: c7458000000000 mov      dword ptr [ebp - 0x80], 0
005eb577: e87465fdff   call     0x5c1af0
005eb57c: 807d0c00     cmp      byte ptr [ebp + 0xc], 0
005eb580: 8d45db       lea      eax, [ebp - 0x25]
005eb583: 8bb57cffffff mov      esi, dword ptr [ebp - 0x84]
005eb589: 8bce         mov      ecx, esi
005eb58b: 50           push     eax
005eb58c: 68089ad501   push     0x1d59a08
005eb591: c645fc17     mov      byte ptr [ebp - 4], 0x17
005eb595: 0f9445db     sete     byte ptr [ebp - 0x25]
005eb599: e86296fdff   call     0x5c4c00

; === 061 | 0x5ebf2a | Team Create ===
005ebf2a: 68c4858c01   push     0x18c85c4
005ebf2f: 68985f8c01   push     0x18c5f98
005ebf34: e8b7072900   call     0x87c6f0
005ebf39: 83c41c       add      esp, 0x1c
005ebf3c: c645fc2b     mov      byte ptr [ebp - 4], 0x2b
005ebf40: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
005ebf46: e86548f6ff   call     0x5507b0
005ebf4b: 803d1047d60100 cmp      byte ptr [0x1d64710], 0
005ebf52: 0f849c030000 je       0x5ec2f4
005ebf58: 8d451b       lea      eax, [ebp + 0x1b]
005ebf5b: 50           push     eax
005ebf5c: 8d451b       lea      eax, [ebp + 0x1b]
005ebf5f: 50           push     eax
005ebf60: 8d451b       lea      eax, [ebp + 0x1b]
005ebf63: 50           push     eax
005ebf64: 6a0b         push     0xb
005ebf66: 8d4ddc       lea      ecx, [ebp - 0x24]
005ebf69: e8d24bfeff   call     0x5d0b40
005ebf6e: 8d8550ffffff lea      eax, [ebp - 0xb0]
005ebf74: c645fc39     mov      byte ptr [ebp - 4], 0x39
005ebf78: 50           push     eax
005ebf79: e8a23df400   call     0x152fd20
005ebf7e: 83c404       add      esp, 4
005ebf81: 8bf0         mov      esi, eax
005ebf83: 6a06         push     6
005ebf85: 68a4848c01   push     0x18c84a4
005ebf8a: 8d4dc0       lea      ecx, [ebp - 0x40]
005ebf8d: c645fc3a     mov      byte ptr [ebp - 4], 0x3a
005ebf91: c745d000000000 mov      dword ptr [ebp - 0x30], 0
005ebf98: c745d40f000000 mov      dword ptr [ebp - 0x2c], 0xf
005ebf9f: c645c000     mov      byte ptr [ebp - 0x40], 0
005ebfa3: e81883f6ff   call     0x5542c0
005ebfa8: 56           push     esi
005ebfa9: 8d45c0       lea      eax, [ebp - 0x40]
005ebfac: c645fc3b     mov      byte ptr [ebp - 4], 0x3b
005ebfb0: 50           push     eax
005ebfb1: 8d4ddc       lea      ecx, [ebp - 0x24]
005ebfb4: e81756feff   call     0x5d15d0
005ebfb9: 8d4818       lea      ecx, [eax + 0x18]
005ebfbc: e82f52f6ff   call     0x5511f0
005ebfc1: 8d4dc0       lea      ecx, [ebp - 0x40]
005ebfc4: e8e747f6ff   call     0x5507b0
005ebfc9: 8d8d50ffffff lea      ecx, [ebp - 0xb0]
005ebfcf: c645fc39     mov      byte ptr [ebp - 4], 0x39

; === 062 | 0x5ec254 | TeamCreate ===
005ec254: 680c858c01   push     0x18c850c
005ec259: 8d8d08ffffff lea      ecx, [ebp - 0xf8]
005ec25f: c645fc44     mov      byte ptr [ebp - 4], 0x44
005ec263: c78518ffffff00000000 mov      dword ptr [ebp - 0xe8], 0
005ec26d: c7851cffffff0f000000 mov      dword ptr [ebp - 0xe4], 0xf
005ec277: c68508ffffff00 mov      byte ptr [ebp - 0xf8], 0
005ec27e: e83d80f6ff   call     0x5542c0
005ec283: 6a03         push     3
005ec285: 689cde8b01   push     0x18bde9c
005ec28a: 8d4dc0       lea      ecx, [ebp - 0x40]
005ec28d: c645fc45     mov      byte ptr [ebp - 4], 0x45
005ec291: c745d000000000 mov      dword ptr [ebp - 0x30], 0
005ec298: c745d40f000000 mov      dword ptr [ebp - 0x2c], 0xf
005ec29f: c645c000     mov      byte ptr [ebp - 0x40], 0
005ec2a3: e81880f6ff   call     0x5542c0
005ec2a8: 8d45dc       lea      eax, [ebp - 0x24]
005ec2ab: c645fc46     mov      byte ptr [ebp - 4], 0x46
005ec2af: 50           push     eax
005ec2b0: 8d8538ffffff lea      eax, [ebp - 0xc8]
005ec2b6: 50           push     eax
005ec2b7: 8d8508ffffff lea      eax, [ebp - 0xf8]
005ec2bd: 50           push     eax
005ec2be: 8d45c0       lea      eax, [ebp - 0x40]
005ec2c1: 50           push     eax
005ec2c2: e8b9d22800   call     0x879580
005ec2c7: 83c410       add      esp, 0x10
005ec2ca: 8d4dc0       lea      ecx, [ebp - 0x40]
005ec2cd: e8de44f6ff   call     0x5507b0
005ec2d2: 8d8d08ffffff lea      ecx, [ebp - 0xf8]
005ec2d8: e8d344f6ff   call     0x5507b0
005ec2dd: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
005ec2e3: e8c844f6ff   call     0x5507b0
005ec2e8: 8d4ddc       lea      ecx, [ebp - 0x24]
005ec2eb: c645fc2b     mov      byte ptr [ebp - 4], 0x2b
005ec2ef: e8dc0cf8ff   call     0x56cfd0
005ec2f4: 803d789ad50100 cmp      byte ptr [0x1d59a78], 0

; === 063 | 0x5ec2ff | TeamCreate.Publish.Failed.Request ===
005ec2ff: 68a8878c01   push     0x18c87a8
005ec304: 8d4dc0       lea      ecx, [ebp - 0x40]
005ec307: c745d000000000 mov      dword ptr [ebp - 0x30], 0
005ec30e: c745d40f000000 mov      dword ptr [ebp - 0x2c], 0xf
005ec315: c645c000     mov      byte ptr [ebp - 0x40], 0
005ec319: e8a27ff6ff   call     0x5542c0
005ec31e: 6a00         push     0
005ec320: 8d45c0       lea      eax, [ebp - 0x40]
005ec323: c645fc47     mov      byte ptr [ebp - 4], 0x47
005ec327: 6a01         push     1
005ec329: 50           push     eax
005ec32a: e8c1c02800   call     0x8783f0
005ec32f: 83c40c       add      esp, 0xc
005ec332: 8d4dc0       lea      ecx, [ebp - 0x40]
005ec335: e87644f6ff   call     0x5507b0
005ec33a: 8b7508       mov      esi, dword ptr [ebp + 8]
005ec33d: 0f57c0       xorps    xmm0, xmm0
005ec340: 660fd606     movq     qword ptr [esi], xmm0
005ec344: e9baf9ffff   jmp      0x5ebd03
005ec349: 8b7508       mov      esi, dword ptr [ebp + 8]
005ec34c: 0f57c0       xorps    xmm0, xmm0
005ec34f: 660fd606     movq     qword ptr [esi], xmm0
005ec353: 8d8dd4feffff lea      ecx, [ebp - 0x12c]
005ec359: e85244f6ff   call     0x5507b0
005ec35e: 8d8d9cfeffff lea      ecx, [ebp - 0x164]
005ec364: e84744f6ff   call     0x5507b0
005ec369: 8d8d7cffffff lea      ecx, [ebp - 0x84]
005ec36f: e8bc47f6ff   call     0x550b30
005ec374: 8d8d20ffffff lea      ecx, [ebp - 0xe0]
005ec37a: e83144f6ff   call     0x5507b0
005ec37f: 8d8db4feffff lea      ecx, [ebp - 0x14c]
005ec385: e82644f6ff   call     0x5507b0
005ec38a: 8d8df0feffff lea      ecx, [ebp - 0x110]
005ec390: e81b44f6ff   call     0x5507b0
005ec395: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
005ec398: 8bc6         mov      eax, esi
005ec39a: 5f           pop      edi
005ec39b: 64890d00000000 mov      dword ptr fs:[0], ecx
005ec3a2: 5e           pop      esi

; === 064 | 0x5f659b | Configuring as cloud edit server! ===
005f659b: 683c918c01   push     0x18c913c
005f65a0: 6a01         push     1
005f65a2: e829882700   call     0x86edd0
005f65a7: 8b4dd8       mov      ecx, dword ptr [ebp - 0x28]
005f65aa: 83c40c       add      esp, 0xc
005f65ad: e8cec40400   call     0x642a80
005f65b2: 8b4310       mov      eax, dword ptr [ebx + 0x10]
005f65b5: 83f804       cmp      eax, 4
005f65b8: 7519         jne      0x5f65d3
005f65ba: 6a06         push     6
005f65bc: 6860918c01   push     0x18c9160
005f65c1: 6a01         push     1
005f65c3: e808882700   call     0x86edd0
005f65c8: 8b4dd8       mov      ecx, dword ptr [ebp - 0x28]
005f65cb: 83c40c       add      esp, 0xc
005f65ce: e80dc60400   call     0x642be0
005f65d3: 8b0f         mov      ecx, dword ptr [edi]
005f65d5: 8d490c       lea      ecx, [ecx + 0xc]
005f65d8: e8837ff6ff   call     0x55e560
005f65dd: 83ec18       sub      esp, 0x18
005f65e0: 894508       mov      dword ptr [ebp + 8], eax
005f65e3: 8bcc         mov      ecx, esp
005f65e5: 8d45b4       lea      eax, [ebp - 0x4c]
005f65e8: 68d89bd501   push     0x1d59bd8
005f65ed: 50           push     eax
005f65ee: 51           push     ecx
005f65ef: e8dcd6ffff   call     0x5f3cd0
005f65f4: 8b4d08       mov      ecx, dword ptr [ebp + 8]
005f65f7: 83c40c       add      esp, 0xc
005f65fa: e8b15f3900   call     0x98c5b0
005f65ff: 83fe03       cmp      esi, 3
005f6602: 750a         jne      0x5f660e
005f6604: 8b0f         mov      ecx, dword ptr [edi]
005f6606: 8d490c       lea      ecx, [ecx + 0xc]
005f6609: e8d2dfffff   call     0x5f45e0
005f660e: 8b0f         mov      ecx, dword ptr [edi]
005f6610: 8d490c       lea      ecx, [ecx + 0xc]
005f6613: e848c1fcff   call     0x5c2760
005f6618: 83ec18       sub      esp, 0x18
005f661b: 8bf0         mov      esi, eax
005f661d: 8bcc         mov      ecx, esp
005f661f: 8d45b4       lea      eax, [ebp - 0x4c]
005f6622: 68fc368c01   push     0x18c36fc
005f6627: 50           push     eax
005f6628: 51           push     ecx
005f6629: e8b226f6ff   call     0x558ce0
005f662e: 83c40c       add      esp, 0xc
005f6631: 8bce         mov      ecx, esi
005f6633: e8983a2e00   call     0x8da0d0
005f6638: 83ceff       or       esi, 0xffffffff
005f663b: 807b5900     cmp      byte ptr [ebx + 0x59], 0

; === 065 | 0x5f698c | Started Model Mesh Job to generate live updates.. or this is team create. ===
005f698c: 6888918c01   push     0x18c9188
005f6991: 6a01         push     1
005f6993: e838842700   call     0x86edd0
005f6998: 6848010000   push     0x148
005f699d: e87ee40701   call     0x1674e20
005f69a2: 83c410       add      esp, 0x10
005f69a5: 8945f0       mov      dword ptr [ebp - 0x10], eax
005f69a8: c645fc09     mov      byte ptr [ebp - 4], 9
005f69ac: 85c0         test     eax, eax
005f69ae: 740c         je       0x5f69bc
005f69b0: 57           push     edi
005f69b1: 8bc8         mov      ecx, eax
005f69b3: e8c8d1ffff   call     0x5f3b80
005f69b8: 8bf0         mov      esi, eax
005f69ba: eb02         jmp      0x5f69be
005f69bc: 33f6         xor      esi, esi
005f69be: 8d7e10       lea      edi, [esi + 0x10]
005f69c1: 8975d4       mov      dword ptr [ebp - 0x2c], esi
005f69c4: 897dd0       mov      dword ptr [ebp - 0x30], edi
005f69c7: 85ff         test     edi, edi
005f69c9: 745d         je       0x5f6a28
005f69cb: 8b470c       mov      eax, dword ptr [edi + 0xc]
005f69ce: 85c0         test     eax, eax
005f69d0: 7406         je       0x5f69d8
005f69d2: 83780400     cmp      dword ptr [eax + 4], 0
005f69d6: 7550         jne      0x5f6a28
005f69d8: 85f6         test     esi, esi
005f69da: 740c         je       0x5f69e8
005f69dc: f0ff4604     lock inc dword ptr [esi + 4]
005f69e0: 85f6         test     esi, esi
005f69e2: 7404         je       0x5f69e8
005f69e4: f0ff4608     lock inc dword ptr [esi + 8]
005f69e8: 897f08       mov      dword ptr [edi + 8], edi
005f69eb: 83cbff       or       ebx, 0xffffffff
005f69ee: 8b4f0c       mov      ecx, dword ptr [edi + 0xc]
005f69f1: 89770c       mov      dword ptr [edi + 0xc], esi
005f69f4: 85c9         test     ecx, ecx
005f69f6: 740e         je       0x5f6a06
005f69f8: 8bc3         mov      eax, ebx
005f69fa: f00fc14108   lock xadd dword ptr [ecx + 8], eax
005f69ff: 7505         jne      0x5f6a06
005f6a01: 8b01         mov      eax, dword ptr [ecx]
005f6a03: ff5004       call     dword ptr [eax + 4]
005f6a06: 85f6         test     esi, esi
005f6a08: 741e         je       0x5f6a28
005f6a0a: 8bc3         mov      eax, ebx
005f6a0c: f00fc14604   lock xadd dword ptr [esi + 4], eax
005f6a11: 7515         jne      0x5f6a28
005f6a13: 8b06         mov      eax, dword ptr [esi]
005f6a15: 8bce         mov      ecx, esi
005f6a17: ff10         call     dword ptr [eax]
005f6a19: f00fc15e08   lock xadd dword ptr [esi + 8], ebx
005f6a1e: 4b           dec      ebx
005f6a1f: 7507         jne      0x5f6a28
005f6a21: 8b06         mov      eax, dword ptr [esi]
005f6a23: 8bce         mov      ecx, esi
005f6a25: ff5004       call     dword ptr [eax + 4]
005f6a28: 83ec08       sub      esp, 8
005f6a2b: c645fc0a     mov      byte ptr [ebp - 4], 0xa
005f6a2f: 8d5e04       lea      ebx, [esi + 4]

; === 066 | 0x5f6a7b | TeamCreateJobActive ===
005f6a7b: 68d4918c01   push     0x18c91d4
005f6a80: 68e8918c01   push     0x18c91e8
005f6a85: 68985f8c01   push     0x18c5f98
005f6a8a: e8c1592800   call     0x87c450
005f6a8f: 83c418       add      esp, 0x18
005f6a92: 8d4dd0       lea      ecx, [ebp - 0x30]
005f6a95: e896a0f5ff   call     0x550b30
005f6a9a: 8b5598       mov      edx, dword ptr [ebp - 0x68]
005f6a9d: 83fa10       cmp      edx, 0x10
005f6aa0: 722c         jb       0x5f6ace
005f6aa2: 8b4d84       mov      ecx, dword ptr [ebp - 0x7c]
005f6aa5: 42           inc      edx
005f6aa6: 8bc1         mov      eax, ecx
005f6aa8: 81fa00100000 cmp      edx, 0x1000
005f6aae: 7214         jb       0x5f6ac4
005f6ab0: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005f6ab3: 83c223       add      edx, 0x23
005f6ab6: 2bc1         sub      eax, ecx
005f6ab8: 83c0fc       add      eax, -4
005f6abb: 83f81f       cmp      eax, 0x1f
005f6abe: 0f8734010000 ja       0x5f6bf8
005f6ac4: 52           push     edx
005f6ac5: 51           push     ecx
005f6ac6: e8d5e30701   call     0x1674ea0
005f6acb: 83c408       add      esp, 8
005f6ace: 8b55b0       mov      edx, dword ptr [ebp - 0x50]
005f6ad1: c7459400000000 mov      dword ptr [ebp - 0x6c], 0
005f6ad8: c745980f000000 mov      dword ptr [ebp - 0x68], 0xf
005f6adf: c6458400     mov      byte ptr [ebp - 0x7c], 0
005f6ae3: 83fa10       cmp      edx, 0x10
005f6ae6: 722c         jb       0x5f6b14
005f6ae8: 8b4d9c       mov      ecx, dword ptr [ebp - 0x64]
005f6aeb: 42           inc      edx
005f6aec: 8bc1         mov      eax, ecx
005f6aee: 81fa00100000 cmp      edx, 0x1000
005f6af4: 7214         jb       0x5f6b0a
005f6af6: 8b49fc       mov      ecx, dword ptr [ecx - 4]
005f6af9: 83c223       add      edx, 0x23
005f6afc: 2bc1         sub      eax, ecx
005f6afe: 83c0fc       add      eax, -4
005f6b01: 83f81f       cmp      eax, 0x1f
005f6b04: 0f87f3000000 ja       0x5f6bfd
005f6b0a: 52           push     edx
005f6b0b: 51           push     ecx
005f6b0c: e88fe30701   call     0x1674ea0
005f6b11: 83c408       add      esp, 8
005f6b14: 8b5580       mov      edx, dword ptr [ebp - 0x80]
005f6b17: c745ac00000000 mov      dword ptr [ebp - 0x54], 0
005f6b1e: c745b00f000000 mov      dword ptr [ebp - 0x50], 0xf

; === 067 | 0x61bef3 | You have been disconnected from Team Create, please reconnect ===
0061bef3: 6888d08c01   push     0x18cd088
0061bef8: eb3d         jmp      0x61bf37
0061befa: 6a30         push     0x30
0061befc: 68c8d08c01   push     0x18cd0c8
0061bf01: eb34         jmp      0x61bf37
0061bf03: 6a47         push     0x47
0061bf05: 6800d18c01   push     0x18cd100
0061bf0a: eb2b         jmp      0x61bf37
0061bf0c: 6a38         push     0x38
0061bf0e: 6848d18c01   push     0x18cd148
0061bf13: eb22         jmp      0x61bf37
0061bf15: 6a35         push     0x35
0061bf17: 6884d18c01   push     0x18cd184
0061bf1c: eb19         jmp      0x61bf37
0061bf1e: 6a52         push     0x52
0061bf20: 68c0d18c01   push     0x18cd1c0
0061bf25: eb10         jmp      0x61bf37
0061bf27: 6a1b         push     0x1b
0061bf29: 6814d28c01   push     0x18cd214
0061bf2e: eb07         jmp      0x61bf37
0061bf30: 6a28         push     0x28
0061bf32: 6830d28c01   push     0x18cd230
0061bf37: 8b7508       mov      esi, dword ptr [ebp + 8]
0061bf3a: 8bce         mov      ecx, esi
0061bf3c: c7461000000000 mov      dword ptr [esi + 0x10], 0
0061bf43: c746140f000000 mov      dword ptr [esi + 0x14], 0xf
0061bf4a: c60600       mov      byte ptr [esi], 0
0061bf4d: e86e83f3ff   call     0x5542c0
0061bf52: 8bc6         mov      eax, esi
0061bf54: 5e           pop      esi
0061bf55: 5d           pop      ebp
0061bf56: c3           ret      
0061bf57: 90           nop      
0061bf58: 76be         jbe      0x61bf18
0061bf5a: 61           popal    
0061bf5b: 0082be61008e add      byte ptr [edx - 0x71ff9e42], al
0061bf61: be61009abe   mov      esi, 0xbe9a0061
0061bf66: 61           popal    
0061bf67: 00a6be6100b2 add      byte ptr [esi - 0x4dff9e42], ah
0061bf6d: be6100bbbe   mov      esi, 0xbebb0061
0061bf72: 61           popal    
0061bf73: 00c4         add      ah, al
0061bf75: be6100cdbe   mov      esi, 0xbecd0061
0061bf7a: 61           popal    
0061bf7b: 00d6         add      dh, dl
0061bf7d: be6100dfbe   mov      esi, 0xbedf0061
0061bf82: 61           popal    
0061bf83: 00e8         add      al, ch
0061bf85: be6100f1be   mov      esi, 0xbef10061
0061bf8a: 61           popal    
0061bf8b: 00fa         add      dl, bh
0061bf8d: be610076be   mov      esi, 0xbe760061
0061bf92: 61           popal    
0061bf93: 0003         add      byte ptr [ebx], al

; === 068 | 0x61c074 | CloudEditKick ===
0061c074: 68c8cc8c01   push     0x18cccc8
0061c079: eb46         jmp      0x61c0c1
0061c07b: 6a0a         push     0xa
0061c07d: 68d8cc8c01   push     0x18cccd8
0061c082: eb3d         jmp      0x61c0c1
0061c084: 6a07         push     7
0061c086: 68e4cc8c01   push     0x18ccce4
0061c08b: eb34         jmp      0x61c0c1
0061c08d: 6a0e         push     0xe
0061c08f: 68eccc8c01   push     0x18cccec
0061c094: eb2b         jmp      0x61c0c1
0061c096: 6a0d         push     0xd
0061c098: 68fccc8c01   push     0x18cccfc
0061c09d: eb22         jmp      0x61c0c1
0061c09f: 6a06         push     6
0061c0a1: 680ccd8c01   push     0x18ccd0c
0061c0a6: eb19         jmp      0x61c0c1
0061c0a8: 6a0e         push     0xe
0061c0aa: 6814cd8c01   push     0x18ccd14
0061c0af: eb10         jmp      0x61c0c1
0061c0b1: 6a09         push     9
0061c0b3: 6824cd8c01   push     0x18ccd24
0061c0b8: eb07         jmp      0x61c0c1
0061c0ba: 6a04         push     4
0061c0bc: 6830cd8c01   push     0x18ccd30
0061c0c1: 8b7508       mov      esi, dword ptr [ebp + 8]
0061c0c4: 8bce         mov      ecx, esi
0061c0c6: c7461000000000 mov      dword ptr [esi + 0x10], 0
0061c0cd: c746140f000000 mov      dword ptr [esi + 0x14], 0xf
0061c0d4: c60600       mov      byte ptr [esi], 0
0061c0d7: e8e481f3ff   call     0x5542c0
0061c0dc: 8bc6         mov      eax, esi
0061c0de: 5e           pop      esi
0061c0df: 5d           pop      ebp
0061c0e0: c3           ret      
0061c0e1: 0f1f00       nop      dword ptr [eax]
0061c0e4: dcbf6100e8bf fdivr    qword ptr [edi - 0x4017ff9f]
0061c0ea: 61           popal    
0061c0eb: 0000         add      byte ptr [eax], al
0061c0ed: c061000c     shl      byte ptr [ecx], 0xc
0061c0f1: c0610018     shl      byte ptr [ecx], 0x18
0061c0f5: c0610024     shl      byte ptr [ecx], 0x24
0061c0f9: c0610030     shl      byte ptr [ecx], 0x30
0061c0fd: c061003c     shl      byte ptr [ecx], 0x3c
0061c101: c0610045     shl      byte ptr [ecx], 0x45
0061c105: c061004e     shl      byte ptr [ecx], 0x4e
0061c109: c0610057     shl      byte ptr [ecx], 0x57
0061c10d: c0610060     shl      byte ptr [ecx], 0x60
0061c111: c0610069     shl      byte ptr [ecx], 0x69
0061c115: c0610072     shl      byte ptr [ecx], 0x72

; === 069 | 0x628e7f | ReplicatorJoinTimeSnapShotTimeTeamCreate ===
00628e7f: 6804dc8c01   push     0x18cdc04
00628e84: e837b4f2ff   call     0x5542c0
00628e89: c645fc04     mov      byte ptr [ebp - 4], 4
00628e8d: eb10         jmp      0x628e9f
00628e8f: 6a1e         push     0x1e
00628e91: 6830dc8c01   push     0x18cdc30
00628e96: e825b4f2ff   call     0x5542c0
00628e9b: c645fc05     mov      byte ptr [ebp - 4], 5
00628e9f: 6a00         push     0
00628ea1: 56           push     esi
00628ea2: 8d45d4       lea      eax, [ebp - 0x2c]
00628ea5: 50           push     eax
00628ea6: 8d8d30ffffff lea      ecx, [ebp - 0xd0]
00628eac: e86f7eef00   call     0x1520d20
00628eb1: 8d4dd4       lea      ecx, [ebp - 0x2c]
00628eb4: e8f778f2ff   call     0x5507b0
00628eb9: e98d010000   jmp      0x62904b
00628ebe: 6a00         push     0
00628ec0: 6a00         push     0
00628ec2: 6aff         push     -1
00628ec4: 8d8d68ffffff lea      ecx, [ebp - 0x98]
00628eca: e82168ef00   call     0x151f6f0
00628ecf: 8b83c01d0000 mov      eax, dword ptr [ebx + 0x1dc0]
00628ed5: c645fc06     mov      byte ptr [ebp - 4], 6
00628ed9: 85c0         test     eax, eax
00628edb: 7410         je       0x628eed
00628edd: 8b80b8000000 mov      eax, dword ptr [eax + 0xb8]
00628ee3: 8b4804       mov      ecx, dword ptr [eax + 4]
00628ee6: 2b08         sub      ecx, dword ptr [eax]
00628ee8: c1f903       sar      ecx, 3
00628eeb: eb03         jmp      0x628ef0
00628eed: 83c9ff       or       ecx, 0xffffffff
00628ef0: 51           push     ecx
00628ef1: 68f8db8c01   push     0x18cdbf8
00628ef6: 8d8d68ffffff lea      ecx, [ebp - 0x98]
00628efc: e8bf6aef00   call     0x151f9c0
00628f01: 8b8e3c040000 mov      ecx, dword ptr [esi + 0x43c]
00628f07: 8b4104       mov      eax, dword ptr [ecx + 4]
00628f0a: 8b11         mov      edx, dword ptr [ecx]
00628f0c: 2bc1         sub      eax, ecx
00628f0e: 2bd1         sub      edx, ecx
00628f10: 8d8d68ffffff lea      ecx, [ebp - 0x98]
00628f16: 50           push     eax
00628f17: 52           push     edx
00628f18: 68f0ec8b01   push     0x18becf0
00628f1d: e88e6cef00   call     0x151fbb0
00628f22: ffb64c040000 push     dword ptr [esi + 0x44c]

; === 070 | 0x629006 | ReplicatorJoinTimeSnapShotTimeTeamCreate ===
00629006: 6804dc8c01   push     0x18cdc04
0062900b: e8b0b2f2ff   call     0x5542c0
00629010: c645fc07     mov      byte ptr [ebp - 4], 7
00629014: eb10         jmp      0x629026
00629016: 6a1e         push     0x1e
00629018: 6830dc8c01   push     0x18cdc30
0062901d: e89eb2f2ff   call     0x5542c0
00629022: c645fc08     mov      byte ptr [ebp - 4], 8
00629026: 6a00         push     0
00629028: 56           push     esi
00629029: 8d45d4       lea      eax, [ebp - 0x2c]
0062902c: 50           push     eax
0062902d: 8d8d68ffffff lea      ecx, [ebp - 0x98]
00629033: e8e87cef00   call     0x1520d20
00629038: 8d4dd4       lea      ecx, [ebp - 0x2c]
0062903b: e87077f2ff   call     0x5507b0
00629040: 8d8d68ffffff lea      ecx, [ebp - 0x98]
00629046: e8a567ef00   call     0x151f7f0
0062904b: 8d8d30ffffff lea      ecx, [ebp - 0xd0]
00629051: e89a67ef00   call     0x151f7f0
00629056: 8d4dc8       lea      ecx, [ebp - 0x38]
00629059: e88243f4ff   call     0x56d3e0
0062905e: 8b75c4       mov      esi, dword ptr [ebp - 0x3c]
00629061: 85f6         test     esi, esi
00629063: 741f         je       0x629084
00629065: 8bc7         mov      eax, edi
00629067: f00fc14604   lock xadd dword ptr [esi + 4], eax
0062906c: 7516         jne      0x629084
0062906e: 8b06         mov      eax, dword ptr [esi]
00629070: 8bce         mov      ecx, esi
00629072: ff10         call     dword ptr [eax]
00629074: 8bc7         mov      eax, edi
00629076: f00fc14608   lock xadd dword ptr [esi + 8], eax
0062907b: 7507         jne      0x629084
0062907d: 8b06         mov      eax, dword ptr [esi]
0062907f: 8bce         mov      ecx, esi
00629081: ff5004       call     dword ptr [eax + 4]
00629084: 8b4d0c       mov      ecx, dword ptr [ebp + 0xc]
00629087: 85c9         test     ecx, ecx
00629089: 740d         je       0x629098
0062908b: f00fc17908   lock xadd dword ptr [ecx + 8], edi
00629090: 4f           dec      edi
00629091: 7505         jne      0x629098
00629093: 8b01         mov      eax, dword ptr [ecx]
00629095: ff5004       call     dword ptr [eax + 4]
00629098: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
0062909b: 5f           pop      edi
0062909c: 5e           pop      esi
0062909d: 64890d00000000 mov      dword ptr fs:[0], ecx
006290a4: 5b           pop      ebx
006290a5: 8be5         mov      esp, ebp
006290a7: 5d           pop      ebp

; === 071 | 0x62af65 | CloudEditServerReplicatorStats ===
0062af65: 6870d98c01   push     0x18cd970
0062af6a: eb13         jmp      0x62af7f
0062af6c: 6a15         push     0x15
0062af6e: 6890d98c01   push     0x18cd990
0062af73: eb0a         jmp      0x62af7f
0062af75: 6a15         push     0x15
0062af77: 68a8d98c01   push     0x18cd9a8
0062af7c: 8d4da8       lea      ecx, [ebp - 0x58]
0062af7f: e83c93f2ff   call     0x5542c0
0062af84: 837dbc10     cmp      dword ptr [ebp - 0x44], 0x10
0062af88: 8d45a8       lea      eax, [ebp - 0x58]
0062af8b: 8b3544ceea01 mov      esi, dword ptr [0x1eace44]
0062af91: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
0062af97: 0f4345a8     cmovae   eax, dword ptr [ebp - 0x58]
0062af9b: 50           push     eax
0062af9c: e84f40f2ff   call     0x54eff0
0062afa1: 6a00         push     0
0062afa3: 56           push     esi
0062afa4: 8d8538ffffff lea      eax, [ebp - 0xc8]
0062afaa: c645fc31     mov      byte ptr [ebp - 4], 0x31
0062afae: 50           push     eax
0062afaf: 8d8d00ffffff lea      ecx, [ebp - 0x100]
0062afb5: e8665def00   call     0x1520d20
0062afba: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
0062afc0: e8eb57f2ff   call     0x5507b0
0062afc5: 8d4da8       lea      ecx, [ebp - 0x58]
0062afc8: e8e357f2ff   call     0x5507b0
0062afcd: 8d8d78ffffff lea      ecx, [ebp - 0x88]
0062afd3: e8d857f2ff   call     0x5507b0
0062afd8: 8d8d98feffff lea      ecx, [ebp - 0x168]
0062afde: e8cd57f2ff   call     0x5507b0
0062afe3: 8d4d90       lea      ecx, [ebp - 0x70]
0062afe6: e8c557f2ff   call     0x5507b0
0062afeb: 8d4dc8       lea      ecx, [ebp - 0x38]
0062afee: e8bd57f2ff   call     0x5507b0
0062aff3: 8d8d00ffffff lea      ecx, [ebp - 0x100]
0062aff9: e8f247ef00   call     0x151f7f0
0062affe: 8d4de0       lea      ecx, [ebp - 0x20]
0062b001: e8da23f4ff   call     0x56d3e0
0062b006: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]

; === 072 | 0x642b18 | Team Create ===
00642b18: 68c4858c01   push     0x18c85c4
00642b1d: 68985f8c01   push     0x18c5f98
00642b22: e829992300   call     0x87c450
00642b27: 83c418       add      esp, 0x18
00642b2a: 803d40a5d50100 cmp      byte ptr [0x1d5a540], 0
00642b31: 7477         je       0x642baa
00642b33: e8383b2300   call     0x876670
00642b38: 8bf0         mov      esi, eax
00642b3a: 85f6         test     esi, esi
00642b3c: 746c         je       0x642baa
00642b3e: 6a04         push     4
00642b40: 68c4f48c01   push     0x18cf4c4
00642b45: 8d4db8       lea      ecx, [ebp - 0x48]
00642b48: c745c800000000 mov      dword ptr [ebp - 0x38], 0
00642b4f: c745cc0f000000 mov      dword ptr [ebp - 0x34], 0xf
00642b56: c645b800     mov      byte ptr [ebp - 0x48], 0
00642b5a: e86117f1ff   call     0x5542c0
00642b5f: 6a0d         push     0xd
00642b61: 68b4f48c01   push     0x18cf4b4
00642b66: 8d4dd0       lea      ecx, [ebp - 0x30]
00642b69: c745fc00000000 mov      dword ptr [ebp - 4], 0
00642b70: c745e000000000 mov      dword ptr [ebp - 0x20], 0
00642b77: c745e40f000000 mov      dword ptr [ebp - 0x1c], 0xf
00642b7e: c645d000     mov      byte ptr [ebp - 0x30], 0
00642b82: e83917f1ff   call     0x5542c0
00642b87: 8d45b8       lea      eax, [ebp - 0x48]
00642b8a: c645fc01     mov      byte ptr [ebp - 4], 1
00642b8e: 50           push     eax
00642b8f: 8d45d0       lea      eax, [ebp - 0x30]
00642b92: 8bce         mov      ecx, esi
00642b94: 50           push     eax
00642b95: e8f6dd3400   call     0x990990
00642b9a: 8d4dd0       lea      ecx, [ebp - 0x30]
00642b9d: e80edcf0ff   call     0x5507b0
00642ba2: 8d4db8       lea      ecx, [ebp - 0x48]
00642ba5: e806dcf0ff   call     0x5507b0
00642baa: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00642bad: 5e           pop      esi
00642bae: 64890d00000000 mov      dword ptr fs:[0], ecx
00642bb5: 8be5         mov      esp, ebp
00642bb7: 5d           pop      ebp
00642bb8: c3           ret      

; === 073 | 0x642c63 | Team Create ===
00642c63: 68c4858c01   push     0x18c85c4
00642c68: 68985f8c01   push     0x18c5f98
00642c6d: c7862401000001000000 mov      dword ptr [esi + 0x124], 1
00642c77: e8d4972300   call     0x87c450
00642c7c: 83c418       add      esp, 0x18
00642c7f: 803d40a5d50100 cmp      byte ptr [0x1d5a540], 0
00642c86: 747e         je       0x642d06
00642c88: e8e3392300   call     0x876670
00642c8d: 8bf0         mov      esi, eax
00642c8f: 85f6         test     esi, esi
00642c91: 7473         je       0x642d06
00642c93: 6a09         push     9
00642c95: 68ccf48c01   push     0x18cf4cc
00642c9a: 8d4db8       lea      ecx, [ebp - 0x48]
00642c9d: c745c800000000 mov      dword ptr [ebp - 0x38], 0
00642ca4: c745cc0f000000 mov      dword ptr [ebp - 0x34], 0xf
00642cab: c645b800     mov      byte ptr [ebp - 0x48], 0
00642caf: e80c16f1ff   call     0x5542c0
00642cb4: 6a0d         push     0xd
00642cb6: 68b4f48c01   push     0x18cf4b4
00642cbb: 8d4dd0       lea      ecx, [ebp - 0x30]
00642cbe: c745fc00000000 mov      dword ptr [ebp - 4], 0
00642cc5: c745e000000000 mov      dword ptr [ebp - 0x20], 0
00642ccc: c745e40f000000 mov      dword ptr [ebp - 0x1c], 0xf
00642cd3: c645d000     mov      byte ptr [ebp - 0x30], 0
00642cd7: e8e415f1ff   call     0x5542c0
00642cdc: 8d45b8       lea      eax, [ebp - 0x48]
00642cdf: c645fc01     mov      byte ptr [ebp - 4], 1
00642ce3: 50           push     eax
00642ce4: 8d45d0       lea      eax, [ebp - 0x30]
00642ce7: 8bce         mov      ecx, esi
00642ce9: 50           push     eax
00642cea: e8a1dc3400   call     0x990990
00642cef: 8d4dd0       lea      ecx, [ebp - 0x30]
00642cf2: e8b9daf0ff   call     0x5507b0
00642cf7: 8d4db8       lea      ecx, [ebp - 0x48]
00642cfa: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
00642d01: e8aadaf0ff   call     0x5507b0
00642d06: a0a1d6ea01   mov      al, byte ptr [0x1ead6a1]

; === 074 | 0x691ddc | RequestCloudEditKick ===
00691ddc: 68ac818d01   push     0x18d81ac
00691de1: 8bf0         mov      esi, eax
00691de3: e808cb1d00   call     0x86e8f0
00691de8: 83c404       add      esp, 4
00691deb: 8bce         mov      ecx, esi
00691ded: 50           push     eax
00691dee: e80df6ffff   call     0x691400
00691df3: 85c0         test     eax, eax
00691df5: 741b         je       0x691e12
00691df7: 8b00         mov      eax, dword ptr [eax]
00691df9: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691dfc: 85c0         test     eax, eax
00691dfe: 7412         je       0x691e12
00691e00: 8d45ec       lea      eax, [ebp - 0x14]
00691e03: 8bcb         mov      ecx, ebx
00691e05: 50           push     eax
00691e06: e825dfffff   call     0x68fd30
00691e0b: c7400401000000 mov      dword ptr [eax + 4], 1
00691e12: 8b1f         mov      ebx, dword ptr [edi]
00691e14: e867f72c00   call     0x961580
00691e19: 68c4818d01   push     0x18d81c4
00691e1e: 8bf0         mov      esi, eax
00691e20: e8cbca1d00   call     0x86e8f0
00691e25: 83c404       add      esp, 4
00691e28: 8bce         mov      ecx, esi
00691e2a: 50           push     eax
00691e2b: e8d0f5ffff   call     0x691400
00691e30: 85c0         test     eax, eax
00691e32: 741b         je       0x691e4f
00691e34: 8b00         mov      eax, dword ptr [eax]
00691e36: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691e39: 85c0         test     eax, eax
00691e3b: 7412         je       0x691e4f
00691e3d: 8d45ec       lea      eax, [ebp - 0x14]
00691e40: 8bcb         mov      ecx, ebx
00691e42: 50           push     eax
00691e43: e8e8deffff   call     0x68fd30
00691e48: c7400401000000 mov      dword ptr [eax + 4], 1
00691e4f: 8b1f         mov      ebx, dword ptr [edi]
00691e51: e82af72c00   call     0x961580
00691e56: 68e0818d01   push     0x18d81e0
00691e5b: 8bf0         mov      esi, eax
00691e5d: e88eca1d00   call     0x86e8f0
00691e62: 83c404       add      esp, 4
00691e65: 8bce         mov      ecx, esi
00691e67: 50           push     eax
00691e68: e893f5ffff   call     0x691400
00691e6d: 85c0         test     eax, eax
00691e6f: 741b         je       0x691e8c
00691e71: 8b00         mov      eax, dword ptr [eax]
00691e73: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691e76: 85c0         test     eax, eax
00691e78: 7412         je       0x691e8c
00691e7a: 8d45ec       lea      eax, [ebp - 0x14]
00691e7d: 8bcb         mov      ecx, ebx

; === 075 | 0x691e19 | RequestCloudEditShutdown ===
00691e19: 68c4818d01   push     0x18d81c4
00691e1e: 8bf0         mov      esi, eax
00691e20: e8cbca1d00   call     0x86e8f0
00691e25: 83c404       add      esp, 4
00691e28: 8bce         mov      ecx, esi
00691e2a: 50           push     eax
00691e2b: e8d0f5ffff   call     0x691400
00691e30: 85c0         test     eax, eax
00691e32: 741b         je       0x691e4f
00691e34: 8b00         mov      eax, dword ptr [eax]
00691e36: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691e39: 85c0         test     eax, eax
00691e3b: 7412         je       0x691e4f
00691e3d: 8d45ec       lea      eax, [ebp - 0x14]
00691e40: 8bcb         mov      ecx, ebx
00691e42: 50           push     eax
00691e43: e8e8deffff   call     0x68fd30
00691e48: c7400401000000 mov      dword ptr [eax + 4], 1
00691e4f: 8b1f         mov      ebx, dword ptr [edi]
00691e51: e82af72c00   call     0x961580
00691e56: 68e0818d01   push     0x18d81e0
00691e5b: 8bf0         mov      esi, eax
00691e5d: e88eca1d00   call     0x86e8f0
00691e62: 83c404       add      esp, 4
00691e65: 8bce         mov      ecx, esi
00691e67: 50           push     eax
00691e68: e893f5ffff   call     0x691400
00691e6d: 85c0         test     eax, eax
00691e6f: 741b         je       0x691e8c
00691e71: 8b00         mov      eax, dword ptr [eax]
00691e73: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691e76: 85c0         test     eax, eax
00691e78: 7412         je       0x691e8c
00691e7a: 8d45ec       lea      eax, [ebp - 0x14]
00691e7d: 8bcb         mov      ecx, ebx
00691e7f: 50           push     eax
00691e80: e8abdeffff   call     0x68fd30
00691e85: c7400401000000 mov      dword ptr [eax + 4], 1
00691e8c: 8b1f         mov      ebx, dword ptr [edi]
00691e8e: e8edf62c00   call     0x961580
00691e93: 6804828d01   push     0x18d8204
00691e98: 8bf0         mov      esi, eax
00691e9a: e851ca1d00   call     0x86e8f0
00691e9f: 83c404       add      esp, 4
00691ea2: 8bce         mov      ecx, esi
00691ea4: 50           push     eax
00691ea5: e856f5ffff   call     0x691400
00691eaa: 85c0         test     eax, eax
00691eac: 741b         je       0x691ec9
00691eae: 8b00         mov      eax, dword ptr [eax]
00691eb0: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691eb3: 85c0         test     eax, eax
00691eb5: 7412         je       0x691ec9
00691eb7: 8d45ec       lea      eax, [ebp - 0x14]
00691eba: 8bcb         mov      ecx, ebx

; === 076 | 0x691e56 | RequestCloudEditImmediatePublish ===
00691e56: 68e0818d01   push     0x18d81e0
00691e5b: 8bf0         mov      esi, eax
00691e5d: e88eca1d00   call     0x86e8f0
00691e62: 83c404       add      esp, 4
00691e65: 8bce         mov      ecx, esi
00691e67: 50           push     eax
00691e68: e893f5ffff   call     0x691400
00691e6d: 85c0         test     eax, eax
00691e6f: 741b         je       0x691e8c
00691e71: 8b00         mov      eax, dword ptr [eax]
00691e73: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691e76: 85c0         test     eax, eax
00691e78: 7412         je       0x691e8c
00691e7a: 8d45ec       lea      eax, [ebp - 0x14]
00691e7d: 8bcb         mov      ecx, ebx
00691e7f: 50           push     eax
00691e80: e8abdeffff   call     0x68fd30
00691e85: c7400401000000 mov      dword ptr [eax + 4], 1
00691e8c: 8b1f         mov      ebx, dword ptr [edi]
00691e8e: e8edf62c00   call     0x961580
00691e93: 6804828d01   push     0x18d8204
00691e98: 8bf0         mov      esi, eax
00691e9a: e851ca1d00   call     0x86e8f0
00691e9f: 83c404       add      esp, 4
00691ea2: 8bce         mov      ecx, esi
00691ea4: 50           push     eax
00691ea5: e856f5ffff   call     0x691400
00691eaa: 85c0         test     eax, eax
00691eac: 741b         je       0x691ec9
00691eae: 8b00         mov      eax, dword ptr [eax]
00691eb0: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691eb3: 85c0         test     eax, eax
00691eb5: 7412         je       0x691ec9
00691eb7: 8d45ec       lea      eax, [ebp - 0x14]
00691eba: 8bcb         mov      ecx, ebx
00691ebc: 50           push     eax
00691ebd: e86edeffff   call     0x68fd30
00691ec2: c7400401000000 mov      dword ptr [eax + 4], 1
00691ec9: 8b1f         mov      ebx, dword ptr [edi]
00691ecb: e8b0f62c00   call     0x961580
00691ed0: 6824828d01   push     0x18d8224
00691ed5: 8bf0         mov      esi, eax
00691ed7: e814ca1d00   call     0x86e8f0
00691edc: 83c404       add      esp, 4
00691edf: 8bce         mov      ecx, esi
00691ee1: 50           push     eax
00691ee2: e819f5ffff   call     0x691400
00691ee7: 85c0         test     eax, eax
00691ee9: 741b         je       0x691f06
00691eeb: 8b00         mov      eax, dword ptr [eax]
00691eed: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691ef0: 85c0         test     eax, eax
00691ef2: 7412         je       0x691f06
00691ef4: 8d45ec       lea      eax, [ebp - 0x14]
00691ef7: 8bcb         mov      ecx, ebx

; === 077 | 0x691e93 | RequestTeamCreateImmediateSave ===
00691e93: 6804828d01   push     0x18d8204
00691e98: 8bf0         mov      esi, eax
00691e9a: e851ca1d00   call     0x86e8f0
00691e9f: 83c404       add      esp, 4
00691ea2: 8bce         mov      ecx, esi
00691ea4: 50           push     eax
00691ea5: e856f5ffff   call     0x691400
00691eaa: 85c0         test     eax, eax
00691eac: 741b         je       0x691ec9
00691eae: 8b00         mov      eax, dword ptr [eax]
00691eb0: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691eb3: 85c0         test     eax, eax
00691eb5: 7412         je       0x691ec9
00691eb7: 8d45ec       lea      eax, [ebp - 0x14]
00691eba: 8bcb         mov      ecx, ebx
00691ebc: 50           push     eax
00691ebd: e86edeffff   call     0x68fd30
00691ec2: c7400401000000 mov      dword ptr [eax + 4], 1
00691ec9: 8b1f         mov      ebx, dword ptr [edi]
00691ecb: e8b0f62c00   call     0x961580
00691ed0: 6824828d01   push     0x18d8224
00691ed5: 8bf0         mov      esi, eax
00691ed7: e814ca1d00   call     0x86e8f0
00691edc: 83c404       add      esp, 4
00691edf: 8bce         mov      ecx, esi
00691ee1: 50           push     eax
00691ee2: e819f5ffff   call     0x691400
00691ee7: 85c0         test     eax, eax
00691ee9: 741b         je       0x691f06
00691eeb: 8b00         mov      eax, dword ptr [eax]
00691eed: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691ef0: 85c0         test     eax, eax
00691ef2: 7412         je       0x691f06
00691ef4: 8d45ec       lea      eax, [ebp - 0x14]
00691ef7: 8bcb         mov      ecx, ebx
00691ef9: 50           push     eax
00691efa: e831deffff   call     0x68fd30
00691eff: c7400401000000 mov      dword ptr [eax + 4], 1
00691f06: 8b1f         mov      ebx, dword ptr [edi]
00691f08: e873f62c00   call     0x961580
00691f0d: 683c828d01   push     0x18d823c
00691f12: 8bf0         mov      esi, eax
00691f14: e8d7c91d00   call     0x86e8f0
00691f19: 83c404       add      esp, 4
00691f1c: 8bce         mov      ecx, esi
00691f1e: 50           push     eax
00691f1f: e8dcf4ffff   call     0x691400
00691f24: 85c0         test     eax, eax
00691f26: 741b         je       0x691f43
00691f28: 8b00         mov      eax, dword ptr [eax]
00691f2a: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691f2d: 85c0         test     eax, eax
00691f2f: 7412         je       0x691f43
00691f31: 8d45ec       lea      eax, [ebp - 0x14]
00691f34: 8bcb         mov      ecx, ebx

; === 078 | 0x691ed0 | CloudEditServerMessage ===
00691ed0: 6824828d01   push     0x18d8224
00691ed5: 8bf0         mov      esi, eax
00691ed7: e814ca1d00   call     0x86e8f0
00691edc: 83c404       add      esp, 4
00691edf: 8bce         mov      ecx, esi
00691ee1: 50           push     eax
00691ee2: e819f5ffff   call     0x691400
00691ee7: 85c0         test     eax, eax
00691ee9: 741b         je       0x691f06
00691eeb: 8b00         mov      eax, dword ptr [eax]
00691eed: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691ef0: 85c0         test     eax, eax
00691ef2: 7412         je       0x691f06
00691ef4: 8d45ec       lea      eax, [ebp - 0x14]
00691ef7: 8bcb         mov      ecx, ebx
00691ef9: 50           push     eax
00691efa: e831deffff   call     0x68fd30
00691eff: c7400401000000 mov      dword ptr [eax + 4], 1
00691f06: 8b1f         mov      ebx, dword ptr [edi]
00691f08: e873f62c00   call     0x961580
00691f0d: 683c828d01   push     0x18d823c
00691f12: 8bf0         mov      esi, eax
00691f14: e8d7c91d00   call     0x86e8f0
00691f19: 83c404       add      esp, 4
00691f1c: 8bce         mov      ecx, esi
00691f1e: 50           push     eax
00691f1f: e8dcf4ffff   call     0x691400
00691f24: 85c0         test     eax, eax
00691f26: 741b         je       0x691f43
00691f28: 8b00         mov      eax, dword ptr [eax]
00691f2a: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691f2d: 85c0         test     eax, eax
00691f2f: 7412         je       0x691f43
00691f31: 8d45ec       lea      eax, [ebp - 0x14]
00691f34: 8bcb         mov      ecx, ebx
00691f36: 50           push     eax
00691f37: e8f4ddffff   call     0x68fd30
00691f3c: c7400401000000 mov      dword ptr [eax + 4], 1
00691f43: 8b1f         mov      ebx, dword ptr [edi]
00691f45: e836f62c00   call     0x961580
00691f4a: 6858828d01   push     0x18d8258
00691f4f: 8bf0         mov      esi, eax
00691f51: e89ac91d00   call     0x86e8f0
00691f56: 83c404       add      esp, 4
00691f59: 8bce         mov      ecx, esi
00691f5b: 50           push     eax
00691f5c: e89ff4ffff   call     0x691400
00691f61: 85c0         test     eax, eax
00691f63: 741b         je       0x691f80
00691f65: 8b00         mov      eax, dword ptr [eax]
00691f67: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691f6a: 85c0         test     eax, eax
00691f6c: 7412         je       0x691f80
00691f6e: 8d45ec       lea      eax, [ebp - 0x14]
00691f71: 8bcb         mov      ecx, ebx

; === 079 | 0x691f0d | CloudEditApplyEditsMessage ===
00691f0d: 683c828d01   push     0x18d823c
00691f12: 8bf0         mov      esi, eax
00691f14: e8d7c91d00   call     0x86e8f0
00691f19: 83c404       add      esp, 4
00691f1c: 8bce         mov      ecx, esi
00691f1e: 50           push     eax
00691f1f: e8dcf4ffff   call     0x691400
00691f24: 85c0         test     eax, eax
00691f26: 741b         je       0x691f43
00691f28: 8b00         mov      eax, dword ptr [eax]
00691f2a: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691f2d: 85c0         test     eax, eax
00691f2f: 7412         je       0x691f43
00691f31: 8d45ec       lea      eax, [ebp - 0x14]
00691f34: 8bcb         mov      ecx, ebx
00691f36: 50           push     eax
00691f37: e8f4ddffff   call     0x68fd30
00691f3c: c7400401000000 mov      dword ptr [eax + 4], 1
00691f43: 8b1f         mov      ebx, dword ptr [edi]
00691f45: e836f62c00   call     0x961580
00691f4a: 6858828d01   push     0x18d8258
00691f4f: 8bf0         mov      esi, eax
00691f51: e89ac91d00   call     0x86e8f0
00691f56: 83c404       add      esp, 4
00691f59: 8bce         mov      ecx, esi
00691f5b: 50           push     eax
00691f5c: e89ff4ffff   call     0x691400
00691f61: 85c0         test     eax, eax
00691f63: 741b         je       0x691f80
00691f65: 8b00         mov      eax, dword ptr [eax]
00691f67: 8945ec       mov      dword ptr [ebp - 0x14], eax
00691f6a: 85c0         test     eax, eax
00691f6c: 7412         je       0x691f80
00691f6e: 8d45ec       lea      eax, [ebp - 0x14]
00691f71: 8bcb         mov      ecx, ebx
00691f73: 50           push     eax
00691f74: e8b7ddffff   call     0x68fd30
00691f79: c7400401000000 mov      dword ptr [eax + 4], 1
00691f80: 803dd056d60100 cmp      byte ptr [0x1d656d0], 0
00691f87: 0f84fc000000 je       0x692089
00691f8d: 8b1f         mov      ebx, dword ptr [edi]
00691f8f: e8acd63500   call     0x9ef640
00691f94: 6870828d01   push     0x18d8270
00691f99: 8bf0         mov      esi, eax
00691f9b: e850c91d00   call     0x86e8f0
00691fa0: 83c404       add      esp, 4
00691fa3: 8bce         mov      ecx, esi
00691fa5: 50           push     eax
00691fa6: e855f4ffff   call     0x691400
00691fab: 85c0         test     eax, eax
00691fad: 741b         je       0x691fca

; === 080 | 0x692d6c | CloudEditSelectionChanged ===
00692d6c: 68e4878d01   push     0x18d87e4
00692d71: 8bf0         mov      esi, eax
00692d73: e878bb1d00   call     0x86e8f0
00692d78: 83c404       add      esp, 4
00692d7b: 8bce         mov      ecx, esi
00692d7d: 50           push     eax
00692d7e: e87de6ffff   call     0x691400
00692d83: 85c0         test     eax, eax
00692d85: 741b         je       0x692da2
00692d87: 8b00         mov      eax, dword ptr [eax]
00692d89: 8945ec       mov      dword ptr [ebp - 0x14], eax
00692d8c: 85c0         test     eax, eax
00692d8e: 7412         je       0x692da2
00692d90: 8d45ec       lea      eax, [ebp - 0x14]
00692d93: 8bcb         mov      ecx, ebx
00692d95: 50           push     eax
00692d96: e895cfffff   call     0x68fd30
00692d9b: c7400401000000 mov      dword ptr [eax + 4], 1
00692da2: 8b1f         mov      ebx, dword ptr [edi]
00692da4: e887082800   call     0x913630
00692da9: 6800888d01   push     0x18d8800
00692dae: 8bf0         mov      esi, eax
00692db0: e83bbb1d00   call     0x86e8f0
00692db5: 83c404       add      esp, 4
00692db8: 8bce         mov      ecx, esi
00692dba: 50           push     eax
00692dbb: e840e6ffff   call     0x691400
00692dc0: 85c0         test     eax, eax
00692dc2: 741b         je       0x692ddf
00692dc4: 8b00         mov      eax, dword ptr [eax]
00692dc6: 8945ec       mov      dword ptr [ebp - 0x14], eax
00692dc9: 85c0         test     eax, eax
00692dcb: 7412         je       0x692ddf
00692dcd: 8d45ec       lea      eax, [ebp - 0x14]
00692dd0: 8bcb         mov      ecx, ebx
00692dd2: 50           push     eax
00692dd3: e858cfffff   call     0x68fd30
00692dd8: c7400401000000 mov      dword ptr [eax + 4], 1
00692ddf: 8b1f         mov      ebx, dword ptr [edi]
00692de1: e84a082800   call     0x913630
00692de6: 6814888d01   push     0x18d8814
00692deb: 8bf0         mov      esi, eax
00692ded: e8feba1d00   call     0x86e8f0
00692df2: 83c404       add      esp, 4
00692df5: 8bce         mov      ecx, esi
00692df7: 50           push     eax
00692df8: e803e6ffff   call     0x691400
00692dfd: 85c0         test     eax, eax
00692dff: 741b         je       0x692e1c
00692e01: 8b00         mov      eax, dword ptr [eax]
00692e03: 8945ec       mov      dword ptr [ebp - 0x14], eax
00692e06: 85c0         test     eax, eax
00692e08: 7412         je       0x692e1c
00692e0a: 8d45ec       lea      eax, [ebp - 0x14]
00692e0d: 8bcb         mov      ecx, ebx

; === 081 | 0x693a56 | CloudEditCameraCoordinateFrame ===
00693a56: 68e47c8d01   push     0x18d7ce4
00693a5b: 8bf0         mov      esi, eax
00693a5d: e88eae1d00   call     0x86e8f0
00693a62: 83c404       add      esp, 4
00693a65: 8bce         mov      ecx, esi
00693a67: 50           push     eax
00693a68: e893d9ffff   call     0x691400
00693a6d: 85c0         test     eax, eax
00693a6f: 741b         je       0x693a8c
00693a71: 8b00         mov      eax, dword ptr [eax]
00693a73: 8945ec       mov      dword ptr [ebp - 0x14], eax
00693a76: 85c0         test     eax, eax
00693a78: 7412         je       0x693a8c
00693a7a: 8d45ec       lea      eax, [ebp - 0x14]
00693a7d: 8bcb         mov      ecx, ebx
00693a7f: 50           push     eax
00693a80: e8abc2ffff   call     0x68fd30
00693a85: c7400405000000 mov      dword ptr [eax + 4], 5
00693a8c: 8b1f         mov      ebx, dword ptr [edi]
00693a8e: e82dbe4600   call     0xaff8c0
00693a93: 68047d8d01   push     0x18d7d04
00693a98: 8bf0         mov      esi, eax
00693a9a: e851ae1d00   call     0x86e8f0
00693a9f: 83c404       add      esp, 4
00693aa2: 8bce         mov      ecx, esi
00693aa4: 50           push     eax
00693aa5: e856d9ffff   call     0x691400
00693aaa: 85c0         test     eax, eax
00693aac: 741b         je       0x693ac9
00693aae: 8b00         mov      eax, dword ptr [eax]
00693ab0: 8945ec       mov      dword ptr [ebp - 0x14], eax
00693ab3: 85c0         test     eax, eax
00693ab5: 7412         je       0x693ac9
00693ab7: 8d45ec       lea      eax, [ebp - 0x14]
00693aba: 8bcb         mov      ecx, ebx
00693abc: 50           push     eax
00693abd: e86ec2ffff   call     0x68fd30
00693ac2: c7400401000000 mov      dword ptr [eax + 4], 1
00693ac9: 8b1f         mov      ebx, dword ptr [edi]
00693acb: e8404f5d00   call     0xc68a10
00693ad0: 68187d8d01   push     0x18d7d18
00693ad5: 8bf0         mov      esi, eax
00693ad7: e814ae1d00   call     0x86e8f0
00693adc: 83c404       add      esp, 4
00693adf: 8bce         mov      ecx, esi
00693ae1: 50           push     eax
00693ae2: e819d9ffff   call     0x691400
00693ae7: 85c0         test     eax, eax
00693ae9: 741b         je       0x693b06
00693aeb: 8b00         mov      eax, dword ptr [eax]
00693aed: 8945ec       mov      dword ptr [ebp - 0x14], eax
00693af0: 85c0         test     eax, eax
00693af2: 7412         je       0x693b06
00693af4: 8d45ec       lea      eax, [ebp - 0x14]
00693af7: 8bcb         mov      ecx, ebx

; === 082 | 0x6f0386 | TeamCreate ===
006f0386: 680c858c01   push     0x18c850c
006f038b: c7411000000000 mov      dword ptr [ecx + 0x10], 0
006f0392: c741140f000000 mov      dword ptr [ecx + 0x14], 0xf
006f0399: c60100       mov      byte ptr [ecx], 0
006f039c: e81f3fe6ff   call     0x5542c0
006f03a1: 83ec18       sub      esp, 0x18
006f03a4: c645fc0c     mov      byte ptr [ebp - 4], 0xc
006f03a8: 8bcc         mov      ecx, esp
006f03aa: 6a06         push     6
006f03ac: c7411000000000 mov      dword ptr [ecx + 0x10], 0
006f03b3: c741140f000000 mov      dword ptr [ecx + 0x14], 0xf
006f03ba: 684c258d01   push     0x18d254c
006f03bf: c60100       mov      byte ptr [ecx], 0
006f03c2: e8f93ee6ff   call     0x5542c0
006f03c7: c645fc01     mov      byte ptr [ebp - 4], 1
006f03cb: e870a11800   call     0x87a540
006f03d0: 83c460       add      esp, 0x60
006f03d3: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
006f03da: 8d4dcc       lea      ecx, [ebp - 0x34]
006f03dd: e8eecbe7ff   call     0x56cfd0
006f03e2: 8b8fb41d0000 mov      ecx, dword ptr [edi + 0x1db4]
006f03e8: e8f3d9feff   call     0x6ddde0
006f03ed: 53           push     ebx
006f03ee: ff7508       push     dword ptr [ebp + 8]
006f03f1: 8bcf         mov      ecx, edi
006f03f3: e8b825f3ff   call     0x6229b0
006f03f8: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
006f03fb: 5f           pop      edi
006f03fc: 5e           pop      esi
006f03fd: 64890d00000000 mov      dword ptr fs:[0], ecx
006f0404: 5b           pop      ebx
006f0405: 8be5         mov      esp, ebp
006f0407: 5d           pop      ebp
006f0408: c20800       ret      8
006f040b: cc           int3     
006f040c: cc           int3     
006f040d: cc           int3     
006f040e: cc           int3     
006f040f: cc           int3     
006f0410: 55           push     ebp
006f0411: 8bec         mov      ebp, esp
006f0413: 6aff         push     -1
006f0415: 6891a27a01   push     0x17aa291
006f041a: 64a100000000 mov      eax, dword ptr fs:[0]
006f0420: 50           push     eax
006f0421: 64892500000000 mov      dword ptr fs:[0], esp
006f0428: 83ec58       sub      esp, 0x58

; === 083 | 0x98b30f | TeamCreate ===
0098b30f: 680c858c01   push     0x18c850c
0098b314: 8d4da8       lea      ecx, [ebp - 0x58]
0098b317: c745b800000000 mov      dword ptr [ebp - 0x48], 0
0098b31e: c745bc0f000000 mov      dword ptr [ebp - 0x44], 0xf
0098b325: c645a800     mov      byte ptr [ebp - 0x58], 0
0098b329: e8928fbcff   call     0x5542c0
0098b32e: 6a03         push     3
0098b330: 689cde8b01   push     0x18bde9c
0098b335: 8d4dc0       lea      ecx, [ebp - 0x40]
0098b338: c645fc08     mov      byte ptr [ebp - 4], 8
0098b33c: c745d000000000 mov      dword ptr [ebp - 0x30], 0
0098b343: c745d40f000000 mov      dword ptr [ebp - 0x2c], 0xf
0098b34a: c645c000     mov      byte ptr [ebp - 0x40], 0
0098b34e: e86d8fbcff   call     0x5542c0
0098b353: 8d45d8       lea      eax, [ebp - 0x28]
0098b356: c645fc09     mov      byte ptr [ebp - 4], 9
0098b35a: 50           push     eax
0098b35b: 8d4510       lea      eax, [ebp + 0x10]
0098b35e: 50           push     eax
0098b35f: 8d45a8       lea      eax, [ebp - 0x58]
0098b362: 50           push     eax
0098b363: 8d45c0       lea      eax, [ebp - 0x40]
0098b366: 50           push     eax
0098b367: e814e2eeff   call     0x879580
0098b36c: 8b55d4       mov      edx, dword ptr [ebp - 0x2c]
0098b36f: 83c410       add      esp, 0x10
0098b372: 83fa10       cmp      edx, 0x10
0098b375: 722c         jb       0x98b3a3
0098b377: 8b4dc0       mov      ecx, dword ptr [ebp - 0x40]
0098b37a: 42           inc      edx
0098b37b: 8bc1         mov      eax, ecx
0098b37d: 81fa00100000 cmp      edx, 0x1000
0098b383: 7214         jb       0x98b399
0098b385: 8b49fc       mov      ecx, dword ptr [ecx - 4]
0098b388: 83c223       add      edx, 0x23
0098b38b: 2bc1         sub      eax, ecx
0098b38d: 83c0fc       add      eax, -4
0098b390: 83f81f       cmp      eax, 0x1f
0098b393: 0f87b2000000 ja       0x98b44b
0098b399: 52           push     edx
0098b39a: 51           push     ecx
0098b39b: e8009bce00   call     0x1674ea0
0098b3a0: 83c408       add      esp, 8
0098b3a3: 8b55bc       mov      edx, dword ptr [ebp - 0x44]
0098b3a6: c745d000000000 mov      dword ptr [ebp - 0x30], 0
0098b3ad: c745d40f000000 mov      dword ptr [ebp - 0x2c], 0xf
0098b3b4: c645c000     mov      byte ptr [ebp - 0x40], 0

; === 084 | 0x9f70ab | Studio.TeamCreate.CollabEdit. ===
009f70ab: 6818d69301   push     0x193d618
009f70b0: 885d08       mov      byte ptr [ebp + 8], bl
009f70b3: c745d800000000 mov      dword ptr [ebp - 0x28], 0
009f70ba: c745dc0f000000 mov      dword ptr [ebp - 0x24], 0xf
009f70c1: c645c800     mov      byte ptr [ebp - 0x38], 0
009f70c5: e8f6d1b5ff   call     0x5542c0
009f70ca: 84db         test     bl, bl
009f70cc: c745fc03000000 mov      dword ptr [ebp - 4], 3
009f70d3: b858f69101   mov      eax, 0x191f658
009f70d8: bea0f69101   mov      esi, 0x191f6a0
009f70dd: 0f44f0       cmove    esi, eax
009f70e0: 8d45c8       lea      eax, [ebp - 0x38]
009f70e3: 56           push     esi
009f70e4: 50           push     eax
009f70e5: 8d4598       lea      eax, [ebp - 0x68]
009f70e8: 50           push     eax
009f70e9: e8921bb6ff   call     0x558c80
009f70ee: 6a00         push     0
009f70f0: 6a01         push     1
009f70f2: 50           push     eax
009f70f3: c645fc04     mov      byte ptr [ebp - 4], 4
009f70f7: e8f412e8ff   call     0x8783f0
009f70fc: 83c418       add      esp, 0x18
009f70ff: 8d4d98       lea      ecx, [ebp - 0x68]
009f7102: e8a996b5ff   call     0x5507b0
009f7107: 8d4dc8       lea      ecx, [ebp - 0x38]
009f710a: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
009f7111: e89a96b5ff   call     0x5507b0
009f7116: 6a00         push     0
009f7118: 6a00         push     0
009f711a: 6a01         push     1
009f711c: 56           push     esi
009f711d: 6838d69301   push     0x193d638
009f7122: 6844848c01   push     0x18c8444
009f7127: e82453e8ff   call     0x87c450
009f712c: 83c418       add      esp, 0x18
009f712f: 8bcf         mov      ecx, edi
009f7131: ff7508       push     dword ptr [ebp + 8]
009f7134: e8873b0000   call     0x9facc0
009f7139: 8b750c       mov      esi, dword ptr [ebp + 0xc]
009f713c: eb10         jmp      0x9f714e
009f713e: 8a4068       mov      al, byte ptr [eax + 0x68]
009f7141: 8bcf         mov      ecx, edi
009f7143: 88450c       mov      byte ptr [ebp + 0xc], al
009f7146: ff750c       push     dword ptr [ebp + 0xc]
009f7149: e8723b0000   call     0x9facc0
009f714e: 803d1057d60100 cmp      byte ptr [0x1d65710], 0

; === 085 | 0x9f729f | Studio.TeamCreate.CollabEditVersionHistory. ===
009f729f: 6844d69301   push     0x193d644
009f72a4: 8d4db0       lea      ecx, [ebp - 0x50]
009f72a7: c745c000000000 mov      dword ptr [ebp - 0x40], 0
009f72ae: c745c40f000000 mov      dword ptr [ebp - 0x3c], 0xf
009f72b5: c645b000     mov      byte ptr [ebp - 0x50], 0
009f72b9: e802d0b5ff   call     0x5542c0
009f72be: 8a5d0c       mov      bl, byte ptr [ebp + 0xc]
009f72c1: b858f69101   mov      eax, 0x191f658
009f72c6: 84db         test     bl, bl
009f72c8: c745fc08000000 mov      dword ptr [ebp - 4], 8
009f72cf: bea0f69101   mov      esi, 0x191f6a0
009f72d4: 0f44f0       cmove    esi, eax
009f72d7: 8d45b0       lea      eax, [ebp - 0x50]
009f72da: 56           push     esi
009f72db: 50           push     eax
009f72dc: 8d4580       lea      eax, [ebp - 0x80]
009f72df: 50           push     eax
009f72e0: e89b19b6ff   call     0x558c80
009f72e5: 6a00         push     0
009f72e7: 6a01         push     1
009f72e9: 50           push     eax
009f72ea: c645fc09     mov      byte ptr [ebp - 4], 9
009f72ee: e8fd10e8ff   call     0x8783f0
009f72f3: 83c418       add      esp, 0x18
009f72f6: 8d4d80       lea      ecx, [ebp - 0x80]
009f72f9: e8b294b5ff   call     0x5507b0
009f72fe: 8d4db0       lea      ecx, [ebp - 0x50]
009f7301: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
009f7308: e8a394b5ff   call     0x5507b0
009f730d: 6a00         push     0
009f730f: 6a00         push     0
009f7311: 6a01         push     1
009f7313: 56           push     esi
009f7314: 6870d69301   push     0x193d670
009f7319: 6844848c01   push     0x18c8444
009f731e: e82d51e8ff   call     0x87c450
009f7323: 83c418       add      esp, 0x18
009f7326: 8bcf         mov      ecx, edi
009f7328: ff750c       push     dword ptr [ebp + 0xc]
009f732b: e8c0390000   call     0x9facf0
009f7330: 803d505ad60100 cmp      byte ptr [0x1d65a50], 0
009f7337: 750b         jne      0x9f7344
009f7339: 84db         test     bl, bl
009f733b: 7407         je       0x9f7344
009f733d: 8bcf         mov      ecx, edi
009f733f: e8dcadffff   call     0x9f2120

; === 086 | 0xa052dc | Studio.TeamCreate.CollabEditVersionHistory.PlaceChangesFailed ===
00a052dc: 6868f19301   push     0x193f168
00a052e1: e8daefb4ff   call     0x5542c0
00a052e6: 6a00         push     0
00a052e8: 8d45cc       lea      eax, [ebp - 0x34]
00a052eb: c645fc02     mov      byte ptr [ebp - 4], 2
00a052ef: 6a01         push     1
00a052f1: 50           push     eax
00a052f2: e8f930e7ff   call     0x8783f0
00a052f7: 83c40c       add      esp, 0xc
00a052fa: 8d4dcc       lea      ecx, [ebp - 0x34]
00a052fd: c645fc00     mov      byte ptr [ebp - 4], 0
00a05301: e8aab4b4ff   call     0x5507b0
00a05306: 6a00         push     0
00a05308: 6a00         push     0
00a0530a: 6a01         push     1
00a0530c: 6854f19301   push     0x193f154
00a05311: 6870d69301   push     0x193d670
00a05316: 6844848c01   push     0x18c8444
00a0531b: e83071e7ff   call     0x87c450
00a05320: 8b75ec       mov      esi, dword ptr [ebp - 0x14]
00a05323: 83c418       add      esp, 0x18
00a05326: 803d405ad60100 cmp      byte ptr [0x1d65a40], 0
00a0532d: 7409         je       0xa05338
00a0532f: 80be8d00000000 cmp      byte ptr [esi + 0x8d], 0
00a05336: 7438         je       0xa05370
00a05338: 83ec08       sub      esp, 8
00a0533b: 8d4e18       lea      ecx, [esi + 0x18]
00a0533e: 8bd4         mov      edx, esp
00a05340: c70200000000 mov      dword ptr [edx], 0
00a05346: c7420400000000 mov      dword ptr [edx + 4], 0
00a0534d: 8b45f0       mov      eax, dword ptr [ebp - 0x10]
00a05350: 85c0         test     eax, eax
00a05352: 7404         je       0xa05358
00a05354: f0ff4004     lock inc dword ptr [eax + 4]
00a05358: 8b45ec       mov      eax, dword ptr [ebp - 0x14]
00a0535b: 8902         mov      dword ptr [edx], eax
00a0535d: 8b45f0       mov      eax, dword ptr [ebp - 0x10]
00a05360: 894204       mov      dword ptr [edx + 4], eax
00a05363: e818160000   call     0xa06980
00a05368: e92f010000   jmp      0xa0549c
00a0536d: 8b75ec       mov      esi, dword ptr [ebp - 0x14]
00a05370: 8d45e4       lea      eax, [ebp - 0x1c]
00a05373: 50           push     eax
00a05374: e877ddc700   call     0x16830f0
00a05379: 83c404       add      esp, 4
00a0537c: c745dc00000000 mov      dword ptr [ebp - 0x24], 0

; === 087 | 0xa0611d | Studio.TeamCreate.CollabEditVersionHistory.CommitFinalized ===
00a0611d: 689cf09301   push     0x193f09c
00a06122: e899e1b4ff   call     0x5542c0
00a06127: 6a00         push     0
00a06129: 8d45c0       lea      eax, [ebp - 0x40]
00a0612c: c645fc08     mov      byte ptr [ebp - 4], 8
00a06130: 6a01         push     1
00a06132: 50           push     eax
00a06133: e8b822e7ff   call     0x8783f0
00a06138: 83c40c       add      esp, 0xc
00a0613b: c645fc00     mov      byte ptr [ebp - 4], 0
00a0613f: 8d4dc0       lea      ecx, [ebp - 0x40]
00a06142: e869a6b4ff   call     0x5507b0
00a06147: 6a00         push     0
00a06149: 6a00         push     0
00a0614b: 6a01         push     1
00a0614d: 688cf09301   push     0x193f08c
00a06152: 6870d69301   push     0x193d670
00a06157: 6844848c01   push     0x18c8444
00a0615c: e8ef62e7ff   call     0x87c450
00a06161: 83c418       add      esp, 0x18
00a06164: 8b75ec       mov      esi, dword ptr [ebp - 0x14]
00a06167: 85f6         test     esi, esi
00a06169: 7421         je       0xa0618c
00a0616b: 83cfff       or       edi, 0xffffffff
00a0616e: 8bc7         mov      eax, edi
00a06170: f00fc14604   lock xadd dword ptr [esi + 4], eax
00a06175: 7515         jne      0xa0618c
00a06177: 8b06         mov      eax, dword ptr [esi]
00a06179: 8bce         mov      ecx, esi
00a0617b: ff10         call     dword ptr [eax]
00a0617d: f00fc17e08   lock xadd dword ptr [esi + 8], edi
00a06182: 4f           dec      edi
00a06183: 7507         jne      0xa0618c
00a06185: 8b06         mov      eax, dword ptr [esi]
00a06187: 8bce         mov      ecx, esi
00a06189: ff5004       call     dword ptr [eax + 4]
00a0618c: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00a0618f: 5f           pop      edi
00a06190: 5e           pop      esi
00a06191: 5b           pop      ebx
00a06192: 64890d00000000 mov      dword ptr fs:[0], ecx
00a06199: 8be5         mov      esp, ebp
00a0619b: 5d           pop      ebp
00a0619c: c20400       ret      4
00a0619f: cc           int3     
00a061a0: 55           push     ebp
00a061a1: 8bec         mov      ebp, esp
00a061a3: 6aff         push     -1
00a061a5: 68f8a47d01   push     0x17da4f8
00a061aa: 64a100000000 mov      eax, dword ptr fs:[0]
00a061b0: 50           push     eax
00a061b1: 64892500000000 mov      dword ptr fs:[0], esp
00a061b8: 83ec28       sub      esp, 0x28
00a061bb: 56           push     esi
00a061bc: 57           push     edi
00a061bd: 51           push     ecx

; === 088 | 0xa063c8 | Studio.TeamCreate.CollabEditVersionHistory.CommitFinalized ===
00a063c8: 689cf09301   push     0x193f09c
00a063cd: e8eedeb4ff   call     0x5542c0
00a063d2: 6a00         push     0
00a063d4: 8d45cc       lea      eax, [ebp - 0x34]
00a063d7: c645fc06     mov      byte ptr [ebp - 4], 6
00a063db: 6a01         push     1
00a063dd: 50           push     eax
00a063de: e80d20e7ff   call     0x8783f0
00a063e3: 83c40c       add      esp, 0xc
00a063e6: c645fc00     mov      byte ptr [ebp - 4], 0
00a063ea: 8d4dcc       lea      ecx, [ebp - 0x34]
00a063ed: e8bea3b4ff   call     0x5507b0
00a063f2: 6a00         push     0
00a063f4: 6a00         push     0
00a063f6: 6a01         push     1
00a063f8: 688cf09301   push     0x193f08c
00a063fd: 6870d69301   push     0x193d670
00a06402: 6844848c01   push     0x18c8444
00a06407: e84460e7ff   call     0x87c450
00a0640c: 83c418       add      esp, 0x18
00a0640f: 5b           pop      ebx
00a06410: 8b75e8       mov      esi, dword ptr [ebp - 0x18]
00a06413: 85f6         test     esi, esi
00a06415: 7421         je       0xa06438
00a06417: 83cfff       or       edi, 0xffffffff
00a0641a: 8bc7         mov      eax, edi
00a0641c: f00fc14604   lock xadd dword ptr [esi + 4], eax
00a06421: 7515         jne      0xa06438
00a06423: 8b06         mov      eax, dword ptr [esi]
00a06425: 8bce         mov      ecx, esi
00a06427: ff10         call     dword ptr [eax]
00a06429: f00fc17e08   lock xadd dword ptr [esi + 8], edi
00a0642e: 4f           dec      edi
00a0642f: 7507         jne      0xa06438
00a06431: 8b06         mov      eax, dword ptr [esi]
00a06433: 8bce         mov      ecx, esi
00a06435: ff5004       call     dword ptr [eax + 4]
00a06438: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00a0643b: 5f           pop      edi
00a0643c: 5e           pop      esi
00a0643d: 64890d00000000 mov      dword ptr fs:[0], ecx
00a06444: 8be5         mov      esp, ebp
00a06446: 5d           pop      ebp
00a06447: c20400       ret      4
00a0644a: cc           int3     
00a0644b: cc           int3     
00a0644c: cc           int3     
00a0644d: cc           int3     
00a0644e: cc           int3     
00a0644f: cc           int3     
00a06450: 55           push     ebp
00a06451: 8bec         mov      ebp, esp
00a06453: 6aff         push     -1
00a06455: 6858a57d01   push     0x17da558
00a0645a: 64a100000000 mov      eax, dword ptr fs:[0]
00a06460: 50           push     eax
00a06461: 64892500000000 mov      dword ptr fs:[0], esp
00a06468: 83ec54       sub      esp, 0x54

; === 089 | 0xa06b4b | Studio.TeamCreate.CollabEditVersionHistory.CommitRecoveryAttempt ===
00a06b4b: 68b8e99301   push     0x193e9b8
00a06b50: 8d4dd4       lea      ecx, [ebp - 0x2c]
00a06b53: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
00a06b5a: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
00a06b61: c645d400     mov      byte ptr [ebp - 0x2c], 0
00a06b65: e856d7b4ff   call     0x5542c0
00a06b6a: 6a00         push     0
00a06b6c: 8d45d4       lea      eax, [ebp - 0x2c]
00a06b6f: c745fc01000000 mov      dword ptr [ebp - 4], 1
00a06b76: 6a01         push     1
00a06b78: 50           push     eax
00a06b79: e87218e7ff   call     0x8783f0
00a06b7e: 8b55e8       mov      edx, dword ptr [ebp - 0x18]
00a06b81: 83c40c       add      esp, 0xc
00a06b84: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
00a06b8b: 83fa10       cmp      edx, 0x10
00a06b8e: 7228         jb       0xa06bb8
00a06b90: 8b4dd4       mov      ecx, dword ptr [ebp - 0x2c]
00a06b93: 42           inc      edx
00a06b94: 8bc1         mov      eax, ecx
00a06b96: 81fa00100000 cmp      edx, 0x1000
00a06b9c: 7210         jb       0xa06bae
00a06b9e: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00a06ba1: 83c223       add      edx, 0x23
00a06ba4: 2bc1         sub      eax, ecx
00a06ba6: 83c0fc       add      eax, -4
00a06ba9: 83f81f       cmp      eax, 0x1f
00a06bac: 7754         ja       0xa06c02
00a06bae: 52           push     edx
00a06baf: 51           push     ecx
00a06bb0: e8ebe2c600   call     0x1674ea0
00a06bb5: 83c408       add      esp, 8
00a06bb8: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
00a06bbf: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
00a06bc6: c645d400     mov      byte ptr [ebp - 0x2c], 0
00a06bca: 6a00         push     0
00a06bcc: 6a00         push     0
00a06bce: 6a01         push     1
00a06bd0: 689ce99301   push     0x193e99c
00a06bd5: 6870d69301   push     0x193d670
00a06bda: 6844848c01   push     0x18c8444
00a06bdf: e86c58e7ff   call     0x87c450
00a06be4: 83c418       add      esp, 0x18
00a06be7: 8bce         mov      ecx, esi
00a06be9: e842080000   call     0xa07430
00a06bee: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]

; === 090 | 0xa0b4cb | Studio.TeamCreate.CollabEditVersionHistory.CommitAttempt ===
00a0b4cb: 6860e99301   push     0x193e960
00a0b4d0: 8d4dd4       lea      ecx, [ebp - 0x2c]
00a0b4d3: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
00a0b4da: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
00a0b4e1: c645d400     mov      byte ptr [ebp - 0x2c], 0
00a0b4e5: e8d68db4ff   call     0x5542c0
00a0b4ea: 6a00         push     0
00a0b4ec: 8d45d4       lea      eax, [ebp - 0x2c]
00a0b4ef: c745fc01000000 mov      dword ptr [ebp - 4], 1
00a0b4f6: 6a01         push     1
00a0b4f8: 50           push     eax
00a0b4f9: e8f2cee6ff   call     0x8783f0
00a0b4fe: 8b55e8       mov      edx, dword ptr [ebp - 0x18]
00a0b501: 83c40c       add      esp, 0xc
00a0b504: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
00a0b50b: 83fa10       cmp      edx, 0x10
00a0b50e: 7228         jb       0xa0b538
00a0b510: 8b4dd4       mov      ecx, dword ptr [ebp - 0x2c]
00a0b513: 42           inc      edx
00a0b514: 8bc1         mov      eax, ecx
00a0b516: 81fa00100000 cmp      edx, 0x1000
00a0b51c: 7210         jb       0xa0b52e
00a0b51e: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00a0b521: 83c223       add      edx, 0x23
00a0b524: 2bc1         sub      eax, ecx
00a0b526: 83c0fc       add      eax, -4
00a0b529: 83f81f       cmp      eax, 0x1f
00a0b52c: 7754         ja       0xa0b582
00a0b52e: 52           push     edx
00a0b52f: 51           push     ecx
00a0b530: e86b99c600   call     0x1674ea0
00a0b535: 83c408       add      esp, 8
00a0b538: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
00a0b53f: c745e80f000000 mov      dword ptr [ebp - 0x18], 0xf
00a0b546: c645d400     mov      byte ptr [ebp - 0x2c], 0
00a0b54a: 6a00         push     0
00a0b54c: 6a00         push     0
00a0b54e: 6a01         push     1
00a0b550: 6850e99301   push     0x193e950
00a0b555: 6870d69301   push     0x193d670
00a0b55a: 6844848c01   push     0x18c8444
00a0b55f: e8ec0ee7ff   call     0x87c450
00a0b564: 83c418       add      esp, 0x18
00a0b567: 8bce         mov      ecx, esi
00a0b569: e812dcffff   call     0xa09180
00a0b56e: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]

; === 091 | 0xa0b6dc | Studio.TeamCreate.CollabEditVersionHistory.CommitFinalizeFailed ===
00a0b6dc: 6888f39301   push     0x193f388
00a0b6e1: e8da8bb4ff   call     0x5542c0
00a0b6e6: 6a00         push     0
00a0b6e8: 8d45d4       lea      eax, [ebp - 0x2c]
00a0b6eb: c645fc02     mov      byte ptr [ebp - 4], 2
00a0b6ef: 6a01         push     1
00a0b6f1: 50           push     eax
00a0b6f2: e8f9cce6ff   call     0x8783f0
00a0b6f7: 83c40c       add      esp, 0xc
00a0b6fa: 8d4dd4       lea      ecx, [ebp - 0x2c]
00a0b6fd: c645fc00     mov      byte ptr [ebp - 4], 0
00a0b701: e8aa50b4ff   call     0x5507b0
00a0b706: 6a00         push     0
00a0b708: 6a00         push     0
00a0b70a: 6a01         push     1
00a0b70c: 686cf39301   push     0x193f36c
00a0b711: 6870d69301   push     0x193d670
00a0b716: 6844848c01   push     0x18c8444
00a0b71b: e8300de7ff   call     0x87c450
00a0b720: 83c418       add      esp, 0x18
00a0b723: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
00a0b726: 85f6         test     esi, esi
00a0b728: 7423         je       0xa0b74d
00a0b72a: 57           push     edi
00a0b72b: 83cfff       or       edi, 0xffffffff
00a0b72e: 8bc7         mov      eax, edi
00a0b730: f00fc14604   lock xadd dword ptr [esi + 4], eax
00a0b735: 7515         jne      0xa0b74c
00a0b737: 8b06         mov      eax, dword ptr [esi]
00a0b739: 8bce         mov      ecx, esi
00a0b73b: ff10         call     dword ptr [eax]
00a0b73d: f00fc17e08   lock xadd dword ptr [esi + 8], edi
00a0b742: 4f           dec      edi
00a0b743: 7507         jne      0xa0b74c
00a0b745: 8b06         mov      eax, dword ptr [esi]
00a0b747: 8bce         mov      ecx, esi
00a0b749: ff5004       call     dword ptr [eax + 4]
00a0b74c: 5f           pop      edi
00a0b74d: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00a0b750: 5e           pop      esi
00a0b751: 5b           pop      ebx
00a0b752: 64890d00000000 mov      dword ptr fs:[0], ecx
00a0b759: 8be5         mov      esp, ebp
00a0b75b: 5d           pop      ebp
00a0b75c: c3           ret      
00a0b75d: cc           int3     
00a0b75e: cc           int3     
00a0b75f: cc           int3     
00a0b760: 55           push     ebp
00a0b761: 8bec         mov      ebp, esp
00a0b763: 64a100000000 mov      eax, dword ptr fs:[0]
00a0b769: 8b4d0c       mov      ecx, dword ptr [ebp + 0xc]
00a0b76c: 6aff         push     -1
00a0b76e: 6868397901   push     0x1793968
00a0b773: 50           push     eax
00a0b774: 8b4508       mov      eax, dword ptr [ebp + 8]
00a0b777: 64892500000000 mov      dword ptr fs:[0], esp
00a0b77e: 83ec18       sub      esp, 0x18

; === 092 | 0xa0bd59 | Studio.TeamCreate.CollabEditVersionHistory.CommitRejected ===
00a0bd59: 680cea9301   push     0x193ea0c
00a0bd5e: e85d85b4ff   call     0x5542c0
00a0bd63: 6a00         push     0
00a0bd65: 8d45d4       lea      eax, [ebp - 0x2c]
00a0bd68: c645fc02     mov      byte ptr [ebp - 4], 2
00a0bd6c: 6a01         push     1
00a0bd6e: 50           push     eax
00a0bd6f: e87cc6e6ff   call     0x8783f0
00a0bd74: 83c40c       add      esp, 0xc
00a0bd77: 8d4dd4       lea      ecx, [ebp - 0x2c]
00a0bd7a: c645fc00     mov      byte ptr [ebp - 4], 0
00a0bd7e: e82d4ab4ff   call     0x5507b0
00a0bd83: 6a00         push     0
00a0bd85: 6a00         push     0
00a0bd87: 6a01         push     1
00a0bd89: 68fce99301   push     0x193e9fc
00a0bd8e: 6870d69301   push     0x193d670
00a0bd93: 6844848c01   push     0x18c8444
00a0bd98: e8b306e7ff   call     0x87c450
00a0bd9d: 83c418       add      esp, 0x18
00a0bda0: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
00a0bda3: 85f6         test     esi, esi
00a0bda5: 7423         je       0xa0bdca
00a0bda7: 57           push     edi
00a0bda8: 83cfff       or       edi, 0xffffffff
00a0bdab: 8bc7         mov      eax, edi
00a0bdad: f00fc14604   lock xadd dword ptr [esi + 4], eax
00a0bdb2: 7515         jne      0xa0bdc9
00a0bdb4: 8b06         mov      eax, dword ptr [esi]
00a0bdb6: 8bce         mov      ecx, esi
00a0bdb8: ff10         call     dword ptr [eax]
00a0bdba: f00fc17e08   lock xadd dword ptr [esi + 8], edi
00a0bdbf: 4f           dec      edi
00a0bdc0: 7507         jne      0xa0bdc9
00a0bdc2: 8b06         mov      eax, dword ptr [esi]
00a0bdc4: 8bce         mov      ecx, esi
00a0bdc6: ff5004       call     dword ptr [eax + 4]
00a0bdc9: 5f           pop      edi
00a0bdca: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00a0bdcd: 5e           pop      esi
00a0bdce: 5b           pop      ebx
00a0bdcf: 64890d00000000 mov      dword ptr fs:[0], ecx
00a0bdd6: 8be5         mov      esp, ebp
00a0bdd8: 5d           pop      ebp
00a0bdd9: c3           ret      
00a0bdda: cc           int3     
00a0bddb: cc           int3     
00a0bddc: cc           int3     
00a0bddd: cc           int3     
00a0bdde: cc           int3     
00a0bddf: cc           int3     
00a0bde0: 55           push     ebp
00a0bde1: 8bec         mov      ebp, esp
00a0bde3: 64a100000000 mov      eax, dword ptr fs:[0]
00a0bde9: 8b4d0c       mov      ecx, dword ptr [ebp + 0xc]
00a0bdec: 6aff         push     -1
00a0bdee: 6868397901   push     0x1793968
00a0bdf3: 50           push     eax
00a0bdf4: 64892500000000 mov      dword ptr fs:[0], esp
00a0bdfb: 8d410c       lea      eax, [ecx + 0xc]

; === 093 | 0xa1138f | Studio.TeamCreate.CollabEditVersionHistory. ===
00a1138f: ba44d69301   mov      edx, 0x193d644
00a11394: b8a4e79301   mov      eax, 0x193e7a4
00a11399: c745d400000000 mov      dword ptr [ebp - 0x2c], 0
00a113a0: 0f44d0       cmove    edx, eax
00a113a3: c745d80f000000 mov      dword ptr [ebp - 0x28], 0xf
00a113aa: 8bca         mov      ecx, edx
00a113ac: c645c400     mov      byte ptr [ebp - 0x3c], 0
00a113b0: 56           push     esi
00a113b1: 8d7101       lea      esi, [ecx + 1]
00a113b4: 8a01         mov      al, byte ptr [ecx]
00a113b6: 41           inc      ecx
00a113b7: 84c0         test     al, al
00a113b9: 75f9         jne      0xa113b4
00a113bb: 2bce         sub      ecx, esi
00a113bd: 51           push     ecx
00a113be: 52           push     edx
00a113bf: 8d4dc4       lea      ecx, [ebp - 0x3c]
00a113c2: e8f92eb4ff   call     0x5542c0
00a113c7: ff7508       push     dword ptr [ebp + 8]
00a113ca: 8d45c4       lea      eax, [ebp - 0x3c]
00a113cd: c745fc00000000 mov      dword ptr [ebp - 4], 0
00a113d4: 50           push     eax
00a113d5: 8d45dc       lea      eax, [ebp - 0x24]
00a113d8: 50           push     eax
00a113d9: e8f228beff   call     0x5f3cd0
00a113de: 6a00         push     0
00a113e0: 8d45dc       lea      eax, [ebp - 0x24]
00a113e3: c645fc01     mov      byte ptr [ebp - 4], 1
00a113e7: 6a01         push     1
00a113e9: 50           push     eax
00a113ea: e80170e6ff   call     0x8783f0
00a113ef: 8b55f0       mov      edx, dword ptr [ebp - 0x10]
00a113f2: 83c418       add      esp, 0x18
00a113f5: 5e           pop      esi
00a113f6: 83fa10       cmp      edx, 0x10
00a113f9: 7228         jb       0xa11423
00a113fb: 8b4ddc       mov      ecx, dword ptr [ebp - 0x24]
00a113fe: 42           inc      edx
00a113ff: 8bc1         mov      eax, ecx
00a11401: 81fa00100000 cmp      edx, 0x1000
00a11407: 7210         jb       0xa11419
00a11409: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00a1140c: 83c223       add      edx, 0x23
00a1140f: 2bc1         sub      eax, ecx
00a11411: 83c0fc       add      eax, -4
00a11414: 83f81f       cmp      eax, 0x1f
00a11417: 775a         ja       0xa11473
00a11419: 52           push     edx
00a1141a: 51           push     ecx
00a1141b: e8803ac600   call     0x1674ea0
00a11420: 83c408       add      esp, 8
00a11423: 8b55d8       mov      edx, dword ptr [ebp - 0x28]
00a11426: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
00a1142d: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
00a11434: c645dc00     mov      byte ptr [ebp - 0x24], 0

; === 094 | 0xa11394 | Studio.NonTeamCreate.VersionHistory. ===
00a11394: b8a4e79301   mov      eax, 0x193e7a4
00a11399: c745d400000000 mov      dword ptr [ebp - 0x2c], 0
00a113a0: 0f44d0       cmove    edx, eax
00a113a3: c745d80f000000 mov      dword ptr [ebp - 0x28], 0xf
00a113aa: 8bca         mov      ecx, edx
00a113ac: c645c400     mov      byte ptr [ebp - 0x3c], 0
00a113b0: 56           push     esi
00a113b1: 8d7101       lea      esi, [ecx + 1]
00a113b4: 8a01         mov      al, byte ptr [ecx]
00a113b6: 41           inc      ecx
00a113b7: 84c0         test     al, al
00a113b9: 75f9         jne      0xa113b4
00a113bb: 2bce         sub      ecx, esi
00a113bd: 51           push     ecx
00a113be: 52           push     edx
00a113bf: 8d4dc4       lea      ecx, [ebp - 0x3c]
00a113c2: e8f92eb4ff   call     0x5542c0
00a113c7: ff7508       push     dword ptr [ebp + 8]
00a113ca: 8d45c4       lea      eax, [ebp - 0x3c]
00a113cd: c745fc00000000 mov      dword ptr [ebp - 4], 0
00a113d4: 50           push     eax
00a113d5: 8d45dc       lea      eax, [ebp - 0x24]
00a113d8: 50           push     eax
00a113d9: e8f228beff   call     0x5f3cd0
00a113de: 6a00         push     0
00a113e0: 8d45dc       lea      eax, [ebp - 0x24]
00a113e3: c645fc01     mov      byte ptr [ebp - 4], 1
00a113e7: 6a01         push     1
00a113e9: 50           push     eax
00a113ea: e80170e6ff   call     0x8783f0
00a113ef: 8b55f0       mov      edx, dword ptr [ebp - 0x10]
00a113f2: 83c418       add      esp, 0x18
00a113f5: 5e           pop      esi
00a113f6: 83fa10       cmp      edx, 0x10
00a113f9: 7228         jb       0xa11423
00a113fb: 8b4ddc       mov      ecx, dword ptr [ebp - 0x24]
00a113fe: 42           inc      edx
00a113ff: 8bc1         mov      eax, ecx
00a11401: 81fa00100000 cmp      edx, 0x1000
00a11407: 7210         jb       0xa11419
00a11409: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00a1140c: 83c223       add      edx, 0x23
00a1140f: 2bc1         sub      eax, ecx
00a11411: 83c0fc       add      eax, -4
00a11414: 83f81f       cmp      eax, 0x1f
00a11417: 775a         ja       0xa11473
00a11419: 52           push     edx
00a1141a: 51           push     ecx
00a1141b: e8803ac600   call     0x1674ea0
00a11420: 83c408       add      esp, 8
00a11423: 8b55d8       mov      edx, dword ptr [ebp - 0x28]
00a11426: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
00a1142d: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
00a11434: c645dc00     mov      byte ptr [ebp - 0x24], 0

; === 095 | 0xa194a4 | isTeamCreate ===
00a194a4: 680cf79301   push     0x193f70c
00a194a9: e812aeb3ff   call     0x5542c0
00a194ae: 8d857cffffff lea      eax, [ebp - 0x84]
00a194b4: c645fc09     mov      byte ptr [ebp - 4], 9
00a194b8: 50           push     eax
00a194b9: 8d4d94       lea      ecx, [ebp - 0x6c]
00a194bc: e80f81bbff   call     0x5d15d0
00a194c1: 8bd6         mov      edx, esi
00a194c3: 8d4818       lea      ecx, [eax + 0x18]
00a194c6: 8d7a01       lea      edi, [edx + 1]
00a194c9: 0f1f8000000000 nop      dword ptr [eax]
00a194d0: 8a02         mov      al, byte ptr [edx]
00a194d2: 42           inc      edx
00a194d3: 84c0         test     al, al
00a194d5: 75f9         jne      0xa194d0
00a194d7: 2bd7         sub      edx, edi
00a194d9: 52           push     edx
00a194da: 56           push     esi
00a194db: e8e0adb3ff   call     0x5542c0
00a194e0: 8b5590       mov      edx, dword ptr [ebp - 0x70]
00a194e3: c645fc08     mov      byte ptr [ebp - 4], 8
00a194e7: 83fa10       cmp      edx, 0x10
00a194ea: 722f         jb       0xa1951b
00a194ec: 8b8d7cffffff mov      ecx, dword ptr [ebp - 0x84]
00a194f2: 42           inc      edx
00a194f3: 8bc1         mov      eax, ecx
00a194f5: 81fa00100000 cmp      edx, 0x1000
00a194fb: 7214         jb       0xa19511
00a194fd: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00a19500: 83c223       add      edx, 0x23
00a19503: 2bc1         sub      eax, ecx
00a19505: 83c0fc       add      eax, -4
00a19508: 83f81f       cmp      eax, 0x1f
00a1950b: 0f8784010000 ja       0xa19695
00a19511: 52           push     edx
00a19512: 51           push     ecx
00a19513: e888b9c500   call     0x1674ea0
00a19518: 83c408       add      esp, 8
00a1951b: 8b7dc8       mov      edi, dword ptr [ebp - 0x38]
00a1951e: 8b37         mov      esi, dword ptr [edi]
00a19520: 3bf7         cmp      esi, edi
00a19522: 0f8412010000 je       0xa1963a
00a19528: 0f1f840000000000 nop      dword ptr [eax + eax]
00a19530: 8b4620       mov      eax, dword ptr [esi + 0x20]
00a19533: 85c0         test     eax, eax
00a19535: 0f84f5000000 je       0xa19630
00a1953b: 50           push     eax
00a1953c: 8d85f9feffff lea      eax, [ebp - 0x107]
00a19542: 50           push     eax
00a19543: e82883b7ff   call     0x591870
00a19548: b90f000000   mov      ecx, 0xf

; === 096 | 0xbf7caf | CloudEdit ===
00bf7caf: 688c5f8c01   push     0x18c5f8c
00bf7cb4: 0f43c7       cmovae   eax, edi
00bf7cb7: 53           push     ebx
00bf7cb8: 50           push     eax
00bf7cb9: e8a24696ff   call     0x55c360
00bf7cbe: 83c410       add      esp, 0x10
00bf7cc1: 84c0         test     al, al
00bf7cc3: 0f84c5010000 je       0xbf7e8e
00bf7cc9: be06000000   mov      esi, 6
00bf7cce: eb05         jmp      0xbf7cd5
00bf7cd0: be01000000   mov      esi, 1
00bf7cd5: 6a0c         push     0xc
00bf7cd7: 68acff9501   push     0x195ffac
00bf7cdc: 8d4ddc       lea      ecx, [ebp - 0x24]
00bf7cdf: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
00bf7ce6: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
00bf7ced: c645dc00     mov      byte ptr [ebp - 0x24], 0
00bf7cf1: e8cac595ff   call     0x5542c0
00bf7cf6: 8b5dc8       mov      ebx, dword ptr [ebp - 0x38]
00bf7cf9: 8d45dc       lea      eax, [ebp - 0x24]
00bf7cfc: 50           push     eax
00bf7cfd: 8bcb         mov      ecx, ebx
00bf7cff: c645fc13     mov      byte ptr [ebp - 4], 0x13
00bf7d03: e8f8ce9cff   call     0x5c4c00
00bf7d08: 8bf8         mov      edi, eax
00bf7d0a: e8b14bc9ff   call     0x88c8c0
00bf7d0f: 894718       mov      dword ptr [edi + 0x18], eax
00bf7d12: 8b8568ffffff mov      eax, dword ptr [ebp - 0x98]
00bf7d18: 8b0d188cea01 mov      ecx, dword ptr [0x1ea8c18]
00bf7d1e: 8b10         mov      edx, dword ptr [eax]
00bf7d20: 3b8a34000000 cmp      ecx, dword ptr [edx + 0x34]
00bf7d26: 0f8ff4040000 jg       0xbf8220
00bf7d2c: 8b4f1c       mov      ecx, dword ptr [edi + 0x1c]
00bf7d2f: 81f90c8cea01 cmp      ecx, 0x1ea8c0c
00bf7d35: 7505         jne      0xbf7d3c
00bf7d37: 897720       mov      dword ptr [edi + 0x20], esi
00bf7d3a: eb1a         jmp      0xbf7d56
00bf7d3c: 85c9         test     ecx, ecx
00bf7d3e: 740c         je       0xbf7d4c
00bf7d40: 8b4908       mov      ecx, dword ptr [ecx + 8]
00bf7d43: 8d4720       lea      eax, [edi + 0x20]
00bf7d46: 50           push     eax
00bf7d47: ffd1         call     ecx
00bf7d49: 83c404       add      esp, 4
00bf7d4c: 897720       mov      dword ptr [edi + 0x20], esi
00bf7d4f: c7471c0c8cea01 mov      dword ptr [edi + 0x1c], 0x1ea8c0c

; === 097 | 0xf5774a | /ide/publish/UploadFromCloudEdit ===
00f5774a: 680ca49201   push     0x192a40c
00f5774f: 8d4dc4       lea      ecx, [ebp - 0x3c]
00f57752: c645fc01     mov      byte ptr [ebp - 4], 1
00f57756: c745d400000000 mov      dword ptr [ebp - 0x2c], 0
00f5775d: c745d80f000000 mov      dword ptr [ebp - 0x28], 0xf
00f57764: c645c400     mov      byte ptr [ebp - 0x3c], 0
00f57768: e853cb5fff   call     0x5542c0
00f5776d: 8d857cffffff lea      eax, [ebp - 0x84]
00f57773: c645fc02     mov      byte ptr [ebp - 4], 2
00f57777: 50           push     eax
00f57778: e8f3755c00   call     0x151ed70
00f5777d: 83c404       add      esp, 4
00f57780: 8bf0         mov      esi, eax
00f57782: 6a05         push     5
00f57784: 68b4598c01   push     0x18c59b4
00f57789: 8d4ddc       lea      ecx, [ebp - 0x24]
00f5778c: c645fc03     mov      byte ptr [ebp - 4], 3
00f57790: c745ec00000000 mov      dword ptr [ebp - 0x14], 0
00f57797: c745f00f000000 mov      dword ptr [ebp - 0x10], 0xf
00f5779e: c645dc00     mov      byte ptr [ebp - 0x24], 0
00f577a2: e819cb5fff   call     0x5542c0
00f577a7: 8d4594       lea      eax, [ebp - 0x6c]
00f577aa: c645fc04     mov      byte ptr [ebp - 4], 4
00f577ae: 50           push     eax
00f577af: 8d45ac       lea      eax, [ebp - 0x54]
00f577b2: 50           push     eax
00f577b3: 8d45c4       lea      eax, [ebp - 0x3c]
00f577b6: 50           push     eax
00f577b7: 56           push     esi
00f577b8: 8d45dc       lea      eax, [ebp - 0x24]
00f577bb: 50           push     eax
00f577bc: 8d8504ffffff lea      eax, [ebp - 0xfc]
00f577c2: 50           push     eax
00f577c3: e8f8445c00   call     0x151bcc0
00f577c8: 83c418       add      esp, 0x18
00f577cb: 8b7508       mov      esi, dword ptr [ebp + 8]
00f577ce: 8bc8         mov      ecx, eax
00f577d0: 56           push     esi
00f577d1: c645fc05     mov      byte ptr [ebp - 4], 5
00f577d5: e896435c00   call     0x151bb70
00f577da: 8d8d04ffffff lea      ecx, [ebp - 0xfc]
00f577e0: e8eb6161ff   call     0x56d9d0
00f577e5: 8b55f0       mov      edx, dword ptr [ebp - 0x10]
00f577e8: 83fa10       cmp      edx, 0x10
00f577eb: 722c         jb       0xf57819

; === 098 | 0x151aa31 | CloudEdit ===
0151aa31: b88c5f8c01   mov      eax, 0x18c5f8c
0151aa36: 5d           pop      ebp
0151aa37: c3           ret      
0151aa38: b824dfa801   mov      eax, 0x1a8df24
0151aa3d: 5d           pop      ebp
0151aa3e: c3           ret      
0151aa3f: b83cf38b01   mov      eax, 0x18bf33c
0151aa44: 5d           pop      ebp
0151aa45: c3           ret      
0151aa46: 6690         nop      
0151aa48: 23aa51012aaa and      ebp, dword ptr [edx - 0x55d5feaf]
0151aa4e: 51           push     ecx
0151aa4f: 0131         add      dword ptr [ecx], esi
0151aa51: aa           stosb    byte ptr es:[edi], al
0151aa52: 51           push     ecx
0151aa53: 0138         add      dword ptr [eax], edi
0151aa55: aa           stosb    byte ptr es:[edi], al
0151aa56: 51           push     ecx
0151aa57: 01cc         add      esp, ecx
0151aa59: cc           int3     
0151aa5a: cc           int3     
0151aa5b: cc           int3     
0151aa5c: cc           int3     
0151aa5d: cc           int3     
0151aa5e: cc           int3     
0151aa5f: cc           int3     
0151aa60: 55           push     ebp
0151aa61: 8bec         mov      ebp, esp
0151aa63: ff0d10eaf601 dec      dword ptr [0x1f6ea10]
0151aa69: 33c0         xor      eax, eax
0151aa6b: 8b4d0c       mov      ecx, dword ptr [ebp + 0xc]
0151aa6e: 8b5508       mov      edx, dword ptr [ebp + 8]
0151aa71: 3914c5f0e9f601 cmp      dword ptr [eax*8 + 0x1f6e9f0], edx
0151aa78: 7509         jne      0x151aa83
0151aa7a: 390cc5f4e9f601 cmp      dword ptr [eax*8 + 0x1f6e9f4], ecx
0151aa81: 7408         je       0x151aa8b
0151aa83: 40           inc      eax
0151aa84: 83f804       cmp      eax, 4
0151aa87: 7ce8         jl       0x151aa71
0151aa89: 5d           pop      ebp
0151aa8a: c3           ret      
0151aa8b: 83f803       cmp      eax, 3
0151aa8e: 7d23         jge      0x151aab3
0151aa90: 56           push     esi
0151aa91: b903000000   mov      ecx, 3
0151aa96: 8d34c5f8e9f601 lea      esi, [eax*8 + 0x1f6e9f8]
0151aa9d: 2bc8         sub      ecx, eax
0151aa9f: 57           push     edi
0151aaa0: 03c9         add      ecx, ecx
0151aaa2: 8d3cc5f0e9f601 lea      edi, [eax*8 + 0x1f6e9f0]
0151aaa9: 81e1feffff3f and      ecx, 0x3ffffffe
0151aaaf: f3a5         rep movsd dword ptr es:[edi], dword ptr [esi]
0151aab1: 5f           pop      edi
0151aab2: 5e           pop      esi
0151aab3: 0f57c0       xorps    xmm0, xmm0
0151aab6: 660f130508eaf601 movlpd   qword ptr [0x1f6ea08], xmm0
0151aabe: 5d           pop      ebp
0151aabf: c3           ret      
0151aac0: 55           push     ebp
0151aac1: 8bec         mov      ebp, esp
0151aac3: 6a7f         push     0x7f
0151aac5: ff7508       push     dword ptr [ebp + 8]
0151aac8: 6818e6f601   push     0x1f6e618
0151aacd: e83e322000   call     0x171dd10
0151aad2: 83c40c       add      esp, 0xc

; === 099 | 0x151aa38 | CloudEditPlayTest ===
0151aa38: b824dfa801   mov      eax, 0x1a8df24
0151aa3d: 5d           pop      ebp
0151aa3e: c3           ret      
0151aa3f: b83cf38b01   mov      eax, 0x18bf33c
0151aa44: 5d           pop      ebp
0151aa45: c3           ret      
0151aa46: 6690         nop      
0151aa48: 23aa51012aaa and      ebp, dword ptr [edx - 0x55d5feaf]
0151aa4e: 51           push     ecx
0151aa4f: 0131         add      dword ptr [ecx], esi
0151aa51: aa           stosb    byte ptr es:[edi], al
0151aa52: 51           push     ecx
0151aa53: 0138         add      dword ptr [eax], edi
0151aa55: aa           stosb    byte ptr es:[edi], al
0151aa56: 51           push     ecx
0151aa57: 01cc         add      esp, ecx
0151aa59: cc           int3     
0151aa5a: cc           int3     
0151aa5b: cc           int3     
0151aa5c: cc           int3     
0151aa5d: cc           int3     
0151aa5e: cc           int3     
0151aa5f: cc           int3     
0151aa60: 55           push     ebp
0151aa61: 8bec         mov      ebp, esp
0151aa63: ff0d10eaf601 dec      dword ptr [0x1f6ea10]
0151aa69: 33c0         xor      eax, eax
0151aa6b: 8b4d0c       mov      ecx, dword ptr [ebp + 0xc]
0151aa6e: 8b5508       mov      edx, dword ptr [ebp + 8]
0151aa71: 3914c5f0e9f601 cmp      dword ptr [eax*8 + 0x1f6e9f0], edx
0151aa78: 7509         jne      0x151aa83
0151aa7a: 390cc5f4e9f601 cmp      dword ptr [eax*8 + 0x1f6e9f4], ecx
0151aa81: 7408         je       0x151aa8b
0151aa83: 40           inc      eax
0151aa84: 83f804       cmp      eax, 4
0151aa87: 7ce8         jl       0x151aa71
0151aa89: 5d           pop      ebp
0151aa8a: c3           ret      
0151aa8b: 83f803       cmp      eax, 3
0151aa8e: 7d23         jge      0x151aab3
0151aa90: 56           push     esi
0151aa91: b903000000   mov      ecx, 3
0151aa96: 8d34c5f8e9f601 lea      esi, [eax*8 + 0x1f6e9f8]
0151aa9d: 2bc8         sub      ecx, eax
0151aa9f: 57           push     edi
0151aaa0: 03c9         add      ecx, ecx
0151aaa2: 8d3cc5f0e9f601 lea      edi, [eax*8 + 0x1f6e9f0]
0151aaa9: 81e1feffff3f and      ecx, 0x3ffffffe
0151aaaf: f3a5         rep movsd dword ptr es:[edi], dword ptr [esi]
0151aab1: 5f           pop      edi
0151aab2: 5e           pop      esi
0151aab3: 0f57c0       xorps    xmm0, xmm0
0151aab6: 660f130508eaf601 movlpd   qword ptr [0x1f6ea08], xmm0
0151aabe: 5d           pop      ebp
0151aabf: c3           ret      
0151aac0: 55           push     ebp
0151aac1: 8bec         mov      ebp, esp
0151aac3: 6a7f         push     0x7f
0151aac5: ff7508       push     dword ptr [ebp + 8]
0151aac8: 6818e6f601   push     0x1f6e618
0151aacd: e83e322000   call     0x171dd10
0151aad2: 83c40c       add      esp, 0xc
0151aad5: c60597e6f60100 mov      byte ptr [0x1f6e697], 0
0151aadc: 5d           pop      ebp

; === 100 | 0x477057 | NetworkClientSideCompleteness ===
00477057: 688c978d01   push     0x18d978c
0047705c: e8ef0e2001   call     0x1677f50
00477061: 83c40c       add      esp, 0xc
00477064: a344e5ea01   mov      dword ptr [0x1eae544], eax
00477069: c3           ret      
0047706a: cc           int3     
0047706b: cc           int3     
0047706c: cc           int3     
0047706d: cc           int3     
0047706e: cc           int3     
0047706f: cc           int3     
00477070: 6a02         push     2
00477072: 68a0b2d501   push     0x1d5b2a0
00477077: 6828988d01   push     0x18d9828
0047707c: e8cf0e2001   call     0x1677f50
00477081: 83c40c       add      esp, 0xc
00477084: a35ce5ea01   mov      dword ptr [0x1eae55c], eax
00477089: c3           ret      
0047708a: cc           int3     
0047708b: cc           int3     
0047708c: cc           int3     
0047708d: cc           int3     
0047708e: cc           int3     
0047708f: cc           int3     
00477090: 6a00         push     0
00477092: 68489b8d01   push     0x18d9b48
00477097: e8c4e11f01   call     0x1675260
0047709c: 83c408       add      esp, 8
0047709f: a358e5ea01   mov      dword ptr [0x1eae558], eax
004770a4: c3           ret      
004770a5: cc           int3     
004770a6: cc           int3     
004770a7: cc           int3     
004770a8: cc           int3     
004770a9: cc           int3     
004770aa: cc           int3     
004770ab: cc           int3     
004770ac: cc           int3     
004770ad: cc           int3     
004770ae: cc           int3     
004770af: cc           int3     
004770b0: 6a02         push     2
004770b2: 68ace4ea01   push     0x1eae4ac
004770b7: 68b4948d01   push     0x18d94b4
004770bc: e8ef0e2001   call     0x1677fb0
004770c1: 83c40c       add      esp, 0xc
004770c4: a3dce4ea01   mov      dword ptr [0x1eae4dc], eax
004770c9: c3           ret      
004770ca: cc           int3     
004770cb: cc           int3     
004770cc: cc           int3     
004770cd: cc           int3     
004770ce: cc           int3     
004770cf: cc           int3     
004770d0: 6a02         push     2
004770d2: 6860b1d501   push     0x1d5b160
004770d7: 68f0948d01   push     0x18d94f0
004770dc: e8af0e2001   call     0x1677f90
004770e1: 83c40c       add      esp, 0xc
004770e4: a3e8e4ea01   mov      dword ptr [0x1eae4e8], eax
004770e9: c3           ret      
004770ea: cc           int3     
004770eb: cc           int3     
004770ec: cc           int3     
004770ed: cc           int3     
004770ee: cc           int3     
004770ef: cc           int3     
004770f0: 6a02         push     2
004770f2: 6800b2d501   push     0x1d5b200
004770f7: 6874978d01   push     0x18d9774

; === 101 | 0x4772d7 | SupportJoinDataItemV2UseInvalidOffsets ===
004772d7: 681c968d01   push     0x18d961c
004772dc: e86f0c2001   call     0x1677f50
004772e1: 83c40c       add      esp, 0xc
004772e4: a314e5ea01   mov      dword ptr [0x1eae514], eax
004772e9: c3           ret      
004772ea: cc           int3     
004772eb: cc           int3     
004772ec: cc           int3     
004772ed: cc           int3     
004772ee: cc           int3     
004772ef: cc           int3     
004772f0: 6a02         push     2
004772f2: 6828b2d501   push     0x1d5b228
004772f7: 6804968d01   push     0x18d9604
004772fc: e84f0c2001   call     0x1677f50
00477301: 83c40c       add      esp, 0xc
00477304: a310e5ea01   mov      dword ptr [0x1eae510], eax
00477309: c3           ret      
0047730a: cc           int3     
0047730b: cc           int3     
0047730c: cc           int3     
0047730d: cc           int3     
0047730e: cc           int3     
0047730f: cc           int3     
00477310: 6a02         push     2
00477312: 6848b2d501   push     0x1d5b248
00477317: 6884968d01   push     0x18d9684
0047731c: e82f0c2001   call     0x1677f50
00477321: 83c40c       add      esp, 0xc
00477324: a324e5ea01   mov      dword ptr [0x1eae524], eax
00477329: c3           ret      
0047732a: cc           int3     
0047732b: cc           int3     
0047732c: cc           int3     
0047732d: cc           int3     
0047732e: cc           int3     
0047732f: cc           int3     
00477330: 6a02         push     2
00477332: 6840b2d501   push     0x1d5b240
00477337: 6860968d01   push     0x18d9660
0047733c: e80f0c2001   call     0x1677f50
00477341: 83c40c       add      esp, 0xc
00477344: a320e5ea01   mov      dword ptr [0x1eae520], eax
00477349: c3           ret      
0047734a: cc           int3     
0047734b: cc           int3     
0047734c: cc           int3     
0047734d: cc           int3     
0047734e: cc           int3     
0047734f: cc           int3     
00477350: 6a02         push     2
00477352: 68b8e4ea01   push     0x1eae4b8
00477357: 68bc958d01   push     0x18d95bc
0047735c: e82f0c2001   call     0x1677f90
00477361: 83c40c       add      esp, 0xc
00477364: a308e5ea01   mov      dword ptr [0x1eae508], eax
00477369: c3           ret      
0047736a: cc           int3     
0047736b: cc           int3     
0047736c: cc           int3     
0047736d: cc           int3     
0047736e: cc           int3     
0047736f: cc           int3     
00477370: 6a02         push     2
00477372: 6888b1d501   push     0x1d5b188
00477377: 68a0958d01   push     0x18d95a0

; === 102 | 0x4772f7 | SupportJoinDataItemV2iv ===
004772f7: 6804968d01   push     0x18d9604
004772fc: e84f0c2001   call     0x1677f50
00477301: 83c40c       add      esp, 0xc
00477304: a310e5ea01   mov      dword ptr [0x1eae510], eax
00477309: c3           ret      
0047730a: cc           int3     
0047730b: cc           int3     
0047730c: cc           int3     
0047730d: cc           int3     
0047730e: cc           int3     
0047730f: cc           int3     
00477310: 6a02         push     2
00477312: 6848b2d501   push     0x1d5b248
00477317: 6884968d01   push     0x18d9684
0047731c: e82f0c2001   call     0x1677f50
00477321: 83c40c       add      esp, 0xc
00477324: a324e5ea01   mov      dword ptr [0x1eae524], eax
00477329: c3           ret      
0047732a: cc           int3     
0047732b: cc           int3     
0047732c: cc           int3     
0047732d: cc           int3     
0047732e: cc           int3     
0047732f: cc           int3     
00477330: 6a02         push     2
00477332: 6840b2d501   push     0x1d5b240
00477337: 6860968d01   push     0x18d9660
0047733c: e80f0c2001   call     0x1677f50
00477341: 83c40c       add      esp, 0xc
00477344: a320e5ea01   mov      dword ptr [0x1eae520], eax
00477349: c3           ret      
0047734a: cc           int3     
0047734b: cc           int3     
0047734c: cc           int3     
0047734d: cc           int3     
0047734e: cc           int3     
0047734f: cc           int3     
00477350: 6a02         push     2
00477352: 68b8e4ea01   push     0x1eae4b8
00477357: 68bc958d01   push     0x18d95bc
0047735c: e82f0c2001   call     0x1677f90
00477361: 83c40c       add      esp, 0xc
00477364: a308e5ea01   mov      dword ptr [0x1eae508], eax
00477369: c3           ret      
0047736a: cc           int3     
0047736b: cc           int3     
0047736c: cc           int3     
0047736d: cc           int3     
0047736e: cc           int3     
0047736f: cc           int3     
00477370: 6a02         push     2
00477372: 6888b1d501   push     0x1d5b188
00477377: 68a0958d01   push     0x18d95a0
0047737c: e80f0c2001   call     0x1677f90
00477381: 83c40c       add      esp, 0xc
00477384: a304e5ea01   mov      dword ptr [0x1eae504], eax
00477389: c3           ret      
0047738a: cc           int3     
0047738b: cc           int3     
0047738c: cc           int3     
0047738d: cc           int3     
0047738e: cc           int3     
0047738f: cc           int3     
00477390: 6a02         push     2
00477392: 6818b2d501   push     0x1d5b218
00477397: 6888958d01   push     0x18d9588

; === 103 | 0x477f87 | ReplicatorJoinDataItemStatsInfluxHundrethsPercentage ===
00477f87: 6828d18d01   push     0x18dd128
00477f8c: e8ffff1f01   call     0x1677f90
00477f91: 83c40c       add      esp, 0xc
00477f94: a3c4eeea01   mov      dword ptr [0x1eaeec4], eax
00477f99: c3           ret      
00477f9a: cc           int3     
00477f9b: cc           int3     
00477f9c: cc           int3     
00477f9d: cc           int3     
00477f9e: cc           int3     
00477f9f: cc           int3     
00477fa0: 6a02         push     2
00477fa2: 689ceeea01   push     0x1eaee9c
00477fa7: 6860d18d01   push     0x18dd160
00477fac: e8dfff1f01   call     0x1677f90
00477fb1: 83c40c       add      esp, 0xc
00477fb4: a3c8eeea01   mov      dword ptr [0x1eaeec8], eax
00477fb9: c3           ret      
00477fba: cc           int3     
00477fbb: cc           int3     
00477fbc: cc           int3     
00477fbd: cc           int3     
00477fbe: cc           int3     
00477fbf: cc           int3     
00477fc0: b9a0eeea01   mov      ecx, 0x1eaeea0
00477fc5: e976f11700   jmp      0x5f7140
00477fca: cc           int3     
00477fcb: cc           int3     
00477fcc: cc           int3     
00477fcd: cc           int3     
00477fce: cc           int3     
00477fcf: cc           int3     
00477fd0: 6a24         push     0x24
00477fd2: 68d8e38b01   push     0x18be3d8
00477fd7: b958b6d501   mov      ecx, 0x1d5b658
00477fdc: e8dfc20d00   call     0x5542c0
00477fe1: 68c0df8701   push     0x187dfc0
00477fe6: e869b62701   call     0x16f3654
00477feb: 59           pop      ecx
00477fec: c3           ret      
00477fed: cc           int3     
00477fee: cc           int3     
00477fef: cc           int3     
00477ff0: 6a02         push     2
00477ff2: 687cb6d501   push     0x1d5b67c
00477ff7: 68c4d38d01   push     0x18dd3c4
00477ffc: e88fff1f01   call     0x1677f90
00478001: 83c40c       add      esp, 0xc
00478004: a304efea01   mov      dword ptr [0x1eaef04], eax
00478009: c3           ret      
0047800a: cc           int3     
0047800b: cc           int3     
0047800c: cc           int3     
0047800d: cc           int3     
0047800e: cc           int3     
0047800f: cc           int3     
00478010: 6a02         push     2
00478012: 68b0b6d501   push     0x1d5b6b0
00478017: 68b0d38d01   push     0x18dd3b0
0047801c: e82fff1f01   call     0x1677f50
00478021: 83c40c       add      esp, 0xc
00478024: a300efea01   mov      dword ptr [0x1eaef00], eax
00478029: c3           ret      

; === 104 | 0x477fa7 | ReportJoinDataItemCacheEfficiencyHundrethsPercentage2 ===
00477fa7: 6860d18d01   push     0x18dd160
00477fac: e8dfff1f01   call     0x1677f90
00477fb1: 83c40c       add      esp, 0xc
00477fb4: a3c8eeea01   mov      dword ptr [0x1eaeec8], eax
00477fb9: c3           ret      
00477fba: cc           int3     
00477fbb: cc           int3     
00477fbc: cc           int3     
00477fbd: cc           int3     
00477fbe: cc           int3     
00477fbf: cc           int3     
00477fc0: b9a0eeea01   mov      ecx, 0x1eaeea0
00477fc5: e976f11700   jmp      0x5f7140
00477fca: cc           int3     
00477fcb: cc           int3     
00477fcc: cc           int3     
00477fcd: cc           int3     
00477fce: cc           int3     
00477fcf: cc           int3     
00477fd0: 6a24         push     0x24
00477fd2: 68d8e38b01   push     0x18be3d8
00477fd7: b958b6d501   mov      ecx, 0x1d5b658
00477fdc: e8dfc20d00   call     0x5542c0
00477fe1: 68c0df8701   push     0x187dfc0
00477fe6: e869b62701   call     0x16f3654
00477feb: 59           pop      ecx
00477fec: c3           ret      
00477fed: cc           int3     
00477fee: cc           int3     
00477fef: cc           int3     
00477ff0: 6a02         push     2
00477ff2: 687cb6d501   push     0x1d5b67c
00477ff7: 68c4d38d01   push     0x18dd3c4
00477ffc: e88fff1f01   call     0x1677f90
00478001: 83c40c       add      esp, 0xc
00478004: a304efea01   mov      dword ptr [0x1eaef04], eax
00478009: c3           ret      
0047800a: cc           int3     
0047800b: cc           int3     
0047800c: cc           int3     
0047800d: cc           int3     
0047800e: cc           int3     
0047800f: cc           int3     
00478010: 6a02         push     2
00478012: 68b0b6d501   push     0x1d5b6b0
00478017: 68b0d38d01   push     0x18dd3b0
0047801c: e82fff1f01   call     0x1677f50
00478021: 83c40c       add      esp, 0xc
00478024: a300efea01   mov      dword ptr [0x1eaef00], eax
00478029: c3           ret      
0047802a: cc           int3     
0047802b: cc           int3     
0047802c: cc           int3     
0047802d: cc           int3     
0047802e: cc           int3     
0047802f: cc           int3     
00478030: b9e0eeea01   mov      ecx, 0x1eaeee0
00478035: e906f11700   jmp      0x5f7140
0047803a: cc           int3     
0047803b: cc           int3     
0047803c: cc           int3     
0047803d: cc           int3     
0047803e: cc           int3     
0047803f: cc           int3     
00478040: 6a24         push     0x24
00478042: 68d8e38b01   push     0x18be3d8
00478047: b998b6d501   mov      ecx, 0x1d5b698

; === 105 | 0x4782d7 | JoinDataCacheInitialOrder ===
004782d7: 6864d88d01   push     0x18dd864
004782dc: e86ffc1f01   call     0x1677f50
004782e1: 83c40c       add      esp, 0xc
004782e4: a34cefea01   mov      dword ptr [0x1eaef4c], eax
004782e9: c3           ret      
004782ea: cc           int3     
004782eb: cc           int3     
004782ec: cc           int3     
004782ed: cc           int3     
004782ee: cc           int3     
004782ef: cc           int3     
004782f0: 6a01         push     1
004782f2: 6810b7d501   push     0x1d5b710
004782f7: 6828d88d01   push     0x18dd828
004782fc: e84ffc1f01   call     0x1677f50
00478301: 83c40c       add      esp, 0xc
00478304: a344efea01   mov      dword ptr [0x1eaef44], eax
00478309: c3           ret      
0047830a: cc           int3     
0047830b: cc           int3     
0047830c: cc           int3     
0047830d: cc           int3     
0047830e: cc           int3     
0047830f: cc           int3     
00478310: 6a02         push     2
00478312: 68e4b6d501   push     0x1d5b6e4
00478317: 68f8d78d01   push     0x18dd7f8
0047831c: e86ffc1f01   call     0x1677f90
00478321: 83c40c       add      esp, 0xc
00478324: a340efea01   mov      dword ptr [0x1eaef40], eax
00478329: c3           ret      
0047832a: cc           int3     
0047832b: cc           int3     
0047832c: cc           int3     
0047832d: cc           int3     
0047832e: cc           int3     
0047832f: cc           int3     
00478330: b918efea01   mov      ecx, 0x1eaef18
00478335: e906ee1700   jmp      0x5f7140
0047833a: cc           int3     
0047833b: cc           int3     
0047833c: cc           int3     
0047833d: cc           int3     
0047833e: cc           int3     
0047833f: cc           int3     
00478340: 6a24         push     0x24
00478342: 68d8e38b01   push     0x18be3d8
00478347: b9f8b6d501   mov      ecx, 0x1d5b6f8
0047834c: e86fbf0d00   call     0x5542c0
00478351: 68a0e08701   push     0x187e0a0
00478356: e8f9b22701   call     0x16f3654
0047835b: 59           pop      ecx
0047835c: c3           ret      
0047835d: cc           int3     
0047835e: cc           int3     
0047835f: cc           int3     
00478360: b9e4efea01   mov      ecx, 0x1eaefe4
00478365: e9d6ed1700   jmp      0x5f7140
0047836a: cc           int3     
0047836b: cc           int3     
0047836c: cc           int3     
0047836d: cc           int3     
0047836e: cc           int3     
0047836f: cc           int3     
00478370: 6a24         push     0x24
00478372: 68d8e38b01   push     0x18be3d8
00478377: b940b7d501   mov      ecx, 0x1d5b740

; === 106 | 0x4782f7 | JoinDataCacheOptimizeBlobCount ===
004782f7: 6828d88d01   push     0x18dd828
004782fc: e84ffc1f01   call     0x1677f50
00478301: 83c40c       add      esp, 0xc
00478304: a344efea01   mov      dword ptr [0x1eaef44], eax
00478309: c3           ret      
0047830a: cc           int3     
0047830b: cc           int3     
0047830c: cc           int3     
0047830d: cc           int3     
0047830e: cc           int3     
0047830f: cc           int3     
00478310: 6a02         push     2
00478312: 68e4b6d501   push     0x1d5b6e4
00478317: 68f8d78d01   push     0x18dd7f8
0047831c: e86ffc1f01   call     0x1677f90
00478321: 83c40c       add      esp, 0xc
00478324: a340efea01   mov      dword ptr [0x1eaef40], eax
00478329: c3           ret      
0047832a: cc           int3     
0047832b: cc           int3     
0047832c: cc           int3     
0047832d: cc           int3     
0047832e: cc           int3     
0047832f: cc           int3     
00478330: b918efea01   mov      ecx, 0x1eaef18
00478335: e906ee1700   jmp      0x5f7140
0047833a: cc           int3     
0047833b: cc           int3     
0047833c: cc           int3     
0047833d: cc           int3     
0047833e: cc           int3     
0047833f: cc           int3     
00478340: 6a24         push     0x24
00478342: 68d8e38b01   push     0x18be3d8
00478347: b9f8b6d501   mov      ecx, 0x1d5b6f8
0047834c: e86fbf0d00   call     0x5542c0
00478351: 68a0e08701   push     0x187e0a0
00478356: e8f9b22701   call     0x16f3654
0047835b: 59           pop      ecx
0047835c: c3           ret      
0047835d: cc           int3     
0047835e: cc           int3     
0047835f: cc           int3     
00478360: b9e4efea01   mov      ecx, 0x1eaefe4
00478365: e9d6ed1700   jmp      0x5f7140
0047836a: cc           int3     
0047836b: cc           int3     
0047836c: cc           int3     
0047836d: cc           int3     
0047836e: cc           int3     
0047836f: cc           int3     
00478370: 6a24         push     0x24
00478372: 68d8e38b01   push     0x18be3d8
00478377: b940b7d501   mov      ecx, 0x1d5b740
0047837c: e83fbf0d00   call     0x5542c0
00478381: 6800e18701   push     0x187e100
00478386: e8c9b22701   call     0x16f3654
0047838b: 59           pop      ecx
0047838c: c3           ret      
0047838d: cc           int3     
0047838e: cc           int3     
0047838f: cc           int3     
00478390: 6a02         push     2
00478392: 6830b8d501   push     0x1d5b830
00478397: 68e8e48d01   push     0x18de4e8

; === 107 | 0x478317 | JoinDataItemEstimatedCompressionRatioHundreths ===
00478317: 68f8d78d01   push     0x18dd7f8
0047831c: e86ffc1f01   call     0x1677f90
00478321: 83c40c       add      esp, 0xc
00478324: a340efea01   mov      dword ptr [0x1eaef40], eax
00478329: c3           ret      
0047832a: cc           int3     
0047832b: cc           int3     
0047832c: cc           int3     
0047832d: cc           int3     
0047832e: cc           int3     
0047832f: cc           int3     
00478330: b918efea01   mov      ecx, 0x1eaef18
00478335: e906ee1700   jmp      0x5f7140
0047833a: cc           int3     
0047833b: cc           int3     
0047833c: cc           int3     
0047833d: cc           int3     
0047833e: cc           int3     
0047833f: cc           int3     
00478340: 6a24         push     0x24
00478342: 68d8e38b01   push     0x18be3d8
00478347: b9f8b6d501   mov      ecx, 0x1d5b6f8
0047834c: e86fbf0d00   call     0x5542c0
00478351: 68a0e08701   push     0x187e0a0
00478356: e8f9b22701   call     0x16f3654
0047835b: 59           pop      ecx
0047835c: c3           ret      
0047835d: cc           int3     
0047835e: cc           int3     
0047835f: cc           int3     
00478360: b9e4efea01   mov      ecx, 0x1eaefe4
00478365: e9d6ed1700   jmp      0x5f7140
0047836a: cc           int3     
0047836b: cc           int3     
0047836c: cc           int3     
0047836d: cc           int3     
0047836e: cc           int3     
0047836f: cc           int3     
00478370: 6a24         push     0x24
00478372: 68d8e38b01   push     0x18be3d8
00478377: b940b7d501   mov      ecx, 0x1d5b740
0047837c: e83fbf0d00   call     0x5542c0
00478381: 6800e18701   push     0x187e100
00478386: e8c9b22701   call     0x16f3654
0047838b: 59           pop      ecx
0047838c: c3           ret      
0047838d: cc           int3     
0047838e: cc           int3     
0047838f: cc           int3     
00478390: 6a02         push     2
00478392: 6830b8d501   push     0x1d5b830
00478397: 68e8e48d01   push     0x18de4e8
0047839c: e8affb1f01   call     0x1677f50
004783a1: 83c40c       add      esp, 0xc
004783a4: a34cf0ea01   mov      dword ptr [0x1eaf04c], eax
004783a9: c3           ret      
004783aa: cc           int3     
004783ab: cc           int3     
004783ac: cc           int3     
004783ad: cc           int3     
004783ae: cc           int3     
004783af: cc           int3     
004783b0: 6a02         push     2
004783b2: 6848b8d501   push     0x1d5b848
004783b7: 6840e58d01   push     0x18de540

; === 108 | 0x478c37 | JoinDataRxStats ===
00478c37: 68c8028e01   push     0x18e02c8
00478c3c: e86ff31f01   call     0x1677fb0
00478c41: 83c40c       add      esp, 0xc
00478c44: a3ccf3ea01   mov      dword ptr [0x1eaf3cc], eax
00478c49: c3           ret      
00478c4a: cc           int3     
00478c4b: cc           int3     
00478c4c: cc           int3     
00478c4d: cc           int3     
00478c4e: cc           int3     
00478c4f: cc           int3     
00478c50: 6a02         push     2
00478c52: 685cf3ea01   push     0x1eaf35c
00478c57: 6820018e01   push     0x18e0120
00478c5c: e84ff31f01   call     0x1677fb0
00478c61: 83c40c       add      esp, 0xc
00478c64: a394f3ea01   mov      dword ptr [0x1eaf394], eax
00478c69: c3           ret      
00478c6a: cc           int3     
00478c6b: cc           int3     
00478c6c: cc           int3     
00478c6d: cc           int3     
00478c6e: cc           int3     
00478c6f: cc           int3     
00478c70: 6a02         push     2
00478c72: 688cbad501   push     0x1d5ba8c
00478c77: 689c028e01   push     0x18e029c
00478c7c: e8cff21f01   call     0x1677f50
00478c81: 83c40c       add      esp, 0xc
00478c84: a3c8f3ea01   mov      dword ptr [0x1eaf3c8], eax
00478c89: c3           ret      
00478c8a: cc           int3     
00478c8b: cc           int3     
00478c8c: cc           int3     
00478c8d: cc           int3     
00478c8e: cc           int3     
00478c8f: cc           int3     
00478c90: 6a02         push     2
00478c92: 68e4b9d501   push     0x1d5b9e4
00478c97: 6838018e01   push     0x18e0138
00478c9c: e8eff21f01   call     0x1677f90
00478ca1: 83c40c       add      esp, 0xc
00478ca4: a398f3ea01   mov      dword ptr [0x1eaf398], eax
00478ca9: c3           ret      
00478caa: cc           int3     
00478cab: cc           int3     
00478cac: cc           int3     
00478cad: cc           int3     
00478cae: cc           int3     
00478caf: cc           int3     
00478cb0: 6a01         push     1
00478cb2: 686cbad501   push     0x1d5ba6c
00478cb7: 6894018e01   push     0x18e0194
00478cbc: e88ff21f01   call     0x1677f50
00478cc1: 83c40c       add      esp, 0xc
00478cc4: a3a4f3ea01   mov      dword ptr [0x1eaf3a4], eax
00478cc9: c3           ret      
00478cca: cc           int3     
00478ccb: cc           int3     
00478ccc: cc           int3     
00478ccd: cc           int3     
00478cce: cc           int3     
00478ccf: cc           int3     
00478cd0: b96cf3ea01   mov      ecx, 0x1eaf36c
00478cd5: e966e41700   jmp      0x5f7140
00478cda: cc           int3     

; === 109 | 0x4793a7 | MaxJoinDataSendPerBurstKB ===
004793a7: 68b0168e01   push     0x18e16b0
004793ac: e8dfeb1f01   call     0x1677f90
004793b1: 83c40c       add      esp, 0xc
004793b4: a3c4f4ea01   mov      dword ptr [0x1eaf4c4], eax
004793b9: c3           ret      
004793ba: cc           int3     
004793bb: cc           int3     
004793bc: cc           int3     
004793bd: cc           int3     
004793be: cc           int3     
004793bf: cc           int3     
004793c0: b9a4f4ea01   mov      ecx, 0x1eaf4a4
004793c5: e976dd1700   jmp      0x5f7140
004793ca: cc           int3     
004793cb: cc           int3     
004793cc: cc           int3     
004793cd: cc           int3     
004793ce: cc           int3     
004793cf: cc           int3     
004793d0: 6a24         push     0x24
004793d2: 68d8e38b01   push     0x18be3d8
004793d7: b9b0bbd501   mov      ecx, 0x1d5bbb0
004793dc: e8dfae0d00   call     0x5542c0
004793e1: 6880e48701   push     0x187e480
004793e6: e869a22701   call     0x16f3654
004793eb: 59           pop      ecx
004793ec: c3           ret      
004793ed: cc           int3     
004793ee: cc           int3     
004793ef: cc           int3     
004793f0: 6a02         push     2
004793f2: 6818bcd501   push     0x1d5bc18
004793f7: 68fc178e01   push     0x18e17fc
004793fc: e84feb1f01   call     0x1677f50
00479401: 83c40c       add      esp, 0xc
00479404: a300f5ea01   mov      dword ptr [0x1eaf500], eax
00479409: c3           ret      
0047940a: cc           int3     
0047940b: cc           int3     
0047940c: cc           int3     
0047940d: cc           int3     
0047940e: cc           int3     
0047940f: cc           int3     
00479410: 6a02         push     2
00479412: 68c8f4ea01   push     0x1eaf4c8
00479417: 6838178e01   push     0x18e1738
0047941c: e86feb1f01   call     0x1677f90
00479421: 83c40c       add      esp, 0xc
00479424: a3f0f4ea01   mov      dword ptr [0x1eaf4f0], eax
00479429: c3           ret      
0047942a: cc           int3     
0047942b: cc           int3     
0047942c: cc           int3     
0047942d: cc           int3     
0047942e: cc           int3     
0047942f: cc           int3     
00479430: 6a02         push     2
00479432: 68ccf4ea01   push     0x1eaf4cc
00479437: 68c4178e01   push     0x18e17c4
0047943c: e84feb1f01   call     0x1677f90
00479441: 83c40c       add      esp, 0xc
00479444: a3fcf4ea01   mov      dword ptr [0x1eaf4fc], eax
00479449: c3           ret      

; === 110 | 0x479417 | ReplicatorJoinDataItemV2StatsInfluxHundrethsPercentage ===
00479417: 6838178e01   push     0x18e1738
0047941c: e86feb1f01   call     0x1677f90
00479421: 83c40c       add      esp, 0xc
00479424: a3f0f4ea01   mov      dword ptr [0x1eaf4f0], eax
00479429: c3           ret      
0047942a: cc           int3     
0047942b: cc           int3     
0047942c: cc           int3     
0047942d: cc           int3     
0047942e: cc           int3     
0047942f: cc           int3     
00479430: 6a02         push     2
00479432: 68ccf4ea01   push     0x1eaf4cc
00479437: 68c4178e01   push     0x18e17c4
0047943c: e84feb1f01   call     0x1677f90
00479441: 83c40c       add      esp, 0xc
00479444: a3fcf4ea01   mov      dword ptr [0x1eaf4fc], eax
00479449: c3           ret      
0047944a: cc           int3     
0047944b: cc           int3     
0047944c: cc           int3     
0047944d: cc           int3     
0047944e: cc           int3     
0047944f: cc           int3     
00479450: 6a02         push     2
00479452: 6808bcd501   push     0x1d5bc08
00479457: 6870178e01   push     0x18e1770
0047945c: e8efea1f01   call     0x1677f50
00479461: 83c40c       add      esp, 0xc
00479464: a3f4f4ea01   mov      dword ptr [0x1eaf4f4], eax
00479469: c3           ret      
0047946a: cc           int3     
0047946b: cc           int3     
0047946c: cc           int3     
0047946d: cc           int3     
0047946e: cc           int3     
0047946f: cc           int3     
00479470: 6a01         push     1
00479472: 6810bcd501   push     0x1d5bc10
00479477: 689c178e01   push     0x18e179c
0047947c: e8cfea1f01   call     0x1677f50
00479481: 83c40c       add      esp, 0xc
00479484: a3f8f4ea01   mov      dword ptr [0x1eaf4f8], eax
00479489: c3           ret      
0047948a: cc           int3     
0047948b: cc           int3     
0047948c: cc           int3     
0047948d: cc           int3     
0047948e: cc           int3     
0047948f: cc           int3     
00479490: b9d0f4ea01   mov      ecx, 0x1eaf4d0
00479495: e9a6dc1700   jmp      0x5f7140
0047949a: cc           int3     
0047949b: cc           int3     
0047949c: cc           int3     
0047949d: cc           int3     
0047949e: cc           int3     
0047949f: cc           int3     
004794a0: 6a24         push     0x24
004794a2: 68d8e38b01   push     0x18be3d8
004794a7: b9f0bbd501   mov      ecx, 0x1d5bbf0
004794ac: e80fae0d00   call     0x5542c0
004794b1: 68e0e48701   push     0x187e4e0
004794b6: e899a12701   call     0x16f3654
004794bb: 59           pop      ecx

; === 111 | 0x479437 | ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2 ===
00479437: 68c4178e01   push     0x18e17c4
0047943c: e84feb1f01   call     0x1677f90
00479441: 83c40c       add      esp, 0xc
00479444: a3fcf4ea01   mov      dword ptr [0x1eaf4fc], eax
00479449: c3           ret      
0047944a: cc           int3     
0047944b: cc           int3     
0047944c: cc           int3     
0047944d: cc           int3     
0047944e: cc           int3     
0047944f: cc           int3     
00479450: 6a02         push     2
00479452: 6808bcd501   push     0x1d5bc08
00479457: 6870178e01   push     0x18e1770
0047945c: e8efea1f01   call     0x1677f50
00479461: 83c40c       add      esp, 0xc
00479464: a3f4f4ea01   mov      dword ptr [0x1eaf4f4], eax
00479469: c3           ret      
0047946a: cc           int3     
0047946b: cc           int3     
0047946c: cc           int3     
0047946d: cc           int3     
0047946e: cc           int3     
0047946f: cc           int3     
00479470: 6a01         push     1
00479472: 6810bcd501   push     0x1d5bc10
00479477: 689c178e01   push     0x18e179c
0047947c: e8cfea1f01   call     0x1677f50
00479481: 83c40c       add      esp, 0xc
00479484: a3f8f4ea01   mov      dword ptr [0x1eaf4f8], eax
00479489: c3           ret      
0047948a: cc           int3     
0047948b: cc           int3     
0047948c: cc           int3     
0047948d: cc           int3     
0047948e: cc           int3     
0047948f: cc           int3     
00479490: b9d0f4ea01   mov      ecx, 0x1eaf4d0
00479495: e9a6dc1700   jmp      0x5f7140
0047949a: cc           int3     
0047949b: cc           int3     
0047949c: cc           int3     
0047949d: cc           int3     
0047949e: cc           int3     
0047949f: cc           int3     
004794a0: 6a24         push     0x24
004794a2: 68d8e38b01   push     0x18be3d8
004794a7: b9f0bbd501   mov      ecx, 0x1d5bbf0
004794ac: e80fae0d00   call     0x5542c0
004794b1: 68e0e48701   push     0x187e4e0
004794b6: e899a12701   call     0x16f3654
004794bb: 59           pop      ecx
004794bc: c3           ret      
004794bd: cc           int3     
004794be: cc           int3     
004794bf: cc           int3     
004794c0: b90cf5ea01   mov      ecx, 0x1eaf50c
004794c5: e976dc1700   jmp      0x5f7140
004794ca: cc           int3     
004794cb: cc           int3     
004794cc: cc           int3     
004794cd: cc           int3     
004794ce: cc           int3     
004794cf: cc           int3     
004794d0: 6a24         push     0x24
004794d2: 68d8e38b01   push     0x18be3d8
004794d7: b938bcd501   mov      ecx, 0x1d5bc38

; === 112 | 0x479457 | ReportReplicatorJoinDataItemStatsToInflux ===
00479457: 6870178e01   push     0x18e1770
0047945c: e8efea1f01   call     0x1677f50
00479461: 83c40c       add      esp, 0xc
00479464: a3f4f4ea01   mov      dword ptr [0x1eaf4f4], eax
00479469: c3           ret      
0047946a: cc           int3     
0047946b: cc           int3     
0047946c: cc           int3     
0047946d: cc           int3     
0047946e: cc           int3     
0047946f: cc           int3     
00479470: 6a01         push     1
00479472: 6810bcd501   push     0x1d5bc10
00479477: 689c178e01   push     0x18e179c
0047947c: e8cfea1f01   call     0x1677f50
00479481: 83c40c       add      esp, 0xc
00479484: a3f8f4ea01   mov      dword ptr [0x1eaf4f8], eax
00479489: c3           ret      
0047948a: cc           int3     
0047948b: cc           int3     
0047948c: cc           int3     
0047948d: cc           int3     
0047948e: cc           int3     
0047948f: cc           int3     
00479490: b9d0f4ea01   mov      ecx, 0x1eaf4d0
00479495: e9a6dc1700   jmp      0x5f7140
0047949a: cc           int3     
0047949b: cc           int3     
0047949c: cc           int3     
0047949d: cc           int3     
0047949e: cc           int3     
0047949f: cc           int3     
004794a0: 6a24         push     0x24
004794a2: 68d8e38b01   push     0x18be3d8
004794a7: b9f0bbd501   mov      ecx, 0x1d5bbf0
004794ac: e80fae0d00   call     0x5542c0
004794b1: 68e0e48701   push     0x187e4e0
004794b6: e899a12701   call     0x16f3654
004794bb: 59           pop      ecx
004794bc: c3           ret      
004794bd: cc           int3     
004794be: cc           int3     
004794bf: cc           int3     
004794c0: b90cf5ea01   mov      ecx, 0x1eaf50c
004794c5: e976dc1700   jmp      0x5f7140
004794ca: cc           int3     
004794cb: cc           int3     
004794cc: cc           int3     
004794cd: cc           int3     
004794ce: cc           int3     
004794cf: cc           int3     
004794d0: 6a24         push     0x24
004794d2: 68d8e38b01   push     0x18be3d8
004794d7: b938bcd501   mov      ecx, 0x1d5bc38
004794dc: e8dfad0d00   call     0x5542c0
004794e1: 6840e58701   push     0x187e540
004794e6: e869a12701   call     0x16f3654
004794eb: 59           pop      ecx
004794ec: c3           ret      
004794ed: cc           int3     
004794ee: cc           int3     
004794ef: cc           int3     
004794f0: b92cf5ea01   mov      ecx, 0x1eaf52c
004794f5: e946dc1700   jmp      0x5f7140
004794fa: cc           int3     

; === 113 | 0x4799d7 | JoinDataCompressionLevel ===
004799d7: 6824348e01   push     0x18e3424
004799dc: e8afe51f01   call     0x1677f90
004799e1: 83c40c       add      esp, 0xc
004799e4: a348f9ea01   mov      dword ptr [0x1eaf948], eax
004799e9: c3           ret      
004799ea: cc           int3     
004799eb: cc           int3     
004799ec: cc           int3     
004799ed: cc           int3     
004799ee: cc           int3     
004799ef: cc           int3     
004799f0: 6a02         push     2
004799f2: 689cbed501   push     0x1d5be9c
004799f7: 6844358e01   push     0x18e3544
004799fc: e88fe51f01   call     0x1677f90
00479a01: 83c40c       add      esp, 0xc
00479a04: a36cf9ea01   mov      dword ptr [0x1eaf96c], eax
00479a09: c3           ret      
00479a0a: cc           int3     
00479a0b: cc           int3     
00479a0c: cc           int3     
00479a0d: cc           int3     
00479a0e: cc           int3     
00479a0f: cc           int3     
00479a10: 6a00         push     0
00479a12: 68bc368e01   push     0x18e36bc
00479a17: e844b81f01   call     0x1675260
00479a1c: 83c408       add      esp, 8
00479a1f: a394f9ea01   mov      dword ptr [0x1eaf994], eax
00479a24: c3           ret      
00479a25: cc           int3     
00479a26: cc           int3     
00479a27: cc           int3     
00479a28: cc           int3     
00479a29: cc           int3     
00479a2a: cc           int3     
00479a2b: cc           int3     
00479a2c: cc           int3     
00479a2d: cc           int3     
00479a2e: cc           int3     
00479a2f: cc           int3     
00479a30: 6a02         push     2
00479a32: 6870bed501   push     0x1d5be70
00479a37: 6840348e01   push     0x18e3440
00479a3c: e84fe51f01   call     0x1677f90
00479a41: 83c40c       add      esp, 0xc
00479a44: a34cf9ea01   mov      dword ptr [0x1eaf94c], eax
00479a49: c3           ret      
00479a4a: cc           int3     
00479a4b: cc           int3     
00479a4c: cc           int3     
00479a4d: cc           int3     
00479a4e: cc           int3     
00479a4f: cc           int3     
00479a50: 6a02         push     2
00479a52: 6810f9ea01   push     0x1eaf910
00479a57: 6868348e01   push     0x18e3468
00479a5c: e82fe51f01   call     0x1677f90
00479a61: 83c40c       add      esp, 0xc
00479a64: a350f9ea01   mov      dword ptr [0x1eaf950], eax
00479a69: c3           ret      
00479a6a: cc           int3     
00479a6b: cc           int3     
00479a6c: cc           int3     
00479a6d: cc           int3     
00479a6e: cc           int3     
00479a6f: cc           int3     
00479a70: 6a01         push     1
00479a72: 6864bed501   push     0x1d5be64
00479a77: 68f8338e01   push     0x18e33f8

; === 114 | 0x48edb7 | CsFilterMessageSignalRateLimitCapacity ===
0048edb7: 681cfe9201   push     0x192fe1c
0048edbc: e8cf911e01   call     0x1677f90
0048edc1: 83c40c       add      esp, 0xc
0048edc4: a3041cee01   mov      dword ptr [0x1ee1c04], eax
0048edc9: c3           ret      
0048edca: cc           int3     
0048edcb: cc           int3     
0048edcc: cc           int3     
0048edcd: cc           int3     
0048edce: cc           int3     
0048edcf: cc           int3     
0048edd0: 6a02         push     2
0048edd2: 68681bee01   push     0x1ee1b68
0048edd7: 68f4fd9201   push     0x192fdf4
0048eddc: e8af911e01   call     0x1677f90
0048ede1: 83c40c       add      esp, 0xc
0048ede4: a3001cee01   mov      dword ptr [0x1ee1c00], eax
0048ede9: c3           ret      
0048edea: cc           int3     
0048edeb: cc           int3     
0048edec: cc           int3     
0048eded: cc           int3     
0048edee: cc           int3     
0048edef: cc           int3     
0048edf0: 6a01         push     1
0048edf2: 68bc41d601   push     0x1d641bc
0048edf7: 6868fb9201   push     0x192fb68
0048edfc: e84f911e01   call     0x1677f50
0048ee01: 83c40c       add      esp, 0xc
0048ee04: a3b01bee01   mov      dword ptr [0x1ee1bb0], eax
0048ee09: c3           ret      
0048ee0a: cc           int3     
0048ee0b: cc           int3     
0048ee0c: cc           int3     
0048ee0d: cc           int3     
0048ee0e: cc           int3     
0048ee0f: cc           int3     
0048ee10: 6a01         push     1
0048ee12: 682c42d601   push     0x1d6422c
0048ee17: 680cff9201   push     0x192ff0c
0048ee1c: e82f911e01   call     0x1677f50
0048ee21: 83c40c       add      esp, 0xc
0048ee24: a3241cee01   mov      dword ptr [0x1ee1c24], eax
0048ee29: c3           ret      
0048ee2a: cc           int3     
0048ee2b: cc           int3     
0048ee2c: cc           int3     
0048ee2d: cc           int3     
0048ee2e: cc           int3     
0048ee2f: cc           int3     
0048ee30: 6a01         push     1
0048ee32: 680c41d601   push     0x1d6410c
0048ee37: 68a0fd9201   push     0x192fda0
0048ee3c: e84f911e01   call     0x1677f90
0048ee41: 83c40c       add      esp, 0xc
0048ee44: a3f41bee01   mov      dword ptr [0x1ee1bf4], eax
0048ee49: c3           ret      
0048ee4a: cc           int3     
0048ee4b: cc           int3     
0048ee4c: cc           int3     
0048ee4d: cc           int3     
0048ee4e: cc           int3     
0048ee4f: cc           int3     
0048ee50: 6a01         push     1
0048ee52: 68dc41d601   push     0x1d641dc
0048ee57: 6828fc9201   push     0x192fc28

; === 115 | 0x48edd7 | CsFilterMessageSignalRateLimitDuration ===
0048edd7: 68f4fd9201   push     0x192fdf4
0048eddc: e8af911e01   call     0x1677f90
0048ede1: 83c40c       add      esp, 0xc
0048ede4: a3001cee01   mov      dword ptr [0x1ee1c00], eax
0048ede9: c3           ret      
0048edea: cc           int3     
0048edeb: cc           int3     
0048edec: cc           int3     
0048eded: cc           int3     
0048edee: cc           int3     
0048edef: cc           int3     
0048edf0: 6a01         push     1
0048edf2: 68bc41d601   push     0x1d641bc
0048edf7: 6868fb9201   push     0x192fb68
0048edfc: e84f911e01   call     0x1677f50
0048ee01: 83c40c       add      esp, 0xc
0048ee04: a3b01bee01   mov      dword ptr [0x1ee1bb0], eax
0048ee09: c3           ret      
0048ee0a: cc           int3     
0048ee0b: cc           int3     
0048ee0c: cc           int3     
0048ee0d: cc           int3     
0048ee0e: cc           int3     
0048ee0f: cc           int3     
0048ee10: 6a01         push     1
0048ee12: 682c42d601   push     0x1d6422c
0048ee17: 680cff9201   push     0x192ff0c
0048ee1c: e82f911e01   call     0x1677f50
0048ee21: 83c40c       add      esp, 0xc
0048ee24: a3241cee01   mov      dword ptr [0x1ee1c24], eax
0048ee29: c3           ret      
0048ee2a: cc           int3     
0048ee2b: cc           int3     
0048ee2c: cc           int3     
0048ee2d: cc           int3     
0048ee2e: cc           int3     
0048ee2f: cc           int3     
0048ee30: 6a01         push     1
0048ee32: 680c41d601   push     0x1d6410c
0048ee37: 68a0fd9201   push     0x192fda0
0048ee3c: e84f911e01   call     0x1677f90
0048ee41: 83c40c       add      esp, 0xc
0048ee44: a3f41bee01   mov      dword ptr [0x1ee1bf4], eax
0048ee49: c3           ret      
0048ee4a: cc           int3     
0048ee4b: cc           int3     
0048ee4c: cc           int3     
0048ee4d: cc           int3     
0048ee4e: cc           int3     
0048ee4f: cc           int3     
0048ee50: 6a01         push     1
0048ee52: 68dc41d601   push     0x1d641dc
0048ee57: 6828fc9201   push     0x192fc28
0048ee5c: e8ef901e01   call     0x1677f50
0048ee61: 83c40c       add      esp, 0xc
0048ee64: a3c81bee01   mov      dword ptr [0x1ee1bc8], eax
0048ee69: c3           ret      
0048ee6a: cc           int3     
0048ee6b: cc           int3     
0048ee6c: cc           int3     
0048ee6d: cc           int3     
0048ee6e: cc           int3     
0048ee6f: cc           int3     
0048ee70: 6a02         push     2
0048ee72: 68c441d601   push     0x1d641c4
0048ee77: 6888fb9201   push     0x192fb88

; === 116 | 0x4966b7 | DebugLocalRccTicketTesting ===
004966b7: 6810529301   push     0x1935210
004966bc: e88f181e01   call     0x1677f50
004966c1: 83c40c       add      esp, 0xc
004966c4: a38030ee01   mov      dword ptr [0x1ee3080], eax
004966c9: c3           ret      
004966ca: cc           int3     
004966cb: cc           int3     
004966cc: cc           int3     
004966cd: cc           int3     
004966ce: cc           int3     
004966cf: cc           int3     
004966d0: 6a01         push     1
004966d2: 680047d601   push     0x1d64700
004966d7: 687c519301   push     0x193517c
004966dc: e86f181e01   call     0x1677f50
004966e1: 83c40c       add      esp, 0xc
004966e4: a36c30ee01   mov      dword ptr [0x1ee306c], eax
004966e9: c3           ret      
004966ea: cc           int3     
004966eb: cc           int3     
004966ec: cc           int3     
004966ed: cc           int3     
004966ee: cc           int3     
004966ef: cc           int3     
004966f0: 6a01         push     1
004966f2: 686846d601   push     0x1d64668
004966f7: 68e84d9301   push     0x1934de8
004966fc: e84f181e01   call     0x1677f50
00496701: 83c40c       add      esp, 0xc
00496704: a3ec2fee01   mov      dword ptr [0x1ee2fec], eax
00496709: c3           ret      
0049670a: cc           int3     
0049670b: cc           int3     
0049670c: cc           int3     
0049670d: cc           int3     
0049670e: cc           int3     
0049670f: cc           int3     
00496710: 6a02         push     2
00496712: 689846d601   push     0x1d64698
00496717: 68944f9301   push     0x1934f94
0049671c: e82f181e01   call     0x1677f50
00496721: 83c40c       add      esp, 0xc
00496724: a32030ee01   mov      dword ptr [0x1ee3020], eax
00496729: c3           ret      
0049672a: cc           int3     
0049672b: cc           int3     
0049672c: cc           int3     
0049672d: cc           int3     
0049672e: cc           int3     
0049672f: cc           int3     
00496730: 6a01         push     1
00496732: 68f046d601   push     0x1d646f0
00496737: 6840519301   push     0x1935140
0049673c: e80f181e01   call     0x1677f50
00496741: 83c40c       add      esp, 0xc
00496744: a36430ee01   mov      dword ptr [0x1ee3064], eax
00496749: c3           ret      
0049674a: cc           int3     
0049674b: cc           int3     
0049674c: cc           int3     
0049674d: cc           int3     
0049674e: cc           int3     
0049674f: cc           int3     
00496750: 6a01         push     1
00496752: 685845d601   push     0x1d64558
00496757: 680c4e9301   push     0x1934e0c

; === 117 | 0x4a4877 | MaxJoinDataSizeKB ===
004a4877: 68109e9301   push     0x1939e10
004a487c: e82f371d01   call     0x1677fb0
004a4881: 83c40c       add      esp, 0xc
004a4884: a34843ee01   mov      dword ptr [0x1ee4348], eax
004a4889: c3           ret      
004a488a: cc           int3     
004a488b: cc           int3     
004a488c: cc           int3     
004a488d: cc           int3     
004a488e: cc           int3     
004a488f: cc           int3     
004a4890: 6a01         push     1
004a4892: 681042ee01   push     0x1ee4210
004a4897: 68d89d9301   push     0x1939dd8
004a489c: e80f371d01   call     0x1677fb0
004a48a1: 83c40c       add      esp, 0xc
004a48a4: a33c43ee01   mov      dword ptr [0x1ee433c], eax
004a48a9: c3           ret      
004a48aa: cc           int3     
004a48ab: cc           int3     
004a48ac: cc           int3     
004a48ad: cc           int3     
004a48ae: cc           int3     
004a48af: cc           int3     
004a48b0: 6a01         push     1
004a48b2: 687b51d601   push     0x1d6517b
004a48b7: 68289c9301   push     0x1939c28
004a48bc: e8ef361d01   call     0x1677fb0
004a48c1: 83c40c       add      esp, 0xc
004a48c4: a3d042ee01   mov      dword ptr [0x1ee42d0], eax
004a48c9: c3           ret      
004a48ca: cc           int3     
004a48cb: cc           int3     
004a48cc: cc           int3     
004a48cd: cc           int3     
004a48ce: cc           int3     
004a48cf: cc           int3     
004a48d0: 6a01         push     1
004a48d2: 689151d601   push     0x1d65191
004a48d7: 684c9c9301   push     0x1939c4c
004a48dc: e8cf361d01   call     0x1677fb0
004a48e1: 83c40c       add      esp, 0xc
004a48e4: a3d842ee01   mov      dword ptr [0x1ee42d8], eax
004a48e9: c3           ret      
004a48ea: cc           int3     
004a48eb: cc           int3     
004a48ec: cc           int3     
004a48ed: cc           int3     
004a48ee: cc           int3     
004a48ef: cc           int3     
004a48f0: 6a01         push     1
004a48f2: 689051d601   push     0x1d65190
004a48f7: 68389c9301   push     0x1939c38
004a48fc: e8af361d01   call     0x1677fb0
004a4901: 83c40c       add      esp, 0xc
004a4904: a3d442ee01   mov      dword ptr [0x1ee42d4], eax
004a4909: c3           ret      
004a490a: cc           int3     
004a490b: cc           int3     
004a490c: cc           int3     
004a490d: cc           int3     
004a490e: cc           int3     
004a490f: cc           int3     
004a4910: 6a01         push     1
004a4912: 680542ee01   push     0x1ee4205
004a4917: 68e09c9301   push     0x1939ce0

; === 118 | 0x4af797 | CsFilterMessageSignalRatePermyriad ===
004af797: 682c549401   push     0x194542c
004af79c: e8ef871c01   call     0x1677f90
004af7a1: 83c40c       add      esp, 0xc
004af7a4: a320aaee01   mov      dword ptr [0x1eeaa20], eax
004af7a9: c3           ret      
004af7aa: cc           int3     
004af7ab: cc           int3     
004af7ac: cc           int3     
004af7ad: cc           int3     
004af7ae: cc           int3     
004af7af: cc           int3     
004af7b0: 55           push     ebp
004af7b1: 8bec         mov      ebp, esp
004af7b3: 51           push     ecx
004af7b4: 56           push     esi
004af7b5: e876bc8300   call     0xceb430
004af7ba: 6810e8a700   push     0xa7e810
004af7bf: 83ec18       sub      esp, 0x18
004af7c2: 8bf0         mov      esi, eax
004af7c4: 8bcc         mov      ecx, esp
004af7c6: 6a1f         push     0x1f
004af7c8: c7411000000000 mov      dword ptr [ecx + 0x10], 0
004af7cf: c741140f000000 mov      dword ptr [ecx + 0x14], 0xf
004af7d6: 68f4539401   push     0x19453f4
004af7db: c60100       mov      byte ptr [ecx], 0
004af7de: e8dd4a0a00   call     0x5542c0
004af7e3: 8bce         mov      ecx, esi
004af7e5: e806bd8300   call     0xceb4f0
004af7ea: a314aaee01   mov      dword ptr [0x1eeaa14], eax
004af7ef: 5e           pop      esi
004af7f0: 8be5         mov      esp, ebp
004af7f2: 5d           pop      ebp
004af7f3: c3           ret      
004af7f4: cc           int3     
004af7f5: cc           int3     
004af7f6: cc           int3     
004af7f7: cc           int3     
004af7f8: cc           int3     
004af7f9: cc           int3     
004af7fa: cc           int3     
004af7fb: cc           int3     
004af7fc: cc           int3     
004af7fd: cc           int3     
004af7fe: cc           int3     
004af7ff: cc           int3     
004af800: 6a01         push     1
004af802: 687864d601   push     0x1d66478
004af807: 68f4539401   push     0x19453f4
004af80c: e83f871c01   call     0x1677f50
004af811: 83c40c       add      esp, 0xc
004af814: a310aaee01   mov      dword ptr [0x1eeaa10], eax
004af819: c3           ret      
004af81a: cc           int3     
004af81b: cc           int3     
004af81c: cc           int3     
004af81d: cc           int3     
004af81e: cc           int3     
004af81f: cc           int3     
004af820: 6a01         push     1
004af822: 687064d601   push     0x1d66470
004af827: 68e0539401   push     0x19453e0
004af82c: e81f871c01   call     0x1677f50
004af831: 83c40c       add      esp, 0xc
004af834: a30caaee01   mov      dword ptr [0x1eeaa0c], eax
004af839: c3           ret      

; === 119 | 0x4b23e7 | GroupTeleportJoinDataOverWrite ===
004b23e7: 6884949401   push     0x1949484
004b23ec: e85f5b1c01   call     0x1677f50
004b23f1: 83c40c       add      esp, 0xc
004b23f4: a314b5ee01   mov      dword ptr [0x1eeb514], eax
004b23f9: c3           ret      
004b23fa: cc           int3     
004b23fb: cc           int3     
004b23fc: cc           int3     
004b23fd: cc           int3     
004b23fe: cc           int3     
004b23ff: cc           int3     
004b2400: 6a02         push     2
004b2402: 687066d601   push     0x1d66670
004b2407: 68c8949401   push     0x19494c8
004b240c: e83f5b1c01   call     0x1677f50
004b2411: 83c40c       add      esp, 0xc
004b2414: a31cb5ee01   mov      dword ptr [0x1eeb51c], eax
004b2419: c3           ret      
004b241a: cc           int3     
004b241b: cc           int3     
004b241c: cc           int3     
004b241d: cc           int3     
004b241e: cc           int3     
004b241f: cc           int3     
004b2420: 6a02         push     2
004b2422: 68e4b4ee01   push     0x1eeb4e4
004b2427: 6838949401   push     0x1949438
004b242c: e85f5b1c01   call     0x1677f90
004b2431: 83c40c       add      esp, 0xc
004b2434: a30cb5ee01   mov      dword ptr [0x1eeb50c], eax
004b2439: c3           ret      
004b243a: cc           int3     
004b243b: cc           int3     
004b243c: cc           int3     
004b243d: cc           int3     
004b243e: cc           int3     
004b243f: cc           int3     
004b2440: 6a02         push     2
004b2442: 68e8b4ee01   push     0x1eeb4e8
004b2447: 6844959401   push     0x1949544
004b244c: e83f5b1c01   call     0x1677f90
004b2451: 83c40c       add      esp, 0xc
004b2454: a32cb5ee01   mov      dword ptr [0x1eeb52c], eax
004b2459: c3           ret      
004b245a: cc           int3     
004b245b: cc           int3     
004b245c: cc           int3     
004b245d: cc           int3     
004b245e: cc           int3     
004b245f: cc           int3     
004b2460: 6a02         push     2
004b2462: 68b465d601   push     0x1d665b4
004b2467: 68d0939401   push     0x19493d0
004b246c: e81f5b1c01   call     0x1677f90
004b2471: 83c40c       add      esp, 0xc
004b2474: a300b5ee01   mov      dword ptr [0x1eeb500], eax
004b2479: c3           ret      
004b247a: cc           int3     
004b247b: cc           int3     
004b247c: cc           int3     
004b247d: cc           int3     
004b247e: cc           int3     
004b247f: cc           int3     
004b2480: 6a01         push     1
004b2482: 688066d601   push     0x1d66680
004b2487: 6808959401   push     0x1949508

; === 120 | 0x4c6302 | Ticket ===
004c6302: 68b46b9501   push     0x1956bb4
004c6307: b93c74d601   mov      ecx, 0x1d6743c
004c630c: e8afdf0800   call     0x5542c0
004c6311: 68b0f08801   push     0x188f0b0
004c6316: e839d32201   call     0x16f3654
004c631b: 59           pop      ecx
004c631c: c3           ret      
004c631d: cc           int3     
004c631e: cc           int3     
004c631f: cc           int3     
004c6320: 6a0c         push     0xc
004c6322: 689c6b9501   push     0x1956b9c
004c6327: b9f473d601   mov      ecx, 0x1d673f4
004c632c: e88fdf0800   call     0x5542c0
004c6331: 6810f18801   push     0x188f110
004c6336: e819d32201   call     0x16f3654
004c633b: 59           pop      ecx
004c633c: c3           ret      
004c633d: cc           int3     
004c633e: cc           int3     
004c633f: cc           int3     
004c6340: 6a04         push     4
004c6342: 68ac6b9501   push     0x1956bac
004c6347: b90c74d601   mov      ecx, 0x1d6740c
004c634c: e86fdf0800   call     0x5542c0
004c6351: 6870f18801   push     0x188f170
004c6356: e8f9d22201   call     0x16f3654
004c635b: 59           pop      ecx
004c635c: c3           ret      
004c635d: cc           int3     
004c635e: cc           int3     
004c635f: cc           int3     
004c6360: 6a05         push     5
004c6362: 68cc029501   push     0x19502cc
004c6367: b92474d601   mov      ecx, 0x1d67424
004c636c: e84fdf0800   call     0x5542c0
004c6371: 68d0f18801   push     0x188f1d0
004c6376: e8d9d22201   call     0x16f3654
004c637b: 59           pop      ecx
004c637c: c3           ret      
004c637d: cc           int3     
004c637e: cc           int3     
004c637f: cc           int3     
004c6380: 6a06         push     6
004c6382: 687c6b9501   push     0x1956b7c
004c6387: b9ac73d601   mov      ecx, 0x1d673ac
004c638c: e82fdf0800   call     0x5542c0
004c6391: 6830f28801   push     0x188f230
004c6396: e8b9d22201   call     0x16f3654
004c639b: 59           pop      ecx
004c639c: c3           ret      
004c639d: cc           int3     
004c639e: cc           int3     
004c639f: cc           int3     
004c63a0: 6a08         push     8
004c63a2: 68846b9501   push     0x1956b84

; === 121 | 0x4d473e | ticket= ===
004d473e: 68e0e39501   push     0x195e3e0
004d4743: b9207fd601   mov      ecx, 0x1d67f20
004d4748: c645fc02     mov      byte ptr [ebp - 4], 2
004d474c: c705307fd60100000000 mov      dword ptr [0x1d67f30], 0
004d4756: c705347fd6010f000000 mov      dword ptr [0x1d67f34], 0xf
004d4760: c605207fd60100 mov      byte ptr [0x1d67f20], 0
004d4767: e854fb0700   call     0x5542c0
004d476c: 6810258901   push     0x1892510
004d4771: e8deee2101   call     0x16f3654
004d4776: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
004d4779: 83c404       add      esp, 4
004d477c: 64890d00000000 mov      dword ptr fs:[0], ecx
004d4783: 8be5         mov      esp, ebp
004d4785: 5d           pop      ebp
004d4786: c3           ret      
004d4787: cc           int3     
004d4788: cc           int3     
004d4789: cc           int3     
004d478a: cc           int3     
004d478b: cc           int3     
004d478c: cc           int3     
004d478d: cc           int3     
004d478e: cc           int3     
004d478f: cc           int3     
004d4790: 68d0dd6600   push     0x66ddd0
004d4795: b9406def01   mov      ecx, 0x1ef6d40
004d479a: e881d63b00   call     0x891e20
004d479f: c3           ret      
004d47a0: 55           push     ebp
004d47a1: 8bec         mov      ebp, esp
004d47a3: 6aff         push     -1
004d47a5: 6823158001   push     0x1801523
004d47aa: 64a100000000 mov      eax, dword ptr fs:[0]
004d47b0: 50           push     eax
004d47b1: 64892500000000 mov      dword ptr fs:[0], esp
004d47b8: 81ecf4000000 sub      esp, 0xf4
004d47be: 56           push     esi
004d47bf: c745dc00000000 mov      dword ptr [ebp - 0x24], 0
004d47c6: c645d801     mov      byte ptr [ebp - 0x28], 1
004d47ca: e881ad7000   call     0xbdf550
004d47cf: f30f7e45d8   movq     xmm0, qword ptr [ebp - 0x28]
004d47d4: 83ec0c       sub      esp, 0xc
004d47d7: 8bcc         mov      ecx, esp
004d47d9: 6a00         push     0
004d47db: 660fd601     movq     qword ptr [ecx], xmm0
004d47df: 688c2a1302   push     0x2132a8c

; === 122 | 0x50d502 | signalR ===
0050d502: 68f0569901   push     0x19956f0
0050d507: b9e8ddd601   mov      ecx, 0x1d6dde8
0050d50c: e8af6d0400   call     0x5542c0
0050d511: 6810048a01   push     0x18a0410
0050d516: e839611e01   call     0x16f3654
0050d51b: 59           pop      ecx
0050d51c: c3           ret      
0050d51d: cc           int3     
0050d51e: cc           int3     
0050d51f: cc           int3     
0050d520: 6a02         push     2
0050d522: 68e8ddd601   push     0x1d6dde8
0050d527: 6800559901   push     0x1995500
0050d52c: e89faa1601   call     0x1677fd0
0050d531: 83c40c       add      esp, 0xc
0050d534: a3d878f101   mov      dword ptr [0x1f178d8], eax
0050d539: c3           ret      
0050d53a: cc           int3     
0050d53b: cc           int3     
0050d53c: cc           int3     
0050d53d: cc           int3     
0050d53e: cc           int3     
0050d53f: cc           int3     
0050d540: 6a65         push     0x65
0050d542: 6888569901   push     0x1995688
0050d547: b9d0ddd601   mov      ecx, 0x1d6ddd0
0050d54c: e86f6d0400   call     0x5542c0
0050d551: 6870048a01   push     0x18a0470
0050d556: e8f9601e01   call     0x16f3654
0050d55b: 59           pop      ecx
0050d55c: c3           ret      
0050d55d: cc           int3     
0050d55e: cc           int3     
0050d55f: cc           int3     
0050d560: 6a02         push     2
0050d562: 68d0ddd601   push     0x1d6ddd0
0050d567: 68e4549901   push     0x19954e4
0050d56c: e85faa1601   call     0x1677fd0
0050d571: 83c40c       add      esp, 0xc
0050d574: a3d478f101   mov      dword ptr [0x1f178d4], eax
0050d579: c3           ret      
0050d57a: cc           int3     
0050d57b: cc           int3     
0050d57c: cc           int3     
0050d57d: cc           int3     
0050d57e: cc           int3     
0050d57f: cc           int3     
0050d580: 6a01         push     1
0050d582: 68c478f101   push     0x1f178c4
0050d587: 68a4549901   push     0x19954a4
0050d58c: e81faa1601   call     0x1677fb0
0050d591: 83c40c       add      esp, 0xc
0050d594: a3c878f101   mov      dword ptr [0x1f178c8], eax
0050d599: c3           ret      
0050d59a: cc           int3     
0050d59b: cc           int3     
0050d59c: cc           int3     
0050d59d: cc           int3     
0050d59e: cc           int3     
0050d59f: cc           int3     
0050d5a0: 6a01         push     1
0050d5a2: 68c0ddd601   push     0x1d6ddc0

; === 123 | 0x50f2d5 | Ticket ===
0050f2d5: 68b46b9501   push     0x1956bb4
0050f2da: 0f1100       movups   xmmword ptr [eax], xmm0
0050f2dd: e8aea18f00   call     0xe09490
0050f2e2: 68100a8a01   push     0x18a0a10
0050f2e7: e868431e01   call     0x16f3654
0050f2ec: 83c404       add      esp, 4
0050f2ef: 8be5         mov      esp, ebp
0050f2f1: 5d           pop      ebp
0050f2f2: 8be3         mov      esp, ebx
0050f2f4: 5b           pop      ebx
0050f2f5: c3           ret      
0050f2f6: cc           int3     
0050f2f7: cc           int3     
0050f2f8: cc           int3     
0050f2f9: cc           int3     
0050f2fa: cc           int3     
0050f2fb: cc           int3     
0050f2fc: cc           int3     
0050f2fd: cc           int3     
0050f2fe: cc           int3     
0050f2ff: cc           int3     
0050f300: 6a01         push     1
0050f302: 6a00         push     0
0050f304: 83ec10       sub      esp, 0x10
0050f307: b91888f101   mov      ecx, 0x1f18818
0050f30c: 8bc4         mov      eax, esp
0050f30e: 6a00         push     0
0050f310: 68e0bde000   push     0xe0bde0
0050f315: 6a00         push     0
0050f317: 68e0b1d000   push     0xd0b1e0
0050f31c: 6808709901   push     0x1997008
0050f321: 6820709901   push     0x1997020
0050f326: c60000       mov      byte ptr [eax], 0
0050f329: c7400400000000 mov      dword ptr [eax + 4], 0
0050f330: c7400800000000 mov      dword ptr [eax + 8], 0
0050f337: c7400c1f000000 mov      dword ptr [eax + 0xc], 0x1f
0050f33e: e81dbf8f00   call     0xe0b260
0050f343: 68900a8a01   push     0x18a0a90
0050f348: e807431e01   call     0x16f3654
0050f34d: 59           pop      ecx
0050f34e: c3           ret      
0050f34f: cc           int3     
0050f350: 55           push     ebp
0050f351: 8bec         mov      ebp, esp
0050f353: 6aff         push     -1
0050f355: 683c7a8201   push     0x1827a3c
0050f35a: 64a100000000 mov      eax, dword ptr fs:[0]
0050f360: 50           push     eax
0050f361: 64892500000000 mov      dword ptr fs:[0], esp
0050f368: 83ec14       sub      esp, 0x14
0050f36b: 56           push     esi
0050f36c: 57           push     edi
0050f36d: c645e000     mov      byte ptr [ebp - 0x20], 0
0050f371: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
0050f378: c745e800000000 mov      dword ptr [ebp - 0x18], 0

; === 124 | 0x546767 | SignalRConnection ===
00546767: 68249aa301   push     0x1a39a24
0054676c: e83f181301   call     0x1677fb0
00546771: 83c40c       add      esp, 0xc
00546774: a3c0d6f601   mov      dword ptr [0x1f6d6c0], eax
00546779: c3           ret      
0054677a: cc           int3     
0054677b: cc           int3     
0054677c: cc           int3     
0054677d: cc           int3     
0054677e: cc           int3     
0054677f: cc           int3     
00546780: 6a02         push     2
00546782: 680083d701   push     0x1d78300
00546787: 68109aa301   push     0x1a39a10
0054678c: e8ff171301   call     0x1677f90
00546791: 83c40c       add      esp, 0xc
00546794: a3c4d6f601   mov      dword ptr [0x1f6d6c4], eax
00546799: c3           ret      
0054679a: cc           int3     
0054679b: cc           int3     
0054679c: cc           int3     
0054679d: cc           int3     
0054679e: cc           int3     
0054679f: cc           int3     
005467a0: e8dbeb1301   call     0x1685380
005467a5: a3c8d6f601   mov      dword ptr [0x1f6d6c8], eax
005467aa: c3           ret      
005467ab: cc           int3     
005467ac: cc           int3     
005467ad: cc           int3     
005467ae: cc           int3     
005467af: cc           int3     
005467b0: e87bef1301   call     0x1685730
005467b5: a3bcd6f601   mov      dword ptr [0x1f6d6bc], eax
005467ba: c3           ret      
005467bb: cc           int3     
005467bc: cc           int3     
005467bd: cc           int3     
005467be: cc           int3     
005467bf: cc           int3     
005467c0: e8bbeb1301   call     0x1685380
005467c5: a3b8d6f601   mov      dword ptr [0x1f6d6b8], eax
005467ca: c3           ret      
005467cb: cc           int3     
005467cc: cc           int3     
005467cd: cc           int3     
005467ce: cc           int3     
005467cf: cc           int3     
005467d0: 6a02         push     2
005467d2: 681083d701   push     0x1d78310
005467d7: 6830cda301   push     0x1a3cd30
005467dc: e86f171301   call     0x1677f50
005467e1: 83c40c       add      esp, 0xc
005467e4: a3e8d6f601   mov      dword ptr [0x1f6d6e8], eax
005467e9: c3           ret      
005467ea: cc           int3     
005467eb: cc           int3     
005467ec: cc           int3     
005467ed: cc           int3     
005467ee: cc           int3     
005467ef: cc           int3     
005467f0: e88beb1301   call     0x1685380
005467f5: a3ecd6f601   mov      dword ptr [0x1f6d6ec], eax
005467fa: c3           ret      
005467fb: cc           int3     
005467fc: cc           int3     
005467fd: cc           int3     
005467fe: cc           int3     
005467ff: cc           int3     
00546800: e82bef1301   call     0x1685730
00546805: a3e4d6f601   mov      dword ptr [0x1f6d6e4], eax
0054680a: c3           ret      

; === 125 | 0x546787 | SignalRRpcQueueSize ===
00546787: 68109aa301   push     0x1a39a10
0054678c: e8ff171301   call     0x1677f90
00546791: 83c40c       add      esp, 0xc
00546794: a3c4d6f601   mov      dword ptr [0x1f6d6c4], eax
00546799: c3           ret      
0054679a: cc           int3     
0054679b: cc           int3     
0054679c: cc           int3     
0054679d: cc           int3     
0054679e: cc           int3     
0054679f: cc           int3     
005467a0: e8dbeb1301   call     0x1685380
005467a5: a3c8d6f601   mov      dword ptr [0x1f6d6c8], eax
005467aa: c3           ret      
005467ab: cc           int3     
005467ac: cc           int3     
005467ad: cc           int3     
005467ae: cc           int3     
005467af: cc           int3     
005467b0: e87bef1301   call     0x1685730
005467b5: a3bcd6f601   mov      dword ptr [0x1f6d6bc], eax
005467ba: c3           ret      
005467bb: cc           int3     
005467bc: cc           int3     
005467bd: cc           int3     
005467be: cc           int3     
005467bf: cc           int3     
005467c0: e8bbeb1301   call     0x1685380
005467c5: a3b8d6f601   mov      dword ptr [0x1f6d6b8], eax
005467ca: c3           ret      
005467cb: cc           int3     
005467cc: cc           int3     
005467cd: cc           int3     
005467ce: cc           int3     
005467cf: cc           int3     
005467d0: 6a02         push     2
005467d2: 681083d701   push     0x1d78310
005467d7: 6830cda301   push     0x1a3cd30
005467dc: e86f171301   call     0x1677f50
005467e1: 83c40c       add      esp, 0xc
005467e4: a3e8d6f601   mov      dword ptr [0x1f6d6e8], eax
005467e9: c3           ret      
005467ea: cc           int3     
005467eb: cc           int3     
005467ec: cc           int3     
005467ed: cc           int3     
005467ee: cc           int3     
005467ef: cc           int3     
005467f0: e88beb1301   call     0x1685380
005467f5: a3ecd6f601   mov      dword ptr [0x1f6d6ec], eax
005467fa: c3           ret      
005467fb: cc           int3     
005467fc: cc           int3     
005467fd: cc           int3     
005467fe: cc           int3     
005467ff: cc           int3     
00546800: e82bef1301   call     0x1685730
00546805: a3e4d6f601   mov      dword ptr [0x1f6d6e4], eax
0054680a: c3           ret      
0054680b: cc           int3     
0054680c: cc           int3     
0054680d: cc           int3     
0054680e: cc           int3     
0054680f: cc           int3     
00546810: e86beb1301   call     0x1685380
00546815: a3e0d6f601   mov      dword ptr [0x1f6d6e0], eax
0054681a: c3           ret      
0054681b: cc           int3     
0054681c: cc           int3     
0054681d: cc           int3     
0054681e: cc           int3     
0054681f: cc           int3     
00546820: 6a3e         push     0x3e
00546822: 6844d7a301   push     0x1a3d744
00546827: b9a083d701   mov      ecx, 0x1d783a0

; === 126 | 0x5467d7 | SignalrRbxHttp ===
005467d7: 6830cda301   push     0x1a3cd30
005467dc: e86f171301   call     0x1677f50
005467e1: 83c40c       add      esp, 0xc
005467e4: a3e8d6f601   mov      dword ptr [0x1f6d6e8], eax
005467e9: c3           ret      
005467ea: cc           int3     
005467eb: cc           int3     
005467ec: cc           int3     
005467ed: cc           int3     
005467ee: cc           int3     
005467ef: cc           int3     
005467f0: e88beb1301   call     0x1685380
005467f5: a3ecd6f601   mov      dword ptr [0x1f6d6ec], eax
005467fa: c3           ret      
005467fb: cc           int3     
005467fc: cc           int3     
005467fd: cc           int3     
005467fe: cc           int3     
005467ff: cc           int3     
00546800: e82bef1301   call     0x1685730
00546805: a3e4d6f601   mov      dword ptr [0x1f6d6e4], eax
0054680a: c3           ret      
0054680b: cc           int3     
0054680c: cc           int3     
0054680d: cc           int3     
0054680e: cc           int3     
0054680f: cc           int3     
00546810: e86beb1301   call     0x1685380
00546815: a3e0d6f601   mov      dword ptr [0x1f6d6e0], eax
0054681a: c3           ret      
0054681b: cc           int3     
0054681c: cc           int3     
0054681d: cc           int3     
0054681e: cc           int3     
0054681f: cc           int3     
00546820: 6a3e         push     0x3e
00546822: 6844d7a301   push     0x1a3d744
00546827: b9a083d701   mov      ecx, 0x1d783a0
0054682c: e88fda0000   call     0x5542c0
00546831: 68e0cd8a01   push     0x18acde0
00546836: e819ce1a01   call     0x16f3654
0054683b: 59           pop      ecx
0054683c: c3           ret      
0054683d: cc           int3     
0054683e: cc           int3     
0054683f: cc           int3     
00546840: 6840ce8a01   push     0x18ace40
00546845: e80ace1a01   call     0x16f3654
0054684a: 59           pop      ecx
0054684b: c3           ret      
0054684c: cc           int3     
0054684d: cc           int3     
0054684e: cc           int3     
0054684f: cc           int3     
00546850: 6a07         push     7
00546852: 68d0d9a301   push     0x1a3d9d0
00546857: b97884d701   mov      ecx, 0x1d78478
0054685c: e85fda0000   call     0x5542c0
00546861: 6890ce8a01   push     0x18ace90
00546866: e8e9cd1a01   call     0x16f3654
0054686b: 59           pop      ecx
0054686c: c3           ret      
0054686d: cc           int3     
0054686e: cc           int3     
0054686f: cc           int3     
00546870: 6a06         push     6
00546872: 68a0d69501   push     0x195d6a0
00546877: b91884d701   mov      ecx, 0x1d78418

; === 127 | 0x5edcb7 | NetworkClient ===
005edcb7: 682c8d8c01   push     0x18c8d2c
005edcbc: 0f1101       movups   xmmword ptr [ecx], xmm0
005edcbf: 50           push     eax
005edcc0: b9d894ea01   mov      ecx, 0x1ea94d8
005edcc5: e8f6422a00   call     0x891fc0
005edcca: c705e096ea01208d8c01 mov      dword ptr [0x1ea96e0], 0x18c8d20
005edcd4: 68e096ea01   push     0x1ea96e0
005edcd9: 68d894ea01   push     0x1ea94d8
005edcde: c645fc02     mov      byte ptr [ebp - 4], 2
005edce2: e8e95e2a00   call     0x893bd0
005edce7: 6880c18701   push     0x187c180
005edcec: e863591001   call     0x16f3654
005edcf1: 68e896ea01   push     0x1ea96e8
005edcf6: e8c45a1001   call     0x16f37bf
005edcfb: 83c410       add      esp, 0x10
005edcfe: e94dffffff   jmp      0x5edc50
005edd03: cc           int3     
005edd04: cc           int3     
005edd05: cc           int3     
005edd06: cc           int3     
005edd07: cc           int3     
005edd08: cc           int3     
005edd09: cc           int3     
005edd0a: cc           int3     
005edd0b: cc           int3     
005edd0c: cc           int3     
005edd0d: cc           int3     
005edd0e: cc           int3     
005edd0f: cc           int3     
005edd10: 55           push     ebp
005edd11: 8bec         mov      ebp, esp
005edd13: 64a100000000 mov      eax, dword ptr fs:[0]
005edd19: 6aff         push     -1
005edd1b: 68ecbc7901   push     0x179bcec
005edd20: 50           push     eax
005edd21: 64892500000000 mov      dword ptr fs:[0], esp
005edd28: 83ec10       sub      esp, 0x10
005edd2b: a188a3ea01   mov      eax, dword ptr [0x1eaa388]
005edd30: 85c0         test     eax, eax
005edd32: 752b         jne      0x5edd5f
005edd34: 64a12c000000 mov      eax, dword ptr fs:[0x2c]
005edd3a: 8b0dd0371102 mov      ecx, dword ptr [0x21137d0]
005edd40: 8b0c88       mov      ecx, dword ptr [eax + ecx*4]
005edd43: a198a5ea01   mov      eax, dword ptr [0x1eaa598]
005edd48: 3b8134000000 cmp      eax, dword ptr [ecx + 0x34]
005edd4e: 7f1d         jg       0x5edd6d
005edd50: c70588a3ea0190a3ea01 mov      dword ptr [0x1eaa388], 0x1eaa390
005edd5a: b890a3ea01   mov      eax, 0x1eaa390

; === 128 | 0x5ee2f7 | NetworkServer ===
005ee2f7: 684c8d8c01   push     0x18c8d4c
005ee2fc: 0f1101       movups   xmmword ptr [ecx], xmm0
005ee2ff: 50           push     eax
005ee300: b9f896ea01   mov      ecx, 0x1ea96f8
005ee305: e8b63c2a00   call     0x891fc0
005ee30a: c7050099ea01408d8c01 mov      dword ptr [0x1ea9900], 0x18c8d40
005ee314: 680099ea01   push     0x1ea9900
005ee319: 68f896ea01   push     0x1ea96f8
005ee31e: c645fc02     mov      byte ptr [ebp - 4], 2
005ee322: e8a9582a00   call     0x893bd0
005ee327: 6840c28701   push     0x187c240
005ee32c: e823531001   call     0x16f3654
005ee331: 680899ea01   push     0x1ea9908
005ee336: e884541001   call     0x16f37bf
005ee33b: 83c410       add      esp, 0x10
005ee33e: e94dffffff   jmp      0x5ee290
005ee343: cc           int3     
005ee344: cc           int3     
005ee345: cc           int3     
005ee346: cc           int3     
005ee347: cc           int3     
005ee348: cc           int3     
005ee349: cc           int3     
005ee34a: cc           int3     
005ee34b: cc           int3     
005ee34c: cc           int3     
005ee34d: cc           int3     
005ee34e: cc           int3     
005ee34f: cc           int3     
005ee350: 55           push     ebp
005ee351: 8bec         mov      ebp, esp
005ee353: 64a100000000 mov      eax, dword ptr fs:[0]
005ee359: 6aff         push     -1
005ee35b: 68dcbd7901   push     0x179bddc
005ee360: 50           push     eax
005ee361: 64892500000000 mov      dword ptr fs:[0], esp
005ee368: 83ec10       sub      esp, 0x10
005ee36b: a170a1ea01   mov      eax, dword ptr [0x1eaa170]
005ee370: 85c0         test     eax, eax
005ee372: 752b         jne      0x5ee39f
005ee374: 64a12c000000 mov      eax, dword ptr fs:[0x2c]
005ee37a: 8b0dd0371102 mov      ecx, dword ptr [0x21137d0]
005ee380: 8b0c88       mov      ecx, dword ptr [eax + ecx*4]
005ee383: a180a3ea01   mov      eax, dword ptr [0x1eaa380]
005ee388: 3b8134000000 cmp      eax, dword ptr [ecx + 0x34]
005ee38e: 7f1d         jg       0x5ee3ad
005ee390: c70570a1ea0178a1ea01 mov      dword ptr [0x1eaa170], 0x1eaa178
005ee39a: b878a1ea01   mov      eax, 0x1eaa178

; === 129 | 0x61a09e | Join Data Items ===
0061a09e: b8d4aa8c01   mov      eax, 0x18caad4
0061a0a3: 5d           pop      ebp
0061a0a4: c3           ret      
0061a0a5: b8e4aa8c01   mov      eax, 0x18caae4
0061a0aa: 5d           pop      ebp
0061a0ab: c3           ret      
0061a0ac: b800ab8c01   mov      eax, 0x18cab00
0061a0b1: 5d           pop      ebp
0061a0b2: c3           ret      
0061a0b3: b814ab8c01   mov      eax, 0x18cab14
0061a0b8: 5d           pop      ebp
0061a0b9: c3           ret      
0061a0ba: b82cab8c01   mov      eax, 0x18cab2c
0061a0bf: 5d           pop      ebp
0061a0c0: c3           ret      
0061a0c1: b844ab8c01   mov      eax, 0x18cab44
0061a0c6: 5d           pop      ebp
0061a0c7: c3           ret      
0061a0c8: b850ab8c01   mov      eax, 0x18cab50
0061a0cd: 5d           pop      ebp
0061a0ce: c3           ret      
0061a0cf: b884aa8c01   mov      eax, 0x18caa84
0061a0d4: 5d           pop      ebp
0061a0d5: c3           ret      
0061a0d6: b85cab8c01   mov      eax, 0x18cab5c
0061a0db: 5d           pop      ebp
0061a0dc: c3           ret      
0061a0dd: b878ab8c01   mov      eax, 0x18cab78
0061a0e2: 5d           pop      ebp
0061a0e3: c3           ret      
0061a0e4: b890ab8c01   mov      eax, 0x18cab90
0061a0e9: 5d           pop      ebp
0061a0ea: c3           ret      
0061a0eb: b8a4ab8c01   mov      eax, 0x18caba4
0061a0f0: 5d           pop      ebp
0061a0f1: c3           ret      
0061a0f2: b8b8ab8c01   mov      eax, 0x18cabb8
0061a0f7: 5d           pop      ebp
0061a0f8: c3           ret      
0061a0f9: b8d4ab8c01   mov      eax, 0x18cabd4
0061a0fe: 5d           pop      ebp
0061a0ff: c3           ret      
0061a100: 66a061006da0 mov      al, byte ptr [0xa06d0061]
0061a106: 61           popal    
0061a107: 0074a061     add      byte ptr [eax + 0x61], dh
0061a10b: 007ba0       add      byte ptr [ebx - 0x60], bh
0061a10e: 61           popal    
0061a10f: 0082a06100cf add      byte ptr [edx - 0x30ff9e60], al
0061a115: a06100cfa0   mov      al, byte ptr [0xa0cf0061]
0061a11a: 61           popal    
0061a11b: 0089a0610090 add      byte ptr [ecx - 0x6fff9e60], cl
0061a121: a06100cfa0   mov      al, byte ptr [0xa0cf0061]
0061a126: 61           popal    
0061a127: 0097a061009e add      byte ptr [edi - 0x61ff9e60], dl
0061a12d: a06100a5a0   mov      al, byte ptr [0xa0a50061]
0061a132: 61           popal    
0061a133: 00aca06100b3a0 add      byte ptr [eax - 0x5f4cff9f], ch
0061a13a: 61           popal    
0061a13b: 00baa06100c1 add      byte ptr [edx - 0x3eff9e60], bh
0061a141: a06100c8a0   mov      al, byte ptr [0xa0c80061]

; === 130 | 0x61a0e4 | Join Data Items V2 ===
0061a0e4: b890ab8c01   mov      eax, 0x18cab90
0061a0e9: 5d           pop      ebp
0061a0ea: c3           ret      
0061a0eb: b8a4ab8c01   mov      eax, 0x18caba4
0061a0f0: 5d           pop      ebp
0061a0f1: c3           ret      
0061a0f2: b8b8ab8c01   mov      eax, 0x18cabb8
0061a0f7: 5d           pop      ebp
0061a0f8: c3           ret      
0061a0f9: b8d4ab8c01   mov      eax, 0x18cabd4
0061a0fe: 5d           pop      ebp
0061a0ff: c3           ret      
0061a100: 66a061006da0 mov      al, byte ptr [0xa06d0061]
0061a106: 61           popal    
0061a107: 0074a061     add      byte ptr [eax + 0x61], dh
0061a10b: 007ba0       add      byte ptr [ebx - 0x60], bh
0061a10e: 61           popal    
0061a10f: 0082a06100cf add      byte ptr [edx - 0x30ff9e60], al
0061a115: a06100cfa0   mov      al, byte ptr [0xa0cf0061]
0061a11a: 61           popal    
0061a11b: 0089a0610090 add      byte ptr [ecx - 0x6fff9e60], cl
0061a121: a06100cfa0   mov      al, byte ptr [0xa0cf0061]
0061a126: 61           popal    
0061a127: 0097a061009e add      byte ptr [edi - 0x61ff9e60], dl
0061a12d: a06100a5a0   mov      al, byte ptr [0xa0a50061]
0061a132: 61           popal    
0061a133: 00aca06100b3a0 add      byte ptr [eax - 0x5f4cff9f], ch
0061a13a: 61           popal    
0061a13b: 00baa06100c1 add      byte ptr [edx - 0x3eff9e60], bh
0061a141: a06100c8a0   mov      al, byte ptr [0xa0c80061]
0061a146: 61           popal    
0061a147: 00cf         add      bh, cl
0061a149: a06100d6a0   mov      al, byte ptr [0xa0d60061]
0061a14e: 61           popal    
0061a14f: 00dd         add      ch, bl
0061a151: a06100f9a0   mov      al, byte ptr [0xa0f90061]
0061a156: 61           popal    
0061a157: 00e4         add      ah, ah
0061a159: a06100eba0   mov      al, byte ptr [0xa0eb0061]
0061a15e: 61           popal    
0061a15f: 00f2         add      dl, dh
0061a161: a06100cccc   mov      al, byte ptr [0xcccc0061]
0061a166: cc           int3     
0061a167: cc           int3     
0061a168: cc           int3     
0061a169: cc           int3     
0061a16a: cc           int3     
0061a16b: cc           int3     
0061a16c: cc           int3     
0061a16d: cc           int3     
0061a16e: cc           int3     
0061a16f: cc           int3     
0061a170: 55           push     ebp
0061a171: 8bec         mov      ebp, esp
0061a173: 83ec08       sub      esp, 8
0061a176: 56           push     esi
0061a177: 57           push     edi
0061a178: ff750c       push     dword ptr [ebp + 0xc]
0061a17b: e8c08c2700   call     0x892e40
0061a180: 8bf0         mov      esi, eax
0061a182: 83c404       add      esp, 4
0061a185: 85f6         test     esi, esi

; === 131 | 0x61bec6 | Error processing ticket, please reconnect ===
0061bec6: 6890cf8c01   push     0x18ccf90
0061becb: eb6a         jmp      0x61bf37
0061becd: 6a28         push     0x28
0061becf: 68bccf8c01   push     0x18ccfbc
0061bed4: eb61         jmp      0x61bf37
0061bed6: 6a22         push     0x22
0061bed8: 68e8cf8c01   push     0x18ccfe8
0061bedd: eb58         jmp      0x61bf37
0061bedf: 6a44         push     0x44
0061bee1: 6810d08c01   push     0x18cd010
0061bee6: eb4f         jmp      0x61bf37
0061bee8: 6a2d         push     0x2d
0061beea: 6858d08c01   push     0x18cd058
0061beef: eb46         jmp      0x61bf37
0061bef1: 6a3d         push     0x3d
0061bef3: 6888d08c01   push     0x18cd088
0061bef8: eb3d         jmp      0x61bf37
0061befa: 6a30         push     0x30
0061befc: 68c8d08c01   push     0x18cd0c8
0061bf01: eb34         jmp      0x61bf37
0061bf03: 6a47         push     0x47
0061bf05: 6800d18c01   push     0x18cd100
0061bf0a: eb2b         jmp      0x61bf37
0061bf0c: 6a38         push     0x38
0061bf0e: 6848d18c01   push     0x18cd148
0061bf13: eb22         jmp      0x61bf37
0061bf15: 6a35         push     0x35
0061bf17: 6884d18c01   push     0x18cd184
0061bf1c: eb19         jmp      0x61bf37
0061bf1e: 6a52         push     0x52
0061bf20: 68c0d18c01   push     0x18cd1c0
0061bf25: eb10         jmp      0x61bf37
0061bf27: 6a1b         push     0x1b
0061bf29: 6814d28c01   push     0x18cd214
0061bf2e: eb07         jmp      0x61bf37
0061bf30: 6a28         push     0x28
0061bf32: 6830d28c01   push     0x18cd230
0061bf37: 8b7508       mov      esi, dword ptr [ebp + 8]
0061bf3a: 8bce         mov      ecx, esi
0061bf3c: c7461000000000 mov      dword ptr [esi + 0x10], 0
0061bf43: c746140f000000 mov      dword ptr [esi + 0x14], 0xf
0061bf4a: c60600       mov      byte ptr [esi], 0
0061bf4d: e86e83f3ff   call     0x5542c0
0061bf52: 8bc6         mov      eax, esi
0061bf54: 5e           pop      esi
0061bf55: 5d           pop      ebp
0061bf56: c3           ret      
0061bf57: 90           nop      
0061bf58: 76be         jbe      0x61bf18
0061bf5a: 61           popal    
0061bf5b: 0082be61008e add      byte ptr [edx - 0x71ff9e42], al
0061bf61: be61009abe   mov      esi, 0xbe9a0061
0061bf66: 61           popal    

; === 132 | 0x61c047 | DuplicateTicket ===
0061c047: 6888cc8c01   push     0x18ccc88
0061c04c: eb73         jmp      0x61c0c1
0061c04e: 6a07         push     7
0061c050: 6898cc8c01   push     0x18ccc98
0061c055: eb6a         jmp      0x61c0c1
0061c057: 6a07         push     7
0061c059: 68a0cc8c01   push     0x18ccca0
0061c05e: eb61         jmp      0x61c0c1
0061c060: 6a10         push     0x10
0061c062: 68a8cc8c01   push     0x18ccca8
0061c067: eb58         jmp      0x61c0c1
0061c069: 6a0a         push     0xa
0061c06b: 68bccc8c01   push     0x18cccbc
0061c070: eb4f         jmp      0x61c0c1
0061c072: 6a0d         push     0xd
0061c074: 68c8cc8c01   push     0x18cccc8
0061c079: eb46         jmp      0x61c0c1
0061c07b: 6a0a         push     0xa
0061c07d: 68d8cc8c01   push     0x18cccd8
0061c082: eb3d         jmp      0x61c0c1
0061c084: 6a07         push     7
0061c086: 68e4cc8c01   push     0x18ccce4
0061c08b: eb34         jmp      0x61c0c1
0061c08d: 6a0e         push     0xe
0061c08f: 68eccc8c01   push     0x18cccec
0061c094: eb2b         jmp      0x61c0c1
0061c096: 6a0d         push     0xd
0061c098: 68fccc8c01   push     0x18cccfc
0061c09d: eb22         jmp      0x61c0c1
0061c09f: 6a06         push     6
0061c0a1: 680ccd8c01   push     0x18ccd0c
0061c0a6: eb19         jmp      0x61c0c1
0061c0a8: 6a0e         push     0xe
0061c0aa: 6814cd8c01   push     0x18ccd14
0061c0af: eb10         jmp      0x61c0c1
0061c0b1: 6a09         push     9
0061c0b3: 6824cd8c01   push     0x18ccd24
0061c0b8: eb07         jmp      0x61c0c1
0061c0ba: 6a04         push     4
0061c0bc: 6830cd8c01   push     0x18ccd30
0061c0c1: 8b7508       mov      esi, dword ptr [ebp + 8]
0061c0c4: 8bce         mov      ecx, esi
0061c0c6: c7461000000000 mov      dword ptr [esi + 0x10], 0
0061c0cd: c746140f000000 mov      dword ptr [esi + 0x14], 0xf
0061c0d4: c60600       mov      byte ptr [esi], 0
0061c0d7: e8e481f3ff   call     0x5542c0
0061c0dc: 8bc6         mov      eax, esi
0061c0de: 5e           pop      esi
0061c0df: 5d           pop      ebp
0061c0e0: c3           ret      
0061c0e1: 0f1f00       nop      dword ptr [eax]
0061c0e4: dcbf6100e8bf fdivr    qword ptr [edi - 0x4017ff9f]
0061c0ea: 61           popal    

; === 133 | 0x61fc89 | JoinDataItem ===
0061fc89: be94af8c01   mov      esi, 0x18caf94
0061fc8e: 0f84c9000000 je       0x61fd5d
0061fc94: 8b07         mov      eax, dword ptr [edi]
0061fc96: 8bcf         mov      ecx, edi
0061fc98: 8b80d4000000 mov      eax, dword ptr [eax + 0xd4]
0061fc9e: ffd0         call     eax
0061fca0: 84c0         test     al, al
0061fca2: 0f84b5000000 je       0x61fd5d
0061fca8: 807d2000     cmp      byte ptr [ebp + 0x20], 0
0061fcac: 0f84a7000000 je       0x61fd59
0061fcb2: 83bfe41d000000 cmp      dword ptr [edi + 0x1de4], 0
0061fcb9: 0f95c0       setne    al
0061fcbc: 50           push     eax
0061fcbd: ff7518       push     dword ptr [ebp + 0x18]
0061fcc0: ff33         push     dword ptr [ebx]
0061fcc2: e859e40b00   call     0x6de120
0061fcc7: 83c40c       add      esp, 0xc
0061fcca: 84c0         test     al, al
0061fccc: 0f8487000000 je       0x61fd59
0061fcd2: 803d0d42ee0100 cmp      byte ptr [0x1ee420d], 0
0061fcd9: c6452001     mov      byte ptr [ebp + 0x20], 1
0061fcdd: 744c         je       0x61fd2b
0061fcdf: 8b0b         mov      ecx, dword ptr [ebx]
0061fce1: 8d45cc       lea      eax, [ebp - 0x34]
0061fce4: 50           push     eax
0061fce5: e896262800   call     0x8a2380
0061fcea: 8bc8         mov      ecx, eax
0061fcec: 83791410     cmp      dword ptr [ecx + 0x14], 0x10
0061fcf0: c645fc02     mov      byte ptr [ebp - 4], 2
0061fcf4: 7202         jb       0x61fcf8
0061fcf6: 8b09         mov      ecx, dword ptr [ecx]
0061fcf8: 837d0c00     cmp      dword ptr [ebp + 0xc], 0
0061fcfc: baccb78c01   mov      edx, 0x18cb7cc
0061fd01: 6a00         push     0
0061fd03: 8bc6         mov      eax, esi
0061fd05: 0f45c2       cmovne   eax, edx
0061fd08: 50           push     eax
0061fd09: 0fb6050d42ee01 movzx    eax, byte ptr [0x1ee420d]
0061fd10: 51           push     ecx
0061fd11: 68e0b78c01   push     0x18cb7e0
0061fd16: 50           push     eax
0061fd17: e874770501   call     0x1677490
0061fd1c: 83c414       add      esp, 0x14
0061fd1f: c645fc01     mov      byte ptr [ebp - 4], 1
0061fd23: 8d4dcc       lea      ecx, [ebp - 0x34]
0061fd26: e8850af3ff   call     0x5507b0
0061fd2b: 8b8fb41d0000 mov      ecx, dword ptr [edi + 0x1db4]

; === 134 | 0x61fd52 | JoinDataItem ===
0061fd52: be94af8c01   mov      esi, 0x18caf94
0061fd57: eb04         jmp      0x61fd5d
0061fd59: c6452000     mov      byte ptr [ebp + 0x20], 0
0061fd5d: 8bcf         mov      ecx, edi
0061fd5f: e8dcf7ffff   call     0x61f540
0061fd64: 84c0         test     al, al
0061fd66: 741a         je       0x61fd82
0061fd68: 807d1c00     cmp      byte ptr [ebp + 0x1c], 0
0061fd6c: 7414         je       0x61fd82
0061fd6e: 8b07         mov      eax, dword ptr [edi]
0061fd70: 8bcf         mov      ecx, edi
0061fd72: 8b80d4000000 mov      eax, dword ptr [eax + 0xd4]
0061fd78: ffd0         call     eax
0061fd7a: 84c0         test     al, al
0061fd7c: 0f859a000000 jne      0x61fe1c
0061fd82: 803d0d42ee0100 cmp      byte ptr [0x1ee420d], 0
0061fd89: 7448         je       0x61fdd3
0061fd8b: 8b0b         mov      ecx, dword ptr [ebx]
0061fd8d: 8d45b4       lea      eax, [ebp - 0x4c]
0061fd90: 50           push     eax
0061fd91: e8ea252800   call     0x8a2380
0061fd96: 83781410     cmp      dword ptr [eax + 0x14], 0x10
0061fd9a: c645fc03     mov      byte ptr [ebp - 4], 3
0061fd9e: 7202         jb       0x61fda2
0061fda0: 8b00         mov      eax, dword ptr [eax]
0061fda2: 837d0c00     cmp      dword ptr [ebp + 0xc], 0
0061fda6: b9ccb78c01   mov      ecx, 0x18cb7cc
0061fdab: 6a00         push     0
0061fdad: 0f45f1       cmovne   esi, ecx
0061fdb0: 56           push     esi
0061fdb1: 50           push     eax
0061fdb2: 0fb6050d42ee01 movzx    eax, byte ptr [0x1ee420d]
0061fdb9: 6838b88c01   push     0x18cb838
0061fdbe: 50           push     eax
0061fdbf: e8cc760501   call     0x1677490
0061fdc4: 83c414       add      esp, 0x14
0061fdc7: c645fc01     mov      byte ptr [ebp - 4], 1
0061fdcb: 8d4db4       lea      ecx, [ebp - 0x4c]
0061fdce: e8dd09f3ff   call     0x5507b0
0061fdd3: 803d10b8d50100 cmp      byte ptr [0x1d5b810], 0
0061fdda: 742c         je       0x61fe08
0061fddc: 837d0c01     cmp      dword ptr [ebp + 0xc], 1
0061fde0: 7526         jne      0x61fe08
0061fde2: ff7524       push     dword ptr [ebp + 0x24]
0061fde5: 8b4514       mov      eax, dword ptr [ebp + 0x14]
0061fde8: 8bb7b41d0000 mov      esi, dword ptr [edi + 0x1db4]
0061fdee: 50           push     eax
0061fdef: 8d45e4       lea      eax, [ebp - 0x1c]
0061fdf2: 50           push     eax

; === 135 | 0x627184 | Replicator::readJoinDataItem() : Procsssing JoinDataItem ===
00627184: 685cc68c01   push     0x18cc65c
00627189: 50           push     eax
0062718a: e821030501   call     0x16774b0
0062718f: 83c40c       add      esp, 0xc
00627192: 8d45a4       lea      eax, [ebp - 0x5c]
00627195: 50           push     eax
00627196: e845b60501   call     0x16827e0
0062719b: 8b4d08       mov      ecx, dword ptr [ebp + 8]
0062719e: 33f6         xor      esi, esi
006271a0: 83c404       add      esp, 4
006271a3: 8975f0       mov      dword ptr [ebp - 0x10], esi
006271a6: 8b5910       mov      ebx, dword ptr [ecx + 0x10]
006271a9: 8b4114       mov      eax, dword ptr [ecx + 0x14]
006271ac: 895de8       mov      dword ptr [ebp - 0x18], ebx
006271af: 8945ac       mov      dword ptr [ebp - 0x54], eax
006271b2: 3bd8         cmp      ebx, eax
006271b4: 0f846f090000 je       0x627b29
006271ba: 660f1f440000 nop      word ptr [eax + eax]
006271c0: 803d0f42ee0100 cmp      byte ptr [0x1ee420f], 0
006271c7: 0f84df000000 je       0x6272ac
006271cd: 8d854cffffff lea      eax, [ebp - 0xb4]
006271d3: 8d4b24       lea      ecx, [ebx + 0x24]
006271d6: 50           push     eax
006271d7: e834233a00   call     0x9c9510
006271dc: 8bf0         mov      esi, eax
006271de: 837e1410     cmp      dword ptr [esi + 0x14], 0x10
006271e2: c745fc00000000 mov      dword ptr [ebp - 4], 0
006271e9: 7202         jb       0x6271ed
006271eb: 8b36         mov      esi, dword ptr [esi]
006271ed: 8d4584       lea      eax, [ebp - 0x7c]
006271f0: 8d4b1c       lea      ecx, [ebx + 0x1c]
006271f3: 50           push     eax
006271f4: e817233a00   call     0x9c9510
006271f9: 83781410     cmp      dword ptr [eax + 0x14], 0x10
006271fd: c645fc01     mov      byte ptr [ebp - 4], 1
00627201: 7202         jb       0x627205
00627203: 8b00         mov      eax, dword ptr [eax]
00627205: 6a00         push     0
00627207: 56           push     esi
00627208: 50           push     eax
00627209: 0fb6050f42ee01 movzx    eax, byte ptr [0x1ee420f]
00627210: 6898c68c01   push     0x18cc698
00627215: 50           push     eax
00627216: e875020501   call     0x1677490
0062721b: 8b5598       mov      edx, dword ptr [ebp - 0x68]
0062721e: 83c414       add      esp, 0x14
00627221: c645fc00     mov      byte ptr [ebp - 4], 0
00627225: 83fa10       cmp      edx, 0x10

; === 136 | 0x627210 | Replicator::readJoinDataItem() :  will process newInstanceItem [%s->%s] ===
00627210: 6898c68c01   push     0x18cc698
00627215: 50           push     eax
00627216: e875020501   call     0x1677490
0062721b: 8b5598       mov      edx, dword ptr [ebp - 0x68]
0062721e: 83c414       add      esp, 0x14
00627221: c645fc00     mov      byte ptr [ebp - 4], 0
00627225: 83fa10       cmp      edx, 0x10
00627228: 722c         jb       0x627256
0062722a: 8b4d84       mov      ecx, dword ptr [ebp - 0x7c]
0062722d: 42           inc      edx
0062722e: 8bc1         mov      eax, ecx
00627230: 81fa00100000 cmp      edx, 0x1000
00627236: 7214         jb       0x62724c
00627238: 8b49fc       mov      ecx, dword ptr [ecx - 4]
0062723b: 83c223       add      edx, 0x23
0062723e: 2bc1         sub      eax, ecx
00627240: 83c0fc       add      eax, -4
00627243: 83f81f       cmp      eax, 0x1f
00627246: 0f87e8090000 ja       0x627c34
0062724c: 52           push     edx
0062724d: 51           push     ecx
0062724e: e84ddc0401   call     0x1674ea0
00627253: 83c408       add      esp, 8
00627256: 8b9560ffffff mov      edx, dword ptr [ebp - 0xa0]
0062725c: c7459400000000 mov      dword ptr [ebp - 0x6c], 0
00627263: c745980f000000 mov      dword ptr [ebp - 0x68], 0xf
0062726a: c6458400     mov      byte ptr [ebp - 0x7c], 0
0062726e: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
00627275: 83fa10       cmp      edx, 0x10
00627278: 722f         jb       0x6272a9
0062727a: 8b8d4cffffff mov      ecx, dword ptr [ebp - 0xb4]
00627280: 42           inc      edx
00627281: 8bc1         mov      eax, ecx
00627283: 81fa00100000 cmp      edx, 0x1000
00627289: 7214         jb       0x62729f
0062728b: 8b49fc       mov      ecx, dword ptr [ecx - 4]
0062728e: 83c223       add      edx, 0x23
00627291: 2bc1         sub      eax, ecx
00627293: 83c0fc       add      eax, -4
00627296: 83f81f       cmp      eax, 0x1f
00627299: 0f8795090000 ja       0x627c34
0062729f: 52           push     edx
006272a0: 51           push     ecx
006272a1: e8fadb0401   call     0x1674ea0
006272a6: 83c408       add      esp, 8
006272a9: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
006272ac: 8bcf         mov      ecx, edi
006272ae: e88d82ffff   call     0x61f540
006272b3: 84c0         test     al, al

; === 137 | 0x627391 | Replicator::readJoinDataItem() : pushing child %s[%s] to parent childrenWaitingForTheirTurn[%s] ===
00627391: 6830c78c01   push     0x18cc730
00627396: 50           push     eax
00627397: e8f4000501   call     0x1677490
0062739c: 83c414       add      esp, 0x14
0062739f: 8d8da4feffff lea      ecx, [ebp - 0x15c]
006273a5: e80694f2ff   call     0x5507b0
006273aa: 8d8d8cfeffff lea      ecx, [ebp - 0x174]
006273b0: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
006273b7: e8f493f2ff   call     0x5507b0
006273bc: 57           push     edi
006273bd: 8bcb         mov      ecx, ebx
006273bf: e85ca90900   call     0x6c1d20
006273c4: 8d4324       lea      eax, [ebx + 0x24]
006273c7: 50           push     eax
006273c8: 8d8fe0370000 lea      ecx, [edi + 0x37e0]
006273ce: e8fdd3feff   call     0x6147d0
006273d3: 8bf0         mov      esi, eax
006273d5: 53           push     ebx
006273d6: 8b460c       mov      eax, dword ptr [esi + 0xc]
006273d9: 394610       cmp      dword ptr [esi + 0x10], eax
006273dc: 0f843a020000 je       0x62761c
006273e2: 8bc8         mov      ecx, eax
006273e4: e8777cfeff   call     0x60f060
006273e9: 83460c58     add      dword ptr [esi + 0xc], 0x58
006273ed: e922070000   jmp      0x627b14
006273f2: 83e010       and      eax, 0x10
006273f5: 83c800       or       eax, 0
006273f8: 0f85ecfeffff jne      0x6272ea
006273fe: 803d98a0d50100 cmp      byte ptr [0x1d5a098], 0
00627405: 0f8415010000 je       0x627520
0062740b: 8d8fc8370000 lea      ecx, [edi + 0x37c8]
00627411: 8d7b24       lea      edi, [ebx + 0x24]
00627414: 57           push     edi
00627415: e856d1feff   call     0x614570
0062741a: 8bd8         mov      ebx, eax
0062741c: 8b45e8       mov      eax, dword ptr [ebp - 0x18]
0062741f: 83784000     cmp      dword ptr [eax + 0x40], 0
00627423: 8d7040       lea      esi, [eax + 0x40]
00627426: 7510         jne      0x627438
00627428: 8b4dec       mov      ecx, dword ptr [ebp - 0x14]
0062742b: 56           push     esi
0062742c: 57           push     edi
0062742d: 8b4954       mov      ecx, dword ptr [ecx + 0x54]
00627430: e88ba6ffff   call     0x621ac0
00627435: 8b45e8       mov      eax, dword ptr [ebp - 0x18]

; === 138 | 0x6274a2 | Replicator::readJoinDataItem() :  pushing child [%s] to parent orderedChildrenWaitingForTheirTurn[%s] ===
006274a2: 6890c78c01   push     0x18cc790
006274a7: 50           push     eax
006274a8: e8e3ff0401   call     0x1677490
006274ad: 83c414       add      esp, 0x14
006274b0: 8d8d04ffffff lea      ecx, [ebp - 0xfc]
006274b6: e8f592f2ff   call     0x5507b0
006274bb: 8d8decfeffff lea      ecx, [ebp - 0x114]
006274c1: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
006274c8: e8e392f2ff   call     0x5507b0
006274cd: eb03         jmp      0x6274d2
006274cf: 8b5de8       mov      ebx, dword ptr [ebp - 0x18]
006274d2: ff75ec       push     dword ptr [ebp - 0x14]
006274d5: 8bcb         mov      ecx, ebx
006274d7: e844a80900   call     0x6c1d20
006274dc: 57           push     edi
006274dd: 8b7dec       mov      edi, dword ptr [ebp - 0x14]
006274e0: 8d8fc8370000 lea      ecx, [edi + 0x37c8]
006274e6: e885d0feff   call     0x614570
006274eb: 53           push     ebx
006274ec: 8d4b34       lea      ecx, [ebx + 0x34]
006274ef: 51           push     ecx
006274f0: 51           push     ecx
006274f1: 8d8d7cffffff lea      ecx, [ebp - 0x84]
006274f7: 51           push     ecx
006274f8: 8d4810       lea      ecx, [eax + 0x10]
006274fb: e8a0edfdff   call     0x6062a0
00627500: e90f060000   jmp      0x627b14
00627505: 8b5de8       mov      ebx, dword ptr [ebp - 0x18]
00627508: 8b7dec       mov      edi, dword ptr [ebp - 0x14]
0062750b: 8bcf         mov      ecx, edi
0062750d: 53           push     ebx
0062750e: e89dd3ffff   call     0x6248b0
00627513: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
00627516: 03f0         add      esi, eax
00627518: 8975f0       mov      dword ptr [ebp - 0x10], esi
0062751b: e9f7050000   jmp      0x627b17
00627520: 8d87c8370000 lea      eax, [edi + 0x37c8]
00627526: 8d7b24       lea      edi, [ebx + 0x24]
00627529: 57           push     edi
0062752a: 8d4db4       lea      ecx, [ebp - 0x4c]
0062752d: 51           push     ecx
0062752e: 8bc8         mov      ecx, eax
00627530: e85b69ffff   call     0x61de90
00627535: 8b4b34       mov      ecx, dword ptr [ebx + 0x34]
00627538: 83c334       add      ebx, 0x34
0062753b: 85c9         test     ecx, ecx
0062753d: 0f84c1000000 je       0x627604
00627543: 8b45b4       mov      eax, dword ptr [ebp - 0x4c]

; === 139 | 0x6275a4 | Replicator::readJoinDataItem() :  pushing child [%s] to parent orderedChildrenWaitingForTheirTurn[%s] ===
006275a4: 6890c78c01   push     0x18cc790
006275a9: 50           push     eax
006275aa: e8e1fe0401   call     0x1677490
006275af: 83c414       add      esp, 0x14
006275b2: 8d8dd4feffff lea      ecx, [ebp - 0x12c]
006275b8: e8f391f2ff   call     0x5507b0
006275bd: 8d8dbcfeffff lea      ecx, [ebp - 0x144]
006275c3: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
006275ca: e8e191f2ff   call     0x5507b0
006275cf: ff75ec       push     dword ptr [ebp - 0x14]
006275d2: 8b75e8       mov      esi, dword ptr [ebp - 0x18]
006275d5: 8bce         mov      ecx, esi
006275d7: e844a70900   call     0x6c1d20
006275dc: 57           push     edi
006275dd: 8b7dec       mov      edi, dword ptr [ebp - 0x14]
006275e0: 8d8fc8370000 lea      ecx, [edi + 0x37c8]
006275e6: e885cffeff   call     0x614570
006275eb: 56           push     esi
006275ec: 53           push     ebx
006275ed: 53           push     ebx
006275ee: 8d8d74ffffff lea      ecx, [ebp - 0x8c]
006275f4: 51           push     ecx
006275f5: 8d4810       lea      ecx, [eax + 0x10]
006275f8: e8a3ecfdff   call     0x6062a0
006275fd: 8bde         mov      ebx, esi
006275ff: e910050000   jmp      0x627b14
00627604: 8b5de8       mov      ebx, dword ptr [ebp - 0x18]
00627607: 8b7dec       mov      edi, dword ptr [ebp - 0x14]
0062760a: 8bcf         mov      ecx, edi
0062760c: 53           push     ebx
0062760d: e89ed2ffff   call     0x6248b0
00627612: 03f0         add      esi, eax
00627614: 8975f0       mov      dword ptr [ebp - 0x10], esi
00627617: e9fb040000   jmp      0x627b17
0062761c: 50           push     eax
0062761d: 8d4e08       lea      ecx, [esi + 8]
00627620: e8fbc4fdff   call     0x603b20
00627625: e9ea040000   jmp      0x627b14
0062762a: 8b03         mov      eax, dword ptr [ebx]
0062762c: 46           inc      esi
0062762d: 57           push     edi
0062762e: 8bcb         mov      ecx, ebx
00627630: 8975f0       mov      dword ptr [ebp - 0x10], esi
00627633: ff5004       call     dword ptr [eax + 4]
00627636: 8b87701f0000 mov      eax, dword ptr [edi + 0x1f70]
0062763c: 80785a00     cmp      byte ptr [eax + 0x5a], 0
00627640: 741a         je       0x62765c
00627642: f30f10430c   movss    xmm0, dword ptr [ebx + 0xc]
00627647: 8d8fe8170000 lea      ecx, [edi + 0x17e8]

; === 140 | 0x62778e | Replicator::readJoinDataItem() : erasing parent childrenWaitingForTheirTurn[%s] ===
0062778e: 68e0c68c01   push     0x18cc6e0
00627793: 50           push     eax
00627794: e817fd0401   call     0x16774b0
00627799: 8b9548ffffff mov      edx, dword ptr [ebp - 0xb8]
0062779f: 83c40c       add      esp, 0xc
006277a2: c645fc02     mov      byte ptr [ebp - 4], 2
006277a6: 83fa10       cmp      edx, 0x10
006277a9: 722f         jb       0x6277da
006277ab: 8b8d34ffffff mov      ecx, dword ptr [ebp - 0xcc]
006277b1: 42           inc      edx
006277b2: 8bc1         mov      eax, ecx
006277b4: 81fa00100000 cmp      edx, 0x1000
006277ba: 7214         jb       0x6277d0
006277bc: 8b49fc       mov      ecx, dword ptr [ecx - 4]
006277bf: 83c223       add      edx, 0x23
006277c2: 2bc1         sub      eax, ecx
006277c4: 83c0fc       add      eax, -4
006277c7: 83f81f       cmp      eax, 0x1f
006277ca: 0f8764040000 ja       0x627c34
006277d0: 52           push     edx
006277d1: 51           push     ecx
006277d2: e8c9d60401   call     0x1674ea0
006277d7: 83c408       add      esp, 8
006277da: 51           push     ecx
006277db: 8b4dc4       mov      ecx, dword ptr [ebp - 0x3c]
006277de: 8bc4         mov      eax, esp
006277e0: 8930         mov      dword ptr [eax], esi
006277e2: 8d45a0       lea      eax, [ebp - 0x60]
006277e5: 50           push     eax
006277e6: e8d55effff   call     0x61d6c0
006277eb: 837de400     cmp      dword ptr [ebp - 0x1c], 0
006277ef: 0f840a030000 je       0x627aff
006277f5: 8b45e0       mov      eax, dword ptr [ebp - 0x20]
006277f8: 8b55d4       mov      edx, dword ptr [ebp - 0x2c]
006277fb: 85d2         test     edx, edx
006277fd: 7402         je       0x627801
006277ff: 8b12         mov      edx, dword ptr [edx]
00627801: 8b4a08       mov      ecx, dword ptr [edx + 8]
00627804: 49           dec      ecx
00627805: 23c8         and      ecx, eax
00627807: 8b4204       mov      eax, dword ptr [edx + 4]
0062780a: 8b1c88       mov      ebx, dword ptr [eax + ecx*4]
0062780d: 8b45ec       mov      eax, dword ptr [ebp - 0x14]
00627810: 837b24ff     cmp      dword ptr [ebx + 0x24], -1
00627814: 8b7854       mov      edi, dword ptr [eax + 0x54]
00627817: 7547         jne      0x627860
00627819: c7434000000000 mov      dword ptr [ebx + 0x40], 0
00627820: 8b7344       mov      esi, dword ptr [ebx + 0x44]
00627823: c7434400000000 mov      dword ptr [ebx + 0x44], 0
0062782a: 85f6         test     esi, esi
0062782c: 0f8429010000 je       0x62795b
00627832: 83c8ff       or       eax, 0xffffffff

; === 141 | 0x627a71 | Replicator::readJoinDataItem() : erasing parent childrenWaitingForTheirTurn[%s] ===
00627a71: 68e0c68c01   push     0x18cc6e0
00627a76: 50           push     eax
00627a77: e834fa0401   call     0x16774b0
00627a7c: 8b9530ffffff mov      edx, dword ptr [ebp - 0xd0]
00627a82: 83c40c       add      esp, 0xc
00627a85: c645fc02     mov      byte ptr [ebp - 4], 2
00627a89: 83fa10       cmp      edx, 0x10
00627a8c: 722f         jb       0x627abd
00627a8e: 8b8d1cffffff mov      ecx, dword ptr [ebp - 0xe4]
00627a94: 42           inc      edx
00627a95: 8bc1         mov      eax, ecx
00627a97: 81fa00100000 cmp      edx, 0x1000
00627a9d: 7214         jb       0x627ab3
00627a9f: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00627aa2: 83c223       add      edx, 0x23
00627aa5: 2bc1         sub      eax, ecx
00627aa7: 83c0fc       add      eax, -4
00627aaa: 83f81f       cmp      eax, 0x1f
00627aad: 0f8781010000 ja       0x627c34
00627ab3: 52           push     edx
00627ab4: 51           push     ecx
00627ab5: e8e6d30401   call     0x1674ea0
00627aba: 83c408       add      esp, 8
00627abd: 51           push     ecx
00627abe: 8b4dc4       mov      ecx, dword ptr [ebp - 0x3c]
00627ac1: 8bc4         mov      eax, esp
00627ac3: 8930         mov      dword ptr [eax], esi
00627ac5: 8d459c       lea      eax, [ebp - 0x64]
00627ac8: 50           push     eax
00627ac9: e8f25bffff   call     0x61d6c0
00627ace: 8b4ddc       mov      ecx, dword ptr [ebp - 0x24]
00627ad1: 8b45d8       mov      eax, dword ptr [ebp - 0x28]
00627ad4: 49           dec      ecx
00627ad5: 234de0       and      ecx, dword ptr [ebp - 0x20]
00627ad8: 6a00         push     0
00627ada: 8b0c88       mov      ecx, dword ptr [eax + ecx*4]
00627add: 8b01         mov      eax, dword ptr [ecx]
00627adf: ff10         call     dword ptr [eax]
00627ae1: 8b4de4       mov      ecx, dword ptr [ebp - 0x1c]
00627ae4: 83e901       sub      ecx, 1
00627ae7: 894de4       mov      dword ptr [ebp - 0x1c], ecx
00627aea: 7504         jne      0x627af0
00627aec: 33c0         xor      eax, eax
00627aee: eb04         jmp      0x627af4
00627af0: 8b45e0       mov      eax, dword ptr [ebp - 0x20]
00627af3: 40           inc      eax
00627af4: 8945e0       mov      dword ptr [ebp - 0x20], eax
00627af7: 85c9         test     ecx, ecx
00627af9: 0f85f9fcffff jne      0x6277f8
00627aff: 8d4dd4       lea      ecx, [ebp - 0x2c]
00627b02: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
00627b09: e8529afeff   call     0x611560
00627b0e: 8b5de8       mov      ebx, dword ptr [ebp - 0x18]
00627b11: 8b7dec       mov      edi, dword ptr [ebp - 0x14]

; === 142 | 0x627bc8 | Replicator::readJoinDataItem() took %fms : orderedChildrenWaitingForTheirTurn size=%d ===
00627bc8: 68f8c78c01   push     0x18cc7f8
00627bcd: 51           push     ecx
00627bce: e84df90401   call     0x1677520
00627bd3: 83c414       add      esp, 0x14
00627bd6: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00627bd9: 8b45f0       mov      eax, dword ptr [ebp - 0x10]
00627bdc: 5f           pop      edi
00627bdd: 5e           pop      esi
00627bde: 64890d00000000 mov      dword ptr fs:[0], ecx
00627be5: 5b           pop      ebx
00627be6: 8be5         mov      esp, ebp
00627be8: 5d           pop      ebp
00627be9: c20400       ret      4
00627bec: 8b432c       mov      eax, dword ptr [ebx + 0x2c]
00627bef: 83780800     cmp      dword ptr [eax + 8], 0
00627bf3: 0f841effffff je       0x627b17
00627bf9: 8b03         mov      eax, dword ptr [ebx]
00627bfb: 46           inc      esi
00627bfc: 57           push     edi
00627bfd: 8bcb         mov      ecx, ebx
00627bff: 8975f0       mov      dword ptr [ebp - 0x10], esi
00627c02: ff5004       call     dword ptr [eax + 4]
00627c05: 8b87701f0000 mov      eax, dword ptr [edi + 0x1f70]
00627c0b: 80785a00     cmp      byte ptr [eax + 0x5a], 0
00627c0f: 0f8402ffffff je       0x627b17
00627c15: f30f10430c   movss    xmm0, dword ptr [ebx + 0xc]
00627c1a: 8d4338       lea      eax, [ebx + 0x38]
00627c1d: 51           push     ecx
00627c1e: f30f110424   movss    dword ptr [esp], xmm0
00627c23: 8d8fe8170000 lea      ecx, [edi + 0x17e8]
00627c29: 50           push     eax
00627c2a: e8c1050000   call     0x6281f0
00627c2f: e9e3feffff   jmp      0x627b17
00627c34: e86aeb0e01   call     0x17167a3
00627c39: cc           int3     
00627c3a: cc           int3     
00627c3b: cc           int3     
00627c3c: cc           int3     
00627c3d: cc           int3     
00627c3e: cc           int3     
00627c3f: cc           int3     
00627c40: 55           push     ebp
00627c41: 8bec         mov      ebp, esp
00627c43: 56           push     esi
00627c44: 8bf1         mov      esi, ecx
00627c46: 8a0d0a42ee01 mov      cl, byte ptr [0x1ee420a]
00627c4c: 84c9         test     cl, cl
00627c4e: 7417         je       0x627c67
00627c50: 8b4508       mov      eax, dword ptr [ebp + 8]
00627c53: ff7010       push     dword ptr [eax + 0x10]
00627c56: 0fb6c1       movzx    eax, cl
00627c59: 6814c38c01   push     0x18cc314
00627c5e: 50           push     eax
00627c5f: e84cf80401   call     0x16774b0
00627c64: 83c40c       add      esp, 0xc
00627c67: 83be6c1f000000 cmp      dword ptr [esi + 0x1f6c], 0
00627c6e: 0f869b000000 jbe      0x627d0f

; === 143 | 0x629258 | NetworkServer ===
00629258: 684c8d8c01   push     0x18c8d4c
0062925d: e85eb0f2ff   call     0x5542c0
00629262: 8b07         mov      eax, dword ptr [edi]
00629264: 8bcf         mov      ecx, edi
00629266: 8b80b4000000 mov      eax, dword ptr [eax + 0xb4]
0062926c: ffd0         call     eax
0062926e: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
00629274: 51           push     ecx
00629275: 8bc8         mov      ecx, eax
00629277: e8a4e22f00   call     0x927520
0062927c: eb19         jmp      0x629297
0062927e: 682c8d8c01   push     0x18c8d2c
00629283: e838b0f2ff   call     0x5542c0
00629288: 8d8538ffffff lea      eax, [ebp - 0xc8]
0062928e: 50           push     eax
0062928f: e86c72f000   call     0x1530500
00629294: 83c404       add      esp, 4
00629297: 8bf0         mov      esi, eax
00629299: 8d4590       lea      eax, [ebp - 0x70]
0062929c: 3bc6         cmp      eax, esi
0062929e: 7429         je       0x6292c9
006292a0: 8bc8         mov      ecx, eax
006292a2: e80975f2ff   call     0x5507b0
006292a7: 0f1006       movups   xmm0, xmmword ptr [esi]
006292aa: 0f114590     movups   xmmword ptr [ebp - 0x70], xmm0
006292ae: f30f7e4610   movq     xmm0, qword ptr [esi + 0x10]
006292b3: 660fd645a0   movq     qword ptr [ebp - 0x60], xmm0
006292b8: c7461000000000 mov      dword ptr [esi + 0x10], 0
006292bf: c746140f000000 mov      dword ptr [esi + 0x14], 0xf
006292c6: c60600       mov      byte ptr [esi], 0
006292c9: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
006292cf: e8dc74f2ff   call     0x5507b0
006292d4: 660f6e87280e0000 movd     xmm0, dword ptr [edi + 0xe28]
006292dc: 83ec08       sub      esp, 8
006292df: f30fe6c0     cvtdq2pd xmm0, xmm0
006292e3: f20f110424   movsd    qword ptr [esp], xmm0
006292e8: 8b45d8       mov      eax, dword ptr [ebp - 0x28]
006292eb: 8d4da8       lea      ecx, [ebp - 0x58]
006292ee: 83c00e       add      eax, 0xe
006292f1: c645fc04     mov      byte ptr [ebp - 4], 4
006292f5: 50           push     eax
006292f6: c745b800000000 mov      dword ptr [ebp - 0x48], 0
006292fd: c745bc0f000000 mov      dword ptr [ebp - 0x44], 0xf

; === 144 | 0x62927e | NetworkClient ===
0062927e: 682c8d8c01   push     0x18c8d2c
00629283: e838b0f2ff   call     0x5542c0
00629288: 8d8538ffffff lea      eax, [ebp - 0xc8]
0062928e: 50           push     eax
0062928f: e86c72f000   call     0x1530500
00629294: 83c404       add      esp, 4
00629297: 8bf0         mov      esi, eax
00629299: 8d4590       lea      eax, [ebp - 0x70]
0062929c: 3bc6         cmp      eax, esi
0062929e: 7429         je       0x6292c9
006292a0: 8bc8         mov      ecx, eax
006292a2: e80975f2ff   call     0x5507b0
006292a7: 0f1006       movups   xmm0, xmmword ptr [esi]
006292aa: 0f114590     movups   xmmword ptr [ebp - 0x70], xmm0
006292ae: f30f7e4610   movq     xmm0, qword ptr [esi + 0x10]
006292b3: 660fd645a0   movq     qword ptr [ebp - 0x60], xmm0
006292b8: c7461000000000 mov      dword ptr [esi + 0x10], 0
006292bf: c746140f000000 mov      dword ptr [esi + 0x14], 0xf
006292c6: c60600       mov      byte ptr [esi], 0
006292c9: 8d8d38ffffff lea      ecx, [ebp - 0xc8]
006292cf: e8dc74f2ff   call     0x5507b0
006292d4: 660f6e87280e0000 movd     xmm0, dword ptr [edi + 0xe28]
006292dc: 83ec08       sub      esp, 8
006292df: f30fe6c0     cvtdq2pd xmm0, xmm0
006292e3: f20f110424   movsd    qword ptr [esp], xmm0
006292e8: 8b45d8       mov      eax, dword ptr [ebp - 0x28]
006292eb: 8d4da8       lea      ecx, [ebp - 0x58]
006292ee: 83c00e       add      eax, 0xe
006292f1: c645fc04     mov      byte ptr [ebp - 4], 4
006292f5: 50           push     eax
006292f6: c745b800000000 mov      dword ptr [ebp - 0x48], 0
006292fd: c745bc0f000000 mov      dword ptr [ebp - 0x44], 0xf
00629304: c645a800     mov      byte ptr [ebp - 0x58], 0
00629308: c745c402000000 mov      dword ptr [ebp - 0x3c], 2
0062930f: e87c0ef6ff   call     0x58a190
00629314: 837ddc10     cmp      dword ptr [ebp - 0x24], 0x10
00629318: 8d45c8       lea      eax, [ebp - 0x38]
0062931b: ff75d8       push     dword ptr [ebp - 0x28]
0062931e: 0f4345c8     cmovae   eax, dword ptr [ebp - 0x38]

; === 145 | 0x62bfad | schemaReadTopReplicationContainerStateFromStream()::FFlagCreateAndUpdateDataReplicationCache5Adding=%d, SupportJoinDataItemV2iv=%d ===
0062bfad: 68d0d98c01   push     0x18cd9d0
0062bfb2: 50           push     eax
0062bfb3: e8d8b40401   call     0x1677490
0062bfb8: 83c414       add      esp, 0x14
0062bfbb: 8b8708380000 mov      eax, dword ptr [edi + 0x3808]
0062bfc1: 2500000200   and      eax, 0x20000
0062bfc6: 83c800       or       eax, 0
0062bfc9: 0f8528010000 jne      0x62c0f7
0062bfcf: 8b07         mov      eax, dword ptr [edi]
0062bfd1: 8bcf         mov      ecx, edi
0062bfd3: 8b80d4000000 mov      eax, dword ptr [eax + 0xd4]
0062bfd9: ffd0         call     eax
0062bfdb: 84c0         test     al, al
0062bfdd: 0f8414010000 je       0x62c0f7
0062bfe3: 68b0000000   push     0xb0
0062bfe8: e8338e0401   call     0x1674e20
0062bfed: 8bf0         mov      esi, eax
0062bfef: 83c404       add      esp, 4
0062bff2: 8975e4       mov      dword ptr [ebp - 0x1c], esi
0062bff5: 8975ec       mov      dword ptr [ebp - 0x14], esi
0062bff8: c645fc02     mov      byte ptr [ebp - 4], 2
0062bffc: 85f6         test     esi, esi
0062bffe: 0f84ce000000 je       0x62c0d2
0062c004: 57           push     edi
0062c005: 8bce         mov      ecx, esi
0062c007: e8245a0800   call     0x6b1a30
0062c00c: c7067caf8c01 mov      dword ptr [esi], 0x18caf7c
0062c012: 83c630       add      esi, 0x30
0062c015: 6a00         push     0
0062c017: 6a00         push     0
0062c019: 8bce         mov      ecx, esi
0062c01b: c645fc03     mov      byte ptr [ebp - 4], 3
0062c01f: 8975d4       mov      dword ptr [ebp - 0x2c], esi
0062c022: c70600000000 mov      dword ptr [esi], 0
0062c028: c7460400000000 mov      dword ptr [esi + 4], 0
0062c02f: e8dcacfeff   call     0x616d10
0062c034: 8906         mov      dword ptr [esi], eax
0062c036: 8b75e4       mov      esi, dword ptr [ebp - 0x1c]
0062c039: c645fc04     mov      byte ptr [ebp - 4], 4
0062c03d: 8d4e5c       lea      ecx, [esi + 0x5c]
0062c040: c74638ffffffff mov      dword ptr [esi + 0x38], 0xffffffff
0062c047: c7463c00000000 mov      dword ptr [esi + 0x3c], 0
0062c04e: c7464000000000 mov      dword ptr [esi + 0x40], 0

; === 146 | 0x62c0bc | JoinDataItem ===
0062c0bc: 6894af8c01   push     0x18caf94
0062c0c1: c60100       mov      byte ptr [ecx], 0
0062c0c4: e8f781f2ff   call     0x5542c0
0062c0c9: c686a800000001 mov      byte ptr [esi + 0xa8], 1
0062c0d0: eb05         jmp      0x62c0d7
0062c0d2: 33f6         xor      esi, esi
0062c0d4: 8975e4       mov      dword ptr [ebp - 0x1c], esi
0062c0d7: 0fb6050c52d601 movzx    eax, byte ptr [0x1d6520c]
0062c0de: 8d8fec1d0000 lea      ecx, [edi + 0x1dec]
0062c0e4: 69c0e8030000 imul     eax, eax, 0x3e8
0062c0ea: 56           push     esi
0062c0eb: c645fc01     mov      byte ptr [ebp - 4], 1
0062c0ef: 894638       mov      dword ptr [esi + 0x38], eax
0062c0f2: e8595e0800   call     0x6b1f50
0062c0f7: 8d8500ffffff lea      eax, [ebp - 0x100]
0062c0fd: c78500ffffff7ce28c01 mov      dword ptr [ebp - 0x100], 0x18ce27c
0062c107: 89bd04ffffff mov      dword ptr [ebp - 0xfc], edi
0062c10d: 89b508ffffff mov      dword ptr [ebp - 0xf8], esi
0062c113: 898524ffffff mov      dword ptr [ebp - 0xdc], eax
0062c119: ff7508       push     dword ptr [ebp + 8]
0062c11c: 8d45b4       lea      eax, [ebp - 0x4c]
0062c11f: c645fc07     mov      byte ptr [ebp - 4], 7
0062c123: 50           push     eax
0062c124: e837fb0700   call     0x6abc60
0062c129: 8b45b4       mov      eax, dword ptr [ebp - 0x4c]
0062c12c: 83c408       add      esp, 8
0062c12f: 3b05ec9ed501 cmp      eax, dword ptr [0x1d59eec]
0062c135: 0f838c070000 jae      0x62c8c7
0062c13b: c745ac00000000 mov      dword ptr [ebp - 0x54], 0
0062c142: 85c0         test     eax, eax
0062c144: 0f84ab050000 je       0x62c6f5
0062c14a: 660f1f440000 nop      word ptr [eax + eax]
0062c150: 85f6         test     esi, esi
0062c152: 7408         je       0x62c15c
0062c154: 8b4e34       mov      ecx, dword ptr [esi + 0x34]
0062c157: 894db0       mov      dword ptr [ebp - 0x50], ecx
0062c15a: eb07         jmp      0x62c163
0062c15c: c745b000000000 mov      dword ptr [ebp - 0x50], 0

; === 147 | 0x62c3c7 | JoinDataItem ===
0062c3c7: 6894af8c01   push     0x18caf94
0062c3cc: 50           push     eax
0062c3cd: 0fb6050d42ee01 movzx    eax, byte ptr [0x1ee420d]
0062c3d4: 68f0da8c01   push     0x18cdaf0
0062c3d9: 50           push     eax
0062c3da: e8b1b00401   call     0x1677490
0062c3df: 83c414       add      esp, 0x14
0062c3e2: c645fc11     mov      byte ptr [ebp - 4], 0x11
0062c3e6: 8d8d7cffffff lea      ecx, [ebp - 0x84]
0062c3ec: e8bf43f2ff   call     0x5507b0
0062c3f1: 8b8fb41d0000 mov      ecx, dword ptr [edi + 0x1db4]
0062c3f7: e864cc0a00   call     0x6d9060
0062c3fc: ff75dc       push     dword ptr [ebp - 0x24]
0062c3ff: 8b8fb41d0000 mov      ecx, dword ptr [edi + 0x1db4]
0062c405: 8bf0         mov      esi, eax
0062c407: e824da0a00   call     0x6d9e30
0062c40c: 50           push     eax
0062c40d: ff75cc       push     dword ptr [ebp - 0x34]
0062c410: 8d45dc       lea      eax, [ebp - 0x24]
0062c413: 8bce         mov      ecx, esi
0062c415: ff75d0       push     dword ptr [ebp - 0x30]
0062c418: 50           push     eax
0062c419: e862cc0900   call     0x6c9080
0062c41e: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
0062c421: 8bcf         mov      ecx, edi
0062c423: e81831ffff   call     0x61f540
0062c428: 84c0         test     al, al
0062c42a: 7523         jne      0x62c44f
0062c42c: 8b8d24ffffff mov      ecx, dword ptr [ebp - 0xdc]
0062c432: 8845e8       mov      byte ptr [ebp - 0x18], al
0062c435: 85c9         test     ecx, ecx
0062c437: 0f8409060000 je       0x62ca46
0062c43d: 8b01         mov      eax, dword ptr [ecx]
0062c43f: 8d55e8       lea      edx, [ebp - 0x18]
0062c442: 52           push     edx
0062c443: 8d55a4       lea      edx, [ebp - 0x5c]
0062c446: 52           push     edx
0062c447: 56           push     esi
0062c448: 8d55dc       lea      edx, [ebp - 0x24]
0062c44b: 52           push     edx
0062c44c: ff5008       call     dword ptr [eax + 8]
0062c44f: 807dcc00     cmp      byte ptr [ebp - 0x34], 0
0062c453: 0f84e2010000 je       0x62c63b
0062c459: 8b07         mov      eax, dword ptr [edi]
0062c45b: 8bcf         mov      ecx, edi
0062c45d: 8b80d4000000 mov      eax, dword ptr [eax + 0xd4]
0062c463: ffd0         call     eax
0062c465: 84c0         test     al, al
0062c467: 0f84ce010000 je       0x62c63b

; === 148 | 0x62fec3 | Join Data Items ===
0062fec3: b8d4aa8c01   mov      eax, 0x18caad4
0062fec8: eb52         jmp      0x62ff1c
0062feca: b8e4aa8c01   mov      eax, 0x18caae4
0062fecf: eb4b         jmp      0x62ff1c
0062fed1: b800ab8c01   mov      eax, 0x18cab00
0062fed6: eb44         jmp      0x62ff1c
0062fed8: b814ab8c01   mov      eax, 0x18cab14
0062fedd: eb3d         jmp      0x62ff1c
0062fedf: b82cab8c01   mov      eax, 0x18cab2c
0062fee4: eb36         jmp      0x62ff1c
0062fee6: b844ab8c01   mov      eax, 0x18cab44
0062feeb: eb2f         jmp      0x62ff1c
0062feed: b850ab8c01   mov      eax, 0x18cab50
0062fef2: eb28         jmp      0x62ff1c
0062fef4: b85cab8c01   mov      eax, 0x18cab5c
0062fef9: eb21         jmp      0x62ff1c
0062fefb: b878ab8c01   mov      eax, 0x18cab78
0062ff00: eb1a         jmp      0x62ff1c
0062ff02: b890ab8c01   mov      eax, 0x18cab90
0062ff07: eb13         jmp      0x62ff1c
0062ff09: b8a4ab8c01   mov      eax, 0x18caba4
0062ff0e: eb0c         jmp      0x62ff1c
0062ff10: b8b8ab8c01   mov      eax, 0x18cabb8
0062ff15: eb05         jmp      0x62ff1c
0062ff17: b8d4ab8c01   mov      eax, 0x18cabd4
0062ff1c: 51           push     ecx
0062ff1d: 52           push     edx
0062ff1e: 50           push     eax
0062ff1f: 6818b08c01   push     0x18cb018
0062ff24: ff359cd0ea01 push     dword ptr [0x1ead09c]
0062ff2a: ff3598d0ea01 push     dword ptr [0x1ead098]
0062ff30: e82bd8ef00   call     0x152d760
0062ff35: 8b8328010000 mov      eax, dword ptr [ebx + 0x128]
0062ff3b: 83c418       add      esp, 0x18
0062ff3e: 8b8070380000 mov      eax, dword ptr [eax + 0x3870]
0062ff44: c704b000000000 mov      dword ptr [eax + esi*4], 0
0062ff4b: 46           inc      esi
0062ff4c: e9b4feffff   jmp      0x62fe05
0062ff51: 64a12c000000 mov      eax, dword ptr fs:[0x2c]
0062ff57: 8b0c88       mov      ecx, dword ptr [eax + ecx*4]
0062ff5a: a1b0d0ea01   mov      eax, dword ptr [0x1ead0b0]
0062ff5f: 3b8134000000 cmp      eax, dword ptr [ecx + 0x34]
0062ff65: 0f8f14040000 jg       0x63037f

; === 149 | 0x62ff02 | Join Data Items V2 ===
0062ff02: b890ab8c01   mov      eax, 0x18cab90
0062ff07: eb13         jmp      0x62ff1c
0062ff09: b8a4ab8c01   mov      eax, 0x18caba4
0062ff0e: eb0c         jmp      0x62ff1c
0062ff10: b8b8ab8c01   mov      eax, 0x18cabb8
0062ff15: eb05         jmp      0x62ff1c
0062ff17: b8d4ab8c01   mov      eax, 0x18cabd4
0062ff1c: 51           push     ecx
0062ff1d: 52           push     edx
0062ff1e: 50           push     eax
0062ff1f: 6818b08c01   push     0x18cb018
0062ff24: ff359cd0ea01 push     dword ptr [0x1ead09c]
0062ff2a: ff3598d0ea01 push     dword ptr [0x1ead098]
0062ff30: e82bd8ef00   call     0x152d760
0062ff35: 8b8328010000 mov      eax, dword ptr [ebx + 0x128]
0062ff3b: 83c418       add      esp, 0x18
0062ff3e: 8b8070380000 mov      eax, dword ptr [eax + 0x3870]
0062ff44: c704b000000000 mov      dword ptr [eax + esi*4], 0
0062ff4b: 46           inc      esi
0062ff4c: e9b4feffff   jmp      0x62fe05
0062ff51: 64a12c000000 mov      eax, dword ptr fs:[0x2c]
0062ff57: 8b0c88       mov      ecx, dword ptr [eax + ecx*4]
0062ff5a: a1b0d0ea01   mov      eax, dword ptr [0x1ead0b0]
0062ff5f: 3b8134000000 cmp      eax, dword ptr [ecx + 0x34]
0062ff65: 0f8f14040000 jg       0x63037f
0062ff6b: 57           push     edi
0062ff6c: 6834b08c01   push     0x18cb034
0062ff71: ff35acd0ea01 push     dword ptr [0x1ead0ac]
0062ff77: ff35a8d0ea01 push     dword ptr [0x1ead0a8]
0062ff7d: e8ded7ef00   call     0x152d760
0062ff82: 83c410       add      esp, 0x10
0062ff85: 33f6         xor      esi, esi
0062ff87: 83fe1a       cmp      esi, 0x1a
0062ff8a: 0f8f2d010000 jg       0x6300bd
0062ff90: 8b8328010000 mov      eax, dword ptr [ebx + 0x128]
0062ff96: 8b8070380000 mov      eax, dword ptr [eax + 0x3870]
0062ff9c: 833cb000     cmp      dword ptr [eax + esi*4], 0
0062ffa0: 0f8411010000 je       0x6300b7
0062ffa6: 64a12c000000 mov      eax, dword ptr fs:[0x2c]

; === 150 | 0x630030 | Join Data Items ===
00630030: b8d4aa8c01   mov      eax, 0x18caad4
00630035: eb52         jmp      0x630089
00630037: b8e4aa8c01   mov      eax, 0x18caae4
0063003c: eb4b         jmp      0x630089
0063003e: b800ab8c01   mov      eax, 0x18cab00
00630043: eb44         jmp      0x630089
00630045: b814ab8c01   mov      eax, 0x18cab14
0063004a: eb3d         jmp      0x630089
0063004c: b82cab8c01   mov      eax, 0x18cab2c
00630051: eb36         jmp      0x630089
00630053: b844ab8c01   mov      eax, 0x18cab44
00630058: eb2f         jmp      0x630089
0063005a: b850ab8c01   mov      eax, 0x18cab50
0063005f: eb28         jmp      0x630089
00630061: b85cab8c01   mov      eax, 0x18cab5c
00630066: eb21         jmp      0x630089
00630068: b878ab8c01   mov      eax, 0x18cab78
0063006d: eb1a         jmp      0x630089
0063006f: b890ab8c01   mov      eax, 0x18cab90
00630074: eb13         jmp      0x630089
00630076: b8a4ab8c01   mov      eax, 0x18caba4
0063007b: eb0c         jmp      0x630089
0063007d: b8b8ab8c01   mov      eax, 0x18cabb8
00630082: eb05         jmp      0x630089
00630084: b8d4ab8c01   mov      eax, 0x18cabd4
00630089: 51           push     ecx
0063008a: 50           push     eax
0063008b: 682cb08c01   push     0x18cb02c
00630090: ff35bcd0ea01 push     dword ptr [0x1ead0bc]
00630096: ff35b8d0ea01 push     dword ptr [0x1ead0b8]
0063009c: e8bfd6ef00   call     0x152d760
006300a1: 8b8328010000 mov      eax, dword ptr [ebx + 0x128]
006300a7: 83c414       add      esp, 0x14
006300aa: 8b8070380000 mov      eax, dword ptr [eax + 0x3870]
006300b0: c704b000000000 mov      dword ptr [eax + esi*4], 0
006300b7: 46           inc      esi
006300b8: e9cafeffff   jmp      0x62ff87
006300bd: 8b8b28010000 mov      ecx, dword ptr [ebx + 0x128]
006300c3: 8d89041e0000 lea      ecx, [ecx + 0x1e04]
006300c9: e852daf1ff   call     0x54db20
006300ce: 648b352c000000 mov      esi, dword ptr fs:[0x2c]
006300d5: 8b3dd0371102 mov      edi, dword ptr [0x21137d0]

; === 151 | 0x63006f | Join Data Items V2 ===
0063006f: b890ab8c01   mov      eax, 0x18cab90
00630074: eb13         jmp      0x630089
00630076: b8a4ab8c01   mov      eax, 0x18caba4
0063007b: eb0c         jmp      0x630089
0063007d: b8b8ab8c01   mov      eax, 0x18cabb8
00630082: eb05         jmp      0x630089
00630084: b8d4ab8c01   mov      eax, 0x18cabd4
00630089: 51           push     ecx
0063008a: 50           push     eax
0063008b: 682cb08c01   push     0x18cb02c
00630090: ff35bcd0ea01 push     dword ptr [0x1ead0bc]
00630096: ff35b8d0ea01 push     dword ptr [0x1ead0b8]
0063009c: e8bfd6ef00   call     0x152d760
006300a1: 8b8328010000 mov      eax, dword ptr [ebx + 0x128]
006300a7: 83c414       add      esp, 0x14
006300aa: 8b8070380000 mov      eax, dword ptr [eax + 0x3870]
006300b0: c704b000000000 mov      dword ptr [eax + esi*4], 0
006300b7: 46           inc      esi
006300b8: e9cafeffff   jmp      0x62ff87
006300bd: 8b8b28010000 mov      ecx, dword ptr [ebx + 0x128]
006300c3: 8d89041e0000 lea      ecx, [ecx + 0x1e04]
006300c9: e852daf1ff   call     0x54db20
006300ce: 648b352c000000 mov      esi, dword ptr fs:[0x2c]
006300d5: 8b3dd0371102 mov      edi, dword ptr [0x21137d0]
006300db: 85c0         test     eax, eax
006300dd: 743f         je       0x63011e
006300df: 8b0cbe       mov      ecx, dword ptr [esi + edi*4]
006300e2: a1d0d0ea01   mov      eax, dword ptr [0x1ead0d0]
006300e7: 3b8134000000 cmp      eax, dword ptr [ecx + 0x34]
006300ed: 0f8f24030000 jg       0x630417
006300f3: 8b8b28010000 mov      ecx, dword ptr [ebx + 0x128]
006300f9: 8d89041e0000 lea      ecx, [ecx + 0x1e04]
006300ff: e81cdaf1ff   call     0x54db20
00630104: 50           push     eax
00630105: 6844b08c01   push     0x18cb044
0063010a: ff35ccd0ea01 push     dword ptr [0x1ead0cc]
00630110: ff35c8d0ea01 push     dword ptr [0x1ead0c8]

; === 152 | 0x640ab0 | create a NetworkServer ===
00640ab0: 682c048d01   push     0x18d042c
00640ab5: 6a06         push     6
00640ab7: 8bce         mov      ecx, esi
00640ab9: e8424bc100   call     0x1255600
00640abe: 6a0d         push     0xd
00640ac0: 684c8d8c01   push     0x18c8d4c
00640ac5: 8d4dc8       lea      ecx, [ebp - 0x38]
00640ac8: c745d800000000 mov      dword ptr [ebp - 0x28], 0
00640acf: c745dc0f000000 mov      dword ptr [ebp - 0x24], 0xf
00640ad6: c645c800     mov      byte ptr [ebp - 0x38], 0
00640ada: e8e137f1ff   call     0x5542c0
00640adf: 8d45c8       lea      eax, [ebp - 0x38]
00640ae2: c645fc1a     mov      byte ptr [ebp - 4], 0x1a
00640ae6: 50           push     eax
00640ae7: 8bcf         mov      ecx, edi
00640ae9: e8325a2600   call     0x8a6520
00640aee: 8b55dc       mov      edx, dword ptr [ebp - 0x24]
00640af1: c645fc19     mov      byte ptr [ebp - 4], 0x19
00640af5: 83fa10       cmp      edx, 0x10
00640af8: 722c         jb       0x640b26
00640afa: 8b4dc8       mov      ecx, dword ptr [ebp - 0x38]
00640afd: 42           inc      edx
00640afe: 8bc1         mov      eax, ecx
00640b00: 81fa00100000 cmp      edx, 0x1000
00640b06: 7214         jb       0x640b1c
00640b08: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00640b0b: 83c223       add      edx, 0x23
00640b0e: 2bc1         sub      eax, ecx
00640b10: 83c0fc       add      eax, -4
00640b13: 83f81f       cmp      eax, 0x1f
00640b16: 0f878a000000 ja       0x640ba6
00640b1c: 52           push     edx
00640b1d: 51           push     ecx
00640b1e: e87d430301   call     0x1674ea0
00640b23: 83c408       add      esp, 8
00640b26: 8d4df0       lea      ecx, [ebp - 0x10]
00640b29: e842313f00   call     0xa33c70
00640b2e: 50           push     eax
00640b2f: 8bcf         mov      ecx, edi
00640b31: c645fc1b     mov      byte ptr [ebp - 4], 0x1b
00640b35: e8f65e0000   call     0x646a30
00640b3a: 8d4df0       lea      ecx, [ebp - 0x10]
00640b3d: c645fc19     mov      byte ptr [ebp - 4], 0x19
00640b41: e8eac1f2ff   call     0x56cd30
00640b46: 8d4df0       lea      ecx, [ebp - 0x10]
00640b49: e822313f00   call     0xa33c70
00640b4e: 50           push     eax
00640b4f: 8bcb         mov      ecx, ebx
00640b51: c645fc1c     mov      byte ptr [ebp - 4], 0x1c

; === 153 | 0x640ac0 | NetworkServer ===
00640ac0: 684c8d8c01   push     0x18c8d4c
00640ac5: 8d4dc8       lea      ecx, [ebp - 0x38]
00640ac8: c745d800000000 mov      dword ptr [ebp - 0x28], 0
00640acf: c745dc0f000000 mov      dword ptr [ebp - 0x24], 0xf
00640ad6: c645c800     mov      byte ptr [ebp - 0x38], 0
00640ada: e8e137f1ff   call     0x5542c0
00640adf: 8d45c8       lea      eax, [ebp - 0x38]
00640ae2: c645fc1a     mov      byte ptr [ebp - 4], 0x1a
00640ae6: 50           push     eax
00640ae7: 8bcf         mov      ecx, edi
00640ae9: e8325a2600   call     0x8a6520
00640aee: 8b55dc       mov      edx, dword ptr [ebp - 0x24]
00640af1: c645fc19     mov      byte ptr [ebp - 4], 0x19
00640af5: 83fa10       cmp      edx, 0x10
00640af8: 722c         jb       0x640b26
00640afa: 8b4dc8       mov      ecx, dword ptr [ebp - 0x38]
00640afd: 42           inc      edx
00640afe: 8bc1         mov      eax, ecx
00640b00: 81fa00100000 cmp      edx, 0x1000
00640b06: 7214         jb       0x640b1c
00640b08: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00640b0b: 83c223       add      edx, 0x23
00640b0e: 2bc1         sub      eax, ecx
00640b10: 83c0fc       add      eax, -4
00640b13: 83f81f       cmp      eax, 0x1f
00640b16: 0f878a000000 ja       0x640ba6
00640b1c: 52           push     edx
00640b1d: 51           push     ecx
00640b1e: e87d430301   call     0x1674ea0
00640b23: 83c408       add      esp, 8
00640b26: 8d4df0       lea      ecx, [ebp - 0x10]
00640b29: e842313f00   call     0xa33c70
00640b2e: 50           push     eax
00640b2f: 8bcf         mov      ecx, edi
00640b31: c645fc1b     mov      byte ptr [ebp - 4], 0x1b
00640b35: e8f65e0000   call     0x646a30
00640b3a: 8d4df0       lea      ecx, [ebp - 0x10]
00640b3d: c645fc19     mov      byte ptr [ebp - 4], 0x19
00640b41: e8eac1f2ff   call     0x56cd30
00640b46: 8d4df0       lea      ecx, [ebp - 0x10]
00640b49: e822313f00   call     0xa33c70
00640b4e: 50           push     eax
00640b4f: 8bcb         mov      ecx, ebx
00640b51: c645fc1c     mov      byte ptr [ebp - 4], 0x1c
00640b55: e8d60d0000   call     0x641930
00640b5a: 8d4df0       lea      ecx, [ebp - 0x10]
00640b5d: c645fc19     mov      byte ptr [ebp - 4], 0x19
00640b61: c7400400000000 mov      dword ptr [eax + 4], 0

; === 154 | 0x640b85 | NetworkServer:Create ===
00640b85: 6844048d01   push     0x18d0444
00640b8a: 50           push     eax
00640b8b: e820690301   call     0x16774b0
00640b90: 83c40c       add      esp, 0xc
00640b93: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
00640b96: 8bc7         mov      eax, edi
00640b98: 5f           pop      edi
00640b99: 5e           pop      esi
00640b9a: 5b           pop      ebx
00640b9b: 64890d00000000 mov      dword ptr fs:[0], ecx
00640ba2: 8be5         mov      esp, ebp
00640ba4: 5d           pop      ebp
00640ba5: c3           ret      
00640ba6: e8f85b0d01   call     0x17167a3
00640bab: cc           int3     
00640bac: cc           int3     
00640bad: cc           int3     
00640bae: cc           int3     
00640baf: cc           int3     
00640bb0: 56           push     esi
00640bb1: 8bf1         mov      esi, ecx
00640bb3: 8b4608       mov      eax, dword ptr [esi + 8]
00640bb6: 85c0         test     eax, eax
00640bb8: 743e         je       0x640bf8
00640bba: 8b4e10       mov      ecx, dword ptr [esi + 0x10]
00640bbd: 2bc8         sub      ecx, eax
00640bbf: 81f900100000 cmp      ecx, 0x1000
00640bc5: 7212         jb       0x640bd9
00640bc7: 8b50fc       mov      edx, dword ptr [eax - 4]
00640bca: 83c123       add      ecx, 0x23
00640bcd: 2bc2         sub      eax, edx
00640bcf: 83c0fc       add      eax, -4
00640bd2: 83f81f       cmp      eax, 0x1f
00640bd5: 7723         ja       0x640bfa
00640bd7: 8bc2         mov      eax, edx
00640bd9: 51           push     ecx
00640bda: 50           push     eax
00640bdb: e8c0420301   call     0x1674ea0
00640be0: c7460800000000 mov      dword ptr [esi + 8], 0
00640be7: 83c408       add      esp, 8
00640bea: c7460c00000000 mov      dword ptr [esi + 0xc], 0
00640bf1: c7461000000000 mov      dword ptr [esi + 0x10], 0
00640bf8: 5e           pop      esi
00640bf9: c3           ret      
00640bfa: e8a45b0d01   call     0x17167a3
00640bff: cc           int3     
00640c00: e91b390800   jmp      0x6c4520
00640c05: cc           int3     
00640c06: cc           int3     
00640c07: cc           int3     
00640c08: cc           int3     
00640c09: cc           int3     
00640c0a: cc           int3     
00640c0b: cc           int3     
00640c0c: cc           int3     
00640c0d: cc           int3     
00640c0e: cc           int3     
00640c0f: cc           int3     
00640c10: 83790808     cmp      dword ptr [ecx + 8], 8
00640c14: 760d         jbe      0x640c23
00640c16: 8b01         mov      eax, dword ptr [ecx]
00640c18: 85c0         test     eax, eax
00640c1a: 7407         je       0x640c23
00640c1c: 50           push     eax
00640c1d: e87e420301   call     0x1674ea0
00640c22: 59           pop      ecx
00640c23: c3           ret      
00640c24: cc           int3     
00640c25: cc           int3     

; === 155 | 0x641358 | NetworkServer:Destroy ===
00641358: 685c048d01   push     0x18d045c
0064135d: 50           push     eax
0064135e: e84d610301   call     0x16774b0
00641363: 83c40c       add      esp, 0xc
00641366: 8bb384040000 mov      esi, dword ptr [ebx + 0x484]
0064136c: 8dbb84040000 lea      edi, [ebx + 0x484]
00641372: ff7604       push     dword ptr [esi + 4]
00641375: 8bcf         mov      ecx, edi
00641377: c745fc00000000 mov      dword ptr [ebp - 4], 0
0064137e: e89d53f3ff   call     0x576720
00641383: 8b07         mov      eax, dword ptr [edi]
00641385: 6a28         push     0x28
00641387: 897004       mov      dword ptr [eax + 4], esi
0064138a: 8b07         mov      eax, dword ptr [edi]
0064138c: 8930         mov      dword ptr [eax], esi
0064138e: 8b07         mov      eax, dword ptr [edi]
00641390: 897008       mov      dword ptr [eax + 8], esi
00641393: c7470400000000 mov      dword ptr [edi + 4], 0
0064139a: ff37         push     dword ptr [edi]
0064139c: e8ff3a0301   call     0x1674ea0
006413a1: 8bb37c040000 mov      esi, dword ptr [ebx + 0x47c]
006413a7: 8dbb7c040000 lea      edi, [ebx + 0x47c]
006413ad: 83c408       add      esp, 8
006413b0: ff7604       push     dword ptr [esi + 4]
006413b3: 8bcf         mov      ecx, edi
006413b5: c745fc01000000 mov      dword ptr [ebp - 4], 1
006413bc: e85f53f3ff   call     0x576720
006413c1: 8b07         mov      eax, dword ptr [edi]
006413c3: 6a28         push     0x28
006413c5: 897004       mov      dword ptr [eax + 4], esi
006413c8: 8b07         mov      eax, dword ptr [edi]
006413ca: 8930         mov      dword ptr [eax], esi
006413cc: 8b07         mov      eax, dword ptr [edi]
006413ce: 897008       mov      dword ptr [eax + 8], esi
006413d1: c7470400000000 mov      dword ptr [edi + 4], 0
006413d8: ff37         push     dword ptr [edi]
006413da: e8c13a0301   call     0x1674ea0
006413df: 83c408       add      esp, 8
006413e2: 8d8b78040000 lea      ecx, [ebx + 0x478]
006413e8: e8c37c0301   call     0x16790b0
006413ed: 33c9         xor      ecx, ecx
006413ef: 8d8364040000 lea      eax, [ebx + 0x464]
006413f5: 8708         xchg     dword ptr [eax], ecx
006413f7: 85c9         test     ecx, ecx
006413f9: 7407         je       0x641402

; === 156 | 0x64239a | NetworkServer:NewIncomingConnection ===
0064239a: 6800078d01   push     0x18d0700
0064239f: 50           push     eax
006423a0: e80b510301   call     0x16774b0
006423a5: 83c40c       add      esp, 0xc
006423a8: 803d1342ee0100 cmp      byte ptr [0x1ee4213], 0
006423af: 7446         je       0x6423f7
006423b1: e85a0d0401   call     0x1683110
006423b6: 0fb6051342ee01 movzx    eax, byte ptr [0x1ee4213]
006423bd: 83ec10       sub      esp, 0x10
006423c0: dd5dd8       fstp     qword ptr [ebp - 0x28]
006423c3: f20f104dd8   movsd    xmm1, qword ptr [ebp - 0x28]
006423c8: 660f5ac9     cvtpd2ps xmm1, xmm1
006423cc: c744240c00000000 mov      dword ptr [esp + 0xc], 0
006423d4: c744240800000000 mov      dword ptr [esp + 8], 0
006423dc: c744240400000000 mov      dword ptr [esp + 4], 0
006423e4: f30f110c24   movss    dword ptr [esp], xmm1
006423e9: 6824078d01   push     0x18d0724
006423ee: 50           push     eax
006423ef: e8dc500301   call     0x16774d0
006423f4: 83c418       add      esp, 0x18
006423f7: 803d8d4ed80100 cmp      byte ptr [0x1d84e8d], 0
006423fe: 746d         je       0x64246d
00642400: 6a7c         push     0x7c
00642402: 6a01         push     1
00642404: ff7508       push     dword ptr [ebp + 8]
00642407: 8d45b0       lea      eax, [ebp - 0x50]
0064240a: 50           push     eax
0064240b: e810f20600   call     0x6b1620
00642410: 83c410       add      esp, 0x10
00642413: 83781410     cmp      dword ptr [eax + 0x14], 0x10
00642417: c645fc04     mov      byte ptr [ebp - 4], 4
0064241b: 7202         jb       0x64241f
0064241d: 8b00         mov      eax, dword ptr [eax]
0064241f: 50           push     eax
00642420: 0fb6058d4ed801 movzx    eax, byte ptr [0x1d84e8d]
00642427: 684c078d01   push     0x18d074c
0064242c: 50           push     eax
0064242d: e8ee500301   call     0x1677520
00642432: 8b55c4       mov      edx, dword ptr [ebp - 0x3c]
00642435: 83c40c       add      esp, 0xc
00642438: c645fc03     mov      byte ptr [ebp - 4], 3
0064243c: 83fa10       cmp      edx, 0x10

; === 157 | 0x64aaab | NetworkServer:Start ===
0064aaab: 6840058d01   push     0x18d0540
0064aab0: 50           push     eax
0064aab1: e8fac90201   call     0x16774b0
0064aab6: 83c40c       add      esp, 0xc
0064aab9: 803d409dd50100 cmp      byte ptr [0x1d59d40], 0
0064aac0: 741a         je       0x64aadc
0064aac2: 8b8ec8000000 mov      ecx, dword ptr [esi + 0xc8]
0064aac8: e85330f0ff   call     0x54db20
0064aacd: ff7510       push     dword ptr [ebp + 0x10]
0064aad0: 8b08         mov      ecx, dword ptr [eax]
0064aad2: 8b9170010000 mov      edx, dword ptr [ecx + 0x170]
0064aad8: 8bc8         mov      ecx, eax
0064aada: ffd2         call     edx
0064aadc: c745dc00000000 mov      dword ptr [ebp - 0x24], 0
0064aae3: c745e000000000 mov      dword ptr [ebp - 0x20], 0
0064aaea: c745e400000000 mov      dword ptr [ebp - 0x1c], 0
0064aaf1: 803d38a5d50100 cmp      byte ptr [0x1d5a538], 0
0064aaf8: c645fc01     mov      byte ptr [ebp - 4], 1
0064aafc: 0f843c010000 je       0x64ac3e
0064ab02: 8d459c       lea      eax, [ebp - 0x64]
0064ab05: 50           push     eax
0064ab06: e82595ffff   call     0x644030
0064ab0b: 8bf0         mov      esi, eax
0064ab0d: c7451000000000 mov      dword ptr [ebp + 0x10], 0
0064ab14: 33c9         xor      ecx, ecx
0064ab16: 8d45dc       lea      eax, [ebp - 0x24]
0064ab19: 83c404       add      esp, 4
0064ab1c: 894df0       mov      dword ptr [ebp - 0x10], ecx
0064ab1f: 33ff         xor      edi, edi
0064ab21: 3bc6         cmp      eax, esi
0064ab23: 7432         je       0x64ab57
0064ab25: 8bc8         mov      ecx, eax
0064ab27: e814cff2ff   call     0x577a40
0064ab2c: 8b4e04       mov      ecx, dword ptr [esi + 4]
0064ab2f: 8b3e         mov      edi, dword ptr [esi]
0064ab31: 8b4608       mov      eax, dword ptr [esi + 8]
0064ab34: c70600000000 mov      dword ptr [esi], 0
0064ab3a: c7460400000000 mov      dword ptr [esi + 4], 0
0064ab41: 897ddc       mov      dword ptr [ebp - 0x24], edi
0064ab44: 894d10       mov      dword ptr [ebp + 0x10], ecx
0064ab47: 894de0       mov      dword ptr [ebp - 0x20], ecx
0064ab4a: 8945e4       mov      dword ptr [ebp - 0x1c], eax
0064ab4d: c7460800000000 mov      dword ptr [esi + 8], 0

; === 158 | 0x64b3bd | NetworkServer:Stop blockDuration(%d) ===
0064b3bd: 68ec058d01   push     0x18d05ec
0064b3c2: 50           push     eax
0064b3c3: e8e8c00201   call     0x16774b0
0064b3c8: 83c40c       add      esp, 0xc
0064b3cb: 8b472c       mov      eax, dword ptr [edi + 0x2c]
0064b3ce: 85c0         test     eax, eax
0064b3d0: 7454         je       0x64b426
0064b3d2: 56           push     esi
0064b3d3: 8b7730       mov      esi, dword ptr [edi + 0x30]
0064b3d6: 85f6         test     esi, esi
0064b3d8: 740a         je       0x64b3e4
0064b3da: f0ff4604     lock inc dword ptr [esi + 4]
0064b3de: 8b472c       mov      eax, dword ptr [edi + 0x2c]
0064b3e1: 8b7730       mov      esi, dword ptr [edi + 0x30]
0064b3e4: 8b4804       mov      ecx, dword ptr [eax + 4]
0064b3e7: 8b00         mov      eax, dword ptr [eax]
0064b3e9: 3bc1         cmp      eax, ecx
0064b3eb: 7410         je       0x64b3fd
0064b3ed: 0f1f00       nop      dword ptr [eax]
0064b3f0: 8b10         mov      edx, dword ptr [eax]
0064b3f2: 83c008       add      eax, 8
0064b3f5: c6422200     mov      byte ptr [edx + 0x22], 0
0064b3f9: 3bc1         cmp      eax, ecx
0064b3fb: 75f3         jne      0x64b3f0
0064b3fd: 85f6         test     esi, esi
0064b3ff: 7424         je       0x64b425
0064b401: 83cbff       or       ebx, 0xffffffff
0064b404: 8bc3         mov      eax, ebx
0064b406: f00fc14604   lock xadd dword ptr [esi + 4], eax
0064b40b: 7515         jne      0x64b422
0064b40d: 8b06         mov      eax, dword ptr [esi]
0064b40f: 8bce         mov      ecx, esi
0064b411: ff10         call     dword ptr [eax]
0064b413: f00fc15e08   lock xadd dword ptr [esi + 8], ebx
0064b418: 4b           dec      ebx
0064b419: 7507         jne      0x64b422
0064b41b: 8b06         mov      eax, dword ptr [esi]
0064b41d: 8bce         mov      ecx, esi
0064b41f: ff5004       call     dword ptr [eax + 4]
0064b422: 8b5d08       mov      ebx, dword ptr [ebp + 8]
0064b425: 5e           pop      esi
0064b426: 8bcf         mov      ecx, edi
0064b428: e8839c2500   call     0x8a50b0
0064b42d: 8b8fc8000000 mov      ecx, dword ptr [edi + 0xc8]
0064b433: e8e826f0ff   call     0x54db20
0064b438: 8bc8         mov      ecx, eax
0064b43a: 8b10         mov      edx, dword ptr [eax]
0064b43c: 8b4238       mov      eax, dword ptr [edx + 0x38]
0064b43f: ffd0         call     eax
0064b441: 84c0         test     al, al
0064b443: 7417         je       0x64b45c
0064b445: 8b8fc8000000 mov      ecx, dword ptr [edi + 0xc8]
0064b44b: e8d026f0ff   call     0x54db20
0064b450: 6a03         push     3
0064b452: 6a00         push     0
0064b454: 53           push     ebx
0064b455: 8b10         mov      edx, dword ptr [eax]
0064b457: 8bc8         mov      ecx, eax
0064b459: ff5234       call     dword ptr [edx + 0x34]
0064b45c: 5f           pop      edi
0064b45d: 5b           pop      ebx

; === 159 | 0x652e38 | SubmitTicket ===
00652e38: 68f41f8d01   push     0x18d1ff4
00652e3d: 6804208d01   push     0x18d2004
00652e42: 68985f8c01   push     0x18c5f98
00652e47: e804962200   call     0x87c450
00652e4c: c687093f000001 mov      byte ptr [edi + 0x3f09], 1
00652e53: 83c418       add      esp, 0x18
00652e56: a15cdcea01   mov      eax, dword ptr [0x1eadc5c]
00652e5b: a808         test     al, 8
00652e5d: 740d         je       0x652e6c
00652e5f: c745fc03000000 mov      dword ptr [ebp - 4], 3
00652e66: 56           push     esi
00652e67: e910030000   jmp      0x65317c
00652e6c: 8d4fa4       lea      ecx, [edi - 0x5c]
00652e6f: c687ec3e000001 mov      byte ptr [edi + 0x3eec], 1
00652e76: 53           push     ebx
00652e77: e8743d0100   call     0x666bf0
00652e7c: 8d45dc       lea      eax, [ebp - 0x24]
00652e7f: c687fc3d000001 mov      byte ptr [edi + 0x3dfc], 1
00652e86: 50           push     eax
00652e87: e864020301   call     0x16830f0
00652e8c: 83c404       add      esp, 4
00652e8f: 8d8f743b0000 lea      ecx, [edi + 0x3b74]
00652e95: 83ec08       sub      esp, 8
00652e98: f20f1000     movsd    xmm0, qword ptr [eax]
00652e9c: f20f5c87643b0000 subsd    xmm0, qword ptr [edi + 0x3b64]
00652ea4: f20f110424   movsd    qword ptr [esp], xmm0
00652ea9: 6810208d01   push     0x18d2010
00652eae: e84dccec00   call     0x151fb00
00652eb3: 8a0d0a42ee01 mov      cl, byte ptr [0x1ee420a]
00652eb9: 84c9         test     cl, cl
00652ebb: 7419         je       0x652ed6
00652ebd: 0fb687143d0000 movzx    eax, byte ptr [edi + 0x3d14]
00652ec4: 50           push     eax
00652ec5: 0fb6c1       movzx    eax, cl
00652ec8: 6820208d01   push     0x18d2020
00652ecd: 50           push     eax
00652ece: e8dd450201   call     0x16774b0
00652ed3: 83c40c       add      esp, 0xc
00652ed6: c745fc04000000 mov      dword ptr [ebp - 4], 4
00652edd: 56           push     esi

; === 160 | 0x652ea9 | ProcessedTicket ===
00652ea9: 6810208d01   push     0x18d2010
00652eae: e84dccec00   call     0x151fb00
00652eb3: 8a0d0a42ee01 mov      cl, byte ptr [0x1ee420a]
00652eb9: 84c9         test     cl, cl
00652ebb: 7419         je       0x652ed6
00652ebd: 0fb687143d0000 movzx    eax, byte ptr [edi + 0x3d14]
00652ec4: 50           push     eax
00652ec5: 0fb6c1       movzx    eax, cl
00652ec8: 6820208d01   push     0x18d2020
00652ecd: 50           push     eax
00652ece: e8dd450201   call     0x16774b0
00652ed3: 83c40c       add      esp, 0xc
00652ed6: c745fc04000000 mov      dword ptr [ebp - 4], 4
00652edd: 56           push     esi
00652ede: e999020000   jmp      0x65317c
00652ee3: 80bf143d000000 cmp      byte ptr [edi + 0x3d14], 0
00652eea: 7551         jne      0x652f3d
00652eec: 803d8f4ed80100 cmp      byte ptr [0x1d84e8f], 0
00652ef3: 743b         je       0x652f30
00652ef5: 6a7c         push     0x7c
00652ef7: 6a01         push     1
00652ef9: 8d45c4       lea      eax, [ebp - 0x3c]
00652efc: 53           push     ebx
00652efd: 50           push     eax
00652efe: e81de70500   call     0x6b1620
00652f03: 83c410       add      esp, 0x10
00652f06: 83781410     cmp      dword ptr [eax + 0x14], 0x10
00652f0a: c645fc05     mov      byte ptr [ebp - 4], 5
00652f0e: 7202         jb       0x652f12
00652f10: 8b00         mov      eax, dword ptr [eax]
00652f12: 50           push     eax
00652f13: 0fb6058f4ed801 movzx    eax, byte ptr [0x1d84e8f]
00652f1a: 683c208d01   push     0x18d203c
00652f1f: 50           push     eax
00652f20: e82b470201   call     0x1677650
00652f25: 83c40c       add      esp, 0xc
00652f28: 8d4dc4       lea      ecx, [ebp - 0x3c]
00652f2b: e880d8efff   call     0x5507b0
00652f30: c745fc06000000 mov      dword ptr [ebp - 4], 6
00652f37: 56           push     esi
00652f38: e93f020000   jmp      0x65317c
00652f3d: 80bfef3e000000 cmp      byte ptr [edi + 0x3eef], 0
00652f44: 741e         je       0x652f64
00652f46: 80bfe23e000002 cmp      byte ptr [edi + 0x3ee2], 2
00652f4d: 7415         je       0x652f64

; === 161 | 0x65c7a9 | AuthenticateTicket ===
0065c7a9: 68381f8d01   push     0x18d1f38
0065c7ae: 6a00         push     0
0065c7b0: 8bce         mov      ecx, esi
0065c7b2: e859e20000   call     0x66aa10
0065c7b7: 68381f8d01   push     0x18d1f38
0065c7bc: 68941d8d01   push     0x18d1d94
0065c7c1: 8bce         mov      ecx, esi
0065c7c3: e858c20000   call     0x668a20
0065c7c8: 56           push     esi
0065c7c9: c6865b3f000001 mov      byte ptr [esi + 0x3f5b], 1
0065c7d0: e80b1effff   call     0x64e5e0
0065c7d5: 8b75dc       mov      esi, dword ptr [ebp - 0x24]
0065c7d8: 8bf8         mov      edi, eax
0065c7da: 83c404       add      esp, 4
0065c7dd: 85ff         test     edi, edi
0065c7df: 7475         je       0x65c856
0065c7e1: 8b16         mov      edx, dword ptr [esi]
0065c7e3: 8bce         mov      ecx, esi
0065c7e5: ff5204       call     dword ptr [edx + 4]
0065c7e8: 50           push     eax
0065c7e9: 8d4d88       lea      ecx, [ebp - 0x78]
0065c7ec: e8ff27efff   call     0x54eff0
0065c7f1: 6a17         push     0x17
0065c7f3: 684c1f8d01   push     0x18d1f4c
0065c7f8: 8d8d70ffffff lea      ecx, [ebp - 0x90]
0065c7fe: c645fc0a     mov      byte ptr [ebp - 4], 0xa
0065c802: c7458000000000 mov      dword ptr [ebp - 0x80], 0
0065c809: c745840f000000 mov      dword ptr [ebp - 0x7c], 0xf
0065c810: c68570ffffff00 mov      byte ptr [ebp - 0x90], 0
0065c817: e8a47aefff   call     0x5542c0
0065c81c: 6a00         push     0
0065c81e: 6a00         push     0
0065c820: 8d4588       lea      eax, [ebp - 0x78]
0065c823: c645fc0b     mov      byte ptr [ebp - 4], 0xb
0065c827: 50           push     eax
0065c828: 8d8570ffffff lea      eax, [ebp - 0x90]
0065c82e: 8bcf         mov      ecx, edi
0065c830: 50           push     eax
0065c831: e8ea0a2700   call     0x8cd320
0065c836: 50           push     eax
0065c837: e894a52d00   call     0x936dd0
0065c83c: 83c414       add      esp, 0x14
0065c83f: 8d8d70ffffff lea      ecx, [ebp - 0x90]
0065c845: e8663fefff   call     0x5507b0
0065c84a: 8d4d88       lea      ecx, [ebp - 0x78]

; === 162 | 0x65c7b7 | AuthenticateTicket ===
0065c7b7: 68381f8d01   push     0x18d1f38
0065c7bc: 68941d8d01   push     0x18d1d94
0065c7c1: 8bce         mov      ecx, esi
0065c7c3: e858c20000   call     0x668a20
0065c7c8: 56           push     esi
0065c7c9: c6865b3f000001 mov      byte ptr [esi + 0x3f5b], 1
0065c7d0: e80b1effff   call     0x64e5e0
0065c7d5: 8b75dc       mov      esi, dword ptr [ebp - 0x24]
0065c7d8: 8bf8         mov      edi, eax
0065c7da: 83c404       add      esp, 4
0065c7dd: 85ff         test     edi, edi
0065c7df: 7475         je       0x65c856
0065c7e1: 8b16         mov      edx, dword ptr [esi]
0065c7e3: 8bce         mov      ecx, esi
0065c7e5: ff5204       call     dword ptr [edx + 4]
0065c7e8: 50           push     eax
0065c7e9: 8d4d88       lea      ecx, [ebp - 0x78]
0065c7ec: e8ff27efff   call     0x54eff0
0065c7f1: 6a17         push     0x17
0065c7f3: 684c1f8d01   push     0x18d1f4c
0065c7f8: 8d8d70ffffff lea      ecx, [ebp - 0x90]
0065c7fe: c645fc0a     mov      byte ptr [ebp - 4], 0xa
0065c802: c7458000000000 mov      dword ptr [ebp - 0x80], 0
0065c809: c745840f000000 mov      dword ptr [ebp - 0x7c], 0xf
0065c810: c68570ffffff00 mov      byte ptr [ebp - 0x90], 0
0065c817: e8a47aefff   call     0x5542c0
0065c81c: 6a00         push     0
0065c81e: 6a00         push     0
0065c820: 8d4588       lea      eax, [ebp - 0x78]
0065c823: c645fc0b     mov      byte ptr [ebp - 4], 0xb
0065c827: 50           push     eax
0065c828: 8d8570ffffff lea      eax, [ebp - 0x90]
0065c82e: 8bcf         mov      ecx, edi
0065c830: 50           push     eax
0065c831: e8ea0a2700   call     0x8cd320
0065c836: 50           push     eax
0065c837: e894a52d00   call     0x936dd0
0065c83c: 83c414       add      esp, 0x14
0065c83f: 8d8d70ffffff lea      ecx, [ebp - 0x90]
0065c845: e8663fefff   call     0x5507b0
0065c84a: 8d4d88       lea      ecx, [ebp - 0x78]
0065c84d: c645fc09     mov      byte ptr [ebp - 4], 9
0065c851: e85a3fefff   call     0x5507b0
0065c856: 803d0a42ee0100 cmp      byte ptr [0x1ee420a], 0
0065c85d: 741d         je       0x65c87c

; === 163 | 0x65c7f3 | Authenticate-TicketFail ===
0065c7f3: 684c1f8d01   push     0x18d1f4c
0065c7f8: 8d8d70ffffff lea      ecx, [ebp - 0x90]
0065c7fe: c645fc0a     mov      byte ptr [ebp - 4], 0xa
0065c802: c7458000000000 mov      dword ptr [ebp - 0x80], 0
0065c809: c745840f000000 mov      dword ptr [ebp - 0x7c], 0xf
0065c810: c68570ffffff00 mov      byte ptr [ebp - 0x90], 0
0065c817: e8a47aefff   call     0x5542c0
0065c81c: 6a00         push     0
0065c81e: 6a00         push     0
0065c820: 8d4588       lea      eax, [ebp - 0x78]
0065c823: c645fc0b     mov      byte ptr [ebp - 4], 0xb
0065c827: 50           push     eax
0065c828: 8d8570ffffff lea      eax, [ebp - 0x90]
0065c82e: 8bcf         mov      ecx, edi
0065c830: 50           push     eax
0065c831: e8ea0a2700   call     0x8cd320
0065c836: 50           push     eax
0065c837: e894a52d00   call     0x936dd0
0065c83c: 83c414       add      esp, 0x14
0065c83f: 8d8d70ffffff lea      ecx, [ebp - 0x90]
0065c845: e8663fefff   call     0x5507b0
0065c84a: 8d4d88       lea      ecx, [ebp - 0x78]
0065c84d: c645fc09     mov      byte ptr [ebp - 4], 9
0065c851: e85a3fefff   call     0x5507b0
0065c856: 803d0a42ee0100 cmp      byte ptr [0x1ee420a], 0
0065c85d: 741d         je       0x65c87c
0065c85f: 8b06         mov      eax, dword ptr [esi]
0065c861: 8bce         mov      ecx, esi
0065c863: ff5004       call     dword ptr [eax + 4]
0065c866: 50           push     eax
0065c867: 0fb6050a42ee01 movzx    eax, byte ptr [0x1ee420a]
0065c86e: 68681f8d01   push     0x18d1f68
0065c873: 50           push     eax
0065c874: e8d7ad0101   call     0x1677650
0065c879: 83c40c       add      esp, 0xc
0065c87c: 6a00         push     0
0065c87e: 6a00         push     0
0065c880: e823fa0a01   call     0x170c2a8
0065c885: 6898daea01   push     0x1eada98
0065c88a: e87a6f0901   call     0x16f3809
0065c88f: 83c404       add      esp, 4
0065c892: 833d98daea01ff cmp      dword ptr [0x1eada98], -1
0065c899: 0f853afbffff jne      0x65c3d9

; === 164 | 0x65c86e | ServerReplicator:InstallRemotePlayer - Authenticate-TicketFail: %s ===
0065c86e: 68681f8d01   push     0x18d1f68
0065c873: 50           push     eax
0065c874: e8d7ad0101   call     0x1677650
0065c879: 83c40c       add      esp, 0xc
0065c87c: 6a00         push     0
0065c87e: 6a00         push     0
0065c880: e823fa0a01   call     0x170c2a8
0065c885: 6898daea01   push     0x1eada98
0065c88a: e87a6f0901   call     0x16f3809
0065c88f: 83c404       add      esp, 4
0065c892: 833d98daea01ff cmp      dword ptr [0x1eada98], -1
0065c899: 0f853afbffff jne      0x65c3d9
0065c89f: 6aff         push     -1
0065c8a1: 68bc1d8d01   push     0x18d1dbc
0065c8a6: 6804598c01   push     0x18c5904
0065c8ab: c745fc00000000 mov      dword ptr [ebp - 4], 0
0065c8b2: e8f911ed00   call     0x152dab0
0065c8b7: 6898daea01   push     0x1eada98
0065c8bc: a390daea01   mov      dword ptr [0x1eada90], eax
0065c8c1: 891594daea01 mov      dword ptr [0x1eada94], edx
0065c8c7: c745fcffffffff mov      dword ptr [ebp - 4], 0xffffffff
0065c8ce: e8ec6e0901   call     0x16f37bf
0065c8d3: 83c410       add      esp, 0x10
0065c8d6: e9fefaffff   jmp      0x65c3d9
0065c8db: 8d45c8       lea      eax, [ebp - 0x38]
0065c8de: 687c1e8d01   push     0x18d1e7c
0065c8e3: 50           push     eax
0065c8e4: e8c78d0101   call     0x16756b0
0065c8e9: 83c408       add      esp, 8
0065c8ec: 8d45c8       lea      eax, [ebp - 0x38]
0065c8ef: 689871c101   push     0x1c17198
0065c8f4: 50           push     eax
0065c8f5: e8aef90a01   call     0x170c2a8
0065c8fa: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
0065c8ff: 84c0         test     al, al
0065c901: 7413         je       0x65c916
0065c903: 6a00         push     0
0065c905: 0fb6c0       movzx    eax, al
0065c908: 68901e8d01   push     0x18d1e90
0065c90d: 50           push     eax
0065c90e: e89dab0101   call     0x16774b0

; === 165 | 0x65c908 | ServerReplicator:InstallRemotePlayer - MissingTicket ===
0065c908: 68901e8d01   push     0x18d1e90
0065c90d: 50           push     eax
0065c90e: e89dab0101   call     0x16774b0
0065c913: 83c40c       add      esp, 0xc
0065c916: 8d45bc       lea      eax, [ebp - 0x44]
0065c919: 68d41c8d01   push     0x18d1cd4
0065c91e: 50           push     eax
0065c91f: e88c8d0101   call     0x16756b0
0065c924: 83c408       add      esp, 8
0065c927: 8d45bc       lea      eax, [ebp - 0x44]
0065c92a: 689871c101   push     0x1c17198
0065c92f: 50           push     eax
0065c930: e873f90a01   call     0x170c2a8
0065c935: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
0065c93a: 84c0         test     al, al
0065c93c: 7413         je       0x65c951
0065c93e: 6a00         push     0
0065c940: 0fb6c0       movzx    eax, al
0065c943: 68c81e8d01   push     0x18d1ec8
0065c948: 50           push     eax
0065c949: e862ab0101   call     0x16774b0
0065c94e: 83c40c       add      esp, 0xc
0065c951: 8bce         mov      ecx, esi
0065c953: e8987aefff   call     0x5543f0
0065c958: 50           push     eax
0065c959: 8d45b0       lea      eax, [ebp - 0x50]
0065c95c: 68201d8d01   push     0x18d1d20
0065c961: 50           push     eax
0065c962: e8498d0101   call     0x16756b0
0065c967: 83c40c       add      esp, 0xc
0065c96a: 8d45b0       lea      eax, [ebp - 0x50]
0065c96d: 689871c101   push     0x1c17198
0065c972: 50           push     eax
0065c973: e830f90a01   call     0x170c2a8
0065c978: 68001f8d01   push     0x18d1f00
0065c97d: e83e8e0101   call     0x16757c0
0065c982: cc           int3     
0065c983: cc           int3     
0065c984: cc           int3     
0065c985: cc           int3     
0065c986: cc           int3     
0065c987: cc           int3     
0065c988: cc           int3     
0065c989: cc           int3     
0065c98a: cc           int3     
0065c98b: cc           int3     
0065c98c: cc           int3     
0065c98d: cc           int3     
0065c98e: cc           int3     
0065c98f: cc           int3     
0065c990: 55           push     ebp
0065c991: 8bec         mov      ebp, esp
0065c993: 6aff         push     -1
0065c995: 68a81f7a01   push     0x17a1fa8
0065c99a: 64a100000000 mov      eax, dword ptr fs:[0]
0065c9a0: 50           push     eax
0065c9a1: 64892500000000 mov      dword ptr fs:[0], esp
0065c9a8: 83ec08       sub      esp, 8

; === 166 | 0x65c919 | missing ticket ===
0065c919: 68d41c8d01   push     0x18d1cd4
0065c91e: 50           push     eax
0065c91f: e88c8d0101   call     0x16756b0
0065c924: 83c408       add      esp, 8
0065c927: 8d45bc       lea      eax, [ebp - 0x44]
0065c92a: 689871c101   push     0x1c17198
0065c92f: 50           push     eax
0065c930: e873f90a01   call     0x170c2a8
0065c935: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
0065c93a: 84c0         test     al, al
0065c93c: 7413         je       0x65c951
0065c93e: 6a00         push     0
0065c940: 0fb6c0       movzx    eax, al
0065c943: 68c81e8d01   push     0x18d1ec8
0065c948: 50           push     eax
0065c949: e862ab0101   call     0x16774b0
0065c94e: 83c40c       add      esp, 0xc
0065c951: 8bce         mov      ecx, esi
0065c953: e8987aefff   call     0x5543f0
0065c958: 50           push     eax
0065c959: 8d45b0       lea      eax, [ebp - 0x50]
0065c95c: 68201d8d01   push     0x18d1d20
0065c961: 50           push     eax
0065c962: e8498d0101   call     0x16756b0
0065c967: 83c40c       add      esp, 0xc
0065c96a: 8d45b0       lea      eax, [ebp - 0x50]
0065c96d: 689871c101   push     0x1c17198
0065c972: 50           push     eax
0065c973: e830f90a01   call     0x170c2a8
0065c978: 68001f8d01   push     0x18d1f00
0065c97d: e83e8e0101   call     0x16757c0
0065c982: cc           int3     
0065c983: cc           int3     
0065c984: cc           int3     
0065c985: cc           int3     
0065c986: cc           int3     
0065c987: cc           int3     
0065c988: cc           int3     
0065c989: cc           int3     
0065c98a: cc           int3     
0065c98b: cc           int3     
0065c98c: cc           int3     
0065c98d: cc           int3     
0065c98e: cc           int3     
0065c98f: cc           int3     
0065c990: 55           push     ebp
0065c991: 8bec         mov      ebp, esp
0065c993: 6aff         push     -1
0065c995: 68a81f7a01   push     0x17a1fa8
0065c99a: 64a100000000 mov      eax, dword ptr fs:[0]
0065c9a0: 50           push     eax
0065c9a1: 64892500000000 mov      dword ptr fs:[0], esp
0065c9a8: 83ec08       sub      esp, 8
0065c9ab: 8b4d08       mov      ecx, dword ptr [ebp + 8]
0065c9ae: 8d45ec       lea      eax, [ebp - 0x14]
0065c9b1: 50           push     eax
0065c9b2: e8d9aaf2ff   call     0x587490
0065c9b7: 8b4dec       mov      ecx, dword ptr [ebp - 0x14]
0065c9ba: c745fc00000000 mov      dword ptr [ebp - 4], 0

; === 167 | 0x65c943 | ServerReplicator:InstallRemotePlayer - DuplicateTicket ===
0065c943: 68c81e8d01   push     0x18d1ec8
0065c948: 50           push     eax
0065c949: e862ab0101   call     0x16774b0
0065c94e: 83c40c       add      esp, 0xc
0065c951: 8bce         mov      ecx, esi
0065c953: e8987aefff   call     0x5543f0
0065c958: 50           push     eax
0065c959: 8d45b0       lea      eax, [ebp - 0x50]
0065c95c: 68201d8d01   push     0x18d1d20
0065c961: 50           push     eax
0065c962: e8498d0101   call     0x16756b0
0065c967: 83c40c       add      esp, 0xc
0065c96a: 8d45b0       lea      eax, [ebp - 0x50]
0065c96d: 689871c101   push     0x1c17198
0065c972: 50           push     eax
0065c973: e830f90a01   call     0x170c2a8
0065c978: 68001f8d01   push     0x18d1f00
0065c97d: e83e8e0101   call     0x16757c0
0065c982: cc           int3     
0065c983: cc           int3     
0065c984: cc           int3     
0065c985: cc           int3     
0065c986: cc           int3     
0065c987: cc           int3     
0065c988: cc           int3     
0065c989: cc           int3     
0065c98a: cc           int3     
0065c98b: cc           int3     
0065c98c: cc           int3     
0065c98d: cc           int3     
0065c98e: cc           int3     
0065c98f: cc           int3     
0065c990: 55           push     ebp
0065c991: 8bec         mov      ebp, esp
0065c993: 6aff         push     -1
0065c995: 68a81f7a01   push     0x17a1fa8
0065c99a: 64a100000000 mov      eax, dword ptr fs:[0]
0065c9a0: 50           push     eax
0065c9a1: 64892500000000 mov      dword ptr fs:[0], esp
0065c9a8: 83ec08       sub      esp, 8
0065c9ab: 8b4d08       mov      ecx, dword ptr [ebp + 8]
0065c9ae: 8d45ec       lea      eax, [ebp - 0x14]
0065c9b1: 50           push     eax
0065c9b2: e8d9aaf2ff   call     0x587490
0065c9b7: 8b4dec       mov      ecx, dword ptr [ebp - 0x14]
0065c9ba: c745fc00000000 mov      dword ptr [ebp - 4], 0
0065c9c1: 85c9         test     ecx, ecx
0065c9c3: 740b         je       0x65c9d0
0065c9c5: 8b891c3c0000 mov      ecx, dword ptr [ecx + 0x3c1c]
0065c9cb: e8a069feff   call     0x643370
0065c9d0: 56           push     esi
0065c9d1: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
0065c9d4: 85f6         test     esi, esi
0065c9d6: 7423         je       0x65c9fb
0065c9d8: 57           push     edi
0065c9d9: 83cfff       or       edi, 0xffffffff
0065c9dc: 8bc7         mov      eax, edi
0065c9de: f00fc14604   lock xadd dword ptr [esi + 4], eax
0065c9e3: 7515         jne      0x65c9fa

; === 168 | 0x65c95c | ticket has already been used: %s ===
0065c95c: 68201d8d01   push     0x18d1d20
0065c961: 50           push     eax
0065c962: e8498d0101   call     0x16756b0
0065c967: 83c40c       add      esp, 0xc
0065c96a: 8d45b0       lea      eax, [ebp - 0x50]
0065c96d: 689871c101   push     0x1c17198
0065c972: 50           push     eax
0065c973: e830f90a01   call     0x170c2a8
0065c978: 68001f8d01   push     0x18d1f00
0065c97d: e83e8e0101   call     0x16757c0
0065c982: cc           int3     
0065c983: cc           int3     
0065c984: cc           int3     
0065c985: cc           int3     
0065c986: cc           int3     
0065c987: cc           int3     
0065c988: cc           int3     
0065c989: cc           int3     
0065c98a: cc           int3     
0065c98b: cc           int3     
0065c98c: cc           int3     
0065c98d: cc           int3     
0065c98e: cc           int3     
0065c98f: cc           int3     
0065c990: 55           push     ebp
0065c991: 8bec         mov      ebp, esp
0065c993: 6aff         push     -1
0065c995: 68a81f7a01   push     0x17a1fa8
0065c99a: 64a100000000 mov      eax, dword ptr fs:[0]
0065c9a0: 50           push     eax
0065c9a1: 64892500000000 mov      dword ptr fs:[0], esp
0065c9a8: 83ec08       sub      esp, 8
0065c9ab: 8b4d08       mov      ecx, dword ptr [ebp + 8]
0065c9ae: 8d45ec       lea      eax, [ebp - 0x14]
0065c9b1: 50           push     eax
0065c9b2: e8d9aaf2ff   call     0x587490
0065c9b7: 8b4dec       mov      ecx, dword ptr [ebp - 0x14]
0065c9ba: c745fc00000000 mov      dword ptr [ebp - 4], 0
0065c9c1: 85c9         test     ecx, ecx
0065c9c3: 740b         je       0x65c9d0
0065c9c5: 8b891c3c0000 mov      ecx, dword ptr [ecx + 0x3c1c]
0065c9cb: e8a069feff   call     0x643370
0065c9d0: 56           push     esi
0065c9d1: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
0065c9d4: 85f6         test     esi, esi
0065c9d6: 7423         je       0x65c9fb
0065c9d8: 57           push     edi
0065c9d9: 83cfff       or       edi, 0xffffffff
0065c9dc: 8bc7         mov      eax, edi
0065c9de: f00fc14604   lock xadd dword ptr [esi + 4], eax
0065c9e3: 7515         jne      0x65c9fa
0065c9e5: 8b06         mov      eax, dword ptr [esi]
0065c9e7: 8bce         mov      ecx, esi
0065c9e9: ff10         call     dword ptr [eax]
0065c9eb: f00fc17e08   lock xadd dword ptr [esi + 8], edi
0065c9f0: 4f           dec      edi
0065c9f1: 7507         jne      0x65c9fa
0065c9f3: 8b06         mov      eax, dword ptr [esi]
0065c9f5: 8bce         mov      ecx, esi
0065c9f7: ff5004       call     dword ptr [eax + 4]
0065c9fa: 5f           pop      edi
0065c9fb: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
0065c9fe: 5e           pop      esi

; === 169 | 0x65c978 | ticket signature not verified. (installRemotePlayer) ===
0065c978: 68001f8d01   push     0x18d1f00
0065c97d: e83e8e0101   call     0x16757c0
0065c982: cc           int3     
0065c983: cc           int3     
0065c984: cc           int3     
0065c985: cc           int3     
0065c986: cc           int3     
0065c987: cc           int3     
0065c988: cc           int3     
0065c989: cc           int3     
0065c98a: cc           int3     
0065c98b: cc           int3     
0065c98c: cc           int3     
0065c98d: cc           int3     
0065c98e: cc           int3     
0065c98f: cc           int3     
0065c990: 55           push     ebp
0065c991: 8bec         mov      ebp, esp
0065c993: 6aff         push     -1
0065c995: 68a81f7a01   push     0x17a1fa8
0065c99a: 64a100000000 mov      eax, dword ptr fs:[0]
0065c9a0: 50           push     eax
0065c9a1: 64892500000000 mov      dword ptr fs:[0], esp
0065c9a8: 83ec08       sub      esp, 8
0065c9ab: 8b4d08       mov      ecx, dword ptr [ebp + 8]
0065c9ae: 8d45ec       lea      eax, [ebp - 0x14]
0065c9b1: 50           push     eax
0065c9b2: e8d9aaf2ff   call     0x587490
0065c9b7: 8b4dec       mov      ecx, dword ptr [ebp - 0x14]
0065c9ba: c745fc00000000 mov      dword ptr [ebp - 4], 0
0065c9c1: 85c9         test     ecx, ecx
0065c9c3: 740b         je       0x65c9d0
0065c9c5: 8b891c3c0000 mov      ecx, dword ptr [ecx + 0x3c1c]
0065c9cb: e8a069feff   call     0x643370
0065c9d0: 56           push     esi
0065c9d1: 8b75f0       mov      esi, dword ptr [ebp - 0x10]
0065c9d4: 85f6         test     esi, esi
0065c9d6: 7423         je       0x65c9fb
0065c9d8: 57           push     edi
0065c9d9: 83cfff       or       edi, 0xffffffff
0065c9dc: 8bc7         mov      eax, edi
0065c9de: f00fc14604   lock xadd dword ptr [esi + 4], eax
0065c9e3: 7515         jne      0x65c9fa
0065c9e5: 8b06         mov      eax, dword ptr [esi]
0065c9e7: 8bce         mov      ecx, esi
0065c9e9: ff10         call     dword ptr [eax]
0065c9eb: f00fc17e08   lock xadd dword ptr [esi + 8], edi
0065c9f0: 4f           dec      edi
0065c9f1: 7507         jne      0x65c9fa
0065c9f3: 8b06         mov      eax, dword ptr [esi]
0065c9f5: 8bce         mov      ecx, esi
0065c9f7: ff5004       call     dword ptr [eax + 4]
0065c9fa: 5f           pop      edi
0065c9fb: 8b4df4       mov      ecx, dword ptr [ebp - 0xc]
0065c9fe: 5e           pop      esi
0065c9ff: 64890d00000000 mov      dword ptr fs:[0], ecx
0065ca06: 8be5         mov      esp, ebp
0065ca08: 5d           pop      ebp
0065ca09: c3           ret      
0065ca0a: cc           int3     
0065ca0b: cc           int3     
0065ca0c: cc           int3     
0065ca0d: cc           int3     
0065ca0e: cc           int3     
0065ca0f: cc           int3     
0065ca10: 55           push     ebp
0065ca11: 8bec         mov      ebp, esp
0065ca13: 6aff         push     -1
0065ca15: 68781d7a01   push     0x17a1d78
0065ca1a: 64a100000000 mov      eax, dword ptr fs:[0]

; === 170 | 0x65d81d | TicketCheck ===
0065d81d: b8083b8d01   mov      eax, 0x18d3b08
0065d822: 5d           pop      ebp
0065d823: c3           ret      
0065d824: b8143b8d01   mov      eax, 0x18d3b14
0065d829: 5d           pop      ebp
0065d82a: c3           ret      
0065d82b: b8283b8d01   mov      eax, 0x18d3b28
0065d830: 5d           pop      ebp
0065d831: c3           ret      
0065d832: b8383b8d01   mov      eax, 0x18d3b38
0065d837: 5d           pop      ebp
0065d838: c3           ret      
0065d839: b8443b8d01   mov      eax, 0x18d3b44
0065d83e: 5d           pop      ebp
0065d83f: c3           ret      
0065d840: b814cd8c01   mov      eax, 0x18ccd14
0065d845: 5d           pop      ebp
0065d846: c3           ret      
0065d847: b824cd8c01   mov      eax, 0x18ccd24
0065d84c: 5d           pop      ebp
0065d84d: c3           ret      
0065d84e: b8543b8d01   mov      eax, 0x18d3b54
0065d853: 5d           pop      ebp
0065d854: c3           ret      
0065d855: b8683b8d01   mov      eax, 0x18d3b68
0065d85a: 5d           pop      ebp
0065d85b: c3           ret      
0065d85c: b8743b8d01   mov      eax, 0x18d3b74
0065d861: 5d           pop      ebp
0065d862: c3           ret      
0065d863: b8803b8d01   mov      eax, 0x18d3b80
0065d868: 5d           pop      ebp
0065d869: c3           ret      
0065d86a: b88c3b8d01   mov      eax, 0x18d3b8c
0065d86f: 5d           pop      ebp
0065d870: c3           ret      
0065d871: 0f1f00       nop      dword ptr [eax]
0065d874: 75d7         jne      0x65d84d
0065d876: 65007cd765   add      byte ptr gs:[edi + edx*8 + 0x65], bh
0065d87b: 0083d765008a add      byte ptr [ebx - 0x75ff9a29], al
0065d881: d7           xlatb    
0065d882: 650091d7650098 add      byte ptr gs:[ecx - 0x67ff9a29], dl
0065d889: d7           xlatb    
0065d88a: 65009fd76500a6 add      byte ptr gs:[edi - 0x59ff9a29], bl
0065d891: d7           xlatb    
0065d892: 6500add76500b4 add      byte ptr gs:[ebp - 0x4bff9a29], ch
0065d899: d7           xlatb    
0065d89a: 6500bbd76500c2 add      byte ptr gs:[ebx - 0x3dff9a29], bh
0065d8a1: d7           xlatb    
0065d8a2: 6500c9       add      cl, cl
0065d8a5: d7           xlatb    
0065d8a6: 6500d0       add      al, dl
0065d8a9: d7           xlatb    
0065d8aa: 6500d7       add      bh, dl
0065d8ad: d7           xlatb    
0065d8ae: 6500de       add      dh, bl
0065d8b1: d7           xlatb    
0065d8b2: 6500e5       add      ch, ah
0065d8b5: d7           xlatb    
0065d8b6: 6500ec       add      ah, ch
0065d8b9: d7           xlatb    
0065d8ba: 6500f3       add      bl, dh
0065d8bd: d7           xlatb    

; === 171 | 0x66266e | PreauthenticateTicket ===
0066266e: 687c1d8d01   push     0x18d1d7c
00662673: 6a00         push     0
00662675: 8bce         mov      ecx, esi
00662677: e894830000   call     0x66aa10
0066267c: 687c1d8d01   push     0x18d1d7c
00662681: 68941d8d01   push     0x18d1d94
00662686: 8bce         mov      ecx, esi
00662688: e893630000   call     0x668a20
0066268d: 56           push     esi
0066268e: c6865b3f000001 mov      byte ptr [esi + 0x3f5b], 1
00662695: e846bffeff   call     0x64e5e0
0066269a: 8bf0         mov      esi, eax
0066269c: 83c404       add      esp, 4
0066269f: 85f6         test     esi, esi
006626a1: 7466         je       0x662709
006626a3: 8b4de0       mov      ecx, dword ptr [ebp - 0x20]
006626a6: 8b11         mov      edx, dword ptr [ecx]
006626a8: ff5204       call     dword ptr [edx + 4]
006626ab: 50           push     eax
006626ac: 8d4d98       lea      ecx, [ebp - 0x68]
006626af: e83cc9eeff   call     0x54eff0
006626b4: 6a1a         push     0x1a
006626b6: 68a01d8d01   push     0x18d1da0
006626bb: 8d4db0       lea      ecx, [ebp - 0x50]
006626be: c645fc04     mov      byte ptr [ebp - 4], 4
006626c2: c745c000000000 mov      dword ptr [ebp - 0x40], 0
006626c9: c745c40f000000 mov      dword ptr [ebp - 0x3c], 0xf
006626d0: c645b000     mov      byte ptr [ebp - 0x50], 0
006626d4: e8e71befff   call     0x5542c0
006626d9: 6a00         push     0
006626db: 6a00         push     0
006626dd: 8d4598       lea      eax, [ebp - 0x68]
006626e0: c645fc05     mov      byte ptr [ebp - 4], 5
006626e4: 50           push     eax
006626e5: 8d45b0       lea      eax, [ebp - 0x50]
006626e8: 8bce         mov      ecx, esi
006626ea: 50           push     eax
006626eb: e830ac2600   call     0x8cd320
006626f0: 50           push     eax
006626f1: e8da462d00   call     0x936dd0
006626f6: 83c414       add      esp, 0x14
006626f9: 8d4db0       lea      ecx, [ebp - 0x50]
006626fc: e8afe0eeff   call     0x5507b0
00662701: 8d4d98       lea      ecx, [ebp - 0x68]
00662704: e8a7e0eeff   call     0x5507b0
00662709: b839266600   mov      eax, 0x662639
0066270e: c3           ret      

; === 172 | 0x66267c | PreauthenticateTicket ===
0066267c: 687c1d8d01   push     0x18d1d7c
00662681: 68941d8d01   push     0x18d1d94
00662686: 8bce         mov      ecx, esi
00662688: e893630000   call     0x668a20
0066268d: 56           push     esi
0066268e: c6865b3f000001 mov      byte ptr [esi + 0x3f5b], 1
00662695: e846bffeff   call     0x64e5e0
0066269a: 8bf0         mov      esi, eax
0066269c: 83c404       add      esp, 4
0066269f: 85f6         test     esi, esi
006626a1: 7466         je       0x662709
006626a3: 8b4de0       mov      ecx, dword ptr [ebp - 0x20]
006626a6: 8b11         mov      edx, dword ptr [ecx]
006626a8: ff5204       call     dword ptr [edx + 4]
006626ab: 50           push     eax
006626ac: 8d4d98       lea      ecx, [ebp - 0x68]
006626af: e83cc9eeff   call     0x54eff0
006626b4: 6a1a         push     0x1a
006626b6: 68a01d8d01   push     0x18d1da0
006626bb: 8d4db0       lea      ecx, [ebp - 0x50]
006626be: c645fc04     mov      byte ptr [ebp - 4], 4
006626c2: c745c000000000 mov      dword ptr [ebp - 0x40], 0
006626c9: c745c40f000000 mov      dword ptr [ebp - 0x3c], 0xf
006626d0: c645b000     mov      byte ptr [ebp - 0x50], 0
006626d4: e8e71befff   call     0x5542c0
006626d9: 6a00         push     0
006626db: 6a00         push     0
006626dd: 8d4598       lea      eax, [ebp - 0x68]
006626e0: c645fc05     mov      byte ptr [ebp - 4], 5
006626e4: 50           push     eax
006626e5: 8d45b0       lea      eax, [ebp - 0x50]
006626e8: 8bce         mov      ecx, esi
006626ea: 50           push     eax
006626eb: e830ac2600   call     0x8cd320
006626f0: 50           push     eax
006626f1: e8da462d00   call     0x936dd0
006626f6: 83c414       add      esp, 0x14
006626f9: 8d4db0       lea      ecx, [ebp - 0x50]
006626fc: e8afe0eeff   call     0x5507b0
00662701: 8d4d98       lea      ecx, [ebp - 0x68]
00662704: e8a7e0eeff   call     0x5507b0
00662709: b839266600   mov      eax, 0x662639
0066270e: c3           ret      
0066270f: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
00662714: 84c0         test     al, al
00662716: 7413         je       0x66272b
00662718: 6a00         push     0
0066271a: 0fb6c0       movzx    eax, al
0066271d: 689c1c8d01   push     0x18d1c9c

; === 173 | 0x6626b6 | Preauthenticate-TicketFail ===
006626b6: 68a01d8d01   push     0x18d1da0
006626bb: 8d4db0       lea      ecx, [ebp - 0x50]
006626be: c645fc04     mov      byte ptr [ebp - 4], 4
006626c2: c745c000000000 mov      dword ptr [ebp - 0x40], 0
006626c9: c745c40f000000 mov      dword ptr [ebp - 0x3c], 0xf
006626d0: c645b000     mov      byte ptr [ebp - 0x50], 0
006626d4: e8e71befff   call     0x5542c0
006626d9: 6a00         push     0
006626db: 6a00         push     0
006626dd: 8d4598       lea      eax, [ebp - 0x68]
006626e0: c645fc05     mov      byte ptr [ebp - 4], 5
006626e4: 50           push     eax
006626e5: 8d45b0       lea      eax, [ebp - 0x50]
006626e8: 8bce         mov      ecx, esi
006626ea: 50           push     eax
006626eb: e830ac2600   call     0x8cd320
006626f0: 50           push     eax
006626f1: e8da462d00   call     0x936dd0
006626f6: 83c414       add      esp, 0x14
006626f9: 8d4db0       lea      ecx, [ebp - 0x50]
006626fc: e8afe0eeff   call     0x5507b0
00662701: 8d4d98       lea      ecx, [ebp - 0x68]
00662704: e8a7e0eeff   call     0x5507b0
00662709: b839266600   mov      eax, 0x662639
0066270e: c3           ret      
0066270f: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
00662714: 84c0         test     al, al
00662716: 7413         je       0x66272b
00662718: 6a00         push     0
0066271a: 0fb6c0       movzx    eax, al
0066271d: 689c1c8d01   push     0x18d1c9c
00662722: 50           push     eax
00662723: e8884d0101   call     0x16774b0
00662728: 83c40c       add      esp, 0xc
0066272b: 8d45d4       lea      eax, [ebp - 0x2c]
0066272e: 68d41c8d01   push     0x18d1cd4
00662733: 50           push     eax
00662734: e8772f0101   call     0x16756b0
00662739: 83c408       add      esp, 8
0066273c: 8d45d4       lea      eax, [ebp - 0x2c]
0066273f: 689871c101   push     0x1c17198
00662744: 50           push     eax
00662745: e85e9b0a01   call     0x170c2a8
0066274a: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
0066274f: 84c0         test     al, al
00662751: 7413         je       0x662766
00662753: 6a00         push     0
00662755: 0fb6c0       movzx    eax, al
00662758: 68e41c8d01   push     0x18d1ce4

; === 174 | 0x66271d | ServerReplicator:preauthenticatePlayer - MissingTicket ===
0066271d: 689c1c8d01   push     0x18d1c9c
00662722: 50           push     eax
00662723: e8884d0101   call     0x16774b0
00662728: 83c40c       add      esp, 0xc
0066272b: 8d45d4       lea      eax, [ebp - 0x2c]
0066272e: 68d41c8d01   push     0x18d1cd4
00662733: 50           push     eax
00662734: e8772f0101   call     0x16756b0
00662739: 83c408       add      esp, 8
0066273c: 8d45d4       lea      eax, [ebp - 0x2c]
0066273f: 689871c101   push     0x1c17198
00662744: 50           push     eax
00662745: e85e9b0a01   call     0x170c2a8
0066274a: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
0066274f: 84c0         test     al, al
00662751: 7413         je       0x662766
00662753: 6a00         push     0
00662755: 0fb6c0       movzx    eax, al
00662758: 68e41c8d01   push     0x18d1ce4
0066275d: 50           push     eax
0066275e: e84d4d0101   call     0x16774b0
00662763: 83c40c       add      esp, 0xc
00662766: 8bcf         mov      ecx, edi
00662768: e8831cefff   call     0x5543f0
0066276d: 50           push     eax
0066276e: 8d45c8       lea      eax, [ebp - 0x38]
00662771: 68201d8d01   push     0x18d1d20
00662776: 50           push     eax
00662777: e8342f0101   call     0x16756b0
0066277c: 83c40c       add      esp, 0xc
0066277f: 8d45c8       lea      eax, [ebp - 0x38]
00662782: 689871c101   push     0x1c17198
00662787: 50           push     eax
00662788: e81b9b0a01   call     0x170c2a8
0066278d: 68441d8d01   push     0x18d1d44
00662792: e829300101   call     0x16757c0
00662797: cc           int3     
00662798: cc           int3     
00662799: cc           int3     
0066279a: cc           int3     
0066279b: cc           int3     
0066279c: cc           int3     
0066279d: cc           int3     
0066279e: cc           int3     
0066279f: cc           int3     
006627a0: 55           push     ebp
006627a1: 8bec         mov      ebp, esp
006627a3: 6aff         push     -1
006627a5: 6814277a01   push     0x17a2714
006627aa: 64a100000000 mov      eax, dword ptr fs:[0]
006627b0: 50           push     eax
006627b1: 64892500000000 mov      dword ptr fs:[0], esp
006627b8: 81ec94000000 sub      esp, 0x94
006627be: 53           push     ebx

; === 175 | 0x66272e | missing ticket ===
0066272e: 68d41c8d01   push     0x18d1cd4
00662733: 50           push     eax
00662734: e8772f0101   call     0x16756b0
00662739: 83c408       add      esp, 8
0066273c: 8d45d4       lea      eax, [ebp - 0x2c]
0066273f: 689871c101   push     0x1c17198
00662744: 50           push     eax
00662745: e85e9b0a01   call     0x170c2a8
0066274a: a08e4ed801   mov      al, byte ptr [0x1d84e8e]
0066274f: 84c0         test     al, al
00662751: 7413         je       0x662766
00662753: 6a00         push     0
00662755: 0fb6c0       movzx    eax, al
00662758: 68e41c8d01   push     0x18d1ce4
0066275d: 50           push     eax
0066275e: e84d4d0101   call     0x16774b0
00662763: 83c40c       add      esp, 0xc
00662766: 8bcf         mov      ecx, edi
00662768: e8831cefff   call     0x5543f0
0066276d: 50           push     eax
0066276e: 8d45c8       lea      eax, [ebp - 0x38]
00662771: 68201d8d01   push     0x18d1d20
00662776: 50           push     eax
00662777: e8342f0101   call     0x16756b0
0066277c: 83c40c       add      esp, 0xc
0066277f: 8d45c8       lea      eax, [ebp - 0x38]
00662782: 689871c101   push     0x1c17198
00662787: 50           push     eax
00662788: e81b9b0a01   call     0x170c2a8
0066278d: 68441d8d01   push     0x18d1d44
00662792: e829300101   call     0x16757c0
00662797: cc           int3     
00662798: cc           int3     
00662799: cc           int3     
0066279a: cc           int3     
0066279b: cc           int3     
0066279c: cc           int3     
0066279d: cc           int3     
0066279e: cc           int3     
0066279f: cc           int3     
006627a0: 55           push     ebp
006627a1: 8bec         mov      ebp, esp
006627a3: 6aff         push     -1
006627a5: 6814277a01   push     0x17a2714
006627aa: 64a100000000 mov      eax, dword ptr fs:[0]
006627b0: 50           push     eax
006627b1: 64892500000000 mov      dword ptr fs:[0], esp
006627b8: 81ec94000000 sub      esp, 0x94
006627be: 53           push     ebx
006627bf: 56           push     esi
006627c0: 57           push     edi
006627c1: 8bf9         mov      edi, ecx
006627c3: c745d800000000 mov      dword ptr [ebp - 0x28], 0
006627ca: 8b4d08       mov      ecx, dword ptr [ebp + 8]
006627cd: 8d45b4       lea      eax, [ebp - 0x4c]
006627d0: 50           push     eax

; === 176 | 0x662758 | ServerReplicator:preauthenticatePlayer - DuplicateTicket ===
00662758: 68e41c8d01   push     0x18d1ce4
0066275d: 50           push     eax
0066275e: e84d4d0101   call     0x16774b0
00662763: 83c40c       add      esp, 0xc
00662766: 8bcf         mov      ecx, edi
00662768: e8831cefff   call     0x5543f0
0066276d: 50           push     eax
0066276e: 8d45c8       lea      eax, [ebp - 0x38]
00662771: 68201d8d01   push     0x18d1d20
00662776: 50           push     eax
00662777: e8342f0101   call     0x16756b0
0066277c: 83c40c       add      esp, 0xc
0066277f: 8d45c8       lea      eax, [ebp - 0x38]
00662782: 689871c101   push     0x1c17198
00662787: 50           push     eax
00662788: e81b9b0a01   call     0x170c2a8
0066278d: 68441d8d01   push     0x18d1d44
00662792: e829300101   call     0x16757c0
00662797: cc           int3     
00662798: cc           int3     
00662799: cc           int3     
0066279a: cc           int3     
0066279b: cc           int3     
0066279c: cc           int3     
0066279d: cc           int3     
0066279e: cc           int3     
0066279f: cc           int3     
006627a0: 55           push     ebp
006627a1: 8bec         mov      ebp, esp
006627a3: 6aff         push     -1
006627a5: 6814277a01   push     0x17a2714
006627aa: 64a100000000 mov      eax, dword ptr fs:[0]
006627b0: 50           push     eax
006627b1: 64892500000000 mov      dword ptr fs:[0], esp
006627b8: 81ec94000000 sub      esp, 0x94
006627be: 53           push     ebx
006627bf: 56           push     esi
006627c0: 57           push     edi
006627c1: 8bf9         mov      edi, ecx
006627c3: c745d800000000 mov      dword ptr [ebp - 0x28], 0
006627ca: 8b4d08       mov      ecx, dword ptr [ebp + 8]
006627cd: 8d45b4       lea      eax, [ebp - 0x4c]
006627d0: 50           push     eax
006627d1: 897db0       mov      dword ptr [ebp - 0x50], edi
006627d4: e8f7a30400   call     0x6acbd0
006627d9: 33c9         xor      ecx, ecx
006627db: c745fc00000000 mov      dword ptr [ebp - 4], 0
006627e2: b301         mov      bl, 1
006627e4: 394dc4       cmp      dword ptr [ebp - 0x3c], ecx
006627e7: 7631         jbe      0x66281a
006627e9: 0f1f8000000000 nop      dword ptr [eax]
006627f0: 837dc810     cmp      dword ptr [ebp - 0x38], 0x10
006627f4: 8d45b4       lea      eax, [ebp - 0x4c]
006627f7: 0f4345b4     cmovae   eax, dword ptr [ebp - 0x4c]
006627fb: 803408aa     xor      byte ptr [eax + ecx], 0xaa

; === 177 | 0x662771 | ticket has already been used: %s ===
00662771: 68201d8d01   push     0x18d1d20
00662776: 50           push     eax
00662777: e8342f0101   call     0x16756b0
0066277c: 83c40c       add      esp, 0xc
0066277f: 8d45c8       lea      eax, [ebp - 0x38]
00662782: 689871c101   push     0x1c17198
00662787: 50           push     eax
00662788: e81b9b0a01   call     0x170c2a8
0066278d: 68441d8d01   push     0x18d1d44
00662792: e829300101   call     0x16757c0
00662797: cc           int3     
00662798: cc           int3     
00662799: cc           int3     
0066279a: cc           int3     
0066279b: cc           int3     
0066279c: cc           int3     
0066279d: cc           int3     
0066279e: cc           int3     
0066279f: cc           int3     
006627a0: 55           push     ebp
006627a1: 8bec         mov      ebp, esp
006627a3: 6aff         push     -1
006627a5: 6814277a01   push     0x17a2714
006627aa: 64a100000000 mov      eax, dword ptr fs:[0]
006627b0: 50           push     eax
006627b1: 64892500000000 mov      dword ptr fs:[0], esp
006627b8: 81ec94000000 sub      esp, 0x94
006627be: 53           push     ebx
006627bf: 56           push     esi
006627c0: 57           push     edi
006627c1: 8bf9         mov      edi, ecx
006627c3: c745d800000000 mov      dword ptr [ebp - 0x28], 0
006627ca: 8b4d08       mov      ecx, dword ptr [ebp + 8]
006627cd: 8d45b4       lea      eax, [ebp - 0x4c]
006627d0: 50           push     eax
006627d1: 897db0       mov      dword ptr [ebp - 0x50], edi
006627d4: e8f7a30400   call     0x6acbd0
006627d9: 33c9         xor      ecx, ecx
006627db: c745fc00000000 mov      dword ptr [ebp - 4], 0
006627e2: b301         mov      bl, 1
006627e4: 394dc4       cmp      dword ptr [ebp - 0x3c], ecx
006627e7: 7631         jbe      0x66281a
006627e9: 0f1f8000000000 nop      dword ptr [eax]
006627f0: 837dc810     cmp      dword ptr [ebp - 0x38], 0x10
006627f4: 8d45b4       lea      eax, [ebp - 0x4c]
006627f7: 0f4345b4     cmovae   eax, dword ptr [ebp - 0x4c]
006627fb: 803408aa     xor      byte ptr [eax + ecx], 0xaa
006627ff: 8d45b4       lea      eax, [ebp - 0x4c]
00662802: 837dc810     cmp      dword ptr [ebp - 0x38], 0x10
00662806: 0f4345b4     cmovae   eax, dword ptr [ebp - 0x4c]
0066280a: 803c0880     cmp      byte ptr [eax + ecx], 0x80
0066280e: 7708         ja       0x662818
00662810: 41           inc      ecx
00662811: 3b4dc4       cmp      ecx, dword ptr [ebp - 0x3c]

; === 178 | 0x66278d | ticket signature not verified. (preauthenticatePlayer) ===
0066278d: 68441d8d01   push     0x18d1d44
00662792: e829300101   call     0x16757c0
00662797: cc           int3     
00662798: cc           int3     
00662799: cc           int3     
0066279a: cc           int3     
0066279b: cc           int3     
0066279c: cc           int3     
0066279d: cc           int3     
0066279e: cc           int3     
0066279f: cc           int3     
006627a0: 55           push     ebp
006627a1: 8bec         mov      ebp, esp
006627a3: 6aff         push     -1
006627a5: 6814277a01   push     0x17a2714
006627aa: 64a100000000 mov      eax, dword ptr fs:[0]
006627b0: 50           push     eax
006627b1: 64892500000000 mov      dword ptr fs:[0], esp
006627b8: 81ec94000000 sub      esp, 0x94
006627be: 53           push     ebx
006627bf: 56           push     esi
006627c0: 57           push     edi
006627c1: 8bf9         mov      edi, ecx
006627c3: c745d800000000 mov      dword ptr [ebp - 0x28], 0
006627ca: 8b4d08       mov      ecx, dword ptr [ebp + 8]
006627cd: 8d45b4       lea      eax, [ebp - 0x4c]
006627d0: 50           push     eax
006627d1: 897db0       mov      dword ptr [ebp - 0x50], edi
006627d4: e8f7a30400   call     0x6acbd0
006627d9: 33c9         xor      ecx, ecx
006627db: c745fc00000000 mov      dword ptr [ebp - 4], 0
006627e2: b301         mov      bl, 1
006627e4: 394dc4       cmp      dword ptr [ebp - 0x3c], ecx
006627e7: 7631         jbe      0x66281a
006627e9: 0f1f8000000000 nop      dword ptr [eax]
006627f0: 837dc810     cmp      dword ptr [ebp - 0x38], 0x10
006627f4: 8d45b4       lea      eax, [ebp - 0x4c]
006627f7: 0f4345b4     cmovae   eax, dword ptr [ebp - 0x4c]
006627fb: 803408aa     xor      byte ptr [eax + ecx], 0xaa
006627ff: 8d45b4       lea      eax, [ebp - 0x4c]
00662802: 837dc810     cmp      dword ptr [ebp - 0x38], 0x10
00662806: 0f4345b4     cmovae   eax, dword ptr [ebp - 0x4c]
0066280a: 803c0880     cmp      byte ptr [eax + ecx], 0x80
0066280e: 7708         ja       0x662818
00662810: 41           inc      ecx
00662811: 3b4dc4       cmp      ecx, dword ptr [ebp - 0x3c]
00662814: 72da         jb       0x6627f0
00662816: eb02         jmp      0x66281a
00662818: 32db         xor      bl, bl
0066281a: 833d7cdaea0100 cmp      dword ptr [0x1eada7c], 0
00662821: 0f8580030000 jne      0x662ba7
00662827: 6a06         push     6
00662829: 6880268d01   push     0x18d2680
0066282e: 8d4ddc       lea      ecx, [ebp - 0x24]

; === 179 | 0x664c1a | Fake Join Data ===
00664c1a: 68bc258d01   push     0x18d25bc
00664c1f: 685cb28c01   push     0x18cb25c
00664c24: 68985f8c01   push     0x18c5f98
00664c29: e822782100   call     0x87c450
00664c2e: 8b13         mov      edx, dword ptr [ebx]
00664c30: 83c418       add      esp, 0x18
00664c33: 33c0         xor      eax, eax
00664c35: 8bcb         mov      ecx, ebx
00664c37: 833da8a5d50101 cmp      dword ptr [0x1d5a5a8], 1
00664c3e: 6a00         push     0
00664c40: 68cc258d01   push     0x18d25cc
00664c45: 0f9fc0       setg     al
00664c48: 50           push     eax
00664c49: 6a18         push     0x18
00664c4b: 68e0258d01   push     0x18d25e0
00664c50: ff9290020000 call     dword ptr [edx + 0x290]
00664c56: 5f           pop      edi
00664c57: 5e           pop      esi
00664c58: c683623f000001 mov      byte ptr [ebx + 0x3f62], 1
00664c5f: 5b           pop      ebx
00664c60: 5d           pop      ebp
00664c61: c20400       ret      4
00664c64: cc           int3     
00664c65: cc           int3     
00664c66: cc           int3     
00664c67: cc           int3     
00664c68: cc           int3     
00664c69: cc           int3     
00664c6a: cc           int3     
00664c6b: cc           int3     
00664c6c: cc           int3     
00664c6d: cc           int3     
00664c6e: cc           int3     
00664c6f: cc           int3     
00664c70: 55           push     ebp
00664c71: 8bec         mov      ebp, esp
00664c73: 64a100000000 mov      eax, dword ptr fs:[0]
00664c79: 6aff         push     -1
00664c7b: 6805297a01   push     0x17a2905
00664c80: 50           push     eax
00664c81: 64892500000000 mov      dword ptr fs:[0], esp
00664c88: 81ecf8000000 sub      esp, 0xf8
00664c8e: 53           push     ebx
00664c8f: 56           push     esi
00664c90: 57           push     edi
00664c91: 8bf9         mov      edi, ecx
00664c93: 8b8fd03d0000 mov      ecx, dword ptr [edi + 0x3dd0]
00664c99: 85c9         test     ecx, ecx
00664c9b: 0f84920a0000 je       0x665733
00664ca1: 83796c00     cmp      dword ptr [ecx + 0x6c], 0
00664ca5: 0f84880a0000 je       0x665733
00664cab: 33f6         xor      esi, esi
00664cad: c745ac04000000 mov      dword ptr [ebp - 0x54], 4
00664cb4: 8d45ac       lea      eax, [ebp - 0x54]
00664cb7: c745b000000000 mov      dword ptr [ebp - 0x50], 0
00664cbe: 32ff         xor      bh, bh

; === 180 | 0x666c8a | ServerReplicator:processTicket ===
00666c8a: 6854218d01   push     0x18d2154
00666c8f: 50           push     eax
00666c90: e81b080101   call     0x16774b0
00666c95: 83c40c       add      esp, 0xc
00666c98: 83bf843d000000 cmp      dword ptr [edi + 0x3d84], 0
00666c9f: 6a00         push     0
00666ca1: 0f840f010000 je       0x666db6
00666ca7: 8b07         mov      eax, dword ptr [edi]
00666ca9: 8bcf         mov      ecx, edi
00666cab: 6a00         push     0
00666cad: 6a02         push     2
00666caf: 6a04         push     4
00666cb1: 6888cc8c01   push     0x18ccc88
00666cb6: 6809010000   push     0x109
00666cbb: ff9094020000 call     dword ptr [eax + 0x294]
00666cc1: 8b5580       mov      edx, dword ptr [ebp - 0x80]
00666cc4: 83fa10       cmp      edx, 0x10
00666cc7: 722f         jb       0x666cf8
00666cc9: 8b8d6cffffff mov      ecx, dword ptr [ebp - 0x94]
00666ccf: 42           inc      edx
00666cd0: 8bc1         mov      eax, ecx
00666cd2: 81fa00100000 cmp      edx, 0x1000
00666cd8: 7214         jb       0x666cee
00666cda: 8b49fc       mov      ecx, dword ptr [ecx - 4]
00666cdd: 83c223       add      edx, 0x23
00666ce0: 2bc1         sub      eax, ecx
00666ce2: 83c0fc       add      eax, -4
00666ce5: 83f81f       cmp      eax, 0x1f
00666ce8: 0f879a190000 ja       0x668688
00666cee: 52           push     edx
00666cef: 51           push     ecx
00666cf0: e8abe10001   call     0x1674ea0
00666cf5: 83c408       add      esp, 8
00666cf8: 8b9568ffffff mov      edx, dword ptr [ebp - 0x98]
00666cfe: c7857cffffff00000000 mov      dword ptr [ebp - 0x84], 0
00666d08: c745800f000000 mov      dword ptr [ebp - 0x80], 0xf
00666d0f: c6856cffffff00 mov      byte ptr [ebp - 0x94], 0
00666d16: 83fa10       cmp      edx, 0x10
00666d19: 722f         jb       0x666d4a
00666d1b: 8b8d54ffffff mov      ecx, dword ptr [ebp - 0xac]
00666d21: 42           inc      edx
00666d22: 8bc1         mov      eax, ecx
00666d24: 81fa00100000 cmp      edx, 0x1000
00666d2a: 7214         jb       0x666d40
