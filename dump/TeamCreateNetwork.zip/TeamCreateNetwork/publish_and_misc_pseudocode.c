// WARNING: partial, inferred-entry pseudocode from references. No whole-program analysis.

// referenced at 0x004719a7, inferred function entry 004719a7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004719a7(void)

{
  _DAT_01ea8d90 = func_0x01677f50(&UNK_018c56d8);
  return;
}



// referenced at 0x00471f07, inferred function entry 00471f07

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00471f07(void)

{
  _DAT_01ea93a8 = func_0x01677f50(&UNK_018c8208);
  return;
}



// referenced at 0x00471f27, inferred function entry 00471f27

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00471f27(void)

{
  _DAT_01ea93b0 = func_0x01677f50(&UNK_018c8228);
  return;
}



// referenced at 0x00471f47, inferred function entry 00471f47

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00471f47(void)

{
  _DAT_01ea93ac = func_0x01677f50(&UNK_018c8248);
  return;
}



// referenced at 0x00471fe7, inferred function entry 00471fe7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00471fe7(void)

{
  _DAT_01ea93b4 = func_0x01677f90(&UNK_018c81e0);
  return;
}



// referenced at 0x00472007, inferred function entry 00472007

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00472007(void)

{
  _DAT_01ea93bc = func_0x01677fb0(&UNK_018c82ac);
  return;
}



// referenced at 0x00472047, inferred function entry 00472047

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00472047(void)

{
  _DAT_01ea9390 = func_0x01677fb0(&UNK_018c8288);
  return;
}



// referenced at 0x00472617, inferred function entry 00472617

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00472617(void)

{
  _DAT_01eaad4c = func_0x01677f50(&UNK_018c9014);
  return;
}



// referenced at 0x00472c87, inferred function entry 00472c87

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00472c87(void)

{
  _DAT_01ead018 = func_0x01677f50(&UNK_018ca974);
  return;
}



// referenced at 0x004737b7, inferred function entry 004737b7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004737b7(void)

{
  _DAT_01eaceb0 = func_0x01677fb0(&UNK_018c9d94);
  return;
}



// referenced at 0x004737d7, inferred function entry 004737d7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004737d7(void)

{
  _DAT_01eacef4 = func_0x01677f50(&UNK_018c9fcc);
  return;
}



// referenced at 0x00474277, inferred function entry 00474277

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00474277(void)

{
  _DAT_01ead6fc = func_0x01677f50(&UNK_018cf16c);
  return;
}



// referenced at 0x00476987, inferred function entry 00476987

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00476987(void)

{
  _DAT_01eadf6c = func_0x01677f90(&UNK_018d6d4c);
  return;
}



// referenced at 0x004771d7, inferred function entry 004771d7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004771d7(void)

{
  _DAT_01eae538 = func_0x01677f50(&UNK_018d973c);
  return;
}



// referenced at 0x004771f7, inferred function entry 004771f7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004771f7(void)

{
  _DAT_01eae534 = func_0x01677f50(&UNK_018d9714);
  return;
}



// referenced at 0x00478c77, inferred function entry 00478c77

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00478c77(void)

{
  _DAT_01eaf3c8 = func_0x01677f50(&UNK_018e029c);
  return;
}



// referenced at 0x00487d57, inferred function entry 00487d57

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487d57(void)

{
  _DAT_01ee0580 = func_0x01677f50(&UNK_01929dcc);
  return;
}



// referenced at 0x00487ed2, inferred function entry 00487ed2

void FUN_00487ed2(void)

{
  func_0x005542c0(&UNK_0192a40c);
  func_0x016f3654(&UNK_018829c0);
  return;
}



// referenced at 0x00487ef7, inferred function entry 00487ef7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487ef7(void)

{
  _DAT_01ee0568 = func_0x01677fd0(&UNK_01929d0c);
  return;
}



// referenced at 0x00488637, inferred function entry 00488637

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488637(void)

{
  _DAT_01ee04f4 = func_0x01677f90(&UNK_01929a1c);
  return;
}



// referenced at 0x00496a17, inferred function entry 00496a17

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496a17(void)

{
  _DAT_01ee3078 = func_0x01677f50(&UNK_019351d0);
  return;
}



// referenced at 0x00496a37, inferred function entry 00496a37

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496a37(void)

{
  _DAT_01ee3074 = func_0x01677f50(&UNK_019351b0);
  return;
}



// referenced at 0x00496a57, inferred function entry 00496a57

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496a57(void)

{
  _DAT_01ee3024 = func_0x01677f50(&UNK_01934fb0);
  return;
}



// referenced at 0x004a90f7, inferred function entry 004a90f7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a90f7(void)

{
  _DAT_01ee5c78 = func_0x01677f90(&UNK_0193d1d0);
  return;
}



// referenced at 0x004c14e7, inferred function entry 004c14e7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c14e7(void)

{
  _DAT_01eee690 = func_0x01677f50(&UNK_01952928);
  return;
}



// referenced at 0x004c1547, inferred function entry 004c1547

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c1547(void)

{
  _DAT_01eee6a4 = func_0x01677f50(&UNK_019529d0);
  return;
}



// referenced at 0x004f1247, inferred function entry 004f1247

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f1247(void)

{
  _DAT_01f0482c = func_0x01677f50(&UNK_01978ff8);
  return;
}



// referenced at 0x004f27d7, inferred function entry 004f27d7

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f27d7(void)

{
  _DAT_01f04f4c = func_0x01677f50(&UNK_0197ad60);
  return;
}



// referenced at 0x005d471b, inferred function entry 005d471b

undefined4 FUN_005d471b(void)

{
  int iVar1;
  uint uVar2;
  code *pcVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined *puVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  
  func_0x0151b710(&UNK_018c5ef8);
  puVar4 = (undefined4 *)func_0x00912100(unaff_EBP + -0x58);
  uVar2 = puVar4[5];
  *(undefined *)(unaff_EBP + -4) = 1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*puVar4;
  }
  func_0x0151b710(&UNK_018c5f04,puVar4);
  uVar2 = *(uint *)(unaff_EBP + -0x44);
  *(undefined *)(unaff_EBP + -4) = 0;
  if (0xf < uVar2) {
    iVar1 = *(int *)(unaff_EBP + -0x58);
    uVar9 = uVar2 + 1;
    iVar8 = iVar1;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar1 + -4);
      uVar9 = uVar2 + 0x24;
      if (0x1f < (iVar1 - iVar8) - 4U) {
        func_0x017167a3();
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
      }
    }
    func_0x01674ea0(iVar8,uVar9);
  }
  piVar5 = *(int **)(unaff_EBP + 0x14);
  if (0xf < (uint)piVar5[5]) {
    piVar5 = (int *)*piVar5;
  }
  func_0x0151b710(&UNK_018c5f10,piVar5);
  if (**(int **)(unaff_EBP + 0x18) != 0) {
    uVar10 = func_0x00928340();
    func_0x0151ba20(&UNK_018c5f1c,0x13,uVar10);
  }
  puVar6 = &UNK_018bdf50;
  if (*(char *)(unaff_EBP + 0x1c) == '\0') {
    puVar6 = &UNK_018bdf48;
  }
  func_0x0151b710(&UNK_018c5f30,puVar6);
  func_0x0151b940(&UNK_018c5f44,8,*(double *)(unaff_EDI + 0xc0) + *(double *)(unaff_EDI + 0xb8));
  uVar10 = func_0x01522960();
  func_0x0151ba20(&UNK_018c5f50,0xf,uVar10);
  func_0x0151ba20(&UNK_018c5f60,6,*(undefined4 *)(unaff_EDI + 0xd8),
                  *(undefined4 *)(unaff_EDI + 0xdc));
  func_0x0054ef60(unaff_EBP + -0x40);
  func_0x005507b0();
  uVar7 = *(undefined4 *)(unaff_EBP + 8);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar7;
}



// referenced at 0x005d5ee3, inferred function entry 005d5ee3

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005d5ee3(void)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int unaff_EBX;
  int unaff_EBP;
  int *unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  
  func_0x016774b0();
  uVar5 = *(undefined4 *)(unaff_EBP + -0x14);
  *(int *)(unaff_EBP + -0x18) = unaff_EBX + 0x2c8;
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    unaff_EDI[2] = unaff_EDI[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(unaff_EBP + -0x3c) = uVar5;
  *(int **)(unaff_EBP + -0x38) = unaff_EDI;
  *(undefined *)(unaff_EBP + -4) = 3;
  uVar7 = func_0x01675290();
  *(undefined4 *)(unaff_EBP + -0x24) = uVar7;
  *(undefined *)(unaff_EBP + -4) = 4;
  puVar8 = (undefined4 *)func_0x01674e20(0x20);
  uVar5 = *(undefined4 *)(unaff_EBP + -0x18);
  *(undefined4 **)(unaff_EBP + -0x20) = puVar8;
  if (puVar8 == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puVar8 = 0;
    puVar8[1] = 1;
    puVar8[2] = &UNK_005d3240;
    puVar8[3] = &UNK_005d3660;
    puVar8[4] = 0;
    puVar8[5] = uVar5;
    puVar8[6] = 0;
    puVar8[7] = 0;
    if (unaff_EDI != (int *)0x0) {
      LOCK();
      unaff_EDI[2] = unaff_EDI[2] + 1;
      UNLOCK();
    }
    puVar8[6] = *(undefined4 *)(unaff_EBP + -0x14);
    puVar8[7] = unaff_EDI;
  }
  func_0x016797d0();
  *(undefined4 **)(unaff_EBP + -0x20) = puVar8;
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    puVar8[1] = puVar8[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(unaff_EBP + -0x10) = 1;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x01675290(uVar7);
  *(undefined4 *)(unaff_EBP + -0x10) = 0;
  if (puVar8 != (undefined4 *)0x0) {
    piVar6 = puVar8 + 1;
    LOCK();
    iVar3 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      func_0x01674ea0(puVar8);
    }
  }
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    iVar3 = unaff_EDI[2] + -1;
    unaff_EDI[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*unaff_EDI + 4))();
    }
  }
  *(int *)(unaff_EBP + -0x1c) = *(int *)(unaff_EBP + -0x1c) + 0x2cc;
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    unaff_EDI[2] = unaff_EDI[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x14);
  *(int **)(unaff_EBP + -0x38) = unaff_EDI;
  uVar5 = _DAT_02110da8;
  *(undefined *)(unaff_EBP + -4) = 7;
  uVar7 = func_0x01675290(uVar5);
  *(undefined4 *)(unaff_EBP + -0x24) = uVar7;
  *(undefined *)(unaff_EBP + -4) = 8;
  puVar8 = (undefined4 *)func_0x01674e20(0x20);
  uVar5 = *(undefined4 *)(unaff_EBP + -0x1c);
  *(undefined4 **)(unaff_EBP + -0x20) = puVar8;
  if (puVar8 == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puVar8 = 0;
    puVar8[1] = 1;
    puVar8[2] = &UNK_005d3560;
    puVar8[3] = &UNK_005d3660;
    puVar8[4] = 0;
    puVar8[5] = uVar5;
    puVar8[6] = 0;
    puVar8[7] = 0;
    if (unaff_EDI != (int *)0x0) {
      LOCK();
      unaff_EDI[2] = unaff_EDI[2] + 1;
      UNLOCK();
    }
    puVar8[6] = *(undefined4 *)(unaff_EBP + -0x14);
    puVar8[7] = unaff_EDI;
  }
  func_0x016797d0(puVar8);
  *(undefined4 **)(unaff_EBP + -0x20) = puVar8;
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    puVar8[1] = puVar8[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(unaff_EBP + -0x10) = 2;
  *(undefined *)(unaff_EBP + -4) = 9;
  func_0x01675290(uVar7);
  if (puVar8 != (undefined4 *)0x0) {
    piVar6 = puVar8 + 1;
    LOCK();
    iVar3 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      func_0x01674ea0(puVar8);
    }
  }
  *(undefined4 *)(unaff_EBP + -0x10) = 0;
  if (unaff_EDI != (int *)0x0) {
    *(undefined4 *)(unaff_EBP + -0x10) = 0;
    LOCK();
    iVar3 = unaff_EDI[2] + -1;
    unaff_EDI[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*unaff_EDI + 4))();
      *(undefined4 *)(unaff_EBP + -0x10) = 0;
    }
  }
  *(int *)(unaff_EBP + -0x1c) = *(int *)(unaff_EBP + -0x2c) + 0x74;
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    unaff_EDI[2] = unaff_EDI[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x14);
  *(int **)(unaff_EBP + -0x38) = unaff_EDI;
  uVar5 = _DAT_02110da8;
  *(undefined *)(unaff_EBP + -4) = 0x13;
  uVar7 = func_0x01675290(uVar5);
  *(undefined4 *)(unaff_EBP + -0x24) = uVar7;
  *(undefined *)(unaff_EBP + -4) = 0x14;
  puVar8 = (undefined4 *)func_0x01674e20(0x20);
  uVar5 = *(undefined4 *)(unaff_EBP + -0x1c);
  *(undefined4 **)(unaff_EBP + -0x20) = puVar8;
  if (puVar8 == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puVar8 = 0;
    puVar8[1] = 1;
    puVar8[2] = &UNK_005d3310;
    puVar8[3] = &UNK_005d3660;
    puVar8[4] = 0;
    puVar8[5] = uVar5;
    puVar8[6] = 0;
    puVar8[7] = 0;
    if (unaff_EDI != (int *)0x0) {
      LOCK();
      unaff_EDI[2] = unaff_EDI[2] + 1;
      UNLOCK();
    }
    puVar8[6] = *(undefined4 *)(unaff_EBP + -0x14);
    puVar8[7] = unaff_EDI;
  }
  func_0x016797d0(puVar8);
  *(undefined4 **)(unaff_EBP + -0x20) = puVar8;
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    puVar8[1] = puVar8[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(unaff_EBP + -0x10) = 0x10;
  *(undefined *)(unaff_EBP + -4) = 0x15;
  func_0x01675290(uVar7);
  if (puVar8 != (undefined4 *)0x0) {
    piVar6 = puVar8 + 1;
    LOCK();
    iVar3 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      func_0x01674ea0(puVar8);
    }
  }
  *(undefined *)(unaff_EBP + -4) = 1;
  puVar1 = (uint *)(unaff_EDI + 2);
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    uVar9 = *puVar1;
    *puVar1 = uVar9 - 1;
    UNLOCK();
    if (uVar9 - 1 == 0) {
      (**(code **)(*unaff_EDI + 4))();
    }
  }
  uVar9 = (uint)DAT_01ea8d1c;
  if (DAT_01ea8d1c != 0) {
    uVar9 = func_0x016774b0(DAT_01ea8d1c,&UNK_018c6644,0);
  }
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    uVar4 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      uVar9 = (**(code **)(*unaff_EDI + 4))();
    }
  }
  piVar6 = *(int **)(unaff_EBP + -0x28);
  if (piVar6 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar6 + 1);
    uVar4 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      uVar9 = (**(code **)*piVar6)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar9 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005d946b, inferred function entry 005d946b

void FUN_005d946b(void)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int unaff_EBX;
  int unaff_EBP;
  undefined *puVar8;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar9;
  
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c5ef8);
  *(undefined *)(unaff_EBP + -4) = 0x1d;
  func_0x005d15d0(unaff_EBP + -0x24);
  func_0x00551260();
  *(undefined *)(unaff_EBP + -4) = 1;
  func_0x005507b0();
  puVar4 = (undefined4 *)func_0x00912100(unaff_EBP + -0x54);
  uVar2 = puVar4[5];
  *(undefined *)(unaff_EBP + -4) = 0x1e;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*puVar4;
  }
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c5f04,10);
  *(undefined *)(unaff_EBP + -4) = 0x1f;
  func_0x005d15d0(unaff_EBP + -0x24,puVar4);
  func_0x00551260();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 1;
  func_0x005507b0();
  uVar5 = func_0x01675640(unaff_EBP + -0x54,&UNK_018c5880,
                          *(double *)(unaff_EBX + 0xc0) + *(double *)(unaff_EBX + 0xb8));
  *(undefined *)(unaff_EBP + -4) = 0x20;
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c5f44,8);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005d15d0(unaff_EBP + -0x24,uVar5);
  func_0x005511f0();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 1;
  func_0x005507b0();
  uVar9 = func_0x01522960();
  uVar5 = func_0x01675640(unaff_EBP + -0x54,&UNK_018c6c58,uVar9);
  *(undefined *)(unaff_EBP + -4) = 0x22;
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c5f50,0xf);
  *(undefined *)(unaff_EBP + -4) = 0x23;
  func_0x005d15d0(unaff_EBP + -0x24,uVar5);
  func_0x005511f0();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 1;
  func_0x005507b0();
  uVar9 = func_0x00928340();
  *(undefined8 *)(unaff_EBP + -0x78) = uVar9;
  iVar6 = func_0x005d1850(unaff_EBP + -0x78);
  piVar1 = *(int **)(unaff_EBP + 8);
  iVar7 = *piVar1;
  *(undefined8 *)(unaff_EBP + -0x88) = *(undefined8 *)(iVar6 + 8);
  func_0x0054ef60(iVar7 + 0x2a8);
  *(undefined *)(unaff_EBP + -4) = 0x24;
  uVar5 = func_0x01675640(unaff_EBP + -0xa0,&UNK_018bed48,uVar9);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c6c60,6);
  *(undefined *)(unaff_EBP + -4) = 0x26;
  func_0x005d15d0(unaff_EBP + -0x24,uVar5);
  func_0x005511f0();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x24;
  func_0x005507b0();
  func_0x0054ef60(*piVar1 + 0x214);
  iVar7 = unaff_EBP + -0x6c;
  if (0xf < *(uint *)(unaff_EBP + -0x58)) {
    iVar7 = *(int *)(unaff_EBP + -0x6c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x27;
  cVar3 = func_0x0055c360(iVar7,*(undefined4 *)(unaff_EBP + -0x5c),&UNK_018bc9b8,0);
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  puVar8 = &UNK_018bdf50;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  if (cVar3 != '\0') {
    puVar8 = &UNK_018bdf48;
  }
  func_0x005542c0(&UNK_018c5d68,4);
  *(undefined *)(unaff_EBP + -4) = 0x28;
  func_0x005d15d0(unaff_EBP + -0x24,puVar8);
  func_0x00551260();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x24;
  func_0x005507b0();
  uVar5 = func_0x01675640(unaff_EBP + -0xa0,&UNK_018c5880,*(undefined8 *)(unaff_EBP + -0x88));
  *(undefined *)(unaff_EBP + -4) = 0x29;
  *(undefined4 *)(unaff_EBP + -0x5c) = 0;
  *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
  *(undefined *)(unaff_EBP + -0x6c) = 0;
  func_0x005542c0(&UNK_018c5d70,0x12);
  *(undefined *)(unaff_EBP + -4) = 0x2a;
  func_0x005d15d0(unaff_EBP + -0x6c,uVar5);
  func_0x005511f0();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x24;
  func_0x005507b0();
  *(undefined4 *)(unaff_EBP + -0x5c) = 0;
  *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
  *(undefined *)(unaff_EBP + -0x6c) = 0;
  func_0x005542c0(&UNK_018c5d84,0xd);
  *(undefined *)(unaff_EBP + -4) = 0x2b;
  func_0x005d15d0(unaff_EBP + -0x6c,unaff_EBP + -0x54);
  func_0x00551230();
  *(undefined *)(unaff_EBP + -4) = 0x24;
  func_0x005507b0();
  *(undefined4 *)(unaff_EBP + 8) = *(undefined4 *)(*piVar1 + 0x450);
  uVar5 = func_0x00920c80(unaff_EBP + -0xa0,unaff_EBP + 8);
  *(undefined *)(unaff_EBP + -4) = 0x2c;
  *(undefined4 *)(unaff_EBP + -0x5c) = 0;
  *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
  *(undefined *)(unaff_EBP + -0x6c) = 0;
  func_0x005542c0(&UNK_018c5d94,0xe);
  *(undefined *)(unaff_EBP + -4) = 0x2d;
  func_0x005d15d0(unaff_EBP + -0x6c,uVar5);
  func_0x005511f0();
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x24;
  func_0x005507b0();
  iVar7 = func_0x0065b150(*piVar1);
  if (iVar7 != 0) {
    func_0x00657b90(unaff_EBP + -0x3c);
  }
  *(undefined4 *)(unaff_EBP + -0x90) = 0;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
  *(undefined *)(unaff_EBP + -0xa0) = 0;
  func_0x005542c0(&UNK_018c6c68,9);
  *(undefined *)(unaff_EBP + -4) = 0x2e;
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  func_0x005542c0(&UNK_018c5da4,0xe);
  *(undefined *)(unaff_EBP + -4) = 0x2f;
  *(undefined4 *)(unaff_EBP + -0x5c) = 0;
  *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
  *(undefined *)(unaff_EBP + -0x6c) = 0;
  func_0x005542c0(&UNK_018c6c74,6);
  *(undefined *)(unaff_EBP + -4) = 0x30;
  func_0x008794f0(unaff_EBP + -0x6c,unaff_EBP + -0x24,unaff_EBP + -0xa0,unaff_EBP + -0x3c);
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  func_0x0056cfd0();
  func_0x00550b30();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// referenced at 0x005da95d, inferred function entry 005da95d

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005da95d(void)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  undefined *puVar11;
  
  func_0x016774b0();
  func_0x00587490(unaff_EBP + -0x24);
  iVar8 = *(int *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar8 == 0) {
    uVar9 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    puVar11 = &UNK_018c6cb0;
  }
  else {
    iVar5 = func_0x005cf750();
    if (iVar5 == 0) {
      uVar9 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6d08;
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iVar8 == -0xc) {
            iVar8 = 0;
          }
          else {
            func_0x005789c0(0x1ea8dfc,&UNK_005cf1d0);
            uVar6 = func_0x005cf580();
            piVar7 = (int *)func_0x008aa140(uVar6);
            *(int **)(unaff_EBP + -0x10) = piVar7;
            if (*piVar7 == 0) {
              uVar6 = func_0x009ef740();
              piVar7 = (int *)func_0x008a9ba0(unaff_EBP + -0x1c,uVar6);
              iVar8 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              piVar7 = *(int **)(unaff_EBP + -0x10);
              *piVar7 = iVar8;
              piVar3 = (int *)piVar7[1];
              piVar7[1] = iVar5;
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
              piVar3 = *(int **)(unaff_EBP + -0x18);
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
            }
            iVar8 = *piVar7;
          }
          if ((9999 < _DAT_01ee5c3c) || ((iVar8 != 0 && (*(char *)(iVar8 + 0xee) != '\0')))) {
            func_0x00562c90(unaff_EBP + -0x1c,*(undefined4 *)(unaff_EBP + 8));
            *(undefined *)(unaff_EBP + -4) = 1;
            if (*(int *)(unaff_EBP + -0x1c) == 0) {
              *(undefined8 *)(unaff_EBP + -0x14) = 0;
              uVar10 = *(undefined8 *)(unaff_EBP + -0x14);
            }
            else {
              uVar10 = func_0x00928340();
            }
            func_0x005ea890(unaff_EBP + -0x14,uVar10);
            if ((*(char *)(unaff_EBP + -0x10) != '\0') && (DAT_01ea8d1c != 0)) {
              func_0x016774b0(DAT_01ea8d1c,&UNK_018c6d68,*(undefined4 *)(unaff_EBP + -0x14));
            }
            *(undefined *)(unaff_EBP + -4) = 0;
            func_0x00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = func_0x005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar9 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          func_0x016774b0(DAT_01ea8d1c,&UNK_018c6dd0,0);
        }
      }
LAB_005dab4f:
      uVar9 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6e18;
    }
  }
  uVar9 = func_0x016774b0(uVar9,puVar11,0);
LAB_005dab6b:
  piVar7 = *(int **)(unaff_EBP + -0x20);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar2 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar9 = (**(code **)*piVar7)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005da997, inferred function entry 005da95d

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005da95d(void)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  undefined *puVar11;
  
  func_0x016774b0();
  func_0x00587490(unaff_EBP + -0x24);
  iVar8 = *(int *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar8 == 0) {
    uVar9 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    puVar11 = &UNK_018c6cb0;
  }
  else {
    iVar5 = func_0x005cf750();
    if (iVar5 == 0) {
      uVar9 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6d08;
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iVar8 == -0xc) {
            iVar8 = 0;
          }
          else {
            func_0x005789c0(0x1ea8dfc,&UNK_005cf1d0);
            uVar6 = func_0x005cf580();
            piVar7 = (int *)func_0x008aa140(uVar6);
            *(int **)(unaff_EBP + -0x10) = piVar7;
            if (*piVar7 == 0) {
              uVar6 = func_0x009ef740();
              piVar7 = (int *)func_0x008a9ba0(unaff_EBP + -0x1c,uVar6);
              iVar8 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              piVar7 = *(int **)(unaff_EBP + -0x10);
              *piVar7 = iVar8;
              piVar3 = (int *)piVar7[1];
              piVar7[1] = iVar5;
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
              piVar3 = *(int **)(unaff_EBP + -0x18);
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
            }
            iVar8 = *piVar7;
          }
          if ((9999 < _DAT_01ee5c3c) || ((iVar8 != 0 && (*(char *)(iVar8 + 0xee) != '\0')))) {
            func_0x00562c90(unaff_EBP + -0x1c,*(undefined4 *)(unaff_EBP + 8));
            *(undefined *)(unaff_EBP + -4) = 1;
            if (*(int *)(unaff_EBP + -0x1c) == 0) {
              *(undefined8 *)(unaff_EBP + -0x14) = 0;
              uVar10 = *(undefined8 *)(unaff_EBP + -0x14);
            }
            else {
              uVar10 = func_0x00928340();
            }
            func_0x005ea890(unaff_EBP + -0x14,uVar10);
            if ((*(char *)(unaff_EBP + -0x10) != '\0') && (DAT_01ea8d1c != 0)) {
              func_0x016774b0(DAT_01ea8d1c,&UNK_018c6d68,*(undefined4 *)(unaff_EBP + -0x14));
            }
            *(undefined *)(unaff_EBP + -4) = 0;
            func_0x00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = func_0x005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar9 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          func_0x016774b0(DAT_01ea8d1c,&UNK_018c6dd0,0);
        }
      }
LAB_005dab4f:
      uVar9 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6e18;
    }
  }
  uVar9 = func_0x016774b0(uVar9,puVar11,0);
LAB_005dab6b:
  piVar7 = *(int **)(unaff_EBP + -0x20);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar2 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar9 = (**(code **)*piVar7)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005da9be, inferred function entry 005da95d

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005da95d(void)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  undefined *puVar11;
  
  func_0x016774b0();
  func_0x00587490(unaff_EBP + -0x24);
  iVar8 = *(int *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar8 == 0) {
    uVar9 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    puVar11 = &UNK_018c6cb0;
  }
  else {
    iVar5 = func_0x005cf750();
    if (iVar5 == 0) {
      uVar9 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6d08;
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iVar8 == -0xc) {
            iVar8 = 0;
          }
          else {
            func_0x005789c0(0x1ea8dfc,&UNK_005cf1d0);
            uVar6 = func_0x005cf580();
            piVar7 = (int *)func_0x008aa140(uVar6);
            *(int **)(unaff_EBP + -0x10) = piVar7;
            if (*piVar7 == 0) {
              uVar6 = func_0x009ef740();
              piVar7 = (int *)func_0x008a9ba0(unaff_EBP + -0x1c,uVar6);
              iVar8 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              piVar7 = *(int **)(unaff_EBP + -0x10);
              *piVar7 = iVar8;
              piVar3 = (int *)piVar7[1];
              piVar7[1] = iVar5;
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
              piVar3 = *(int **)(unaff_EBP + -0x18);
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
            }
            iVar8 = *piVar7;
          }
          if ((9999 < _DAT_01ee5c3c) || ((iVar8 != 0 && (*(char *)(iVar8 + 0xee) != '\0')))) {
            func_0x00562c90(unaff_EBP + -0x1c,*(undefined4 *)(unaff_EBP + 8));
            *(undefined *)(unaff_EBP + -4) = 1;
            if (*(int *)(unaff_EBP + -0x1c) == 0) {
              *(undefined8 *)(unaff_EBP + -0x14) = 0;
              uVar10 = *(undefined8 *)(unaff_EBP + -0x14);
            }
            else {
              uVar10 = func_0x00928340();
            }
            func_0x005ea890(unaff_EBP + -0x14,uVar10);
            if ((*(char *)(unaff_EBP + -0x10) != '\0') && (DAT_01ea8d1c != 0)) {
              func_0x016774b0(DAT_01ea8d1c,&UNK_018c6d68,*(undefined4 *)(unaff_EBP + -0x14));
            }
            *(undefined *)(unaff_EBP + -4) = 0;
            func_0x00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = func_0x005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar9 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          func_0x016774b0(DAT_01ea8d1c,&UNK_018c6dd0,0);
        }
      }
LAB_005dab4f:
      uVar9 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6e18;
    }
  }
  uVar9 = func_0x016774b0(uVar9,puVar11,0);
LAB_005dab6b:
  piVar7 = *(int **)(unaff_EBP + -0x20);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar2 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar9 = (**(code **)*piVar7)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005dab06, inferred function entry 005da95d

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005da95d(void)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  undefined *puVar11;
  
  func_0x016774b0();
  func_0x00587490(unaff_EBP + -0x24);
  iVar8 = *(int *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar8 == 0) {
    uVar9 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    puVar11 = &UNK_018c6cb0;
  }
  else {
    iVar5 = func_0x005cf750();
    if (iVar5 == 0) {
      uVar9 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6d08;
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iVar8 == -0xc) {
            iVar8 = 0;
          }
          else {
            func_0x005789c0(0x1ea8dfc,&UNK_005cf1d0);
            uVar6 = func_0x005cf580();
            piVar7 = (int *)func_0x008aa140(uVar6);
            *(int **)(unaff_EBP + -0x10) = piVar7;
            if (*piVar7 == 0) {
              uVar6 = func_0x009ef740();
              piVar7 = (int *)func_0x008a9ba0(unaff_EBP + -0x1c,uVar6);
              iVar8 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              piVar7 = *(int **)(unaff_EBP + -0x10);
              *piVar7 = iVar8;
              piVar3 = (int *)piVar7[1];
              piVar7[1] = iVar5;
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
              piVar3 = *(int **)(unaff_EBP + -0x18);
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
            }
            iVar8 = *piVar7;
          }
          if ((9999 < _DAT_01ee5c3c) || ((iVar8 != 0 && (*(char *)(iVar8 + 0xee) != '\0')))) {
            func_0x00562c90(unaff_EBP + -0x1c,*(undefined4 *)(unaff_EBP + 8));
            *(undefined *)(unaff_EBP + -4) = 1;
            if (*(int *)(unaff_EBP + -0x1c) == 0) {
              *(undefined8 *)(unaff_EBP + -0x14) = 0;
              uVar10 = *(undefined8 *)(unaff_EBP + -0x14);
            }
            else {
              uVar10 = func_0x00928340();
            }
            func_0x005ea890(unaff_EBP + -0x14,uVar10);
            if ((*(char *)(unaff_EBP + -0x10) != '\0') && (DAT_01ea8d1c != 0)) {
              func_0x016774b0(DAT_01ea8d1c,&UNK_018c6d68,*(undefined4 *)(unaff_EBP + -0x14));
            }
            *(undefined *)(unaff_EBP + -4) = 0;
            func_0x00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = func_0x005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar9 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          func_0x016774b0(DAT_01ea8d1c,&UNK_018c6dd0,0);
        }
      }
LAB_005dab4f:
      uVar9 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6e18;
    }
  }
  uVar9 = func_0x016774b0(uVar9,puVar11,0);
LAB_005dab6b:
  piVar7 = *(int **)(unaff_EBP + -0x20);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar2 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar9 = (**(code **)*piVar7)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005dab41, inferred function entry 005da95d

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005da95d(void)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  undefined *puVar11;
  
  func_0x016774b0();
  func_0x00587490(unaff_EBP + -0x24);
  iVar8 = *(int *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar8 == 0) {
    uVar9 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    puVar11 = &UNK_018c6cb0;
  }
  else {
    iVar5 = func_0x005cf750();
    if (iVar5 == 0) {
      uVar9 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6d08;
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iVar8 == -0xc) {
            iVar8 = 0;
          }
          else {
            func_0x005789c0(0x1ea8dfc,&UNK_005cf1d0);
            uVar6 = func_0x005cf580();
            piVar7 = (int *)func_0x008aa140(uVar6);
            *(int **)(unaff_EBP + -0x10) = piVar7;
            if (*piVar7 == 0) {
              uVar6 = func_0x009ef740();
              piVar7 = (int *)func_0x008a9ba0(unaff_EBP + -0x1c,uVar6);
              iVar8 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              piVar7 = *(int **)(unaff_EBP + -0x10);
              *piVar7 = iVar8;
              piVar3 = (int *)piVar7[1];
              piVar7[1] = iVar5;
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
              piVar3 = *(int **)(unaff_EBP + -0x18);
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
            }
            iVar8 = *piVar7;
          }
          if ((9999 < _DAT_01ee5c3c) || ((iVar8 != 0 && (*(char *)(iVar8 + 0xee) != '\0')))) {
            func_0x00562c90(unaff_EBP + -0x1c,*(undefined4 *)(unaff_EBP + 8));
            *(undefined *)(unaff_EBP + -4) = 1;
            if (*(int *)(unaff_EBP + -0x1c) == 0) {
              *(undefined8 *)(unaff_EBP + -0x14) = 0;
              uVar10 = *(undefined8 *)(unaff_EBP + -0x14);
            }
            else {
              uVar10 = func_0x00928340();
            }
            func_0x005ea890(unaff_EBP + -0x14,uVar10);
            if ((*(char *)(unaff_EBP + -0x10) != '\0') && (DAT_01ea8d1c != 0)) {
              func_0x016774b0(DAT_01ea8d1c,&UNK_018c6d68,*(undefined4 *)(unaff_EBP + -0x14));
            }
            *(undefined *)(unaff_EBP + -4) = 0;
            func_0x00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = func_0x005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar9 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          func_0x016774b0(DAT_01ea8d1c,&UNK_018c6dd0,0);
        }
      }
LAB_005dab4f:
      uVar9 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6e18;
    }
  }
  uVar9 = func_0x016774b0(uVar9,puVar11,0);
LAB_005dab6b:
  piVar7 = *(int **)(unaff_EBP + -0x20);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar2 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar9 = (**(code **)*piVar7)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005dab5a, inferred function entry 005da95d

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_005da95d(void)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  undefined4 *unaff_FS_OFFSET;
  undefined8 uVar10;
  undefined *puVar11;
  
  func_0x016774b0();
  func_0x00587490(unaff_EBP + -0x24);
  iVar8 = *(int *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar8 == 0) {
    uVar9 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    puVar11 = &UNK_018c6cb0;
  }
  else {
    iVar5 = func_0x005cf750();
    if (iVar5 == 0) {
      uVar9 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6d08;
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iVar8 == -0xc) {
            iVar8 = 0;
          }
          else {
            func_0x005789c0(0x1ea8dfc,&UNK_005cf1d0);
            uVar6 = func_0x005cf580();
            piVar7 = (int *)func_0x008aa140(uVar6);
            *(int **)(unaff_EBP + -0x10) = piVar7;
            if (*piVar7 == 0) {
              uVar6 = func_0x009ef740();
              piVar7 = (int *)func_0x008a9ba0(unaff_EBP + -0x1c,uVar6);
              iVar8 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              piVar7 = *(int **)(unaff_EBP + -0x10);
              *piVar7 = iVar8;
              piVar3 = (int *)piVar7[1];
              piVar7[1] = iVar5;
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
              piVar3 = *(int **)(unaff_EBP + -0x18);
              if (piVar3 != (int *)0x0) {
                LOCK();
                iVar8 = piVar3[1] + -1;
                piVar3[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar3)();
                  LOCK();
                  iVar8 = piVar3[2] + -1;
                  piVar3[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
                piVar7 = *(int **)(unaff_EBP + -0x10);
              }
            }
            iVar8 = *piVar7;
          }
          if ((9999 < _DAT_01ee5c3c) || ((iVar8 != 0 && (*(char *)(iVar8 + 0xee) != '\0')))) {
            func_0x00562c90(unaff_EBP + -0x1c,*(undefined4 *)(unaff_EBP + 8));
            *(undefined *)(unaff_EBP + -4) = 1;
            if (*(int *)(unaff_EBP + -0x1c) == 0) {
              *(undefined8 *)(unaff_EBP + -0x14) = 0;
              uVar10 = *(undefined8 *)(unaff_EBP + -0x14);
            }
            else {
              uVar10 = func_0x00928340();
            }
            func_0x005ea890(unaff_EBP + -0x14,uVar10);
            if ((*(char *)(unaff_EBP + -0x10) != '\0') && (DAT_01ea8d1c != 0)) {
              func_0x016774b0(DAT_01ea8d1c,&UNK_018c6d68,*(undefined4 *)(unaff_EBP + -0x14));
            }
            *(undefined *)(unaff_EBP + -4) = 0;
            func_0x00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = func_0x005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar9 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          func_0x016774b0(DAT_01ea8d1c,&UNK_018c6dd0,0);
        }
      }
LAB_005dab4f:
      uVar9 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      puVar11 = &UNK_018c6e18;
    }
  }
  uVar9 = func_0x016774b0(uVar9,puVar11,0);
LAB_005dab6b:
  piVar7 = *(int **)(unaff_EBP + -0x20);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar2 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar9 = (**(code **)*piVar7)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar9;
}



// referenced at 0x005dafce, inferred function entry 005dafce

void FUN_005dafce(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 uVar4;
  uint uVar5;
  code *pcVar6;
  char *pcVar7;
  int iVar8;
  undefined *puVar9;
  int unaff_EBP;
  int unaff_ESI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar10;
  undefined *apuStack_70 [2];
  undefined *apuStack_68 [6];
  undefined4 uStack_50;
  undefined *puStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  undefined *puStack_34;
  uint uStack_30;
  int iStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  uint uStack_14;
  undefined4 *puStack_10;
  int iStack_c;
  undefined *puStack_8;
  char *pcStack_4;
  
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  pcVar7 = "CloudEdit";
  do {
    pcStack_4 = pcVar7;
    pcVar7 = pcStack_4 + 1;
  } while (*pcStack_4 != '\0');
  pcStack_4 = pcStack_4 + -0x18c5f8c;
  puStack_8 = &UNK_018c5f8c;
  iStack_c = 0x5db003;
  func_0x005542c0();
  puVar1 = *(undefined4 **)(unaff_ESI + 0x40);
  puStack_10 = puVar1 + 0x12;
  *(undefined *)(unaff_EBP + -4) = 5;
  iStack_c = unaff_EBP + -0x3c;
  if (0xf < *(uint *)(unaff_EBP + -0x28)) {
    iStack_c = *(int *)(unaff_EBP + -0x3c);
  }
  if (0xf < (uint)puVar1[0x17]) {
    puStack_10 = (undefined4 *)*puStack_10;
  }
  uStack_14 = puVar1[1];
  puStack_20 = (undefined *)(unaff_EBP + -0x6c);
  puStack_18 = (undefined *)*puVar1;
  puStack_1c = &UNK_018c5fa0;
  uStack_24 = 0x5db035;
  puStack_10 = (undefined4 *)func_0x01675640();
  uVar5 = puStack_10[5];
  iStack_c = puStack_10[4];
  *(undefined *)(unaff_EBP + -4) = 6;
  if (0xf < uVar5) {
    puStack_10 = (undefined4 *)*puStack_10;
  }
  uStack_14 = 0x5db054;
  func_0x00554150();
  uVar5 = *(uint *)(unaff_EBP + -0x58);
  *(undefined *)(unaff_EBP + -4) = 5;
  if (0xf < uVar5) {
    iVar2 = *(int *)(unaff_EBP + -0x6c);
    uStack_14 = uVar5 + 1;
    iVar8 = iVar2;
    if (uStack_14 < 0x1000) {
LAB_005db082:
      puStack_1c = (undefined *)0x5db089;
      puStack_18 = (undefined *)iVar8;
      func_0x01674ea0();
      goto LAB_005db08c;
    }
    iVar8 = *(int *)(iVar2 + -4);
    uStack_14 = uVar5 + 0x24;
    if ((iVar2 - iVar8) - 4U < 0x20) goto LAB_005db082;
    uStack_14 = 0x5db44f;
    func_0x017167a3();
LAB_005db44f:
    uStack_30 = 0x5db454;
    func_0x017167a3();
LAB_005db454:
    uStack_30 = 0x5db459;
    func_0x017167a3();
LAB_005db459:
    uStack_30 = 0x5db45e;
    func_0x017167a3();
LAB_005db45e:
    uStack_30 = 0x5db463;
    func_0x017167a3();
LAB_005db463:
    uStack_48 = 0x5db468;
    func_0x017167a3();
LAB_005db468:
    uStack_48 = 0x5db46d;
    func_0x017167a3();
LAB_005db46d:
    uStack_48 = 0x5db472;
    func_0x017167a3();
LAB_005db472:
    uStack_48 = 0x5db477;
    func_0x017167a3();
    pcVar6 = (code *)swi(3);
    (*pcVar6)();
    return;
  }
LAB_005db08c:
  uStack_14 = 0;
  puStack_18 = &UNK_018bc9b8;
  *(undefined4 *)(unaff_EBP + -0x5c) = 0;
  *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
  *(undefined *)(unaff_EBP + -0x6c) = 0;
  puStack_1c = (undefined *)0x5db0ad;
  func_0x005542c0();
  puStack_1c = (undefined *)0x20;
  puStack_20 = &UNK_018c5840;
  *(undefined *)(unaff_EBP + -4) = 7;
  *(undefined4 *)(unaff_EBP + -0x44) = 0;
  *(undefined4 *)(unaff_EBP + -0x40) = 0xf;
  *(undefined *)(unaff_EBP + -0x54) = 0;
  uStack_24 = 0x5db0d2;
  func_0x005542c0();
  uStack_24 = 5;
  puStack_28 = &UNK_018c59b4;
  *(undefined *)(unaff_EBP + -4) = 8;
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  iStack_2c = 0x5db0f7;
  func_0x005542c0();
  iStack_2c = unaff_EBP + -0x6c;
  *(undefined *)(unaff_EBP + -4) = 9;
  uStack_30 = unaff_EBP + -0x84;
  puStack_34 = (undefined *)(unaff_EBP + -0x54);
  iStack_38 = unaff_ESI + 0x90;
  iStack_3c = unaff_EBP + -0x24;
  iStack_40 = unaff_EBP + -0x174;
  uStack_44 = 0x5db121;
  iStack_2c = func_0x0151bcc0();
  uStack_30 = 0x5db130;
  func_0x005d1360();
  uStack_30 = 0x5db13b;
  func_0x0056d9d0();
  uVar5 = *(uint *)(unaff_EBP + -0x10);
  *(undefined *)(unaff_EBP + -4) = 8;
  if (0xf < uVar5) {
    puVar3 = *(undefined **)(unaff_EBP + -0x24);
    uStack_30 = uVar5 + 1;
    puVar9 = puVar3;
    if (0xfff < uStack_30) {
      puVar9 = *(undefined **)(puVar3 + -4);
      uStack_30 = uVar5 + 0x24;
      if ((undefined *)0x1f < puVar3 + (-4 - (int)puVar9)) goto LAB_005db44f;
    }
    iStack_38 = 0x5db170;
    puStack_34 = puVar9;
    func_0x01674ea0();
  }
  uVar5 = *(uint *)(unaff_EBP + -0x40);
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  *(undefined *)(unaff_EBP + -4) = 7;
  if (0xf < uVar5) {
    puVar3 = *(undefined **)(unaff_EBP + -0x54);
    uStack_30 = uVar5 + 1;
    puVar9 = puVar3;
    if (0xfff < uStack_30) {
      puVar9 = *(undefined **)(puVar3 + -4);
      uStack_30 = uVar5 + 0x24;
      if ((undefined *)0x1f < puVar3 + (-4 - (int)puVar9)) goto LAB_005db454;
    }
    iStack_38 = 0x5db1ba;
    puStack_34 = puVar9;
    func_0x01674ea0();
  }
  uVar5 = *(uint *)(unaff_EBP + -0x58);
  *(undefined4 *)(unaff_EBP + -0x44) = 0;
  *(undefined4 *)(unaff_EBP + -0x40) = 0xf;
  *(undefined *)(unaff_EBP + -0x54) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  if (0xf < uVar5) {
    puVar3 = *(undefined **)(unaff_EBP + -0x6c);
    uStack_30 = uVar5 + 1;
    puVar9 = puVar3;
    if (0xfff < uStack_30) {
      puVar9 = *(undefined **)(puVar3 + -4);
      uStack_30 = uVar5 + 0x24;
      if ((undefined *)0x1f < puVar3 + (-4 - (int)puVar9)) goto LAB_005db459;
    }
    iStack_38 = 0x5db204;
    puStack_34 = puVar9;
    func_0x01674ea0();
  }
  uVar5 = *(uint *)(unaff_EBP + -0x28);
  *(undefined *)(unaff_EBP + -4) = 1;
  if (0xf < uVar5) {
    iVar2 = *(int *)(unaff_EBP + -0x3c);
    uStack_30 = uVar5 + 1;
    iVar8 = iVar2;
    if (0xfff < uStack_30) {
      iVar8 = *(int *)(iVar2 + -4);
      uStack_30 = uVar5 + 0x24;
      if (0x1f < (iVar2 - iVar8) - 4U) goto LAB_005db45e;
    }
    iStack_38 = 0x5db23c;
    puStack_34 = (undefined *)iVar8;
    func_0x01674ea0();
  }
  uStack_30 = 0x10;
  puStack_34 = &UNK_018c5fc8;
  uVar4 = *(undefined4 *)(*(int *)(unaff_ESI + 0x40) + 0x9c);
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  iStack_38 = 0x5db269;
  func_0x005542c0();
  iStack_38 = unaff_EBP + -0x24;
  *(undefined *)(unaff_EBP + -4) = 10;
  iStack_3c = 0x5db27c;
  uStack_44 = func_0x0151bb70();
  iStack_3c = 0;
  iStack_40 = 0;
  *(undefined *)(unaff_EBP + -4) = 0xb;
  uStack_48 = 0x5db290;
  func_0x014cc090();
  bVar10 = DAT_01d5a4c0 == '\0';
  *(undefined *)(unaff_EBP + -4) = 0xc;
  if (bVar10) {
    uStack_48 = 0;
    puStack_4c = &UNK_018bc9b8;
    *(undefined4 *)(unaff_EBP + -0x5c) = 0;
    *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
    *(undefined *)(unaff_EBP + -0x6c) = 0;
    uStack_50 = 0x5db2c2;
    func_0x005542c0();
    uStack_50 = 0;
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined ***)(unaff_EBP + 0xc) = apuStack_70;
    apuStack_70[0] = (undefined *)0x0;
    func_0x005d6520(apuStack_68,apuStack_68,2);
    apuStack_68[0] = &UNK_005d5bd0;
    apuStack_70[0] = &UNK_018c6f1d;
    func_0x014cd990(unaff_EBP + -0x6c,0x1d79f68,0);
    uVar5 = *(uint *)(unaff_EBP + -0x58);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    if (0xf < uVar5) {
      iVar2 = *(int *)(unaff_EBP + -0x6c);
      uStack_48 = uVar5 + 1;
      iVar8 = iVar2;
      if (0xfff < uStack_48) {
        iVar8 = *(int *)(iVar2 + -4);
        uStack_48 = uVar5 + 0x24;
        if (0x1f < (iVar2 - iVar8) - 4U) goto LAB_005db463;
      }
      uStack_50 = 0x5db340;
      puStack_4c = (undefined *)iVar8;
      func_0x01674ea0();
    }
  }
  puStack_4c = (undefined *)(unaff_EBP + -0x3c);
  uStack_50 = 0x5db34d;
  uStack_48 = uVar4;
  func_0x005dabb0();
  uStack_48 = 0x5db35b;
  func_0x0056db40();
  uVar5 = *(uint *)(unaff_EBP + -0x10);
  if (0xf < uVar5) {
    puVar3 = *(undefined **)(unaff_EBP + -0x24);
    uStack_48 = uVar5 + 1;
    puVar9 = puVar3;
    if (0xfff < uStack_48) {
      puVar9 = *(undefined **)(puVar3 + -4);
      uStack_48 = uVar5 + 0x24;
      if ((undefined *)0x1f < puVar3 + (-4 - (int)puVar9)) goto LAB_005db468;
    }
    uStack_50 = 0x5db38c;
    puStack_4c = puVar9;
    func_0x01674ea0();
  }
  uVar5 = *(uint *)(unaff_EBP + -0x28);
  *(undefined4 *)(unaff_EBP + -0x14) = 0;
  *(undefined4 *)(unaff_EBP + -0x10) = 0xf;
  *(undefined *)(unaff_EBP + -0x24) = 0;
  if (0xf < uVar5) {
    puVar3 = *(undefined **)(unaff_EBP + -0x3c);
    uStack_48 = uVar5 + 1;
    puVar9 = puVar3;
    if (0xfff < uStack_48) {
      puVar9 = *(undefined **)(puVar3 + -4);
      uStack_48 = uVar5 + 0x24;
      if ((undefined *)0x1f < puVar3 + (-4 - (int)puVar9)) goto LAB_005db46d;
    }
    uStack_50 = 0x5db3d2;
    puStack_4c = puVar9;
    func_0x01674ea0();
  }
  uVar5 = *(uint *)(unaff_EBP + -0x70);
  if (0xf < uVar5) {
    puVar3 = *(undefined **)(unaff_EBP + -0x84);
    uStack_48 = uVar5 + 1;
    puVar9 = puVar3;
    if (0xfff < uStack_48) {
      puVar9 = *(undefined **)(puVar3 + -4);
      uStack_48 = uVar5 + 0x24;
      if ((undefined *)0x1f < puVar3 + (-4 - (int)puVar9)) goto LAB_005db472;
    }
    uStack_50 = 0x5db405;
    puStack_4c = puVar9;
    func_0x01674ea0();
  }
  *(undefined4 *)(unaff_EBP + -0x74) = 0;
  *(undefined4 *)(unaff_EBP + -0x70) = 0xf;
  *(undefined *)(unaff_EBP + -0x84) = 0;
  uStack_48 = 0x5db428;
  func_0x0056d9d0();
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return;
}



// referenced at 0x005e68a1, inferred function entry 005e68a1

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005e68a1(void)

{
  undefined8 uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined *puVar10;
  undefined4 *puVar11;
  undefined *puVar12;
  undefined4 uVar13;
  int *piVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  char *pcVar18;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  uint uVar19;
  undefined4 *unaff_FS_OFFSET;
  bool bVar20;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  uVar19 = *(uint *)(unaff_EBP + -0x18);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (uVar19 < 0x10) {
LAB_005e6912:
    iVar7 = *(int *)(unaff_EBP + -0x34);
    *(undefined4 *)(unaff_EBP + -0xb0) = 0;
    *(undefined4 *)(unaff_EBP + -0xac) = 0xf;
    *(undefined *)(unaff_EBP + -0xc0) = 0;
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 2;
    if ((iVar7 != 0) && (*(char *)(unaff_EBP + 8) != '\0')) {
      if (DAT_01d65cf0 == '\0') {
        cVar6 = func_0x00a161b0();
        if (cVar6 != '\0') {
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c83b8,0x58);
          *(undefined *)(unaff_EBP + -4) = 5;
          func_0x0098c2c0(3,unaff_EBP + -0x2c);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c8414,0x2c);
          *(undefined *)(unaff_EBP + -4) = 6;
          func_0x008783f0(unaff_EBP + -0x2c,1,0);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
LAB_005e6a0c:
          func_0x005507b0();
          *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
          return 0;
        }
      }
      else {
        cVar6 = func_0x00a16240();
        if (cVar6 != '\0') {
          iVar7 = func_0x005e5bb0();
          *(int *)(unaff_EBP + -0x40) = iVar7;
          if (iVar7 != 0) {
            func_0x00a15e60(unaff_EBP + -100);
            *(undefined *)(unaff_EBP + -4) = 3;
            cVar6 = func_0x00a155c0(*(undefined4 *)(unaff_EBP + -0x40),unaff_EBP + -100,1);
            *(char *)(unaff_EBP + -0x11) = cVar6;
            bVar20 = DAT_01d65cf8 != '\0';
            *(char *)(unaff_EBP + -0x30) = cVar6;
            if (bVar20) {
              func_0x00a19180(*(undefined4 *)(unaff_EBP + -0x40),*(undefined4 *)(unaff_EBP + -0x30),
                              unaff_EBP + -100);
              cVar6 = *(char *)(unaff_EBP + -0x11);
            }
            if (cVar6 != '\0') {
              *(undefined4 *)(unaff_EBP + -0x1c) = 0;
              *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
              *(undefined *)(unaff_EBP + -0x2c) = 0;
              func_0x005542c0(&UNK_018c8350,99);
              *(undefined *)(unaff_EBP + -4) = 4;
              func_0x0098c2c0(3,unaff_EBP + -0x2c);
              func_0x005507b0();
              func_0x005e6280();
              goto LAB_005e6a0c;
            }
            *(undefined *)(unaff_EBP + -4) = 2;
            func_0x005e6280();
          }
        }
      }
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    if ((((DAT_01d65cf0 == '\0') && (iVar7 != 0)) && (*(char *)(unaff_EBP + 8) != '\0')) &&
       (cVar6 = func_0x00a16240(), cVar6 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
    piVar14 = *(int **)(unaff_ESI + 0x43c);
    func_0x00a19ae0(*piVar14 - (int)piVar14,piVar14[1] - (int)piVar14);
    func_0x00a24b20(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x10c) = *(undefined4 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -200) = 0;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0xf;
    *(undefined *)(unaff_EBP + -0xd8) = 0;
    bVar20 = DAT_01ea937d != '\0';
    *(undefined *)(unaff_EBP + -4) = 7;
    if (((bVar20) || (DAT_01d64710 != '\0')) || (DAT_01ea937e != '\0')) {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      puVar8 = (undefined4 *)
               func_0x01531190(unaff_EBP + -0x88,iVar7,*(undefined4 *)(unaff_EBP + -0xb0));
      if ((undefined4 *)(unaff_EBP + -0xd8) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *(undefined4 *)(unaff_EBP + -0xd8) = *puVar8;
        *(undefined4 *)(unaff_EBP + -0xd4) = uVar13;
        *(undefined4 *)(unaff_EBP + -0xd0) = uVar3;
        *(undefined4 *)(unaff_EBP + -0xcc) = uVar4;
        *(undefined8 *)(unaff_EBP + -200) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e3;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
    }
    if (DAT_01ea937c != '\0') {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      pcVar9 = (char *)(*(int *)(unaff_EBP + -0xb0) + iVar7);
      pcVar18 = (char *)(unaff_EBP + -0xc0);
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        pcVar18 = *(char **)(unaff_EBP + -0xc0);
      }
      uVar19 = 0;
      iVar7 = (int)pcVar9 - (int)pcVar18;
      *(undefined4 *)(unaff_EBP + -0x40) = 0;
      if (pcVar9 < pcVar18) {
        iVar7 = 0;
      }
      *(int *)(unaff_EBP + -0x30) = iVar7;
      if (iVar7 != 0) {
        do {
          cVar6 = *pcVar18;
          pcVar18 = pcVar18 + 1;
          uVar19 = uVar19 ^ (uVar19 >> 2) + 0x9e3779b9 + uVar19 * 0x40 + (int)cVar6;
          iVar7 = *(int *)(unaff_EBP + -0x40) + 1;
          *(int *)(unaff_EBP + -0x40) = iVar7;
        } while (iVar7 != *(int *)(unaff_EBP + -0x30));
      }
      func_0x016774b0(DAT_01ea937c,&UNK_018c844c,uVar19);
      unaff_EDI = *(int *)(unaff_EBP + -0x38);
    }
    if (DAT_01ea937d != '\0') {
      puVar10 = &UNK_018c8468;
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      if (*(char *)(unaff_EBP + 8) == '\0') {
        puVar10 = &UNK_018c8474;
      }
      func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar10,puVar12,iVar7);
    }
    if (DAT_01d64710 != '\0') {
      *(undefined *)(unaff_EBP + -0x70) = 0;
      *(undefined4 *)(unaff_EBP + -0x38) = 0xb;
      puVar11 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x38);
      puVar8 = puVar11 + -1;
      if (puVar11 != (undefined4 *)&UNK_018be198) {
        puVar8 = puVar11;
      }
      *(undefined4 *)(unaff_EBP + -0x6c) = *puVar8;
      *(undefined4 *)(unaff_EBP + -0x68) = 0;
      *(undefined4 *)(unaff_EBP + -100) = 0x3f800000;
      *(undefined4 *)(unaff_EBP + -0x60) = 0;
      *(undefined4 *)(unaff_EBP + -0x5c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      puVar8 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x88);
      *(undefined *)(unaff_EBP + -4) = 9;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84a4,6);
      *(undefined *)(unaff_EBP + -4) = 10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 9;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e8;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81ed;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84ac,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xb;
      puVar10 = (undefined *)func_0x005d15d0(unaff_EBP + -0x2c);
      if (puVar10 != &DAT_01d79c68) {
        puVar10 = &DAT_01d79c80;
        if (0xf < _DAT_01d79c94) {
          puVar10 = _DAT_01d79c80;
        }
        func_0x005542c0(puVar10,_DAT_01d79c90);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f2;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84c0,0x12);
      *(undefined *)(unaff_EBP + -4) = 0xc;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      if (iVar7 != 0x1d79c50) {
        puVar10 = &DAT_01d79c68;
        if (0xf < _DAT_01d79c7c) {
          puVar10 = _DAT_01d79c68;
        }
        func_0x005542c0(puVar10,_DAT_01d79c78);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f7;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84d4,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xe;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      if ((undefined4 *)(iVar7 + 0x18) == (undefined4 *)(unaff_EBP + -0x2c)) {
        uVar19 = *(uint *)(unaff_EBP + -0x18);
      }
      else {
        func_0x005507b0();
        uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
        uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
        uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
        uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
        *(undefined *)(unaff_EBP + -0x2c) = 0;
        *(undefined4 *)(iVar7 + 0x18) = uVar13;
        *(undefined4 *)(iVar7 + 0x1c) = uVar3;
        *(undefined4 *)(iVar7 + 0x20) = uVar4;
        *(undefined4 *)(iVar7 + 0x24) = uVar5;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(unaff_EBP + -0x1c);
        uVar19 = 0xf;
      }
      uVar16 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      if (0xf < uVar16) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar17 = uVar16 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar17) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar17 = uVar16 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81fc;
        }
        func_0x01674ea0(iVar15,uVar17);
      }
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8201;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x88,unaff_EBP + 8);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84e8,9);
      *(undefined *)(unaff_EBP + -4) = 0x10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8206;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e820b;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x88,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      *(undefined *)(unaff_EBP + -4) = 0x11;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84f4,6);
      *(undefined *)(unaff_EBP + -4) = 0x12;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0x11;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8210;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8215;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x78) = 0;
      *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
      *(undefined *)(unaff_EBP + -0x88) = 0;
      func_0x005542c0(&UNK_018c84fc,0xd);
      *(undefined *)(unaff_EBP + -4) = 0x13;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c850c,10);
      *(undefined *)(unaff_EBP + -4) = 0x14;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018bde9c,3);
      *(undefined *)(unaff_EBP + -4) = 0x15;
      func_0x00879580(unaff_EBP + -0x2c,unaff_EBP + -0xa0,unaff_EBP + -0x88,unaff_EBP + -0x70);
      func_0x005507b0();
      func_0x005507b0();
      func_0x005507b0();
      *(undefined *)(unaff_EBP + -4) = 7;
      func_0x0056cfd0();
    }
    if (DAT_01ea937e != '\0') {
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      cVar6 = DAT_01ea937e;
      iVar7 = unaff_EBP + -0x2c;
      if (0xf < *(uint *)(unaff_EBP + -0x18)) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
      }
      puVar10 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar10 = _DAT_01d79c68;
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      *(undefined *)(unaff_EBP + -4) = 0x16;
      func_0x01677520(cVar6,&UNK_018c8518,puVar12,puVar10,*(undefined *)(unaff_EBP + 8),iVar7);
      func_0x005507b0();
    }
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 0x2c;
    func_0x014c9d60(unaff_EBP + -0x60,0);
    iVar7 = *(int *)(unaff_EBP + -0xa4);
    puVar8 = (undefined4 *)(iVar7 + 0x424);
    *(undefined *)(unaff_EBP + -4) = 0x2d;
    if (0xf < *(uint *)(iVar7 + 0x438)) {
      puVar8 = (undefined4 *)*puVar8;
    }
    func_0x014cbbc0(puVar8,*(undefined4 *)(iVar7 + 0x434));
    *(undefined4 *)(*(int *)(unaff_EBP + -0x60) + 0xb0) = 0;
    func_0x014cb780(unaff_EBP + -0xc0,1);
    pcVar18 = _DAT_01d79bfc;
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (pcVar18 == (char *)0x0) {
      iVar7 = 0;
    }
    else {
      *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
      pcVar9 = pcVar18;
      do {
        cVar6 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar6 != '\0');
      iVar7 = (int)pcVar9 - *(int *)(unaff_EBP + -0x38);
    }
    puVar10 = &DAT_01d79d70;
    if (0xf < _DAT_01d79d84) {
      puVar10 = _DAT_01d79d70;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79d80,pcVar18,iVar7);
    pcVar18 = "False";
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (*(char *)(unaff_EBP + 8) == '\0') {
      pcVar18 = "True";
    }
    *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
    pcVar9 = pcVar18;
    do {
      cVar6 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar6 != '\0');
    puVar10 = &DAT_01d79ed8;
    if (0xf < _DAT_01d79eec) {
      puVar10 = _DAT_01d79ed8;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79ee8,pcVar18,(int)pcVar9 - *(int *)(unaff_EBP + -0x38));
    if (DAT_01d64710 == '\0') {
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    else {
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x58,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2e;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86ac,0x12,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
      iVar7 = *(int *)(unaff_EBP + -0x34);
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x58,iVar7);
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2f;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86c0,0x14,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
    }
    *(undefined *)(unaff_EBP + -0x2c) = 0;
    uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
    uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
    uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
    uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
    uVar1 = *(undefined8 *)(unaff_EBP + -0x1c);
    *(undefined4 *)(unaff_EBP + -0x2c) = *(undefined4 *)(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x28) = *(undefined4 *)(unaff_EBP + -0xbc);
    *(undefined4 *)(unaff_EBP + -0x24) = *(undefined4 *)(unaff_EBP + -0xb8);
    *(undefined4 *)(unaff_EBP + -0x20) = *(undefined4 *)(unaff_EBP + -0xb4);
    *(undefined8 *)(unaff_EBP + -0x1c) = *(undefined8 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -0xc0) = uVar13;
    *(undefined4 *)(unaff_EBP + -0xbc) = uVar3;
    *(undefined4 *)(unaff_EBP + -0xb8) = uVar4;
    *(undefined4 *)(unaff_EBP + -0xb4) = uVar5;
    *(undefined8 *)(unaff_EBP + -0xb0) = uVar1;
    func_0x005507b0();
    func_0x0151f360(1);
    *(undefined4 *)(unaff_EBP + -0x90) = 0;
    *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
    *(undefined *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x31;
    func_0x014cba60();
    *(undefined **)(unaff_EBP + -0x134) = &UNK_018c8948;
    *(int *)(unaff_EBP + -0x130) = unaff_EBP + -0x40;
    *(int *)(unaff_EBP + -300) = unaff_EBP + -0xa0;
    *(int *)(unaff_EBP + -0x110) = unaff_EBP + -0x134;
    *(undefined *)(unaff_EBP + -4) = 0x32;
    func_0x014cb530(unaff_EBP + -0x134);
    piVar14 = *(int **)(unaff_EBP + -0x110);
    *(undefined *)(unaff_EBP + -4) = 0x31;
    if (piVar14 != (int *)0x0) {
      (**(code **)(*piVar14 + 0x10))
                (CONCAT31((int3)((uint)(unaff_EBP + -0x134) >> 8),
                          piVar14 != (int *)(unaff_EBP + -0x134)));
    }
    func_0x0151f430();
    if (*(int *)(unaff_EBP + -0x90) == 0) {
      if ((*(char *)(unaff_EBP + 8) != '\0') && (unaff_EDI != 0)) {
        func_0x005789c0(0x1ea93dc,&UNK_005e5a90);
        uVar13 = func_0x005e5ab0();
        piVar14 = (int *)func_0x008aa140(uVar13);
        *(int **)(unaff_EBP + -0x30) = piVar14;
        if (*piVar14 == 0) {
          uVar13 = func_0x00a1a140();
          uVar13 = func_0x008a9ba0(unaff_EBP + -0x3c,uVar13);
          func_0x005587e0(uVar13);
          piVar14 = *(int **)(unaff_EBP + -0x38);
          if (piVar14 != (int *)0x0) {
            LOCK();
            iVar15 = piVar14[1] + -1;
            piVar14[1] = iVar15;
            UNLOCK();
            if (iVar15 == 0) {
              (**(code **)*piVar14)();
              LOCK();
              iVar15 = piVar14[2] + -1;
              piVar14[2] = iVar15;
              UNLOCK();
              if (iVar15 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
          piVar14 = *(int **)(unaff_EBP + -0x30);
        }
        if (*piVar14 != 0) {
          func_0x00a1b330(*(undefined4 *)(unaff_EBP + 0xc),*(undefined4 *)(unaff_EBP + 0x10));
        }
      }
      if (iVar7 != 0) {
        *(undefined4 *)(unaff_EBP + -0x78) = 0;
        *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
        *(undefined *)(unaff_EBP + -0x88) = 0;
        func_0x005542c0(&UNK_018c86d8,0x13);
        *(undefined *)(unaff_EBP + -4) = 0x33;
        func_0x0097c9e0(unaff_EBP + -0x88);
        *(undefined *)(unaff_EBP + -4) = 0x31;
        func_0x005507b0();
        if (DAT_01d64710 != '\0') {
          func_0x005ea7b0();
        }
      }
      func_0x005507b0();
      func_0x0151f390();
      func_0x00550b30();
      func_0x005507b0();
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 1;
    }
  }
  else {
    iVar7 = *(int *)(unaff_EBP + -0x2c);
    uVar16 = uVar19 + 1;
    iVar15 = iVar7;
    if (uVar16 < 0x1000) {
LAB_005e6908:
      func_0x01674ea0(iVar15,uVar16);
      goto LAB_005e6912;
    }
    iVar15 = *(int *)(iVar7 + -4);
    uVar16 = uVar19 + 0x24;
    if ((iVar7 - iVar15) - 4U < 0x20) goto LAB_005e6908;
    func_0x017167a3();
LAB_005e81e3:
    func_0x017167a3();
LAB_005e81e8:
    func_0x017167a3();
LAB_005e81ed:
    func_0x017167a3();
LAB_005e81f2:
    func_0x017167a3();
LAB_005e81f7:
    func_0x017167a3();
LAB_005e81fc:
    func_0x017167a3();
LAB_005e8201:
    func_0x017167a3();
LAB_005e8206:
    func_0x017167a3();
LAB_005e820b:
    func_0x017167a3();
LAB_005e8210:
    func_0x017167a3();
LAB_005e8215:
    func_0x017167a3();
  }
  func_0x005500e0(unaff_EBP + -0xa0);
  func_0x0170c2a8(unaff_EBP + -0x16c,&UNK_01c17198);
  func_0x0170c2a8(0,0);
  pcVar2 = (code *)swi(3);
  uVar13 = (*pcVar2)();
  return uVar13;
}



// referenced at 0x005e6be3, inferred function entry 005e68a1

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005e68a1(void)

{
  undefined8 uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined *puVar10;
  undefined4 *puVar11;
  undefined *puVar12;
  undefined4 uVar13;
  int *piVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  char *pcVar18;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  uint uVar19;
  undefined4 *unaff_FS_OFFSET;
  bool bVar20;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  uVar19 = *(uint *)(unaff_EBP + -0x18);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (uVar19 < 0x10) {
LAB_005e6912:
    iVar7 = *(int *)(unaff_EBP + -0x34);
    *(undefined4 *)(unaff_EBP + -0xb0) = 0;
    *(undefined4 *)(unaff_EBP + -0xac) = 0xf;
    *(undefined *)(unaff_EBP + -0xc0) = 0;
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 2;
    if ((iVar7 != 0) && (*(char *)(unaff_EBP + 8) != '\0')) {
      if (DAT_01d65cf0 == '\0') {
        cVar6 = func_0x00a161b0();
        if (cVar6 != '\0') {
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c83b8,0x58);
          *(undefined *)(unaff_EBP + -4) = 5;
          func_0x0098c2c0(3,unaff_EBP + -0x2c);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c8414,0x2c);
          *(undefined *)(unaff_EBP + -4) = 6;
          func_0x008783f0(unaff_EBP + -0x2c,1,0);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
LAB_005e6a0c:
          func_0x005507b0();
          *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
          return 0;
        }
      }
      else {
        cVar6 = func_0x00a16240();
        if (cVar6 != '\0') {
          iVar7 = func_0x005e5bb0();
          *(int *)(unaff_EBP + -0x40) = iVar7;
          if (iVar7 != 0) {
            func_0x00a15e60(unaff_EBP + -100);
            *(undefined *)(unaff_EBP + -4) = 3;
            cVar6 = func_0x00a155c0(*(undefined4 *)(unaff_EBP + -0x40),unaff_EBP + -100,1);
            *(char *)(unaff_EBP + -0x11) = cVar6;
            bVar20 = DAT_01d65cf8 != '\0';
            *(char *)(unaff_EBP + -0x30) = cVar6;
            if (bVar20) {
              func_0x00a19180(*(undefined4 *)(unaff_EBP + -0x40),*(undefined4 *)(unaff_EBP + -0x30),
                              unaff_EBP + -100);
              cVar6 = *(char *)(unaff_EBP + -0x11);
            }
            if (cVar6 != '\0') {
              *(undefined4 *)(unaff_EBP + -0x1c) = 0;
              *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
              *(undefined *)(unaff_EBP + -0x2c) = 0;
              func_0x005542c0(&UNK_018c8350,99);
              *(undefined *)(unaff_EBP + -4) = 4;
              func_0x0098c2c0(3,unaff_EBP + -0x2c);
              func_0x005507b0();
              func_0x005e6280();
              goto LAB_005e6a0c;
            }
            *(undefined *)(unaff_EBP + -4) = 2;
            func_0x005e6280();
          }
        }
      }
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    if ((((DAT_01d65cf0 == '\0') && (iVar7 != 0)) && (*(char *)(unaff_EBP + 8) != '\0')) &&
       (cVar6 = func_0x00a16240(), cVar6 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
    piVar14 = *(int **)(unaff_ESI + 0x43c);
    func_0x00a19ae0(*piVar14 - (int)piVar14,piVar14[1] - (int)piVar14);
    func_0x00a24b20(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x10c) = *(undefined4 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -200) = 0;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0xf;
    *(undefined *)(unaff_EBP + -0xd8) = 0;
    bVar20 = DAT_01ea937d != '\0';
    *(undefined *)(unaff_EBP + -4) = 7;
    if (((bVar20) || (DAT_01d64710 != '\0')) || (DAT_01ea937e != '\0')) {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      puVar8 = (undefined4 *)
               func_0x01531190(unaff_EBP + -0x88,iVar7,*(undefined4 *)(unaff_EBP + -0xb0));
      if ((undefined4 *)(unaff_EBP + -0xd8) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *(undefined4 *)(unaff_EBP + -0xd8) = *puVar8;
        *(undefined4 *)(unaff_EBP + -0xd4) = uVar13;
        *(undefined4 *)(unaff_EBP + -0xd0) = uVar3;
        *(undefined4 *)(unaff_EBP + -0xcc) = uVar4;
        *(undefined8 *)(unaff_EBP + -200) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e3;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
    }
    if (DAT_01ea937c != '\0') {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      pcVar9 = (char *)(*(int *)(unaff_EBP + -0xb0) + iVar7);
      pcVar18 = (char *)(unaff_EBP + -0xc0);
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        pcVar18 = *(char **)(unaff_EBP + -0xc0);
      }
      uVar19 = 0;
      iVar7 = (int)pcVar9 - (int)pcVar18;
      *(undefined4 *)(unaff_EBP + -0x40) = 0;
      if (pcVar9 < pcVar18) {
        iVar7 = 0;
      }
      *(int *)(unaff_EBP + -0x30) = iVar7;
      if (iVar7 != 0) {
        do {
          cVar6 = *pcVar18;
          pcVar18 = pcVar18 + 1;
          uVar19 = uVar19 ^ (uVar19 >> 2) + 0x9e3779b9 + uVar19 * 0x40 + (int)cVar6;
          iVar7 = *(int *)(unaff_EBP + -0x40) + 1;
          *(int *)(unaff_EBP + -0x40) = iVar7;
        } while (iVar7 != *(int *)(unaff_EBP + -0x30));
      }
      func_0x016774b0(DAT_01ea937c,&UNK_018c844c,uVar19);
      unaff_EDI = *(int *)(unaff_EBP + -0x38);
    }
    if (DAT_01ea937d != '\0') {
      puVar10 = &UNK_018c8468;
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      if (*(char *)(unaff_EBP + 8) == '\0') {
        puVar10 = &UNK_018c8474;
      }
      func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar10,puVar12,iVar7);
    }
    if (DAT_01d64710 != '\0') {
      *(undefined *)(unaff_EBP + -0x70) = 0;
      *(undefined4 *)(unaff_EBP + -0x38) = 0xb;
      puVar11 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x38);
      puVar8 = puVar11 + -1;
      if (puVar11 != (undefined4 *)&UNK_018be198) {
        puVar8 = puVar11;
      }
      *(undefined4 *)(unaff_EBP + -0x6c) = *puVar8;
      *(undefined4 *)(unaff_EBP + -0x68) = 0;
      *(undefined4 *)(unaff_EBP + -100) = 0x3f800000;
      *(undefined4 *)(unaff_EBP + -0x60) = 0;
      *(undefined4 *)(unaff_EBP + -0x5c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      puVar8 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x88);
      *(undefined *)(unaff_EBP + -4) = 9;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84a4,6);
      *(undefined *)(unaff_EBP + -4) = 10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 9;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e8;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81ed;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84ac,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xb;
      puVar10 = (undefined *)func_0x005d15d0(unaff_EBP + -0x2c);
      if (puVar10 != &DAT_01d79c68) {
        puVar10 = &DAT_01d79c80;
        if (0xf < _DAT_01d79c94) {
          puVar10 = _DAT_01d79c80;
        }
        func_0x005542c0(puVar10,_DAT_01d79c90);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f2;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84c0,0x12);
      *(undefined *)(unaff_EBP + -4) = 0xc;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      if (iVar7 != 0x1d79c50) {
        puVar10 = &DAT_01d79c68;
        if (0xf < _DAT_01d79c7c) {
          puVar10 = _DAT_01d79c68;
        }
        func_0x005542c0(puVar10,_DAT_01d79c78);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f7;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84d4,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xe;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      if ((undefined4 *)(iVar7 + 0x18) == (undefined4 *)(unaff_EBP + -0x2c)) {
        uVar19 = *(uint *)(unaff_EBP + -0x18);
      }
      else {
        func_0x005507b0();
        uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
        uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
        uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
        uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
        *(undefined *)(unaff_EBP + -0x2c) = 0;
        *(undefined4 *)(iVar7 + 0x18) = uVar13;
        *(undefined4 *)(iVar7 + 0x1c) = uVar3;
        *(undefined4 *)(iVar7 + 0x20) = uVar4;
        *(undefined4 *)(iVar7 + 0x24) = uVar5;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(unaff_EBP + -0x1c);
        uVar19 = 0xf;
      }
      uVar16 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      if (0xf < uVar16) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar17 = uVar16 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar17) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar17 = uVar16 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81fc;
        }
        func_0x01674ea0(iVar15,uVar17);
      }
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8201;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x88,unaff_EBP + 8);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84e8,9);
      *(undefined *)(unaff_EBP + -4) = 0x10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8206;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e820b;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x88,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      *(undefined *)(unaff_EBP + -4) = 0x11;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84f4,6);
      *(undefined *)(unaff_EBP + -4) = 0x12;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0x11;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8210;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8215;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x78) = 0;
      *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
      *(undefined *)(unaff_EBP + -0x88) = 0;
      func_0x005542c0(&UNK_018c84fc,0xd);
      *(undefined *)(unaff_EBP + -4) = 0x13;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c850c,10);
      *(undefined *)(unaff_EBP + -4) = 0x14;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018bde9c,3);
      *(undefined *)(unaff_EBP + -4) = 0x15;
      func_0x00879580(unaff_EBP + -0x2c,unaff_EBP + -0xa0,unaff_EBP + -0x88,unaff_EBP + -0x70);
      func_0x005507b0();
      func_0x005507b0();
      func_0x005507b0();
      *(undefined *)(unaff_EBP + -4) = 7;
      func_0x0056cfd0();
    }
    if (DAT_01ea937e != '\0') {
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      cVar6 = DAT_01ea937e;
      iVar7 = unaff_EBP + -0x2c;
      if (0xf < *(uint *)(unaff_EBP + -0x18)) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
      }
      puVar10 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar10 = _DAT_01d79c68;
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      *(undefined *)(unaff_EBP + -4) = 0x16;
      func_0x01677520(cVar6,&UNK_018c8518,puVar12,puVar10,*(undefined *)(unaff_EBP + 8),iVar7);
      func_0x005507b0();
    }
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 0x2c;
    func_0x014c9d60(unaff_EBP + -0x60,0);
    iVar7 = *(int *)(unaff_EBP + -0xa4);
    puVar8 = (undefined4 *)(iVar7 + 0x424);
    *(undefined *)(unaff_EBP + -4) = 0x2d;
    if (0xf < *(uint *)(iVar7 + 0x438)) {
      puVar8 = (undefined4 *)*puVar8;
    }
    func_0x014cbbc0(puVar8,*(undefined4 *)(iVar7 + 0x434));
    *(undefined4 *)(*(int *)(unaff_EBP + -0x60) + 0xb0) = 0;
    func_0x014cb780(unaff_EBP + -0xc0,1);
    pcVar18 = _DAT_01d79bfc;
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (pcVar18 == (char *)0x0) {
      iVar7 = 0;
    }
    else {
      *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
      pcVar9 = pcVar18;
      do {
        cVar6 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar6 != '\0');
      iVar7 = (int)pcVar9 - *(int *)(unaff_EBP + -0x38);
    }
    puVar10 = &DAT_01d79d70;
    if (0xf < _DAT_01d79d84) {
      puVar10 = _DAT_01d79d70;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79d80,pcVar18,iVar7);
    pcVar18 = "False";
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (*(char *)(unaff_EBP + 8) == '\0') {
      pcVar18 = "True";
    }
    *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
    pcVar9 = pcVar18;
    do {
      cVar6 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar6 != '\0');
    puVar10 = &DAT_01d79ed8;
    if (0xf < _DAT_01d79eec) {
      puVar10 = _DAT_01d79ed8;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79ee8,pcVar18,(int)pcVar9 - *(int *)(unaff_EBP + -0x38));
    if (DAT_01d64710 == '\0') {
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    else {
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x58,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2e;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86ac,0x12,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
      iVar7 = *(int *)(unaff_EBP + -0x34);
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x58,iVar7);
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2f;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86c0,0x14,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
    }
    *(undefined *)(unaff_EBP + -0x2c) = 0;
    uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
    uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
    uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
    uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
    uVar1 = *(undefined8 *)(unaff_EBP + -0x1c);
    *(undefined4 *)(unaff_EBP + -0x2c) = *(undefined4 *)(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x28) = *(undefined4 *)(unaff_EBP + -0xbc);
    *(undefined4 *)(unaff_EBP + -0x24) = *(undefined4 *)(unaff_EBP + -0xb8);
    *(undefined4 *)(unaff_EBP + -0x20) = *(undefined4 *)(unaff_EBP + -0xb4);
    *(undefined8 *)(unaff_EBP + -0x1c) = *(undefined8 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -0xc0) = uVar13;
    *(undefined4 *)(unaff_EBP + -0xbc) = uVar3;
    *(undefined4 *)(unaff_EBP + -0xb8) = uVar4;
    *(undefined4 *)(unaff_EBP + -0xb4) = uVar5;
    *(undefined8 *)(unaff_EBP + -0xb0) = uVar1;
    func_0x005507b0();
    func_0x0151f360(1);
    *(undefined4 *)(unaff_EBP + -0x90) = 0;
    *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
    *(undefined *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x31;
    func_0x014cba60();
    *(undefined **)(unaff_EBP + -0x134) = &UNK_018c8948;
    *(int *)(unaff_EBP + -0x130) = unaff_EBP + -0x40;
    *(int *)(unaff_EBP + -300) = unaff_EBP + -0xa0;
    *(int *)(unaff_EBP + -0x110) = unaff_EBP + -0x134;
    *(undefined *)(unaff_EBP + -4) = 0x32;
    func_0x014cb530(unaff_EBP + -0x134);
    piVar14 = *(int **)(unaff_EBP + -0x110);
    *(undefined *)(unaff_EBP + -4) = 0x31;
    if (piVar14 != (int *)0x0) {
      (**(code **)(*piVar14 + 0x10))
                (CONCAT31((int3)((uint)(unaff_EBP + -0x134) >> 8),
                          piVar14 != (int *)(unaff_EBP + -0x134)));
    }
    func_0x0151f430();
    if (*(int *)(unaff_EBP + -0x90) == 0) {
      if ((*(char *)(unaff_EBP + 8) != '\0') && (unaff_EDI != 0)) {
        func_0x005789c0(0x1ea93dc,&UNK_005e5a90);
        uVar13 = func_0x005e5ab0();
        piVar14 = (int *)func_0x008aa140(uVar13);
        *(int **)(unaff_EBP + -0x30) = piVar14;
        if (*piVar14 == 0) {
          uVar13 = func_0x00a1a140();
          uVar13 = func_0x008a9ba0(unaff_EBP + -0x3c,uVar13);
          func_0x005587e0(uVar13);
          piVar14 = *(int **)(unaff_EBP + -0x38);
          if (piVar14 != (int *)0x0) {
            LOCK();
            iVar15 = piVar14[1] + -1;
            piVar14[1] = iVar15;
            UNLOCK();
            if (iVar15 == 0) {
              (**(code **)*piVar14)();
              LOCK();
              iVar15 = piVar14[2] + -1;
              piVar14[2] = iVar15;
              UNLOCK();
              if (iVar15 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
          piVar14 = *(int **)(unaff_EBP + -0x30);
        }
        if (*piVar14 != 0) {
          func_0x00a1b330(*(undefined4 *)(unaff_EBP + 0xc),*(undefined4 *)(unaff_EBP + 0x10));
        }
      }
      if (iVar7 != 0) {
        *(undefined4 *)(unaff_EBP + -0x78) = 0;
        *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
        *(undefined *)(unaff_EBP + -0x88) = 0;
        func_0x005542c0(&UNK_018c86d8,0x13);
        *(undefined *)(unaff_EBP + -4) = 0x33;
        func_0x0097c9e0(unaff_EBP + -0x88);
        *(undefined *)(unaff_EBP + -4) = 0x31;
        func_0x005507b0();
        if (DAT_01d64710 != '\0') {
          func_0x005ea7b0();
        }
      }
      func_0x005507b0();
      func_0x0151f390();
      func_0x00550b30();
      func_0x005507b0();
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 1;
    }
  }
  else {
    iVar7 = *(int *)(unaff_EBP + -0x2c);
    uVar16 = uVar19 + 1;
    iVar15 = iVar7;
    if (uVar16 < 0x1000) {
LAB_005e6908:
      func_0x01674ea0(iVar15,uVar16);
      goto LAB_005e6912;
    }
    iVar15 = *(int *)(iVar7 + -4);
    uVar16 = uVar19 + 0x24;
    if ((iVar7 - iVar15) - 4U < 0x20) goto LAB_005e6908;
    func_0x017167a3();
LAB_005e81e3:
    func_0x017167a3();
LAB_005e81e8:
    func_0x017167a3();
LAB_005e81ed:
    func_0x017167a3();
LAB_005e81f2:
    func_0x017167a3();
LAB_005e81f7:
    func_0x017167a3();
LAB_005e81fc:
    func_0x017167a3();
LAB_005e8201:
    func_0x017167a3();
LAB_005e8206:
    func_0x017167a3();
LAB_005e820b:
    func_0x017167a3();
LAB_005e8210:
    func_0x017167a3();
LAB_005e8215:
    func_0x017167a3();
  }
  func_0x005500e0(unaff_EBP + -0xa0);
  func_0x0170c2a8(unaff_EBP + -0x16c,&UNK_01c17198);
  func_0x0170c2a8(0,0);
  pcVar2 = (code *)swi(3);
  uVar13 = (*pcVar2)();
  return uVar13;
}



// referenced at 0x005e735b, inferred function entry 005e68a1

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005e68a1(void)

{
  undefined8 uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined *puVar10;
  undefined4 *puVar11;
  undefined *puVar12;
  undefined4 uVar13;
  int *piVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  char *pcVar18;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  uint uVar19;
  undefined4 *unaff_FS_OFFSET;
  bool bVar20;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  uVar19 = *(uint *)(unaff_EBP + -0x18);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (uVar19 < 0x10) {
LAB_005e6912:
    iVar7 = *(int *)(unaff_EBP + -0x34);
    *(undefined4 *)(unaff_EBP + -0xb0) = 0;
    *(undefined4 *)(unaff_EBP + -0xac) = 0xf;
    *(undefined *)(unaff_EBP + -0xc0) = 0;
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 2;
    if ((iVar7 != 0) && (*(char *)(unaff_EBP + 8) != '\0')) {
      if (DAT_01d65cf0 == '\0') {
        cVar6 = func_0x00a161b0();
        if (cVar6 != '\0') {
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c83b8,0x58);
          *(undefined *)(unaff_EBP + -4) = 5;
          func_0x0098c2c0(3,unaff_EBP + -0x2c);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c8414,0x2c);
          *(undefined *)(unaff_EBP + -4) = 6;
          func_0x008783f0(unaff_EBP + -0x2c,1,0);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
LAB_005e6a0c:
          func_0x005507b0();
          *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
          return 0;
        }
      }
      else {
        cVar6 = func_0x00a16240();
        if (cVar6 != '\0') {
          iVar7 = func_0x005e5bb0();
          *(int *)(unaff_EBP + -0x40) = iVar7;
          if (iVar7 != 0) {
            func_0x00a15e60(unaff_EBP + -100);
            *(undefined *)(unaff_EBP + -4) = 3;
            cVar6 = func_0x00a155c0(*(undefined4 *)(unaff_EBP + -0x40),unaff_EBP + -100,1);
            *(char *)(unaff_EBP + -0x11) = cVar6;
            bVar20 = DAT_01d65cf8 != '\0';
            *(char *)(unaff_EBP + -0x30) = cVar6;
            if (bVar20) {
              func_0x00a19180(*(undefined4 *)(unaff_EBP + -0x40),*(undefined4 *)(unaff_EBP + -0x30),
                              unaff_EBP + -100);
              cVar6 = *(char *)(unaff_EBP + -0x11);
            }
            if (cVar6 != '\0') {
              *(undefined4 *)(unaff_EBP + -0x1c) = 0;
              *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
              *(undefined *)(unaff_EBP + -0x2c) = 0;
              func_0x005542c0(&UNK_018c8350,99);
              *(undefined *)(unaff_EBP + -4) = 4;
              func_0x0098c2c0(3,unaff_EBP + -0x2c);
              func_0x005507b0();
              func_0x005e6280();
              goto LAB_005e6a0c;
            }
            *(undefined *)(unaff_EBP + -4) = 2;
            func_0x005e6280();
          }
        }
      }
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    if ((((DAT_01d65cf0 == '\0') && (iVar7 != 0)) && (*(char *)(unaff_EBP + 8) != '\0')) &&
       (cVar6 = func_0x00a16240(), cVar6 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
    piVar14 = *(int **)(unaff_ESI + 0x43c);
    func_0x00a19ae0(*piVar14 - (int)piVar14,piVar14[1] - (int)piVar14);
    func_0x00a24b20(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x10c) = *(undefined4 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -200) = 0;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0xf;
    *(undefined *)(unaff_EBP + -0xd8) = 0;
    bVar20 = DAT_01ea937d != '\0';
    *(undefined *)(unaff_EBP + -4) = 7;
    if (((bVar20) || (DAT_01d64710 != '\0')) || (DAT_01ea937e != '\0')) {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      puVar8 = (undefined4 *)
               func_0x01531190(unaff_EBP + -0x88,iVar7,*(undefined4 *)(unaff_EBP + -0xb0));
      if ((undefined4 *)(unaff_EBP + -0xd8) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *(undefined4 *)(unaff_EBP + -0xd8) = *puVar8;
        *(undefined4 *)(unaff_EBP + -0xd4) = uVar13;
        *(undefined4 *)(unaff_EBP + -0xd0) = uVar3;
        *(undefined4 *)(unaff_EBP + -0xcc) = uVar4;
        *(undefined8 *)(unaff_EBP + -200) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e3;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
    }
    if (DAT_01ea937c != '\0') {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      pcVar9 = (char *)(*(int *)(unaff_EBP + -0xb0) + iVar7);
      pcVar18 = (char *)(unaff_EBP + -0xc0);
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        pcVar18 = *(char **)(unaff_EBP + -0xc0);
      }
      uVar19 = 0;
      iVar7 = (int)pcVar9 - (int)pcVar18;
      *(undefined4 *)(unaff_EBP + -0x40) = 0;
      if (pcVar9 < pcVar18) {
        iVar7 = 0;
      }
      *(int *)(unaff_EBP + -0x30) = iVar7;
      if (iVar7 != 0) {
        do {
          cVar6 = *pcVar18;
          pcVar18 = pcVar18 + 1;
          uVar19 = uVar19 ^ (uVar19 >> 2) + 0x9e3779b9 + uVar19 * 0x40 + (int)cVar6;
          iVar7 = *(int *)(unaff_EBP + -0x40) + 1;
          *(int *)(unaff_EBP + -0x40) = iVar7;
        } while (iVar7 != *(int *)(unaff_EBP + -0x30));
      }
      func_0x016774b0(DAT_01ea937c,&UNK_018c844c,uVar19);
      unaff_EDI = *(int *)(unaff_EBP + -0x38);
    }
    if (DAT_01ea937d != '\0') {
      puVar10 = &UNK_018c8468;
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      if (*(char *)(unaff_EBP + 8) == '\0') {
        puVar10 = &UNK_018c8474;
      }
      func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar10,puVar12,iVar7);
    }
    if (DAT_01d64710 != '\0') {
      *(undefined *)(unaff_EBP + -0x70) = 0;
      *(undefined4 *)(unaff_EBP + -0x38) = 0xb;
      puVar11 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x38);
      puVar8 = puVar11 + -1;
      if (puVar11 != (undefined4 *)&UNK_018be198) {
        puVar8 = puVar11;
      }
      *(undefined4 *)(unaff_EBP + -0x6c) = *puVar8;
      *(undefined4 *)(unaff_EBP + -0x68) = 0;
      *(undefined4 *)(unaff_EBP + -100) = 0x3f800000;
      *(undefined4 *)(unaff_EBP + -0x60) = 0;
      *(undefined4 *)(unaff_EBP + -0x5c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      puVar8 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x88);
      *(undefined *)(unaff_EBP + -4) = 9;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84a4,6);
      *(undefined *)(unaff_EBP + -4) = 10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 9;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e8;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81ed;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84ac,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xb;
      puVar10 = (undefined *)func_0x005d15d0(unaff_EBP + -0x2c);
      if (puVar10 != &DAT_01d79c68) {
        puVar10 = &DAT_01d79c80;
        if (0xf < _DAT_01d79c94) {
          puVar10 = _DAT_01d79c80;
        }
        func_0x005542c0(puVar10,_DAT_01d79c90);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f2;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84c0,0x12);
      *(undefined *)(unaff_EBP + -4) = 0xc;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      if (iVar7 != 0x1d79c50) {
        puVar10 = &DAT_01d79c68;
        if (0xf < _DAT_01d79c7c) {
          puVar10 = _DAT_01d79c68;
        }
        func_0x005542c0(puVar10,_DAT_01d79c78);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f7;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84d4,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xe;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      if ((undefined4 *)(iVar7 + 0x18) == (undefined4 *)(unaff_EBP + -0x2c)) {
        uVar19 = *(uint *)(unaff_EBP + -0x18);
      }
      else {
        func_0x005507b0();
        uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
        uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
        uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
        uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
        *(undefined *)(unaff_EBP + -0x2c) = 0;
        *(undefined4 *)(iVar7 + 0x18) = uVar13;
        *(undefined4 *)(iVar7 + 0x1c) = uVar3;
        *(undefined4 *)(iVar7 + 0x20) = uVar4;
        *(undefined4 *)(iVar7 + 0x24) = uVar5;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(unaff_EBP + -0x1c);
        uVar19 = 0xf;
      }
      uVar16 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      if (0xf < uVar16) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar17 = uVar16 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar17) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar17 = uVar16 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81fc;
        }
        func_0x01674ea0(iVar15,uVar17);
      }
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8201;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x88,unaff_EBP + 8);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84e8,9);
      *(undefined *)(unaff_EBP + -4) = 0x10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8206;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e820b;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x88,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      *(undefined *)(unaff_EBP + -4) = 0x11;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84f4,6);
      *(undefined *)(unaff_EBP + -4) = 0x12;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0x11;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8210;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8215;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x78) = 0;
      *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
      *(undefined *)(unaff_EBP + -0x88) = 0;
      func_0x005542c0(&UNK_018c84fc,0xd);
      *(undefined *)(unaff_EBP + -4) = 0x13;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c850c,10);
      *(undefined *)(unaff_EBP + -4) = 0x14;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018bde9c,3);
      *(undefined *)(unaff_EBP + -4) = 0x15;
      func_0x00879580(unaff_EBP + -0x2c,unaff_EBP + -0xa0,unaff_EBP + -0x88,unaff_EBP + -0x70);
      func_0x005507b0();
      func_0x005507b0();
      func_0x005507b0();
      *(undefined *)(unaff_EBP + -4) = 7;
      func_0x0056cfd0();
    }
    if (DAT_01ea937e != '\0') {
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      cVar6 = DAT_01ea937e;
      iVar7 = unaff_EBP + -0x2c;
      if (0xf < *(uint *)(unaff_EBP + -0x18)) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
      }
      puVar10 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar10 = _DAT_01d79c68;
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      *(undefined *)(unaff_EBP + -4) = 0x16;
      func_0x01677520(cVar6,&UNK_018c8518,puVar12,puVar10,*(undefined *)(unaff_EBP + 8),iVar7);
      func_0x005507b0();
    }
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 0x2c;
    func_0x014c9d60(unaff_EBP + -0x60,0);
    iVar7 = *(int *)(unaff_EBP + -0xa4);
    puVar8 = (undefined4 *)(iVar7 + 0x424);
    *(undefined *)(unaff_EBP + -4) = 0x2d;
    if (0xf < *(uint *)(iVar7 + 0x438)) {
      puVar8 = (undefined4 *)*puVar8;
    }
    func_0x014cbbc0(puVar8,*(undefined4 *)(iVar7 + 0x434));
    *(undefined4 *)(*(int *)(unaff_EBP + -0x60) + 0xb0) = 0;
    func_0x014cb780(unaff_EBP + -0xc0,1);
    pcVar18 = _DAT_01d79bfc;
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (pcVar18 == (char *)0x0) {
      iVar7 = 0;
    }
    else {
      *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
      pcVar9 = pcVar18;
      do {
        cVar6 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar6 != '\0');
      iVar7 = (int)pcVar9 - *(int *)(unaff_EBP + -0x38);
    }
    puVar10 = &DAT_01d79d70;
    if (0xf < _DAT_01d79d84) {
      puVar10 = _DAT_01d79d70;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79d80,pcVar18,iVar7);
    pcVar18 = "False";
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (*(char *)(unaff_EBP + 8) == '\0') {
      pcVar18 = "True";
    }
    *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
    pcVar9 = pcVar18;
    do {
      cVar6 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar6 != '\0');
    puVar10 = &DAT_01d79ed8;
    if (0xf < _DAT_01d79eec) {
      puVar10 = _DAT_01d79ed8;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79ee8,pcVar18,(int)pcVar9 - *(int *)(unaff_EBP + -0x38));
    if (DAT_01d64710 == '\0') {
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    else {
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x58,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2e;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86ac,0x12,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
      iVar7 = *(int *)(unaff_EBP + -0x34);
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x58,iVar7);
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2f;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86c0,0x14,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
    }
    *(undefined *)(unaff_EBP + -0x2c) = 0;
    uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
    uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
    uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
    uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
    uVar1 = *(undefined8 *)(unaff_EBP + -0x1c);
    *(undefined4 *)(unaff_EBP + -0x2c) = *(undefined4 *)(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x28) = *(undefined4 *)(unaff_EBP + -0xbc);
    *(undefined4 *)(unaff_EBP + -0x24) = *(undefined4 *)(unaff_EBP + -0xb8);
    *(undefined4 *)(unaff_EBP + -0x20) = *(undefined4 *)(unaff_EBP + -0xb4);
    *(undefined8 *)(unaff_EBP + -0x1c) = *(undefined8 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -0xc0) = uVar13;
    *(undefined4 *)(unaff_EBP + -0xbc) = uVar3;
    *(undefined4 *)(unaff_EBP + -0xb8) = uVar4;
    *(undefined4 *)(unaff_EBP + -0xb4) = uVar5;
    *(undefined8 *)(unaff_EBP + -0xb0) = uVar1;
    func_0x005507b0();
    func_0x0151f360(1);
    *(undefined4 *)(unaff_EBP + -0x90) = 0;
    *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
    *(undefined *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x31;
    func_0x014cba60();
    *(undefined **)(unaff_EBP + -0x134) = &UNK_018c8948;
    *(int *)(unaff_EBP + -0x130) = unaff_EBP + -0x40;
    *(int *)(unaff_EBP + -300) = unaff_EBP + -0xa0;
    *(int *)(unaff_EBP + -0x110) = unaff_EBP + -0x134;
    *(undefined *)(unaff_EBP + -4) = 0x32;
    func_0x014cb530(unaff_EBP + -0x134);
    piVar14 = *(int **)(unaff_EBP + -0x110);
    *(undefined *)(unaff_EBP + -4) = 0x31;
    if (piVar14 != (int *)0x0) {
      (**(code **)(*piVar14 + 0x10))
                (CONCAT31((int3)((uint)(unaff_EBP + -0x134) >> 8),
                          piVar14 != (int *)(unaff_EBP + -0x134)));
    }
    func_0x0151f430();
    if (*(int *)(unaff_EBP + -0x90) == 0) {
      if ((*(char *)(unaff_EBP + 8) != '\0') && (unaff_EDI != 0)) {
        func_0x005789c0(0x1ea93dc,&UNK_005e5a90);
        uVar13 = func_0x005e5ab0();
        piVar14 = (int *)func_0x008aa140(uVar13);
        *(int **)(unaff_EBP + -0x30) = piVar14;
        if (*piVar14 == 0) {
          uVar13 = func_0x00a1a140();
          uVar13 = func_0x008a9ba0(unaff_EBP + -0x3c,uVar13);
          func_0x005587e0(uVar13);
          piVar14 = *(int **)(unaff_EBP + -0x38);
          if (piVar14 != (int *)0x0) {
            LOCK();
            iVar15 = piVar14[1] + -1;
            piVar14[1] = iVar15;
            UNLOCK();
            if (iVar15 == 0) {
              (**(code **)*piVar14)();
              LOCK();
              iVar15 = piVar14[2] + -1;
              piVar14[2] = iVar15;
              UNLOCK();
              if (iVar15 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
          piVar14 = *(int **)(unaff_EBP + -0x30);
        }
        if (*piVar14 != 0) {
          func_0x00a1b330(*(undefined4 *)(unaff_EBP + 0xc),*(undefined4 *)(unaff_EBP + 0x10));
        }
      }
      if (iVar7 != 0) {
        *(undefined4 *)(unaff_EBP + -0x78) = 0;
        *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
        *(undefined *)(unaff_EBP + -0x88) = 0;
        func_0x005542c0(&UNK_018c86d8,0x13);
        *(undefined *)(unaff_EBP + -4) = 0x33;
        func_0x0097c9e0(unaff_EBP + -0x88);
        *(undefined *)(unaff_EBP + -4) = 0x31;
        func_0x005507b0();
        if (DAT_01d64710 != '\0') {
          func_0x005ea7b0();
        }
      }
      func_0x005507b0();
      func_0x0151f390();
      func_0x00550b30();
      func_0x005507b0();
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 1;
    }
  }
  else {
    iVar7 = *(int *)(unaff_EBP + -0x2c);
    uVar16 = uVar19 + 1;
    iVar15 = iVar7;
    if (uVar16 < 0x1000) {
LAB_005e6908:
      func_0x01674ea0(iVar15,uVar16);
      goto LAB_005e6912;
    }
    iVar15 = *(int *)(iVar7 + -4);
    uVar16 = uVar19 + 0x24;
    if ((iVar7 - iVar15) - 4U < 0x20) goto LAB_005e6908;
    func_0x017167a3();
LAB_005e81e3:
    func_0x017167a3();
LAB_005e81e8:
    func_0x017167a3();
LAB_005e81ed:
    func_0x017167a3();
LAB_005e81f2:
    func_0x017167a3();
LAB_005e81f7:
    func_0x017167a3();
LAB_005e81fc:
    func_0x017167a3();
LAB_005e8201:
    func_0x017167a3();
LAB_005e8206:
    func_0x017167a3();
LAB_005e820b:
    func_0x017167a3();
LAB_005e8210:
    func_0x017167a3();
LAB_005e8215:
    func_0x017167a3();
  }
  func_0x005500e0(unaff_EBP + -0xa0);
  func_0x0170c2a8(unaff_EBP + -0x16c,&UNK_01c17198);
  func_0x0170c2a8(0,0);
  pcVar2 = (code *)swi(3);
  uVar13 = (*pcVar2)();
  return uVar13;
}



// referenced at 0x005e748a, inferred function entry 005e68a1

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005e68a1(void)

{
  undefined8 uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined *puVar10;
  undefined4 *puVar11;
  undefined *puVar12;
  undefined4 uVar13;
  int *piVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  char *pcVar18;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  uint uVar19;
  undefined4 *unaff_FS_OFFSET;
  bool bVar20;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x2c,1,0);
  uVar19 = *(uint *)(unaff_EBP + -0x18);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (uVar19 < 0x10) {
LAB_005e6912:
    iVar7 = *(int *)(unaff_EBP + -0x34);
    *(undefined4 *)(unaff_EBP + -0xb0) = 0;
    *(undefined4 *)(unaff_EBP + -0xac) = 0xf;
    *(undefined *)(unaff_EBP + -0xc0) = 0;
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 2;
    if ((iVar7 != 0) && (*(char *)(unaff_EBP + 8) != '\0')) {
      if (DAT_01d65cf0 == '\0') {
        cVar6 = func_0x00a161b0();
        if (cVar6 != '\0') {
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c83b8,0x58);
          *(undefined *)(unaff_EBP + -4) = 5;
          func_0x0098c2c0(3,unaff_EBP + -0x2c);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          *(undefined4 *)(unaff_EBP + -0x1c) = 0;
          *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
          *(undefined *)(unaff_EBP + -0x2c) = 0;
          func_0x005542c0(&UNK_018c8414,0x2c);
          *(undefined *)(unaff_EBP + -4) = 6;
          func_0x008783f0(unaff_EBP + -0x2c,1,0);
          *(undefined *)(unaff_EBP + -4) = 2;
          func_0x005507b0();
          func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
LAB_005e6a0c:
          func_0x005507b0();
          *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
          return 0;
        }
      }
      else {
        cVar6 = func_0x00a16240();
        if (cVar6 != '\0') {
          iVar7 = func_0x005e5bb0();
          *(int *)(unaff_EBP + -0x40) = iVar7;
          if (iVar7 != 0) {
            func_0x00a15e60(unaff_EBP + -100);
            *(undefined *)(unaff_EBP + -4) = 3;
            cVar6 = func_0x00a155c0(*(undefined4 *)(unaff_EBP + -0x40),unaff_EBP + -100,1);
            *(char *)(unaff_EBP + -0x11) = cVar6;
            bVar20 = DAT_01d65cf8 != '\0';
            *(char *)(unaff_EBP + -0x30) = cVar6;
            if (bVar20) {
              func_0x00a19180(*(undefined4 *)(unaff_EBP + -0x40),*(undefined4 *)(unaff_EBP + -0x30),
                              unaff_EBP + -100);
              cVar6 = *(char *)(unaff_EBP + -0x11);
            }
            if (cVar6 != '\0') {
              *(undefined4 *)(unaff_EBP + -0x1c) = 0;
              *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
              *(undefined *)(unaff_EBP + -0x2c) = 0;
              func_0x005542c0(&UNK_018c8350,99);
              *(undefined *)(unaff_EBP + -4) = 4;
              func_0x0098c2c0(3,unaff_EBP + -0x2c);
              func_0x005507b0();
              func_0x005e6280();
              goto LAB_005e6a0c;
            }
            *(undefined *)(unaff_EBP + -4) = 2;
            func_0x005e6280();
          }
        }
      }
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    if ((((DAT_01d65cf0 == '\0') && (iVar7 != 0)) && (*(char *)(unaff_EBP + 8) != '\0')) &&
       (cVar6 = func_0x00a16240(), cVar6 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
    piVar14 = *(int **)(unaff_ESI + 0x43c);
    func_0x00a19ae0(*piVar14 - (int)piVar14,piVar14[1] - (int)piVar14);
    func_0x00a24b20(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x10c) = *(undefined4 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -200) = 0;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0xf;
    *(undefined *)(unaff_EBP + -0xd8) = 0;
    bVar20 = DAT_01ea937d != '\0';
    *(undefined *)(unaff_EBP + -4) = 7;
    if (((bVar20) || (DAT_01d64710 != '\0')) || (DAT_01ea937e != '\0')) {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      puVar8 = (undefined4 *)
               func_0x01531190(unaff_EBP + -0x88,iVar7,*(undefined4 *)(unaff_EBP + -0xb0));
      if ((undefined4 *)(unaff_EBP + -0xd8) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *(undefined4 *)(unaff_EBP + -0xd8) = *puVar8;
        *(undefined4 *)(unaff_EBP + -0xd4) = uVar13;
        *(undefined4 *)(unaff_EBP + -0xd0) = uVar3;
        *(undefined4 *)(unaff_EBP + -0xcc) = uVar4;
        *(undefined8 *)(unaff_EBP + -200) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e3;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
    }
    if (DAT_01ea937c != '\0') {
      iVar7 = unaff_EBP + -0xc0;
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        iVar7 = *(int *)(unaff_EBP + -0xc0);
      }
      pcVar9 = (char *)(*(int *)(unaff_EBP + -0xb0) + iVar7);
      pcVar18 = (char *)(unaff_EBP + -0xc0);
      if (0xf < *(uint *)(unaff_EBP + -0xac)) {
        pcVar18 = *(char **)(unaff_EBP + -0xc0);
      }
      uVar19 = 0;
      iVar7 = (int)pcVar9 - (int)pcVar18;
      *(undefined4 *)(unaff_EBP + -0x40) = 0;
      if (pcVar9 < pcVar18) {
        iVar7 = 0;
      }
      *(int *)(unaff_EBP + -0x30) = iVar7;
      if (iVar7 != 0) {
        do {
          cVar6 = *pcVar18;
          pcVar18 = pcVar18 + 1;
          uVar19 = uVar19 ^ (uVar19 >> 2) + 0x9e3779b9 + uVar19 * 0x40 + (int)cVar6;
          iVar7 = *(int *)(unaff_EBP + -0x40) + 1;
          *(int *)(unaff_EBP + -0x40) = iVar7;
        } while (iVar7 != *(int *)(unaff_EBP + -0x30));
      }
      func_0x016774b0(DAT_01ea937c,&UNK_018c844c,uVar19);
      unaff_EDI = *(int *)(unaff_EBP + -0x38);
    }
    if (DAT_01ea937d != '\0') {
      puVar10 = &UNK_018c8468;
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      if (*(char *)(unaff_EBP + 8) == '\0') {
        puVar10 = &UNK_018c8474;
      }
      func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar10,puVar12,iVar7);
    }
    if (DAT_01d64710 != '\0') {
      *(undefined *)(unaff_EBP + -0x70) = 0;
      *(undefined4 *)(unaff_EBP + -0x38) = 0xb;
      puVar11 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x38);
      puVar8 = puVar11 + -1;
      if (puVar11 != (undefined4 *)&UNK_018be198) {
        puVar8 = puVar11;
      }
      *(undefined4 *)(unaff_EBP + -0x6c) = *puVar8;
      *(undefined4 *)(unaff_EBP + -0x68) = 0;
      *(undefined4 *)(unaff_EBP + -100) = 0x3f800000;
      *(undefined4 *)(unaff_EBP + -0x60) = 0;
      *(undefined4 *)(unaff_EBP + -0x5c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      puVar8 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x88);
      *(undefined *)(unaff_EBP + -4) = 9;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84a4,6);
      *(undefined *)(unaff_EBP + -4) = 10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 9;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81e8;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81ed;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84ac,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xb;
      puVar10 = (undefined *)func_0x005d15d0(unaff_EBP + -0x2c);
      if (puVar10 != &DAT_01d79c68) {
        puVar10 = &DAT_01d79c80;
        if (0xf < _DAT_01d79c94) {
          puVar10 = _DAT_01d79c80;
        }
        func_0x005542c0(puVar10,_DAT_01d79c90);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f2;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84c0,0x12);
      *(undefined *)(unaff_EBP + -4) = 0xc;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      if (iVar7 != 0x1d79c50) {
        puVar10 = &DAT_01d79c68;
        if (0xf < _DAT_01d79c7c) {
          puVar10 = _DAT_01d79c68;
        }
        func_0x005542c0(puVar10,_DAT_01d79c78);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81f7;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c84d4,0x13);
      *(undefined *)(unaff_EBP + -4) = 0xe;
      iVar7 = func_0x005d15d0(unaff_EBP + -0xa0);
      if ((undefined4 *)(iVar7 + 0x18) == (undefined4 *)(unaff_EBP + -0x2c)) {
        uVar19 = *(uint *)(unaff_EBP + -0x18);
      }
      else {
        func_0x005507b0();
        uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
        uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
        uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
        uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
        *(undefined *)(unaff_EBP + -0x2c) = 0;
        *(undefined4 *)(iVar7 + 0x18) = uVar13;
        *(undefined4 *)(iVar7 + 0x1c) = uVar3;
        *(undefined4 *)(iVar7 + 0x20) = uVar4;
        *(undefined4 *)(iVar7 + 0x24) = uVar5;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(unaff_EBP + -0x1c);
        uVar19 = 0xf;
      }
      uVar16 = *(uint *)(unaff_EBP + -0x8c);
      *(undefined *)(unaff_EBP + -4) = 0xd;
      if (0xf < uVar16) {
        iVar7 = *(int *)(unaff_EBP + -0xa0);
        uVar17 = uVar16 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar17) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar17 = uVar16 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e81fc;
        }
        func_0x01674ea0(iVar15,uVar17);
      }
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8201;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x88,unaff_EBP + 8);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84e8,9);
      *(undefined *)(unaff_EBP + -4) = 0x10;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0xf;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8206;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e820b;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x88,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      *(undefined *)(unaff_EBP + -4) = 0x11;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018c84f4,6);
      *(undefined *)(unaff_EBP + -4) = 0x12;
      iVar7 = func_0x005d15d0(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x38) = iVar7;
      if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
        func_0x005507b0();
        uVar13 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        iVar7 = *(int *)(unaff_EBP + -0x38);
        *(undefined4 *)(iVar7 + 0x18) = *puVar8;
        *(undefined4 *)(iVar7 + 0x1c) = uVar13;
        *(undefined4 *)(iVar7 + 0x20) = uVar3;
        *(undefined4 *)(iVar7 + 0x24) = uVar4;
        *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      uVar19 = *(uint *)(unaff_EBP + -0x18);
      *(undefined *)(unaff_EBP + -4) = 0x11;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8210;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      uVar19 = *(uint *)(unaff_EBP + -0x74);
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar19) {
        iVar7 = *(int *)(unaff_EBP + -0x88);
        uVar16 = uVar19 + 1;
        iVar15 = iVar7;
        if (0xfff < uVar16) {
          iVar15 = *(int *)(iVar7 + -4);
          uVar16 = uVar19 + 0x24;
          if (0x1f < (iVar7 - iVar15) - 4U) goto LAB_005e8215;
        }
        func_0x01674ea0(iVar15,uVar16);
      }
      *(undefined4 *)(unaff_EBP + -0x78) = 0;
      *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
      *(undefined *)(unaff_EBP + -0x88) = 0;
      func_0x005542c0(&UNK_018c84fc,0xd);
      *(undefined *)(unaff_EBP + -4) = 0x13;
      *(undefined4 *)(unaff_EBP + -0x90) = 0;
      *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
      *(undefined *)(unaff_EBP + -0xa0) = 0;
      func_0x005542c0(&UNK_018c850c,10);
      *(undefined *)(unaff_EBP + -4) = 0x14;
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(&UNK_018bde9c,3);
      *(undefined *)(unaff_EBP + -4) = 0x15;
      func_0x00879580(unaff_EBP + -0x2c,unaff_EBP + -0xa0,unaff_EBP + -0x88,unaff_EBP + -0x70);
      func_0x005507b0();
      func_0x005507b0();
      func_0x005507b0();
      *(undefined *)(unaff_EBP + -4) = 7;
      func_0x0056cfd0();
    }
    if (DAT_01ea937e != '\0') {
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      uVar13 = 4;
      if (*(uint *)(unaff_EBP + -200) < 4) {
        uVar13 = *(undefined4 *)(unaff_EBP + -200);
      }
      iVar7 = unaff_EBP + -0xd8;
      if (0xf < *(uint *)(unaff_EBP + -0xc4)) {
        iVar7 = *(int *)(unaff_EBP + -0xd8);
      }
      *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
      *(undefined *)(unaff_EBP + -0x2c) = 0;
      func_0x005542c0(iVar7,uVar13);
      cVar6 = DAT_01ea937e;
      iVar7 = unaff_EBP + -0x2c;
      if (0xf < *(uint *)(unaff_EBP + -0x18)) {
        iVar7 = *(int *)(unaff_EBP + -0x2c);
      }
      puVar10 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar10 = _DAT_01d79c68;
      }
      puVar12 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar12 = _DAT_01d79c80;
      }
      *(undefined *)(unaff_EBP + -4) = 0x16;
      func_0x01677520(cVar6,&UNK_018c8518,puVar12,puVar10,*(undefined *)(unaff_EBP + 8),iVar7);
      func_0x005507b0();
    }
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -4) = 1;
    *(undefined *)(unaff_EBP + -4) = 0x2c;
    func_0x014c9d60(unaff_EBP + -0x60,0);
    iVar7 = *(int *)(unaff_EBP + -0xa4);
    puVar8 = (undefined4 *)(iVar7 + 0x424);
    *(undefined *)(unaff_EBP + -4) = 0x2d;
    if (0xf < *(uint *)(iVar7 + 0x438)) {
      puVar8 = (undefined4 *)*puVar8;
    }
    func_0x014cbbc0(puVar8,*(undefined4 *)(iVar7 + 0x434));
    *(undefined4 *)(*(int *)(unaff_EBP + -0x60) + 0xb0) = 0;
    func_0x014cb780(unaff_EBP + -0xc0,1);
    pcVar18 = _DAT_01d79bfc;
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (pcVar18 == (char *)0x0) {
      iVar7 = 0;
    }
    else {
      *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
      pcVar9 = pcVar18;
      do {
        cVar6 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar6 != '\0');
      iVar7 = (int)pcVar9 - *(int *)(unaff_EBP + -0x38);
    }
    puVar10 = &DAT_01d79d70;
    if (0xf < _DAT_01d79d84) {
      puVar10 = _DAT_01d79d70;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79d80,pcVar18,iVar7);
    pcVar18 = "False";
    *(undefined4 *)(unaff_EBP + -0x30) = *(undefined4 *)(unaff_EBP + -0x60);
    if (*(char *)(unaff_EBP + 8) == '\0') {
      pcVar18 = "True";
    }
    *(char **)(unaff_EBP + -0x38) = pcVar18 + 1;
    pcVar9 = pcVar18;
    do {
      cVar6 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar6 != '\0');
    puVar10 = &DAT_01d79ed8;
    if (0xf < _DAT_01d79eec) {
      puVar10 = _DAT_01d79ed8;
    }
    func_0x014cb8a0(puVar10,_DAT_01d79ee8,pcVar18,(int)pcVar9 - *(int *)(unaff_EBP + -0x38));
    if (DAT_01d64710 == '\0') {
      iVar7 = *(int *)(unaff_EBP + -0x34);
    }
    else {
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)
               func_0x01675640(unaff_EBP + -0x58,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                               *(undefined4 *)(unaff_EBP + 0x10));
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2e;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86ac,0x12,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
      iVar7 = *(int *)(unaff_EBP + -0x34);
      *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x60);
      puVar8 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x58,iVar7);
      uVar13 = puVar8[4];
      uVar19 = puVar8[5];
      *(undefined *)(unaff_EBP + -4) = 0x2f;
      if (0xf < uVar19) {
        puVar8 = (undefined4 *)*puVar8;
      }
      func_0x014cb8a0(&UNK_018c86c0,0x14,puVar8,uVar13);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
      func_0x005507b0();
    }
    *(undefined *)(unaff_EBP + -0x2c) = 0;
    uVar13 = *(undefined4 *)(unaff_EBP + -0x2c);
    uVar3 = *(undefined4 *)(unaff_EBP + -0x28);
    uVar4 = *(undefined4 *)(unaff_EBP + -0x24);
    uVar5 = *(undefined4 *)(unaff_EBP + -0x20);
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
    uVar1 = *(undefined8 *)(unaff_EBP + -0x1c);
    *(undefined4 *)(unaff_EBP + -0x2c) = *(undefined4 *)(unaff_EBP + -0xc0);
    *(undefined4 *)(unaff_EBP + -0x28) = *(undefined4 *)(unaff_EBP + -0xbc);
    *(undefined4 *)(unaff_EBP + -0x24) = *(undefined4 *)(unaff_EBP + -0xb8);
    *(undefined4 *)(unaff_EBP + -0x20) = *(undefined4 *)(unaff_EBP + -0xb4);
    *(undefined8 *)(unaff_EBP + -0x1c) = *(undefined8 *)(unaff_EBP + -0xb0);
    *(undefined4 *)(unaff_EBP + -0xc0) = uVar13;
    *(undefined4 *)(unaff_EBP + -0xbc) = uVar3;
    *(undefined4 *)(unaff_EBP + -0xb8) = uVar4;
    *(undefined4 *)(unaff_EBP + -0xb4) = uVar5;
    *(undefined8 *)(unaff_EBP + -0xb0) = uVar1;
    func_0x005507b0();
    func_0x0151f360(1);
    *(undefined4 *)(unaff_EBP + -0x90) = 0;
    *(undefined4 *)(unaff_EBP + -0x8c) = 0xf;
    *(undefined *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x31;
    func_0x014cba60();
    *(undefined **)(unaff_EBP + -0x134) = &UNK_018c8948;
    *(int *)(unaff_EBP + -0x130) = unaff_EBP + -0x40;
    *(int *)(unaff_EBP + -300) = unaff_EBP + -0xa0;
    *(int *)(unaff_EBP + -0x110) = unaff_EBP + -0x134;
    *(undefined *)(unaff_EBP + -4) = 0x32;
    func_0x014cb530(unaff_EBP + -0x134);
    piVar14 = *(int **)(unaff_EBP + -0x110);
    *(undefined *)(unaff_EBP + -4) = 0x31;
    if (piVar14 != (int *)0x0) {
      (**(code **)(*piVar14 + 0x10))
                (CONCAT31((int3)((uint)(unaff_EBP + -0x134) >> 8),
                          piVar14 != (int *)(unaff_EBP + -0x134)));
    }
    func_0x0151f430();
    if (*(int *)(unaff_EBP + -0x90) == 0) {
      if ((*(char *)(unaff_EBP + 8) != '\0') && (unaff_EDI != 0)) {
        func_0x005789c0(0x1ea93dc,&UNK_005e5a90);
        uVar13 = func_0x005e5ab0();
        piVar14 = (int *)func_0x008aa140(uVar13);
        *(int **)(unaff_EBP + -0x30) = piVar14;
        if (*piVar14 == 0) {
          uVar13 = func_0x00a1a140();
          uVar13 = func_0x008a9ba0(unaff_EBP + -0x3c,uVar13);
          func_0x005587e0(uVar13);
          piVar14 = *(int **)(unaff_EBP + -0x38);
          if (piVar14 != (int *)0x0) {
            LOCK();
            iVar15 = piVar14[1] + -1;
            piVar14[1] = iVar15;
            UNLOCK();
            if (iVar15 == 0) {
              (**(code **)*piVar14)();
              LOCK();
              iVar15 = piVar14[2] + -1;
              piVar14[2] = iVar15;
              UNLOCK();
              if (iVar15 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
          piVar14 = *(int **)(unaff_EBP + -0x30);
        }
        if (*piVar14 != 0) {
          func_0x00a1b330(*(undefined4 *)(unaff_EBP + 0xc),*(undefined4 *)(unaff_EBP + 0x10));
        }
      }
      if (iVar7 != 0) {
        *(undefined4 *)(unaff_EBP + -0x78) = 0;
        *(undefined4 *)(unaff_EBP + -0x74) = 0xf;
        *(undefined *)(unaff_EBP + -0x88) = 0;
        func_0x005542c0(&UNK_018c86d8,0x13);
        *(undefined *)(unaff_EBP + -4) = 0x33;
        func_0x0097c9e0(unaff_EBP + -0x88);
        *(undefined *)(unaff_EBP + -4) = 0x31;
        func_0x005507b0();
        if (DAT_01d64710 != '\0') {
          func_0x005ea7b0();
        }
      }
      func_0x005507b0();
      func_0x0151f390();
      func_0x00550b30();
      func_0x005507b0();
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 1;
    }
  }
  else {
    iVar7 = *(int *)(unaff_EBP + -0x2c);
    uVar16 = uVar19 + 1;
    iVar15 = iVar7;
    if (uVar16 < 0x1000) {
LAB_005e6908:
      func_0x01674ea0(iVar15,uVar16);
      goto LAB_005e6912;
    }
    iVar15 = *(int *)(iVar7 + -4);
    uVar16 = uVar19 + 0x24;
    if ((iVar7 - iVar15) - 4U < 0x20) goto LAB_005e6908;
    func_0x017167a3();
LAB_005e81e3:
    func_0x017167a3();
LAB_005e81e8:
    func_0x017167a3();
LAB_005e81ed:
    func_0x017167a3();
LAB_005e81f2:
    func_0x017167a3();
LAB_005e81f7:
    func_0x017167a3();
LAB_005e81fc:
    func_0x017167a3();
LAB_005e8201:
    func_0x017167a3();
LAB_005e8206:
    func_0x017167a3();
LAB_005e820b:
    func_0x017167a3();
LAB_005e8210:
    func_0x017167a3();
LAB_005e8215:
    func_0x017167a3();
  }
  func_0x005500e0(unaff_EBP + -0xa0);
  func_0x0170c2a8(unaff_EBP + -0x16c,&UNK_01c17198);
  func_0x0170c2a8(0,0);
  pcVar2 = (code *)swi(3);
  uVar13 = (*pcVar2)();
  return uVar13;
}



// referenced at 0x005e7a09, inferred function entry 005e7a09

undefined * FUN_005e7a09(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0054eff0(&UNK_018c8754);
  *(undefined *)(unaff_EBP + -4) = 0x39;
  func_0x01520d20(unaff_EBP + -0x88);
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x35;
  func_0x0151f7f0();
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    func_0x0098c2c0(3,unaff_EBP + -0x70);
  }
  if (DAT_01d59a70 != '\0') {
    uVar1 = func_0x0054eff0(&UNK_018c8774);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xa8) + 4))();
    uVar3 = func_0x0054eff0(&UNK_018c877c);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    uVar2 = func_0x00558c80(unaff_EBP + -0x108,uVar3,uVar2);
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    uVar1 = func_0x00558ba0(unaff_EBP + -0xf0,uVar2,uVar1);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    uVar1 = func_0x00558c20(unaff_EBP + -0x58,uVar1,*(int *)(unaff_EBP + -0xa4) + 0x424);
    func_0x005511f0(uVar1);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    iVar4 = unaff_EBP + -0x70;
    if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
      iVar4 = *(int *)(unaff_EBP + -0x70);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar4,0,0,0,3);
    unaff_EDI = *(int **)(unaff_EBP + -0xa8);
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + -0x11,unaff_EBP + -0x11,unaff_EBP + -0x11);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    uVar1 = func_0x0152fd20(unaff_EBP + -0x184);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    func_0x0054eff0(&UNK_018c84a4);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    func_0x005d15d0(unaff_EBP + -0x88,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    func_0x005d15d0(unaff_EBP + -0xa0,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x005d15d0(unaff_EBP + -0x108,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x44;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x124,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x45;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x46;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x47;
    func_0x005d15d0(unaff_EBP + -0xf0);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c87a0);
    *(undefined *)(unaff_EBP + -4) = 0x48;
    func_0x005d15d0(unaff_EBP + -0xf0,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x49;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x4a;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x4b;
    func_0x00879580(unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x58,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0(&UNK_018c87a8);
    *(undefined *)(unaff_EBP + -4) = 0x4c;
    func_0x008783f0(unaff_EBP + -0x58,1,0);
    func_0x005507b0();
  }
  func_0x005507b0();
  return &UNK_005e7e50;
}



// referenced at 0x005e7b2b, inferred function entry 005e7a09

undefined * FUN_005e7a09(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0054eff0(&UNK_018c8754);
  *(undefined *)(unaff_EBP + -4) = 0x39;
  func_0x01520d20(unaff_EBP + -0x88);
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x35;
  func_0x0151f7f0();
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    func_0x0098c2c0(3,unaff_EBP + -0x70);
  }
  if (DAT_01d59a70 != '\0') {
    uVar1 = func_0x0054eff0(&UNK_018c8774);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xa8) + 4))();
    uVar3 = func_0x0054eff0(&UNK_018c877c);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    uVar2 = func_0x00558c80(unaff_EBP + -0x108,uVar3,uVar2);
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    uVar1 = func_0x00558ba0(unaff_EBP + -0xf0,uVar2,uVar1);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    uVar1 = func_0x00558c20(unaff_EBP + -0x58,uVar1,*(int *)(unaff_EBP + -0xa4) + 0x424);
    func_0x005511f0(uVar1);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    iVar4 = unaff_EBP + -0x70;
    if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
      iVar4 = *(int *)(unaff_EBP + -0x70);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar4,0,0,0,3);
    unaff_EDI = *(int **)(unaff_EBP + -0xa8);
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + -0x11,unaff_EBP + -0x11,unaff_EBP + -0x11);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    uVar1 = func_0x0152fd20(unaff_EBP + -0x184);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    func_0x0054eff0(&UNK_018c84a4);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    func_0x005d15d0(unaff_EBP + -0x88,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    func_0x005d15d0(unaff_EBP + -0xa0,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x005d15d0(unaff_EBP + -0x108,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x44;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x124,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x45;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x46;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x47;
    func_0x005d15d0(unaff_EBP + -0xf0);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c87a0);
    *(undefined *)(unaff_EBP + -4) = 0x48;
    func_0x005d15d0(unaff_EBP + -0xf0,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x49;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x4a;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x4b;
    func_0x00879580(unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x58,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0(&UNK_018c87a8);
    *(undefined *)(unaff_EBP + -4) = 0x4c;
    func_0x008783f0(unaff_EBP + -0x58,1,0);
    func_0x005507b0();
  }
  func_0x005507b0();
  return &UNK_005e7e50;
}



// referenced at 0x005e7d9c, inferred function entry 005e7a09

undefined * FUN_005e7a09(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0054eff0(&UNK_018c8754);
  *(undefined *)(unaff_EBP + -4) = 0x39;
  func_0x01520d20(unaff_EBP + -0x88);
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x35;
  func_0x0151f7f0();
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    func_0x0098c2c0(3,unaff_EBP + -0x70);
  }
  if (DAT_01d59a70 != '\0') {
    uVar1 = func_0x0054eff0(&UNK_018c8774);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xa8) + 4))();
    uVar3 = func_0x0054eff0(&UNK_018c877c);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    uVar2 = func_0x00558c80(unaff_EBP + -0x108,uVar3,uVar2);
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    uVar1 = func_0x00558ba0(unaff_EBP + -0xf0,uVar2,uVar1);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    uVar1 = func_0x00558c20(unaff_EBP + -0x58,uVar1,*(int *)(unaff_EBP + -0xa4) + 0x424);
    func_0x005511f0(uVar1);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    iVar4 = unaff_EBP + -0x70;
    if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
      iVar4 = *(int *)(unaff_EBP + -0x70);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar4,0,0,0,3);
    unaff_EDI = *(int **)(unaff_EBP + -0xa8);
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + -0x11,unaff_EBP + -0x11,unaff_EBP + -0x11);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    uVar1 = func_0x0152fd20(unaff_EBP + -0x184);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    func_0x0054eff0(&UNK_018c84a4);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    func_0x005d15d0(unaff_EBP + -0x88,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    func_0x005d15d0(unaff_EBP + -0xa0,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x005d15d0(unaff_EBP + -0x108,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x44;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x124,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x45;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x46;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x47;
    func_0x005d15d0(unaff_EBP + -0xf0);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c87a0);
    *(undefined *)(unaff_EBP + -4) = 0x48;
    func_0x005d15d0(unaff_EBP + -0xf0,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x49;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x4a;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x4b;
    func_0x00879580(unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x58,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0(&UNK_018c87a8);
    *(undefined *)(unaff_EBP + -4) = 0x4c;
    func_0x008783f0(unaff_EBP + -0x58,1,0);
    func_0x005507b0();
  }
  func_0x005507b0();
  return &UNK_005e7e50;
}



// referenced at 0x005e7e19, inferred function entry 005e7a09

undefined * FUN_005e7a09(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0054eff0(&UNK_018c8754);
  *(undefined *)(unaff_EBP + -4) = 0x39;
  func_0x01520d20(unaff_EBP + -0x88);
  func_0x005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x35;
  func_0x0151f7f0();
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    func_0x0098c2c0(3,unaff_EBP + -0x70);
  }
  if (DAT_01d59a70 != '\0') {
    uVar1 = func_0x0054eff0(&UNK_018c8774);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xa8) + 4))();
    uVar3 = func_0x0054eff0(&UNK_018c877c);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    uVar2 = func_0x00558c80(unaff_EBP + -0x108,uVar3,uVar2);
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    uVar1 = func_0x00558ba0(unaff_EBP + -0xf0,uVar2,uVar1);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    uVar1 = func_0x00558c20(unaff_EBP + -0x58,uVar1,*(int *)(unaff_EBP + -0xa4) + 0x424);
    func_0x005511f0(uVar1);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    iVar4 = unaff_EBP + -0x70;
    if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
      iVar4 = *(int *)(unaff_EBP + -0x70);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar4,0,0,0,3);
    unaff_EDI = *(int **)(unaff_EBP + -0xa8);
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + -0x11,unaff_EBP + -0x11,unaff_EBP + -0x11);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    uVar1 = func_0x0152fd20(unaff_EBP + -0x184);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    func_0x0054eff0(&UNK_018c84a4);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    func_0x005d15d0(unaff_EBP + -0x88,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    func_0x005d15d0(unaff_EBP + -0xa0,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x005d15d0(unaff_EBP + -0x108,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x44;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x124,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x45;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x46;
    func_0x005d15d0(unaff_EBP + -0x108,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x47;
    func_0x005d15d0(unaff_EBP + -0xf0);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c87a0);
    *(undefined *)(unaff_EBP + -4) = 0x48;
    func_0x005d15d0(unaff_EBP + -0xf0,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x49;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x4a;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x4b;
    func_0x00879580(unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x58,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0(&UNK_018c87a8);
    *(undefined *)(unaff_EBP + -4) = 0x4c;
    func_0x008783f0(unaff_EBP + -0x58,1,0);
    func_0x005507b0();
  }
  func_0x005507b0();
  return &UNK_005e7e50;
}



// referenced at 0x005e7eb4, inferred function entry 005e7eb4

undefined4 FUN_005e7eb4(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4);
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    uVar1 = func_0x0152fd20();
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    func_0x0054eff0();
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x005d15d0(unaff_EBP + -0x58,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    func_0x005d15d0(unaff_EBP + -0x58,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x15c,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x22;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x23;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x24;
    func_0x005d15d0(unaff_EBP + -0x58);
    func_0x005542c0(&UNK_018c85d8,0x17);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c85f0);
    *(undefined *)(unaff_EBP + -4) = 0x25;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x28;
    func_0x00879580(unaff_EBP + -0x58,unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    func_0x0056cfd0();
  }
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    if (*(char *)(unaff_EBP + 8) == '\0') {
      func_0x0054eff0();
      *(undefined *)(unaff_EBP + -4) = 0x2a;
    }
    else {
      func_0x0054eff0();
      *(undefined *)(unaff_EBP + -4) = 0x29;
    }
    func_0x0098c2c0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    func_0x005507b0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x008783f0();
    func_0x005507b0();
  }
  func_0x005507b0();
  return 0x5e6a0c;
}



// referenced at 0x005e80e3, inferred function entry 005e7eb4

undefined4 FUN_005e7eb4(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4);
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    uVar1 = func_0x0152fd20();
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    func_0x0054eff0();
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x005d15d0(unaff_EBP + -0x58,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    func_0x005d15d0(unaff_EBP + -0x58,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x15c,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x22;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x23;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x24;
    func_0x005d15d0(unaff_EBP + -0x58);
    func_0x005542c0(&UNK_018c85d8,0x17);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c85f0);
    *(undefined *)(unaff_EBP + -4) = 0x25;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x28;
    func_0x00879580(unaff_EBP + -0x58,unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    func_0x0056cfd0();
  }
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    if (*(char *)(unaff_EBP + 8) == '\0') {
      func_0x0054eff0();
      *(undefined *)(unaff_EBP + -4) = 0x2a;
    }
    else {
      func_0x0054eff0();
      *(undefined *)(unaff_EBP + -4) = 0x29;
    }
    func_0x0098c2c0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    func_0x005507b0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x008783f0();
    func_0x005507b0();
  }
  func_0x005507b0();
  return 0x5e6a0c;
}



// referenced at 0x005e81a4, inferred function entry 005e7eb4

undefined4 FUN_005e7eb4(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  int *unaff_EDI;
  
  func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4);
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    uVar1 = func_0x0152fd20();
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    func_0x0054eff0();
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84ac);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x005d15d0(unaff_EBP + -0x58,&DAT_01d79c80);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c84c0);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    func_0x005d15d0(unaff_EBP + -0x58,&DAT_01d79c68);
    func_0x00551230();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = func_0x009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    func_0x0054eff0(&UNK_018c84e8);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = func_0x01675640(unaff_EBP + -0x15c,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                            *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x22;
    func_0x0054eff0(&UNK_018c84f4);
    *(undefined *)(unaff_EBP + -4) = 0x23;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85d0);
    *(undefined *)(unaff_EBP + -4) = 0x24;
    func_0x005d15d0(unaff_EBP + -0x58);
    func_0x005542c0(&UNK_018c85d8,0x17);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    uVar1 = (**(code **)(*unaff_EDI + 4))();
    func_0x0054eff0(&UNK_018c85f0);
    *(undefined *)(unaff_EBP + -4) = 0x25;
    func_0x005d15d0(unaff_EBP + -0x58,uVar1);
    func_0x00551260();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    func_0x005507b0();
    func_0x0054eff0(&UNK_018c85fc);
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x0054eff0(&UNK_018c850c);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0054eff0(&UNK_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x28;
    func_0x00879580(unaff_EBP + -0x58,unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x2c);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    func_0x0056cfd0();
  }
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    if (*(char *)(unaff_EBP + 8) == '\0') {
      func_0x0054eff0();
      *(undefined *)(unaff_EBP + -4) = 0x2a;
    }
    else {
      func_0x0054eff0();
      *(undefined *)(unaff_EBP + -4) = 0x29;
    }
    func_0x0098c2c0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    func_0x005507b0();
  }
  if (DAT_01d59a78 != '\0') {
    func_0x0054eff0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x008783f0();
    func_0x005507b0();
  }
  func_0x005507b0();
  return 0x5e6a0c;
}



// referenced at 0x005e82ab, inferred function entry 005e82ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_005e82ab(void)

{
  int *piVar1;
  undefined8 uVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  code *pcVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined *puVar16;
  int *piVar17;
  undefined4 uVar18;
  int iVar19;
  uint uVar20;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar21;
  
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x9c,1,0);
  uVar3 = *(uint *)(unaff_EBP + -0x88);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x9c);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (uVar20 < 0x1000) {
LAB_005e8327:
      func_0x01674ea0(iVar19,uVar20);
      goto LAB_005e8331;
    }
    iVar19 = *(int *)(iVar15 + -4);
    uVar20 = uVar3 + 0x24;
    if ((iVar15 - iVar19) - 4U < 0x20) goto LAB_005e8327;
    func_0x017167a3();
LAB_005e9a6a:
    func_0x017167a3();
LAB_005e9a6f:
    func_0x017167a3();
LAB_005e9a74:
    func_0x017167a3();
LAB_005e9a79:
    func_0x017167a3();
LAB_005e9a7e:
    uVar18 = func_0x0056acb0();
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x00564940(uVar18);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
  }
LAB_005e8331:
  if ((unaff_EDI != 0) && (*(char *)(unaff_EBP + 0xc) != '\0')) {
    cVar10 = func_0x00a161b0(*(undefined4 *)(unaff_EBP + -0x48));
    if (cVar10 != '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c83b8,0x58);
      *(undefined4 *)(unaff_EBP + -4) = 1;
      func_0x0098c2c0(3,unaff_EBP + -0x9c);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c8414,0x2c);
      *(undefined4 *)(unaff_EBP + -4) = 2;
      func_0x008783f0(unaff_EBP + -0x9c,1,0);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 0;
    }
    if ((*(char *)(unaff_EBP + 0xc) != '\0') &&
       (cVar10 = func_0x00a16240(*(undefined4 *)(unaff_EBP + -0x48)), cVar10 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
  }
  piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
  func_0x00a19ae0(*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17,
                  *(undefined4 *)(unaff_EBP + -0x48));
  *(undefined4 *)(unaff_EBP + -0x114) = 0;
  *(undefined4 *)(unaff_EBP + -0x110) = 0xf;
  *(undefined *)(unaff_EBP + -0x124) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0;
  *(undefined4 *)(unaff_EBP + -0xd8) = 0xf;
  *(undefined *)(unaff_EBP + -0xec) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x00a24b20(unaff_EBP + -0x124);
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  puVar12 = (undefined4 *)
            func_0x01531190(unaff_EBP + -0x28,iVar15,*(undefined4 *)(unaff_EBP + -0x114));
  if ((undefined4 *)(unaff_EBP + -0xec) != puVar12) {
    func_0x005507b0();
    uVar18 = puVar12[1];
    uVar7 = puVar12[2];
    uVar8 = puVar12[3];
    *(undefined4 *)(unaff_EBP + -0xec) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xe8) = uVar18;
    *(undefined4 *)(unaff_EBP + -0xe4) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xe0) = uVar8;
    *(undefined8 *)(unaff_EBP + -0xdc) = *(undefined8 *)(puVar12 + 4);
    puVar12[4] = 0;
    puVar12[5] = 0xf;
    *(undefined *)puVar12 = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x28);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6a;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  func_0x005c39d0(iVar15,*(undefined4 *)(unaff_EBP + -0x114),unaff_EBP + -0x9c,
                  *(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x124);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x120);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x11c);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x118);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x114);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x114) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x124) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x120) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x11c) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x118) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6f;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  if (DAT_01ea937d != '\0') {
    puVar13 = &UNK_018c8468;
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      puVar13 = &UNK_018c8474;
    }
    func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar13,puVar16,iVar15);
  }
  if (DAT_01d64710 != '\0') {
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(unaff_EBP + -0xd0) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xcc) = 0;
    *(undefined4 *)(unaff_EBP + -200) = 0x3f800000;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    puVar12 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 7;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 8;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 9;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x40);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 10;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84d4,0x13);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != (undefined4 *)(unaff_EBP + -0x40)) {
      func_0x005507b0();
      uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
      uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
      uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
      uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined4 *)(iVar15 + 0x18) = uVar18;
      *(undefined4 *)(iVar15 + 0x1c) = uVar7;
      *(undefined4 *)(iVar15 + 0x20) = uVar8;
      *(undefined4 *)(iVar15 + 0x24) = uVar9;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(unaff_EBP + -0x30);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x28,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x28,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0xf;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x10;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c87cc,0x15);
    *(undefined *)(unaff_EBP + -4) = 0x11;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x13;
    func_0x00879580(unaff_EBP + -100,unaff_EBP + -0x40,unaff_EBP + -0xbc,unaff_EBP + -0xd4);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 5;
    func_0x0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    cVar10 = DAT_01ea937e;
    iVar15 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
    }
    puVar13 = &DAT_01d79c68;
    if (0xf < _DAT_01d79c7c) {
      puVar13 = _DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    *(undefined *)(unaff_EBP + -4) = 0x14;
    func_0x01677520(cVar10,&UNK_018c87e8,puVar16,puVar13,*(undefined *)(unaff_EBP + 0xc),iVar15,
                    *(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + 0x14));
    uVar3 = *(uint *)(unaff_EBP + -0x2c);
    *(undefined *)(unaff_EBP + -4) = 5;
    if (0xf < uVar3) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
      uVar20 = uVar3 + 1;
      iVar19 = iVar15;
      if (0xfff < uVar20) {
        iVar19 = *(int *)(iVar15 + -4);
        uVar20 = uVar3 + 0x24;
        if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a74;
      }
      func_0x01674ea0(iVar19,uVar20);
    }
  }
  iVar15 = _DAT_01d658cc;
  if ((_DAT_01d658cc < 1) || (*(undefined *)(unaff_EBP + -0x41) = 1, _DAT_01d658f8 < iVar15)) {
    *(undefined *)(unaff_EBP + -0x41) = 0;
  }
  puVar13 = (undefined *)func_0x01674e20(0x18);
  *(undefined **)(unaff_EBP + -0x10) = puVar13;
  if (puVar13 == (undefined *)0x0) {
    puVar13 = (undefined *)0x0;
  }
  else {
    *puVar13 = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(puVar13 + 4) = *puVar12;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x10c) = 0;
  *(undefined4 *)(unaff_EBP + -0x108) = 0;
  func_0x005c1af0(puVar13,*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -4) = 0x15;
  *(bool *)(unaff_EBP + -0x49) = *(char *)(unaff_EBP + 0xc) == '\0';
  func_0x005c4c00(0x1d59a08,unaff_EBP + -0x49);
  func_0x005e52b0();
  func_0x005c4c00(0x1d59a38,unaff_EBP + -0x9c);
  func_0x005c16d0();
  func_0x005c4c00(0x1d59a50,unaff_EBP + -0xec);
  func_0x005c16d0();
  *(undefined4 *)(unaff_EBP + -0x14c) = 0;
  *(undefined4 *)(unaff_EBP + -0x148) = 0xf;
  *(undefined *)(unaff_EBP + -0x15c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x16;
  func_0x005e4d60(unaff_EBP + -0x10c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  func_0x0098fc00(unaff_EBP + -0x22c,unaff_EBP + -0x15c,1);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  if (*(int *)(unaff_EBP + -0x228) != 0) {
    (**(code **)(*(int *)(unaff_EBP + -0x228) + 8))(unaff_EBP + -0x224);
  }
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x98);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x94);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x90);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x8c);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x8c) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x9c) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x98) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x94) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x90) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a79;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  uVar11 = DAT_01d65a38;
  bVar21 = *(char *)(unaff_EBP + -0x41) == '\0';
  *(undefined4 *)(unaff_EBP + -300) = 0;
  if (!bVar21) {
    uVar11 = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x128) = 0xf;
  *(undefined *)(unaff_EBP + -0x10) = uVar11;
  *(undefined *)(unaff_EBP + -0x13c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (bVar21) {
    piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
    puVar12 = (undefined4 *)
              func_0x00a27b10(unaff_EBP + -0x84,*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      puVar14 = puVar12 + 4;
      if (0xf < (uint)puVar12[5]) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x005542c0(puVar12,*puVar14);
    }
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0xf;
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c8870,0x1b);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c888c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c71bc,4);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x0151bcc0(unaff_EBP + -0x1d4,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40,
                    unaff_EBP + -0xd4,unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    puVar12 = (undefined4 *)func_0x0151bb70(unaff_EBP + -0x84);
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x13c) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x138) = uVar18;
      *(undefined4 *)(unaff_EBP + -0x134) = uVar7;
      *(undefined4 *)(unaff_EBP + -0x130) = uVar8;
      *(undefined8 *)(unaff_EBP + -300) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    func_0x0056d9d0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  func_0x005507b0();
  func_0x014c9d60(unaff_EBP + -0x6c,0);
  iVar15 = unaff_EBP + -0x13c;
  if (0xf < *(uint *)(unaff_EBP + -0x128)) {
    iVar15 = *(int *)(unaff_EBP + -0x13c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x014cbbc0(iVar15,*(undefined4 *)(unaff_EBP + -300));
  *(undefined4 *)(*(int *)(unaff_EBP + -0x6c) + 0xb0) = 0;
  puVar13 = &DAT_01d79f98;
  if (0xf < _DAT_01d79fac) {
    puVar13 = _DAT_01d79f98;
  }
  puVar16 = &DAT_01d79d70;
  if (0xf < _DAT_01d79d84) {
    puVar16 = _DAT_01d79d70;
  }
  func_0x014cb8a0(puVar16,_DAT_01d79d80,puVar13,_DAT_01d79fa8);
  puVar12 = (undefined4 *)
            func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                            *(undefined4 *)(unaff_EBP + 0x14));
  uVar18 = puVar12[4];
  uVar3 = puVar12[5];
  *(undefined *)(unaff_EBP + -4) = 0x22;
  if (0xf < uVar3) {
    puVar12 = (undefined4 *)*puVar12;
  }
  puVar13 = &DAT_01d79ef0;
  if (0xf < _DAT_01d79f04) {
    puVar13 = _DAT_01d79ef0;
  }
  func_0x014cb8a0(puVar13,_DAT_01d79f00,puVar12,uVar18);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005507b0();
  func_0x014cba10(&UNK_018c88a0,3);
  func_0x014cb780(unaff_EBP + -0x15c,*(undefined4 *)(unaff_EBP + -0x10));
  if (DAT_01d64710 == '\0') {
    iVar15 = *(int *)(unaff_EBP + -0xa0);
  }
  else {
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    uVar18 = puVar12[4];
    uVar3 = puVar12[5];
    *(undefined *)(unaff_EBP + -4) = 0x23;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86ac,0x12,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
    iVar15 = *(int *)(unaff_EBP + -0xa0);
    puVar12 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x84,iVar15);
    uVar3 = puVar12[5];
    uVar18 = puVar12[4];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86c0,0x14,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
  }
  func_0x014cb340(unaff_EBP + -0x144);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  if (*(int **)(unaff_EBP + -0x144) == (int *)0x0) goto LAB_005e9a7e;
  piVar17 = (int *)(**(code **)(**(int **)(unaff_EBP + -0x144) + 0x14))();
  *(undefined4 *)(unaff_EBP + -0xf4) = 0;
  *(int **)(unaff_EBP + -0x10) = piVar17;
  *(undefined4 *)(unaff_EBP + -0xf0) = 0xf;
  *(undefined *)(unaff_EBP + -0x104) = 0;
  iVar19 = *piVar17;
  *(undefined *)(unaff_EBP + -4) = 0x27;
  if (*(int *)(iVar19 + 0x70) == 0) {
    iVar4 = *(int *)(iVar19 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar17 = (int *)(iVar19 + 0x10);
      if (0xf < *(uint *)(iVar19 + 0x24)) {
        piVar17 = (int *)*piVar17;
      }
      uVar18 = func_0x01675640(unaff_EBP + -0x84,&UNK_018c8324,iVar4,piVar17);
      func_0x005511f0(uVar18);
      goto LAB_005e9426;
    }
    *(undefined4 *)(unaff_EBP + -0xa4) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x29;
    cVar10 = func_0x0098f070(iVar19 + 0x40,unaff_EBP + -0xa4,0);
    if (cVar10 == '\0') {
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88ec;
    }
    else {
      func_0x00580040(unaff_EBP + -0x10,0x1d599f0);
      if (*(int *)(unaff_EBP + -0x10) != 0) {
        puVar12 = (undefined4 *)func_0x0055d5e0();
        pcVar5 = *(char **)(unaff_EBP + 8);
        *(undefined4 *)(pcVar5 + 4) = *puVar12;
        if (*pcVar5 == '\0') {
          *pcVar5 = '\x01';
        }
        if (iVar15 != 0) {
          func_0x0054eff0(&UNK_018c86d8);
          *(undefined *)(unaff_EBP + -4) = 0x2a;
          func_0x0097c9e0(unaff_EBP + -0x28);
          *(undefined *)(unaff_EBP + -4) = 0x29;
          func_0x005507b0();
          if (DAT_01d64710 != '\0') {
            func_0x005ea7b0();
          }
        }
        func_0x00550b30();
        *(undefined *)(unaff_EBP + 0xb) = 1;
        goto LAB_005e99b2;
      }
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88c0;
    }
    uVar18 = func_0x01675640(unaff_EBP + -0x84,puVar13,uVar18);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x00550b30();
  }
  else {
    puVar12 = (undefined4 *)func_0x01675640(unaff_EBP + -0x84,&UNK_018c88a4,*(int *)(iVar19 + 0x70))
    ;
    if ((undefined4 *)(unaff_EBP + -0x104) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x104) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x100) = uVar18;
      *(undefined4 *)(unaff_EBP + -0xfc) = uVar7;
      *(undefined4 *)(unaff_EBP + -0xf8) = uVar8;
      uVar2 = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined8 *)(unaff_EBP + -0xf4) = uVar2;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    if (*(int *)(**(int **)(unaff_EBP + -0x10) + 0x84) != 0) {
      puVar12 = (undefined4 *)
                func_0x00558df0(unaff_EBP + -0x84,&UNK_018bcaac,**(int **)(unaff_EBP + -0x10) + 0x74
                               );
      uVar3 = puVar12[5];
      uVar18 = puVar12[4];
      *(undefined *)(unaff_EBP + -4) = 0x28;
      if (0xf < uVar3) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x00554150(puVar12,uVar18);
      *(undefined *)(unaff_EBP + -4) = 0x27;
LAB_005e9426:
      func_0x005507b0();
    }
  }
  if (iVar15 != 0) {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      func_0x005542c0(&UNK_018c8708,0x15);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
    }
    else {
      func_0x005542c0(&UNK_018c86ec,0x18);
      *(undefined *)(unaff_EBP + -4) = 0x2c;
    }
    uVar18 = func_0x00558c20(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0x104);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x005507b0();
    func_0x0098c2c0(3,unaff_EBP + -0x40);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c8774,6);
    *(undefined *)(unaff_EBP + -4) = 0x2e;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c877c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x2f;
    uVar18 = func_0x00558ba0(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0xbc);
    *(undefined *)(unaff_EBP + -4) = 0x30;
    func_0x00558c20(unaff_EBP + -100,uVar18,unaff_EBP + -0x13c);
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x34;
    func_0x005507b0();
    iVar15 = unaff_EBP + -100;
    if (0xf < *(uint *)(unaff_EBP + -0x50)) {
      iVar15 = *(int *)(unaff_EBP + -100);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar15,0,0,0,3);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + 0xb,unaff_EBP + 0xb,unaff_EBP + 0xb);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    uVar18 = func_0x0152fd20(unaff_EBP + -0x84);
    *(undefined *)(unaff_EBP + -4) = 0x36;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 0x37;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 0x38;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x28);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x39;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x009ee570(unaff_EBP + -0x84,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x01675640(unaff_EBP + -0xbc,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                             *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c85d0,7);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005d15d0(unaff_EBP + -0x28);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a0,5);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 + 0x18 != unaff_EBP + -0x104) {
      iVar15 = unaff_EBP + -0x104;
      if (0xf < *(uint *)(unaff_EBP + -0xf0)) {
        iVar15 = *(int *)(unaff_EBP + -0x104);
      }
      func_0x005542c0(iVar15,*(undefined4 *)(unaff_EBP + -0xf4));
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c85fc,0x1c);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x00879580(unaff_EBP + -0x28,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a8,0x21);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x008783f0(unaff_EBP + -0x28,1,0);
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + 0xb) = 0;
LAB_005e99b2:
  func_0x005507b0();
  func_0x00550ad0();
  piVar17 = *(int **)(unaff_EBP + -0x68);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      iVar15 = piVar17[2] + -1;
      piVar17[2] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  piVar17 = *(int **)(unaff_EBP + -0x108);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      piVar1 = piVar17 + 2;
      iVar15 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar15 == 1) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  uVar11 = *(undefined *)(unaff_EBP + 0xb);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar11;
}



// referenced at 0x005e83ae, inferred function entry 005e82ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_005e82ab(void)

{
  int *piVar1;
  undefined8 uVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  code *pcVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined *puVar16;
  int *piVar17;
  undefined4 uVar18;
  int iVar19;
  uint uVar20;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar21;
  
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x9c,1,0);
  uVar3 = *(uint *)(unaff_EBP + -0x88);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x9c);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (uVar20 < 0x1000) {
LAB_005e8327:
      func_0x01674ea0(iVar19,uVar20);
      goto LAB_005e8331;
    }
    iVar19 = *(int *)(iVar15 + -4);
    uVar20 = uVar3 + 0x24;
    if ((iVar15 - iVar19) - 4U < 0x20) goto LAB_005e8327;
    func_0x017167a3();
LAB_005e9a6a:
    func_0x017167a3();
LAB_005e9a6f:
    func_0x017167a3();
LAB_005e9a74:
    func_0x017167a3();
LAB_005e9a79:
    func_0x017167a3();
LAB_005e9a7e:
    uVar18 = func_0x0056acb0();
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x00564940(uVar18);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
  }
LAB_005e8331:
  if ((unaff_EDI != 0) && (*(char *)(unaff_EBP + 0xc) != '\0')) {
    cVar10 = func_0x00a161b0(*(undefined4 *)(unaff_EBP + -0x48));
    if (cVar10 != '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c83b8,0x58);
      *(undefined4 *)(unaff_EBP + -4) = 1;
      func_0x0098c2c0(3,unaff_EBP + -0x9c);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c8414,0x2c);
      *(undefined4 *)(unaff_EBP + -4) = 2;
      func_0x008783f0(unaff_EBP + -0x9c,1,0);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 0;
    }
    if ((*(char *)(unaff_EBP + 0xc) != '\0') &&
       (cVar10 = func_0x00a16240(*(undefined4 *)(unaff_EBP + -0x48)), cVar10 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
  }
  piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
  func_0x00a19ae0(*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17,
                  *(undefined4 *)(unaff_EBP + -0x48));
  *(undefined4 *)(unaff_EBP + -0x114) = 0;
  *(undefined4 *)(unaff_EBP + -0x110) = 0xf;
  *(undefined *)(unaff_EBP + -0x124) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0;
  *(undefined4 *)(unaff_EBP + -0xd8) = 0xf;
  *(undefined *)(unaff_EBP + -0xec) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x00a24b20(unaff_EBP + -0x124);
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  puVar12 = (undefined4 *)
            func_0x01531190(unaff_EBP + -0x28,iVar15,*(undefined4 *)(unaff_EBP + -0x114));
  if ((undefined4 *)(unaff_EBP + -0xec) != puVar12) {
    func_0x005507b0();
    uVar18 = puVar12[1];
    uVar7 = puVar12[2];
    uVar8 = puVar12[3];
    *(undefined4 *)(unaff_EBP + -0xec) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xe8) = uVar18;
    *(undefined4 *)(unaff_EBP + -0xe4) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xe0) = uVar8;
    *(undefined8 *)(unaff_EBP + -0xdc) = *(undefined8 *)(puVar12 + 4);
    puVar12[4] = 0;
    puVar12[5] = 0xf;
    *(undefined *)puVar12 = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x28);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6a;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  func_0x005c39d0(iVar15,*(undefined4 *)(unaff_EBP + -0x114),unaff_EBP + -0x9c,
                  *(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x124);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x120);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x11c);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x118);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x114);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x114) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x124) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x120) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x11c) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x118) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6f;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  if (DAT_01ea937d != '\0') {
    puVar13 = &UNK_018c8468;
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      puVar13 = &UNK_018c8474;
    }
    func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar13,puVar16,iVar15);
  }
  if (DAT_01d64710 != '\0') {
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(unaff_EBP + -0xd0) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xcc) = 0;
    *(undefined4 *)(unaff_EBP + -200) = 0x3f800000;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    puVar12 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 7;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 8;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 9;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x40);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 10;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84d4,0x13);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != (undefined4 *)(unaff_EBP + -0x40)) {
      func_0x005507b0();
      uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
      uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
      uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
      uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined4 *)(iVar15 + 0x18) = uVar18;
      *(undefined4 *)(iVar15 + 0x1c) = uVar7;
      *(undefined4 *)(iVar15 + 0x20) = uVar8;
      *(undefined4 *)(iVar15 + 0x24) = uVar9;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(unaff_EBP + -0x30);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x28,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x28,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0xf;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x10;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c87cc,0x15);
    *(undefined *)(unaff_EBP + -4) = 0x11;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x13;
    func_0x00879580(unaff_EBP + -100,unaff_EBP + -0x40,unaff_EBP + -0xbc,unaff_EBP + -0xd4);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 5;
    func_0x0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    cVar10 = DAT_01ea937e;
    iVar15 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
    }
    puVar13 = &DAT_01d79c68;
    if (0xf < _DAT_01d79c7c) {
      puVar13 = _DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    *(undefined *)(unaff_EBP + -4) = 0x14;
    func_0x01677520(cVar10,&UNK_018c87e8,puVar16,puVar13,*(undefined *)(unaff_EBP + 0xc),iVar15,
                    *(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + 0x14));
    uVar3 = *(uint *)(unaff_EBP + -0x2c);
    *(undefined *)(unaff_EBP + -4) = 5;
    if (0xf < uVar3) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
      uVar20 = uVar3 + 1;
      iVar19 = iVar15;
      if (0xfff < uVar20) {
        iVar19 = *(int *)(iVar15 + -4);
        uVar20 = uVar3 + 0x24;
        if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a74;
      }
      func_0x01674ea0(iVar19,uVar20);
    }
  }
  iVar15 = _DAT_01d658cc;
  if ((_DAT_01d658cc < 1) || (*(undefined *)(unaff_EBP + -0x41) = 1, _DAT_01d658f8 < iVar15)) {
    *(undefined *)(unaff_EBP + -0x41) = 0;
  }
  puVar13 = (undefined *)func_0x01674e20(0x18);
  *(undefined **)(unaff_EBP + -0x10) = puVar13;
  if (puVar13 == (undefined *)0x0) {
    puVar13 = (undefined *)0x0;
  }
  else {
    *puVar13 = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(puVar13 + 4) = *puVar12;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x10c) = 0;
  *(undefined4 *)(unaff_EBP + -0x108) = 0;
  func_0x005c1af0(puVar13,*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -4) = 0x15;
  *(bool *)(unaff_EBP + -0x49) = *(char *)(unaff_EBP + 0xc) == '\0';
  func_0x005c4c00(0x1d59a08,unaff_EBP + -0x49);
  func_0x005e52b0();
  func_0x005c4c00(0x1d59a38,unaff_EBP + -0x9c);
  func_0x005c16d0();
  func_0x005c4c00(0x1d59a50,unaff_EBP + -0xec);
  func_0x005c16d0();
  *(undefined4 *)(unaff_EBP + -0x14c) = 0;
  *(undefined4 *)(unaff_EBP + -0x148) = 0xf;
  *(undefined *)(unaff_EBP + -0x15c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x16;
  func_0x005e4d60(unaff_EBP + -0x10c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  func_0x0098fc00(unaff_EBP + -0x22c,unaff_EBP + -0x15c,1);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  if (*(int *)(unaff_EBP + -0x228) != 0) {
    (**(code **)(*(int *)(unaff_EBP + -0x228) + 8))(unaff_EBP + -0x224);
  }
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x98);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x94);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x90);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x8c);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x8c) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x9c) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x98) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x94) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x90) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a79;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  uVar11 = DAT_01d65a38;
  bVar21 = *(char *)(unaff_EBP + -0x41) == '\0';
  *(undefined4 *)(unaff_EBP + -300) = 0;
  if (!bVar21) {
    uVar11 = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x128) = 0xf;
  *(undefined *)(unaff_EBP + -0x10) = uVar11;
  *(undefined *)(unaff_EBP + -0x13c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (bVar21) {
    piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
    puVar12 = (undefined4 *)
              func_0x00a27b10(unaff_EBP + -0x84,*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      puVar14 = puVar12 + 4;
      if (0xf < (uint)puVar12[5]) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x005542c0(puVar12,*puVar14);
    }
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0xf;
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c8870,0x1b);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c888c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c71bc,4);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x0151bcc0(unaff_EBP + -0x1d4,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40,
                    unaff_EBP + -0xd4,unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    puVar12 = (undefined4 *)func_0x0151bb70(unaff_EBP + -0x84);
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x13c) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x138) = uVar18;
      *(undefined4 *)(unaff_EBP + -0x134) = uVar7;
      *(undefined4 *)(unaff_EBP + -0x130) = uVar8;
      *(undefined8 *)(unaff_EBP + -300) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    func_0x0056d9d0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  func_0x005507b0();
  func_0x014c9d60(unaff_EBP + -0x6c,0);
  iVar15 = unaff_EBP + -0x13c;
  if (0xf < *(uint *)(unaff_EBP + -0x128)) {
    iVar15 = *(int *)(unaff_EBP + -0x13c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x014cbbc0(iVar15,*(undefined4 *)(unaff_EBP + -300));
  *(undefined4 *)(*(int *)(unaff_EBP + -0x6c) + 0xb0) = 0;
  puVar13 = &DAT_01d79f98;
  if (0xf < _DAT_01d79fac) {
    puVar13 = _DAT_01d79f98;
  }
  puVar16 = &DAT_01d79d70;
  if (0xf < _DAT_01d79d84) {
    puVar16 = _DAT_01d79d70;
  }
  func_0x014cb8a0(puVar16,_DAT_01d79d80,puVar13,_DAT_01d79fa8);
  puVar12 = (undefined4 *)
            func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                            *(undefined4 *)(unaff_EBP + 0x14));
  uVar18 = puVar12[4];
  uVar3 = puVar12[5];
  *(undefined *)(unaff_EBP + -4) = 0x22;
  if (0xf < uVar3) {
    puVar12 = (undefined4 *)*puVar12;
  }
  puVar13 = &DAT_01d79ef0;
  if (0xf < _DAT_01d79f04) {
    puVar13 = _DAT_01d79ef0;
  }
  func_0x014cb8a0(puVar13,_DAT_01d79f00,puVar12,uVar18);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005507b0();
  func_0x014cba10(&UNK_018c88a0,3);
  func_0x014cb780(unaff_EBP + -0x15c,*(undefined4 *)(unaff_EBP + -0x10));
  if (DAT_01d64710 == '\0') {
    iVar15 = *(int *)(unaff_EBP + -0xa0);
  }
  else {
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    uVar18 = puVar12[4];
    uVar3 = puVar12[5];
    *(undefined *)(unaff_EBP + -4) = 0x23;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86ac,0x12,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
    iVar15 = *(int *)(unaff_EBP + -0xa0);
    puVar12 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x84,iVar15);
    uVar3 = puVar12[5];
    uVar18 = puVar12[4];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86c0,0x14,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
  }
  func_0x014cb340(unaff_EBP + -0x144);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  if (*(int **)(unaff_EBP + -0x144) == (int *)0x0) goto LAB_005e9a7e;
  piVar17 = (int *)(**(code **)(**(int **)(unaff_EBP + -0x144) + 0x14))();
  *(undefined4 *)(unaff_EBP + -0xf4) = 0;
  *(int **)(unaff_EBP + -0x10) = piVar17;
  *(undefined4 *)(unaff_EBP + -0xf0) = 0xf;
  *(undefined *)(unaff_EBP + -0x104) = 0;
  iVar19 = *piVar17;
  *(undefined *)(unaff_EBP + -4) = 0x27;
  if (*(int *)(iVar19 + 0x70) == 0) {
    iVar4 = *(int *)(iVar19 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar17 = (int *)(iVar19 + 0x10);
      if (0xf < *(uint *)(iVar19 + 0x24)) {
        piVar17 = (int *)*piVar17;
      }
      uVar18 = func_0x01675640(unaff_EBP + -0x84,&UNK_018c8324,iVar4,piVar17);
      func_0x005511f0(uVar18);
      goto LAB_005e9426;
    }
    *(undefined4 *)(unaff_EBP + -0xa4) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x29;
    cVar10 = func_0x0098f070(iVar19 + 0x40,unaff_EBP + -0xa4,0);
    if (cVar10 == '\0') {
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88ec;
    }
    else {
      func_0x00580040(unaff_EBP + -0x10,0x1d599f0);
      if (*(int *)(unaff_EBP + -0x10) != 0) {
        puVar12 = (undefined4 *)func_0x0055d5e0();
        pcVar5 = *(char **)(unaff_EBP + 8);
        *(undefined4 *)(pcVar5 + 4) = *puVar12;
        if (*pcVar5 == '\0') {
          *pcVar5 = '\x01';
        }
        if (iVar15 != 0) {
          func_0x0054eff0(&UNK_018c86d8);
          *(undefined *)(unaff_EBP + -4) = 0x2a;
          func_0x0097c9e0(unaff_EBP + -0x28);
          *(undefined *)(unaff_EBP + -4) = 0x29;
          func_0x005507b0();
          if (DAT_01d64710 != '\0') {
            func_0x005ea7b0();
          }
        }
        func_0x00550b30();
        *(undefined *)(unaff_EBP + 0xb) = 1;
        goto LAB_005e99b2;
      }
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88c0;
    }
    uVar18 = func_0x01675640(unaff_EBP + -0x84,puVar13,uVar18);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x00550b30();
  }
  else {
    puVar12 = (undefined4 *)func_0x01675640(unaff_EBP + -0x84,&UNK_018c88a4,*(int *)(iVar19 + 0x70))
    ;
    if ((undefined4 *)(unaff_EBP + -0x104) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x104) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x100) = uVar18;
      *(undefined4 *)(unaff_EBP + -0xfc) = uVar7;
      *(undefined4 *)(unaff_EBP + -0xf8) = uVar8;
      uVar2 = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined8 *)(unaff_EBP + -0xf4) = uVar2;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    if (*(int *)(**(int **)(unaff_EBP + -0x10) + 0x84) != 0) {
      puVar12 = (undefined4 *)
                func_0x00558df0(unaff_EBP + -0x84,&UNK_018bcaac,**(int **)(unaff_EBP + -0x10) + 0x74
                               );
      uVar3 = puVar12[5];
      uVar18 = puVar12[4];
      *(undefined *)(unaff_EBP + -4) = 0x28;
      if (0xf < uVar3) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x00554150(puVar12,uVar18);
      *(undefined *)(unaff_EBP + -4) = 0x27;
LAB_005e9426:
      func_0x005507b0();
    }
  }
  if (iVar15 != 0) {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      func_0x005542c0(&UNK_018c8708,0x15);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
    }
    else {
      func_0x005542c0(&UNK_018c86ec,0x18);
      *(undefined *)(unaff_EBP + -4) = 0x2c;
    }
    uVar18 = func_0x00558c20(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0x104);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x005507b0();
    func_0x0098c2c0(3,unaff_EBP + -0x40);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c8774,6);
    *(undefined *)(unaff_EBP + -4) = 0x2e;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c877c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x2f;
    uVar18 = func_0x00558ba0(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0xbc);
    *(undefined *)(unaff_EBP + -4) = 0x30;
    func_0x00558c20(unaff_EBP + -100,uVar18,unaff_EBP + -0x13c);
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x34;
    func_0x005507b0();
    iVar15 = unaff_EBP + -100;
    if (0xf < *(uint *)(unaff_EBP + -0x50)) {
      iVar15 = *(int *)(unaff_EBP + -100);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar15,0,0,0,3);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + 0xb,unaff_EBP + 0xb,unaff_EBP + 0xb);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    uVar18 = func_0x0152fd20(unaff_EBP + -0x84);
    *(undefined *)(unaff_EBP + -4) = 0x36;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 0x37;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 0x38;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x28);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x39;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x009ee570(unaff_EBP + -0x84,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x01675640(unaff_EBP + -0xbc,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                             *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c85d0,7);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005d15d0(unaff_EBP + -0x28);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a0,5);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 + 0x18 != unaff_EBP + -0x104) {
      iVar15 = unaff_EBP + -0x104;
      if (0xf < *(uint *)(unaff_EBP + -0xf0)) {
        iVar15 = *(int *)(unaff_EBP + -0x104);
      }
      func_0x005542c0(iVar15,*(undefined4 *)(unaff_EBP + -0xf4));
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c85fc,0x1c);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x00879580(unaff_EBP + -0x28,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a8,0x21);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x008783f0(unaff_EBP + -0x28,1,0);
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + 0xb) = 0;
LAB_005e99b2:
  func_0x005507b0();
  func_0x00550ad0();
  piVar17 = *(int **)(unaff_EBP + -0x68);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      iVar15 = piVar17[2] + -1;
      piVar17[2] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  piVar17 = *(int **)(unaff_EBP + -0x108);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      piVar1 = piVar17 + 2;
      iVar15 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar15 == 1) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  uVar11 = *(undefined *)(unaff_EBP + 0xb);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar11;
}



// referenced at 0x005e8a6f, inferred function entry 005e82ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_005e82ab(void)

{
  int *piVar1;
  undefined8 uVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  code *pcVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined *puVar16;
  int *piVar17;
  undefined4 uVar18;
  int iVar19;
  uint uVar20;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar21;
  
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x9c,1,0);
  uVar3 = *(uint *)(unaff_EBP + -0x88);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x9c);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (uVar20 < 0x1000) {
LAB_005e8327:
      func_0x01674ea0(iVar19,uVar20);
      goto LAB_005e8331;
    }
    iVar19 = *(int *)(iVar15 + -4);
    uVar20 = uVar3 + 0x24;
    if ((iVar15 - iVar19) - 4U < 0x20) goto LAB_005e8327;
    func_0x017167a3();
LAB_005e9a6a:
    func_0x017167a3();
LAB_005e9a6f:
    func_0x017167a3();
LAB_005e9a74:
    func_0x017167a3();
LAB_005e9a79:
    func_0x017167a3();
LAB_005e9a7e:
    uVar18 = func_0x0056acb0();
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x00564940(uVar18);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
  }
LAB_005e8331:
  if ((unaff_EDI != 0) && (*(char *)(unaff_EBP + 0xc) != '\0')) {
    cVar10 = func_0x00a161b0(*(undefined4 *)(unaff_EBP + -0x48));
    if (cVar10 != '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c83b8,0x58);
      *(undefined4 *)(unaff_EBP + -4) = 1;
      func_0x0098c2c0(3,unaff_EBP + -0x9c);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c8414,0x2c);
      *(undefined4 *)(unaff_EBP + -4) = 2;
      func_0x008783f0(unaff_EBP + -0x9c,1,0);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 0;
    }
    if ((*(char *)(unaff_EBP + 0xc) != '\0') &&
       (cVar10 = func_0x00a16240(*(undefined4 *)(unaff_EBP + -0x48)), cVar10 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
  }
  piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
  func_0x00a19ae0(*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17,
                  *(undefined4 *)(unaff_EBP + -0x48));
  *(undefined4 *)(unaff_EBP + -0x114) = 0;
  *(undefined4 *)(unaff_EBP + -0x110) = 0xf;
  *(undefined *)(unaff_EBP + -0x124) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0;
  *(undefined4 *)(unaff_EBP + -0xd8) = 0xf;
  *(undefined *)(unaff_EBP + -0xec) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x00a24b20(unaff_EBP + -0x124);
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  puVar12 = (undefined4 *)
            func_0x01531190(unaff_EBP + -0x28,iVar15,*(undefined4 *)(unaff_EBP + -0x114));
  if ((undefined4 *)(unaff_EBP + -0xec) != puVar12) {
    func_0x005507b0();
    uVar18 = puVar12[1];
    uVar7 = puVar12[2];
    uVar8 = puVar12[3];
    *(undefined4 *)(unaff_EBP + -0xec) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xe8) = uVar18;
    *(undefined4 *)(unaff_EBP + -0xe4) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xe0) = uVar8;
    *(undefined8 *)(unaff_EBP + -0xdc) = *(undefined8 *)(puVar12 + 4);
    puVar12[4] = 0;
    puVar12[5] = 0xf;
    *(undefined *)puVar12 = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x28);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6a;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  func_0x005c39d0(iVar15,*(undefined4 *)(unaff_EBP + -0x114),unaff_EBP + -0x9c,
                  *(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x124);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x120);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x11c);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x118);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x114);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x114) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x124) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x120) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x11c) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x118) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6f;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  if (DAT_01ea937d != '\0') {
    puVar13 = &UNK_018c8468;
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      puVar13 = &UNK_018c8474;
    }
    func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar13,puVar16,iVar15);
  }
  if (DAT_01d64710 != '\0') {
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(unaff_EBP + -0xd0) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xcc) = 0;
    *(undefined4 *)(unaff_EBP + -200) = 0x3f800000;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    puVar12 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 7;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 8;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 9;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x40);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 10;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84d4,0x13);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != (undefined4 *)(unaff_EBP + -0x40)) {
      func_0x005507b0();
      uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
      uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
      uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
      uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined4 *)(iVar15 + 0x18) = uVar18;
      *(undefined4 *)(iVar15 + 0x1c) = uVar7;
      *(undefined4 *)(iVar15 + 0x20) = uVar8;
      *(undefined4 *)(iVar15 + 0x24) = uVar9;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(unaff_EBP + -0x30);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x28,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x28,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0xf;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x10;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c87cc,0x15);
    *(undefined *)(unaff_EBP + -4) = 0x11;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x13;
    func_0x00879580(unaff_EBP + -100,unaff_EBP + -0x40,unaff_EBP + -0xbc,unaff_EBP + -0xd4);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 5;
    func_0x0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    cVar10 = DAT_01ea937e;
    iVar15 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
    }
    puVar13 = &DAT_01d79c68;
    if (0xf < _DAT_01d79c7c) {
      puVar13 = _DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    *(undefined *)(unaff_EBP + -4) = 0x14;
    func_0x01677520(cVar10,&UNK_018c87e8,puVar16,puVar13,*(undefined *)(unaff_EBP + 0xc),iVar15,
                    *(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + 0x14));
    uVar3 = *(uint *)(unaff_EBP + -0x2c);
    *(undefined *)(unaff_EBP + -4) = 5;
    if (0xf < uVar3) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
      uVar20 = uVar3 + 1;
      iVar19 = iVar15;
      if (0xfff < uVar20) {
        iVar19 = *(int *)(iVar15 + -4);
        uVar20 = uVar3 + 0x24;
        if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a74;
      }
      func_0x01674ea0(iVar19,uVar20);
    }
  }
  iVar15 = _DAT_01d658cc;
  if ((_DAT_01d658cc < 1) || (*(undefined *)(unaff_EBP + -0x41) = 1, _DAT_01d658f8 < iVar15)) {
    *(undefined *)(unaff_EBP + -0x41) = 0;
  }
  puVar13 = (undefined *)func_0x01674e20(0x18);
  *(undefined **)(unaff_EBP + -0x10) = puVar13;
  if (puVar13 == (undefined *)0x0) {
    puVar13 = (undefined *)0x0;
  }
  else {
    *puVar13 = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(puVar13 + 4) = *puVar12;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x10c) = 0;
  *(undefined4 *)(unaff_EBP + -0x108) = 0;
  func_0x005c1af0(puVar13,*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -4) = 0x15;
  *(bool *)(unaff_EBP + -0x49) = *(char *)(unaff_EBP + 0xc) == '\0';
  func_0x005c4c00(0x1d59a08,unaff_EBP + -0x49);
  func_0x005e52b0();
  func_0x005c4c00(0x1d59a38,unaff_EBP + -0x9c);
  func_0x005c16d0();
  func_0x005c4c00(0x1d59a50,unaff_EBP + -0xec);
  func_0x005c16d0();
  *(undefined4 *)(unaff_EBP + -0x14c) = 0;
  *(undefined4 *)(unaff_EBP + -0x148) = 0xf;
  *(undefined *)(unaff_EBP + -0x15c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x16;
  func_0x005e4d60(unaff_EBP + -0x10c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  func_0x0098fc00(unaff_EBP + -0x22c,unaff_EBP + -0x15c,1);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  if (*(int *)(unaff_EBP + -0x228) != 0) {
    (**(code **)(*(int *)(unaff_EBP + -0x228) + 8))(unaff_EBP + -0x224);
  }
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x98);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x94);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x90);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x8c);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x8c) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x9c) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x98) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x94) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x90) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a79;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  uVar11 = DAT_01d65a38;
  bVar21 = *(char *)(unaff_EBP + -0x41) == '\0';
  *(undefined4 *)(unaff_EBP + -300) = 0;
  if (!bVar21) {
    uVar11 = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x128) = 0xf;
  *(undefined *)(unaff_EBP + -0x10) = uVar11;
  *(undefined *)(unaff_EBP + -0x13c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (bVar21) {
    piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
    puVar12 = (undefined4 *)
              func_0x00a27b10(unaff_EBP + -0x84,*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      puVar14 = puVar12 + 4;
      if (0xf < (uint)puVar12[5]) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x005542c0(puVar12,*puVar14);
    }
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0xf;
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c8870,0x1b);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c888c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c71bc,4);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x0151bcc0(unaff_EBP + -0x1d4,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40,
                    unaff_EBP + -0xd4,unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    puVar12 = (undefined4 *)func_0x0151bb70(unaff_EBP + -0x84);
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x13c) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x138) = uVar18;
      *(undefined4 *)(unaff_EBP + -0x134) = uVar7;
      *(undefined4 *)(unaff_EBP + -0x130) = uVar8;
      *(undefined8 *)(unaff_EBP + -300) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    func_0x0056d9d0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  func_0x005507b0();
  func_0x014c9d60(unaff_EBP + -0x6c,0);
  iVar15 = unaff_EBP + -0x13c;
  if (0xf < *(uint *)(unaff_EBP + -0x128)) {
    iVar15 = *(int *)(unaff_EBP + -0x13c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x014cbbc0(iVar15,*(undefined4 *)(unaff_EBP + -300));
  *(undefined4 *)(*(int *)(unaff_EBP + -0x6c) + 0xb0) = 0;
  puVar13 = &DAT_01d79f98;
  if (0xf < _DAT_01d79fac) {
    puVar13 = _DAT_01d79f98;
  }
  puVar16 = &DAT_01d79d70;
  if (0xf < _DAT_01d79d84) {
    puVar16 = _DAT_01d79d70;
  }
  func_0x014cb8a0(puVar16,_DAT_01d79d80,puVar13,_DAT_01d79fa8);
  puVar12 = (undefined4 *)
            func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                            *(undefined4 *)(unaff_EBP + 0x14));
  uVar18 = puVar12[4];
  uVar3 = puVar12[5];
  *(undefined *)(unaff_EBP + -4) = 0x22;
  if (0xf < uVar3) {
    puVar12 = (undefined4 *)*puVar12;
  }
  puVar13 = &DAT_01d79ef0;
  if (0xf < _DAT_01d79f04) {
    puVar13 = _DAT_01d79ef0;
  }
  func_0x014cb8a0(puVar13,_DAT_01d79f00,puVar12,uVar18);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005507b0();
  func_0x014cba10(&UNK_018c88a0,3);
  func_0x014cb780(unaff_EBP + -0x15c,*(undefined4 *)(unaff_EBP + -0x10));
  if (DAT_01d64710 == '\0') {
    iVar15 = *(int *)(unaff_EBP + -0xa0);
  }
  else {
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    uVar18 = puVar12[4];
    uVar3 = puVar12[5];
    *(undefined *)(unaff_EBP + -4) = 0x23;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86ac,0x12,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
    iVar15 = *(int *)(unaff_EBP + -0xa0);
    puVar12 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x84,iVar15);
    uVar3 = puVar12[5];
    uVar18 = puVar12[4];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86c0,0x14,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
  }
  func_0x014cb340(unaff_EBP + -0x144);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  if (*(int **)(unaff_EBP + -0x144) == (int *)0x0) goto LAB_005e9a7e;
  piVar17 = (int *)(**(code **)(**(int **)(unaff_EBP + -0x144) + 0x14))();
  *(undefined4 *)(unaff_EBP + -0xf4) = 0;
  *(int **)(unaff_EBP + -0x10) = piVar17;
  *(undefined4 *)(unaff_EBP + -0xf0) = 0xf;
  *(undefined *)(unaff_EBP + -0x104) = 0;
  iVar19 = *piVar17;
  *(undefined *)(unaff_EBP + -4) = 0x27;
  if (*(int *)(iVar19 + 0x70) == 0) {
    iVar4 = *(int *)(iVar19 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar17 = (int *)(iVar19 + 0x10);
      if (0xf < *(uint *)(iVar19 + 0x24)) {
        piVar17 = (int *)*piVar17;
      }
      uVar18 = func_0x01675640(unaff_EBP + -0x84,&UNK_018c8324,iVar4,piVar17);
      func_0x005511f0(uVar18);
      goto LAB_005e9426;
    }
    *(undefined4 *)(unaff_EBP + -0xa4) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x29;
    cVar10 = func_0x0098f070(iVar19 + 0x40,unaff_EBP + -0xa4,0);
    if (cVar10 == '\0') {
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88ec;
    }
    else {
      func_0x00580040(unaff_EBP + -0x10,0x1d599f0);
      if (*(int *)(unaff_EBP + -0x10) != 0) {
        puVar12 = (undefined4 *)func_0x0055d5e0();
        pcVar5 = *(char **)(unaff_EBP + 8);
        *(undefined4 *)(pcVar5 + 4) = *puVar12;
        if (*pcVar5 == '\0') {
          *pcVar5 = '\x01';
        }
        if (iVar15 != 0) {
          func_0x0054eff0(&UNK_018c86d8);
          *(undefined *)(unaff_EBP + -4) = 0x2a;
          func_0x0097c9e0(unaff_EBP + -0x28);
          *(undefined *)(unaff_EBP + -4) = 0x29;
          func_0x005507b0();
          if (DAT_01d64710 != '\0') {
            func_0x005ea7b0();
          }
        }
        func_0x00550b30();
        *(undefined *)(unaff_EBP + 0xb) = 1;
        goto LAB_005e99b2;
      }
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88c0;
    }
    uVar18 = func_0x01675640(unaff_EBP + -0x84,puVar13,uVar18);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x00550b30();
  }
  else {
    puVar12 = (undefined4 *)func_0x01675640(unaff_EBP + -0x84,&UNK_018c88a4,*(int *)(iVar19 + 0x70))
    ;
    if ((undefined4 *)(unaff_EBP + -0x104) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x104) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x100) = uVar18;
      *(undefined4 *)(unaff_EBP + -0xfc) = uVar7;
      *(undefined4 *)(unaff_EBP + -0xf8) = uVar8;
      uVar2 = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined8 *)(unaff_EBP + -0xf4) = uVar2;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    if (*(int *)(**(int **)(unaff_EBP + -0x10) + 0x84) != 0) {
      puVar12 = (undefined4 *)
                func_0x00558df0(unaff_EBP + -0x84,&UNK_018bcaac,**(int **)(unaff_EBP + -0x10) + 0x74
                               );
      uVar3 = puVar12[5];
      uVar18 = puVar12[4];
      *(undefined *)(unaff_EBP + -4) = 0x28;
      if (0xf < uVar3) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x00554150(puVar12,uVar18);
      *(undefined *)(unaff_EBP + -4) = 0x27;
LAB_005e9426:
      func_0x005507b0();
    }
  }
  if (iVar15 != 0) {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      func_0x005542c0(&UNK_018c8708,0x15);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
    }
    else {
      func_0x005542c0(&UNK_018c86ec,0x18);
      *(undefined *)(unaff_EBP + -4) = 0x2c;
    }
    uVar18 = func_0x00558c20(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0x104);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x005507b0();
    func_0x0098c2c0(3,unaff_EBP + -0x40);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c8774,6);
    *(undefined *)(unaff_EBP + -4) = 0x2e;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c877c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x2f;
    uVar18 = func_0x00558ba0(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0xbc);
    *(undefined *)(unaff_EBP + -4) = 0x30;
    func_0x00558c20(unaff_EBP + -100,uVar18,unaff_EBP + -0x13c);
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x34;
    func_0x005507b0();
    iVar15 = unaff_EBP + -100;
    if (0xf < *(uint *)(unaff_EBP + -0x50)) {
      iVar15 = *(int *)(unaff_EBP + -100);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar15,0,0,0,3);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + 0xb,unaff_EBP + 0xb,unaff_EBP + 0xb);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    uVar18 = func_0x0152fd20(unaff_EBP + -0x84);
    *(undefined *)(unaff_EBP + -4) = 0x36;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 0x37;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 0x38;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x28);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x39;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x009ee570(unaff_EBP + -0x84,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x01675640(unaff_EBP + -0xbc,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                             *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c85d0,7);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005d15d0(unaff_EBP + -0x28);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a0,5);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 + 0x18 != unaff_EBP + -0x104) {
      iVar15 = unaff_EBP + -0x104;
      if (0xf < *(uint *)(unaff_EBP + -0xf0)) {
        iVar15 = *(int *)(unaff_EBP + -0x104);
      }
      func_0x005542c0(iVar15,*(undefined4 *)(unaff_EBP + -0xf4));
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c85fc,0x1c);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x00879580(unaff_EBP + -0x28,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a8,0x21);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x008783f0(unaff_EBP + -0x28,1,0);
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + 0xb) = 0;
LAB_005e99b2:
  func_0x005507b0();
  func_0x00550ad0();
  piVar17 = *(int **)(unaff_EBP + -0x68);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      iVar15 = piVar17[2] + -1;
      piVar17[2] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  piVar17 = *(int **)(unaff_EBP + -0x108);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      piVar1 = piVar17 + 2;
      iVar15 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar15 == 1) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  uVar11 = *(undefined *)(unaff_EBP + 0xb);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar11;
}



// referenced at 0x005e8b99, inferred function entry 005e82ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_005e82ab(void)

{
  int *piVar1;
  undefined8 uVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  code *pcVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined *puVar16;
  int *piVar17;
  undefined4 uVar18;
  int iVar19;
  uint uVar20;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar21;
  
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x9c,1,0);
  uVar3 = *(uint *)(unaff_EBP + -0x88);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x9c);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (uVar20 < 0x1000) {
LAB_005e8327:
      func_0x01674ea0(iVar19,uVar20);
      goto LAB_005e8331;
    }
    iVar19 = *(int *)(iVar15 + -4);
    uVar20 = uVar3 + 0x24;
    if ((iVar15 - iVar19) - 4U < 0x20) goto LAB_005e8327;
    func_0x017167a3();
LAB_005e9a6a:
    func_0x017167a3();
LAB_005e9a6f:
    func_0x017167a3();
LAB_005e9a74:
    func_0x017167a3();
LAB_005e9a79:
    func_0x017167a3();
LAB_005e9a7e:
    uVar18 = func_0x0056acb0();
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x00564940(uVar18);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
  }
LAB_005e8331:
  if ((unaff_EDI != 0) && (*(char *)(unaff_EBP + 0xc) != '\0')) {
    cVar10 = func_0x00a161b0(*(undefined4 *)(unaff_EBP + -0x48));
    if (cVar10 != '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c83b8,0x58);
      *(undefined4 *)(unaff_EBP + -4) = 1;
      func_0x0098c2c0(3,unaff_EBP + -0x9c);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c8414,0x2c);
      *(undefined4 *)(unaff_EBP + -4) = 2;
      func_0x008783f0(unaff_EBP + -0x9c,1,0);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 0;
    }
    if ((*(char *)(unaff_EBP + 0xc) != '\0') &&
       (cVar10 = func_0x00a16240(*(undefined4 *)(unaff_EBP + -0x48)), cVar10 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
  }
  piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
  func_0x00a19ae0(*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17,
                  *(undefined4 *)(unaff_EBP + -0x48));
  *(undefined4 *)(unaff_EBP + -0x114) = 0;
  *(undefined4 *)(unaff_EBP + -0x110) = 0xf;
  *(undefined *)(unaff_EBP + -0x124) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0;
  *(undefined4 *)(unaff_EBP + -0xd8) = 0xf;
  *(undefined *)(unaff_EBP + -0xec) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x00a24b20(unaff_EBP + -0x124);
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  puVar12 = (undefined4 *)
            func_0x01531190(unaff_EBP + -0x28,iVar15,*(undefined4 *)(unaff_EBP + -0x114));
  if ((undefined4 *)(unaff_EBP + -0xec) != puVar12) {
    func_0x005507b0();
    uVar18 = puVar12[1];
    uVar7 = puVar12[2];
    uVar8 = puVar12[3];
    *(undefined4 *)(unaff_EBP + -0xec) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xe8) = uVar18;
    *(undefined4 *)(unaff_EBP + -0xe4) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xe0) = uVar8;
    *(undefined8 *)(unaff_EBP + -0xdc) = *(undefined8 *)(puVar12 + 4);
    puVar12[4] = 0;
    puVar12[5] = 0xf;
    *(undefined *)puVar12 = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x28);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6a;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  func_0x005c39d0(iVar15,*(undefined4 *)(unaff_EBP + -0x114),unaff_EBP + -0x9c,
                  *(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x124);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x120);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x11c);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x118);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x114);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x114) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x124) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x120) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x11c) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x118) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6f;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  if (DAT_01ea937d != '\0') {
    puVar13 = &UNK_018c8468;
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      puVar13 = &UNK_018c8474;
    }
    func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar13,puVar16,iVar15);
  }
  if (DAT_01d64710 != '\0') {
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(unaff_EBP + -0xd0) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xcc) = 0;
    *(undefined4 *)(unaff_EBP + -200) = 0x3f800000;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    puVar12 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 7;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 8;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 9;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x40);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 10;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84d4,0x13);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != (undefined4 *)(unaff_EBP + -0x40)) {
      func_0x005507b0();
      uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
      uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
      uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
      uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined4 *)(iVar15 + 0x18) = uVar18;
      *(undefined4 *)(iVar15 + 0x1c) = uVar7;
      *(undefined4 *)(iVar15 + 0x20) = uVar8;
      *(undefined4 *)(iVar15 + 0x24) = uVar9;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(unaff_EBP + -0x30);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x28,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x28,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0xf;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x10;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c87cc,0x15);
    *(undefined *)(unaff_EBP + -4) = 0x11;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x13;
    func_0x00879580(unaff_EBP + -100,unaff_EBP + -0x40,unaff_EBP + -0xbc,unaff_EBP + -0xd4);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 5;
    func_0x0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    cVar10 = DAT_01ea937e;
    iVar15 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
    }
    puVar13 = &DAT_01d79c68;
    if (0xf < _DAT_01d79c7c) {
      puVar13 = _DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    *(undefined *)(unaff_EBP + -4) = 0x14;
    func_0x01677520(cVar10,&UNK_018c87e8,puVar16,puVar13,*(undefined *)(unaff_EBP + 0xc),iVar15,
                    *(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + 0x14));
    uVar3 = *(uint *)(unaff_EBP + -0x2c);
    *(undefined *)(unaff_EBP + -4) = 5;
    if (0xf < uVar3) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
      uVar20 = uVar3 + 1;
      iVar19 = iVar15;
      if (0xfff < uVar20) {
        iVar19 = *(int *)(iVar15 + -4);
        uVar20 = uVar3 + 0x24;
        if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a74;
      }
      func_0x01674ea0(iVar19,uVar20);
    }
  }
  iVar15 = _DAT_01d658cc;
  if ((_DAT_01d658cc < 1) || (*(undefined *)(unaff_EBP + -0x41) = 1, _DAT_01d658f8 < iVar15)) {
    *(undefined *)(unaff_EBP + -0x41) = 0;
  }
  puVar13 = (undefined *)func_0x01674e20(0x18);
  *(undefined **)(unaff_EBP + -0x10) = puVar13;
  if (puVar13 == (undefined *)0x0) {
    puVar13 = (undefined *)0x0;
  }
  else {
    *puVar13 = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(puVar13 + 4) = *puVar12;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x10c) = 0;
  *(undefined4 *)(unaff_EBP + -0x108) = 0;
  func_0x005c1af0(puVar13,*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -4) = 0x15;
  *(bool *)(unaff_EBP + -0x49) = *(char *)(unaff_EBP + 0xc) == '\0';
  func_0x005c4c00(0x1d59a08,unaff_EBP + -0x49);
  func_0x005e52b0();
  func_0x005c4c00(0x1d59a38,unaff_EBP + -0x9c);
  func_0x005c16d0();
  func_0x005c4c00(0x1d59a50,unaff_EBP + -0xec);
  func_0x005c16d0();
  *(undefined4 *)(unaff_EBP + -0x14c) = 0;
  *(undefined4 *)(unaff_EBP + -0x148) = 0xf;
  *(undefined *)(unaff_EBP + -0x15c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x16;
  func_0x005e4d60(unaff_EBP + -0x10c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  func_0x0098fc00(unaff_EBP + -0x22c,unaff_EBP + -0x15c,1);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  if (*(int *)(unaff_EBP + -0x228) != 0) {
    (**(code **)(*(int *)(unaff_EBP + -0x228) + 8))(unaff_EBP + -0x224);
  }
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x98);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x94);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x90);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x8c);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x8c) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x9c) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x98) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x94) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x90) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a79;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  uVar11 = DAT_01d65a38;
  bVar21 = *(char *)(unaff_EBP + -0x41) == '\0';
  *(undefined4 *)(unaff_EBP + -300) = 0;
  if (!bVar21) {
    uVar11 = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x128) = 0xf;
  *(undefined *)(unaff_EBP + -0x10) = uVar11;
  *(undefined *)(unaff_EBP + -0x13c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (bVar21) {
    piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
    puVar12 = (undefined4 *)
              func_0x00a27b10(unaff_EBP + -0x84,*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      puVar14 = puVar12 + 4;
      if (0xf < (uint)puVar12[5]) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x005542c0(puVar12,*puVar14);
    }
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0xf;
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c8870,0x1b);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c888c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c71bc,4);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x0151bcc0(unaff_EBP + -0x1d4,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40,
                    unaff_EBP + -0xd4,unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    puVar12 = (undefined4 *)func_0x0151bb70(unaff_EBP + -0x84);
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x13c) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x138) = uVar18;
      *(undefined4 *)(unaff_EBP + -0x134) = uVar7;
      *(undefined4 *)(unaff_EBP + -0x130) = uVar8;
      *(undefined8 *)(unaff_EBP + -300) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    func_0x0056d9d0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  func_0x005507b0();
  func_0x014c9d60(unaff_EBP + -0x6c,0);
  iVar15 = unaff_EBP + -0x13c;
  if (0xf < *(uint *)(unaff_EBP + -0x128)) {
    iVar15 = *(int *)(unaff_EBP + -0x13c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x014cbbc0(iVar15,*(undefined4 *)(unaff_EBP + -300));
  *(undefined4 *)(*(int *)(unaff_EBP + -0x6c) + 0xb0) = 0;
  puVar13 = &DAT_01d79f98;
  if (0xf < _DAT_01d79fac) {
    puVar13 = _DAT_01d79f98;
  }
  puVar16 = &DAT_01d79d70;
  if (0xf < _DAT_01d79d84) {
    puVar16 = _DAT_01d79d70;
  }
  func_0x014cb8a0(puVar16,_DAT_01d79d80,puVar13,_DAT_01d79fa8);
  puVar12 = (undefined4 *)
            func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                            *(undefined4 *)(unaff_EBP + 0x14));
  uVar18 = puVar12[4];
  uVar3 = puVar12[5];
  *(undefined *)(unaff_EBP + -4) = 0x22;
  if (0xf < uVar3) {
    puVar12 = (undefined4 *)*puVar12;
  }
  puVar13 = &DAT_01d79ef0;
  if (0xf < _DAT_01d79f04) {
    puVar13 = _DAT_01d79ef0;
  }
  func_0x014cb8a0(puVar13,_DAT_01d79f00,puVar12,uVar18);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005507b0();
  func_0x014cba10(&UNK_018c88a0,3);
  func_0x014cb780(unaff_EBP + -0x15c,*(undefined4 *)(unaff_EBP + -0x10));
  if (DAT_01d64710 == '\0') {
    iVar15 = *(int *)(unaff_EBP + -0xa0);
  }
  else {
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    uVar18 = puVar12[4];
    uVar3 = puVar12[5];
    *(undefined *)(unaff_EBP + -4) = 0x23;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86ac,0x12,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
    iVar15 = *(int *)(unaff_EBP + -0xa0);
    puVar12 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x84,iVar15);
    uVar3 = puVar12[5];
    uVar18 = puVar12[4];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86c0,0x14,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
  }
  func_0x014cb340(unaff_EBP + -0x144);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  if (*(int **)(unaff_EBP + -0x144) == (int *)0x0) goto LAB_005e9a7e;
  piVar17 = (int *)(**(code **)(**(int **)(unaff_EBP + -0x144) + 0x14))();
  *(undefined4 *)(unaff_EBP + -0xf4) = 0;
  *(int **)(unaff_EBP + -0x10) = piVar17;
  *(undefined4 *)(unaff_EBP + -0xf0) = 0xf;
  *(undefined *)(unaff_EBP + -0x104) = 0;
  iVar19 = *piVar17;
  *(undefined *)(unaff_EBP + -4) = 0x27;
  if (*(int *)(iVar19 + 0x70) == 0) {
    iVar4 = *(int *)(iVar19 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar17 = (int *)(iVar19 + 0x10);
      if (0xf < *(uint *)(iVar19 + 0x24)) {
        piVar17 = (int *)*piVar17;
      }
      uVar18 = func_0x01675640(unaff_EBP + -0x84,&UNK_018c8324,iVar4,piVar17);
      func_0x005511f0(uVar18);
      goto LAB_005e9426;
    }
    *(undefined4 *)(unaff_EBP + -0xa4) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x29;
    cVar10 = func_0x0098f070(iVar19 + 0x40,unaff_EBP + -0xa4,0);
    if (cVar10 == '\0') {
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88ec;
    }
    else {
      func_0x00580040(unaff_EBP + -0x10,0x1d599f0);
      if (*(int *)(unaff_EBP + -0x10) != 0) {
        puVar12 = (undefined4 *)func_0x0055d5e0();
        pcVar5 = *(char **)(unaff_EBP + 8);
        *(undefined4 *)(pcVar5 + 4) = *puVar12;
        if (*pcVar5 == '\0') {
          *pcVar5 = '\x01';
        }
        if (iVar15 != 0) {
          func_0x0054eff0(&UNK_018c86d8);
          *(undefined *)(unaff_EBP + -4) = 0x2a;
          func_0x0097c9e0(unaff_EBP + -0x28);
          *(undefined *)(unaff_EBP + -4) = 0x29;
          func_0x005507b0();
          if (DAT_01d64710 != '\0') {
            func_0x005ea7b0();
          }
        }
        func_0x00550b30();
        *(undefined *)(unaff_EBP + 0xb) = 1;
        goto LAB_005e99b2;
      }
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88c0;
    }
    uVar18 = func_0x01675640(unaff_EBP + -0x84,puVar13,uVar18);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x00550b30();
  }
  else {
    puVar12 = (undefined4 *)func_0x01675640(unaff_EBP + -0x84,&UNK_018c88a4,*(int *)(iVar19 + 0x70))
    ;
    if ((undefined4 *)(unaff_EBP + -0x104) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x104) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x100) = uVar18;
      *(undefined4 *)(unaff_EBP + -0xfc) = uVar7;
      *(undefined4 *)(unaff_EBP + -0xf8) = uVar8;
      uVar2 = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined8 *)(unaff_EBP + -0xf4) = uVar2;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    if (*(int *)(**(int **)(unaff_EBP + -0x10) + 0x84) != 0) {
      puVar12 = (undefined4 *)
                func_0x00558df0(unaff_EBP + -0x84,&UNK_018bcaac,**(int **)(unaff_EBP + -0x10) + 0x74
                               );
      uVar3 = puVar12[5];
      uVar18 = puVar12[4];
      *(undefined *)(unaff_EBP + -4) = 0x28;
      if (0xf < uVar3) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x00554150(puVar12,uVar18);
      *(undefined *)(unaff_EBP + -4) = 0x27;
LAB_005e9426:
      func_0x005507b0();
    }
  }
  if (iVar15 != 0) {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      func_0x005542c0(&UNK_018c8708,0x15);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
    }
    else {
      func_0x005542c0(&UNK_018c86ec,0x18);
      *(undefined *)(unaff_EBP + -4) = 0x2c;
    }
    uVar18 = func_0x00558c20(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0x104);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x005507b0();
    func_0x0098c2c0(3,unaff_EBP + -0x40);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c8774,6);
    *(undefined *)(unaff_EBP + -4) = 0x2e;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c877c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x2f;
    uVar18 = func_0x00558ba0(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0xbc);
    *(undefined *)(unaff_EBP + -4) = 0x30;
    func_0x00558c20(unaff_EBP + -100,uVar18,unaff_EBP + -0x13c);
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x34;
    func_0x005507b0();
    iVar15 = unaff_EBP + -100;
    if (0xf < *(uint *)(unaff_EBP + -0x50)) {
      iVar15 = *(int *)(unaff_EBP + -100);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar15,0,0,0,3);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + 0xb,unaff_EBP + 0xb,unaff_EBP + 0xb);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    uVar18 = func_0x0152fd20(unaff_EBP + -0x84);
    *(undefined *)(unaff_EBP + -4) = 0x36;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 0x37;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 0x38;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x28);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x39;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x009ee570(unaff_EBP + -0x84,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x01675640(unaff_EBP + -0xbc,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                             *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c85d0,7);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005d15d0(unaff_EBP + -0x28);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a0,5);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 + 0x18 != unaff_EBP + -0x104) {
      iVar15 = unaff_EBP + -0x104;
      if (0xf < *(uint *)(unaff_EBP + -0xf0)) {
        iVar15 = *(int *)(unaff_EBP + -0x104);
      }
      func_0x005542c0(iVar15,*(undefined4 *)(unaff_EBP + -0xf4));
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c85fc,0x1c);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x00879580(unaff_EBP + -0x28,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a8,0x21);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x008783f0(unaff_EBP + -0x28,1,0);
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + 0xb) = 0;
LAB_005e99b2:
  func_0x005507b0();
  func_0x00550ad0();
  piVar17 = *(int **)(unaff_EBP + -0x68);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      iVar15 = piVar17[2] + -1;
      piVar17[2] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  piVar17 = *(int **)(unaff_EBP + -0x108);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      piVar1 = piVar17 + 2;
      iVar15 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar15 == 1) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  uVar11 = *(undefined *)(unaff_EBP + 0xb);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar11;
}



// referenced at 0x005e95a7, inferred function entry 005e82ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_005e82ab(void)

{
  int *piVar1;
  undefined8 uVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  code *pcVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined *puVar16;
  int *piVar17;
  undefined4 uVar18;
  int iVar19;
  uint uVar20;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar21;
  
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x9c,1,0);
  uVar3 = *(uint *)(unaff_EBP + -0x88);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x9c);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (uVar20 < 0x1000) {
LAB_005e8327:
      func_0x01674ea0(iVar19,uVar20);
      goto LAB_005e8331;
    }
    iVar19 = *(int *)(iVar15 + -4);
    uVar20 = uVar3 + 0x24;
    if ((iVar15 - iVar19) - 4U < 0x20) goto LAB_005e8327;
    func_0x017167a3();
LAB_005e9a6a:
    func_0x017167a3();
LAB_005e9a6f:
    func_0x017167a3();
LAB_005e9a74:
    func_0x017167a3();
LAB_005e9a79:
    func_0x017167a3();
LAB_005e9a7e:
    uVar18 = func_0x0056acb0();
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x00564940(uVar18);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
  }
LAB_005e8331:
  if ((unaff_EDI != 0) && (*(char *)(unaff_EBP + 0xc) != '\0')) {
    cVar10 = func_0x00a161b0(*(undefined4 *)(unaff_EBP + -0x48));
    if (cVar10 != '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c83b8,0x58);
      *(undefined4 *)(unaff_EBP + -4) = 1;
      func_0x0098c2c0(3,unaff_EBP + -0x9c);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c8414,0x2c);
      *(undefined4 *)(unaff_EBP + -4) = 2;
      func_0x008783f0(unaff_EBP + -0x9c,1,0);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 0;
    }
    if ((*(char *)(unaff_EBP + 0xc) != '\0') &&
       (cVar10 = func_0x00a16240(*(undefined4 *)(unaff_EBP + -0x48)), cVar10 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
  }
  piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
  func_0x00a19ae0(*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17,
                  *(undefined4 *)(unaff_EBP + -0x48));
  *(undefined4 *)(unaff_EBP + -0x114) = 0;
  *(undefined4 *)(unaff_EBP + -0x110) = 0xf;
  *(undefined *)(unaff_EBP + -0x124) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0;
  *(undefined4 *)(unaff_EBP + -0xd8) = 0xf;
  *(undefined *)(unaff_EBP + -0xec) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x00a24b20(unaff_EBP + -0x124);
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  puVar12 = (undefined4 *)
            func_0x01531190(unaff_EBP + -0x28,iVar15,*(undefined4 *)(unaff_EBP + -0x114));
  if ((undefined4 *)(unaff_EBP + -0xec) != puVar12) {
    func_0x005507b0();
    uVar18 = puVar12[1];
    uVar7 = puVar12[2];
    uVar8 = puVar12[3];
    *(undefined4 *)(unaff_EBP + -0xec) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xe8) = uVar18;
    *(undefined4 *)(unaff_EBP + -0xe4) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xe0) = uVar8;
    *(undefined8 *)(unaff_EBP + -0xdc) = *(undefined8 *)(puVar12 + 4);
    puVar12[4] = 0;
    puVar12[5] = 0xf;
    *(undefined *)puVar12 = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x28);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6a;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  func_0x005c39d0(iVar15,*(undefined4 *)(unaff_EBP + -0x114),unaff_EBP + -0x9c,
                  *(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x124);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x120);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x11c);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x118);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x114);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x114) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x124) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x120) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x11c) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x118) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6f;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  if (DAT_01ea937d != '\0') {
    puVar13 = &UNK_018c8468;
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      puVar13 = &UNK_018c8474;
    }
    func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar13,puVar16,iVar15);
  }
  if (DAT_01d64710 != '\0') {
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(unaff_EBP + -0xd0) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xcc) = 0;
    *(undefined4 *)(unaff_EBP + -200) = 0x3f800000;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    puVar12 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 7;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 8;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 9;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x40);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 10;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84d4,0x13);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != (undefined4 *)(unaff_EBP + -0x40)) {
      func_0x005507b0();
      uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
      uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
      uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
      uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined4 *)(iVar15 + 0x18) = uVar18;
      *(undefined4 *)(iVar15 + 0x1c) = uVar7;
      *(undefined4 *)(iVar15 + 0x20) = uVar8;
      *(undefined4 *)(iVar15 + 0x24) = uVar9;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(unaff_EBP + -0x30);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x28,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x28,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0xf;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x10;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c87cc,0x15);
    *(undefined *)(unaff_EBP + -4) = 0x11;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x13;
    func_0x00879580(unaff_EBP + -100,unaff_EBP + -0x40,unaff_EBP + -0xbc,unaff_EBP + -0xd4);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 5;
    func_0x0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    cVar10 = DAT_01ea937e;
    iVar15 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
    }
    puVar13 = &DAT_01d79c68;
    if (0xf < _DAT_01d79c7c) {
      puVar13 = _DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    *(undefined *)(unaff_EBP + -4) = 0x14;
    func_0x01677520(cVar10,&UNK_018c87e8,puVar16,puVar13,*(undefined *)(unaff_EBP + 0xc),iVar15,
                    *(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + 0x14));
    uVar3 = *(uint *)(unaff_EBP + -0x2c);
    *(undefined *)(unaff_EBP + -4) = 5;
    if (0xf < uVar3) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
      uVar20 = uVar3 + 1;
      iVar19 = iVar15;
      if (0xfff < uVar20) {
        iVar19 = *(int *)(iVar15 + -4);
        uVar20 = uVar3 + 0x24;
        if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a74;
      }
      func_0x01674ea0(iVar19,uVar20);
    }
  }
  iVar15 = _DAT_01d658cc;
  if ((_DAT_01d658cc < 1) || (*(undefined *)(unaff_EBP + -0x41) = 1, _DAT_01d658f8 < iVar15)) {
    *(undefined *)(unaff_EBP + -0x41) = 0;
  }
  puVar13 = (undefined *)func_0x01674e20(0x18);
  *(undefined **)(unaff_EBP + -0x10) = puVar13;
  if (puVar13 == (undefined *)0x0) {
    puVar13 = (undefined *)0x0;
  }
  else {
    *puVar13 = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(puVar13 + 4) = *puVar12;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x10c) = 0;
  *(undefined4 *)(unaff_EBP + -0x108) = 0;
  func_0x005c1af0(puVar13,*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -4) = 0x15;
  *(bool *)(unaff_EBP + -0x49) = *(char *)(unaff_EBP + 0xc) == '\0';
  func_0x005c4c00(0x1d59a08,unaff_EBP + -0x49);
  func_0x005e52b0();
  func_0x005c4c00(0x1d59a38,unaff_EBP + -0x9c);
  func_0x005c16d0();
  func_0x005c4c00(0x1d59a50,unaff_EBP + -0xec);
  func_0x005c16d0();
  *(undefined4 *)(unaff_EBP + -0x14c) = 0;
  *(undefined4 *)(unaff_EBP + -0x148) = 0xf;
  *(undefined *)(unaff_EBP + -0x15c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x16;
  func_0x005e4d60(unaff_EBP + -0x10c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  func_0x0098fc00(unaff_EBP + -0x22c,unaff_EBP + -0x15c,1);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  if (*(int *)(unaff_EBP + -0x228) != 0) {
    (**(code **)(*(int *)(unaff_EBP + -0x228) + 8))(unaff_EBP + -0x224);
  }
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x98);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x94);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x90);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x8c);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x8c) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x9c) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x98) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x94) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x90) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a79;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  uVar11 = DAT_01d65a38;
  bVar21 = *(char *)(unaff_EBP + -0x41) == '\0';
  *(undefined4 *)(unaff_EBP + -300) = 0;
  if (!bVar21) {
    uVar11 = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x128) = 0xf;
  *(undefined *)(unaff_EBP + -0x10) = uVar11;
  *(undefined *)(unaff_EBP + -0x13c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (bVar21) {
    piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
    puVar12 = (undefined4 *)
              func_0x00a27b10(unaff_EBP + -0x84,*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      puVar14 = puVar12 + 4;
      if (0xf < (uint)puVar12[5]) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x005542c0(puVar12,*puVar14);
    }
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0xf;
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c8870,0x1b);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c888c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c71bc,4);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x0151bcc0(unaff_EBP + -0x1d4,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40,
                    unaff_EBP + -0xd4,unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    puVar12 = (undefined4 *)func_0x0151bb70(unaff_EBP + -0x84);
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x13c) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x138) = uVar18;
      *(undefined4 *)(unaff_EBP + -0x134) = uVar7;
      *(undefined4 *)(unaff_EBP + -0x130) = uVar8;
      *(undefined8 *)(unaff_EBP + -300) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    func_0x0056d9d0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  func_0x005507b0();
  func_0x014c9d60(unaff_EBP + -0x6c,0);
  iVar15 = unaff_EBP + -0x13c;
  if (0xf < *(uint *)(unaff_EBP + -0x128)) {
    iVar15 = *(int *)(unaff_EBP + -0x13c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x014cbbc0(iVar15,*(undefined4 *)(unaff_EBP + -300));
  *(undefined4 *)(*(int *)(unaff_EBP + -0x6c) + 0xb0) = 0;
  puVar13 = &DAT_01d79f98;
  if (0xf < _DAT_01d79fac) {
    puVar13 = _DAT_01d79f98;
  }
  puVar16 = &DAT_01d79d70;
  if (0xf < _DAT_01d79d84) {
    puVar16 = _DAT_01d79d70;
  }
  func_0x014cb8a0(puVar16,_DAT_01d79d80,puVar13,_DAT_01d79fa8);
  puVar12 = (undefined4 *)
            func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                            *(undefined4 *)(unaff_EBP + 0x14));
  uVar18 = puVar12[4];
  uVar3 = puVar12[5];
  *(undefined *)(unaff_EBP + -4) = 0x22;
  if (0xf < uVar3) {
    puVar12 = (undefined4 *)*puVar12;
  }
  puVar13 = &DAT_01d79ef0;
  if (0xf < _DAT_01d79f04) {
    puVar13 = _DAT_01d79ef0;
  }
  func_0x014cb8a0(puVar13,_DAT_01d79f00,puVar12,uVar18);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005507b0();
  func_0x014cba10(&UNK_018c88a0,3);
  func_0x014cb780(unaff_EBP + -0x15c,*(undefined4 *)(unaff_EBP + -0x10));
  if (DAT_01d64710 == '\0') {
    iVar15 = *(int *)(unaff_EBP + -0xa0);
  }
  else {
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    uVar18 = puVar12[4];
    uVar3 = puVar12[5];
    *(undefined *)(unaff_EBP + -4) = 0x23;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86ac,0x12,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
    iVar15 = *(int *)(unaff_EBP + -0xa0);
    puVar12 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x84,iVar15);
    uVar3 = puVar12[5];
    uVar18 = puVar12[4];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86c0,0x14,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
  }
  func_0x014cb340(unaff_EBP + -0x144);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  if (*(int **)(unaff_EBP + -0x144) == (int *)0x0) goto LAB_005e9a7e;
  piVar17 = (int *)(**(code **)(**(int **)(unaff_EBP + -0x144) + 0x14))();
  *(undefined4 *)(unaff_EBP + -0xf4) = 0;
  *(int **)(unaff_EBP + -0x10) = piVar17;
  *(undefined4 *)(unaff_EBP + -0xf0) = 0xf;
  *(undefined *)(unaff_EBP + -0x104) = 0;
  iVar19 = *piVar17;
  *(undefined *)(unaff_EBP + -4) = 0x27;
  if (*(int *)(iVar19 + 0x70) == 0) {
    iVar4 = *(int *)(iVar19 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar17 = (int *)(iVar19 + 0x10);
      if (0xf < *(uint *)(iVar19 + 0x24)) {
        piVar17 = (int *)*piVar17;
      }
      uVar18 = func_0x01675640(unaff_EBP + -0x84,&UNK_018c8324,iVar4,piVar17);
      func_0x005511f0(uVar18);
      goto LAB_005e9426;
    }
    *(undefined4 *)(unaff_EBP + -0xa4) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x29;
    cVar10 = func_0x0098f070(iVar19 + 0x40,unaff_EBP + -0xa4,0);
    if (cVar10 == '\0') {
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88ec;
    }
    else {
      func_0x00580040(unaff_EBP + -0x10,0x1d599f0);
      if (*(int *)(unaff_EBP + -0x10) != 0) {
        puVar12 = (undefined4 *)func_0x0055d5e0();
        pcVar5 = *(char **)(unaff_EBP + 8);
        *(undefined4 *)(pcVar5 + 4) = *puVar12;
        if (*pcVar5 == '\0') {
          *pcVar5 = '\x01';
        }
        if (iVar15 != 0) {
          func_0x0054eff0(&UNK_018c86d8);
          *(undefined *)(unaff_EBP + -4) = 0x2a;
          func_0x0097c9e0(unaff_EBP + -0x28);
          *(undefined *)(unaff_EBP + -4) = 0x29;
          func_0x005507b0();
          if (DAT_01d64710 != '\0') {
            func_0x005ea7b0();
          }
        }
        func_0x00550b30();
        *(undefined *)(unaff_EBP + 0xb) = 1;
        goto LAB_005e99b2;
      }
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88c0;
    }
    uVar18 = func_0x01675640(unaff_EBP + -0x84,puVar13,uVar18);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x00550b30();
  }
  else {
    puVar12 = (undefined4 *)func_0x01675640(unaff_EBP + -0x84,&UNK_018c88a4,*(int *)(iVar19 + 0x70))
    ;
    if ((undefined4 *)(unaff_EBP + -0x104) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x104) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x100) = uVar18;
      *(undefined4 *)(unaff_EBP + -0xfc) = uVar7;
      *(undefined4 *)(unaff_EBP + -0xf8) = uVar8;
      uVar2 = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined8 *)(unaff_EBP + -0xf4) = uVar2;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    if (*(int *)(**(int **)(unaff_EBP + -0x10) + 0x84) != 0) {
      puVar12 = (undefined4 *)
                func_0x00558df0(unaff_EBP + -0x84,&UNK_018bcaac,**(int **)(unaff_EBP + -0x10) + 0x74
                               );
      uVar3 = puVar12[5];
      uVar18 = puVar12[4];
      *(undefined *)(unaff_EBP + -4) = 0x28;
      if (0xf < uVar3) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x00554150(puVar12,uVar18);
      *(undefined *)(unaff_EBP + -4) = 0x27;
LAB_005e9426:
      func_0x005507b0();
    }
  }
  if (iVar15 != 0) {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      func_0x005542c0(&UNK_018c8708,0x15);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
    }
    else {
      func_0x005542c0(&UNK_018c86ec,0x18);
      *(undefined *)(unaff_EBP + -4) = 0x2c;
    }
    uVar18 = func_0x00558c20(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0x104);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x005507b0();
    func_0x0098c2c0(3,unaff_EBP + -0x40);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c8774,6);
    *(undefined *)(unaff_EBP + -4) = 0x2e;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c877c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x2f;
    uVar18 = func_0x00558ba0(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0xbc);
    *(undefined *)(unaff_EBP + -4) = 0x30;
    func_0x00558c20(unaff_EBP + -100,uVar18,unaff_EBP + -0x13c);
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x34;
    func_0x005507b0();
    iVar15 = unaff_EBP + -100;
    if (0xf < *(uint *)(unaff_EBP + -0x50)) {
      iVar15 = *(int *)(unaff_EBP + -100);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar15,0,0,0,3);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + 0xb,unaff_EBP + 0xb,unaff_EBP + 0xb);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    uVar18 = func_0x0152fd20(unaff_EBP + -0x84);
    *(undefined *)(unaff_EBP + -4) = 0x36;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 0x37;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 0x38;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x28);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x39;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x009ee570(unaff_EBP + -0x84,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x01675640(unaff_EBP + -0xbc,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                             *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c85d0,7);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005d15d0(unaff_EBP + -0x28);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a0,5);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 + 0x18 != unaff_EBP + -0x104) {
      iVar15 = unaff_EBP + -0x104;
      if (0xf < *(uint *)(unaff_EBP + -0xf0)) {
        iVar15 = *(int *)(unaff_EBP + -0x104);
      }
      func_0x005542c0(iVar15,*(undefined4 *)(unaff_EBP + -0xf4));
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c85fc,0x1c);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x00879580(unaff_EBP + -0x28,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a8,0x21);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x008783f0(unaff_EBP + -0x28,1,0);
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + 0xb) = 0;
LAB_005e99b2:
  func_0x005507b0();
  func_0x00550ad0();
  piVar17 = *(int **)(unaff_EBP + -0x68);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      iVar15 = piVar17[2] + -1;
      piVar17[2] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  piVar17 = *(int **)(unaff_EBP + -0x108);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      piVar1 = piVar17 + 2;
      iVar15 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar15 == 1) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  uVar11 = *(undefined *)(unaff_EBP + 0xb);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar11;
}



// referenced at 0x005e98ce, inferred function entry 005e82ab

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_005e82ab(void)

{
  int *piVar1;
  undefined8 uVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  code *pcVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined *puVar16;
  int *piVar17;
  undefined4 uVar18;
  int iVar19;
  uint uVar20;
  int unaff_EBP;
  int unaff_EDI;
  undefined4 *unaff_FS_OFFSET;
  bool bVar21;
  
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  func_0x005542c0(&UNK_018c8334);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  func_0x008783f0(unaff_EBP + -0x9c,1,0);
  uVar3 = *(uint *)(unaff_EBP + -0x88);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x9c);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (uVar20 < 0x1000) {
LAB_005e8327:
      func_0x01674ea0(iVar19,uVar20);
      goto LAB_005e8331;
    }
    iVar19 = *(int *)(iVar15 + -4);
    uVar20 = uVar3 + 0x24;
    if ((iVar15 - iVar19) - 4U < 0x20) goto LAB_005e8327;
    func_0x017167a3();
LAB_005e9a6a:
    func_0x017167a3();
LAB_005e9a6f:
    func_0x017167a3();
LAB_005e9a74:
    func_0x017167a3();
LAB_005e9a79:
    func_0x017167a3();
LAB_005e9a7e:
    uVar18 = func_0x0056acb0();
    *(undefined *)(unaff_EBP + -4) = 0x26;
    func_0x00564940(uVar18);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
  }
LAB_005e8331:
  if ((unaff_EDI != 0) && (*(char *)(unaff_EBP + 0xc) != '\0')) {
    cVar10 = func_0x00a161b0(*(undefined4 *)(unaff_EBP + -0x48));
    if (cVar10 != '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c83b8,0x58);
      *(undefined4 *)(unaff_EBP + -4) = 1;
      func_0x0098c2c0(3,unaff_EBP + -0x9c);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
      *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
      *(undefined *)(unaff_EBP + -0x9c) = 0;
      func_0x005542c0(&UNK_018c8414,0x2c);
      *(undefined4 *)(unaff_EBP + -4) = 2;
      func_0x008783f0(unaff_EBP + -0x9c,1,0);
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      func_0x005507b0();
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8100,0,0,0);
      *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
      return 0;
    }
    if ((*(char *)(unaff_EBP + 0xc) != '\0') &&
       (cVar10 = func_0x00a16240(*(undefined4 *)(unaff_EBP + -0x48)), cVar10 != '\0')) {
      func_0x0087c450(&UNK_018c8444,&UNK_018c80e0,&UNK_018c8124,0,0,0);
    }
  }
  piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
  func_0x00a19ae0(*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17,
                  *(undefined4 *)(unaff_EBP + -0x48));
  *(undefined4 *)(unaff_EBP + -0x114) = 0;
  *(undefined4 *)(unaff_EBP + -0x110) = 0xf;
  *(undefined *)(unaff_EBP + -0x124) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0;
  *(undefined4 *)(unaff_EBP + -0xd8) = 0xf;
  *(undefined *)(unaff_EBP + -0xec) = 0;
  *(undefined *)(unaff_EBP + -4) = 5;
  func_0x00a24b20(unaff_EBP + -0x124);
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  puVar12 = (undefined4 *)
            func_0x01531190(unaff_EBP + -0x28,iVar15,*(undefined4 *)(unaff_EBP + -0x114));
  if ((undefined4 *)(unaff_EBP + -0xec) != puVar12) {
    func_0x005507b0();
    uVar18 = puVar12[1];
    uVar7 = puVar12[2];
    uVar8 = puVar12[3];
    *(undefined4 *)(unaff_EBP + -0xec) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xe8) = uVar18;
    *(undefined4 *)(unaff_EBP + -0xe4) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xe0) = uVar8;
    *(undefined8 *)(unaff_EBP + -0xdc) = *(undefined8 *)(puVar12 + 4);
    puVar12[4] = 0;
    puVar12[5] = 0xf;
    *(undefined *)puVar12 = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x28);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6a;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  iVar15 = unaff_EBP + -0x124;
  if (0xf < *(uint *)(unaff_EBP + -0x110)) {
    iVar15 = *(int *)(unaff_EBP + -0x124);
  }
  func_0x005c39d0(iVar15,*(undefined4 *)(unaff_EBP + -0x114),unaff_EBP + -0x9c,
                  *(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x124);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x120);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x11c);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x118);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x114);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x114) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x124) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x120) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x11c) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x118) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a6f;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  if (DAT_01ea937d != '\0') {
    puVar13 = &UNK_018c8468;
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      puVar13 = &UNK_018c8474;
    }
    func_0x01677520(DAT_01ea937d,&UNK_018c847c,puVar13,puVar16,iVar15);
  }
  if (DAT_01d64710 != '\0') {
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(unaff_EBP + -0xd0) = *puVar12;
    *(undefined4 *)(unaff_EBP + -0xcc) = 0;
    *(undefined4 *)(unaff_EBP + -200) = 0x3f800000;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    puVar12 = (undefined4 *)func_0x0152fd20(unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 7;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 8;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 9;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x40);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 10;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x40);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84d4,0x13);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != (undefined4 *)(unaff_EBP + -0x40)) {
      func_0x005507b0();
      uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
      uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
      uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
      uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined4 *)(iVar15 + 0x18) = uVar18;
      *(undefined4 *)(iVar15 + 0x1c) = uVar7;
      *(undefined4 *)(iVar15 + 0x20) = uVar8;
      *(undefined4 *)(iVar15 + 0x24) = uVar9;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(unaff_EBP + -0x30);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)func_0x009ee570(unaff_EBP + -0x28,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0xd;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x28,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0xf;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x10;
    iVar15 = func_0x005d15d0(unaff_EBP + -100);
    if ((undefined4 *)(iVar15 + 0x18) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(iVar15 + 0x18) = *puVar12;
      *(undefined4 *)(iVar15 + 0x1c) = uVar18;
      *(undefined4 *)(iVar15 + 0x20) = uVar7;
      *(undefined4 *)(iVar15 + 0x24) = uVar8;
      *(undefined8 *)(iVar15 + 0x28) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 6;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c87cc,0x15);
    *(undefined *)(unaff_EBP + -4) = 0x11;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x13;
    func_0x00879580(unaff_EBP + -100,unaff_EBP + -0x40,unaff_EBP + -0xbc,unaff_EBP + -0xd4);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 5;
    func_0x0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    uVar18 = 4;
    if (*(uint *)(unaff_EBP + -0xdc) < 4) {
      uVar18 = *(undefined4 *)(unaff_EBP + -0xdc);
    }
    iVar15 = unaff_EBP + -0xec;
    if (0xf < *(uint *)(unaff_EBP + -0xd8)) {
      iVar15 = *(int *)(unaff_EBP + -0xec);
    }
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(iVar15,uVar18);
    cVar10 = DAT_01ea937e;
    iVar15 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
    }
    puVar13 = &DAT_01d79c68;
    if (0xf < _DAT_01d79c7c) {
      puVar13 = _DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < _DAT_01d79c94) {
      puVar16 = _DAT_01d79c80;
    }
    *(undefined *)(unaff_EBP + -4) = 0x14;
    func_0x01677520(cVar10,&UNK_018c87e8,puVar16,puVar13,*(undefined *)(unaff_EBP + 0xc),iVar15,
                    *(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + 0x14));
    uVar3 = *(uint *)(unaff_EBP + -0x2c);
    *(undefined *)(unaff_EBP + -4) = 5;
    if (0xf < uVar3) {
      iVar15 = *(int *)(unaff_EBP + -0x40);
      uVar20 = uVar3 + 1;
      iVar19 = iVar15;
      if (0xfff < uVar20) {
        iVar19 = *(int *)(iVar15 + -4);
        uVar20 = uVar3 + 0x24;
        if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a74;
      }
      func_0x01674ea0(iVar19,uVar20);
    }
  }
  iVar15 = _DAT_01d658cc;
  if ((_DAT_01d658cc < 1) || (*(undefined *)(unaff_EBP + -0x41) = 1, _DAT_01d658f8 < iVar15)) {
    *(undefined *)(unaff_EBP + -0x41) = 0;
  }
  puVar13 = (undefined *)func_0x01674e20(0x18);
  *(undefined **)(unaff_EBP + -0x10) = puVar13;
  if (puVar13 == (undefined *)0x0) {
    puVar13 = (undefined *)0x0;
  }
  else {
    *puVar13 = 0;
    *(undefined4 *)(unaff_EBP + -0x10) = 0xb;
    puVar14 = (undefined4 *)func_0x00563d40(&UNK_018be100,&UNK_018be198,unaff_EBP + -0x10);
    puVar12 = puVar14 + -1;
    if (puVar14 != (undefined4 *)&UNK_018be198) {
      puVar12 = puVar14;
    }
    *(undefined4 *)(puVar13 + 4) = *puVar12;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x10c) = 0;
  *(undefined4 *)(unaff_EBP + -0x108) = 0;
  func_0x005c1af0(puVar13,*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -4) = 0x15;
  *(bool *)(unaff_EBP + -0x49) = *(char *)(unaff_EBP + 0xc) == '\0';
  func_0x005c4c00(0x1d59a08,unaff_EBP + -0x49);
  func_0x005e52b0();
  func_0x005c4c00(0x1d59a38,unaff_EBP + -0x9c);
  func_0x005c16d0();
  func_0x005c4c00(0x1d59a50,unaff_EBP + -0xec);
  func_0x005c16d0();
  *(undefined4 *)(unaff_EBP + -0x14c) = 0;
  *(undefined4 *)(unaff_EBP + -0x148) = 0xf;
  *(undefined *)(unaff_EBP + -0x15c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x16;
  func_0x005e4d60(unaff_EBP + -0x10c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  func_0x0098fc00(unaff_EBP + -0x22c,unaff_EBP + -0x15c,1);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  if (*(int *)(unaff_EBP + -0x228) != 0) {
    (**(code **)(*(int *)(unaff_EBP + -0x228) + 8))(unaff_EBP + -0x224);
  }
  *(undefined *)(unaff_EBP + -0x40) = 0;
  uVar18 = *(undefined4 *)(unaff_EBP + -0x40);
  uVar7 = *(undefined4 *)(unaff_EBP + -0x3c);
  uVar8 = *(undefined4 *)(unaff_EBP + -0x38);
  uVar9 = *(undefined4 *)(unaff_EBP + -0x34);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  uVar2 = *(undefined8 *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x98);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x94);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x90);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x8c);
  uVar3 = *(uint *)(unaff_EBP + -0x2c);
  *(undefined8 *)(unaff_EBP + -0x8c) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x9c) = uVar18;
  *(undefined4 *)(unaff_EBP + -0x98) = uVar7;
  *(undefined4 *)(unaff_EBP + -0x94) = uVar8;
  *(undefined4 *)(unaff_EBP + -0x90) = uVar9;
  if (0xf < uVar3) {
    iVar15 = *(int *)(unaff_EBP + -0x40);
    uVar20 = uVar3 + 1;
    iVar19 = iVar15;
    if (0xfff < uVar20) {
      iVar19 = *(int *)(iVar15 + -4);
      uVar20 = uVar3 + 0x24;
      if (0x1f < (iVar15 - iVar19) - 4U) goto LAB_005e9a79;
    }
    func_0x01674ea0(iVar19,uVar20);
  }
  uVar11 = DAT_01d65a38;
  bVar21 = *(char *)(unaff_EBP + -0x41) == '\0';
  *(undefined4 *)(unaff_EBP + -300) = 0;
  if (!bVar21) {
    uVar11 = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x128) = 0xf;
  *(undefined *)(unaff_EBP + -0x10) = uVar11;
  *(undefined *)(unaff_EBP + -0x13c) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (bVar21) {
    piVar17 = *(int **)(*(int *)(unaff_EBP + -0x48) + 0x43c);
    puVar12 = (undefined4 *)
              func_0x00a27b10(unaff_EBP + -0x84,*piVar17 - (int)piVar17,piVar17[1] - (int)piVar17);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      puVar14 = puVar12 + 4;
      if (0xf < (uint)puVar12[5]) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x005542c0(puVar12,*puVar14);
    }
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    *(undefined4 *)(unaff_EBP + -0xc4) = 0;
    *(undefined4 *)(unaff_EBP + -0xc0) = 0xf;
    *(undefined *)(unaff_EBP + -0xd4) = 0;
    func_0x005542c0(&UNK_018bc9b8,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    func_0x005542c0(&UNK_018c8870,0x1b);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c888c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c71bc,4);
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    func_0x0151bcc0(unaff_EBP + -0x1d4,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40,
                    unaff_EBP + -0xd4,unaff_EBP + -0x28);
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    puVar12 = (undefined4 *)func_0x0151bb70(unaff_EBP + -0x84);
    if ((undefined4 *)(unaff_EBP + -0x13c) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x13c) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x138) = uVar18;
      *(undefined4 *)(unaff_EBP + -0x134) = uVar7;
      *(undefined4 *)(unaff_EBP + -0x130) = uVar8;
      *(undefined8 *)(unaff_EBP + -300) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    func_0x0056d9d0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  func_0x005507b0();
  func_0x014c9d60(unaff_EBP + -0x6c,0);
  iVar15 = unaff_EBP + -0x13c;
  if (0xf < *(uint *)(unaff_EBP + -0x128)) {
    iVar15 = *(int *)(unaff_EBP + -0x13c);
  }
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x014cbbc0(iVar15,*(undefined4 *)(unaff_EBP + -300));
  *(undefined4 *)(*(int *)(unaff_EBP + -0x6c) + 0xb0) = 0;
  puVar13 = &DAT_01d79f98;
  if (0xf < _DAT_01d79fac) {
    puVar13 = _DAT_01d79f98;
  }
  puVar16 = &DAT_01d79d70;
  if (0xf < _DAT_01d79d84) {
    puVar16 = _DAT_01d79d70;
  }
  func_0x014cb8a0(puVar16,_DAT_01d79d80,puVar13,_DAT_01d79fa8);
  puVar12 = (undefined4 *)
            func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                            *(undefined4 *)(unaff_EBP + 0x14));
  uVar18 = puVar12[4];
  uVar3 = puVar12[5];
  *(undefined *)(unaff_EBP + -4) = 0x22;
  if (0xf < uVar3) {
    puVar12 = (undefined4 *)*puVar12;
  }
  puVar13 = &DAT_01d79ef0;
  if (0xf < _DAT_01d79f04) {
    puVar13 = _DAT_01d79ef0;
  }
  func_0x014cb8a0(puVar13,_DAT_01d79f00,puVar12,uVar18);
  *(undefined *)(unaff_EBP + -4) = 0x21;
  func_0x005507b0();
  func_0x014cba10(&UNK_018c88a0,3);
  func_0x014cb780(unaff_EBP + -0x15c,*(undefined4 *)(unaff_EBP + -0x10));
  if (DAT_01d64710 == '\0') {
    iVar15 = *(int *)(unaff_EBP + -0xa0);
  }
  else {
    puVar12 = (undefined4 *)
              func_0x01675640(unaff_EBP + -0x84,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                              *(undefined4 *)(unaff_EBP + 0x14));
    uVar18 = puVar12[4];
    uVar3 = puVar12[5];
    *(undefined *)(unaff_EBP + -4) = 0x23;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86ac,0x12,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
    iVar15 = *(int *)(unaff_EBP + -0xa0);
    puVar12 = (undefined4 *)func_0x005ea020(unaff_EBP + -0x84,iVar15);
    uVar3 = puVar12[5];
    uVar18 = puVar12[4];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar12 = (undefined4 *)*puVar12;
    }
    func_0x014cb8a0(&UNK_018c86c0,0x14,puVar12,uVar18);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    func_0x005507b0();
  }
  func_0x014cb340(unaff_EBP + -0x144);
  *(undefined *)(unaff_EBP + -4) = 0x25;
  if (*(int **)(unaff_EBP + -0x144) == (int *)0x0) goto LAB_005e9a7e;
  piVar17 = (int *)(**(code **)(**(int **)(unaff_EBP + -0x144) + 0x14))();
  *(undefined4 *)(unaff_EBP + -0xf4) = 0;
  *(int **)(unaff_EBP + -0x10) = piVar17;
  *(undefined4 *)(unaff_EBP + -0xf0) = 0xf;
  *(undefined *)(unaff_EBP + -0x104) = 0;
  iVar19 = *piVar17;
  *(undefined *)(unaff_EBP + -4) = 0x27;
  if (*(int *)(iVar19 + 0x70) == 0) {
    iVar4 = *(int *)(iVar19 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar17 = (int *)(iVar19 + 0x10);
      if (0xf < *(uint *)(iVar19 + 0x24)) {
        piVar17 = (int *)*piVar17;
      }
      uVar18 = func_0x01675640(unaff_EBP + -0x84,&UNK_018c8324,iVar4,piVar17);
      func_0x005511f0(uVar18);
      goto LAB_005e9426;
    }
    *(undefined4 *)(unaff_EBP + -0xa4) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x29;
    cVar10 = func_0x0098f070(iVar19 + 0x40,unaff_EBP + -0xa4,0);
    if (cVar10 == '\0') {
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88ec;
    }
    else {
      func_0x00580040(unaff_EBP + -0x10,0x1d599f0);
      if (*(int *)(unaff_EBP + -0x10) != 0) {
        puVar12 = (undefined4 *)func_0x0055d5e0();
        pcVar5 = *(char **)(unaff_EBP + 8);
        *(undefined4 *)(pcVar5 + 4) = *puVar12;
        if (*pcVar5 == '\0') {
          *pcVar5 = '\x01';
        }
        if (iVar15 != 0) {
          func_0x0054eff0(&UNK_018c86d8);
          *(undefined *)(unaff_EBP + -4) = 0x2a;
          func_0x0097c9e0(unaff_EBP + -0x28);
          *(undefined *)(unaff_EBP + -4) = 0x29;
          func_0x005507b0();
          if (DAT_01d64710 != '\0') {
            func_0x005ea7b0();
          }
        }
        func_0x00550b30();
        *(undefined *)(unaff_EBP + 0xb) = 1;
        goto LAB_005e99b2;
      }
      uVar18 = func_0x005543f0();
      puVar13 = &UNK_018c88c0;
    }
    uVar18 = func_0x01675640(unaff_EBP + -0x84,puVar13,uVar18);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x00550b30();
  }
  else {
    puVar12 = (undefined4 *)func_0x01675640(unaff_EBP + -0x84,&UNK_018c88a4,*(int *)(iVar19 + 0x70))
    ;
    if ((undefined4 *)(unaff_EBP + -0x104) != puVar12) {
      func_0x005507b0();
      uVar18 = puVar12[1];
      uVar7 = puVar12[2];
      uVar8 = puVar12[3];
      *(undefined4 *)(unaff_EBP + -0x104) = *puVar12;
      *(undefined4 *)(unaff_EBP + -0x100) = uVar18;
      *(undefined4 *)(unaff_EBP + -0xfc) = uVar7;
      *(undefined4 *)(unaff_EBP + -0xf8) = uVar8;
      uVar2 = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined8 *)(unaff_EBP + -0xf4) = uVar2;
      *(undefined *)puVar12 = 0;
    }
    func_0x005507b0();
    if (*(int *)(**(int **)(unaff_EBP + -0x10) + 0x84) != 0) {
      puVar12 = (undefined4 *)
                func_0x00558df0(unaff_EBP + -0x84,&UNK_018bcaac,**(int **)(unaff_EBP + -0x10) + 0x74
                               );
      uVar3 = puVar12[5];
      uVar18 = puVar12[4];
      *(undefined *)(unaff_EBP + -4) = 0x28;
      if (0xf < uVar3) {
        puVar12 = (undefined4 *)*puVar12;
      }
      func_0x00554150(puVar12,uVar18);
      *(undefined *)(unaff_EBP + -4) = 0x27;
LAB_005e9426:
      func_0x005507b0();
    }
  }
  if (iVar15 != 0) {
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
    *(undefined *)(unaff_EBP + -0x40) = 0;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    if (*(char *)(unaff_EBP + 0xc) == '\0') {
      func_0x005542c0(&UNK_018c8708,0x15);
      *(undefined *)(unaff_EBP + -4) = 0x2d;
    }
    else {
      func_0x005542c0(&UNK_018c86ec,0x18);
      *(undefined *)(unaff_EBP + -4) = 0x2c;
    }
    uVar18 = func_0x00558c20(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0x104);
    func_0x005511f0(uVar18);
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    func_0x005507b0();
    func_0x0098c2c0(3,unaff_EBP + -0x40);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c8774,6);
    *(undefined *)(unaff_EBP + -4) = 0x2e;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c877c,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x2f;
    uVar18 = func_0x00558ba0(unaff_EBP + -0x84,unaff_EBP + -0x28,unaff_EBP + -0xbc);
    *(undefined *)(unaff_EBP + -4) = 0x30;
    func_0x00558c20(unaff_EBP + -100,uVar18,unaff_EBP + -0x13c);
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x34;
    func_0x005507b0();
    iVar15 = unaff_EBP + -100;
    if (0xf < *(uint *)(unaff_EBP + -0x50)) {
      iVar15 = *(int *)(unaff_EBP + -100);
    }
    func_0x0087c6f0(&UNK_018c5f98,&UNK_018c85c4,iVar15,0,0,0,3);
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x005507b0();
  }
  if (DAT_01d64710 != '\0') {
    func_0x005d0b40(0xb,unaff_EBP + 0xb,unaff_EBP + 0xb,unaff_EBP + 0xb);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    uVar18 = func_0x0152fd20(unaff_EBP + -0x84);
    *(undefined *)(unaff_EBP + -4) = 0x36;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84a4,6);
    *(undefined *)(unaff_EBP + -4) = 0x37;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84ac,0x13);
    *(undefined *)(unaff_EBP + -4) = 0x38;
    puVar13 = (undefined *)func_0x005d15d0(unaff_EBP + -0x28);
    if (puVar13 != &DAT_01d79c68) {
      puVar13 = &DAT_01d79c80;
      if (0xf < _DAT_01d79c94) {
        puVar13 = _DAT_01d79c80;
      }
      func_0x005542c0(puVar13,_DAT_01d79c90);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84c0,0x12);
    *(undefined *)(unaff_EBP + -4) = 0x39;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 != 0x1d79c50) {
      puVar13 = &DAT_01d79c68;
      if (0xf < _DAT_01d79c7c) {
        puVar13 = _DAT_01d79c68;
      }
      func_0x005542c0(puVar13,_DAT_01d79c78);
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x009ee570(unaff_EBP + -0x84,unaff_EBP + 0xc);
    *(undefined *)(unaff_EBP + -4) = 0x3a;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84e8,9);
    *(undefined *)(unaff_EBP + -4) = 0x3b;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    uVar18 = func_0x01675640(unaff_EBP + -0xbc,&UNK_018bed48,*(undefined4 *)(unaff_EBP + 0x10),
                             *(undefined4 *)(unaff_EBP + 0x14));
    *(undefined *)(unaff_EBP + -4) = 0x3c;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c84f4,6);
    *(undefined *)(unaff_EBP + -4) = 0x3d;
    func_0x005d15d0(unaff_EBP + -0x28,uVar18);
    func_0x005511f0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c85d0,7);
    *(undefined *)(unaff_EBP + -4) = 0x3e;
    func_0x005d15d0(unaff_EBP + -0x28);
    func_0x005542c0(&UNK_018c8790,0xe);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a0,5);
    *(undefined *)(unaff_EBP + -4) = 0x3f;
    iVar15 = func_0x005d15d0(unaff_EBP + -0x28);
    if (iVar15 + 0x18 != unaff_EBP + -0x104) {
      iVar15 = unaff_EBP + -0x104;
      if (0xf < *(uint *)(unaff_EBP + -0xf0)) {
        iVar15 = *(int *)(unaff_EBP + -0x104);
      }
      func_0x005542c0(iVar15,*(undefined4 *)(unaff_EBP + -0xf4));
    }
    *(undefined *)(unaff_EBP + -4) = 0x35;
    func_0x005507b0();
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    *(undefined4 *)(unaff_EBP + -0x50) = 0xf;
    *(undefined *)(unaff_EBP + -100) = 0;
    func_0x005542c0(&UNK_018c85fc,0x1c);
    *(undefined *)(unaff_EBP + -4) = 0x40;
    *(undefined4 *)(unaff_EBP + -0xac) = 0;
    *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
    *(undefined *)(unaff_EBP + -0xbc) = 0;
    func_0x005542c0(&UNK_018c850c,10);
    *(undefined *)(unaff_EBP + -4) = 0x41;
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018bde9c,3);
    *(undefined *)(unaff_EBP + -4) = 0x42;
    func_0x00879580(unaff_EBP + -0x28,unaff_EBP + -0xbc,unaff_EBP + -100,unaff_EBP + -0x40);
    func_0x005507b0();
    func_0x005507b0();
    func_0x005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x27;
    func_0x0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x18) = 0;
    *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
    *(undefined *)(unaff_EBP + -0x28) = 0;
    func_0x005542c0(&UNK_018c87a8,0x21);
    *(undefined *)(unaff_EBP + -4) = 0x43;
    func_0x008783f0(unaff_EBP + -0x28,1,0);
    func_0x005507b0();
  }
  *(undefined *)(unaff_EBP + 0xb) = 0;
LAB_005e99b2:
  func_0x005507b0();
  func_0x00550ad0();
  piVar17 = *(int **)(unaff_EBP + -0x68);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      iVar15 = piVar17[2] + -1;
      piVar17[2] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  piVar17 = *(int **)(unaff_EBP + -0x108);
  if (piVar17 != (int *)0x0) {
    LOCK();
    iVar15 = piVar17[1] + -1;
    piVar17[1] = iVar15;
    UNLOCK();
    if (iVar15 == 0) {
      (**(code **)*piVar17)();
      LOCK();
      piVar1 = piVar17 + 2;
      iVar15 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar15 == 1) {
        (**(code **)(*piVar17 + 4))();
      }
    }
  }
  func_0x005507b0();
  func_0x005507b0();
  func_0x005507b0();
  uVar11 = *(undefined *)(unaff_EBP + 0xb);
  *unaff_FS_OFFSET = *(undefined4 *)(unaff_EBP + -0xc);
  return uVar11;
}


