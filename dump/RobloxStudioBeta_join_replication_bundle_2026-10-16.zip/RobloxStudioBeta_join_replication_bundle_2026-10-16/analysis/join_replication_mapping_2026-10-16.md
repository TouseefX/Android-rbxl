# Roblox target: Join and Replication mapping (2026-10-16)

## Bottom line

The target's **“Replication data” is first built server-side as a `ReplicationDataCache` during the `Server Join Snapshot` batch**. That cache is then consumed by the `JoinDataItemV2` builder and queued for the joining peer before the player-install phase. I found no evidence that the cache object itself is sent as a standalone “pre-join Replication data” packet.

The actual network path shows a `0x81` join-start message (with additional opaque fields) and `0x83 0x16 <kind>` JoinDataItemV2 messages. The cache generator groups live instance data into cacheable, Part, non-cacheable, and optional character-model-root categories. The receiver dispatches deserialized new-instance, property-change, delete, attribute, shared-string, atomic-tree, and cluster items. This is **runtime instance/property replication**, not evidence of an `.rbxl` file transfer or an RBXL writer.

The `0x80` Mrd path remains separate. The C++ additions below explicitly leave `0x80` unhandled by the join parser.

## Evidence and reconstructed server sequence

| Phase | Target code evidence | What it establishes |
|---|---|---|
| Server join batch | `FUN_145e4d500` logs `Server Join Snapshot`; its body contains the calls and phase markers below. | One coordinator processes waiting replicators/peers in batches. The function body, not comments/docs, is the basis for the sequence. |
| Network schema | `FUN_145e4d500` calls `FUN_145ea9d50` at the per-peer “send network schema” stage. `FUN_145ea9d50` obtains schema bytes, emits chunks of at most **400 bytes**, and routes them through `FUN_145ea7fd0` or `FUN_145ea7ed0`. | Network schema delivery is a distinct join prerequisite/phase, not the place snapshot itself. Exact schema semantics are not reconstructed here. |
| Join start / globals and top containers | `FUN_145e4d500` calls `FUN_145ea94b0` or `FUN_145ea9000` at its “send Globals and Top Containers” stage. Both builders write leading byte `0x81`, then flags/fields derived from peer, replicator, and configuration state. They may append `FUN_145df0370` output under a condition. | The join-start packet is separate from the JDI snapshot. `0x81` is an observed target wire tag here; its remaining field meanings and complete parser are still unknown. The high-level stage label and optional append are observed, but the exact byte-to-field mapping is not. |
| Prebuild Replication cache | `FUN_145e4d500` calls `FUN_145e33e70` at the “Prebuild Replication Cache” stage. `FUN_145e33e70` directly calls `FUN_145fb4cc0`; the latter contains `ReplicationDataCache::generateDataBlobs` logging and calls `FUN_145fb54f0` / `FUN_145fb5e20`. | This is the strongest target-side identification of the “Replication data”: server-side generated instance-data blobs, not an independently identified RBXL file. |
| Cache categories | `FUN_145fb4cc0` has code paths/log keys for **cacheable instances**, **Part instances**, **non-cacheable instances**, and (when enabled) **character-model roots**. It updates category counters and returns prepared collections. | These are concrete generator categories. They do not reveal a complete property schema or asset format. |
| Generate/queue JDIv2 | `FUN_145e33e70` calls `FUN_145f92500` and `FUN_145fb4cc0`; the coordinator then reaches its `GenerateJDIv2` / queue stage and later `Install Player` / `Done Batch` stages. `FUN_145f92500` writes `0x83 0x16 0x02`; it also calls `FUN_145f90fe0` with kinds 3, 2, and 4. | The cached data is handed into JoinDataItemV2 generation/queueing before player installation. The kind-2/3/4 inner payloads are not fully decoded by this pass. |
| Other JDI kinds | `FUN_145f94050` writes `0x83 0x16 0x01` and calls `FUN_145dba600`; `FUN_145f944b0` writes `0x83 0x16 0x05` and also calls `FUN_145dba600`. | Kinds 1 and 5 use the observed compressed envelope. The helper writes compressed-byte length, input/uncompressed length, then compressed bytes; the target’s transform path is Zstandard, with the target level/config value observed as 1. A builder can append one zero byte. |

### Key distinction about “before joining”

The order in `FUN_145e4d500` is roughly: **network schema → join-start/globals/top-container sends → prebuild Replication cache → generate/queue JDIv2 → install player → finish batch**. Thus, “Replication data before joining” most accurately describes the **server-side snapshot/cache preparation before player installation**, not a proven separate client packet that precedes the join-start message. The client receives the actual snapshot through the JDIv2/Replication stream.

`ReplicationDataBlob` RTTI is present, but `FUN_145fb6e90` is a cache-entry cleanup/state-update method, not a proven send routine. The concrete send-side connection is the cache generator and JDIv2 builders above.

## Client receive/apply path and place representation

- The `DeserializedJoinDataItem` receive/apply method is `FUN_145fccad0`; Replicator and ClientReplicator vtables point slot 167 to `FUN_145dd0350`, which dispatches deserialized item records.
- The receiver-side class/handler mappings in RTTI and decompilation include:
  - `DeserializedNewObjectItem` → `FUN_145f4fdf0`
  - `DeserializedChangePropertyItem` → `FUN_145f880c0` → `FUN_145dda4c0`
  - `DeserializedDeleteInstanceItem` → `FUN_145f88d20`
  - `DeserializedChangeAttributeItem` → `FUN_145f86980`
  - `DeserializedSharedStringItem` → `FUN_145f7cd60`
  - `DeserializedResolveNewInstanceAtomicTreeItem` → `FUN_145f51700`
  - `DeserializedClusterItem` → `FUN_145f6dd10`
- `FUN_145dd0350` walks `0xd8`-stride **in-memory** records and dispatches each through its handler slot. That stride is not established as a wire stride.

Together with the server’s instance-category blob generation, this supports the interpretation that the joining client reconstructs an in-memory place/instance graph through Replication items and subsequent property/state updates. The traced path does **not** show a raw `.rbxl` document being sent. A separate content/asset-download path may exist outside these functions; it was not established here. No RBXL writer or asset writer was added.

## Change synchronization (explained only; not implemented)

The target has a `ChangePropertyItem@Replicator` send-side type. Its serializer vtable method `FUN_145f889f0` calls `FUN_145f88a40`; that code checks Replicator/property conditions (`FUN_145dc6d50`, `FUN_145dc42e0`) before serializing. On receive, `DeserializedChangePropertyItem` reaches `FUN_145dda4c0`, which applies/handles the property update. The broader Replicator transport sends packet buffers through connection dispatch (`FUN_145f666f0`), and the `0x83` path is distinct from the user-designated `0x80` path.

The evidence-supported conceptual cycle is: an eligible locally changed/owned property is queued by the local Replicator, encoded as a change item, sent upstream, validated/applied by the server Replicator, then represented to other clients as server-originated Replication. Client-to-client direct P2P was not established. The precise local change-observer scheduler, full ownership/filter rules, coalescing behavior, and complete server fan-out call chain were not recovered in this pass; therefore the statement about the full cycle is an architectural inference from the ClientReplicator/ServerReplicator roles and shared item handlers, not a claim that every local edit is transmitted. No syncing code was added.

## C++ changes

Modified only the join/Replication portion of the portable reconstruction:

- `reconstruction/include/rbx_channel_protocol.hpp`
- `reconstruction/src/rbx_channel_protocol.cpp`
- `reconstruction/tests/test_channel_protocol.cpp`

Added:

- Observed JDI kind tags 1–5. The parser preserves kind-2/3/4 bodies as opaque bytes; it does **not** incorrectly impose the kind-1/5 length format on them.
- A strict parser/serializer for the verified kind-1/kind-5 envelope (`0x83 0x16`, little-endian compressed length, little-endian uncompressed/input length, compressed bytes, optional zero trailer).
- Classification and lossless pass-through for the `0x81` join-start body and `0x83 0x16 <kind>` JDI items.
- A pluggable Zstandard decode interface for kind 1/5 that validates decoded output length. No Zstandard implementation or guessed instance schema is embedded.
- A sink interface that routes recognized messages without applying them to an invented DataModel representation.
- Descriptive enums for the observed Replication cache categories and high-level server join-batch phases (not wire values).

No RBXL writer, place-edit synchronization, or target networking was implemented.

## Validation and limits

- Ran `make clean test` in `/home/user/reconstruction`: all three C++17 test executables passed (`reconstruction_tests`, `channel_protocol_tests`, and `mrd_wire_codec_tests`). The added tests cover join-start preservation, kinds 1–5, kind-1/5 envelope bounds/round-trip, opaque kind-2/3/4 payloads, decoder output-size validation, sink dispatch, and that `0x80` remains unhandled by this join parser.
- This was a portable Linux/GCC static build/test only. No Windows/MSVC build was performed; `cmake` remains unavailable in the workspace.
- The authorized `RobloxStudioBeta.exe` was not executed or modified. Ghidra imported it with `-noanalysis`; analysis was targeted decompilation and static xref scanning only.
- Not recovered: full `0x81` field schema; inner kind-2/3/4 JDI schemas; a complete client-side decompressor/apply implementation; all content/asset delivery; full outbound property-update scheduling and fan-out. The C++ implementation deliberately stops at opaque routing / verified framing.

## Primary workspace evidence

- `/home/user/analysis/join_replication_target_decomp.txt` — join-start, schema, JDI helpers, and receive/apply handlers.
- `/home/user/analysis/join_replication_extras_decomp.txt` — server join coordinator, ReplicationDataCache generator, kind-2/3/4 builder, cache/blob helpers, and property-item code.
- `/home/user/analysis/join_replication_direct_call_xrefs.txt` — direct call edges connecting `FUN_145e4d500`, `FUN_145e33e70`, cache generation, and JDI builders.
- `/home/user/analysis/network_rtti_vtables.txt` — Replicator/ClientReplicator vtable and deserialized item-handler mappings.
- `/home/user/analysis/join_packet_helpers_decomp.txt` and `/home/user/analysis/join_data_helpers_decomp.txt` — retained compressed-envelope helpers for kinds 1 and 5.
- `/home/user/analysis/ghidra_join_replication_extras3_20261016.log` — successful targeted Ghidra `-process` run for the added functions.
