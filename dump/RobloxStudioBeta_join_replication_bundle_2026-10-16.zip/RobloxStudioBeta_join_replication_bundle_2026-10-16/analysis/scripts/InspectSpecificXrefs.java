import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.listing.Function;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;

public class InspectSpecificXrefs extends GhidraScript {
    private static final String[] TARGETS = {
        "148ebf3f0", "148ec0608", "143816d50", "143816e10",
        "143800d00", "1437e3040", "149046790", "144c267d0",
        "144c263c0", "144c262b0", "144c26c00"
    };

    @Override
    public void run() throws Exception {
        String outPath = "/home/user/analysis/specific_xrefs.txt";
        try (java.io.PrintWriter out = new java.io.PrintWriter(outPath)) {
            for (String s : TARGETS) {
                Address target = toAddr(Long.parseUnsignedLong(s, 16));
                out.println("\nTARGET " + s + " @ " + target);
                ReferenceIterator it = currentProgram.getReferenceManager().getReferencesTo(target);
                int n = 0;
                while (it.hasNext() && n < 500) {
                    Reference ref = it.next();
                    Address from = ref.getFromAddress();
                    Function f = currentProgram.getFunctionManager().getFunctionContaining(from);
                    CodeUnit cu = currentProgram.getListing().getCodeUnitAt(from);
                    out.printf("  from=%s type=%s operand=%d function=%s code=%s%n",
                        from, ref.getReferenceType(), ref.getOperandIndex(),
                        f == null ? "<none>" : f.getName() + "@" + f.getEntryPoint(),
                        cu == null ? "<none>" : cu.toString());
                    n++;
                }
                out.println("  count=" + n);
            }
        }
        println("Wrote " + outPath);
    }
}
