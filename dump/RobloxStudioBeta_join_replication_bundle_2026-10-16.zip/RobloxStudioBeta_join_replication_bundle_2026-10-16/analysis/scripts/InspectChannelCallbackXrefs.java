import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;
import java.io.FileWriter;
import java.io.PrintWriter;

public class InspectChannelCallbackXrefs extends GhidraScript {
    private static final String[] TARGETS = {
        "1437763f0", "14377d770", "14377ddd0", "1437984f0", "143798600",
        "143798cf0", "1437982d0", "143798a30", "14378b280", "14378c180",
        "14378a960", "14379ce50", "14379c270", "143799e00",
        "148ebee30", "148ebee38", "148ebee40", "148ebee68", "148ebee70",
        "148ebee78", "148ebee80", "148ebee88", "148ebee90", "148ebee98",
        "142a14bd0", "142a14a70", "142a148e0", "142a15c20", "142a15c60",
        "140003db0", "1400078b0", "14377a140", "14378fb20",
        "143776af0", "1437769f0", "143776620", "1437764a0", "143775f00",
        "148ebed00", "148ebed08", "148ebed10", "148ebed18", "148ebed20",
        "148ebed28", "148ebed30", "148ebed38", "148ebed40", "148ebed48",
        "148ebed50", "148ebed58", "148ebed60", "148ebed68", "148ebed70",
        "148ebed78", "148ebed80", "148ebed88", "148ebee68",
        "14377b290"
    };
    @Override
    public void run() throws Exception {
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/channel_callback_xrefs.txt"))) {
            for (String s : TARGETS) {
                Address target = toAddr(Long.parseUnsignedLong(s, 16));
                out.println("\nTARGET " + s + " @ " + target);
                ReferenceIterator it = currentProgram.getReferenceManager().getReferencesTo(target);
                int n = 0;
                while (it.hasNext() && n < 500) {
                    Reference r = it.next();
                    Address from = r.getFromAddress();
                    Function f = currentProgram.getFunctionManager().getFunctionContaining(from);
                    CodeUnit cu = currentProgram.getListing().getCodeUnitAt(from);
                    out.printf("  from=%s type=%s operand=%d caller=%s code=%s%n", from,
                        r.getReferenceType(), r.getOperandIndex(),
                        f == null ? "<none>" : f.getName() + "@" + f.getEntryPoint(),
                        cu == null ? "<none>" : cu.toString());
                    n++;
                }
                out.println("  count=" + n);
            }
        }
        println("Wrote /home/user/analysis/channel_callback_xrefs.txt");
    }
}
