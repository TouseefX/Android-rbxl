import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileMultiplexedConnectionCallbacks extends GhidraScript {
    private static final String[] VAS = {
        "1437a8160", "1437a89a0", "1437a8350", "1437a8980", "1437a93a0",
        "1437a8df0", "1437a9550", "1437a94b0", "1437a8ce0", "1437a9150",
        "1437a9290", "1437a91f0", "1437a8bd0", "1437a8b40",
        "1437af380", "1437afef0", "1437b0220", "1437afae0", "1437b0090",
        "1437b0020", "1437af9b0", "1437afe20", "1437afe90", "1437af5d0", "1437af450"
    };
    @Override public void run() throws Exception {
        DecompInterface d=new DecompInterface(); d.setOptions(new DecompileOptions()); d.toggleCCode(true); d.toggleSyntaxTree(true); d.setSimplificationStyle("decompile");
        if(!d.openProgram(currentProgram)) throw new Exception("Could not open program");
        FunctionManager fm=currentProgram.getFunctionManager();
        try(PrintWriter out=new PrintWriter(new FileWriter("/home/user/analysis/multiplexed_connection_callbacks.txt"))){
            out.println("Static decompilation of QuicMultiplexedConnection/WtMultiplexedConnection vtable targets. Target not run.");
            for(String s:VAS){
                Address a=currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(s); Function f=fm.getFunctionAt(a);
                out.println("\n\nFUNCTION "+s+" @ "+a);
                if(f==null){out.println("NO FUNCTION ENTRY");continue;}
                out.println("name="+f.getName()+" end="+f.getBody().getMaxAddress()+" signature="+f.getSignature());
                DecompileResults r=d.decompileFunction(f,45,monitor);
                if(r!=null&&r.decompileCompleted()&&r.getDecompiledFunction()!=null)out.println(r.getDecompiledFunction().getC());
                else out.println("DECOMPILATION FAILED: "+(r==null?"null":r.getErrorMessage()));
                System.gc();
            }
        }finally{d.dispose();}
        println("Wrote /home/user/analysis/multiplexed_connection_callbacks.txt");
    }
}
