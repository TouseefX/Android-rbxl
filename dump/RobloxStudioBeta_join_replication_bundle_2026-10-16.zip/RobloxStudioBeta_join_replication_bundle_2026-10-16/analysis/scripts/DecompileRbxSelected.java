import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileRbxSelected extends GhidraScript {
    private static class Target {
        String label;
        String address;
        Target(String label, String address) { this.label = label; this.address = address; }
    }

    @Override
    public void run() throws Exception {
        Target[] targets = {
            new Target("SysUdpSocket vtable slot 0", "1435f18d0"),
            new Target("SysUdpSocket vtable slot 2", "1435f2240"),
            new Target("SysUdpSocket vtable slot 4", "1435f2300"),
            new Target("SysUdpSocket vtable slot 8", "1435f4530"),
            new Target("SysUdpSocket vtable slot 10", "1435f48b0"),
            new Target("SysUdpSocket vtable slot 11", "1435f2010"),
            new Target("SysUdpSocket vtable slot 12", "1435f4bb0"),
            new Target("SysUdpSocket vtable slot 13", "1435f5100"),
            new Target("SysUdpSocket vtable slot 14", "1435f5830"),
            new Target("SysUdpSocket vtable slot 15", "1435f5d00"),
            new Target("SysUdpSocket vtable slot 16", "1435f5950"),
            new Target("SysUdpSocket vtable slot 17", "1435f51f0"),
            new Target("SysUdpSocket vtable slot 18", "1435f2b50"),
            new Target("SysUdpSocket vtable slot 21", "1435f2db0"),
            new Target("LibuvTcpSocket vtable slot 2", "1435feaa0"),
            new Target("LibuvTcpSocket vtable slot 3", "1435fd3d0"),
            new Target("LibuvTcpSocket vtable slot 4", "1435fe9c0"),
            new Target("LibuvTcpSocket vtable slot 5", "1435fec20"),
            new Target("LibuvTcpSocket vtable slot 6", "1435ffa20"),
            new Target("LibuvTcpSocket vtable slot 7", "1435ffec0"),
            new Target("LibuvTcpSocket vtable slot 9", "1435fef20"),
            new Target("LibuvTcpSocket vtable slot 11", "1435ffc50"),
            new Target("LibuvUdpSocket vtable slot 2", "143601860"),
            new Target("LibuvUdpSocket vtable slot 4", "143601910"),
            new Target("LibuvUdpSocket vtable slot 5", "143601570"),
            new Target("LibuvUdpSocket vtable slot 8", "143602810"),
            new Target("LibuvUdpSocket vtable slot 10", "143602a40"),
            new Target("LibuvUdpSocket vtable slot 11", "143601670"),
            new Target("LibuvUdpSocket vtable slot 12", "143602b60"),
            new Target("H3Connection vtable slot 0", "1437d33d0"),
            new Target("H3Connection vtable slot 1", "1437d38b0"),
            new Target("H3Connection vtable slot 2", "1437d5480"),
            new Target("WtSession vtable slot 0", "1437c7a50"),
            new Target("WtSession vtable slot 1", "1437c7bc0"),
            new Target("QUIC crypto client vtable slot 0", "1437e1530"),
            new Target("QUIC crypto client vtable slot 1", "1437e1af0"),
            new Target("QUIC crypto client vtable slot 2", "1437e1710"),
            new Target("RTC IO client connection vtable slot 0", "143793850"),
            new Target("RTC IO client connection vtable slot 2", "143792640"),
            new Target("RTC IO client connection vtable slot 3", "14378ada0"),
            new Target("RTC IO client connection vtable slot 4", "14378fb20"),
            new Target("RTC IO client connection vtable slot 5", "143790020"),
            new Target("RTC IO client connection vtable slot 6", "143781360"),
            new Target("RTC IO client connection vtable slot 8", "1437821e0"),
            new Target("RTC IO client connection vtable slot 9", "143784830"),
            new Target("RTC IO client connection vtable slot 10", "143791b80")
        };

        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program in decompiler");

        FunctionManager fm = currentProgram.getFunctionManager();
        int complete = 0;
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/ghidra_network_decomp.txt"))) {
            out.println("Ghidra decompilation export; functions renamed by the analyst only in this heading.");
            for (Target target : targets) {
                monitor.checkCancelled();
                Address entry = currentProgram.getAddressFactory().getDefaultAddressSpace()
                    .getAddress(Long.parseUnsignedLong(target.address, 16));
                Function f = fm.getFunctionAt(entry);
                if (f == null) f = fm.getFunctionContaining(entry);
                if (currentProgram.getListing().getInstructionAt(entry) == null) {
                    try { disassemble(entry); } catch (Exception ignored) {}
                }
                if (f == null) f = fm.getFunctionAt(entry);
                out.println("\n\n/******** " + target.label + " @ " + entry + " ********/");
                if (f == null) {
                    out.println("NO FUNCTION at entry; instruction=" + currentProgram.getListing().getInstructionAt(entry));
                    continue;
                }
                out.println("Ghidra name=" + f.getName() + " entry=" + f.getEntryPoint());
                out.println("signature=" + f.getSignature());
                DecompileResults result = decomp.decompileFunction(f, 60, monitor);
                if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null) {
                    out.println(result.getDecompiledFunction().getC());
                    complete++;
                } else {
                    out.println("DECOMPILATION FAILED: " + (result == null ? "null result" : result.getErrorMessage()));
                }
            }
            out.println("\ncompleted=" + complete + " requested=" + targets.length);
        } finally {
            decomp.dispose();
        }
        println("Wrote /home/user/analysis/ghidra_network_decomp.txt; completed=" + complete + "/" + targets.length);
    }
}
