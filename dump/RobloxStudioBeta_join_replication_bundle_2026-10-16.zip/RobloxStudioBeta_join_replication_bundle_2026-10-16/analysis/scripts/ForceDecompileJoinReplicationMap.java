import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.SourceType;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class ForceDecompileJoinReplicationMap extends GhidraScript {
    private static final String[] STARTS = {
        "145ea9000", "145ea94b0", "145ea9d50", "145e33e70",
        "145f91af0", "145f94050", "145f944b0", "145dba600",
        "145dd0350", "145fccad0", "145fcca80",
        "145f4fdf0", "145f880c0", "145f88d20", "145f86980",
        "145f7cd60", "145f6dd10", "145f51700", "145f56ca0",
        "145fb7530", "145fb6e90", "145fb3e10"
    };
    private static final String OUT = "/home/user/analysis/join_replication_target_decomp.txt";

    @Override
    public void run() throws Exception {
        MemoryBlock pdata = null;
        for (MemoryBlock b : currentProgram.getMemory().getBlocks()) {
            if (b.getName().equals(".pdata")) { pdata = b; break; }
        }
        if (pdata == null) throw new Exception("No .pdata");
        byte[] bytes = new byte[(int)pdata.getSize()];
        currentProgram.getMemory().getBytes(pdata.getStart(), bytes);
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        long imageBase = currentProgram.getImageBase().getOffset();
        FunctionManager fm = currentProgram.getFunctionManager();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Decompiler open failed");
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT))) {
            for (String s : STARTS) {
                Address start = toAddr(Long.parseUnsignedLong(s, 16));
                long rva = start.getOffset() - imageBase, endRva = -1;
                for (int i = 0; i + 12 <= bytes.length; i += 12) {
                    long begin = Integer.toUnsignedLong(bb.getInt(i));
                    long end = Integer.toUnsignedLong(bb.getInt(i + 4));
                    if (begin == rva && end > begin) { endRva = end; break; }
                }
                out.println("\n\nFUNCTION " + s);
                if (endRva < 0) { out.println("NO_PDATA"); continue; }
                Address end = toAddr(imageBase + endRva - 1);
                AddressSet body = new AddressSet(start, end);
                boolean disassembled = new DisassembleCommand(start, body, true).applyTo(currentProgram, monitor);
                Function f = fm.getFunctionAt(start);
                if (f == null) {
                    try { f = fm.createFunction(null, start, (AddressSetView)body, SourceType.ANALYSIS); }
                    catch (Exception e) { out.println("CREATE_FAILED " + e); }
                } else {
                    try { f.setBody((AddressSetView)body); }
                    catch (Exception e) { out.println("SETBODY_FAILED " + e); }
                }
                out.println("disassembled=" + disassembled + " function=" + (f == null ? "<none>" : f.getName()) + " end=" + end);
                if (f != null) {
                    DecompileResults result = decomp.decompileFunction(f, 60, monitor);
                    if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null)
                        out.println(result.getDecompiledFunction().getC());
                    else out.println("DECOMPILE_FAILED " + (result == null ? "null" : result.getErrorMessage()));
                }
                out.flush();
                System.gc();
            }
        } finally { decomp.dispose(); }
        println("Wrote " + OUT);
    }
}
