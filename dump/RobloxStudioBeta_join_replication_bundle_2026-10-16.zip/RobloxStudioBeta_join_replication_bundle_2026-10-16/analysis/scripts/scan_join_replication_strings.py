#!/usr/bin/env python3
"""Static PE scanner: map selected embedded Roblox network log strings to RIP-relative code refs.
Reads only the authorized executable as data; does not execute it.
"""
import struct, sys, os
sys.path.insert(0, "/home/user/.cache/capstone")
from capstone import Cs, CS_ARCH_X86, CS_MODE_64, x86_const

EXE = "/tmp/RobloxStudioBeta.exe"
OUT = "/home/user/analysis/join_replication_string_xrefs.txt"
IMAGE_BASE = 0x140000000
TEXT_RVA = 0x1000
TEXT_RAW = 0x400
TEXT_SIZE = 0x8822693
PDATA_RVA = 0x14db47000 - IMAGE_BASE
PDATA_RAW = 0x0d0aae00
PDATA_SIZE = 0x4b6fc0
RDATA_RVA = 0x148825000 - IMAGE_BASE
RDATA_RAW = 0x08823600
RDATA_SIZE = 0x0406126c

NEEDLES = [
    b"[FLog::Network] ServerReplicator: Start sending join for peer: %d",
    b"[FLog::Network] ServerReplicator: Start sending join for peer: %p",
    b"Getting Replication Cache and Queue JDI",
    b"Performing player install",
    b"ServerReplicator::sendNetworkSchemaDefinition",
    b"[FLog::Network] Serializing Instances and preparing blobs for JoinDataItemV2",
    b"Replicator::processDeserializedJoinDataItem() : Procsssing DeserializedJoinDataItem",
    b"Replicator::processDeserializedJoinDataItem() :  will process newInstanceItem",
    b"Replicator::processDeserializedJoinDataItem() took {} ms",
    b"JoinDataItemV2::getReadyBitStream: readyBitstreamList size: %d",
    b"ReplicationDataBlob::requeueInstancesForBlobbing(blob)",
    b"ReplicationDataBlob::remove(mrd)",
]

with open(EXE, "rb") as f:
    raw = f.read()

strings = {}
for needle in NEEDLES:
    offs=[]
    pos=0
    while True:
        pos=raw.find(needle, pos)
        if pos<0: break
        if RDATA_RAW <= pos < RDATA_RAW+RDATA_SIZE:
            va=IMAGE_BASE + RDATA_RVA + (pos-RDATA_RAW)
            offs.append((pos,va))
        pos += 1
    strings[needle.decode("ascii", "replace")] = offs

md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = True
refs = {va:[] for arr in strings.values() for _,va in arr}
functions=[]
for off in range(PDATA_RAW, PDATA_RAW+PDATA_SIZE, 12):
    begin,end,unwind=struct.unpack_from("<III",raw,off)
    if not (TEXT_RVA <= begin < end <= TEXT_RVA+TEXT_SIZE):
        continue
    functions.append((IMAGE_BASE+begin,IMAGE_BASE+end,begin,end))

# Process each exact .pdata function body once, using its true start to keep instruction alignment.
for va_start,va_end,begin,end in functions:
    code_off = TEXT_RAW + begin-TEXT_RVA
    code = raw[code_off:code_off+(end-begin)]
    for insn in md.disasm(code, va_start):
        for op in insn.operands:
            if op.type == x86_const.X86_OP_MEM and op.mem.base == x86_const.X86_REG_RIP:
                target = insn.address + insn.size + op.mem.disp
                if target in refs:
                    refs[target].append((va_start,va_end,insn.address,insn.mnemonic,insn.op_str))

with open(OUT,"w") as f:
    f.write(f"EXE SHA256 target expected: cc70176d50d5f2c1edc26d40f1fcdc530748fc83dedc63c2fdbb251f766972d2\n")
    f.write(f".text .pdata functions scanned: {len(functions)}\n")
    for label,arr in strings.items():
        f.write(f"\nSTRING {label!r}\n")
        for fo,va in arr:
            f.write(f"  file=0x{fo:x} VA=0x{va:x} xrefs={len(refs.get(va,[]))}\n")
            for fs,fe,ia,mn,opstr in refs.get(va,[]):
                f.write(f"    fn=0x{fs:x}-0x{fe:x} ref=0x{ia:x}: {mn} {opstr}\n")
print(OUT, "functions",len(functions),"strings",sum(map(len,strings.values())),"refs",sum(map(len,refs.values())))
