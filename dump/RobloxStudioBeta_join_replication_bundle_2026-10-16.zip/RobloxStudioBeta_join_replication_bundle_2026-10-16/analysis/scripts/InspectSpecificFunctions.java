import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;

public class InspectSpecificFunctions extends GhidraScript {
    private static final String[] TARGETS = {
        "14379c2ab", "14379c270", "1437a766f", "1437a75b4",
        "1437a799e", "143816c7d", "143816c30", "143816c00",
        "143816d50", "143816e10", "143816d30", "1437e3ec0",
        "143784890", "1437e4070", "1437860d0", "1437a6e20",
        "14378b774", "14378c482", "143791ad9", "143792814",
        "14378d794", "14378d9e1", "14378bd23", "14379863c", "143799daf",
        "14378a47b", "143798575", "14379858b",
        "1437824d0", "143785e50", "143785200", "143785af0", "143798a30",
        "14377a424", "14377a43e", "14377ab75", "14377b2fa",
        "14377ad33", "14377b182", "14377b511", "14d8a9a50"
    };

    @Override
    public void run() throws Exception {
        String outPath = "/home/user/analysis/specific_functions.txt";
        MemoryBlock pdata = null;
        for (MemoryBlock b : currentProgram.getMemory().getBlocks()) {
            if (b.getName().equals(".pdata")) { pdata = b; break; }
        }
        byte[] pdataBytes = null;
        if (pdata != null && pdata.getSize() <= Integer.MAX_VALUE) {
            pdataBytes = new byte[(int)pdata.getSize()];
            currentProgram.getMemory().getBytes(pdata.getStart(), pdataBytes);
        }
        long imageBase = currentProgram.getImageBase().getOffset();
        try (java.io.PrintWriter out = new java.io.PrintWriter(outPath)) {
            for (String s : TARGETS) {
                Address addr = toAddr(Long.parseUnsignedLong(s, 16));
                Function f = currentProgram.getFunctionManager().getFunctionContaining(addr);
                out.println("\nADDRESS " + s + " function=" +
                    (f == null ? "<none>" : f.getName() + " entry=" + f.getEntryPoint() +
                     " body=" + f.getBody().getMinAddress() + ".." + f.getBody().getMaxAddress()));
                if (s.equalsIgnoreCase("14d8a9a50")) {
                    out.print("  global bytes=");
                    for (int i = 0; i < 16; i++) out.printf("%02x ", currentProgram.getMemory().getByte(addr.add(i)) & 0xff);
                    out.println();
                }
                if (pdataBytes != null) {
                    long rva = addr.getOffset() - imageBase;
                    java.nio.ByteBuffer bb = java.nio.ByteBuffer.wrap(pdataBytes).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                    for (int i = 0; i + 12 <= pdataBytes.length; i += 12) {
                        long begin = Integer.toUnsignedLong(bb.getInt(i));
                        long end = Integer.toUnsignedLong(bb.getInt(i + 4));
                        if (begin != 0 && end > begin && begin <= rva && rva < end) {
                            out.printf("  pdata=%x..%x rva=%x%n", imageBase + begin, imageBase + end, rva);
                            break;
                        }
                    }
                }
                ReferenceIterator it = currentProgram.getReferenceManager().getReferencesTo(addr);
                int n = 0;
                while (it.hasNext() && n < 100) {
                    Reference r = it.next();
                    Function caller = currentProgram.getFunctionManager().getFunctionContaining(r.getFromAddress());
                    out.printf("  xref %s %s caller=%s%n", r.getFromAddress(), r.getReferenceType(),
                        caller == null ? "<none>" : caller.getName() + "@" + caller.getEntryPoint());
                    n++;
                }
                if (n == 0) out.println("  xref count=0");
            }
        }
        println("Wrote " + outPath);
    }
}
