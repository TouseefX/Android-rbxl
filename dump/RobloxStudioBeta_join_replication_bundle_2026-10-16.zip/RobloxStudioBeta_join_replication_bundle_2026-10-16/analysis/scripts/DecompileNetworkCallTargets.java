import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.Map;

public class DecompileNetworkCallTargets extends GhidraScript {
    private static final String OUT_FILE = "/home/user/analysis/network_call_targets_decomp.txt";
    private static final String[] VAS = {
        "145da5400", "145db1760", "145dd49d0", "145dd4cd0", "145df3070",
        "145def760", "145deecd0", "145f1efa0", "145df8e80", "145f94970",
        "145f68610", "145dbf4d0", "145daff90", "145e7a030", "145f91af0",
        "145f90d50", "145fccad0", "1477579e0", "147757c20", "147757cd0",
        "147757680", "145da98a0", "145e7a180", "142a0f3d0", "144c25af0",
        "1437e2f00", "1437e3040", "1437e3ec0", "1437e4070",
        "143800d00", "143800de0", "143781c70", "143784890",
        "143799c90", "143799e00", "143779d00", "143776eb0",
        "1437860d0", "14377ff60", "1437824d0", "143785e50",
        "143785200", "143785af0", "143798a30"
    };

    @Override
    public void run() throws Exception {
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program in decompiler");
        FunctionManager fm = currentProgram.getFunctionManager();
        Map<String, Boolean> seen = new LinkedHashMap<>();
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT_FILE))) {
            out.println("Call-target decompilation leads selected from Replicator packet handling and join-item vtables. No target executable was run.");
            for (String text : VAS) {
                if (seen.putIfAbsent(text, Boolean.TRUE) != null) continue;
                Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(text);
                Function f = fm.getFunctionAt(a);
                out.println("\n\n/******** CALL TARGET @ " + a + " ********/");
                if (f == null) {
                    out.println("NO FUNCTION ENTRY; not decompiled by this script");
                    continue;
                }
                out.println("Ghidra name=" + f.getName() + " entry=" + f.getEntryPoint() + " bodyAddresses=" + f.getBody().getNumAddresses());
                out.println("signature=" + f.getSignature());
                DecompileResults result = decomp.decompileFunction(f, 30, monitor);
                if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null) {
                    out.println(result.getDecompiledFunction().getC());
                } else {
                    out.println("DECOMPILATION FAILED: " + (result == null ? "null result" : result.getErrorMessage()));
                }
                System.gc();
            }
            out.println("\nsummary requested=" + seen.size());
        } finally {
            decomp.dispose();
        }
        println("Wrote " + OUT_FILE + "; requested=" + seen.size());
    }
}
