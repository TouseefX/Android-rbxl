import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileRbxSysTcp extends GhidraScript {
    private static class T {String name,va; T(String n,String v){name=n;va=v;}}
    @Override public void run() throws Exception {
        T[] ts={
            new T("SysTcpSocket vtable slot 0", "1435ed2c0"),
            new T("SysTcpSocket vtable slot 2", "1435ed2f0"),
            new T("SysTcpSocket vtable slot 4", "1435eb9a0"),
            new T("SysTcpSocket vtable slot 5", "1435ed4a0"),
            new T("SysTcpSocket vtable slot 6", "1435eef10"),
            new T("SysTcpSocket vtable slot 7", "1435ef520"),
            new T("SysTcpSocket vtable slot 8", "1435ef420"),
            new T("SysTcpSocket vtable slot 9", "1435ebe60"),
            new T("SysTcpSocket vtable slot 10", "1435ed9f0"),
            new T("SysTcpSocket vtable slot 11", "1435ef2c0"),
            new T("SysTcpSocket vtable slot 12", "1435edb60"),
            new T("SysTcpSocket vtable slot 13", "1435ec000"),
            new T("SysTcpSocket vtable slot 14", "1435edc60")
        };
        DecompInterface d=new DecompInterface(); d.setOptions(new DecompileOptions()); d.toggleCCode(true); d.toggleSyntaxTree(true); d.setSimplificationStyle("decompile");
        if(!d.openProgram(currentProgram)) throw new Exception("decompiler open failed");
        FunctionManager fm=currentProgram.getFunctionManager(); int ok=0;
        try(PrintWriter out=new PrintWriter(new FileWriter("/home/user/analysis/ghidra_sys_tcp_decomp.txt"))) {
            for(T t:ts){
                monitor.checkCancelled();
                Address a=currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(Long.parseUnsignedLong(t.va,16));
                Function f=fm.getFunctionAt(a); if(f==null) f=fm.getFunctionContaining(a);
                if(currentProgram.getListing().getInstructionAt(a)==null){try{disassemble(a);}catch(Exception ignored){}}
                if(f==null) f=fm.getFunctionAt(a);
                out.println("\n\n/******** "+t.name+" @ "+a+" ********/");
                if(f==null){out.println("NO FUNCTION");continue;}
                out.println("Ghidra name="+f.getName()+" entry="+f.getEntryPoint()); out.println("signature="+f.getSignature());
                DecompileResults r=d.decompileFunction(f,60,monitor);
                if(r!=null&&r.decompileCompleted()&&r.getDecompiledFunction()!=null){out.println(r.getDecompiledFunction().getC());ok++;} else out.println("FAILED: "+(r==null?"null":r.getErrorMessage()));
            }
            out.println("\ncompleted="+ok+" requested="+ts.length);
        }finally{d.dispose();}
        println("Wrote /home/user/analysis/ghidra_sys_tcp_decomp.txt; completed="+ok+"/"+ts.length);
    }
}
