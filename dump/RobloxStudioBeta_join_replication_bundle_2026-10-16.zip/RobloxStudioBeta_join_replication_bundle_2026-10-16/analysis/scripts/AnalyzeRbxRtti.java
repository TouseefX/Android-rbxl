import ghidra.app.plugin.prototype.MicrosoftCodeAnalyzerPlugin.RttiAnalyzer;
import ghidra.app.script.GhidraScript;
import ghidra.app.util.importer.MessageLog;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.symbol.SymbolIterator;
import java.io.FileWriter;
import java.io.PrintWriter;

public class AnalyzeRbxRtti extends GhidraScript {
    @Override
    public void run() throws Exception {
        println("Running Ghidra Microsoft RTTI analyzer on imported PE metadata");
        RttiAnalyzer analyzer = new RttiAnalyzer();
        AddressSetView loaded = currentProgram.getMemory().getLoadedAndInitializedAddressSet();
        analyzer.added(currentProgram, loaded, monitor, new MessageLog());

        int rbxSymbols = 0;
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/rbx_rtti_symbols.txt"))) {
            out.println("program=" + currentProgram.getName());
            out.println("functions=" + currentProgram.getFunctionManager().getFunctionCount());
            SymbolIterator symbols = currentProgram.getSymbolTable().getAllSymbols(true);
            while (symbols.hasNext()) {
                Symbol symbol = symbols.next();
                String full = symbol.getName(true);
                if (full.contains("RbxTransport")) {
                    out.println(symbol.getAddress() + "\t" + symbol.getSymbolType() + "\t" + full);
                    rbxSymbols++;
                }
            }
            out.println("rbxSymbolCount=" + rbxSymbols);
        }
        println("Wrote /home/user/analysis/rbx_rtti_symbols.txt; RbxTransport symbols=" + rbxSymbols);
    }
}
