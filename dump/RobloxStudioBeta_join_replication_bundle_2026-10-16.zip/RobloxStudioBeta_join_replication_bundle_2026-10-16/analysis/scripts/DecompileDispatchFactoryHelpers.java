import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileDispatchFactoryHelpers extends GhidraScript {
    @Override public void run() throws Exception {
        String[] vas = {"1437e37b0", "1437e3850", "1437e29d0", "143800810", "1437a15b0", "1437a1220"};
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");
        FunctionManager fm = currentProgram.getFunctionManager();
        String outPath = "/home/user/analysis/dispatch_factory_helpers.txt";
        try (PrintWriter out = new PrintWriter(new FileWriter(outPath))) {
            out.println("Static decompilation of listener/dispatcher factory helpers. Target not executed.");
            for (String s : vas) {
                Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(Long.parseUnsignedLong(s, 16));
                Function f = fm.getFunctionAt(a);
                out.println("\n\nFUNCTION " + a);
                if (f == null) { out.println("NO FUNCTION ENTRY"); continue; }
                out.println("name=" + f.getName() + " end=" + f.getBody().getMaxAddress() + " signature=" + f.getSignature());
                DecompileResults r = decomp.decompileFunction(f, 60, monitor);
                if (r != null && r.decompileCompleted() && r.getDecompiledFunction() != null) out.println(r.getDecompiledFunction().getC());
                else out.println("DECOMPILATION FAILED: " + (r == null ? "null" : r.getErrorMessage()));
                System.gc();
            }
        } finally { decomp.dispose(); }
        println("Wrote " + outPath);
    }
}
