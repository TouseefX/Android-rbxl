import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;
import ghidra.program.model.symbol.ReferenceManager;
import ghidra.program.model.symbol.SourceType;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ForceDecompileMrdSemanticTrace extends GhidraScript {
    private static final String[][] RANGES = {
        {"143079290", "1430792af", "Mrd parser input wrapper"},
        {"1430792b0", "143079533", "Mrd parser feed and dispatch"},
        {"143079540", "14307982b", "Mrd input-format dispatcher"},
        {"1430790a0", "143079284", "outer Mrd parser consumer"},
        {"143077dc0", "143078478", "Mrd decoded-item/network dispatch bridge"},
        {"14307a700", "14307a902", "0x80 history-reference item builder"},
        {"14307ab00", "14307ace5", "neighboring 0xc0 static-table item builder"},
        {"14307a4e0", "14307a6fd", "Mrd item-pair operation"},
        {"14307a910", "14307aaf3", "Mrd item append operation"},
        {"143082f50", "1430831d1", "outer Mrd record builder"},
        {"143081e00", "14308223e", "outer Mrd record-builder caller"}
    };
    private static final String[] XREFS = {
        "143077dc0", "1430790a0", "1430792b0", "143079540", "143079fe0",
        "14307a700", "14307ab00", "143082f50"
    };
    private static final String OUT = "/home/user/analysis/mrd_0x80_semantic_trace.txt";

    private void printXrefs(PrintWriter out, ReferenceManager rm, Address target) {
        out.println("REFERENCES TO " + target + ":");
        ReferenceIterator refs = rm.getReferencesTo(target);
        int count = 0;
        while (refs.hasNext() && count < 2000) {
            Reference r = refs.next();
            out.println("  " + r.getFromAddress() + " " + r.getReferenceType());
            count++;
        }
        if (count == 0) out.println("  (none recorded in this imported pass)");
    }

    @Override
    public void run() throws Exception {
        FunctionManager fm = currentProgram.getFunctionManager();
        ReferenceManager rm = currentProgram.getReferenceManager();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT))) {
            out.println("Targeted static decompilation for Mrd tag/history and Network dispatch context.");
            out.println("No target code was executed or modified; semantic names remain provisional.");
            for (String[] row : RANGES) {
                monitor.checkCancelled();
                Address start = toAddr(Long.parseUnsignedLong(row[0], 16));
                Address end = toAddr(Long.parseUnsignedLong(row[1], 16));
                AddressSet body = new AddressSet(start, end);
                List<Address> remove = new ArrayList<>();
                java.util.Iterator<Function> fit = fm.getFunctionsOverlapping((AddressSetView)body);
                while (fit.hasNext()) {
                    Function old = fit.next();
                    if (!old.getEntryPoint().equals(start)) remove.add(old.getEntryPoint());
                }
                for (Address a : remove) fm.removeFunction(a);
                boolean disassembled = new DisassembleCommand(start, body, true).applyTo(currentProgram, monitor);
                Function f = fm.getFunctionAt(start);
                if (f == null) f = fm.createFunction(null, start, (AddressSetView)body, SourceType.ANALYSIS);
                else f.setBody((AddressSetView)body);
                out.println("\n\nFUNCTION " + row[0] + "-" + row[1] + " (" + row[2] + ")");
                out.println("disassembled=" + disassembled + " name=" + f.getName() + " bodyBytes=" + f.getBody().getNumAddresses());
                out.println("-- listing --");
                InstructionIterator it = currentProgram.getListing().getInstructions(body, true);
                while (it.hasNext()) {
                    Instruction ins = it.next();
                    out.println(ins.getAddress() + "  " + ins);
                }
                out.println("-- decompilation --");
                DecompileResults result = decomp.decompileFunction(f, 180, monitor);
                if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null)
                    out.println(result.getDecompiledFunction().getC());
                else out.println("DECOMPILATION_FAILED " + (result == null ? "null" : result.getErrorMessage()));
                System.gc();
            }
            out.println("\n\n-- static xrefs (when present in imported disassembly) --");
            for (String hex : XREFS) {
                printXrefs(out, rm, toAddr(Long.parseUnsignedLong(hex, 16)));
            }
        } finally { decomp.dispose(); }
        println("Wrote " + OUT);
    }
}
