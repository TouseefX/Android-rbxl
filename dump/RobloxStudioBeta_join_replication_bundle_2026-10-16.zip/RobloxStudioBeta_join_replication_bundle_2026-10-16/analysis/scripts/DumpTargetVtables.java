import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class DumpTargetVtables extends GhidraScript {
    private byte[] littleEndian(long value, int bytes) {
        ByteBuffer b = ByteBuffer.allocate(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (bytes == 4) b.putInt((int)value); else b.putLong(value);
        return b.array();
    }

    private boolean isCode(Memory memory, long va) {
        try {
            Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(va);
            MemoryBlock b = memory.getBlock(a);
            return b != null && b.isExecute();
        } catch (Exception e) { return false; }
    }

    @Override
    public void run() throws Exception {
        String[] types = {
            ".?AVTcpSocketInterface@Impl@Io@RbxTransport@RBX@@",
            ".?AVUdpSocketInterface@Impl@Io@RbxTransport@RBX@@",
            ".?AVSysTcpSocket@Impl@Io@RbxTransport@RBX@@",
            ".?AVSysUdpSocket@Impl@Io@RbxTransport@RBX@@",
            ".?AVLibuvTcpSocket@Impl@Io@RbxTransport@RBX@@",
            ".?AVLibuvUdpSocket@Impl@Io@RbxTransport@RBX@@",
            ".?AVQuicClientConnection@Protocol@RbxTransport@RBX@@",
            ".?AVQuicServerConnection@Protocol@RbxTransport@RBX@@",
            ".?AVH3Connection@Http@RbxTransport@RBX@@",
            ".?AVWtSession@Http@RbxTransport@RBX@@",
            ".?AVTlsContext@Tls@Protocol@RbxTransport@RBX@@",
            ".?AVRtcIoClientConnection@Impl@RbxTransport@RBX@@",
            ".?AVRtcIoServerConnection@Impl@RbxTransport@RBX@@",
            ".?AVRtcIoQuicClientConnection@Impl@RbxTransport@RBX@@",
            ".?AVRtcIoWtClientConnection@Impl@RbxTransport@RBX@@",
            ".?AVQuicCryptoClientContext@Protocol@RbxTransport@RBX@@",
            ".?AVQuicCryptoServerContext@Protocol@RbxTransport@RBX@@",
            ".?AVRnaInterface@RbxTransport@RBX@@"
        };
        Memory memory = currentProgram.getMemory();
        FunctionManager fm = currentProgram.getFunctionManager();
        long imageBase = currentProgram.getImageBase().getOffset();
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/rbx_vtables.txt"))) {
            out.println("imageBase=" + currentProgram.getImageBase());
            for (String type : types) {
                out.println("\nTYPE " + type);
                byte[] nameBytes = type.getBytes("US-ASCII");
                int nameMatches = 0;
                for (MemoryBlock b : memory.getBlocks()) {
                    if (!b.isInitialized()) continue;
                    Address search = b.getStart();
                    while (search.compareTo(b.getEnd()) <= 0 && nameMatches < 16) {
                        Address nameAddr = memory.findBytes(search, b.getEnd(), nameBytes, null, true, monitor);
                        if (nameAddr == null) break;
                        nameMatches++;
                        out.println("  name @ " + nameAddr + " block=" + b.getName());
                        Address td = nameAddr.subtract(16);
                        long typeInfoVftable = memory.getLong(td);
                        long spare = memory.getLong(td.add(8));
                        out.println("    typeDescriptor=" + td + " typeInfoVftable=0x" + Long.toHexString(typeInfoVftable) + " spare=0x" + Long.toHexString(spare));
                        long tdRva = td.getOffset() - imageBase;
                        byte[] rvaBytes = littleEndian(tdRva, 4);
                        int colMatches = 0;
                        for (MemoryBlock scan : memory.getBlocks()) {
                            if (!scan.isInitialized() || !(scan.getName().equals(".rdata") || scan.getName().equals(".data") || scan.getName().equals(".text"))) continue;
                            Address pos = scan.getStart();
                            while (pos.compareTo(scan.getEnd()) <= 0 && colMatches < 64) {
                                Address ref = memory.findBytes(pos, scan.getEnd(), rvaBytes, null, true, monitor);
                                if (ref == null) break;
                                Address col = ref.subtract(12);
                                try {
                                    int signature = memory.getInt(col);
                                    int foundTdRva = memory.getInt(col.add(12));
                                    if (signature == 1 && foundTdRva == (int)tdRva) {
                                        colMatches++;
                                        out.println("    COL @ " + col + " (ref " + ref + ")");
                                        byte[] colPtrBytes = littleEndian(col.getOffset(), 8);
                                        for (MemoryBlock scan2 : memory.getBlocks()) {
                                            if (!scan2.isInitialized() || !(scan2.getName().equals(".rdata") || scan2.getName().equals(".data"))) continue;
                                            Address p = scan2.getStart();
                                            int vftableMatches = 0;
                                            while (p.compareTo(scan2.getEnd()) <= 0 && vftableMatches < 8) {
                                                Address colPtr = memory.findBytes(p, scan2.getEnd(), colPtrBytes, null, true, monitor);
                                                if (colPtr == null) break;
                                                Address vf = colPtr.add(8);
                                                long first = memory.getLong(vf);
                                                if (isCode(memory, first)) {
                                                    vftableMatches++;
                                                    out.println("      vftable @ " + vf + " block=" + scan2.getName());
                                                    for (int slot = 0; slot < 32; slot++) {
                                                        Address slotAddr = vf.add(slot * 8L);
                                                        long fnVa = memory.getLong(slotAddr);
                                                        if (!isCode(memory, fnVa)) break;
                                                        Address fnAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(fnVa);
                                                        Function f = fm.getFunctionAt(fnAddr);
                                                        if (f == null) f = fm.getFunctionContaining(fnAddr);
                                                        out.println("        slot=" + slot + " ptr=" + fnAddr + " func=" + (f == null ? "<none>" : f.getName()+" @ "+f.getEntryPoint()));
                                                    }
                                                }
                                                p = colPtr.add(8);
                                            }
                                        }
                                    }
                                } catch (Exception ignored) {}
                                pos = ref.add(1);
                            }
                        }
                        search = nameAddr.add(nameBytes.length);
                    }
                }
                out.println("  nameMatches=" + nameMatches);
            }
            out.println("\nfunctionCount=" + fm.getFunctionCount());
        }
        println("Wrote /home/user/analysis/rbx_vtables.txt");
    }
}
