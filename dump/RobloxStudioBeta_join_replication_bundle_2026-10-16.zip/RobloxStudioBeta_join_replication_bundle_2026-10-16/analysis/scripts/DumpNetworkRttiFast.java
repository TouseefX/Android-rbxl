import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class DumpNetworkRttiFast extends GhidraScript {
    private static final class TypeInfo {
        final String decorated;
        final long nameAddress;
        final long tdAddress;
        final int tdRva;
        TypeInfo(String name, long nameVa, long tdVa, int rva) {
            decorated = name; nameAddress = nameVa; tdAddress = tdVa; tdRva = rva;
        }
    }

    private static byte[] readBlock(Memory memory, MemoryBlock block) throws Exception {
        long n = block.getSize();
        if (n > Integer.MAX_VALUE) throw new Exception("block too large: " + block.getName());
        byte[] bytes = new byte[(int)n];
        memory.getBytes(block.getStart(), bytes);
        return bytes;
    }

    private static int u32le(byte[] b, int i) {
        return (b[i] & 0xff) | ((b[i+1] & 0xff) << 8) |
               ((b[i+2] & 0xff) << 16) | (b[i+3] << 24);
    }

    private static long u64le(byte[] b, int i) {
        return ((long)u32le(b, i) & 0xffffffffL) |
               (((long)u32le(b, i + 4) & 0xffffffffL) << 32);
    }

    private static boolean targetTypeName(String s) {
        return s.contains("@Network@RBX@@") || s.contains("Network@RBX@@") ||
               s.contains("NetworkBase@RBX@@") || s.contains("@RbxTransport@RBX@@") ||
               s.contains("RbxTransport@RBX@@");
    }

    private static boolean isDataForRtti(MemoryBlock b) {
        String n = b.getName();
        return b.isInitialized() && (n.equals(".data") || n.equals(".rdata") ||
               n.equals("_RDATA") || n.equals(".rodata"));
    }

    private boolean isCode(Memory memory, long va) {
        try {
            Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(va);
            MemoryBlock b = memory.getBlock(a);
            return b != null && b.isExecute();
        } catch (Exception e) { return false; }
    }

    @Override
    public void run() throws Exception {
        Memory memory = currentProgram.getMemory();
        long imageBase = currentProgram.getImageBase().getOffset();
        FunctionManager fm = currentProgram.getFunctionManager();
        List<MemoryBlock> dataBlocks = new ArrayList<>();
        for (MemoryBlock block : memory.getBlocks()) if (isDataForRtti(block)) dataBlocks.add(block);

        Map<Long, TypeInfo> typesByNameVa = new TreeMap<>();
        Map<Integer, List<TypeInfo>> typesByRva = new HashMap<>();

        // Single pass through initialized non-executable data blocks for MSVC
        // decorated class/struct names; no global RTTI pattern analyzer is run.
        for (MemoryBlock block : dataBlocks) {
            monitor.checkCancelled();
            byte[] b = readBlock(memory, block);
            for (int i = 0; i + 4 < b.length; i++) {
                if (b[i] != '.' || b[i+1] != '?' || b[i+2] != 'A') continue;
                int end = i;
                while (end < b.length && b[end] != 0 && end - i < 65536) end++;
                if (end == b.length || end - i < 5) continue;
                String name = new String(b, i, end - i, StandardCharsets.US_ASCII);
                if (!targetTypeName(name)) continue;
                long nameVa = block.getStart().getOffset() + i;
                long tdVa = nameVa - 16;
                if (tdVa < imageBase) continue;
                int rva = (int)(tdVa - imageBase);
                TypeInfo info = new TypeInfo(name, nameVa, tdVa, rva);
                if (typesByNameVa.putIfAbsent(nameVa, info) == null)
                    typesByRva.computeIfAbsent(rva, k -> new ArrayList<>()).add(info);
                i = end;
            }
        }

        // One aligned scan for CompleteObjectLocator records. The TypeDescriptor
        // RVA is at COL+12 in PE32+ RTTI; the signature must be 1.
        Map<Long, List<TypeInfo>> colTypes = new TreeMap<>();
        for (MemoryBlock block : dataBlocks) {
            monitor.checkCancelled();
            byte[] b = readBlock(memory, block);
            long blockVa = block.getStart().getOffset();
            for (int i = 12; i + 4 <= b.length; i += 4) {
                int rva = u32le(b, i);
                List<TypeInfo> candidates = typesByRva.get(rva);
                if (candidates == null) continue;
                int colOffset = i - 12;
                if (u32le(b, colOffset) != 1) continue;
                long colVa = blockVa + colOffset;
                colTypes.put(colVa, candidates);
            }
        }

        Set<Long> colAddresses = new HashSet<>(colTypes.keySet());
        Map<Long, List<Long>> vtablesByCol = new TreeMap<>();
        // One pointer scan to find COL references immediately before vftables.
        for (MemoryBlock block : dataBlocks) {
            monitor.checkCancelled();
            byte[] b = readBlock(memory, block);
            long blockVa = block.getStart().getOffset();
            for (int i = 0; i + 16 <= b.length; i += 8) {
                long value = u64le(b, i);
                if (!colAddresses.contains(value)) continue;
                long vfVa = blockVa + i + 8;
                long first;
                try { first = memory.getLong(currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(vfVa)); }
                catch (Exception e) { continue; }
                if (isCode(memory, first))
                    vtablesByCol.computeIfAbsent(value, k -> new ArrayList<>()).add(vfVa);
            }
        }

        int totalSlots = 0;
        Set<Long> distinctFunctions = new TreeSet<>();
        int vtableCount = 0;
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/network_rtti_vtables.txt"))) {
            out.println("program=" + currentProgram.getName());
            out.println("imageBase=0x" + Long.toHexString(imageBase));
            out.println("functionCount=" + fm.getFunctionCount());
            out.println("typeDescriptorNames=" + typesByNameVa.size());
            out.println("completeObjectLocators=" + colTypes.size());
            for (Map.Entry<Long, List<TypeInfo>> entry : colTypes.entrySet()) {
                long colVa = entry.getKey();
                List<TypeInfo> infos = entry.getValue();
                out.println("\nCOL @ 0x" + Long.toHexString(colVa) +
                            " types=" + infos.size() +
                            " vtables=" + (vtablesByCol.containsKey(colVa) ? vtablesByCol.get(colVa).size() : 0));
                for (TypeInfo info : infos)
                    out.println("  TYPE " + info.decorated + "\n    name @ 0x" + Long.toHexString(info.nameAddress) +
                                " typeDescriptor @ 0x" + Long.toHexString(info.tdAddress) +
                                " rva=0x" + Integer.toHexString(info.tdRva));
                List<Long> vtables = vtablesByCol.getOrDefault(colVa, new ArrayList<>());
                for (long vfVa : vtables) {
                    vtableCount++;
                    out.println("  VFTABLE @ 0x" + Long.toHexString(vfVa));
                    for (int slot = 0; slot < 128; slot++) {
                        long slotVa = vfVa + slot * 8L;
                        long fnVa;
                        try { fnVa = memory.getLong(currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(slotVa)); }
                        catch (Exception e) { break; }
                        if (!isCode(memory, fnVa)) break;
                        totalSlots++;
                        distinctFunctions.add(fnVa);
                        Address fnAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(fnVa);
                        Function f = fm.getFunctionAt(fnAddr);
                        if (f == null) f = fm.getFunctionContaining(fnAddr);
                        out.println("    slot=" + slot + " ptr=0x" + Long.toHexString(fnVa) +
                                    " func=" + (f == null ? "<none>" : f.getName() + " @ " + f.getEntryPoint()));
                    }
                }
            }
            out.println("\nsummary typeDescriptorNames=" + typesByNameVa.size() +
                        " COLs=" + colTypes.size() + " vftables=" + vtableCount +
                        " slots=" + totalSlots + " distinctFunctionPointers=" + distinctFunctions.size());
            for (long fn : distinctFunctions) out.println("FUNCTION_PTR 0x" + Long.toHexString(fn));
        }
        println("Wrote /home/user/analysis/network_rtti_vtables.txt; typeNames=" + typesByNameVa.size() +
                " COLs=" + colTypes.size() + " vftables=" + vtableCount +
                " slots=" + totalSlots + " uniqueFns=" + distinctFunctions.size());
    }
}
