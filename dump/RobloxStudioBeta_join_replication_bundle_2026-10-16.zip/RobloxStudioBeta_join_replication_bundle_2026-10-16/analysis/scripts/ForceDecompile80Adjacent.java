import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.SourceType;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Targeted static inspection of selected functions that contain byte 0x80
 * stores/bit operations found by raw objdump search. This deliberately does
 * not infer that any occurrence is the user's wire tag/opcode.
 */
public class ForceDecompile80Adjacent extends GhidraScript {
    private static final String[] STARTS = {
        "14307bf76", "14307e370", "14307e500", "1435baeb0", "1435ba7a0",
        "14307f660", "143084870", "143084970", "14307f3b0", "14307f430"
    };
    private static final String OUT = "/home/user/analysis/0x80_adjacent_functions_decomp.txt";

    @Override
    public void run() throws Exception {
        MemoryBlock pdata = null;
        for (MemoryBlock b : currentProgram.getMemory().getBlocks()) {
            if (b.getName().equals(".pdata")) { pdata = b; break; }
        }
        if (pdata == null) throw new Exception("No .pdata block");
        byte[] bytes = new byte[(int)pdata.getSize()];
        currentProgram.getMemory().getBytes(pdata.getStart(), bytes);
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        long imageBase = currentProgram.getImageBase().getOffset();
        FunctionManager fm = currentProgram.getFunctionManager();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");

        try (PrintWriter out = new PrintWriter(new FileWriter(OUT))) {
            out.println("Targeted decompilation of raw-immediate 0x80 candidate functions. No occurrence is classified as the designated wire tag without matching producer/consumer evidence.");
            out.println("program=" + currentProgram.getName() + " imageBase=0x" + Long.toHexString(imageBase));
            for (String s : STARTS) {
                monitor.checkCancelled();
                Address start = toAddr(Long.parseUnsignedLong(s, 16));
                long rva = start.getOffset() - imageBase;
                long endRva = -1;
                for (int i = 0; i + 12 <= bytes.length; i += 12) {
                    long begin = Integer.toUnsignedLong(bb.getInt(i));
                    long end = Integer.toUnsignedLong(bb.getInt(i + 4));
                    if (begin == rva && end > begin) { endRva = end; break; }
                }
                out.println("\n\nFUNCTION " + s);
                if (endRva < 0) { out.println("NO_EXACT_PDATA_ENTRY"); continue; }
                Address end = toAddr(imageBase + endRva - 1);
                AddressSet body = new AddressSet(start, end);
                boolean disassembled = new DisassembleCommand(start, body, true).applyTo(currentProgram, monitor);
                Function f = fm.getFunctionAt(start);
                if (f == null) {
                    try { f = fm.createFunction(null, start, (AddressSetView)body, SourceType.ANALYSIS); }
                    catch (Exception e) { out.println("CREATE_FAILED " + e); }
                } else {
                    try { f.setBody((AddressSetView)body); }
                    catch (Exception e) { out.println("SETBODY_FAILED " + e); }
                }
                out.println("pdataEnd=" + end + " disassembled=" + disassembled +
                    " function=" + (f == null ? "<none>" : f.getName() + " body=" + f.getBody().getNumAddresses()));
                out.println("-- listing --");
                InstructionIterator it = currentProgram.getListing().getInstructions(body, true);
                while (it.hasNext()) {
                    Instruction ins = it.next();
                    out.println(ins.getAddress() + "  " + ins);
                }
                if (f != null) {
                    out.println("-- decompilation --");
                    DecompileResults result = decomp.decompileFunction(f, 60, monitor);
                    if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null)
                        out.println(result.getDecompiledFunction().getC());
                    else out.println("DECOMPILATION_FAILED " + (result == null ? "null" : result.getErrorMessage()));
                }
                System.gc();
            }
        } finally {
            decomp.dispose();
        }
        println("Wrote " + OUT);
    }
}
