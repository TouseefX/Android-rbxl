import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileCallbackQueueHelpers extends GhidraScript {
    private static final String[] VAS = {
        "140003db0", "1400078b0", "140001b50",
        "142a148e0", "142a14a70", "142a14aa0", "142a14bd0",
        "142a15c20", "142a15c60", "14378fa70", "14378ebd0",
        "14378eb70", "143785af0"
    };
    @Override
    public void run() throws Exception {
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");
        FunctionManager fm = currentProgram.getFunctionManager();
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/channel_callback_helpers_decomp.txt"))) {
            out.println("Selected static decompilations for callback/scheduler and channel-event helper tracing. Target not executed.");
            for (String s : VAS) {
                Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(s);
                Function f = fm.getFunctionAt(a);
                out.println("\n\nFUNCTION " + s + " @ " + a);
                if (f == null) {
                    out.println("NO FUNCTION ENTRY");
                    continue;
                }
                out.println("name=" + f.getName() + " end=" + f.getBody().getMaxAddress() + " signature=" + f.getSignature());
                DecompileResults r = decomp.decompileFunction(f, 45, monitor);
                if (r != null && r.decompileCompleted() && r.getDecompiledFunction() != null) out.println(r.getDecompiledFunction().getC());
                else out.println("DECOMPILATION FAILED: " + (r == null ? "null" : r.getErrorMessage()));
                System.gc();
            }
        } finally { decomp.dispose(); }
        println("Wrote /home/user/analysis/channel_callback_helpers_decomp.txt");
    }
}
