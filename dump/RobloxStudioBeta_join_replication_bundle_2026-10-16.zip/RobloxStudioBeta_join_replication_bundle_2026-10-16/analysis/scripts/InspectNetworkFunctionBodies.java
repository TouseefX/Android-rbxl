import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import java.io.FileWriter;
import java.io.PrintWriter;

public class InspectNetworkFunctionBodies extends GhidraScript {
    @Override public void run() throws Exception {
        String[] addrs = {"145daff90", "145f91af0", "145f4fdf0", "1435f4530", "144c24e60"};
        FunctionManager fm = currentProgram.getFunctionManager();
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/function_body_probe.txt"))) {
            for (String s : addrs) {
                Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(Long.parseUnsignedLong(s,16));
                Function f = fm.getFunctionAt(a);
                out.println("\n" + a + " function=" + (f == null ? "<none>" : f.getName()+" @ "+f.getEntryPoint()));
                if (f == null) continue;
                out.println("body min="+f.getBody().getMinAddress()+" max="+f.getBody().getMaxAddress()+" numAddresses="+f.getBody().getNumAddresses());
                int n=0;
                InstructionIterator it=currentProgram.getListing().getInstructions(f.getBody(),true);
                while(it.hasNext()&&n<20){Instruction ins=it.next();out.println("  "+ins.getAddress()+" "+ins);n++;}
                out.println("instructionsShown="+n);
            }
        }
        println("Wrote /home/user/analysis/function_body_probe.txt");
    }
}
