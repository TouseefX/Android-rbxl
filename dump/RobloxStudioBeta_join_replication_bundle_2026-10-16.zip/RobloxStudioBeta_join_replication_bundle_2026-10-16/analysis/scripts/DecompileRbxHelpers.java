import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileRbxHelpers extends GhidraScript {
    private static class Target { String label, address; Target(String l,String a){label=l;address=a;} }
    @Override public void run() throws Exception {
        Target[] targets = {
            new Target("SysUdpSocket helper called by slot 2", "1435f2090"),
            new Target("SysUdpSocket receive helper", "1435f4c80"),
            new Target("SysUdpSocket address/result helper", "1435f5d80"),
            new Target("SysUdpSocket send helper", "1435f5b70"),
            new Target("SysUdpSocket query helper", "1435f59a0"),
            new Target("SysUdpSocket option helper", "1435f5330"),
            new Target("SysUdpSocket error formatter", "1435f2c20"),
            new Target("socket state helper", "1435f6330"),
            new Target("error result helper", "1435e0940"),
            new Target("Libuv error/result helper", "143603db0"),
            new Target("Libuv error constructor", "1436030e0"),
            new Target("Libuv TCP callback/operation helper", "1435fe2f0"),
            new Target("Libuv TCP connect/start helper", "143605210"),
            new Target("Libuv TCP option helper", "143604bd0"),
            new Target("Libuv TCP option helper 1", "143604c10"),
            new Target("Libuv TCP option helper 2", "143604c20"),
            new Target("QUIC client connection helper", "1437e3c10"),
            new Target("H3 helper A", "1437bf190"),
            new Target("H3 helper B", "1437bf650"),
            new Target("TLS helper", "1439f72f0"),
            new Target("TLS helper 2", "1439de550"),
            new Target("system UDP event helper", "1435dd410"),
            new Target("Libuv UDP event helper", "1436016e0"),
            new Target("Libuv UDP poll helper", "143600ea0")
        };
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program in decompiler");
        FunctionManager fm=currentProgram.getFunctionManager();
        int ok=0;
        try(PrintWriter out=new PrintWriter(new FileWriter("/home/user/analysis/ghidra_network_helpers.txt"))) {
            for(Target t:targets) {
                monitor.checkCancelled();
                Address a=currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(Long.parseUnsignedLong(t.address,16));
                Function f=fm.getFunctionAt(a);
                if(f==null) f=fm.getFunctionContaining(a);
                if(currentProgram.getListing().getInstructionAt(a)==null) { try{disassemble(a);}catch(Exception ignored){} }
                if(f==null) f=fm.getFunctionAt(a);
                out.println("\n\n/******** " + t.label + " @ " + a + " ********/");
                if(f==null){out.println("NO FUNCTION");continue;}
                out.println("Ghidra name="+f.getName()+" entry="+f.getEntryPoint());
                out.println("signature="+f.getSignature());
                DecompileResults r=decomp.decompileFunction(f,60,monitor);
                if(r!=null&&r.decompileCompleted()&&r.getDecompiledFunction()!=null){out.println(r.getDecompiledFunction().getC());ok++;}
                else out.println("FAILED: "+(r==null?"null":r.getErrorMessage()));
            }
            out.println("\ncompleted="+ok+" requested="+targets.length);
        } finally {decomp.dispose();}
        println("Wrote /home/user/analysis/ghidra_network_helpers.txt; completed="+ok+"/"+targets.length);
    }
}
