import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.SourceType;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class ForceDecompileJoinReplicationExtras extends GhidraScript {
    private static final String[] STARTS = {
        "145ea8110", "145ea7fd0", "145ea7ed0", "145f92500",
        "145fb4cc0", "145fb5e20", "145f6f3d0", "145e317a0",
        "145e27770", "145df0370", "145dae5b0", "145e4d500", "145ea99a0",
        "145eaa4f0", "145f90fe0", "145fb4310", "145fb54f0", "145fb6290", "145fb79e0",
        "145f88a40", "145dda4c0", "145f666f0", "145f87e30", "145fb7530", "145fb6e90", "145fb3e10"
    };
    private static final String OUT = "/home/user/analysis/join_replication_extras_decomp.txt";

    @Override public void run() throws Exception {
        MemoryBlock pdata = null;
        for (MemoryBlock b : currentProgram.getMemory().getBlocks()) if (b.getName().equals(".pdata")) { pdata=b; break; }
        if (pdata==null) throw new Exception("No .pdata");
        byte[] bytes=new byte[(int)pdata.getSize()]; currentProgram.getMemory().getBytes(pdata.getStart(),bytes);
        ByteBuffer bb=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        long base=currentProgram.getImageBase().getOffset(); FunctionManager fm=currentProgram.getFunctionManager();
        DecompInterface d=new DecompInterface(); d.setOptions(new DecompileOptions()); d.toggleCCode(true); d.toggleSyntaxTree(true); d.setSimplificationStyle("decompile");
        if(!d.openProgram(currentProgram)) throw new Exception("Decompiler open failed");
        try(PrintWriter out=new PrintWriter(new FileWriter(OUT))){
            for(String s:STARTS){ Address start=toAddr(Long.parseUnsignedLong(s,16)); long rva=start.getOffset()-base,endRva=-1;
                for(int i=0;i+12<=bytes.length;i+=12){long b=Integer.toUnsignedLong(bb.getInt(i)),e=Integer.toUnsignedLong(bb.getInt(i+4)); if(b==rva&&e>b){endRva=e;break;}}
                out.println("\n\nFUNCTION "+s); if(endRva<0){out.println("NO_PDATA");continue;}
                Address end=toAddr(base+endRva-1); AddressSet body=new AddressSet(start,end);
                boolean ok=new DisassembleCommand(start,body,true).applyTo(currentProgram,monitor); Function fn=fm.getFunctionAt(start);
                if(fn==null){try{fn=fm.createFunction(null,start,(AddressSetView)body,SourceType.ANALYSIS);}catch(Exception e){out.println("CREATE_FAILED "+e);}}
                else {try{fn.setBody((AddressSetView)body);}catch(Exception e){out.println("SETBODY_FAILED "+e);}}
                out.println("disassembled="+ok+" function="+(fn==null?"<none>":fn.getName())+" end="+end);
                if(fn!=null){DecompileResults r=d.decompileFunction(fn,60,monitor); if(r!=null&&r.decompileCompleted()&&r.getDecompiledFunction()!=null)out.println(r.getDecompiledFunction().getC());else out.println("DECOMPILE_FAILED "+(r==null?"null":r.getErrorMessage()));}
                out.flush();System.gc();
            }
        }finally{d.dispose();}
        println("Wrote "+OUT);
    }
}
