import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.symbol.SourceType;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ForceDecompileMrdWireTrace extends GhidraScript {
    private static final String[][] RANGES = {
        {"14307af50", "14307b7b8", "Mrd-input parser with chained .pdata blocks"},
        {"14307b7c0", "14307c3f4", "related Mrd input parser with chained .pdata blocks"},
        {"14307c740", "14307d1aa", "Mrd output serializer with chained .pdata blocks"},
        {"14307c4b0", "14307c73c", "serializer caller"},
        {"143082f50", "143082fef", "outer record builder"},
        {"143081e00", "14308223d", "outer record-builder caller"},
        {"1430790a0", "143079283", "outer record consumer"}
    };
    private static final String OUT = "/home/user/analysis/mrd_0x80_whole_functions.txt";

    @Override
    public void run() throws Exception {
        FunctionManager fm = currentProgram.getFunctionManager();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT))) {
            out.println("Targeted static decompilation of chained .pdata Mrd-like writer/reader functions.");
            out.println("No target code was executed. Function labels and semantic names remain provisional.");
            for (String[] row : RANGES) {
                monitor.checkCancelled();
                Address start = toAddr(Long.parseUnsignedLong(row[0], 16));
                Address end = toAddr(Long.parseUnsignedLong(row[1], 16));
                AddressSet body = new AddressSet(start, end);
                List<Address> remove = new ArrayList<>();
                java.util.Iterator<Function> fit = fm.getFunctionsOverlapping((AddressSetView)body);
                while (fit.hasNext()) {
                    Function old = fit.next();
                    if (!old.getEntryPoint().equals(start)) remove.add(old.getEntryPoint());
                }
                for (Address a : remove) fm.removeFunction(a);
                boolean disassembled = new DisassembleCommand(start, body, true).applyTo(currentProgram, monitor);
                Function f = fm.getFunctionAt(start);
                if (f == null) f = fm.createFunction(null, start, (AddressSetView)body, SourceType.ANALYSIS);
                else f.setBody((AddressSetView)body);
                out.println("\n\nFUNCTION " + row[0] + "-" + row[1] + " (" + row[2] + ")");
                out.println("disassembled=" + disassembled + " name=" + f.getName() + " bodyBytes=" + f.getBody().getNumAddresses());
                out.println("-- listing --");
                InstructionIterator it = currentProgram.getListing().getInstructions(body, true);
                while (it.hasNext()) {
                    Instruction ins = it.next();
                    out.println(ins.getAddress() + "  " + ins);
                }
                out.println("-- decompilation --");
                DecompileResults result = decomp.decompileFunction(f, 120, monitor);
                if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null)
                    out.println(result.getDecompiledFunction().getC());
                else out.println("DECOMPILATION_FAILED " + (result == null ? "null" : result.getErrorMessage()));
                System.gc();
            }
        } finally { decomp.dispose(); }
        println("Wrote " + OUT);
    }
}
