import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import java.io.FileWriter;
import java.io.PrintWriter;

public class InspectImportedProgram extends GhidraScript {
    @Override
    public void run() throws Exception {
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/ghidra_inspect.txt"))) {
            out.println("program=" + currentProgram.getName());
            out.println("language=" + currentProgram.getLanguage().getLanguageID());
            out.println("compiler=" + currentProgram.getCompilerSpec().getCompilerSpecID());
            out.println("imageBase=" + currentProgram.getImageBase());
            out.println("functionCount=" + currentProgram.getFunctionManager().getFunctionCount());
            out.println("--- blocks ---");
            Memory memory = currentProgram.getMemory();
            for (MemoryBlock block : memory.getBlocks()) {
                out.printf("%s %s..%s size=%d initialized=%s R=%s W=%s X=%s%n",
                    block.getName(), block.getStart(), block.getEnd(), block.getSize(),
                    block.isInitialized(), block.isRead(), block.isWrite(), block.isExecute());
            }
            out.println("--- targeted strings ---");
            String[] needles = {
                ".?AVtype_info@@",
                ".?AVH3Connection@Http@RbxTransport@RBX@@",
                ".?AVLibuvTcpSocket@Impl@Io@RbxTransport@RBX@@",
                ".?AVQuicClientConnection@Protocol@RbxTransport@RBX@@",
                ".?AVWtSession@Http@RbxTransport@RBX@@"
            };
            for (String needle : needles) {
                byte[] pattern = needle.getBytes("US-ASCII");
                out.println("needle=" + needle);
                for (MemoryBlock block : memory.getBlocks()) {
                    if (!block.isInitialized()) continue;
                    Address start = block.getStart();
                    Address end = block.getEnd();
                    int count = 0;
                    while (start.compareTo(end) <= 0 && count < 20) {
                        Address found = memory.findBytes(start, end, pattern, null, true, monitor);
                        if (found == null) break;
                        out.println("  " + block.getName() + " @ " + found);
                        count++;
                        start = found.add(pattern.length);
                    }
                }
            }
            out.println("--- functions present ---");
            int shown = 0;
            for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
                if (shown++ >= 20) break;
                out.println(f.getEntryPoint() + " " + f.getName());
            }
        }
        println("Wrote /home/user/analysis/ghidra_inspect.txt");
    }
}
