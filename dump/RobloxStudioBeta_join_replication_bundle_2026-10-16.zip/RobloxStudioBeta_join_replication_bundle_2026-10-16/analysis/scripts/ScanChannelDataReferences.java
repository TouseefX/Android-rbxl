import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;

public class ScanChannelDataReferences extends GhidraScript {
    private boolean inRange(long v) {
        return (v >= 0x148ebed00L && v < 0x148ebef20L) ||
               v == 0x1437763f0L || v == 0x14377a140L || v == 0x14377b290L ||
               v == 0x14378a960L || v == 0x14379ce50L;
    }
    @Override
    public void run() throws Exception {
        MemoryBlock text = currentProgram.getMemory().getBlock(".text");
        if (text == null) throw new Exception("No .text block");
        println("Scanning decoded instructions in " + text.getStart() + ".." + text.getEnd());
        InstructionIterator it = currentProgram.getListing().getInstructions(text.getStart(), true);
        long count = 0, hits = 0;
        while (it.hasNext() && !monitor.isCancelled()) {
            Instruction ins = it.next();
            count++;
            boolean printed = false;
            for (int op=0; op<ins.getNumOperands(); op++) {
                Object[] obs = ins.getOpObjects(op);
                for (Object o: obs) {
                    if (o instanceof Address) {
                        Address a=(Address)o;
                        long v=a.getOffset();
                        if (inRange(v)) {
                            if (!printed) { println(ins.getAddress()+"  "+ins); printed=true; }
                            println("    op"+op+" -> "+a+" refs="+ins.getReferencesFrom().length);
                            hits++;
                        }
                    }
                }
            }
            if ((count % 1000000)==0) monitor.setMessage("Scanned "+count+" instructions; matches="+hits);
        }
        println("DONE instructions="+count+" matches="+hits);
    }
}
