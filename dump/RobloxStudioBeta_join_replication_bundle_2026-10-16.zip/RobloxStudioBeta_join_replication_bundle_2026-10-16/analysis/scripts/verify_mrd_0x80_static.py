#!/usr/bin/env python3
"""Static verification of the Mrd Huffman tables and clean-room codec model.

Reads (never loads or executes) RobloxStudioBeta.exe, extracts the target's code and
transition tables by RVA/VA, checks the C++ include against the code table, then runs
our bitstream model against the target's decoder transition table.
"""

from __future__ import annotations

import argparse
import hashlib
import random
import re
import struct
from pathlib import Path

ENCODER_VA = 0x148D45C00
DECODER_VA = 0x148D46410
ENCODER_SHA256 = "05a119ba76df924cbcad8bf3066ea1d023c0cef8f4be6ddc107a8b7f57595093"
DECODER_SHA256 = "c9bd00a073f505ced0b226941f80457cd19aefbea1c665496d3b2806d57692c3"
DECODER_SIZE = 4 * 1024 * 1024
MAX_FIELD = 0x3FFFFFFFFFFFFFFF


def pe_va_reader(path: Path):
    data = path.read_bytes()
    if data[:2] != b"MZ":
        raise ValueError("target is not a PE image")
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe : pe + 4] != b"PE\0\0":
        raise ValueError("missing PE signature")
    section_count = struct.unpack_from("<H", data, pe + 6)[0]
    optional_size = struct.unpack_from("<H", data, pe + 20)[0]
    image_base = struct.unpack_from("<Q", data, pe + 24 + 24)[0]
    section_table = pe + 24 + optional_size
    sections = []
    for i in range(section_count):
        off = section_table + i * 40
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from("<IIII", data, off + 8)
        sections.append((virtual_address, max(virtual_size, raw_size), raw_offset))

    def read_va(va: int, size: int) -> bytes:
        rva = va - image_base
        for virtual_address, mapped_size, raw_offset in sections:
            if virtual_address <= rva and rva + size <= virtual_address + mapped_size:
                file_offset = raw_offset + rva - virtual_address
                return data[file_offset : file_offset + size]
        raise ValueError(f"VA {va:#x} (size {size:#x}) is not file-backed")

    return read_va


def load_cpp_table(path: Path):
    text = path.read_text(encoding="utf-8")
    rows = re.findall(r"HuffmanCode\{(\d+)u,\s*0x([0-9a-fA-F]{8})u\}", text)
    if len(rows) != 256:
        raise ValueError(f"expected 256 C++ table rows, found {len(rows)}")
    return [(int(length), int(code, 16)) for length, code in rows]


def codes_are_prefix_free(codes):
    normalized = []
    for length, code in codes:
        if not 0 < length <= 30:
            return False
        normalized.append((length, code >> (32 - length)))
    for i, (length, bits) in enumerate(normalized):
        for j, (other_length, other_bits) in enumerate(normalized):
            if i == j:
                continue
            if length <= other_length and bits == (other_bits >> (other_length - length)):
                return False
    return True


def huffman_encode(payload: bytes, codes) -> bytes:
    out = bytearray()
    current = 0
    used = 0
    for symbol in payload:
        length, code = codes[symbol]
        for bit_index in range(length):
            current = (current << 1) | ((code >> (31 - bit_index)) & 1)
            used += 1
            if used == 8:
                out.append(current)
                current = 0
                used = 0
    if used:
        pad = 8 - used
        out.append((current << pad) | ((1 << pad) - 1))
    return bytes(out)


def target_decoder(payload: bytes, table_bytes: bytes):
    words = memoryview(table_bytes).cast("I")
    state = 0
    state_word = 0x00010000  # FUN_143084850 resets to state 0, end-accepted flag 1.
    output = bytearray()
    for byte in payload:
        high = words[state * 16 + (byte >> 4)]
        if (high & 0x00020000) != 0:
            output.append((high >> 24) & 0xFF)
        low = words[(high & 0xFFFF) * 16 + (byte & 0x0F)]
        if (low & 0x00020000) != 0:
            output.append((low >> 24) & 0xFF)
        state_word = low
        state = low & 0xFFFF
    return bytes(output), (state_word & 0x00010000) != 0


def append_field(prefix: int, value: int, width: int) -> bytes:
    mask = (1 << width) - 1
    if not 0 <= value <= MAX_FIELD:
        raise ValueError("field outside target reader's 62-bit bound")
    first = (prefix & (~mask & 0xFF)) | min(value, mask)
    out = bytearray([first])
    if value >= mask:
        remainder = value - mask
        while remainder >= 0x80:
            out.append((remainder & 0x7F) | 0x80)
            remainder >>= 7
        out.append(remainder)
    return bytes(out)


def encode_record(tag: int, payload: bytes, codes):
    compressed = huffman_encode(payload, codes)
    use_huffman = len(compressed) < len(payload)
    body = compressed if use_huffman else payload
    return (append_field(0x80, tag, 6) +
            append_field(0x80 if use_huffman else 0, len(body), 7) + body,
            use_huffman)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("target", type=Path, nargs="?", default=Path("/tmp/RobloxStudioBeta.exe"))
    parser.add_argument("--cpp-table", type=Path,
                        default=Path(__file__).resolve().parents[2] / "reconstruction/src/mrd_huffman_table.inc")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "mrd_0x80_static_verification.txt")
    args = parser.parse_args()

    read_va = pe_va_reader(args.target)
    encoder_raw = read_va(ENCODER_VA, 256 * 8)
    decoder_raw = read_va(DECODER_VA, DECODER_SIZE)
    encoder_hash = hashlib.sha256(encoder_raw).hexdigest()
    decoder_hash = hashlib.sha256(decoder_raw).hexdigest()
    if encoder_hash != ENCODER_SHA256:
        raise SystemExit(f"encoder-table hash mismatch: {encoder_hash}")
    if decoder_hash != DECODER_SHA256:
        raise SystemExit(f"decoder-table hash mismatch: {decoder_hash}")

    target_codes = [struct.unpack_from("<II", encoder_raw, i * 8) for i in range(256)]
    cpp_codes = load_cpp_table(args.cpp_table)
    if cpp_codes != target_codes:
        raise SystemExit("C++ table entries do not match the target table")
    if not codes_are_prefix_free(target_codes):
        raise SystemExit("target table failed uniqueness/prefix-free validation")

    decoder_table = bytes(decoder_raw)
    samples = 0

    def verify(payload: bytes):
        nonlocal samples
        generated = huffman_encode(payload, target_codes)
        decoded, accepted = target_decoder(generated, decoder_table)
        if decoded != payload or not accepted:
            raise AssertionError(
                f"target transition-table mismatch at sample {samples}: "
                f"input={len(payload)} output={len(decoded)} accepted={accepted}"
            )
        samples += 1

    # Exhaustive single bytes and ordered two-byte messages.
    for symbol in range(256):
        verify(bytes([symbol]))
    for first in range(256):
        for second in range(256):
            verify(bytes([first, second]))

    for payload in (b"", b"a" * 3, b"a" * 128, bytes(range(256)), b"the quick brown fox" * 19):
        verify(payload)
    rng = random.Random(0x80C0FFEE)
    for length in (3, 7, 31, 255, 4096):
        verify(bytes(rng.randrange(256) for _ in range(length)))

    golden_3a, compressed_3a = encode_record(1, b"aaa", target_codes)
    if not compressed_3a or golden_3a != bytes((0x81, 0x82, 0x18, 0xC7)):
        raise SystemExit(f"3x'a' wire fixture mismatch: {golden_3a.hex()}")
    golden_raw, compressed_raw = encode_record(1, b"\xff", target_codes)
    if compressed_raw or golden_raw != bytes((0x81, 0x01, 0xFF)):
        raise SystemExit(f"raw wire fixture mismatch: {golden_raw.hex()}")

    lines = [
        "Static Mrd 0x80 codec verification: PASS",
        f"Target: {args.target}",
        "Target executable was read as data only; no target code was executed.",
        f"Encoder table @ {ENCODER_VA:#x}: {len(encoder_raw)} bytes, SHA-256 {encoder_hash}",
        f"Decoder table @ {DECODER_VA:#x}: {len(decoder_raw)} bytes, SHA-256 {decoder_hash}",
        "C++ include: all 256 (length, left-aligned-code) pairs match byte-for-byte.",
        "Codebook: unique and prefix-free; code lengths range from 5 through 30 bits.",
        f"Target transition-table simulation: {samples} payloads decoded exactly and ended in an accepting state.",
        "Coverage: every one-symbol and ordered two-symbol payload; fixed and seeded random samples through 4096 bytes.",
        f"Compressed golden record for b'aaa': {golden_3a.hex()}",
        f"Raw golden record for b'\\xff': {golden_raw.hex()}",
        "Writer model uses strict compressed-size < raw-size selection, width-6/width-7 fields, ULEB continuation groups, and one-bit final padding.",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
