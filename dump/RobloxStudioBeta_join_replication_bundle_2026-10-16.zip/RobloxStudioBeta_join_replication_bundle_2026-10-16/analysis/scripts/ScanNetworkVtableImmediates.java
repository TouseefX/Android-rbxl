import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.scalar.Scalar;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScanNetworkVtableImmediates extends GhidraScript {
    private static final String RTTI_FILE = "/home/user/analysis/network_rtti_vtables.txt";
    private static final String OUT_FILE = "/home/user/analysis/network_vtable_immediates.txt";
    private static final Pattern PTR = Pattern.compile("ptr=(0x[0-9a-fA-F]+)");
    private static final Pattern VF = Pattern.compile("VFTABLE @ (0x[0-9a-fA-F]+)");
    private static final Pattern SLOT = Pattern.compile("slot=(\\d+)");
    private static final Set<Long> INTERESTING = new LinkedHashSet<>(Arrays.asList(
        0x80L, 0x81L, 0x82L, 0x83L, 0x84L, 0x86L, 0x8aL, 0x8dL, 0x8fL,
        0x90L, 0x92L, 0x97L, 0xa1L, 0xa5L, 0xa6L
    ));

    private static final class TargetRef {
        final long address;
        final LinkedHashSet<String> labels = new LinkedHashSet<>();
        TargetRef(long va) { address = va; }
    }

    private long parseVa(String text) {
        String s = text.startsWith("0x") || text.startsWith("0X") ? text.substring(2) : text;
        return Long.parseUnsignedLong(s, 16);
    }

    private static long u32le(byte[] b, int i) {
        return ((long)b[i] & 0xffL) | (((long)b[i+1] & 0xffL) << 8) |
               (((long)b[i+2] & 0xffL) << 16) | (((long)b[i+3] & 0xffL) << 24);
    }

    private boolean relevantType(String n) {
        if (!(n.startsWith(".?AV") || n.startsWith(".?AU"))) return false;
        if (!(n.contains("@Network@RBX@@") || n.contains("@NetworkBase@RBX@@") ||
              n.contains("@RbxTransport@RBX@@"))) return false;
        if (n.startsWith(".?AV?$") || n.startsWith(".?AU?$") ||
            n.contains("@std@@") || n.contains("SmallVector@") ||
            n.contains("SubsystemHandleImpl") || n.contains("@Reflection@RBX@@") ||
            n.contains("@Detail@RSL@@")) return false;
        return true;
    }

    private boolean executable(long va) {
        try {
            Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(va);
            MemoryBlock b = currentProgram.getMemory().getBlock(a);
            return b != null && b.isExecute();
        } catch (Exception e) { return false; }
    }

    private Map<Long, TargetRef> loadTargets() throws Exception {
        Map<Long, TargetRef> targets = new LinkedHashMap<>();
        Set<String> types = new LinkedHashSet<>();
        String vftable = "?";
        boolean selected = false;
        try (BufferedReader in = new BufferedReader(new FileReader(RTTI_FILE))) {
            String line;
            while ((line = in.readLine()) != null) {
                if (line.startsWith("COL @")) {
                    types.clear(); vftable = "?"; selected = false;
                } else if (line.startsWith("  TYPE ")) {
                    String type = line.substring("  TYPE ".length()).trim();
                    if (relevantType(type)) { types.add(type); selected = true; }
                } else if (line.startsWith("  VFTABLE @")) {
                    Matcher m = VF.matcher(line);
                    vftable = m.find() ? m.group(1) : "?";
                } else if (selected && line.startsWith("    slot=")) {
                    Matcher pm = PTR.matcher(line);
                    Matcher sm = SLOT.matcher(line);
                    if (!pm.find() || !sm.find()) continue;
                    long va = parseVa(pm.group(1));
                    if (!executable(va)) continue;
                    TargetRef ref = targets.computeIfAbsent(va, TargetRef::new);
                    for (String type : types)
                        ref.labels.add(type + " | vftable=" + vftable + " | slot=" + sm.group(1));
                }
            }
        }
        return targets;
    }

    private Map<Long, Long> loadPdataRanges() throws Exception {
        Memory memory = currentProgram.getMemory();
        MemoryBlock pdata = null;
        for (MemoryBlock b : memory.getBlocks()) if (b.getName().equals(".pdata")) { pdata = b; break; }
        if (pdata == null) throw new Exception(".pdata block not found");
        if (pdata.getSize() > Integer.MAX_VALUE) throw new Exception(".pdata block too large");
        byte[] bytes = new byte[(int)pdata.getSize()];
        memory.getBytes(pdata.getStart(), bytes);
        long imageBase = currentProgram.getImageBase().getOffset();
        Map<Long, Long> ranges = new LinkedHashMap<>();
        for (int i = 0; i + 12 <= bytes.length; i += 12) {
            long beginRva = u32le(bytes, i);
            long endRva = u32le(bytes, i + 4);
            long unwindRva = u32le(bytes, i + 8);
            if (beginRva == 0 || endRva <= beginRva || endRva - beginRva > 0x1000000L) continue;
            long begin = imageBase + beginRva;
            long end = imageBase + endRva;
            if (!executable(begin) || !executable(end - 1)) continue;
            // Unwind metadata also must be within the mapped image.
            if (unwindRva == 0 || imageBase + unwindRva >= currentProgram.getMaxAddress().getOffset()) continue;
            ranges.put(begin, end);
        }
        return ranges;
    }

    @Override
    public void run() throws Exception {
        Map<Long, TargetRef> targets = loadTargets();
        Map<Long, Long> pdataRanges = loadPdataRanges();
        FunctionManager fm = currentProgram.getFunctionManager();
        java.util.List<TargetRef> rangesToScan = new ArrayList<>();
        int missingFunctions = 0, missingPdata = 0, disassemblyFailures = 0;
        int targetIndex = 0;

        // The PE import was deliberately -noanalysis. Recover exact x64 function
        // extents from .pdata, then disassemble only selected vtable targets.
        for (TargetRef target : targets.values()) {
            monitor.checkCancelled();
            Address entry = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(target.address);
            Function f = fm.getFunctionAt(entry);
            if (f == null || !f.getEntryPoint().equals(entry)) { missingFunctions++; continue; }
            Long endVa = pdataRanges.get(target.address);
            if (endVa == null || endVa <= target.address) { missingPdata++; continue; }
            Address end = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(endVa - 1);
            AddressSet functionRange = new AddressSet(entry, end);
            DisassembleCommand cmd = new DisassembleCommand(entry, functionRange, true);
            if (!cmd.applyTo(currentProgram, monitor)) disassemblyFailures++;
            rangesToScan.add(target);
            targetIndex++;
            if ((targetIndex % 100) == 0)
                println("ScanNetworkVtableImmediates: targeted functions=" + targetIndex +
                        "/" + targets.size() + " failures=" + disassemblyFailures);
        }

        int scannedFunctions = 0, scannedInstructions = 0, hits = 0;
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT_FILE))) {
            out.println("Immediate-operand scan of targeted .pdata-bounded disassemblies for vtable functions associated with RBX::Network, RBX::NetworkBase, or RBX::RbxTransport.");
            out.println("Values are literal/operand leads only; an occurrence is not proof that it is a wire tag.");
            out.println("interesting=0x80,0x81,0x82,0x83,0x84,0x86,0x8a,0x8d,0x8f,0x90,0x92,0x97,0xa1,0xa5,0xa6");
            out.println("uniqueExecutablePointers=" + targets.size() + " pdataRanges=" + pdataRanges.size() +
                        " functionsWithRanges=" + rangesToScan.size() + " missingFunctionEntries=" +
                        missingFunctions + " missingPdataRanges=" + missingPdata +
                        " targetedDisassemblyFailures=" + disassemblyFailures);
            for (TargetRef target : rangesToScan) {
                monitor.checkCancelled();
                Address entry = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(target.address);
                Function f = fm.getFunctionAt(entry);
                Long endVa = pdataRanges.get(target.address);
                if (f == null || endVa == null || endVa <= target.address) continue;
                Address end = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(endVa - 1);
                AddressSet functionRange = new AddressSet(entry, end);
                scannedFunctions++;
                InstructionIterator it = currentProgram.getListing().getInstructions(functionRange, true);
                while (it.hasNext()) {
                    Instruction ins = it.next();
                    scannedInstructions++;
                    for (int op = 0; op < ins.getNumOperands(); op++) {
                        Object[] objs = ins.getOpObjects(op);
                        if (objs == null) continue;
                        for (Object obj : objs) {
                            if (!(obj instanceof Scalar)) continue;
                            long value = ((Scalar)obj).getValue() & 0xffffffffL;
                            if (!INTERESTING.contains(value)) continue;
                            hits++;
                            out.println("\nHIT value=0x" + Long.toHexString(value) +
                                        " instruction=" + ins.getAddress() + " operand=" + op +
                                        " function=" + f.getName() + " entry=" + f.getEntryPoint());
                            for (String label : target.labels) out.println("  REF " + label);
                            out.println("  ASM " + ins.toString());
                        }
                    }
                }
                if ((scannedFunctions % 100) == 0)
                    println("ScanNetworkVtableImmediates: functions=" + scannedFunctions +
                            "/" + rangesToScan.size() + " instructions=" + scannedInstructions +
                            " hits=" + hits);
            }
            out.println("\nsummary uniqueExecutablePointers=" + targets.size() +
                        " pdataRanges=" + pdataRanges.size() + " functionsScanned=" +
                        scannedFunctions + " missingFunctionEntries=" + missingFunctions +
                        " missingPdataRanges=" + missingPdata + " disassemblyFailures=" +
                        disassemblyFailures + " instructionsScanned=" + scannedInstructions +
                        " immediateHits=" + hits);
        }
        println("Wrote " + OUT_FILE + "; functions=" + scannedFunctions +
                " missingFunctions=" + missingFunctions + " missingPdata=" + missingPdata +
                " disassemblyFailures=" + disassemblyFailures + " instructions=" +
                scannedInstructions + " hits=" + hits);
    }
}
