import ghidra.app.script.GhidraScript;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.symbol.SymbolIterator;
import java.io.FileWriter;
import java.io.PrintWriter;

public class PrintRbxSymbols extends GhidraScript {
    @Override
    public void run() throws Exception {
        int count = 0;
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/rbx_symbols_snapshot.txt"))) {
            out.println("functions=" + currentProgram.getFunctionManager().getFunctionCount());
            SymbolIterator symbols = currentProgram.getSymbolTable().getAllSymbols(true);
            while (symbols.hasNext()) {
                Symbol symbol = symbols.next();
                String full = symbol.getName(true);
                if (full.contains("RbxTransport")) {
                    out.println(symbol.getAddress() + "\t" + symbol.getSymbolType() + "\t" + full);
                    count++;
                }
            }
            out.println("rbxSymbolCount=" + count);
        }
        println("Wrote /home/user/analysis/rbx_symbols_snapshot.txt");
    }
}
