import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.mem.MemoryBlock;
import java.io.FileWriter;
import java.io.PrintWriter;

public class InspectNetworkCallTargets extends GhidraScript {
    private static final String OUT_FILE = "/home/user/analysis/network_call_target_probe.txt";
    private static final String[] VAS = {
        "145da5400", "145db1760", "145f6eed0", "145dd49d0", "145dd4cd0",
        "145df3070", "145def760", "145deecd0", "145f1efa0", "145df8e80",
        "145f94970", "145f68610", "145dbf4d0", "145df8e80", "145dd9860",
        "145daff90", "145db0c00", "145e7a030"
    };

    @Override
    public void run() throws Exception {
        FunctionManager fm = currentProgram.getFunctionManager();
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT_FILE))) {
            for (String text : VAS) {
                Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(text);
                MemoryBlock block = currentProgram.getMemory().getBlock(a);
                Function exact = fm.getFunctionAt(a);
                Function containing = fm.getFunctionContaining(a);
                Instruction ins = currentProgram.getListing().getInstructionAt(a);
                out.println("VA=" + a + " block=" + (block == null ? "null" : block.getName()) +
                    " executable=" + (block != null && block.isExecute()) +
                    " instruction=" + (ins == null ? "null" : ins.toString()));
                out.println("  exactFunction=" + (exact == null ? "null" : exact.getName() + " entry=" + exact.getEntryPoint() + " body=" + exact.getBody().getNumAddresses()));
                out.println("  containingFunction=" + (containing == null ? "null" : containing.getName() + " entry=" + containing.getEntryPoint()));
            }
        }
        println("Wrote " + OUT_FILE);
    }
}
