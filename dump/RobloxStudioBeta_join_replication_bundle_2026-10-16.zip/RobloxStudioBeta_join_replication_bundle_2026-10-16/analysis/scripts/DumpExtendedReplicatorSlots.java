import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class DumpExtendedReplicatorSlots extends GhidraScript {
    private static final long[] VTABLES = {0x1493127d0L, 0x14931b298L};
    private static final String[] TYPES = {"Replicator", "ClientReplicator"};

    @Override
    public void run() throws Exception {
        String outPath = "/home/user/analysis/extended_replicator_vtable_slots.txt";
        try (java.io.PrintWriter out = new java.io.PrintWriter(outPath)) {
            for (int t = 0; t < VTABLES.length; t++) {
                Address table = toAddr(VTABLES[t]);
                out.println("TYPE " + TYPES[t] + " vftable=" + table);
                for (int slot = 120; slot <= 175; slot++) {
                    Address entry = table.add(slot * 8L);
                    long pointer = currentProgram.getMemory().getLong(entry);
                    Address target = toAddr(pointer);
                    Function f = currentProgram.getFunctionManager().getFunctionAt(target);
                    out.printf("  slot=%d entry=%s ptr=%s function=%s%n", slot, entry, target,
                        f == null ? "<none>" : f.getName() + " @ " + f.getEntryPoint());
                }
            }
        }
        println("Wrote " + outPath);
    }
}
