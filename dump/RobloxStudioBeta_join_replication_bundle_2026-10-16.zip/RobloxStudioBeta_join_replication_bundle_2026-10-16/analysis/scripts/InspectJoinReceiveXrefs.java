import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.listing.Function;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;

public class InspectJoinReceiveXrefs extends GhidraScript {
    private static final String[] TARGETS = {
        "145fcca80", "145fccad0", "1493443e0", "145fe0180",
        "145dae5b0", "142b69050"
    };

    @Override
    public void run() throws Exception {
        String outPath = "/home/user/analysis/join_receive_xrefs.txt";
        try (java.io.PrintWriter out = new java.io.PrintWriter(outPath)) {
            for (String s : TARGETS) {
                Address target = toAddr(Long.parseUnsignedLong(s, 16));
                out.println("\nTARGET " + s + " @ " + target);
                ReferenceIterator it = currentProgram.getReferenceManager().getReferencesTo(target);
                int n = 0;
                while (it.hasNext() && n < 500) {
                    Reference ref = it.next();
                    Address from = ref.getFromAddress();
                    Function f = currentProgram.getFunctionManager().getFunctionContaining(from);
                    CodeUnit cu = currentProgram.getListing().getCodeUnitAt(from);
                    out.printf("  from=%s type=%s operand=%d function=%s code=%s%n",
                        from, ref.getReferenceType(), ref.getOperandIndex(),
                        f == null ? "<none>" : f.getName() + "@" + f.getEntryPoint(),
                        cu == null ? "<none>" : cu.toString());
                    n++;
                }
                out.println("  count=" + n);
            }
        }
        println("Wrote " + outPath);
    }
}
