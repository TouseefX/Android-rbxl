#include <capstone/capstone.h>
#include <capstone/x86.h>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

static constexpr uint64_t B=0x140000000ULL, TR=0x1000, TF=0x400, TS=0x8822693, PR=0x0d0aae00, PS=0x4b6fc0;
struct Edge{uint64_t caller,callerEnd,at,target;};
int main(){
 std::ifstream f("/tmp/RobloxStudioBeta.exe",std::ios::binary); if(!f)return 2; f.seekg(0,std::ios::end);size_t n=f.tellg();f.seekg(0);std::vector<uint8_t> raw(n);f.read((char*)raw.data(),n);
 std::vector<uint64_t> targets={0x145ea9000,0x145ea94b0,0x145ea9d50,0x145e33e70,0x145ea8110,0x145ea7fd0,0x145ea7ed0,0x145f92500,0x145f90fe0,0x145fb4310,0x145fb4cc0,0x145fb54f0,0x145fb5e20,0x145fb6290,0x145fb79e0,0x145f91af0,0x145f94050,0x145f944b0,0x145dd0350,0x145f4fdf0,0x145f880c0,0x145f88d20,0x145f86980,0x145f7cd60,0x145f6dd10,0x145f51700,0x145f6f3d0,0x145e317a0,0x145df0370,0x145f666f0,0x145fb6040,0x145fb7530,0x145fb6e90};
 std::unordered_map<uint64_t,std::vector<Edge>> refs;for(auto t:targets)refs[t];
 csh h;cs_open(CS_ARCH_X86,CS_MODE_64,&h);cs_option(h,CS_OPT_DETAIL,CS_OPT_ON);cs_insn*ins=cs_malloc(h);size_t nf=0;
 for(uint64_t p=PR;p+12<=PR+PS;p+=12){uint32_t b,e,u;memcpy(&b,raw.data()+p,4);memcpy(&e,raw.data()+p+4,4);memcpy(&u,raw.data()+p+8,4);if(!(TR<=b&&b<e&&e<=TR+TS))continue;nf++;const uint8_t*code=raw.data()+TF+(b-TR);size_t sz=e-b;uint64_t a=B+b;while(sz&&cs_disasm_iter(h,&code,&sz,&a,ins)){if(ins->id==X86_INS_CALL){auto &x=ins->detail->x86;for(uint8_t i=0;i<x.op_count;i++)if(x.operands[i].type==X86_OP_IMM){auto it=refs.find((uint64_t)x.operands[i].imm);if(it!=refs.end())it->second.push_back({B+b,B+e,ins->address,(uint64_t)x.operands[i].imm});}}}}
 std::ofstream o("/home/user/analysis/join_replication_direct_call_xrefs.txt");o<<".pdata functions scanned: "<<nf<<"\n";for(auto t:targets){o<<"\nTARGET 0x"<<std::hex<<t<<std::dec<<" refs="<<refs[t].size()<<"\n";for(auto&e:refs[t])o<<" caller=0x"<<std::hex<<e.caller<<"-0x"<<e.callerEnd<<" call=0x"<<e.at<<"\n";}cs_free(ins,1);cs_close(&h);std::cout<<"wrote call refs; scanned "<<nf<<" functions\n";
}
