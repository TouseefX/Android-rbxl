import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.mem.MemoryBlock;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DecompileAllNetworkVtableMethods extends GhidraScript {
    private static final String RTTI_FILE = "/home/user/analysis/network_rtti_vtables.txt";
    private static final String OUT_FILE = "/home/user/analysis/ghidra_network_all_vtables_decomp.txt";
    private static final Pattern PTR = Pattern.compile("ptr=(0x[0-9a-fA-F]+)");
    private static final Pattern VF = Pattern.compile("VFTABLE @ (0x[0-9a-fA-F]+)");
    private static final Pattern SLOT = Pattern.compile("slot=(\\d+)");

    private static final class TargetRef {
        final long address;
        final LinkedHashSet<String> labels = new LinkedHashSet<>();
        TargetRef(long va) { address = va; }
    }

    private static final Set<String> FOCUS_TYPES = new LinkedHashSet<>(Arrays.asList(
        // Core transport/session interface and transport adapter.
        ".?AVNetworkStream@Network@RBX@@",
        ".?AVConnectionInternal@NetworkBase@RBX@@",
        ".?AVRbxTransportConnection@NetworkBase@RBX@@",
        ".?AVRbxTransportListener@NetworkBase@RBX@@",
        ".?AVRakNetFactory@NetworkBase@RBX@@",
        ".?AVRakNetConnection@Network@RBX@@",
        ".?AVRakNetClientConnection@Network@RBX@@",
        ".?AVRtcIoBaseConnection@Impl@RbxTransport@RBX@@",
        ".?AVRtcIoClientConnectionBase@Impl@RbxTransport@RBX@@",
        ".?AVRtcIoClientConnection@Impl@RbxTransport@RBX@@",
        ".?AVRtcAppConnection@Impl@RbxTransport@RBX@@",
        ".?AVOpenUnreliableChannelControl@System@RbxTransport@RBX@@",
        ".?AVOpenReliableChannelControl@System@RbxTransport@RBX@@",

        // Replicator and packet/stream scheduling surfaces.
        ".?AVNetworkObject@Network@RBX@@",
        ".?AVReplicator@Network@RBX@@",
        ".?AVClientReplicator@Network@RBX@@",
        ".?AVServerReplicator@Network@RBX@@",
        ".?AVNetworkJoinProcessorJob@Network@RBX@@",
        ".?AVDeserializePacketsJob@Network@RBX@@",
        ".?AVProcessPacketsJob@Replicator@Network@RBX@@",
        ".?AVStreamJob@Replicator@Network@RBX@@",

        // Message/item handlers implicated by join, marker, instance and property flow.
        ".?AVDeserializedItem@Network@RBX@@",
        ".?AVDeserializedNewObjectItem@Network@RBX@@",
        ".?AVDeserializedChangePropertyItem@Network@RBX@@",
        ".?AVDeserializedDeleteInstanceItem@Network@RBX@@",
        ".?AVDeserializedEventInvocationItem@Network@RBX@@",
        ".?AVDeserializedJoinDataItem@Network@RBX@@",
        ".?AVJoinDataItemV2@Replicator@Network@RBX@@",
        ".?AVDeserializedMarkerItem@Network@RBX@@",
        ".?AVMarkerItem@Replicator@Network@RBX@@",
        ".?AVChangePropertyItem@Replicator@Network@RBX@@"
    ));

    private boolean relevantType(String n) {
        if (!(n.startsWith(".?AV") || n.startsWith(".?AU"))) return false;
        if (!(n.contains("@Network@RBX@@") || n.contains("@NetworkBase@RBX@@") ||
              n.contains("@RbxTransport@RBX@@"))) return false;
        if (n.startsWith(".?AV?$") || n.startsWith(".?AU?$") ||
            n.contains("@std@@") || n.contains("SmallVector@") ||
            n.contains("SubsystemHandleImpl") || n.contains("@Reflection@RBX@@") ||
            n.contains("@Detail@RSL@@")) return false;
        return true;
    }

    private long parseVa(String text) {
        String s = text.startsWith("0x") || text.startsWith("0X") ? text.substring(2) : text;
        return Long.parseUnsignedLong(s, 16);
    }

    private boolean executable(long va) {
        try {
            Address a = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(va);
            MemoryBlock b = currentProgram.getMemory().getBlock(a);
            return b != null && b.isExecute();
        } catch (Exception e) { return false; }
    }

    private Map<Long, TargetRef> loadTargets() throws Exception {
        Map<Long, TargetRef> targets = new LinkedHashMap<>();
        List<String> types = new ArrayList<>();
        String vftable = "";
        boolean selectedTable = false;
        try (BufferedReader in = new BufferedReader(new FileReader(RTTI_FILE))) {
            String line;
            while ((line = in.readLine()) != null) {
                if (line.startsWith("COL @")) {
                    types.clear(); vftable = ""; selectedTable = false;
                } else if (line.startsWith("  TYPE ")) {
                    String type = line.substring("  TYPE ".length()).trim();
                    types.add(type);
                } else if (line.startsWith("  VFTABLE @")) {
                    Matcher m = VF.matcher(line);
                    vftable = m.find() ? m.group(1) : "?";
                    selectedTable = false;
                    for (String type : types) if (relevantType(type)) selectedTable = true;
                } else if (selectedTable && line.startsWith("    slot=")) {
                    Matcher pm = PTR.matcher(line);
                    Matcher sm = SLOT.matcher(line);
                    if (!pm.find() || !sm.find()) continue;
                    long va = parseVa(pm.group(1));
                    if (!executable(va)) continue;
                    TargetRef ref = targets.computeIfAbsent(va, TargetRef::new);
                    for (String type : types) if (relevantType(type))
                        ref.labels.add(type + " | vftable=" + vftable + " | slot=" + sm.group(1));
                }
            }
        }
        return targets;
    }

    @Override
    public void run() throws Exception {
        Map<Long, TargetRef> targets = loadTargets();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program in decompiler");

        FunctionManager fm = currentProgram.getFunctionManager();
        int completed = 0, noFunction = 0, failed = 0, requested = 0;
        try (PrintWriter out = new PrintWriter(new FileWriter(OUT_FILE))) {
            out.println("Expanded targeted vtable decompilation; labels are RTTI/vtable references, not recovered method names.");
            out.println("program=" + currentProgram.getName() + " imageBase=" + currentProgram.getImageBase());
            out.println("relevantDecoratedTypes=RBX::Network|NetworkBase|RbxTransport");
            out.println("uniqueExecutablePointers=" + targets.size());
            for (TargetRef target : targets.values()) {
                monitor.checkCancelled();
                requested++;
                Address entry = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(target.address);
                Function f = fm.getFunctionAt(entry);
                if (f == null && currentProgram.getListing().getInstructionAt(entry) == null) {
                    try { disassemble(entry); } catch (Exception ignored) {}
                }
                if (f == null) f = fm.getFunctionAt(entry);
                if (f == null) {
                    f = fm.getFunctionContaining(entry);
                    if (f != null && !f.getEntryPoint().equals(entry)) f = null;
                }
                out.println("\n\n/******** VTABLE TARGET @ " + entry + " ********/");
                for (String label : target.labels) out.println("REF " + label);
                if (f == null) {
                    noFunction++;
                    out.println("NO FUNCTION ENTRY (not forced into a function by this pass)");
                    continue;
                }
                out.println("Ghidra name=" + f.getName() + " entry=" + f.getEntryPoint());
                out.println("signature=" + f.getSignature());
                DecompileResults result = decomp.decompileFunction(f, 25, monitor);
                if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null) {
                    out.println(result.getDecompiledFunction().getC());
                    completed++;
                } else {
                    failed++;
                    out.println("DECOMPILATION FAILED: " + (result == null ? "null result" : result.getErrorMessage()));
                }
                if ((requested % 25) == 0) {
                    println("DecompileNetworkFocus: processed " + requested + "/" + targets.size() +
                            " completed=" + completed + " noFunction=" + noFunction + " failed=" + failed);
                    System.gc();
                }
            }
            out.println("\nsummary requested=" + requested + " completed=" + completed +
                        " noFunction=" + noFunction + " failed=" + failed);
        } finally {
            decomp.dispose();
        }
        println("Wrote " + OUT_FILE + "; requested=" + requested + " completed=" + completed +
                " noFunction=" + noFunction + " failed=" + failed);
    }
}
