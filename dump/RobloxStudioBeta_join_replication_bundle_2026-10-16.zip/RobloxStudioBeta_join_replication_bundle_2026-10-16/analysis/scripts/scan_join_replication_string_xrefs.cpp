#include <capstone/capstone.h>
#include <capstone/x86.h>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

static constexpr uint64_t IMAGE_BASE=0x140000000ULL;
static constexpr uint64_t TEXT_RVA=0x1000, TEXT_RAW=0x400, TEXT_SIZE=0x8822693;
static constexpr uint64_t PDATA_RAW=0x0d0aae00, PDATA_SIZE=0x4b6fc0;
static constexpr uint64_t RDATA_RVA=0x148825000ULL-IMAGE_BASE, RDATA_RAW=0x08823600, RDATA_SIZE=0x0406126c;
struct Needle { const char* s; };
static const Needle needles[]={
 {"[FLog::Network] ServerReplicator: Start sending join for peer: %d"},
 {"[FLog::Network] ServerReplicator: Start sending join for peer: %p"},
 {"Getting Replication Cache and Queue JDI"},
 {"Performing player install"},
 {"ServerReplicator::sendNetworkSchemaDefinition"},
 {"[FLog::Network] Serializing Instances and preparing blobs for JoinDataItemV2"},
 {"Replicator::processDeserializedJoinDataItem() : Procsssing DeserializedJoinDataItem"},
 {"Replicator::processDeserializedJoinDataItem() :  will process newInstanceItem"},
 {"Replicator::processDeserializedJoinDataItem() took {} ms"},
 {"JoinDataItemV2::getReadyBitStream: readyBitstreamList size: %d"},
 {"ReplicationDataBlob::requeueInstancesForBlobbing(blob)"},
 {"ReplicationDataBlob::remove(mrd)"},
};
struct Ref { uint64_t start,end,at; std::string mnemonic,operand; };

int main(){
 std::ifstream f("/tmp/RobloxStudioBeta.exe",std::ios::binary);
 if(!f){std::cerr<<"no target\n";return 2;}
 f.seekg(0,std::ios::end); size_t n=(size_t)f.tellg(); f.seekg(0);
 std::vector<uint8_t> raw(n); f.read((char*)raw.data(),n);
 std::vector<uint64_t> target;
 std::vector<std::string> labels;
 for(auto nd:needles){
   std::string s=nd.s; size_t pos=0; bool found=false;
   for(;;){
     auto it=std::search(raw.begin()+pos,raw.end(),s.begin(),s.end(),
       [](uint8_t a,char b){ return a==static_cast<uint8_t>(b); });
     if(it==raw.end()) break;
     pos=static_cast<size_t>(it-raw.begin());
     if(pos>=RDATA_RAW && pos<RDATA_RAW+RDATA_SIZE){
       target.push_back(IMAGE_BASE+RDATA_RVA+(pos-RDATA_RAW)); labels.push_back(s); found=true;
     }
     pos++;
   }
   (void)found;
 }
 std::unordered_map<uint64_t,std::vector<Ref>> refs;
 for(auto a:target) refs[a];
 csh h; if(cs_open(CS_ARCH_X86,CS_MODE_64,&h)!=CS_ERR_OK){std::cerr<<"cs_open failed\n";return 3;}
 cs_option(h,CS_OPT_DETAIL,CS_OPT_ON); cs_insn *insn=cs_malloc(h);
 size_t fcount=0;
 for(uint64_t p=PDATA_RAW;p+12<=PDATA_RAW+PDATA_SIZE;p+=12){
   uint32_t begin,end,unwind; std::memcpy(&begin,raw.data()+p,4);std::memcpy(&end,raw.data()+p+4,4);std::memcpy(&unwind,raw.data()+p+8,4);
   if(!(TEXT_RVA<=begin && begin<end && end<=TEXT_RVA+TEXT_SIZE)) continue;
   fcount++;
   const uint8_t* code=raw.data()+TEXT_RAW+(begin-TEXT_RVA); size_t sz=end-begin; uint64_t addr=IMAGE_BASE+begin;
   while(sz && cs_disasm_iter(h,&code,&sz,&addr,insn)){
     const cs_x86 &x=insn->detail->x86;
     for(uint8_t i=0;i<x.op_count;i++) if(x.operands[i].type==X86_OP_MEM && x.operands[i].mem.base==X86_REG_RIP){
       uint64_t t=insn->address+insn->size+x.operands[i].mem.disp;
       auto it=refs.find(t); if(it!=refs.end()) it->second.push_back({IMAGE_BASE+begin,IMAGE_BASE+end,insn->address,insn->mnemonic,insn->op_str});
     }
   }
 }
 std::ofstream o("/home/user/analysis/join_replication_string_xrefs.txt");
 o<<".text/.pdata functions scanned: "<<fcount<<"\n";
 for(size_t i=0;i<target.size();i++){
  auto &v=refs[target[i]]; o<<"\nSTRING "<<labels[i]<<"\n  VA=0x"<<std::hex<<target[i]<<std::dec<<" xrefs="<<v.size()<<"\n";
  for(auto &r:v) o<<"  fn=0x"<<std::hex<<r.start<<"-0x"<<r.end<<" ref=0x"<<r.at<<std::dec<<": "<<r.mnemonic<<" "<<r.operand<<"\n";
 }
 std::cout<<"scanned "<<fcount<<" functions; wrote xrefs\n";
 cs_free(insn,1);cs_close(&h);
}
