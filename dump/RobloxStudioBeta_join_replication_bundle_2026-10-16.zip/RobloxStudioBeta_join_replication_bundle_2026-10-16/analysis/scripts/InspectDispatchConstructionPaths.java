import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;
import java.io.FileWriter;
import java.io.PrintWriter;

public class InspectDispatchConstructionPaths extends GhidraScript {
    private Address addr(String s) {
        return currentProgram.getAddressFactory().getDefaultAddressSpace()
            .getAddress(Long.parseUnsignedLong(s, 16));
    }

    @Override
    public void run() throws Exception {
        String outPath = "/home/user/analysis/dispatch_construction_paths.txt";
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");
        FunctionManager fm = currentProgram.getFunctionManager();
        try (PrintWriter out = new PrintWriter(new FileWriter(outPath))) {
            out.println("Static caller/callee context for dispatcher construction paths. Target not executed.");
            String[] callsites = {"14377ad09", "14377b15a", "1437b4e57", "1437b8634"};
            for (String s : callsites) {
                Address a = addr(s);
                Function f = fm.getFunctionContaining(a);
                out.println("\n\nCALLSITE " + a + " function=" + (f == null ? "<none>" : f.getName()+" @ "+f.getEntryPoint()+" end="+f.getBody().getMaxAddress()));
                if (f != null) {
                    out.println("signature=" + f.getSignature());
                    DecompileResults r = decomp.decompileFunction(f, 60, monitor);
                    if (r != null && r.decompileCompleted() && r.getDecompiledFunction() != null) out.println(r.getDecompiledFunction().getC());
                    else out.println("DECOMPILATION FAILED: " + (r == null ? "null" : r.getErrorMessage()));
                }
            }
            String[] targets = {"1437a7ec0", "1437ae0c0", "14377abd0", "14377b020", "14377ab20", "14377b290", "1437e37b0", "1437e3850", "1435deac0", "1437e2260", "1476beb74"};
            for (String s : targets) {
                Address target = addr(s);
                out.println("\n\nTARGET " + target);
                ReferenceIterator refs = currentProgram.getReferenceManager().getReferencesTo(target);
                int n = 0;
                while (refs.hasNext() && n < 100) {
                    Reference ref = refs.next();
                    Address from = ref.getFromAddress();
                    Function f = fm.getFunctionContaining(from);
                    out.println("  from=" + from + " type=" + ref.getReferenceType() + " caller=" + (f == null ? "<none>" : f.getName()+" @ "+f.getEntryPoint()));
                    n++;
                }
                out.println("  refCount=" + n);
            }
        } finally {
            decomp.dispose();
        }
        println("Wrote " + outPath);
    }
}
