import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import java.io.FileWriter;
import java.io.PrintWriter;

public class DecompileRtcIoConstructionHelpers extends GhidraScript {
    private static final String[] VAS = {"1437a7ec0", "1437ae0c0", "1437b0100", "14377ab20", "14377b290"};
    @Override public void run() throws Exception {
        DecompInterface d = new DecompInterface();
        d.setOptions(new DecompileOptions()); d.toggleCCode(true); d.toggleSyntaxTree(true); d.setSimplificationStyle("decompile");
        if (!d.openProgram(currentProgram)) throw new Exception("Could not open program");
        FunctionManager fm=currentProgram.getFunctionManager();
        try (PrintWriter out=new PrintWriter(new FileWriter("/home/user/analysis/rtc_io_construction_helpers.txt"))) {
            out.println("Static decompilation of RtcIo connection-construction callsites/helpers. Target not run.");
            for(String s: VAS){
                Address a=currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(s); Function f=fm.getFunctionAt(a);
                out.println("\n\nFUNCTION "+s+" @ "+a);
                if(f==null){out.println("NO FUNCTION ENTRY");continue;}
                out.println("name="+f.getName()+" end="+f.getBody().getMaxAddress()+" signature="+f.getSignature());
                DecompileResults r=d.decompileFunction(f,45,monitor);
                if(r!=null&&r.decompileCompleted()&&r.getDecompiledFunction()!=null)out.println(r.getDecompiledFunction().getC());
                else out.println("DECOMPILATION FAILED: "+(r==null?"null":r.getErrorMessage()));
                System.gc();
            }
        } finally {d.dispose();}
        println("Wrote /home/user/analysis/rtc_io_construction_helpers.txt");
    }
}
