import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionManager;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.SourceType;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class ForceDecompileChannelCallbacks extends GhidraScript {
    private static final String[] STARTS = {
        "1437763f0", "14377d770", "14377ddd0", "1437984f0",
        "143798600", "143798cf0", "1437982d0", "143798a30"
    };

    @Override
    public void run() throws Exception {
        MemoryBlock pdata = null;
        for (MemoryBlock b : currentProgram.getMemory().getBlocks()) {
            if (b.getName().equals(".pdata")) { pdata = b; break; }
        }
        if (pdata == null) throw new Exception("No .pdata");
        byte[] bytes = new byte[(int)pdata.getSize()];
        currentProgram.getMemory().getBytes(pdata.getStart(), bytes);
        ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        long imageBase = currentProgram.getImageBase().getOffset();
        FunctionManager fm = currentProgram.getFunctionManager();
        DecompInterface decomp = new DecompInterface();
        decomp.setOptions(new DecompileOptions());
        decomp.toggleCCode(true);
        decomp.toggleSyntaxTree(true);
        decomp.setSimplificationStyle("decompile");
        if (!decomp.openProgram(currentProgram)) throw new Exception("Could not open program");
        try (PrintWriter out = new PrintWriter(new FileWriter("/home/user/analysis/channel_callbacks_decomp.txt"))) {
            for (String s : STARTS) {
                Address start = toAddr(Long.parseUnsignedLong(s, 16));
                long rva = start.getOffset() - imageBase;
                long endRva = -1;
                for (int i = 0; i + 12 <= bytes.length; i += 12) {
                    long begin = Integer.toUnsignedLong(bb.getInt(i));
                    long end = Integer.toUnsignedLong(bb.getInt(i + 4));
                    if (begin == rva && end > begin) { endRva = end; break; }
                }
                if (endRva < 0) { out.println("NO_PDATA " + s); continue; }
                Address end = toAddr(imageBase + endRva - 1);
                AddressSet body = new AddressSet(start, end);
                DisassembleCommand dc = new DisassembleCommand(start, body, true);
                boolean disassembled = dc.applyTo(currentProgram, monitor);
                Function f = fm.getFunctionAt(start);
                if (f == null) {
                    try { f = fm.createFunction(null, start, (AddressSetView)body, SourceType.ANALYSIS); }
                    catch (Exception e) { out.println("CREATE_FAILED " + s + " " + e); }
                } else {
                    try { f.setBody((AddressSetView)body); }
                    catch (Exception e) { out.println("SETBODY_FAILED " + s + " " + e); }
                }
                out.println("\n\nFUNCTION " + s + " end=" + end + " disassembled=" + disassembled +
                    " function=" + (f == null ? "<none>" : f.getName() + " body=" + f.getBody().getNumAddresses()));
                if (f != null) {
                    DecompileResults result = decomp.decompileFunction(f, 60, monitor);
                    if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null) {
                        out.println(result.getDecompiledFunction().getC());
                    } else {
                        out.println("DECOMPILATION_FAILED " + (result == null ? "null" : result.getErrorMessage()));
                    }
                }
                System.gc();
            }
        } finally {
            decomp.dispose();
        }
        println("Wrote /home/user/analysis/channel_callbacks_decomp.txt");
    }
}
