# Bundle index — Join/Replication analysis and C++ reconstruction

This package contains the current portable C++ reconstruction and the available text/static-analysis artifacts for the RobloxStudioBeta networking work, including the earlier transport/channel and `0x80` Mrd findings. The dated Join/Replication mapping is the latest summary; the decompilation outputs and code are the underlying workspace artifacts.

## Package contents

- `reconstruction/` — C++17 reconstruction, headers, source files, tests, Makefile, CMakeLists, and the repository README. The three latest join/Replication changes are in `include/rbx_channel_protocol.hpp`, `src/rbx_channel_protocol.cpp`, and `tests/test_channel_protocol.cpp`.
- `analysis/` — analysis notes, Ghidra decompilation text, native xref scans, scripts, string/RTTI tables, and Ghidra logs. The 2026-10-16 Join/Replication report and direct callgraph are included.
- `reference/` — auxiliary candidate code previously consulted for navigation only. It is **not** evidence of the target executable's implementation; target-side claims are grounded in the included decompilation/xref artifacts.
- `previous_reports/RobloxStudioBeta_network_reconstruction_report.md` — earlier summary report retained for historical context.

## Validation

Portable test command, from `reconstruction/`:

```sh
make clean test
```

The latest run passed all three C++17 test programs. No Windows/MSVC build or target execution is claimed.

## Intentionally excluded

- The authorized `RobloxStudioBeta.exe` and downloaded archive: the bundle does not redistribute the target binary.
- Ghidra project databases: readable decompilation text, scripts, and logs are included instead.
- The extracted Ghidra/JDK tool installation and generated `reconstruction/build/` binaries: neither is required to review the source/evidence; build outputs can be regenerated.
- The older reconstruction ZIP nested inside this package: the current source project is included directly.
