# RobloxStudioBeta join/Replication analysis + C++ bundle

Start with `analysis/join_replication_mapping_2026-10-16.md` for the latest target-side Join/Replication findings and `analysis/bundle_index_2026-10-16.md` for the complete inventory and exclusions.

`reconstruction/` contains the C++17 source project, including the current join/Replication parser, tests, and earlier transport/channel/Mrd reconstruction. Build/test with `make clean test` from that directory. The target executable was not included and was not run.

`analysis/` contains the static decompilation outputs, xref scans, scripts, logs, and earlier scope notes. `reference/` contains auxiliary candidate code only; it is not target-version proof.
