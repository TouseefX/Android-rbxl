# RobloxStudioBeta.exe — network reconstruction (RbxTransport, Network, NetworkBase)

**Analysis date:** 2026-10-16 (Asia/Dubai)  
**Target:** the user's supplied Roblox Studio package; static analysis only.  
**Status:** partial, buildable clean-room C++17 reconstruction of selected Windows socket policy, channel-control behavior, a bounded join-data envelope, and the payload-bearing Mrd `0x80` helper path. The width-6 value is a backward-reference delta into a newest-first history ring; the `FUN_1430790a0`/`FUN_143077dc0` consumer-to-callback boundary is mapped. The referenced component's domain meaning, its connection to specific `RBX::Network`/`NetworkBase`/Replicator code, complete network behavior, and RBXL place writing remain open.

## Environment and setup

- Sandbox: Debian 13 x86-64, 2 CPUs, roughly 1.9 GiB RAM, about 21 GiB free disk. System Java was OpenJDK 11; no Ghidra, Windows cross-compiler, or CMake was initially present.
- The originally retained Ghidra/JDK paths were incomplete. For the 2026-10-16 targeted pass, re-downloaded the official Ghidra **12.1.4** distribution (SHA-256 `ddac49f903da9d5bac833e5cc79395098b9c33cfd3279be5f31bd00387d2d4db`) and Temurin **JDK 21.0.12.1** to session-local cache paths; Java 21 started successfully and Ghidra headless launched. These cache paths are ephemeral and may not persist with the workspace snapshot.
- Extracted only `RobloxStudioBeta.exe` from the user-provided zip. For the latest pass it is at session-temporary `/tmp/RobloxStudioBeta.exe`; SHA-256 `cc70176d50d5f2c1edc26d40f1fcdc530748fc83dedc63c2fdbb251f766972d2`. The EXE is **225,310,672 bytes**, PE32+ / Windows x86-64, 9 sections, preferred image base `0x140000000`. Source zip SHA-256: `5d893bc30ad276b9c4b154ab213b0ea75e5bc2946f6f5dfe952169bdcb2b3346`. The binary was read as data only.
- Ghidra detected **Portable Executable (PE)**, language `x86:LE:64:default`, compiler `windows`. No matching PDB was in the archive; the executable's debug directory refers to one that is not available here.
- Full-program Ghidra analysis remains impractical under the sandbox memory ceiling; the latest pass used a 512 MiB Java heap and `-noanalysis`, then forced targeted disassembly/function creation and decompilation for selected addresses. This produced `/home/user/analysis/mrd_0x80_semantic_trace.txt`, including the outer format dispatcher `FUN_143079540`, Mrd consumer `FUN_1430790a0`, and item-dispatch bridge `FUN_143077dc0`. The global Microsoft RTTI analyzer also previously exhausted Java heap while building bulk vtable-search patterns. No target code was run.
- Session-local command used for the latest targeted trace (temporary Ghidra/JDK/target paths may no longer exist after the session):

  ```sh
  export JAVA_HOME=/home/user/.cache/temurin21
  export PATH="$JAVA_HOME/bin:$PATH"
  export GHIDRA_HEADLESS_MAXMEM=512M
  export GHIDRA_HEADLESS_JAVA_OPTIONS='-Djava.io.tmpdir=/home/user/.cache/ghidra_scratch'
  /home/user/.cache/ghidra12/ghidra_12.1.4_PUBLIC/support/analyzeHeadless \
    /home/user/ghidra_mrd_work RobloxNetwork \
    -import /tmp/RobloxStudioBeta.exe -noanalysis -scriptPath /home/user/analysis/scripts -postScript ForceDecompileMrdSemanticTrace.java -log /home/user/analysis/ghidra_mrd_semantic_20261016.log
  ```

## Scope

The initial pass interpreted “Network / RbxTransport mostly network” as Roblox's own `RBX::RbxTransport` stack, not every network-related dependency in Studio. It covered `Impl::Io` Windows/Libuv socket families, selected protocol/HTTP/3/QUIC/RTC-Io type metadata, and directly related helpers. It did **not** complete the broader requested `RBX::Network` / `Network::`, `RBX::NetworkBase`, join/replication, or RBXL-writer analysis. The channel-control extension below adds a focused RbxTransport control slice, not full scope coverage. Qt Network, WebRTC internals, WinINet, gRPC/Envoy and other unrelated or third-party networking code were not decompiled.

Ghidra decompiled **80 selected functions**: 46 selected vtable entries, 13 `SysTcpSocket` entries and 21 helper functions. Three additional requested helper addresses were not function entries. The exact list and raw Ghidra output are in the workspace under `/home/user/analysis/` (`rbx_vtables.txt`, `ghidra_network_decomp.txt`, `ghidra_sys_tcp_decomp.txt`, and `ghidra_network_helpers.txt`). These are supporting analysis artifacts, not original source.

## Findings

### Stack outline

RTTI/type-name evidence identifies these in-house components (namespaces and types are from the binary; function/method names inferred from behavior are marked provisional):

- `RBX::RbxTransport::Impl::Io::{SysTcpSocket, SysUdpSocket, LibuvTcpSocket, LibuvUdpSocket}`
- `RBX::RbxTransport::Impl::Io::{SysEventLoop, LibuvEventLoop, SysPollerMswin, LibuvPoller, Tcp/Udp socket interfaces}`
- `RBX::RbxTransport::Protocol::{QuicClientConnection, QuicServerConnection, QuicCryptoClientContext, QuicCryptoServerContext}`
- `RBX::RbxTransport::Http::{H3Connection, WtSession}`
- `RBX::RbxTransport::Impl::{RtcIoClientConnection, RtcIoServerConnection, RtcIoQuicClientConnection, RtcIoWtClientConnection}`

The binary also contains strings for `RbxTransport/Io/sys`, `RbxTransport/Io/libuv`, `RtcIoClientConnectionBase::openSendChannel`, and `RbxTransport/RtcIo/Remote/...` events including `Handshake`, `AcceptH3`, `AcceptWtSession`, `FlowControl`, `Loss`, `Rx`, and `StreamClose`. These support the component map but do not, by themselves, prove the full protocol state machine.

### Concrete socket behavior recovered from selected Ghidra decompilations

- **TCP bind/options — `FUN_1435eb9a0`**, identified as a `SysTcpSocket` vtable target: conditionally calls Winsock `setsockopt` before bind. The immediate constants are level `0x29`/option `0x1b` (the standard `IPPROTO_TCP`/`TCP_NODELAY` pair) and level `0xffff`/option `4` (the Winsock `SOL_SOCKET`/`SO_REUSEADDR` pair), then the call shape matches `bind(socket, sockaddr, length)`.
- **TCP connect — `FUN_1435ed4a0`**: obtains a socket handle and calls WS2_32 ordinal 4 with a socket/address/length-shaped argument list; the return path distinguishes success from failure and goes through a Roblox error/result helper. The ordinal mapping identifies this as `connect`.
- **Local and peer address — `FUN_1435ed9f0` / `FUN_1435ef2c0`**: calls WS2_32 ordinals 6 and 5 respectively, matching `getsockname` and `getpeername`.
- **UDP message send — `FUN_1435f5d80`**: constructs a message/buffer structure and calls the imported `WSASendMsg` entry. The exact ancillary-data layout and overlapped/completion details are not fully recoverable from the decompiler output.
- **UDP options — `FUN_1435f5330` / `FUN_1435f2c20`**: use WS2_32 ordinals 21 and 7 (setsockopt/getsockopt). The handler includes literals `Cannot disable dontFragment in IPv6`, `IP_PKTINFO is not supported on this platform`, `IP_RECVERR is Linux-specific`, `SO_TIMESTAMPNS is Linux-specific`, and `Unknown option: {}`. The `IP_DONTFRAGMENT` interpretation is inferred from option level/name constants plus the string; the original option enum is not recovered.
- **Duplicate async receive guard — `FUN_1435f4530`**: one branch reports `There is an asynchronous recv in progress already`. The corresponding reconstruction keeps a single-pending-receive guard; the original poller/deferred-operation lifetime rules are not reproduced.
- **UDP batch option:** `MaxSameIterationRecv MUST be positive` is present in a `SysUdpSocket` option path. The source reconstruction models the positive-value constraint but does not claim to recover the original enum/field layout.
- **Libuv option behavior:** a `LibuvUdpSocket` vtable path returns `This platform does not support SO_REUSEPORT`. A Libuv TCP option path contains `Invalid value for the given option` and `Unknown option: {}`. The complete option mapping is unknown.
- **TLS/QUIC diagnostics:** selected QUIC crypto/TLS paths contain `Certificate file {} not found`, `TlsContext::initClient failed`, and `Failed to initialize TLS client session`. The full certificate-selection and QUIC handshake implementation is not reconstructed.
- **Runtime imports:** `WS2_32.dll` includes named imports such as `WSASocketW`, `WSAConnect`, `WSASendMsg`, `WSASendTo`, `WSARecv`, `WSARecvFrom`, `WSAIoctl`, `WSAPoll`, address conversion/resolution helpers, and ordinal imports. The executable also imports `bcrypt.dll`, `CRYPT32.dll`, `IPHLPAPI.DLL`, and `WININET.dll`; import presence alone does not attribute every call to `RbxTransport`.

The PE imports these Winsock functions by ordinal in several cases. Ordinals 2, 4, 5, 6, 7, 21, 111, 115 and 116 were cross-checked against the public [Wine `ws2_32.spec` compatibility map](https://raw.githubusercontent.com/wine-mirror/wine/master/dlls/ws2_32/ws2_32.spec); the standard function definitions are documented by Microsoft [1](https://learn.microsoft.com/en-us/windows/win32/api/winsock2/). The Wine mapping is a compatibility reference, not a Roblox symbol file.

## Reconstructed code

The full C++17 project is in `/home/user/reconstruction/`; the source bundle is `RobloxStudioBeta_RbxTransport_reconstruction.zip`. The code is **analyst-written** and makes uncertainty explicit. It reconstructs the synchronous socket-call surface, selected UDP option/error behavior, the duplicate-receive guard, and TLS diagnostic surfaces. `AsyncReceiver` and `TlsClientProvider` are explicit interfaces where the binary's implementation details were not recovered.

Key reconstructed methods (the complete files are separate buildable source files):

```cpp
// include/rbx_transport_reconstruction.hpp / src/rbx_transport_reconstruction.cpp
Status SysTcpSocket::bind(const Endpoint& local, TcpBindOptions options) {
    if (options.noDelay) {
        Status status = api_.setOption(socket_, SocketOption::TcpNoDelay, 1, local.family);
        if (!status.ok()) return status;
    }
    if (options.reuseAddress) {
        Status status = api_.setOption(socket_, SocketOption::ReuseAddress, 1, local.family);
        if (!status.ok()) return status;
    }
    return api_.bind(socket_, local);
}

Status SysTcpSocket::connect(const Endpoint& peer) {
    return api_.connect(socket_, peer);
}

// SysUdpSocket::beginAsyncReceive rejects a second outstanding receive,
// then clears the pending bit on completion or initiation failure.
Status SysUdpSocket::beginAsyncReceive(AsyncReceiver& receiver,
                                       ReceiveCompletion completion) {
    const auto state = receiveState_;
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        if (state->pending) {
            return Status::failure(ErrorKind::AlreadyInProgress,
                                   "There is an asynchronous recv in progress already");
        }
        state->pending = true;
    }
    auto wrapped = [state, completion = std::move(completion)](
                       Status status, Endpoint source,
                       std::vector<std::uint8_t> bytes) mutable {
        { std::lock_guard<std::mutex> lock(state->mutex); state->pending = false; }
        if (completion) completion(std::move(status), source, std::move(bytes));
    };
    Status status = receiver.startReceive(socket_, std::move(wrapped));
    if (!status.ok()) {
        std::lock_guard<std::mutex> lock(state->mutex);
        state->pending = false;
    }
    return status;
}
```

For the Windows adapter, `src/winsock_socket_api.cpp` maps the reconstructed interface to `WSASocketW`, `WSAConnect`, `bind`, `getsockname`, `getpeername`, socket options, `WSAIoctl` resolution of the `WSASendMsg` extension pointer, and `WSAStartup`/`WSACleanup`. The adapter's async receive provider remains abstract rather than inventing the target's event-loop behavior.

## Added channel-control reconstruction slice (2026-10-15)

This second pass extends `/home/user/reconstruction/` with `include/rbx_channel_protocol.hpp`, `src/rbx_channel_protocol.cpp`, and `tests/test_channel_protocol.cpp`. It is analyst-written behavior modeling based on selected implementation code, not a source restoration.

- **Fourteen-channel profile:** `FUN_144c25af0` returns three row fields per channel index. The reconstruction identifies only `mode == 1` as unreliable and keeps the other fields neutral (`auxiliary`, `flag`). The default profile's unreliable indices are 3, 5, 6, and 11. `configureChannels` calls the narrow open-channel interface in index order and returns the first failure instead of reproducing the target's fatal path.
- **Reliable open:** `FUN_143816d50` is slot 1 of the `OpenReliableChannelControl` vtable. It initializes a 6-byte body and writes type, application, and one DWORD. `FUN_1437a7980` writes a one-byte field before that body. The serializer emits `0x06`, the expected body-size value; the exact internal length calculation remains provisional.
- **Unreliable open:** `FUN_143816e10` is slot 1 of the `OpenUnreliableChannelControl` vtable. It initializes a 10-byte body: type `0x02`, application byte, channel-index DWORD, and nonnegative ID-magnitude DWORD. `FUN_14379c270` constructs this control with the channel index, ID, and `"ctrl"` tag. `FUN_147757cd0` calls Winsock ordinal 8 before storing a DWORD; that supports network-byte-order serialization, though the import name was not recovered in the targeted disassembly.
- **IDs and state:** clean-room helpers represent local IDs as negative signed values and serialize positive magnitudes, with parity-separated allocation and peer-ID validation. The link from allocation order to channel order is conditional: channels 3, 5, 6, 11 receive `-2, -4, -6, -8` only if their callbacks are processed in that order. `ChannelControlState`'s duplicate-open rejection is a safe local guard; the target's reset/reopen lifecycle is unresolved.
- **Dispatch:** the reconstruction captures the observed same-thread inline-call versus other-thread executor-submit branch. The executor is injected and its scheduling/FIFO properties are deliberately unspecified.
- **Framing boundary:** `FUN_1437984f0` dispatches parsed control types 0, 1, and 2. That does not prove the outer framing. The separate Mrd `0x80` helper path is now mapped and implemented as a byte codec below; it is not equated with these channel-control types or with the provisional reliable length byte `0x06`. The `0x80` value's backward-reference/distance semantics are mapped separately; its combined-data domain meaning and relation to these channel controls remain unresolved.

## Broader Network / NetworkBase static extension (2026-10-15)

The follow-on used retained RTTI/vtable output plus targeted decompilation; details and raw outputs are in `/home/user/analysis/network_scope_extension_2026-10-15.md`. The target `JoinDataItemV2` builders `FUN_145f94050` and `FUN_145f944b0` emit `83 16 01` and `83 16 05`; their shared `FUN_145dba600` wrapper writes the compressed-byte count, the uncompressed/input byte count (the source stream's vtable `+0x10` value also passed as compressor input length), then the compressed bytes, with a conditional zero trailer. The builders pass transform setting `1` with worker count `0`; the low-worker configuration path preserves setting `1`, and `FUN_1476d6890` writes frame magic `0xfd2fb528` (little-endian bytes `28 b5 2f fd`), confirming Zstandard framing at level `1`. The exact compression implementation/options and output compatibility are not reconstructed. `FUN_142a14360` confirms the raw capacity-check/copy/advance path. On receive, `FUN_145fccad0` calls through `+0x538`; extending the vtable scan beyond its previous 128-slot cap shows slot 167 in both `Replicator` and `ClientReplicator` points to `FUN_145dd0350`, which iterates `0xd8`-stride in-memory join records and calls each record's slot-1 handler. Neither `0x58` nor `0xd8` is established as a wire record size. The C++ code serializes only the bounded envelope and does not compress or construct item bodies. The separate Mrd `0x80` writer/reader path now has a mapped backward-reference delta, newest-first history-ring lookup, and parser-to-item-callback boundary. Its component's domain meaning and connection to these join records remain unresolved; the RbxTransport backend path and `NetworkStream` codec methods are not yet connected/mapped.

## Targeted Mrd `0x80` payload-bearing codec path (2026-10-15)

The user's `0x80` lead was traced as a paired lower-level writer/reader format in the supplied executable; it is not being reclassified as a varint width/length prefix. The parent-function decompilation is retained in `/home/user/analysis/mrd_0x80_whole_functions.txt`, generated by `/home/user/analysis/scripts/ForceDecompileMrdWireTrace.java`. The script was run in Ghidra 12.1.4 against the existing imported program with analysis disabled; the target binary itself was never executed.

- **Writer helper and tag meaning:** `FUN_14307e370` (`0x14307e370`–`0x14307e4ff`) writes a caller-supplied first-byte prefix, then calls `FUN_14307dd30` to merge a bounded-width value into that byte. For the selected `0x80` path, the prefix is `0x80` and width is 6. Values below `0x3f` occupy the low six bits; values at/above that sentinel use `0x3f` followed by unsigned 7-bit continuation groups encoding `value - 0x3f`. The exact helper instructions (the address lacks an exact `.pdata` entry) are retained in `/home/user/analysis/mrd_0x80_helper_disassembly.txt`. The width-6 value is not an arbitrary message ID in this writer path: `FUN_14307c740` obtains a cached entry sequence from `FUN_14307d360` and emits `currentSequence - cachedSequence - 1`. The paired parser computes `currentSequence - encodedValue - 1` and routes the `0x80`/bit-6-clear family through `FUN_14307a700`, which looks up a prior entry and constructs a new queued record using that entry's first component plus the newly decoded payload. This establishes a backward-reference delta; the domain-level meaning of the combined data remains unknown. The helper then writes a separate width-7 payload-byte-count field. Its prefix is `0x80` for Huffman and `0` for raw data, so the top bit marks compression and the lower seven bits carry the count (with the same continuation rule when saturated).
- **Compression selection and bytes:** `FUN_143084970` sums the target code lengths and returns `(totalBits + 7) >> 3`. `FUN_14307e370` selects Huffman only when this byte count is strictly less than the raw payload size; otherwise it copies raw bytes. `FUN_143084870` writes the target's MSB-first, left-aligned codes and fills unused low bits of the final byte with ones.
- **Matching reader path and neighboring family:** `FUN_1430790a0` passes its input to `FUN_14307af50` using the parser state at object offset `+0x150`. `FUN_14307af50` dispatches high-bit tag families, sets a width-6 field reader, and in the `0x80` payload-bearing path reads the next width-7 value plus its high-bit compression flag. For this path, the first-byte bit-6 state selects `FUN_14307a700`, whose history lookup matches the writer's backward-delta arithmetic. The neighboring `0xc0` family clears that state and routes through `FUN_14307ab00`, which indexes a static target table at `0x14c8be9e0` with `0x48`-byte entries; it is not conflated with the user's `0x80` path. Raw bytes are copied directly; compressed bytes pass through `FUN_14307f3b0` / `FUN_143084760`. The target rejects encoded payload lengths above `0x10000`, allocates a Huffman output buffer of `2 * compressedSize + 1`, and caps aggregate parser input at `0x20000`. The parser also checks current parser/buffer state before entering payload states; the later-traced outer numeric mode dispatcher is only partially recovered. Accordingly, the C++ decoder parses one complete helper-emitted payload unit, not the entire `FUN_14307af50` state machine or outer record dispatch.
- **Target tables:** the 256-entry encoder table at VA `0x148d45c00` is 2,048 bytes with SHA-256 `05a119ba76df924cbcad8bf3066ea1d023c0cef8f4be6ddc107a8b7f57595093`. Lengths range from 5 to 30 bits; codes are unique and prefix-free. The decoder transition table at VA `0x148d46410` is 4,194,304 bytes with SHA-256 `c9bd00a073f505ced0b226941f80457cd19aefbea1c665496d3b2806d57692c3`. The C++ initializer `src/mrd_huffman_table.inc` contains the exact extracted 256 pairs.
- **Clean-room implementation:** `/home/user/reconstruction/include/rbx_mrd_wire_codec.hpp` and `src/rbx_mrd_wire_codec.cpp` implement this bounded helper path with 62-bit field-overflow protection, target-derived payload/output limits, raw-vs-Huffman selection, and an MSB-first trie decoder. `tests/test_mrd_wire_codec.cpp` covers sentinel/continuation boundaries, raw and compressed golden bytes, one-bit padding, malformed and truncated input, concatenated units, limits, and deterministic round trips. The API names the decoded width-6 field `backReferenceDelta`, matching the recovered `currentSequence - priorSequence - 1` arithmetic; the C++ helper still does not store history or infer the referenced data's domain type.
- **Static verification:** `/home/user/analysis/scripts/verify_mrd_0x80_static.py` reads the executable as data, checks both table hashes and every C++ encoder-table entry, and simulates generated bytes through the target's extracted decoder transition table. It passed 65,802 payloads (all 256 one-symbol and 65,536 ordered two-symbol inputs, plus fixed and seeded random samples through 4,096 bytes), each decoded exactly and reached the decoder's accepting final state. The result is recorded in `/home/user/analysis/mrd_0x80_static_verification.txt`. This is table/model validation, not target execution.

## Mrd history ring and decoded-item dispatch bridge (2026-10-16)

The new targeted trace is in `/home/user/analysis/mrd_0x80_semantic_trace.txt`; the relevant ring-helper instruction windows are in `/home/user/analysis/mrd_0x80_history_ring_helpers.txt`.

- **Outer mode dispatch:** `FUN_1430792b0` is a feed/dispatch path that can call `FUN_143079540`, which reads a leading discriminator and sets parser mode at `+0x1f8`. Observed discriminator values 0, 2, and 3 route respectively to `FUN_143078480`, the Mrd consumer `FUN_1430790a0`, and `FUN_14307d6f0`; value 1 is rejected. `FUN_1430792b0` also has a separate path to `FUN_143077dc0`. These are raw mode branches, not inferred application-level names.
- `FUN_14307a700` resolves the decoded sequence value back to a prior sequence and then calls `FUN_14307fec0` with `(currentSequence - priorSequence - 1)`. The ring accessor uses a base pointer, element stride at `+0x18`, capacity at `+0x10`, head at `+0x20`, and count at `+0x28`; it calculates `base + (((head + index) & (capacity - 1)) * stride)`. `FUN_14307ffe0` decrements the head modulo the capacity before returning the inserted slot. Thus, for this path, ring index 0 is the newest entry, and encoded delta 0 selects the immediately preceding cached sequence; increasing delta selects older entries. The parser's item-extent call `FUN_143079fe0` is RTTI-mapped as slot 0 of the `RBX::Network::MrdModeItemizedInstance` vtable `0x14931fd78`; it returns `*(this+0x18) - *(this+0x10)`. This names a related Mrd item-interface, but does not by itself establish the full domain meaning of the referenced component.
- `FUN_1430790a0` calls the parser `FUN_14307af50`, drains the resulting item queue, and calls `FUN_143077dc0` for each item. On success it advances that item's cursor; when a nonzero parsed result is returned, it may invoke a callback stored at object offset `+0x98` with item metadata. `FUN_143077dc0` branches on raw parser/item fields (including `+0x220`, `+0x248`, and `+0x260`) and conditionally dispatches through callback pointers at offsets `+0x90`, `+0xa0`, `+0xb0`, `+0xb8`, `+0xc8`, and `+0xd8`. The object's concrete class and the callback targets' domain meanings are not recovered. This is a verified internal parser-to-callback boundary, not yet a proven connection to `RBX::Network`, `NetworkBase`, Replicator, or the RbxTransport `+0x890` backend.

## Validation

- **Static analysis:** PE metadata/import inspection and targeted RTTI/vtable scans completed. The newly forced Ghidra decompilation of `FUN_1430792b0`, `FUN_143079540`, `FUN_1430790a0`, `FUN_143077dc0`, and related Mrd functions succeeded under `-noanalysis`; the output includes assembly listings and decompiled C. Full-program auto-analysis and full RTTI recovery remain unsuccessful under the sandbox memory limit. Broader `RBX::Network` / `NetworkBase`, join/replication, and RBXL writing remain outstanding.
- **Portable code build/test:** On 2026-10-16, `make clean test` in `/home/user/reconstruction` compiled the portable C++17 core with `g++ -O2 -Wall -Wextra -Wpedantic`. All three executables passed: `transport reconstruction tests passed`, `channel protocol reconstruction tests passed`, and `Mrd 0x80 wire codec tests passed`. The static verifier was rerun and passed 65,802 payloads against the target-derived decoder model. A direct CMake configure attempt could not run because `cmake` is not installed in this sandbox.
- **Windows adapter:** not compiled or linked here; the sandbox has no MSVC/MinGW toolchain. The code is intended for the Windows SDK and `Ws2_32.lib`, but a Windows build is **not confirmed**.
- **Target execution:** not performed. No dynamic behavior, live network access, Roblox server interaction, or target modification was performed.

## Caveats and next steps

- This is not a whole-network-stack clone. QUIC, HTTP/3, WebTransport/`WtSession`, `RtcIo`, the Libuv loop/poller, crypto internals, and higher-level packet framing remain only partially mapped or interface-only.
- No matching PDB was supplied. Ghidra's function names are generic `FUN_...`; `SysTcpSocket::bind/connect/getLocalName/getPeerName` are analyst labels based on vtable placement, argument shapes, and imported call ordinals.
- The global RTTI analyzer exhausted Java heap, so the report makes no claim that all classes, inheritance edges, or function references were found. Static addresses and vtable slot numbers are build-specific.
- The reconstructed Windows adapter and the original Roblox implementation are not behaviorally equivalent by proof. The portable socket-policy, channel-control, bounded join-envelope, and Mrd `0x80` helper-codec slices were built and tested; the socket/channel tests use fakes, and the Mrd table check is a static model comparison. Validate on a disposable Windows test harness before using any networking code with a real service.
- To extend this, supply a matching PDB or name exact target methods/protocols (for example, `SysUdpSocket`, `QuicClientConnection`, `H3Connection`, or `RtcIoClientConnection`) and the next pass can stay constrained to those methods.
