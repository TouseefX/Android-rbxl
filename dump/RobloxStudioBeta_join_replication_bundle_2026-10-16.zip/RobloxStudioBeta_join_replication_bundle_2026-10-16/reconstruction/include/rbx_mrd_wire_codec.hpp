#pragma once

// Clean-room, bounded reconstruction of the target's payload-bearing 0x80 Mrd helper path.
// This is the complete byte unit emitted by FUN_14307e370, not the outer Mrd dispatch or
// all branches of FUN_14307af50. Static target analysis identifies the width-6 value as a
// backward-reference delta; no application-level meaning is assigned to the referenced data.

#include <cstddef>
#include <cstdint>
#include <vector>

namespace rbxtransport::reconstruction::mrd {

inline constexpr std::size_t kTargetMaxMrdPayloadBytes = 0x10000;
inline constexpr std::size_t kTargetMaxHuffmanOutputBytes = 0x20000;
inline constexpr std::size_t kTargetMaxMrdRecordBytes = 0x20000;
inline constexpr std::uint64_t kTargetMaxMrdFieldValue = 0x3fffffffffffffffULL;

struct Mrd80CodecLimits {
    // Defaults mirror the reader's 0x10000 payload-length check, 0x20000
    // aggregate input cap, and 2 * compressed-size + 1 output allocation.
    std::size_t maxPayloadBytes{kTargetMaxMrdPayloadBytes};
    std::size_t maxDecodedBytes{kTargetMaxHuffmanOutputBytes};
    std::size_t maxRecordBytes{kTargetMaxMrdRecordBytes};
};

enum class MrdWireError {
    None,
    InvalidArgument,
    NeedMoreData,
    InvalidTagFamily,
    FieldValueOverflow,
    PayloadLimitExceeded,
    RecordLimitExceeded,
    InvalidHuffmanData,
    DecodedPayloadLimitExceeded,
};

struct Mrd80Record {
    // Width-6 value after the 0x80 family prefix. In the matched writer/reader path,
    // the writer emits currentSequence - priorSequenceIndex - 1; the parser reverses
    // that arithmetic before selecting a prior record. The record-container lookup itself
    // is not part of this byte codec.
    std::uint64_t backReferenceDelta{0};
    bool huffmanCompressed{false};
    std::vector<std::uint8_t> payload;
    std::size_t bytesConsumed{0};
};

struct MrdEncodeResult {
    std::vector<std::uint8_t> bytes;
    MrdWireError error{MrdWireError::None};

    bool ok() const noexcept { return error == MrdWireError::None; }
};

struct MrdDecodeResult {
    Mrd80Record record;
    MrdWireError error{MrdWireError::None};

    bool ok() const noexcept { return error == MrdWireError::None; }
};

// Writes the target serializer's 0x80-prefixed width-6 field, then the separate
// width-7 payload byte-count field. Huffman is selected only if its byte count is
// strictly smaller than the raw payload; the target pads final Huffman bits with ones.
MrdEncodeResult encodeMrd80Record(std::uint64_t backReferenceDelta,
                                  const std::uint8_t* payload,
                                  std::size_t payloadSize,
                                  const Mrd80CodecLimits& limits = {});

// Parses one complete record and reports bytesConsumed so callers can continue with
// following records. A truncated record returns NeedMoreData; it never reads past size.
MrdDecodeResult decodeMrd80Record(const std::uint8_t* data,
                                  std::size_t size,
                                  const Mrd80CodecLimits& limits = {});

// Reverses the observed history arithmetic: priorIndex = currentSequence - backReferenceDelta - 1.
// Sequence indexes are zero-based; false is returned when the delta cannot refer backward.
bool resolveMrd80PriorSequenceIndex(std::uint64_t currentSequence,
                                    std::uint64_t backReferenceDelta,
                                    std::uint64_t& priorSequenceIndex) noexcept;

const char* toString(MrdWireError error) noexcept;

} // namespace rbxtransport::reconstruction::mrd
