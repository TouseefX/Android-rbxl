#pragma once

// Clean-room reconstruction of the statically supported RbxTransport channel-control slice.
// This is not recovered Roblox source, and it does not implement QUIC/WebTransport itself.

#include "rbx_transport_reconstruction.hpp"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <mutex>
#include <optional>
#include <vector>

namespace rbxtransport::reconstruction::protocol {

inline constexpr std::size_t kChannelProfileCount = 14;
inline constexpr std::uint8_t kReliableOpenType = 1;
inline constexpr std::uint8_t kUnreliableOpenType = 2;
inline constexpr std::size_t kReliableOpenBodySize = 6;
inline constexpr std::size_t kReliableOpenRecordSize = 7;
inline constexpr std::size_t kUnreliableOpenBodySize = 10;
inline constexpr std::uint8_t kJoinDataLeadByte = 0x83;
inline constexpr std::uint8_t kJoinDataSubcode = 0x16;
// The JoinDataItemV2 builders pass this target global to the Zstandard transform path.
// The target writes a Zstd frame and retains setting/level 1; compression is not modeled.
inline constexpr std::uint8_t kTargetJoinZstdCompressionLevel = 1;

// The target's FUN_144c25af0 switch returns these three fields per channel index.
// Only mode==1 is semantically identified as unreliable; the auxiliary and flag fields
// deliberately keep neutral names because their higher-level meanings are not established.
struct ChannelProfileRow {
    std::uint32_t mode;
    std::uint32_t auxiliary;
    std::uint8_t flag;
};

using ChannelProfile = std::array<ChannelProfileRow, kChannelProfileCount>;

inline constexpr ChannelProfile kDefaultChannelProfile{{
    {0, 3, 0}, {0, 3, 0}, {0, 3, 0}, {1, 3, 0},
    {0, 3, 1}, {1, 2, 0}, {1, 2, 0}, {0, 3, 0},
    {0, 3, 0}, {0, 4, 0}, {0, 2, 0}, {1, 2, 0},
    {0, 3, 0}, {0, 3, 0}
}};

inline constexpr bool isUnreliable(const ChannelProfileRow& row) noexcept {
    return row.mode == 1;
}

// A narrow seam for the recovered 14-channel setup loop. Runtime overrides can be supplied
// as another ChannelProfile. The target traps after a failed open; this safe reconstruction
// returns the first failure instead of terminating the process.
class ChannelOpenApi {
public:
    virtual ~ChannelOpenApi() = default;
    virtual Status openSendChannel(std::uint8_t application,
                                   std::uint32_t channelIndex,
                                   const ChannelProfileRow& row) = 0;
};

Status configureChannels(ChannelOpenApi& api, std::uint8_t application,
                         const ChannelProfile& profile = kDefaultChannelProfile);

// Internal local IDs are negative; the wire serializer emits their positive magnitude.
// parity=0 produces -2,-4,-6...; parity=1 produces -3,-5,-7...
class LocalUnreliableIdAllocator {
public:
    explicit LocalUnreliableIdAllocator(std::uint8_t parity) noexcept;

    ValueResult<std::int32_t> allocate();
    std::uint8_t parity() const noexcept { return parity_; }
    std::uint64_t allocations() const noexcept;

private:
    std::atomic<std::uint64_t> counter_{0};
    std::uint8_t parity_{0};
};

ValueResult<std::uint32_t> wireMagnitude(std::int32_t internalId);
bool isValidPeerInternalId(std::int32_t internalId,
                           std::uint8_t localParity) noexcept;
ValueResult<std::int32_t> decodePeerWireId(std::uint32_t magnitude,
                                           std::uint8_t localParity);

struct DecodedUnreliableOpenControl {
    std::uint8_t application{0};
    std::uint32_t channelIndex{0};
    std::int32_t internalId{0};
};

// Reliable open: FUN_143816d50 writes a 6-byte body (type, application, channel-u32).
// FUN_1437a7980 writes a one-byte body-size field before that body; 0x06 is the observed
// expected size for this record. This framing is specific to this serializer and is not
// generalized to other control messages or to the unresolved user-designated wire tag 0x80.
std::array<std::uint8_t, kReliableOpenBodySize>
serializeReliableOpenBody(std::uint8_t application, std::uint32_t channelIndex);
std::array<std::uint8_t, kReliableOpenRecordSize>
serializeReliableOpenRecord(std::uint8_t application, std::uint32_t channelIndex);

// Unreliable open control: FUN_143816e10 writes two bytes plus two dwords, for a 10-byte
// body: type=2, application, channel index, abs(internal ID). Dwords are emitted in the
// network-order form produced by the target's Winsock ordinal-8 conversion path.
ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>
serializeUnreliableOpenControl(std::uint8_t application,
                               std::uint32_t channelIndex,
                               std::int32_t internalId);
ValueResult<DecodedUnreliableOpenControl>
parseUnreliableOpenControl(const std::uint8_t* data, std::size_t size);

// Partial join-data envelope observed in JoinDataItemV2 helpers. FUN_145f94050 emits
// 0x83, FUN_145e7a180 appends 0x16, then it writes kind 0x01; FUN_145f944b0 uses
// kind 0x05. FUN_145dba600 writes a 32-bit compressed-byte count, then the source stream's
// virtual +0x10 value (also passed to the compressor as input length), then exactly that
// many compressed bytes. The builders pass kTargetJoinZstdCompressionLevel into the
// transform helper; FUN_1476d6890 writes Zstandard frame magic, but compression itself is external.
enum class JoinDataChunkKind : std::uint8_t {
    Kind1 = 1,
    Kind2 = 2,
    Kind3 = 3,
    Kind4 = 4,
    Kind5 = 5,
};

// The two-u32 length envelope is established for kinds 1 and 5 only. Target code also emits
// kinds 2, 3, and 4 by copying an existing bitstream/blob directly after the 0x83 0x16 kind
// bytes; do not apply this length-pair model to those three opaque payloads.
struct JoinDataChunkEnvelope {
    JoinDataChunkKind kind{JoinDataChunkKind::Kind1};
    // Input byte count supplied to the compressor and repeated after compressed size.
    std::uint32_t uncompressedSize{0};
    std::vector<std::uint8_t> compressedBytes;
    // Some target builders append a single zero byte after the compressed payload.
    bool appendOptionalZero{false};
};

ValueResult<std::vector<std::uint8_t>>
serializeJoinDataChunkEnvelope(const JoinDataChunkEnvelope& envelope);
ValueResult<JoinDataChunkEnvelope>
parseJoinDataChunkEnvelope(const std::uint8_t* data, std::size_t size);

// Join/Replication messages are classified conservatively. The 0x81 start message body and
// kind 2/3/4 JDI bodies are retained byte-for-byte because their field layouts are not recovered.
inline constexpr std::uint8_t kJoinStartMessageTag = 0x81;
enum class JoinReplicationMessageType : std::uint8_t {
    Other,
    JoinStart,
    JoinDataItem,
};

struct ParsedJoinDataItem {
    JoinDataChunkKind kind{JoinDataChunkKind::Kind1};
    // Exact bytes after 0x83 0x16 <kind>; this is always preserved, even when a typed
    // kind-1/kind-5 compressed envelope was also recognized.
    std::vector<std::uint8_t> opaquePayload;
    std::optional<JoinDataChunkEnvelope> compressedEnvelope;
};

struct ParsedJoinReplicationMessage {
    JoinReplicationMessageType type{JoinReplicationMessageType::Other};
    // Exact original message for safe pass-through/logging.
    std::vector<std::uint8_t> rawBytes;
    // JoinStart: bytes after 0x81. JoinDataItem: the item payload after its 3-byte prefix.
    std::vector<std::uint8_t> body;
    std::optional<ParsedJoinDataItem> dataItem;
};

ValueResult<ParsedJoinReplicationMessage>
parseJoinReplicationMessage(const std::uint8_t* data, std::size_t size);
ValueResult<std::vector<std::uint8_t>>
serializeJoinStartMessage(const std::vector<std::uint8_t>& opaqueBody);
ValueResult<std::vector<std::uint8_t>>
serializeJoinDataItemOpaque(JoinDataChunkKind kind,
                           const std::vector<std::uint8_t>& opaquePayload);

// The target's ReplicationDataCache::generateDataBlobs code names these snapshot groups.
// These labels are implementation categories, not wire IDs or a complete schema.
enum class ReplicationCacheCategory : std::uint8_t {
    CacheableInstances,
    PartInstances,
    NonCacheableInstances,
    CharacterModelRoots,
};

// Coarse stages logged/called by the target's Server Join Snapshot routine. These are
// descriptive reconstruction labels, not a state machine and not serialized values.
enum class ServerJoinBatchPhase : std::uint8_t {
    SendNetworkSchemaDefinition,
    SendGlobalsAndTopContainers,
    PrebuildReplicationCache,
    GenerateAndQueueJdiV2,
    InstallPlayer,
    CompleteBatch,
};

// A Zstandard implementation is intentionally injected: target framing and expected output
// length are supported here, but the target's compressor implementation/options are external.
class JoinDataZstdDecoder {
public:
    virtual ~JoinDataZstdDecoder() = default;
    virtual ValueResult<std::vector<std::uint8_t>> decompress(
        const std::uint8_t* compressedBytes, std::size_t compressedSize,
        std::uint32_t expectedUncompressedSize) = 0;
};

ValueResult<std::vector<std::uint8_t>>
decompressJoinDataChunk(const JoinDataChunkEnvelope& envelope,
                        JoinDataZstdDecoder& decoder);

class JoinReplicationSink {
public:
    virtual ~JoinReplicationSink() = default;
    // The payloads remain opaque; the sink owns any engine-specific object/property apply path.
    virtual Status onJoinStart(const std::vector<std::uint8_t>& opaqueBody) = 0;
    virtual Status onJoinDataItem(const ParsedJoinDataItem& item) = 0;
};

enum class JoinReplicationDispatchResult : std::uint8_t {
    NotHandled,
    Handled,
};

ValueResult<JoinReplicationDispatchResult>
dispatchJoinReplicationMessage(const std::uint8_t* data, std::size_t size,
                              JoinReplicationSink& sink);

// Models the verified dispatch branch only: equal thread IDs invoke inline; otherwise a
// copied callable is handed to the supplied interface. The interface intentionally makes
// no FIFO or scheduling guarantee because the target's concrete executor is unresolved.
class CallbackExecutor {
public:
    virtual ~CallbackExecutor() = default;
    virtual void submit(std::function<void()> callback) = 0;
};

enum class CallbackDispatchPath {
    NoCallback,
    InvokedInline,
    Submitted,
};

CallbackDispatchPath dispatchCallback(std::int32_t currentThreadId,
                                      std::int32_t ownerThreadId,
                                      CallbackExecutor& executor,
                                      std::function<void()> callback);

// Per-channel representation of the target's signed ID stored at the channel object +0x98.
// It models the allocate/store/serialize sequence but not the opaque transport, map allocation
// strategy, or peer event-loop policy. Duplicate-open rejection is a safe local guard; the
// target's reset/reopen lifecycle is not yet established.
class ChannelControlState {
public:
    explicit ChannelControlState(std::uint8_t localParity) noexcept;

    ValueResult<std::int32_t> onUnreliableOpenCallback(std::uint32_t channelIndex);
    ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>
    makeUnreliableOpenControl(std::uint8_t application,
                              std::uint32_t channelIndex) const;
    std::optional<std::int32_t> localId(std::uint32_t channelIndex) const;

private:
    LocalUnreliableIdAllocator allocator_;
    mutable std::mutex mutex_;
    std::array<std::optional<std::int32_t>, kChannelProfileCount> localIds_{};
};

} // namespace rbxtransport::reconstruction::protocol
