#pragma once

// Best-effort source-level reconstruction from the RobloxStudioBeta.exe static analysis.
// This is original, clean-room code, not recovered Roblox source.

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <mutex>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace rbxtransport::reconstruction {

using NativeSocket = std::uintptr_t;
constexpr NativeSocket kInvalidSocket = std::numeric_limits<NativeSocket>::max();

enum class AddressFamily {
    IPv4,
    IPv6,
};

enum class SocketKind {
    Stream,
    Datagram,
};

struct Endpoint {
    AddressFamily family{AddressFamily::IPv4};
    // IPv4 uses bytes [0..3]; IPv6 uses all 16 bytes. Port is host byte order.
    std::array<std::uint8_t, 16> address{};
    std::uint16_t port{0};
};

struct MessageBuffer {
    const void* data{nullptr};
    std::size_t size{0};
};

enum class SocketOption {
    TcpNoDelay,
    ReuseAddress,
    DontFragment,
};

enum class ErrorKind {
    None,
    WinSock,
    Libuv,
    Unsupported,
    InvalidArgument,
    AlreadyInProgress,
    Tls,
};

struct Status {
    ErrorKind kind{ErrorKind::None};
    int nativeCode{0};
    std::string message;

    static Status success();
    static Status failure(ErrorKind kind, std::string message, int nativeCode = 0);
    bool ok() const noexcept;
};

template <typename T>
struct ValueResult {
    T value{};
    Status status{};

    static ValueResult success(T value) {
        ValueResult result;
        result.value = std::move(value);
        result.status = Status::success();
        return result;
    }

    static ValueResult failure(Status status) {
        ValueResult result;
        result.status = std::move(status);
        return result;
    }

    bool ok() const noexcept { return status.ok(); }
};

// The adapter keeps system calls separate from the recovered policy/state layer.
// On Windows, WinSockSocketApi maps these operations to Winsock calls. Tests use a fake.
class SocketApi {
public:
    virtual ~SocketApi() = default;

    virtual ValueResult<NativeSocket> createSocket(AddressFamily family, SocketKind kind) = 0;
    virtual Status closeSocket(NativeSocket socket) = 0;
    virtual Status setOption(NativeSocket socket, SocketOption option, int value,
                             AddressFamily family) = 0;
    virtual ValueResult<int> getOption(NativeSocket socket, SocketOption option,
                                       AddressFamily family) = 0;
    virtual Status bind(NativeSocket socket, const Endpoint& endpoint) = 0;
    virtual Status connect(NativeSocket socket, const Endpoint& endpoint) = 0;
    virtual ValueResult<Endpoint> getLocalName(NativeSocket socket) = 0;
    virtual ValueResult<Endpoint> getPeerName(NativeSocket socket) = 0;
    virtual ValueResult<std::size_t> sendMessage(
        NativeSocket socket, const Endpoint& destination,
        const std::vector<MessageBuffer>& buffers) = 0;
};

using ReceiveCompletion = std::function<void(Status, Endpoint, std::vector<std::uint8_t>)>;

// The target contains separate Sys* and Libuv* poller/socket families. Receive scheduling
// stays behind this interface because its event-loop ownership and lifetime rules were not
// fully recoverable from the available decompilation.
class AsyncReceiver {
public:
    virtual ~AsyncReceiver() = default;
    virtual Status startReceive(NativeSocket socket, ReceiveCompletion completion) = 0;
};

struct TcpBindOptions {
    bool noDelay{false};
    bool reuseAddress{false};
};

class SysTcpSocket {
public:
    SysTcpSocket(SocketApi& api, NativeSocket socket);

    Status bind(const Endpoint& local, TcpBindOptions options);
    Status connect(const Endpoint& peer);
    ValueResult<Endpoint> localName();
    ValueResult<Endpoint> peerName();
    Status close();

private:
    SocketApi& api_;
    NativeSocket socket_;
};

enum class UdpOption {
    DontFragment,
    IpPacketInfo,
    IpReceiveError,
    TimestampNanoseconds,
};

class SysUdpSocket {
public:
    SysUdpSocket(SocketApi& api, NativeSocket socket, AddressFamily family);

    ValueResult<std::size_t> sendMessage(const Endpoint& destination,
                                         const std::vector<MessageBuffer>& buffers);
    Status setOption(UdpOption option, int value);
    ValueResult<int> getOption(UdpOption option);
    Status setMaxSameIterationRecv(int value);
    int maxSameIterationRecv() const;

    Status beginAsyncReceive(AsyncReceiver& receiver, ReceiveCompletion completion);
    bool receivePending() const;
    Status close();

private:
    struct ReceiveState {
        mutable std::mutex mutex;
        bool pending{false};
        int maxSameIterationRecv{1};
    };

    SocketApi& api_;
    NativeSocket socket_;
    AddressFamily family_;
    std::shared_ptr<ReceiveState> receiveState_;
};

// Recovered policy/error surfaces for the Libuv UDP option path. The actual libuv event loop,
// poller and deferred-operation ownership are not reconstructed here.
class LibuvUdpOptionPolicy {
public:
    static Status setReusePort(bool enabled);
};

class LibuvOptionValidation {
public:
    static Status unknownOption(std::string_view name);
    static Status invalidValue();
};

// TLS error text is present in the target, but certificate selection and QUIC TLS internals
// remain opaque. This interface only reconstructs the observed diagnostic path.
class TlsClientProvider {
public:
    virtual ~TlsClientProvider() = default;
    virtual bool certificateFileExists(std::string_view path) const = 0;
    virtual Status initializeClient(std::string_view certificatePath) = 0;
    virtual Status createClientSession() = 0;
};

class TlsClientContext {
public:
    Status initClient(TlsClientProvider& provider, std::string_view certificatePath) const;
};

#if defined(_WIN32)

// Windows adapter for the statically observed SysTcpSocket/SysUdpSocket calls.
// Caller owns WSAStartup/WSACleanup lifetime through WinSockRuntime.
class WinSockRuntime {
public:
    Status startup();
    Status cleanup();
    bool started() const noexcept { return started_; }

private:
    bool started_{false};
};

class WinSockSocketApi final : public SocketApi {
public:
    ValueResult<NativeSocket> createSocket(AddressFamily family, SocketKind kind) override;
    Status closeSocket(NativeSocket socket) override;
    Status setOption(NativeSocket socket, SocketOption option, int value,
                     AddressFamily family) override;
    ValueResult<int> getOption(NativeSocket socket, SocketOption option,
                               AddressFamily family) override;
    Status bind(NativeSocket socket, const Endpoint& endpoint) override;
    Status connect(NativeSocket socket, const Endpoint& endpoint) override;
    ValueResult<Endpoint> getLocalName(NativeSocket socket) override;
    ValueResult<Endpoint> getPeerName(NativeSocket socket) override;
    ValueResult<std::size_t> sendMessage(
        NativeSocket socket, const Endpoint& destination,
        const std::vector<MessageBuffer>& buffers) override;
};

#endif // defined(_WIN32)

} // namespace rbxtransport::reconstruction
