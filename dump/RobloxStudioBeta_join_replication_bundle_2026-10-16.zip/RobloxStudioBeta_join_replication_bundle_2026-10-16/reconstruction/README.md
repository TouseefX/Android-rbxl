# Roblox network reconstruction — clean-room Windows C++ project

This is **original clean-room code**, not recovered Roblox source. It models only behavior supported by the supplied executable's static analysis. It is not a full Roblox client, QUIC/WebTransport implementation, replication client, or place-file writer.

## Reconstructed slices

- **Windows socket surface:** TCP bind/connect/address queries, UDP message/option policy, Winsock adapter, and an abstract async-receive boundary.
- **Channel profile/setup:** the statically recovered 14-row profile and ordered `openSendChannel` setup loop, with caller-supplied rows available for runtime overrides.
- **Unreliable channel IDs:** local parity allocation (`-2,-4,…` or `-3,-5,…`), positive wire-magnitude conversion, and the observed opposite-parity check for peer IDs.
- **Control serializers:** the reliable channel-open body/length byte and the fixed 10-byte unreliable-open control body. The 32-bit fields are emitted in network order, matching the target's Winsock ordinal-8 conversion path.
- **Callback dispatch branch:** same-thread inline invocation versus handing a copied callable to a pluggable executor interface. The concrete executor and FIFO behavior remain unknown, so the interface promises neither.
- **Partial join-data envelope:** target `JoinDataItemV2` builders show prefixes `83 16 01` and `83 16 05`, followed by compressed-byte count, uncompressed/input byte count, Zstandard bytes, and an optional zero trailer. The target emits Zstandard frame magic and passes compression level `1` on this path. C++ exposes the level and serializes only the bounded envelope; it accepts compressed bytes from a caller and does not compress or reconstruct item bodies.
- **Mrd `0x80` wire codec slice:** the paired writer/reader uses a `0x80` prefix with a width-6 backward-reference delta (`current sequence - prior sequence - 1`), then a separate width-7 byte count whose high bit marks Huffman data. Target static analysis shows the lookup ring is newest-first, so delta 0 selects the immediate prior cached sequence. The consumer's extent method is an RTTI-backed `RBX::Network::MrdModeItemizedInstance` vtable entry; the callback owner's identity and remaining item/domain semantics are still unknown. The writer selects Huffman only when it is strictly smaller, using the target's extracted 256-entry code table and one-bit padding; otherwise it copies raw bytes. C++ implements the bounded byte codec and inverse index arithmetic, but not the ring container, parsed-item callbacks, or referenced/payload data semantics.

The default profile's unreliable rows are channels 3, 5, 6, and 11. Their mapping to local IDs 2, 4, 6, and 8 is **conditional on callback processing in profile order**; this project does not claim the target's cross-thread executor preserves that order.

This Mrd `0x80` slice is distinct from the reliable-record length byte `0x06`, channel-control type bytes `0x01`/`0x02`, the RbxTransport close reason, and Android-rbxl's unrelated compact-varint example. The paired codec does not establish full `RBX::Network` dispatch, join/replication semantics, or complete RBXL writing.

## Project files

- `include/rbx_transport_reconstruction.hpp` — transport abstractions and socket policy.
- `src/rbx_transport_reconstruction.cpp` — portable socket-policy/state layer.
- `src/winsock_socket_api.cpp` — Windows-only Winsock implementation for the recovered socket surface.
- `include/rbx_channel_protocol.hpp` — channel profile, IDs, serializers, and dispatcher seam.
- `src/rbx_channel_protocol.cpp` — clean-room channel-control and bounded join-envelope serializers.
- `include/rbx_mrd_wire_codec.hpp` / `src/rbx_mrd_wire_codec.cpp` — bounded Mrd `0x80`-family record codec using the target Huffman table.
- `src/mrd_huffman_table.inc` — 256 target code/length pairs, with the extracted table hash recorded in the file.
- `tests/test_transport.cpp` — fake-backed socket-policy tests.
- `tests/test_channel_protocol.cpp` — profile, ID/parity, control records, join-envelope bytes, state, and dispatch-branch tests.
- `tests/test_mrd_wire_codec.cpp` — `0x80` field boundaries, compression/raw selection, one-padding, limits, malformed input, and round-trip tests.
- `../analysis/scripts/verify_mrd_0x80_static.py` — static target-table/hash and decoder-transition-model verification (reads the EXE as data only).
- `../RobloxStudioBeta_network_reconstruction_report.md` — evidence, scope, and unresolved items.

## Build and test

Portable sandbox build (GCC/Clang, C++17):

```sh
make test
```

Windows/MSVC build (CMake):

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

The portable core and fake-backed tests are built and run with GCC in this sandbox; the `0x80` Huffman tables are validated by static table comparison and reference-model tests. **The Windows/MSVC adapter has not been compiled here.** The target executable was not run or modified.

## Evidence and limits

Implementation notes in the source refer to target functions such as `FUN_144c25af0`, `FUN_143785af0`, `FUN_143816d50`, `FUN_143816e10`, `FUN_1435dbca0`, and the Mrd writer/reader at `FUN_14307e370` / `FUN_14307af50`. The actual QUIC/RtcIo objects, stream/poller scheduling, outer transport framing, Mrd item's domain meaning and callback-owner identity, connection from the mapped Mrd callback boundary into `RBX::Network`/`NetworkBase`/Replicator, complete join/replication flow, and RBXL writing remain incomplete. This project intentionally leaves those areas behind interfaces or out of scope instead of fabricating behavior.
