#include "rbx_mrd_wire_codec.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <limits>
#include <utility>

namespace rbxtransport::reconstruction::mrd {
namespace {

struct HuffmanCode {
    std::uint32_t bitLength;
    std::uint32_t leftAlignedBits;
};

constexpr std::array<HuffmanCode, 256> kTargetHuffmanCodes{{
#include "mrd_huffman_table.inc"
}};

constexpr std::size_t kMaxHuffmanCodeLength = 30;
constexpr std::size_t kMaxTrieNodes = 1 + 256 * kMaxHuffmanCodeLength;

struct TrieNode {
    std::array<int, 2> child{{-1, -1}};
    int symbol{-1};
};

struct HuffmanTrie {
    std::array<TrieNode, kMaxTrieNodes> nodes{};
    std::size_t nodeCount{1};
    bool valid{true};

    HuffmanTrie() {
        for (std::size_t symbol = 0; symbol < kTargetHuffmanCodes.size(); ++symbol) {
            const HuffmanCode code = kTargetHuffmanCodes[symbol];
            if (code.bitLength == 0 || code.bitLength > kMaxHuffmanCodeLength) {
                valid = false;
                return;
            }

            int node = 0;
            for (std::uint32_t bitIndex = 0; bitIndex < code.bitLength; ++bitIndex) {
                if (nodes[static_cast<std::size_t>(node)].symbol >= 0) {
                    valid = false;
                    return;
                }
                const unsigned shift = 31U - bitIndex;
                const int bit = static_cast<int>((code.leftAlignedBits >> shift) & 1U);
                int next = nodes[static_cast<std::size_t>(node)].child[static_cast<std::size_t>(bit)];
                if (next < 0) {
                    if (nodeCount >= nodes.size()) {
                        valid = false;
                        return;
                    }
                    next = static_cast<int>(nodeCount++);
                    nodes[static_cast<std::size_t>(node)].child[static_cast<std::size_t>(bit)] = next;
                }
                node = next;
            }

            TrieNode& leaf = nodes[static_cast<std::size_t>(node)];
            if (leaf.symbol >= 0 || leaf.child[0] >= 0 || leaf.child[1] >= 0) {
                valid = false;
                return;
            }
            leaf.symbol = static_cast<int>(symbol);
        }
    }
};

const HuffmanTrie& targetHuffmanTrie() {
    static const HuffmanTrie trie;
    return trie;
}

Mrd80CodecLimits boundedLimits(const Mrd80CodecLimits& limits) noexcept {
    return {
        std::min(limits.maxPayloadBytes, kTargetMaxMrdPayloadBytes),
        std::min(limits.maxDecodedBytes, kTargetMaxHuffmanOutputBytes),
        std::min(limits.maxRecordBytes, kTargetMaxMrdRecordBytes),
    };
}

std::uint64_t fieldMask(unsigned width) noexcept {
    return (std::uint64_t{1} << width) - 1U;
}

std::size_t uleb128Size(std::uint64_t value) noexcept {
    std::size_t size = 1;
    while (value >= 0x80U) {
        value >>= 7U;
        ++size;
    }
    return size;
}

std::size_t boundedFieldSize(std::uint64_t value, unsigned width) noexcept {
    const std::uint64_t mask = fieldMask(width);
    return 1U + (value < mask ? 0U : uleb128Size(value - mask));
}

void appendBoundedField(std::vector<std::uint8_t>& output,
                        std::uint8_t prefix,
                        std::uint64_t value,
                        unsigned width) {
    const std::uint8_t mask = static_cast<std::uint8_t>(fieldMask(width));
    const std::size_t firstByte = output.size();
    output.push_back(prefix);

    const std::uint8_t preserved = static_cast<std::uint8_t>(prefix & static_cast<std::uint8_t>(~mask));
    if (value < mask) {
        output[firstByte] = static_cast<std::uint8_t>(preserved | static_cast<std::uint8_t>(value));
        return;
    }

    output[firstByte] = static_cast<std::uint8_t>(preserved | mask);
    std::uint64_t remainder = value - mask;
    while (remainder >= 0x80U) {
        output.push_back(static_cast<std::uint8_t>((remainder & 0x7fU) | 0x80U));
        remainder >>= 7U;
    }
    output.push_back(static_cast<std::uint8_t>(remainder));
}

MrdWireError readBoundedField(const std::uint8_t* data,
                              std::size_t size,
                              std::size_t maxRecordBytes,
                              std::size_t& offset,
                              unsigned width,
                              std::uint64_t& value) noexcept {
    if (offset >= maxRecordBytes) return MrdWireError::RecordLimitExceeded;
    if (offset >= size) return MrdWireError::NeedMoreData;

    const std::uint64_t mask = fieldMask(width);
    const std::uint64_t first = static_cast<std::uint64_t>(data[offset++] & static_cast<std::uint8_t>(mask));
    value = first;
    if (first != mask) return MrdWireError::None;

    unsigned shift = 0;
    for (;;) {
        if (offset >= maxRecordBytes) return MrdWireError::RecordLimitExceeded;
        if (offset >= size) return MrdWireError::NeedMoreData;

        const std::uint8_t groupByte = data[offset++];
        const std::uint64_t group = groupByte & 0x7fU;
        if (shift >= 63U || group > ((kTargetMaxMrdFieldValue - value) >> shift)) {
            return MrdWireError::FieldValueOverflow;
        }
        value += group << shift;

        if ((groupByte & 0x80U) == 0) return MrdWireError::None;
        if (shift >= 56U) return MrdWireError::FieldValueOverflow;
        shift += 7U;
    }
}

std::uint64_t huffmanBitCount(const std::uint8_t* input, std::size_t size) noexcept {
    std::uint64_t bits = 0;
    for (std::size_t i = 0; i < size; ++i) {
        bits += kTargetHuffmanCodes[input[i]].bitLength;
    }
    return bits;
}

void encodeHuffman(const std::uint8_t* input,
                   std::size_t size,
                   std::vector<std::uint8_t>& output) {
    const std::uint64_t bitCount = huffmanBitCount(input, size);
    output.reserve(static_cast<std::size_t>((bitCount + 7U) / 8U));

    std::uint8_t current = 0;
    unsigned usedBits = 0;
    for (std::size_t i = 0; i < size; ++i) {
        const HuffmanCode code = kTargetHuffmanCodes[input[i]];
        for (std::uint32_t bitIndex = 0; bitIndex < code.bitLength; ++bitIndex) {
            current = static_cast<std::uint8_t>(
                (static_cast<unsigned>(current) << 1U) |
                ((code.leftAlignedBits >> (31U - bitIndex)) & 1U));
            ++usedBits;
            if (usedBits == 8U) {
                output.push_back(current);
                current = 0;
                usedBits = 0;
            }
        }
    }

    if (usedBits != 0U) {
        const unsigned paddingBits = 8U - usedBits;
        current = static_cast<std::uint8_t>(
            (static_cast<unsigned>(current) << paddingBits) |
            ((1U << paddingBits) - 1U));
        output.push_back(current);
    }
}

MrdWireError decodeHuffman(const std::uint8_t* input,
                           std::size_t size,
                           std::size_t outputLimit,
                           std::vector<std::uint8_t>& output) {
    const HuffmanTrie& trie = targetHuffmanTrie();
    if (!trie.valid) return MrdWireError::InvalidHuffmanData;

    output.clear();
    output.reserve(std::min(outputLimit, size * 2U));
    int node = 0;
    std::size_t unfinishedBits = 0;
    bool unfinishedBitsAreOnes = true;

    for (std::size_t byteIndex = 0; byteIndex < size; ++byteIndex) {
        const std::uint8_t byte = input[byteIndex];
        for (int bitIndex = 7; bitIndex >= 0; --bitIndex) {
            const int bit = static_cast<int>((byte >> bitIndex) & 1U);
            const int next = trie.nodes[static_cast<std::size_t>(node)].child[static_cast<std::size_t>(bit)];
            if (next < 0) return MrdWireError::InvalidHuffmanData;
            node = next;

            const int symbol = trie.nodes[static_cast<std::size_t>(node)].symbol;
            if (symbol >= 0) {
                if (output.size() >= outputLimit) {
                    return MrdWireError::DecodedPayloadLimitExceeded;
                }
                output.push_back(static_cast<std::uint8_t>(symbol));
                node = 0;
                unfinishedBits = 0;
                unfinishedBitsAreOnes = true;
            } else {
                ++unfinishedBits;
                unfinishedBitsAreOnes = unfinishedBitsAreOnes && (bit != 0);
            }
        }
    }

    // The target encoder fills the final byte with ones. The codebook reserves that
    // all-one tail as the decoder's accepting end state; at most seven bits can be padding.
    if (node != 0 && !(unfinishedBits <= 7U && unfinishedBitsAreOnes)) {
        return MrdWireError::InvalidHuffmanData;
    }
    return MrdWireError::None;
}

} // namespace

MrdEncodeResult encodeMrd80Record(std::uint64_t backReferenceDelta,
                                  const std::uint8_t* payload,
                                  std::size_t payloadSize,
                                  const Mrd80CodecLimits& requestedLimits) {
    const Mrd80CodecLimits limits = boundedLimits(requestedLimits);
    if (payload == nullptr && payloadSize != 0U) {
        return {{}, MrdWireError::InvalidArgument};
    }
    if (backReferenceDelta > kTargetMaxMrdFieldValue) {
        return {{}, MrdWireError::FieldValueOverflow};
    }
    if (payloadSize > limits.maxPayloadBytes) {
        return {{}, MrdWireError::PayloadLimitExceeded};
    }

    const std::uint64_t compressedBits = huffmanBitCount(payload, payloadSize);
    const std::size_t compressedSize = static_cast<std::size_t>((compressedBits + 7U) / 8U);
    const bool useHuffman = compressedSize < payloadSize;
    const std::size_t storedSize = useHuffman ? compressedSize : payloadSize;

    const std::size_t headerSize = boundedFieldSize(backReferenceDelta, 6U) +
                                   boundedFieldSize(storedSize, 7U);
    if (headerSize > limits.maxRecordBytes ||
        storedSize > limits.maxRecordBytes - headerSize) {
        return {{}, MrdWireError::RecordLimitExceeded};
    }

    MrdEncodeResult result;
    result.bytes.reserve(headerSize + storedSize);
    appendBoundedField(result.bytes, 0x80U, backReferenceDelta, 6U);
    appendBoundedField(result.bytes, useHuffman ? 0x80U : 0x00U, storedSize, 7U);

    if (useHuffman) {
        std::vector<std::uint8_t> encoded;
        encodeHuffman(payload, payloadSize, encoded);
        if (encoded.size() != storedSize) {
            return {{}, MrdWireError::InvalidHuffmanData};
        }
        result.bytes.insert(result.bytes.end(), encoded.begin(), encoded.end());
    } else if (storedSize != 0U) {
        result.bytes.insert(result.bytes.end(), payload, payload + storedSize);
    }
    return result;
}

MrdDecodeResult decodeMrd80Record(const std::uint8_t* data,
                                  std::size_t size,
                                  const Mrd80CodecLimits& requestedLimits) {
    const Mrd80CodecLimits limits = boundedLimits(requestedLimits);
    if (data == nullptr && size != 0U) {
        return {{}, MrdWireError::InvalidArgument};
    }
    if (limits.maxRecordBytes == 0U) {
        return {{}, MrdWireError::RecordLimitExceeded};
    }
    if (size == 0U) return {{}, MrdWireError::NeedMoreData};
    if ((data[0] & 0xc0U) != 0x80U) {
        return {{}, MrdWireError::InvalidTagFamily};
    }

    std::size_t offset = 0;
    std::uint64_t backReferenceDelta = 0;
    MrdWireError error = readBoundedField(data, size, limits.maxRecordBytes,
                                          offset, 6U, backReferenceDelta);
    if (error != MrdWireError::None) return {{}, error};

    if (offset >= limits.maxRecordBytes) {
        return {{}, MrdWireError::RecordLimitExceeded};
    }
    if (offset >= size) return {{}, MrdWireError::NeedMoreData};
    const bool compressed = (data[offset] & 0x80U) != 0U;

    std::uint64_t storedSize64 = 0;
    error = readBoundedField(data, size, limits.maxRecordBytes,
                             offset, 7U, storedSize64);
    if (error != MrdWireError::None) return {{}, error};
    if (storedSize64 > limits.maxPayloadBytes ||
        storedSize64 > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        return {{}, MrdWireError::PayloadLimitExceeded};
    }
    const std::size_t storedSize = static_cast<std::size_t>(storedSize64);
    if (offset > limits.maxRecordBytes ||
        storedSize > limits.maxRecordBytes - offset) {
        return {{}, MrdWireError::RecordLimitExceeded};
    }
    if (storedSize > size - offset) return {{}, MrdWireError::NeedMoreData};

    Mrd80Record record;
    record.backReferenceDelta = backReferenceDelta;
    record.huffmanCompressed = compressed;
    record.bytesConsumed = offset + storedSize;

    if (compressed) {
        error = decodeHuffman(data + offset, storedSize,
                              limits.maxDecodedBytes, record.payload);
        if (error != MrdWireError::None) return {{}, error};
    } else {
        if (storedSize > limits.maxDecodedBytes) {
            return {{}, MrdWireError::DecodedPayloadLimitExceeded};
        }
        if (storedSize != 0U) {
            record.payload.assign(data + offset, data + offset + storedSize);
        }
    }
    return {std::move(record), MrdWireError::None};
}

bool resolveMrd80PriorSequenceIndex(std::uint64_t currentSequence,
                                    std::uint64_t backReferenceDelta,
                                    std::uint64_t& priorSequenceIndex) noexcept {
    if (currentSequence == 0U || backReferenceDelta >= currentSequence) return false;
    priorSequenceIndex = currentSequence - backReferenceDelta - 1U;
    return true;
}

const char* toString(MrdWireError error) noexcept {
    switch (error) {
    case MrdWireError::None: return "none";
    case MrdWireError::InvalidArgument: return "invalid argument";
    case MrdWireError::NeedMoreData: return "need more data";
    case MrdWireError::InvalidTagFamily: return "invalid tag family";
    case MrdWireError::FieldValueOverflow: return "field value overflow";
    case MrdWireError::PayloadLimitExceeded: return "payload limit exceeded";
    case MrdWireError::RecordLimitExceeded: return "record limit exceeded";
    case MrdWireError::InvalidHuffmanData: return "invalid Huffman data";
    case MrdWireError::DecodedPayloadLimitExceeded: return "decoded payload limit exceeded";
    }
    return "unknown Mrd wire error";
}

} // namespace rbxtransport::reconstruction::mrd
