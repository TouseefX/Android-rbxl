#if defined(_WIN32)

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <winsock2.h>
#include <ws2tcpip.h>
#include <mswsock.h>

#include "rbx_transport_reconstruction.hpp"

#include <climits>
#include <cstring>
#include <string>
#include <vector>

namespace rbxtransport::reconstruction {
namespace {

Status winsockFailure(const char* operation) {
    const int error = WSAGetLastError();
    return Status::failure(ErrorKind::WinSock, operation, error);
}

struct NativeAddress {
    sockaddr_storage storage{};
    int length{0};

    const sockaddr* asSockaddr() const {
        return reinterpret_cast<const sockaddr*>(&storage);
    }
    sockaddr* asSockaddr() {
        return reinterpret_cast<sockaddr*>(&storage);
    }
};

Status encodeEndpoint(const Endpoint& endpoint, NativeAddress& output) {
    if (endpoint.family == AddressFamily::IPv4) {
        sockaddr_in address{};
        address.sin_family = AF_INET;
        address.sin_port = htons(endpoint.port);
        std::memcpy(&address.sin_addr, endpoint.address.data(), 4);
        std::memcpy(&output.storage, &address, sizeof(address));
        output.length = sizeof(address);
        return Status::success();
    }

    sockaddr_in6 address{};
    address.sin6_family = AF_INET6;
    address.sin6_port = htons(endpoint.port);
    std::memcpy(&address.sin6_addr, endpoint.address.data(), 16);
    std::memcpy(&output.storage, &address, sizeof(address));
    output.length = sizeof(address);
    return Status::success();
}

ValueResult<Endpoint> decodeEndpoint(const sockaddr* address, int length) {
    if (address == nullptr) {
        return ValueResult<Endpoint>::failure(
            Status::failure(ErrorKind::InvalidArgument, "Null socket address"));
    }

    Endpoint endpoint{};
    if (address->sa_family == AF_INET && length >= static_cast<int>(sizeof(sockaddr_in))) {
        const auto* ipv4 = reinterpret_cast<const sockaddr_in*>(address);
        endpoint.family = AddressFamily::IPv4;
        endpoint.port = ntohs(ipv4->sin_port);
        std::memcpy(endpoint.address.data(), &ipv4->sin_addr, 4);
        return ValueResult<Endpoint>::success(endpoint);
    }
    if (address->sa_family == AF_INET6 && length >= static_cast<int>(sizeof(sockaddr_in6))) {
        const auto* ipv6 = reinterpret_cast<const sockaddr_in6*>(address);
        endpoint.family = AddressFamily::IPv6;
        endpoint.port = ntohs(ipv6->sin6_port);
        std::memcpy(endpoint.address.data(), &ipv6->sin6_addr, 16);
        return ValueResult<Endpoint>::success(endpoint);
    }
    return ValueResult<Endpoint>::failure(
        Status::failure(ErrorKind::Unsupported, "Unsupported socket address family"));
}

} // namespace

Status WinSockRuntime::startup() {
    if (started_) return Status::success();
    WSADATA data{};
    const int result = WSAStartup(MAKEWORD(2, 2), &data);
    if (result != 0) {
        return Status::failure(ErrorKind::WinSock, "WSAStartup failed", result);
    }
    started_ = true;
    return Status::success();
}

Status WinSockRuntime::cleanup() {
    if (!started_) return Status::success();
    if (WSACleanup() == SOCKET_ERROR) return winsockFailure("WSACleanup failed");
    started_ = false;
    return Status::success();
}

ValueResult<NativeSocket> WinSockSocketApi::createSocket(AddressFamily family, SocketKind kind) {
    const int af = family == AddressFamily::IPv4 ? AF_INET : AF_INET6;
    const int type = kind == SocketKind::Stream ? SOCK_STREAM : SOCK_DGRAM;
    const int protocol = kind == SocketKind::Stream ? IPPROTO_TCP : IPPROTO_UDP;
    const SOCKET socket = WSASocketW(af, type, protocol, nullptr, 0, WSA_FLAG_OVERLAPPED);
    if (socket == INVALID_SOCKET) {
        return ValueResult<NativeSocket>::failure(winsockFailure("WSASocketW failed"));
    }
    return ValueResult<NativeSocket>::success(static_cast<NativeSocket>(socket));
}

Status WinSockSocketApi::closeSocket(NativeSocket socket) {
    if (closesocket(static_cast<SOCKET>(socket)) == SOCKET_ERROR) {
        return winsockFailure("closesocket failed");
    }
    return Status::success();
}

Status WinSockSocketApi::setOption(NativeSocket socket, SocketOption option, int value,
                                  AddressFamily family) {
    int level = 0;
    int name = 0;
    switch (option) {
    case SocketOption::TcpNoDelay:
        level = IPPROTO_TCP;
        name = TCP_NODELAY;
        break;
    case SocketOption::ReuseAddress:
        level = SOL_SOCKET;
        name = SO_REUSEADDR;
        break;
    case SocketOption::DontFragment:
        if (family == AddressFamily::IPv6) {
            return value == 0
                ? Status::failure(ErrorKind::Unsupported,
                                  "Cannot disable dontFragment in IPv6")
                : Status::success();
        }
        level = IPPROTO_IP;
#ifdef IP_DONTFRAGMENT
        name = IP_DONTFRAGMENT;
#else
        name = 14; // Windows IP_DONTFRAGMENT value observed via the target's option path.
#endif
        break;
    }

    const int optionValue = value;
    const int result = setsockopt(static_cast<SOCKET>(socket), level, name,
                                  reinterpret_cast<const char*>(&optionValue),
                                  sizeof(optionValue));
    if (result == SOCKET_ERROR) return winsockFailure("setsockopt failed");
    return Status::success();
}

ValueResult<int> WinSockSocketApi::getOption(NativeSocket socket, SocketOption option,
                                             AddressFamily family) {
    int level = 0;
    int name = 0;
    switch (option) {
    case SocketOption::TcpNoDelay:
        level = IPPROTO_TCP;
        name = TCP_NODELAY;
        break;
    case SocketOption::ReuseAddress:
        level = SOL_SOCKET;
        name = SO_REUSEADDR;
        break;
    case SocketOption::DontFragment:
        if (family == AddressFamily::IPv6) return ValueResult<int>::success(1);
        level = IPPROTO_IP;
#ifdef IP_DONTFRAGMENT
        name = IP_DONTFRAGMENT;
#else
        name = 14;
#endif
        break;
    }

    int value = 0;
    int length = sizeof(value);
    if (getsockopt(static_cast<SOCKET>(socket), level, name,
                   reinterpret_cast<char*>(&value), &length) == SOCKET_ERROR) {
        return ValueResult<int>::failure(winsockFailure("getsockopt failed"));
    }
    return ValueResult<int>::success(value);
}

Status WinSockSocketApi::bind(NativeSocket socket, const Endpoint& endpoint) {
    NativeAddress address;
    Status status = encodeEndpoint(endpoint, address);
    if (!status.ok()) return status;
    if (::bind(static_cast<SOCKET>(socket), address.asSockaddr(), address.length) == SOCKET_ERROR) {
        return winsockFailure("bind failed");
    }
    return Status::success();
}

Status WinSockSocketApi::connect(NativeSocket socket, const Endpoint& endpoint) {
    NativeAddress address;
    Status status = encodeEndpoint(endpoint, address);
    if (!status.ok()) return status;
    // WSAConnect matches the named Winsock import; the binary also has an ordinal-4
    // connect-shaped call in the SysTcpSocket vtable.
    if (WSAConnect(static_cast<SOCKET>(socket), address.asSockaddr(), address.length,
                   nullptr, nullptr, nullptr, nullptr) == SOCKET_ERROR) {
        return winsockFailure("WSAConnect failed");
    }
    return Status::success();
}

ValueResult<Endpoint> WinSockSocketApi::getLocalName(NativeSocket socket) {
    NativeAddress address;
    address.length = sizeof(address.storage);
    if (getsockname(static_cast<SOCKET>(socket), address.asSockaddr(), &address.length) == SOCKET_ERROR) {
        return ValueResult<Endpoint>::failure(winsockFailure("getsockname failed"));
    }
    return decodeEndpoint(address.asSockaddr(), address.length);
}

ValueResult<Endpoint> WinSockSocketApi::getPeerName(NativeSocket socket) {
    NativeAddress address;
    address.length = sizeof(address.storage);
    if (getpeername(static_cast<SOCKET>(socket), address.asSockaddr(), &address.length) == SOCKET_ERROR) {
        return ValueResult<Endpoint>::failure(winsockFailure("getpeername failed"));
    }
    return decodeEndpoint(address.asSockaddr(), address.length);
}

ValueResult<std::size_t> WinSockSocketApi::sendMessage(
    NativeSocket socket, const Endpoint& destination,
    const std::vector<MessageBuffer>& buffers) {
    NativeAddress address;
    Status status = encodeEndpoint(destination, address);
    if (!status.ok()) return ValueResult<std::size_t>::failure(status);

    if (buffers.size() > static_cast<std::size_t>(ULONG_MAX)) {
        return ValueResult<std::size_t>::failure(
            Status::failure(ErrorKind::InvalidArgument, "Too many message buffers"));
    }

    std::vector<WSABUF> nativeBuffers;
    nativeBuffers.reserve(buffers.size());
    for (const MessageBuffer& buffer : buffers) {
        if (buffer.size > static_cast<std::size_t>(ULONG_MAX)) {
            return ValueResult<std::size_t>::failure(
                Status::failure(ErrorKind::InvalidArgument, "Message buffer is too large"));
        }
        WSABUF native{};
        native.buf = const_cast<char*>(static_cast<const char*>(buffer.data));
        native.len = static_cast<ULONG>(buffer.size);
        nativeBuffers.push_back(native);
    }

    WSAMSG message{};
    message.name = address.asSockaddr();
    message.namelen = address.length;
    message.lpBuffers = nativeBuffers.empty() ? nullptr : nativeBuffers.data();
    message.dwBufferCount = static_cast<DWORD>(nativeBuffers.size());

    // WSASendMsg is exposed as an extension-function pointer in the Windows SDK headers.
    // The target imports a WSASendMsg entry; resolving the provider function via WSAIoctl
    // keeps this reconstruction buildable with the SDK's documented declaration.
    GUID sendMessageId = WSAID_WSASENDMSG;
    LPFN_WSASENDMSG sendMessage = nullptr;
    DWORD bytesReturned = 0;
    if (WSAIoctl(static_cast<SOCKET>(socket), SIO_GET_EXTENSION_FUNCTION_POINTER,
                 &sendMessageId, sizeof(sendMessageId), &sendMessage, sizeof(sendMessage),
                 &bytesReturned, nullptr, nullptr) == SOCKET_ERROR) {
        return ValueResult<std::size_t>::failure(winsockFailure("WSAIoctl(WSASendMsg) failed"));
    }

    DWORD bytesSent = 0;
    if (sendMessage(static_cast<SOCKET>(socket), &message, 0, &bytesSent, nullptr, nullptr) ==
        SOCKET_ERROR) {
        return ValueResult<std::size_t>::failure(winsockFailure("WSASendMsg failed"));
    }
    return ValueResult<std::size_t>::success(static_cast<std::size_t>(bytesSent));
}

} // namespace rbxtransport::reconstruction

#endif // defined(_WIN32)
