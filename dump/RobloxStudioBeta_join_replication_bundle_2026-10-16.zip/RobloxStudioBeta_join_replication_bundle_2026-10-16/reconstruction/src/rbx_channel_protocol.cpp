#include "rbx_channel_protocol.hpp"

#include <algorithm>
#include <limits>
#include <utility>

namespace rbxtransport::reconstruction::protocol {
namespace {

void storeNetworkU32(std::uint8_t* destination, std::uint32_t value) noexcept {
    destination[0] = static_cast<std::uint8_t>((value >> 24) & 0xffU);
    destination[1] = static_cast<std::uint8_t>((value >> 16) & 0xffU);
    destination[2] = static_cast<std::uint8_t>((value >> 8) & 0xffU);
    destination[3] = static_cast<std::uint8_t>(value & 0xffU);
}

std::uint32_t loadNetworkU32(const std::uint8_t* source) noexcept {
    return (static_cast<std::uint32_t>(source[0]) << 24) |
           (static_cast<std::uint32_t>(source[1]) << 16) |
           (static_cast<std::uint32_t>(source[2]) << 8) |
           static_cast<std::uint32_t>(source[3]);
}

void appendTargetU32(std::vector<std::uint8_t>& destination,
                     std::uint32_t value) {
    // FUN_145dba600 passes the address of a native uint32_t to the target's
    // raw-byte writer. The target is x64 little-endian.
    destination.push_back(static_cast<std::uint8_t>(value & 0xffU));
    destination.push_back(static_cast<std::uint8_t>((value >> 8) & 0xffU));
    destination.push_back(static_cast<std::uint8_t>((value >> 16) & 0xffU));
    destination.push_back(static_cast<std::uint8_t>((value >> 24) & 0xffU));
}

std::uint32_t loadTargetU32(const std::uint8_t* source) noexcept {
    return static_cast<std::uint32_t>(source[0]) |
           (static_cast<std::uint32_t>(source[1]) << 8) |
           (static_cast<std::uint32_t>(source[2]) << 16) |
           (static_cast<std::uint32_t>(source[3]) << 24);
}

bool isObservedJoinDataKind(std::uint8_t kind) noexcept {
    return kind >= static_cast<std::uint8_t>(JoinDataChunkKind::Kind1) &&
           kind <= static_cast<std::uint8_t>(JoinDataChunkKind::Kind5);
}

bool hasCompressedLengthPair(std::uint8_t kind) noexcept {
    return kind == static_cast<std::uint8_t>(JoinDataChunkKind::Kind1) ||
           kind == static_cast<std::uint8_t>(JoinDataChunkKind::Kind5);
}

Status protocolError(ErrorKind kind, const char* message) {
    return Status::failure(kind, message);
}

} // namespace

Status configureChannels(ChannelOpenApi& api, std::uint8_t application,
                         const ChannelProfile& profile) {
    for (std::uint32_t channelIndex = 0;
         channelIndex < static_cast<std::uint32_t>(profile.size());
         ++channelIndex) {
        Status status = api.openSendChannel(application, channelIndex, profile[channelIndex]);
        if (!status.ok()) return status;
    }
    return Status::success();
}

LocalUnreliableIdAllocator::LocalUnreliableIdAllocator(std::uint8_t parity) noexcept
    : parity_(static_cast<std::uint8_t>(parity & 1U)) {}

ValueResult<std::int32_t> LocalUnreliableIdAllocator::allocate() {
    constexpr std::uint64_t maxPositiveId =
        static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max());
    const std::uint64_t maxOrdinal = (maxPositiveId - parity_) / 2U;

    std::uint64_t previous = counter_.load(std::memory_order_relaxed);
    for (;;) {
        if (previous >= maxOrdinal) {
            return ValueResult<std::int32_t>::failure(protocolError(
                ErrorKind::InvalidArgument, "Unreliable channel ID space exhausted"));
        }
        if (counter_.compare_exchange_weak(previous, previous + 1U,
                                           std::memory_order_relaxed,
                                           std::memory_order_relaxed)) {
            const std::uint64_t magnitude = 2U * (previous + 1U) | parity_;
            return ValueResult<std::int32_t>::success(
                -static_cast<std::int32_t>(magnitude));
        }
    }
}

std::uint64_t LocalUnreliableIdAllocator::allocations() const noexcept {
    return counter_.load(std::memory_order_relaxed);
}

ValueResult<std::uint32_t> wireMagnitude(std::int32_t internalId) {
    if (internalId >= 0 || internalId == std::numeric_limits<std::int32_t>::min()) {
        return ValueResult<std::uint32_t>::failure(protocolError(
            ErrorKind::InvalidArgument, "Internal unreliable channel ID must be negative"));
    }
    const std::int64_t wide = internalId;
    return ValueResult<std::uint32_t>::success(
        static_cast<std::uint32_t>(-wide));
}

bool isValidPeerInternalId(std::int32_t internalId,
                           std::uint8_t localParity) noexcept {
    if (internalId >= 0 || internalId == std::numeric_limits<std::int32_t>::min()) {
        return false;
    }
    const std::uint32_t magnitude = static_cast<std::uint32_t>(-
        static_cast<std::int64_t>(internalId));
    return magnitude != 0 && ((magnitude & 1U) != (localParity & 1U));
}

ValueResult<std::int32_t> decodePeerWireId(std::uint32_t magnitude,
                                           std::uint8_t localParity) {
    if (magnitude == 0 ||
        magnitude > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        return ValueResult<std::int32_t>::failure(protocolError(
            ErrorKind::InvalidArgument, "Peer unreliable channel ID is out of range"));
    }
    const std::int32_t internalId = -static_cast<std::int32_t>(magnitude);
    if (!isValidPeerInternalId(internalId, localParity)) {
        return ValueResult<std::int32_t>::failure(protocolError(
            ErrorKind::InvalidArgument, "Peer unreliable channel ID has local parity"));
    }
    return ValueResult<std::int32_t>::success(internalId);
}

std::array<std::uint8_t, kReliableOpenBodySize>
serializeReliableOpenBody(std::uint8_t application, std::uint32_t channelIndex) {
    std::array<std::uint8_t, kReliableOpenBodySize> body{};
    body[0] = kReliableOpenType;
    body[1] = application;
    storeNetworkU32(body.data() + 2, channelIndex);
    return body;
}

std::array<std::uint8_t, kReliableOpenRecordSize>
serializeReliableOpenRecord(std::uint8_t application, std::uint32_t channelIndex) {
    std::array<std::uint8_t, kReliableOpenRecordSize> record{};
    record[0] = static_cast<std::uint8_t>(kReliableOpenBodySize);
    const auto body = serializeReliableOpenBody(application, channelIndex);
    std::copy(body.begin(), body.end(), record.begin() + 1);
    return record;
}

ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>
serializeUnreliableOpenControl(std::uint8_t application,
                               std::uint32_t channelIndex,
                               std::int32_t internalId) {
    const ValueResult<std::uint32_t> magnitude = wireMagnitude(internalId);
    if (!magnitude.ok()) {
        return ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>::failure(
            magnitude.status);
    }

    std::array<std::uint8_t, kUnreliableOpenBodySize> body{};
    body[0] = kUnreliableOpenType;
    body[1] = application;
    storeNetworkU32(body.data() + 2, channelIndex);
    storeNetworkU32(body.data() + 6, magnitude.value);
    return ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>::success(body);
}

ValueResult<DecodedUnreliableOpenControl>
parseUnreliableOpenControl(const std::uint8_t* data, std::size_t size) {
    if (data == nullptr || size != kUnreliableOpenBodySize) {
        return ValueResult<DecodedUnreliableOpenControl>::failure(protocolError(
            ErrorKind::InvalidArgument, "Unreliable open control must be exactly 10 bytes"));
    }
    if (data[0] != kUnreliableOpenType) {
        return ValueResult<DecodedUnreliableOpenControl>::failure(protocolError(
            ErrorKind::InvalidArgument, "Unexpected unreliable open control type"));
    }

    const std::uint32_t magnitude = loadNetworkU32(data + 6);
    if (magnitude == 0 ||
        magnitude > static_cast<std::uint32_t>(std::numeric_limits<std::int32_t>::max())) {
        return ValueResult<DecodedUnreliableOpenControl>::failure(protocolError(
            ErrorKind::InvalidArgument, "Unreliable open control ID is out of range"));
    }

    DecodedUnreliableOpenControl decoded;
    decoded.application = data[1];
    decoded.channelIndex = loadNetworkU32(data + 2);
    decoded.internalId = -static_cast<std::int32_t>(magnitude);
    return ValueResult<DecodedUnreliableOpenControl>::success(decoded);
}

ValueResult<std::vector<std::uint8_t>>
serializeJoinDataChunkEnvelope(const JoinDataChunkEnvelope& envelope) {
    const auto kind = static_cast<std::uint8_t>(envelope.kind);
    if (kind != static_cast<std::uint8_t>(JoinDataChunkKind::Kind1) &&
        kind != static_cast<std::uint8_t>(JoinDataChunkKind::Kind5)) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument, "Unsupported target join-data chunk kind"));
    }
    if (envelope.compressedBytes.size() >
        static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument, "Join-data compressed payload exceeds 32-bit length"));
    }

    std::vector<std::uint8_t> bytes;
    bytes.reserve(11U + envelope.compressedBytes.size() +
                  (envelope.appendOptionalZero ? 1U : 0U));
    bytes.push_back(kJoinDataLeadByte);
    bytes.push_back(kJoinDataSubcode);
    bytes.push_back(kind);
    appendTargetU32(bytes, static_cast<std::uint32_t>(envelope.compressedBytes.size()));
    appendTargetU32(bytes, envelope.uncompressedSize);
    bytes.insert(bytes.end(), envelope.compressedBytes.begin(), envelope.compressedBytes.end());
    if (envelope.appendOptionalZero) bytes.push_back(0);
    return ValueResult<std::vector<std::uint8_t>>::success(std::move(bytes));
}

ValueResult<JoinDataChunkEnvelope>
parseJoinDataChunkEnvelope(const std::uint8_t* data, std::size_t size) {
    if (data == nullptr || size < 11U) {
        return ValueResult<JoinDataChunkEnvelope>::failure(protocolError(
            ErrorKind::InvalidArgument, "Compressed join-data envelope is truncated"));
    }
    if (data[0] != kJoinDataLeadByte || data[1] != kJoinDataSubcode ||
        !hasCompressedLengthPair(data[2])) {
        return ValueResult<JoinDataChunkEnvelope>::failure(protocolError(
            ErrorKind::InvalidArgument,
            "Compressed length-pair framing is supported only for observed kinds 1 and 5"));
    }

    const std::uint32_t compressedSize = loadTargetU32(data + 3);
    const std::uint64_t expectedSize = 11ULL + compressedSize;
    if (expectedSize > static_cast<std::uint64_t>(size)) {
        return ValueResult<JoinDataChunkEnvelope>::failure(protocolError(
            ErrorKind::InvalidArgument, "Compressed join-data payload is shorter than declared"));
    }

    JoinDataChunkEnvelope envelope;
    envelope.kind = static_cast<JoinDataChunkKind>(data[2]);
    envelope.uncompressedSize = loadTargetU32(data + 7);
    envelope.compressedBytes.assign(data + 11, data + static_cast<std::size_t>(expectedSize));
    if (size == static_cast<std::size_t>(expectedSize)) {
        envelope.appendOptionalZero = false;
    } else if (expectedSize < static_cast<std::uint64_t>(size) &&
               expectedSize + 1ULL == static_cast<std::uint64_t>(size) &&
               data[static_cast<std::size_t>(expectedSize)] == 0) {
        envelope.appendOptionalZero = true;
    } else {
        return ValueResult<JoinDataChunkEnvelope>::failure(protocolError(
            ErrorKind::InvalidArgument,
            "Compressed join-data envelope has unexpected trailing bytes"));
    }
    return ValueResult<JoinDataChunkEnvelope>::success(std::move(envelope));
}

ValueResult<ParsedJoinReplicationMessage>
parseJoinReplicationMessage(const std::uint8_t* data, std::size_t size) {
    if (data == nullptr && size != 0) {
        return ValueResult<ParsedJoinReplicationMessage>::failure(protocolError(
            ErrorKind::InvalidArgument, "Join/Replication message buffer is null"));
    }

    ParsedJoinReplicationMessage parsed;
    if (size != 0) parsed.rawBytes.assign(data, data + size);
    if (size == 0) {
        return ValueResult<ParsedJoinReplicationMessage>::success(std::move(parsed));
    }

    if (data[0] == kJoinStartMessageTag) {
        parsed.type = JoinReplicationMessageType::JoinStart;
        parsed.body.assign(data + 1, data + size);
        return ValueResult<ParsedJoinReplicationMessage>::success(std::move(parsed));
    }

    if (data[0] != kJoinDataLeadByte || size < 2 || data[1] != kJoinDataSubcode) {
        return ValueResult<ParsedJoinReplicationMessage>::success(std::move(parsed));
    }
    if (size < 3) {
        return ValueResult<ParsedJoinReplicationMessage>::failure(protocolError(
            ErrorKind::InvalidArgument, "Join-data item prefix is truncated"));
    }

    const std::uint8_t kindByte = data[2];
    if (!isObservedJoinDataKind(kindByte)) {
        return ValueResult<ParsedJoinReplicationMessage>::success(std::move(parsed));
    }

    ParsedJoinDataItem item;
    item.kind = static_cast<JoinDataChunkKind>(kindByte);
    item.opaquePayload.assign(data + 3, data + size);
    if (hasCompressedLengthPair(kindByte)) {
        ValueResult<JoinDataChunkEnvelope> envelope = parseJoinDataChunkEnvelope(data, size);
        if (!envelope.ok()) {
            return ValueResult<ParsedJoinReplicationMessage>::failure(envelope.status);
        }
        item.compressedEnvelope = std::move(envelope.value);
    }

    parsed.type = JoinReplicationMessageType::JoinDataItem;
    parsed.body = item.opaquePayload;
    parsed.dataItem = std::move(item);
    return ValueResult<ParsedJoinReplicationMessage>::success(std::move(parsed));
}

ValueResult<std::vector<std::uint8_t>>
serializeJoinStartMessage(const std::vector<std::uint8_t>& opaqueBody) {
    if (opaqueBody.size() == std::numeric_limits<std::size_t>::max()) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument, "Join-start message is too large"));
    }
    std::vector<std::uint8_t> bytes;
    bytes.reserve(opaqueBody.size() + 1U);
    bytes.push_back(kJoinStartMessageTag);
    bytes.insert(bytes.end(), opaqueBody.begin(), opaqueBody.end());
    return ValueResult<std::vector<std::uint8_t>>::success(std::move(bytes));
}

ValueResult<std::vector<std::uint8_t>>
serializeJoinDataItemOpaque(JoinDataChunkKind kind,
                           const std::vector<std::uint8_t>& opaquePayload) {
    const auto kindByte = static_cast<std::uint8_t>(kind);
    if (!isObservedJoinDataKind(kindByte)) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument, "Unsupported observed JoinDataItemV2 kind"));
    }
    if (opaquePayload.size() > std::numeric_limits<std::size_t>::max() - 3U) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument, "Join-data item is too large"));
    }
    std::vector<std::uint8_t> bytes;
    bytes.reserve(opaquePayload.size() + 3U);
    bytes.push_back(kJoinDataLeadByte);
    bytes.push_back(kJoinDataSubcode);
    bytes.push_back(kindByte);
    bytes.insert(bytes.end(), opaquePayload.begin(), opaquePayload.end());
    return ValueResult<std::vector<std::uint8_t>>::success(std::move(bytes));
}

ValueResult<std::vector<std::uint8_t>>
decompressJoinDataChunk(const JoinDataChunkEnvelope& envelope,
                        JoinDataZstdDecoder& decoder) {
    if (!hasCompressedLengthPair(static_cast<std::uint8_t>(envelope.kind))) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument,
            "Only observed JoinDataItemV2 kinds 1 and 5 use this compressed envelope"));
    }
    ValueResult<std::vector<std::uint8_t>> decoded = decoder.decompress(
        envelope.compressedBytes.data(), envelope.compressedBytes.size(),
        envelope.uncompressedSize);
    if (!decoded.ok()) return decoded;
    if (decoded.value.size() != envelope.uncompressedSize) {
        return ValueResult<std::vector<std::uint8_t>>::failure(protocolError(
            ErrorKind::InvalidArgument,
            "Zstandard output size does not match the target envelope"));
    }
    return decoded;
}

ValueResult<JoinReplicationDispatchResult>
dispatchJoinReplicationMessage(const std::uint8_t* data, std::size_t size,
                              JoinReplicationSink& sink) {
    ValueResult<ParsedJoinReplicationMessage> parsed =
        parseJoinReplicationMessage(data, size);
    if (!parsed.ok()) {
        return ValueResult<JoinReplicationDispatchResult>::failure(parsed.status);
    }

    Status callbackStatus = Status::success();
    if (parsed.value.type == JoinReplicationMessageType::JoinStart) {
        callbackStatus = sink.onJoinStart(parsed.value.body);
    } else if (parsed.value.type == JoinReplicationMessageType::JoinDataItem &&
               parsed.value.dataItem.has_value()) {
        callbackStatus = sink.onJoinDataItem(*parsed.value.dataItem);
    } else {
        return ValueResult<JoinReplicationDispatchResult>::success(
            JoinReplicationDispatchResult::NotHandled);
    }

    if (!callbackStatus.ok()) {
        return ValueResult<JoinReplicationDispatchResult>::failure(callbackStatus);
    }
    return ValueResult<JoinReplicationDispatchResult>::success(
        JoinReplicationDispatchResult::Handled);
}

CallbackDispatchPath dispatchCallback(std::int32_t currentThreadId,
                                      std::int32_t ownerThreadId,
                                      CallbackExecutor& executor,
                                      std::function<void()> callback) {
    if (!callback) return CallbackDispatchPath::NoCallback;
    if (currentThreadId == ownerThreadId) {
        callback();
        return CallbackDispatchPath::InvokedInline;
    }
    executor.submit(std::move(callback));
    return CallbackDispatchPath::Submitted;
}

ChannelControlState::ChannelControlState(std::uint8_t localParity) noexcept
    : allocator_(localParity) {}

ValueResult<std::int32_t>
ChannelControlState::onUnreliableOpenCallback(std::uint32_t channelIndex) {
    if (channelIndex >= kChannelProfileCount) {
        return ValueResult<std::int32_t>::failure(protocolError(
            ErrorKind::InvalidArgument, "Unreliable channel index is outside the 14-channel profile"));
    }

    std::lock_guard<std::mutex> lock(mutex_);
    if (localIds_[channelIndex].has_value()) {
        return ValueResult<std::int32_t>::failure(protocolError(
            ErrorKind::AlreadyInProgress, "Unreliable channel already has a local wire ID"));
    }
    ValueResult<std::int32_t> id = allocator_.allocate();
    if (!id.ok()) return id;
    localIds_[channelIndex] = id.value;
    return id;
}

ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>
ChannelControlState::makeUnreliableOpenControl(std::uint8_t application,
                                              std::uint32_t channelIndex) const {
    if (channelIndex >= kChannelProfileCount) {
        return ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>::failure(
            protocolError(ErrorKind::InvalidArgument,
                          "Unreliable channel index is outside the 14-channel profile"));
    }

    std::optional<std::int32_t> id;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        id = localIds_[channelIndex];
    }
    if (!id.has_value()) {
        return ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>>::failure(
            protocolError(ErrorKind::InvalidArgument,
                          "Unreliable channel has no allocated local wire ID"));
    }
    return serializeUnreliableOpenControl(application, channelIndex, *id);
}

std::optional<std::int32_t>
ChannelControlState::localId(std::uint32_t channelIndex) const {
    if (channelIndex >= kChannelProfileCount) return std::nullopt;
    std::lock_guard<std::mutex> lock(mutex_);
    return localIds_[channelIndex];
}

} // namespace rbxtransport::reconstruction::protocol
