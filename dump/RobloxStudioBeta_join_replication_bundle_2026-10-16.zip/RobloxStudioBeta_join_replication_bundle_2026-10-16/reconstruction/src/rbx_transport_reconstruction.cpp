#include "rbx_transport_reconstruction.hpp"

#include <utility>

namespace rbxtransport::reconstruction {

Status Status::success() {
    return {};
}

Status Status::failure(ErrorKind kind, std::string message, int nativeCode) {
    Status result;
    result.kind = kind;
    result.nativeCode = nativeCode;
    result.message = std::move(message);
    return result;
}

bool Status::ok() const noexcept {
    return kind == ErrorKind::None;
}

SysTcpSocket::SysTcpSocket(SocketApi& api, NativeSocket socket)
    : api_(api), socket_(socket) {}

Status SysTcpSocket::bind(const Endpoint& local, TcpBindOptions options) {
    // Ghidra: FUN_1435eb9a0 applies socket options before the WS2_32 ordinal-2 bind call.
    // The option flags are represented as named booleans here; exact original flag packing
    // and all error-formatting helpers were not recovered.
    if (options.noDelay) {
        Status status = api_.setOption(socket_, SocketOption::TcpNoDelay, 1, local.family);
        if (!status.ok()) return status;
    }
    if (options.reuseAddress) {
        Status status = api_.setOption(socket_, SocketOption::ReuseAddress, 1, local.family);
        if (!status.ok()) return status;
    }
    return api_.bind(socket_, local);
}

Status SysTcpSocket::connect(const Endpoint& peer) {
    // Ghidra: FUN_1435ed4a0 calls WS2_32 ordinal 4 with (socket, sockaddr, length),
    // then forwards the result through Roblox's error/result conversion helper.
    return api_.connect(socket_, peer);
}

ValueResult<Endpoint> SysTcpSocket::localName() {
    // Ghidra: FUN_1435ed9f0 calls WS2_32 ordinal 6 (getsockname).
    return api_.getLocalName(socket_);
}

ValueResult<Endpoint> SysTcpSocket::peerName() {
    // Ghidra: FUN_1435ef2c0 calls WS2_32 ordinal 5 (getpeername).
    return api_.getPeerName(socket_);
}

Status SysTcpSocket::close() {
    if (socket_ == kInvalidSocket) return Status::success();
    Status status = api_.closeSocket(socket_);
    if (status.ok()) socket_ = kInvalidSocket;
    return status;
}

SysUdpSocket::SysUdpSocket(SocketApi& api, NativeSocket socket, AddressFamily family)
    : api_(api), socket_(socket), family_(family), receiveState_(std::make_shared<ReceiveState>()) {}

ValueResult<std::size_t> SysUdpSocket::sendMessage(
    const Endpoint& destination, const std::vector<MessageBuffer>& buffers) {
    // Ghidra: FUN_1435f5d80 constructs a message/buffer structure and calls the imported
    // WSASendMsg entry. The exact ancillary-data layout is intentionally not reproduced.
    return api_.sendMessage(socket_, destination, buffers);
}

Status SysUdpSocket::setOption(UdpOption option, int value) {
    switch (option) {
    case UdpOption::DontFragment:
        // The target contains the diagnostic "Cannot disable dontFragment in IPv6".
        if (family_ == AddressFamily::IPv6 && value == 0) {
            return Status::failure(ErrorKind::Unsupported,
                                   "Cannot disable dontFragment in IPv6");
        }
        // The target's Windows path sets/queries the corresponding IPv4 socket option.
        if (family_ == AddressFamily::IPv6) return Status::success();
        return api_.setOption(socket_, SocketOption::DontFragment, value != 0 ? 1 : 0, family_);
    case UdpOption::IpPacketInfo:
        return Status::failure(ErrorKind::Unsupported,
                               "IP_PKTINFO is not supported on this platform");
    case UdpOption::IpReceiveError:
        return Status::failure(ErrorKind::Unsupported, "IP_RECVERR is Linux-specific");
    case UdpOption::TimestampNanoseconds:
        return Status::failure(ErrorKind::Unsupported, "SO_TIMESTAMPNS is Linux-specific");
    }
    return Status::failure(ErrorKind::InvalidArgument, "Unknown UDP option");
}

ValueResult<int> SysUdpSocket::getOption(UdpOption option) {
    switch (option) {
    case UdpOption::DontFragment:
        // Ghidra's getsockopt path treats IPv6 as always non-fragmenting.
        if (family_ == AddressFamily::IPv6) return ValueResult<int>::success(1);
        return api_.getOption(socket_, SocketOption::DontFragment, family_);
    case UdpOption::IpPacketInfo:
        return ValueResult<int>::failure(Status::failure(
            ErrorKind::Unsupported, "IP_PKTINFO is not supported on this platform"));
    case UdpOption::IpReceiveError:
        return ValueResult<int>::failure(Status::failure(
            ErrorKind::Unsupported, "IP_RECVERR is Linux-specific"));
    case UdpOption::TimestampNanoseconds:
        return ValueResult<int>::failure(Status::failure(
            ErrorKind::Unsupported, "SO_TIMESTAMPNS is Linux-specific"));
    }
    return ValueResult<int>::failure(
        Status::failure(ErrorKind::InvalidArgument, "Unknown UDP option"));
}

Status SysUdpSocket::setMaxSameIterationRecv(int value) {
    if (value <= 0) {
        return Status::failure(ErrorKind::InvalidArgument,
                               "MaxSameIterationRecv MUST be positive");
    }
    std::lock_guard<std::mutex> lock(receiveState_->mutex);
    receiveState_->maxSameIterationRecv = value;
    return Status::success();
}

int SysUdpSocket::maxSameIterationRecv() const {
    std::lock_guard<std::mutex> lock(receiveState_->mutex);
    return receiveState_->maxSameIterationRecv;
}

Status SysUdpSocket::beginAsyncReceive(AsyncReceiver& receiver,
                                       ReceiveCompletion completion) {
    const std::shared_ptr<ReceiveState> state = receiveState_;
    {
        std::lock_guard<std::mutex> lock(state->mutex);
        if (state->pending) {
            // Ghidra: FUN_1435f4530/FUN_1435eef10 contain this duplicate-receive diagnostic.
            return Status::failure(ErrorKind::AlreadyInProgress,
                                   "There is an asynchronous recv in progress already");
        }
        state->pending = true;
    }

    ReceiveCompletion wrapped = [state, completion = std::move(completion)](
                                    Status status, Endpoint source,
                                    std::vector<std::uint8_t> bytes) mutable {
        {
            std::lock_guard<std::mutex> lock(state->mutex);
            state->pending = false;
        }
        if (completion) completion(std::move(status), source, std::move(bytes));
    };

    Status status = receiver.startReceive(socket_, std::move(wrapped));
    if (!status.ok()) {
        std::lock_guard<std::mutex> lock(state->mutex);
        state->pending = false;
    }
    return status;
}

bool SysUdpSocket::receivePending() const {
    std::lock_guard<std::mutex> lock(receiveState_->mutex);
    return receiveState_->pending;
}

Status SysUdpSocket::close() {
    if (socket_ == kInvalidSocket) return Status::success();
    Status status = api_.closeSocket(socket_);
    if (status.ok()) socket_ = kInvalidSocket;
    return status;
}

Status LibuvUdpOptionPolicy::setReusePort(bool enabled) {
    if (!enabled) return Status::success();
    // Literal recovered from the LibuvUdpSocket option path (vtable slot 5).
    return Status::failure(ErrorKind::Unsupported,
                           "This platform does not support SO_REUSEPORT");
}

Status LibuvOptionValidation::unknownOption(std::string_view name) {
    return Status::failure(ErrorKind::Libuv,
                           "Unknown option: " + std::string(name));
}

Status LibuvOptionValidation::invalidValue() {
    return Status::failure(ErrorKind::Libuv, "Invalid value for the given option");
}

Status TlsClientContext::initClient(TlsClientProvider& provider,
                                    std::string_view certificatePath) const {
    // These messages are present in the QUIC/TLS code. Exact certificate selection and
    // initialization branch ordering remain uncertain; this method preserves only the
    // observed failure surfaces.
    if (!certificatePath.empty() && !provider.certificateFileExists(certificatePath)) {
        return Status::failure(ErrorKind::Tls,
                               "Certificate file " + std::string(certificatePath) + " not found");
    }

    Status contextStatus = provider.initializeClient(certificatePath);
    if (!contextStatus.ok()) {
        return Status::failure(ErrorKind::Tls, "TlsContext::initClient failed",
                               contextStatus.nativeCode);
    }

    Status sessionStatus = provider.createClientSession();
    if (!sessionStatus.ok()) {
        return Status::failure(ErrorKind::Tls,
                               "Failed to initialize TLS client session",
                               sessionStatus.nativeCode);
    }
    return Status::success();
}

} // namespace rbxtransport::reconstruction
