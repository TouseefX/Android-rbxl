#include "rbx_transport_reconstruction.hpp"

#include <cassert>
#include <iostream>
#include <string>
#include <utility>

using namespace rbxtransport::reconstruction;

namespace {

class FakeSocketApi final : public SocketApi {
public:
    std::vector<std::string> calls;
    Status nextOptionStatus = Status::success();
    Status bindStatus = Status::success();
    Status connectStatus = Status::success();
    Status closeStatus = Status::success();
    Endpoint local{};
    Endpoint peer{};
    std::size_t sendBytes{0};

    ValueResult<NativeSocket> createSocket(AddressFamily, SocketKind) override {
        calls.emplace_back("create");
        return ValueResult<NativeSocket>::success(77);
    }

    Status closeSocket(NativeSocket) override {
        calls.emplace_back("close");
        return closeStatus;
    }

    Status setOption(NativeSocket, SocketOption option, int, AddressFamily) override {
        switch (option) {
        case SocketOption::TcpNoDelay: calls.emplace_back("option:tcp-nodelay"); break;
        case SocketOption::ReuseAddress: calls.emplace_back("option:reuse-address"); break;
        case SocketOption::DontFragment: calls.emplace_back("option:dont-fragment"); break;
        }
        return nextOptionStatus;
    }

    ValueResult<int> getOption(NativeSocket, SocketOption option, AddressFamily) override {
        switch (option) {
        case SocketOption::TcpNoDelay: calls.emplace_back("get-option:tcp-nodelay"); break;
        case SocketOption::ReuseAddress: calls.emplace_back("get-option:reuse-address"); break;
        case SocketOption::DontFragment: calls.emplace_back("get-option:dont-fragment"); break;
        }
        return ValueResult<int>::success(1);
    }

    Status bind(NativeSocket, const Endpoint&) override {
        calls.emplace_back("bind");
        return bindStatus;
    }

    Status connect(NativeSocket, const Endpoint&) override {
        calls.emplace_back("connect");
        return connectStatus;
    }

    ValueResult<Endpoint> getLocalName(NativeSocket) override {
        calls.emplace_back("local-name");
        return ValueResult<Endpoint>::success(local);
    }

    ValueResult<Endpoint> getPeerName(NativeSocket) override {
        calls.emplace_back("peer-name");
        return ValueResult<Endpoint>::success(peer);
    }

    ValueResult<std::size_t> sendMessage(
        NativeSocket, const Endpoint&, const std::vector<MessageBuffer>& buffers) override {
        calls.emplace_back("send-message");
        std::size_t total = 0;
        for (const MessageBuffer& buffer : buffers) total += buffer.size;
        return ValueResult<std::size_t>::success(total == 0 ? sendBytes : total);
    }
};

class FakeAsyncReceiver final : public AsyncReceiver {
public:
    ReceiveCompletion completion;
    Status startStatus = Status::success();

    Status startReceive(NativeSocket, ReceiveCompletion callback) override {
        completion = std::move(callback);
        return startStatus;
    }

    void complete(Status status = Status::success()) {
        assert(static_cast<bool>(completion));
        Endpoint source{};
        source.family = AddressFamily::IPv4;
        source.port = 4567;
        completion(std::move(status), source, {1, 2, 3});
        completion = {};
    }
};

class FakeTlsProvider final : public TlsClientProvider {
public:
    bool certExists{true};
    Status clientStatus = Status::success();
    Status sessionStatus = Status::success();

    bool certificateFileExists(std::string_view) const override { return certExists; }
    Status initializeClient(std::string_view) override { return clientStatus; }
    Status createClientSession() override { return sessionStatus; }
};

void testTcpSocketForwarding() {
    FakeSocketApi api;
    Endpoint endpoint{};
    endpoint.family = AddressFamily::IPv4;
    endpoint.port = 80;
    SysTcpSocket socket(api, 10);

    Status status = socket.bind(endpoint, TcpBindOptions{true, true});
    assert(status.ok());
    assert((api.calls == std::vector<std::string>{
        "option:tcp-nodelay", "option:reuse-address", "bind"}));

    assert(socket.connect(endpoint).ok());
    assert(socket.localName().ok());
    assert(socket.peerName().ok());
    assert(socket.close().ok());
    assert(api.calls.back() == "close");
}

void testUdpSendAndOptions() {
    FakeSocketApi api;
    Endpoint destination{};
    destination.family = AddressFamily::IPv4;
    destination.port = 9000;
    SysUdpSocket socket(api, 11, AddressFamily::IPv4);

    const std::uint8_t payload[] = {1, 2, 3, 4};
    const std::vector<MessageBuffer> buffers{{payload, sizeof(payload)}};
    ValueResult<std::size_t> sent = socket.sendMessage(destination, buffers);
    assert(sent.ok());
    assert(sent.value == 4);
    assert(api.calls.back() == "send-message");

    assert(socket.setOption(UdpOption::DontFragment, 1).ok());
    assert(api.calls.back() == "option:dont-fragment");
    ValueResult<int> dontFragment = socket.getOption(UdpOption::DontFragment);
    assert(dontFragment.ok() && dontFragment.value == 1);
    assert(api.calls.back() == "get-option:dont-fragment");

    Status info = socket.setOption(UdpOption::IpPacketInfo, 1);
    assert(!info.ok());
    assert(info.message == "IP_PKTINFO is not supported on this platform");
    Status errQueue = socket.setOption(UdpOption::IpReceiveError, 1);
    assert(!errQueue.ok());
    assert(errQueue.message == "IP_RECVERR is Linux-specific");
    Status timestamp = socket.setOption(UdpOption::TimestampNanoseconds, 1);
    assert(!timestamp.ok());
    assert(timestamp.message == "SO_TIMESTAMPNS is Linux-specific");

    assert(!socket.setMaxSameIterationRecv(0).ok());
    assert(socket.setMaxSameIterationRecv(4).ok());
    assert(socket.maxSameIterationRecv() == 4);

    SysUdpSocket ipv6(api, 12, AddressFamily::IPv6);
    Status fragment = ipv6.setOption(UdpOption::DontFragment, 0);
    assert(!fragment.ok());
    assert(fragment.message == "Cannot disable dontFragment in IPv6");
}

void testAsyncReceiveGuard() {
    FakeSocketApi api;
    FakeAsyncReceiver receiver;
    SysUdpSocket socket(api, 13, AddressFamily::IPv4);
    int completions = 0;

    Status first = socket.beginAsyncReceive(receiver,
        [&completions](Status status, Endpoint, std::vector<std::uint8_t> bytes) {
            assert(status.ok());
            assert(bytes.size() == 3);
            ++completions;
        });
    assert(first.ok());
    assert(socket.receivePending());

    Status second = socket.beginAsyncReceive(receiver, {});
    assert(!second.ok());
    assert(second.kind == ErrorKind::AlreadyInProgress);
    assert(second.message == "There is an asynchronous recv in progress already");

    receiver.complete();
    assert(completions == 1);
    assert(!socket.receivePending());

    assert(socket.beginAsyncReceive(receiver, {}).ok());
    assert(socket.receivePending());
}

void testPlatformAndTlsErrors() {
    assert(!LibuvUdpOptionPolicy::setReusePort(true).ok());
    assert(LibuvUdpOptionPolicy::setReusePort(true).message ==
           "This platform does not support SO_REUSEPORT");
    assert(LibuvUdpOptionPolicy::setReusePort(false).ok());
    assert(LibuvOptionValidation::unknownOption("x").message == "Unknown option: x");
    assert(LibuvOptionValidation::invalidValue().message ==
           "Invalid value for the given option");

    TlsClientContext tls;
    FakeTlsProvider provider;
    provider.certExists = false;
    Status missing = tls.initClient(provider, "cert.pem");
    assert(!missing.ok());
    assert(missing.message == "Certificate file cert.pem not found");

    provider.certExists = true;
    provider.clientStatus = Status::failure(ErrorKind::Tls, "internal", 11);
    Status initFailure = tls.initClient(provider, "cert.pem");
    assert(!initFailure.ok());
    assert(initFailure.message == "TlsContext::initClient failed");
    assert(initFailure.nativeCode == 11);

    provider.clientStatus = Status::success();
    provider.sessionStatus = Status::failure(ErrorKind::Tls, "internal", 12);
    Status sessionFailure = tls.initClient(provider, "cert.pem");
    assert(!sessionFailure.ok());
    assert(sessionFailure.message == "Failed to initialize TLS client session");
    assert(sessionFailure.nativeCode == 12);
}

} // namespace

int main() {
    testTcpSocketForwarding();
    testUdpSendAndOptions();
    testAsyncReceiveGuard();
    testPlatformAndTlsErrors();
    std::cout << "transport reconstruction tests passed\n";
    return 0;
}
