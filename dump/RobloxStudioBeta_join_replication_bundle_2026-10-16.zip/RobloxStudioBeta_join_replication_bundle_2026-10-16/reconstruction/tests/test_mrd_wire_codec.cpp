#include "rbx_mrd_wire_codec.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <vector>

using namespace rbxtransport::reconstruction::mrd;

inline void checkCondition(bool condition, const char* expression,
                           const char* file, int line) {
    if (condition) return;
    std::cerr << "CHECK failed at " << file << ':' << line
              << ": " << expression << '\n';
    std::exit(EXIT_FAILURE);
}
#define CHECK(condition) checkCondition(static_cast<bool>(condition), #condition, __FILE__, __LINE__)

namespace {

std::uint32_t nextRandom(std::uint32_t& state) {
    state ^= state << 13U;
    state ^= state >> 17U;
    state ^= state << 5U;
    return state;
}

void testTargetGoldenHuffmanAndPadding() {
    // Target table entry for 'a' is length 5, code 0x18000000. Three symbols
    // produce fifteen bits; FUN_143084870 pads the last byte with one bits.
    const std::array<std::uint8_t, 3> threeAs{{'a', 'a', 'a'}};
    const MrdEncodeResult encoded = encodeMrd80Record(1, threeAs.data(), threeAs.size());
    const std::vector<std::uint8_t> expected{{0x81, 0x82, 0x18, 0xc7}};
    CHECK(encoded.ok());
    CHECK(encoded.bytes == expected);

    MrdDecodeResult decoded = decodeMrd80Record(expected.data(), expected.size());
    CHECK(decoded.ok());
    CHECK(decoded.record.backReferenceDelta == 1);
    CHECK(decoded.record.huffmanCompressed);
    CHECK(decoded.record.bytesConsumed == expected.size());
    CHECK(decoded.record.payload == std::vector<std::uint8_t>(threeAs.begin(), threeAs.end()));

    std::vector<std::uint8_t> manyAs(128, static_cast<std::uint8_t>('a'));
    MrdEncodeResult largeCompressed = encodeMrd80Record(5, manyAs.data(), manyAs.size());
    CHECK(largeCompressed.ok());
    CHECK(largeCompressed.bytes.size() == 82);
    CHECK(largeCompressed.bytes[0] == 0x85);
    CHECK(largeCompressed.bytes[1] == 0xd0); // compressed flag plus width-7 size 80
    MrdDecodeResult largeRoundTrip = decodeMrd80Record(
        largeCompressed.bytes.data(), largeCompressed.bytes.size());
    CHECK(largeRoundTrip.ok());
    CHECK(largeRoundTrip.record.huffmanCompressed);
    CHECK(largeRoundTrip.record.payload == manyAs);
}

void testRawChoiceAndEmptyRecord() {
    // Symbol 0xff has a 26-bit code, so for this one-byte input Huffman is not smaller.
    const std::array<std::uint8_t, 1> oneByte{{0xff}};
    MrdEncodeResult raw = encodeMrd80Record(1, oneByte.data(), oneByte.size());
    CHECK(raw.ok());
    CHECK(raw.bytes == std::vector<std::uint8_t>({0x81, 0x01, 0xff}));

    MrdDecodeResult rawDecoded = decodeMrd80Record(raw.bytes.data(), raw.bytes.size());
    CHECK(rawDecoded.ok());
    CHECK(!rawDecoded.record.huffmanCompressed);
    CHECK(rawDecoded.record.payload == std::vector<std::uint8_t>(oneByte.begin(), oneByte.end()));

    MrdEncodeResult empty = encodeMrd80Record(0, nullptr, 0);
    CHECK(empty.ok());
    CHECK(empty.bytes == std::vector<std::uint8_t>({0x80, 0x00}));
    MrdDecodeResult emptyDecoded = decodeMrd80Record(empty.bytes.data(), empty.bytes.size());
    CHECK(emptyDecoded.ok());
    CHECK(emptyDecoded.record.payload.empty());
    CHECK(emptyDecoded.record.bytesConsumed == 2);

    // The reader accepts the decoder's initial state as end-accepted for a zero-byte
    // compressed payload; the writer itself does not choose compression for empty input.
    const std::array<std::uint8_t, 2> emptyCompressed{{0x80, 0x80}};
    MrdDecodeResult acceptedEmptyHuffman =
        decodeMrd80Record(emptyCompressed.data(), emptyCompressed.size());
    CHECK(acceptedEmptyHuffman.ok());
    CHECK(acceptedEmptyHuffman.record.huffmanCompressed);
    CHECK(acceptedEmptyHuffman.record.payload.empty());
}

void testSentinelAndContinuationFields() {
    std::uint64_t priorIndex = std::numeric_limits<std::uint64_t>::max();
    CHECK(resolveMrd80PriorSequenceIndex(10, 2, priorIndex));
    CHECK(priorIndex == 7);
    CHECK(resolveMrd80PriorSequenceIndex(10, 9, priorIndex));
    CHECK(priorIndex == 0);
    CHECK(!resolveMrd80PriorSequenceIndex(10, 10, priorIndex));
    CHECK(!resolveMrd80PriorSequenceIndex(0, 0, priorIndex));

    const std::array<std::uint8_t, 0> emptyPayload{};
    struct Case {
        std::uint64_t tag;
        std::vector<std::uint8_t> expected;
    };
    const std::array<Case, 4> cases{{
        {63,  {0xbf, 0x00, 0x00}},
        {64,  {0xbf, 0x01, 0x00}},
        {190, {0xbf, 0x7f, 0x00}},
        {191, {0xbf, 0x80, 0x01, 0x00}},
    }};
    for (const Case& test : cases) {
        MrdEncodeResult encoded = encodeMrd80Record(test.tag, emptyPayload.data(), 0);
        CHECK(encoded.ok());
        CHECK(encoded.bytes == test.expected);
        MrdDecodeResult decoded = decodeMrd80Record(test.expected.data(), test.expected.size());
        CHECK(decoded.ok());
        CHECK(decoded.record.backReferenceDelta == test.tag);
        CHECK(decoded.record.bytesConsumed == test.expected.size());
    }

    // At the exact width-7 sentinel, the size field emits a zero continuation group.
    // Zero bytes are intentionally high-cost under the target Huffman table, so this is raw.
    const std::vector<std::uint8_t> zeros(127, 0);
    MrdEncodeResult sizeSentinel = encodeMrd80Record(0, zeros.data(), zeros.size());
    CHECK(sizeSentinel.ok());
    CHECK(sizeSentinel.bytes.size() == 3 + zeros.size());
    CHECK(sizeSentinel.bytes[0] == 0x80);
    CHECK(sizeSentinel.bytes[1] == 0x7f);
    CHECK(sizeSentinel.bytes[2] == 0x00);
    CHECK(std::equal(zeros.begin(), zeros.end(), sizeSentinel.bytes.begin() + 3));
    MrdDecodeResult decodedZeros = decodeMrd80Record(
        sizeSentinel.bytes.data(), sizeSentinel.bytes.size());
    CHECK(decodedZeros.ok());
    CHECK(decodedZeros.record.payload == zeros);
}

void testIncrementalBoundsAndMalformedInput() {
    CHECK(decodeMrd80Record(nullptr, 0).error == MrdWireError::NeedMoreData);
    CHECK(encodeMrd80Record(0, nullptr, 1).error == MrdWireError::InvalidArgument);

    const std::array<std::uint8_t, 1> invalidTag{{0x40}};
    CHECK(decodeMrd80Record(invalidTag.data(), invalidTag.size()).error ==
          MrdWireError::InvalidTagFamily);

    const std::array<std::uint8_t, 1> tagOnly{{0x81}};
    CHECK(decodeMrd80Record(tagOnly.data(), tagOnly.size()).error == MrdWireError::NeedMoreData);
    const std::array<std::uint8_t, 3> compressedTruncated{{0x81, 0x82, 0x18}};
    CHECK(decodeMrd80Record(compressedTruncated.data(), compressedTruncated.size()).error ==
          MrdWireError::NeedMoreData);

    const std::array<std::uint8_t, 6> invalidHuffman{{
        0x80, 0x84, 0xff, 0xff, 0xff, 0xff
    }};
    CHECK(decodeMrd80Record(invalidHuffman.data(), invalidHuffman.size()).error ==
          MrdWireError::InvalidHuffmanData);

    const std::array<std::uint8_t, 11> overflowTag{{
        0xbf, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x7f
    }};
    CHECK(decodeMrd80Record(overflowTag.data(), overflowTag.size()).error ==
          MrdWireError::FieldValueOverflow);
    CHECK(encodeMrd80Record(std::numeric_limits<std::uint64_t>::max(), nullptr, 0).error ==
          MrdWireError::FieldValueOverflow);

    Mrd80CodecLimits smallLimits;
    smallLimits.maxPayloadBytes = 2;
    const std::array<std::uint8_t, 3> threeBytes{{1, 2, 3}};
    CHECK(encodeMrd80Record(0, threeBytes.data(), threeBytes.size(), smallLimits).error ==
          MrdWireError::PayloadLimitExceeded);

    const std::array<std::uint8_t, 4> huffmanThreeAs{{0x81, 0x82, 0x18, 0xc7}};
    smallLimits = {};
    smallLimits.maxDecodedBytes = 2;
    CHECK(decodeMrd80Record(huffmanThreeAs.data(), huffmanThreeAs.size(), smallLimits).error ==
          MrdWireError::DecodedPayloadLimitExceeded);

    smallLimits = {};
    smallLimits.maxRecordBytes = 2;
    const std::array<std::uint8_t, 3> rawTwoBytes{{0x80, 0x02, 0xaa}};
    CHECK(decodeMrd80Record(rawTwoBytes.data(), rawTwoBytes.size(), smallLimits).error ==
          MrdWireError::RecordLimitExceeded);
}

void testConcatenatedRecordsAndDeterministicRoundTrips() {
    const std::array<std::uint8_t, 3> firstPayload{{'a', 'b', 'c'}};
    const std::array<std::uint8_t, 1> secondPayload{{0xff}};
    MrdEncodeResult first = encodeMrd80Record(64, firstPayload.data(), firstPayload.size());
    MrdEncodeResult second = encodeMrd80Record(3, secondPayload.data(), secondPayload.size());
    CHECK(first.ok() && second.ok());

    std::vector<std::uint8_t> stream = first.bytes;
    stream.insert(stream.end(), second.bytes.begin(), second.bytes.end());
    MrdDecodeResult decodedFirst = decodeMrd80Record(stream.data(), stream.size());
    CHECK(decodedFirst.ok());
    CHECK(decodedFirst.record.bytesConsumed == first.bytes.size());
    CHECK(decodedFirst.record.backReferenceDelta == 64);
    CHECK(decodedFirst.record.payload == std::vector<std::uint8_t>(firstPayload.begin(), firstPayload.end()));

    MrdDecodeResult decodedSecond = decodeMrd80Record(
        stream.data() + decodedFirst.record.bytesConsumed,
        stream.size() - decodedFirst.record.bytesConsumed);
    CHECK(decodedSecond.ok());
    CHECK(decodedSecond.record.bytesConsumed == second.bytes.size());
    CHECK(decodedSecond.record.backReferenceDelta == 3);
    CHECK(decodedSecond.record.payload == std::vector<std::uint8_t>(secondPayload.begin(), secondPayload.end()));

    std::uint32_t randomState = 0x80c0ffeeU;
    const std::array<std::size_t, 9> lengths{{0, 1, 2, 3, 7, 31, 128, 1024, 4096}};
    for (std::size_t length : lengths) {
        std::vector<std::uint8_t> payload(length);
        for (std::uint8_t& byte : payload) {
            byte = static_cast<std::uint8_t>(nextRandom(randomState) >> 24U);
        }
        const std::uint64_t tag = length == 0 ? 63 : static_cast<std::uint64_t>(length + 63);
        MrdEncodeResult encoded = encodeMrd80Record(tag, payload.data(), payload.size());
        CHECK(encoded.ok());
        MrdDecodeResult decoded = decodeMrd80Record(encoded.bytes.data(), encoded.bytes.size());
        CHECK(decoded.ok());
        CHECK(decoded.record.backReferenceDelta == tag);
        CHECK(decoded.record.payload == payload);
        CHECK(decoded.record.bytesConsumed == encoded.bytes.size());
    }
}

} // namespace

int main() {
    testTargetGoldenHuffmanAndPadding();
    testRawChoiceAndEmptyRecord();
    testSentinelAndContinuationFields();
    testIncrementalBoundsAndMalformedInput();
    testConcatenatedRecordsAndDeterministicRoundTrips();
    std::cout << "Mrd 0x80 wire codec tests passed\n";
    return 0;
}
