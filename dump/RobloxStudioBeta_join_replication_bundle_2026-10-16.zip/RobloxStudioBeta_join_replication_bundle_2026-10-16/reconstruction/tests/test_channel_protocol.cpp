#include "rbx_channel_protocol.hpp"

#include <cstdint>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <limits>
#include <utility>
#include <vector>

using namespace rbxtransport::reconstruction;
using namespace rbxtransport::reconstruction::protocol;

inline void checkCondition(bool condition, const char* expression,
                           const char* file, int line) {
    if (condition) return;
    std::cerr << "CHECK failed at " << file << ':' << line
              << ": " << expression << '\n';
    std::exit(EXIT_FAILURE);
}
#define CHECK(condition) checkCondition(static_cast<bool>(condition), #condition, __FILE__, __LINE__)

namespace {

class FakeChannelOpenApi final : public ChannelOpenApi {
public:
    struct Call {
        std::uint8_t application;
        std::uint32_t index;
        ChannelProfileRow row;
    };

    std::vector<Call> calls;
    std::uint32_t failAt{std::numeric_limits<std::uint32_t>::max()};

    Status openSendChannel(std::uint8_t application, std::uint32_t channelIndex,
                           const ChannelProfileRow& row) override {
        calls.push_back({application, channelIndex, row});
        if (channelIndex == failAt) {
            return Status::failure(ErrorKind::InvalidArgument, "fake open failure");
        }
        return Status::success();
    }
};

class FakeExecutor final : public CallbackExecutor {
public:
    std::vector<std::function<void()>> pending;

    void submit(std::function<void()> callback) override {
        pending.push_back(std::move(callback));
    }

    void runOne() {
        CHECK(!pending.empty());
        auto callback = std::move(pending.front());
        pending.erase(pending.begin());
        if (callback) callback();
    }
};

class FakeJoinDataDecoder final : public JoinDataZstdDecoder {
public:
    ValueResult<std::vector<std::uint8_t>> decompress(
        const std::uint8_t* compressedBytes, std::size_t compressedSize,
        std::uint32_t) override {
        if (compressedBytes == nullptr && compressedSize != 0) {
            return ValueResult<std::vector<std::uint8_t>>::failure(Status::failure(
                ErrorKind::InvalidArgument, "null compressed data"));
        }
        std::vector<std::uint8_t> bytes;
        if (compressedSize != 0) bytes.assign(compressedBytes, compressedBytes + compressedSize);
        return ValueResult<std::vector<std::uint8_t>>::success(std::move(bytes));
    }
};

class FakeJoinSink final : public JoinReplicationSink {
public:
    std::vector<std::uint8_t> joinStartBody;
    std::vector<ParsedJoinDataItem> items;

    Status onJoinStart(const std::vector<std::uint8_t>& opaqueBody) override {
        joinStartBody = opaqueBody;
        return Status::success();
    }

    Status onJoinDataItem(const ParsedJoinDataItem& item) override {
        items.push_back(item);
        return Status::success();
    }
};

void testDefaultProfileAndSetupLoop() {
    constexpr std::array<std::uint32_t, 4> expectedUnreliable{{3, 5, 6, 11}};
    std::size_t found = 0;
    for (std::uint32_t index = 0; index < kDefaultChannelProfile.size(); ++index) {
        if (isUnreliable(kDefaultChannelProfile[index])) {
            CHECK(found < expectedUnreliable.size());
            CHECK(index == expectedUnreliable[found]);
            ++found;
        }
    }
    CHECK(found == expectedUnreliable.size());

    FakeChannelOpenApi api;
    CHECK(configureChannels(api, 2).ok());
    CHECK(api.calls.size() == kChannelProfileCount);
    for (std::uint32_t index = 0; index < api.calls.size(); ++index) {
        CHECK(api.calls[index].application == 2);
        CHECK(api.calls[index].index == index);
        CHECK(api.calls[index].row.mode == kDefaultChannelProfile[index].mode);
        CHECK(api.calls[index].row.auxiliary == kDefaultChannelProfile[index].auxiliary);
        CHECK(api.calls[index].row.flag == kDefaultChannelProfile[index].flag);
    }

    FakeChannelOpenApi failingApi;
    failingApi.failAt = 4;
    Status failure = configureChannels(failingApi, 1);
    CHECK(!failure.ok());
    CHECK(failingApi.calls.size() == 5);
}

void testWireIdAllocationAndParity() {
    LocalUnreliableIdAllocator clientIds(0);
    CHECK(clientIds.allocate().value == -2);
    CHECK(clientIds.allocate().value == -4);
    CHECK(clientIds.allocate().value == -6);
    CHECK(clientIds.allocations() == 3);

    LocalUnreliableIdAllocator serverIds(1);
    CHECK(serverIds.allocate().value == -3);
    CHECK(serverIds.allocate().value == -5);

    CHECK(isValidPeerInternalId(-3, 0));
    CHECK(!isValidPeerInternalId(-2, 0));
    CHECK(!isValidPeerInternalId(2, 0));
    CHECK(!isValidPeerInternalId(0, 0));
    CHECK(!isValidPeerInternalId(std::numeric_limits<std::int32_t>::min(), 0));

    ValueResult<std::int32_t> peerOdd = decodePeerWireId(3, 0);
    CHECK(peerOdd.ok() && peerOdd.value == -3);
    ValueResult<std::int32_t> peerWrongParity = decodePeerWireId(2, 0);
    CHECK(!peerWrongParity.ok());
    ValueResult<std::int32_t> peerEven = decodePeerWireId(2, 1);
    CHECK(peerEven.ok() && peerEven.value == -2);
    CHECK(!decodePeerWireId(0, 0).ok());
}

void testControlSerializers() {
    const auto reliable = serializeReliableOpenRecord(0x07, 0x0000000b);
    const std::array<std::uint8_t, kReliableOpenRecordSize> expectedReliable{{
        0x06, 0x01, 0x07, 0x00, 0x00, 0x00, 0x0b
    }};
    CHECK(reliable == expectedReliable);

    ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>> unreliable =
        serializeUnreliableOpenControl(0x02, 3, -2);
    const std::array<std::uint8_t, kUnreliableOpenBodySize> expectedUnreliable{{
        0x02, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x02
    }};
    CHECK(unreliable.ok());
    CHECK(unreliable.value == expectedUnreliable);

    ValueResult<DecodedUnreliableOpenControl> decoded =
        parseUnreliableOpenControl(unreliable.value.data(), unreliable.value.size());
    CHECK(decoded.ok());
    CHECK(decoded.value.application == 0x02);
    CHECK(decoded.value.channelIndex == 3);
    CHECK(decoded.value.internalId == -2);

    CHECK(!serializeUnreliableOpenControl(0, 3, 2).ok());
    CHECK(!parseUnreliableOpenControl(nullptr, 0).ok());
    std::array<std::uint8_t, kUnreliableOpenBodySize> wrongType = expectedUnreliable;
    wrongType[0] = kReliableOpenType;
    CHECK(!parseUnreliableOpenControl(wrongType.data(), wrongType.size()).ok());
}

void testJoinDataChunkEnvelope() {
    // These opaque vectors exercise only envelope ordering; they are not Zstd fixtures.
    JoinDataChunkEnvelope primary;
    primary.kind = JoinDataChunkKind::Kind1;
    primary.uncompressedSize = 0x11223344;
    primary.compressedBytes = {0xaa, 0xbb, 0xcc};
    const std::vector<std::uint8_t> expectedPrimary{
        0x83, 0x16, 0x01,
        0x03, 0x00, 0x00, 0x00,
        0x44, 0x33, 0x22, 0x11,
        0xaa, 0xbb, 0xcc
    };
    auto primaryBytes = serializeJoinDataChunkEnvelope(primary);
    CHECK(primaryBytes.ok());
    CHECK(primaryBytes.value == expectedPrimary);
    auto parsedPrimary = parseJoinDataChunkEnvelope(primaryBytes.value.data(),
                                                    primaryBytes.value.size());
    CHECK(parsedPrimary.ok());
    CHECK(parsedPrimary.value.kind == JoinDataChunkKind::Kind1);
    CHECK(parsedPrimary.value.uncompressedSize == 0x11223344);
    CHECK(parsedPrimary.value.compressedBytes == primary.compressedBytes);
    CHECK(!parsedPrimary.value.appendOptionalZero);

    JoinDataChunkEnvelope secondary;
    secondary.kind = JoinDataChunkKind::Kind5;
    secondary.uncompressedSize = 8;
    secondary.compressedBytes = {0xfe, 0x22};
    secondary.appendOptionalZero = true;
    const std::vector<std::uint8_t> expectedSecondary{
        0x83, 0x16, 0x05,
        0x02, 0x00, 0x00, 0x00,
        0x08, 0x00, 0x00, 0x00,
        0xfe, 0x22, 0x00
    };
    auto secondaryBytes = serializeJoinDataChunkEnvelope(secondary);
    CHECK(secondaryBytes.ok());
    CHECK(secondaryBytes.value == expectedSecondary);
    auto parsedSecondary = parseJoinDataChunkEnvelope(secondaryBytes.value.data(),
                                                      secondaryBytes.value.size());
    CHECK(parsedSecondary.ok());
    CHECK(parsedSecondary.value.kind == JoinDataChunkKind::Kind5);
    CHECK(parsedSecondary.value.uncompressedSize == 8);
    CHECK(parsedSecondary.value.compressedBytes == secondary.compressedBytes);
    CHECK(parsedSecondary.value.appendOptionalZero);

    JoinDataChunkEnvelope unsupported;
    unsupported.kind = JoinDataChunkKind::Kind2;
    CHECK(!serializeJoinDataChunkEnvelope(unsupported).ok());
    CHECK(!parseJoinDataChunkEnvelope(nullptr, 0).ok());
    CHECK(!parseJoinDataChunkEnvelope(expectedPrimary.data(), 10).ok());

    std::vector<std::uint8_t> badTail = expectedPrimary;
    badTail.push_back(0x7f);
    CHECK(!parseJoinDataChunkEnvelope(badTail.data(), badTail.size()).ok());
    std::vector<std::uint8_t> shortPayload = expectedPrimary;
    shortPayload[3] = 0xff;
    CHECK(!parseJoinDataChunkEnvelope(shortPayload.data(), shortPayload.size()).ok());

    FakeJoinDataDecoder decoder;
    JoinDataChunkEnvelope decodable;
    decodable.kind = JoinDataChunkKind::Kind1;
    decodable.uncompressedSize = 3;
    decodable.compressedBytes = {1, 2, 3};
    auto decoded = decompressJoinDataChunk(decodable, decoder);
    CHECK(decoded.ok() && decoded.value == decodable.compressedBytes);
    decodable.uncompressedSize = 4;
    CHECK(!decompressJoinDataChunk(decodable, decoder).ok());
    decodable.kind = JoinDataChunkKind::Kind3;
    CHECK(!decompressJoinDataChunk(decodable, decoder).ok());
}

void testJoinReplicationMessageRouting() {
    const std::vector<std::uint8_t> startBody{0x12, 0x34, 0x00, 0xff};
    auto startBytes = serializeJoinStartMessage(startBody);
    CHECK(startBytes.ok());
    CHECK(startBytes.value.front() == kJoinStartMessageTag);
    auto parsedStart = parseJoinReplicationMessage(startBytes.value.data(), startBytes.value.size());
    CHECK(parsedStart.ok());
    CHECK(parsedStart.value.type == JoinReplicationMessageType::JoinStart);
    CHECK(parsedStart.value.body == startBody);
    CHECK(parsedStart.value.rawBytes == startBytes.value);

    // The target observes five 0x83/0x16 kind values. Kinds 2, 3, and 4 are preserved
    // as opaque payloads; their internal layout is not guessed by this parser.
    for (JoinDataChunkKind kind : {JoinDataChunkKind::Kind2,
                                   JoinDataChunkKind::Kind3,
                                   JoinDataChunkKind::Kind4}) {
        const std::vector<std::uint8_t> opaque{0xa1, 0x00, 0x05, 0x00};
        auto encoded = serializeJoinDataItemOpaque(kind, opaque);
        CHECK(encoded.ok());
        auto parsed = parseJoinReplicationMessage(encoded.value.data(), encoded.value.size());
        CHECK(parsed.ok());
        CHECK(parsed.value.type == JoinReplicationMessageType::JoinDataItem);
        CHECK(parsed.value.dataItem.has_value());
        CHECK(parsed.value.dataItem->kind == kind);
        CHECK(parsed.value.dataItem->opaquePayload == opaque);
        CHECK(!parsed.value.dataItem->compressedEnvelope.has_value());
    }

    JoinDataChunkEnvelope compressed;
    compressed.kind = JoinDataChunkKind::Kind5;
    compressed.uncompressedSize = 2;
    compressed.compressedBytes = {0x7a, 0x00};
    auto compressedBytes = serializeJoinDataChunkEnvelope(compressed);
    CHECK(compressedBytes.ok());
    auto parsedCompressed = parseJoinReplicationMessage(compressedBytes.value.data(),
                                                        compressedBytes.value.size());
    CHECK(parsedCompressed.ok());
    CHECK(parsedCompressed.value.dataItem.has_value());
    CHECK(parsedCompressed.value.dataItem->compressedEnvelope.has_value());
    CHECK(parsedCompressed.value.dataItem->compressedEnvelope->compressedBytes ==
          compressed.compressedBytes);

    // Keep the earlier, user-designated 0x80 Mrd path distinct from JoinDataItemV2.
    const std::vector<std::uint8_t> mrdLike{0x80, 0x01, 0x02};
    auto parsedMrdLike = parseJoinReplicationMessage(mrdLike.data(), mrdLike.size());
    CHECK(parsedMrdLike.ok());
    CHECK(parsedMrdLike.value.type == JoinReplicationMessageType::Other);

    FakeJoinSink sink;
    auto startDispatch = dispatchJoinReplicationMessage(startBytes.value.data(),
                                                        startBytes.value.size(), sink);
    CHECK(startDispatch.ok());
    CHECK(startDispatch.value == JoinReplicationDispatchResult::Handled);
    CHECK(sink.joinStartBody == startBody);
    auto itemDispatch = dispatchJoinReplicationMessage(compressedBytes.value.data(),
                                                        compressedBytes.value.size(), sink);
    CHECK(itemDispatch.ok());
    CHECK(itemDispatch.value == JoinReplicationDispatchResult::Handled);
    CHECK(sink.items.size() == 1);
    CHECK(sink.items[0].kind == JoinDataChunkKind::Kind5);
    auto otherDispatch = dispatchJoinReplicationMessage(mrdLike.data(), mrdLike.size(), sink);
    CHECK(otherDispatch.ok());
    CHECK(otherDispatch.value == JoinReplicationDispatchResult::NotHandled);
}


void testPerChannelStateAndDispatchBranch() {
    ChannelControlState state(0);
    ValueResult<std::int32_t> channel3 = state.onUnreliableOpenCallback(3);
    ValueResult<std::int32_t> channel5 = state.onUnreliableOpenCallback(5);
    CHECK(channel3.ok() && channel3.value == -2);
    CHECK(channel5.ok() && channel5.value == -4);
    CHECK(!state.onUnreliableOpenCallback(3).ok());

    ValueResult<std::array<std::uint8_t, kUnreliableOpenBodySize>> body =
        state.makeUnreliableOpenControl(1, 3);
    CHECK(body.ok());
    CHECK(body.value[0] == kUnreliableOpenType);
    CHECK(body.value[1] == 1);
    CHECK(body.value[5] == 3);
    CHECK(body.value[9] == 2);
    CHECK(!state.makeUnreliableOpenControl(1, 6).ok());
    CHECK(!state.onUnreliableOpenCallback(14).ok());

    FakeExecutor executor;
    int calls = 0;
    CallbackDispatchPath direct = dispatchCallback(7, 7, executor, [&calls] { ++calls; });
    CHECK(direct == CallbackDispatchPath::InvokedInline);
    CHECK(calls == 1);
    CHECK(executor.pending.empty());

    CallbackDispatchPath posted = dispatchCallback(8, 7, executor, [&calls] { ++calls; });
    CHECK(posted == CallbackDispatchPath::Submitted);
    CHECK(calls == 1);
    CHECK(executor.pending.size() == 1);
    executor.runOne();
    CHECK(calls == 2);
    CHECK(dispatchCallback(7, 7, executor, {}) == CallbackDispatchPath::NoCallback);
}

} // namespace

int main() {
    testDefaultProfileAndSetupLoop();
    testWireIdAllocationAndParity();
    testControlSerializers();
    testJoinDataChunkEnvelope();
    testJoinReplicationMessageRouting();
    testPerChannelStateAndDispatchBranch();
    std::cout << "channel protocol reconstruction tests passed\n";
    return 0;
}
