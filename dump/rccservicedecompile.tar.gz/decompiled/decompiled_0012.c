/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 3000 ; VA 0x0055ddc5 ; Catch_All@0055ddc5 */

undefined * Catch_All_0055ddc5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055ddd6;
}



/* FUNCTION 3001 ; VA 0x0055ddf0 ; FUN_0055ddf0 */

void FUN_0055ddf0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_48 [52];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792aa0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562600(auStack_48,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_48,&DAT_01c1ea00);
}



/* FUNCTION 3002 ; VA 0x0055de35 ; Catch_All@0055de35 */

undefined * Catch_All_0055de35(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055de46;
}



/* FUNCTION 3003 ; VA 0x0055de60 ; FUN_0055de60 */

void FUN_0055de60(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792ab0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc8;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005626b0(auStack_2c,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c1e9a4);
}



/* FUNCTION 3004 ; VA 0x0055dea5 ; Catch_All@0055dea5 */

undefined * Catch_All_0055dea5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055deb6;
}



/* FUNCTION 3005 ; VA 0x0055ded0 ; FUN_0055ded0 */

void FUN_0055ded0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792ac0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562710(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1e5cc);
}



/* FUNCTION 3006 ; VA 0x0055df15 ; Catch_All@0055df15 */

undefined * Catch_All_0055df15(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055df26;
}



/* FUNCTION 3007 ; VA 0x0055df40 ; FUN_0055df40 */

undefined4 * FUN_0055df40(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792b03;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00938790();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xd8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00938fe0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055bb50(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3008 ; VA 0x0055e000 ; FUN_0055e000 */

int FUN_0055e000(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792b18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8ac8,&LAB_0055d550);
  uVar2 = FUN_00560b40();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00938890();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0055df40(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8ac8,&LAB_0055d550);
      uVar2 = FUN_00560b40();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3009 ; VA 0x0055e190 ; FUN_0055e190 */

undefined4 * FUN_0055e190(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792b63;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00937b90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xac);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00937c70();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055bc40(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3010 ; VA 0x0055e250 ; FUN_0055e250 */

undefined4 * FUN_0055e250(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792ba3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0093aca0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xa8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_0093adc0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055bd30(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3011 ; VA 0x0055e310 ; FUN_0055e310 */

int FUN_0055e310(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792bb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8ad0,&LAB_0055d560);
  uVar2 = FUN_00560bc0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_0093ada0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0055e250(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8ad0,&LAB_0055d560);
      uVar2 = FUN_00560bc0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3012 ; VA 0x0055e4a0 ; FUN_0055e4a0 */

undefined4 * FUN_0055e4a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792c03;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00961580();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x340);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_0096b750();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055be20(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3013 ; VA 0x0055e560 ; FUN_0055e560 */

int FUN_0055e560(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792c18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
  uVar2 = FUN_00560c40();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00961660();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0055e4a0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
      uVar2 = FUN_00560c40();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3014 ; VA 0x0055e6f0 ; FUN_0055e6f0 */

undefined4 * FUN_0055e6f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792c60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00558f80();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x60);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_005cae70();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055bf10(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3015 ; VA 0x0055e7b0 ; FUN_0055e7b0 */

int FUN_0055e7b0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792c78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8a88,&LAB_0055d580);
  uVar2 = FUN_00560cc0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar4 = *piVar3;
  if (*piVar3 == 0) {
    if (DAT_01ea8964 == 0) {
      iVar4 = FUN_00558f80();
      DAT_01ea8964 = *(int *)(iVar4 + 4);
    }
    piVar5 = (int *)FUN_008a9ba0(auStack_24,DAT_01ea8964);
    iVar4 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar3 = iVar4;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar4 = piStack_20[2] + -1;
        piStack_20[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar4 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0055e6f0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8a88,&LAB_0055d580);
      uVar2 = FUN_00560cc0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar5 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      iVar4 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 3016 ; VA 0x0055e950 ; FUN_0055e950 */

undefined4 * FUN_0055e950(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792cc3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0093f0f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(1000);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009459a0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055c000(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3017 ; VA 0x0055ea10 ; FUN_0055ea10 */

int FUN_0055ea10(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792cd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
  uVar2 = FUN_00560dc0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_0093f210();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0055e950(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
      uVar2 = FUN_00560dc0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3018 ; VA 0x0055eba0 ; FUN_0055eba0 */

undefined4 * FUN_0055eba0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792d20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00911380();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00911960();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055c0f0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3019 ; VA 0x0055ec60 ; FUN_0055ec60 */

undefined4 * FUN_0055ec60(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792d60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00559080();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_005c4680();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055c1e0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3020 ; VA 0x0055ed20 ; FUN_0055ed20 */

int FUN_0055ed20(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792d78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8a78,&LAB_0055d5c0);
  uVar2 = FUN_00560ec0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar4 = *piVar3;
  if (*piVar3 == 0) {
    if (DAT_01ea8744 == 0) {
      iVar4 = FUN_00559080();
      DAT_01ea8744 = *(int *)(iVar4 + 4);
    }
    piVar5 = (int *)FUN_008a9ba0(auStack_24,DAT_01ea8744);
    iVar4 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar3 = iVar4;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar4 = piStack_20[2] + -1;
        piStack_20[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar4 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0055ec60(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8a78,&LAB_0055d5c0);
      uVar2 = FUN_00560ec0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar5 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      iVar4 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 3021 ; VA 0x0055eec0 ; FUN_0055eec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055eec0(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792dd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::bad_alloc::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055d760(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::bad_alloc::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055d760(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3022 ; VA 0x0055f0b0 ; FUN_0055f0b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055f0b0(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792e20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::bad_cast::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_cast>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_cast>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055d7d0(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_cast>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::bad_cast::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_cast>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_cast>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055d7d0(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_cast>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3023 ; VA 0x0055f2a0 ; FUN_0055f2a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055f2a0(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792e70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::bad_exception::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055d840(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::bad_exception::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055d840(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3024 ; VA 0x0055f490 ; FUN_0055f490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055f490(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792ec0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::bad_typeid::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055d8b0(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::bad_typeid::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055d8b0(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3025 ; VA 0x0055f680 ; FUN_0055f680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055f680(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792f10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::domain_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055d920(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::domain_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055d920(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3026 ; VA 0x0055f870 ; FUN_0055f870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055f870(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_68;
  undefined8 uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined **ppuStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined **ppuStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792f60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::ios_base::failure::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_68 = std::exception::vftable;
    uStack_64 = 0;
    FUN_0170c226(param_2 + 4,&uStack_64);
    uStack_5c = *(undefined4 *)(param_2 + 0xc);
    uStack_58 = *(undefined4 *)(param_2 + 0x10);
    piStack_50 = (int *)PTR_018bd540;
    uStack_4c = _UNK_018bd544;
    uStack_48 = _UNK_018bd548;
    uStack_44 = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_68 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
    ppuStack_54 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_005644b0(&ppuStack_68,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055d990(param_1,&ppuStack_68);
    ppuStack_68 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
    ppuStack_54 = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_50 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_50 + 0x10))(), cVar1 != '\0'))
    {
      piStack_50 = (int *)0x0;
    }
    ppuStack_68 = std::exception::vftable;
    puVar3 = &uStack_64;
  }
  else {
    ppuStack_40 = std::exception::vftable;
    uStack_3c = 0;
    FUN_0170c226(param_2 + 4,&uStack_3c);
    uStack_34 = *(undefined4 *)(param_2 + 0xc);
    uStack_30 = *(undefined4 *)(param_2 + 0x10);
    ppuStack_40 = std::ios_base::failure::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_40 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_005644b0(&ppuStack_40,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055d990(param_1,&ppuStack_40);
    ppuStack_40 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_40 = std::exception::vftable;
    puVar3 = &uStack_3c;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3027 ; VA 0x0055fa80 ; FUN_0055fa80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055fa80(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792fb0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::invalid_argument::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055da00(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::invalid_argument::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055da00(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3028 ; VA 0x0055fc70 ; FUN_0055fc70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055fc70(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793000;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::length_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::length_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::length_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055da70(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::length_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::length_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::length_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::length_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055da70(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::length_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3029 ; VA 0x0055fe70 ; FUN_0055fe70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0055fe70(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::logic_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055dae0(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::logic_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055dae0(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3030 ; VA 0x00560060 ; FUN_00560060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00560060(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017930a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::out_of_range::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055db50(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::out_of_range::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055db50(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3031 ; VA 0x00560250 ; FUN_00560250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00560250(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017930f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::overflow_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055dbc0(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::overflow_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055dbc0(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3032 ; VA 0x00560440 ; FUN_00560440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00560440(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793140;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::range_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::range_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::range_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055dc30(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::range_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::range_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::range_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::range_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055dc30(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::range_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3033 ; VA 0x00560630 ; FUN_00560630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00560630(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793190;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::runtime_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055dca0(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::runtime_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055dca0(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3034 ; VA 0x00560820 ; FUN_00560820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00560820(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined **ppuStack_58;
  undefined8 uStack_54;
  undefined **ppuStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined8 uStack_34;
  undefined **ppuStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017931e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_2,0,&std::underflow_error::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ppuStack_58 = std::exception::vftable;
    uStack_54 = 0;
    FUN_0170c226(param_2 + 4,&uStack_54);
    piStack_48 = (int *)PTR_018bd540;
    uStack_44 = _UNK_018bd544;
    uStack_40 = _UNK_018bd548;
    uStack_3c = _UNK_018bd54c;
    uStack_8._0_1_ = 6;
    uStack_8._1_3_ = 0;
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
    ppuStack_4c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00564340(&ppuStack_58,&ppuStack_18);
    uStack_8 = 8;
    FUN_0055dd10(param_1,&ppuStack_58);
    ppuStack_58 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
    ppuStack_4c = boost::exception::vftable;
    uStack_8 = 9;
    if ((piStack_48 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_48 + 0x10))(), cVar1 != '\0'))
    {
      piStack_48 = (int *)0x0;
    }
    ppuStack_58 = std::exception::vftable;
    puVar3 = &uStack_54;
  }
  else {
    ppuStack_38 = std::exception::vftable;
    uStack_34 = 0;
    FUN_0170c226(param_2 + 4,&uStack_34);
    ppuStack_38 = std::underflow_error::vftable;
    piStack_28 = *(int **)(iVar2 + 4);
    uStack_8 = 0;
    ppuStack_2c = boost::exception::vftable;
    if (piStack_28 != (int *)0x0) {
      (**(code **)(*piStack_28 + 0xc))();
    }
    uStack_24 = *(undefined4 *)(iVar2 + 8);
    uStack_20 = *(undefined4 *)(iVar2 + 0xc);
    uStack_1c = *(undefined4 *)(iVar2 + 0x10);
    uStack_8._0_1_ = 1;
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
    ppuStack_2c = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
    uStack_14 = FUN_0170d850(param_2);
    ppuStack_18 = boost::
                  error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
                  vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00564340(&ppuStack_38,&ppuStack_18);
    uStack_8 = 3;
    FUN_0055dd10(param_1,&ppuStack_38);
    ppuStack_38 = boost::exception_detail::
                  current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
    ppuStack_2c = boost::exception::vftable;
    uStack_8 = 4;
    if ((piStack_28 != (int *)0x0) && (cVar1 = (**(code **)(*piStack_28 + 0x10))(), cVar1 != '\0'))
    {
      piStack_28 = (int *)0x0;
    }
    ppuStack_38 = std::exception::vftable;
    puVar3 = &uStack_34;
  }
  FUN_0170c289(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3035 ; VA 0x00560a10 ; FUN_00560a10 */

void FUN_00560a10(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_2[0xb];
  if (0xf < uVar1) {
    iVar2 = param_2[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00560a9c;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[10] = 0;
  param_2[0xb] = 0xf;
  *(undefined *)(param_2 + 6) = 0;
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00560a9c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 3036 ; VA 0x00560ab0 ; FUN_00560ab0 */

void FUN_00560ab0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2[7] != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_2[7] + 8))(param_2 + 8);
  }
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3037 ; VA 0x00560b40 ; FUN_00560b40 */

undefined4 FUN_00560b40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017931fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8aec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8aec);
    if (DAT_01ea8aec == -1) {
      uStack_8 = 0;
      DAT_01ea8ae8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8aec);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8ae8;
}



/* FUNCTION 3038 ; VA 0x00560bc0 ; FUN_00560bc0 */

undefined4 FUN_00560bc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179321c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8af4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8af4);
    if (DAT_01ea8af4 == -1) {
      uStack_8 = 0;
      DAT_01ea8af0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8af4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8af0;
}



/* FUNCTION 3039 ; VA 0x00560c40 ; FUN_00560c40 */

undefined4 FUN_00560c40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179323c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8aa4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8aa4);
    if (DAT_01ea8aa4 == -1) {
      uStack_8 = 0;
      DAT_01ea8aa0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8aa4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8aa0;
}



/* FUNCTION 3040 ; VA 0x00560cc0 ; FUN_00560cc0 */

undefined4 FUN_00560cc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179325c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8ac4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8ac4);
    if (DAT_01ea8ac4 == -1) {
      uStack_8 = 0;
      DAT_01ea8ac0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8ac4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8ac0;
}



/* FUNCTION 3041 ; VA 0x00560d40 ; FUN_00560d40 */

undefined4 FUN_00560d40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179327c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8b0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8b0c);
    if (DAT_01ea8b0c == -1) {
      uStack_8 = 0;
      DAT_01ea8b08 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8b0c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8b08;
}



/* FUNCTION 3042 ; VA 0x00560dc0 ; FUN_00560dc0 */

undefined4 FUN_00560dc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179329c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8abc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8abc);
    if (DAT_01ea8abc == -1) {
      uStack_8 = 0;
      DAT_01ea8ab8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8abc);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8ab8;
}



/* FUNCTION 3043 ; VA 0x00560e40 ; FUN_00560e40 */

undefined4 FUN_00560e40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017932bc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8ae4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8ae4);
    if (DAT_01ea8ae4 == -1) {
      uStack_8 = 0;
      DAT_01ea8ae0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8ae4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8ae0;
}



/* FUNCTION 3044 ; VA 0x00560ec0 ; FUN_00560ec0 */

undefined4 FUN_00560ec0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017932dc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8ab4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8ab4);
    if (DAT_01ea8ab4 == -1) {
      uStack_8 = 0;
      DAT_01ea8ab0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8ab4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8ab0;
}



/* FUNCTION 3045 ; VA 0x00560f40 ; FUN_00560f40 */

undefined4 FUN_00560f40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017932fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8b04) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8b04);
    if (DAT_01ea8b04 == -1) {
      uStack_8 = 0;
      DAT_01ea8b00 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8b04);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8b00;
}



/* FUNCTION 3046 ; VA 0x00560fc0 ; FUN_00560fc0 */

undefined FUN_00560fc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int *piStack_18;
  bool bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00581d10(&piStack_18);
  puVar1 = (undefined4 *)*piVar3;
  if (puVar1 != (undefined4 *)0x0) {
    LOCK();
    puVar1[4] = puVar1[4] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_18[4] + -1;
    piStack_18[4] = iVar4;
    UNLOCK();
    if ((iVar4 == 0) && (piStack_18 != (int *)0x0)) {
      iVar4 = piStack_18[1];
      if ((iVar4 != 0) && (iVar4 != -1)) {
        CloseHandle(iVar4);
      }
      iVar4 = *piStack_18;
      if ((iVar4 != 0) && (iVar4 != -1)) {
        CloseHandle(iVar4);
      }
      FUN_01674ea0(piStack_18,0x14);
    }
  }
  FUN_0058c660();
  do {
    cVar2 = FUN_01689e80(*puVar1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
    if (cVar2 == '\0') {
      bStack_11 = false;
      break;
    }
    iVar4 = WaitForSingleObjectEx(puVar1[1],0,0);
    bStack_11 = iVar4 == 0;
  } while (iVar4 != 0);
  FUN_0056e770();
  uStack_8 = 3;
  FUN_00587410();
  ExceptionList = pvStack_10;
  return bStack_11;
}



/* FUNCTION 3047 ; VA 0x005610e0 ; FUN_005610e0 */

undefined4 * FUN_005610e0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179335c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c047c;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_month::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3048 ; VA 0x005611c0 ; FUN_005611c0 */

undefined4 * FUN_005611c0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179339c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c08a0;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_month::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3049 ; VA 0x005612a0 ; FUN_005612a0 */

undefined4 * FUN_005612a0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017933dc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c08e0;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_year::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3050 ; VA 0x00561380 ; FUN_00561380 */

undefined4 * FUN_00561380(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179341c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0600;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>::
            vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3051 ; VA 0x00561460 ; FUN_00561460 */

undefined4 * FUN_00561460(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179345c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018c06e4;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_already_retrieved::vftable;
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3052 ; VA 0x00561560 ; FUN_00561560 */

undefined4 * FUN_00561560(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179349c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018c0860;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_uninitialized::vftable;
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3053 ; VA 0x00561660 ; FUN_00561660 */

undefined4 * FUN_00561660(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017934d4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0x10] = &DAT_018c0724;
  param_1[0x12] = boost::exception_detail::clone_base::vftable;
  uStack_8 = 0;
  FUN_005680e0(param_2);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
             ::vftable;
  param_1[0xb] = boost::exception_detail::
                 clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
                 ::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[0x10] + 4) + 0x40 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>::
       vftable;
  *(int *)(*(int *)(param_1[0x10] + 4) + 0x3c + (int)param_1) = *(int *)(param_1[0x10] + 4) + -8;
  FUN_00554960(param_1 + 0xb,-(uint)(param_2 != 0) & param_2 + 0x2cU);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3054 ; VA 0x00561710 ; FUN_00561710 */

undefined4 * FUN_00561710(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179350c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018c0640;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_already_satisfied::vftable;
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3055 ; VA 0x00561810 ; FUN_00561810 */

undefined4 * FUN_00561810(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179354c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018c06a4;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_moved::vftable;
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3056 ; VA 0x00561910 ; FUN_00561910 */

undefined4 * FUN_00561910(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179358c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0ac4;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3057 ; VA 0x005619f0 ; FUN_005619f0 */

undefined4 * FUN_005619f0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017935cc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0af0;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_cast::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3058 ; VA 0x00561ad0 ; FUN_00561ad0 */

undefined4 * FUN_00561ad0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179360c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0b48;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_exception::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3059 ; VA 0x00561bb0 ; FUN_00561bb0 */

undefined4 * FUN_00561bb0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179364c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0b1c;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_typeid::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3060 ; VA 0x00561c90 ; FUN_00561c90 */

undefined4 * FUN_00561c90(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179368c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c090c;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::domain_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3061 ; VA 0x00561d70 ; FUN_00561d70 */

undefined4 * FUN_00561d70(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017936cc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018c0a6c;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3062 ; VA 0x00561e70 ; FUN_00561e70 */

undefined4 * FUN_00561e70(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179370c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0938;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3063 ; VA 0x00561f70 ; FUN_00561f70 */

undefined4 * FUN_00561f70(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179374c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0964;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::length_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3064 ; VA 0x00562050 ; FUN_00562050 */

undefined4 * FUN_00562050(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179378c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c09bc;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3065 ; VA 0x00562130 ; FUN_00562130 */

undefined4 * FUN_00562130(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017937cc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0990;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3066 ; VA 0x00562210 ; FUN_00562210 */

undefined4 * FUN_00562210(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179380c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0a14;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::overflow_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3067 ; VA 0x005622f0 ; FUN_005622f0 */

undefined4 * FUN_005622f0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179384c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c09e8;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::range_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3068 ; VA 0x005623d0 ; FUN_005623d0 */

undefined4 * FUN_005623d0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179388c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0a98;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3069 ; VA 0x005624b0 ; FUN_005624b0 */

undefined4 * FUN_005624b0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017938cc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c0a40;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::underflow_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3070 ; VA 0x00562590 ; FUN_00562590 */

undefined4 * FUN_00562590(undefined4 *param_1,int param_2)

{
  param_1[5] = &DAT_018c0664;
  param_1[7] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(undefined ***)(*(int *)(param_1[5] + 4) + 0x14 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(int *)(*(int *)(param_1[5] + 4) + 0x10 + (int)param_1) = *(int *)(param_1[5] + 4) + -8;
  return param_1;
}



/* FUNCTION 3071 ; VA 0x00562600 ; FUN_00562600 */

undefined4 * FUN_00562600(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793904;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018c07d0;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  uStack_8 = 1;
  *param_1 = RBX::http_status_error::vftable;
  FUN_0054ef60(param_2 + 0xc);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3072 ; VA 0x005626b0 ; FUN_005626b0 */

undefined4 * FUN_005626b0(undefined4 *param_1,int param_2)

{
  param_1[3] = &DAT_018c07ac;
  param_1[5] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(undefined ***)(*(int *)(param_1[3] + 4) + 0xc + (int)param_1) =
       boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(int *)(*(int *)(param_1[3] + 4) + 8 + (int)param_1) = *(int *)(param_1[3] + 4) + -8;
  return param_1;
}



/* FUNCTION 3073 ; VA 0x00562710 ; FUN_00562710 */

undefined4 * FUN_00562710(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793934;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c04a8;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  uStack_8 = 0;
  FUN_0056b5e0(param_2);
  *param_1 = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  param_1[5] = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(param_1,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3074 ; VA 0x005627b0 ; FUN_005627b0 */

undefined4 * FUN_005627b0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>
             ::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::gregorian::bad_day_of_month>::vftable;
  return param_1;
}



/* FUNCTION 3075 ; VA 0x00562810 ; FUN_00562810 */

undefined4 * FUN_00562810(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
               vftable;
  return param_1;
}



/* FUNCTION 3076 ; VA 0x00562870 ; FUN_00562870 */

undefined4 * FUN_00562870(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
               vftable;
  return param_1;
}



/* FUNCTION 3077 ; VA 0x005628d0 ; FUN_005628d0 */

undefined4 * FUN_005628d0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  return param_1;
}



/* FUNCTION 3078 ; VA 0x00562930 ; FUN_00562930 */

undefined4 * FUN_00562930(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
             vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
               vftable;
  return param_1;
}



/* FUNCTION 3079 ; VA 0x005629a0 ; FUN_005629a0 */

undefined4 * FUN_005629a0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
             vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
               vftable;
  return param_1;
}



/* FUNCTION 3080 ; VA 0x00562a10 ; FUN_00562a10 */

undefined4 * FUN_00562a10(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791b48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  param_1[0xb] = boost::exception::vftable;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  param_1[0xb] = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3081 ; VA 0x00562ac0 ; FUN_00562ac0 */

undefined4 * FUN_00562ac0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>::
             vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>
               ::vftable;
  return param_1;
}



/* FUNCTION 3082 ; VA 0x00562b30 ; FUN_00562b30 */

undefined4 * FUN_00562b30(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  return param_1;
}



/* FUNCTION 3083 ; VA 0x00562ba0 ; FUN_00562ba0 */

int * FUN_00562ba0(int *param_1)

{
  int *piVar1;
  undefined uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  piVar3 = (int *)FUN_0054e7d0(auStack_18);
  uVar2 = (**(code **)(*piVar3 + 0x20))(10);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar4 != (undefined4 *)0x0) {
      (**(code **)*puVar4)(1);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00589420(uVar2);
  FUN_00581480();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3084 ; VA 0x00562c50 ; FUN_00562c50 */

int FUN_00562c50(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005ee170();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 3085 ; VA 0x00562c90 ; FUN_00562c90 */

int * FUN_00562c90(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00913630(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 3086 ; VA 0x00562d80 ; FUN_00562d80 */

int FUN_00562d80(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
  uVar3 = FUN_00560d40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00995770();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 3087 ; VA 0x00562e40 ; FUN_00562e40 */

int FUN_00562e40(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
  uVar3 = FUN_00560e40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_005ee510();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 3088 ; VA 0x00562f00 ; FUN_00562f00 */

int FUN_00562f00(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
  uVar3 = FUN_00560f40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_008aa950();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 3089 ; VA 0x00562fc0 ; FUN_00562fc0 */

void __thiscall FUN_00562fc0(int param_1,undefined4 *param_2,uint param_3,undefined4 *param_4)

{
  uint uVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piVar6;
  
  uVar1 = *(uint *)(param_1 + 4);
  uVar5 = param_3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar4 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (puVar4 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar4;
    }
    if (piVar6 != (int *)0x0) {
      do {
        if (param_3 == piVar6[1]) {
          piVar3 = piVar6 + 2;
          if (0xf < (uint)piVar6[7]) {
            piVar3 = (int *)*piVar3;
          }
          puVar4 = param_4;
          if (0xf < (uint)param_4[5]) {
            puVar4 = (undefined4 *)*param_4;
          }
          cVar2 = FUN_0055c360(puVar4,param_4[4],piVar3,piVar6[6]);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar6[1] % uVar1 != uVar5) {
          *param_2 = 0;
          return;
        }
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar6;
  return;
}



/* FUNCTION 3090 ; VA 0x00563070 ; FUN_00563070 */

int __fastcall FUN_00563070(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088c8c0();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_00889220();
    iVar1 = *piVar3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return iVar1;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088c8c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    ExceptionList = pvStack_10;
    return *piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 3091 ; VA 0x00563150 ; FUN_00563150 */

undefined4 *
FUN_00563150(undefined4 *param_1,char *param_2,char *param_3,undefined4 param_4,int *param_5,
            uint *param_6)

{
  byte *pbVar1;
  char cVar2;
  byte bVar3;
  char *pcVar4;
  int iVar5;
  byte bVar6;
  int iVar7;
  byte bVar8;
  
  if (param_2 != param_3) {
    do {
      while (iVar5 = (int)*param_2, DAT_01d59298 == iVar5) {
        iVar5 = 0x3e;
LAB_00563221:
        param_2 = param_2 + 1;
        cVar2 = (char)iVar5;
        if (param_2 != param_3) {
          while( true ) {
            iVar5 = (int)*param_2;
            if (DAT_01d59298 == iVar5) {
              iVar5 = 0x3e;
              goto LAB_005632cc;
            }
            if (DAT_01d5929c == iVar5) break;
            if ((iVar5 < DAT_01d591a0) || (DAT_01d59204 < iVar5)) {
              if ((iVar5 < DAT_01d59208) || (DAT_01d5926c < iVar5)) {
                if ((iVar5 < DAT_01d59270) || (DAT_01d59294 < iVar5)) {
                  if (iVar5 == 0x3d) {
                    iVar5 = -1;
                    goto LAB_005632cc;
                  }
                  iVar5 = -2;
                }
                else {
                  iVar5 = (iVar5 - DAT_01d59270) + 0x34;
                }
              }
              else {
                iVar5 = (iVar5 - DAT_01d59208) + 0x1a;
              }
            }
            else {
              iVar5 = iVar5 - DAT_01d591a0;
            }
            if ((iVar5 != -2) || (param_2 = param_2 + 1, param_2 == param_3)) goto LAB_005632cc;
          }
          iVar5 = 0x3f;
        }
LAB_005632cc:
        if (param_2 == param_3) goto LAB_00563201;
        if (iVar5 == -1) {
LAB_005631dc:
          *param_6 = *param_6 | 2;
          *param_1 = param_2;
          return param_1;
        }
        pcVar4 = param_2 + 1;
        bVar6 = (byte)(iVar5 >> 4) & 3 | cVar2 << 2;
        if (pcVar4 == param_3) {
LAB_005635e5:
          *param_6 = *param_6 | 3;
          *param_1 = pcVar4;
          return param_1;
        }
        while( true ) {
          iVar7 = (int)*pcVar4;
          if (DAT_01d59298 == iVar7) {
            iVar7 = 0x3e;
            goto LAB_0056338f;
          }
          if (DAT_01d5929c == iVar7) break;
          if ((iVar7 < DAT_01d591a0) || (DAT_01d59204 < iVar7)) {
            if ((iVar7 < DAT_01d59208) || (DAT_01d5926c < iVar7)) {
              if ((iVar7 < DAT_01d59270) || (DAT_01d59294 < iVar7)) {
                if (iVar7 == 0x3d) {
                  iVar7 = -1;
                  goto LAB_0056338f;
                }
                iVar7 = -2;
              }
              else {
                iVar7 = (iVar7 - DAT_01d59270) + 0x34;
              }
            }
            else {
              iVar7 = (iVar7 - DAT_01d59208) + 0x1a;
            }
          }
          else {
            iVar7 = iVar7 - DAT_01d591a0;
          }
          if ((iVar7 != -2) || (pcVar4 = pcVar4 + 1, pcVar4 == param_3)) goto LAB_0056338f;
        }
        iVar7 = 0x3f;
LAB_0056338f:
        if (pcVar4 == param_3) goto LAB_005635e5;
        param_2 = pcVar4 + 1;
        if (iVar7 == -1) {
          if (param_2 == param_3) {
            *param_6 = *param_6 | 1;
          }
          else {
            iVar5 = FUN_00577c50((int)*param_2);
            if (iVar5 == -1) {
              param_2 = pcVar4 + 2;
            }
          }
          FUN_0056ec80(bVar6);
          *param_1 = param_2;
          return param_1;
        }
        bVar3 = (byte)(iVar7 >> 2) & 0xf | (char)iVar5 << 4;
        if (param_2 == param_3) {
LAB_00563594:
          *param_6 = *param_6 | 1;
          *param_1 = param_2;
          return param_1;
        }
        while( true ) {
          iVar5 = (int)*param_2;
          if (DAT_01d59298 == iVar5) {
            iVar5 = 0x3e;
            goto LAB_00563450;
          }
          if (DAT_01d5929c == iVar5) break;
          if ((iVar5 < DAT_01d591a0) || (DAT_01d59204 < iVar5)) {
            if ((iVar5 < DAT_01d59208) || (DAT_01d5926c < iVar5)) {
              if ((iVar5 < DAT_01d59270) || (DAT_01d59294 < iVar5)) {
                if (iVar5 == 0x3d) {
                  iVar5 = -1;
                  goto LAB_00563450;
                }
                iVar5 = -2;
              }
              else {
                iVar5 = (iVar5 - DAT_01d59270) + 0x34;
              }
            }
            else {
              iVar5 = (iVar5 - DAT_01d59208) + 0x1a;
            }
          }
          else {
            iVar5 = iVar5 - DAT_01d591a0;
          }
          if ((iVar5 != -2) || (param_2 = param_2 + 1, param_2 == param_3)) goto LAB_00563450;
        }
        iVar5 = 0x3f;
LAB_00563450:
        if (param_2 == param_3) goto LAB_00563594;
        if (iVar5 == -1) {
          FUN_0056ec80(bVar6);
          FUN_0056ec80(bVar3);
          *param_1 = param_2 + 1;
          return param_1;
        }
        bVar8 = (byte)iVar5 & 0x3f | (char)iVar7 << 6;
        if (param_5 != (int *)0x0) {
          if (*(int *)param_5[8] != 0) {
            iVar5 = *(int *)param_5[0xc];
            if (0 < iVar5) {
              *(int *)param_5[0xc] = iVar5 + -1;
              pbVar1 = *(byte **)param_5[8];
              *(byte **)param_5[8] = pbVar1 + 1;
              *pbVar1 = bVar6;
              goto LAB_005634b8;
            }
          }
          (**(code **)(*param_5 + 0xc))(bVar6);
        }
LAB_005634b8:
        if (param_5 != (int *)0x0) {
          if (*(int *)param_5[8] != 0) {
            iVar5 = *(int *)param_5[0xc];
            if (0 < iVar5) {
              *(int *)param_5[0xc] = iVar5 + -1;
              pbVar1 = *(byte **)param_5[8];
              *(byte **)param_5[8] = pbVar1 + 1;
              *pbVar1 = bVar3;
              goto LAB_00563507;
            }
          }
          (**(code **)(*param_5 + 0xc))(bVar3);
        }
LAB_00563507:
        if (param_5 != (int *)0x0) {
          if (*(int *)param_5[8] != 0) {
            iVar5 = *(int *)param_5[0xc];
            if (0 < iVar5) {
              *(int *)param_5[0xc] = iVar5 + -1;
              pbVar1 = *(byte **)param_5[8];
              *(byte **)param_5[8] = pbVar1 + 1;
              *pbVar1 = bVar8;
              goto LAB_00563550;
            }
          }
          (**(code **)(*param_5 + 0xc))(bVar8);
        }
LAB_00563550:
        param_2 = param_2 + 1;
        if (param_2 == param_3) {
          *param_1 = param_2;
          return param_1;
        }
      }
      if (DAT_01d5929c == iVar5) {
        iVar5 = 0x3f;
        goto LAB_00563221;
      }
      if ((iVar5 < DAT_01d591a0) || (DAT_01d59204 < iVar5)) {
        if ((DAT_01d59208 <= iVar5) && (iVar5 <= DAT_01d5926c)) {
          iVar5 = (iVar5 - DAT_01d59208) + 0x1a;
          goto LAB_005631ce;
        }
        if ((DAT_01d59270 <= iVar5) && (iVar5 <= DAT_01d59294)) {
          iVar5 = (iVar5 - DAT_01d59270) + 0x34;
          goto LAB_005631ce;
        }
        if (iVar5 == 0x3d) goto LAB_005631dc;
      }
      else {
        iVar5 = iVar5 - DAT_01d591a0;
LAB_005631ce:
        if ((-1 < iVar5) || (iVar5 != -2)) {
          if (iVar5 == -1) goto LAB_005631dc;
          goto LAB_00563221;
        }
      }
      param_2 = param_2 + 1;
    } while (param_2 != param_3);
LAB_00563201:
    *param_6 = *param_6 | 3;
  }
  *param_1 = param_2;
  return param_1;
}



/* FUNCTION 3092 ; VA 0x00563600 ; FUN_00563600 */

undefined4 FUN_00563600(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01681330(param_1,auStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3093 ; VA 0x00563690 ; FUN_00563690 */

undefined4 __thiscall FUN_00563690(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = FUN_008898b0();
    FUN_0054ef60(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 3094 ; VA 0x00563790 ; FUN_00563790 */

undefined8 __fastcall FUN_00563790(int *param_1)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  int *piVar6;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088da50();
  if (iVar1 != iVar3) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined8 *)FUN_0088baa0();
    uVar2 = *puVar5;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return uVar2;
  }
  iVar1 = *param_1;
  iVar3 = FUN_0088da50();
  if (iVar1 == iVar3) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    ExceptionList = pvStack_10;
    return *(undefined8 *)piVar6;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 3095 ; VA 0x00563880 ; FUN_00563880 */

undefined4 FUN_00563880(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  uVar1 = *param_3;
  FUN_00580040(&param_3,param_2);
  if ((param_3 != (undefined4 *)0x0) && (*(char *)(param_3[8] + 0x21) != '\0')) {
    uVar1 = FUN_00563790();
    return uVar1;
  }
  return uVar1;
}



/* FUNCTION 3096 ; VA 0x005638c0 ; FUN_005638c0 */

void FUN_005638c0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_14 [12];
  int iStack_8;
  
  FUN_00580040(&iStack_8,param_2);
  if ((iStack_8 != 0) && (*(char *)(*(int *)(iStack_8 + 0x20) + 0x21) != '\0')) {
    FUN_00563790();
    return;
  }
  uVar1 = FUN_005543f0();
  FUN_016756b0(auStack_14,"missing %s setting",uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_14,&DAT_01c17198);
}



/* FUNCTION 3097 ; VA 0x00563920 ; FUN_00563920 */

undefined4 FUN_00563920(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iStack_8;
  
  FUN_00580040(&iStack_8,param_2);
  if (iStack_8 != 0) {
    iVar2 = *(int *)(iStack_8 + 0x20);
    iVar3 = FUN_0088cb40();
    if (iVar2 == iVar3) {
      iVar2 = *(int *)(iStack_8 + 0x20);
      iVar3 = FUN_0088cb40();
      if (iVar2 == iVar3) {
        puVar4 = (undefined4 *)(iStack_8 + 0x28);
        if (*(int *)(iStack_8 + 0x24) == 0) {
          puVar4 = (undefined4 *)0x0;
        }
        if (param_3 != puVar4) {
          puVar1 = puVar4 + 4;
          if (0xf < (uint)puVar4[5]) {
            puVar4 = (undefined4 *)*puVar4;
          }
          FUN_005542c0(puVar4,*puVar1);
        }
        return 1;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  return 0;
}



/* FUNCTION 3098 ; VA 0x005639a0 ; FUN_005639a0 */

undefined4 FUN_005639a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  
  uVar5 = *param_3;
  FUN_00580040(&param_3,param_2);
  puVar2 = param_3;
  if ((param_3 != (undefined4 *)0x0) && (iVar1 = param_3[8], iVar3 = FUN_0088c8c0(), iVar1 == iVar3)
     ) {
    iVar1 = puVar2[8];
    iVar3 = FUN_0088c8c0();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar4 = puVar2 + 10;
    if (puVar2[9] == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    uVar5 = *puVar4;
  }
  return uVar5;
}



/* FUNCTION 3099 ; VA 0x00563a00 ; FUN_00563a00 */

undefined4 FUN_00563a00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_4);
  uStack_8 = 0;
  FUN_00563920(param_2,param_3,param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3100 ; VA 0x00563a70 ; FUN_00563a70 */

undefined4 FUN_00563a70(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_14 [12];
  int iStack_8;
  
  FUN_00580040(&iStack_8,param_2);
  if (iStack_8 != 0) {
    iVar1 = *(int *)(iStack_8 + 0x20);
    iVar2 = FUN_0088c8c0();
    if (iVar1 == iVar2) {
      iVar1 = *(int *)(iStack_8 + 0x20);
      iVar2 = FUN_0088c8c0();
      if (iVar1 == iVar2) {
        puVar3 = (undefined4 *)(iStack_8 + 0x28);
        if (*(int *)(iStack_8 + 0x24) == 0) {
          puVar3 = (undefined4 *)0x0;
        }
        return *puVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  uVar4 = FUN_005543f0();
  FUN_016756b0(auStack_14,"missing %s setting",uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_14,&DAT_01c17198);
}



/* FUNCTION 3101 ; VA 0x00563af0 ; FUN_00563af0 */

undefined * FUN_00563af0(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  cVar1 = FUN_00563920(param_2,param_3,param_1);
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar2 = FUN_005543f0();
  FUN_016756b0(auStack_20,"missing %s setting",uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 3102 ; VA 0x00563b90 ; FUN_00563b90 */

uint FUN_00563b90(char *param_1)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  pcVar3 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar3 = *(char **)param_1;
  }
  piVar1 = (int *)(param_1 + 0x10);
  if (0xf < *(uint *)(param_1 + 0x14)) {
    param_1 = *(char **)param_1;
  }
  iVar4 = (int)(pcVar3 + *piVar1) - (int)param_1;
  uVar6 = 0;
  iVar5 = 0;
  if (pcVar3 + *piVar1 < param_1) {
    iVar4 = 0;
  }
  if (iVar4 != 0) {
    do {
      cVar2 = *param_1;
      param_1 = param_1 + 1;
      iVar5 = iVar5 + 1;
      uVar6 = uVar6 ^ cVar2 + -0x61c88647 + uVar6 * 0x40 + (uVar6 >> 2);
    } while (iVar5 != iVar4);
  }
  return uVar6;
}



/* FUNCTION 3103 ; VA 0x00563bf0 ; FUN_00563bf0 */

undefined4 * FUN_00563bf0(undefined4 param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x60);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::thread_data<class_boost::function<void___cdecl(void)>_>::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puVar3[0x10] = 0;
    FUN_005880d0(param_1);
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 3104 ; VA 0x00563c6a ; Catch_All@00563c6a */

void Catch_All_00563c6a(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3105 ; VA 0x00563ca0 ; FUN_00563ca0 */

undefined4 FUN_00563ca0(undefined4 param_1,undefined4 param_2)

{
  FUN_0055b250(param_1,0,param_2,param_1);
  return param_1;
}



/* FUNCTION 3106 ; VA 0x00563cc0 ; FUN_00563cc0 */

void FUN_00563cc0(int *param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017939a0;
  pvStack_10 = ExceptionList;
  LOCK();
  iStack_8 = *param_1;
  ExceptionList = &pvStack_10;
  *param_1 = *param_1 + -1;
  UNLOCK();
  iStack_8 = iStack_8 + -1;
  if (iStack_8 == 0) {
    if ((code *)param_1[3] != (code *)0x0) {
      (*(code *)param_1[3])(param_1);
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    if (param_1[4] != 0) {
      FUN_00563cc0(param_1[4]);
    }
    piVar1 = param_1 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(param_1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3107 ; VA 0x00563d40 ; FUN_00563d40 */

int FUN_00563d40(int param_1,int param_2,uint *param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_2 - param_1 >> 2;
  if (0 < iVar1) {
    do {
      iVar2 = iVar1 >> 1;
      if (*(uint *)(param_1 + iVar2 * 4) < *param_3) {
        param_1 = param_1 + iVar2 * 4 + 4;
        iVar2 = iVar1 + (-1 - iVar2);
      }
      iVar1 = iVar2;
    } while (0 < iVar2);
  }
  return param_1;
}



/* FUNCTION 3108 ; VA 0x00563d90 ; FUN_00563d90 */

void FUN_00563d90(int *param_1)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  undefined4 uStack_8;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>
              ::vftable;
    *(undefined *)(puVar1 + 3) = 0;
    uStack_8 = 0xb;
    ppuVar2 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_8);
    ppuVar3 = ppuVar2 + -1;
    if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar3 = ppuVar2;
    }
    puVar1[4] = *ppuVar3;
    puVar1[5] = 0;
    puVar1[6] = 0x3f800000;
    puVar1[7] = 0;
    puVar1[8] = 0;
    param_1[1] = (int)puVar1;
    *param_1 = (int)(puVar1 + 3);
    return;
  }
  param_1[1] = 0;
  *param_1 = 0xc;
  return;
}



/* FUNCTION 3109 ; VA 0x00563e30 ; FUN_00563e30 */

void FUN_00563e30(int *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939bf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_CWebService::ScriptBlockingContext>::vftable;
    FUN_0151f360(0);
    puVar1[4] = 0;
    puVar1[5] = 0;
    *(undefined *)(puVar1 + 6) = 0;
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3110 ; VA 0x00563ec0 ; FUN_00563ec0 */

void __thiscall FUN_00563ec0(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x24,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    puVar1[7] = 0;
    puVar1[8] = 0xf;
    *(undefined *)(puVar1 + 3) = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 3111 ; VA 0x00563f20 ; FUN_00563f20 */

int * FUN_00563f20(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8ac8,&LAB_0055d550);
  uVar3 = FUN_00560b40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00938890();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 3112 ; VA 0x00563fd0 ; FUN_00563fd0 */

int * FUN_00563fd0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8ad0,&LAB_0055d560);
  uVar3 = FUN_00560bc0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_0093ada0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 3113 ; VA 0x00564080 ; FUN_00564080 */

int * FUN_00564080(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
  uVar3 = FUN_00560c40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00961660();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 3114 ; VA 0x00564130 ; FUN_00564130 */

int * FUN_00564130(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
  uVar3 = FUN_00560d40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00995770();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 3115 ; VA 0x005641e0 ; FUN_005641e0 */

int * FUN_005641e0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
  uVar3 = FUN_00560dc0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_0093f210();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 3116 ; VA 0x00564290 ; FUN_00564290 */

int * FUN_00564290(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
  uVar3 = FUN_00560e40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_005ee510();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 3117 ; VA 0x00564340 ; FUN_00564340 */

int FUN_00564340(TypeDescriptor *param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939f7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
              vftable;
    puVar4[1] = *(undefined4 *)(param_2 + 4);
  }
  FUN_005585d0(puVar4);
  iVar3 = (int)param_1;
  uStack_8 = 0;
  piVar5 = *(int **)((int)param_1 + 0x10);
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)FUN_01674e20(0x28);
    param_1 = (TypeDescriptor *)piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar1 = piVar5 + 1;
      *piVar5 = (int)boost::exception_detail::error_info_container_impl::vftable;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      *piVar1 = 0;
      piVar5[2] = 0;
      piStack_14 = piVar1;
      iVar6 = FUN_00575ad0();
      *piVar1 = iVar6;
      piVar5[7] = 0;
      piVar5[8] = 0xf;
      *(undefined *)(piVar5 + 3) = 0;
      piVar5[9] = 0;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (*(int **)(iVar3 + 0x10) != (int *)0x0) {
      (**(code **)(**(int **)(iVar3 + 0x10) + 0x10))();
    }
    *(int **)(iVar3 + 0x10) = piVar5;
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 0xc))();
    }
  }
  param_1 = &boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
             RTTI_Type_Descriptor;
  pcVar2 = *(code **)(*piVar5 + 8);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  (*pcVar2)(auStack_18,&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar6 = piStack_14[2] + -1;
      piStack_14[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  uStack_8 = 5;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_1c + 4))();
      LOCK();
      piVar5 = piStack_1c + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_1c + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 3118 ; VA 0x005644b0 ; FUN_005644b0 */

int FUN_005644b0(TypeDescriptor *param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939f7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
              vftable;
    puVar4[1] = *(undefined4 *)(param_2 + 4);
  }
  FUN_005585d0(puVar4);
  iVar3 = (int)param_1;
  uStack_8 = 0;
  piVar5 = *(int **)((int)param_1 + 0x18);
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)FUN_01674e20(0x28);
    param_1 = (TypeDescriptor *)piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar1 = piVar5 + 1;
      *piVar5 = (int)boost::exception_detail::error_info_container_impl::vftable;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      *piVar1 = 0;
      piVar5[2] = 0;
      piStack_14 = piVar1;
      iVar6 = FUN_00575ad0();
      *piVar1 = iVar6;
      piVar5[7] = 0;
      piVar5[8] = 0xf;
      *(undefined *)(piVar5 + 3) = 0;
      piVar5[9] = 0;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (*(int **)(iVar3 + 0x18) != (int *)0x0) {
      (**(code **)(**(int **)(iVar3 + 0x18) + 0x10))();
    }
    *(int **)(iVar3 + 0x18) = piVar5;
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 0xc))();
    }
  }
  param_1 = &boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
             RTTI_Type_Descriptor;
  pcVar2 = *(code **)(*piVar5 + 8);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  (*pcVar2)(auStack_18,&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar6 = piStack_14[2] + -1;
      piStack_14[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  uStack_8 = 5;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_1c + 4))();
      LOCK();
      piVar5 = piStack_1c + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_1c + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 3119 ; VA 0x00564620 ; FUN_00564620 */

int FUN_00564620(TypeDescriptor *param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939f7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
              vftable;
    puVar4[1] = *(undefined4 *)(param_2 + 4);
  }
  FUN_005585d0(puVar4);
  iVar3 = (int)param_1;
  uStack_8 = 0;
  piVar5 = *(int **)((int)param_1 + 4);
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)FUN_01674e20(0x28);
    param_1 = (TypeDescriptor *)piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar1 = piVar5 + 1;
      *piVar5 = (int)boost::exception_detail::error_info_container_impl::vftable;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      *piVar1 = 0;
      piVar5[2] = 0;
      piStack_14 = piVar1;
      iVar6 = FUN_00575ad0();
      *piVar1 = iVar6;
      piVar5[7] = 0;
      piVar5[8] = 0xf;
      *(undefined *)(piVar5 + 3) = 0;
      piVar5[9] = 0;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (*(int **)(iVar3 + 4) != (int *)0x0) {
      (**(code **)(**(int **)(iVar3 + 4) + 0x10))();
    }
    *(int **)(iVar3 + 4) = piVar5;
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 0xc))();
    }
  }
  param_1 = &boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>::
             RTTI_Type_Descriptor;
  pcVar2 = *(code **)(*piVar5 + 8);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  (*pcVar2)(auStack_18,&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar6 = piStack_14[2] + -1;
      piStack_14[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  uStack_8 = 5;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_1c + 4))();
      LOCK();
      piVar5 = piStack_1c + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_1c + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 3120 ; VA 0x005647a0 ; thunk_FUN_00888530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00888530(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2a6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede824) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede824);
    if (DAT_01ede824 == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_1c = uStack_1c & 0xffffff00;
      _DAT_01ede800 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede804 = FUN_0086e3d0(&DAT_0191cd0c);
      _DAT_01ede808 = (ulonglong)uStack_1c;
      _DAT_01ede810 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede800 = RBX::Reflection::Type::vftable;
      _DAT_01ede81c = 0;
      _DAT_01ede820 = 0;
      DAT_01ede822 = 0;
      _DAT_01ede814 = uVar1;
      _DAT_01ede818 = _DAT_01ede804;
      FUN_00888bf0();
      _DAT_01ede800 = RBX::Reflection::TType<void>::vftable;
      FUN_016f3654(&LAB_01880890);
      FUN_016f37bf(&DAT_01ede824);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede800;
}



/* FUNCTION 3121 ; VA 0x005647b0 ; FUN_005647b0 */

void FUN_005647b0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793a18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005627b0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_005610e0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c1e50c);
}



/* FUNCTION 3122 ; VA 0x00564800 ; FUN_00564800 */

void FUN_00564800(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00562810(auStack_30,param_1);
  uStack_8 = 0;
  FUN_005611c0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c1eae8);
}



/* FUNCTION 3123 ; VA 0x00564850 ; FUN_00564850 */

void FUN_00564850(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793a58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00562870(auStack_30,param_1);
  uStack_8 = 0;
  FUN_005612a0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c1eb70);
}



/* FUNCTION 3124 ; VA 0x005648a0 ; FUN_005648a0 */

void FUN_005648a0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793a78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005628d0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00561380(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c1e62c);
}



/* FUNCTION 3125 ; VA 0x005648f0 ; FUN_005648f0 */

void FUN_005648f0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_6c [52];
  undefined auStack_38 [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793a98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00562930(auStack_38,param_1);
  uStack_8 = 0;
  FUN_00561460(auStack_6c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c1e890);
}



/* FUNCTION 3126 ; VA 0x00564940 ; FUN_00564940 */

void FUN_00564940(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_6c [52];
  undefined auStack_38 [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793ab8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005629a0(auStack_38,param_1);
  uStack_8 = 0;
  FUN_00561560(auStack_6c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c1ea60);
}



/* FUNCTION 3127 ; VA 0x00564990 ; FUN_00564990 */

void FUN_00564990(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_9c [64];
  undefined auStack_5c [76];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793adb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00562a10(auStack_9c,param_1);
  uStack_8 = 0;
  FUN_00561660(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c1e918);
}



/* FUNCTION 3128 ; VA 0x005649e0 ; FUN_005649e0 */

void FUN_005649e0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_6c [52];
  undefined auStack_38 [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793af8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00562ac0(auStack_38,param_1);
  uStack_8 = 0;
  FUN_00561710(auStack_6c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c1e6ac);
}



/* FUNCTION 3129 ; VA 0x00564a30 ; FUN_00564a30 */

void FUN_00564a30(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_6c [52];
  undefined auStack_38 [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793b18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00562b30(auStack_38,param_1);
  uStack_8 = 0;
  FUN_00561810(auStack_6c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c1e808);
}



/* FUNCTION 3130 ; VA 0x00564a80 ; FUN_00564a80 */

void FUN_00564a80(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_0054e7d0(param_2);
  (**(code **)(*piVar1 + 0x18))(param_1);
  return;
}



/* FUNCTION 3131 ; VA 0x00564aa0 ; FUN_00564aa0 */

int * FUN_00564aa0(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791cbf;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  piVar2 = DAT_01ea8a14;
  uStack_8 = 0;
  if (DAT_01e90d00 == 0) {
    FUN_016dda75(0);
    if (DAT_01e90d00 == 0) {
      DAT_01e90d00 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01e90d00;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01e90d00;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01e90d00 < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01e90d00 * 4);
    if (piVar4 != (int *)0x0) goto LAB_00564bd1;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00564b43:
    if (piVar4 != (int *)0x0) goto LAB_00564bd1;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_00564b43;
    }
  }
  piVar4 = piVar2;
  if (piVar2 == (int *)0x0) {
    piVar4 = (int *)FUN_01674e20(8);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        puVar5 = &DAT_018bc9b8;
      }
      else {
        puVar5 = *(undefined1 **)(iVar3 + 0x18);
        if (puVar5 == (undefined1 *)0x0) {
          puVar5 = (undefined1 *)(iVar3 + 0x1c);
        }
      }
      FUN_0054f870(puVar5);
      bVar6 = true;
      piVar4[1] = 0;
      *piVar4 = (int)std::
                     num_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
                     ::vftable;
    }
    if (bVar6) {
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016de14f(piVar4);
    (**(code **)(*piVar4 + 4))();
    DAT_01ea8a14 = piVar4;
  }
LAB_00564bd1:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 3132 ; VA 0x00564bf0 ; FUN_00564bf0 */

int * FUN_00564bf0(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  undefined4 uVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793b70;
  pvStack_10 = ExceptionList;
  bVar7 = false;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  piVar2 = DAT_01ea8a18;
  uStack_8 = 0;
  if (DAT_01e90d04 == 0) {
    FUN_016dda75(0);
    if (DAT_01e90d04 == 0) {
      DAT_01e90d04 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01e90d04;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01e90d04;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01e90d04 < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01e90d04 * 4);
    if (piVar4 != (int *)0x0) goto LAB_00564d3e;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00564c93:
    if (piVar4 != (int *)0x0) goto LAB_00564d3e;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_00564c93;
    }
  }
  piVar4 = piVar2;
  if (piVar2 == (int *)0x0) {
    piVar4 = (int *)FUN_01674e20(0x18);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        puVar5 = &DAT_018bc9b8;
      }
      else {
        puVar5 = *(undefined1 **)(iVar3 + 0x18);
        if (puVar5 == (undefined1 *)0x0) {
          puVar5 = (undefined1 *)(iVar3 + 0x1c);
        }
      }
      uVar6 = FUN_0054f870(puVar5);
      bVar7 = true;
      piVar4[1] = 0;
      uStack_8 = 3;
      *piVar4 = (int)std::numpunct<char>::vftable;
      FUN_00577040(uVar6,1);
    }
    uStack_8 = 0;
    if (bVar7) {
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_016de14f(piVar4);
    (**(code **)(*piVar4 + 4))();
    DAT_01ea8a18 = piVar4;
  }
LAB_00564d3e:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 3133 ; VA 0x00564d60 ; FUN_00564d60 */

undefined4 __fastcall FUN_00564d60(undefined4 param_1)

{
  FUN_01682800(param_1);
  return param_1;
}



/* FUNCTION 3134 ; VA 0x00564d70 ; FUN_00564d70 */

undefined4 __thiscall FUN_00564d70(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005672c0(param_2,param_3);
  return param_1;
}



/* FUNCTION 3135 ; VA 0x00564d90 ; FUN_00564d90 */

int * __thiscall
FUN_00564d90(int *param_1,undefined4 *param_2,uint param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793bb2;
  pvStack_10 = ExceptionList;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bd138;
    param_1[0x1c] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_1 + 4,0);
  uStack_8 = 2;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x70;
  FUN_0054ee60();
  param_1[4] = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  param_1[7] = (int)(param_1 + 5);
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0xb] = (int)(param_1 + 9);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xf] = (int)(param_1 + 0xd);
  param_1[0x10] = (int)(param_1 + 0xe);
  *(undefined *)((int)param_1 + 0x4d) = 0;
  param_1[8] = (int)(param_1 + 6);
  param_1[6] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  *(undefined4 *)param_1[0x10] = 0;
  *(undefined4 *)param_1[7] = 0;
  *(undefined4 *)param_1[0xb] = 0;
  *(undefined4 *)param_1[0xf] = 0;
  param_1[0x17] = 0;
  param_1[0x14] = DAT_01e90d08;
  param_1[0x15] = DAT_01e90d0c;
  param_1[0x12] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar1 = FUN_005886c0(param_2,param_3 | 1,param_4);
  if (iVar1 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x70;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3136 ; VA 0x00564f30 ; FUN_00564f30 */

int * __thiscall FUN_00564f30(int *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793be7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bf130;
    param_1[4] = (int)&DAT_018bf138;
    param_1[8] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_2,0);
  *(undefined ***)((int)param_1 + *(int *)(param_1[4] + 4) + 0x10) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[4] + 4) + 0xc + (int)param_1) = *(int *)(param_1[4] + 4) + -8;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x20;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3137 ; VA 0x00565000 ; FUN_00565000 */

int * __thiscall FUN_00565000(int *param_1,undefined4 *param_2,uint param_3,int param_4)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793c2f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bffbc;
    param_1[0x18] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_1 + 4,0);
  uStack_8 = 2;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x60;
  FUN_0054ee60();
  param_1[4] = (int)std::
                    basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                    ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar7 = ~param_3 & 2 | 8;
  if ((param_3 & 8) == 0) {
    uVar7 = ~param_3 & 2;
  }
  uVar4 = uVar7 | 0x10;
  if ((param_3 & 4) == 0) {
    uVar4 = uVar7;
  }
  uVar7 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar7 < 0x80000000) {
    if (uVar7 == 0) {
      param_1[0x12] = 0;
    }
    else {
      iVar3 = FUN_00554060(uVar7);
      FUN_0170c6f0(iVar3,param_2,uVar7);
      param_1[0x12] = uVar7 + iVar3;
      *(int *)param_1[7] = iVar3;
      *(int *)param_1[0xb] = iVar3;
      *(uint *)param_1[0xf] = uVar7;
      if ((uVar4 & 2) == 0) {
        iVar1 = param_1[0x12];
        iVar6 = iVar3;
        if ((uVar4 & 0x18) != 0) {
          iVar6 = iVar1;
        }
        *(int *)param_1[8] = iVar3;
        *(int *)param_1[0xc] = iVar6;
        *(int *)param_1[0x10] = iVar1 - iVar6;
      }
      uVar4 = uVar4 | 1;
    }
    param_1[0x13] = uVar4;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_010c5e30();
  pcVar2 = (code *)swi(3);
  piVar5 = (int *)(*pcVar2)();
  return piVar5;
}



/* FUNCTION 3138 ; VA 0x00565180 ; FUN_00565180 */

int * __thiscall
FUN_00565180(int *param_1,undefined4 *param_2,uint param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793c72;
  pvStack_10 = ExceptionList;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bfd64;
    param_1[0x1a] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -8;
  FUN_00554f20(param_1 + 1,0);
  uStack_8 = 2;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_0054ee60();
  param_1[1] = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  param_1[4] = (int)(param_1 + 2);
  *(undefined *)(param_1 + 0x13) = 0;
  param_1[8] = (int)(param_1 + 6);
  param_1[9] = (int)(param_1 + 7);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xd] = (int)(param_1 + 0xb);
  *(undefined *)((int)param_1 + 0x41) = 0;
  param_1[5] = (int)(param_1 + 3);
  param_1[3] = 0;
  *(undefined4 *)param_1[9] = 0;
  *(undefined4 *)param_1[0xd] = 0;
  *(undefined4 *)param_1[4] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  param_1[0x14] = 0;
  param_1[0x11] = DAT_01e90d08;
  param_1[0x12] = DAT_01e90d0c;
  param_1[0xf] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar1 = FUN_005886c0(param_2,param_3 | 2,param_4);
  if (iVar1 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3139 ; VA 0x00565320 ; FUN_00565320 */

int * __thiscall
FUN_00565320(int *param_1,undefined4 param_2,uint param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793c72;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bfd64;
    param_1[0x1a] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -8;
  FUN_00554f20(param_1 + 1,0);
  uStack_8 = 2;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_0054ee60();
  param_1[1] = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  param_1[4] = (int)(param_1 + 2);
  *(undefined *)(param_1 + 0x13) = 0;
  param_1[8] = (int)(param_1 + 6);
  param_1[9] = (int)(param_1 + 7);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xd] = (int)(param_1 + 0xb);
  *(undefined *)((int)param_1 + 0x41) = 0;
  param_1[5] = (int)(param_1 + 3);
  param_1[3] = 0;
  *(undefined4 *)param_1[9] = 0;
  *(undefined4 *)param_1[0xd] = 0;
  *(undefined4 *)param_1[4] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  param_1[0x14] = 0;
  param_1[0x11] = DAT_01e90d08;
  param_1[0x12] = DAT_01e90d0c;
  param_1[0xf] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar1 = FUN_005886c0(param_2,param_3 | 2,param_4);
  if (iVar1 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3140 ; VA 0x00565490 ; FUN_00565490 */

int * __thiscall FUN_00565490(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793c9c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018be0f8;
    param_1[2] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -8;
  FUN_00554f20(param_2,param_3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3141 ; VA 0x00565520 ; FUN_00565520 */

int * __thiscall FUN_00565520(int *param_1,uint param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793cd7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018be314;
    param_1[0x14] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -8;
  FUN_00554f20(param_1 + 1,0);
  uStack_8 = 2;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x50;
  FUN_0054ee60();
  param_1[1] = (int)std::
                    basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                    ::vftable;
  param_1[0xf] = 0;
  uVar1 = (~param_2 & 1) << 2;
  uVar2 = uVar1 | 8;
  if ((param_2 & 8) == 0) {
    uVar2 = uVar1;
  }
  uVar1 = uVar2 | 0x10;
  if ((param_2 & 4) == 0) {
    uVar1 = uVar2;
  }
  param_1[0x10] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3142 ; VA 0x00565610 ; FUN_00565610 */

undefined * __thiscall
FUN_00565610(undefined *param_1,undefined4 *param_2,uint param_3,uint param_4)

{
  code *pcVar1;
  undefined *puVar2;
  uint uVar3;
  
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (param_3 <= (uint)param_2[4]) {
    uVar3 = param_2[4] - param_3;
    if (uVar3 < param_4) {
      param_4 = uVar3;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0((int)param_2 + param_3,param_4);
    return param_1;
  }
  FUN_00554050();
  pcVar1 = (code *)swi(3);
  puVar2 = (undefined *)(*pcVar1)();
  return puVar2;
}



/* FUNCTION 3143 ; VA 0x00565660 ; FUN_00565660 */

int * __thiscall FUN_00565660(int *param_1,uint param_2,char param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uVar2 = param_1[5];
  if (param_2 <= uVar2) {
    piVar7 = param_1;
    if (0xf < uVar2) {
      piVar7 = (int *)*param_1;
    }
    param_1[4] = param_2;
    FUN_0170d1f0(piVar7,(int)param_3,param_2);
    *(undefined *)((int)piVar7 + param_2) = 0;
    return param_1;
  }
  if (0x7fffffff < param_2) {
    FUN_00554040();
    pcVar4 = (code *)swi(3);
    piVar7 = (int *)(*pcVar4)();
    return piVar7;
  }
  uVar8 = param_2 | 0xf;
  if (uVar8 < 0x80000000) {
    if (0x7fffffff - (uVar2 >> 1) < uVar2) {
      uVar8 = 0x7fffffff;
    }
    else {
      uVar1 = (uVar2 >> 1) + uVar2;
      if (uVar8 < uVar1) {
        uVar8 = uVar1;
      }
    }
  }
  else {
    uVar8 = 0x7fffffff;
  }
  iVar5 = FUN_00554060(uVar8 + 1);
  param_1[5] = uVar8;
  param_1[4] = param_2;
  FUN_0170d1f0(iVar5,(int)param_3,param_2);
  *(undefined *)(iVar5 + param_2) = 0;
  if (0xf < uVar2) {
    uVar8 = uVar2 + 1;
    iVar3 = *param_1;
    iVar6 = iVar3;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar8 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  *param_1 = iVar5;
  return param_1;
}



/* FUNCTION 3144 ; VA 0x00565770 ; FUN_00565770 */

undefined * __thiscall FUN_00565770(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(param_2,param_3);
  return param_1;
}



/* FUNCTION 3145 ; VA 0x005657a0 ; FUN_005657a0 */

undefined4 * __thiscall FUN_005657a0(undefined4 *param_1,undefined4 *param_2,uint param_3)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793cf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ee60();
  *param_1 = std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
  uStack_8 = 0;
  uVar8 = (~param_3 & 1) << 2;
  uVar6 = uVar8 | 2;
  if ((param_3 & 2) != 0) {
    uVar6 = uVar8;
  }
  uVar8 = uVar6 | 8;
  if ((param_3 & 8) == 0) {
    uVar8 = uVar6;
  }
  uVar6 = param_2[4];
  uVar4 = uVar8 | 0x10;
  if ((param_3 & 4) == 0) {
    uVar4 = uVar8;
  }
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar6 < 0x80000000) {
    if ((uVar6 == 0) || (((byte)uVar4 & 6) == 6)) {
      param_1[0xe] = 0;
    }
    else {
      iVar3 = FUN_00554060(uVar6);
      FUN_0170c6f0(iVar3,param_2,uVar6);
      param_1[0xe] = uVar6 + iVar3;
      if ((uVar4 & 4) == 0) {
        *(int *)param_1[3] = iVar3;
        *(int *)param_1[7] = iVar3;
        *(uint *)param_1[0xb] = uVar6;
      }
      if ((uVar4 & 2) == 0) {
        iVar1 = param_1[0xe];
        iVar7 = iVar3;
        if ((uVar4 & 0x18) != 0) {
          iVar7 = iVar1;
        }
        *(int *)param_1[4] = iVar3;
        *(int *)param_1[8] = iVar7;
        *(int *)param_1[0xc] = iVar1 - iVar7;
        if ((uVar4 & 4) != 0) {
          *(int *)param_1[3] = iVar3;
          *(undefined4 *)param_1[7] = 0;
          *(int *)param_1[0xb] = iVar3;
        }
      }
      uVar4 = uVar4 | 1;
    }
    param_1[0xf] = uVar4;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_010c5e30();
  pcVar2 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar2)();
  return puVar5;
}



/* FUNCTION 3146 ; VA 0x005658e0 ; FUN_005658e0 */

undefined4 * __thiscall FUN_005658e0(undefined4 *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  
  FUN_0054ee60();
  *param_1 = std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
  param_1[0xe] = 0;
  uVar2 = (~param_2 & 1) << 2;
  uVar1 = uVar2 | 2;
  if ((param_2 & 2) != 0) {
    uVar1 = uVar2;
  }
  uVar2 = uVar1 | 8;
  if ((param_2 & 8) == 0) {
    uVar2 = uVar1;
  }
  uVar1 = uVar2 | 0x10;
  if ((param_2 & 4) == 0) {
    uVar1 = uVar2;
  }
  param_1[0xf] = uVar1;
  return param_1;
}



/* FUNCTION 3147 ; VA 0x00565940 ; FUN_00565940 */

int * __thiscall FUN_00565940(int *param_1,uint param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793d42;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bf148;
    param_1[4] = (int)&DAT_018bf150;
    param_1[0x1a] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_1 + 6,0);
  *(undefined ***)((int)param_1 + *(int *)(param_1[4] + 4) + 0x10) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[4] + 4) + 0xc + (int)param_1) = *(int *)(param_1[4] + 4) + -8;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x20;
  uStack_8 = 5;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_0054ee60();
  param_1[6] = (int)std::
                    basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                    ::vftable;
  param_1[0x14] = 0;
  uVar2 = (~param_2 & 1) << 2;
  uVar1 = uVar2 | 2;
  if ((param_2 & 2) != 0) {
    uVar1 = uVar2;
  }
  uVar2 = uVar1 | 8;
  if ((param_2 & 8) == 0) {
    uVar2 = uVar1;
  }
  uVar1 = uVar2 | 0x10;
  if ((param_2 & 4) == 0) {
    uVar1 = uVar2;
  }
  param_1[0x15] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3148 ; VA 0x00565a80 ; FUN_00565a80 */

undefined4 * __thiscall FUN_00565a80(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = *param_2;
  param_1[6] = 0;
  param_1[7] = 0;
  uVar1 = param_2[3];
  uVar2 = param_2[4];
  uVar3 = param_2[5];
  param_1[2] = param_2[2];
  param_1[3] = uVar1;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
  param_2[6] = 0;
  param_2[7] = 0xf;
  *(undefined *)(param_2 + 2) = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_2[8] = 0;
  param_2[9] = 0;
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uVar1 = param_2[0xd];
  uVar2 = param_2[0xe];
  uVar3 = param_2[0xf];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = uVar1;
  param_1[0xe] = uVar2;
  param_1[0xf] = uVar3;
  *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
  param_2[0x10] = 0;
  param_2[0x11] = 0xf;
  *(undefined *)(param_2 + 0xc) = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = param_2[0x13];
  param_2[0x12] = 0;
  param_2[0x13] = 0;
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  return param_1;
}



/* FUNCTION 3149 ; VA 0x00565b60 ; FUN_00565b60 */

int * __thiscall FUN_00565b60(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  uint uVar7;
  
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be080,
                         &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr,
                         &param_4);
  ppuVar6 = (undefined **)&DAT_018be0ec;
  if (ppuVar2 != &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr) {
    ppuVar6 = ppuVar2;
  }
  *param_1 = (int)(ppuVar6 + -0x62f820) >> 2;
  uVar3 = *(int *)(&DAT_018be080 + ((int)(ppuVar6 + -0x62f820) >> 2) * 4) + 1;
  param_1[2] = uVar3;
  if (uVar3 == 0) {
LAB_00565bfc:
    puVar5 = (undefined4 *)0x0;
  }
  else {
    uVar7 = uVar3 * 4;
    if (uVar3 < 0x40000000) {
      if (uVar7 < 0x1000) {
        if (uVar7 != 0) {
          puVar5 = (undefined4 *)FUN_01674e20(uVar7);
          goto LAB_00565bfe;
        }
        goto LAB_00565bfc;
      }
    }
    else {
      uVar7 = 0xffffffff;
    }
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    puVar5 = (undefined4 *)(iVar4 + 0x23U & 0xffffffe0);
    puVar5[-1] = iVar4;
  }
LAB_00565bfe:
  param_1[3] = (int)puVar5;
  puVar1 = puVar5 + *(int *)(&DAT_018be080 + *param_1 * 4);
  for (; puVar5 != puVar1; puVar5 = puVar5 + 1) {
    *puVar5 = 0;
  }
  *(int *)param_3 = param_3;
  *(int *)(param_1[3] + *(int *)(&DAT_018be080 + *param_1 * 4) * 4) = param_3;
  *(int *)(param_3 + 4) = param_1[3] + *(int *)(&DAT_018be080 + *param_1 * 4) * 4;
  return param_1;
}



/* FUNCTION 3150 ; VA 0x00565c60 ; FUN_00565c60 */

undefined4 * __thiscall FUN_00565c60(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793d74;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c047c;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_month::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3151 ; VA 0x00565d40 ; FUN_00565d40 */

undefined4 * __thiscall FUN_00565d40(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793da4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c08a0;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_month::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3152 ; VA 0x00565e20 ; FUN_00565e20 */

undefined4 * __thiscall FUN_00565e20(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793dd4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c08e0;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_year::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3153 ; VA 0x00565f00 ; FUN_00565f00 */

undefined4 * __thiscall FUN_00565f00(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793e04;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0600;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>::
       vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3154 ; VA 0x00565fe0 ; FUN_00565fe0 */

undefined4 * __thiscall FUN_00565fe0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793e34;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018c06e4;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_already_retrieved::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3155 ; VA 0x005660d0 ; FUN_005660d0 */

undefined4 * __thiscall FUN_005660d0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793e64;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018c0860;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_uninitialized::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3156 ; VA 0x005661c0 ; FUN_005661c0 */

undefined4 * __thiscall FUN_005661c0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791dfc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x10] = &DAT_018c0724;
    param_1[0x12] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_005680e0(param_2);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
             ::vftable;
  param_1[0xb] = boost::exception_detail::
                 clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
                 ::vftable;
  *(undefined ***)(*(int *)(param_1[0x10] + 4) + 0x40 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>::
       vftable;
  *(undefined4 *)(*(int *)(param_1[0x10] + 4) + 0x3c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3157 ; VA 0x00566250 ; FUN_00566250 */

undefined4 * __thiscall FUN_00566250(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793e94;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018c0640;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_already_satisfied::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3158 ; VA 0x00566340 ; FUN_00566340 */

undefined4 * __thiscall FUN_00566340(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793ec4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018c06a4;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_moved::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3159 ; VA 0x00566430 ; FUN_00566430 */

undefined4 * __thiscall FUN_00566430(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793e04;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0ac4;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3160 ; VA 0x00566510 ; FUN_00566510 */

undefined4 * __thiscall FUN_00566510(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793ef4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0af0;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_cast::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3161 ; VA 0x005665f0 ; FUN_005665f0 */

undefined4 * __thiscall FUN_005665f0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793f24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0b48;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_exception::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3162 ; VA 0x005666d0 ; FUN_005666d0 */

undefined4 * __thiscall FUN_005666d0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793f54;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0b1c;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_typeid::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3163 ; VA 0x005667b0 ; FUN_005667b0 */

undefined4 * __thiscall FUN_005667b0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793f84;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c090c;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::domain_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3164 ; VA 0x00566890 ; FUN_00566890 */

undefined4 * __thiscall FUN_00566890(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793fb4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018c0a6c;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3165 ; VA 0x00566980 ; FUN_00566980 */

undefined4 * __thiscall FUN_00566980(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793fe4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0938;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3166 ; VA 0x00566a60 ; FUN_00566a60 */

undefined4 * __thiscall FUN_00566a60(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794014;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0964;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::length_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3167 ; VA 0x00566b40 ; FUN_00566b40 */

undefined4 * __thiscall FUN_00566b40(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794044;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c09bc;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3168 ; VA 0x00566c20 ; FUN_00566c20 */

undefined4 * __thiscall FUN_00566c20(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794074;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0990;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3169 ; VA 0x00566d00 ; FUN_00566d00 */

undefined4 * __thiscall FUN_00566d00(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017940a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0a14;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::overflow_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3170 ; VA 0x00566de0 ; FUN_00566de0 */

undefined4 * __thiscall FUN_00566de0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017940d4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c09e8;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::range_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3171 ; VA 0x00566ec0 ; FUN_00566ec0 */

undefined4 * __thiscall FUN_00566ec0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794104;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0a98;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3172 ; VA 0x00566fa0 ; FUN_00566fa0 */

undefined4 * __thiscall FUN_00566fa0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794134;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c0a40;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::underflow_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3173 ; VA 0x00567080 ; FUN_00567080 */

undefined4 * __thiscall FUN_00567080(undefined4 *param_1,int param_2,int param_3)

{
  if (param_3 != 0) {
    param_1[5] = &DAT_018c0664;
    param_1[7] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(undefined ***)(*(int *)(param_1[5] + 4) + 0x14 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(undefined4 *)(*(int *)(param_1[5] + 4) + 0x10 + (int)param_1) = 0;
  return param_1;
}



/* FUNCTION 3174 ; VA 0x00567100 ; FUN_00567100 */

undefined4 * __thiscall FUN_00567100(undefined4 *param_1,int param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794164;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018c07d0;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  uStack_8 = 1;
  *param_1 = RBX::http_status_error::vftable;
  FUN_0054ef60(param_2 + 0xc);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3175 ; VA 0x005671c0 ; FUN_005671c0 */

undefined4 * __thiscall FUN_005671c0(undefined4 *param_1,int param_2,int param_3)

{
  if (param_3 != 0) {
    param_1[3] = &DAT_018c07ac;
    param_1[5] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(undefined ***)(*(int *)(param_1[3] + 4) + 0xc + (int)param_1) =
       boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(undefined4 *)(*(int *)(param_1[3] + 4) + 8 + (int)param_1) = 0;
  return param_1;
}



/* FUNCTION 3176 ; VA 0x00567230 ; FUN_00567230 */

undefined4 * __thiscall FUN_00567230(undefined4 *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791e2c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c04a8;
    param_1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_0056b5e0(param_2);
  *param_1 = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  param_1[5] = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3177 ; VA 0x005672c0 ; FUN_005672c0 */

uint * __thiscall FUN_005672c0(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined8 uVar4;
  
  *param_1 = 1;
  param_1[1] = 0;
  uVar1 = *param_2;
  if (((uVar1 != 0) && (uVar1 != 0xffffffff)) && (uVar1 != 0xfffffffe)) {
    uVar2 = *param_3;
    uVar3 = param_3[1];
    if ((((uVar2 != 0) || (uVar3 != 0x80000000)) && ((uVar2 != 0xffffffff || (uVar3 != 0x7fffffff)))
        ) && ((uVar2 != 0xfffffffe || (uVar3 != 0x7fffffff)))) {
      uVar4 = FUN_016f39b0(uVar1,0,0x1dd76000,0x14);
      uVar1 = *param_3;
      uVar2 = param_3[1];
      *param_1 = (uint)uVar4 + *param_3;
      param_1[1] = (int)((ulonglong)uVar4 >> 0x20) + uVar2 + (uint)CARRY4((uint)uVar4,uVar1);
      return param_1;
    }
  }
  uVar2 = param_3[1];
  uVar3 = *param_3;
  if (((uVar3 == 0) && (uVar2 == 0x80000000)) ||
     ((((uVar3 == 0xffffffff && (uVar2 == 0x7fffffff)) ||
       ((uVar3 == 0xfffffffe && (uVar2 == 0x7fffffff)))) ||
      (((uVar1 == 0 || (uVar1 == 0xffffffff)) || (uVar1 == 0xfffffffe)))))) {
    if (((uVar3 == 0xfffffffe) && (uVar2 == 0x7fffffff)) || (uVar1 == 0xfffffffe)) {
LAB_005673c7:
      *param_1 = 0xfffffffe;
      param_1[1] = 0x7fffffff;
      return param_1;
    }
    if ((uVar3 == 0xffffffff) && (uVar2 == 0x7fffffff)) {
      if (uVar1 == 0) goto LAB_005673c7;
    }
    else if ((uVar3 == 0) && (uVar2 == 0x80000000)) {
      if (uVar1 == 0xffffffff) goto LAB_005673c7;
      goto LAB_005673a4;
    }
    if ((uVar3 == 0xffffffff) && (uVar2 == 0x7fffffff)) {
LAB_005673a4:
      *param_1 = uVar3;
      param_1[1] = uVar2;
      return param_1;
    }
    if (uVar1 == 0xffffffff) {
      *param_1 = 0xffffffff;
      param_1[1] = 0x7fffffff;
      return param_1;
    }
    if (uVar1 == 0) {
      *param_1 = 0;
      param_1[1] = 0x80000000;
      return param_1;
    }
  }
  *param_1 = uVar1 + uVar3;
  param_1[1] = uVar2 + CARRY4(uVar1,uVar3);
  return param_1;
}



/* FUNCTION 3178 ; VA 0x00567430 ; FUN_00567430 */

undefined4 * __thiscall FUN_00567430(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>
             ::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::bad_alloc>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3179 ; VA 0x005674d0 ; FUN_005674d0 */

undefined4 * __thiscall FUN_005674d0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_cast::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>::
             vftable;
  param_1[3] = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>
               ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3180 ; VA 0x00567570 ; FUN_00567570 */

undefined4 * __thiscall FUN_00567570(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017941b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_exception::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3181 ; VA 0x00567610 ; FUN_00567610 */

undefined4 * __thiscall FUN_00567610(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017941d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_typeid::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>
             ::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::bad_typeid>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3182 ; VA 0x005676b0 ; FUN_005676b0 */

undefined4 * __thiscall FUN_005676b0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017941f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::domain_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3183 ; VA 0x00567750 ; FUN_00567750 */

undefined4 * __thiscall FUN_00567750(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794218;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3184 ; VA 0x00567800 ; FUN_00567800 */

undefined4 * __thiscall FUN_00567800(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794238;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3185 ; VA 0x005678a0 ; FUN_005678a0 */

undefined4 * __thiscall FUN_005678a0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794258;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::length_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::length_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::length_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3186 ; VA 0x00567940 ; FUN_00567940 */

undefined4 * __thiscall FUN_00567940(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794278;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3187 ; VA 0x005679e0 ; FUN_005679e0 */

undefined4 * __thiscall FUN_005679e0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794298;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3188 ; VA 0x00567a80 ; FUN_00567a80 */

undefined4 * __thiscall FUN_00567a80(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017942b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::overflow_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3189 ; VA 0x00567b20 ; FUN_00567b20 */

undefined4 * __thiscall FUN_00567b20(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017942d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::range_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::range_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::range_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3190 ; VA 0x00567bc0 ; FUN_00567bc0 */

undefined4 * __thiscall FUN_00567bc0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3191 ; VA 0x00567c60 ; FUN_00567c60 */

undefined4 * __thiscall FUN_00567c60(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017942f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::underflow_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
  param_1[3] = boost::exception_detail::
               current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3192 ; VA 0x00567d00 ; FUN_00567d00 */

undefined4 * __thiscall FUN_00567d00(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794318;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_month::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>
             ::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::gregorian::bad_day_of_month>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3193 ; VA 0x00567da0 ; FUN_00567da0 */

undefined4 * __thiscall FUN_00567da0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794338;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_month::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3194 ; VA 0x00567e40 ; FUN_00567e40 */

undefined4 * __thiscall FUN_00567e40(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794358;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_year::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3195 ; VA 0x00567ee0 ; FUN_00567ee0 */

undefined4 * __thiscall FUN_00567ee0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3196 ; VA 0x00567f80 ; FUN_00567f80 */

undefined4 * __thiscall FUN_00567f80(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794378;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_already_retrieved::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
             vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3197 ; VA 0x00568030 ; FUN_00568030 */

undefined4 * __thiscall FUN_00568030(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794398;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_uninitialized::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
             vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3198 ; VA 0x005680e0 ; FUN_005680e0 */

undefined4 * __thiscall FUN_005680e0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017943c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  *param_1 = boost::lock_error::vftable;
  param_1[0xb] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x30);
  uStack_8 = 1;
  param_1[0xc] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[0xd] = *(undefined4 *)(param_2 + 0x34);
  param_1[0xe] = *(undefined4 *)(param_2 + 0x38);
  param_1[0xf] = *(undefined4 *)(param_2 + 0x3c);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  param_1[0xb] = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3199 ; VA 0x005681a0 ; FUN_005681a0 */

undefined4 * __thiscall FUN_005681a0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017943d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_already_satisfied::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>::
             vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>
               ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3200 ; VA 0x00568250 ; FUN_00568250 */

undefined4 * __thiscall FUN_00568250(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017943f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_moved::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3201 ; VA 0x00568300 ; FUN_00568300 */

int __thiscall FUN_00568300(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  float fVar2;
  undefined **ppuVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  
  param_2 = (undefined4 *)*param_2;
  if (param_1 == 0) {
    iVar5 = 0;
  }
  else {
    iVar5 = param_1 + -0xc;
  }
  uVar10 = -(uint)(*(int *)(iVar5 + 4) != 0) & *(int *)(iVar5 + 4) + 0x30U;
  ppuVar3 = (undefined **)
            FUN_00563d40(&DAT_018be080,
                         &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr,
                         &param_2);
  ppuVar7 = (undefined **)&DAT_018be0ec;
  if (ppuVar3 != &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr) {
    ppuVar7 = ppuVar3;
  }
  *(int *)(param_1 + 4) = (int)(ppuVar7 + -0x62f820) >> 2;
  uVar4 = *(int *)(&DAT_018be080 + ((int)(ppuVar7 + -0x62f820) >> 2) * 4) + 1;
  *(uint *)(param_1 + 0xc) = uVar4;
  if (uVar4 == 0) {
LAB_005683bb:
    puVar9 = (undefined4 *)0x0;
  }
  else {
    uVar8 = uVar4 * 4;
    if (uVar4 < 0x40000000) {
      if (uVar8 < 0x1000) {
        if (uVar8 != 0) {
          puVar9 = (undefined4 *)FUN_01674e20(uVar8);
          goto LAB_005683bd;
        }
        goto LAB_005683bb;
      }
    }
    else {
      uVar8 = 0xffffffff;
    }
    uVar4 = uVar8 + 0x23;
    if (uVar4 <= uVar8) {
      uVar4 = 0xffffffff;
    }
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    puVar9 = (undefined4 *)(iVar5 + 0x23U & 0xffffffe0);
    puVar9[-1] = iVar5;
  }
LAB_005683bd:
  *(undefined4 **)(param_1 + 0x10) = puVar9;
  puVar1 = puVar9 + *(int *)(&DAT_018be080 + *(int *)(param_1 + 4) * 4);
  for (; puVar9 != puVar1; puVar9 = puVar9 + 1) {
    *puVar9 = 0;
  }
  *(uint *)uVar10 = uVar10;
  fVar2 = DAT_018c0d80;
  *(uint *)(*(int *)(param_1 + 0x10) + *(int *)(&DAT_018be080 + *(int *)(param_1 + 4) * 4) * 4) =
       uVar10;
  *(int *)(uVar10 + 4) =
       *(int *)(param_1 + 0x10) + *(int *)(&DAT_018be080 + *(int *)(param_1 + 4) * 4) * 4;
  *(undefined4 *)(param_1 + 0x14) = 0x3f800000;
  iVar5 = *(int *)(&DAT_018be080 + *(int *)(param_1 + 4) * 4);
  *(undefined4 *)(param_1 + 0x18) = 0xffffffff;
  if ((float)((double)iVar5 + (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)]) < fVar2) {
    uVar6 = FUN_016f3cd0();
    *(undefined4 *)(param_1 + 0x18) = uVar6;
  }
  return param_1;
}



/* FUNCTION 3202 ; VA 0x00568460 ; FUN_00568460 */

undefined4 __thiscall FUN_00568460(undefined4 param_1,uint param_2)

{
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  int in_stack_00000034;
  uint in_stack_00000048;
  undefined4 in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794438;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00568c30();
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    if (0xfff < in_stack_00000030 + 1) {
      if (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    if (0xfff < in_stack_00000048 + 1) {
      if (0x1f < (in_stack_00000034 - *(int *)(in_stack_00000034 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3203 ; VA 0x005685c0 ; FUN_005685c0 */

undefined4 __thiscall FUN_005685c0(undefined4 param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000044;
  int *in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01794488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000048[1] = in_stack_00000048[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  FUN_0054ef60();
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_8 = 6;
  FUN_0054ef60(&param_2);
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00569200();
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000040) {
    if (0xfff < in_stack_00000040 + 1) {
      if (0x1f < (in_stack_0000002c - *(int *)(in_stack_0000002c - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000048;
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000048[1] + -1;
    in_stack_00000048[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000048)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3204 ; VA 0x00568780 ; FUN_00568780 */

undefined4 * __thiscall FUN_00568780(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  
  *param_1 = param_2;
  iVar1 = FUN_016dee6d(param_2);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  return param_1;
}



/* FUNCTION 3205 ; VA 0x005687b0 ; FUN_005687b0 */

undefined4 * __thiscall FUN_005687b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar4 = ExceptionList;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  iVar2 = param_2[1];
  param_1[1] = iVar2;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  *param_2 = 0;
  piVar3 = (int *)param_2[1];
  param_2[1] = 0;
  uStack_8 = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 8))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvVar4;
  return param_1;
}



/* FUNCTION 3206 ; VA 0x00568850 ; FUN_00568850 */

undefined4 __thiscall FUN_00568850(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017944a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3207 ; VA 0x005688d0 ; FUN_005688d0 */

undefined4 __thiscall FUN_005688d0(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  uint uVar2;
  int iVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  int in_stack_00000034;
  uint in_stack_00000048;
  undefined auStack_64 [12];
  undefined4 uStack_58;
  uint uStack_54;
  int *piStack_50;
  int aiStack_48 [5];
  uint uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794500;
  pvStack_10 = ExceptionList;
  piStack_50 = (int *)&stack0x0000001c;
  uStack_8 = 2;
  uStack_54 = 0x568904;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = (int *)&param_2;
  uStack_8._0_1_ = 3;
  uStack_54 = 0x568914;
  FUN_0054ef60();
  puStack_18 = auStack_64;
  uStack_8._0_1_ = 5;
  FUN_0054ef60(aiStack_30);
  FUN_00568850();
  piStack_50 = aiStack_48;
  uStack_8._0_1_ = 6;
  uStack_54 = 0x568940;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_1c) {
    piStack_50 = (int *)(uStack_1c + 1);
    iVar3 = aiStack_30[0];
    if (0xfff < piStack_50) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      piStack_50 = (int *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x568a90;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x568975;
    uStack_54 = iVar3;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_34) {
    piStack_50 = (int *)(uStack_34 + 1);
    iVar3 = aiStack_48[0];
    if (0xfff < piStack_50) {
      iVar3 = *(int *)(aiStack_48[0] + -4);
      piStack_50 = (int *)(uStack_34 + 0x24);
      if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x568a95;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x5689ad;
    uStack_54 = iVar3;
    FUN_01674ea0();
  }
  piStack_50 = &stack0x00000034;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_54 = 0x5689c0;
  FUN_0054ef60();
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    uVar2 = param_2;
    if (0xfff < piStack_50) {
      uVar2 = *(uint *)(param_2 - 4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x568a9a;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x5689f1;
    uStack_54 = uVar2;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    piStack_50 = (int *)(in_stack_00000030 + 1);
    uVar2 = in_stack_0000001c;
    if (0xfff < piStack_50) {
      uVar2 = *(uint *)(in_stack_0000001c - 4);
      piStack_50 = (int *)(in_stack_00000030 + 0x24);
      if (0x1f < (in_stack_0000001c - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x568a9f;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x568a33;
    uStack_54 = uVar2;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    piStack_50 = (int *)(in_stack_00000048 + 1);
    iVar3 = in_stack_00000034;
    if (0xfff < piStack_50) {
      iVar3 = *(int *)(in_stack_00000034 + -4);
      piStack_50 = (int *)(in_stack_00000048 + 0x24);
      if (0x1f < (in_stack_00000034 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00568aa4;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x568a75;
    uStack_54 = iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3208 ; VA 0x00568ab0 ; FUN_00568ab0 */

int __thiscall FUN_00568ab0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 *puStack_44;
  uint auStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar4 = in_stack_00000020;
  uVar3 = in_stack_0000001c;
  puStack_c = &LAB_01794538;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_1c = in_stack_0000001c;
  piStack_18 = in_stack_00000020;
  puStack_44 = &param_2;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_48 = 0x568b01;
  puStack_14 = (undefined *)param_1;
  FUN_0054ef60();
  puStack_14 = auStack_58;
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_0054ef60(auStack_34);
  FUN_00568850();
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = uVar3;
  *(int **)(param_1 + 0x1c) = piVar4;
  if (0xf < uStack_20) {
    puStack_44 = (undefined4 *)(uStack_20 + 1);
    uVar5 = auStack_34[0];
    if (0xfff < puStack_44) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      puStack_44 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)0x568c20;
        FUN_017167a3();
      }
    }
    uStack_4c = 0x568b6a;
    uStack_48 = uVar5;
    FUN_01674ea0();
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0x568b83;
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_44 = (undefined4 *)0x568b93;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x20) = in_stack_00000024;
  *(undefined4 *)(param_1 + 0x24) = in_stack_00000028;
  if (0xf < in_stack_00000018) {
    puStack_44 = (undefined4 *)(in_stack_00000018 + 1);
    uVar5 = param_2;
    if (0xfff < puStack_44) {
      uVar5 = *(uint *)(param_2 - 4);
      puStack_44 = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)&UNK_00568c25;
        FUN_017167a3();
      }
    }
    uStack_4c = 0x568bcc;
    uStack_48 = uVar5;
    FUN_01674ea0();
  }
  piVar4 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0x568bf7;
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_44 = (undefined4 *)0x568c06;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3209 ; VA 0x00568c30 ; FUN_00568c30 */

int __thiscall FUN_00568c30(int param_1,uint param_2)

{
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  int in_stack_00000034;
  uint in_stack_00000048;
  undefined4 in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794438;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005688d0();
  *(undefined4 *)(param_1 + 0x48) = in_stack_0000004c;
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    if (0xfff < in_stack_00000030 + 1) {
      if (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    if (0xfff < in_stack_00000048 + 1) {
      if (0x1f < (in_stack_00000034 - *(int *)(in_stack_00000034 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3210 ; VA 0x00568d90 ; FUN_00568d90 */

undefined4 __thiscall FUN_00568d90(undefined4 param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  int in_stack_0000002c;
  uint in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01794578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  uStack_7 = 0;
  FUN_0054ef60(&param_2);
  uStack_8 = 2;
  FUN_00568ab0();
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_0054ef60();
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000040) {
    if (0xfff < in_stack_00000040 + 1) {
      if (0x1f < (in_stack_0000002c - *(int *)(in_stack_0000002c + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3211 ; VA 0x00568ee0 ; FUN_00568ee0 */

undefined4 * __thiscall FUN_00568ee0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  int aiStack_5c [5];
  uint uStack_48;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017945b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(aiStack_5c);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_44);
  *param_1 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(aiStack_2c);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    iVar1 = aiStack_2c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_2c[0] + -4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  param_1[7] = in_stack_00000020;
  if (0xf < uStack_30) {
    uVar2 = uStack_30 + 1;
    iVar1 = aiStack_44[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_44[0] + -4);
      uVar2 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  param_1[8] = in_stack_00000024;
  if (0xf < uStack_48) {
    uVar2 = uStack_48 + 1;
    iVar1 = aiStack_5c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_5c[0] + -4);
      uVar2 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  param_1[9] = in_stack_00000028;
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_3 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3212 ; VA 0x00569050 ; FUN_00569050 */

int __thiscall FUN_00569050(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000044;
  int *in_stack_00000048;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017945f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00568d90();
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    in_stack_00000048[1] = in_stack_00000048[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x40) = in_stack_00000044;
  *(int **)(param_1 + 0x44) = in_stack_00000048;
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000040) {
    if (0xfff < in_stack_00000040 + 1) {
      if (0x1f < (in_stack_0000002c - *(int *)(in_stack_0000002c - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000048;
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000048[1] + -1;
    in_stack_00000048[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000048)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3213 ; VA 0x00569200 ; FUN_00569200 */

int __thiscall FUN_00569200(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000044;
  int *in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01794488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000048[1] = in_stack_00000048[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  FUN_0054ef60();
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_8 = 6;
  FUN_0054ef60(&param_2);
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00569050();
  *(undefined4 *)(param_1 + 0x48) = in_stack_0000004c;
  *(undefined4 *)(param_1 + 0x4c) = in_stack_00000050;
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000040) {
    if (0xfff < in_stack_00000040 + 1) {
      if (0x1f < (in_stack_0000002c - *(int *)(in_stack_0000002c - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000048;
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000048[1] + -1;
    in_stack_00000048[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000048)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3214 ; VA 0x005693c0 ; FUN_005693c0 */

undefined4 * __thiscall FUN_005693c0(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  FUN_00587410();
  return param_1;
}



/* FUNCTION 3215 ; VA 0x005693e0 ; FUN_005693e0 */

undefined * __thiscall FUN_005693e0(undefined *param_1,undefined4 param_2)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  
  *param_1 = 0;
  ppuVar1 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar2 = ppuVar1 + -1;
  if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar2 = ppuVar1;
  }
  *(undefined **)(param_1 + 4) = *ppuVar2;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return param_1;
}



/* FUNCTION 3216 ; VA 0x00569440 ; FUN_00569440 */

undefined4 * __fastcall FUN_00569440(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return param_1;
}



/* FUNCTION 3217 ; VA 0x00569460 ; FUN_00569460 */

uint * __thiscall FUN_00569460(uint *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_2[1] - *param_2 >> 3;
  if (uVar3 != 0) {
    if (0x1fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = uVar3 * 8;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar4 = uVar3 + 0x23;
      if (uVar4 <= uVar3) {
        uVar4 = 0xffffffff;
      }
      iVar5 = FUN_01674e20(uVar4);
      if (iVar5 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar4 = iVar5 + 0x23U & 0xffffffe0;
      *(int *)(uVar4 - 4) = iVar5;
    }
    *param_1 = uVar4;
    param_1[1] = uVar4;
    param_1[2] = *param_1 + uVar3;
    puVar2 = (undefined4 *)param_2[1];
    puVar7 = (undefined4 *)*param_1;
    for (puVar6 = (undefined4 *)*param_2; puVar6 != puVar2; puVar6 = puVar6 + 2) {
      *puVar7 = 0;
      puVar7[1] = 0;
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar7 = *puVar6;
      puVar7[1] = puVar6[1];
      puVar7 = puVar7 + 2;
    }
    FUN_005596d0(puVar7,puVar7,param_1);
    param_1[1] = (uint)puVar7;
  }
  return param_1;
}



/* FUNCTION 3218 ; VA 0x00569550 ; FUN_00569550 */

undefined4 * __thiscall FUN_00569550(undefined4 *param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794608;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar1 = FUN_005759f0(param_2);
  if (cVar1 != '\0') {
    puVar3 = (undefined4 *)*param_1;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    for (; param_2 != 0; param_2 = param_2 + -1) {
      uVar2 = FUN_00888530();
      *puVar3 = uVar2;
      puVar3[1] = 0;
      puVar3 = puVar3 + 0x34;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00559720(puVar3,puVar3,param_1);
    param_1[1] = puVar3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3219 ; VA 0x005695f5 ; Catch_All@005695f5 */

void Catch_All_005695f5(void)

{
  FUN_00577b20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3220 ; VA 0x00569610 ; FUN_00569610 */

int * __thiscall FUN_00569610(int *param_1,int param_2)

{
  undefined4 ***pppuVar1;
  byte bVar2;
  undefined uVar3;
  undefined3 uVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  byte *pbVar9;
  byte *pbVar10;
  uint uVar11;
  int *piVar12;
  undefined4 *****pppppuVar13;
  undefined4 ****ppppuVar14;
  uint uVar15;
  char *pcVar16;
  bool bVar17;
  int aiStack_148 [4];
  undefined4 uStack_138;
  undefined *puStack_134;
  int aiStack_130 [6];
  code *pcStack_118;
  undefined auStack_114 [52];
  undefined4 uStack_e0;
  int *piStack_dc;
  code *pcStack_d8;
  undefined4 *puStack_d4;
  undefined4 ****ppppuStack_d0;
  undefined4 ****ppppuStack_cc;
  undefined4 ****ppppuStack_c8;
  undefined4 ****ppppuStack_c4;
  undefined4 ***apppuStack_b0 [2];
  undefined4 ***apppuStack_a8 [5];
  uint uStack_94;
  undefined4 ****appppuStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined **ppuStack_78;
  code *pcStack_74;
  undefined4 ***apppuStack_70 [2];
  undefined4 ***pppuStack_68;
  int *piStack_64;
  undefined ***pppuStack_54;
  undefined4 ****appppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 ****appppuStack_38 [2];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 ***pppuStack_20;
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017948b5;
  pvStack_10 = ExceptionList;
  uVar15 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ppppuStack_c4 = (undefined4 ****)0x1;
  ppppuStack_c8 = (undefined4 ****)0x569654;
  FUN_0151f360();
  piStack_18 = param_1 + 3;
  uStack_8._0_1_ = 2;
  piVar12 = param_1 + 4;
  *piStack_18 = (int)SimpleJSON::vftable;
  *piVar12 = 0;
  param_1[5] = 0;
  ppppuStack_c4 = (undefined4 ****)0x569676;
  piStack_1c = piVar12;
  iVar6 = FUN_00575af0();
  *piVar12 = iVar6;
  DAT_01e90d68 = param_1 + 3;
  *(undefined *)(param_1 + 6) = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0xf;
  *(undefined *)(param_1 + 7) = 0;
  *DAT_01e90d68 = (int)RCCServiceSettings::vftable;
  param_1[0x13] = 0;
  param_1[0x14] = 0xf;
  *(undefined *)(param_1 + 0xf) = 0;
  uStack_8._0_1_ = 4;
  ppppuStack_c4 = (undefined4 ****)0x5696ae;
  FUN_00574b70();
  uStack_8._0_1_ = 5;
  ppppuStack_c4 = (undefined4 ****)(param_2 + 0x98);
  ppppuStack_c8 = (undefined4 ****)0x5696c4;
  FUN_0054ef60();
  ppppuStack_c4 = (undefined4 ****)(param_2 + 0x30);
  uStack_8._0_1_ = 6;
  ppppuStack_c8 = (undefined4 ****)0x5696d7;
  piStack_18 = (int *)ppppuStack_c4;
  FUN_0054ef60();
  uStack_8._0_1_ = 7;
  ppppuStack_c4 = (undefined4 ****)0x1;
  ppppuStack_c8 = (undefined4 ****)0x5696e8;
  FUN_0151f360();
  *(undefined *)(param_1 + 0x24) = *(undefined *)(param_2 + 0xf8);
  *(undefined *)((int)param_1 + 0x91) = *(undefined *)(param_2 + 300);
  ppppuStack_c4 = (undefined4 ****)(param_2 + 0x130);
  uStack_8._0_1_ = 8;
  ppppuStack_c8 = (undefined4 ****)0x569716;
  FUN_0054ef60();
  param_1[0x2c] = 0;
  piVar12 = param_1 + 0x2d;
  uStack_8._0_1_ = 10;
  *piVar12 = 0;
  param_1[0x2e] = 0;
  ppppuStack_c4 = (undefined4 ****)0x569735;
  piStack_1c = piVar12;
  iVar6 = FUN_00575b10();
  *piVar12 = iVar6;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  pcVar16 = (char *)(param_1 + 0x34);
  ppppuStack_c4 = (undefined4 ****)(param_2 + 0x114);
  uStack_8._0_1_ = 0xd;
  ppppuStack_c8 = (undefined4 ****)0x56976f;
  FUN_0054ef60();
  uStack_8._0_1_ = 0xe;
  if (DAT_01d59104 != 0) {
    ppppuStack_c4 = (undefined4 ****)0x0;
    ppppuStack_cc = (undefined4 ****)(uint)DAT_01d59104;
    ppppuStack_c8 = (undefined4 ****)0x18bf7d0;
    ppppuStack_d0 = (undefined4 ****)0x56978b;
    FUN_016774b0();
  }
  ppppuStack_c4 = (undefined4 ****)0xa;
  ppppuStack_c8 = (undefined4 ****)0x18bcd04;
  uStack_40 = 0;
  uStack_3c = 0xf;
  appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
  ppppuStack_cc = (undefined4 ****)0x5697af;
  FUN_005542c0();
  ppppuStack_c4 = appppuStack_50;
  uStack_8._0_1_ = 0xf;
  ppppuStack_c8 = (undefined4 ****)0x5697bc;
  FUN_01522540();
  uStack_8._0_1_ = 0xe;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if (0xf < uStack_3c) {
    ppppuStack_c4 = (undefined4 ****)(uStack_3c + 1);
    ppppuVar14 = appppuStack_50[0];
    if (0xfff < ppppuStack_c4) {
      ppppuVar14 = (undefined4 ****)appppuStack_50[0][-1];
      ppppuStack_c4 = (undefined4 ****)(uStack_3c + 0x24);
      if (0x1f < (uint)((int)appppuStack_50[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        ppppuStack_c4 = (undefined4 ****)0x56a37d;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    ppppuStack_cc = (undefined4 ****)0x5697f4;
    ppppuStack_c8 = ppppuVar14;
    FUN_01674ea0();
  }
  ppppuStack_c4 = (undefined4 ****)(param_2 + 0x48);
  ppppuStack_c8 = (undefined4 ****)0x569803;
  FUN_01522420();
  ppppuStack_c8 = (undefined4 ****)param_2;
  ppppuStack_cc = (undefined4 ****)0x56980b;
  FUN_01522330();
  piStack_dc = piStack_18;
  uStack_e0 = 0x569818;
  FUN_0054ef60();
  piStack_dc = (int *)0x56981d;
  FUN_015223f0();
  ppppuStack_c4 = (undefined4 ****)0x6;
  ppppuStack_c8 = (undefined4 ****)0x18bf7f0;
  ppppuStack_cc = (undefined4 ****)0x569831;
  FUN_005542c0();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea896c) {
    ppppuStack_c4 = (undefined4 ****)&DAT_01ea896c;
    ppppuStack_c8 = (undefined4 ****)0x56a387;
    FUN_016f3809();
    if (DAT_01ea896c == -1) {
      uStack_8._0_1_ = 0x10;
      ppppuStack_c4 = (undefined4 ****)0x56a3a5;
      FUN_00895650();
      ppppuStack_c4 = (undefined4 ****)&DAT_01ea896c;
      uStack_8._0_1_ = 0xe;
      ppppuStack_c8 = (undefined4 ****)0x56a3b3;
      FUN_016f37bf();
    }
  }
  ppppuStack_c4 = (undefined4 ****)(param_1 + 3);
  ppppuStack_c8 = (undefined4 ****)0x56985c;
  FUN_00574e30();
  ppppuStack_c4 = (undefined4 ****)0x569861;
  FUN_016780d0();
  if ((DAT_01d593a8 != '\0') &&
     (ppppuStack_c4 = *(undefined4 *****)(param_2 + 0x150),
     ppppuStack_c4 != (undefined4 ****)0xffffffff)) {
    ppppuStack_c8 = (undefined4 ****)0xffffffff;
    ppppuStack_cc = (undefined4 ****)0xffffffff;
    ppppuStack_d0 = (undefined4 ****)0x569882;
    FUN_0093ccf0();
    ppppuStack_d0 = (undefined4 ****)0x3f;
    uStack_30 = 0xffffffff;
    uStack_2c = 0xffffffff;
    uStack_28 = *(undefined4 *)(param_2 + 0x150);
    puStack_d4 = &uStack_30;
    pcStack_d8 = FUN_0093d990;
    piStack_dc = (int *)0x5698ac;
    FUN_01677790();
  }
  if (DAT_01ea8524 == 0) {
    ppppuStack_c4 = (undefined4 ****)0x5698c1;
    piStack_18 = (int *)FUN_00910d90();
    piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
    piStack_18 = (int *)*piStack_18;
    pppuStack_20 = (undefined4 ***)(piStack_18 + 0x25);
    ppppuStack_c4 = (undefined4 ****)0x5698da;
    FUN_00587410();
    uStack_8._0_1_ = 0x11;
    if (DAT_01ea8524 == 0) {
      ppppuStack_c4 = (undefined4 ****)&uStack_28;
      ppppuStack_c8 = (undefined4 ****)0x5698f0;
      FUN_0055eba0();
      uVar15 = 0x100;
      uStack_14 = 0x100;
      ppppuStack_c4 = (undefined4 ****)0x0;
      ppppuStack_c8 = (undefined4 ****)piStack_18;
      uStack_8._0_1_ = 0x12;
      ppppuStack_cc = (undefined4 ****)0x56990c;
      FUN_008a65e0();
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_24[1] + -1;
        piStack_24[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          ppppuStack_c4 = (undefined4 ****)0x569924;
          (**(code **)*piStack_24)();
          LOCK();
          iVar6 = piStack_18[2] + -1;
          piStack_18[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            ppppuStack_c4 = (undefined4 ****)0x569936;
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    uStack_8._0_1_ = 0x13;
    if ((char)piStack_1c != '\0') {
      LOCK();
      pppuVar1 = (undefined4 ***)*pppuStack_20;
      *pppuStack_20 = *pppuStack_20 + -0x20000000;
      UNLOCK();
      if ((((uint)pppuVar1 & 0x40000000) == 0) && (-0x80000000 < (int)pppuVar1)) {
        LOCK();
        pppuVar1 = (undefined4 ***)*pppuStack_20;
        *pppuStack_20 = (undefined4 ***)((uint)*pppuStack_20 | 0x40000000);
        UNLOCK();
        if (((uint)pppuVar1 >> 0x1e & 1) == 0) {
          ppppuStack_c4 = (undefined4 ****)0x569966;
          ppppuStack_c4 = (undefined4 ****)FUN_00554e40();
          ppppuStack_c8 = (undefined4 ****)0x56996d;
          SetEvent();
        }
      }
    }
    uStack_8._0_1_ = 0xe;
  }
  piVar12 = DAT_01d590cc;
  if (DAT_01d59338 != '\0') {
    piVar12 = DAT_01d590d4;
  }
  ppppuStack_c4 = *(undefined4 *****)(param_2 + 0x148);
  if ((ppppuStack_c4 != (undefined4 ****)0x0) &&
     (piVar12 = (int *)ppppuStack_c4, piStack_18 = (int *)ppppuStack_c4, DAT_01d59036 != 0)) {
    ppppuStack_cc = (undefined4 ****)(uint)DAT_01d59036;
    ppppuStack_c8 = (undefined4 ****)0x18bf7f8;
    ppppuStack_d0 = (undefined4 ****)0x5699af;
    FUN_01677520();
    piVar12 = piStack_18;
  }
  ppppuStack_c8 = (undefined4 ****)0x5699bb;
  ppppuStack_c4 = (undefined4 ****)piVar12;
  FUN_0151ddb0();
  ppppuStack_c4 = (undefined4 ****)0x5699c3;
  FUN_00588480();
  if (DAT_01ea8528 == (int *)0x0) {
    ppppuStack_c4 = (undefined4 ****)0x5699d6;
    piStack_18 = (int *)FUN_00910d90();
    piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
    piStack_18 = (int *)*piStack_18;
    pppuStack_20 = (undefined4 ***)((int)piStack_18 + 0x94);
    ppppuStack_c4 = (undefined4 ****)0x5699ef;
    FUN_00587410();
    uStack_8._0_1_ = 0x14;
    if (DAT_01ea8528 == (int *)0x0) {
      ppppuStack_c4 = (undefined4 ****)&uStack_28;
      ppppuStack_c8 = (undefined4 ****)0x569a05;
      FUN_0055e190();
      uVar15 = uVar15 | 0x200;
      ppppuStack_c4 = (undefined4 ****)0x0;
      ppppuStack_c8 = (undefined4 ****)piStack_18;
      uStack_8._0_1_ = 0x15;
      ppppuStack_cc = (undefined4 ****)0x569a22;
      uStack_14 = uVar15;
      FUN_008a65e0();
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_24[1] + -1;
        piStack_24[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          ppppuStack_c4 = (undefined4 ****)0x569a3a;
          (**(code **)*piStack_24)();
          LOCK();
          iVar6 = piStack_18[2] + -1;
          piStack_18[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            ppppuStack_c4 = (undefined4 ****)0x569a4c;
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    piStack_18 = DAT_01ea8528;
    uStack_8._0_1_ = 0x16;
    if ((char)piStack_1c != '\0') {
      LOCK();
      pppuVar1 = (undefined4 ***)*pppuStack_20;
      *pppuStack_20 = *pppuStack_20 + -0x20000000;
      UNLOCK();
      if ((((uint)pppuVar1 & 0x40000000) == 0) && (-0x80000000 < (int)pppuVar1)) {
        LOCK();
        pppuVar1 = (undefined4 ***)*pppuStack_20;
        *pppuStack_20 = (undefined4 ***)((uint)*pppuStack_20 | 0x40000000);
        UNLOCK();
        if (((uint)pppuVar1 >> 0x1e & 1) == 0) {
          ppppuStack_c4 = (undefined4 ****)0x569a85;
          ppppuStack_c4 = (undefined4 ****)FUN_00554e40();
          ppppuStack_c8 = (undefined4 ****)0x569a8c;
          SetEvent();
        }
      }
    }
    uStack_8._0_1_ = 0xe;
  }
  ppppuStack_c4 = (undefined4 ****)0x0;
  ppppuStack_c8 = (undefined4 ****)0x569a9c;
  FUN_00938740();
  ppppuStack_c4 = (undefined4 ****)0x569aa1;
  FUN_005f2070();
  ppppuStack_c4 = (undefined4 ****)(uint)*(byte *)(param_2 + 0x7c);
  ppppuStack_c8 = (undefined4 ****)0x569aae;
  FUN_00555060();
  ppppuStack_c8 = (undefined4 ****)&ppuStack_78;
  ppuStack_78 = std::_Func_impl_no_alloc<void_(__cdecl*)(void),void>::vftable;
  pcStack_74 = FUN_00588480;
  uStack_8._0_1_ = 0x17;
  ppppuStack_cc = (undefined4 ****)0x569acc;
  pppuStack_54 = (undefined ***)ppppuStack_c8;
  FUN_0093cc30();
  uStack_8._0_1_ = 0xe;
  if (pppuStack_54 != (undefined ***)0x0) {
    ppppuStack_c4 =
         (undefined4 ****)CONCAT31((int3)((uint)&ppuStack_78 >> 8),pppuStack_54 != &ppuStack_78);
    ppppuStack_c8 = (undefined4 ****)0x569aea;
    (*(code *)(*pppuStack_54)[4])();
  }
  if (*(char *)((int)param_1 + 0x91) == '\0') {
    ppppuStack_c4 = (undefined4 ****)0x2;
    ppppuStack_c8 = (undefined4 ****)&DAT_018bf820;
    uStack_28 = 0;
    piStack_24 = (int *)0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    ppppuStack_cc = (undefined4 ****)0x569cd1;
    FUN_005542c0();
    uStack_8._0_1_ = 0x1d;
    if (param_1[0x38] == 0) {
      pcVar16 = "RCCServiceThumbnail";
      if (*(char *)(param_1 + 0x24) == '\0') {
        pcVar16 = "RCCService";
      }
    }
    else if (0xf < (uint)param_1[0x39]) {
      pcVar16 = *(char **)pcVar16;
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
    piVar12 = (int *)pcVar16;
    do {
      cVar5 = *(char *)piVar12;
      piVar12 = (int *)((int)piVar12 + 1);
    } while (cVar5 != '\0');
    ppppuStack_c4 = (undefined4 ****)((int)piVar12 - (int)((int)pcVar16 + 1));
    ppppuStack_cc = (undefined4 ****)0x569d23;
    ppppuStack_c8 = (undefined4 ****)pcVar16;
    FUN_005542c0();
    ppppuStack_c4 = appppuStack_90;
    uStack_8._0_1_ = 0x1e;
    ppppuStack_c8 = (undefined4 ****)0x569d35;
    ppppuStack_cc = (undefined4 ****)FUN_00581a10();
    ppppuStack_c4 = appppuStack_38;
    uStack_8._0_1_ = 0x1f;
    ppppuStack_c8 = appppuStack_50;
    ppppuStack_d0 = (undefined4 *****)0x569d47;
    FUN_0093d050();
    uStack_8._0_1_ = 0x1e;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x1e;
    if (0xf < uStack_7c) {
      ppppuStack_c4 = (undefined4 ****)(uStack_7c + 1);
      pppppuVar13 = (undefined4 *****)appppuStack_90[0];
      if (0xfff < ppppuStack_c4) {
        pppppuVar13 = (undefined4 *****)appppuStack_90[0][-1];
        ppppuStack_c4 = (undefined4 ****)(uStack_7c + 0x24);
        if (0x1f < (uint)((int)appppuStack_90[0] + (-4 - (int)pppppuVar13))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_c4 = (undefined4 ****)0x56a3cf;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppuStack_cc = (undefined4 *****)0x569d82;
      ppppuStack_c8 = pppppuVar13;
      FUN_01674ea0();
    }
    uStack_80 = 0;
    uStack_7c = 0xf;
    appppuStack_90[0] = (undefined4 ****)((uint)appppuStack_90[0] & 0xffffff00);
    uStack_8._0_1_ = 0x1d;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x1d;
    if (0xf < uStack_3c) {
      ppppuStack_c4 = (undefined4 ****)(uStack_3c + 1);
      pppppuVar13 = (undefined4 *****)appppuStack_50[0];
      if (0xfff < ppppuStack_c4) {
        pppppuVar13 = (undefined4 *****)appppuStack_50[0][-1];
        ppppuStack_c4 = (undefined4 ****)(uStack_3c + 0x24);
        if (0x1f < (uint)((int)appppuStack_50[0] + (-4 - (int)pppppuVar13))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_c4 = (undefined4 ****)0x56a3d4;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppuStack_cc = (undefined4 *****)0x569dcf;
      ppppuStack_c8 = pppppuVar13;
      FUN_01674ea0();
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
    uStack_8._0_1_ = 0xe;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < piStack_24) {
      ppppuStack_c4 = (undefined4 ****)((int)piStack_24 + 1);
      ppppuVar14 = appppuStack_38[0];
      if (0xfff < ppppuStack_c4) {
        ppppuVar14 = (undefined4 ****)appppuStack_38[0][-1];
        ppppuStack_c4 = (undefined4 ****)((int)piStack_24 + 0x24);
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_c4 = (undefined4 ****)&UNK_0056a3d9;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      goto LAB_00569e12;
    }
  }
  else {
    ppppuStack_c4 = apppuStack_a8;
    ppppuStack_c8 = (undefined4 ****)0x569b05;
    uVar7 = FUN_00581a10();
    ppppuStack_c4 = (undefined4 ****)0x2;
    ppppuStack_c8 = (undefined4 ****)&DAT_018bf820;
    uStack_8._0_1_ = 0x18;
    uStack_40 = 0;
    uStack_3c = 0xf;
    appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
    ppppuStack_cc = (undefined4 ****)0x569b2d;
    FUN_005542c0();
    uStack_8._0_1_ = 0x19;
    if (param_1[0x38] == 0) {
      pcVar16 = "RCCServiceThumbnail";
      if (*(char *)(param_1 + 0x24) == '\0') {
        pcVar16 = "RCCService";
      }
    }
    else if (0xf < (uint)param_1[0x39]) {
      pcVar16 = *(char **)pcVar16;
    }
    uStack_28 = 0;
    piStack_24 = (int *)0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    piVar12 = (int *)pcVar16;
    do {
      cVar5 = *(char *)piVar12;
      piVar12 = (int *)((int)piVar12 + 1);
    } while (cVar5 != '\0');
    ppppuStack_c4 = (undefined4 ****)((int)piVar12 - (int)((int)pcVar16 + 1));
    ppppuStack_cc = (undefined4 ****)0x569b83;
    ppppuStack_c8 = (undefined4 ****)pcVar16;
    FUN_005542c0();
    ppppuStack_c4 = (undefined4 ****)(param_1 + 0x25);
    uStack_8._0_1_ = 0x1a;
    ppppuStack_c8 = &pppuStack_68;
    ppppuStack_cc = (undefined4 ****)0x569b97;
    ppppuStack_c4 = (undefined4 ****)FUN_0151a8d0();
    uStack_8._0_1_ = 0x1b;
    ppppuStack_c8 = (undefined4 ****)0x569baa;
    FUN_0054f050();
    ppppuStack_c8 = appppuStack_50;
    uStack_8._0_1_ = 0x1c;
    ppppuStack_cc = appppuStack_38;
    ppppuStack_d0 = appppuStack_90;
    puStack_d4 = (undefined4 *)0x569bc5;
    ppppuStack_c4 = (undefined4 ****)uVar7;
    FUN_0093cee0();
    ppppuStack_c4 = (undefined4 ****)0x569bd3;
    FUN_00550800();
    ppppuStack_c4 = (undefined4 ****)0x569bdb;
    FUN_00550800();
    uStack_8._0_1_ = 0x19;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x19;
    if (0xf < piStack_24) {
      ppppuStack_c4 = (undefined4 ****)((int)piStack_24 + 1);
      pppppuVar13 = (undefined4 *****)appppuStack_38[0];
      if (0xfff < ppppuStack_c4) {
        pppppuVar13 = (undefined4 *****)appppuStack_38[0][-1];
        ppppuStack_c4 = (undefined4 ****)((int)piStack_24 + 0x24);
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar13))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_c4 = (undefined4 ****)0x56a3c0;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppuStack_cc = (undefined4 *****)0x569c10;
      ppppuStack_c8 = pppppuVar13;
      FUN_01674ea0();
    }
    uStack_28 = 0;
    piStack_24 = (int *)0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_8._0_1_ = 0x18;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x18;
    if (0xf < uStack_3c) {
      ppppuStack_c4 = (undefined4 ****)(uStack_3c + 1);
      pppppuVar13 = (undefined4 *****)appppuStack_50[0];
      if (0xfff < ppppuStack_c4) {
        pppppuVar13 = (undefined4 *****)appppuStack_50[0][-1];
        ppppuStack_c4 = (undefined4 ****)(uStack_3c + 0x24);
        if (0x1f < (uint)((int)appppuStack_50[0] + (-4 - (int)pppppuVar13))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_c4 = (undefined4 ****)0x56a3c5;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppuStack_cc = (undefined4 *****)0x569c5a;
      ppppuStack_c8 = pppppuVar13;
      FUN_01674ea0();
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
    uStack_8._0_1_ = 0xe;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_94) {
      ppppuStack_c4 = (undefined4 ****)(uStack_94 + 1);
      ppppuVar14 = (undefined4 ****)apppuStack_a8[0];
      if (0xfff < ppppuStack_c4) {
        ppppuVar14 = (undefined4 ****)apppuStack_a8[0][-1];
        ppppuStack_c4 = (undefined4 ****)(uStack_94 + 0x24);
        if (0x1f < (uint)((int)apppuStack_a8[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_c4 = (undefined4 ****)0x56a3ca;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
LAB_00569e12:
      uStack_8._0_1_ = 0xe;
      uStack_3c = 0xf;
      uStack_40 = 0;
      ppppuStack_cc = (undefined4 *****)0x569e19;
      ppppuStack_c8 = ppppuVar14;
      FUN_01674ea0();
    }
  }
  if (*(char *)(param_1 + 0x24) == '\0') {
    ppppuStack_c4 = (undefined4 ****)0x34;
    ppppuStack_c8 = (undefined4 ****)0x569e30;
    puVar8 = (undefined4 *)FUN_01674e20();
    uStack_8._0_1_ = 0x20;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x20;
    if (puVar8 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
      uStack_8._0_1_ = uVar3;
    }
    else {
      ppppuStack_c4 = (undefined4 ****)0x24;
      ppppuStack_c8 = (undefined4 ****)0x18bf824;
      uStack_80 = 0;
      uStack_7c = 0xf;
      appppuStack_90[0] = (undefined4 ****)((uint)appppuStack_90[0] & 0xffffff00);
      ppppuStack_cc = (undefined4 ****)0x569e6b;
      FUN_005542c0();
      ppppuStack_c4 = appppuStack_90;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
      uStack_14 = uVar15 | 1;
      ppppuStack_c8 = (undefined4 ****)0x569e81;
      ppppuStack_c8 = (undefined4 ****)FUN_0151b370();
      ppppuStack_cc = &pppuStack_68;
      ppppuStack_d0 = (undefined4 *****)0x569e8b;
      ppppuStack_c4 = (undefined4 ****)FUN_0151eab0();
      uVar15 = uVar15 | 3;
      uStack_8._0_1_ = 0x22;
      uStack_8._1_3_ = 0;
      *puVar8 = SecurityDataUpdater::vftable;
      ppppuStack_c8 = (undefined4 ****)0x569eaa;
      uStack_14 = uVar15;
      FUN_0054ef60();
      puVar8[0xb] = 0;
      puVar8[0xc] = 0xf;
      *(undefined *)(puVar8 + 7) = 0;
      *puVar8 = MD5Updater::vftable;
    }
    piVar12 = (int *)param_1[0x2c];
    param_1[0x2c] = (int)puVar8;
    if (piVar12 != (int *)0x0) {
      ppppuStack_c4 = (undefined4 ****)0x1;
      ppppuStack_c8 = (undefined4 ****)0x569edd;
      (**(code **)(*piVar12 + 4))();
    }
    if ((uVar15 & 2) != 0) {
      uVar15 = uVar15 & 0xfffffffd;
      ppppuStack_c4 = (undefined4 ****)0x569ef0;
      uStack_14 = uVar15;
      FUN_005507b0();
    }
    uStack_8._0_1_ = 0xe;
    uStack_8._1_3_ = 0;
    if ((uVar15 & 1) != 0) {
      uVar15 = uVar15 & 0xfffffffe;
      ppppuStack_c4 = (undefined4 ****)0x569f0d;
      uStack_14 = uVar15;
      FUN_005507b0();
    }
  }
  ppppuStack_c4 = (undefined4 ****)0x4;
  ppppuStack_c8 = (undefined4 *****)0x569f14;
  iVar6 = FUN_01674e20();
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    ppppuStack_c4 = &pppuStack_20;
    pppuStack_20 = (undefined4 ***)FUN_0058c7a0;
    ppppuStack_c8 = (undefined4 ****)0x569f33;
    piStack_1c = param_1;
    cVar5 = FUN_00585a40();
    if (cVar5 == '\0') {
      pppuStack_68 = pppuStack_20;
      piStack_64 = piStack_1c;
      apppuStack_70[0] = (undefined4 ****)0x18c0c71;
    }
    else {
      apppuStack_70[0] = (undefined4 ****)0x0;
    }
    ppppuStack_c4 = (undefined4 ****)0x18bf84c;
    ppppuStack_c8 = apppuStack_70;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
    ppppuStack_cc = apppuStack_b0;
    uStack_14 = uVar15 | 4;
    ppppuStack_d0 = (undefined4 *****)0x569f79;
    ppppuStack_c4 = (undefined4 ****)FUN_0151a450();
    uVar15 = uVar15 | 0xc;
    uStack_8 = 0x27;
    ppppuStack_c8 = (undefined4 *****)0x569f91;
    uStack_14 = uVar15;
    iVar6 = FUN_00558700();
  }
  pppppuVar13 = (undefined4 *****)*param_1;
  *param_1 = iVar6;
  if (pppppuVar13 != (undefined4 *****)0x0) {
    uStack_8 = 0x2a;
    ppppuStack_c4 = (undefined4 ****)0x569fae;
    FUN_016899e0();
    ppppuVar14 = *pppppuVar13;
    if (ppppuVar14 != (undefined4 ****)0x0) {
      LOCK();
      pppuVar1 = (undefined4 ***)((int)ppppuVar14[1] + -1);
      ppppuVar14[1] = pppuVar1;
      UNLOCK();
      if (pppuVar1 == (undefined4 ***)0x0) {
        ppppuStack_c4 = (undefined4 ****)0x0;
        ppppuStack_c8 = (undefined4 ****)0x569fc6;
        (*(code *)**ppppuVar14)();
        ppppuStack_cc = (undefined4 ****)0x0;
        ppppuStack_d0 = (undefined4 ****)0x569fcf;
        ppppuStack_c8 = ppppuVar14;
        ppppuStack_d0 = (undefined4 ****)GetProcessHeap();
        puStack_d4 = (undefined4 *)0x569fd6;
        HeapFree();
      }
    }
    ppppuStack_c4 = (undefined4 ****)0x4;
    ppppuStack_cc = (undefined4 *****)0x569fe0;
    ppppuStack_c8 = pppppuVar13;
    FUN_01674ea0();
  }
  if ((uVar15 & 8) != 0) {
    uVar15 = uVar15 & 0xfffffff7;
    uStack_8 = 0x2b;
    uStack_14 = uVar15;
    if ((undefined4 ****)apppuStack_b0[0] != (undefined4 ****)0x0) {
      if ((((uint)apppuStack_b0[0] & 1) == 0) &&
         (*(code **)((uint)apppuStack_b0[0] & 0xfffffffe) != (code *)0x0)) {
        ppppuStack_cc = apppuStack_a8;
        ppppuStack_c4 = (undefined4 ****)0x2;
        ppppuStack_d0 = (undefined4 *****)0x56a018;
        ppppuStack_c8 = ppppuStack_cc;
        (**(code **)((uint)apppuStack_b0[0] & 0xfffffffe))();
      }
      apppuStack_b0[0] = (undefined4 ****)0x0;
    }
  }
  uStack_8._1_3_ = 0;
  uVar4 = uStack_8._1_3_;
  if ((uVar15 & 4) != 0) {
    uVar15 = uVar15 & 0xfffffffb;
    uStack_8._1_3_ = 0;
    uVar4 = uStack_8._1_3_;
    uStack_8._0_1_ = 0x2c;
    uStack_8._1_3_ = 0;
    if ((((undefined4 ****)apppuStack_70[0] != (undefined4 ****)0x0) &&
        (uVar4 = uStack_8._1_3_, ((uint)apppuStack_70[0] & 1) == 0)) &&
       (*(code **)((uint)apppuStack_70[0] & 0xfffffffe) != (code *)0x0)) {
      ppppuStack_cc = &pppuStack_68;
      ppppuStack_c4 = (undefined4 ****)0x2;
      ppppuStack_d0 = (undefined4 *****)0x56a055;
      ppppuStack_c8 = ppppuStack_cc;
      (**(code **)((uint)apppuStack_70[0] & 0xfffffffe))();
      uVar4 = uStack_8._1_3_;
    }
  }
  uStack_8._1_3_ = uVar4;
  uStack_8._0_1_ = 0xe;
  if (DAT_01d59348 == '\0') {
    if ((DAT_01d59368 != 0) || (DAT_01d59398 != 0)) {
      ppppuStack_c4 = (undefined4 ****)0x4;
      ppppuStack_c8 = (undefined4 ****)0x56a22b;
      iVar6 = FUN_01674e20();
      uStack_8._0_1_ = 0x34;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x34;
      if (iVar6 == 0) {
        ppppuStack_c4 = (undefined4 ****)0x0;
        uStack_8._0_1_ = uVar3;
      }
      else {
        ppppuStack_c4 = (undefined4 ****)0x0;
        pcStack_118 = FUN_0057fb20;
        piStack_1c = aiStack_130;
        puStack_134 = &DAT_01d59370;
        uStack_138 = 0x56a25b;
        FUN_0054ef60();
        piStack_18 = aiStack_148;
        uStack_8._0_1_ = 0x35;
        FUN_0054ef60(&DAT_01d59388);
        uStack_8._0_1_ = 0x36;
        FUN_0054ef60(&DAT_01d59358);
        uStack_8._0_1_ = 0x34;
        FUN_0055ceb0(auStack_114,FUN_005dd3a0);
        pcStack_118 = (code *)0x56a2a1;
        FUN_005581c0();
        ppppuStack_c4 = (undefined4 ****)0x18bf8e4;
        ppppuStack_c8 = apppuStack_b0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x37);
        ppppuStack_cc = apppuStack_70;
        uStack_14 = uVar15 | 0x40;
        ppppuStack_d0 = (undefined4 *****)0x56a2c0;
        ppppuStack_c4 = (undefined4 ****)FUN_0151a450();
        uVar15 = uVar15 | 0xc0;
        uStack_8._0_1_ = 0x38;
        uStack_8._1_3_ = 0;
        ppppuStack_c8 = (undefined4 ****)0x56a2dc;
        uStack_14 = uVar15;
        ppppuStack_c4 = (undefined4 ****)FUN_00558700();
      }
      ppppuStack_c8 = (undefined4 *****)0x56a2e9;
      FUN_0058a2f0();
      if ((char)uVar15 < '\0') {
        uVar15 = uVar15 & 0xffffff7f;
        uStack_8 = 0x3b;
        uStack_14 = uVar15;
        if ((undefined4 ****)apppuStack_70[0] != (undefined4 ****)0x0) {
          if ((((uint)apppuStack_70[0] & 1) == 0) &&
             (*(code **)((uint)apppuStack_70[0] & 0xfffffffe) != (code *)0x0)) {
            ppppuStack_cc = &pppuStack_68;
            ppppuStack_c4 = (undefined4 ****)0x2;
            ppppuStack_d0 = (undefined4 *****)0x56a31a;
            ppppuStack_c8 = ppppuStack_cc;
            (**(code **)((uint)apppuStack_70[0] & 0xfffffffe))();
          }
          apppuStack_70[0] = (undefined4 ****)0x0;
        }
      }
      uStack_8._0_1_ = 0xe;
      uStack_8._1_3_ = 0;
      if ((uVar15 & 0x40) != 0) {
        uStack_8 = 0x3c;
        if ((((undefined4 ****)apppuStack_b0[0] != (undefined4 ****)0x0) &&
            (((uint)apppuStack_b0[0] & 1) == 0)) &&
           (*(code **)((uint)apppuStack_b0[0] & 0xfffffffe) != (code *)0x0)) {
          ppppuStack_cc = apppuStack_a8;
          ppppuStack_c4 = (undefined4 ****)0x2;
          ppppuStack_d0 = (undefined4 *****)0x56a357;
          ppppuStack_c8 = ppppuStack_cc;
          (**(code **)((uint)apppuStack_b0[0] & 0xfffffffe))();
        }
        uStack_8._0_1_ = 0xe;
      }
    }
  }
  else {
    ppppuStack_c4 = (undefined4 ****)0x18bf870;
    ppppuStack_c8 = (undefined4 *****)0x56a073;
    pbVar9 = (byte *)FUN_01717a5d();
    ppppuStack_c4 = (undefined4 ****)pbVar9;
    if (pbVar9 == (byte *)0x0) {
      if (DAT_01d59037 != 0) {
        ppppuStack_cc = (undefined4 ****)(uint)DAT_01d59037;
        ppppuStack_c8 = (undefined4 ****)0x18bf87c;
        ppppuStack_d0 = (undefined4 *****)0x56a094;
        FUN_016774b0();
      }
    }
    else {
      if (DAT_01d59037 != 0) {
        ppppuStack_cc = (undefined4 ****)(uint)DAT_01d59037;
        ppppuStack_c8 = (undefined4 ****)0x18bf8ac;
        ppppuStack_d0 = (undefined4 *****)0x56a0ac;
        FUN_01677520();
      }
      pbVar10 = &DAT_018bf8dc;
      do {
        bVar2 = *pbVar9;
        bVar17 = bVar2 < *pbVar10;
        if (bVar2 != *pbVar10) {
LAB_0056a0d4:
          uVar11 = -(uint)bVar17 | 1;
          goto LAB_0056a0d9;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar9[1];
        bVar17 = bVar2 < pbVar10[1];
        if (bVar2 != pbVar10[1]) goto LAB_0056a0d4;
        pbVar9 = pbVar9 + 2;
        pbVar10 = pbVar10 + 2;
      } while (bVar2 != 0);
      uVar11 = 0;
LAB_0056a0d9:
      if (uVar11 == 0) {
        *(undefined *)(param_1 + 0x2b) = 1;
      }
    }
    if ((DAT_01d59368 != 0) && (DAT_01d59398 != 0)) {
      if (DAT_01d59348 != '\0') {
        ppppuStack_c4 = (undefined4 ****)(uint)*(byte *)(param_1 + 0x2b);
        ppppuStack_c8 = (undefined4 *****)0x56a114;
        cVar5 = FUN_005df310();
        if (cVar5 == '\0') goto LAB_0056a35e;
      }
      ppppuStack_c4 = (undefined4 ****)0x4;
      ppppuStack_c8 = (undefined4 ****)0x56a126;
      iVar6 = FUN_01674e20();
      uStack_8._0_1_ = 0x2d;
      if (iVar6 == 0) {
        ppppuStack_c4 = (undefined4 ****)0x0;
      }
      else {
        ppppuStack_c4 = (undefined4 ****)0x0;
        pcStack_118 = FUN_0057fb20;
        piStack_1c = aiStack_130;
        puStack_134 = &DAT_01d59370;
        uStack_138 = 0x56a156;
        FUN_0054ef60();
        piStack_18 = aiStack_148;
        uStack_8._0_1_ = 0x2e;
        FUN_0054ef60(&DAT_01d59388);
        uStack_8._0_1_ = 0x2f;
        FUN_0054ef60(&DAT_01d59358);
        uStack_8._0_1_ = 0x2d;
        FUN_0055ceb0(auStack_114,FUN_005dd3a0);
        pcStack_118 = (code *)0x56a199;
        FUN_005581c0();
        ppppuStack_c4 = (undefined4 ****)0x18bf8e4;
        ppppuStack_c8 = apppuStack_70;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
        ppppuStack_cc = apppuStack_b0;
        uStack_14 = uVar15 | 0x10;
        ppppuStack_d0 = (undefined4 *****)0x56a1b8;
        ppppuStack_c4 = (undefined4 ****)FUN_0151a450();
        uVar15 = uVar15 | 0x30;
        uStack_8._0_1_ = 0x31;
        uStack_8._1_3_ = 0;
        ppppuStack_c8 = (undefined4 ****)0x56a1d1;
        uStack_14 = uVar15;
        ppppuStack_c4 = (undefined4 ****)FUN_00558700();
      }
      ppppuStack_c8 = (undefined4 *****)0x56a1de;
      FUN_0058a2f0();
      if ((uVar15 & 0x20) != 0) {
        uVar15 = uVar15 & 0xffffffdf;
        ppppuStack_c4 = (undefined4 ****)0x56a1f1;
        FUN_00550990();
      }
      uStack_8._0_1_ = 0xe;
      uStack_8._1_3_ = 0;
      if ((uVar15 & 0x10) != 0) {
        ppppuStack_c4 = (undefined4 ****)0x56a209;
        FUN_00550990();
      }
    }
  }
LAB_0056a35e:
  ppppuStack_c4 = (undefined4 ****)0x56a363;
  thunk_FUN_01747ee0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3221 ; VA 0x0056a3e0 ; FUN_0056a3e0 */

undefined4 * __thiscall FUN_0056a3e0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  *param_1 = param_2;
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 3222 ; VA 0x0056a400 ; FUN_0056a400 */

undefined4 * __thiscall FUN_0056a400(undefined4 *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  if (param_2 != (char *)0x0) {
    pcVar2 = param_2;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    *param_1 = param_2;
    param_1[1] = (int)pcVar2 - (int)(param_2 + 1);
    return param_1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 3223 ; VA 0x0056a440 ; FUN_0056a440 */

undefined4 * __thiscall FUN_0056a440(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = 0;
  if ((undefined4 *)param_2[1] != (undefined4 *)0x0) {
    (**(code **)param_2[1])(param_2 + 2,param_1 + 2);
    param_1[1] = param_2[1];
    return param_1;
  }
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 3224 ; VA 0x0056a4b0 ; FUN_0056a4b0 */

undefined4 * __fastcall FUN_0056a4b0(undefined4 *param_1)

{
  *param_1 = _ns1__BatchJobResponse::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 3225 ; VA 0x0056a500 ; FUN_0056a500 */

undefined4 * __fastcall FUN_0056a500(undefined4 *param_1)

{
  *param_1 = _ns1__OpenJobResponse::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 3226 ; VA 0x0056a530 ; FUN_0056a530 */

undefined4 * __thiscall FUN_0056a530(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_cast::vftable;
  return param_1;
}



/* FUNCTION 3227 ; VA 0x0056a570 ; FUN_0056a570 */

undefined4 * __thiscall FUN_0056a570(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_month::vftable;
  return param_1;
}



/* FUNCTION 3228 ; VA 0x0056a5b0 ; FUN_0056a5b0 */

undefined4 * __thiscall FUN_0056a5b0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  puStack_c = param_2;
  FUN_0170c226(&puStack_c,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_month::vftable;
  return param_1;
}



/* FUNCTION 3229 ; VA 0x0056a600 ; FUN_0056a600 */

undefined4 * __fastcall FUN_0056a600(undefined4 *param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_24 [4];
  undefined4 uStack_14;
  uint uStack_10;
  undefined4 ***pppuStack_c;
  undefined4 *puStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0xf;
  apppuStack_24[0] = (undefined4 ***)((uint)apppuStack_24[0] & 0xffffff00);
  puStack_8 = param_1;
  FUN_005542c0("Day of month value is out of range 1..31",0x28);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_c = apppuStack_24;
  if (0xf < uStack_10) {
    pppuStack_c = apppuStack_24[0];
  }
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  FUN_0170c226(&pppuStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_10) {
    uVar2 = uStack_10 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_24[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_24[0][-1];
      uVar2 = uStack_10 + 0x24;
      if (0x1f < (uint)((int)apppuStack_24[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  *param_1 = boost::gregorian::bad_day_of_month::vftable;
  return param_1;
}



/* FUNCTION 3230 ; VA 0x0056a6b0 ; FUN_0056a6b0 */

undefined4 * __thiscall FUN_0056a6b0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_month::vftable;
  return param_1;
}



/* FUNCTION 3231 ; VA 0x0056a6f0 ; FUN_0056a6f0 */

undefined4 * __fastcall FUN_0056a6f0(undefined4 *param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_24 [4];
  undefined4 uStack_14;
  uint uStack_10;
  undefined4 ***pppuStack_c;
  undefined4 *puStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0xf;
  apppuStack_24[0] = (undefined4 ***)((uint)apppuStack_24[0] & 0xffffff00);
  puStack_8 = param_1;
  FUN_005542c0("Month number is out of range 1..12",0x22);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_c = apppuStack_24;
  if (0xf < uStack_10) {
    pppuStack_c = apppuStack_24[0];
  }
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  FUN_0170c226(&pppuStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_10) {
    uVar2 = uStack_10 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_24[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_24[0][-1];
      uVar2 = uStack_10 + 0x24;
      if (0x1f < (uint)((int)apppuStack_24[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  *param_1 = boost::gregorian::bad_month::vftable;
  return param_1;
}



/* FUNCTION 3232 ; VA 0x0056a7a0 ; FUN_0056a7a0 */

undefined4 * __thiscall FUN_0056a7a0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_typeid::vftable;
  return param_1;
}



/* FUNCTION 3233 ; VA 0x0056a7e0 ; FUN_0056a7e0 */

undefined4 * __thiscall FUN_0056a7e0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_year::vftable;
  return param_1;
}



/* FUNCTION 3234 ; VA 0x0056a820 ; FUN_0056a820 */

undefined4 * __fastcall FUN_0056a820(undefined4 *param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_24 [4];
  undefined4 uStack_14;
  uint uStack_10;
  undefined4 ***pppuStack_c;
  undefined4 *puStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0xf;
  apppuStack_24[0] = (undefined4 ***)((uint)apppuStack_24[0] & 0xffffff00);
  puStack_8 = param_1;
  FUN_005542c0("Year is out of valid range: 1400..10000",0x27);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_c = apppuStack_24;
  if (0xf < uStack_10) {
    pppuStack_c = apppuStack_24[0];
  }
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  FUN_0170c226(&pppuStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_10) {
    uVar2 = uStack_10 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_24[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_24[0][-1];
      uVar2 = uStack_10 + 0x24;
      if (0x1f < (uint)((int)apppuStack_24[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  *param_1 = boost::gregorian::bad_year::vftable;
  return param_1;
}



/* FUNCTION 3235 ; VA 0x0056a8d0 ; FUN_0056a8d0 */

undefined4 * __thiscall FUN_0056a8d0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::broken_promise::vftable;
  return param_1;
}



/* FUNCTION 3236 ; VA 0x0056a920 ; FUN_0056a920 */

undefined4 * __thiscall
FUN_0056a920(undefined4 *param_1,undefined4 param_2,undefined4 param_3,ushort param_4)

{
  code *pcVar1;
  ushort uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined2 uStack_16;
  undefined2 uStack_14;
  ushort uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017948d0;
  pvStack_10 = ExceptionList;
  uStack_16 = (undefined2)param_2;
  uStack_14 = (undefined2)param_3;
  uStack_12 = param_4;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0057d1d0(&uStack_16);
  *param_1 = uVar3;
  uVar2 = FUN_0057eb10(param_2,param_3);
  if (param_4 <= uVar2) {
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar3 = FUN_0054eff0("Day of month is not valid for year");
  uStack_8 = 0;
  uVar3 = FUN_0056a5b0(uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_005647b0(uVar3);
  pcVar1 = (code *)swi(3);
  puVar4 = (undefined4 *)(*pcVar1)();
  return puVar4;
}



/* FUNCTION 3237 ; VA 0x0056a9c0 ; FUN_0056a9c0 */

undefined4 * __thiscall FUN_0056a9c0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  switch(param_2) {
  case 0:
    *param_1 = 0xfffffffe;
    return param_1;
  case 1:
    *param_1 = 0;
    return param_1;
  case 2:
    *param_1 = 0xffffffff;
    return param_1;
  case 3:
    *param_1 = 1;
    break;
  case 4:
    *param_1 = 0xfffffffd;
LAB_0056aa35:
    uVar4 = 0x1f;
    uVar3 = 0xc;
    uVar2 = 9999;
    goto LAB_0056aa51;
  default:
    *param_1 = 0xfffffffe;
    if (param_2 != 3) {
      if (param_2 != 4) {
        return param_1;
      }
      goto LAB_0056aa35;
    }
  }
  uVar4 = 1;
  uVar3 = 1;
  uVar2 = 0x578;
LAB_0056aa51:
  puVar1 = (undefined4 *)FUN_0056a920(uVar2,uVar3,uVar4);
  *param_1 = *puVar1;
  return param_1;
}



/* FUNCTION 3238 ; VA 0x0056aa80 ; FUN_0056aa80 */

undefined4 * __thiscall FUN_0056aa80(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::domain_error::vftable;
  return param_1;
}



/* FUNCTION 3239 ; VA 0x0056aac0 ; FUN_0056aac0 */

undefined4 * __fastcall FUN_0056aac0(undefined4 *param_1)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  return param_1;
}



/* FUNCTION 3240 ; VA 0x0056aae0 ; FUN_0056aae0 */

undefined4 * __thiscall FUN_0056aae0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_already_retrieved::vftable;
  return param_1;
}



/* FUNCTION 3241 ; VA 0x0056ab30 ; FUN_0056ab30 */

undefined4 * __fastcall FUN_0056ab30(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0168a9f0();
  FUN_0056abb0(2,uVar1);
  *param_1 = boost::future_already_retrieved::vftable;
  return param_1;
}



/* FUNCTION 3242 ; VA 0x0056ab60 ; FUN_0056ab60 */

undefined4 * __thiscall FUN_0056ab60(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  return param_1;
}



/* FUNCTION 3243 ; VA 0x0056abb0 ; FUN_0056abb0 */

undefined4 * __thiscall FUN_0056abb0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_24 [5];
  uint uStack_10;
  undefined4 ***pppuStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  (**(code **)(*param_3 + 8))(apppuStack_24,param_2);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_c = apppuStack_24;
  if (0xf < uStack_10) {
    pppuStack_c = apppuStack_24[0];
  }
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  FUN_0170c226(&pppuStack_c,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  if (0xf < uStack_10) {
    uVar2 = uStack_10 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_24[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_24[0][-1];
      uVar2 = uStack_10 + 0x24;
      if (0x1f < (uint)((int)apppuStack_24[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  param_1[3] = param_2;
  param_1[4] = param_3;
  *param_1 = boost::future_error::vftable;
  return param_1;
}



/* FUNCTION 3244 ; VA 0x0056ac60 ; FUN_0056ac60 */

undefined4 * __thiscall FUN_0056ac60(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::future_uninitialized::vftable;
  return param_1;
}



/* FUNCTION 3245 ; VA 0x0056acb0 ; FUN_0056acb0 */

undefined4 * __fastcall FUN_0056acb0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0168a9f0();
  FUN_0056abb0(4,uVar1);
  *param_1 = boost::future_uninitialized::vftable;
  return param_1;
}



/* FUNCTION 3246 ; VA 0x0056ace0 ; FUN_0056ace0 */

ushort * __thiscall FUN_0056ace0(ushort *param_1,uint param_2)

{
  code *pcVar1;
  ushort *puVar2;
  uint extraout_EDX;
  
  *param_1 = 0x578;
  if ((param_2 & 0xffff) + 1 < 0x579) {
    FUN_00588680(0x578,param_2,0);
    param_2 = extraout_EDX;
  }
  else if ((ushort)param_2 < 0x2711) {
    *param_1 = (ushort)param_2;
    return param_1;
  }
  FUN_00588680(0x578,param_2,1);
  pcVar1 = (code *)swi(3);
  puVar2 = (ushort *)(*pcVar1)();
  return puVar2;
}



/* FUNCTION 3247 ; VA 0x0056ad30 ; FUN_0056ad30 */

undefined4 * __thiscall FUN_0056ad30(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  uStack_8 = 0;
  *param_1 = RBX::http_status_error::vftable;
  FUN_0054ef60(param_2 + 0xc);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3248 ; VA 0x0056adb0 ; FUN_0056adb0 */

undefined4 * __thiscall FUN_0056adb0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  return param_1;
}



/* FUNCTION 3249 ; VA 0x0056adf0 ; FUN_0056adf0 */

undefined4 * __thiscall FUN_0056adf0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::length_error::vftable;
  return param_1;
}


