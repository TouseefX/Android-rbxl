/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 18500 ; VA 0x009afcd0 ; FUN_009afcd0 */

void FUN_009afcd0(undefined4 param_1)

{
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("BodyWidthScale",0xe);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyHeightScale",0xf);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyDepthScale",0xe);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("HeadScale",9);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyTypeScale",0xd);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyProportionScale",0x13);
  FUN_009ae900(param_1,uVar1);
  return;
}



/* FUNCTION 18501 ; VA 0x009afe20 ; FUN_009afe20 */

void FUN_009afe20(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = thunk_FUN_009c67e0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_009c6c60();
  iStack_8._0_1_ = 1;
  uStack_f0 = thunk_FUN_009c67e0();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_009c6c60();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18502 ; VA 0x009aff50 ; FUN_009aff50 */

void FUN_009aff50(int param_1,undefined4 param_2,undefined param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = thunk_FUN_009c67e0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_009c6c60();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18503 ; VA 0x009b0080 ; FUN_009b0080 */

void FUN_009b0080(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_009c68d0();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_009c6cd0();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18504 ; VA 0x009b0180 ; FUN_009b0180 */

int FUN_009b0180(int param_1,undefined param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d462c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088daf0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_005c9ef0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_3;
  piStack_e4 = param_4;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 18505 ; VA 0x009b0300 ; FUN_009b0300 */

void FUN_009b0300(int param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  iVar2 = *(int *)(param_1 + 0x18);
  if (param_2 == '\0') {
    FUN_01679490();
    FUN_01679490();
    if (*(int *)(iVar2 + 0x668) != 0) {
      FUN_009af8d0(*(int *)(iVar2 + 0x674) + *(int *)(iVar2 + 0x664) * 4,0);
      puVar3 = *(undefined4 **)(iVar2 + 0x674);
      puVar1 = puVar3 + *(int *)(iVar2 + 0x664);
      for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
        *puVar3 = 0;
      }
    }
    if (*(int *)(iVar2 + 0x698) != 0) {
      FUN_009af930(*(int *)(iVar2 + 0x6a4) + *(int *)(iVar2 + 0x694) * 4,0);
      puVar3 = *(undefined4 **)(iVar2 + 0x6a4);
      puVar1 = puVar3 + *(int *)(iVar2 + 0x694);
      for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
        *puVar3 = 0;
      }
    }
    return;
  }
  FUN_009adbf0();
  return;
}



/* FUNCTION 18506 ; VA 0x009b03b0 ; FUN_009b03b0 */

void FUN_009b03b0(undefined4 param_1,undefined4 param_2)

{
  FUN_009b7ec0(param_2);
  return;
}



/* FUNCTION 18507 ; VA 0x009b03d0 ; FUN_009b03d0 */

void FUN_009b03d0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x009b03f7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x18))();
  return;
}



/* FUNCTION 18508 ; VA 0x009b0400 ; FUN_009b0400 */

void FUN_009b0400(int param_1,undefined4 param_2)

{
  (**(code **)(param_1 + 0x18))(param_2);
  return;
}



/* FUNCTION 18509 ; VA 0x009b0430 ; FUN_009b0430 */

int FUN_009b0430(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_009a5c30(uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18510 ; VA 0x009b04c0 ; FUN_009b04c0 */

void FUN_009b04c0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(param_1 + 0x28);
  if (*(int *)(param_1 + 0x30) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x30) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_009a5c30(uVar2,*(undefined4 *)(param_1 + 0x2c),*(undefined4 *)(param_1 + 0x30));
  return;
}



/* FUNCTION 18511 ; VA 0x009b0500 ; FUN_009b0500 */

void FUN_009b0500(int param_1)

{
  (**(code **)(param_1 + 0x18))(*(undefined *)(param_1 + 0x2c));
  return;
}



/* FUNCTION 18512 ; VA 0x009b0530 ; FUN_009b0530 */

int FUN_009b0530(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 0x30) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x30) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_009a5ce0(uVar3,*(undefined4 *)(param_1 + 0x2c),*(undefined4 *)(param_1 + 0x30),param_2
                       ,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18513 ; VA 0x009b05f0 ; FUN_009b05f0 */

int FUN_009b05f0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  uVar3 = *(undefined *)(param_1 + 0x2c);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar4 = *(code **)(param_1 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(param_2,param_3,uVar3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 18514 ; VA 0x009b06e0 ; FUN_009b06e0 */

int FUN_009b06e0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d4660;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  if (*(uint *)(param_1 + 0x18) == 0) {
    uVar4 = FUN_0054fda0();
    _uStack_8 = CONCAT31(uStack_7,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar4);
  }
  iVar3 = (**(code **)((*(uint *)(param_1 + 0x18) & 0xfffffffe) + 4))
                    (param_1 + 0x20,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18515 ; VA 0x009b07d0 ; FUN_009b07d0 */

int FUN_009b07d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_1 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009b0800. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*piVar2 + 4))();
        return iVar3;
      }
    }
  }
  return param_1;
}



/* FUNCTION 18516 ; VA 0x009b0810 ; FUN_009b0810 */

void FUN_009b0810(void)

{
  FUN_009a4a10();
  return;
}



/* FUNCTION 18517 ; VA 0x009b0820 ; FUN_009b0820 */

void __fastcall FUN_009b0820(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if ((DAT_01d5a308 != '\0') && (*(int *)(param_1 + 0x7d4) == 0)) {
    puVar4 = (undefined4 *)FUN_01674e20(0x18);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar4[1] = 1;
      puVar4[2] = 1;
      *puVar4 = std::_Ref_count_obj<struct_RBX::ContentTracker>::vftable;
      *(undefined8 *)(puVar4 + 3) = 0;
      puVar4[5] = 0;
      puVar4[3] = 0;
      puVar4[4] = 0;
      puVar4[5] = 0;
    }
    *(undefined4 **)(param_1 + 0x7d4) = puVar4 + 3;
    piVar2 = *(int **)(param_1 + 0x7d8);
    *(undefined4 **)(param_1 + 0x7d8) = puVar4;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  return;
}



/* FUNCTION 18518 ; VA 0x009b08e0 ; FUN_009b08e0 */

int __fastcall FUN_009b08e0(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined auStack_1c [12];
  undefined auStack_10 [12];
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))(auStack_10);
  pfVar5 = (float *)(**(code **)(param_1 + 8))(auStack_1c);
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 18519 ; VA 0x009b0980 ; FUN_009b0980 */

bool __fastcall FUN_009b0980(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(param_1 + 8))();
  iVar2 = (**(code **)(param_1 + 8))();
  return iVar2 == iVar1;
}



/* FUNCTION 18520 ; VA 0x009b09e0 ; FUN_009b09e0 */

undefined __fastcall FUN_009b09e0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  puVar5 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar2 = puVar5 + 4;
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  uVar3 = FUN_0055c360(puVar5,*puVar2,puVar4,*puVar1);
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    iVar6 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_40[0] + -4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 18521 ; VA 0x009b0b10 ; FUN_009b0b10 */

int __fastcall FUN_009b0b10(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))();
  pfVar5 = (float *)(**(code **)(param_1 + 8))();
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 18522 ; VA 0x009b0ba0 ; FUN_009b0ba0 */

int __fastcall FUN_009b0ba0(int param_1)

{
  float fVar1;
  float fVar2;
  uint3 uVar3;
  undefined2 extraout_var;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar1 = (float)fVar4;
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar2 = (float)fVar4;
  uVar3 = CONCAT21(extraout_var,
                   (fVar1 == fVar2) << 6 | (NAN(fVar1) || NAN(fVar2)) << 2 | 2U | fVar1 < fVar2);
  if ((NAN(fVar1) || NAN(fVar2)) != (fVar1 == fVar2)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 18523 ; VA 0x009b0c10 ; FUN_009b0c10 */

bool __fastcall FUN_009b0c10(int param_1)

{
  char cVar1;
  char cVar2;
  
  cVar1 = (**(code **)(param_1 + 8))();
  cVar2 = (**(code **)(param_1 + 8))();
  return cVar2 == cVar1;
}



/* FUNCTION 18524 ; VA 0x009b0c70 ; FUN_009b0c70 */

bool __fastcall FUN_009b0c70(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(param_1 + 8))();
  iVar2 = (**(code **)(param_1 + 8))();
  return iVar2 == iVar1;
}



/* FUNCTION 18525 ; VA 0x009b0cd0 ; FUN_009b0cd0 */

int __fastcall FUN_009b0cd0(int param_1)

{
  float fVar1;
  float fVar2;
  uint3 uVar3;
  undefined2 extraout_var;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar1 = (float)fVar4;
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar2 = (float)fVar4;
  uVar3 = CONCAT21(extraout_var,
                   (fVar1 == fVar2) << 6 | (NAN(fVar1) || NAN(fVar2)) << 2 | 2U | fVar1 < fVar2);
  if ((NAN(fVar1) || NAN(fVar2)) != (fVar1 == fVar2)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 18526 ; VA 0x009b0d50 ; FUN_009b0d50 */

void __thiscall FUN_009b0d50(int param_1,uint param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  undefined4 **ppuStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar9 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4688;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  if (param_2 == 0) {
    return;
  }
  if (param_1 == 0) {
    return;
  }
  param_2 = *(uint *)(param_1 + 0x34);
  if (param_2 == 0) {
    return;
  }
  iVar6 = *(int *)(param_2 + 0xc);
  ppuStack_44 = (undefined4 **)0x9b0da0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00b63e30();
  if ((uint)*(ushort *)(iVar5 + 0x1da) <
      (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
    ExceptionList = pvStack_10;
    return;
  }
  ppuStack_44 = (undefined4 **)0x9b0dc6;
  FUN_009c7940();
  ppuStack_44 = (undefined4 **)(uint)(DAT_01d64a58 == '\0');
  puStack_4c = (undefined4 *)0x9b0dda;
  puStack_48 = (undefined4 *)param_1;
  cVar4 = FUN_00971ce0();
  if (cVar4 == '\0') {
    puStack_48 = (undefined4 *)0x9b0f82;
    ppuStack_44 = (undefined4 **)param_1;
    iVar6 = FUN_008b2e60();
    ppuStack_44 = *(undefined4 ***)(iVar9 + 0x34);
    if (ppuStack_44 != (undefined4 **)iVar6) {
      puStack_48 = (undefined4 *)0x9b0f92;
      cVar4 = FUN_008b0500();
      if (cVar4 == '\0') goto LAB_009b0f99;
    }
    puStack_48 = &uStack_24;
    ppuStack_44 = (undefined4 **)iVar9;
    puStack_4c = (undefined4 *)0x9b0fc2;
    piVar7 = (int *)FUN_0060dcd0();
    puStack_4c = (undefined4 *)*piVar7;
    puStack_48 = (undefined4 *)piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    ppuStack_44 = (undefined4 **)&uStack_2c;
    uStack_2c = 0;
    piStack_28 = (int *)0x0;
    uStack_8 = 2;
    uStack_34 = 0;
    uStack_30 = 0;
    FUN_009c10f0(param_1);
    goto LAB_009b101a;
  }
  ppuStack_44 = (undefined4 **)0x1;
  puStack_4c = (undefined4 *)0x9b0ded;
  puStack_48 = (undefined4 *)param_1;
  cVar4 = FUN_0097c970();
  if (cVar4 != '\0') {
LAB_009b0f99:
    ppuStack_44 = (undefined4 **)0x0;
    puStack_48 = (undefined4 *)param_2;
    puStack_4c = (undefined4 *)0x9b0fa5;
    FUN_008a65e0();
    ExceptionList = pvStack_10;
    return;
  }
  puStack_48 = (undefined4 *)0x9b0dfe;
  ppuStack_44 = (undefined4 **)param_1;
  iVar6 = FUN_009b4820();
  if (iVar6 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  puStack_48 = (undefined4 *)0x9b0e11;
  ppuStack_44 = (undefined4 **)param_1;
  iVar5 = FUN_008b2e60();
  ppuStack_44 = *(undefined4 ***)(iVar9 + 0x34);
  if (ppuStack_44 == (undefined4 **)iVar5) {
LAB_009b0e2c:
    param_2 = CONCAT13(1,(undefined3)param_2);
  }
  else {
    puStack_48 = (undefined4 *)0x9b0e21;
    cVar4 = FUN_008b0500();
    param_2 = param_2 & 0xffffff;
    if (cVar4 != '\0') goto LAB_009b0e2c;
  }
  puStack_48 = (undefined4 *)0x9b0e36;
  ppuStack_44 = (undefined4 **)iVar6;
  iVar5 = FUN_00980070();
  if ((iVar5 == 0) || (param_2._3_1_ != '\0')) {
    ppuStack_44 = (undefined4 **)0x0;
    puStack_4c = (undefined4 *)0x9b0f69;
    puStack_48 = (undefined4 *)iVar6;
    FUN_008a65e0();
    ExceptionList = pvStack_10;
    return;
  }
  ppuStack_44 = (undefined4 **)&param_2;
  puStack_48 = (undefined4 *)0x9b0e56;
  FUN_00927d30();
  puStack_1c = &param_2;
  uStack_18 = 0;
  ppuStack_44 = &puStack_1c;
  puStack_4c = &uStack_34;
  puStack_48 = (undefined4 *)iVar9;
  piVar7 = (int *)FUN_0060dcd0();
  uStack_8 = 0;
  piStack_14 = (int *)&puStack_4c;
  if ((*piVar7 == 0) ||
     (iVar9 = *(int *)(*piVar7 + 0xc), piStack_14 = (int *)&puStack_4c, iVar6 = thunk_FUN_00897b90()
     , (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    piStack_20 = (int *)0x0;
    puVar8 = &uStack_24;
    bVar3 = false;
    bVar2 = true;
    iVar9 = 0;
  }
  else {
    piStack_28 = (int *)piVar7[1];
    iVar9 = *piVar7;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
      piStack_28 = (int *)piVar7[1];
    }
    puVar8 = &uStack_2c;
    bVar3 = true;
    bVar2 = false;
  }
  piVar7 = piStack_14;
  iVar6 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  piStack_14[1] = iVar6;
  *piVar7 = iVar9;
  piVar7 = piStack_20;
  if ((bVar2) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar9 = piStack_20[1] + -1;
    piStack_20[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  piVar7 = piStack_28;
  if ((bVar3) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar9 = piStack_28[1] + -1;
    piStack_28[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar9 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  FUN_009c10f0(param_1);
LAB_009b101a:
  ppuStack_44 = (undefined4 **)0x9b101f;
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18527 ; VA 0x009b1040 ; FUN_009b1040 */

void * FUN_009b1040(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00c46280();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      pvVar4 = (void *)FUN_009b0d50(param_1);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 18528 ; VA 0x009b10e0 ; FUN_009b10e0 */

undefined4 __thiscall FUN_009b10e0(byte *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar4 = FUN_0055c740(param_1 + *param_1 + 1,param_2);
  uVar8 = uVar4 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar8 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    do {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar8)) {
        return 0;
      }
      if (piVar2[1] == uVar4) {
        piVar5 = piVar2 + 2;
        if (0xf < (uint)piVar2[7]) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar7 = (undefined4 *)*param_2;
        }
        cVar3 = FUN_0055c360(puVar7,param_2[4],piVar5,piVar2[6]);
        if (cVar3 != '\0') {
          uVar6 = FUN_009af8d0(piVar1,*piVar2);
          if (*piVar1 != 0) {
            uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
            if (uVar8 == uVar4) {
              return uVar6;
            }
            *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar1;
          }
          puVar7 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
          if ((int *)*puVar7 == piVar1) {
            *puVar7 = 0;
          }
          return uVar6;
        }
      }
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    } while( true );
  }
  return 0;
}



/* FUNCTION 18529 ; VA 0x009b11e0 ; FUN_009b11e0 */

undefined4 __thiscall FUN_009b11e0(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_009af930(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 18530 ; VA 0x009b12c0 ; FUN_009b12c0 */

undefined4 __thiscall FUN_009b12c0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = param_2[1];
  uVar5 = uVar7;
  if (((int)uVar7 < 1) && ((int)uVar7 < 0)) {
    uVar5 = ~uVar7;
  }
  uVar5 = (uVar5 >> 2) + uVar5 * 0x40 + *param_2 ^ uVar5;
  uVar6 = uVar5 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    for (piVar2 = (int *)*piVar1;
        (piVar2 != (int *)0x0 && ((uint)piVar2[1] % *(uint *)(param_1 + 4) == uVar6));
        piVar2 = (int *)*piVar2) {
      if ((piVar2[1] == uVar5) && ((*param_2 == piVar2[2] && (uVar7 == piVar2[3])))) {
        uVar3 = FUN_006c96e0(piVar1,*piVar2);
        if (*piVar1 != 0) {
          uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
          if (uVar6 == uVar7) {
            return uVar3;
          }
          *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
        }
        puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
        if ((int *)*puVar4 == piVar1) {
          *puVar4 = 0;
        }
        return uVar3;
      }
      piVar1 = piVar2;
    }
  }
  return 0;
}



/* FUNCTION 18531 ; VA 0x009b13b0 ; FUN_009b13b0 */

void __thiscall FUN_009b13b0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  uint in_stack_0000002c;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c858b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)*param_3)();
  if (iVar2 != 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 2;
    cVar1 = (**(code **)(*param_3 + 4))(1,&uStack_ec);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_0088baa0();
      uStack_14 = puVar3[1];
      uStack_18 = *puVar3;
      uStack_8._0_1_ = 3;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009b1486;
    }
    uStack_8._0_1_ = 4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8._0_1_ = 1;
  }
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  uStack_18 = *puVar3;
  uStack_14 = puVar3[1];
LAB_009b1486:
  FUN_009aae90(param_2,*(undefined8 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18532 ; VA 0x009b1540 ; FUN_009b1540 */

void __thiscall FUN_009b1540(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint in_stack_0000002c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d46b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00926720(auStack_18,param_3,param_1 + 0x44);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_009aad20(param_2,*(undefined8 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),uVar3,
               &param_4,&stack0x0000002c);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18533 ; VA 0x009b1640 ; FUN_009b1640 */

void __thiscall FUN_009b1640(int param_1,undefined4 param_2,code *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  char cVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint in_stack_0000002c;
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  undefined auStack_2c [12];
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar3 = param_3;
  puStack_c = &LAB_017d46ff;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar5 = (*(code *)**(undefined4 **)param_3)();
  if (1 < uVar5) {
    param_3 = *(code **)(*(int *)pcVar3 + 0x38);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee334c)
       && (FUN_016f3809(&DAT_01ee334c), DAT_01ee334c == -1)) {
      uStack_8._0_1_ = 2;
      FUN_00e2cce0();
      FUN_016f3654(&LAB_01885bd0);
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01ee334c);
    }
    cVar4 = (*param_3)(2,&DAT_01ee32e8,&uStack_14);
    if (cVar4 != '\0') goto LAB_009b1751;
    uStack_fc = FUN_00888530();
    iStack_f8 = 0;
    uStack_8._0_1_ = 3;
    cVar4 = (**(code **)(*(int *)pcVar3 + 4))(2,&uStack_fc);
    if (cVar4 != '\0') {
      puVar6 = (undefined4 *)FUN_00e2c9d0();
      uStack_14 = *puVar6;
      uStack_8._0_1_ = 4;
      if (iStack_f8 != 0) {
        (**(code **)(iStack_f8 + 8))(auStack_f4);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009b1751;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(param_1 + 0x48) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_2c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  uStack_14 = **(undefined4 **)(param_1 + 0x48);
LAB_009b1751:
  iVar2 = iStack_18;
  param_3 = (code *)uStack_14;
  uVar7 = FUN_00926720(auStack_20,pcVar3,iStack_18 + 0x44);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_009ab190(param_2,*(undefined8 *)(iVar2 + 0x38),*(undefined4 *)(iVar2 + 0x40),uVar7,&param_3,
               &param_4,&stack0x0000002c);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18534 ; VA 0x009b1890 ; FUN_009b1890 */

void __thiscall FUN_009b1890(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  undefined uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint in_stack_0000002c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4728;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008cca80(auStack_28,param_3,param_1 + 0x44);
  uStack_8._0_1_ = 2;
  FUN_009aabe0(param_2,*(undefined8 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),uVar2,
               &param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18535 ; VA 0x009b19b0 ; FUN_009b19b0 */

void __thiscall FUN_009b19b0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined uVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint in_stack_0000002c;
  undefined4 uStack_104;
  int iStack_100;
  undefined auStack_fc [200];
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4763;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_3)();
  if (1 < uVar3) {
    uStack_104 = FUN_00888530();
    iStack_100 = 0;
    uStack_8._0_1_ = 2;
    cVar2 = (**(code **)(*param_3 + 4))(2,&uStack_104);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_0088baa0();
      uStack_18 = *puVar4;
      uStack_14 = puVar4[1];
      uStack_8._0_1_ = 3;
      if (iStack_100 != 0) {
        (**(code **)(iStack_100 + 8))(auStack_fc);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009b1a8c;
    }
    uStack_8._0_1_ = 4;
    if (iStack_100 != 0) {
      (**(code **)(iStack_100 + 8))(auStack_fc);
    }
    uStack_8._0_1_ = 1;
  }
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  uStack_18 = *puVar4;
  uStack_14 = puVar4[1];
LAB_009b1a8c:
  uVar5 = FUN_008cca80(auStack_34,param_3,param_1 + 0x44);
  uStack_8._0_1_ = 5;
  FUN_009ab040(param_2,*(undefined8 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),uVar5,
               &uStack_18,&param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar3 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18536 ; VA 0x009b1bb0 ; FUN_009b1bb0 */

void __thiscall
FUN_009b1bb0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,uint param_5)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined auStack_44 [16];
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined **ppuStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4790;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00f94320();
  if ((cVar2 == '\0') ||
     (((*(char **)(param_1 + 0x178) != (char *)0x0 && (**(char **)(param_1 + 0x178) != '\0')) ||
      (*(int *)(param_1 + 0x16c) == 0)))) {
    puVar3 = &param_2;
    if (((int)param_5 >> 1 & 1U) == 0) {
      puVar3 = param_2;
    }
    (**(code **)(param_5 & 0xfffffff8))(puVar3,param_1);
  }
  else {
    FUN_0060dcd0(&uStack_18);
    if (iStack_14 != 0) {
      LOCK();
      *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 1;
      UNLOCK();
    }
    FUN_006d0690(&param_2);
    uStack_8._0_1_ = 2;
    ppuStack_28 = (undefined **)0x0;
    puStack_24 = (undefined4 *)FUN_01674fa0(0x18,4);
    uStack_2c = 4;
    uStack_20 = 0x18;
    uStack_34 = CONCAT44(0x18,puStack_24);
    *puStack_24 = 0;
    puStack_24[1] = 0;
    *puStack_24 = uStack_18;
    puStack_24[1] = iStack_14;
    FUN_006d0690(auStack_44);
    ppuStack_28 = &PTR_FUN_01d6504c;
    FUN_009a33c0();
    iVar1 = *(int *)(param_1 + 0x16c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (*(int *)(iVar1 + 8) == *(int *)(iVar1 + 4)) {
      FUN_0099c0f0(*(int *)(iVar1 + 4),&uStack_34);
    }
    else {
      FUN_0099e8e0(iVar1);
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 0x10;
    }
    FUN_006d1d50();
    FUN_00550b30();
  }
  uStack_8 = 4;
  if ((param_5 & 0xfffffff8) != 0) {
    uVar4 = (int)param_5 >> 1;
    if ((~(byte)((int)param_5 >> 2) & 1) == 0) {
      puVar3 = &param_2;
      if ((uVar4 & 1) == 0) {
        puVar3 = param_2;
      }
      (**(code **)((param_5 & 0xfffffff8) + 8))(puVar3);
    }
    if ((uVar4 & 1) == 0) {
      FUN_01674ee0(param_2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18537 ; VA 0x009b1d80 ; FUN_009b1d80 */

undefined4 __thiscall FUN_009b1d80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d47a8;
  pvStack_1c = ExceptionList;
  pcStack_40 = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_1c;
  uVar3 = (*pcStack_40)(auStack_2c);
  uStack_14 = 0;
  uStack_24 = FUN_009d5950(param_3,uVar3);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 18538 ; VA 0x009b1e40 ; FUN_009b1e40 */

undefined4 __thiscall FUN_009b1e40(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  code *pcStack_48;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d47d0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puVar4 = (undefined4 *)FUN_009d1340(auStack_34,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_48 = (code *)uVar2;
  uVar5 = (*pcStack_48)(auStack_2c,*puVar4,puVar4[1]);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  uStack_24 = FUN_009d5980(param_3,uVar5);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_30[1] + -1;
    piStack_30[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 18539 ; VA 0x009b1f80 ; FUN_009b1f80 */

undefined4 __thiscall FUN_009b1f80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bc228;
  pvStack_1c = ExceptionList;
  pcStack_40 = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_1c;
  uVar3 = (*pcStack_40)(auStack_2c);
  uStack_14 = 0;
  uStack_24 = FUN_009d5980(param_3,uVar3);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 18540 ; VA 0x009b2040 ; FUN_009b2040 */

undefined4 __thiscall FUN_009b2040(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 uVar4;
  code *pcStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9558;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puStack_24 = (undefined4 *)
               FUN_009d1340(auStack_30,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puStack_24[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_24[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  uVar4 = (*pcStack_40)(*puStack_24,puStack_24[1]);
  FUN_009c65d0();
  iVar3 = FUN_009cb050(uVar4);
  if (iVar3 == 0) {
    FUN_01256980(param_3);
  }
  else {
    FUN_00880a00(param_3,iVar3);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 1;
}



/* FUNCTION 18541 ; VA 0x009b2160 ; FUN_009b2160 */

undefined4 __thiscall FUN_009b2160(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 uVar4;
  code *pcStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9558;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puStack_24 = (undefined4 *)
               FUN_009d1340(auStack_30,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puStack_24[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_24[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  uVar4 = (*pcStack_40)(*puStack_24,puStack_24[1]);
  FUN_009c6730();
  iVar3 = FUN_009cb050(uVar4);
  if (iVar3 == 0) {
    FUN_01256980(param_3);
  }
  else {
    FUN_00880a00(param_3,iVar3);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 1;
}



/* FUNCTION 18542 ; VA 0x009b2280 ; FUN_009b2280 */

undefined4 __thiscall FUN_009b2280(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uStack_20;
  
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  uVar1 = (*uStack_20)();
  FUN_009c67e0();
  iVar2 = FUN_009cb050(uVar1);
  if (iVar2 != 0) {
    FUN_00880a00(param_3,iVar2);
    return 1;
  }
  FUN_01256980(param_3);
  return 1;
}



/* FUNCTION 18543 ; VA 0x009b2310 ; FUN_009b2310 */

undefined4 __thiscall FUN_009b2310(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  float10 fVar2;
  undefined4 uStack_28;
  
  iVar1 = FUN_01256300(param_3);
  fVar2 = (float10)FUN_009d0730(param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_28 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_28)((float)fVar2);
  return 0;
}



/* FUNCTION 18544 ; VA 0x009b2390 ; FUN_009b2390 */

undefined4 __thiscall FUN_009b2390(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bc228;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puVar4 = (undefined4 *)FUN_009d1340(auStack_2c,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  (*pcStack_40)(*puVar4,puVar4[1]);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 18545 ; VA 0x009b2480 ; FUN_009b2480 */

undefined4 FUN_009b2480(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined auStack_4c [12];
  undefined8 uStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9558;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300(param_2);
  puStack_28 = (undefined4 *)
               FUN_009d1340(auStack_30,param_2,param_3,2,iVar4 - param_3,iStack_24 + 0x48);
  uStack_14 = 0;
  puVar5 = (undefined8 *)FUN_009d16a0(auStack_4c,param_2,param_3,1,iVar4 - param_3,iStack_24 + 0x44)
  ;
  uVar3 = *(undefined4 *)(puVar5 + 1);
  uStack_40 = *(undefined8 *)(iStack_24 + 0x38);
  uVar2 = *puVar5;
  if (puStack_28[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_28[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*(code *)uStack_40)(uVar2,uVar3,*puStack_28,puStack_28[1]);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 18546 ; VA 0x009b25b0 ; FUN_009b25b0 */

undefined4 FUN_009b25b0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  uVar1 = FUN_009d1aa0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x48);
  uStack_18 = CONCAT31(uStack_18._1_3_,uVar1);
  puVar3 = (undefined8 *)FUN_009d16a0(auStack_34,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x44)
  ;
  uStack_28 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_28)(*puVar3,*(undefined4 *)(puVar3 + 1),uStack_18);
  return 0;
}



/* FUNCTION 18547 ; VA 0x009b2660 ; FUN_009b2660 */

undefined4 __thiscall FUN_009b2660(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uStack_20;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009b3690(param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_20)(uVar2);
  return 0;
}



/* FUNCTION 18548 ; VA 0x009b26d0 ; FUN_009b26d0 */

undefined4 __thiscall FUN_009b26d0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_28;
  
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,2,iVar2 - param_4,param_1 + 0x48);
  uVar3 = FUN_009b3690(param_3,param_4,1,iVar2 - param_4,param_1 + 0x44);
  uStack_28 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_28)(uVar3,uVar1);
  return 0;
}



/* FUNCTION 18549 ; VA 0x009b2770 ; FUN_009b2770 */

undefined4 __fastcall FUN_009b2770(int param_1)

{
  undefined4 uStack_20;
  
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_20)();
  return 0;
}



/* FUNCTION 18550 ; VA 0x009b27c0 ; FUN_009b27c0 */

undefined4 __thiscall FUN_009b27c0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined4 uStack_28;
  
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,1,iVar2 - param_4,param_1 + 0x44);
  uStack_28 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_28)(uVar1);
  return 0;
}



/* FUNCTION 18551 ; VA 0x009b2840 ; FUN_009b2840 */

undefined4 __thiscall FUN_009b2840(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined8 uStack_38;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a8af8;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d09d0(aiStack_50,param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_38 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  FUN_0054ef60(uVar2);
  uVar2 = (*(code *)uStack_38)();
  uVar2 = FUN_009d5ac0(param_3,uVar2);
  if (0xf < uStack_3c) {
    uVar3 = uStack_3c + 1;
    iVar1 = aiStack_50[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_50[0] + -4);
      uVar3 = uStack_3c + 0x24;
      if (0x1f < (aiStack_50[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_1c;
  return uVar2;
}



/* FUNCTION 18552 ; VA 0x009b2930 ; FUN_009b2930 */

undefined4 FUN_009b2930(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  code *pcStack_48;
  int iStack_44;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bbe88;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar5 = FUN_01256300(param_2);
  iVar5 = iVar5 - param_3;
  puStack_2c = (undefined4 *)FUN_009d1340(auStack_34,param_2,param_3,2,iVar5,iStack_24 + 0x48);
  uStack_14 = 0;
  if (0 < iVar5) {
    uVar6 = FUN_009c6730();
    cVar4 = FUN_009d1e20(uVar6,param_2,param_3 + 1,&iStack_28);
    if (cVar4 != '\0') goto LAB_009b29d4;
  }
  iStack_28 = FUN_0099fea0(param_2,param_3,1,iVar5,iStack_24 + 0x44);
LAB_009b29d4:
  uVar2 = *(undefined8 *)(iStack_24 + 0x38);
  iVar5 = *(int *)(*(int *)(param_1 + 0x138) + *(int *)(iStack_24 + 0x40));
  iStack_44 = (int)((ulonglong)uVar2 >> 0x20);
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_48 = (code *)uVar2;
  iVar3 = iStack_28;
  iStack_28 = iVar5 + iStack_44 + param_1 + 0x138;
  uVar6 = (*pcStack_48)(iVar3,*puStack_2c,puStack_2c[1]);
  uVar6 = FUN_009d5ac0(param_2,uVar6);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_30[2] + -1;
      piStack_30[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uVar6;
}



/* FUNCTION 18553 ; VA 0x009b2a80 ; FUN_009b2a80 */

void __thiscall FUN_009b2a80(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uStack_20;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009b3690(param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  uVar2 = (*uStack_20)(uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 18554 ; VA 0x009b2b00 ; FUN_009b2b00 */

void FUN_009b2b00(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcStack_28;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  if (0 < iVar2 - param_3) {
    uVar3 = FUN_009c68d0();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 1,&uStack_18);
    if (cVar1 != '\0') goto LAB_009b2b6b;
  }
  uStack_18 = FUN_009a00a0(param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x44);
LAB_009b2b6b:
  pcStack_28 = (code *)*(undefined8 *)(iStack_14 + 0x38);
  uVar3 = (*pcStack_28)(uStack_18);
  FUN_009d5ac0(param_2,uVar3);
  return;
}



/* FUNCTION 18555 ; VA 0x009b2bb0 ; FUN_009b2bb0 */

void __thiscall FUN_009b2bb0(int param_1,undefined4 *param_2,int *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = param_3[1];
  uVar5 = uVar1;
  if (((int)uVar1 < 1) && ((int)uVar1 < 0)) {
    uVar5 = ~uVar1;
  }
  uVar5 = (uVar5 >> 2) + uVar5 * 0x40 + *param_3 ^ uVar5;
  uVar4 = uVar5 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (puVar2 == (undefined4 *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3 = (int *)*puVar2;
    }
    if (piVar3 != (int *)0x0) {
      do {
        if (uVar5 == piVar3[1]) {
          if ((*param_3 == piVar3[2]) && (uVar1 == piVar3[3])) break;
        }
        else if ((uint)piVar3[1] % *(uint *)(param_1 + 4) != uVar4) {
          *param_2 = 0;
          return;
        }
        piVar3 = (int *)*piVar3;
        if (piVar3 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar3;
  return;
}



/* FUNCTION 18556 ; VA 0x009b2c70 ; FUN_009b2c70 */

undefined4 __fastcall FUN_009b2c70(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (*(int **)(param_1 + 4) == (int *)0x0) {
    return 0;
  }
  iVar1 = (**(code **)(**(int **)(param_1 + 4) + 4))();
  iVar2 = *(int *)(param_1 + 4);
  if (iVar1 == 0xf) {
    iVar2 = *(int *)(iVar2 + 4);
  }
  return *(undefined4 *)(iVar2 + 0xc);
}



/* FUNCTION 18557 ; VA 0x009b2ca0 ; FUN_009b2ca0 */

void FUN_009b2ca0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088c960();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0091b810(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18558 ; VA 0x009b2d00 ; FUN_009b2d00 */

/* WARNING: Removing unreachable block (ram,0x009b2daf) */
/* WARNING: Removing unreachable block (ram,0x009b2dbd) */
/* WARNING: Removing unreachable block (ram,0x009b2df3) */
/* WARNING: Removing unreachable block (ram,0x009b2dcd) */

void FUN_009b2d00(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)*param_2;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    FUN_0054ef60();
    uStack_8 = 0;
    FUN_006ecaa0(uStack_2c,uStack_28,uStack_24,uStack_20,CONCAT44(uStack_18,uStack_1c));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 18559 ; VA 0x009b2e00 ; FUN_009b2e00 */

void FUN_009b2e00(undefined4 param_1,undefined4 param_2)

{
  FUN_0099fd60(param_1,param_2,param_2);
  return;
}



/* FUNCTION 18560 ; VA 0x009b2e20 ; FUN_009b2e20 */

void FUN_009b2e20(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    uStack_8 = 0;
    FUN_0089be10(*piVar2,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18561 ; VA 0x009b2ed0 ; FUN_009b2ed0 */

void FUN_009b2ed0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = thunk_FUN_009c67e0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    uVar2 = *puVar4;
    iVar5 = thunk_FUN_009c67e0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_006150c0(*piVar6,uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18562 ; VA 0x009b2f60 ; FUN_009b2f60 */

void FUN_009b2f60(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  int *piVar7;
  
  iVar2 = *param_2;
  iVar6 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088daf0();
  if (iVar6 == iVar4) {
    puVar5 = (undefined *)(iVar2 + 0xd8);
    piVar3 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar5 = (undefined *)0x0;
    }
    iVar2 = *piVar3;
    uVar1 = *puVar5;
    param_2 = (int *)CONCAT13(uVar1,param_2._0_3_);
    iVar6 = thunk_FUN_009c67e0();
    if (iVar2 == iVar6) {
      piVar7 = piVar3 + 2;
      if (piVar3[1] == 0) {
        piVar7 = (int *)0x0;
      }
      param_2 = (int *)CONCAT31(param_2._1_3_,uVar1);
      FUN_005e66b0(*piVar7,param_2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18563 ; VA 0x009b2ff0 ; FUN_009b2ff0 */

void FUN_009b2ff0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_009c68d0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18564 ; VA 0x009b3050 ; FUN_009b3050 */

void FUN_009b3050(void)

{
  FUN_006eccd0();
  return;
}



/* FUNCTION 18565 ; VA 0x009b3080 ; FUN_009b3080 */

void FUN_009b3080(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088daf0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*(undefined *)piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18566 ; VA 0x009b30e0 ; FUN_009b30e0 */

void FUN_009b30e0(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)*param_2;
  iVar7 = *piVar2;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar7 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar4 = piVar2 + 2;
  iVar7 = *param_2;
  if (piVar2[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar3 = *(int *)(iVar7 + 0xd0);
  uVar1 = *(undefined *)piVar4;
  iVar5 = FUN_0088cdc0();
  if (iVar3 == iVar5) {
    puVar6 = (undefined4 *)(iVar7 + 0xd8);
    if (*(int *)(iVar7 + 0xd4) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar7 = puVar6[1];
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = puVar6[1];
    }
    uStack_8 = 0;
    FUN_009a5dd0(CONCAT31((int3)((uint)piVar4 >> 8),uVar1),*puVar6,iVar7);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18567 ; VA 0x009b31d0 ; FUN_009b31d0 */

void FUN_009b31d0(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  if (param_1 != (int *)0x0) {
    (**(code **)(*param_1 + 0x30))();
    puVar2 = (undefined4 *)param_1[0xb];
    if (puVar2 != (undefined4 *)0x0) {
      puVar1 = (undefined4 *)puVar2[1];
      for (puVar2 = (undefined4 *)*puVar2; puVar2 != puVar1; puVar2 = puVar2 + 2) {
        FUN_009b31d0(*puVar2);
      }
    }
  }
  return;
}



/* FUNCTION 18568 ; VA 0x009b3210 ; FUN_009b3210 */

int FUN_009b3210(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d47f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0089bce0(param_1,param_2,param_3,param_4);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18569 ; VA 0x009b32f0 ; FUN_009b32f0 */

undefined FUN_009b32f0(undefined4 param_1,int param_2,undefined8 *param_3,float *param_4,
                      float *param_5)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  char cVar13;
  float *pfVar14;
  uint uVar15;
  float fVar16;
  float fVar17;
  undefined auStack_bc [4];
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_9c;
  float fStack_94;
  undefined8 uStack_90;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined **ppuStack_78;
  undefined **appuStack_74 [3];
  float fStack_68;
  float fStack_64;
  float fStack_60;
  undefined ***pppuStack_5c;
  undefined2 uStack_58;
  undefined uStack_56;
  undefined4 uStack_54;
  undefined ***pppuStack_50;
  undefined2 uStack_4c;
  undefined uStack_4a;
  undefined4 uStack_48;
  undefined **ppuStack_44;
  undefined4 uStack_40;
  undefined **ppuStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined4 uStack_28;
  undefined uStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d4828;
  pvStack_1c = ExceptionList;
  uStack_21 = 0;
  if (*(int *)(param_2 + 0x6f4) == 0) {
    return 0;
  }
  uStack_28 = *(undefined4 *)(*(int *)(param_2 + 0x6f4) + 0x6ac);
  ExceptionList = &pvStack_1c;
  pfVar14 = (float *)FUN_00c157b0();
  uVar15 = 0;
  uStack_84 = 0;
  fVar1 = pfVar14[4];
  fVar2 = pfVar14[5];
  fVar3 = pfVar14[6];
  fVar4 = pfVar14[7];
  uStack_80 = 0;
  fVar9 = pfVar14[8];
  fVar10 = pfVar14[9];
  fVar11 = pfVar14[10];
  fVar12 = pfVar14[0xb];
  uStack_7c = 0;
  fVar5 = *pfVar14;
  fVar6 = pfVar14[1];
  fVar7 = pfVar14[2];
  fVar8 = pfVar14[3];
  ppuStack_78 = RBX::FilterHumanoidParts::vftable;
  *(undefined8 *)param_5 = *param_3;
  param_5[2] = *(float *)(param_3 + 1);
  do {
    fVar17 = (float)(int)((uint)(uVar15 != 2) * 2 + -1) * *param_4;
    fVar16 = (float)(int)((uint)(uVar15 != 1) * 2 + -1) * param_4[2];
    fStack_94 = fVar3 * fVar17 + fVar4 * 0.0 + fVar9 * fVar16 + fVar12;
    fStack_30 = fVar8 * fVar17 + fVar1 * 0.0 + fVar2 * fVar16 + fVar11;
    uStack_88 = *(undefined4 *)(param_3 + 1);
    fStack_2c = fVar5 * fVar17 + fVar6 * 0.0 + fVar7 * fVar16 + fVar10;
    uStack_9c = CONCAT44(fStack_30,fStack_2c);
    uStack_90 = *param_3;
    uStack_14 = 0;
    fStack_34 = fStack_94;
    uStack_40 = FUN_009b7320();
    ppuStack_44 = RBX::FilterSameAssembly::vftable;
    ppuStack_3c = RBX::FilterSameAssembly::vftable;
    uStack_38 = param_1;
    uStack_14._0_1_ = 2;
    FUN_00f9ba80(&ppuStack_44,&ppuStack_3c);
    uStack_14 = CONCAT31(uStack_14._1_3_,4);
    fStack_b8 = 0.0;
    fStack_b4 = 0.0;
    fStack_b0 = 0.0;
    uStack_ac = 0;
    uStack_a8 = 0;
    uStack_a4 = 0;
    cVar13 = FUN_00f94350();
    if ((cVar13 == '\0') || (*(int *)(param_2 + 0x170) == 0)) {
      pppuStack_5c = appuStack_74;
      uStack_58 = 0;
      uStack_56 = 0;
      uStack_54 = 0;
      cVar13 = FUN_00ce2b90(&uStack_9c,&pppuStack_5c,auStack_bc);
    }
    else {
      pppuStack_50 = appuStack_74;
      uStack_4c = 0;
      uStack_4a = 0;
      uStack_48 = 0;
      cVar13 = FUN_00ce2dc0(&uStack_9c,&pppuStack_50,*(int *)(param_2 + 0x170),auStack_bc);
    }
    if (cVar13 != '\0') {
      fStack_68 = fStack_b8 - fStack_2c;
      fStack_64 = fStack_b4 - fStack_30;
      fStack_60 = fStack_b0 - fStack_34;
      if (fStack_68 * fStack_68 + fStack_64 * fStack_64 + fStack_60 * fStack_60 <
          *param_5 * *param_5 + param_5[1] * param_5[1] + param_5[2] * param_5[2]) {
        *(ulonglong *)param_5 = CONCAT44(fStack_64,fStack_68);
        uStack_21 = 1;
        param_5[2] = fStack_60;
      }
    }
    uVar15 = uVar15 + 1;
    appuStack_74[0] = RBX::HitTestFilter::vftable;
    ppuStack_3c = RBX::HitTestFilter::vftable;
    ppuStack_44 = RBX::HitTestFilter::vftable;
  } while (uVar15 < 3);
  ExceptionList = pvStack_1c;
  return uStack_21;
}



/* FUNCTION 18570 ; VA 0x009b3690 ; FUN_009b3690 */

int FUN_009b3690(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_009c67e0();
    cVar2 = FUN_009d1e20(uVar3,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_0099ea40();
      iVar1 = *piVar4;
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 18571 ; VA 0x009b37e0 ; FUN_009b37e0 */

void __thiscall FUN_009b37e0(int param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined4 uStack_11c;
  int iStack_118;
  int iStack_114;
  int iStack_110;
  undefined4 uStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4863;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  uStack_4c = 0;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&iStack_38);
  iStack_8 = 0;
  if (((param_1 != 0) && (iVar10 = *(int *)(param_1 + 0x34), iVar10 != 0)) &&
     (iVar6 = *(int *)(iVar10 + 0xc), iStack_20 = iVar10, iVar5 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
     (uint)*(ushort *)(iVar5 + 0x1da))) {
    uVar9 = 0;
    uStack_18 = 0;
    iVar6 = FUN_005d6c30();
    if (iVar6 != 0) {
      do {
        iVar10 = *(int *)(**(int **)(iVar10 + 0x2c) + uVar9 * 8);
        if ((iVar10 == 0) ||
           (iVar6 = *(int *)(iVar10 + 0xc), iVar5 = FUN_00c8dce0(),
           (uint)*(ushort *)(iVar5 + 0x1da) <
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
          iVar10 = 0;
        }
        FUN_0060dcd0(&iStack_40,iVar10);
        piVar4 = piStack_3c;
        iStack_8._0_1_ = 1;
        iStack_14 = iStack_40;
        if (iStack_40 != 0) {
          iVar10 = *(int *)(iStack_40 + 0xc);
          iVar6 = thunk_FUN_00897b90();
          if ((uint)*(ushort *)(iVar6 + 0x1da) <
              (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
            bVar2 = true;
            piStack_44 = (int *)0x0;
            piVar7 = &iStack_48;
            iStack_14 = 0;
          }
          else {
            if (piVar4 != (int *)0x0) {
              LOCK();
              piVar4[1] = piVar4[1] + 1;
              UNLOCK();
            }
            piVar7 = &iStack_28;
            iStack_28 = iStack_14;
            bVar3 = true;
            piStack_24 = piVar4;
          }
          iStack_30 = iStack_14;
          iStack_2c = piVar7[1];
          iStack_1c = iStack_2c;
          *piVar7 = 0;
          piVar7[1] = 0;
          piVar7 = piStack_44;
          if ((bVar2) && (bVar2 = false, piStack_44 != (int *)0x0)) {
            LOCK();
            iVar10 = piStack_44[1] + -1;
            piStack_44[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_44)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar10 = *piVar1 + -1;
              *piVar1 = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          piVar7 = piStack_24;
          if ((bVar3) && (bVar3 = false, piStack_24 != (int *)0x0)) {
            LOCK();
            iVar10 = piStack_24[1] + -1;
            piStack_24[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar10 = *piVar1 + -1;
              *piVar1 = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          iStack_8._0_1_ = 2;
          uStack_11c = FUN_0088cdc0();
          iStack_114 = iStack_14;
          iStack_118 = 0;
          iStack_110 = iStack_1c;
          iStack_30 = 0;
          iStack_2c = 0;
          iStack_118 = FUN_006309e0();
          iVar10 = iStack_38;
          iStack_8 = CONCAT31(iStack_8._1_3_,3);
          if (*(int *)(iStack_38 + 8) == *(int *)(iStack_38 + 4)) {
            FUN_005ca4f0(*(int *)(iStack_38 + 4),&uStack_11c);
          }
          else {
            FUN_005caf00(&uStack_11c);
            *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 0xd0;
          }
          iStack_8._0_1_ = 4;
          if (iStack_118 != 0) {
            (**(code **)(iStack_118 + 8))(&iStack_114);
          }
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar10 = piVar4[1] + -1;
          piVar4[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar10 = piVar4[2] + -1;
            piVar4[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        iVar10 = iStack_20;
        uVar9 = uStack_18 + 1;
        uStack_18 = uVar9;
        uVar8 = FUN_005d6c30();
      } while (uVar9 < uVar8);
    }
  }
  *param_2 = iStack_38;
  param_2[1] = iStack_34;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18572 ; VA 0x009b3a80 ; FUN_009b3a80 */

undefined FUN_009b3a80(float *param_1,float *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  float10 fVar6;
  float fVar7;
  float fVar8;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  float fStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796ea0;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_11 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("BodyTypeScale",0xd);
  uStack_8 = 0;
  iVar2 = FUN_008a1240(auStack_30);
  if (iVar2 == 0) {
LAB_009b3b02:
    iVar2 = 0;
  }
  else {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar3 = FUN_00daf5e0();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) goto LAB_009b3b02;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  if (iVar2 != 0) {
    fVar6 = (float10)FUN_00cc2960();
    fStack_18 = (float)fVar6;
    fVar8 = 0.0;
    if (0.0 <= fStack_18) {
      fVar8 = fStack_18;
    }
    uStack_11 = 1;
    fVar7 = DAT_018ce2f8;
    if (fVar8 <= DAT_018ce2f8) {
      fVar7 = fVar8;
    }
    *param_1 = fVar7;
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("BodyProportionScale",0x13);
  uStack_8 = 1;
  iVar2 = FUN_008a1240(auStack_48);
  if (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar3 = FUN_00daf5e0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_009b3be4;
  }
  iVar2 = 0;
LAB_009b3be4:
  uStack_8 = 0xffffffff;
  if (0xf < uStack_34) {
    uVar5 = uStack_34 + 1;
    uVar4 = auStack_48[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_48[0] - 4);
      uVar5 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (iVar2 != 0) {
    fVar6 = (float10)FUN_00cc2960();
    fVar8 = 0.0;
    if (0.0 <= (float)fVar6) {
      fVar8 = (float)fVar6;
    }
    fVar7 = DAT_018ce2f8;
    if (fVar8 <= DAT_018ce2f8) {
      fVar7 = fVar8;
    }
    *param_2 = fVar7;
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 18573 ; VA 0x009b3ca0 ; FUN_009b3ca0 */

undefined4 __thiscall FUN_009b3ca0(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x228) != 0) {
    iVar1 = FUN_009b68d0(param_2);
    return *(undefined4 *)(param_1 + 0x378 + iVar1 * 8);
  }
  return *(undefined4 *)(param_1 + 0x340 + param_2 * 8);
}



/* FUNCTION 18574 ; VA 0x009b3ce0 ; FUN_009b3ce0 */

undefined4 * FUN_009b3ce0(uint param_1,char param_2)

{
  if (6 < param_1) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3b34) {
      FUN_016f3809(&DAT_01ee3b34);
      if (DAT_01ee3b34 == -1) {
        FUN_016f3654(&LAB_01886740);
        FUN_016f37bf(&DAT_01ee3b34);
      }
    }
    return &DAT_01d64eb0;
  }
  if (param_2 != '\0') {
    return (undefined4 *)(&DAT_01d64bb8 + param_1 * 0x18);
  }
  return (undefined4 *)(&DAT_01d64b10 + param_1 * 0x18);
}



/* FUNCTION 18575 ; VA 0x009b3d60 ; FUN_009b3d60 */

undefined4 FUN_009b3d60(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4878;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009b8c00(auStack_18);
  uStack_8 = 0;
  FUN_0089d950(param_1,3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18576 ; VA 0x009b3df0 ; FUN_009b3df0 */

undefined8 FUN_009b3df0(int *param_1,int *param_2)

{
  undefined8 uVar1;
  char cVar2;
  uint uVar3;
  undefined8 *puVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_1)();
  if (1 < uVar3) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = (**(code **)(*param_1 + 4))(2,&uStack_ec);
    if (cVar2 != '\0') {
      puVar4 = (undefined8 *)FUN_0088baa0();
      uVar1 = *puVar4;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((undefined8 *)*param_2 != (undefined8 *)0x0) {
    ExceptionList = pvStack_10;
    return *(undefined8 *)*param_2;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 18577 ; VA 0x009b3f30 ; FUN_009b3f30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_009b3f30(undefined4 *param_1,float *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  float *pfVar5;
  undefined4 *puVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  undefined auStack_c8 [12];
  undefined auStack_bc [36];
  undefined auStack_98 [8];
  float fStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined auStack_1c [4];
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  float fStack_8;
  
  FUN_00d226b0(&fStack_5c);
  pfVar5 = (float *)FUN_0071fcc0(auStack_c8);
  fVar7 = param_2[1];
  fVar8 = *param_2;
  fVar9 = param_2[2];
  fStack_24 = pfVar5[6] * fVar8 + pfVar5[7] * fVar7 + pfVar5[8] * fVar9 + pfVar5[0xb];
  fStack_28 = pfVar5[3] * fVar8 + pfVar5[4] * fVar7 + pfVar5[5] * fVar9 + pfVar5[10];
  fStack_2c = pfVar5[1] * fVar7 + fVar8 * *pfVar5 + pfVar5[2] * fVar9 + pfVar5[9];
  FUN_00d23e50(auStack_98,param_2);
  uStack_14._4_4_ = DAT_018ce2f8 / fStack_90;
  pfVar5 = (float *)FUN_01126580(auStack_1c);
  fStack_8 = pfVar5[1] * fStack_90;
  fStack_c = *pfVar5 * fStack_90;
  pfVar5 = (float *)FUN_00d5ab70(auStack_1c,&fStack_c);
  fStack_c = *pfVar5;
  fStack_8 = pfVar5[1];
  uStack_8c = _DAT_018e3fb0;
  uStack_88 = _UNK_018e3fb4;
  uStack_84 = _UNK_018e3fb8;
  uStack_80 = _UNK_018e3fbc;
  uStack_6c = 0x3f800000;
  fStack_68 = fStack_c * uStack_14._4_4_;
  fStack_64 = fStack_8 * uStack_14._4_4_;
  uStack_7c = _DAT_018e3fb0;
  uStack_78 = _UNK_018e3fb4;
  uStack_74 = _UNK_018e3fb8;
  uStack_70 = _UNK_018e3fbc;
  fStack_18 = fStack_24;
  fStack_60 = fStack_24;
  FUN_01162aa0(uStack_14._4_4_,0,0,0,uStack_14._4_4_,0,0,0,0x3f800000);
  fVar7 = fStack_68 * fStack_50;
  uStack_14 = (ulonglong)
              (uint)(fStack_64 * fStack_58 + fStack_68 * fStack_5c + fStack_60 * fStack_54 +
                    fStack_38);
  fVar9 = fStack_64 * fStack_4c;
  fVar8 = fStack_60 * fStack_48;
  fStack_18 = fStack_64 * fStack_40 + fStack_68 * fStack_44 + fStack_60 * fStack_3c + fStack_30;
  puVar6 = (undefined4 *)FUN_01160c20(auStack_bc,&uStack_8c);
  uVar1 = puVar6[1];
  uVar2 = puVar6[2];
  uVar3 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar2 = puVar6[5];
  uVar3 = puVar6[6];
  uVar4 = puVar6[7];
  uVar1 = puVar6[8];
  param_1[4] = puVar6[4];
  param_1[5] = uVar2;
  param_1[6] = uVar3;
  param_1[7] = uVar4;
  param_1[8] = uVar1;
  *(ulonglong *)(param_1 + 9) = CONCAT44(fVar9 + fVar7 + fVar8 + fStack_34,(int)uStack_14);
  param_1[0xb] = fStack_18;
  return param_1;
}



/* FUNCTION 18578 ; VA 0x009b41d0 ; FUN_009b41d0 */

undefined4 __thiscall FUN_009b41d0(int param_1,int param_2)

{
  undefined4 uVar1;
  
  if (param_2 == 0) {
    uVar1 = (**(code **)(*(int *)(param_1 + -0xa8) + 0x44))();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 18579 ; VA 0x009b4200 ; FUN_009b4200 */

float10 __thiscall FUN_009b4200(int param_1,int param_2)

{
  int iVar1;
  
  if (*(char *)(param_2 + 0x3d) != '\0') {
    return (float10)DAT_018e0028;
  }
  if ((*(int *)(param_1 + 0x174) != 0) && (*(int *)(param_2 + 0x2c) != 0)) {
    FUN_00f9efc0(*(int *)(param_1 + 0x174));
  }
  iVar1 = *(int *)(param_2 + 0x24);
  if (iVar1 != 0) {
    if (*(char *)(iVar1 + 4) != '\0') {
      FUN_00f958d0();
    }
    return (float10)*(float *)(iVar1 + 0x14);
  }
  if ((*(char *)(param_2 + 0x3c) != '\0') && (*(int *)(param_2 + 0x20) != param_2)) {
    return (float10)0.0;
  }
  return (float10)*(float *)(param_2 + 0x84);
}



/* FUNCTION 18580 ; VA 0x009b4290 ; FUN_009b4290 */

undefined4 __thiscall FUN_009b4290(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  char *unaff_EBX;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined4 ***apppuStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == 0) {
    unaff_EBX = "GetBodyPartR15 must be passed a non-nil part.";
    ExceptionList = &pvStack_10;
  }
  else {
    iVar2 = *(int *)(param_2 + 0x34);
    ExceptionList = &pvStack_10;
    if (((param_1 == 0) ||
        (iVar10 = *(int *)(param_1 + 0x34), ExceptionList = &pvStack_10, iVar10 == 0)) ||
       (iVar3 = *(int *)(iVar10 + 0xc), ExceptionList = &pvStack_10, iVar5 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
      iVar10 = 0;
    }
    if (iVar2 == iVar10) {
      FUN_0054ef60(*(undefined4 *)(param_2 + 0x28));
      puVar9 = &DAT_01d64c60;
      while( true ) {
        puVar6 = puVar9 + 1;
        ppppuVar7 = apppuStack_2c;
        if (0xf < uStack_18) {
          ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
        }
        if (0xf < (uint)puVar9[6]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        cVar4 = FUN_0055c360(puVar6,puVar9[5],ppppuVar7,uStack_1c);
        if (cVar4 != '\0') break;
        puVar9 = puVar9 + 7;
        if (puVar9 == &DAT_01d64e20) {
          if (0xf < uStack_18) {
            uVar8 = uStack_18 + 1;
            ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
            if (0xfff < uVar8) {
              ppppuVar7 = (undefined4 ****)apppuStack_2c[0][-1];
              uVar8 = uStack_18 + 0x24;
              if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(ppppuVar7,uVar8);
          }
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar2 = param_3[1] + -1;
            param_3[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*param_3)();
              LOCK();
              piVar1 = param_3 + 2;
              iVar2 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                (**(code **)(*param_3 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return 0x11;
        }
      }
      uStack_14 = *puVar9;
      if (0xf < uStack_18) {
        uVar8 = uStack_18 + 1;
        ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
        if (0xfff < uVar8) {
          ppppuVar7 = (undefined4 ****)apppuStack_2c[0][-1];
          uVar8 = uStack_18 + 0x24;
          if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar7,uVar8);
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar2 = param_3[1] + -1;
        param_3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uStack_14;
    }
  }
  FUN_00550130(unaff_EBX);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 18581 ; VA 0x009b4460 ; FUN_009b4460 */

undefined4 __thiscall FUN_009b4460(int param_1,uint param_2)

{
  int iVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  int iVar7;
  uint auStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iStack_14 = *(int *)(param_1 + 0x34);
    if (iStack_14 != 0) {
      iVar7 = *(int *)(iStack_14 + 0xc);
      ExceptionList = &pvStack_10;
      iVar1 = FUN_00b63e30();
      if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        iStack_1c = 0;
        uStack_18 = 0xf;
        auStack_2c[0] = auStack_2c[0] & 0xffffff00;
        puVar6 = &DAT_01d64c64;
        uStack_8 = 0;
        iVar7 = 0x10;
        do {
          if ((puVar6[-1] == param_2) && (auStack_2c != puVar6)) {
            puVar2 = puVar6;
            if (0xf < puVar6[5]) {
              puVar2 = (uint *)*puVar6;
            }
            FUN_005542c0(puVar2,puVar6[4]);
          }
          puVar6 = puVar6 + 7;
          iVar7 = iVar7 + -1;
        } while (iVar7 != 0);
        if (iStack_1c != 0) {
          uVar3 = FUN_008a1240(auStack_2c);
          if (0xf < uStack_18) {
            uVar5 = uStack_18 + 1;
            uVar4 = auStack_2c[0];
            if (0xfff < uVar5) {
              uVar4 = *(uint *)(auStack_2c[0] - 4);
              uVar5 = uStack_18 + 0x24;
              if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar4,uVar5);
          }
          ExceptionList = pvStack_10;
          return uVar3;
        }
        if (0xf < uStack_18) {
          uVar5 = uStack_18 + 1;
          uVar4 = auStack_2c[0];
          if (0xfff < uVar5) {
            uVar4 = *(uint *)(auStack_2c[0] - 4);
            uVar5 = uStack_18 + 0x24;
            if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar4,uVar5);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 18582 ; VA 0x009b45c0 ; FUN_009b45c0 */

void * __thiscall FUN_009b45c0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvVar6;
  int *piVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  pvVar6 = ExceptionList;
  if ((param_1 != 0) && (iVar2 = *(int *)(param_1 + 0x34), iVar2 != 0)) {
    iVar3 = *(int *)(iVar2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b63e30();
    pvVar6 = (void *)(uint)*(ushort *)(iVar5 + 0x1da);
    if (((void *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= pvVar6) &&
       (puVar8 = *(undefined4 **)(iVar2 + 0x2c), puVar8 != (undefined4 *)0x0)) {
      piVar7 = *(int **)(iVar2 + 0x30);
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        puVar8 = *(undefined4 **)(iVar2 + 0x2c);
        piVar7 = *(int **)(iVar2 + 0x30);
      }
      puVar4 = (undefined4 *)puVar8[1];
      puVar8 = (undefined4 *)*puVar8;
      uStack_8 = 0;
      for (; puVar8 != puVar4; puVar8 = puVar8 + 2) {
        if (puVar8[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar8[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        pvVar6 = (void *)FUN_009abd70(*puVar8,puVar8[1],param_2);
      }
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar1 = piVar7 + 1;
        iVar2 = *piVar1;
        pvVar6 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pvVar6 = (void *)(**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            pvVar6 = (void *)(**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 18583 ; VA 0x009b46d0 ; FUN_009b46d0 */

void __thiscall FUN_009b46d0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x32c);
  *param_2 = *(undefined8 *)(param_1 + 0x324);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 18584 ; VA 0x009b46f0 ; FUN_009b46f0 */

float10 __fastcall FUN_009b46f0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x24);
  if (iVar1 != 0) {
    if (*(char *)(iVar1 + 4) != '\0') {
      FUN_00f958d0();
    }
    return (float10)*(float *)(iVar1 + 0x14);
  }
  if ((*(char *)(param_1 + 0x3c) != '\0') && (*(int *)(param_1 + 0x20) != param_1)) {
    return (float10)0.0;
  }
  return (float10)*(float *)(param_1 + 0x84);
}



/* FUNCTION 18585 ; VA 0x009b4770 ; FUN_009b4770 */

void __thiscall FUN_009b4770(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar3 = param_2;
  (**(code **)(*param_1 + 0x10))(param_2);
  piVar4 = param_1 + -0x4d;
  if (piVar4 != (int *)0x0) {
    piVar1 = (int *)param_1[-0x40];
    if ((piVar1 != (int *)0x0) && (piVar4 = piVar1, piVar1[0xd] != 0)) {
      piVar4 = (int *)FUN_005c8ac0();
    }
    if ((((piVar4 != (int *)0x0) &&
         (iVar6 = piVar4[3], iVar5 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) && (iVar6 = FUN_0099ed80(), iVar6 != 0)) &&
       (piVar4 = *(int **)(iVar6 + 100), piVar4 != *(int **)(iVar6 + 0x68))) {
      do {
        param_2 = *(undefined4 *)(*piVar4 + 0xa8);
        puVar2 = *(undefined4 **)(iVar3 + 4);
        if (*(undefined4 **)(iVar3 + 8) == puVar2) {
          FUN_006030d0(puVar2,&param_2);
        }
        else {
          *puVar2 = param_2;
          *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 4;
        }
        piVar4 = piVar4 + 1;
      } while (piVar4 != *(int **)(iVar6 + 0x68));
    }
  }
  return;
}



/* FUNCTION 18586 ; VA 0x009b4820 ; FUN_009b4820 */

int FUN_009b4820(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_1 != 0) && (iVar1 = *(int *)(param_1 + 0x34), iVar1 != 0)) {
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      return iVar1;
    }
  }
  return 0;
}



/* FUNCTION 18587 ; VA 0x009b4870 ; FUN_009b4870 */

void FUN_009b4870(void)

{
  int iVar1;
  
  if (DAT_01ee3d64 == 0) {
    iVar1 = FUN_0099be20();
    DAT_01ee3d64 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 18588 ; VA 0x009b48a0 ; FUN_009b48a0 */

int FUN_009b48a0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_1 != 0) && (iVar1 = *(int *)(param_1 + 0x34), iVar1 != 0)) {
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      return iVar1;
    }
  }
  return 0;
}



/* FUNCTION 18589 ; VA 0x009b48f0 ; FUN_009b48f0 */

int FUN_009b48f0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799c39;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_018db5cc,4);
    uStack_8 = 0;
    bVar6 = true;
    uStack_14 = 1;
    iVar2 = FUN_008a0cb0(auStack_2c);
    if (iVar2 != 0) {
      iVar1 = *(int *)(iVar2 + 0xc);
      iVar3 = FUN_00aff8c0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_009b4977;
    }
  }
  iVar2 = 0;
LAB_009b4977:
  if ((bVar6) && (0xf < uStack_18)) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 18590 ; VA 0x009b49d0 ; FUN_009b49d0 */

void FUN_009b49d0(undefined4 param_1)

{
  FUN_0097bf90(param_1);
  FUN_009b48f0();
  return;
}



/* FUNCTION 18591 ; VA 0x009b49f0 ; FUN_009b49f0 */

undefined4 FUN_009b49f0(undefined4 param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_2 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar5 = *piVar6;
      if ((iVar5 != 0) &&
         (iVar3 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00e2c3f0(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) goto LAB_009b4a48;
    }
  }
  iVar5 = 0;
LAB_009b4a48:
  FUN_0060dcd0(param_1,iVar5);
  return param_1;
}



/* FUNCTION 18592 ; VA 0x009b4a60 ; FUN_009b4a60 */

undefined4 __fastcall FUN_009b4a60(int param_1)

{
  undefined4 uVar1;
  
  if (*(int **)(param_1 + 0x6f8) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x009b4a6c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(param_1 + 0x6f8) + 0x3c))();
    return uVar1;
  }
  return 0x12;
}



/* FUNCTION 18593 ; VA 0x009b4a80 ; FUN_009b4a80 */

bool __fastcall FUN_009b4a80(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x6f4) != 0) {
    iVar1 = (**(code **)(**(int **)(param_1 + 0x6f8) + 0x3c))();
    return iVar1 == 0xf;
  }
  return true;
}



/* FUNCTION 18594 ; VA 0x009b4ab0 ; FUN_009b4ab0 */

undefined4 __thiscall FUN_009b4ab0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x17c);
  return param_2;
}



/* FUNCTION 18595 ; VA 0x009b4ad0 ; FUN_009b4ad0 */

void FUN_009b4ad0(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  double dVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  fVar4 = *param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2];
  if (DAT_018f76ac < fVar4) {
    dVar3 = (double)fVar4;
    FUN_017267a0();
    fVar4 = param_2[1];
    fVar5 = DAT_018ce2f8 / (float)dVar3;
    fVar6 = *param_2;
    fVar1 = param_2[2];
    fVar7 = fVar4 * fVar5 * 0.0;
    fVar2 = fVar7 - fVar1 * fVar5;
    fVar7 = fVar6 * fVar5 - fVar7;
    fVar5 = fVar1 * fVar5 * 0.0 - fVar6 * fVar5 * 0.0;
    if (DAT_018f76ac < fVar5 * fVar5 + fVar2 * fVar2 + fVar7 * fVar7) {
      fVar8 = fVar7 * fVar4 - fVar5 * fVar1;
      fVar5 = fVar5 * fVar6 - fVar2 * fVar4;
      fVar4 = fVar2 * fVar1 - fVar7 * fVar6;
      dVar3 = (double)(fVar4 * fVar4 + fVar8 * fVar8 + fVar5 * fVar5);
      FUN_017267a0();
      fVar6 = DAT_018ce2f8 / (float)dVar3;
      *param_1 = fVar8 * fVar6;
      param_1[1] = fVar4 * fVar6;
      param_1[2] = fVar5 * fVar6;
      return;
    }
  }
  *param_1 = 0.0;
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  return;
}



/* FUNCTION 18596 ; VA 0x009b4c70 ; FUN_009b4c70 */

undefined4 __fastcall FUN_009b4c70(int param_1)

{
  int iVar1;
  
  if (((*(int *)(param_1 + 0x3a4) != 0) &&
      (iVar1 = *(int *)(*(int *)(param_1 + 0x3a4) + 0xa8), iVar1 != 0)) && (iVar1 != -0x50)) {
    return *(undefined4 *)(iVar1 + 0x70);
  }
  return 0;
}



/* FUNCTION 18597 ; VA 0x009b4ca0 ; FUN_009b4ca0 */

int __fastcall FUN_009b4ca0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar5 = *(int *)(param_1 + 0x348);
  }
  else {
    iVar5 = *(int *)(param_1 + 0x378);
  }
  if (iVar5 != 0) {
    puVar1 = *(undefined4 **)(iVar5 + 0x2c);
    if (puVar1 != (undefined4 *)0x0) {
      piVar2 = (int *)puVar1[1];
      for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
        iVar5 = *piVar6;
        if ((iVar5 != 0) &&
           (iVar3 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00cffc50(),
           (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
           (uint)*(ushort *)(iVar4 + 0x1da))) {
          return iVar5;
        }
      }
    }
    return 0;
  }
  return 0;
}



/* FUNCTION 18598 ; VA 0x009b4cd0 ; FUN_009b4cd0 */

void FUN_009b4cd0(void)

{
  FUN_009b48f0();
  return;
}



/* FUNCTION 18599 ; VA 0x009b4ce0 ; FUN_009b4ce0 */

int __fastcall FUN_009b4ce0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar5 = *(int *)(param_1 + 0x348);
  }
  else {
    iVar5 = *(int *)(param_1 + 0x378);
  }
  if (iVar5 != 0) {
    puVar1 = *(undefined4 **)(iVar5 + 0x2c);
    if (puVar1 != (undefined4 *)0x0) {
      piVar2 = (int *)puVar1[1];
      for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
        iVar5 = *piVar6;
        if ((iVar5 != 0) &&
           (iVar3 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00db9c60(),
           (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
           (uint)*(ushort *)(iVar4 + 0x1da))) {
          return iVar5;
        }
      }
    }
    return 0;
  }
  return 0;
}



/* FUNCTION 18600 ; VA 0x009b4d10 ; FUN_009b4d10 */

undefined4 __fastcall FUN_009b4d10(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x348);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x378);
  }
  if (iVar1 != 0) {
    return *(undefined4 *)(iVar1 + 0xa8);
  }
  return 0;
}



/* FUNCTION 18601 ; VA 0x009b4d50 ; FUN_009b4d50 */

undefined4 __fastcall FUN_009b4d50(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 0x378);
  }
  return *(undefined4 *)(param_1 + 0x348);
}



/* FUNCTION 18602 ; VA 0x009b4d90 ; FUN_009b4d90 */

float10 __fastcall FUN_009b4d90(int param_1)

{
  return (float10)(float)(**(uint **)(param_1 + 0x218) ^ (uint)*(uint **)(param_1 + 0x218));
}



/* FUNCTION 18603 ; VA 0x009b4db0 ; FUN_009b4db0 */

float10 __fastcall FUN_009b4db0(int param_1)

{
  int iVar1;
  
  if (((*(int *)(param_1 + 0x3f8) == 0) ||
      (iVar1 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar1 == 0)) || (iVar1 == -0x50)) {
    iVar1 = 0;
  }
  else {
    iVar1 = *(int *)(iVar1 + 0x70);
  }
  iVar1 = *(int *)(*(int *)(*(int *)(iVar1 + 0x20) + 0x2c) + 0x14);
  return (float10)((float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]) *
                  *(float *)(*(int *)(param_1 + 0x6f4) + 0x610));
}



/* FUNCTION 18604 ; VA 0x009b4e20 ; FUN_009b4e20 */

float10 __fastcall FUN_009b4e20(int param_1)

{
  return (float10)(float)(**(int **)(param_1 + 0x210) + (int)*(int **)(param_1 + 0x210));
}



/* FUNCTION 18605 ; VA 0x009b4e40 ; FUN_009b4e40 */

float10 __fastcall FUN_009b4e40(int param_1)

{
  return (float10)(float)(**(uint **)(param_1 + 0x208) ^ (uint)*(uint **)(param_1 + 0x208));
}



/* FUNCTION 18606 ; VA 0x009b4e60 ; FUN_009b4e60 */

undefined4 __fastcall FUN_009b4e60(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 0x3d0);
  }
  return *(undefined4 *)(param_1 + 0x358);
}



/* FUNCTION 18607 ; VA 0x009b4e80 ; FUN_009b4e80 */

undefined4 __fastcall FUN_009b4e80(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 0x3a0);
  }
  return *(undefined4 *)(param_1 + 0x368);
}



/* FUNCTION 18608 ; VA 0x009b4ea0 ; FUN_009b4ea0 */

undefined4 __thiscall FUN_009b4ea0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  char *unaff_EBX;
  int iVar6;
  undefined4 ***apppuStack_28 [3];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == 0) {
    unaff_EBX = "GetLimb must be passed a non-nil part.";
    ExceptionList = &pvStack_10;
  }
  else {
    iVar1 = *(int *)(param_2 + 0x34);
    ExceptionList = &pvStack_10;
    if (((param_1 == 0) ||
        (iVar6 = *(int *)(param_1 + 0x34), ExceptionList = &pvStack_10, iVar6 == 0)) ||
       (iVar2 = *(int *)(iVar6 + 0xc), ExceptionList = &pvStack_10, iVar4 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
      iVar6 = 0;
    }
    if (iVar1 == iVar6) {
      FUN_0054ef60(*(undefined4 *)(param_2 + 0x28));
      ppppuVar5 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar5 = (undefined4 ****)apppuStack_28[0];
      }
      cVar3 = FUN_0055c360(ppppuVar5,uStack_18,&DAT_018db5cc,4);
      if (cVar3 != '\0') {
        FUN_005507b0();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 0;
      }
      ppppuVar5 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar5 = (undefined4 ****)apppuStack_28[0];
      }
      cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"Torso",5);
      if (cVar3 == '\0') {
        ppppuVar5 = apppuStack_28;
        if (0xf < uStack_14) {
          ppppuVar5 = (undefined4 ****)apppuStack_28[0];
        }
        cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LowerTorso",10);
        if (cVar3 == '\0') {
          ppppuVar5 = apppuStack_28;
          if (0xf < uStack_14) {
            ppppuVar5 = (undefined4 ****)apppuStack_28[0];
          }
          cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"UpperTorso",10);
          if (cVar3 == '\0') {
            ppppuVar5 = apppuStack_28;
            if (0xf < uStack_14) {
              ppppuVar5 = (undefined4 ****)apppuStack_28[0];
            }
            cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"Left Arm",8);
            if (cVar3 == '\0') {
              ppppuVar5 = apppuStack_28;
              if (0xf < uStack_14) {
                ppppuVar5 = (undefined4 ****)apppuStack_28[0];
              }
              cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LeftUpperArm",0xc);
              if (cVar3 == '\0') {
                ppppuVar5 = apppuStack_28;
                if (0xf < uStack_14) {
                  ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                }
                cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LeftLowerArm",0xc);
                if (cVar3 == '\0') {
                  ppppuVar5 = apppuStack_28;
                  if (0xf < uStack_14) {
                    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                  }
                  cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LeftHand",8);
                  if (cVar3 == '\0') {
                    ppppuVar5 = apppuStack_28;
                    if (0xf < uStack_14) {
                      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                    }
                    cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"Right Arm",9);
                    if (cVar3 == '\0') {
                      ppppuVar5 = apppuStack_28;
                      if (0xf < uStack_14) {
                        ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                      }
                      cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"RightUpperArm",0xd);
                      if (cVar3 == '\0') {
                        ppppuVar5 = apppuStack_28;
                        if (0xf < uStack_14) {
                          ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                        }
                        cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"RightLowerArm",0xd);
                        if (cVar3 == '\0') {
                          ppppuVar5 = apppuStack_28;
                          if (0xf < uStack_14) {
                            ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                          }
                          cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"RightHand",9);
                          if (cVar3 == '\0') {
                            ppppuVar5 = apppuStack_28;
                            if (0xf < uStack_14) {
                              ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                            }
                            cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"Right Leg",9);
                            if (cVar3 == '\0') {
                              ppppuVar5 = apppuStack_28;
                              if (0xf < uStack_14) {
                                ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                              }
                              cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"RightUpperLeg",0xd);
                              if (cVar3 == '\0') {
                                ppppuVar5 = apppuStack_28;
                                if (0xf < uStack_14) {
                                  ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                                }
                                cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"RightLowerLeg",0xd);
                                if (cVar3 == '\0') {
                                  ppppuVar5 = apppuStack_28;
                                  if (0xf < uStack_14) {
                                    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                                  }
                                  cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"RightFoot",9);
                                  if (cVar3 == '\0') {
                                    ppppuVar5 = apppuStack_28;
                                    if (0xf < uStack_14) {
                                      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                                    }
                                    cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"Left Leg",8);
                                    if (cVar3 == '\0') {
                                      ppppuVar5 = apppuStack_28;
                                      if (0xf < uStack_14) {
                                        ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                                      }
                                      cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LeftUpperLeg",0xc);
                                      if (cVar3 == '\0') {
                                        ppppuVar5 = apppuStack_28;
                                        if (0xf < uStack_14) {
                                          ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                                        }
                                        cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LeftLowerLeg",0xc)
                                        ;
                                        if (cVar3 == '\0') {
                                          ppppuVar5 = apppuStack_28;
                                          if (0xf < uStack_14) {
                                            ppppuVar5 = (undefined4 ****)apppuStack_28[0];
                                          }
                                          cVar3 = FUN_0055c360(ppppuVar5,uStack_18,"LeftFoot",8);
                                          if (cVar3 == '\0') {
                                            FUN_005507b0();
                                            FUN_00550b30();
                                            ExceptionList = pvStack_10;
                                            return 6;
                                          }
                                        }
                                      }
                                    }
                                    FUN_005507b0();
                                    FUN_00550b30();
                                    ExceptionList = pvStack_10;
                                    return 4;
                                  }
                                }
                              }
                            }
                            FUN_005507b0();
                            FUN_00550b30();
                            ExceptionList = pvStack_10;
                            return 5;
                          }
                        }
                      }
                    }
                    FUN_005507b0();
                    FUN_00550b30();
                    ExceptionList = pvStack_10;
                    return 3;
                  }
                }
              }
            }
            FUN_005507b0();
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 2;
          }
        }
      }
      FUN_005507b0();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  FUN_00550130(unaff_EBX);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 18609 ; VA 0x009b52d0 ; FUN_009b52d0 */

undefined4 FUN_009b52d0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_0097bf90(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_009ba890();
    return uVar2;
  }
  return 0;
}



/* FUNCTION 18610 ; VA 0x009b52ef ; FUN_009b52ef */

void FUN_009b52ef(void)

{
  FUN_009b5300();
  return;
}



/* FUNCTION 18611 ; VA 0x009b5300 ; FUN_009b5300 */

undefined4 * __thiscall FUN_009b5300(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  
  if (*(int *)(param_1 + -0x5bc) == 0) {
    iVar5 = *(int *)(param_1 + -0x49c);
  }
  else {
    iVar5 = *(int *)(param_1 + -0x46c);
  }
  if (iVar5 != 0) {
    puVar4 = (undefined4 *)FUN_00b077e0();
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *param_2 = *puVar4;
    param_2[1] = uVar1;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    uVar1 = puVar4[5];
    uVar2 = puVar4[6];
    uVar3 = puVar4[7];
    param_2[4] = puVar4[4];
    param_2[5] = uVar1;
    param_2[6] = uVar2;
    param_2[7] = uVar3;
    uVar1 = puVar4[9];
    uVar2 = puVar4[10];
    uVar3 = puVar4[0xb];
    param_2[8] = puVar4[8];
    param_2[9] = uVar1;
    param_2[10] = uVar2;
    param_2[0xb] = uVar3;
    return param_2;
  }
  FUN_0060efa0();
  return param_2;
}



/* FUNCTION 18612 ; VA 0x009b5360 ; FUN_009b5360 */

int __fastcall FUN_009b5360(int param_1)

{
  uint *puVar1;
  uint3 uVar2;
  
  puVar1 = *(uint **)(param_1 + 0x1fc);
  uVar2 = (uint3)((uint)puVar1 >> 8);
  if (((float)(*puVar1 ^ (uint)puVar1) <= 0.0) && (*(char *)(param_1 + 0x2e5) != '\0')) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 18613 ; VA 0x009b5390 ; FUN_009b5390 */

undefined4 __fastcall FUN_009b5390(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (((DAT_01d64a68 == '\0') || (*(char *)(param_1 + 0x23a) != '\0')) &&
     (*(char *)(param_1 + 0x2e6) == '\0')) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar1 = *(int *)(param_1 + 0x348);
      iVar2 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar1 = *(int *)(param_1 + 0x378);
      iVar2 = *(int *)(param_1 + 0x380);
    }
    if (((iVar1 != 0) && (iVar2 != 0)) &&
       (iVar1 = FUN_00c15be0(*(undefined4 *)(iVar1 + 0xa8),*(undefined4 *)(iVar2 + 0xa8),0),
       iVar1 != 0)) {
      *(undefined *)(param_1 + 0x2e4) = 1;
      return 0;
    }
    if (*(char *)(param_1 + 0x2e4) != '\0') {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 18614 ; VA 0x009b5410 ; FUN_009b5410 */

void __thiscall FUN_009b5410(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x1c4);
  *param_2 = *(undefined8 *)(param_1 + 0x1bc);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 18615 ; VA 0x009b5430 ; FUN_009b5430 */

float10 __fastcall FUN_009b5430(int param_1)

{
  return (float10)*(float *)(param_1 + 0x14);
}



/* FUNCTION 18616 ; VA 0x009b5440 ; FUN_009b5440 */

float10 __fastcall FUN_009b5440(int param_1)

{
  return (float10)(float)(**(int **)(param_1 + 0x200) + (int)*(int **)(param_1 + 0x200));
}



/* FUNCTION 18617 ; VA 0x009b5460 ; FUN_009b5460 */

float10 __fastcall FUN_009b5460(int param_1)

{
  return (float10)(float)(**(uint **)(param_1 + 0x214) ^ (uint)*(uint **)(param_1 + 0x214));
}



/* FUNCTION 18618 ; VA 0x009b54b0 ; FUN_009b54b0 */

int __fastcall FUN_009b54b0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x348);
    iVar2 = *(int *)(param_1 + 0x370);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x378);
    iVar2 = *(int *)(param_1 + 0x380);
  }
  if ((iVar1 == 0) || (iVar2 == 0)) {
    iVar1 = 0;
  }
  else {
    iVar1 = FUN_00c15be0(*(undefined4 *)(iVar1 + 0xa8),*(undefined4 *)(iVar2 + 0xa8),0);
    if (iVar1 != 0) {
      *(undefined *)(param_1 + 0x2e4) = 1;
      return iVar1;
    }
  }
  return iVar1;
}



/* FUNCTION 18619 ; VA 0x009b5540 ; FUN_009b5540 */

int FUN_009b5540(char param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 == 0) && (param_1 == '\0')) {
    return 0;
  }
  iVar1 = FUN_008a4100();
  return iVar1 + 0xa0;
}



/* FUNCTION 18620 ; VA 0x009b5570 ; FUN_009b5570 */

undefined8 * FUN_009b5570(undefined8 *param_1,int param_2,float *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  char cVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 *puVar11;
  uint uVar12;
  char *pcVar13;
  int *piVar14;
  undefined4 *puStack_a4;
  uint uStack_a0;
  int *piStack_9c;
  int **ppiStack_98;
  undefined auStack_8c [24];
  int *piStack_74;
  undefined8 uStack_6c;
  float fStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  uint auStack_40 [3];
  code *pcStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  code *pcStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d48ec;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  uStack_30 = 0;
  piStack_2c = (int *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar13 = PTR_DAT_01d64a08;
  do {
    cVar7 = *pcVar13;
    pcVar13 = pcVar13 + 1;
  } while (cVar7 != '\0');
  ppiStack_98 = (int **)((int)pcVar13 - (int)(PTR_DAT_01d64a08 + 1));
  piStack_9c = (int *)PTR_DAT_01d64a08;
  uStack_a0 = 0x9b55c7;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  ppiStack_98 = (int **)auStack_40;
  uStack_8 = 0;
  piStack_9c = (int *)0x9b55da;
  iVar8 = FUN_008a1240();
  if (iVar8 != 0) {
    iVar1 = *(int *)(iVar8 + 0xc);
    ppiStack_98 = (int **)0x9b55e8;
    iVar9 = FUN_00dafce0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
        (uint)*(ushort *)(iVar9 + 0x1da)) goto LAB_009b5605;
  }
  iVar8 = 0;
LAB_009b5605:
  uStack_8 = 0xffffffff;
  if (0xf < piStack_2c) {
    ppiStack_98 = (int **)((int)piStack_2c + 1);
    uVar12 = auStack_40[0];
    if (0xfff < ppiStack_98) {
      uVar12 = *(uint *)(auStack_40[0] - 4);
      ppiStack_98 = (int **)((int)piStack_2c + 0x24);
      if (0x1f < (auStack_40[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        ppiStack_98 = (int **)0x9b5a9e;
        FUN_017167a3();
      }
    }
    uStack_a0 = 0x9b563d;
    piStack_9c = (int *)uVar12;
    FUN_01674ea0();
  }
  uStack_30 = 0;
  piStack_2c = (int *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (iVar8 != 0) {
    uVar10 = *(undefined4 *)(iVar8 + 0x5c);
    *param_1 = *(undefined8 *)(iVar8 + 0x54);
    *(undefined4 *)(param_1 + 1) = uVar10;
    ExceptionList = pvStack_10;
    return param_1;
  }
  ppiStack_98 = (int **)&uStack_6c;
  piStack_9c = (int *)0x9b5688;
  FUN_00a6bd00();
  if (((*(int *)(param_2 + 0x34) != 0) &&
      (iVar8 = *(int *)(*(int *)(param_2 + 0x34) + 0x34), iVar8 != 0)) &&
     (puVar11 = *(undefined4 **)(iVar8 + 0x2c), puVar11 != (undefined4 *)0x0)) {
    piVar2 = (int *)puVar11[1];
    for (piVar14 = (int *)*puVar11; piVar14 != piVar2; piVar14 = piVar14 + 2) {
      pcStack_18 = (code *)*piVar14;
      if (pcStack_18 != (code *)0x0) {
        iStack_1c = *(int *)((int)pcStack_18 + 0xc);
        ppiStack_98 = (int **)0x9b56ba;
        iVar8 = FUN_0099be20();
        if ((uint)*(ushort *)(iStack_1c + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
            (uint)*(ushort *)(iVar8 + 0x1da)) {
          if (pcStack_18 != (code *)0x0) {
            ppiStack_98 = (int **)0x13;
            piStack_9c = (int *)0x18db4bc;
            uStack_30 = 0;
            piStack_2c = (int *)0xf;
            auStack_40[0] = auStack_40[0] & 0xffffff00;
            uStack_a0 = 0x9b57b8;
            FUN_005542c0();
            ppiStack_98 = (int **)auStack_40;
            uStack_8 = 1;
            piStack_9c = (int *)0x9b57ca;
            iVar8 = FUN_008a1240();
            cStack_11 = iVar8 == 0;
            uStack_8 = 0xffffffff;
            ppiStack_98 = (int **)0x9b57df;
            FUN_005507b0();
            if (cStack_11 != '\0') {
              fStack_64 = fStack_64 / param_3[2];
              uStack_6c = CONCAT44(uStack_6c._4_4_ / param_3[1],(float)uStack_6c / *param_3);
              piStack_4c = (int *)fStack_64;
            }
          }
          break;
        }
      }
    }
  }
  ppiStack_98 = &piStack_48;
  piStack_9c = (int *)0x9b56ef;
  FUN_0099ef10();
  iStack_1c = 1;
  uStack_8 = 2;
  uStack_50 = 0;
  piStack_4c = (int *)&DAT_0000000f;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  pcStack_18 = *(code **)(*piStack_48 + 0x38);
  param_3 = (float *)(PTR_DAT_01d64a08 + 1);
  pcVar13 = PTR_DAT_01d64a08;
  do {
    cVar7 = *pcVar13;
    pcVar13 = pcVar13 + 1;
  } while (cVar7 != '\0');
  ppiStack_98 = (int **)((int)pcVar13 - (int)param_3);
  piStack_9c = (int *)PTR_DAT_01d64a08;
  uStack_a0 = 0x9b5744;
  FUN_005542c0();
  ppiStack_98 = (int **)auStack_60;
  uStack_8._0_1_ = 3;
  piStack_9c = (int *)0x9b5751;
  (*pcStack_18)();
  uStack_8._0_1_ = 2;
  uVar6 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (&DAT_0000000f < piStack_4c) {
    piStack_9c = (int *)((int)piStack_4c + 1);
    uVar12 = auStack_60[0];
    if ((int *)0xfff < piStack_9c) {
      uVar12 = *(uint *)(auStack_60[0] - 4);
      piStack_9c = piStack_4c + 9;
      if (0x1f < (auStack_60[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_9c = (int *)&UNK_009b5aa3;
        uStack_8._0_1_ = uVar6;
        FUN_017167a3();
      }
    }
    puStack_a4 = (undefined4 *)0x9b582b;
    uStack_a0 = uVar12;
    FUN_01674ea0();
  }
  piStack_9c = (int *)&uStack_6c;
  uStack_a0 = 0x9b583a;
  FUN_00db5810();
  piStack_9c = (int *)0x0;
  puStack_a4 = (undefined4 *)0x9b5845;
  uStack_a0 = param_2;
  FUN_008a65e0();
  piStack_9c = (int *)0x9b584c;
  iVar8 = FUN_008a4100();
  pcStack_18 = (code *)(iVar8 + 8);
  pcStack_34 = FUN_009ab8e0;
  piStack_9c = (int *)(uint)DAT_01ee37b5;
  uStack_30 = 0xfffffecc;
  FUN_0060dcd0(&puStack_a4,param_2);
  puStack_24 = (undefined4 *)FUN_0099e2b0(auStack_8c,CONCAT44(uStack_30,pcStack_34),0,uStack_20);
  uStack_8._0_1_ = 5;
  uVar10 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 6;
  uStack_28 = uVar10;
  piStack_2c = (int *)FUN_01674e20(0x38);
  if (piStack_2c == (undefined4 *)0x0) {
    puVar11 = (undefined4 *)0x0;
  }
  else {
    *piStack_2c = 0;
    piStack_2c[1] = 1;
    piStack_2c[2] = (int)FUN_009b0530;
    piStack_2c[3] = (int)FUN_009b07d0;
    piStack_2c[4] = 0;
    piStack_2c[5] = (int)pcStack_18;
    uVar3 = puStack_24[1];
    uVar4 = puStack_24[2];
    uVar5 = puStack_24[3];
    piStack_2c[6] = *puStack_24;
    piStack_2c[7] = uVar3;
    piStack_2c[8] = uVar4;
    piStack_2c[9] = uVar5;
    piStack_2c[10] = puStack_24[4];
    piStack_2c[0xb] = 0;
    piStack_2c[0xc] = 0;
    if (puStack_24[6] != 0) {
      LOCK();
      piVar2 = (int *)(puStack_24[6] + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    piStack_2c[0xb] = puStack_24[5];
    piStack_2c[0xc] = puStack_24[6];
    puVar11 = piStack_2c;
  }
  uStack_a0 = 0x9b5932;
  piStack_9c = puVar11;
  FUN_016797d0();
  if (puVar11 != (undefined4 *)0x0) {
    LOCK();
    puVar11[1] = puVar11[1] + 1;
    UNLOCK();
  }
  iStack_1c = 3;
  uStack_8._0_1_ = 7;
  uStack_a0 = 0x9b5956;
  param_3 = (float *)puVar11;
  piStack_9c = (int *)uVar10;
  FUN_01675290();
  uStack_a0 = param_2;
  puStack_a4 = &uStack_50;
  uStack_8._0_1_ = 5;
  puVar11 = (undefined4 *)FUN_0060dcd0();
  uStack_30 = *puVar11;
  piVar2 = (int *)puVar11[1];
  *puVar11 = 0;
  puVar11[1] = 0;
  piStack_9c = &uStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  uStack_a0 = 0x9b5997;
  piStack_2c = piVar2;
  FUN_009a4d30();
  piStack_9c = (int *)&param_3;
  uStack_a0 = 0x9b59a5;
  cVar7 = FUN_01679300();
  if (cVar7 != '\0') {
    piStack_9c = (int *)0x9b59b0;
    FUN_01679490();
    piStack_9c = (int *)&param_3;
    uStack_a0 = 0x9b59bb;
    FUN_016791c0();
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar8 = piVar2[1] + -1;
    piVar2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      piStack_9c = (int *)0x9b59d1;
      (**(code **)*piVar2)();
      LOCK();
      iVar8 = piVar2[2] + -1;
      piVar2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        piStack_9c = (int *)0x9b59e1;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      piStack_9c = (int *)0x9b59f7;
      (**(code **)*piStack_4c)();
      LOCK();
      piVar14 = piVar2 + 2;
      iVar8 = *piVar14 + -1;
      *piVar14 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        piStack_9c = (int *)0x9b5a07;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (float *)0x0) {
    piVar2 = (int *)(param_3 + 1);
    LOCK();
    iVar8 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      piStack_9c = (int *)param_3;
      uStack_a0 = 0x9b5a24;
      FUN_01674ea0();
    }
  }
  if (piStack_74 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_74[1] + -1;
    piStack_74[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      piStack_9c = (int *)0x9b5a3d;
      (**(code **)*piStack_74)();
      LOCK();
      iVar8 = piStack_74[2] + -1;
      piStack_74[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        piStack_9c = (int *)0x9b5a4d;
        (**(code **)(*piStack_74 + 4))();
      }
    }
  }
  *param_1 = uStack_6c;
  *(float *)(param_1 + 1) = fStack_64;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_44[1] + -1;
    piStack_44[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      piStack_9c = (int *)0x9b5a75;
      (**(code **)*piStack_44)();
      LOCK();
      piVar2 = piStack_44 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        piStack_9c = (int *)0x9b5a84;
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18621 ; VA 0x009b5ac0 ; FUN_009b5ac0 */

undefined8 * FUN_009b5ac0(undefined8 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  char *pcVar13;
  uint uVar14;
  undefined *puStack_88;
  uint uStack_84;
  undefined4 **ppuStack_80;
  int **ppiStack_7c;
  undefined auStack_70 [24];
  int *piStack_58;
  undefined auStack_50 [4];
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  uint auStack_40 [3];
  code *pcStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4951;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_30 = 0;
  piStack_2c = (int *)0xf;
  ExceptionList = &pvStack_10;
  *param_1 = *(undefined8 *)(param_2 + 0x54);
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 0x5c);
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar13 = PTR_DAT_01d64a0c;
  do {
    cVar8 = *pcVar13;
    pcVar13 = pcVar13 + 1;
  } while (cVar8 != '\0');
  ppiStack_7c = (int **)((int)pcVar13 - (int)(PTR_DAT_01d64a0c + 1));
  ppuStack_80 = (undefined4 **)PTR_DAT_01d64a0c;
  uStack_84 = 0x9b5b33;
  FUN_005542c0();
  ppiStack_7c = (int **)auStack_40;
  uStack_8 = 0;
  ppuStack_80 = (undefined4 **)0x9b5b45;
  iVar9 = FUN_008a1240();
  if (iVar9 != 0) {
    iVar2 = *(int *)(iVar9 + 0xc);
    ppiStack_7c = (int **)0x9b5b53;
    iVar10 = FUN_00dafce0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
        (uint)*(ushort *)(iVar10 + 0x1da)) goto LAB_009b5b72;
  }
  iVar9 = 0;
LAB_009b5b72:
  uStack_8 = 0xffffffff;
  if (0xf < piStack_2c) {
    ppiStack_7c = (int **)((int)piStack_2c + 1);
    uVar14 = auStack_40[0];
    if (0xfff < ppiStack_7c) {
      uVar14 = *(uint *)(auStack_40[0] - 4);
      ppiStack_7c = (int **)((int)piStack_2c + 0x24);
      if (0x1f < (auStack_40[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
        ppiStack_7c = (int **)0x9b5ed9;
        FUN_017167a3();
      }
    }
    uStack_84 = 0x9b5baa;
    ppuStack_80 = (undefined4 **)uVar14;
    FUN_01674ea0();
  }
  uStack_30 = 0;
  piStack_2c = (int *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (iVar9 == 0) {
    ppiStack_7c = &piStack_48;
    ppuStack_80 = (undefined4 **)0x9b5be3;
    FUN_0099ef10();
    uStack_1c = 1;
    uStack_8 = 1;
    uStack_30 = 0;
    piStack_2c = (int *)0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    pcVar3 = *(code **)(*piStack_48 + 0x38);
    puStack_18 = PTR_DAT_01d64a0c + 1;
    pcVar13 = PTR_DAT_01d64a0c;
    do {
      cVar8 = *pcVar13;
      pcVar13 = pcVar13 + 1;
    } while (cVar8 != '\0');
    ppiStack_7c = (int **)((int)pcVar13 - (int)puStack_18);
    ppuStack_80 = (undefined4 **)PTR_DAT_01d64a0c;
    uStack_84 = 0x9b5c34;
    FUN_005542c0();
    ppiStack_7c = (int **)auStack_40;
    uStack_8._0_1_ = 2;
    ppuStack_80 = (undefined4 **)0x9b5c40;
    (*pcVar3)();
    uStack_8._0_1_ = 1;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < piStack_2c) {
      ppuStack_80 = (undefined4 **)((int)piStack_2c + 1);
      uVar14 = auStack_40[0];
      if (0xfff < ppuStack_80) {
        uVar14 = *(uint *)(auStack_40[0] - 4);
        ppuStack_80 = (undefined4 **)((int)piStack_2c + 0x24);
        if (0x1f < (auStack_40[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
          ppuStack_80 = (undefined4 **)&UNK_009b5ede;
          uStack_8._0_1_ = uVar7;
          FUN_017167a3();
        }
      }
      puStack_88 = (undefined *)0x9b5c75;
      uStack_84 = uVar14;
      FUN_01674ea0();
    }
    ppuStack_80 = (undefined4 **)param_1;
    uStack_84 = 0x9b5c84;
    FUN_00db5810();
    ppuStack_80 = (undefined4 **)0x0;
    uStack_84 = param_2;
    puStack_88 = (undefined *)0x9b5c92;
    FUN_008a65e0();
    ppuStack_80 = (undefined4 **)0x9b5c99;
    iVar9 = FUN_008a4100();
    puStack_18 = (undefined *)(iVar9 + 8);
    pcStack_34 = FUN_009ab8e0;
    ppuStack_80 = (undefined4 **)(uint)DAT_01ee37b5;
    uStack_30 = 0xfffffecc;
    FUN_0060dcd0(&puStack_88,param_2);
    puStack_24 = (undefined4 *)FUN_0099e2b0(auStack_70,CONCAT44(uStack_30,pcStack_34),0,uStack_20);
    uStack_8._0_1_ = 4;
    uVar11 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 5;
    uStack_28 = uVar11;
    piStack_2c = (int *)FUN_01674e20(0x38);
    if (piStack_2c == (undefined4 *)0x0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      *piStack_2c = 0;
      piStack_2c[1] = 1;
      piStack_2c[2] = (int)FUN_009b0530;
      piStack_2c[3] = (int)FUN_009b07d0;
      piStack_2c[4] = 0;
      piStack_2c[5] = (int)puStack_18;
      uVar4 = puStack_24[1];
      uVar5 = puStack_24[2];
      uVar6 = puStack_24[3];
      piStack_2c[6] = *puStack_24;
      piStack_2c[7] = uVar4;
      piStack_2c[8] = uVar5;
      piStack_2c[9] = uVar6;
      piStack_2c[10] = puStack_24[4];
      piStack_2c[0xb] = 0;
      piStack_2c[0xc] = 0;
      if (puStack_24[6] != 0) {
        LOCK();
        piVar1 = (int *)(puStack_24[6] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piStack_2c[0xb] = puStack_24[5];
      piStack_2c[0xc] = puStack_24[6];
      puVar12 = piStack_2c;
    }
    uStack_84 = 0x9b5d7c;
    ppuStack_80 = (undefined4 **)puVar12;
    FUN_016797d0();
    if (puVar12 != (undefined4 *)0x0) {
      LOCK();
      puVar12[1] = puVar12[1] + 1;
      UNLOCK();
    }
    uStack_1c = 3;
    uStack_8._0_1_ = 6;
    uStack_84 = 0x9b5da0;
    ppuStack_80 = (undefined4 **)uVar11;
    puStack_14 = puVar12;
    FUN_01675290();
    puStack_88 = auStack_50;
    uStack_84 = param_2;
    uStack_8._0_1_ = 4;
    puVar12 = (undefined4 *)FUN_0060dcd0();
    uStack_30 = *puVar12;
    piVar1 = (int *)puVar12[1];
    *puVar12 = 0;
    puVar12[1] = 0;
    ppuStack_80 = (undefined4 **)&uStack_30;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    uStack_84 = 0x9b5de4;
    piStack_2c = piVar1;
    FUN_009a4d30();
    ppuStack_80 = &puStack_14;
    uStack_84 = 0x9b5df2;
    cVar8 = FUN_01679300();
    if (cVar8 != '\0') {
      ppuStack_80 = (undefined4 **)0x9b5dfd;
      FUN_01679490();
      ppuStack_80 = &puStack_14;
      uStack_84 = 0x9b5e08;
      FUN_016791c0();
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar9 = piVar1[1] + -1;
      piVar1[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_80 = (undefined4 **)0x9b5e1e;
        (**(code **)*piVar1)();
        LOCK();
        iVar9 = piVar1[2] + -1;
        piVar1[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_80 = (undefined4 **)0x9b5e2e;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_80 = (undefined4 **)0x9b5e44;
        (**(code **)*piStack_4c)();
        LOCK();
        iVar9 = piStack_4c[2] + -1;
        piStack_4c[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_80 = (undefined4 **)0x9b5e54;
          (**(code **)(*piStack_4c + 4))();
        }
      }
    }
    if (puStack_14 != (undefined4 *)0x0) {
      piVar1 = puStack_14 + 1;
      LOCK();
      iVar9 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        ppuStack_80 = (undefined4 **)puStack_14;
        uStack_84 = 0x9b5e71;
        FUN_01674ea0();
      }
    }
    if (piStack_58 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_58[1] + -1;
      piStack_58[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_80 = (undefined4 **)0x9b5e8a;
        (**(code **)*piStack_58)();
        LOCK();
        iVar9 = piStack_58[2] + -1;
        piStack_58[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_80 = (undefined4 **)0x9b5e9a;
          (**(code **)(*piStack_58 + 4))();
        }
      }
    }
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_44[1] + -1;
      piStack_44[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_80 = (undefined4 **)0x9b5eb0;
        (**(code **)*piStack_44)();
        LOCK();
        piVar1 = piStack_44 + 2;
        iVar9 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          ppuStack_80 = (undefined4 **)0x9b5ebf;
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
  }
  else {
    *param_1 = *(undefined8 *)(iVar9 + 0x54);
    *(undefined4 *)(param_1 + 1) = *(undefined4 *)(iVar9 + 0x5c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18622 ; VA 0x009b5ee0 ; FUN_009b5ee0 */

undefined8 * FUN_009b5ee0(undefined8 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  char cVar8;
  undefined8 *puVar9;
  int iVar10;
  int iVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  char *pcVar14;
  uint uVar15;
  undefined *puStack_88;
  uint uStack_84;
  undefined4 **ppuStack_80;
  int **ppiStack_7c;
  undefined auStack_70 [24];
  int *piStack_58;
  undefined auStack_50 [4];
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  uint auStack_40 [3];
  code *pcStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d49b1;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ppiStack_7c = (int **)0x9b5f11;
  ExceptionList = &pvStack_10;
  puVar9 = (undefined8 *)FUN_00b08320();
  ppuStack_80 = (undefined4 **)PTR_DAT_01d64a0c;
  uStack_30 = 0;
  uVar12 = *(undefined4 *)(puVar9 + 1);
  *param_1 = *puVar9;
  *(undefined4 *)(param_1 + 1) = uVar12;
  piStack_2c = (int *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar14 = (char *)ppuStack_80;
  do {
    cVar8 = *pcVar14;
    pcVar14 = pcVar14 + 1;
  } while (cVar8 != '\0');
  ppiStack_7c = (int **)((int)pcVar14 - (int)((int)ppuStack_80 + 1));
  uStack_84 = 0x9b5f53;
  FUN_005542c0();
  ppiStack_7c = (int **)auStack_40;
  uStack_8 = 0;
  ppuStack_80 = (undefined4 **)0x9b5f65;
  iVar10 = FUN_008a1240();
  if (iVar10 != 0) {
    iVar2 = *(int *)(iVar10 + 0xc);
    ppiStack_7c = (int **)0x9b5f73;
    iVar11 = FUN_00dafce0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8) <=
        (uint)*(ushort *)(iVar11 + 0x1da)) goto LAB_009b5f90;
  }
  iVar10 = 0;
LAB_009b5f90:
  uStack_8 = 0xffffffff;
  if (0xf < piStack_2c) {
    ppiStack_7c = (int **)((int)piStack_2c + 1);
    uVar15 = auStack_40[0];
    if (0xfff < ppiStack_7c) {
      uVar15 = *(uint *)(auStack_40[0] - 4);
      ppiStack_7c = (int **)((int)piStack_2c + 0x24);
      if (0x1f < (auStack_40[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
        ppiStack_7c = (int **)0x9b630e;
        FUN_017167a3();
      }
    }
    uStack_84 = 0x9b5fc8;
    ppuStack_80 = (undefined4 **)uVar15;
    FUN_01674ea0();
  }
  uStack_30 = 0;
  piStack_2c = (int *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (iVar10 != 0) {
    uVar12 = *(undefined4 *)(iVar10 + 0x5c);
    *param_1 = *(undefined8 *)(iVar10 + 0x54);
    *(undefined4 *)(param_1 + 1) = uVar12;
    ExceptionList = pvStack_10;
    return param_1;
  }
  ppiStack_7c = &piStack_48;
  ppuStack_80 = (undefined4 **)0x9b6010;
  FUN_0099ef10();
  uStack_1c = 1;
  uStack_8 = 1;
  uStack_30 = 0;
  piStack_2c = (int *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar3 = *(code **)(*piStack_48 + 0x38);
  puStack_18 = PTR_DAT_01d64a0c + 1;
  pcVar14 = PTR_DAT_01d64a0c;
  do {
    cVar8 = *pcVar14;
    pcVar14 = pcVar14 + 1;
  } while (cVar8 != '\0');
  ppiStack_7c = (int **)((int)pcVar14 - (int)puStack_18);
  ppuStack_80 = (undefined4 **)PTR_DAT_01d64a0c;
  uStack_84 = 0x9b6064;
  FUN_005542c0();
  ppiStack_7c = (int **)auStack_40;
  uStack_8._0_1_ = 2;
  ppuStack_80 = (undefined4 **)0x9b6070;
  (*pcVar3)();
  uStack_8._0_1_ = 1;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < piStack_2c) {
    ppuStack_80 = (undefined4 **)((int)piStack_2c + 1);
    uVar15 = auStack_40[0];
    if (0xfff < ppuStack_80) {
      uVar15 = *(uint *)(auStack_40[0] - 4);
      ppuStack_80 = (undefined4 **)((int)piStack_2c + 0x24);
      if (0x1f < (auStack_40[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
        ppuStack_80 = (undefined4 **)&UNK_009b6313;
        uStack_8._0_1_ = uVar7;
        FUN_017167a3();
      }
    }
    puStack_88 = (undefined *)0x9b60a5;
    uStack_84 = uVar15;
    FUN_01674ea0();
  }
  ppuStack_80 = (undefined4 **)0x9b60b5;
  ppuStack_80 = (undefined4 **)FUN_00b08320();
  uStack_84 = 0x9b60bd;
  FUN_00db5810();
  ppuStack_80 = (undefined4 **)0x0;
  uStack_84 = param_2;
  puStack_88 = (undefined *)0x9b60c8;
  FUN_008a65e0();
  ppuStack_80 = (undefined4 **)0x9b60cf;
  iVar10 = FUN_008a4100();
  puStack_18 = (undefined *)(iVar10 + 8);
  pcStack_34 = FUN_009ab8e0;
  ppuStack_80 = (undefined4 **)(uint)DAT_01ee37b5;
  uStack_30 = 0xfffffecc;
  FUN_0060dcd0(&puStack_88,param_2);
  puStack_24 = (undefined4 *)FUN_0099e2b0(auStack_70,CONCAT44(uStack_30,pcStack_34),0,uStack_20);
  uStack_8._0_1_ = 4;
  uVar12 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 5;
  uStack_28 = uVar12;
  piStack_2c = (int *)FUN_01674e20(0x38);
  if (piStack_2c == (undefined4 *)0x0) {
    puVar13 = (undefined4 *)0x0;
  }
  else {
    *piStack_2c = 0;
    piStack_2c[1] = 1;
    piStack_2c[2] = (int)FUN_009b0530;
    piStack_2c[3] = (int)FUN_009b07d0;
    piStack_2c[4] = 0;
    piStack_2c[5] = (int)puStack_18;
    uVar4 = puStack_24[1];
    uVar5 = puStack_24[2];
    uVar6 = puStack_24[3];
    piStack_2c[6] = *puStack_24;
    piStack_2c[7] = uVar4;
    piStack_2c[8] = uVar5;
    piStack_2c[9] = uVar6;
    piStack_2c[10] = puStack_24[4];
    piStack_2c[0xb] = 0;
    piStack_2c[0xc] = 0;
    if (puStack_24[6] != 0) {
      LOCK();
      piVar1 = (int *)(puStack_24[6] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    piStack_2c[0xb] = puStack_24[5];
    piStack_2c[0xc] = puStack_24[6];
    puVar13 = piStack_2c;
  }
  uStack_84 = 0x9b61b2;
  ppuStack_80 = (undefined4 **)puVar13;
  FUN_016797d0();
  if (puVar13 != (undefined4 *)0x0) {
    LOCK();
    puVar13[1] = puVar13[1] + 1;
    UNLOCK();
  }
  uStack_1c = 3;
  uStack_8._0_1_ = 6;
  uStack_84 = 0x9b61d6;
  ppuStack_80 = (undefined4 **)uVar12;
  puStack_14 = puVar13;
  FUN_01675290();
  uStack_84 = param_2;
  puStack_88 = auStack_50;
  uStack_8._0_1_ = 4;
  puVar13 = (undefined4 *)FUN_0060dcd0();
  uStack_30 = *puVar13;
  piVar1 = (int *)puVar13[1];
  *puVar13 = 0;
  puVar13[1] = 0;
  ppuStack_80 = (undefined4 **)&uStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uStack_84 = 0x9b6217;
  piStack_2c = piVar1;
  FUN_009a4d30();
  ppuStack_80 = &puStack_14;
  uStack_84 = 0x9b6225;
  cVar8 = FUN_01679300();
  if (cVar8 != '\0') {
    ppuStack_80 = (undefined4 **)0x9b6230;
    FUN_01679490();
    ppuStack_80 = &puStack_14;
    uStack_84 = 0x9b623b;
    FUN_016791c0();
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar10 = piVar1[1] + -1;
    piVar1[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppuStack_80 = (undefined4 **)0x9b6251;
      (**(code **)*piVar1)();
      LOCK();
      iVar10 = piVar1[2] + -1;
      piVar1[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppuStack_80 = (undefined4 **)0x9b6261;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar10 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppuStack_80 = (undefined4 **)0x9b6277;
      (**(code **)*piStack_4c)();
      LOCK();
      iVar10 = piStack_4c[2] + -1;
      piStack_4c[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppuStack_80 = (undefined4 **)0x9b6287;
        (**(code **)(*piStack_4c + 4))();
      }
    }
  }
  if (puStack_14 != (undefined4 *)0x0) {
    piVar1 = puStack_14 + 1;
    LOCK();
    iVar10 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar10 == 1) {
      ppuStack_80 = (undefined4 **)puStack_14;
      uStack_84 = 0x9b62a4;
      FUN_01674ea0();
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_58[1] + -1;
    piStack_58[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppuStack_80 = (undefined4 **)0x9b62bd;
      (**(code **)*piStack_58)();
      LOCK();
      iVar10 = piStack_58[2] + -1;
      piStack_58[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppuStack_80 = (undefined4 **)0x9b62cd;
        (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_44[1] + -1;
    piStack_44[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppuStack_80 = (undefined4 **)0x9b62e3;
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        ppuStack_80 = (undefined4 **)0x9b62f2;
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18623 ; VA 0x009b6320 ; FUN_009b6320 */

undefined4 FUN_009b6320(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 ***pppuVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_58 [16];
  int iStack_48;
  undefined4 uStack_44;
  undefined4 **appuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d49d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 == 0) {
LAB_009b64d8:
    uVar6 = 0;
  }
  else {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("AvatarPartScaleType",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_008a1240(auStack_28);
    if (iVar3 == 0) {
LAB_009b63ab:
      iVar3 = 0;
    }
    else {
      iVar5 = *(int *)(iVar3 + 0xc);
      iVar4 = FUN_00daffe0();
      if ((uint)*(ushort *)(iVar4 + 0x1da) <
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_009b63ab;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (DAT_01d64a78 == '\0') {
LAB_009b6459:
      if (iVar3 == 0) goto LAB_009b64d8;
    }
    else if (iVar3 == 0) {
      iVar5 = FUN_0099fb30();
      if (iVar5 == 0) goto LAB_009b64d8;
      uStack_44 = 0xf;
      auStack_58[0] = 0;
      iStack_48 = iVar3;
      FUN_005542c0("AvatarPartScaleType",0x13);
      uStack_8._0_1_ = 2;
      uVar6 = FUN_008a1240(auStack_58);
      iVar3 = FUN_0099f8e0(uVar6);
      uStack_8 = (uint)uStack_8._1_3_ << 8;
      FUN_005507b0();
      goto LAB_009b6459;
    }
    FUN_0054ef60(iVar3 + 0x54);
    pppuVar7 = appuStack_40;
    if (0xf < uStack_2c) {
      pppuVar7 = (undefined4 ***)appuStack_40[0];
    }
    cVar2 = FUN_0055c360(pppuVar7,uStack_30,"ProportionsNormal",0x11);
    if (cVar2 == '\0') {
      pppuVar7 = appuStack_40;
      if (0xf < uStack_2c) {
        pppuVar7 = (undefined4 ***)appuStack_40[0];
      }
      cVar2 = FUN_0055c360(pppuVar7,uStack_30,"ProportionsSlender",0x12);
      if (cVar2 == '\0') {
        uVar6 = 0;
        FUN_005507b0();
      }
      else {
        uVar6 = 2;
        FUN_005507b0();
      }
    }
    else {
      uVar6 = 1;
      FUN_005507b0();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 18624 ; VA 0x009b6520 ; FUN_009b6520 */

undefined8 *
FUN_009b6520(undefined8 *param_1,int param_2,float param_3,float param_4,float param_5,int param_6)

{
  undefined8 uVar1;
  int iVar2;
  uint uVar3;
  undefined *puVar4;
  undefined *puVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  int aiStack_48 [5];
  uint uStack_34;
  undefined8 uStack_30;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  ulonglong uStack_18;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_30 = 0x3f8000003f800000;
  fStack_28 = 1.0;
  if (param_2 == 0) {
    *param_1 = 0x3f8000003f800000;
    *(undefined4 *)(param_1 + 1) = 0x3f800000;
    return param_1;
  }
  FUN_0054ef60(*(undefined4 *)(param_2 + 0x28));
  puVar4 = &DAT_01ee3898;
  puVar5 = &DAT_01ee38b8;
  if ((param_5 == 1.4013e-45) || (param_5 == 2.8026e-45)) {
    puVar4 = &DAT_01ee38d8;
    puVar5 = &DAT_01ee38f8;
  }
  uStack_30 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  fStack_28 = DAT_018ce2f8;
  FUN_0097be30(&param_2,aiStack_48);
  if (param_2 != *(int *)(puVar4 + 4)) {
    uStack_30 = *(undefined8 *)(param_2 + 0x20);
    fStack_28 = *(float *)(param_2 + 0x28);
  }
  fVar7 = fStack_28;
  param_5 = DAT_018ce2f8;
  uStack_18 = (ulonglong)(uint)DAT_018ce2f8;
  fStack_8 = DAT_018ce2f8;
  uStack_24 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  fStack_1c = DAT_018ce2f8;
  uStack_10 = uStack_30;
  FUN_0097be30(&param_2,aiStack_48);
  if (param_2 == *(int *)(puVar5 + 4)) {
    fVar10 = param_5;
    fVar11 = fStack_8;
    fVar9 = (float)uStack_18;
  }
  else {
    uVar1 = *(undefined8 *)(param_2 + 0x20);
    fStack_1c = *(float *)(param_2 + 0x28);
    uStack_24._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
    uStack_24._0_4_ = (float)uVar1;
    fVar10 = fStack_1c;
    fVar11 = uStack_24._4_4_;
    fVar9 = (float)uStack_24;
    uStack_24 = uVar1;
  }
  fVar9 = (fVar9 - (float)uStack_30) * param_3 + (float)uStack_30;
  fVar11 = (fVar11 - uStack_30._4_4_) * param_3 + uStack_30._4_4_;
  fVar10 = (fVar10 - fStack_28) * param_3 + fStack_28;
  if (param_6 == 1) {
    uStack_30 = uStack_10;
    uVar1 = uStack_30;
    fStack_28 = fVar7;
  }
  else {
    fVar7 = DAT_018ce2f8;
    fVar8 = DAT_018ce2f8;
    fVar6 = DAT_018ce2f8;
    uVar1 = uStack_24;
    fStack_28 = fStack_1c;
    if (param_6 != 2) goto LAB_009b66e6;
  }
  uStack_30 = uVar1;
  fVar7 = fStack_28;
  fVar8 = (float)uStack_30;
  fVar6 = uStack_30._4_4_;
LAB_009b66e6:
  fStack_28 = ((fVar10 - DAT_018ce2f8) * param_4 + DAT_018ce2f8) / fVar7;
  *param_1 = CONCAT44(((fVar11 - DAT_018ce2f8) * param_4 + DAT_018ce2f8) / fVar6,
                      ((fVar9 - DAT_018ce2f8) * param_4 + DAT_018ce2f8) / fVar8);
  *(float *)(param_1 + 1) = fStack_28;
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    iVar2 = aiStack_48[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_48[0] + -4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return param_1;
}



/* FUNCTION 18625 ; VA 0x009b6750 ; FUN_009b6750 */

void __thiscall FUN_009b6750(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  code *pcStack_c;
  undefined4 uStack_8;
  
  if (((param_1 != 0) && (*(int *)(param_1 + 0x34) != 0)) &&
     (iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar2 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    uStack_8 = param_2;
    pcStack_c = FUN_009abd70;
    FUN_00917910(&pcStack_c);
  }
  return;
}



/* FUNCTION 18626 ; VA 0x009b67c0 ; FUN_009b67c0 */

undefined4 FUN_009b67c0(undefined4 param_1)

{
  FUN_009c5d10();
  FUN_00aebf60(param_1);
  return param_1;
}



/* FUNCTION 18627 ; VA 0x009b67f0 ; FUN_009b67f0 */

void __thiscall FUN_009b67f0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  code *pcStack_c;
  undefined4 uStack_8;
  
  if (((param_1 != 0) && (*(int *)(param_1 + 0x34) != 0)) &&
     (iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar2 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    uStack_8 = param_2;
    pcStack_c = FUN_009abcc0;
    FUN_00917910(&pcStack_c);
  }
  return;
}



/* FUNCTION 18628 ; VA 0x009b6850 ; FUN_009b6850 */

undefined4 __thiscall FUN_009b6850(int param_1,int param_2)

{
  return *(undefined4 *)(param_1 + 0x378 + param_2 * 8);
}



/* FUNCTION 18629 ; VA 0x009b6870 ; FUN_009b6870 */

undefined * FUN_009b6870(undefined *param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = &DAT_01d64c60;
  do {
    if (*piVar1 == param_2) {
      FUN_0054ef60(piVar1 + 1);
      return param_1;
    }
    piVar1 = piVar1 + 7;
  } while (piVar1 != &DAT_01d64e20);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  return param_1;
}



/* FUNCTION 18630 ; VA 0x009b68d0 ; FUN_009b68d0 */

undefined4 FUN_009b68d0(undefined4 param_1)

{
  switch(param_1) {
  default:
    return 0xf;
  case 1:
    return 0;
  case 2:
    return 0xe;
  case 3:
    return 0xb;
  case 4:
    return 8;
  case 5:
    return 5;
  case 6:
    return 1;
  }
}



/* FUNCTION 18631 ; VA 0x009b6940 ; FUN_009b6940 */

undefined4 * __thiscall FUN_009b6940(int param_1,undefined4 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  int iVar16;
  undefined4 *puVar17;
  float *pfVar18;
  int iVar19;
  undefined auStack_78 [48];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  if ((*(int *)(param_1 + 0x5c0) == 0) ||
     (iVar16 = (**(code **)(**(int **)(param_1 + 0x5c4) + 0x3c))(), iVar16 == 0xf)) {
    iVar16 = *(int *)(param_1 + 0xf4);
  }
  else {
    iVar16 = *(int *)(param_1 + 0xf4);
    if (iVar16 == 0) {
      iVar19 = *(int *)(param_1 + 0x20c);
    }
    else {
      iVar19 = *(int *)(param_1 + 700);
    }
    if (iVar19 != 0) goto LAB_009b69a6;
  }
  if (iVar16 == 0) {
    iVar16 = *(int *)(param_1 + 0x23c);
  }
  else {
    iVar16 = *(int *)(param_1 + 0x24c);
  }
  if (iVar16 == 0) {
    FUN_0060efa0();
    return param_2;
  }
LAB_009b69a6:
  puVar17 = (undefined4 *)FUN_00b077e0();
  uStack_48 = *puVar17;
  uStack_44 = puVar17[1];
  uStack_40 = puVar17[2];
  uStack_3c = puVar17[3];
  uStack_38 = puVar17[4];
  uStack_34 = puVar17[5];
  uStack_30 = puVar17[6];
  uStack_2c = puVar17[7];
  uStack_28 = puVar17[8];
  uStack_24 = puVar17[9];
  uStack_20 = puVar17[10];
  uStack_1c = puVar17[0xb];
  iVar16 = FUN_009c6d40();
  pfVar18 = (float *)FUN_0071f260(auStack_78,iVar16 + 0x1e0);
  fVar1 = *(float *)(param_1 + 0x134);
  fVar2 = *(float *)(param_1 + 0x138);
  fVar3 = *(float *)(param_1 + 0x13c);
  fVar4 = *pfVar18;
  fVar5 = pfVar18[1];
  fVar6 = pfVar18[2];
  fVar7 = pfVar18[3];
  fVar8 = pfVar18[4];
  fVar9 = pfVar18[5];
  fVar10 = pfVar18[6];
  fVar11 = pfVar18[7];
  fVar12 = pfVar18[9];
  fVar13 = pfVar18[8];
  fVar14 = pfVar18[10];
  fVar15 = pfVar18[0xb];
  *param_2 = 0x3f800000;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0x3f800000;
  param_2[5] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0x3f800000;
  *(ulonglong *)(param_2 + 9) =
       CONCAT44(fVar1 * fVar7 + fVar2 * fVar8 + fVar3 * fVar9 + fVar14,
                fVar1 * fVar4 + fVar2 * fVar5 + fVar3 * fVar6 + fVar12);
  param_2[0xb] = fVar1 * fVar10 + fVar2 * fVar11 + fVar3 * fVar13 + fVar15;
  return param_2;
}



/* FUNCTION 18632 ; VA 0x009b6b40 ; FUN_009b6b40 */

/* WARNING: Removing unreachable block (ram,0x009b6bd5) */
/* WARNING: Removing unreachable block (ram,0x009b6be3) */
/* WARNING: Removing unreachable block (ram,0x009b6d18) */
/* WARNING: Removing unreachable block (ram,0x009b6bf7) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009b6b40(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uStack_30;
  undefined *puStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar4 = _UNK_018e3fbc;
  uVar3 = _UNK_018e3fb8;
  uVar2 = _UNK_018e3fb4;
  uVar1 = _DAT_018e3fb0;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4f08;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x228) == 0) {
    uStack_30 = 0;
    uStack_18 = 0;
    puStack_2c = &DAT_bf800000;
    uStack_28 = 0;
    ExceptionList = &pvStack_10;
    FUN_01163c80(&uStack_30,0,&DAT_bf800000);
    uVar6 = DAT_018f7864;
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_8 = 0;
    iVar5 = FUN_00c48290();
    uStack_8 = 0xffffffff;
    if (iVar5 != 0) {
      FUN_00d6c620(param_2);
      ExceptionList = pvStack_10;
      return param_2;
    }
    uStack_24 = 0;
    uStack_18 = 0;
    puStack_20 = &DAT_bf800000;
    uStack_1c = 0;
    FUN_01163c80(&uStack_24,0,&DAT_bf800000);
    uVar6 = DAT_019399cc;
  }
  *param_2 = uVar1;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  param_2[4] = uVar1;
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  param_2[7] = uVar4;
  param_2[8] = uVar1;
  param_2[9] = (int)uStack_18;
  param_2[10] = uVar6;
  param_2[0xb] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18633 ; VA 0x009b6c36 ; FUN_009b6c36 */

void FUN_009b6c36(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int unaff_EBP;
  
  *(undefined **)(unaff_EBP + -0x30) = &DAT_bf800000;
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined8 *)(unaff_EBP + -0x14) = 0;
  *(undefined **)(unaff_EBP + -0x1c) = &DAT_bf800000;
  *(undefined4 *)(unaff_EBP + -0x18) = 0;
  FUN_01163c80(unaff_EBP + -0x20,0,*(undefined4 *)(unaff_EBP + -0x30));
  uVar5 = DAT_019399cc;
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  uVar2 = *(undefined4 *)(unaff_EBP + -0x70);
  uVar3 = *(undefined4 *)(unaff_EBP + -0x6c);
  uVar4 = *(undefined4 *)(unaff_EBP + -0x68);
  *(undefined4 *)(unaff_EBP + -0x48) = *(undefined4 *)(unaff_EBP + -0x30);
  puVar1 = *(undefined4 **)(unaff_EBP + 8);
  *(ulonglong *)(unaff_EBP + -0x50) = CONCAT44(uVar5,(int)*(undefined8 *)(unaff_EBP + -0x14));
  *puVar1 = *(undefined4 *)(unaff_EBP + -0x74);
  puVar1[1] = uVar2;
  puVar1[2] = uVar3;
  puVar1[3] = uVar4;
  uVar2 = *(undefined4 *)(unaff_EBP + -0x60);
  uVar3 = *(undefined4 *)(unaff_EBP + -0x5c);
  uVar4 = *(undefined4 *)(unaff_EBP + -0x58);
  puVar1[4] = *(undefined4 *)(unaff_EBP + -100);
  puVar1[5] = uVar2;
  puVar1[6] = uVar3;
  puVar1[7] = uVar4;
  uVar2 = *(undefined4 *)(unaff_EBP + -0x50);
  uVar3 = *(undefined4 *)(unaff_EBP + -0x4c);
  uVar4 = *(undefined4 *)(unaff_EBP + -0x48);
  puVar1[8] = *(undefined4 *)(unaff_EBP + -0x54);
  puVar1[9] = uVar2;
  puVar1[10] = uVar3;
  puVar1[0xb] = uVar4;
  return;
}



/* FUNCTION 18634 ; VA 0x009b6d20 ; FUN_009b6d20 */

undefined4 __fastcall FUN_009b6d20(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 1000);
  }
  return *(undefined4 *)(param_1 + 0x350);
}



/* FUNCTION 18635 ; VA 0x009b6d40 ; FUN_009b6d40 */

undefined4 __fastcall FUN_009b6d40(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 0x3b8);
  }
  return *(undefined4 *)(param_1 + 0x360);
}



/* FUNCTION 18636 ; VA 0x009b6d60 ; FUN_009b6d60 */

int __fastcall FUN_009b6d60(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799c39;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  uStack_14 = 0;
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar2 = *(int *)(param_1 + 0x370);
  }
  else {
    iVar2 = *(int *)(param_1 + 0x380);
  }
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Right Shoulder",0xe);
    uStack_8 = 0;
    bVar6 = true;
    uStack_14 = 1;
    iVar2 = FUN_008a1240(auStack_2c);
    if (iVar2 != 0) {
      iVar1 = *(int *)(iVar2 + 0xc);
      iVar3 = FUN_00c391f0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_009b6dfe;
    }
  }
  iVar2 = 0;
LAB_009b6dfe:
  if ((bVar6) && (0xf < uStack_18)) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 18637 ; VA 0x009b6e50 ; FUN_009b6e50 */

undefined4 __fastcall FUN_009b6e50(int param_1)

{
  int iVar1;
  
  if (((*(int *)(param_1 + 0x3f8) != 0) &&
      (iVar1 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar1 != 0)) && (iVar1 != -0x50)) {
    return *(undefined4 *)(iVar1 + 0x70);
  }
  return 0;
}



/* FUNCTION 18638 ; VA 0x009b6e80 ; FUN_009b6e80 */

void __thiscall FUN_009b6e80(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  code *pcStack_c;
  undefined4 uStack_8;
  
  if ((param_1 != 0x134) && (*(int *)(param_1 + -0x100) != 0)) {
    iVar1 = *(int *)(*(int *)(param_1 + -0x100) + 0xc);
    iVar2 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      uStack_8 = param_2;
      pcStack_c = FUN_009abcc0;
      FUN_00917910(&pcStack_c);
    }
  }
  return;
}



/* FUNCTION 18639 ; VA 0x009b6ef0 ; FUN_009b6ef0 */

undefined __thiscall FUN_009b6ef0(int param_1,uint param_2)

{
  if (param_2 < 0x11) {
    return *(undefined *)(param_2 + 0x2a9 + param_1);
  }
  FUN_0086f2f0(3,"Invalid state passed to GetStateEnabled.");
  return 1;
}



/* FUNCTION 18640 ; VA 0x009b6f20 ; FUN_009b6f20 */

undefined4 __fastcall FUN_009b6f20(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x6d8) == 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_018c3d40,6);
    uStack_8 = 0;
    iVar5 = FUN_008a1240(auStack_30);
    if ((iVar5 == 0) ||
       (iVar1 = *(int *)(iVar5 + 0xc), iVar6 = FUN_00e44030(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      iVar5 = 0;
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar9 = uStack_1c + 1;
      uVar8 = auStack_30[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_30[0] - 4);
        uVar9 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    puVar7 = (undefined4 *)FUN_0060dcd0(auStack_18,iVar5);
    uVar2 = *puVar7;
    uVar3 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(param_1 + 0x6d8) = uVar2;
    piVar4 = *(int **)(param_1 + 0x6dc);
    *(undefined4 *)(param_1 + 0x6dc) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_14[1] + -1;
      piStack_14[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar5 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return *(undefined4 *)(param_1 + 0x6d8);
}



/* FUNCTION 18641 ; VA 0x009b70a0 ; FUN_009b70a0 */

void FUN_009b70a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4a00;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&uStack_20);
  uStack_8 = 0;
  iVar4 = FUN_009b6f20();
  uVar3 = uStack_20;
  if ((iVar4 != 0) && (puVar6 = *(undefined4 **)(iVar4 + 0x2c), puVar6 != (undefined4 *)0x0)) {
    piVar5 = *(int **)(iVar4 + 0x30);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(iVar4 + 0x30);
      puVar6 = *(undefined4 **)(iVar4 + 0x2c);
    }
    puVar2 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    for (; piStack_14 = piVar5, puVar6 != puVar2; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar5 = (int *)(puVar6[1] + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      FUN_009abe20(*puVar6,puVar6[1],uVar3);
      piVar5 = piStack_14;
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  *param_1 = uStack_20;
  param_1[1] = uStack_1c;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18642 ; VA 0x009b71c0 ; FUN_009b71c0 */

void FUN_009b71c0(undefined4 *param_1)

{
  uint uVar1;
  
  uVar1 = DAT_018ce2f4;
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  *(ulonglong *)(param_1 + 9) = (ulonglong)uVar1 << 0x20;
  param_1[0xb] = 0;
  return;
}



/* FUNCTION 18643 ; VA 0x009b7230 ; FUN_009b7230 */

int __fastcall FUN_009b7230(int param_1)

{
  int iVar1;
  
  if ((*(int *)(param_1 + 0x3f8) != 0) &&
     (iVar1 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar1 != 0)) {
    return iVar1 + 0x50;
  }
  return 0;
}



/* FUNCTION 18644 ; VA 0x009b7250 ; FUN_009b7250 */

int __fastcall FUN_009b7250(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar1 == 0) {
    if (*(int *)(param_1 + 0x228) != 0) {
      return *(int *)(param_1 + 0x380);
    }
    iVar1 = *(int *)(param_1 + 0x370);
  }
  return iVar1;
}



/* FUNCTION 18645 ; VA 0x009b7280 ; FUN_009b7280 */

undefined4 __fastcall FUN_009b7280(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 0x3f0);
  }
  return *(undefined4 *)(param_1 + 0x340);
}



/* FUNCTION 18646 ; VA 0x009b72a0 ; FUN_009b72a0 */

float10 __fastcall FUN_009b72a0(int param_1)

{
  int iVar1;
  float10 fVar2;
  undefined auStack_18 [12];
  double dStack_c;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar1 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar1 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar1 = *(int *)(param_1 + 0x380);
    }
    if (iVar1 == 0) {
      return (float10)0;
    }
  }
  FUN_00b077e0();
  iVar1 = FUN_011612d0(auStack_18,2);
  dStack_c = (double)*(float *)(iVar1 + 8);
  fVar2 = (float10)FUN_01728580();
  return (float10)(float)fVar2;
}



/* FUNCTION 18647 ; VA 0x009b7320 ; FUN_009b7320 */

undefined4 __fastcall FUN_009b7320(int param_1)

{
  if (*(int *)(param_1 + 0x3f8) != 0) {
    return *(undefined4 *)(*(int *)(param_1 + 0x3f8) + 0xa8);
  }
  return 0;
}



/* FUNCTION 18648 ; VA 0x009b7340 ; FUN_009b7340 */

undefined4 __fastcall FUN_009b7340(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar1 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar1 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar1 = *(int *)(param_1 + 0x380);
    }
    if (iVar1 == 0) {
      return 0;
    }
  }
  return *(undefined4 *)(iVar1 + 0xa8);
}



/* FUNCTION 18649 ; VA 0x009b73a0 ; FUN_009b73a0 */

undefined8 * __thiscall FUN_009b73a0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))(auStack_10);
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 18650 ; VA 0x009b73f0 ; FUN_009b73f0 */

void __fastcall FUN_009b73f0(int param_1)

{
  (**(code **)(param_1 + 8))();
  return;
}



/* FUNCTION 18651 ; VA 0x009b7420 ; FUN_009b7420 */

undefined4 * __thiscall FUN_009b7420(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_1c);
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return param_2;
}



/* FUNCTION 18652 ; VA 0x009b74c0 ; FUN_009b74c0 */

undefined8 * __thiscall FUN_009b74c0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))();
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 18653 ; VA 0x009b7500 ; FUN_009b7500 */

void __fastcall FUN_009b7500(int param_1)

{
  (**(code **)(param_1 + 8))();
  return;
}



/* FUNCTION 18654 ; VA 0x009b7540 ; FUN_009b7540 */

void __thiscall FUN_009b7540(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_009c63c0();
  *param_3 = uVar3;
  iVar4 = FUN_009c6a30();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18655 ; VA 0x009b75a0 ; FUN_009b75a0 */

void __thiscall FUN_009b75a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_009c6470();
  *param_3 = uVar3;
  iVar4 = FUN_009c6aa0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18656 ; VA 0x009b7600 ; FUN_009b7600 */

void __thiscall FUN_009b7600(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_009c6520();
  *param_3 = uVar3;
  iVar4 = FUN_009c6b10();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18657 ; VA 0x009b7660 ; FUN_009b7660 */

void __thiscall FUN_009b7660(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0098d050();
  *param_3 = uVar3;
  iVar4 = FUN_0098d150();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18658 ; VA 0x009b76c0 ; FUN_009b76c0 */

void __thiscall FUN_009b76c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_009c6680();
  *param_3 = uVar3;
  iVar4 = FUN_009c6b80();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18659 ; VA 0x009b7720 ; FUN_009b7720 */

void __thiscall FUN_009b7720(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00896e70();
  *param_3 = uVar3;
  iVar4 = FUN_008973b0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18660 ; VA 0x009b7780 ; FUN_009b7780 */

void __thiscall FUN_009b7780(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_009c67e0();
  *param_3 = uVar3;
  iVar4 = FUN_009c6c60();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 18661 ; VA 0x009b77e0 ; FUN_009b77e0 */

undefined4 __fastcall FUN_009b77e0(int param_1)

{
  if (*(int *)(param_1 + 0x228) != 0) {
    return *(undefined4 *)(param_1 + 0x380);
  }
  return *(undefined4 *)(param_1 + 0x370);
}



/* FUNCTION 18662 ; VA 0x009b7810 ; FUN_009b7810 */

void __thiscall FUN_009b7810(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x1b8);
  *param_2 = *(undefined8 *)(param_1 + 0x1b0);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 18663 ; VA 0x009b7830 ; FUN_009b7830 */

float10 __fastcall FUN_009b7830(int param_1)

{
  return (float10)(float)(**(int **)(param_1 + 0x1f0) + (int)*(int **)(param_1 + 0x1f0));
}



/* FUNCTION 18664 ; VA 0x009b7850 ; FUN_009b7850 */

void __thiscall FUN_009b7850(int param_1,undefined *param_2,undefined8 *param_3)

{
  float *pfVar1;
  char cVar2;
  undefined8 *puVar3;
  float10 fVar4;
  double dVar5;
  double dVar6;
  float fVar7;
  float fVar8;
  uint uVar9;
  double dStack_40;
  float fStack_38;
  undefined8 uStack_2c;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  *param_2 = 1;
  fStack_c = 0.0;
  *param_3 = 0;
  *(undefined4 *)(param_3 + 1) = 0;
  if ((*(char *)(param_1 + 0x292) != '\0') && (cVar2 = FUN_009ab310(), cVar2 != '\0')) {
    fStack_20 = 0.0;
    fStack_1c = 0.0;
    fStack_18 = 0.0;
    fStack_14 = 0.0;
    fStack_10 = 0.0;
    fStack_c = 0.0;
    dStack_40 = 0.0;
    fStack_38 = 0.0;
    uStack_2c = 0;
    fStack_24 = 0.0;
    cVar2 = FUN_009b7b40(&fStack_20,&fStack_14);
    if ((cVar2 == '\0') || (cVar2 = FUN_009b7d40(&dStack_40), cVar2 == '\0')) {
      fVar8 = uStack_2c._4_4_;
    }
    else {
      fVar8 = dStack_40._0_4_ - fStack_20;
      fStack_38 = fStack_38 - fStack_18;
      uStack_2c = (ulonglong)(uint)fVar8;
      dVar5 = (double)(fVar8 * fVar8 + 0.0 + fStack_38 * fStack_38);
      fStack_24 = fStack_38;
      FUN_017267a0();
      if ((float)dVar5 < DAT_018fde64) {
        return;
      }
      fVar8 = 0.0;
    }
    dVar5 = (double)((float)uStack_2c * (float)uStack_2c + fVar8 * fVar8 + fStack_24 * fStack_24);
    if (NAN(dVar5) == (dVar5 == 0.0)) {
      uVar9 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
      dVar6 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar9,
                               SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      dStack_40 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & uVar9,
                                   SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
      fVar4 = (float10)FUN_01160810();
      dVar5 = DAT_018f76b0;
      if ((NAN(dVar6) || NAN((double)fVar4)) == (dVar6 == (double)fVar4)) {
        dVar5 = dVar6 * DAT_018f76b0;
      }
      if (dVar5 < dStack_40) {
        puVar3 = (undefined8 *)FUN_00c94eb0(&dStack_40,&uStack_2c);
        *param_3 = *puVar3;
        *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar3 + 1);
      }
      fVar8 = uStack_2c._4_4_;
    }
    pfVar1 = *(float **)(param_1 + 0x2a0);
    if (pfVar1 == (float *)0x0) {
      fVar8 = (float)uStack_2c * (float)uStack_2c + fVar8 * fVar8 + fStack_24 * fStack_24;
    }
    else {
      fVar8 = (pfVar1[1] * fStack_1c + *pfVar1 * fStack_20 + pfVar1[2] * fStack_18) - pfVar1[3];
      dVar5 = (double)fVar8;
      fVar8 = (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) &
                                      (uint)((ulonglong)DAT_018c0da0 >> 0x20),
                                      SUB84(dVar5,0) & (uint)DAT_018c0da0) * fVar8;
    }
    fVar7 = (fStack_10 * fStack_10 + fStack_14 * fStack_14 + fStack_c * fStack_c) * DAT_018fabc4;
    if (fVar7 <= DAT_018ce2f8) {
      fVar7 = DAT_018ce2f8;
    }
    *param_2 = fVar8 < fVar7;
  }
  return;
}



/* FUNCTION 18665 ; VA 0x009b7b40 ; FUN_009b7b40 */

uint __thiscall FUN_009b7b40(int param_1,undefined8 *param_2,undefined8 *param_3)

{
  float fVar1;
  uint uVar2;
  uint *puVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 *puVar6;
  float fVar7;
  
  uVar2 = *(uint *)(param_1 + 0x228);
  if (uVar2 == 0) {
    iVar5 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar5 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar5 == 0) {
    if (uVar2 == 0) {
      iVar5 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar5 = *(int *)(param_1 + 0x380);
    }
    if (iVar5 == 0) {
      return uVar2 & 0xffffff00;
    }
  }
  puVar3 = *(uint **)(param_1 + 0x218);
  uVar2 = *puVar3;
  iVar5 = FUN_00b08320();
  fVar7 = *(float *)(iVar5 + 4) * DAT_018ce2f4;
  iVar5 = FUN_00b077e0();
  fVar1 = *(float *)(iVar5 + 0x2c);
  *param_2 = CONCAT44(*(float *)(iVar5 + 0x28) - (fVar7 + (float)(uVar2 ^ (uint)puVar3)),
                      *(float *)(iVar5 + 0x24) - 0.0);
  *(float *)(param_2 + 1) = fVar1 - 0.0;
  puVar6 = (undefined8 *)FUN_00b07b60();
  *param_3 = *puVar6;
  uVar4 = *(undefined4 *)(puVar6 + 1);
  *(undefined4 *)(param_3 + 1) = uVar4;
  return CONCAT31((int3)((uint)uVar4 >> 8),1);
}



/* FUNCTION 18666 ; VA 0x009b7c10 ; FUN_009b7c10 */

undefined4 __fastcall FUN_009b7c10(int param_1)

{
  return *(undefined4 *)(param_1 + 0x19c);
}



/* FUNCTION 18667 ; VA 0x009b7c20 ; FUN_009b7c20 */

float10 __fastcall FUN_009b7c20(int param_1)

{
  float10 fVar1;
  
  if (*(int **)(param_1 + 0x5c4) != (int *)0x0) {
    fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x5c4) + 0x38))(param_1);
    return (float10)(float)fVar1;
  }
  return (float10)0.0;
}



/* FUNCTION 18668 ; VA 0x009b7c50 ; FUN_009b7c50 */

bool FUN_009b7c50(int param_1)

{
  int iVar1;
  uint uVar2;
  bool bVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009b6f20();
  if (iVar1 == 0) {
    bVar3 = false;
  }
  else {
    iVar1 = FUN_008a1240(&param_1);
    bVar3 = iVar1 != 0;
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return bVar3;
}



/* FUNCTION 18669 ; VA 0x009b7ce0 ; FUN_009b7ce0 */

undefined4 __fastcall FUN_009b7ce0(int param_1)

{
  if (*(int *)(param_1 + 0xf4) != 0) {
    return CONCAT31((int3)((uint)*(int *)(param_1 + 0x244) >> 8),*(int *)(param_1 + 0x244) != 0);
  }
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x214) >> 8),*(int *)(param_1 + 0x214) != 0);
}



/* FUNCTION 18670 ; VA 0x009b7d10 ; FUN_009b7d10 */

void FUN_009b7d10(undefined4 param_1)

{
  undefined auStack_24 [20];
  undefined4 uStack_10;
  
  uStack_10 = 0x9b7d1c;
  FUN_009c68d0();
  FUN_009cb090(auStack_24,param_1);
  FUN_009b7c50();
  return;
}



/* FUNCTION 18671 ; VA 0x009b7d40 ; FUN_009b7d40 */

uint __thiscall FUN_009b7d40(int param_1,undefined8 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  float *pfVar8;
  int iVar9;
  float fVar10;
  
  if ((param_1 == 0) || (iVar9 = *(int *)(param_1 + 0x34), iVar9 == 0)) {
LAB_009b7d7a:
    iVar9 = 0;
  }
  else {
    iVar4 = *(int *)(iVar9 + 0xc);
    iVar6 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) goto LAB_009b7d7a;
  }
  iVar9 = FUN_00980070(iVar9);
  if (iVar9 != 0) {
    uVar7 = FUN_0090c170();
    if (*(int *)(uVar7 + 0x88) == 2) goto LAB_009b7da5;
    uVar7 = FUN_0090c170();
    if (*(int *)(uVar7 + 0x88) == 4) goto LAB_009b7da5;
  }
  if (*(int *)(param_1 + 0x19c) == 0) {
    *param_2 = *(undefined8 *)(param_1 + 0x1a4);
    uVar5 = *(undefined4 *)(param_1 + 0x1ac);
    *(undefined4 *)(param_2 + 1) = uVar5;
    return CONCAT31((int3)((uint)uVar5 >> 8),1);
  }
  uVar7 = FUN_008b2e60(param_1);
  if (uVar7 != 0) {
    uVar7 = FUN_008b0500(*(undefined4 *)(param_1 + 0x19c));
    if ((char)uVar7 != '\0') {
      pfVar8 = (float *)FUN_00b077e0();
      fVar1 = *(float *)(param_1 + 0x1a8);
      fVar2 = *(float *)(param_1 + 0x1a4);
      fVar3 = *(float *)(param_1 + 0x1ac);
      fVar10 = pfVar8[6] * fVar2 + pfVar8[7] * fVar1 + pfVar8[8] * fVar3 + pfVar8[0xb];
      *param_2 = CONCAT44(pfVar8[3] * fVar2 + pfVar8[4] * fVar1 + pfVar8[5] * fVar3 + pfVar8[10],
                          pfVar8[1] * fVar1 + *pfVar8 * fVar2 + pfVar8[2] * fVar3 + pfVar8[9]);
      *(float *)(param_2 + 1) = fVar10;
      return CONCAT31((int3)((uint)fVar10 >> 8),1);
    }
  }
LAB_009b7da5:
  return uVar7 & 0xffffff00;
}



/* FUNCTION 18672 ; VA 0x009b7ec0 ; FUN_009b7ec0 */

void __thiscall FUN_009b7ec0(int param_1,int param_2)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  byte bVar5;
  undefined uVar6;
  int iVar7;
  byte bVar8;
  int *piVar9;
  int iVar10;
  int *piVar11;
  bool bVar12;
  undefined8 uVar13;
  undefined4 in_stack_ffffffb0;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4a2c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00f94350();
  if (cVar4 == '\0') {
    if ((*(char *)(param_1 + 0x21c) < '\x01') && (cVar4 = FUN_009a6aa0(), cVar4 == '\0')) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  else if (*(char *)(param_1 + 0x21c) < '\x01') {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar10 = *(int *)(param_1 + 0x340);
    }
    else {
      iVar10 = *(int *)(param_1 + 0x3f0);
    }
    if (iVar10 == 0) {
      if (*(int *)(param_1 + 0x228) == 0) {
        iVar10 = *(int *)(param_1 + 0x370);
      }
      else {
        iVar10 = *(int *)(param_1 + 0x380);
      }
      if (iVar10 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
    }
    if (*(int *)(iVar10 + 0xa8) == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    if (*(int *)(param_1 + 0x6f4) == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_009b1bb0(in_stack_ffffffb0,in_stack_ffffffb4,in_stack_ffffffb8,&DAT_01d650e2);
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3b40) &&
     (FUN_016f3809(), DAT_01ee3b40 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0(&DAT_018cb3fc,"Humanoid::onStepped",0xffffffff);
    DAT_01ee3b3c = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01ee3b38 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ee3b40);
  }
  uVar3 = DAT_01ee3b3c;
  uVar2 = DAT_01ee3b38;
  uVar13 = FUN_0152d930(DAT_01ee3b38,DAT_01ee3b3c);
  uStack_8 = 1;
  FUN_009c6dc0(*(undefined8 *)(param_2 + 8));
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar10 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar10 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar10 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar10 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar10 = *(int *)(param_1 + 0x380);
    }
    if (iVar10 != 0) goto LAB_009b8048;
    iVar10 = 0;
LAB_009b800d:
    bVar12 = false;
  }
  else {
LAB_009b8048:
    iVar10 = FUN_00c155c0();
    if (iVar10 == 0) goto LAB_009b800d;
    cVar4 = FUN_00ca0f40();
    bVar12 = cVar4 == '\0';
  }
  bVar8 = *(byte *)(param_1 + 0x222);
  bVar1 = '\0' < (char)bVar8;
  if (iVar10 == 0) {
LAB_009b8034:
    bVar5 = FUN_01679ce0();
    bVar8 = 1;
    if ((bVar5 & 0x7f) != 0) {
      bVar8 = bVar5 & 0x7f;
    }
    bVar8 = -bVar8;
LAB_009b8077:
    *(byte *)(param_1 + 0x222) = bVar8;
  }
  else if (bVar12) {
    cVar4 = FUN_00b03420();
    if ((cVar4 != '\0') && (*(int *)(iVar10 + 0x3c) != 3)) goto LAB_009b8034;
    bVar5 = FUN_01679ce0();
    bVar8 = 1;
    if ((bVar5 & 0x7f) != 0) {
      bVar8 = bVar5 & 0x7f;
    }
    goto LAB_009b8077;
  }
  if (bVar1 != '\0' < (char)bVar8) {
    FUN_005e6780();
    bVar8 = *(byte *)(param_1 + 0x222);
  }
  if (((char)bVar8 < '\x01') && (*(char *)(param_1 + 0x223) < '\x01')) {
    if (*(int *)(param_1 + 0x6f4) == 0) goto LAB_009b81b3;
    FUN_00dc3d60();
  }
  else {
    if (*(int *)(param_1 + 0x6f4) == 0) goto LAB_009b81b3;
    if ((*(int *)(param_1 + 0x34) != 0) &&
       (iVar10 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar7 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
       (uint)*(ushort *)(iVar7 + 0x1da))) {
      FUN_00dc53f0(param_1 + 0x6f8,(float)*(double *)(param_2 + 8));
    }
    if ((*(char *)(param_1 + 0x2e5) != '\0') ||
       (DAT_018ce2f0 < (float)(**(uint **)(param_1 + 0x1fc) ^ (uint)*(uint **)(param_1 + 0x1fc)))) {
      uVar6 = 1;
    }
    else {
      uVar6 = 0;
    }
    *(undefined *)(param_1 + 0x2e5) = uVar6;
  }
  if ((*(int *)(param_1 + 0x6f4) != 0) &&
     (piVar9 = *(int **)(param_1 + 0x6f8), piVar9 != (int *)0x0)) {
    piVar11 = *(int **)(param_1 + 0x6fc);
    if (piVar11 != (int *)0x0) {
      LOCK();
      piVar11[1] = piVar11[1] + 1;
      UNLOCK();
      piVar9 = *(int **)(param_1 + 0x6f8);
      piVar11 = *(int **)(param_1 + 0x6fc);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    (**(code **)(*piVar9 + 0x34))();
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        piVar9 = piVar11 + 2;
        iVar10 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
LAB_009b81b3:
  uStack_8 = 3;
  FUN_0152dda0(uVar2,uVar3,uVar13);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18673 ; VA 0x009b8240 ; FUN_009b8240 */

int FUN_009b8240(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4a48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (*(int *)(param_1 + 0xc) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xc) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar3 = FUN_009bb900(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18674 ; VA 0x009b82e0 ; FUN_009b82e0 */

/* WARNING: Removing unreachable block (ram,0x009b8380) */
/* WARNING: Removing unreachable block (ram,0x009b838e) */
/* WARNING: Removing unreachable block (ram,0x009b83bb) */
/* WARNING: Removing unreachable block (ram,0x009b839e) */

void FUN_009b82e0(undefined4 param_1,undefined4 ****param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***pppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_6;
  uStack_14 = param_7;
  pppuStack_28 = param_2;
  uStack_24 = param_3;
  uStack_20 = param_4;
  uStack_1c = param_5;
  uStack_8 = 1;
  ppppuVar1 = &pppuStack_28;
  if (0xf < param_7) {
    ppppuVar1 = param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(3,"Humanoid::luaApplyDescriptionBlocking() onErrorCallback %s",ppppuVar1);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)pppuStack_28;
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)pppuStack_28[-1];
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18675 ; VA 0x009b83d0 ; FUN_009b83d0 */

/* WARNING: Removing unreachable block (ram,0x009b849a) */
/* WARNING: Removing unreachable block (ram,0x009b84a3) */
/* WARNING: Removing unreachable block (ram,0x009b84b1) */

int FUN_009b83d0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4a70;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_009be7b0(*puVar3,puVar3[1],param_2,param_3,puVar3 + 2,puVar3 + 0xc);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18676 ; VA 0x009b84d0 ; FUN_009b84d0 */

/* WARNING: Removing unreachable block (ram,0x009b852d) */
/* WARNING: Removing unreachable block (ram,0x009b8539) */
/* WARNING: Removing unreachable block (ram,0x009b8547) */

undefined4 FUN_009b84d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009a5870(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 18677 ; VA 0x009b8560 ; FUN_009b8560 */

/* WARNING: Removing unreachable block (ram,0x009b8600) */
/* WARNING: Removing unreachable block (ram,0x009b860e) */
/* WARNING: Removing unreachable block (ram,0x009b863b) */
/* WARNING: Removing unreachable block (ram,0x009b861e) */

void FUN_009b8560(undefined4 param_1,undefined4 ****param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***pppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_6;
  uStack_14 = param_7;
  pppuStack_28 = param_2;
  uStack_24 = param_3;
  uStack_20 = param_4;
  uStack_1c = param_5;
  uStack_8 = 1;
  ppppuVar1 = &pppuStack_28;
  if (0xf < param_7) {
    ppppuVar1 = param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(3,&DAT_018bd25c,ppppuVar1);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)pppuStack_28;
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)pppuStack_28[-1];
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18678 ; VA 0x009b8650 ; FUN_009b8650 */

/* WARNING: Removing unreachable block (ram,0x009b86ad) */
/* WARNING: Removing unreachable block (ram,0x009b86b9) */
/* WARNING: Removing unreachable block (ram,0x009b86c7) */

undefined4 FUN_009b8650(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8a98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009a59e0(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 18679 ; VA 0x009b86e0 ; FUN_009b86e0 */

int FUN_009b86e0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c46b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_0099b990(param_1,uVar3,&param_1,0);
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 18680 ; VA 0x009b8760 ; FUN_009b8760 */

int FUN_009b8760(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar6 = *param_1;
  uVar3 = *(undefined4 *)(iVar6 + 0x10);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar6 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar6 + 0x18) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = *(undefined4 *)(iVar6 + 0x14);
  uVar5 = *(undefined4 *)(iVar6 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar6 = FUN_009a5ce0(uVar3,param_2,param_3,uVar4,uVar5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 18681 ; VA 0x009b8820 ; FUN_009b8820 */

/* WARNING: Removing unreachable block (ram,0x009b8887) */
/* WARNING: Removing unreachable block (ram,0x009b8895) */
/* WARNING: Removing unreachable block (ram,0x009b88bd) */
/* WARNING: Removing unreachable block (ram,0x009b88a5) */

void FUN_009b8820(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009a5b30(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18682 ; VA 0x009b88d0 ; FUN_009b88d0 */

/* WARNING: Removing unreachable block (ram,0x009b892d) */
/* WARNING: Removing unreachable block (ram,0x009b8939) */
/* WARNING: Removing unreachable block (ram,0x009b8947) */

undefined4 FUN_009b88d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009a5bb0(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 18683 ; VA 0x009b8960 ; FUN_009b8960 */

uint __fastcall FUN_009b8960(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x40) & 1;
  if (DAT_01d65340 != '\0') {
    if (uVar1 != 0) {
      return (uint)(*(uint *)(param_1 + 0x40) != 3);
    }
    uVar1 = 0;
  }
  return uVar1;
}



/* FUNCTION 18684 ; VA 0x009b8980 ; FUN_009b8980 */

bool __fastcall FUN_009b8980(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  float10 fVar5;
  undefined4 uVar6;
  undefined auStack_6 [2];
  
  iVar1 = FUN_008b2e60(param_1);
  if (iVar1 != 0) {
    iVar1 = FUN_00a9d3e0();
    if (iVar1 != 0) {
      if (*(int *)(param_1 + 0x228) == 0) {
        iVar1 = *(int *)(param_1 + 0x340);
      }
      else {
        iVar1 = *(int *)(param_1 + 0x3f0);
      }
      if (iVar1 != 0) {
        iVar1 = FUN_00b077e0();
        uVar6 = 1;
        fVar5 = (float10)FUN_01725280((double)(*(float *)(iVar1 + 0x2c) * DAT_018e1340),1);
        iVar2 = (int)(short)(int)fVar5;
        fVar5 = (float10)FUN_01725280((double)(*(float *)(iVar1 + 0x28) * DAT_018e1340),iVar2);
        iVar3 = (short)(int)fVar5 + 1;
        fVar5 = (float10)FUN_01725280((double)(*(float *)(iVar1 + 0x24) * DAT_018e1340),iVar3);
        pcVar4 = (char *)FUN_00a70be0(auStack_6,(int)(short)(int)fVar5,iVar3,iVar2,uVar6);
        return *pcVar4 == '\x01';
      }
    }
  }
  return false;
}



/* FUNCTION 18685 ; VA 0x009b8aa0 ; FUN_009b8aa0 */

undefined4 FUN_009b8aa0(undefined *param_1)

{
  if ((((param_1 != &DAT_021225e8) && (param_1 != &DAT_021227f0)) && (param_1 != &DAT_02122578)) &&
     ((param_1 != &DAT_0212253c && (param_1 != &DAT_02122504)))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 18686 ; VA 0x009b8ae0 ; FUN_009b8ae0 */

int __fastcall FUN_009b8ae0(int param_1)

{
  undefined *puVar1;
  uint3 uVar2;
  
  puVar1 = *(undefined **)(param_1 + 0x178);
  uVar2 = (uint3)((uint)puVar1 >> 8);
  if (puVar1 == (undefined *)0x0) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31(uVar2,*puVar1);
}



/* FUNCTION 18687 ; VA 0x009b8af0 ; FUN_009b8af0 */

undefined4 __thiscall FUN_009b8af0(int param_1,undefined4 *param_2)

{
  if (((((param_2 != (undefined4 *)&DAT_02122208) || (*(char *)(param_1 + 0x20c) != '\0')) &&
       ((param_2 != (undefined4 *)&DAT_02122278 || (*(char *)(param_1 + 0x20c) == '\0')))) &&
      ((DAT_01d64a60 != '\0' || (param_2 != &DAT_021229f8)))) &&
     ((DAT_01d64a68 != '\0' || (param_2 != (undefined4 *)&DAT_02122738)))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 18688 ; VA 0x009b8b50 ; FUN_009b8b50 */

uint FUN_009b8b50(void)

{
  int iVar1;
  
  iVar1 = FUN_0099be20();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 18689 ; VA 0x009b8b70 ; FUN_009b8b70 */

byte __fastcall FUN_009b8b70(int param_1)

{
  return *(byte *)(param_1 + 0x44) & 1;
}



/* FUNCTION 18690 ; VA 0x009b8b80 ; FUN_009b8b80 */

uint FUN_009b8b80(void)

{
  int iVar1;
  
  iVar1 = FUN_0099be20();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 18691 ; VA 0x009b8ba0 ; FUN_009b8ba0 */

undefined4 FUN_009b8ba0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  char *pcVar4;
  
  pcVar3 = (char *)FUN_00dc3b10(*param_2);
  pcVar4 = pcVar3;
  do {
    cVar2 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar2 != '\0');
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  cVar2 = FUN_0055c360(param_1,*puVar1,pcVar3,(int)pcVar4 - (int)(pcVar3 + 1));
  if (cVar2 != '\0') {
    *param_3 = *param_2;
    return 1;
  }
  return 0;
}



/* FUNCTION 18692 ; VA 0x009b8c00 ; FUN_009b8c00 */

int * __thiscall FUN_009b8c00(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4aa1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009b49f0(param_2,param_1);
  uStack_8 = 0;
  if (*param_2 == 0) {
    piVar5 = (int *)FUN_0099f2b0(auStack_18);
    iVar2 = *piVar5;
    iVar3 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *param_2 = iVar2;
    piVar5 = (int *)param_2[1];
    param_2[1] = iVar3;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[1] + -1;
      piVar5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar2 = piVar5[2] + -1;
        piVar5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    piStack_14 = (int *)param_2[1];
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    uStack_8 = 1;
    pcVar4 = *(code **)(*(int *)*param_2 + 0x38);
    uVar6 = FUN_00e2c4f0();
    (*pcVar4)(uVar6);
    FUN_008a65e0(param_1,0);
    piVar5 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18693 ; VA 0x009b8d60 ; FUN_009b8d60 */

undefined4 FUN_009b8d60(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009c5d10();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00aec240(param_1,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18694 ; VA 0x009b8e00 ; FUN_009b8e00 */

void FUN_009b8e00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c63c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18695 ; VA 0x009b8e40 ; FUN_009b8e40 */

void FUN_009b8e40(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6470();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18696 ; VA 0x009b8e80 ; FUN_009b8e80 */

void FUN_009b8e80(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6520();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18697 ; VA 0x009b8ec0 ; FUN_009b8ec0 */

void FUN_009b8ec0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c65d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18698 ; VA 0x009b8f00 ; FUN_009b8f00 */

void FUN_009b8f00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6680();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18699 ; VA 0x009b8f40 ; FUN_009b8f40 */

void FUN_009b8f40(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6730();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18700 ; VA 0x009b8f80 ; FUN_009b8f80 */

void FUN_009b8f80(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_009c67e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18701 ; VA 0x009b8fc0 ; FUN_009b8fc0 */

void FUN_009b8fc0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c68d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18702 ; VA 0x009b9000 ; FUN_009b9000 */

void __thiscall
FUN_009b9000(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4ad8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (DAT_01d64a10 == '\0') {
    uStack_44 = 0;
    ExceptionList = &pvStack_10;
    if (param_12 != 0) {
      uStack_44 = param_12;
      if ((param_12 & 1) == 0) {
        uStack_4c = ZEXT48(&uStack_3c);
        puStack_50 = &param_14;
        uStack_54 = 0x9b9127;
        ExceptionList = &pvStack_10;
        (**(code **)(param_12 & 0xfffffffe))();
      }
      else {
        uStack_3c = param_14;
        uStack_38 = param_15;
        uStack_34 = param_16;
        puStack_30 = (undefined4 *)param_17;
        uStack_2c = param_18;
        ExceptionList = &pvStack_10;
      }
    }
    uStack_8._0_1_ = 4;
    if (param_5 != 0) {
      if ((param_5 & 1) == 0) {
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_5c,0);
      }
      else {
        uStack_5c = param_7;
        uStack_58 = param_8;
        uStack_54 = param_9;
        puStack_50 = param_10;
        uStack_4c = param_11;
      }
    }
    bVar3 = true;
  }
  else {
    bVar3 = *(char *)(param_1 + 0x291) == '\0';
    uStack_44 = 0;
    ExceptionList = &pvStack_10;
    if (param_12 != 0) {
      uStack_44 = param_12;
      if ((param_12 & 1) == 0) {
        uStack_4c = ZEXT48(&uStack_3c);
        puStack_50 = &param_14;
        uStack_54 = 0x9b9084;
        ExceptionList = &pvStack_10;
        (**(code **)(param_12 & 0xfffffffe))();
      }
      else {
        uStack_3c = param_14;
        uStack_38 = param_15;
        uStack_34 = param_16;
        puStack_30 = (undefined4 *)param_17;
        uStack_2c = param_18;
        ExceptionList = &pvStack_10;
      }
    }
    uStack_8._0_1_ = 3;
    if (param_5 != 0) {
      if ((param_5 & 1) == 0) {
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_5c,0);
      }
      else {
        uStack_5c = param_7;
        uStack_58 = param_8;
        uStack_54 = param_9;
        puStack_50 = param_10;
        uStack_4c = param_11;
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_009a7640(param_2,param_3,0,bVar3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x9b91c5,(undefined4)uStack_2c);
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = CONCAT44(0x9b91d4,(undefined4)uStack_2c);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_7;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x9b91f5;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_14;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x9b9223;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18703 ; VA 0x009b9240 ; FUN_009b9240 */

code * FUN_009b9240(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  code **ppcVar3;
  char cVar4;
  undefined4 *puVar5;
  code *pcVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined *puStack_158;
  int *piStack_154;
  undefined auStack_150 [8];
  undefined4 uStack_148;
  int *piStack_144;
  int *piStack_140;
  int *piStack_13c;
  undefined *puStack_138;
  undefined4 uStack_134;
  char *pcStack_130;
  int iStack_12c;
  int *piStack_128;
  int *piStack_124;
  int *piStack_120;
  undefined4 **ppuStack_11c;
  undefined4 *puStack_118;
  char *pcStack_114;
  char *pcStack_110;
  code *apcStack_10c [2];
  int iStack_104;
  int *piStack_100;
  int *piStack_fc;
  int *piStack_f8;
  undefined8 uStack_f4;
  undefined auStack_bc [4];
  int *piStack_b8;
  undefined4 uStack_b4;
  int *piStack_b0;
  int *piStack_ac;
  int *piStack_a8;
  int *piStack_a4;
  int *piStack_a0;
  undefined *puStack_9c;
  undefined auStack_98 [4];
  int *piStack_94;
  code *pcStack_90;
  int iStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  undefined8 uStack_78;
  int aiStack_70 [3];
  int *piStack_64;
  int *piStack_60;
  int aiStack_5c [3];
  undefined *puStack_50;
  undefined *puStack_4c;
  int *piStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  char cStack_1d;
  int *piStack_1c;
  char acStack_18 [4];
  char acStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4bb9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_30 = (int *)0x0;
  iStack_40 = 0;
  piStack_3c = (int *)0x0;
  cStack_1d = '\0';
  acStack_14[0] = '\0';
  uStack_f4 = CONCAT44(acStack_14,0x9b9292);
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00585a40();
  if (cVar4 == '\0') {
    pcStack_90 = (code *)((int)&DAT_01939764 + 1);
  }
  else {
    pcStack_90 = (code *)0x0;
  }
  piStack_24 = (int *)apcStack_10c;
  uStack_8._0_1_ = 2;
  apcStack_10c[0] = (code *)0x0;
  ppcVar3 = apcStack_10c;
  if (pcStack_90 != (code *)0x0) {
    apcStack_10c[0] = pcStack_90;
    if (((uint)pcStack_90 & 1) == 0) {
      pcStack_114 = (char *)&iStack_104;
      pcStack_110 = (char *)0x0;
      puStack_118 = &iStack_88;
      ppuStack_11c = (undefined4 **)0x9b9301;
      (**(code **)((uint)pcStack_90 & 0xfffffffe))();
      ppcVar3 = (code **)piStack_24;
    }
    else {
      iStack_104 = iStack_88;
      piStack_100 = piStack_84;
      piStack_fc = piStack_80;
      piStack_f8 = piStack_7c;
      uStack_f4 = uStack_78;
      ppcVar3 = apcStack_10c;
    }
  }
  piStack_24 = (int *)ppcVar3;
  pcStack_110 = (char *)&iStack_40;
  pcStack_114 = &cStack_1d;
  puStack_118 = (undefined4 *)0x1;
  ppuStack_11c = &piStack_30;
  piStack_120 = (int *)0x0;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piStack_128 = (int *)param_1;
  piStack_124 = param_2;
  iStack_12c = 0x9b9343;
  cVar4 = FUN_009c5e40();
  if (cVar4 == '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    goto LAB_009b98b1;
  }
  uStack_f4 = 0x18009b935a;
  piStack_2c = (int *)FUN_01674e20();
  if (piStack_2c == (int *)0x0) {
    piStack_2c = (int *)0x0;
  }
  else {
    piStack_2c[1] = 1;
    piStack_2c[2] = 1;
    *piStack_2c = (int)std::
                       _Ref_count_obj<class_boost::promise<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>_>_>
                       ::vftable;
    piStack_2c[3] = 0;
    piStack_2c[4] = 0;
    *(undefined *)(piStack_2c + 5) = 0;
  }
  piVar2 = piStack_2c;
  piVar8 = piStack_2c + 3;
  uStack_8._0_1_ = 4;
  uStack_f4 = CONCAT44(0x9b93a5,(undefined4)uStack_f4);
  piStack_64 = piVar8;
  piStack_60 = piStack_2c;
  FUN_008ff200();
  piStack_28 = (int *)*piVar8;
  if (piStack_28 == (int *)0x0) {
    uStack_f4 = CONCAT44(0x9b9949,(undefined4)uStack_f4);
    uVar7 = FUN_0056b1c0();
    uStack_8._0_1_ = 5;
    uStack_f4 = CONCAT44(uVar7,0x9b9953);
    FUN_00564a30();
  }
  else if (*(char *)(piVar2 + 5) == '\0') {
    *(undefined *)(piVar2 + 5) = 1;
    piVar2 = (int *)piVar2[4];
    piVar8 = piVar2 + 1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar8 = *piVar8 + 1;
      UNLOCK();
      if (piVar2 != (int *)0x0) {
        LOCK();
        *piVar8 = *piVar8 + 1;
        UNLOCK();
        if (piVar2 != (int *)0x0) {
          LOCK();
          *piVar8 = *piVar8 + 1;
          UNLOCK();
        }
      }
    }
    uStack_8._0_1_ = 7;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar8;
      *piVar8 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        uStack_f4 = CONCAT44(0x9b93f2,(undefined4)uStack_f4);
        (**(code **)(*piVar2 + 4))();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b9402,(undefined4)uStack_f4);
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    uStack_8._0_1_ = 8;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_f4 = CONCAT44(0x9b941c,(undefined4)uStack_f4);
        (**(code **)(*piVar2 + 4))();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b942c,(undefined4)uStack_f4);
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    piVar8 = piVar2 + 1;
    piStack_a4 = piStack_28;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar8 = *piVar8 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 9;
    piStack_a0 = piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar8;
      *piVar8 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        uStack_f4 = CONCAT44(0x9b945c,(undefined4)uStack_f4);
        (**(code **)(*piVar2 + 4))();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b946c,(undefined4)uStack_f4);
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    piStack_38 = piStack_2c + 1;
    LOCK();
    *piStack_38 = *piStack_38 + 1;
    UNLOCK();
    piStack_ac = piStack_2c + 3;
    piStack_a8 = piStack_2c;
    uStack_8._0_1_ = 0xc;
    uStack_f4 = CONCAT44(&piStack_48,0x9b9494);
    FUN_0099fc60();
    aiStack_5c[0] = 0;
    aiStack_5c[1] = 0;
    aiStack_5c[2] = 0;
    aiStack_70[0] = 0;
    aiStack_70[1] = 0;
    aiStack_70[2] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if ((DAT_01d64ac8 == '\0') || (*(int *)(iStack_34 + 0x228) == 0)) {
LAB_009b94eb:
      acStack_14[0] = '\0';
    }
    else {
      uStack_f4 = CONCAT44(iStack_34,0x9b94e0);
      cVar4 = FUN_008bc690();
      acStack_14[0] = '\x01';
      if (cVar4 == '\0') goto LAB_009b94eb;
    }
    uStack_f4 = CONCAT44(iStack_34,auStack_98);
    piStack_f8 = (int *)0x9b94fe;
    piStack_fc = (int *)FUN_009b49f0();
    piStack_f8 = &iStack_40;
    uStack_8._0_1_ = 0x10;
    piStack_100 = (int *)0x9b950c;
    acStack_18[0] = FUN_009a87d0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    piStack_1c = piStack_94;
    if (piStack_94 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_94[1] + -1;
      piStack_94[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_f4 = CONCAT44(0x9b9532,(undefined4)uStack_f4);
        (**(code **)*piStack_94)();
        LOCK();
        iVar1 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b9543,(undefined4)uStack_f4);
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piVar8 = piStack_1c;
    if (acStack_18[0] != '\0') {
      piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
      if (DAT_01d64ab0 != '\0') {
        piStack_1c = (int *)CONCAT31(SUB43(piVar8,1),cStack_1d == '\0');
      }
      if (acStack_14[0] == '\0') {
        uStack_f4 = CONCAT44(piStack_1c,aiStack_5c);
        piStack_f8 = piStack_48;
        piStack_fc = piStack_30;
        piStack_100 = (int *)0x9b958e;
        FUN_00e30c10();
      }
      else {
        uStack_f4 = CONCAT44(piStack_1c,aiStack_70);
        piStack_f8 = aiStack_5c;
        piStack_fc = piStack_48;
        piStack_100 = piStack_30;
        iStack_104 = 0x9b957d;
        FUN_00e30ca0();
      }
    }
    if ((piStack_30 == (int *)0x0) || (piStack_30 == (int *)0xfffffff4)) {
      piStack_1c = (int *)0x0;
    }
    else {
      uStack_f4 = CONCAT44(0x9b95a1,(undefined4)uStack_f4);
      piStack_1c = (int *)FUN_005c2760();
    }
    uStack_f4 = CONCAT44(0x9b95b2,(undefined4)uStack_f4);
    piStack_f8 = (int *)FUN_008ccd70();
    uStack_f4 = 0x100000000;
    if (acStack_14[0] == '\0') {
      ppuStack_11c = (undefined4 **)0x0;
      LOCK();
      *piStack_38 = *piStack_38 + 1;
      UNLOCK();
      piStack_124 = piStack_64;
      piStack_120 = piStack_2c;
      piStack_128 = (int *)0x9b9633;
      FUN_0099b230();
      piStack_120 = aiStack_5c;
      ppuStack_11c = (int **)0x42200000;
      piStack_124 = (int *)0x9b9647;
      FUN_008d16d0();
    }
    else {
      piStack_120 = (int *)0x0;
      LOCK();
      *piStack_38 = *piStack_38 + 1;
      UNLOCK();
      piStack_128 = piStack_64;
      piStack_124 = piStack_2c;
      iStack_12c = 0x9b95f0;
      piStack_fc = piStack_f8;
      piStack_f8 = aiStack_70;
      FUN_0099b230();
      piStack_124 = aiStack_5c;
      piStack_120 = (int *)0x42200000;
      piStack_128 = (int *)0x9b9604;
      FUN_008d1df0();
    }
    if (piStack_28 != (int *)0x0) {
      uStack_f4._4_4_ = 0;
      uStack_f4._0_4_ = 0x9b9659;
      (**(code **)(*piStack_28 + 8))();
      uStack_f4 = CONCAT44(uStack_f4._4_4_,0x9b9665);
      puVar5 = (undefined4 *)(**(code **)(*piStack_28 + 0x14))();
      piStack_b0 = (int *)puVar5[1];
      if (piStack_b0 != (int *)0x0) {
        LOCK();
        piStack_b0[1] = piStack_b0[1] + 1;
        UNLOCK();
        piStack_b0 = (int *)puVar5[1];
      }
      uStack_b4 = *puVar5;
      puStack_9c = (undefined *)apcStack_10c;
      piStack_28 = (int *)apcStack_10c;
      acStack_18[0] = '\0';
      *(int *)(iStack_34 + 0x33c) = *(int *)(iStack_34 + 0x33c) + 1;
      puStack_4c = *(undefined **)(iStack_34 + 0x33c);
      puStack_50 = (undefined *)iStack_40;
      pcStack_110 = acStack_18;
      pcStack_114 = (char *)0x9b96bd;
      piStack_24 = (int *)uStack_b4;
      piStack_1c = piStack_b0;
      cVar4 = FUN_00585a40();
      if (cVar4 == '\0') {
        *piStack_28 = (int)&DAT_01939841;
      }
      else {
        *piStack_28 = 0;
      }
      piStack_94 = &iStack_12c;
      piStack_28 = &iStack_12c;
      acStack_18[0] = '\0';
      pcStack_130 = acStack_18;
      uStack_134 = 0x9b96f2;
      cVar4 = FUN_00585a40();
      if (cVar4 == '\0') {
        *piStack_28 = (int)&DAT_01939839;
      }
      else {
        *piStack_28 = 0;
      }
      pcStack_130 = puStack_4c;
      puStack_138 = auStack_bc;
      uStack_134 = 3;
      uStack_8._0_1_ = 0x15;
      piStack_13c = (int *)0x9b9726;
      piStack_13c = (int *)FUN_0089d950();
      puStack_50 = (undefined *)&puStack_138;
      piStack_140 = (int *)&puStack_138;
      uStack_8._0_1_ = 0x16;
      piStack_144 = (int *)0x9b9739;
      FUN_00917080();
      if (piStack_44 != (int *)0x0) {
        LOCK();
        piStack_44[1] = piStack_44[1] + 1;
        UNLOCK();
      }
      piStack_140 = piStack_48;
      piStack_13c = piStack_44;
      piStack_28 = &uStack_148;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      uStack_148 = piStack_24;
      piStack_144 = piStack_1c;
      piStack_24 = (int *)auStack_150;
      puStack_158 = auStack_150;
      uStack_8._0_1_ = 0x19;
      piStack_154 = piStack_30;
      puStack_4c = (undefined *)&piStack_140;
      FUN_005e5de0();
      uStack_8._0_1_ = 0x1a;
      FUN_0060e0c0(&puStack_158,iStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
      FUN_009a7b50();
      piStack_24 = piStack_b8;
      if (piStack_b8 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_b8[1] + -1;
        piStack_b8[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b97d3,(undefined4)uStack_f4);
          (**(code **)*piStack_b8)();
          LOCK();
          iVar1 = piStack_24[2] + -1;
          piStack_24[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_f4 = CONCAT44(0x9b97e4,(undefined4)uStack_f4);
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b97f8,(undefined4)uStack_f4);
          (**(code **)*piStack_1c)();
          LOCK();
          iVar1 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_f4 = CONCAT44(0x9b9809,(undefined4)uStack_f4);
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      uStack_f4 = CONCAT44(0x9b9811,(undefined4)uStack_f4);
      FUN_0056d320();
      uStack_f4 = CONCAT44(0x9b9819,(undefined4)uStack_f4);
      FUN_00577a40();
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_44[1] + -1;
        piStack_44[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b982d,(undefined4)uStack_f4);
          (**(code **)*piStack_44)();
          LOCK();
          iVar1 = piStack_44[2] + -1;
          piStack_44[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_f4 = CONCAT44(0x9b983e,(undefined4)uStack_f4);
            (**(code **)(*piStack_44 + 4))();
          }
        }
      }
      LOCK();
      iVar1 = *piStack_38;
      *piStack_38 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        uStack_f4 = CONCAT44(0x9b9850,(undefined4)uStack_f4);
        (**(code **)*piStack_2c)();
        LOCK();
        iVar1 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b9861,(undefined4)uStack_f4);
          (**(code **)(*piStack_2c + 4))();
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[1] + -1;
        piVar2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b9879,(undefined4)uStack_f4);
          (**(code **)(*piVar2 + 4))();
          LOCK();
          iVar1 = piVar2[2] + -1;
          piVar2[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_f4 = CONCAT44(0x9b9889,(undefined4)uStack_f4);
            (**(code **)(*piVar2 + 8))();
          }
        }
      }
      piVar8 = piStack_2c;
      LOCK();
      iVar1 = *piStack_38;
      *piStack_38 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        uStack_f4 = CONCAT44(0x9b989d,(undefined4)uStack_f4);
        (**(code **)*piStack_2c)();
        LOCK();
        piVar2 = piVar8 + 2;
        iVar1 = *piVar2 + -1;
        *piVar2 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_f4 = CONCAT44(0x9b98ad,(undefined4)uStack_f4);
          (**(code **)(*piVar8 + 4))();
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
LAB_009b98b1:
      pcVar6 = pcStack_90;
      if (pcStack_90 != (code *)0x0) {
        if ((((uint)pcStack_90 & 1) == 0) &&
           (pcVar6 = *(code **)((uint)pcStack_90 & 0xfffffffe), pcVar6 != (code *)0x0)) {
          piStack_f8 = &iStack_88;
          uStack_f4 = CONCAT44(2,piStack_f8);
          piStack_fc = (int *)0x9b98d4;
          pcVar6 = (code *)(*pcVar6)();
        }
        pcStack_90 = (code *)0x0;
      }
      piVar8 = piStack_3c;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        piVar2 = piStack_3c + 1;
        iVar1 = *piVar2;
        pcVar6 = (code *)*piVar2;
        *piVar2 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          uStack_f4 = CONCAT44(0x9b98f7,(undefined4)uStack_f4);
          (**(code **)*piStack_3c)();
          LOCK();
          piVar2 = piVar8 + 2;
          iVar1 = *piVar2;
          pcVar6 = (code *)*piVar2;
          *piVar2 = iVar1 + -1;
          UNLOCK();
          if (iVar1 + -1 == 0) {
            uStack_f4 = CONCAT44(0x9b9907,(undefined4)uStack_f4);
            pcVar6 = (code *)(**(code **)(*piVar8 + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        piVar8 = param_2 + 1;
        iVar1 = *piVar8;
        pcVar6 = (code *)*piVar8;
        *piVar8 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          uStack_f4 = CONCAT44(0x9b991d,(undefined4)uStack_f4);
          pcVar6 = (code *)(**(code **)*param_2)();
          LOCK();
          piVar8 = param_2 + 2;
          iVar1 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            uStack_f4 = CONCAT44(0x9b992c,(undefined4)uStack_f4);
            pcVar6 = (code *)(**(code **)(*param_2 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return pcVar6;
    }
    goto LAB_009b9968;
  }
  uStack_f4 = CONCAT44(0x9b995e,(undefined4)uStack_f4);
  uVar7 = FUN_0056ab30();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  uStack_f4 = CONCAT44(uVar7,0x9b9968);
  FUN_005648f0();
LAB_009b9968:
  uStack_f4 = CONCAT44(0x9b9973,(undefined4)uStack_f4);
  uVar7 = FUN_0056acb0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  uStack_f4 = CONCAT44(uVar7,0x9b997d);
  FUN_00564940();
  pcVar6 = (code *)swi(3);
  pcVar6 = (code *)(*pcVar6)();
  return pcVar6;
}



/* FUNCTION 18704 ; VA 0x009b9980 ; FUN_009b9980 */

void FUN_009b9980(undefined4 param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4bf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != 0) {
    uStack_40 = param_10;
    if ((param_10 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_12;
      uStack_50 = 0x9b99ea;
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_12;
      uStack_34 = param_13;
      uStack_30 = param_14;
      puStack_2c = (undefined4 *)param_15;
      uStack_28 = param_16;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_58,0);
    }
    else {
      uStack_58 = param_5;
      uStack_54 = param_6;
      uStack_50 = param_7;
      puStack_4c = param_8;
      uStack_48 = param_9;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_009a7640(param_1,param_2,0,0,3);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x9b9a87,(undefined4)uStack_28);
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0x9b9a96,(undefined4)uStack_28);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_5;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x9b9ab7;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_12;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x9b9ae5;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18705 ; VA 0x009b9b00 ; FUN_009b9b00 */

void FUN_009b9b00(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = param_1[2];
  if (iVar1 == param_1[1]) {
    uVar2 = 2;
    if (iVar1 != 0) {
      uVar2 = iVar1 * 2;
    }
    for (; uVar2 < iVar1 + 1U; uVar2 = uVar2 * 2) {
    }
    FUN_009c14b0(uVar2);
  }
  *(undefined4 *)(*param_1 + param_1[1] * 4) = param_2;
  param_1[1] = param_1[1] + 1;
  iVar1 = param_1[2];
  if (iVar1 == param_1[1]) {
    uVar2 = 2;
    if (iVar1 != 0) {
      uVar2 = iVar1 * 2;
    }
    for (; uVar2 < iVar1 + 1U; uVar2 = uVar2 * 2) {
    }
    FUN_009c14b0(uVar2);
  }
  *(undefined4 *)(*param_1 + param_1[1] * 4) = param_3;
  param_1[1] = param_1[1] + 1;
  iVar1 = param_1[2];
  if (iVar1 == param_1[1]) {
    uVar2 = 2;
    if (iVar1 != 0) {
      uVar2 = iVar1 * 2;
    }
    for (; uVar2 < iVar1 + 1U; uVar2 = uVar2 * 2) {
    }
    FUN_009c14b0(uVar2);
  }
  *(undefined4 *)(*param_1 + param_1[1] * 4) = param_4;
  param_1[1] = param_1[1] + 1;
  return;
}



/* FUNCTION 18706 ; VA 0x009b9bc0 ; FUN_009b9bc0 */

int * FUN_009b9bc0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009b9ca9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dbe3ec);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_0878ef73b390876bd1eac58c3a0be9ec>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 18707 ; VA 0x009b9cd0 ; FUN_009b9cd0 */

void FUN_009b9cd0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dbdd14);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_2afbad00d6c10d40ce601ef4a734ec25>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 18708 ; VA 0x009b9d30 ; FUN_009b9d30 */

int * FUN_009b9d30(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009b9e07. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009b9d86. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dbdd84);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_4131373aca04cb8b08b6b3f4723c8e54>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 18709 ; VA 0x009b9e20 ; FUN_009b9e20 */

void FUN_009b9e20(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009a03a0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_009a3470();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dbe2b8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_47746cf46c9caa2c92420d88c2d7109c>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 18710 ; VA 0x009b9f70 ; FUN_009b9f70 */

void FUN_009b9f70(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_005e5f00(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dbe2f0);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_77ed249c0eb798d1a5aba99d9b0ba231>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 18711 ; VA 0x009ba0e0 ; FUN_009ba0e0 */

void FUN_009ba0e0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dbdd4c);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_a1c154cd696ed5996418b4167dc8c059>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 18712 ; VA 0x009ba140 ; FUN_009ba140 */

void FUN_009ba140(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dbe424);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_d8113b82b36713f13d2ebaaa2257938b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 18713 ; VA 0x009ba1a0 ; FUN_009ba1a0 */

void FUN_009ba1a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009a0450(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dbe280);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_f64656d71b226653aa7d5f2fe4492b34>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 18714 ; VA 0x009ba2f0 ; FUN_009ba2f0 */

void FUN_009ba2f0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d060f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x70);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_009a1b20(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x50);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x58,iVar4 + 0x58,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x50) = 0;
        }
        FUN_009a39a0();
        FUN_01674ea0(iVar4,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dbddbc);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Humanoid>,class_std::weak_ptr<class_RBX::DataModel>,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::HumanoidAssetRequirement>,class_std::allocator<class_std::shared_ptr<class_RBX::HumanoidAssetRequirement>_>_>_>,class_std::shared_ptr<class_RBX::HumanoidDescription>,unsigned_int,class_boost::function<void___cdecl(void)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list8<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Humanoid>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::HumanoidAssetRequirement>,class_std::allocator<class_std::shared_ptr<class_RBX::HumanoidAssetRequirement>_>_>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::HumanoidDescription>_>,class_boost::_bi::value<unsigned_int>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 18715 ; VA 0x009ba480 ; FUN_009ba480 */

void FUN_009ba480(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar3 = (undefined4 *)*param_1;
      puVar8 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar8 == (undefined4 *)0x0) {
        *param_2 = 0;
        return;
      }
      uVar5 = puVar3[1];
      uVar6 = puVar3[2];
      uVar7 = puVar3[3];
      *puVar8 = *puVar3;
      puVar8[1] = uVar5;
      puVar8[2] = uVar6;
      puVar8[3] = uVar7;
      puVar8[4] = puVar3[4];
      puVar8[5] = 0;
      puVar8[6] = 0;
      if (puVar3[6] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[6] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar8[5] = puVar3[5];
      puVar8[6] = puVar3[6];
      *param_2 = (int)puVar8;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar9 = *param_2;
      if (iVar9 != 0) {
        piVar1 = *(int **)(iVar9 + 0x18);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar4 = piVar1[1] + -1;
          piVar1[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            piVar2 = piVar1 + 2;
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar9,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar9 = FUN_0170d8dd(*param_2 + 4,0x1dbe45c);
      if (iVar9 != 0) {
        *param_2 = 0;
        return;
      }
      *param_2 = *param_1;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::Humanoid,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::Humanoid*>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::PartInstance>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 18716 ; VA 0x009ba5a0 ; FUN_009ba5a0 */

void FUN_009ba5a0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4c17;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar5 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x28);
      if (iVar3 == 0) {
        iVar3 = 0;
      }
      else {
        *(undefined4 *)(iVar3 + 0x24) = 0;
        uStack_8 = 1;
        if (*(undefined4 **)(iVar5 + 0x24) != (undefined4 *)0x0) {
          uVar4 = (**(code **)**(undefined4 **)(iVar5 + 0x24))(iVar3);
          *(undefined4 *)(iVar3 + 0x24) = uVar4;
          *param_2 = iVar3;
          ExceptionList = pvStack_10;
          return;
        }
      }
      *param_2 = iVar3;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      piVar1 = (int *)*param_2;
      if (piVar1 != (int *)0x0) {
        piVar2 = (int *)piVar1[9];
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          ExceptionList = &pvStack_10;
          (**(code **)(*piVar2 + 0x10))(piVar2 != piVar1);
          piVar1[9] = 0;
        }
        FUN_01674ea0(piVar1,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_0170d8dd(*param_2 + 4,0x1dbe32c);
      if (iVar5 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&std::
                   function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 18717 ; VA 0x009ba710 ; FUN_009ba710 */

void FUN_009ba710(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4c47;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar5 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x28);
      if (iVar3 == 0) {
        iVar3 = 0;
      }
      else {
        *(undefined4 *)(iVar3 + 0x24) = 0;
        uStack_8 = 1;
        if (*(undefined4 **)(iVar5 + 0x24) != (undefined4 *)0x0) {
          uVar4 = (**(code **)**(undefined4 **)(iVar5 + 0x24))(iVar3);
          *(undefined4 *)(iVar3 + 0x24) = uVar4;
          *param_2 = iVar3;
          ExceptionList = pvStack_10;
          return;
        }
      }
      *param_2 = iVar3;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      piVar1 = (int *)*param_2;
      if (piVar1 != (int *)0x0) {
        piVar2 = (int *)piVar1[9];
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          ExceptionList = &pvStack_10;
          (**(code **)(*piVar2 + 0x10))(piVar2 != piVar1);
          piVar1[9] = 0;
        }
        FUN_01674ea0(piVar1,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_0170d8dd(*param_2 + 4,0x1dbe394);
      if (iVar5 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&std::
                   function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 18718 ; VA 0x009ba880 ; FUN_009ba880 */

void FUN_009ba880(void)

{
  FUN_009ba890();
  return;
}



/* FUNCTION 18719 ; VA 0x009ba890 ; FUN_009ba890 */

int FUN_009ba890(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar3 = FUN_00b63e30();
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      iVar4 = param_1;
    }
    if (iVar4 != 0) {
      piVar2 = *(int **)(iVar4 + 0x130);
      piVar5 = *(int **)(iVar4 + 300);
      while( true ) {
        if (piVar5 == piVar2) {
          return 0;
        }
        iVar1 = *piVar5;
        if ((iVar1 != 0) &&
           (iVar4 = *(int *)(iVar1 + 0xc), iVar3 = FUN_0099be20(),
           (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da))) break;
        piVar5 = piVar5 + 1;
      }
      return iVar1;
    }
  }
  return 0;
}



/* FUNCTION 18720 ; VA 0x009ba920 ; FUN_009ba920 */

void __thiscall FUN_009ba920(int param_1,float param_2,float param_3,float param_4,char param_5)

{
  float fVar1;
  int iVar2;
  uint *puVar3;
  float10 fVar4;
  double dVar5;
  float fVar6;
  undefined8 uStack_98;
  float fStack_90;
  undefined8 uStack_8c;
  float fStack_84;
  undefined8 uStack_80;
  undefined4 uStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 != 0) {
    uStack_80 = 0;
    if (((NAN(param_2) != (param_2 == 0.0)) && (NAN(param_3) != (param_3 == 0.0))) &&
       (NAN(param_4) != (param_4 == 0.0))) {
      uStack_98 = 0;
      fStack_90 = 0.0;
      FUN_009c3ea0(&uStack_98);
      *(ulonglong *)(param_1 + 0x1c8) = CONCAT44((int)uStack_80,(int)uStack_80);
      *(undefined4 *)(param_1 + 0x1d0) = 0;
      return;
    }
    dVar5 = (double)(param_3 * param_3 + param_2 * param_2 + param_4 * param_4);
    FUN_017267a0();
    if (DAT_018ce2f8 < (float)dVar5) {
      FUN_01165610(0x358637bd);
    }
    dVar5 = (double)(param_3 * param_3 + param_2 * param_2 + param_4 * param_4);
    FUN_017267a0();
    puVar3 = *(uint **)(param_1 + 0x1f8);
    fVar6 = (float)uStack_80;
    if ((float)uStack_80 <= (float)dVar5) {
      fVar6 = (float)dVar5;
    }
    fVar1 = DAT_018ce2f8;
    if (fVar6 <= DAT_018ce2f8) {
      fVar1 = fVar6;
    }
    if ((NAN(fVar1) || NAN((float)(*puVar3 ^ (uint)puVar3))) ==
        (fVar1 == (float)(*puVar3 ^ (uint)puVar3))) {
      *puVar3 = (uint)fVar1 ^ (uint)puVar3;
    }
    dVar5 = (double)(param_3 * param_3 + param_2 * param_2 + param_4 * param_4);
    FUN_017267a0();
    fVar6 = DAT_018ce2f8 / (float)dVar5;
    param_2 = param_2 * fVar6;
    param_3 = param_3 * fVar6;
    param_4 = param_4 * fVar6;
    uStack_8c = CONCAT44(param_3,param_2);
    *(undefined8 *)(param_1 + 0x1c8) = uStack_8c;
    *(float *)(param_1 + 0x1d0) = param_4;
    fStack_84 = param_4;
    if (param_5 == '\0') {
      FUN_009c3ea0(&uStack_8c);
    }
    else {
      iVar2 = FUN_008b2e60(param_1);
      if ((iVar2 != 0) && (iVar2 = (**(code **)(*(int *)(iVar2 + 0x144) + 4))(), iVar2 != 0)) {
        FUN_00d226b0(&fStack_38);
        if ((*(int **)(param_1 + 0x6f8) != (int *)0x0) &&
           (iVar2 = (**(code **)(**(int **)(param_1 + 0x6f8) + 0x3c))(), iVar2 == 4)) {
          fStack_90 = param_2 * fStack_20 + param_3 * fStack_1c + param_4 * fStack_18;
          uStack_98 = CONCAT44(param_2 * fStack_2c + param_3 * fStack_28 + param_4 * fStack_24,
                               param_2 * fStack_38 + param_3 * fStack_34 + param_4 * fStack_30);
          FUN_009c3ea0(&uStack_98);
          return;
        }
        fStack_68 = fStack_38;
        fStack_64 = fStack_34;
        fStack_60 = fStack_30;
        fStack_5c = fStack_2c;
        fStack_58 = fStack_28;
        fStack_54 = fStack_24;
        fStack_50 = fStack_20;
        fStack_4c = fStack_1c;
        fStack_48 = fStack_18;
        fStack_44 = fStack_14;
        fStack_40 = fStack_10;
        fStack_3c = fStack_c;
        puVar3 = (uint *)FUN_011612d0();
        uStack_6c = 0;
        fStack_84 = (float)(puVar3[2] ^ DAT_018c4ea0) + fStack_3c;
        uStack_8c = CONCAT44((float)puVar3[1] * DAT_018f9988 + fStack_40,
                             (float)(*puVar3 ^ DAT_018c4ea0) + fStack_44);
        FUN_01163c80(&uStack_8c,CONCAT44(DAT_018ce2f8,(float)uStack_80),0);
        fStack_90 = param_2 * fStack_50 + param_3 * fStack_4c + param_4 * fStack_48;
        uStack_98 = (ulonglong)
                    (uint)(param_2 * fStack_68 + param_3 * fStack_64 + param_4 * fStack_60);
        fVar4 = (float10)FUN_01165610(0x358637bd);
        fVar6 = (float)uStack_80;
        if ((NAN((float)fVar4) || NAN(fVar6)) != ((float)fVar4 == fVar6)) {
          uStack_6c = 0;
          uStack_98 = CONCAT44(fVar6,fVar6);
          fStack_90 = 0.0;
        }
        FUN_009c3ea0(&uStack_98);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 18721 ; VA 0x009bae00 ; FUN_009bae00 */

void __thiscall FUN_009bae00(int param_1,int param_2,float *param_3,float *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  int iVar7;
  float *pfVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 *puVar11;
  float fVar12;
  undefined4 uVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fStack_12c;
  float fStack_124;
  float fStack_118;
  float fStack_114;
  float fStack_110;
  float fStack_10c;
  float fStack_108;
  float fStack_104;
  float fStack_100;
  float fStack_fc;
  float fStack_f8;
  float fStack_f4;
  float fStack_f0;
  float fStack_ec;
  float fStack_e8;
  float fStack_e4;
  undefined auStack_e0 [32];
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  float fStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  undefined auStack_80 [36];
  undefined auStack_5c [36];
  undefined auStack_38 [52];
  
  if (*(int *)(param_1 + 0x3f8) != 0) {
    iVar7 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8);
    if ((iVar7 != 0) && (*(int *)(iVar7 + 0x1a8) != 0)) {
      iVar7 = FUN_00c155c0();
      if (*(int *)(iVar7 + 0x3c) < 2) {
        if (((*(int *)(param_1 + 0x3f8) == 0) ||
            (iVar7 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar7 == 0)) || (iVar7 == -0x50)) {
          iVar7 = 0;
        }
        else {
          iVar7 = *(int *)(iVar7 + 0x70);
        }
        if (((param_2 != 0) && (*(int *)(param_1 + 0x6f4) != 0)) &&
           ((iVar7 != 0 && (*(int *)(param_2 + 0x1a8) != 0)))) {
          pfVar8 = (float *)FUN_00c157b0();
          iVar9 = FUN_00c157b0();
          uVar10 = FUN_01162330(auStack_e0,0x358637bd);
          FUN_01160c20(auStack_80,uVar10);
          fStack_110 = 0.0;
          fStack_10c = 0.0;
          fStack_108 = 0.0;
          fStack_114 = 0.0;
          FUN_01162b60(&fStack_110,&fStack_118);
          if (((DAT_01d64b0c <=
                (pfVar8[10] - param_3[10]) * (pfVar8[10] - param_3[10]) +
                (pfVar8[9] - param_3[9]) * (pfVar8[9] - param_3[9]) +
                (pfVar8[0xb] - param_3[0xb]) * (pfVar8[0xb] - param_3[0xb])) ||
              (DAT_018f76ac <= fStack_118)) ||
             ((fVar16 = *(float *)(iVar9 + 0x34) - param_4[1],
              fVar14 = *(float *)(iVar9 + 0x30) - *param_4,
              fVar12 = *(float *)(iVar9 + 0x38) - param_4[2],
              DAT_01d64b0c <= fVar16 * fVar16 + fVar14 * fVar14 + fVar12 * fVar12 ||
              (fVar16 = *(float *)(iVar9 + 0x40) - param_4[4],
              fVar14 = *(float *)(iVar9 + 0x3c) - param_4[3],
              fVar12 = *(float *)(iVar9 + 0x44) - param_4[5],
              DAT_01d64b0c <= fVar16 * fVar16 + fVar14 * fVar14 + fVar12 * fVar12)))) {
            FUN_00fa07b0();
            fVar16 = *(float *)(iVar7 + 0xd8) - param_3[9];
            fVar12 = *(float *)(iVar7 + 0xdc) - param_3[10];
            fVar14 = *(float *)(iVar7 + 0xe0) - param_3[0xb];
            fStack_f0 = param_3[3] * fVar12 + fVar16 * *param_3 + param_3[6] * fVar14;
            fStack_f4 = param_3[4] * fVar12 + param_3[1] * fVar16 + param_3[7] * fVar14;
            fStack_f8 = param_3[5] * fVar12 + param_3[2] * fVar16 + param_3[8] * fVar14;
            fStack_104 = fStack_f4 * pfVar8[1] + *pfVar8 * fStack_f0 + fStack_f8 * pfVar8[2] +
                         pfVar8[9];
            fStack_100 = fStack_f4 * pfVar8[4] + fStack_f0 * pfVar8[3] + fStack_f8 * pfVar8[5] +
                         pfVar8[10];
            fStack_fc = fStack_f0 * pfVar8[6] + fStack_f4 * pfVar8[7] + fStack_f8 * pfVar8[8] +
                        pfVar8[0xb];
            FUN_009c7460(param_2,&fStack_104,(float *)(iVar7 + 0xd8));
            uVar10 = (undefined4)DAT_018c0d60;
            uVar13 = (undefined4)((ulonglong)DAT_018c0d60 >> 0x20);
            FUN_017267a0();
            fStack_e8 = DAT_018ce2f8 / (float)(double)CONCAT44(uVar13,uVar10);
            fStack_ec = fStack_e8 * 0.0;
            fStack_e4 = fStack_ec;
            FUN_01161370(auStack_5c,&fStack_ec,
                         (fStack_110 * 0.0 + fStack_10c + fStack_108 * 0.0) * fStack_118);
            FUN_00fa07b0();
            puVar11 = (undefined4 *)FUN_01160c20(auStack_e0,auStack_5c);
            fStack_e4 = fStack_fc + 0.0;
            fStack_8c = fStack_104 + 0.0;
            uStack_a0 = puVar11[4];
            uStack_9c = puVar11[5];
            uStack_98 = puVar11[6];
            uStack_94 = puVar11[7];
            fStack_88 = fStack_100 + 0.0;
            fStack_124 = 0.0;
            uStack_b0 = *puVar11;
            uStack_ac = puVar11[1];
            uStack_a8 = puVar11[2];
            uStack_a4 = puVar11[3];
            uStack_c0 = puVar11[8];
            uStack_bc = CONCAT44(fStack_88,fStack_8c);
            fStack_12c = 0.0;
            fStack_b4 = fStack_e4;
            uStack_90 = uStack_c0;
            fStack_84 = fStack_e4;
            if (DAT_01f2dcd0 != '\0') {
              fStack_12c = pfVar8[0xb] - param_3[0xb];
              fStack_124 = pfVar8[10] - param_3[10];
              fStack_114 = pfVar8[9] - param_3[9];
              FUN_016774d0(DAT_01f2dcd0,"Pre Friction Displacement: %4.4f, %4.4f, %4.4f",fStack_114,
                           fStack_124,fStack_12c,0);
            }
            uVar10 = FUN_0071fcc0(auStack_e0);
            FUN_0071f260(auStack_38,uVar10);
            uVar10 = FUN_00c155c0();
            FUN_009afa00(param_1,auStack_38,uVar10);
            if (DAT_01f2dcd0 != '\0') {
              fVar12 = *pfVar8;
              fVar14 = pfVar8[3];
              fVar17 = *(float *)(iVar7 + 0xd8) - pfVar8[9];
              fVar18 = *(float *)(iVar7 + 0xdc) - pfVar8[10];
              fVar15 = *(float *)(iVar7 + 0xe0) - pfVar8[0xb];
              fVar16 = pfVar8[6];
              fVar1 = pfVar8[1];
              fVar2 = pfVar8[2];
              fVar3 = pfVar8[4];
              fVar4 = pfVar8[5];
              fVar5 = pfVar8[7];
              fVar6 = pfVar8[8];
              FUN_016774d0(DAT_01f2dcd0,"Platform displaced: %4.4f, %4.4f, %4.4f",fStack_114,
                           fStack_124,fStack_12c,0);
              if (DAT_01f2dcd0 != '\0') {
                FUN_016774d0(DAT_01f2dcd0,"character Position in Object Space: %4.4f, %4.4f, %4.4f",
                             fStack_f0,fStack_f4,fStack_f8,0);
                if (DAT_01f2dcd0 != '\0') {
                  FUN_016774d0(DAT_01f2dcd0,
                               "New characterPosition in Object Space: %4.4f, %4.4f, %4.4f",
                               fVar12 * fVar17 + fVar14 * fVar18 + fVar16 * fVar15,
                               fVar3 * fVar18 + fVar1 * fVar17 + fVar5 * fVar15,
                               fVar18 * fVar4 + fVar17 * fVar2 + fVar6 * fVar15,0);
                }
              }
            }
          }
          else if (DAT_01f2dcd0 != '\0') {
            FUN_016774b0(DAT_01f2dcd0,"Floor Movement too small",0);
            return;
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 18722 ; VA 0x009bb480 ; FUN_009bb480 */

int FUN_009bb480(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int in_stack_00000010;
  int *in_stack_00000014;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = in_stack_00000010;
  puStack_c = &LAB_017d4c68;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_00000010 != 0) {
    iVar2 = *(int *)(in_stack_00000010 + 0xc);
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) goto LAB_009bb4d0;
  }
  iVar5 = 0;
LAB_009bb4d0:
  iVar5 = FUN_009bb520(&stack0x00000004,iVar5);
  piVar3 = in_stack_00000014;
  if (in_stack_00000014 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000014 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*in_stack_00000014)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 18723 ; VA 0x009bb520 ; FUN_009bb520 */

void __thiscall FUN_009bb520(int param_1,float *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  uint *puVar3;
  char cVar4;
  float *pfVar5;
  int iVar6;
  undefined4 uVar7;
  float10 fVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  undefined8 uStack_38;
  float fStack_30;
  float fStack_2c;
  undefined8 uStack_28;
  double dStack_20;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4c8f;
  pvStack_10 = ExceptionList;
  uStack_38 = *(undefined8 *)param_2;
  fStack_30 = param_2[2];
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    pfVar5 = (float *)FUN_00b077e0();
    fVar12 = *param_2 - pfVar5[9];
    fVar10 = param_2[1] - pfVar5[10];
    fVar11 = param_2[2] - pfVar5[0xb];
    fStack_3c = pfVar5[5] * fVar10 + pfVar5[2] * fVar12 + pfVar5[8] * fVar11;
    uStack_38 = CONCAT44(pfVar5[4] * fVar10 + pfVar5[1] * fVar12 + pfVar5[7] * fVar11,
                         pfVar5[3] * fVar10 + fVar12 * *pfVar5 + pfVar5[6] * fVar11);
    fStack_30 = fStack_3c;
  }
  fStack_2c = 0.0;
  uStack_28 = 0.0;
  if ((param_3 == 0) && (cVar4 = FUN_009b7b40(&fStack_2c,&fStack_44), cVar4 != '\0')) {
    fStack_44 = fStack_2c - (float)uStack_38;
    fStack_40 = (float)uStack_28 - uStack_38._4_4_;
    fStack_3c = uStack_28._4_4_ - fStack_30;
    dVar9 = (double)(fStack_40 * fStack_40 + fStack_44 * fStack_44 + fStack_3c * fStack_3c);
    if (NAN(dVar9) == (dVar9 == 0.0)) {
      uStack_18 = (double)CONCAT44((uint)((ulonglong)dVar9 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar9,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      uStack_28 = (double)CONCAT44((uint)((ulonglong)(dVar9 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar9 - 0.0,0) & (uint)DAT_018c0da0);
      fVar8 = (float10)FUN_01160810();
      dStack_20 = (double)fVar8;
      dVar9 = DAT_018f76b0;
      if ((NAN(uStack_18) || NAN(dStack_20)) == (uStack_18 == dStack_20)) {
        dVar9 = uStack_18 * DAT_018f76b0;
      }
      if (dVar9 < uStack_28) {
        iVar6 = FUN_01674e20(0x10);
        uStack_8 = 0;
        if (iVar6 == 0) {
          uVar7 = 0;
        }
        else {
          uVar7 = FUN_01166ea0(&fStack_44,&uStack_38);
        }
        uStack_8 = 0xffffffff;
        uStack_18 = 0.0;
        FUN_0099cb10(uVar7,iVar6);
        *(undefined4 *)(param_1 + 0x2a0) = (undefined4)uStack_18;
        piVar2 = *(int **)(param_1 + 0x2a4);
        *(undefined4 *)(param_1 + 0x2a4) = uStack_18._4_4_;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar6 = piVar2[1] + -1;
          piVar2[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar6 = piVar2[2] + -1;
            piVar2[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
      }
    }
  }
  fVar10 = DAT_018ce2f8;
  puVar3 = *(uint **)(param_1 + 0x1f8);
  if ((NAN(DAT_018ce2f8) || NAN((float)(*puVar3 ^ (uint)puVar3))) ==
      (DAT_018ce2f8 == (float)(*puVar3 ^ (uint)puVar3))) {
    *puVar3 = (uint)puVar3 ^ 0x3f800000;
  }
  fStack_3c = fStack_30 + 0.0;
  *(ulonglong *)(param_1 + 0x1a4) = CONCAT44(uStack_38._4_4_ + 0.0,(float)uStack_38 + fVar10);
  *(float *)(param_1 + 0x1ac) = fStack_3c;
  if (DAT_01d64ae0 == '\0') {
    *(undefined4 *)(param_1 + 0x19c) = 0;
    piVar2 = *(int **)(param_1 + 0x1a0);
    *(undefined4 *)(param_1 + 0x1a0) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar6 = piVar2[1] + -1;
      piVar2[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  FUN_009c5b10(param_3);
  FUN_009c5c00(&uStack_38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18724 ; VA 0x009bb850 ; FUN_009bb850 */

void FUN_009bb850(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_0099f370(auStack_24);
  uStack_18 = puVar4[1];
  piVar2 = (int *)*puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 0;
  piStack_1c = piVar2;
  uStack_14 = uStack_18;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  (**(code **)(*piVar2 + 0xac))(0x3dcccccd);
  param_1[1] = uStack_14;
  *param_1 = piVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18725 ; VA 0x009bb900 ; FUN_009bb900 */

int FUN_009bb900(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_28 = 0x3f800000;
  uStack_24 = 0x3f800000;
  piStack_20 = (int *)&DAT_3f800000;
  uStack_1c = 0x3f800000;
  uStack_18 = 0x3f800000;
  piStack_14 = (int *)&DAT_3f800000;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009c1620(param_1,&uStack_1c,&uStack_28);
  if (DAT_01d64a80 != '\0') {
    iVar4 = thunk_FUN_00c48580();
    if (iVar4 != 0) {
      puVar5 = (undefined4 *)FUN_0060dcd0(&uStack_24,iVar4);
      uStack_18 = *puVar5;
      piVar3 = (int *)puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      piStack_14 = piVar3;
      iVar4 = FUN_009b11e0(&uStack_18);
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          iVar4 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            iVar4 = (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_20 + 1;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          iVar4 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            iVar4 = (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 1;
    iVar2 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar3 = param_2 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18726 ; VA 0x009bba40 ; FUN_009bba40 */

undefined4 * __thiscall FUN_009bba40(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined auStack_c [4];
  int *piStack_8;
  
  iVar5 = param_2;
  puVar4 = (undefined4 *)FUN_008a3ee0(param_2);
  if (*(int *)(param_1 + 0x5c) != 0) {
    return puVar4;
  }
  iVar5 = *(int *)(iVar5 + 8);
  if (iVar5 != 0) {
    iVar6 = *(int *)(iVar5 + 0x34);
    if ((iVar6 != 0) && (iVar5 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      iVar5 = FUN_005c8ac0();
    }
    if ((iVar5 != 0) &&
       (iVar5 = *(int *)(iVar5 + 0xc), iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
       (uint)*(ushort *)(iVar6 + 0x1da))) {
      uVar7 = FUN_005c3230();
      goto LAB_009bbaac;
    }
  }
  uVar7 = 0;
LAB_009bbaac:
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_c,uVar7);
  uVar7 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 *)(param_1 + 0x5c) = uVar7;
  piVar3 = *(int **)(param_1 + 0x60);
  *(undefined4 *)(param_1 + 0x60) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    puVar4 = (undefined4 *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      puVar4 = (undefined4 *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar4 = (undefined4 *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_8 + 1;
    iVar5 = *piVar3;
    puVar4 = (undefined4 *)*piVar3;
    *piVar3 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar4 = (undefined4 *)(**(code **)*piStack_8)();
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (*(int *)(param_1 + 0x5c) != 0) {
    piVar3 = *(int **)(*(int *)(param_1 + 0x5c) + 0x58);
    puVar4 = (undefined4 *)*piVar3;
    if (puVar4 != (undefined4 *)piVar3[1]) {
      do {
        param_2 = FUN_0170d75d(*puVar4,0,&RBX::Instance::RTTI_Type_Descriptor,
                               &RBX::PartInstance::RTTI_Type_Descriptor,0);
        if (param_2 != 0) {
          piVar3 = *(int **)(param_1 + 0x68);
          if (*(int **)(param_1 + 0x6c) == piVar3) {
            FUN_006030d0(piVar3,&param_2);
          }
          else {
            *piVar3 = param_2;
            *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + 4;
          }
        }
        puVar4 = puVar4 + 2;
      } while (puVar4 != *(undefined4 **)(*(int *)(*(int *)(param_1 + 0x5c) + 0x58) + 4));
    }
    puVar4 = (undefined4 *)FUN_009dffa0(param_1 + 0x58);
  }
  return puVar4;
}



/* FUNCTION 18727 ; VA 0x009bbba0 ; FUN_009bbba0 */

void __thiscall FUN_009bbba0(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  byte bVar10;
  undefined4 *puVar11;
  code *pcStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4d42;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_008a3ee0(param_2);
  if (*(char *)(param_1 + 0x290) != '\0') {
    cVar3 = FUN_00fa0fb0(*(undefined4 *)(param_1 + 0x28),param_1,0);
    *(bool *)(param_1 + 0x290) = cVar3 == '\0';
  }
  if (*param_2 == param_1) {
    if (param_2[2] == 0) {
      piVar6 = (int *)(param_1 + 0x344);
      piStack_18 = (int *)0x7;
      do {
        if (*piVar6 != 0) {
          LOCK();
          piVar1 = (int *)(*piVar6 + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_009c8ad0(piVar6[-1],*piVar6);
        piVar6[-1] = 0;
        piStack_20 = (int *)*piVar6;
        *piVar6 = 0;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_20[1] + -1;
          piStack_20[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            iVar8 = piStack_20[2] + -1;
            piStack_20[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
        }
        piVar6 = piVar6 + 2;
        piStack_18 = (int *)((int)piStack_18 + -1);
      } while (piStack_18 != (int *)0x0);
      *(undefined4 *)(param_1 + 0x3f8) = 0;
      piVar6 = *(int **)(param_1 + 0x3fc);
      *(undefined4 *)(param_1 + 0x3fc) = 0;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar8 = piVar6[1] + -1;
        piVar6[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar8 = piVar6[2] + -1;
          piVar6[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (*(int *)(param_1 + 0x228) != 0) {
        piVar6 = (int *)(param_1 + 0x37c);
        piStack_18 = (int *)0x10;
        do {
          if (*piVar6 != 0) {
            LOCK();
            piVar1 = (int *)(*piVar6 + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          FUN_009c8ad0(piVar6[-1],*piVar6);
          piVar6[-1] = 0;
          piStack_20 = (int *)*piVar6;
          *piVar6 = 0;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar8 = piStack_20[1] + -1;
            piStack_20[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              iVar8 = piStack_20[2] + -1;
              piStack_20[2] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)(*piStack_20 + 4))();
              }
            }
          }
          piVar6 = piVar6 + 2;
          piStack_18 = (int *)((int)piStack_18 + -1);
        } while (piStack_18 != (int *)0x0);
      }
      FUN_01679490();
      FUN_01679490();
      FUN_01679490();
      FUN_01679490();
    }
    else {
      FUN_009bf2f0();
      FUN_008a4100();
      uStack_34 = uStack_2c;
      uStack_24 = CONCAT31(uStack_24._1_3_,1);
      uStack_2c = uStack_24;
      pcStack_40 = FUN_009bc830;
      uStack_3c = 0xfffffecc;
      uStack_38 = 0;
      iStack_30 = param_1;
      piStack_20 = (int *)FUN_0099e690(&iStack_1c,&pcStack_40);
      uStack_8 = 0;
      cVar3 = FUN_01679300(piStack_20);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(piStack_20);
      }
      uStack_8 = 0xffffffff;
      if (iStack_1c != 0) {
        piVar6 = (int *)(iStack_1c + 4);
        LOCK();
        iVar8 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          FUN_01674ea0(iStack_1c);
        }
      }
      FUN_008a4100();
      uStack_34 = uStack_2c;
      uStack_24 = uStack_24 & 0xffffff00;
      uStack_2c = uStack_24;
      pcStack_40 = FUN_009bc830;
      uStack_3c = 0xfffffecc;
      uStack_38 = 0;
      iStack_30 = param_1;
      piStack_20 = (int *)FUN_0099e690(&iStack_1c,&pcStack_40);
      uStack_8 = 1;
      cVar3 = FUN_01679300(piStack_20);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(piStack_20);
      }
      uStack_8 = 0xffffffff;
      if (iStack_1c != 0) {
        piVar6 = (int *)(iStack_1c + 4);
        LOCK();
        iVar8 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          FUN_01674ea0(iStack_1c);
        }
      }
      if (*(int *)(param_1 + 0x774) != 0) {
        FUN_009c6f30();
      }
    }
  }
  iStack_1c = FUN_008b33d0(param_1);
  if (iStack_1c == 0) {
    piStack_18 = (int *)0x0;
  }
  else {
    piStack_18 = *(int **)(iStack_1c + 0x1b4);
  }
  if (*(int **)(param_1 + 0x6f4) != piStack_18) {
    cVar3 = FUN_00f94340();
    if ((cVar3 != '\0') && (*(int *)(param_1 + 0x178) != 0)) {
      FUN_00f93aa0(param_1);
    }
    if ((*(int *)(param_1 + 0x6f8) != 0) && (piStack_18 == (int *)0x0)) {
      FUN_00dc4f00();
    }
    if (*(int *)(param_1 + 0x6f4) != 0) {
      if (DAT_01d69160 != '\0') {
        piVar6 = (int *)(*(int *)(param_1 + 0x6f4) + 0x638);
        *piVar6 = *piVar6 + -1;
      }
      bVar4 = FUN_01679ce0();
      bVar10 = 1;
      if ((bVar4 & 0x7f) != 0) {
        bVar10 = bVar4 & 0x7f;
      }
      *(byte *)(param_1 + 0x223) = -bVar10;
      FUN_01679490();
      FUN_01679490();
      *(undefined4 *)(param_1 + 0x6f8) = 0;
      piStack_20 = *(int **)(param_1 + 0x6fc);
      *(undefined4 *)(param_1 + 0x6fc) = 0;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_20[1] + -1;
        piStack_20[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar8 = piStack_20[2] + -1;
          piStack_20[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      if ('\0' < *(char *)(param_1 + 0x21c)) {
        FUN_00c3dac0(param_1 + 0x54,0,1);
        FUN_00ca4900(0,0);
        FUN_00ca4900(1,0);
      }
    }
    *(int **)(param_1 + 0x6f4) = piStack_18;
    if (piStack_18 == (int *)0x0) {
      FUN_00c3dac0(param_1 + 0x54,0,1);
      FUN_00ca4900(0,0);
      FUN_00ca4900(1,0);
    }
    else {
      if (DAT_01d69160 != '\0') {
        piStack_18[0x18e] = piStack_18[0x18e] + 1;
      }
      if (DAT_01d641ec != '\0') {
        FUN_009c4910(0);
      }
      if (*(int *)(param_1 + 0x228) == 0) {
        piStack_20 = *(int **)(param_1 + 0x34);
        if ((piStack_20 == (int *)0x0) ||
           (iVar8 = piStack_20[3], iVar5 = FUN_00b63e30(), piVar6 = piStack_20,
           (uint)*(ushort *)(iVar5 + 0x1da) <
           (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
          piVar6 = (int *)0x0;
        }
        FUN_009bf280(piVar6);
      }
      FUN_009a6aa0();
      uVar7 = FUN_00dbf2c0(param_1);
      uStack_28 = 0;
      uStack_24 = 0;
      FUN_0099ca80(uVar7,param_2);
      *(undefined4 *)(param_1 + 0x6f8) = uStack_28;
      piStack_20 = *(int **)(param_1 + 0x6fc);
      *(uint *)(param_1 + 0x6fc) = uStack_24;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_20[1] + -1;
        piStack_20[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar8 = piStack_20[2] + -1;
          piStack_20[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      iVar8 = FUN_008b2e60(param_1);
      iVar5 = FUN_0097bf90(param_1);
      if (iVar5 == 0) {
        iVar5 = 0;
      }
      else {
        iVar5 = FUN_009ba890(iVar5);
      }
      if (param_1 == iVar5) {
        iVar5 = (**(code **)(*(int *)(iVar8 + 0x144) + 4))();
        iVar5 = *(int *)(iVar5 + 0x1ac);
        if ((((iVar5 == 5) || (iVar5 == 4)) || (iVar5 == 1)) || (iVar5 == 3)) {
          (**(code **)(*(int *)(iVar8 + 0x144) + 4))();
          iVar5 = FUN_00d215f0();
          if (iVar5 != param_1 + 0x134) {
            (**(code **)(*(int *)(iVar8 + 0x144) + 4))();
            FUN_00d24b00(param_1);
          }
        }
        bVar4 = FUN_01679ce0();
        bVar10 = 1;
        if ((bVar4 & 0x7f) != 0) {
          bVar10 = bVar4 & 0x7f;
        }
        *(byte *)(param_1 + 0x223) = bVar10;
      }
      cVar3 = FUN_00f94340();
      if (cVar3 == '\0') {
        if (DAT_01d64a98 != '\0') {
          iStack_1c = FUN_0063f220(iStack_1c);
          iStack_1c = iStack_1c + 200;
          uStack_8 = 2;
          uVar9 = FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 3;
          uStack_24 = uVar9;
          piStack_20 = (int *)FUN_01674e20(0x1c);
          if (piStack_20 == (int *)0x0) {
            piStack_20 = (int *)0x0;
          }
          else {
            *piStack_20 = 0;
            piStack_20[1] = 1;
            piStack_20[2] = (int)FUN_009b03b0;
            piStack_20[3] = (int)_guard_check_icall;
            piStack_20[4] = 0;
            piStack_20[5] = iStack_1c;
            piStack_20[6] = param_1;
          }
          FUN_016797d0(piStack_20);
          piStack_18 = piStack_20;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            piStack_20[1] = piStack_20[1] + 1;
            UNLOCK();
          }
          uStack_14 = 1;
          uStack_8._0_1_ = 4;
          FUN_01675290(uVar9);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          cVar3 = FUN_01679300(&piStack_18);
          if (cVar3 != '\0') {
            FUN_01679490();
            FUN_016791c0(&piStack_18);
          }
          uStack_8 = 0xffffffff;
          uStack_14 = 0;
          if (piStack_18 != (int *)0x0) {
            piVar6 = piStack_18 + 1;
            LOCK();
            iVar8 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            uStack_14 = 0;
            if (iVar8 == 1) {
              FUN_01674ea0(piStack_18);
              uStack_14 = 0;
            }
          }
        }
      }
      else {
        iVar8 = FUN_0063f220(iStack_1c);
        if ((iVar8 != 0) && (*(int *)(iVar8 + 0xb8) != 0)) {
          FUN_00f938f0(param_1);
        }
      }
      if (*(int *)(param_1 + 0x228) == 1) {
        cVar3 = FUN_00971ce0(param_2[2],1);
        if (cVar3 == '\0') {
          iVar8 = FUN_008b2e60(param_2[2]);
          if (iVar8 != 0) {
            if ('\0' < *(char *)(param_1 + 0x222)) {
              FUN_009adbf0();
            }
            uStack_8 = 5;
            uVar9 = FUN_01675290(DAT_02110da8);
            uStack_8._0_1_ = 6;
            uStack_24 = uVar9;
            piStack_20 = (int *)FUN_01674e20(0x1c);
            if (piStack_20 == (int *)0x0) {
              piStack_20 = (int *)0x0;
            }
            else {
              *piStack_20 = 0;
              piStack_20[1] = 1;
              piStack_20[2] = (int)FUN_009b0300;
              piStack_20[3] = (int)_guard_check_icall;
              piStack_20[4] = 0;
              piStack_20[5] = param_1 + 0x710;
              piStack_20[6] = param_1;
            }
            FUN_016797d0(piStack_20);
            piStack_18 = piStack_20;
            if (piStack_20 != (int *)0x0) {
              LOCK();
              piStack_20[1] = piStack_20[1] + 1;
              UNLOCK();
            }
            uStack_14 = 2;
            uStack_8._0_1_ = 7;
            FUN_01675290(uVar9);
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            cVar3 = FUN_01679300(&piStack_18);
            if (cVar3 != '\0') {
              FUN_01679490();
              FUN_016791c0(&piStack_18);
            }
            uStack_8 = 0xffffffff;
            if (piStack_18 != (int *)0x0) {
              piVar6 = piStack_18 + 1;
              LOCK();
              iVar8 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar8 == 1) {
                FUN_01674ea0(piStack_18);
              }
            }
          }
        }
        else {
          FUN_009adbf0();
        }
      }
    }
  }
  if (*param_2 == param_1) {
    piVar6 = (int *)param_2[1];
    if (piVar6 != (int *)0x0) {
      (**(code **)(*piVar6 + 0x30))();
      puVar11 = (undefined4 *)piVar6[0xb];
      if (puVar11 != (undefined4 *)0x0) {
        puVar2 = (undefined4 *)puVar11[1];
        for (puVar11 = (undefined4 *)*puVar11; puVar11 != puVar2; puVar11 = puVar11 + 2) {
          FUN_009b31d0(*puVar11);
        }
      }
    }
    piVar6 = (int *)param_2[2];
    if (piVar6 != (int *)0x0) {
      (**(code **)(*piVar6 + 0x30))();
      puVar11 = (undefined4 *)piVar6[0xb];
      if (puVar11 != (undefined4 *)0x0) {
        puVar2 = (undefined4 *)puVar11[1];
        for (puVar11 = (undefined4 *)*puVar11; puVar11 != puVar2; puVar11 = puVar11 + 2) {
          FUN_009b31d0(*puVar11);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18728 ; VA 0x009bc4b0 ; FUN_009bc4b0 */

void __fastcall FUN_009bc4b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  
  if (*(char *)(param_1 + 0x292) != '\0') {
    *(undefined *)(param_1 + 0x292) = 0;
    *(undefined8 *)(param_1 + 0x298) = 0;
    *(undefined4 *)(param_1 + 0x2a0) = 0;
    piVar2 = *(int **)(param_1 + 0x2a4);
    *(undefined4 *)(param_1 + 0x2a4) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    cVar4 = FUN_00f94320();
    if (cVar4 == '\0') {
      FUN_005e6780(0);
    }
    else {
      FUN_009b1bb0();
    }
  }
  if (*(int **)(param_1 + 0x6f8) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x6f8) + 0x30))();
  }
  return;
}



/* FUNCTION 18729 ; VA 0x009bc560 ; FUN_009bc560 */

void __thiscall FUN_009bc560(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined auStack_24 [8];
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4d60;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_2 + 0x34);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009b6f20();
  if (iVar1 == iVar4) {
    FUN_009c68d0();
    piVar5 = *(int **)(iVar2 + 0x28);
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    uVar6 = 0x9bc5af;
    cVar3 = FUN_009cb180(piVar5,&param_2);
    if (cVar3 != '\0') {
      cVar3 = FUN_00f94320();
      if (cVar3 == '\0') {
        FUN_005e6780(param_2);
      }
      else {
        FUN_009b1bb0(param_2,uVar6,piVar5,&DAT_01d65062);
      }
    }
    cVar3 = FUN_00f94320();
    if (cVar3 == '\0') {
      FUN_0054ef60(*(undefined4 *)(iVar2 + 0x28));
      FUN_006ecaa0();
    }
    else {
      puVar7 = &uStack_1c;
      FUN_0060e0c0(puVar7,iVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[2] = piStack_18[2] + 1;
        UNLOCK();
      }
      uStack_8 = 0;
      FUN_009b1bb0(uStack_1c,piStack_18,puVar7,&DAT_01d6506e);
      uStack_8 = 0xffffffff;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[2] + -1;
        piStack_18[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if (DAT_01d64a70 != '\0') {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar4 = FUN_00ae6b40();
    if ((((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) && (*(int *)(param_1 + 0x708) != 0)) &&
       (*(int *)(param_1 + 0x708) != iVar2)) {
      FUN_008a5010();
      uVar6 = FUN_0060dcd0(auStack_24,iVar2);
      FUN_005587e0(uVar6);
      FUN_00550b30();
    }
  }
  FUN_008a4130(iVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18730 ; VA 0x009bc6f0 ; FUN_009bc6f0 */

void FUN_009bc6f0(int *param_1)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4d80;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*param_1 + 0x34);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009b6f20();
  if (iVar1 == iVar4) {
    FUN_009c68d0();
    piVar7 = *(int **)(*piVar2 + 0x28);
    if (0xf < (uint)piVar7[5]) {
      piVar7 = (int *)*piVar7;
    }
    uVar6 = 0x9bc743;
    cVar3 = FUN_009cb180(piVar7,&param_1);
    if (cVar3 != '\0') {
      cVar3 = FUN_00f94320();
      if (cVar3 == '\0') {
        piVar7 = (int *)0x9bc77f;
        FUN_005e6780(param_1);
      }
      else {
        FUN_009b1bb0(param_1,uVar6,piVar7,&DAT_01d6507a);
      }
    }
    cVar3 = FUN_00f94320();
    if (cVar3 == '\0') {
      FUN_0054ef60(*(undefined4 *)(*piVar2 + 0x28));
      FUN_006ecaa0();
    }
    else {
      piVar5 = (int *)piVar2[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
        piVar5 = (int *)piVar2[1];
      }
      iVar1 = *piVar2;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
      uStack_8 = 0;
      FUN_009b1bb0(iVar1,piVar5,piVar7,&DAT_01d65086);
      uStack_8 = 0xffffffff;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  FUN_008a41c0(piVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18731 ; VA 0x009bc830 ; FUN_009bc830 */

int __thiscall FUN_009bc830(int param_1,int ***param_2,int *param_3,char param_4)

{
  int ***pppiVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  int **ppiVar7;
  int ****ppppiVar8;
  int *piVar9;
  int ***pppiVar10;
  uint uVar11;
  undefined4 *puVar12;
  int **appiStack_74 [4];
  undefined4 uStack_64;
  int **ppiStack_60;
  int ***pppiStack_5c;
  int ***pppiStack_58;
  int ***pppiStack_54;
  int ***pppiStack_38;
  int ***pppiStack_34;
  int ***pppiStack_30;
  int **ppiStack_2c;
  int ***pppiStack_28;
  int ***pppiStack_20;
  int **ppiStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4db0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  pppiStack_54 = (int ***)DAT_01ee37cc;
  uStack_8 = 0;
  pppiStack_58 = (int ***)0x9bc866;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = FUN_01675290();
  uStack_8._0_1_ = 1;
  pppiStack_20 = param_2;
  piVar9 = (int *)0x0;
  if (param_2 != (int ***)0x0) {
    ppiVar7 = param_2[3];
    pppiStack_54 = (int ***)0x9bc888;
    iVar6 = FUN_00aff8c0();
    param_1 = iStack_14;
    if ((uint)*(ushort *)(ppiVar7 + 0x76) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      if (*(int *)(iStack_14 + 0x228) != 0) {
        puVar12 = &DAT_01d64c60;
        ppiVar7 = pppiStack_20[10];
        do {
          pppiStack_58 = (int ***)(puVar12 + 1);
          if (0xf < (uint)puVar12[6]) {
            pppiStack_58 = (int ***)*pppiStack_58;
          }
          ppiStack_60 = ppiVar7;
          if ((int *)0xf < ppiVar7[5]) {
            ppiStack_60 = (int **)*ppiVar7;
          }
          pppiStack_54 = (int ***)puVar12[5];
          pppiStack_5c = (int ***)ppiVar7[4];
          uStack_64 = 0x9bc8e3;
          cVar4 = FUN_0055c360();
          if (cVar4 != '\0') {
            if (pppiStack_20[0xd] == *(int ***)(iStack_14 + 0x34)) {
              pppiStack_54 = pppiStack_20;
              pppiStack_58 = (int ***)&pppiStack_34;
              pppiStack_5c = (int ***)0x9bc915;
              pppiStack_54 = (int ***)FUN_0060dcd0();
              param_1 = iStack_14;
              pppiStack_58 = (int ***)0x9bc929;
              FUN_005587e0();
              pppiStack_28 = pppiStack_30;
              if (pppiStack_30 == (int ***)0x0) break;
              LOCK();
              ppiVar7 = (int **)((int)pppiStack_30[1] + -1);
              pppiStack_30[1] = ppiVar7;
              UNLOCK();
              if (ppiVar7 != (int **)0x0) break;
              pppiStack_54 = (int ***)0x9bc94b;
              (*(code *)**pppiStack_30)();
              LOCK();
              ppiVar7 = (int **)((int)pppiStack_28[2] + -1);
              pppiStack_28[2] = ppiVar7;
              UNLOCK();
              if (ppiVar7 != (int **)0x0) break;
              ppiVar7 = *pppiStack_28;
            }
            else {
              if (*(int ***)(iStack_14 + 0x34) == (int **)0x0) {
LAB_009bc990:
                pppiStack_34 = (int ***)0x0;
                pppiStack_54 = (int ***)&pppiStack_34;
                pppiStack_30 = (int ***)0x0;
                piVar9 = (int *)0x2;
              }
              else {
                pppiStack_54 = (int ***)(puVar12 + 1);
                pppiStack_58 = (int ***)0x9bc96f;
                pppiStack_54 = (int ***)FUN_008a1240();
                pppiStack_58 = (int ***)0x9bc975;
                pppiStack_54 = (int ***)FUN_006e16a0();
                if (pppiStack_54 == (int ***)0x0) goto LAB_009bc990;
                pppiStack_58 = &ppiStack_2c;
                pppiStack_5c = (int ***)0x9bc986;
                pppiStack_54 = (int ***)FUN_0060dcd0();
                piVar9 = (int *)0x1;
              }
              param_1 = iStack_14;
              pppiStack_58 = (int ***)0x9bc9ba;
              piStack_18 = piVar9;
              FUN_005587e0();
              if ((((uint)piVar9 & 2) != 0) &&
                 (piVar9 = (int *)((uint)piVar9 & 0xfffffffd), piStack_18 = piVar9,
                 pppiStack_30 != (int ***)0x0)) {
                LOCK();
                ppiVar7 = (int **)((int)pppiStack_30[1] + -1);
                pppiStack_30[1] = ppiVar7;
                UNLOCK();
                if (ppiVar7 == (int **)0x0) {
                  pppiStack_54 = (int ***)0x9bc9da;
                  (*(code *)**pppiStack_30)();
                  LOCK();
                  ppiVar7 = (int **)((int)pppiStack_30[2] + -1);
                  pppiStack_30[2] = ppiVar7;
                  UNLOCK();
                  if (ppiVar7 == (int **)0x0) {
                    pppiStack_54 = (int ***)0x9bc9ec;
                    (*(code *)(*pppiStack_30)[1])();
                  }
                }
              }
              pppiVar10 = pppiStack_28;
              if ((((uint)piVar9 & 1) == 0) ||
                 (piStack_18 = (int *)((uint)piVar9 & 0xfffffffe), pppiStack_28 == (int ***)0x0))
              break;
              LOCK();
              ppiVar7 = (int **)((int)pppiStack_28[1] + -1);
              pppiStack_28[1] = ppiVar7;
              UNLOCK();
              if (ppiVar7 != (int **)0x0) break;
              pppiStack_54 = (int ***)0x9bca0e;
              (*(code *)**pppiStack_28)();
              LOCK();
              pppiVar1 = pppiVar10 + 2;
              ppiVar7 = (int **)((int)*pppiVar1 + -1);
              *pppiVar1 = ppiVar7;
              UNLOCK();
              if (ppiVar7 != (int **)0x0) break;
              ppiVar7 = *pppiVar10;
            }
            pppiStack_54 = (int ***)0x9bca1f;
            (*(code *)ppiVar7[1])();
            break;
          }
          puVar12 = puVar12 + 7;
          param_1 = iStack_14;
        } while (puVar12 != &DAT_01d64e20);
      }
      pppiVar10 = (int ***)0x0;
      do {
        pppiStack_28 = (int ***)CONCAT31(pppiStack_28._1_3_,*(int *)(param_1 + 0x228) != 0);
        pppiStack_54 = pppiStack_28;
        pppiStack_5c = (int ***)0x9bca35;
        pppiStack_58 = pppiVar10;
        pppiStack_58 = (int ***)FUN_009b3ce0();
        pppiStack_54 = (int ***)pppiStack_58[4];
        ppiStack_60 = pppiStack_20[10];
        if ((int **)0xf < pppiStack_58[5]) {
          pppiStack_58 = (int ***)*pppiStack_58;
        }
        pppiStack_5c = (int ***)ppiStack_60[4];
        if ((int *)0xf < ppiStack_60[5]) {
          ppiStack_60 = (int **)*ppiStack_60;
        }
        uStack_64 = 0x9bca62;
        pppiStack_30 = pppiStack_54;
        cVar4 = FUN_0055c360();
        if (cVar4 != '\0') {
          pppiStack_28 = *(int ****)(param_1 + 0x34);
          pppiStack_54 = pppiStack_20;
          if (((int ***)pppiStack_20[0xd] != pppiStack_28) &&
             (pppiStack_54 = (int ***)0x0, pppiStack_28 != (int ***)0x0)) {
            pppiStack_30 = (int ***)CONCAT31(pppiStack_30._1_3_,*(int *)(param_1 + 0x228) != 0);
            pppiStack_54 = pppiStack_30;
            pppiStack_5c = (int ***)0x9bca98;
            pppiStack_58 = pppiVar10;
            pppiStack_54 = (int ***)FUN_009b3ce0();
            pppiStack_58 = (int ***)0x9bcaa4;
            pppiStack_30 = (int ***)FUN_008a1240();
            if (pppiStack_30 != (int ***)0x0) {
              ppiVar7 = pppiStack_30[3];
              pppiStack_54 = (int ***)0x9bcab3;
              iVar6 = FUN_00aff8c0();
              pppiStack_54 = pppiStack_30;
              param_1 = iStack_14;
              if ((uint)*(ushort *)(ppiVar7 + 0x76) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                  (uint)*(ushort *)(iVar6 + 0x1da)) goto LAB_009bcad8;
            }
            pppiStack_54 = (int ***)0x0;
          }
LAB_009bcad8:
          pppiStack_5c = (int ***)0x9bcae1;
          pppiStack_58 = pppiVar10;
          FUN_009c2f60();
          break;
        }
        pppiVar10 = (int ***)((int)pppiVar10 + 1);
      } while ((int)pppiVar10 < 7);
      pppiVar10 = pppiStack_20;
      ppiStack_60 = (int **)&pppiStack_58;
      pppiStack_5c = pppiStack_20;
      uStack_64 = 0x9bcaf0;
      FUN_0060dcd0();
      pppiStack_5c = (int ***)0x9bcafa;
      FUN_009c8ad0();
      piVar9 = piStack_18;
      if (*(int *)(param_1 + 0x774) != 0) {
        ppiStack_60 = (int **)&pppiStack_58;
        pppiStack_5c = pppiVar10;
        uStack_64 = 0x9bcb0f;
        FUN_0060dcd0();
        pppiStack_5c = (int ***)0x9bcb19;
        FUN_009c8c80();
        piVar9 = piStack_18;
      }
    }
  }
  pppiStack_58 = (int ***)0x9bcb22;
  pppiStack_54 = (int ***)param_1;
  pppiStack_28 = (int ***)FUN_008f7870();
  if ((pppiStack_28 == (int ***)0x0) ||
     ((*(int *)((int)pppiStack_28 + 0x4a0) != 2 && (*(int *)((int)pppiStack_28 + 0x4a0) != 3))))
  goto LAB_009bcd41;
  if (param_2 == (int ***)0x0) {
LAB_009bcb8d:
    uVar11 = (uint)piVar9 | 8;
    pppiStack_30 = (int ***)0x0;
    ppppiVar8 = &pppiStack_34;
    pppiStack_20 = (int ***)0x0;
  }
  else {
    ppiVar7 = param_2[3];
    pppiStack_54 = (int ***)0x9bcb53;
    iVar6 = FUN_00c8dbe0();
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(ppiVar7 + 0x76) - (uint)*(ushort *)(iVar6 + 0x1d8)) goto LAB_009bcb8d;
    pppiStack_20 = param_2;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_18 = param_3;
    uVar11 = (uint)piVar9 | 4;
    ppppiVar8 = (int ****)&ppiStack_1c;
  }
  pppiVar10 = ppppiVar8[1];
  *ppppiVar8 = (int ***)0x0;
  ppppiVar8[1] = (int ***)0x0;
  if (((uVar11 & 8) != 0) && (uVar11 = uVar11 & 0xfffffff7, pppiStack_30 != (int ***)0x0)) {
    LOCK();
    ppiVar7 = (int **)((int)pppiStack_30[1] + -1);
    pppiStack_30[1] = ppiVar7;
    UNLOCK();
    if (ppiVar7 == (int **)0x0) {
      pppiStack_54 = (int ***)0x9bcbd5;
      (*(code *)**pppiStack_30)();
      LOCK();
      ppiVar7 = (int **)((int)pppiStack_30[2] + -1);
      pppiStack_30[2] = ppiVar7;
      UNLOCK();
      if (ppiVar7 == (int **)0x0) {
        pppiStack_54 = (int ***)0x9bcbe7;
        (*(code *)(*pppiStack_30)[1])();
      }
    }
  }
  piVar9 = piStack_18;
  if (((uVar11 & 4) != 0) && (piStack_18 != (int *)0x0)) {
    LOCK();
    iVar6 = piStack_18[1] + -1;
    piStack_18[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      pppiStack_54 = (int ***)0x9bcc03;
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piVar9 + 2;
      iVar6 = *piVar2 + -1;
      *piVar2 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pppiStack_54 = (int ***)0x9bcc14;
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  if (pppiStack_20 != (int ***)0x0) {
    if (param_4 == '\0') {
      if (DAT_01d68a9c == '\0') {
        if (pppiVar10 != (int ***)0x0) {
          LOCK();
          pppiVar10[1] = (int **)((int)pppiVar10[1] + 1);
          UNLOCK();
        }
        pppiStack_58 = pppiStack_20;
        pppiStack_5c = (int ***)0x9bcd1c;
        pppiStack_54 = pppiVar10;
        FUN_009bb900();
      }
      else {
        pppiStack_54 = (int ***)0x1;
        pppiStack_30 = appiStack_74;
        puVar12 = (undefined4 *)FUN_0060e0c0();
        uStack_8._0_1_ = 3;
        *puVar12 = 0;
        puVar12[1] = 0;
        if (pppiVar10 != (int ***)0x0) {
          LOCK();
          pppiVar10[1] = (int **)((int)pppiVar10[1] + 1);
          UNLOCK();
        }
        FUN_0099b130();
        FUN_0090ca30();
        if (pppiStack_20 != (int ***)0x0) {
          LOCK();
          ppiVar7 = (int **)((int)pppiStack_20[2] + -1);
          pppiStack_20[2] = ppiVar7;
          UNLOCK();
          if (ppiVar7 == (int **)0x0) {
            pppiStack_54 = (int ***)0x9bccf3;
            (*(code *)(*pppiStack_20)[1])();
          }
        }
      }
    }
    else {
      pppiStack_54 = (int ***)&pppiStack_38;
      pppiStack_38 = *(int ****)(iStack_14 + 0x330);
      pppiStack_58 = (int ***)(iStack_14 + 0x324);
      pppiStack_5c = pppiStack_20;
      ppiStack_60 = (int **)0x9bcc54;
      pppiStack_34 = pppiStack_38;
      pppiStack_30 = pppiStack_38;
      FUN_009c1620();
    }
  }
  if (pppiVar10 != (int ***)0x0) {
    LOCK();
    ppiVar7 = (int **)((int)pppiVar10[1] + -1);
    pppiVar10[1] = ppiVar7;
    UNLOCK();
    if (ppiVar7 == (int **)0x0) {
      pppiStack_54 = (int ***)0x9bcd30;
      (*(code *)**pppiVar10)();
      LOCK();
      ppiVar7 = (int **)((int)pppiVar10[2] + -1);
      pppiVar10[2] = ppiVar7;
      UNLOCK();
      if (ppiVar7 == (int **)0x0) {
        pppiStack_54 = (int ***)0x9bcd41;
        (*(code *)(*pppiVar10)[1])();
      }
    }
  }
LAB_009bcd41:
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  pppiStack_58 = (int ***)0x9bcd4b;
  pppiStack_54 = (int ***)uVar5;
  iVar6 = FUN_01675290();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar3 = *piVar9;
    iVar6 = *piVar9;
    *piVar9 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pppiStack_54 = (int ***)0x9bcd67;
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar9 = param_3 + 2;
      iVar3 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pppiStack_54 = (int ***)0x9bcd76;
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 18732 ; VA 0x009bcd90 ; FUN_009bcd90 */

undefined4 * __thiscall
FUN_009bcd90(undefined4 param_1,undefined4 *param_2,int *param_3,undefined4 *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char cVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined auStack_4c [8];
  code *pcStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d4e09;
  pvStack_10 = ExceptionList;
  puStack_20 = (undefined4 *)0x0;
  uStack_8 = 0;
  puVar9 = param_2;
  if (DAT_01d64a50 == '\0') {
    puStack_18 = param_2;
    ExceptionList = &pvStack_10;
    if (param_2 != (undefined4 *)0x0) {
      iVar3 = param_2[3];
      ExceptionList = &pvStack_10;
      iVar8 = FUN_00daf5e0();
      puVar9 = (undefined4 *)(uint)*(ushort *)(iVar8 + 0x1da);
      if ((undefined4 *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) <=
          puVar9) {
        puStack_14 = (undefined4 *)0x0;
        puVar12 = &DAT_01d64e20;
        puStack_1c = (undefined4 *)0x0;
        puStack_20 = (undefined4 *)puStack_18[10];
        do {
          puVar9 = puVar12;
          if (0xf < (uint)puVar12[5]) {
            puVar9 = (undefined4 *)*puVar12;
          }
          puVar11 = puStack_20;
          if (0xf < (uint)puStack_20[5]) {
            puVar11 = (undefined4 *)*puStack_20;
          }
          cVar7 = FUN_0055c360(puVar11,puStack_20[4],puVar9,puVar12[4]);
          uVar10 = uStack_30;
          if (cVar7 != '\0') {
            if ((char)param_4 == '\0') {
              FUN_009b10e0(puStack_18[10]);
              puVar9 = (undefined4 *)FUN_009c4910(1);
            }
            else {
              uStack_24 = uStack_24 & 0xffffff00;
              uStack_30 = uStack_24;
              pcStack_44 = FUN_009c4910;
              uStack_40 = 0xfffffecc;
              uStack_3c = 0;
              uStack_38 = uVar10;
              uStack_34 = param_1;
              param_4 = (undefined4 *)FUN_0099e410(&puStack_20,&pcStack_44);
              uStack_8 = CONCAT31(uStack_8._1_3_,7);
              FUN_009a4ad0(&DAT_01d64e20 + (int)puStack_14 * 6);
              cVar7 = FUN_01679300(param_4);
              if (cVar7 != '\0') {
                FUN_01679490();
                FUN_016791c0(param_4);
              }
              uStack_8 = uStack_8 & 0xffffff00;
              if (puStack_20 != (undefined4 *)0x0) {
                piVar1 = puStack_20 + 1;
                LOCK();
                iVar3 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                  FUN_01674ea0(puStack_20);
                }
              }
              puVar9 = (undefined4 *)FUN_009c4910(0);
            }
            break;
          }
          puVar12 = puVar12 + 6;
          puStack_14 = (undefined4 *)((int)puStack_14 + 1);
          puVar9 = puStack_1c + 6;
          puStack_1c = puVar9;
        } while (puVar9 < (undefined4 *)0x90);
      }
    }
  }
  else {
    puStack_14 = param_2;
    ExceptionList = &pvStack_10;
    if (param_2 != (undefined4 *)0x0) {
      iVar3 = param_2[3];
      ExceptionList = &pvStack_10;
      iVar8 = FUN_00daf5e0();
      puVar9 = (undefined4 *)(uint)*(ushort *)(iVar8 + 0x1da);
      if ((undefined4 *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) <=
          puVar9) {
        if ((char)param_4 == '\0') {
          FUN_009a4ad0(puStack_14[10]);
          puStack_18 = (undefined4 *)0x0;
          uStack_8._0_1_ = 5;
          cVar7 = FUN_01679300(&puStack_18);
          uStack_8 = (uint)uStack_8._1_3_ << 8;
          param_4._3_1_ = cVar7;
          if (puStack_18 != (undefined4 *)0x0) {
            piVar1 = puStack_18 + 1;
            LOCK();
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              FUN_01674ea0(puStack_18);
            }
          }
          if (param_4._3_1_ != '\0') {
            FUN_009b10e0(puStack_14[10]);
            FUN_009c4910(1);
          }
          FUN_009a4d30(&param_2);
          puStack_18 = (undefined4 *)0x0;
          uStack_8._0_1_ = 6;
          puVar9 = (undefined4 *)FUN_01679300(&puStack_18);
          param_4 = (undefined4 *)CONCAT13((char)puVar9,param_4._0_3_);
          uStack_8 = (uint)uStack_8._1_3_ << 8;
          if (puStack_18 != (undefined4 *)0x0) {
            piVar1 = puStack_18 + 1;
            LOCK();
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            puVar9 = (undefined4 *)(iVar3 + -1);
            if (puVar9 == (undefined4 *)0x0) {
              puVar9 = (undefined4 *)FUN_01674ea0(puStack_18);
            }
          }
          if (param_4._3_1_ != '\0') {
            puVar9 = (undefined4 *)FUN_009b11e0(&param_2);
          }
        }
        else {
          pcStack_2c = FUN_009ab710;
          puStack_18 = param_2 + 0x13;
          uStack_28 = 0xfffffecc;
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          puStack_1c = (undefined4 *)
                       FUN_0099e050(auStack_4c,0xfffffecc009ab710,0,param_1,param_2,param_3);
          uStack_8._0_1_ = 2;
          uVar10 = FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 3;
          uStack_24 = uVar10;
          puStack_14 = (undefined4 *)FUN_01674e20(0x38);
          if (puStack_14 == (undefined4 *)0x0) {
            puStack_14 = (undefined4 *)0x0;
          }
          else {
            *puStack_14 = 0;
            puStack_14[1] = 1;
            puStack_14[2] = FUN_009b04c0;
            puStack_14[3] = FUN_009b07d0;
            puStack_14[4] = 0;
            puStack_14[5] = puStack_18;
            uVar4 = puStack_1c[1];
            uVar5 = puStack_1c[2];
            uVar6 = puStack_1c[3];
            puStack_14[6] = *puStack_1c;
            puStack_14[7] = uVar4;
            puStack_14[8] = uVar5;
            puStack_14[9] = uVar6;
            puStack_14[10] = puStack_1c[4];
            puStack_14[0xb] = 0;
            puStack_14[0xc] = 0;
            if (puStack_1c[6] != 0) {
              LOCK();
              piVar1 = (int *)(puStack_1c[6] + 4);
              *piVar1 = *piVar1 + 1;
              UNLOCK();
            }
            puStack_14[0xb] = puStack_1c[5];
            puStack_14[0xc] = puStack_1c[6];
          }
          FUN_016797d0(puStack_14);
          param_4 = puStack_14;
          if (puStack_14 != (undefined4 *)0x0) {
            LOCK();
            puStack_14[1] = puStack_14[1] + 1;
            UNLOCK();
          }
          puStack_20 = (undefined4 *)0x1;
          uStack_8._0_1_ = 4;
          FUN_01675290(uVar10);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_009a4d30(&param_2);
          cVar7 = FUN_01679300(&param_4);
          if (cVar7 != '\0') {
            FUN_01679490();
            FUN_016791c0(&param_4);
          }
          if (param_4 != (undefined4 *)0x0) {
            piVar1 = param_4 + 1;
            LOCK();
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              FUN_01674ea0(param_4);
            }
          }
          uStack_8 = uStack_8 & 0xffffff00;
          FUN_00706c80();
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          puVar9 = (undefined4 *)FUN_009ab710(param_2,param_3);
        }
      }
    }
  }
  piVar1 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    puVar9 = (undefined4 *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar9 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar9 = (undefined4 *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar9;
}



/* FUNCTION 18733 ; VA 0x009bd250 ; FUN_009bd250 */

void __thiscall FUN_009bd250(int param_1,undefined *param_2)

{
  if ((param_2 == &DAT_0211a3a0) && (*(int *)(param_1 + 0x34) != 0)) {
    FUN_009bf2f0();
  }
  return;
}



/* FUNCTION 18734 ; VA 0x009bd270 ; FUN_009bd270 */

void __thiscall FUN_009bd270(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  puVar2 = param_2;
  param_2 = (undefined4 *)
            FUN_0170d75d(*param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                         &RBX::PartInstance::RTTI_Type_Descriptor,0);
  if (param_2 != (undefined4 *)0x0) {
    piVar1 = *(int **)(param_1 + 0x10);
    if (*(int **)(param_1 + 0x14) == piVar1) {
      FUN_006030d0(piVar1,&param_2);
    }
    else {
      *piVar1 = (int)param_2;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
  }
  if (puVar2[2] != 0) {
    piVar1 = *(int **)(param_1 + 0x10);
    piVar3 = *(int **)(param_1 + 0xc);
    if (piVar3 != piVar1) {
      while (*piVar3 != puVar2[2]) {
        piVar3 = piVar3 + 1;
        if (piVar3 == piVar1) {
          return;
        }
      }
      if (piVar3 != piVar1) {
        FUN_0170cc70(piVar3,piVar3 + 1,(int)piVar1 - (int)(piVar3 + 1));
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -4;
      }
    }
  }
  return;
}



/* FUNCTION 18735 ; VA 0x009bd300 ; FUN_009bd300 */

void __thiscall FUN_009bd300(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uStack_3c;
  undefined4 uStack_2c;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4e72;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  puStack_1c = param_1;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    if (param_2 != 0) {
      ExceptionList = &pvStack_10;
      FUN_01679490();
      FUN_01679490();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01d64a60 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_009ab540();
    }
    FUN_006eccd0();
    uStack_8 = 0;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8 = 1;
    puStack_14 = (undefined4 *)FUN_01674e20(0x30);
    if (puStack_14 == (undefined4 *)0x0) {
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 1;
      puStack_14[2] = FUN_009b0430;
      puStack_14[3] = _guard_check_icall;
      puStack_14[4] = 0;
      puStack_14[6] = FUN_009b1040;
      puStack_14[7] = 0xfffffecc;
      puStack_14[8] = 0;
      puStack_14[9] = uStack_2c;
      puStack_14[5] = param_1 + 0x1ca;
      *(ulonglong *)(puStack_14 + 10) = CONCAT44(uStack_3c,param_1);
    }
    FUN_016797d0(puStack_14);
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    uStack_18 = 2;
    uStack_8 = 2;
    FUN_01675290(uVar5);
    puVar3 = puStack_1c;
    uStack_18 = 1;
    uStack_8 = 3;
    cVar4 = FUN_01679300(&puStack_14);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_14);
    }
    uStack_8 = 0xffffffff;
    if (puStack_14 != (undefined4 *)0x0) {
      piVar1 = puStack_14 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puStack_14);
      }
    }
    FUN_006eccd0();
    uStack_8 = 4;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8 = 5;
    puStack_20 = (undefined4 *)FUN_01674e20(0x30);
    if (puStack_20 == (undefined4 *)0x0) {
      puStack_20 = (undefined4 *)0x0;
    }
    else {
      *puStack_20 = 0;
      puStack_20[1] = 1;
      puStack_20[2] = FUN_009b0400;
      puStack_20[3] = _guard_check_icall;
      puStack_20[4] = 0;
      puStack_20[6] = FUN_009c2ca0;
      puStack_20[7] = 0xfffffecc;
      puStack_20[8] = 0;
      puStack_20[9] = uStack_2c;
      puStack_20[5] = puVar3 + 0x1cc;
      *(ulonglong *)(puStack_20 + 10) = CONCAT44(uStack_3c,puVar3);
    }
    FUN_016797d0(puStack_20);
    puStack_1c = puStack_20;
    if (puStack_20 != (undefined4 *)0x0) {
      LOCK();
      puStack_20[1] = puStack_20[1] + 1;
      UNLOCK();
    }
    uStack_18 = 9;
    uStack_8 = 6;
    FUN_01675290(uVar5);
    uStack_8 = 7;
    cVar4 = FUN_01679300(&puStack_1c);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_1c);
    }
    uStack_8 = 0xffffffff;
    if (puStack_1c != (undefined4 *)0x0) {
      piVar1 = puStack_1c + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puStack_1c);
      }
    }
  }
  FUN_008a4210(param_2,param_3);
  if ((DAT_01d64a98 == '\0') && (cVar4 = FUN_00f94340(), cVar4 == '\0')) {
    FUN_00f958f0(param_2,param_3);
  }
  else {
    FUN_01679490();
  }
  if (param_3 != 0) {
    FUN_0099ed80();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18736 ; VA 0x009bd630 ; FUN_009bd630 */

void __thiscall FUN_009bd630(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_008b33d0(param_1 + -0x150);
  if (iVar1 == 0) {
    if (DAT_01d64a98 != '\0') {
      FUN_01679490();
      return;
    }
  }
  else {
    FUN_009b7ec0(param_2);
  }
  return;
}



/* FUNCTION 18737 ; VA 0x009bd670 ; FUN_009bd670 */

void FUN_009bd670(int param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 uint param_10)

{
  int *piVar1;
  undefined4 in_stack_ffffff34;
  undefined4 in_stack_ffffff38;
  undefined in_stack_ffffff3c;
  undefined uVar2;
  undefined4 in_stack_ffffff40;
  undefined4 in_stack_ffffff44;
  undefined4 *in_stack_ffffff48;
  undefined4 *in_stack_ffffff4c;
  undefined4 uVar3;
  undefined4 in_stack_ffffff50;
  undefined4 uVar4;
  int aiStack_a8 [9];
  int *piStack_84;
  int aiStack_80 [9];
  int *piStack_5c;
  uint auStack_58 [2];
  undefined auStack_50 [28];
  uint auStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4ebe;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (DAT_01d63f08 == '\0') {
    uVar3 = 0;
    uVar4 = 0xf;
    uVar2 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("This API is not enabled yet",0x1b);
    FUN_005e65e0(uVar2,in_stack_ffffff40,in_stack_ffffff44,in_stack_ffffff48,uVar3,uVar4);
  }
  else if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uVar3 = 0;
    uVar4 = 0xf;
    uVar2 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Emote ID should be greater than 0",0x21);
    FUN_005e65e0(uVar2,in_stack_ffffff40,in_stack_ffffff44,in_stack_ffffff48,uVar3,uVar4);
  }
  else {
    auStack_34[0] = 0;
    ExceptionList = &pvStack_10;
    if (param_3 != 0) {
      auStack_34[0] = param_3;
      if ((param_3 & 1) == 0) {
        in_stack_ffffff4c = &uStack_2c;
        in_stack_ffffff50 = 0;
        in_stack_ffffff48 = &param_5;
        in_stack_ffffff44 = 0x9bd748;
        ExceptionList = &pvStack_10;
        (**(code **)(param_3 & 0xfffffffe))(in_stack_ffffff48,in_stack_ffffff4c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
        ExceptionList = &pvStack_10;
      }
    }
    uStack_8._0_1_ = 2;
    FUN_0054f510(&param_10);
    FUN_0099b770(in_stack_ffffff34,in_stack_ffffff38,in_stack_ffffff3c,in_stack_ffffff40,
                 in_stack_ffffff44,in_stack_ffffff48,in_stack_ffffff4c,in_stack_ffffff50);
    uStack_8._0_1_ = 3;
    FUN_005e5f00(auStack_34);
    piStack_84 = (int *)0x0;
    uStack_8._0_1_ = 5;
    piVar1 = (int *)FUN_0099c380(auStack_58);
    uStack_8._0_1_ = 6;
    piStack_84 = piVar1;
    if (auStack_58[0] != 0) {
      if (((auStack_58[0] & 1) == 0) && (*(code **)(auStack_58[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_58[0] & 0xfffffffe))(auStack_50,auStack_50,2);
      }
      auStack_58[0] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_009bdb90(param_1,param_2,aiStack_a8,aiStack_80);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x10))(CONCAT31((int3)((uint)aiStack_a8 >> 8),piVar1 != aiStack_a8));
    }
    if (piStack_5c != (int *)0x0) {
      (**(code **)(*piStack_5c + 0x10))
                (CONCAT31((int3)((uint)aiStack_80 >> 8),piStack_5c != aiStack_80));
      piStack_5c = (int *)0x0;
    }
    uStack_8._0_1_ = 8;
    if (auStack_34[0] != 0) {
      if (((auStack_34[0] & 1) == 0) && (*(code **)(auStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      auStack_34[0] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  uStack_8 = 10;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18738 ; VA 0x009bd8b0 ; FUN_009bd8b0 */

void FUN_009bd8b0(uint param_1)

{
  int iVar1;
  undefined uVar2;
  int *piVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  char **in_stack_00000020;
  uint in_stack_00000024;
  int in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined auStack_f4 [24];
  undefined4 uStack_dc;
  undefined4 *puStack_d8;
  char *pcStack_d4;
  undefined4 uStack_d0;
  undefined uStack_cc;
  undefined4 uStack_c8;
  int iStack_c4;
  int *piStack_c0;
  int *piStack_bc;
  uint *puStack_b8;
  int aiStack_ac [9];
  int *piStack_88;
  int aiStack_84 [9];
  int *piStack_60;
  uint auStack_5c [2];
  undefined auStack_54 [28];
  uint auStack_38 [2];
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = in_stack_0000001c;
  puStack_c = &LAB_017d4f26;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if (DAT_01d63ee0 == '\0') {
    uStack_d0 = 0x1b;
    piStack_bc = (int *)0x0;
    puStack_b8 = (uint *)0xf;
    pcStack_d4 = "This API is not enabled yet";
    uStack_cc = 0;
    puStack_d8 = (undefined4 *)0x9bd905;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_d0 = 0x9bd90d;
    FUN_005e65e0();
  }
  else if (((int)in_stack_00000020 < 1) &&
          (((int)in_stack_00000020 < 0 || (in_stack_0000001c == 0)))) {
    uStack_d0 = 0x21;
    piStack_bc = (int *)0x0;
    puStack_b8 = (uint *)0xf;
    pcStack_d4 = "Emote ID should be greater than 0";
    uStack_cc = 0;
    puStack_d8 = (undefined4 *)0x9bd944;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_d0 = 0x9bd94c;
    FUN_005e65e0();
  }
  else if (DAT_01d63f08 == '\0') {
    in_stack_00000020 = &pcStack_d4;
    puStack_d8 = &stack0x00000044;
    uStack_dc = 0x9bdaa7;
    ExceptionList = &pvStack_10;
    FUN_0054f510();
    puStack_18 = auStack_f4;
    uStack_8._0_1_ = 10;
    FUN_0054f510(&stack0x00000024);
    uStack_8._0_1_ = 0xb;
    FUN_0054ef60(&param_1);
    uStack_8._0_1_ = 2;
    FUN_009bdfa0();
  }
  else {
    auStack_38[0] = 0;
    ExceptionList = &pvStack_10;
    if (in_stack_00000024 != 0) {
      auStack_38[0] = in_stack_00000024;
      if ((in_stack_00000024 & 1) == 0) {
        piStack_bc = &iStack_30;
        puStack_b8 = (uint *)0x0;
        piStack_c0 = &stack0x0000002c;
        iStack_c4 = 0x9bd998;
        ExceptionList = &pvStack_10;
        (**(code **)(in_stack_00000024 & 0xfffffffe))();
      }
      else {
        iStack_30 = in_stack_0000002c;
        uStack_2c = in_stack_00000030;
        uStack_28 = in_stack_00000034;
        uStack_24 = in_stack_00000038;
        uStack_20 = in_stack_0000003c;
        ExceptionList = &pvStack_10;
      }
    }
    uStack_8._0_1_ = 3;
    puStack_d8 = &stack0x00000044;
    uStack_dc = 0x9bd9ad;
    FUN_0054f510();
    puStack_d8 = (undefined4 *)0x9bd9b5;
    FUN_0099b770();
    puStack_b8 = auStack_38;
    uStack_8._0_1_ = 4;
    piStack_bc = (int *)0x9bd9c5;
    FUN_005e5f00();
    piStack_88 = (int *)0x0;
    puStack_b8 = auStack_5c;
    uStack_8._0_1_ = 6;
    piStack_bc = (int *)0x9bd9dc;
    piVar3 = (int *)FUN_0099c4c0();
    uStack_8._0_1_ = 7;
    piStack_88 = piVar3;
    if (auStack_5c[0] != 0) {
      if (((auStack_5c[0] & 1) == 0) && (*(code **)(auStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
        piStack_c0 = (int *)auStack_54;
        puStack_b8 = (uint *)0x2;
        iStack_c4 = 0x9bda09;
        piStack_bc = piStack_c0;
        (**(code **)(auStack_5c[0] & 0xfffffffe))();
      }
      auStack_5c[0] = 0;
    }
    puStack_b8 = (uint *)aiStack_84;
    piStack_bc = aiStack_ac;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    piStack_c0 = (int *)in_stack_00000020;
    iStack_c4 = iVar1;
    uStack_c8 = 0x9bda2e;
    FUN_009bdb90();
    if (piVar3 != (int *)0x0) {
      puStack_b8 = (uint *)CONCAT31((int3)((uint)aiStack_ac >> 8),piVar3 != aiStack_ac);
      piStack_bc = (int *)0x9bda47;
      (**(code **)(*piVar3 + 0x10))();
    }
    if (piStack_60 != (int *)0x0) {
      puStack_b8 = (uint *)CONCAT31((int3)((uint)aiStack_84 >> 8),piStack_60 != aiStack_84);
      piStack_bc = (int *)0x9bda5e;
      (**(code **)(*piStack_60 + 0x10))();
      piStack_60 = (int *)0x0;
    }
    uStack_8._0_1_ = 9;
    if (auStack_38[0] != 0) {
      if (((auStack_38[0] & 1) == 0) && (*(code **)(auStack_38[0] & 0xfffffffe) != (code *)0x0)) {
        piStack_c0 = &iStack_30;
        puStack_b8 = (uint *)0x2;
        iStack_c4 = 0x9bda8a;
        piStack_bc = piStack_c0;
        (**(code **)(auStack_38[0] & 0xfffffffe))();
      }
      auStack_38[0] = 0;
    }
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    puStack_b8 = (uint *)(in_stack_00000018 + 1);
    uVar4 = param_1;
    if (0xfff < puStack_b8) {
      uVar4 = *(uint *)(param_1 - 4);
      puStack_b8 = (uint *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_b8 = (uint *)&UNK_009bdb8f;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    piStack_c0 = (int *)0x9bdb11;
    piStack_bc = (int *)uVar4;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      piStack_c0 = &stack0x0000002c;
      puStack_b8 = (uint *)0x2;
      iStack_c4 = 0x9bdb47;
      piStack_bc = piStack_c0;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    piStack_c0 = (int *)&stack0x0000004c;
    puStack_b8 = (uint *)0x2;
    iStack_c4 = 0x9bdb75;
    piStack_bc = piStack_c0;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18739 ; VA 0x009bdb90 ; FUN_009bdb90 */

int __thiscall
FUN_009bdb90(int param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5)

{
  int *piVar1;
  bool bVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined **ppuVar7;
  undefined uVar8;
  undefined auStack_2d4 [12];
  undefined4 uStack_2c8;
  char *pcStack_2c4;
  undefined4 uStack_2c0;
  undefined *puStack_2bc;
  undefined *puStack_2b8;
  undefined4 uStack_2b4;
  undefined4 *puStack_2b0;
  undefined **ppuStack_2ac;
  undefined *puStack_2a8;
  uint auStack_2a4 [2];
  undefined *puStack_29c;
  undefined *puStack_298;
  char *pcStack_294;
  code *pcStack_290;
  undefined auStack_284 [88];
  undefined auStack_22c [88];
  undefined auStack_1d4 [88];
  undefined auStack_17c [88];
  undefined auStack_124 [88];
  undefined auStack_cc [48];
  undefined auStack_9c [24];
  undefined4 uStack_84;
  int *piStack_80;
  undefined auStack_7c [36];
  undefined4 uStack_58;
  undefined auStack_54 [36];
  undefined4 uStack_30;
  undefined *puStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4fe2;
  pvStack_10 = ExceptionList;
  pcStack_294 = (char *)0x9bdbbb;
  ExceptionList = &pvStack_10;
  pcStack_290 = (code *)param_1;
  iStack_18 = param_1;
  puStack_1c = (undefined *)FUN_008f7870();
  if (param_1 != 0) {
    iVar6 = *(int *)(param_1 + 0x34);
    if ((iVar6 != 0) && (param_1 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      pcStack_290 = (code *)0x9bdbd8;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar6 = *(int *)(param_1 + 0xc);
      pcStack_290 = (code *)0x9bdbea;
      iVar5 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        pcStack_290 = (code *)0x9bdc0c;
        iVar6 = FUN_005cf750();
        goto LAB_009bdc12;
      }
    }
  }
  iVar6 = 0;
LAB_009bdc12:
  iVar5 = iStack_18;
  if ((puStack_1c == (undefined *)0x0) || (iVar6 == 0)) {
    puStack_2a8 = (undefined *)0x30;
    ppuStack_2ac = (undefined **)0x1938c40;
  }
  else if ((*(int *)(puStack_1c + 0x4a0) == 1) || (*(int *)(puStack_1c + 0x4a0) == 3)) {
    pcStack_290 = (code *)iStack_18;
    pcStack_294 = (char *)0x9bdc4f;
    pcStack_294 = (char *)FUN_009b4820();
    puStack_298 = (undefined *)0x9bdc55;
    iStack_18 = FUN_00980070();
    if (*(int *)(iVar6 + 0xf4) == iStack_18) {
      if (DAT_01d64a88 != '\0') {
        pcStack_290 = (code *)param_3;
        puStack_298 = auStack_9c;
        pcStack_294 = (char *)param_2;
        puStack_29c = (undefined *)0x9bdc93;
        pcStack_290 = (code *)FUN_0058c590();
        pcStack_294 = "assetID";
        uStack_8 = 0;
        puStack_298 = (undefined *)0x9bdcae;
        FUN_00632a10();
        pcStack_290 = (code *)0x9bdcb9;
        FUN_005507b0();
        puStack_1c = (undefined *)auStack_2a4;
        uStack_8 = 1;
        puStack_2a8 = &uStack_11;
        puStack_2b8 = auStack_9c;
        ppuStack_2ac = (undefined **)&uStack_11;
        puStack_2b0 = (undefined4 *)&uStack_11;
        uStack_2b4 = 0xb;
        uStack_2c0 = 0x9bdce9;
        puStack_2bc = auStack_cc;
        FUN_006370e0();
        piStack_24 = (int *)&puStack_2bc;
        uStack_8._0_1_ = 2;
        uStack_2c0 = 0xe;
        ppuStack_2ac = (undefined **)0x0;
        puStack_2a8 = (undefined *)0xf;
        pcStack_2c4 = "emoteTriggered";
        puStack_2bc = (undefined *)((uint)puStack_2bc & 0xffffff00);
        uStack_2c8 = 0x9bdd12;
        FUN_005542c0();
        puStack_2c = auStack_2d4;
        uStack_8._0_1_ = 3;
        pcStack_2c4 = (char *)0x0;
        uStack_2c0 = 0xf;
        auStack_2d4[0] = 0;
        FUN_005542c0("playEmoteApi",0xc);
        uStack_8._0_1_ = 4;
        uVar8 = 0;
        FUN_005542c0("client",6);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0087a540(uVar8);
        uStack_8 = 0xffffffff;
        pcStack_290 = FUN_005509f0;
        pcStack_294 = (char *)0x1;
        puStack_298 = (undefined *)0x30;
        auStack_2a4[1] = 0x9bdd85;
        puStack_29c = auStack_cc;
        FUN_016f32d1();
      }
      pcStack_294 = (char *)&uStack_28;
      pcStack_290 = (code *)iVar5;
      puStack_298 = (undefined *)0x9bdd8f;
      FUN_0060e0c0();
      piVar3 = piStack_24;
      puStack_20 = &uStack_84;
      uStack_8 = 0;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      uStack_84 = uStack_28;
      piStack_80 = piVar3;
      puStack_2c = auStack_7c;
      uStack_58 = 0;
      uStack_8._0_1_ = 7;
      if (*(undefined4 **)(param_4 + 0x24) != (undefined4 *)0x0) {
        puStack_2b0 = (undefined4 *)auStack_7c;
        uStack_2b4 = 0x9bdde8;
        uStack_58 = (**(code **)**(undefined4 **)(param_4 + 0x24))();
      }
      uStack_30 = 0;
      uStack_8._0_1_ = 9;
      if (*(undefined4 **)(param_5 + 0x24) != (undefined4 *)0x0) {
        puStack_2b0 = (undefined4 *)auStack_54;
        uStack_2b4 = 0x9bde10;
        uStack_30 = (**(code **)**(undefined4 **)(param_5 + 0x24))();
      }
      puStack_2b0 = &uStack_84;
      uStack_8._0_1_ = 10;
      uStack_2b4 = 0x9bde26;
      FUN_009a03a0();
      puStack_2b0 = (undefined4 *)auStack_284;
      uStack_8._0_1_ = 0xb;
      ppuStack_2ac = (undefined **)0x0;
      uStack_2b4 = 0x9bde42;
      FUN_009a03a0();
      puStack_2b0 = (undefined4 *)auStack_22c;
      uStack_8._0_1_ = 0xc;
      uStack_2b4 = 0x9bde58;
      FUN_009a03a0();
      puStack_2b0 = (undefined4 *)auStack_1d4;
      uStack_8._0_1_ = 0xd;
      uStack_2b4 = 0x9bde6e;
      FUN_009a03a0();
      puStack_2b0 = (undefined4 *)auStack_124;
      uStack_8._0_1_ = 0xe;
      uStack_2b4 = 0x9bde7e;
      cVar4 = FUN_00585a40();
      if (cVar4 == '\0') {
        puStack_2b0 = (undefined4 *)auStack_124;
        uStack_2b4 = 0x9bde97;
        FUN_009a03a0();
        puStack_2b0 = (undefined4 *)0x58;
        uStack_8._0_1_ = 0xf;
        uStack_2b4 = 0x9bdea2;
        iVar6 = FUN_01674e20();
        uStack_8._0_1_ = 0x10;
        if (iVar6 == 0) {
          auStack_2a4[0] = 0;
        }
        else {
          puStack_2b0 = (undefined4 *)auStack_17c;
          uStack_2b4 = 0x9bdebe;
          auStack_2a4[0] = FUN_009a03a0();
        }
        puStack_2b0 = (undefined4 *)0x9bded0;
        FUN_009a3470();
        puStack_2b0 = (undefined4 *)0x9bdedb;
        FUN_009a3470();
        bVar2 = true;
      }
      else {
        puStack_2b0 = (undefined4 *)0x9bdeec;
        FUN_009a3470();
        bVar2 = false;
      }
      puStack_2b0 = (undefined4 *)0x9bdefb;
      FUN_009a3470();
      ppuVar7 = &PTR_FUN_01939818;
      if (!bVar2) {
        ppuVar7 = (undefined **)0x0;
      }
      puStack_2b0 = (undefined4 *)0x9bdf15;
      ppuStack_2ac = ppuVar7;
      FUN_009a3470();
      puStack_2b0 = (undefined4 *)0x9bdf20;
      FUN_009a3470();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      puStack_2b0 = (undefined4 *)0x9bdf2c;
      FUN_009a3470();
      puStack_2b0 = (undefined4 *)param_3;
      uStack_2b4 = param_2;
      puStack_2b8 = (undefined *)0x9bdf3a;
      iVar6 = FUN_0091ed60();
      if (piVar3 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return iVar6;
      }
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 != 0) {
        ExceptionList = pvStack_10;
        return iVar5;
      }
      pcStack_290 = (code *)0x9bdf4f;
      iVar6 = (**(code **)(*piVar3 + 4))();
      ExceptionList = pvStack_10;
      return iVar6;
    }
    puStack_2a8 = (undefined *)0x2c;
    ppuStack_2ac = (undefined **)0x1938c74;
  }
  else {
    puStack_2a8 = (undefined *)0x26;
    ppuStack_2ac = (undefined **)0x1938ccc;
  }
  pcStack_294 = (char *)0x0;
  pcStack_290 = (code *)0xf;
  auStack_2a4[0] = auStack_2a4[0] & 0xffffff00;
  puStack_2b0 = (undefined4 *)0x9bdf83;
  FUN_005542c0();
  puStack_2a8 = (undefined *)0x9bdf8b;
  iVar6 = FUN_009a5b30();
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 18740 ; VA 0x009bdf61 ; FUN_009bdf61 */

void FUN_009bdf61(void)

{
  int unaff_EBP;
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("Humanoid must be in the DataModel to play Emotes",0x30);
  FUN_009a5b30(uVar1);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 18741 ; VA 0x009bdfa0 ; FUN_009bdfa0 */

void __thiscall FUN_009bdfa0(int param_1,uint param_2)

{
  int *piVar1;
  undefined ***pppuVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined **ppuVar6;
  uint uVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined *in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined *in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined uVar8;
  uint uStack_244;
  undefined4 *puStack_240;
  undefined4 uStack_238;
  char *pcStack_234;
  undefined4 uStack_230;
  undefined4 *puStack_22c;
  undefined **ppuStack_228;
  undefined **ppuStack_224;
  char *pcStack_220;
  undefined **ppuStack_21c;
  char *pcStack_218;
  uint auStack_214 [2];
  undefined4 *puStack_20c;
  undefined4 *puStack_208;
  char *pcStack_204;
  code *pcStack_200;
  undefined auStack_1f4 [72];
  undefined auStack_1ac [72];
  undefined auStack_164 [72];
  undefined auStack_11c [72];
  undefined auStack_d4 [72];
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int *piStack_70;
  uint uStack_6c;
  undefined *puStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  uint uStack_4c;
  undefined *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined *puStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d50af;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pcStack_204 = (char *)0x9bdfd2;
  ExceptionList = &pvStack_10;
  pcStack_200 = (code *)param_1;
  iStack_18 = param_1;
  puStack_1c = (undefined *)FUN_008f7870();
  if (param_1 == 0) {
LAB_009be027:
    iVar5 = 0;
  }
  else {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      pcStack_200 = (code *)0x9bdfef;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 == 0) goto LAB_009be027;
    iVar5 = *(int *)(param_1 + 0xc);
    pcStack_200 = (code *)0x9be001;
    iVar4 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_009be027;
    pcStack_200 = (code *)0x9be023;
    iVar5 = FUN_005cf750();
  }
  iVar4 = iStack_18;
  if ((puStack_1c == (undefined *)0x0) || (iVar5 == 0)) {
    pcStack_218 = (char *)0x30;
    ppuStack_21c = (undefined **)0x1938c40;
  }
  else if ((*(int *)(puStack_1c + 0x4a0) == 1) || (*(int *)(puStack_1c + 0x4a0) == 3)) {
    pcStack_200 = (code *)iStack_18;
    pcStack_204 = (char *)0x9be066;
    pcStack_204 = (char *)FUN_009b4820();
    puStack_208 = (undefined4 *)0x9be06c;
    iStack_18 = FUN_00980070();
    if (*(int *)(iVar5 + 0xf4) == iStack_18) {
      if (DAT_01d64a88 != '\0') {
        pcStack_200 = (code *)in_stack_00000020;
        puStack_208 = (undefined4 *)auStack_8c;
        pcStack_204 = (char *)in_stack_0000001c;
        puStack_20c = (undefined4 *)0x9be0aa;
        pcStack_200 = (code *)FUN_0058c590();
        pcStack_204 = "assetID";
        uStack_8._0_1_ = 3;
        puStack_208 = (undefined4 *)0x9be0bf;
        FUN_00632a10();
        pcStack_200 = (code *)0x9be0ca;
        FUN_005507b0();
        puStack_1c = (undefined *)auStack_214;
        uStack_8._0_1_ = 4;
        pcStack_218 = &uStack_11;
        ppuStack_228 = &puStack_2c;
        ppuStack_21c = (undefined **)&uStack_11;
        pcStack_220 = &uStack_11;
        ppuStack_224 = (undefined **)0xb;
        uStack_230 = 0x9be0f1;
        puStack_22c = &uStack_5c;
        FUN_006370e0();
        piStack_24 = (int *)&puStack_22c;
        uStack_8._0_1_ = 5;
        uStack_230 = 0xe;
        ppuStack_21c = (undefined **)0x0;
        pcStack_218 = (char *)0xf;
        pcStack_234 = "emoteTriggered";
        puStack_22c = (undefined4 *)((uint)puStack_22c & 0xffffff00);
        uStack_238 = 0x9be11a;
        FUN_005542c0();
        puStack_20 = &uStack_244;
        uStack_8._0_1_ = 6;
        pcStack_234 = (char *)0x0;
        uStack_230 = 0xf;
        uStack_244 = uStack_244 & 0xffffff00;
        FUN_005542c0("playEmoteApi",0xc);
        uStack_8._0_1_ = 7;
        uVar8 = 0;
        FUN_005542c0("client",6);
        uStack_8._0_1_ = 4;
        FUN_0087a540(uVar8);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        pcStack_200 = FUN_005509f0;
        pcStack_204 = (char *)0x1;
        puStack_208 = (undefined4 *)0x30;
        auStack_214[1] = 0x9be18a;
        puStack_20c = &uStack_5c;
        FUN_016f32d1();
      }
      pcStack_204 = (char *)&uStack_28;
      pcStack_200 = (code *)iVar4;
      puStack_208 = (undefined4 *)0x9be194;
      FUN_0060e0c0();
      piVar1 = piStack_24;
      puStack_20 = &uStack_74;
      puStack_2c = (undefined *)&ppuStack_21c;
      pppuVar2 = &ppuStack_21c;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
        pppuVar2 = (undefined ***)puStack_2c;
      }
      puStack_2c = (undefined *)pppuVar2;
      uStack_74 = uStack_28;
      piStack_70 = piVar1;
      uStack_8._0_1_ = 9;
      uStack_6c = 0;
      if (in_stack_00000024 != 0) {
        uStack_6c = in_stack_00000024;
        if ((in_stack_00000024 & 1) == 0) {
          ppuStack_224 = &puStack_64;
          pcStack_220 = (char *)0x0;
          ppuStack_228 = &stack0x0000002c;
          puStack_22c = (undefined4 *)0x9be202;
          (**(code **)(in_stack_00000024 & 0xfffffffe))();
        }
        else {
          puStack_64 = in_stack_0000002c;
          uStack_60 = in_stack_00000030;
          uStack_5c = in_stack_00000034;
          uStack_58 = in_stack_00000038;
          uStack_54 = in_stack_0000003c;
        }
      }
      uStack_8._0_1_ = 10;
      uStack_4c = 0;
      if (in_stack_00000044 != 0) {
        uStack_4c = in_stack_00000044;
        if ((in_stack_00000044 & 1) == 0) {
          ppuStack_224 = &puStack_44;
          pcStack_220 = (char *)0x0;
          ppuStack_228 = &stack0x0000004c;
          puStack_22c = (undefined4 *)0x9be243;
          (**(code **)(in_stack_00000044 & 0xfffffffe))();
        }
        else {
          puStack_44 = in_stack_0000004c;
          uStack_40 = in_stack_00000050;
          uStack_3c = in_stack_00000054;
          uStack_38 = in_stack_00000058;
          uStack_34 = in_stack_0000005c;
        }
      }
      pcStack_220 = (char *)&uStack_74;
      uStack_8._0_1_ = 0xb;
      ppuStack_224 = (undefined **)0x9be259;
      FUN_009a0450();
      pcStack_220 = auStack_1f4;
      uStack_8._0_1_ = 0xc;
      ppuStack_21c = (undefined **)0x0;
      ppuStack_224 = (undefined **)0x9be275;
      FUN_009a0450();
      pcStack_220 = auStack_1ac;
      uStack_8._0_1_ = 0xd;
      ppuStack_224 = (undefined **)0x9be28b;
      FUN_009a0450();
      pcStack_220 = auStack_164;
      uStack_8._0_1_ = 0xe;
      ppuStack_224 = (undefined **)0x9be2a1;
      FUN_009a0450();
      pcStack_220 = auStack_d4;
      uStack_8._0_1_ = 0xf;
      ppuStack_224 = (undefined **)0x9be2b1;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        pcStack_220 = auStack_d4;
        ppuStack_224 = (undefined **)0x9be2ca;
        FUN_009a0450();
        pcStack_220 = (char *)0x48;
        uStack_8._0_1_ = 0x10;
        ppuStack_224 = (undefined **)0x9be2d5;
        puStack_20 = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 0x11;
        if (puStack_20 == (undefined4 *)0x0) {
          auStack_214[0] = 0;
        }
        else {
          pcStack_220 = auStack_11c;
          ppuStack_224 = (undefined **)0x9be2f1;
          auStack_214[0] = FUN_009a0450();
        }
        pcStack_220 = (char *)0x9be303;
        FUN_008e9ba0();
        pcStack_220 = (char *)0x9be30e;
        FUN_008e9ba0();
        uStack_11 = '\x01';
      }
      else {
        pcStack_220 = (char *)0x9be31f;
        FUN_008e9ba0();
        uStack_11 = '\0';
      }
      pcStack_220 = (char *)0x9be32e;
      FUN_008e9ba0();
      ppuVar6 = &PTR_FUN_01939820;
      if (uStack_11 == '\0') {
        ppuVar6 = (undefined **)0x0;
      }
      pcStack_220 = (char *)0x9be348;
      ppuStack_21c = ppuVar6;
      FUN_008e9ba0();
      pcStack_220 = (char *)0x9be353;
      FUN_008e9ba0();
      pcStack_220 = (char *)0x9be35b;
      FUN_008e9ba0();
      pcStack_220 = (char *)in_stack_00000020;
      puStack_240 = &param_2;
      uStack_8._0_1_ = 0x12;
      ppuStack_224 = (undefined **)in_stack_0000001c;
      uStack_244 = 0x9be373;
      FUN_0054ef60();
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      puStack_240 = (undefined4 *)0x9be37f;
      FUN_0091ef70();
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          pcStack_200 = (code *)0x9be394;
          (**(code **)(*piVar1 + 4))();
        }
      }
      goto LAB_009be3c0;
    }
    pcStack_218 = (char *)0x2c;
    ppuStack_21c = (undefined **)0x1938c74;
  }
  else {
    pcStack_218 = (char *)0x26;
    ppuStack_21c = (undefined **)0x1938ccc;
  }
  pcStack_204 = (char *)0x0;
  pcStack_200 = (code *)0xf;
  auStack_214[0] = auStack_214[0] & 0xffffff00;
  pcStack_220 = (char *)0x9be3b8;
  FUN_005542c0();
  pcStack_218 = (char *)0x9be3c0;
  FUN_005e65e0();
LAB_009be3c0:
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    pcStack_200 = (code *)(in_stack_00000018 + 1);
    uVar7 = param_2;
    if (0xfff < pcStack_200) {
      uVar7 = *(uint *)(param_2 - 4);
      pcStack_200 = (code *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_200 = (code *)&UNK_009be473;
        FUN_017167a3();
      }
    }
    puStack_208 = (undefined4 *)0x9be3f5;
    pcStack_204 = (char *)uVar7;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_208 = &stack0x0000002c;
      pcStack_200 = (code *)0x2;
      puStack_20c = (undefined4 *)0x9be42b;
      pcStack_204 = (char *)puStack_208;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 0x14;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_208 = &stack0x0000004c;
    pcStack_200 = (code *)0x2;
    puStack_20c = (undefined4 *)0x9be459;
    pcStack_204 = (char *)puStack_208;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18742 ; VA 0x009be480 ; FUN_009be480 */

void FUN_009be480(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined auStack_100 [24];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  char *pcStack_e0;
  undefined4 *puStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  int *piStack_cc;
  int *piStack_c8;
  uint *puStack_c4;
  int aiStack_b8 [9];
  int *piStack_94;
  int aiStack_90 [9];
  int *piStack_6c;
  uint auStack_68 [2];
  undefined auStack_60 [24];
  uint auStack_48 [2];
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5121;
  pvStack_10 = ExceptionList;
  piStack_c8 = &iStack_28;
  uStack_8 = 2;
  cStack_11 = '\0';
  piStack_cc = (int *)0x9be4ba;
  ExceptionList = &pvStack_10;
  FUN_009b49f0();
  uStack_8._0_1_ = 3;
  if (iStack_28 == 0) {
    puStack_c4 = (uint *)0x9be4cd;
    uVar6 = FUN_005565e0();
    uStack_8._0_1_ = 2;
    if (piStack_24 == (int *)0x0) goto LAB_009be52c;
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
  }
  else {
    puStack_c4 = (uint *)&cStack_11;
    piStack_c8 = (int *)&param_1;
    piStack_cc = (int *)0x9be4f7;
    uVar6 = FUN_00e2fe60();
    uStack_8._0_1_ = 2;
    if (piStack_24 == (int *)0x0) goto LAB_009be52c;
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
  }
  piVar4 = piStack_24;
  piStack_20 = (int *)((ulonglong)uVar6 >> 0x20);
  uStack_1c = (undefined4)uVar6;
  uStack_8._0_1_ = 2;
  if (iVar2 == 0) {
    puStack_c4 = (uint *)0x9be51a;
    (**(code **)*piStack_24)();
    uVar6 = CONCAT44(piStack_20,uStack_1c);
    LOCK();
    piVar1 = piVar4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_c4 = (uint *)0x9be529;
      (**(code **)(*piVar4 + 4))();
      uVar6 = CONCAT44(piStack_20,uStack_1c);
    }
  }
LAB_009be52c:
  piStack_20 = (int *)((ulonglong)uVar6 >> 0x20);
  uStack_1c = (undefined4)uVar6;
  if (cStack_11 == '\0') {
    puStack_dc = &param_1;
    if (0xf < in_stack_00000018) {
      puStack_dc = param_1;
    }
    puStack_e4 = &uStack_d8;
    pcStack_e0 = "No emote exists with name %s";
    uStack_e8 = 0x9be54e;
    FUN_01675640();
    puStack_dc = (undefined4 *)0x9be559;
    FUN_005e65e0();
  }
  else if (DAT_01d63f08 == '\0') {
    piStack_24 = (int *)&pcStack_e0;
    puStack_e4 = &stack0x0000003c;
    uStack_e8 = 0x9be6bf;
    FUN_0054f510();
    puStack_18 = auStack_100;
    uStack_8._0_1_ = 0xb;
    FUN_0054f510(&stack0x0000001c);
    uStack_8._0_1_ = 0xc;
    FUN_0054ef60(&param_1);
    uStack_8._0_1_ = 2;
    FUN_009bdfa0();
  }
  else {
    auStack_48[0] = 0;
    if (in_stack_0000001c != 0) {
      auStack_48[0] = in_stack_0000001c;
      if ((in_stack_0000001c & 1) == 0) {
        piStack_c8 = &iStack_40;
        puStack_c4 = (uint *)0x0;
        piStack_cc = &stack0x00000024;
        uStack_d0 = 0x9be5a5;
        (**(code **)(in_stack_0000001c & 0xfffffffe))();
        uVar6 = CONCAT44(piStack_20,uStack_1c);
      }
      else {
        iStack_40 = in_stack_00000024;
        uStack_3c = in_stack_00000028;
        uStack_38 = in_stack_0000002c;
        uStack_34 = in_stack_00000030;
        uStack_30 = in_stack_00000034;
      }
    }
    piStack_20 = (int *)((ulonglong)uVar6 >> 0x20);
    uStack_1c = (undefined4)uVar6;
    uStack_8._0_1_ = 4;
    puStack_e4 = &stack0x0000003c;
    uStack_e8 = 0x9be5ba;
    FUN_0054f510();
    puStack_e4 = (undefined4 *)0x9be5c5;
    FUN_0099b770();
    puStack_c4 = auStack_48;
    uStack_8._0_1_ = 5;
    piStack_c8 = (int *)0x9be5d5;
    FUN_005e5f00();
    piStack_94 = (int *)0x0;
    puStack_c4 = auStack_68;
    uStack_8._0_1_ = 7;
    piStack_c8 = (int *)0x9be5ec;
    piVar4 = (int *)FUN_0099c600();
    uStack_8._0_1_ = 8;
    piStack_94 = piVar4;
    if (auStack_68[0] != 0) {
      if (((auStack_68[0] & 1) == 0) && (*(code **)(auStack_68[0] & 0xfffffffe) != (code *)0x0)) {
        piStack_cc = (int *)auStack_60;
        puStack_c4 = (uint *)0x2;
        uStack_d0 = 0x9be619;
        piStack_c8 = piStack_cc;
        (**(code **)(auStack_68[0] & 0xfffffffe))();
      }
      auStack_68[0] = 0;
    }
    puStack_c4 = (uint *)aiStack_90;
    piStack_c8 = aiStack_b8;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    piStack_cc = piStack_20;
    uStack_d0 = uStack_1c;
    uStack_d4 = 0x9be643;
    FUN_009bdb90();
    if (piVar4 != (int *)0x0) {
      puStack_c4 = (uint *)CONCAT31((int3)((uint)aiStack_b8 >> 8),piVar4 != aiStack_b8);
      piStack_c8 = (int *)0x9be65c;
      (**(code **)(*piVar4 + 0x10))();
    }
    if (piStack_6c != (int *)0x0) {
      puStack_c4 = (uint *)CONCAT31((int3)((uint)aiStack_90 >> 8),piStack_6c != aiStack_90);
      piStack_c8 = (int *)0x9be676;
      (**(code **)(*piStack_6c + 0x10))();
      piStack_6c = (int *)0x0;
    }
    uStack_8._0_1_ = 10;
    if (auStack_48[0] != 0) {
      if (((auStack_48[0] & 1) == 0) && (*(code **)(auStack_48[0] & 0xfffffffe) != (code *)0x0)) {
        piStack_cc = &iStack_40;
        puStack_c4 = (uint *)0x2;
        uStack_d0 = 0x9be6a2;
        piStack_c8 = piStack_cc;
        (**(code **)(auStack_48[0] & 0xfffffffe))();
      }
      auStack_48[0] = 0;
    }
  }
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    puStack_c4 = (uint *)(in_stack_00000018 + 1);
    puVar5 = param_1;
    if (0xfff < puStack_c4) {
      puVar5 = (undefined4 *)param_1[-1];
      puStack_c4 = (uint *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        puStack_c4 = (uint *)&UNK_009be7aa;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    piStack_cc = (int *)0x9be72c;
    piStack_c8 = puVar5;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      piStack_cc = &stack0x00000024;
      puStack_c4 = (uint *)0x2;
      uStack_d0 = 0x9be762;
      piStack_c8 = piStack_cc;
      (**(code **)(in_stack_0000001c & 0xfffffffe))();
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    piStack_cc = (int *)&stack0x00000044;
    puStack_c4 = (uint *)0x2;
    uStack_d0 = 0x9be790;
    piStack_c8 = piStack_cc;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18743 ; VA 0x009be7b0 ; FUN_009be7b0 */

int FUN_009be7b0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,int param_5,
                int param_6)

{
  int *piVar1;
  char cVar2;
  char **ppcVar3;
  int *piVar4;
  int iVar5;
  undefined *puVar6;
  int iVar7;
  char *pcVar8;
  undefined auStack_208 [24];
  undefined4 uStack_1f0;
  undefined *puStack_1ec;
  int iStack_1e8;
  int *piStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1c8;
  int *piStack_1c4;
  char *pcStack_1c0;
  undefined4 uStack_1bc;
  undefined uStack_1b8;
  undefined4 uStack_1b0;
  undefined4 *puStack_1ac;
  char *pcStack_1a8;
  int *piStack_1a4;
  undefined auStack_194 [4];
  int iStack_190;
  undefined auStack_18c [200];
  int aiStack_c4 [9];
  int *piStack_a0;
  int aiStack_9c [9];
  int *piStack_78;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  int *piStack_58;
  int aiStack_54 [4];
  undefined auStack_44 [16];
  undefined4 uStack_34;
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  undefined *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d51e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_1a4 = &iStack_5c;
  pcStack_1a8 = (char *)0x9be7e4;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  if (iStack_5c == 0) {
    uStack_1bc = 0x16;
    pcStack_1c0 = "Humanoid was destroyed";
  }
  else {
    if (*(int *)(iStack_5c + 0x34) != 0) {
      iVar7 = *(int *)(*(int *)(iStack_5c + 0x34) + 0xc);
      piStack_1a4 = (int *)0x9be816;
      iVar5 = FUN_00b63e30();
      if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        uStack_34 = 0;
        piStack_30 = (int *)&DAT_0000000f;
        auStack_44[0] = 0;
        pcVar8 = PTR_DAT_01d64a18;
        do {
          cVar2 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar2 != '\0');
        piStack_1a4 = (int *)((int)pcVar8 - (int)(PTR_DAT_01d64a18 + 1));
        pcStack_1a8 = PTR_DAT_01d64a18;
        puStack_1ac = (undefined4 *)0x9be865;
        FUN_005542c0();
        piStack_1a4 = (int *)auStack_44;
        uStack_8._0_1_ = 3;
        pcStack_1a8 = (char *)0x9be874;
        iVar7 = FUN_008a1240();
        uStack_8._0_1_ = 2;
        piStack_1a4 = (int *)0x9be882;
        FUN_005507b0();
        if (iVar7 != 0) {
          piStack_1a4 = (int *)0x9;
          pcStack_1a8 = "PlayEmote";
          uStack_64 = 0;
          uStack_60 = 0xf;
          auStack_74[0] = 0;
          puStack_1ac = (undefined4 *)0x9be8b8;
          FUN_005542c0();
          piStack_1a4 = (int *)auStack_74;
          uStack_8._0_1_ = 4;
          pcStack_1a8 = (char *)0x9be8c7;
          piStack_1a4 = (int *)FUN_008a1240();
          pcStack_1a8 = (char *)0x9be8cd;
          iVar7 = FUN_0099f8a0();
          uStack_8._0_1_ = 2;
          piStack_1a4 = (int *)0x9be8e1;
          iStack_20 = iVar7;
          FUN_005507b0();
          if (iVar7 == 0) {
            piStack_1a4 = (int *)0xc;
            pcStack_1a8 = (char *)0x9be8ec;
            puVar6 = (undefined *)FUN_01674e20();
            uStack_8._0_1_ = 5;
            puStack_24 = puVar6;
            if (puVar6 == (undefined *)0x0) {
              pcStack_1a8 = (undefined *)0x0;
            }
            else {
              piStack_1a4 = (int *)&uStack_11;
              pcStack_1a8 = (char *)0x1;
              puStack_1ac = (undefined4 *)0x9be909;
              FUN_00569550();
              pcStack_1a8 = puVar6;
            }
            piStack_1a4 = param_2;
            uStack_8._0_1_ = 2;
            uStack_1c = 0;
            piStack_18 = (int *)0x0;
            puStack_1ac = (undefined4 *)0x9be92b;
            FUN_0055ba30();
            piStack_1a4 = (int *)&uStack_11;
            uStack_8._0_1_ = 6;
            uStack_11 = 0;
            pcStack_1a8 = (char *)0x9be941;
            FUN_005e52b0();
            puStack_1ac = &uStack_1c;
            uStack_1b0 = 0x9be94f;
            FUN_00557fc0();
            puStack_1ac = (undefined4 *)0x9be957;
            FUN_009a5bb0();
            uStack_8._0_1_ = 2;
            piStack_1a4 = (int *)0x9be963;
            FUN_00550b30();
          }
          piStack_1a4 = &iStack_2c;
          pcStack_1a8 = (char *)0x9be96c;
          FUN_008c05f0();
          pcStack_1a8 = (char *)&param_3;
          uStack_8._0_1_ = 7;
          puStack_1ac = &uStack_1c;
          uStack_1b0 = 0x9be97d;
          piStack_1a4 = (int *)FUN_0099f920();
          uStack_8._0_1_ = 8;
          pcStack_1a8 = (char *)0x9be990;
          FUN_00913150();
          iVar7 = iStack_2c;
          piStack_1a4 = (int *)auStack_194;
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
          pcStack_1a8 = *(char **)(iStack_2c + 4);
          if ((char *)*(int *)(iStack_2c + 8) == pcStack_1a8) {
            puStack_1ac = (undefined4 *)0x9be9be;
            FUN_005ca4f0();
          }
          else {
            pcStack_1a8 = (char *)0x9be9ad;
            FUN_005caf00();
            *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 0xd0;
          }
          uStack_8._0_1_ = 10;
          if (iStack_190 != 0) {
            piStack_1a4 = (int *)auStack_18c;
            pcStack_1a8 = (char *)0x9be9d8;
            (**(code **)(iStack_190 + 8))();
          }
          piStack_1a4 = (int *)0x9be9e3;
          FUN_00550b30();
          puStack_24 = (undefined *)&pcStack_1c0;
          piStack_18 = aiStack_9c;
          piStack_78 = (int *)0x0;
          uStack_8._0_1_ = 0xb;
          ppcVar3 = &pcStack_1c0;
          if (*(undefined4 **)(param_6 + 0x24) != (undefined4 *)0x0) {
            piStack_1c4 = aiStack_9c;
            uStack_1c8 = 0x9bea14;
            piStack_78 = (int *)(**(code **)**(undefined4 **)(param_6 + 0x24))();
            ppcVar3 = (char **)puStack_24;
          }
          puStack_24 = (undefined *)ppcVar3;
          piStack_18 = aiStack_54;
          piStack_30 = (int *)0x0;
          uStack_8._0_1_ = 0xd;
          if (piStack_78 != (int *)0x0) {
            piStack_1c4 = aiStack_54;
            uStack_1c8 = 0x9bea36;
            piStack_30 = (int *)(**(code **)*piStack_78)();
          }
          piStack_18 = &iStack_1e8;
          puStack_1ec = (undefined *)&iStack_1e8;
          pcStack_1c0 = (char *)0x0;
          piStack_1c4 = (int *)0x0;
          uStack_8._0_1_ = 0xf;
          piVar4 = &iStack_1e8;
          if (piStack_30 != (int *)0x0) {
            uStack_1f0 = 0x9bea5e;
            piStack_1c4 = (int *)(**(code **)*piStack_30)();
            piVar4 = piStack_18;
          }
          piStack_18 = piVar4;
          uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
          puStack_1ec = (undefined *)0x9bea6c;
          FUN_0099da20();
          if (piStack_30 != (int *)0x0) {
            piStack_1c4 = (int *)CONCAT31((int3)((uint)aiStack_54 >> 8),piStack_30 != aiStack_54);
            uStack_1c8 = 0x9bea83;
            (**(code **)(*piStack_30 + 0x10))();
            piStack_30 = (int *)0x0;
          }
          if (piStack_78 != (int *)0x0) {
            piStack_1c4 = (int *)CONCAT31((int3)((uint)aiStack_9c >> 8),piStack_78 != aiStack_9c);
            uStack_1c8 = 0x9beaa4;
            (**(code **)(*piStack_78 + 0x10))();
            piStack_78 = (int *)0x0;
          }
          piStack_18 = aiStack_c4;
          piStack_a0 = (int *)0x0;
          uStack_8._0_1_ = 0x11;
          if (*(undefined4 **)(param_5 + 0x24) != (undefined4 *)0x0) {
            piStack_1e4 = aiStack_c4;
            iStack_1e8 = 0x9beadc;
            piStack_a0 = (int *)(**(code **)**(undefined4 **)(param_5 + 0x24))();
          }
          piStack_18 = aiStack_54;
          piStack_30 = (int *)0x0;
          uStack_8._0_1_ = 0x13;
          if (piStack_a0 != (int *)0x0) {
            piStack_1e4 = aiStack_54;
            iStack_1e8 = 0x9beb01;
            piStack_30 = (int *)(**(code **)*piStack_a0)();
          }
          piStack_18 = (int *)auStack_208;
          uStack_1e0 = 0;
          piStack_1e4 = (int *)0x0;
          uStack_8._0_1_ = 0x15;
          piVar4 = (int *)auStack_208;
          if (piStack_30 != (int *)0x0) {
            piStack_1e4 = (int *)(**(code **)*piStack_30)(auStack_208);
            piVar4 = piStack_18;
          }
          piStack_18 = piVar4;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
          FUN_0099dbf0();
          if (piStack_30 != (int *)0x0) {
            piStack_1e4 = (int *)CONCAT31((int3)((uint)aiStack_54 >> 8),piStack_30 != aiStack_54);
            iStack_1e8 = 0x9beb4e;
            (**(code **)(*piStack_30 + 0x10))();
            piStack_30 = (int *)0x0;
          }
          uStack_8._0_1_ = 0x10;
          if (piStack_a0 != (int *)0x0) {
            piStack_1e4 = (int *)CONCAT31((int3)((uint)aiStack_c4 >> 8),piStack_a0 != aiStack_c4);
            iStack_1e8 = 0x9beb76;
            (**(code **)(*piStack_a0 + 0x10))();
            piStack_a0 = (int *)0x0;
          }
          if (iStack_28 != 0) {
            LOCK();
            *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
            UNLOCK();
          }
          piStack_1e4 = (int *)iStack_28;
          iStack_1e8 = iStack_2c;
          uStack_8._0_1_ = 7;
          puStack_1ec = (undefined *)0x9bebb1;
          FUN_00ec4c50();
          piStack_1a4 = (int *)0x9bebb9;
          FUN_00550b30();
          piStack_1a4 = (int *)0x9bebc1;
          iVar7 = FUN_00550b30();
          goto LAB_009bec13;
        }
        uStack_1bc = 0x1f;
        pcStack_1c0 = "Character has no Animate script";
        goto LAB_009bebcf;
      }
    }
    uStack_1bc = 0x23;
    pcStack_1c0 = "Humanoid is not part of a Character";
  }
LAB_009bebcf:
  pcStack_1a8 = (char *)0x0;
  piStack_1a4 = (int *)0xf;
  uStack_1b8 = 0;
  piStack_1c4 = (int *)0x9bebe5;
  FUN_005542c0();
  uStack_1bc = 0x9bebed;
  iVar7 = FUN_009a5b30();
  if (piStack_58 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_58 + 1;
    iVar5 = *piVar4;
    iVar7 = *piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piStack_1a4 = (int *)0x9bec03;
      (**(code **)*piStack_58)();
      LOCK();
      piVar4 = piStack_58 + 2;
      iVar5 = *piVar4;
      iVar7 = *piVar4;
      *piVar4 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        piStack_1a4 = (int *)0x9bec13;
        iVar7 = (**(code **)(*piStack_58 + 4))();
      }
    }
  }
LAB_009bec13:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar4 = param_2 + 2;
    iVar5 = *piVar4;
    iVar7 = *piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piStack_1a4 = (int *)0x9bec28;
      iVar7 = (**(code **)(*param_2 + 4))();
    }
  }
  piVar4 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar5 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piStack_1a4 = (int *)0x9bec3e;
      iVar7 = (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_1a4 = (int *)0x9bec4d;
        iVar7 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 18744 ; VA 0x009bec60 ; FUN_009bec60 */

void FUN_009bec60(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined8 param_11,uint param_12)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  char *pcStack_17c;
  undefined4 uStack_178;
  undefined uStack_174;
  undefined4 uStack_16c;
  undefined4 *puStack_168;
  char *pcStack_164;
  int *piStack_160;
  undefined auStack_154 [4];
  int iStack_150;
  undefined auStack_14c [200];
  undefined auStack_84 [16];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [16];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 auStack_54 [2];
  undefined *puStack_4c;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5263;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_160 = &iStack_28;
  pcStack_164 = (char *)0x9bec93;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 4;
  if (iStack_28 == 0) {
    uStack_178 = 0x16;
    pcStack_17c = "Humanoid was destroyed";
  }
  else {
    iStack_14 = *(int *)(iStack_28 + 0x34);
    if (iStack_14 != 0) {
      iVar5 = *(int *)(iStack_14 + 0xc);
      piStack_160 = (int *)0x9becc8;
      iVar4 = FUN_00b63e30();
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        uStack_5c = 0;
        uStack_58 = 0xf;
        auStack_6c[0] = 0;
        pcVar6 = PTR_DAT_01d64a18;
        do {
          cVar2 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar2 != '\0');
        piStack_160 = (int *)((int)pcVar6 - (int)(PTR_DAT_01d64a18 + 1));
        pcStack_164 = PTR_DAT_01d64a18;
        puStack_168 = (undefined4 *)0x9bed17;
        FUN_005542c0();
        piStack_160 = (int *)auStack_6c;
        uStack_8._0_1_ = 5;
        pcStack_164 = (char *)0x9bed27;
        iVar5 = FUN_008a1240();
        uStack_8._0_1_ = 4;
        piStack_160 = (int *)0x9bed35;
        FUN_005507b0();
        if (iVar5 != 0) {
          piStack_160 = (int *)0x9;
          pcStack_164 = "PlayEmote";
          uStack_74 = 0;
          uStack_70 = 0xf;
          auStack_84[0] = 0;
          puStack_168 = (undefined4 *)0x9bed6b;
          FUN_005542c0();
          piStack_160 = (int *)auStack_84;
          uStack_8._0_1_ = 6;
          pcStack_164 = (char *)0x9bed7a;
          piStack_160 = (int *)FUN_008a1240();
          pcStack_164 = (char *)0x9bed80;
          iVar5 = FUN_0099f8a0();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          piStack_160 = (int *)0x9bed94;
          iStack_14 = iVar5;
          FUN_005507b0();
          if (iVar5 == 0) {
            pcStack_164 = (char *)0x9beda1;
            piStack_160 = (int *)iVar5;
            FUN_008927d0();
          }
          piStack_160 = &iStack_20;
          pcStack_164 = (char *)0x9bedaa;
          FUN_008c05f0();
          pcStack_164 = (char *)&param_3;
          uStack_8._0_1_ = 7;
          puStack_168 = auStack_54;
          uStack_16c = 0x9bedbb;
          piStack_160 = (int *)FUN_0099f920();
          uStack_8._0_1_ = 8;
          pcStack_164 = (char *)0x9bedce;
          FUN_00913150();
          iVar5 = iStack_20;
          piStack_160 = (int *)auStack_154;
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
          pcStack_164 = *(char **)(iStack_20 + 4);
          if ((char *)*(undefined4 **)(iStack_20 + 8) == pcStack_164) {
            puStack_168 = (undefined4 *)0x9bedfc;
            FUN_005ca4f0();
          }
          else {
            pcStack_164 = (char *)0x9bedeb;
            FUN_005caf00();
            *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 0xd0;
          }
          uStack_8._0_1_ = 10;
          if (iStack_150 != 0) {
            piStack_160 = (int *)auStack_14c;
            pcStack_164 = (char *)0x9bee16;
            (**(code **)(iStack_150 + 8))();
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          piStack_160 = (int *)0x9bee25;
          FUN_00550b30();
          auStack_48[0] = 0;
          if (param_5 != 0) {
            auStack_48[0] = param_5;
            if ((param_5 & 1) == 0) {
              pcStack_164 = (char *)&uStack_40;
              piStack_160 = (int *)0x0;
              puStack_168 = &param_7;
              uStack_16c = 0x9bee5f;
              (**(code **)(param_5 & 0xfffffffe))();
            }
            else {
              uStack_40 = param_7;
              uStack_3c = param_8;
              uStack_38 = param_9;
              uStack_34 = param_10;
              uStack_30 = param_11;
            }
          }
          puStack_4c = (undefined *)&pcStack_17c;
          uStack_8._0_1_ = 0xb;
          FUN_0054f510(&param_12);
          uStack_8._0_1_ = 0xc;
          FUN_005e5f00(auStack_48);
          FUN_0099b320();
          if (iStack_1c != 0) {
            LOCK();
            *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
            UNLOCK();
          }
          uStack_8._0_1_ = 0xb;
          FUN_00ec4c50(iStack_20,iStack_1c);
          uStack_8._0_1_ = 0xd;
          if (auStack_48[0] != 0) {
            if (((auStack_48[0] & 1) == 0) &&
               (*(code **)(auStack_48[0] & 0xfffffffe) != (code *)0x0)) {
              puStack_168 = &uStack_40;
              piStack_160 = (int *)0x2;
              uStack_16c = 0x9beeed;
              pcStack_164 = (char *)puStack_168;
              (**(code **)(auStack_48[0] & 0xfffffffe))();
            }
            auStack_48[0] = 0;
          }
          piStack_160 = (int *)0x9beeff;
          FUN_00550b30();
          piStack_160 = (int *)0x9bef07;
          FUN_00550b30();
          goto LAB_009bef59;
        }
        uStack_178 = 0x1f;
        pcStack_17c = "Character has no Animate script";
        goto LAB_009bef15;
      }
    }
    uStack_178 = 0x23;
    pcStack_17c = "Humanoid is not part of a Character";
  }
LAB_009bef15:
  pcStack_164 = (char *)0x0;
  piStack_160 = (int *)0xf;
  uStack_174 = 0;
  FUN_005542c0();
  uStack_178 = 0x9bef33;
  FUN_005e65e0();
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_24[1] + -1;
    piStack_24[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_160 = (int *)0x9bef49;
      (**(code **)*piStack_24)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        piStack_160 = (int *)0x9bef59;
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
LAB_009bef59:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar5 = param_2[2] + -1;
    param_2[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_160 = (int *)0x9bef6e;
      (**(code **)(*param_2 + 4))();
    }
  }
  piVar3 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar5 = param_4[1] + -1;
    param_4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_160 = (int *)0x9bef84;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_160 = (int *)0x9bef93;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      puStack_168 = &param_7;
      piStack_160 = (int *)0x2;
      uStack_16c = 0x9befb4;
      pcStack_164 = (char *)puStack_168;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 0xf;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_168 = (undefined4 *)&stack0x0000003c;
    piStack_160 = (int *)0x2;
    uStack_16c = 0x9befe2;
    pcStack_164 = (char *)puStack_168;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18745 ; VA 0x009bf000 ; FUN_009bf000 */

int __thiscall FUN_009bf000(int param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  if (param_2 != &DAT_02123338) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_009cba80(param_2,param_3,param_4);
    ExceptionList = pvStack_10;
    return iVar2;
  }
  piVar5 = (int *)*param_3;
  iVar2 = (param_3[1] - (int)piVar5) / 0xd0;
  if (iVar2 != 1) {
    return iVar2;
  }
  iVar2 = *piVar5;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar2 != iVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar2 = 0;
  piVar4 = piVar5 + 2;
  if (piVar5[1] == 0) {
    piVar4 = (int *)0x0;
  }
  piVar5 = (int *)piVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)piVar4[1];
  }
  uStack_8 = 0;
  if (*piVar4 != 0) {
    iVar2 = FUN_007c0ca0();
    if (iVar2 != 0) {
      iVar1 = *(int *)(iVar2 + 0xc);
      iVar3 = FUN_008aa870();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        FUN_009cba80(&DAT_02123338,param_3,param_4);
LAB_009bf0d9:
        iVar2 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar2;
      }
      if (*(int *)(param_1 + 0x34) != iVar2) goto LAB_009bf0d9;
    }
    iVar2 = FUN_009cba80(&DAT_02123338,param_3,param_4);
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar4 = piVar5 + 1;
    iVar1 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*piVar5)();
      LOCK();
      piVar4 = piVar5 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*piVar5 + 4))();
        ExceptionList = pvStack_10;
        return iVar2;
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 18746 ; VA 0x009bf170 ; FUN_009bf170 */

void __thiscall FUN_009bf170(int *param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  
  uVar1 = param_1[2];
  if (uVar1 == param_1[1]) {
    uVar2 = 2;
    if (uVar1 != 0) {
      uVar2 = uVar1 * 2;
    }
    for (; uVar2 < uVar1 + 1; uVar2 = uVar2 * 2) {
    }
    if (((uVar1 < uVar2) && (uVar2 * 4 != 0)) &&
       (iVar3 = FUN_01674fa0(uVar2 * 4,param_1[4]), iVar3 != 0)) {
      FUN_0099eb50(iVar3,*param_1,param_1[1]);
      if (param_1[2] != 0) {
        FUN_01674ee0(*param_1);
      }
      *param_1 = iVar3;
      param_1[2] = uVar2;
    }
  }
  *(undefined4 *)(*param_1 + param_1[1] * 4) = *param_2;
  param_1[1] = param_1[1] + 1;
  return;
}



/* FUNCTION 18747 ; VA 0x009bf200 ; FUN_009bf200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_009bf200(undefined4 param_1,undefined4 param_2)

{
  double dVar1;
  float10 fVar2;
  
  dVar1 = (double)CONCAT44(param_2,param_1);
  if ((_DAT_019399d0 <= dVar1) && (dVar1 < DAT_019011c8)) {
    return (float10)(float)(double)CONCAT44(param_2,param_1);
  }
  fVar2 = (float10)FUN_01725280((dVar1 + DAT_019011c8) / DAT_019011d0);
  return (float10)(float)((double)CONCAT44(param_2,param_1) - (double)fVar2 * DAT_019011d0);
}



/* FUNCTION 18748 ; VA 0x009bf280 ; FUN_009bf280 */

void FUN_009bf280(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  if (param_1 != 0) {
    uVar4 = 0;
    iVar1 = FUN_005d6c30();
    if (iVar1 != 0) {
      do {
        iVar1 = *(int *)(**(int **)(param_1 + 0x2c) + uVar4 * 8);
        if ((iVar1 != 0) &&
           (iVar1 = *(int *)(iVar1 + 0xc), iVar2 = FUN_00c8dce0(),
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
           (uint)*(ushort *)(iVar2 + 0x1da))) {
          FUN_00c90900();
        }
        uVar4 = uVar4 + 1;
        uVar3 = FUN_005d6c30();
      } while (uVar4 < uVar3);
    }
  }
  return;
}



/* FUNCTION 18749 ; VA 0x009bf2f0 ; FUN_009bf2f0 */

void __fastcall FUN_009bf2f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  bool bVar4;
  bool bVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  int *piVar11;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5278;
  pvStack_10 = ExceptionList;
  bVar5 = false;
  bVar4 = false;
  iStack_24 = 0;
  iStack_14 = param_1;
  if (*(int *)(param_1 + 0x228) == 0) {
    piVar11 = (int *)(param_1 + 0x340);
    iStack_18 = 0;
    ExceptionList = &pvStack_10;
    do {
      if (*piVar11 != 0) {
        FUN_009b11e0(piVar11);
      }
      uStack_20 = CONCAT31(uStack_20._1_3_,*(int *)(iStack_14 + 0x228) != 0);
      uVar6 = FUN_009b3ce0(iStack_18,uStack_20);
      uVar6 = FUN_008a1240(uVar6);
      piStack_1c = (int *)FUN_0060dcd0(auStack_3c,uVar6);
      uStack_8 = 0;
      if ((*piStack_1c == 0) ||
         (iVar8 = *(int *)(*piStack_1c + 0xc), iVar7 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar7 + 0x1da) <
         (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
        piStack_28 = (int *)0x0;
        puVar10 = &uStack_2c;
        bVar4 = true;
        piStack_1c = (int *)0x0;
      }
      else {
        piStack_30 = (int *)piStack_1c[1];
        iVar8 = *piStack_1c;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          piStack_30[1] = piStack_30[1] + 1;
          UNLOCK();
          piStack_30 = (int *)piStack_1c[1];
        }
        bVar5 = true;
        puVar10 = &uStack_34;
        piStack_1c = (int *)iVar8;
      }
      iStack_24 = puVar10[1];
      *puVar10 = 0;
      puVar10[1] = 0;
      piVar2 = piStack_28;
      if ((bVar4) && (bVar4 = false, piStack_28 != (int *)0x0)) {
        LOCK();
        iVar8 = piStack_28[1] + -1;
        piStack_28[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar8 = *piVar1 + -1;
          *piVar1 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_30;
      if ((bVar5) && (bVar5 = false, piStack_30 != (int *)0x0)) {
        LOCK();
        iVar8 = piStack_30[1] + -1;
        piStack_30[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar8 = *piVar1 + -1;
          *piVar1 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      *piVar11 = (int)piStack_1c;
      piVar2 = (int *)piVar11[1];
      piVar11[1] = iStack_24;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar8 = piVar2[1] + -1;
        piVar2[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar8 = piVar2[2] + -1;
          piVar2[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_38;
      uStack_8 = 0xffffffff;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_38[1] + -1;
        piStack_38[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar8 = *piVar1 + -1;
          *piVar1 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      if (piVar11[1] != 0) {
        LOCK();
        piVar2 = (int *)(piVar11[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_009c8ad0(*piVar11,piVar11[1]);
      piVar11 = piVar11 + 2;
      iStack_18 = iStack_18 + 1;
    } while (iStack_18 < 7);
  }
  else {
    piVar11 = &DAT_01d64c60;
    ExceptionList = &pvStack_10;
    do {
      if (*(int *)(param_1 + (*piVar11 + 0x6f) * 8) != 0) {
        FUN_009b11e0(param_1 + (*piVar11 + 0x6f) * 8);
      }
      iVar8 = FUN_008a1240(piVar11 + 1);
      if ((iVar8 == 0) ||
         (iVar7 = *(int *)(iVar8 + 0xc), iVar9 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar9 + 0x1da) <
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8))) {
        iVar8 = 0;
      }
      puVar10 = (undefined4 *)FUN_0060dcd0(&uStack_34,iVar8);
      iVar8 = iStack_14 + *piVar11 * 8;
      uVar6 = *puVar10;
      uVar3 = puVar10[1];
      *puVar10 = 0;
      puVar10[1] = 0;
      *(undefined4 *)(iVar8 + 0x378) = uVar6;
      piVar2 = *(int **)(iVar8 + 0x37c);
      *(undefined4 *)(iVar8 + 0x37c) = uVar3;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar8 = piVar2[1] + -1;
        piVar2[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar8 = piVar2[2] + -1;
          piVar2[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_30;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_30[1] + -1;
        piStack_30[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar8 = *piVar1 + -1;
          *piVar1 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      param_1 = iStack_14;
      iVar8 = iStack_14 + *piVar11 * 8;
      if (*(int *)(iVar8 + 0x37c) != 0) {
        LOCK();
        piVar2 = (int *)(*(int *)(iVar8 + 0x37c) + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_009c8ad0(*(undefined4 *)(iVar8 + 0x378),*(undefined4 *)(iVar8 + 0x37c));
      piVar11 = piVar11 + 7;
    } while (piVar11 != &DAT_01d64e20);
  }
  FUN_009c7e00();
  ExceptionList = pvStack_10;
  return;
}


