/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 27750 ; VA 0x00c2aef0 ; FUN_00c2aef0 */

void __fastcall FUN_00c2aef0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::SocialService>::vftable;
  uVar1 = FUN_00c2a7d0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27751 ; VA 0x00c2af30 ; FUN_00c2af30 */

/* WARNING: Removing unreachable block (ram,0x00c2af82) */
/* WARNING: Removing unreachable block (ram,0x00c2af92) */
/* WARNING: Removing unreachable block (ram,0x00c2af98) */

void * __thiscall
FUN_00c2af30(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807ab0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 27752 ; VA 0x00c2b037 ; Catch@00c2b037 */

undefined * Catch_00c2b037(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00c2b048;
}



/* FUNCTION 27753 ; VA 0x00c2b060 ; FUN_00c2b060 */

undefined4 __thiscall FUN_00c2b060(undefined4 param_1,byte param_2)

{
  FUN_00c2ae50();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 27754 ; VA 0x00c2b090 ; FUN_00c2b090 */

undefined4 * __thiscall FUN_00c2b090(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::SocialService::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x68);
  }
  return param_1;
}



/* FUNCTION 27755 ; VA 0x00c2b0e0 ; FUN_00c2b0e0 */

void FUN_00c2b0e0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  int *piVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c38c0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef9c21);
  auStack_6c[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_6c;
  puVar4 = auStack_6c;
  if (uVar2 != 0) {
    auStack_6c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0xc2b157;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_1c;
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_6c;
      puVar4 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_008dc2e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xc2b239;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_90 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(*param_4,0xc2b27d);
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27756 ; VA 0x00c2b290 ; FUN_00c2b290 */

void __thiscall
FUN_00c2b290(int *****param_1,int param_2,int *param_3,uint param_4,undefined4 param_5,
            int ****param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,int ****param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int ****ppppiVar1;
  int ***pppiVar2;
  char **ppcVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  int *****pppppiVar7;
  int *piVar8;
  int ****ppppiVar9;
  undefined **ppuVar10;
  undefined auStack_274 [4];
  undefined4 uStack_270;
  int ***pppiStack_26c;
  int ***pppiStack_268;
  undefined4 uStack_264;
  int ****ppppiStack_260;
  int ***pppiStack_25c;
  int ****ppppiStack_258;
  int ***pppiStack_254;
  int ***pppiStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined8 uStack_240;
  undefined4 uStack_238;
  char *pcStack_234;
  undefined4 uStack_230;
  undefined uStack_22c;
  undefined4 uStack_224;
  undefined4 *puStack_220;
  undefined4 *puStack_21c;
  int ****ppppiStack_218;
  undefined auStack_20c [72];
  undefined auStack_1c4 [72];
  undefined auStack_17c [72];
  undefined auStack_134 [72];
  undefined auStack_ec [72];
  int ****appppiStack_a4 [2];
  uint uStack_9c;
  int ***pppiStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  uint uStack_7c;
  int ***pppiStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined *puStack_5c;
  undefined auStack_58 [4];
  undefined auStack_54 [4];
  int *piStack_50;
  int ****ppppiStack_4c;
  uint uStack_44;
  int ***pppiStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined *puStack_24;
  int ***pppiStack_20;
  int ****ppppiStack_1c;
  char cStack_15;
  int ****ppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807cb4;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puStack_21c = (undefined4 *)0xc2b2c2;
  ExceptionList = &pvStack_10;
  ppppiStack_218 = (int ****)param_1;
  ppppiStack_1c = (int ****)param_1;
  iVar5 = FUN_0064e810();
  if (iVar5 != 0) {
    puStack_21c = (undefined4 *)0xc2b2d5;
    ppppiStack_218 = (int ****)param_1;
    iVar6 = FUN_008f7870();
    if (iVar6 == 0) {
      puStack_21c = (undefined4 *)auStack_58;
      ppppiStack_218 = (int ****)0x1966808;
      puStack_220 = (undefined4 *)0xc2b8fe;
      FUN_016756b0();
      puStack_21c = (undefined4 *)auStack_58;
      ppppiStack_218 = (int ****)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
      puStack_220 = (undefined4 *)0xc2b90f;
      FUN_0170c2a8();
    }
    if ((*(int *)(iVar6 + 0x4a0) != 1) && (*(int *)(iVar6 + 0x4a0) != 3)) {
      uStack_230 = 0x4b;
      puStack_21c = (undefined4 *)0x0;
      ppppiStack_218 = (int ****)0xf;
      pcStack_234 = "SocialService:CanSendGameInviteAsync can only be executed by a local script";
      uStack_22c = 0;
      uStack_238 = 0xc2b312;
      FUN_005542c0();
      uStack_230 = 0xc2b31a;
      FUN_005e65e0();
      ppppiStack_218 = (int ****)0xc2b322;
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if ((param_4 != 0) &&
         (((param_4 & 1) == 0 && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)))) {
        puStack_220 = &param_6;
        ppppiStack_218 = (int ****)0x2;
        uStack_224 = 0xc2b343;
        puStack_21c = puStack_220;
        (**(code **)(param_4 & 0xfffffffe))();
      }
      uStack_8 = 4;
      goto LAB_00c2b8be;
    }
    if (param_2 != *(int *)(iVar5 + 0xf4)) {
      uStack_230 = 0x92;
      puStack_21c = (undefined4 *)0x0;
      ppppiStack_218 = (int ****)0xf;
      pcStack_234 = 
      "SocialService:CanSendGameInviteAsync called from a local script, but not called on a local player. Local scripts can only prompt the local player."
      ;
      uStack_22c = 0;
      uStack_238 = 0xc2b389;
      FUN_005542c0();
      uStack_230 = 0xc2b391;
      FUN_005e65e0();
      ppppiStack_218 = (int ****)0xc2b399;
      FUN_00550b30();
      ppppiStack_218 = (int ****)0xc2b3a1;
      FUN_00550990();
      ppppiStack_218 = (int ****)0xc2b3a9;
      FUN_00550990();
      ExceptionList = pvStack_10;
      return;
    }
  }
  if (param_1 != (int *****)0x0) {
    ppppiStack_14 = param_1[0xd];
    pppppiVar7 = param_1;
    if (((int *****)ppppiStack_14 != (int *****)0x0) &&
       (pppppiVar7 = (int *****)ppppiStack_14, ((int *****)ppppiStack_14)[0xd] != (int ****)0x0)) {
      ppppiStack_218 = (int ****)0xc2b3d9;
      pppppiVar7 = (int *****)FUN_005c8ac0();
    }
    ppppiStack_14 = (int ****)pppppiVar7;
    if ((int *****)ppppiStack_14 != (int *****)0x0) {
      ppppiVar1 = (int ****)ppppiStack_14[3];
      ppppiStack_218 = (int ****)0xc2b3f3;
      iVar5 = FUN_008a8c30();
      if ((uint)*(ushort *)(ppppiVar1 + 0x76) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        ppppiStack_218 = (int ****)0xc2b41a;
        iVar5 = FUN_00634d90();
        if (iVar5 != 0) {
          ppppiStack_218 = (int ****)0xc2b427;
          cVar4 = FUN_00b83ad0();
          if (cVar4 == '\0') {
            ppppiStack_14 = param_1[0xd];
            pppppiVar7 = param_1;
            if (((int *****)ppppiStack_14 != (int *****)0x0) &&
               (pppppiVar7 = (int *****)ppppiStack_14,
               ((int *****)ppppiStack_14)[0xd] != (int ****)0x0)) {
              ppppiStack_218 = (int ****)0xc2b445;
              pppppiVar7 = (int *****)FUN_005c8ac0();
            }
            ppppiStack_14 = (int ****)pppppiVar7;
            if ((int *****)ppppiStack_14 != (int *****)0x0) {
              ppppiVar1 = (int ****)ppppiStack_14[3];
              ppppiStack_218 = (int ****)0xc2b462;
              iVar5 = FUN_008a8c30();
              if ((uint)*(ushort *)(ppppiVar1 + 0x76) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                  (uint)*(ushort *)(iVar5 + 0x1da)) {
                ppppiStack_218 = (int ****)&LAB_0064e290;
                puStack_21c = (undefined4 *)&DAT_01eadc4c;
                puStack_220 = (undefined4 *)0xc2b490;
                FUN_005789c0();
                ppppiStack_218 = (int ****)0xc2b498;
                ppppiStack_218 = (int ****)FUN_0064e320();
                puStack_21c = (undefined4 *)0xc2b4a3;
                ppppiStack_14 = (int ****)FUN_008aa140();
                if ((int ****)*ppppiStack_14 == (int ****)0x0) {
                  ppppiStack_218 = (int ****)0xc2b4b0;
                  ppppiStack_218 = (int ****)FUN_00bc47d0();
                  puStack_21c = (undefined4 *)auStack_54;
                  puStack_220 = (undefined4 *)0xc2b4bc;
                  piVar8 = (int *)FUN_008a9ba0();
                  ppppiVar1 = (int ****)*piVar8;
                  ppppiVar9 = (int ****)piVar8[1];
                  *piVar8 = 0;
                  piVar8[1] = 0;
                  *ppppiStack_14 = (int ***)ppppiVar1;
                  ppppiVar1 = (int ****)ppppiStack_14[1];
                  ppppiStack_14[1] = (int ***)ppppiVar9;
                  if (ppppiVar1 != (int ****)0x0) {
                    LOCK();
                    pppiVar2 = (int ***)((int)ppppiVar1[1] + -1);
                    ppppiVar1[1] = pppiVar2;
                    UNLOCK();
                    if (pppiVar2 == (int ***)0x0) {
                      ppppiStack_218 = (int ****)0xc2b4ec;
                      (*(code *)**ppppiVar1)();
                      LOCK();
                      pppiVar2 = (int ***)((int)ppppiVar1[2] + -1);
                      ppppiVar1[2] = pppiVar2;
                      UNLOCK();
                      if (pppiVar2 == (int ***)0x0) {
                        ppppiStack_218 = (int ****)0xc2b4fc;
                        (*(code *)(*ppppiVar1)[1])();
                      }
                    }
                  }
                  if (piStack_50 != (int *)0x0) {
                    LOCK();
                    iVar5 = piStack_50[1] + -1;
                    piStack_50[1] = iVar5;
                    UNLOCK();
                    if (iVar5 == 0) {
                      ppppiStack_218 = (int ****)0xc2b515;
                      (**(code **)*piStack_50)();
                      LOCK();
                      iVar5 = piStack_50[2] + -1;
                      piStack_50[2] = iVar5;
                      UNLOCK();
                      if (iVar5 == 0) {
                        ppppiStack_218 = (int ****)0xc2b525;
                        (**(code **)(*piStack_50 + 4))();
                      }
                    }
                  }
                }
                ppppiVar1 = ppppiStack_1c;
                pppiStack_20 = *ppppiStack_14;
                if ((int ****)pppiStack_20 != (int ****)0x0) {
                  puStack_5c = (undefined *)&pcStack_234;
                  ppppiStack_14 = (int ****)&pcStack_234;
                  ppppiStack_4c = ppppiStack_1c;
                  uStack_44 = 0;
                  ppcVar3 = &pcStack_234;
                  ppppiVar9 = (int ****)&pcStack_234;
                  if (param_11 != 0) {
                    uStack_44 = param_11;
                    if ((param_11 & 1) == 0) {
                      uStack_238 = 0;
                      uStack_240 = CONCAT44(&pppiStack_3c,&param_13);
                      uStack_244 = 0xc2b580;
                      (**(code **)(param_11 & 0xfffffffe))();
                      ppcVar3 = (char **)puStack_5c;
                      ppppiVar9 = ppppiStack_14;
                    }
                    else {
                      pppiStack_3c = (int ***)param_13;
                      uStack_38 = param_14;
                      uStack_34 = param_15;
                      uStack_30 = param_16;
                      uStack_2c = param_17;
                      ppcVar3 = &pcStack_234;
                      ppppiVar9 = (int ****)&pcStack_234;
                    }
                  }
                  ppppiStack_14 = ppppiVar9;
                  puStack_5c = (undefined *)ppcVar3;
                  uStack_238 = 0;
                  puStack_24 = (undefined *)&ppppiStack_260;
                  uStack_8._0_1_ = 5;
                  ppppiStack_258 = (int ****)0x0;
                  ppppiStack_260 = ppppiStack_4c;
                  pppppiVar7 = &ppppiStack_260;
                  if (uStack_44 != 0) {
                    ppppiStack_258 = (int ****)uStack_44;
                    if ((uStack_44 & 1) == 0) {
                      pppiStack_268 = (int ***)&pppiStack_250;
                      uStack_264 = 0;
                      pppiStack_26c = (int ***)&pppiStack_3c;
                      uStack_270 = 0xc2b5d1;
                      (**(code **)(uStack_44 & 0xfffffffe))();
                      pppppiVar7 = (int *****)puStack_24;
                    }
                    else {
                      pppiStack_250 = pppiStack_3c;
                      uStack_24c = uStack_38;
                      uStack_248 = uStack_34;
                      uStack_244 = uStack_30;
                      uStack_240 = uStack_2c;
                      pppppiVar7 = &ppppiStack_260;
                    }
                  }
                  puStack_24 = (undefined *)pppppiVar7;
                  uStack_264 = 0xc2b5dc;
                  FUN_00c2a600();
                  uStack_8._0_1_ = 6;
                  if (uStack_44 != 0) {
                    if (((uStack_44 & 1) == 0) &&
                       (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
                      uStack_238 = 2;
                      uStack_240 = CONCAT44(&pppiStack_3c,&pppiStack_3c);
                      uStack_244 = 0xc2b601;
                      (**(code **)(uStack_44 & 0xfffffffe))();
                    }
                    uStack_44 = 0;
                  }
                  ppppiStack_14 = (int ****)appppiStack_a4;
                  uStack_8._0_1_ = 7;
                  puStack_24 = (undefined *)&pppiStack_254;
                  ppppiStack_1c = &pppiStack_254;
                  appppiStack_a4[0] = ppppiVar1;
                  uStack_9c = 0;
                  ppppiVar1 = &pppiStack_254;
                  pppppiVar7 = (int *****)&pppiStack_254;
                  if (param_4 != 0) {
                    uStack_9c = param_4;
                    if ((param_4 & 1) == 0) {
                      pppiStack_25c = (int ***)&pppiStack_94;
                      ppppiStack_258 = (int ****)0x0;
                      ppppiStack_260 = (int ****)&param_6;
                      uStack_264 = 0xc2b66d;
                      (**(code **)(param_4 & 0xfffffffe))();
                      ppppiVar1 = (int ****)puStack_24;
                      pppppiVar7 = (int *****)ppppiStack_1c;
                    }
                    else {
                      pppiStack_94 = (int ***)param_6;
                      uStack_90 = param_7;
                      uStack_8c = param_8;
                      uStack_88 = param_9;
                      uStack_84 = param_10;
                      ppppiVar1 = &pppiStack_254;
                      pppppiVar7 = (int *****)&pppiStack_254;
                    }
                  }
                  ppppiStack_1c = (int ****)pppppiVar7;
                  puStack_24 = (undefined *)ppppiVar1;
                  uStack_8._0_1_ = 8;
                  uStack_7c = 0;
                  if (param_11 != 0) {
                    uStack_7c = param_11;
                    if ((param_11 & 1) == 0) {
                      pppiStack_25c = (int ***)&pppiStack_74;
                      ppppiStack_258 = (int ****)0x0;
                      ppppiStack_260 = (int ****)&param_13;
                      uStack_264 = 0xc2b6ae;
                      (**(code **)(param_11 & 0xfffffffe))();
                    }
                    else {
                      pppiStack_74 = (int ***)param_13;
                      uStack_70 = param_14;
                      uStack_6c = param_15;
                      uStack_68 = param_16;
                      uStack_64 = param_17;
                    }
                  }
                  ppppiStack_258 = (int ****)appppiStack_a4;
                  uStack_8._0_1_ = 9;
                  pppiStack_25c = (int ***)0xc2b6c7;
                  FUN_00c2ac90();
                  ppppiVar1 = ppppiStack_1c;
                  ppppiStack_258 = (int ****)auStack_20c;
                  uStack_8._0_1_ = 10;
                  *ppppiStack_1c = (int ***)0x0;
                  pppiStack_25c = (int ***)0xc2b6e6;
                  FUN_00c2ac90();
                  ppppiStack_258 = (int ****)auStack_1c4;
                  uStack_8._0_1_ = 0xb;
                  pppiStack_25c = (int ***)0xc2b6fc;
                  FUN_00c2ac90();
                  ppppiStack_258 = (int ****)auStack_17c;
                  uStack_8._0_1_ = 0xc;
                  pppiStack_25c = (int ***)0xc2b712;
                  FUN_00c2ac90();
                  ppppiStack_258 = (int ****)auStack_ec;
                  uStack_8._0_1_ = 0xd;
                  pppiStack_25c = (int ***)0xc2b722;
                  cVar4 = FUN_00585a40();
                  if (cVar4 == '\0') {
                    ppppiStack_258 = (int ****)auStack_ec;
                    pppiStack_25c = (int ***)0xc2b73b;
                    FUN_00c2ac90();
                    ppppiStack_258 = (int ****)0x48;
                    uStack_8._0_1_ = 0xe;
                    pppiStack_25c = (int ***)0xc2b746;
                    ppppiStack_1c = (int ****)FUN_01674e20();
                    uStack_8._0_1_ = 0xf;
                    if ((int *****)ppppiStack_1c == (int *****)0x0) {
                      ppppiVar9 = (int ****)0x0;
                    }
                    else {
                      ppppiStack_258 = (int ****)auStack_134;
                      pppiStack_25c = (int ***)0xc2b762;
                      ppppiVar9 = (int ****)FUN_00c2ac90();
                    }
                    ppppiVar1[2] = (int ***)ppppiVar9;
                    ppppiStack_258 = (int ****)0xc2b774;
                    FUN_0096ca80();
                    ppppiStack_258 = (int ****)0xc2b77f;
                    FUN_0096ca80();
                    cStack_15 = '\x01';
                  }
                  else {
                    ppppiStack_258 = (int ****)0xc2b790;
                    FUN_0096ca80();
                    cStack_15 = '\0';
                  }
                  ppppiStack_258 = (int ****)0xc2b79f;
                  FUN_0096ca80();
                  ppuVar10 = &PTR_FUN_01966944;
                  if (cStack_15 == '\0') {
                    ppuVar10 = (undefined **)0x0;
                  }
                  *ppppiVar1 = (int ***)ppuVar10;
                  ppppiStack_258 = (int ****)0xc2b7b9;
                  FUN_0096ca80();
                  ppppiStack_258 = (int ****)0xc2b7c4;
                  FUN_0096ca80();
                  ppppiStack_258 = (int ****)0xc2b7cf;
                  FUN_0096ca80();
                  ppppiStack_258 = (int ****)0x18;
                  pppiStack_25c = (int ***)0x0;
                  uStack_8._0_1_ = 0x10;
                  FUN_010805c0(auStack_274);
                  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                  FUN_00bcb620();
                }
              }
            }
            if (param_3 != (int *)0x0) {
              LOCK();
              iVar5 = param_3[1] + -1;
              param_3[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                ppppiStack_218 = (int ****)0xc2b805;
                (**(code **)*param_3)();
                LOCK();
                piVar8 = param_3 + 2;
                iVar5 = *piVar8;
                *piVar8 = *piVar8 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                  ppppiStack_218 = (int ****)0xc2b814;
                  (**(code **)(*param_3 + 4))();
                }
              }
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
            if (((param_4 != 0) && ((param_4 & 1) == 0)) &&
               (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
              puStack_220 = &param_6;
              ppppiStack_218 = (int ****)0x2;
              uStack_224 = 0xc2b835;
              puStack_21c = puStack_220;
              (**(code **)(param_4 & 0xfffffffe))();
            }
            uStack_8 = 0x12;
            goto LAB_00c2b8be;
          }
        }
      }
    }
  }
  if (param_4 == 0) {
    ppppiStack_218 = (int ****)0xc2b917;
    ppppiStack_218 = (int ****)FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
                    /* WARNING: Subroutine does not return */
    puStack_21c = (undefined4 *)&UNK_00c2b921;
    FUN_0054e5e0();
  }
  puStack_21c = &param_6;
  ppppiStack_218 = (int ****)0x0;
  puStack_220 = (undefined4 *)0xc2b861;
  (**(code **)((param_4 & 0xfffffffe) + 4))();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppppiStack_218 = (int ****)0xc2b87d;
      (**(code **)*param_3)();
      LOCK();
      piVar8 = param_3 + 2;
      iVar5 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        ppppiStack_218 = (int ****)0xc2b88c;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_220 = &param_6;
    ppppiStack_218 = (int ****)0x2;
    uStack_224 = 0xc2b8ad;
    puStack_21c = puStack_220;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 0x15;
LAB_00c2b8be:
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_220 = &param_13;
    ppppiStack_218 = (int ****)0x2;
    uStack_224 = 0xc2b8db;
    puStack_21c = puStack_220;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27757 ; VA 0x00c2b930 ; FUN_00c2b930 */

undefined4 * __thiscall
FUN_00c2b930(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807cf1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c2bdc0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27758 ; VA 0x00c2bae0 ; FUN_00c2bae0 */

undefined4 * FUN_00c2bae0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00673e70(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27759 ; VA 0x00c2bb50 ; FUN_00c2bb50 */

void __thiscall FUN_00c2bb50(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_008882f0();
    iStack_1b8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_1b4 = *puVar5;
    uStack_1b0 = puVar5[1];
    iStack_1b8 = FUN_005c9da0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27760 ; VA 0x00c2bdc0 ; FUN_00c2bdc0 */

int FUN_00c2bdc0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807d44;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_008882f0();
  uStack_ec = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_4;
  piStack_e4 = param_5;
  uStack_ec = FUN_005c9da0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27761 ; VA 0x00c2bf90 ; FUN_00c2bf90 */

void __thiscall FUN_00c2bf90(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint in_stack_0000002c;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c85cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 2;
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_f4);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_0088a3d0();
      piVar5 = (int *)puVar4[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)puVar4[1];
      }
      uStack_18 = *puVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_14 = piVar5;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      FUN_00550b30();
      goto LAB_00c2c0a0;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  piVar5 = (int *)puVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)puVar4[1];
  }
  uStack_18 = *puVar4;
  piStack_14 = piVar5;
LAB_00c2c0a0:
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00c2b0e0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27762 ; VA 0x00c2c170 ; FUN_00c2c170 */

undefined4 FUN_00c2c170(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807d60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_01256300(param_2);
  puVar6 = (undefined4 *)FUN_009d11e0(auStack_24,param_2,param_3,2,iVar5 - param_3,iStack_14 + 0x44)
  ;
  uStack_8 = 0;
  puVar7 = (undefined4 *)FUN_009d1340(auStack_1c,param_2,param_3,1,iVar5 - param_3,iStack_14 + 0x40)
  ;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  if (puVar7[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*puVar7,puVar7[1],uVar3,uVar4);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27763 ; VA 0x00c2c2b0 ; FUN_00c2c2b0 */

/* WARNING: Removing unreachable block (ram,0x00c2c472) */
/* WARNING: Removing unreachable block (ram,0x00c2c47b) */
/* WARNING: Removing unreachable block (ram,0x00c2c48a) */
/* WARNING: Removing unreachable block (ram,0x00c2c498) */
/* WARNING: Removing unreachable block (ram,0x00c2c4a1) */
/* WARNING: Removing unreachable block (ram,0x00c2c4af) */

undefined4
FUN_00c2c2b0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  int iStack_1d0;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  int iStack_100;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807dbc;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00c2c4d0(param_1,param_2,param_3,param_4,param_5);
  uStack_18 = param_4;
  uStack_30 = param_4;
  iStack_1c = param_5;
  iStack_2c = param_5;
  uStack_28 = param_2;
  iStack_24 = param_3;
  uStack_8._0_1_ = 3;
  pcStack_14 = *(code **)(*param_1 + 8);
  uStack_1dc = FUN_0088cdc0();
  uStack_1d8 = 0;
  uStack_1d4 = param_2;
  iStack_1d0 = param_3;
  uStack_28 = 0;
  iStack_24 = 0;
  uStack_1d8 = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_10c = FUN_008882f0();
  uStack_104 = uStack_18;
  uStack_108 = 0;
  iStack_100 = iStack_1c;
  uStack_30 = 0;
  iStack_2c = 0;
  uStack_108 = FUN_005c9da0();
  uStack_8._0_1_ = 5;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  FUN_00687980(&uStack_1dc,&uStack_3c,param_1);
  uStack_8._0_1_ = 6;
  (*pcStack_14)(uStack_20,&uStack_3c,param_6);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar1 = FUN_016f32d1(&uStack_1dc,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 27764 ; VA 0x00c2c4d0 ; FUN_00c2c4d0 */

/* WARNING: Removing unreachable block (ram,0x00c2c55e) */
/* WARNING: Removing unreachable block (ram,0x00c2c567) */
/* WARNING: Removing unreachable block (ram,0x00c2c576) */
/* WARNING: Removing unreachable block (ram,0x00c2c584) */
/* WARNING: Removing unreachable block (ram,0x00c2c58d) */
/* WARNING: Removing unreachable block (ram,0x00c2c59b) */

undefined4
FUN_00c2c4d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807de0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2af30(param_2,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 27765 ; VA 0x00c2c5c0 ; FUN_00c2c5c0 */

void FUN_00c2c5c0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807df8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_2;
  iVar4 = *(int *)(iVar2 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008882f0();
  if (iVar4 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar2 + 0xd8;
  if (*(int *)(iVar2 + 0xd4) == 0) {
    iVar4 = 0;
  }
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar5 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar2 = *param_2;
  iVar4 = FUN_0088cdc0();
  if (iVar2 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0xffffffff;
    FUN_00c2c4d0(param_1,*piVar5,piVar5[1]);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27766 ; VA 0x00c2c6b0 ; FUN_00c2c6b0 */

void FUN_00c2c6b0(int *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4780;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar1 = *param_1;
  uVar2 = *(uint *)(iVar1 + 8);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x10,&uStack_30,0);
    }
    else {
      uStack_30 = *(undefined4 *)(iVar1 + 0x10);
      uStack_2c = *(undefined4 *)(iVar1 + 0x14);
      uStack_28 = *(undefined4 *)(iVar1 + 0x18);
      uStack_24 = *(undefined4 *)(iVar1 + 0x1c);
      uStack_20 = *(undefined8 *)(iVar1 + 0x20);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00c2ccb0();
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
        uStack_20 = CONCAT44(&UNK_00c2c780,(undefined4)uStack_20);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_20 = CONCAT44(uVar2,iVar1);
    uStack_24 = 0xc2c769;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27767 ; VA 0x00c2c790 ; FUN_00c2c790 */

void FUN_00c2c790(int *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01807e28;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar1 = *param_1;
  uStack_40 = 0;
  uVar2 = *(uint *)(iVar1 + 0x28);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = iVar1 + 0x30;
      uStack_50 = 0xc2c7ff;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(iVar1 + 0x30);
      uStack_34 = *(undefined4 *)(iVar1 + 0x34);
      uStack_30 = *(undefined4 *)(iVar1 + 0x38);
      uStack_2c = *(undefined4 *)(iVar1 + 0x3c);
      uStack_28 = *(undefined8 *)(iVar1 + 0x40);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar2 = *(uint *)(iVar1 + 8);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x10,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(iVar1 + 0x10);
      uStack_54 = *(undefined4 *)(iVar1 + 0x14);
      uStack_50 = *(undefined4 *)(iVar1 + 0x18);
      iStack_4c = *(int *)(iVar1 + 0x1c);
      uStack_48 = *(ulonglong *)(iVar1 + 0x20);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00c2cd80();
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
        uStack_28 = CONCAT44(&UNK_00c2c8af,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar2,iVar1);
    uStack_2c = 0xc2c897;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27768 ; VA 0x00c2c8b0 ; FUN_00c2c8b0 */

int __thiscall
FUN_00c2c8b0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807e60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 3;
  uStack_18 = 0;
  uStack_14 = 0;
  iVar3 = FUN_00c2c2b0(param_1,param_2,param_3,param_4,param_5,&uStack_20);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27769 ; VA 0x00c2c9b0 ; FUN_00c2c9b0 */

uint FUN_00c2c9b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c2a7d0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27770 ; VA 0x00c2c9d0 ; FUN_00c2c9d0 */

uint FUN_00c2c9d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c2a7d0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27771 ; VA 0x00c2c9f0 ; FUN_00c2c9f0 */

void FUN_00c2c9f0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dff54c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_092a79174d3efc5669860f8ade9098e5>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27772 ; VA 0x00c2cb60 ; FUN_00c2cb60 */

void FUN_00c2cb60(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00c2ac90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dff584);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_45e4557999d1a4244bc08beb6138d0ec>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27773 ; VA 0x00c2ccb0 ; FUN_00c2ccb0 */

void FUN_00c2ccb0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_01807e80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puVar1 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar1 = param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_01675640(auStack_2c,"SocialService:CanSendGameInviteAsync request failed: %s",puVar1);
  FUN_005e65e0();
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000018) {
    puStack_18 = (undefined *)(in_stack_00000018 + 1);
    puStack_1c = param_1;
    if (0xfff < puStack_18) {
      puStack_1c = (undefined4 *)param_1[-1];
      puStack_18 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puStack_1c))) {
                    /* WARNING: Subroutine does not return */
        puStack_18 = &UNK_00c2cd79;
        FUN_017167a3();
      }
    }
    puStack_20 = (undefined *)0xc2cd28;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = 2;
  if (((in_stack_0000001c != 0) && ((in_stack_0000001c & 1) == 0)) &&
     (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
    puStack_20 = &stack0x00000024;
    puStack_18 = (undefined *)0x2;
    uStack_24 = 0xc2cd61;
    puStack_1c = (undefined4 *)puStack_20;
    (**(code **)(in_stack_0000001c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27774 ; VA 0x00c2cd80 ; FUN_00c2cd80 */

void FUN_00c2cd80(uint param_1)

{
  int iVar1;
  uint *puVar2;
  uint *puVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  byte *pbVar9;
  byte *pbVar10;
  uint uVar11;
  int *piVar12;
  bool bVar13;
  int in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 *in_stack_00000050;
  ulonglong in_stack_00000054;
  undefined uVar14;
  uint auStack_124 [2];
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 *puStack_110;
  undefined8 uStack_10c;
  int iStack_fc;
  int iStack_f8;
  undefined4 auStack_f4 [50];
  byte *pbStack_2c;
  int *piStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807ed3;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (in_stack_00000014 == 0) {
    puStack_1c = (undefined *)auStack_124;
    puStack_18 = (undefined *)auStack_124;
    auStack_124[0] = 0;
    ExceptionList = &pvStack_10;
    puVar2 = auStack_124;
    puVar3 = auStack_124;
    if (in_stack_0000003c != 0) {
      auStack_124[0] = in_stack_0000003c;
      if ((in_stack_0000003c & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_11c,0);
        puVar2 = (uint *)puStack_1c;
        puVar3 = (uint *)puStack_18;
      }
      else {
        uStack_11c = in_stack_00000044;
        uStack_118 = in_stack_00000048;
        uStack_114 = in_stack_0000004c;
        puStack_110 = in_stack_00000050;
        uStack_10c = in_stack_00000054;
        ExceptionList = &pvStack_10;
        puVar2 = auStack_124;
        puVar3 = auStack_124;
      }
    }
    puStack_18 = (undefined *)puVar3;
    puStack_1c = (undefined *)puVar2;
    uStack_8._0_1_ = 3;
    uVar14 = 0;
    FUN_005542c0("Empty response received from Chat webserver",0x2b);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00c2ccb0(uVar14);
    goto LAB_00c2d0d3;
  }
  uStack_10c = CONCAT44(0xc2ce34,(undefined4)uStack_10c);
  ExceptionList = &pvStack_10;
  iStack_fc = FUN_00888530();
  iStack_f8 = 0;
  uStack_8._0_1_ = 4;
  uStack_10c = ZEXT48(&iStack_fc);
  puStack_110 = &param_1;
  uStack_114 = 0xc2ce5a;
  cVar4 = FUN_0098ef90();
  iVar1 = iStack_fc;
  if (cVar4 == '\0') {
    puStack_1c = (undefined *)auStack_124;
    FUN_0054f510(&stack0x0000003c);
    uStack_8._0_1_ = 8;
    uVar14 = 0;
    FUN_005542c0("An unknown error occured",0x18);
    uStack_8._0_1_ = 4;
    FUN_00c2ccb0(uVar14);
LAB_00c2d0b6:
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
  }
  else {
    uStack_10c = CONCAT44(0xc2ce70,(undefined4)uStack_10c);
    iVar5 = FUN_008881d0();
    if (iVar1 != iVar5) {
      uStack_10c = 0x18c072c00c2d18b;
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    puVar6 = auStack_f4;
    if (iStack_f8 == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    piVar8 = (int *)puVar6[1];
    piStack_14 = piVar8;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)puVar6[1];
      piStack_14 = piVar8;
    }
    pbVar9 = (byte *)*puVar6;
    uStack_8._0_1_ = 5;
    uStack_10c = CONCAT44(&DAT_01d685b4,pbVar9 + *pbVar9 + 1);
    puStack_110 = (undefined4 *)0xc2ceba;
    pbStack_2c = pbVar9;
    piStack_28 = piVar8;
    piStack_14 = piVar8;
    uStack_20 = FUN_0055c740();
    uStack_24 = *(uint *)(pbVar9 + 4);
    puStack_18 = (undefined *)(uStack_20 % uStack_24);
    if (*(int *)(pbVar9 + 8) == 0) {
      piVar12 = (int *)0x0;
LAB_00c2cf9b:
      if (piVar12 != (int *)0x0) {
        iVar1 = piVar12[8];
        uStack_10c = CONCAT44(0xc2cfa7,(undefined4)uStack_10c);
        iVar5 = FUN_0088daf0();
        if (iVar1 != iVar5) {
          uStack_10c = 0x18c072c00c2d195;
                    /* WARNING: Subroutine does not return */
          FUN_016757c0();
        }
        piVar8 = piVar12 + 10;
        if (piVar12[9] == 0) {
          piVar8 = (int *)0x0;
        }
        puStack_1c = (undefined *)CONCAT31(puStack_1c._1_3_,*(undefined *)piVar8);
        uStack_10c = CONCAT44(puStack_1c,0xc2d04a);
        FUN_008927d0();
        piVar8 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_14[1] + -1;
          piStack_14[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_10c = CONCAT44(0xc2d063,(undefined4)uStack_10c);
            (**(code **)*piStack_14)();
            LOCK();
            piVar12 = piVar8 + 2;
            iVar1 = *piVar12;
            *piVar12 = *piVar12 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              uStack_10c = CONCAT44(0xc2d072,(undefined4)uStack_10c);
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        goto LAB_00c2d0b6;
      }
    }
    else {
      puVar6 = *(undefined4 **)(*(int *)(pbVar9 + 0x14) + (int)puStack_18 * 4);
      if (puVar6 == (undefined4 *)0x0) {
        piVar12 = (int *)0x0;
      }
      else {
        piVar12 = (int *)*puVar6;
      }
      if (piVar12 != (int *)0x0) {
        do {
          piVar8 = piStack_14;
          if (uStack_20 == piVar12[1]) {
            pbVar9 = (byte *)(piVar12 + 2);
            if (0xf < (uint)piVar12[7]) {
              pbVar9 = *(byte **)pbVar9;
            }
            pbVar10 = (byte *)&DAT_01d685b4;
            if (0xf < DAT_01d685c8) {
              pbVar10 = DAT_01d685b4;
            }
            uVar7 = DAT_01d685c4;
            if (DAT_01d685c4 == piVar12[6]) {
              while (uVar11 = uVar7 - 4, 3 < uVar7) {
                if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_00c2cf4b;
                pbVar10 = pbVar10 + 4;
                pbVar9 = pbVar9 + 4;
                uVar7 = uVar11;
              }
              if (uVar11 == 0xfffffffc) {
LAB_00c2cf7f:
                uVar7 = 0;
              }
              else {
LAB_00c2cf4b:
                bVar13 = *pbVar10 < *pbVar9;
                if ((*pbVar10 == *pbVar9) &&
                   ((uVar11 == 0xfffffffd ||
                    ((bVar13 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
                     ((uVar11 == 0xfffffffe ||
                      ((bVar13 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                       ((uVar11 == 0xffffffff ||
                        (bVar13 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3]))))))))))))
                goto LAB_00c2cf7f;
                uVar7 = -(uint)bVar13 | 1;
              }
              if (uVar7 == 0) break;
            }
          }
          else if ((undefined *)((uint)piVar12[1] % uStack_24) != puStack_18) goto LAB_00c2cfbe;
          piVar12 = (int *)*piVar12;
        } while (piVar12 != (int *)0x0);
        goto LAB_00c2cf9b;
      }
    }
LAB_00c2cfbe:
    puStack_18 = (undefined *)auStack_124;
    FUN_0054f510(&stack0x0000003c);
    uStack_8._0_1_ = 6;
    uVar14 = 0;
    FUN_005542c0("Invalid response received from Chat webserver",0x2d);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_00c2ccb0(uVar14);
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar1 = piVar8[1] + -1;
      piVar8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_10c = CONCAT44(0xc2d017,(undefined4)uStack_10c);
        (**(code **)*piVar8)();
        LOCK();
        piVar12 = piVar8 + 2;
        iVar1 = *piVar12;
        *piVar12 = *piVar12 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          uStack_10c = CONCAT44(0xc2d026,(undefined4)uStack_10c);
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
  }
  if (iStack_f8 != 0) {
    uStack_10c = CONCAT44(auStack_f4,0xc2d0d0);
    (**(code **)(iStack_f8 + 8))();
  }
LAB_00c2d0d3:
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar11 = in_stack_00000018 + 1;
    uVar7 = param_1;
    if (0xfff < uVar11) {
      uVar7 = *(uint *)(param_1 - 4);
      uVar11 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar7) - 4) {
        uStack_10c = CONCAT44(&UNK_00c2d19a,(undefined4)uStack_10c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_10c = CONCAT44(uVar11,uVar7);
    puStack_110 = (undefined4 *)0xc2d108;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      puStack_110 = (undefined4 *)&stack0x00000024;
      uStack_10c = CONCAT44(2,puStack_110);
      uStack_114 = 0xc2d13e;
      (**(code **)(in_stack_0000001c & 0xfffffffe))();
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    puStack_110 = &stack0x00000044;
    uStack_10c = CONCAT44(2,puStack_110);
    uStack_114 = 0xc2d16c;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27775 ; VA 0x00c2d1a0 ; FUN_00c2d1a0 */

int __thiscall FUN_00c2d1a0(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int iStack_104;
  int *piStack_100;
  undefined *puStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807f11;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  if (param_2 != 0) {
    iVar4 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00913630();
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      iVar4 = FUN_008f7870(param_1);
      if (iVar4 == 0) {
        FUN_016756b0(&uStack_20,"SocialService:PromptGameInvite SocialService is not initialized.");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(&uStack_20,&DAT_01c17198);
      }
      if ((*(int *)(iVar4 + 0x4a0) == 1) || (cStack_11 = '\0', *(int *)(iVar4 + 0x4a0) == 3)) {
        cStack_11 = '\x01';
      }
      iVar4 = FUN_0064e810(param_1);
      if (iVar4 == 0) {
LAB_00c2d24a:
        if (cStack_11 != '\0') {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          iVar4 = FUN_00925d30(param_1,param_2,param_3);
          goto LAB_00c2d377;
        }
      }
      else if (cStack_11 != '\0') {
        if (param_2 != *(int *)(iVar4 + 0xf4)) {
          pcVar5 = 
          "SocialService:PromptGameInvite called from a local script, but not called on a local player. Local scripts can only prompt the local player."
          ;
          goto LAB_00c2d3dc;
        }
        goto LAB_00c2d24a;
      }
      FUN_00676bf0(param_2);
      FUN_00927d30(auStack_2c);
      puStack_3c = auStack_2c;
      uStack_38 = 0;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_24 = param_3;
      iStack_34 = param_2;
      piStack_30 = param_3;
      uStack_8._0_1_ = 1;
      pcVar2 = *(code **)(*param_1 + 8);
      uStack_10c = FUN_0088cdc0();
      uStack_108 = 0;
      iStack_104 = param_2;
      piStack_100 = piStack_24;
      iStack_34 = 0;
      piStack_30 = (int *)0x0;
      uStack_108 = FUN_006309e0();
      uStack_8._0_1_ = 2;
      uStack_20 = 0;
      uStack_1c = 0;
      uStack_18 = 0;
      FUN_00687980(&uStack_10c,&puStack_3c,param_3);
      uStack_8._0_1_ = 3;
      (*pcVar2)(&DAT_02134360,&uStack_20,&puStack_3c);
      uStack_8._0_1_ = 4;
      FUN_00577b20();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar4 = FUN_016f32d1(&uStack_10c,0xd0,1,FUN_0056e5b0);
LAB_00c2d377:
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar1 = param_3 + 1;
        iVar3 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar4 = (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            iVar4 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar4;
    }
  }
  pcVar5 = "SocialService:PromptGameInvite argument 1 should be a Player object";
LAB_00c2d3dc:
  FUN_00550130(pcVar5);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(&uStack_20,&DAT_01c17198);
}



/* FUNCTION 27776 ; VA 0x00c2d400 ; FUN_00c2d400 */

int * __thiscall
FUN_00c2d400(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0deb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2d600();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::StudioData,__int64>::
              GetSetImpl<__int64_(__thiscall_RBX::StudioData::*)(void)const_,void_(__thiscall_RBX::StudioData::*)(__int64)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088da50();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StudioData,__int64>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StudioData,__int64>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27777 ; VA 0x00c2d500 ; FUN_00c2d500 */

int * __thiscall
FUN_00c2d500(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2d600();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::StudioData,bool>::
              GetSetImpl<bool_(__thiscall_RBX::StudioData::*)(void)const_,void_(__thiscall_RBX::StudioData::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StudioData,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StudioData,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27778 ; VA 0x00c2d600 ; FUN_00c2d600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c2d600(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807f40;
  pvStack_10 = ExceptionList;
  if (DAT_01ef9e48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa060) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efa060);
      if (DAT_01efa060 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StudioData",1,uStack_20,0,0,0xb,5,0);
        _DAT_01efa058 = RBX::Creator<class_RBX::StudioData>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef9e50,&DAT_01efa058);
        FUN_016f3654(FUN_01893bb0);
        FUN_016f37bf(&DAT_01efa060);
      }
    }
    DAT_01ef9e48 = &DAT_01ef9e50;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef9e48;
}



/* FUNCTION 27779 ; VA 0x00c2d700 ; FUN_00c2d700 */

void FUN_00c2d700(void)

{
  int iVar1;
  
  if (DAT_01efa064 == 0) {
    iVar1 = FUN_00c2d600();
    DAT_01efa064 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27780 ; VA 0x00c2d720 ; FUN_00c2d720 */

undefined4 * __fastcall FUN_00c2d720(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018042a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650("StudioData");
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::StudioData,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00c2d600();
  param_1[3] = uVar1;
  *param_1 = RBX::StudioData::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  *(undefined2 *)(param_1 + 0x1a) = 0x100;
  param_1[0x20] = 0;
  param_1[0x21] = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  param_1[0x22] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  if (DAT_01d685d0 != '\0') {
    *(undefined *)((int)param_1 + 0x69) = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27781 ; VA 0x00c2d7e0 ; FUN_00c2d7e0 */

void __fastcall FUN_00c2d7e0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::StudioData>::vftable;
  uVar1 = FUN_00c2d600(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27782 ; VA 0x00c2d820 ; FUN_00c2d820 */

undefined4 * __thiscall FUN_00c2d820(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::StudioData::vftable;
  uVar1 = param_1[0x21];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1c];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x20] = 0;
  param_1[0x21] = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  return param_1;
}



/* FUNCTION 27783 ; VA 0x00c2d8a0 ; FUN_00c2d8a0 */

void __thiscall FUN_00c2d8a0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x68) != param_2) {
    *(char *)(param_1 + 0x68) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27784 ; VA 0x00c2d8c0 ; FUN_00c2d8c0 */

undefined4 * FUN_00c2d8c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006747b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27785 ; VA 0x00c2d950 ; FUN_00c2d950 */

uint FUN_00c2d950(void)

{
  int iVar1;
  
  iVar1 = FUN_00c2d600();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27786 ; VA 0x00c2d970 ; FUN_00c2d970 */

uint FUN_00c2d970(void)

{
  int iVar1;
  
  iVar1 = FUN_00c2d600();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27787 ; VA 0x00c2d990 ; FUN_00c2d990 */

void __thiscall FUN_00c2d990(int param_1,int param_2,int param_3)

{
  if ((*(int *)(param_1 + 0x90) != param_2) || (*(int *)(param_1 + 0x94) != param_3)) {
    *(int *)(param_1 + 0x90) = param_2;
    *(int *)(param_1 + 0x94) = param_3;
    FUN_008a4940(&DAT_02134584);
  }
  return;
}



/* FUNCTION 27788 ; VA 0x00c2d9d0 ; FUN_00c2d9d0 */

void __thiscall
FUN_00c2d9d0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint param_7)

{
  uint *puVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar1 = (uint *)(param_1 + 0x70);
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00558b30(puVar1,&param_2);
  if (cVar2 == '\0') {
    if (puVar1 != &param_2) {
      FUN_005507b0();
      uVar3 = param_2;
      param_2 = param_2 & 0xffffff00;
      *puVar1 = uVar3;
      *(undefined4 *)(param_1 + 0x74) = param_3;
      *(undefined4 *)(param_1 + 0x78) = param_4;
      *(undefined4 *)(param_1 + 0x7c) = param_5;
      *(ulonglong *)(param_1 + 0x80) = CONCAT44(param_7,param_6);
      param_6 = 0;
      param_7 = 0xf;
    }
    FUN_008a4940(&DAT_0213454c);
  }
  if (0xf < param_7) {
    uVar4 = param_7 + 1;
    uVar3 = param_2;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(param_2 - 4);
      uVar4 = param_7 + 0x24;
      if (0x1f < (param_2 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27789 ; VA 0x00c2da90 ; FUN_00c2da90 */

void __thiscall FUN_00c2da90(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x88) != param_2) {
    *(int *)(param_1 + 0x88) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27790 ; VA 0x00c2dac0 ; FUN_00c2dac0 */

void __thiscall FUN_00c2dac0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x69) != param_2) {
    *(char *)(param_1 + 0x69) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27791 ; VA 0x00c2dae0 ; FUN_00c2dae0 */

void __thiscall FUN_00c2dae0(int param_1,int param_2,int param_3)

{
  if ((param_2 != *(int *)(param_1 + 0x58)) || (param_3 != *(int *)(param_1 + 0x5c))) {
    *(int *)(param_1 + 0x58) = param_2;
    *(int *)(param_1 + 0x5c) = param_3;
    FUN_008a4940(&DAT_0213446c);
  }
  return;
}



/* FUNCTION 27792 ; VA 0x00c2db10 ; FUN_00c2db10 */

void __thiscall FUN_00c2db10(int param_1,int param_2,int param_3)

{
  if ((param_2 != *(int *)(param_1 + 0x60)) || (param_3 != *(int *)(param_1 + 100))) {
    *(int *)(param_1 + 0x60) = param_2;
    *(int *)(param_1 + 100) = param_3;
    FUN_008a4940(&DAT_021344a4);
  }
  return;
}



/* FUNCTION 27793 ; VA 0x00c2db40 ; FUN_00c2db40 */

int * __thiscall FUN_00c2db40(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807fb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_00575b30();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00c2dee0(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27794 ; VA 0x00c2dbfe ; Catch_All@00c2dbfe */

void Catch_All_00c2dbfe(void)

{
  FUN_00c2f250();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27795 ; VA 0x00c2dc10 ; FUN_00c2dc10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c2dc10(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807ff0;
  pvStack_10 = ExceptionList;
  if (DAT_01efa078 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa290) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efa290);
      if (DAT_01efa290 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"UnvalidatedAssetService",1,uStack_20,0,0,0xb,5,0);
        _DAT_01efa288 = RBX::Creator<class_RBX::UnvalidatedAssetService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efa080,&DAT_01efa288);
        FUN_016f3654(FUN_01893d70);
        FUN_016f37bf(&DAT_01efa290);
      }
    }
    DAT_01efa078 = &DAT_01efa080;
  }
  ExceptionList = pvStack_10;
  return DAT_01efa078;
}



/* FUNCTION 27796 ; VA 0x00c2dd10 ; FUN_00c2dd10 */

void FUN_00c2dd10(void)

{
  int iVar1;
  
  if (DAT_01efa294 == 0) {
    iVar1 = FUN_00c2dc10();
    DAT_01efa294 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27797 ; VA 0x00c2dd30 ; FUN_00c2dd30 */

int FUN_00c2dd30(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808000;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575be0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  *(undefined4 *)(iVar1 + 0x18) = param_1[2];
  FUN_00c2ea10(param_1 + 3);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 27798 ; VA 0x00c2dda0 ; Catch_All@00c2dda0 */

void Catch_All_00c2dda0(void)

{
  int unaff_EBP;
  
  FUN_00576e50(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27799 ; VA 0x00c2ddc0 ; FUN_00c2ddc0 */

int FUN_00c2ddc0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009707a0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  uVar2 = FUN_00575b30();
  *(undefined4 *)(iVar1 + 0x18) = uVar2;
  *(undefined4 *)(iVar1 + 0x18) = param_1[2];
  param_1[2] = uVar2;
  uVar2 = *(undefined4 *)(iVar1 + 0x1c);
  *(undefined4 *)(iVar1 + 0x1c) = param_1[3];
  param_1[3] = uVar2;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 27800 ; VA 0x00c2de4c ; Catch_All@00c2de4c */

void Catch_All_00c2de4c(void)

{
  int unaff_EBP;
  
  FUN_00970b90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27801 ; VA 0x00c2de70 ; FUN_00c2de70 */

int FUN_00c2de70(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_00575be0();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  *(undefined4 *)(iVar1 + 0x18) = param_1[2];
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  *(undefined4 *)(iVar1 + 0x20) = 0;
  *(undefined4 *)(iVar1 + 0x24) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = param_1[3];
  *(undefined4 *)(iVar1 + 0x20) = param_1[4];
  *(undefined4 *)(iVar1 + 0x24) = param_1[5];
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  return iVar1;
}



/* FUNCTION 27802 ; VA 0x00c2dee0 ; FUN_00c2dee0 */

undefined4 * __thiscall
FUN_00c2dee0(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808020;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_00c2dd30(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_00c2dee0(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_00c2dee0(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 27803 ; VA 0x00c2df74 ; Catch_All@00c2df74 */

void Catch_All_00c2df74(void)

{
  int unaff_EBP;
  
  FUN_00c2f1c0(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27804 ; VA 0x00c2df90 ; FUN_00c2df90 */

int __thiscall
FUN_00c2df90(int *param_1,undefined4 *param_2,undefined8 *param_3,undefined8 *param_4,
            undefined4 *param_5)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined8 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined4 *puVar14;
  uint uVar15;
  uint uVar16;
  undefined4 *puVar17;
  
  iVar7 = (int)param_2 - *param_1 >> 5;
  iVar8 = param_1[1] - *param_1 >> 5;
  if (iVar8 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar15 = iVar8 + 1;
  uVar16 = param_1[2] - *param_1 >> 5;
  uVar9 = uVar15;
  if ((uVar16 <= 0x7ffffff - (uVar16 >> 1)) && (uVar9 = (uVar16 >> 1) + uVar16, uVar9 < uVar15)) {
    uVar9 = uVar15;
  }
  puVar10 = (undefined4 *)FUN_00577f40(uVar9);
  puVar11 = (undefined8 *)(puVar10 + iVar7 * 8);
  uVar1 = *param_4;
  uVar2 = *param_5;
  uVar3 = param_5[1];
  uVar4 = *(undefined4 *)(param_4 + 1);
  uVar5 = *(undefined4 *)(param_3 + 1);
  *puVar11 = *param_3;
  *(undefined4 *)(puVar11 + 1) = uVar5;
  *(undefined4 *)((int)puVar11 + 0x1c) = uVar3;
  *(undefined8 *)((int)puVar11 + 0xc) = uVar1;
  *(undefined4 *)((int)puVar11 + 0x14) = uVar4;
  *(undefined4 *)(puVar11 + 3) = uVar2;
  puVar17 = (undefined4 *)param_1[1];
  puVar12 = (undefined4 *)*param_1;
  puVar14 = puVar10;
  if (param_2 == puVar17) {
    for (; puVar12 != puVar17; puVar12 = puVar12 + 8) {
      uVar2 = puVar12[1];
      uVar3 = puVar12[2];
      uVar4 = puVar12[3];
      *puVar14 = *puVar12;
      puVar14[1] = uVar2;
      puVar14[2] = uVar3;
      puVar14[3] = uVar4;
      uVar2 = puVar12[5];
      uVar3 = puVar12[6];
      uVar4 = puVar12[7];
      puVar14[4] = puVar12[4];
      puVar14[5] = uVar2;
      puVar14[6] = uVar3;
      puVar14[7] = uVar4;
      puVar14 = puVar14 + 8;
    }
  }
  else {
    if (puVar12 != param_2) {
      do {
        uVar2 = puVar12[1];
        uVar3 = puVar12[2];
        uVar4 = puVar12[3];
        *puVar14 = *puVar12;
        puVar14[1] = uVar2;
        puVar14[2] = uVar3;
        puVar14[3] = uVar4;
        puVar17 = puVar12 + 4;
        uVar2 = puVar12[5];
        uVar3 = puVar12[6];
        uVar4 = puVar12[7];
        puVar12 = puVar12 + 8;
        puVar14[4] = *puVar17;
        puVar14[5] = uVar2;
        puVar14[6] = uVar3;
        puVar14[7] = uVar4;
        puVar14 = puVar14 + 8;
      } while (puVar12 != param_2);
      puVar17 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar17) {
      do {
        uVar2 = param_2[1];
        uVar3 = param_2[2];
        uVar4 = param_2[3];
        *(undefined4 *)(puVar11 + 4) = *param_2;
        *(undefined4 *)((int)puVar11 + 0x24) = uVar2;
        *(undefined4 *)(puVar11 + 5) = uVar3;
        *(undefined4 *)((int)puVar11 + 0x2c) = uVar4;
        puVar12 = param_2 + 4;
        uVar2 = param_2[5];
        uVar3 = param_2[6];
        uVar4 = param_2[7];
        param_2 = param_2 + 8;
        *(undefined4 *)(puVar11 + 6) = *puVar12;
        *(undefined4 *)((int)puVar11 + 0x34) = uVar2;
        *(undefined4 *)(puVar11 + 7) = uVar3;
        *(undefined4 *)((int)puVar11 + 0x3c) = uVar4;
        puVar11 = puVar11 + 4;
      } while (param_2 != puVar17);
    }
  }
  iVar6 = *param_1;
  if (iVar6 != 0) {
    uVar15 = param_1[2] - iVar6 & 0xffffffe0;
    iVar13 = iVar6;
    if (0xfff < uVar15) {
      iVar13 = *(int *)(iVar6 + -4);
      uVar15 = uVar15 + 0x23;
      if (0x1f < (iVar6 - iVar13) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar15);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + (iVar8 + 1) * 8);
  param_1[2] = (int)(puVar10 + uVar9 * 8);
  return *param_1 + iVar7 * 0x20;
}



/* FUNCTION 27805 ; VA 0x00c2e130 ; FUN_00c2e130 */

void __thiscall
FUN_00c2e130(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x7fffffd < (uint)param_1[1]) {
    FUN_00c2f060(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00c2e1e2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00c2e1e2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 27806 ; VA 0x00c2e290 ; FUN_00c2e290 */

void __thiscall
FUN_00c2e290(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x6666664 < (uint)param_1[1]) {
    FUN_00c2f0e0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00c2e342:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00c2e342;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 27807 ; VA 0x00c2e3f0 ; FUN_00c2e3f0 */

undefined4 * __thiscall
FUN_00c2e3f0(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_24 [8];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808030;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_00c2e130(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar4 = (int *)*param_1;
  if (param_3 == (int *)*piVar4) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if (((int)param_4[1] <= param_3[5]) &&
       (((int)param_4[1] < param_3[5] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, *param_4 < (uint)param_3[4]))))
    {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_00c2e130(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar4) {
    iVar1 = piVar4[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if ((*(int *)(iVar1 + 0x14) <= (int)param_4[1]) &&
       ((*(int *)(iVar1 + 0x14) < (int)param_4[1] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(uint *)(iVar1 + 0x10) < *param_4)))) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_00c2e130(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar2 = &stack0xffffffd0;
    if (((int)param_4[1] <= param_3[5]) &&
       (((int)param_4[1] < param_3[5] ||
        (ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, *param_4 < (uint)param_3[4])))) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_0056f560();
      cVar3 = FUN_0096e550(*piVar4 + 0x10,param_4);
      puVar2 = puStack_14;
      if (cVar3 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00c2e130(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00c2e130(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    puStack_14 = puVar2;
    cVar3 = FUN_0096e550(param_3 + 4,param_4);
    if (cVar3 != '\0') {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      piVar4 = piStack_18;
      if ((*piVar5 == *param_1) || (cVar3 = FUN_0096e550(param_4,piStack_18 + 4), cVar3 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00c2e130(param_2,1,piVar4,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00c2e130(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00c2e640(auStack_24,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27808 ; VA 0x00c2e625 ; Catch_All@00c2e625 */

void Catch_All_00c2e625(void)

{
  int unaff_EBP;
  
  FUN_00c2f060(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27809 ; VA 0x00c2e640 ; FUN_00c2e640 */

void __thiscall
FUN_00c2e640(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808040;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  cVar4 = '\x01';
  piVar2 = (int *)*param_1;
  piVar5 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    uVar1 = param_4[1];
    piVar2 = (int *)piVar2[1];
    do {
      piVar5 = piVar2;
      if (param_3 == '\0') {
        if ((piVar5[5] < (int)uVar1) || ((piVar5[5] <= (int)uVar1 && ((uint)piVar5[4] <= *param_4)))
           ) {
          cVar4 = '\0';
          goto LAB_00c2e6cd;
        }
        piVar2 = (int *)*piVar5;
        cVar4 = '\x01';
      }
      else {
        if (((int)uVar1 < piVar5[5]) || (((int)uVar1 <= piVar5[5] && (*param_4 <= (uint)piVar5[4])))
           ) {
          cVar4 = '\x01';
        }
        else {
          cVar4 = '\0';
        }
        if (cVar4 == '\0') {
LAB_00c2e6cd:
          piVar2 = (int *)piVar5[2];
        }
        else {
          piVar2 = (int *)*piVar5;
        }
      }
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    piVar2 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar5;
  if (cVar4 != '\0') {
    if (piVar5 == (int *)*piVar2) {
      cVar4 = '\x01';
      ExceptionList = &pvStack_10;
      goto LAB_00c2e6ee;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  piVar2 = _param_3;
  if (((int)param_4[1] < _param_3[5]) ||
     (((int)param_4[1] <= _param_3[5] && (*param_4 <= (uint)_param_3[4])))) {
    FUN_00c2f060(param_5);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00c2e6ee:
  puVar3 = (undefined4 *)FUN_00c2e130(&param_3,cVar4,piVar5,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27810 ; VA 0x00c2e766 ; Catch_All@00c2e766 */

void Catch_All_00c2e766(void)

{
  int unaff_EBP;
  
  FUN_00c2f060(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27811 ; VA 0x00c2e780 ; FUN_00c2e780 */

void __thiscall
FUN_00c2e780(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,int param_5)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  char cVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = param_5;
  puStack_c = &LAB_01808050;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  cVar8 = '\x01';
  piVar2 = (int *)*param_1;
  piVar9 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    uVar3 = param_4[1];
    piVar6 = (int *)piVar2[1];
    do {
      piVar9 = piVar6;
      if (param_3 == '\0') {
        if ((piVar9[5] < (int)uVar3) || ((piVar9[5] <= (int)uVar3 && ((uint)piVar9[4] <= *param_4)))
           ) {
          cVar8 = '\0';
          goto LAB_00c2e80d;
        }
        piVar6 = (int *)*piVar9;
        cVar8 = '\x01';
      }
      else {
        if (((int)uVar3 < piVar9[5]) || (((int)uVar3 <= piVar9[5] && (*param_4 <= (uint)piVar9[4])))
           ) {
          cVar8 = '\x01';
        }
        else {
          cVar8 = '\0';
        }
        if (cVar8 == '\0') {
LAB_00c2e80d:
          piVar6 = (int *)piVar9[2];
        }
        else {
          piVar6 = (int *)*piVar9;
        }
      }
    } while (*(char *)((int)piVar6 + 0xd) == '\0');
  }
  piVar6 = piVar9;
  if (cVar8 != '\0') {
    if (piVar9 == (int *)*piVar2) {
      cVar8 = '\x01';
      goto LAB_00c2e833;
    }
    if (*(char *)((int)piVar9 + 0xd) == '\0') {
      piVar6 = (int *)*piVar9;
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar6[2] + 0xd);
        piVar2 = (int *)piVar6[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar6 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar9[1] + 0xd);
        piVar2 = (int *)piVar9[1];
        piVar6 = piVar9;
        while ((piVar4 = piVar2, cVar1 == '\0' && (piVar6 == (int *)*piVar4))) {
          cVar1 = *(char *)(piVar4[1] + 0xd);
          piVar2 = (int *)piVar4[1];
          piVar6 = piVar4;
        }
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          piVar6 = piVar4;
        }
      }
    }
    else {
      piVar6 = (int *)piVar9[2];
    }
  }
  if (((int)param_4[1] < piVar6[5]) ||
     (((int)param_4[1] <= piVar6[5] && (*param_4 <= (uint)piVar6[4])))) {
    ExceptionList = &pvStack_10;
    FUN_00c2e930(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar5,0x28);
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00c2e833:
  ExceptionList = &pvStack_10;
  puVar7 = (undefined4 *)FUN_00c2e290(&param_3,cVar8,piVar9,param_4,param_5);
  *param_2 = *puVar7;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27812 ; VA 0x00c2e910 ; Catch_All@00c2e910 */

void Catch_All_00c2e910(void)

{
  int unaff_EBP;
  
  FUN_00c2f0e0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27813 ; VA 0x00c2e930 ; FUN_00c2e930 */

void FUN_00c2e930(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_2 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_2 + 0x14) - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_2 + 0xc) = 0;
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 27814 ; VA 0x00c2e990 ; FUN_00c2e990 */

void __thiscall
FUN_00c2e990(int param_1,undefined8 *param_2,undefined8 *param_3,undefined4 *param_4)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  puVar2 = *(undefined8 **)(param_1 + 4);
  if (*(undefined8 **)(param_1 + 8) != puVar2) {
    uVar3 = param_4[1];
    uVar4 = *param_4;
    uVar5 = *(undefined4 *)(param_3 + 1);
    uVar1 = *param_3;
    uVar6 = *(undefined4 *)(param_2 + 1);
    *puVar2 = *param_2;
    *(undefined4 *)(puVar2 + 1) = uVar6;
    *(undefined8 *)((int)puVar2 + 0xc) = uVar1;
    *(undefined4 *)((int)puVar2 + 0x14) = uVar5;
    *(undefined4 *)((int)puVar2 + 0x1c) = uVar3;
    *(undefined4 *)(puVar2 + 3) = uVar4;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    return;
  }
  FUN_00c2df90(puVar2,param_2,param_3,param_4);
  return;
}



/* FUNCTION 27815 ; VA 0x00c2ea10 ; FUN_00c2ea10 */

int * __thiscall FUN_00c2ea10(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  uint uVar8;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar8 = param_2[1] - *param_2 >> 5;
  if (uVar8 != 0) {
    if (0x7ffffff < uVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar5 = FUN_00577f40(uVar8);
    *param_1 = iVar5;
    param_1[1] = iVar5;
    param_1[2] = uVar8 * 0x20 + *param_1;
    puVar1 = (undefined4 *)param_2[1];
    puVar7 = (undefined4 *)*param_1;
    for (puVar6 = (undefined4 *)*param_2; puVar6 != puVar1; puVar6 = puVar6 + 8) {
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      *puVar7 = *puVar6;
      puVar7[1] = uVar2;
      puVar7[2] = uVar3;
      puVar7[3] = uVar4;
      uVar2 = puVar6[5];
      uVar3 = puVar6[6];
      uVar4 = puVar6[7];
      puVar7[4] = puVar6[4];
      puVar7[5] = uVar2;
      puVar7[6] = uVar3;
      puVar7[7] = uVar4;
      puVar7 = puVar7 + 8;
    }
    param_1[1] = (int)puVar7;
  }
  return param_1;
}



/* FUNCTION 27816 ; VA 0x00c2ea90 ; FUN_00c2ea90 */

undefined4 * __fastcall FUN_00c2ea90(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180807b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650("UnvalidatedAssetService");
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::UnvalidatedAssetService,class_RBX::ServiceInstance>
             ::vftable;
  uVar1 = FUN_00c2dc10();
  param_1[3] = uVar1;
  *param_1 = RBX::UnvalidatedAssetService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  uStack_8 = 1;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uVar1 = FUN_00575ab0();
  param_1[0x1c] = uVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  uVar1 = FUN_00575ab0();
  param_1[0x1e] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27817 ; VA 0x00c2eb60 ; FUN_00c2eb60 */

void __fastcall FUN_00c2eb60(int param_1)

{
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),0xc);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 27818 ; VA 0x00c2ebc0 ; FUN_00c2ebc0 */

void __fastcall FUN_00c2ebc0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::UnvalidatedAssetService>::vftable;
  uVar1 = FUN_00c2dc10(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27819 ; VA 0x00c2ec00 ; FUN_00c2ec00 */

void __fastcall FUN_00c2ec00(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c2f110(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27820 ; VA 0x00c2ec60 ; FUN_00c2ec60 */

void __fastcall FUN_00c2ec60(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c2f1c0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x28);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27821 ; VA 0x00c2ecc0 ; FUN_00c2ecc0 */

void __fastcall FUN_00c2ecc0(int param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 8);
  piVar1 = (int *)(param_1 + 8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c2f1c0(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  *(undefined4 *)(param_1 + 0xc) = 0;
  FUN_01674ea0(*piVar1,0x28);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27822 ; VA 0x00c2ed30 ; FUN_00c2ed30 */

void __fastcall FUN_00c2ed30(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 27823 ; VA 0x00c2ed90 ; FUN_00c2ed90 */

void __fastcall FUN_00c2ed90(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 27824 ; VA 0x00c2edf0 ; FUN_00c2edf0 */

uint * __thiscall FUN_00c2edf0(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint *puStack_8;
  
  puVar1 = (undefined4 *)*param_1;
  puVar6 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    uVar2 = param_2[1];
    puVar3 = (undefined4 *)puVar1[1];
    do {
      if (((int)uVar2 < (int)puVar3[5]) ||
         (((int)uVar2 <= (int)puVar3[5] && (*param_2 <= (uint)puVar3[4])))) {
        puVar4 = (undefined4 *)*puVar3;
        puVar6 = puVar3;
      }
      else {
        puVar4 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if (((puVar6 != puVar1) && ((int)puVar6[5] <= (int)uVar2)) &&
       (((int)puVar6[5] < (int)uVar2 || ((uint)puVar6[4] <= *param_2)))) {
      return puVar6 + 6;
    }
  }
  puStack_8 = param_2;
  iVar5 = FUN_009617c0(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_00c2e3f0(&param_2,puVar6,iVar5 + 0x10,iVar5);
  return param_2 + 6;
}



/* FUNCTION 27825 ; VA 0x00c2ee90 ; FUN_00c2ee90 */

undefined4 __thiscall FUN_00c2ee90(undefined4 param_1,byte param_2)

{
  FUN_00c2eb60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 27826 ; VA 0x00c2eec0 ; FUN_00c2eec0 */

int __thiscall FUN_00c2eec0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 27827 ; VA 0x00c2ef20 ; FUN_00c2ef20 */

int __thiscall FUN_00c2ef20(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),0xc);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 27828 ; VA 0x00c2ef90 ; FUN_00c2ef90 */

undefined4 * __thiscall FUN_00c2ef90(undefined4 *param_1,byte param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::UnvalidatedAssetService::vftable;
  iVar1 = param_1[0x1e];
  uStack_8 = 0;
  FUN_00c2f110(*(undefined4 *)(iVar1 + 4));
  *(int *)(param_1[0x1e] + 4) = iVar1;
  *(int *)param_1[0x1e] = iVar1;
  *(int *)(param_1[0x1e] + 8) = iVar1;
  param_1[0x1f] = 0;
  FUN_01674ea0(param_1[0x1e],0x20);
  iVar1 = param_1[0x1c];
  uStack_8 = 2;
  FUN_00c2f110(*(undefined4 *)(iVar1 + 4));
  *(int *)(param_1[0x1c] + 4) = iVar1;
  *(int *)param_1[0x1c] = iVar1;
  *(int *)(param_1[0x1c] + 8) = iVar1;
  param_1[0x1d] = 0;
  FUN_0054db70(param_1[0x1c],0x20);
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27829 ; VA 0x00c2f060 ; FUN_00c2f060 */

void FUN_00c2f060(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c2f1c0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x18) + 4) = iVar1;
  **(int **)(param_1 + 0x18) = iVar1;
  *(int *)(*(int *)(param_1 + 0x18) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x18),0x28);
  FUN_01674ea0(param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27830 ; VA 0x00c2f0e0 ; FUN_00c2f0e0 */

void __thiscall FUN_00c2f0e0(undefined4 param_1,int param_2)

{
  FUN_00c2e930(param_1,param_2 + 0x10);
  FUN_01674ea0(param_2,0x28);
  return;
}



/* FUNCTION 27831 ; VA 0x00c2f110 ; FUN_00c2f110 */

undefined4 __thiscall FUN_00c2f110(undefined4 param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  void **ppvVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar2 = *(char *)((int)param_2 + 0xd);
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, cVar2 == '\0') {
    FUN_00c2f110(param_2[2]);
    piVar3 = (int *)*param_2;
    piVar1 = param_2 + 6;
    iVar4 = *piVar1;
    uStack_8 = 0;
    FUN_00c2f1c0(*(undefined4 *)(iVar4 + 4));
    uStack_8 = 0xffffffff;
    *(int *)(*piVar1 + 4) = iVar4;
    *(int *)*piVar1 = iVar4;
    *(int *)(*piVar1 + 8) = iVar4;
    param_2[7] = 0;
    FUN_01674ea0(*piVar1,0x28);
    FUN_01674ea0(param_2,0x20);
    ppvVar5 = (void **)ExceptionList;
    param_2 = piVar3;
    cVar2 = *(char *)((int)piVar3 + 0xd);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27832 ; VA 0x00c2f1c0 ; FUN_00c2f1c0 */

void FUN_00c2f1c0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00c2f1c0(param_1[2]);
    iVar2 = param_1[7];
    piVar3 = (int *)*param_1;
    if (iVar2 != 0) {
      uVar5 = param_1[9] - iVar2 & 0xffffffe0;
      iVar4 = iVar2;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar2 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
      param_1[7] = 0;
      param_1[8] = 0;
      param_1[9] = 0;
    }
    FUN_01674ea0(param_1,0x28);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 27833 ; VA 0x00c2f250 ; FUN_00c2f250 */

void __fastcall FUN_00c2f250(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c2f1c0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27834 ; VA 0x00c2f2b0 ; FUN_00c2f2b0 */

void FUN_00c2f2b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined8 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
                 undefined4 *param_9)

{
  undefined4 *puVar1;
  void **ppvVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = DAT_01efa06c;
  puStack_c = &LAB_018081c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar7 = DAT_01efa06c;
  puVar5 = (undefined4 *)DAT_01efa06c[1];
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  if (*(char *)((int)DAT_01efa06c[1] + 0xd) == '\0') {
    do {
      ExceptionList = ppvVar2;
      puVar8 = puVar5;
      piVar3 = puVar8 + 4;
      puVar5 = &param_9;
      if (0xf < in_stack_00000040) {
        puVar5 = param_9;
      }
      if (0xf < (uint)puVar8[9]) {
        piVar3 = (int *)*piVar3;
      }
      iVar4 = FUN_0055c2d0(piVar3,puVar8[8],puVar5,in_stack_0000003c);
      if (iVar4 < 0) {
        puVar5 = (undefined4 *)puVar8[2];
        puVar8 = puVar7;
      }
      else {
        puVar5 = (undefined4 *)*puVar8;
      }
      puVar7 = puVar8;
      ppvVar2 = (void **)ExceptionList;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if (puVar8 != puVar1) {
      piVar3 = puVar8 + 4;
      if (0xf < (uint)puVar8[9]) {
        piVar3 = (int *)*piVar3;
      }
      puVar5 = &param_9;
      if (0xf < in_stack_00000040) {
        puVar5 = param_9;
      }
      iVar4 = FUN_0055c2d0(puVar5,in_stack_0000003c,piVar3,puVar8[8]);
      if (-1 < iVar4) goto LAB_00c2f35b;
    }
  }
  puVar8 = puVar1;
LAB_00c2f35b:
  if ((puVar8 == puVar1) || (puVar8[10] == 0)) {
    FUN_0086f2f0(2,"UnvalidatedAssetService::appendTempAssetId() : Unrecognized usage!");
  }
  else {
    FUN_00c2f400(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,puVar8[10]);
  }
  if (0xf < in_stack_00000040) {
    uVar6 = in_stack_00000040 + 1;
    puVar5 = param_9;
    if (0xfff < uVar6) {
      puVar5 = (undefined4 *)param_9[-1];
      uVar6 = in_stack_00000040 + 0x24;
      if (0x1f < (uint)((int)param_9 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27835 ; VA 0x00c2f400 ; FUN_00c2f400 */

void __thiscall
FUN_00c2f400(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined8 param_6,undefined4 param_7,undefined8 param_8,undefined4 param_9,
            undefined4 param_10)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018081f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00c31380((int)&uStack_18 + 4,&param_4);
  if (*piVar3 == *(int *)(param_1 + 0x70)) {
    FUN_00b47170(auStack_5c);
    uStack_18 = FUN_00b45b30();
    uStack_28 = param_9;
    uStack_30 = param_8;
    uStack_1c = param_7;
    uStack_24 = param_6;
    uStack_4c = param_10;
    uStack_48 = 0;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_8 = 0;
    FUN_00c2e990(&uStack_30,&uStack_24,&uStack_18);
    uStack_8 = 1;
    FUN_00c2edf0(&param_2);
    uStack_3c = param_4;
    uStack_38 = param_5;
    uStack_34 = uStack_4c;
    FUN_00c2ea10(&uStack_48);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar4 = FUN_00c2de70(&uStack_3c);
    FUN_00c2e780(&param_4,0,iVar4 + 0x10,iVar4);
    FUN_00c2ed30();
    puVar1 = (uint *)(param_1 + 0x68);
    uVar2 = *puVar1;
    *puVar1 = *puVar1 + 1;
    *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + (uint)(0xfffffffe < uVar2);
    FUN_00c2ed90();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27836 ; VA 0x00c2f530 ; FUN_00c2f530 */

undefined4 __thiscall
FUN_00c2f530(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined8 param_6,undefined4 param_7,undefined8 param_8,undefined4 param_9)

{
  int *piVar1;
  int *piVar2;
  undefined auStack_30 [16];
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined8 uStack_14;
  undefined4 uStack_c;
  int *piStack_8;
  
  piVar2 = (int *)FUN_00c31380(&piStack_8,&param_2);
  piVar1 = *(int **)(param_1 + 0x70);
  if ((int *)*piVar2 != piVar1) {
    FUN_00c31380(&piStack_8,&param_2);
    if (piStack_8 != piVar1) {
      piVar1 = piStack_8 + 6;
      FUN_00c31380(&piStack_8,&param_4);
      piVar1 = (int *)*piVar1;
      if (piStack_8 != piVar1) {
        FUN_00c31380(&piStack_8,&param_4);
        if (piStack_8 == piVar1) {
          FUN_00c2f400(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0);
          return 1;
        }
        FUN_00b47170(auStack_30);
        _param_4 = FUN_00b45b30();
        uStack_18 = param_9;
        uStack_c = param_7;
        uStack_20 = param_8;
        uStack_14 = param_6;
        FUN_00c2e990();
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 27837 ; VA 0x00c2f650 ; FUN_00c2f650 */

undefined4 * FUN_00c2f650(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006750f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27838 ; VA 0x00c2f6c0 ; FUN_00c2f6c0 */

void __thiscall
FUN_00c2f6c0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [204];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808337;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c1470(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_00912980(*(int *)(param_1 + 0x48));
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    param_2 = (undefined4 *)FUN_00912980(*(int *)(param_1 + 0x4c));
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 0x40) != 0) {
    uVar4 = uVar4 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x50);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0x11;
    uVar4 = uVar4 | 0x200;
  }
  else {
    uStack_28c = FUN_0088cb40();
    iStack_288 = 0;
    FUN_0054ef60(iVar1);
    iStack_288 = FUN_005c9d30();
    puVar5 = &uStack_28c;
    uStack_8 = 0x10;
    uVar4 = uVar4 | 0x100;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 0x200) != 0) {
    uVar4 = uVar4 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x100) != 0) && (uStack_8 = 0x13, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27839 ; VA 0x00c2fb50 ; FUN_00c2fb50 */

void __thiscall FUN_00c2fb50(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [204];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6558;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c1470(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x48));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27840 ; VA 0x00c2fe00 ; FUN_00c2fe00 */

void __thiscall
FUN_00c2fe00(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [204];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e64a5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c1470(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_00912980(*(int *)(param_1 + 0x48));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    puVar4 = (undefined4 *)FUN_00912980(*(int *)(param_1 + 0x4c));
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27841 ; VA 0x00c30180 ; FUN_00c30180 */

void FUN_00c30180(char *param_1)

{
  undefined4 *puVar1;
  undefined uVar2;
  char cVar3;
  uint *puVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  char *pcVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  float10 fVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined auStack_298 [8];
  undefined auStack_290 [8];
  undefined auStack_288 [8];
  undefined auStack_280 [8];
  undefined auStack_278 [8];
  undefined auStack_270 [8];
  undefined auStack_268 [8];
  undefined auStack_260 [8];
  undefined auStack_258 [8];
  undefined auStack_250 [8];
  undefined auStack_248 [8];
  undefined auStack_240 [8];
  undefined auStack_238 [8];
  undefined auStack_230 [8];
  undefined auStack_228 [8];
  undefined auStack_220 [8];
  undefined auStack_218 [8];
  undefined auStack_210 [8];
  undefined auStack_208 [8];
  undefined auStack_200 [8];
  undefined auStack_1f8 [8];
  undefined auStack_1f0 [8];
  undefined auStack_1e8 [8];
  undefined8 uStack_1e0;
  float fStack_1d8;
  float fStack_1d4;
  float fStack_1d0;
  float fStack_1cc;
  undefined8 uStack_1c8;
  float fStack_1c0;
  float fStack_1bc;
  float fStack_1b8;
  float fStack_1b4;
  uint uStack_1ac;
  uint uStack_1a8;
  uint *puStack_1a4;
  uint uStack_1a0;
  undefined8 uStack_19c;
  undefined8 uStack_194;
  undefined auStack_18c [8];
  undefined auStack_184 [8];
  undefined auStack_17c [8];
  undefined auStack_174 [8];
  undefined auStack_16c [8];
  float fStack_164;
  float fStack_160;
  float fStack_15c;
  float fStack_158;
  float fStack_154;
  float fStack_150;
  float fStack_14c;
  float fStack_148;
  float fStack_144;
  float fStack_140;
  float fStack_13c;
  float fStack_138;
  undefined8 uStack_108;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  int iStack_f8;
  int iStack_f4;
  int iStack_ec;
  int iStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  int iStack_dc;
  int iStack_d8;
  int iStack_d4;
  undefined4 uStack_d0;
  int iStack_cc;
  uint uStack_c8;
  uint uStack_c0;
  uint auStack_ac [2];
  uint uStack_a4;
  uint uStack_a0;
  uint *puStack_9c;
  uint uStack_98;
  uint uStack_94;
  uint uStack_8c;
  uint uStack_88;
  undefined4 *puStack_84;
  uint uStack_80;
  undefined auStack_7c [12];
  double dStack_70;
  double dStack_68;
  undefined4 uStack_60;
  undefined auStack_45 [17];
  double dStack_34;
  int iStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018083d6;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffd5c;
  uVar11 = 0;
  uStack_18 = 0;
  pcVar8 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar8 = *(char **)param_1;
  }
  puStack_9c = (uint *)0x0;
  uStack_98 = 0xf;
  auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  pcVar7 = pcVar8;
  do {
    cVar3 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar3 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar8,(int)pcVar7 - (int)(pcVar8 + 1));
  uStack_8 = 0;
  FUN_016819e0(auStack_7c,auStack_ac);
  uStack_8._0_1_ = 2;
  if (0xf < uStack_98) {
    uVar9 = uStack_98 + 1;
    uVar10 = auStack_ac[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_ac[0] - 4);
      uVar9 = uStack_98 + 0x24;
      if (0x1f < (auStack_ac[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_19c = 0xf00000000;
  uStack_1ac = uStack_1ac & 0xffffff00;
  uStack_8._0_1_ = 4;
  cVar3 = FUN_016816d0();
  if (cVar3 == '\0') {
    cVar3 = FUN_01681870();
    if (cVar3 == '\0') {
      FUN_005542c0("PreModerationAsset parse - Not a JSON object",0x2c);
    }
    else {
      FUN_0167eea0(&dStack_34,"lastSaveTime");
      cVar3 = FUN_01681850();
      if (cVar3 != '\0') {
        FUN_0167eea0(&dStack_34,"lastSaveTime");
        uVar13 = FUN_0167e4f0();
        *(undefined8 *)(iStack_2c + 0x58) = uVar13;
      }
      FUN_0167eea0(&dStack_34,"lastKnownPublishRequest");
      cVar3 = FUN_01681850();
      if (cVar3 != '\0') {
        FUN_0167eea0(&dStack_34,"lastKnownPublishRequest");
        uVar13 = FUN_0167e4f0();
        *(undefined8 *)(iStack_2c + 0x60) = uVar13;
      }
      FUN_0167eea0(auStack_17c,"users");
      cVar3 = FUN_01681830();
      if (cVar3 != '\0') {
        FUN_016810c0();
        FUN_01680ea0();
        FUN_01681140();
        while( true ) {
          cVar3 = FUN_005e0cd0();
          if (cVar3 == '\0') break;
          FUN_0167efb0();
          FUN_0167eea0(auStack_248,"userId");
          uVar13 = FUN_0167e4f0();
          uStack_c8 = (uint)((ulonglong)uVar13 >> 0x20);
          uStack_c0 = (uint)uVar13;
          FUN_0167eea0(auStack_184,"assetIds");
          FUN_0167eea0(auStack_16c,"tempIds");
          puStack_20 = (undefined4 *)0x0;
          uStack_1c = 0;
          puStack_20 = (undefined4 *)FUN_00575b30();
          uStack_8._0_1_ = 6;
          puStack_28 = (undefined4 *)0x0;
          uStack_24 = 0;
          puStack_28 = (undefined4 *)FUN_00575b30();
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          cVar3 = FUN_01681830();
          if (cVar3 != '\0') {
            FUN_016810c0();
            FUN_01680ea0();
            FUN_01681140();
            while( true ) {
              cVar3 = FUN_005e0cd0();
              if (cVar3 == '\0') break;
              FUN_0167efb0();
              FUN_0167eea0(auStack_250,"assetUsage");
              iVar5 = FUN_0167e2d0();
              FUN_0167eea0(auStack_258,&DAT_018c1fd8);
              uVar13 = FUN_0167e4f0();
              uStack_60 = (undefined4)((ulonglong)uVar13 >> 0x20);
              FUN_0167eea0(auStack_18c,"useCase");
              cVar3 = FUN_01681830();
              uVar11 = uStack_18;
              if (cVar3 == '\0') {
LAB_00c30982:
                FUN_0167f070();
              }
              else {
                iStack_d4 = 0;
                uStack_d0 = 0;
                iStack_cc = 0;
                uStack_8 = CONCAT31(uStack_8._1_3_,8);
                iStack_d8 = iVar5;
                FUN_016810c0();
                FUN_01680ea0();
                FUN_01681140();
                while( true ) {
                  cVar3 = FUN_005e0cd0();
                  if (cVar3 == '\0') break;
                  FUN_0167efb0();
                  if (iVar5 == 2) {
                    cVar3 = FUN_01681830();
                    if (cVar3 != '\0') {
                      iVar6 = FUN_01681be0();
                      if (iVar6 == 7) {
                        FUN_01680e60(auStack_260,2);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_34 = (double)fVar12;
                        FUN_01680e60(auStack_268,1);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_68 = (double)fVar12;
                        FUN_01680e60(auStack_270,0);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_70 = (double)fVar12;
                        fStack_140 = (float)fVar12;
                        fStack_13c = (float)dStack_68;
                        fStack_138 = (float)dStack_34;
                        FUN_01680e60(auStack_278,5);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_70 = (double)fVar12;
                        FUN_01680e60(auStack_280,4);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_68 = (double)fVar12;
                        FUN_01680e60(auStack_288,3);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_34 = (double)fVar12;
                        fStack_14c = (float)fVar12;
                        fStack_148 = (float)dStack_68;
                        fStack_144 = (float)dStack_70;
                        FUN_01680e60(auStack_290,6);
                        uVar14 = FUN_0167e4f0();
                        uStack_1c8 = CONCAT44(fStack_13c,fStack_140);
                        fStack_1c0 = fStack_138;
                        fStack_1b4 = fStack_144;
                        fStack_1bc = fStack_14c;
                        fStack_1b8 = fStack_148;
                        uStack_194 = uVar14;
                        FUN_00c2e990(&uStack_1c8,&fStack_1bc,&uStack_194);
                        iVar5 = iStack_d8;
                      }
                    }
                  }
                  FUN_0167f070();
                }
                uStack_fc = uStack_60;
                uStack_100 = (int)uVar13;
                iStack_f8 = iVar5;
                FUN_00c2ea10();
                uVar11 = uStack_18 | 2;
                uStack_8._0_1_ = 9;
                uStack_18 = uVar11;
                iVar5 = FUN_00c2de70();
                FUN_00c2e780(auStack_1e8,0,iVar5 + 0x10,iVar5);
                uStack_8._0_1_ = 8;
                uVar2 = (undefined)uStack_8;
                uStack_8._0_1_ = 8;
                if (iStack_f4 != 0) {
                  iVar5 = iStack_f4;
                  if ((0xfff < (iStack_ec - iStack_f4 & 0xffffffe0U)) &&
                     (iVar5 = *(int *)(iStack_f4 + -4), 0x1f < (iStack_f4 - iVar5) - 4U)) {
                    uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                  FUN_01674ea0(iVar5);
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,7);
                if (iStack_d4 == 0) goto LAB_00c30982;
                iVar5 = iStack_d4;
                if ((0xfff < (iStack_cc - iStack_d4 & 0xffffffe0U)) &&
                   (iVar5 = *(int *)(iStack_d4 + -4), 0x1f < (iStack_d4 - iVar5) - 4U)) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
                FUN_01674ea0(iVar5);
                iStack_d4 = 0;
                uStack_d0 = 0;
                iStack_cc = 0;
                FUN_0167f070();
              }
            }
          }
          uStack_8c = uStack_c0;
          uStack_88 = uStack_c8;
          FUN_00c2db40(&puStack_20,(int)&param_1 + 3);
          uVar11 = uVar11 | 4;
          uStack_8._0_1_ = 10;
          uStack_18 = uVar11;
          iVar5 = FUN_00c2ddc0();
          FUN_00c2e640(auStack_1f0,0,iVar5 + 0x10,iVar5);
          puVar1 = puStack_84;
          uStack_8._0_1_ = 0xb;
          FUN_00c2f1c0();
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          puStack_84[1] = puVar1;
          *puStack_84 = puVar1;
          puStack_84[2] = puVar1;
          uStack_80 = 0;
          FUN_01674ea0(puStack_84);
          cVar3 = FUN_01681830();
          if (cVar3 != '\0') {
            FUN_016810c0();
            FUN_01680ea0();
            FUN_01681140();
            while( true ) {
              cVar3 = FUN_005e0cd0();
              if (cVar3 == '\0') break;
              FUN_0167efb0();
              FUN_0167eea0(auStack_1f8,"assetUsage");
              iVar5 = FUN_0167e2d0();
              FUN_0167eea0(auStack_200,&DAT_018c1fd8);
              uVar13 = FUN_0167e380(0,0);
              uStack_60 = (undefined4)((ulonglong)uVar13 >> 0x20);
              FUN_0167eea0(auStack_174,"useCase");
              cVar3 = FUN_01681830();
              uVar11 = uStack_18;
              if (cVar3 == '\0') {
LAB_00c30e95:
                FUN_0167f070();
              }
              else {
                iStack_e4 = 0;
                uStack_e0 = 0;
                iStack_dc = 0;
                uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
                iStack_e8 = iVar5;
                FUN_016810c0();
                FUN_01680ea0();
                FUN_01681140();
                while( true ) {
                  cVar3 = FUN_005e0cd0();
                  if (cVar3 == '\0') break;
                  FUN_0167efb0();
                  if (iVar5 == 2) {
                    cVar3 = FUN_01681830();
                    if (cVar3 != '\0') {
                      iVar6 = FUN_01681be0();
                      if (iVar6 == 7) {
                        FUN_01680e60(auStack_208,2);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_70 = (double)fVar12;
                        FUN_01680e60(auStack_210,1);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_68 = (double)fVar12;
                        FUN_01680e60(auStack_218,0);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_34 = (double)fVar12;
                        fStack_164 = (float)fVar12;
                        fStack_160 = (float)dStack_68;
                        fStack_15c = (float)dStack_70;
                        FUN_01680e60(auStack_220,5);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_70 = (double)fVar12;
                        FUN_01680e60(auStack_228,4);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_68 = (double)fVar12;
                        FUN_01680e60(auStack_298,3);
                        fVar12 = (float10)FUN_0167e350(0);
                        dStack_34 = (double)fVar12;
                        fStack_158 = (float)fVar12;
                        fStack_154 = (float)dStack_68;
                        fStack_150 = (float)dStack_70;
                        FUN_01680e60(auStack_230,6);
                        uStack_108 = FUN_0167e4f0();
                        uStack_1e0 = CONCAT44(fStack_160,fStack_164);
                        fStack_1d8 = fStack_15c;
                        fStack_1cc = fStack_150;
                        fStack_1d4 = fStack_158;
                        fStack_1d0 = fStack_154;
                        FUN_00c2e990(&uStack_1e0,&fStack_1d4,&uStack_108);
                        iVar5 = iStack_e8;
                      }
                    }
                  }
                  FUN_0167f070();
                }
                uStack_fc = uStack_60;
                uStack_100 = (int)uVar13;
                iStack_f8 = iVar5;
                FUN_00c2ea10();
                uVar11 = uStack_18 | 8;
                uStack_8._0_1_ = 0xd;
                uStack_18 = uVar11;
                iVar5 = FUN_00c2de70();
                FUN_00c2e780(auStack_238,0,iVar5 + 0x10,iVar5);
                uStack_8._0_1_ = 0xc;
                uVar2 = (undefined)uStack_8;
                uStack_8._0_1_ = 0xc;
                if (iStack_f4 != 0) {
                  iVar5 = iStack_f4;
                  if ((0xfff < (iStack_ec - iStack_f4 & 0xffffffe0U)) &&
                     (iVar5 = *(int *)(iStack_f4 + -4), 0x1f < (iStack_f4 - iVar5) - 4U)) {
                    uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                  FUN_01674ea0(iVar5);
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,7);
                if (iStack_e4 == 0) goto LAB_00c30e95;
                iVar5 = iStack_e4;
                if ((0xfff < (iStack_dc - iStack_e4 & 0xffffffe0U)) &&
                   (iVar5 = *(int *)(iStack_e4 + -4), 0x1f < (iStack_e4 - iVar5) - 4U)) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
                FUN_01674ea0(iVar5);
                iStack_e4 = 0;
                uStack_e0 = 0;
                iStack_dc = 0;
                FUN_0167f070();
              }
            }
          }
          uStack_a4 = uStack_c0;
          uStack_a0 = uStack_c8;
          FUN_00c2db40(&puStack_28,auStack_45);
          uVar11 = uVar11 | 0x10;
          uStack_8._0_1_ = 0xe;
          uStack_18 = uVar11;
          iVar5 = FUN_00c2ddc0();
          FUN_00c2e640(auStack_240,0,iVar5 + 0x10,iVar5);
          puVar4 = puStack_9c;
          uStack_8._0_1_ = 0xf;
          FUN_00c2f1c0();
          puStack_9c[1] = (uint)puVar4;
          *puStack_9c = (uint)puVar4;
          puStack_9c[2] = (uint)puVar4;
          uStack_98 = 0;
          FUN_01674ea0(puStack_9c);
          puVar1 = puStack_28;
          uStack_8._0_1_ = 0x10;
          FUN_00c2f1c0();
          puStack_28[1] = puVar1;
          *puStack_28 = puVar1;
          puStack_28[2] = puVar1;
          uStack_24 = 0;
          FUN_0054db70(puStack_28);
          puVar1 = puStack_20;
          uStack_8._0_1_ = 0x11;
          FUN_00c2f1c0();
          uStack_8._0_1_ = 4;
          puStack_20[1] = puVar1;
          *puStack_20 = puVar1;
          puStack_20[2] = puVar1;
          uStack_1c = 0;
          FUN_0054db70(puStack_20);
          FUN_0167f070();
        }
      }
    }
  }
  else {
    pcVar7 = (char *)FUN_016814a0();
    puStack_84 = (undefined4 *)0x0;
    uStack_80 = 0xf;
    uStack_94 = uStack_94 & 0xffffff00;
    pcVar8 = pcVar7;
    do {
      cVar3 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(pcVar7,(int)pcVar8 - (int)(pcVar7 + 1));
    uStack_8._0_1_ = 5;
    puVar4 = (uint *)FUN_00585d40(0,"PreModerationAsset parse error: ",0x20);
    uStack_a4 = *puVar4;
    uStack_a0 = puVar4[1];
    puStack_9c = (uint *)puVar4[2];
    uStack_98 = puVar4[3];
    uStack_108 = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    FUN_005507b0();
    uStack_1ac = uStack_a4;
    uStack_1a8 = uStack_a0;
    puStack_1a4 = puStack_9c;
    uStack_1a0 = uStack_98;
    uStack_19c = uStack_108;
    if (0xf < uStack_80) {
      uVar10 = uStack_80 + 1;
      uVar11 = uStack_94;
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(uStack_94 - 4);
        uVar10 = uStack_80 + 0x24;
        if (0x1f < (uStack_94 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
  }
  FUN_005507b0();
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27842 ; VA 0x00c30fcd ; Catch@00c30fcd */

undefined4 Catch_00c30fcd(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1ac) + 4))();
  uVar1 = FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 0x13;
  uVar1 = FUN_00558d90(unaff_EBP + -0xfc,"PreModerationAsset parse error",uVar1);
  FUN_005511f0(uVar1);
  FUN_005507b0();
  FUN_005507b0();
  return 0xc3034a;
}



/* FUNCTION 27843 ; VA 0x00c31050 ; FUN_00c31050 */

undefined4 FUN_00c31050(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint uVar5;
  int aiStack_88 [5];
  uint uStack_74;
  undefined auStack_70 [12];
  undefined auStack_64 [12];
  undefined8 uStack_58;
  undefined8 uStack_50;
  code *pcStack_48;
  undefined8 uStack_3c;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined8 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_018083e8;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  uStack_2c = FUN_009d09d0(aiStack_88,param_2,param_3,5,iVar3,iStack_24 + 0x50);
  uStack_14 = 0;
  puStack_28 = (undefined8 *)FUN_009d16a0(auStack_64,param_2,param_3,4,iVar3,iStack_24 + 0x4c);
  puVar4 = (undefined8 *)FUN_009d16a0(auStack_70,param_2,param_3,3,iVar3,iStack_24 + 0x48);
  uStack_34 = FUN_009d1940(param_2,param_3,2,iVar3,iStack_24 + 0x44);
  uStack_3c = FUN_009d1940(param_2,param_3,1,iVar3,iStack_24 + 0x40);
  pcStack_48 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  uStack_50 = *puStack_28;
  uVar1 = *(undefined4 *)(puStack_28 + 1);
  uStack_58 = *puVar4;
  uVar2 = *(undefined4 *)(puVar4 + 1);
  FUN_0054ef60(uStack_2c);
  (*pcStack_48)(uStack_3c,uStack_34,uStack_58,uVar2,uStack_50,uVar1);
  if (0xf < uStack_74) {
    uVar5 = uStack_74 + 1;
    iVar3 = aiStack_88[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_88[0] + -4);
      uVar5 = uStack_74 + 0x24;
      if (0x1f < (aiStack_88[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 27844 ; VA 0x00c311e0 ; FUN_00c311e0 */

void __thiscall FUN_00c311e0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  
  iVar1 = FUN_01256300(param_3);
  iVar1 = iVar1 - param_4;
  uVar3 = FUN_009d1940(param_3,param_4,3,iVar1,param_1 + 0x48);
  uVar4 = FUN_009d1940(param_3,param_4,2,iVar1,param_1 + 0x44);
  uVar5 = FUN_009d1940(param_3,param_4,1,iVar1,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(uVar5,uVar4,uVar3);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 27845 ; VA 0x00c31280 ; FUN_00c31280 */

void FUN_00c31280(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined auStack_40 [12];
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined8 *puStack_20;
  undefined8 *puStack_1c;
  code *pcStack_18;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  puStack_1c = (undefined8 *)FUN_009d16a0(auStack_34,param_2,param_3,4,iVar1,(int)pcStack_18 + 0x4c)
  ;
  puStack_20 = (undefined8 *)FUN_009d16a0(auStack_40,param_2,param_3,3,iVar1,(int)pcStack_18 + 0x48)
  ;
  uStack_28 = FUN_009d1940(param_2,param_3,2,iVar1,(int)pcStack_18 + 0x44);
  uVar3 = FUN_009d1940();
  pcStack_18 = *(code **)((int)pcStack_18 + 0x38);
  uVar2 = (*pcStack_18)(uVar3,uStack_28,*puStack_20,*(undefined4 *)(puStack_20 + 1),*puStack_1c,
                        *(undefined4 *)(puStack_1c + 1));
  FUN_009d5ac0(param_2,uVar2);
  return;
}



/* FUNCTION 27846 ; VA 0x00c31380 ; FUN_00c31380 */

void __thiscall FUN_00c31380(int *param_1,int *param_2,uint *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar1 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    uVar2 = param_3[1];
    puVar3 = (undefined4 *)puVar1[1];
    puVar5 = puVar1;
    do {
      if (((int)uVar2 < (int)puVar3[5]) ||
         (((int)uVar2 <= (int)puVar3[5] && (*param_3 <= (uint)puVar3[4])))) {
        puVar4 = (undefined4 *)*puVar3;
        puVar5 = puVar3;
      }
      else {
        puVar4 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if (((puVar5 != puVar1) && ((int)puVar5[5] <= (int)uVar2)) &&
       (((int)puVar5[5] < (int)uVar2 || ((uint)puVar5[4] <= *param_3)))) {
      *param_2 = (int)puVar5;
      return;
    }
  }
  *param_2 = (int)puVar1;
  return;
}



/* FUNCTION 27847 ; VA 0x00c313f0 ; FUN_00c313f0 */

undefined4 FUN_00c313f0(undefined4 param_1)

{
  FUN_00c31600(param_1);
  return param_1;
}



/* FUNCTION 27848 ; VA 0x00c31410 ; FUN_00c31410 */

uint FUN_00c31410(void)

{
  int iVar1;
  
  iVar1 = FUN_00c2dc10();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27849 ; VA 0x00c31430 ; FUN_00c31430 */

uint FUN_00c31430(void)

{
  int iVar1;
  
  iVar1 = FUN_00c2dc10();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27850 ; VA 0x00c31450 ; FUN_00c31450 */

void FUN_00c31450(int param_1)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c30180(&param_1);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27851 ; VA 0x00c314c0 ; FUN_00c314c0 */

undefined4 __thiscall FUN_00c314c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 in_stack_00000014;
  undefined4 in_stack_00000018;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_28;
  undefined auStack_24 [12];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808410;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00c31380(&iStack_14,&stack0x00000004);
  iVar2 = iStack_14;
  if (iStack_14 == *(int *)(param_1 + 0x70)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00c31380(&iStack_14,&stack0x0000000c);
  if (iStack_14 == *(int *)(iVar2 + 0x18)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uStack_28 = *(undefined4 *)(iStack_14 + 0x18);
  FUN_00c2ea10(iStack_14 + 0x1c);
  uStack_8 = 0;
  FUN_00c2edf0(&stack0x00000004);
  uStack_40 = in_stack_00000014;
  uStack_3c = in_stack_00000018;
  uStack_38 = uStack_28;
  FUN_00c2ea10(auStack_24);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_00c2de70(&uStack_40);
  FUN_00c2e780(&stack0x00000014,0,iVar3 + 0x10,iVar3);
  FUN_00c2ed30();
  iVar3 = FUN_00553830(iStack_14);
  FUN_00c2e930(iVar2 + 0x18,iVar3 + 0x10);
  FUN_01674ea0(iVar3,0x28);
  piVar1 = (int *)(iStack_18 + 0x68);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  *(int *)(iStack_18 + 0x6c) = *(int *)(iStack_18 + 0x6c) + -1 + (uint)(iVar2 != 0);
  FUN_00c2ed90();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27852 ; VA 0x00c31600 ; FUN_00c31600 */

undefined4 __thiscall FUN_00c31600(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int *piVar8;
  int *piVar9;
  int aiStack_50 [2];
  undefined4 uStack_48;
  char *pcStack_44;
  undefined *puStack_40;
  char *pcStack_3c;
  undefined auStack_2c [12];
  undefined *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808428;
  pvStack_10 = ExceptionList;
  pcStack_3c = (char *)0xc3162b;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_0167e9f0();
  uStack_8 = 0;
  pcStack_3c = (char *)0xc3163a;
  FUN_01681c30();
  pcStack_3c = *(char **)(param_1 + 0x5c);
  puStack_40 = *(undefined **)(param_1 + 0x58);
  pcStack_44 = "lastSaveTime";
  uStack_48 = 0xc3164d;
  FUN_016816e0();
  pcStack_3c = *(char **)(param_1 + 100);
  puStack_40 = *(undefined **)(param_1 + 0x60);
  pcStack_44 = "lastKnownPublishRequest";
  uStack_48 = 0xc31660;
  FUN_016816e0();
  pcStack_3c = "users";
  puStack_40 = (undefined *)0xc3166d;
  FUN_01681d10();
  pcStack_3c = (char *)0xc31674;
  FUN_01681c10();
  piStack_14 = (int *)**(int **)(param_1 + 0x70);
  if (piStack_14 != *(int **)(param_1 + 0x70)) {
    do {
      piVar9 = piStack_14;
      pcStack_3c = (char *)0xc3168c;
      FUN_01681c30();
      iVar2 = piVar9[5];
      puStack_40 = (undefined *)piVar9[4];
      pcStack_44 = "userId";
      uStack_48 = 0xc316a4;
      pcStack_3c = (char *)iVar2;
      puStack_20 = puStack_40;
      FUN_016816e0();
      pcStack_3c = "assetIds";
      puStack_40 = (undefined *)0xc316b1;
      FUN_01681d10();
      pcStack_3c = (char *)0xc316b8;
      FUN_01681c10();
      piVar8 = *(int **)piVar9[6];
      if (piVar8 != (int *)piVar9[6]) {
        do {
          pcStack_3c = (char *)piVar8[5];
          puStack_40 = (undefined *)piVar8[4];
          puStack_18 = aiStack_50;
          aiStack_50[0] = piVar8[6];
          FUN_00c2ea10(piVar8 + 7);
          FUN_00c318d0(auStack_2c);
          piVar3 = (int *)piVar8[2];
          if (*(char *)((int)piVar3 + 0xd) == '\0') {
            cVar1 = *(char *)(*piVar3 + 0xd);
            piVar8 = piVar3;
            piVar3 = (int *)*piVar3;
            while (cVar1 == '\0') {
              cVar1 = *(char *)(*piVar3 + 0xd);
              piVar8 = piVar3;
              piVar3 = (int *)*piVar3;
            }
          }
          else {
            cVar1 = *(char *)(piVar8[1] + 0xd);
            piVar5 = (int *)piVar8[1];
            piVar3 = piVar8;
            while ((piVar8 = piVar5, cVar1 == '\0' && (piVar3 == (int *)piVar8[2]))) {
              cVar1 = *(char *)(piVar8[1] + 0xd);
              piVar5 = (int *)piVar8[1];
              piVar3 = piVar8;
            }
          }
        } while (piVar8 != (int *)piVar9[6]);
      }
      pcStack_3c = (char *)0xc31739;
      FUN_016811a0();
      puVar4 = *(undefined4 **)(iStack_1c + 0x78);
      puVar6 = (undefined4 *)puVar4[1];
      puStack_18 = puVar4;
      if (*(char *)((int)puVar6 + 0xd) == '\0') {
        do {
          if ((iVar2 < (int)puVar6[5]) ||
             ((iVar2 <= (int)puVar6[5] && (puStack_20 <= (undefined *)puVar6[4])))) {
            puVar7 = (undefined4 *)*puVar6;
            puStack_18 = puVar6;
          }
          else {
            puVar7 = (undefined4 *)puVar6[2];
          }
          puVar6 = puVar7;
        } while (*(char *)((int)puVar7 + 0xd) == '\0');
        if (((puStack_18 == puVar4) || (iVar2 < (int)puStack_18[5])) ||
           ((iVar2 <= (int)puStack_18[5] && (puStack_20 < (undefined *)puStack_18[4]))))
        goto LAB_00c3177e;
      }
      else {
LAB_00c3177e:
        puStack_18 = puVar4;
      }
      puVar6 = puStack_18;
      if (puStack_18 != puVar4) {
        pcStack_3c = "tempIds";
        puStack_40 = (undefined *)0xc31798;
        FUN_01681d10();
        pcStack_3c = (char *)0xc3179f;
        FUN_01681c10();
        puVar4 = puStack_18;
        piVar8 = *(int **)puVar6[6];
        if (piVar8 != (int *)puVar6[6]) {
          do {
            pcStack_3c = (char *)piVar8[5];
            aiStack_50[0] = piVar8[6];
            puStack_40 = (undefined *)piVar8[4];
            puStack_20 = (undefined *)aiStack_50;
            FUN_00c2ea10(piVar8 + 7);
            FUN_00c318d0(auStack_2c);
            piVar9 = (int *)piVar8[2];
            if (*(char *)((int)piVar9 + 0xd) == '\0') {
              cVar1 = *(char *)(*piVar9 + 0xd);
              piVar8 = piVar9;
              piVar9 = (int *)*piVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*piVar9 + 0xd);
                piVar8 = piVar9;
                piVar9 = (int *)*piVar9;
              }
            }
            else {
              cVar1 = *(char *)(piVar8[1] + 0xd);
              piVar3 = (int *)piVar8[1];
              piVar9 = piVar8;
              while ((piVar8 = piVar3, cVar1 == '\0' && (piVar9 == (int *)piVar8[2]))) {
                cVar1 = *(char *)(piVar8[1] + 0xd);
                piVar3 = (int *)piVar8[1];
                piVar9 = piVar8;
              }
            }
            piVar9 = piStack_14;
          } while (piVar8 != (int *)puVar4[6]);
        }
        pcStack_3c = (char *)0xc3182c;
        FUN_016811a0();
      }
      pcStack_3c = (char *)0xc31834;
      FUN_01681200();
      piStack_14 = (int *)piVar9[2];
      if (*(char *)((int)piStack_14 + 0xd) == '\0') {
        cVar1 = *(char *)(*piStack_14 + 0xd);
        piVar8 = (int *)*piStack_14;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar8 + 0xd);
          piStack_14 = piVar8;
          piVar8 = (int *)*piVar8;
        }
      }
      else {
        cVar1 = *(char *)(piVar9[1] + 0xd);
        piVar8 = (int *)piVar9[1];
        while ((piStack_14 = piVar8, cVar1 == '\0' && (piVar9 == (int *)piStack_14[2]))) {
          cVar1 = *(char *)(piStack_14[1] + 0xd);
          piVar8 = (int *)piStack_14[1];
          piVar9 = piStack_14;
        }
      }
    } while (piStack_14 != *(int **)(iStack_1c + 0x70));
  }
  pcStack_3c = (char *)0xc31893;
  FUN_016811a0();
  pcStack_3c = (char *)0xc3189b;
  FUN_01681200();
  pcStack_3c = (char *)param_2;
  puStack_40 = (undefined *)0xc318a7;
  FUN_01681c50();
  pcStack_3c = (char *)0xc318af;
  FUN_0167ec80();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27853 ; VA 0x00c318d0 ; FUN_00c318d0 */

void FUN_00c318d0(undefined4 param_1,int param_2,int param_3,int param_4,int param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808448;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01681c30();
  FUN_016816e0(&DAT_018c1fd8,param_6,param_7);
  FUN_016817b0("assetUsage",param_2);
  if (param_2 == 2) {
    FUN_01681d10();
    FUN_01681c10();
    uVar1 = 0;
    if (param_4 - param_3 >> 5 != 0) {
      iVar2 = 0;
      do {
        FUN_01681c10();
        FUN_01681090((double)*(float *)(iVar2 + param_3));
        FUN_01681090((double)*(float *)(iVar2 + 4 + param_3));
        FUN_01681090((double)*(float *)(iVar2 + 8 + param_3));
        FUN_01681090((double)*(float *)(iVar2 + 0xc + param_3));
        FUN_01681090((double)*(float *)(iVar2 + 0x10 + param_3));
        FUN_01681090((double)*(float *)(iVar2 + 0x14 + param_3));
        FUN_01681740(*(undefined4 *)(iVar2 + 0x18 + param_3),*(undefined4 *)(iVar2 + 0x1c + param_3)
                    );
        FUN_016811a0();
        iVar2 = iVar2 + 0x20;
        uVar1 = uVar1 + 1;
      } while (uVar1 < (uint)(param_4 - param_3 >> 5));
    }
    FUN_016811a0();
  }
  FUN_01681200();
  if (param_3 != 0) {
    uVar1 = param_5 - param_3 & 0xffffffe0;
    iVar2 = param_3;
    if (0xfff < uVar1) {
      iVar2 = *(int *)(param_3 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27854 ; VA 0x00c31a80 ; FUN_00c31a80 */

int * __thiscall FUN_00c31a80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = FUN_00c367c0();
  iVar1 = *param_1;
  if (iVar1 == iVar4) {
    if (param_1 + 1 != param_2) {
      FUN_005507b0();
      iVar1 = param_2[1];
      iVar4 = param_2[2];
      iVar2 = param_2[3];
      param_1[1] = *param_2;
      param_1[2] = iVar1;
      param_1[3] = iVar4;
      param_1[4] = iVar2;
      *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[5] = 0;
  param_1[6] = 0;
  iVar1 = param_2[1];
  iVar2 = param_2[2];
  iVar3 = param_2[3];
  param_1[1] = *param_2;
  param_1[2] = iVar1;
  param_1[3] = iVar2;
  param_1[4] = iVar3;
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *param_1 = iVar4;
  return param_1;
}



/* FUNCTION 27855 ; VA 0x00c31b40 ; FUN_00c31b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c31b40(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808480;
  pvStack_10 = ExceptionList;
  if (DAT_01efa364 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa578) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efa578);
      if (DAT_01efa578 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c6de80();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"VideoFrame",0,uStack_20,0,0,0x1b,0,&DAT_01efeae4);
        _DAT_01efa570 = RBX::Creator<class_RBX::VideoFrame>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efa368,&DAT_01efa570);
        FUN_016f3654(FUN_01893fb0);
        FUN_016f37bf(&DAT_01efa578);
      }
    }
    DAT_01efa364 = &DAT_01efa368;
  }
  ExceptionList = pvStack_10;
  return DAT_01efa364;
}



/* FUNCTION 27856 ; VA 0x00c31c40 ; FUN_00c31c40 */

int FUN_00c31c40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808490;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008ed990(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(*param_4);
  *(undefined4 *)(iVar1 + 0x20) = 0;
  *(undefined4 *)(iVar1 + 0x24) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 27857 ; VA 0x00c31cab ; Catch_All@00c31cab */

void Catch_All_00c31cab(void)

{
  int unaff_EBP;
  
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27858 ; VA 0x00c31cd0 ; FUN_00c31cd0 */

void __thiscall FUN_00c31cd0(float *param_1,float *param_2,undefined4 param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  char cVar3;
  uint uVar4;
  float fVar5;
  float fVar6;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018084a0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_18 = param_1;
  uVar4 = FUN_009cc8a0(param_3);
  fVar5 = param_1[1];
  uVar4 = (uint)param_1[6] & uVar4;
  if (*(float *)((int)param_1[3] + uVar4 * 8) != fVar5) {
    fVar5 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
  }
  do {
    fVar6 = param_1[3];
    if (fVar5 == *(float *)((int)fVar6 + uVar4 * 8)) {
      pfStack_1c = param_4;
      fVar1 = *param_4;
      if (fVar5 != fVar1) {
        *(float *)param_4[1] = fVar1;
        **(float **)((int)fVar1 + 4) = fVar5;
        **(undefined4 **)((int)fVar5 + 4) = param_4;
        fVar6 = *(float *)((int)fVar5 + 4);
        *(undefined4 *)((int)fVar5 + 4) = *(undefined4 *)((int)fVar1 + 4);
        *(float *)((int)fVar1 + 4) = param_4[1];
        param_4[1] = fVar6;
        fVar6 = param_1[3];
      }
      fVar1 = *(float *)((int)fVar6 + uVar4 * 8);
      if (fVar1 == param_1[1]) {
        *(float **)((int)fVar6 + uVar4 * 8) = param_4;
        *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
      }
      else if (fVar1 == fVar5) {
        *(float **)((int)fVar6 + uVar4 * 8) = param_4;
      }
      else {
        pfVar2 = (float *)**(undefined4 **)((int)fVar6 + 4 + uVar4 * 8);
        *(float **)((int)fVar6 + 4 + uVar4 * 8) = pfVar2;
        if (pfVar2 != param_4) {
          *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
               *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
        }
      }
      fVar5 = param_1[7];
      uStack_8 = 2;
      fVar6 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)])
              / (float)((double)(int)fVar5 + (double)(&DAT_018c0d90)[-((int)fVar5 >> 0x1f)]);
      if (*param_1 <= fVar6 && fVar6 != *param_1) {
        if ((uint)fVar5 < 0x200) {
          fVar5 = (float)((int)fVar5 << 3);
        }
        else if ((uint)fVar5 < 0x1fffffff) {
          fVar5 = (float)((int)fVar5 * 2);
        }
        FUN_005cb500(fVar5);
        pfVar2 = (float *)param_1[1];
        if ((float *)*pfVar2 != pfVar2) {
          fVar5 = pfVar2[1];
          do {
            fVar6 = *(float *)param_1[1];
            FUN_00c31cd0(auStack_24,(int)fVar6 + 8,fVar6);
          } while (fVar6 != fVar5);
        }
      }
      *param_2 = (float)param_4;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    fVar5 = *(float *)((int)fVar5 + 4);
    cVar3 = FUN_009cbaa0(param_3,(int)fVar5 + 8);
  } while (cVar3 == '\0');
  *(float *)param_4[1] = *param_4;
  *(float *)((int)*param_4 + 4) = param_4[1];
  param_1[2] = (float)((int)param_1[2] + -1);
  FUN_0056cac0();
  FUN_01674ea0(param_4,0x28);
  *param_2 = fVar5;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27859 ; VA 0x00c31e9b ; Catch_All@00c31e9b */

void Catch_All_00c31e9b(void)

{
  int unaff_EBP;
  
  FUN_00c33930(*(undefined4 *)(unaff_EBP + 0x10));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27860 ; VA 0x00c31eaf ; Catch_All@00c31eaf */

void Catch_All_00c31eaf(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_00c322a0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27861 ; VA 0x00c31ee0 ; FUN_00c31ee0 */

int __thiscall FUN_00c31ee0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018084b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::VideoFrame*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27862 ; VA 0x00c31fb2 ; Catch_All@00c31fb2 */

void Catch_All_00c31fb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27863 ; VA 0x00c31fd0 ; FUN_00c31fd0 */

int **** __fastcall FUN_00c31fd0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int ****ppppiVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  int ****ppppiVar9;
  int ***apppiStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018084d8;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    iVar4 = *param_1;
    iVar2 = FUN_0088cb40();
    if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    uStack_8 = 0;
    FUN_009cbbb0(apppiStack_28);
    uStack_8 = 1;
    FUN_00c31a80(apppiStack_28);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      ppppiVar9 = (int ****)apppiStack_28[0];
      if (0xfff < uVar8) {
        ppppiVar9 = (int ****)apppiStack_28[0][-1];
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppiStack_28[0] + (-4 - (int)ppppiVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppiVar9,uVar8);
    }
    iVar4 = FUN_0088d190();
    *param_1 = iVar4;
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088d190();
  if (iVar4 == iVar2) {
    ppppiVar9 = (int ****)(param_1 + 2);
    if (param_1[1] == 0) {
      ppppiVar9 = (int ****)0x0;
    }
    if (ppppiVar9 != (int ****)0x0) {
      ExceptionList = pvStack_10;
      return ppppiVar9;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppiStack_28[0] = (int ***)((uint)apppiStack_28[0] & 0xffffff00);
    iVar4 = *param_1;
    uStack_8 = 2;
    iVar2 = FUN_0088cb40();
    if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    ppppiVar9 = (int ****)(param_1 + 2);
    ppppiVar5 = ppppiVar9;
    if (param_1[1] == 0) {
      ppppiVar5 = (int ****)0x0;
    }
    cVar1 = FUN_00c33b80(ppppiVar5,apppiStack_28);
    if (cVar1 != '\0') {
      iVar2 = FUN_00c367c0();
      iVar4 = param_1[1];
      if (iVar4 == iVar2) {
        if (ppppiVar9 != apppiStack_28) {
          ppppiVar5 = apppiStack_28;
          if (0xf < uStack_14) {
            ppppiVar5 = (int ****)apppiStack_28[0];
          }
          FUN_005542c0(ppppiVar5,uStack_18);
        }
      }
      else {
        if (iVar4 != 0) {
          (**(code **)(iVar4 + 8))(ppppiVar9);
          param_1[1] = 0;
        }
        FUN_0054ef60(apppiStack_28);
        param_1[1] = iVar2;
      }
      iVar4 = FUN_0088d190();
      *param_1 = iVar4;
      iVar2 = FUN_0088d190();
      if (iVar4 == iVar2) {
        iVar4 = param_1[1];
        FUN_005507b0();
        if (iVar4 == 0) {
          ppppiVar9 = (int ****)0x0;
        }
        ExceptionList = pvStack_10;
        return ppppiVar9;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  thunk_FUN_0088d190();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 27864 ; VA 0x00c321e0 ; FUN_00c321e0 */

undefined4 * FUN_00c321e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808523;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c31b40();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x418);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c32720();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c31ee0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27865 ; VA 0x00c322a0 ; FUN_00c322a0 */

undefined4 FUN_00c322a0(undefined4 param_1,undefined4 param_2)

{
  FUN_00c33fc0(param_1,param_2);
  return param_1;
}



/* FUNCTION 27866 ; VA 0x00c322c0 ; FUN_00c322c0 */

int __fastcall FUN_00c322c0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = *(int *)(param_1 + 0x34);
  piVar4 = (int *)(param_1 + 0x34);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00e98320();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) break;
    piVar4 = (int *)(*piVar4 + 0x34);
    iVar1 = *piVar4;
  }
  return iVar1;
}



/* FUNCTION 27867 ; VA 0x00c32310 ; FUN_00c32310 */

undefined4 __thiscall FUN_00c32310(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d190();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = FUN_00c31fd0();
    FUN_0054ef60(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088d190();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27868 ; VA 0x00c32410 ; FUN_00c32410 */

int * FUN_00c32410(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  int iStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808542;
  pvStack_10 = ExceptionList;
  iStack_28 = 0x140;
  uStack_2c = 0xc32438;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20();
  uStack_8 = 0;
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::VideoJob>::vftable;
    iVar1 = *param_2;
    uStack_2c = 0xc3246a;
    iStack_28 = iVar1;
    iVar4 = FUN_008f7870();
    if (iVar4 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = iVar4 + 0x10;
    }
    iStack_28 = 4;
    FUN_00944080(auStack_30,iVar4);
    FUN_00a360a0("Video",1,0);
    piVar3[4] = (int)RBX::VideoJob::vftable;
    piVar3[0x4e] = iVar1;
  }
  piVar2 = piVar3 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar3;
  if ((piVar2 != (int *)0x0) && ((piVar3[7] == 0 || (*(int *)(piVar3[7] + 4) == 0)))) {
    piVar5 = piVar3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar3[6] = (int)piVar2;
    piVar2 = (int *)piVar3[7];
    piVar3[7] = (int)piVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        iStack_28 = 0xc324f8;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        iStack_28 = 0xc3250b;
        (**(code **)*piVar5)();
        LOCK();
        piVar3 = piVar5 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          iStack_28 = 0xc3251a;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27869 ; VA 0x00c32530 ; FUN_00c32530 */

undefined4 * __thiscall FUN_00c32530(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808576;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 8);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0xe);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0x14);
  param_1[0x1a] = param_2[0x1a];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27870 ; VA 0x00c325e0 ; FUN_00c325e0 */

undefined4 * __thiscall
FUN_00c325e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018085a1;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00c31b40();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::VideoFrame,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VideoFrame::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_3);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::VideoFrame,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VideoFrame::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27871 ; VA 0x00c32720 ; FUN_00c32720 */

undefined4 * __fastcall FUN_00c32720(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808692;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c6f840("VideoFrame",0);
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::VideoFrame,class_RBX::GuiObject>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::VideoFrame,class_RBX::GuiObject>::vftable;
  uVar3 = FUN_00c31b40();
  param_1[3] = uVar3;
  *param_1 = RBX::VideoFrame::vftable;
  param_1[0x15] = RBX::VideoFrame::vftable;
  param_1[0xd2] = 0;
  param_1[0xd3] = 0;
  param_1[0xd4] = 0;
  param_1[0xd5] = 0;
  param_1[0xd6] = 0;
  param_1[0xd7] = 0;
  param_1[0xd8] = 0;
  param_1[0xd9] = 0;
  param_1[0xda] = 0;
  param_1[0xdf] = 0;
  param_1[0xe0] = 0xf;
  *(undefined *)(param_1 + 0xdb) = 0;
  *(undefined *)(param_1 + 0xe1) = 0;
  *(undefined8 *)(param_1 + 0xe2) = 0;
  *(undefined *)(param_1 + 0xe4) = 0;
  param_1[0xe5] = 0x3f800000;
  param_1[0xe6] = 0;
  param_1[0xe7] = 0;
  param_1[0xe8] = 0;
  param_1[0xe9] = 0;
  param_1[0xea] = 0;
  param_1[0xef] = 0;
  param_1[0xf0] = 0xf;
  *(undefined *)(param_1 + 0xeb) = 0;
  param_1[0xf5] = 0;
  param_1[0xf6] = 0xf;
  *(undefined *)(param_1 + 0xf1) = 0;
  param_1[0xf7] = 0;
  param_1[0xf8] = 0;
  param_1[0xf9] = 0;
  param_1[0xfa] = 0;
  param_1[0xfb] = 0;
  param_1[0xfc] = 0;
  param_1[0xfd] = 0;
  param_1[0xfe] = 0;
  param_1[0xff] = 0;
  param_1[0x100] = 0;
  param_1[0x101] = 0;
  param_1[0x102] = 0;
  param_1[0x103] = 0;
  param_1[0x104] = 0;
  uStack_8 = 0x10;
  *(undefined2 *)(param_1 + 0x105) = 0;
  *(undefined *)((int)param_1 + 0x416) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x2c);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<struct_RBX::VideoFrame::LoadJob>::vftable;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puVar4[5] = 0;
    puVar4[6] = 0;
    puVar4[7] = 0;
    puVar4[8] = 0;
    puVar4[9] = 0;
    puVar4[10] = 0;
    puVar4[7] = 0;
    puVar4[8] = 0xf;
    *(undefined *)(puVar4 + 3) = 0;
    puVar4[9] = 0;
    puVar4[10] = 0;
  }
  param_1[0x101] = puVar4 + 3;
  piVar1 = (int *)param_1[0x102];
  param_1[0x102] = puVar4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27872 ; VA 0x00c329c0 ; FUN_00c329c0 */

int __fastcall FUN_00c329c0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00637950();
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00c32a21. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 27873 ; VA 0x00c32a30 ; FUN_00c32a30 */

void __fastcall FUN_00c32a30(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::VideoFrame>::vftable;
  uVar1 = FUN_00c31b40(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27874 ; VA 0x00c32a70 ; thunk_FUN_00d5a740 */

void __fastcall thunk_FUN_00d5a740(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::GuiBase2d::vftable;
  param_1[0x15] = RBX::GuiBase2d::vftable;
  piVar3 = (int *)param_1[0x50];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar5 = param_1[0x4e];
  if (iVar5 != 0) {
    piVar3 = (int *)(iVar5 + 4);
    LOCK();
    iVar2 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar5);
    }
  }
  piVar3 = (int *)param_1[0x49];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x47];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x45];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x43];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x41];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x3f];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x3d];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x3b];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x39];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[0x37];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  uVar4 = param_1[0x1e];
  uStack_8 = 1;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    param_1[0x1e] = 0;
  }
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27875 ; VA 0x00c32a80 ; thunk_FUN_00c32d60 */

void __fastcall thunk_FUN_00c32d60(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char cVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(undefined ***)(param_1 + 0x2c8) =
       RBX::EventReplicatorBase<class_RBX::GuiObject,void___cdecl(class_RBX::UDim2)>::vftable;
  cVar6 = FUN_016793f0();
  if (cVar6 != '\0') {
    FUN_01679490();
  }
  cVar6 = FUN_016793f0();
  if (cVar6 != '\0') {
    FUN_01679490();
  }
  iVar4 = *(int *)(param_1 + 0x2e0);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x2dc);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_00c32a90();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = *(int **)(param_1 + 400);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x188);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = *(int **)(param_1 + 0x174);
  uStack_8 = 0xffffffff;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(param_1 + 0x16c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x164);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x15c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x154);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x148);
  if (piVar1 != (int *)0x0) {
    iVar4 = piVar1[1];
    if (iVar4 != 0) {
      uVar5 = *(uint *)(iVar4 + 0x38);
      uStack_8 = 2;
      if (uVar5 != 0) {
        if ((uVar5 & 1) == 0) {
          if (*(code **)(uVar5 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar5 & 0xfffffffe))(iVar4 + 0x40,iVar4 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar4 + 0x38) = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(iVar4,0x58);
    }
    iVar4 = *piVar1;
    if (iVar4 != 0) {
      uVar5 = *(uint *)(iVar4 + 0x38);
      uStack_8 = 3;
      if (uVar5 != 0) {
        if ((uVar5 & 1) == 0) {
          if (*(code **)(uVar5 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar5 & 0xfffffffe))(iVar4 + 0x40,iVar4 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar4 + 0x38) = 0;
      }
      FUN_01674ea0(iVar4,0x58);
    }
    FUN_01674ea0(piVar1,8);
  }
  FUN_00d5a740();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27876 ; VA 0x00c32a90 ; FUN_00c32a90 */

void __fastcall FUN_00c32a90(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27877 ; VA 0x00c32b40 ; FUN_00c32b40 */

void __fastcall FUN_00c32b40(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::GuiObject,void___cdecl(class_RBX::UDim2)>::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27878 ; VA 0x00c32bf0 ; FUN_00c32bf0 */

void __fastcall FUN_00c32bf0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00c33990();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x28);
  return;
}



/* FUNCTION 27879 ; VA 0x00c32c60 ; FUN_00c32c60 */

void __fastcall FUN_00c32c60(undefined4 *param_1)

{
  FUN_00c33990();
  FUN_01674ea0(*param_1,0x28);
  return;
}



/* FUNCTION 27880 ; VA 0x00c32c80 ; FUN_00c32c80 */

void __fastcall FUN_00c32c80(int *param_1)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  param_1 = (int *)*param_1;
  if (param_1 != (int *)0x0) {
    iVar1 = param_1[1];
    ExceptionList = &pvStack_10;
    if (iVar1 != 0) {
      uVar2 = *(uint *)(iVar1 + 0x38);
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      if (uVar2 != 0) {
        ExceptionList = &pvStack_10;
        if ((uVar2 & 1) == 0) {
          ExceptionList = &pvStack_10;
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            ExceptionList = &pvStack_10;
            (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x40,iVar1 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar1 + 0x38) = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(iVar1,0x58);
    }
    iVar1 = *param_1;
    if (iVar1 != 0) {
      uVar2 = *(uint *)(iVar1 + 0x38);
      uStack_8 = 1;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x40,iVar1 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar1 + 0x38) = 0;
      }
      FUN_01674ea0(iVar1,0x58);
    }
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27881 ; VA 0x00c32d50 ; FUN_00c32d50 */

void __fastcall FUN_00c32d50(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00c33990();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x28);
  return;
}



/* FUNCTION 27882 ; VA 0x00c32d60 ; FUN_00c32d60 */

void __fastcall FUN_00c32d60(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char cVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(undefined ***)(param_1 + 0x2c8) =
       RBX::EventReplicatorBase<class_RBX::GuiObject,void___cdecl(class_RBX::UDim2)>::vftable;
  cVar6 = FUN_016793f0();
  if (cVar6 != '\0') {
    FUN_01679490();
  }
  cVar6 = FUN_016793f0();
  if (cVar6 != '\0') {
    FUN_01679490();
  }
  iVar4 = *(int *)(param_1 + 0x2e0);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x2dc);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_00c32a90();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_00c32a90();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = *(int **)(param_1 + 400);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x188);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = *(int **)(param_1 + 0x174);
  uStack_8 = 0xffffffff;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(param_1 + 0x16c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x164);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x15c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x154);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x148);
  if (piVar1 != (int *)0x0) {
    iVar4 = piVar1[1];
    if (iVar4 != 0) {
      uVar5 = *(uint *)(iVar4 + 0x38);
      uStack_8 = 2;
      if (uVar5 != 0) {
        if ((uVar5 & 1) == 0) {
          if (*(code **)(uVar5 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar5 & 0xfffffffe))(iVar4 + 0x40,iVar4 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar4 + 0x38) = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(iVar4,0x58);
    }
    iVar4 = *piVar1;
    if (iVar4 != 0) {
      uVar5 = *(uint *)(iVar4 + 0x38);
      uStack_8 = 3;
      if (uVar5 != 0) {
        if ((uVar5 & 1) == 0) {
          if (*(code **)(uVar5 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar5 & 0xfffffffe))(iVar4 + 0x40,iVar4 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar4 + 0x38) = 0;
      }
      FUN_01674ea0(iVar4,0x58);
    }
    FUN_01674ea0(piVar1,8);
  }
  FUN_00d5a740();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27883 ; VA 0x00c33110 ; FUN_00c33110 */

void __fastcall FUN_00c33110(undefined4 *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808782;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::VideoFrame::vftable;
  param_1[0x15] = RBX::VideoFrame::vftable;
  uStack_8 = 0xf;
  FUN_01679490();
  FUN_01679490();
  if (param_1[0xe9] != 0) {
    iVar3 = FUN_005f7790();
    if (iVar3 != 0) {
      FUN_00c27510();
    }
    FUN_00d43150();
    param_1[0xe9] = 0;
    piVar1 = (int *)param_1[0xea];
    param_1[0xea] = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (DAT_01d6860c != '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    iVar3 = FUN_016dee6d();
    if (iVar3 != 0) {
      FUN_016df3c9();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    FUN_00c34300();
    FUN_0054ef60(param_1 + 0xdb);
    cVar2 = FUN_00c377c0();
    if (cVar2 == '\0') {
      FUN_00c34300();
      FUN_0054ef60(param_1 + 0xdb);
      FUN_00c35b90();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    iVar3 = FUN_016deec8();
    if (iVar3 != 0) {
      FUN_016df3c9();
      FUN_00c3328b();
      return;
    }
    uStack_8 = 0xf;
  }
  piVar1 = (int *)param_1[0x104];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x102];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0091a630();
  piVar1 = (int *)param_1[0xea];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  FUN_01679490();
  if (param_1[0xe8] != 0) {
    piVar1 = (int *)(param_1[0xe8] + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0();
    }
  }
  if (param_1[0xe7] != 0) {
    piVar1 = (int *)(param_1[0xe7] + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0();
    }
  }
  if (param_1[0xe6] != 0) {
    piVar1 = (int *)(param_1[0xe6] + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0();
    }
  }
  if (0xf < (uint)param_1[0xe0]) {
    if ((0xfff < param_1[0xe0] + 1) && (0x1f < (param_1[0xdb] - *(int *)(param_1[0xdb] + -4)) - 4U))
    {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  param_1[0xdf] = 0;
  param_1[0xe0] = 0xf;
  *(undefined *)(param_1 + 0xdb) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c32d60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27884 ; VA 0x00c3326c ; Catch@00c3326c */

undefined * Catch_00c3326c(void)

{
  int unaff_EBP;
  
  *(undefined ***)(unaff_EBP + -0x2c) = std::exception::vftable;
  FUN_0170c289(unaff_EBP + -0x28);
  return &DAT_00c33285;
}



/* FUNCTION 27885 ; VA 0x00c3328b ; FUN_00c3328b */

void FUN_00c3328b(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int unaff_EBX;
  int unaff_EBP;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xf;
  piVar1 = *(int **)(unaff_EDI + 0x410);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + unaff_EBX;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + unaff_EBX;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(unaff_EDI + 0x408);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + unaff_EBX;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + unaff_EBX;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0091a630();
  piVar1 = *(int **)(unaff_EDI + 0x3a8);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + unaff_EBX;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + unaff_EBX;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  *(undefined *)(unaff_EBP + -4) = 0x14;
  FUN_01679490();
  iVar3 = *(int *)(unaff_EDI + 0x3a0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + unaff_EBX;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = *(int *)(unaff_EDI + 0x39c);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + unaff_EBX;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = *(int *)(unaff_EDI + 0x398);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + unaff_EBX;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uVar2 = *(uint *)(unaff_EDI + 0x380);
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EDI + 0x36c);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(unaff_EDI + 0x37c) = 0;
  *(undefined4 *)(unaff_EDI + 0x380) = 0xf;
  *(undefined *)(unaff_EDI + 0x36c) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c32d60();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 27886 ; VA 0x00c33470 ; FUN_00c33470 */

int * __thiscall FUN_00c33470(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  undefined4 uVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int *piStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  uVar5 = FUN_009cc8a0(param_2);
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar5) * 8;
  piVar1 = (int *)(param_1 + 4);
  piVar10 = *(int **)(iVar2 + *(int *)(param_1 + 0xc));
  iVar6 = param_1;
  while( true ) {
    piVar9 = (int *)*piVar1;
    piVar7 = piVar9;
    if (*(int **)(*(int *)(iVar6 + 0xc) + iVar2) != piVar9) {
      piVar7 = (int *)**(undefined4 **)(*(int *)(iVar6 + 0xc) + 4 + iVar2);
    }
    piVar11 = piVar9;
    uStack_c = param_2;
    if (piVar10 == piVar7) goto LAB_00c334f4;
    cVar4 = FUN_009cbaa0(piVar10 + 2,param_2);
    uStack_c = param_2;
    if (cVar4 != '\0') break;
    piVar10 = (int *)*piVar10;
    iVar6 = iStack_8;
  }
  cVar4 = FUN_009cbaa0(param_2,piVar10 + 2);
  piVar9 = (int *)*piVar1;
  piVar11 = piVar10;
  if (cVar4 == '\0') {
    piVar11 = piVar9;
  }
LAB_00c334f4:
  if (piVar11 == piVar9) {
    iVar2 = *piVar9;
    puVar3 = *(undefined4 **)(iVar2 + 4);
    uVar8 = FUN_00c31c40(iVar2,puVar3,&DAT_018bdeda,&uStack_c,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0x6666665) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar2 + 4) = uVar8;
    *puVar3 = uVar8;
    FUN_00c31cd0(&piStack_10,*(int *)*piVar1 + 8,*(int *)*piVar1);
    piVar11 = piStack_10;
  }
  return piVar11 + 8;
}



/* FUNCTION 27887 ; VA 0x00c33560 ; FUN_00c33560 */

void FUN_00c33560(int *param_1)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  if (param_1 != (int *)0x0) {
    iVar1 = param_1[1];
    ExceptionList = &pvStack_10;
    if (iVar1 != 0) {
      uVar2 = *(uint *)(iVar1 + 0x38);
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      if (uVar2 != 0) {
        ExceptionList = &pvStack_10;
        if ((uVar2 & 1) == 0) {
          ExceptionList = &pvStack_10;
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            ExceptionList = &pvStack_10;
            (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x40,iVar1 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar1 + 0x38) = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(iVar1,0x58);
    }
    iVar1 = *param_1;
    if (iVar1 != 0) {
      uVar2 = *(uint *)(iVar1 + 0x38);
      uStack_8 = 1;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x40,iVar1 + 0x40,2);
          }
        }
        *(undefined4 *)(iVar1 + 0x38) = 0;
      }
      FUN_01674ea0(iVar1,0x58);
    }
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27888 ; VA 0x00c33630 ; FUN_00c33630 */

undefined4 __thiscall FUN_00c33630(undefined4 param_1,byte param_2)

{
  FUN_00c32d60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x348);
  }
  return param_1;
}



/* FUNCTION 27889 ; VA 0x00c33660 ; FUN_00c33660 */

undefined4 * __thiscall FUN_00c33660(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::VideoId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 27890 ; VA 0x00c33690 ; FUN_00c33690 */

undefined4 __thiscall FUN_00c33690(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2b8);
  }
  return param_1;
}



/* FUNCTION 27891 ; VA 0x00c336c0 ; FUN_00c336c0 */

undefined4 * __thiscall FUN_00c336c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::VideoId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 27892 ; VA 0x00c336f0 ; FUN_00c336f0 */

undefined4 __thiscall FUN_00c336f0(undefined4 param_1,byte param_2)

{
  FUN_00c33110();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x418);
  }
  return param_1;
}



/* FUNCTION 27893 ; VA 0x00c33720 ; FUN_00c33720 */

void FUN_00c33720(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar3 = *param_2 + 0.0;
  fVar2 = param_2[1] + 0.0;
  param_1[3] = 0.0;
  fVar1 = fVar3;
  if (0.0 <= fVar3) {
    fVar1 = 0.0;
  }
  *param_1 = fVar1;
  fVar1 = fVar2;
  if (0.0 <= fVar2) {
    fVar1 = 0.0;
  }
  param_1[1] = fVar1;
  if (fVar3 <= 0.0) {
    fVar3 = 0.0;
  }
  param_1[2] = fVar3;
  if (fVar2 <= 0.0) {
    fVar2 = 0.0;
  }
  param_1[3] = fVar2;
  return;
}



/* FUNCTION 27894 ; VA 0x00c33780 ; FUN_00c33780 */

undefined4 FUN_00c33780(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    if ((iVar1 != 0) && (iVar3 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if (iVar3 != 0) {
      iVar1 = *(int *)(iVar3 + 0xc);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
        uVar4 = FUN_00560c40();
        piVar5 = (int *)FUN_008aa140(uVar4);
        if (*piVar5 == 0) {
          uVar4 = FUN_00961660();
          piVar6 = (int *)FUN_008a9ba0(auStack_c,uVar4);
          iVar1 = *piVar6;
          iVar3 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piVar5 = iVar1;
          piVar6 = (int *)piVar5[1];
          piVar5[1] = iVar3;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar1 = piVar6[1] + -1;
            piVar6[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar1 = piVar6[2] + -1;
              piVar6[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_8[1] + -1;
            piStack_8[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar6 = piStack_8 + 2;
              iVar1 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                (**(code **)(*piStack_8 + 4))();
              }
            }
          }
        }
        iVar1 = *piVar5;
        if ((iVar1 != 0) &&
           ((iVar1 == *(int *)(param_1 + 0x34) ||
            ((*(int *)(param_1 + 0x34) != 0 && (cVar2 = FUN_00620ec0(iVar1), cVar2 != '\0')))))) {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 27895 ; VA 0x00c338b0 ; FUN_00c338b0 */

void __fastcall FUN_00c338b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 27896 ; VA 0x00c33930 ; FUN_00c33930 */

void __thiscall FUN_00c33930(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_0056cac0();
  FUN_01674ea0(param_2,0x28);
  return;
}



/* FUNCTION 27897 ; VA 0x00c33970 ; FUN_00c33970 */

void FUN_00c33970(void)

{
  FUN_00c72300();
  return;
}



/* FUNCTION 27898 ; VA 0x00c33980 ; FUN_00c33980 */

void __fastcall FUN_00c33980(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c33988. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0xdc))();
  return;
}



/* FUNCTION 27899 ; VA 0x00c33990 ; FUN_00c33990 */

void __fastcall FUN_00c33990(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_0056cac0();
      FUN_01674ea0(piVar2,0x28);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 27900 ; VA 0x00c339d0 ; FUN_00c339d0 */

undefined4 * __thiscall
FUN_00c339d0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018088f1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c33d40;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27901 ; VA 0x00c33b80 ; FUN_00c33b80 */

undefined4 FUN_00c33b80(undefined4 param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8 = 0;
  FUN_009cbbb0(&iStack_28);
  if (param_2 != &iStack_28) {
    FUN_005507b0();
    *param_2 = iStack_28;
    param_2[1] = iStack_24;
    param_2[2] = iStack_20;
    param_2[3] = iStack_1c;
    *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_14,uStack_18);
    ExceptionList = pvStack_10;
    return 1;
  }
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = iStack_28;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iStack_28 + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (iStack_28 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27902 ; VA 0x00c33c40 ; FUN_00c33c40 */

void __thiscall FUN_00c33c40(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808908;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27903 ; VA 0x00c33cd0 ; FUN_00c33cd0 */

undefined4 * FUN_00c33cd0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c321e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27904 ; VA 0x00c33d40 ; FUN_00c33d40 */

void FUN_00c33d40(int param_1,undefined8 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088ca00();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_00630890();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27905 ; VA 0x00c33e40 ; FUN_00c33e40 */

void FUN_00c33e40(int param_1,double param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x18);
  if ((NAN(param_2) || NAN(*(double *)(iVar1 + 0x388))) == (param_2 == *(double *)(iVar1 + 0x388)))
  {
    *(double *)(iVar1 + 0x388) = param_2;
    if (*(int *)(iVar1 + 0x3a4) != 0) {
      iVar1 = FUN_00d46ee0(param_2);
      if ((iVar1 != 0) && (DAT_01d84e8e != '\0')) {
        FUN_016774b0(DAT_01d84e8e,"Failed to set TimePosition",0);
      }
    }
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 27906 ; VA 0x00c33eb0 ; FUN_00c33eb0 */

void FUN_00c33eb0(undefined4 param_1,undefined4 param_2)

{
  FUN_00c36030(param_2);
  return;
}



/* FUNCTION 27907 ; VA 0x00c33ed0 ; FUN_00c33ed0 */

undefined __fastcall FUN_00c33ed0(int param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808930;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 8))(auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar1 = FUN_009cbaa0(uVar3,uVar2);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar6 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar6 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 27908 ; VA 0x00c33fc0 ; FUN_00c33fc0 */

void __thiscall FUN_00c33fc0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = FUN_009cc8a0(param_3 + 2);
  uVar3 = *(uint *)(param_1 + 0x18) & uVar3;
  piVar1 = (int *)(*(int *)(param_1 + 0xc) + uVar3 * 8);
  if ((int *)piVar1[1] == param_3) {
    if ((int *)*piVar1 == param_3) {
      *piVar1 = *(int *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + uVar3 * 8) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar1[1] = param_3[1];
    }
  }
  else if ((int *)*piVar1 == param_3) {
    *piVar1 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_0056cac0();
  FUN_01674ea0(param_3,0x28);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 27909 ; VA 0x00c34050 ; FUN_00c34050 */

int __thiscall FUN_00c34050(int param_1,int param_2)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009cc8a0(param_2);
  iVar8 = (uVar2 & *(uint *)(param_1 + 0x18)) * 8;
  piVar5 = *(int **)(iVar8 + *(int *)(param_1 + 0xc));
  while( true ) {
    piVar6 = *(int **)(param_1 + 4);
    piVar3 = piVar6;
    if (*(int **)(*(int *)(param_1 + 0xc) + iVar8) != piVar6) {
      piVar3 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar8);
    }
    piVar4 = piVar6;
    piVar7 = piVar6;
    if (piVar5 == piVar3) goto LAB_00c3410a;
    cVar1 = FUN_009cbaa0(piVar5 + 2,param_2);
    piVar3 = piVar5;
    if (cVar1 != '\0') break;
    piVar5 = (int *)*piVar5;
  }
  while( true ) {
    piVar6 = *(int **)(param_1 + 4);
    piVar4 = piVar6;
    if (*(int **)(*(int *)(param_1 + 0xc) + iVar8) != piVar6) {
      piVar4 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar8);
    }
    if (piVar3 == piVar4) goto LAB_00c340fd;
    cVar1 = FUN_009cbaa0(param_2,piVar3 + 2);
    if (cVar1 == '\0') break;
    piVar3 = (int *)*piVar3;
  }
  piVar6 = *(int **)(param_1 + 4);
LAB_00c340fd:
  piVar4 = piVar6;
  piVar7 = piVar6;
  if (piVar5 != piVar3) {
    piVar4 = piVar5;
    piVar7 = piVar3;
  }
LAB_00c3410a:
  iVar8 = 0;
  param_2 = 0;
  piVar5 = piVar4;
  if (piVar4 != piVar7) {
    do {
      piVar5 = (int *)*piVar5;
      iVar8 = iVar8 + 1;
    } while (piVar5 != piVar7);
    piVar6 = *(int **)(param_1 + 4);
    param_2 = iVar8;
  }
  if ((piVar4 == (int *)*piVar6) && (piVar7 == piVar6)) {
    uStack_8 = 0;
    FUN_00c33990();
    FUN_005cb500(8);
  }
  else if (piVar4 != piVar7) {
    do {
      piVar5 = (int *)*piVar4;
      uVar2 = FUN_009cc8a0(piVar4 + 2);
      iVar8 = (uVar2 & *(uint *)(param_1 + 0x18)) * 8;
      piVar6 = (int *)(*(int *)(param_1 + 0xc) + iVar8);
      if ((int *)piVar6[1] == piVar4) {
        if ((int *)*piVar6 == piVar4) {
          *piVar6 = *(int *)(param_1 + 4);
          *(undefined4 *)(iVar8 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          piVar6[1] = piVar4[1];
        }
      }
      else if ((int *)*piVar6 == piVar4) {
        *piVar6 = *piVar4;
      }
      *(int *)piVar4[1] = *piVar4;
      *(int *)(*piVar4 + 4) = piVar4[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_0056cac0();
      FUN_01674ea0(piVar4,0x28);
      piVar4 = piVar5;
    } while (piVar5 != piVar7);
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27910 ; VA 0x00c341f0 ; FUN_00c341f0 */

void FUN_00c341f0(int *param_1,undefined8 param_2)

{
  code *pcVar1;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined8 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53a1;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  FUN_008ec650(param_2);
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_f8 = FUN_0088ca00();
  uStack_f4 = 0;
  uStack_f0 = param_2;
  uStack_f4 = FUN_00630890();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f8,&uStack_28,param_1);
  uStack_8._0_1_ = 1;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f8,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27911 ; VA 0x00c34300 ; FUN_00c34300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c34300(undefined4 param_1)

{
  undefined *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808982;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa320) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efa320,param_1);
    if (DAT_01efa320 == -1) {
      uStack_8 = 0;
      _DAT_01efa2e4 = FUN_008ed990(0,0);
      _DAT_01efa2ec = 0;
      _DAT_01efa2f0 = 0;
      _DAT_01efa2f4 = 0;
      uStack_8._0_1_ = 2;
      _DAT_01efa2e0 = 0x3f800000;
      FUN_005cb500(8);
      uStack_8._0_1_ = 3;
      puVar1 = &DAT_01efa300;
      _DAT_01efa300 = 0;
      _DAT_01efa304 = 0;
      _DAT_01efa308 = 0;
      _DAT_01efa304 = FUN_008ed990(0,0);
      _DAT_01efa30c = 0;
      _DAT_01efa310 = 0;
      _DAT_01efa314 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      _DAT_01efa300 = 0x3f800000;
      FUN_005cb500(8);
      FUN_016f3654(&LAB_01893e70,puVar1);
      FUN_016f37bf(&DAT_01efa320);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efa2e0;
}



/* FUNCTION 27912 ; VA 0x00c34450 ; FUN_00c34450 */

void FUN_00c34450(void)

{
  int iVar1;
  
  if (DAT_01efa57c == 0) {
    iVar1 = FUN_00c31b40();
    DAT_01efa57c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27913 ; VA 0x00c34470 ; FUN_00c34470 */

undefined __fastcall FUN_00c34470(int param_1)

{
  return *(undefined *)(param_1 + 0x2e5);
}



/* FUNCTION 27914 ; VA 0x00c34480 ; FUN_00c34480 */

undefined4 * __thiscall FUN_00c34480(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_60 [12];
  undefined4 uStack_54;
  uint uStack_50;
  uint *puStack_4c;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined *puStack_24;
  undefined uStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018089c1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  puStack_4c = (uint *)&DAT_01efa2ac;
  uStack_8 = 0;
  uStack_14 = 1;
  puStack_24 = &DAT_01efa2ac;
  uStack_50 = 0xc344d9;
  iStack_18 = param_1;
  puStack_4c = (uint *)FUN_016dee6d();
  if (puStack_4c != (uint *)0x0) {
    uStack_50 = 0xc344e6;
    FUN_016df3c9();
  }
  uStack_20 = 1;
  uStack_8 = 1;
  if (DAT_01d6860c != '\0') {
    puStack_4c = (uint *)0xc34506;
    FUN_00c34300();
    puStack_1c = (undefined *)(param_1 + 0x36c);
    FUN_0054ef60(puStack_1c);
    cVar3 = FUN_00c378b0();
    if (cVar3 != '\0') {
      puStack_4c = (uint *)0xc34533;
      FUN_00c34300();
      puStack_4c = (uint *)puStack_1c;
      uStack_50 = 0xc34541;
      FUN_0054ef60();
      puStack_1c = auStack_60;
      uStack_8._0_1_ = 2;
      FUN_0054ef60(auStack_3c);
      cVar3 = FUN_00c378b0();
      if (cVar3 == '\0') {
        uVar6 = 0;
        iVar7 = 0;
        uStack_14 = 3;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (0xf < uStack_28) {
          puStack_4c = (uint *)(uStack_28 + 1);
          uVar5 = auStack_3c[0];
          if (0xfff < puStack_4c) {
            uVar5 = *(uint *)(auStack_3c[0] - 4);
            puStack_4c = (uint *)(uStack_28 + 0x24);
            if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
              puStack_4c = (uint *)0xc347a5;
              FUN_017167a3();
            }
          }
          uStack_54 = 0xc34608;
          uStack_50 = uVar5;
          FUN_01674ea0();
        }
      }
      else {
        puStack_4c = auStack_3c;
        uStack_50 = 0xc3456c;
        puVar4 = (undefined4 *)FUN_00c33470();
        iVar7 = puVar4[1];
        if (iVar7 != 0) {
          LOCK();
          *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
          UNLOCK();
          iVar7 = puVar4[1];
        }
        uVar6 = *puVar4;
        uStack_14 = 3;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (0xf < uStack_28) {
          puStack_4c = (uint *)(uStack_28 + 1);
          uVar5 = auStack_3c[0];
          if (0xfff < puStack_4c) {
            uVar5 = *(uint *)(auStack_3c[0] - 4);
            puStack_4c = (uint *)(uStack_28 + 0x24);
            if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
              puStack_4c = (uint *)0xc347a0;
              FUN_017167a3();
            }
          }
          uStack_54 = 0xc345b8;
          uStack_50 = uVar5;
          FUN_01674ea0();
        }
      }
      uStack_2c = 0;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      *param_2 = uVar6;
      piVar2 = (int *)param_2[1];
      uStack_28 = 0xf;
      param_2[1] = iVar7;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar7 = piVar2[1] + -1;
        piVar2[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          puStack_4c = (uint *)0xc3463e;
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar7 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            puStack_4c = (uint *)0xc34651;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      goto LAB_00c34765;
    }
  }
  puStack_4c = *(uint **)(param_1 + 0x404);
  uStack_54 = 0xc34668;
  uStack_50 = param_1 + 0x36c;
  cVar3 = FUN_009cbaa0();
  if ((cVar3 != '\0') && (puStack_4c = (uint *)(*(int *)(param_1 + 0x404) + 0x18), *puStack_4c != 0)
     ) {
    uStack_50 = 0xc3468d;
    FUN_0056ecd0();
    if (DAT_01d6860c != '\0') {
      puStack_4c = (uint *)0xc3469f;
      FUN_00c34300();
      uStack_50 = 0xc346aa;
      puStack_4c = (uint *)(param_1 + 0x36c);
      FUN_0054ef60();
      puStack_1c = auStack_60;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_0054ef60(auStack_3c);
      cVar3 = FUN_00c37690();
      if (cVar3 != '\0') {
        puStack_4c = auStack_3c;
        uStack_50 = 0xc346d6;
        FUN_00c34050();
      }
      puStack_4c = auStack_3c;
      uStack_50 = 0xc346e1;
      puVar4 = (undefined4 *)FUN_00c33470();
      iVar7 = param_2[1];
      if (iVar7 != 0) {
        LOCK();
        *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
        UNLOCK();
        iVar7 = param_2[1];
      }
      *puVar4 = *param_2;
      piVar2 = (int *)puVar4[1];
      puVar4[1] = iVar7;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar7 = piVar2[1] + -1;
        piVar2[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          puStack_4c = (uint *)0xc34711;
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar7 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            puStack_4c = (uint *)0xc34720;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (0xf < uStack_28) {
        puStack_4c = (uint *)(uStack_28 + 1);
        uVar5 = auStack_3c[0];
        if (0xfff < puStack_4c) {
          uVar5 = *(uint *)(auStack_3c[0] - 4);
          puStack_4c = (uint *)(uStack_28 + 0x24);
          if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
            puStack_4c = (uint *)&UNK_00c347aa;
            FUN_017167a3();
          }
        }
        uStack_54 = 0xc34751;
        uStack_50 = uVar5;
        FUN_01674ea0();
      }
    }
    puStack_4c = (uint *)0xc34765;
    FUN_0058a2b0();
  }
LAB_00c34765:
  puStack_4c = (uint *)&DAT_01efa2ac;
  uStack_8 = 4;
  uStack_50 = 0xc34776;
  puStack_4c = (uint *)FUN_016deec8();
  if (puStack_4c != (uint *)0x0) {
    uStack_50 = 0xc34783;
    FUN_016df3c9();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27915 ; VA 0x00c347d0 ; FUN_00c347d0 */

undefined4 __fastcall FUN_00c347d0(int param_1)

{
  return *(undefined4 *)(param_1 + 0xd4);
}



/* FUNCTION 27916 ; VA 0x00c347e0 ; FUN_00c347e0 */

void __thiscall FUN_00c347e0(int param_1,float *param_2)

{
  int iVar1;
  int iVar2;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = 0;
  iStack_c = 0;
  iVar1 = 0;
  iVar2 = 0;
  if (*(int *)(param_1 + 0x3a4) != 0) {
    FUN_00d44b40(&iStack_8,&iStack_c);
    iVar1 = iStack_8;
    iVar2 = iStack_c;
  }
  *param_2 = (float)iVar1;
  param_2[1] = (float)iVar2;
  return;
}



/* FUNCTION 27917 ; VA 0x00c34830 ; FUN_00c34830 */

undefined4 __thiscall FUN_00c34830(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808908;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_3);
  uStack_8 = 0;
  FUN_0054ef60(aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27918 ; VA 0x00c348c0 ; FUN_00c348c0 */

float10 __fastcall FUN_00c348c0(int param_1)

{
  float10 fVar1;
  
  if (*(int *)(param_1 + 0x3a4) != 0) {
    fVar1 = (float10)FUN_00d44bb0();
    return fVar1;
  }
  return (float10)0.0;
}



/* FUNCTION 27919 ; VA 0x00c34900 ; FUN_00c34900 */

void __thiscall FUN_00c34900(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808908;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  uVar2 = FUN_0088d190();
  *param_3 = uVar2;
  FUN_00c31a80(uVar1);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27920 ; VA 0x00c34990 ; FUN_00c34990 */

undefined4 __thiscall FUN_00c34990(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x36c);
  return param_2;
}



/* FUNCTION 27921 ; VA 0x00c349b0 ; FUN_00c349b0 */

undefined __fastcall FUN_00c349b0(int param_1)

{
  return *(undefined *)(param_1 + 0x340);
}



/* FUNCTION 27922 ; VA 0x00c349d0 ; FUN_00c349d0 */

undefined4 __fastcall FUN_00c349d0(int param_1)

{
  return *(undefined4 *)(param_1 + 0xd0);
}



/* FUNCTION 27923 ; VA 0x00c349e0 ; FUN_00c349e0 */

/* WARNING: Removing unreachable block (ram,0x00c34b42) */
/* WARNING: Removing unreachable block (ram,0x00c34b4b) */
/* WARNING: Removing unreachable block (ram,0x00c34b5a) */
/* WARNING: Removing unreachable block (ram,0x00c34b1c) */
/* WARNING: Removing unreachable block (ram,0x00c34b25) */
/* WARNING: Removing unreachable block (ram,0x00c34b34) */
/* WARNING: Removing unreachable block (ram,0x00c34b68) */
/* WARNING: Removing unreachable block (ram,0x00c34b71) */
/* WARNING: Removing unreachable block (ram,0x00c34b7f) */

int FUN_00c349e0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808a00;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  uStack_20 = param_5;
  piStack_1c = param_6;
  piStack_14 = param_4;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c34bf0(iVar3,iVar3 + 8,iVar3 + 0x20,param_2,param_3,param_4,&uStack_20);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27924 ; VA 0x00c34bb0 ; FUN_00c34bb0 */

uint FUN_00c34bb0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c31b40();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27925 ; VA 0x00c34bd0 ; FUN_00c34bd0 */

uint FUN_00c34bd0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c31b40();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27926 ; VA 0x00c34bf0 ; FUN_00c34bf0 */

int FUN_00c34bf0(int *param_1,undefined4 *param_2,undefined4 param_3,int param_4,int *param_5,
                int *param_6,int *param_7)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined8 uVar10;
  int aiStack_58 [7];
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined *puStack_30;
  undefined uStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01808a54;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa330) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01efa330), DAT_01efa330 == -1)) {
    iStack_8._0_1_ = 1;
    uVar10 = FUN_0152dab0("Video","loadVideoCallback",0xffffffff);
    DAT_01efa32c = (undefined4)((ulonglong)uVar10 >> 0x20);
    DAT_01efa328 = (undefined4)uVar10;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_016f37bf(&DAT_01efa330);
  }
  aiStack_58[6] = DAT_01efa328;
  uStack_3c = DAT_01efa32c;
  uStack_38 = FUN_0152d930(DAT_01efa328,DAT_01efa32c);
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  puStack_30 = &DAT_01efa2ac;
  iVar5 = FUN_016dee6d(&DAT_01efa2ac);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  uStack_2c = 1;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  iVar5 = param_1[1];
  if (iVar5 != 0) {
    piVar1 = (int *)(iVar5 + 4);
    iVar5 = *(int *)(iVar5 + 4);
    while (iVar5 != 0) {
      LOCK();
      iVar6 = *piVar1;
      if (iVar5 == iVar6) {
        *piVar1 = iVar5 + 1;
        iVar6 = iVar5;
      }
      UNLOCK();
      if (iVar6 == iVar5) {
        iStack_20 = *param_1;
        piStack_1c = (int *)param_1[1];
        break;
      }
      iVar5 = *piVar1;
    }
  }
  piVar1 = piStack_1c;
  iStack_8 = CONCAT31(iStack_8._1_3_,4);
  if (iStack_20 == 0) {
    if (DAT_01efa298 != '\0') {
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_01677650(DAT_01efa298,"Abandoning video %s because VideoFrame is dead",param_2);
    }
  }
  else {
    cVar3 = FUN_009cbaa0(iStack_20,param_2);
    if (cVar3 != '\0') {
      if (param_4 == 1) {
        if (*param_7 == 0) {
          if (param_5 == (int *)0x0) {
            FUN_00c34fc0(param_2,param_3,"Request failed, no data");
          }
          else {
            FUN_005956d0(0,0,2);
            piStack_18 = param_5;
            piVar2 = *(int **)(*(int *)(*param_5 + 4) + 0x38 + (int)param_5);
            if (piVar2 != (int *)0x0) {
              (**(code **)(*piVar2 + 4))();
            }
            iStack_8._0_1_ = 5;
            uVar4 = FUN_00593b40(1);
            puStack_14 = (undefined4 *)CONCAT31(puStack_14._1_3_,uVar4);
            iStack_8._0_1_ = 6;
            if ((*(byte *)(*(int *)(*param_5 + 4) + 0xc + (int)param_5) & 6) == 0) {
              (**(code **)(**(int **)(*(int *)(*param_5 + 4) + 0x38 + (int)param_5) + 0x28))
                        (aiStack_58,0,0,1,1);
              iStack_8 = CONCAT31(iStack_8._1_3_,7);
            }
            else {
              aiStack_58[0] = -1;
              aiStack_58[1] = 0xffffffff;
              aiStack_58[2] = 0;
              aiStack_58[3] = 0;
              aiStack_58[4] = 0;
              aiStack_58[5] = 0;
              iStack_8 = CONCAT31(iStack_8._1_3_,8);
            }
            piVar2 = *(int **)(*(int *)(*param_5 + 4) + 0x38 + (int)param_5);
            if (piVar2 != (int *)0x0) {
              (**(code **)(*piVar2 + 8))();
            }
            uVar7 = aiStack_58[0] + aiStack_58[2];
            iStack_8._0_1_ = 4;
            FUN_005956d0(0,0,0);
            puStack_14 = (undefined4 *)FUN_01674e20(0x24);
            if (puStack_14 == (undefined4 *)0x0) {
              puVar9 = (undefined4 *)0x0;
            }
            else {
              puStack_14[1] = 1;
              puStack_14[2] = 1;
              *puStack_14 = std::
                            _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                            ::vftable;
              puStack_14[7] = 0;
              puStack_14[8] = 0xf;
              *(undefined *)(puStack_14 + 3) = 0;
              puVar9 = puStack_14;
            }
            puStack_28 = puVar9 + 3;
            iStack_8 = CONCAT31(iStack_8._1_3_,9);
            puStack_24 = puVar9;
            if ((uint)puVar9[7] < uVar7) {
              FUN_00578160(uVar7 - puVar9[7],0);
            }
            else {
              puVar8 = puStack_28;
              if (0xf < (uint)puVar9[8]) {
                puVar8 = (undefined4 *)*puStack_28;
              }
              puVar9[7] = uVar7;
              *(undefined *)((int)puVar8 + uVar7) = 0;
            }
            puVar8 = puVar9 + 3;
            if (0xf < (uint)puVar9[8]) {
              puVar8 = (undefined4 *)*puVar8;
            }
            FUN_005af630(puVar8,uVar7,(int)uVar7 >> 0x1f);
            if (puVar9 != (undefined4 *)0x0) {
              LOCK();
              puVar9[1] = puVar9[1] + 1;
              UNLOCK();
            }
            *(undefined4 **)(iStack_20 + 0x18) = puVar9 + 3;
            piVar2 = *(int **)(iStack_20 + 0x1c);
            *(undefined4 **)(iStack_20 + 0x1c) = puVar9;
            if (piVar2 != (int *)0x0) {
              LOCK();
              iVar5 = piVar2[1] + -1;
              piVar2[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piVar2)();
                LOCK();
                iVar5 = piVar2[2] + -1;
                piVar2[2] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
            FUN_00550b30();
          }
        }
        else {
          FUN_0056ecd0(param_7);
        }
      }
      else {
        FUN_00c34fc0(param_2,param_3,"Request failed");
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,10);
  iVar5 = FUN_016deec8(&DAT_01efa2ac);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
  iVar5 = FUN_0152dda0(aiStack_58[6],uStack_3c,uStack_38);
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar6 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar5 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27927 ; VA 0x00c34fc0 ; FUN_00c34fc0 */

void FUN_00c34fc0(char *param_1,undefined4 param_2,char *param_3)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808a78;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  pcVar2 = param_3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_3,(int)pcVar2 - (int)(param_3 + 1));
  uStack_8 = 0;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    param_1 = *(char **)param_1;
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar2 - (int)(param_1 + 1));
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("Video",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008d2350(auStack_28,param_2,auStack_40,auStack_58);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27928 ; VA 0x00c35160 ; FUN_00c35160 */

void FUN_00c35160(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808a9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x6c);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00c32530(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00c329c0();
        FUN_01674ea0(iVar2,0x6c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1e007f0);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_56b8be487079f6b5d11a78d5c862ca10>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27929 ; VA 0x00c352b0 ; FUN_00c352b0 */

void __thiscall FUN_00c352b0(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800252;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c78c60(param_2);
  FUN_01679490();
  FUN_01679490();
  *(undefined2 *)(param_1 + 0x414) = 0;
  iVar3 = FUN_008f7870(*(undefined4 *)(param_2 + 8));
  iVar1 = *(int *)(param_1 + 0x34);
  iVar4 = param_1;
  if ((iVar1 != 0) && (iVar4 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
    iVar4 = FUN_005c8ac0();
  }
  if ((iVar4 == 0) ||
     (iVar1 = *(int *)(iVar4 + 0xc), iVar5 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    iVar4 = 0;
  }
  if (((*(int *)(param_2 + 8) == 0) || (iVar3 == 0)) || (iVar4 == 0)) {
    *(undefined *)(param_1 + 0x416) = 0;
  }
  else {
    cVar2 = FUN_00ade710(param_1);
    if (cVar2 != '\0') {
      *(undefined *)(param_1 + 0x414) = 1;
    }
    cVar2 = FUN_00c33780(param_1);
    if (cVar2 != '\0') {
      *(undefined *)(param_1 + 0x414) = 1;
    }
    if (((DAT_01d668ec != '\0') && (piVar6 = (int *)FUN_00817fa0(), piVar6 != (int *)0x0)) &&
       (cVar2 = (**(code **)(*piVar6 + 0x108))(), cVar2 != '\0')) {
      *(undefined2 *)(param_1 + 0x414) = 0x101;
    }
    iVar1 = *(int *)(iVar3 + 0x4a0);
    cVar2 = FUN_00983210(*(undefined4 *)(param_2 + 8));
    if ((iVar1 == 2) || (cVar2 != '\0')) {
      uVar9 = 1;
    }
    else {
      uVar9 = 0;
    }
    *(undefined *)(param_1 + 0x416) = uVar9;
    if ((iVar1 == 1) || (cVar2 != '\0')) {
      FUN_006eccd0();
      uStack_8 = 0;
      uVar7 = FUN_01675290(DAT_02110da8);
      uStack_8 = 1;
      puVar8 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar8 == (undefined4 *)0x0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        *puVar8 = 0;
        puVar8[1] = 1;
        puVar8[2] = FUN_00c33eb0;
        puVar8[3] = _guard_check_icall;
        puVar8[4] = 0;
        puVar8[5] = param_1 + 0x35c;
        puVar8[6] = param_1;
      }
      FUN_016797d0(puVar8);
      if (puVar8 != (undefined4 *)0x0) {
        LOCK();
        puVar8[1] = puVar8[1] + 1;
        UNLOCK();
      }
      uStack_8 = 2;
      FUN_01675290(uVar7);
      iVar1 = *(int *)(param_1 + 0x398);
      uStack_8 = 0xffffffff;
      *(undefined4 **)(param_1 + 0x398) = puVar8;
      if (iVar1 != 0) {
        piVar6 = (int *)(iVar1 + 4);
        LOCK();
        iVar4 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(iVar1);
        }
      }
      FUN_006eccd0();
      uStack_8 = 3;
      uVar7 = FUN_01675290(DAT_02110da8);
      uStack_8 = 4;
      puVar8 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar8 == (undefined4 *)0x0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        *puVar8 = 0;
        puVar8[1] = 1;
        puVar8[2] = FUN_00c33e40;
        puVar8[3] = _guard_check_icall;
        puVar8[4] = 0;
        puVar8[5] = param_1 + 0x364;
        puVar8[6] = param_1;
      }
      FUN_016797d0(puVar8);
      if (puVar8 != (undefined4 *)0x0) {
        LOCK();
        puVar8[1] = puVar8[1] + 1;
        UNLOCK();
      }
      uStack_8 = 5;
      FUN_01675290(uVar7);
      iVar1 = *(int *)(param_1 + 0x39c);
      uStack_8 = 0xffffffff;
      *(undefined4 **)(param_1 + 0x39c) = puVar8;
      if (iVar1 != 0) {
        piVar6 = (int *)(iVar1 + 4);
        LOCK();
        iVar4 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(iVar1);
        }
      }
    }
  }
  FUN_00c375d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27930 ; VA 0x00c355d0 ; FUN_00c355d0 */

void __fastcall FUN_00c355d0(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  undefined in_stack_ffffffd4;
  undefined uVar6;
  
  if (*(int *)(param_1 + 0x3a4) != 0) {
    iVar3 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    if ((iVar3 != 0) && (iVar2 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if (((iVar2 != 0) &&
        (iVar3 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar3 = FUN_0068f660(), iVar3 != 0)) {
      (**(code **)(**(int **)(param_1 + 0x3a4) + 4))();
    }
    if (*(int *)(param_1 + 0x3a4) != 0) {
      FUN_00d46ee0(*(undefined8 *)(param_1 + 0x388));
      FUN_00d46ea0();
      FUN_00d47490();
    }
    FUN_00c375d0();
    FUN_008a4940();
    FUN_008a4940();
    FUN_008a4940();
    pcVar5 = (char *)(param_1 + 0x36c);
    FUN_0054ef60(pcVar5);
    FUN_006ecaa0(in_stack_ffffffd4);
    if (*(char *)(param_1 + 900) != '\0') {
      if (0xf < *(uint *)(param_1 + 0x380)) {
        pcVar5 = *(char **)pcVar5;
      }
      uVar6 = 0;
      pcVar4 = pcVar5;
      do {
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(pcVar5,(int)pcVar4 - (int)(pcVar5 + 1));
      FUN_006ecaa0(uVar6);
    }
    FUN_00c37580();
  }
  return;
}



/* FUNCTION 27931 ; VA 0x00c35730 ; FUN_00c35730 */

void __thiscall FUN_00c35730(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808ac0;
  pvStack_10 = ExceptionList;
  piVar8 = *(int **)(param_1 + 0x410);
  if (DAT_01d68614 == '\0') {
    ExceptionList = &pvStack_10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = *(int **)(param_1 + 0x410);
    }
    uStack_1c = *(undefined4 *)(param_1 + 0x40c);
    uStack_8 = 1;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
    }
    piStack_18 = piVar8;
    FUN_0151dac0(uStack_1c,piVar8,1,0);
    uStack_8 = 0xffffffff;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = piVar8[1] + -1;
      piVar8[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar5 = piVar8[2] + -1;
        piVar8[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    *(undefined4 *)(param_1 + 0x40c) = 0;
    piVar8 = *(int **)(param_1 + 0x410);
    *(undefined4 *)(param_1 + 0x410) = 0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = piVar8[1] + -1;
      piVar8[1] = iVar5;
      UNLOCK();
      goto LAB_00c35884;
    }
  }
  else {
    uStack_1c = *(undefined4 *)(param_1 + 0x40c);
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x40c) = 0;
    *(undefined4 *)(param_1 + 0x410) = 0;
    uStack_8 = 0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
    }
    piStack_18 = piVar8;
    FUN_0151dac0(uStack_1c,piVar8,0,0);
    uStack_8 = 0xffffffff;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = piVar8[1] + -1;
      piVar8[1] = iVar5;
      UNLOCK();
LAB_00c35884:
      if (iVar5 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar5 = piVar8[2] + -1;
        piVar8[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0x3a4) != 0) {
    iVar5 = FUN_005f7790();
    if (iVar5 != 0) {
      FUN_00c27510(*(undefined4 *)(param_1 + 0x3a4));
    }
  }
  iVar5 = param_2;
  if (param_2 != 0) {
    iVar6 = FUN_0068f660();
    if ((iVar6 != 0) && (*(int **)(param_1 + 0x3a4) != (int *)0x0)) {
      (**(code **)(**(int **)(param_1 + 0x3a4) + 8))();
    }
  }
  FUN_00c79070(iVar5,param_3);
  if (param_3 != 0) {
    param_2 = param_1;
    puVar7 = (undefined4 *)FUN_00c32410(&uStack_1c,&param_2);
    uVar2 = *puVar7;
    uVar3 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(param_1 + 0x40c) = uVar2;
    piVar8 = *(int **)(param_1 + 0x410);
    *(undefined4 *)(param_1 + 0x410) = uVar3;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = piVar8[1] + -1;
      piVar8[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar5 = piVar8[2] + -1;
        piVar8[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    piVar8 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x410) != 0) {
      LOCK();
      piVar8 = (int *)(*(int *)(param_1 + 0x410) + 4);
      *piVar8 = *piVar8 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0x40c),*(undefined4 *)(param_1 + 0x410));
    if (*(int *)(param_1 + 0x3a4) != 0) {
      iVar5 = FUN_0068f660();
      (**(code **)(**(int **)(param_1 + 0x3a4) + 4))(iVar5);
      goto LAB_00c359cf;
    }
  }
  iVar5 = 0;
LAB_00c359cf:
  if (((*(int *)(param_1 + 0x3a4) != 0) && (*(char *)(param_1 + 900) != '\0')) && (iVar5 != 0)) {
    cVar4 = FUN_00c28090(*(int *)(param_1 + 0x3a4));
    if (cVar4 == '\0') {
      FUN_00c36030(0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27932 ; VA 0x00c35a30 ; FUN_00c35a30 */

void FUN_00c35a30(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 27933 ; VA 0x00c35a60 ; FUN_00c35a60 */

void FUN_00c35a60(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 27934 ; VA 0x00c35a90 ; FUN_00c35a90 */

void __thiscall FUN_00c35a90(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_40 [24];
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808ae0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8 = 0;
    cVar1 = FUN_0087d0d0(auStack_28);
    if (cVar1 != '\0') {
      FUN_0054ef60(auStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_40);
      FUN_005507b0();
    }
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27935 ; VA 0x00c35b60 ; FUN_00c35b60 */

void __fastcall FUN_00c35b60(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x3a4) != 0) {
    iVar1 = FUN_005f7790();
    if (iVar1 != 0) {
      FUN_00c27510(*(undefined4 *)(param_1 + 0x3a4));
    }
  }
  return;
}



/* FUNCTION 27936 ; VA 0x00c35b90 ; FUN_00c35b90 */

void FUN_00c35b90(int param_1)

{
  char cVar1;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  cVar1 = FUN_00c378b0();
  if (cVar1 != '\0') {
    FUN_00c34050();
  }
  FUN_0054ef60(&param_1);
  cVar1 = FUN_00c37690();
  if (cVar1 != '\0') {
    FUN_00c34050();
  }
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_1 - *(int *)(param_1 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27937 ; VA 0x00c35c50 ; FUN_00c35c50 */

void __thiscall FUN_00c35c50(int param_1,undefined4 param_2)

{
  undefined *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_60 [24];
  int aiStack_48 [2];
  undefined auStack_40 [8];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01808b00;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  puVar1 = &stack0xfffffffc;
  if (DAT_01efa298 != '\0') {
    ExceptionList = &pvStack_1c;
    FUN_016774b0(DAT_01efa298,"VideoFrame::render2d",0);
    puVar1 = puStack_20;
  }
  puStack_20 = puVar1;
  if (*(float *)(param_1 + 0x2f0) <= DAT_018ce2f8 && DAT_018ce2f8 != *(float *)(param_1 + 0x2f0)) {
    uVar2 = FUN_00c77710(auStack_40);
    FUN_00c7b030(param_2,uVar2);
  }
  if (*(float *)(param_1 + 0x39c) <= DAT_018ce2f8 && DAT_018ce2f8 != *(float *)(param_1 + 0x39c)) {
    uStack_2c = 0;
    uStack_28 = 0;
    FUN_0054ef60(param_1 + 0x318);
    uStack_14 = 0;
    cStack_21 = FUN_00f9ca80(param_2,aiStack_48,param_1 + 0x350,&uStack_2c,1);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar4 = uStack_34 + 1;
      iVar3 = aiStack_48[0];
      if (0xfff < uVar4) {
        iVar3 = *(int *)(aiStack_48[0] + -4);
        uVar4 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    if (cStack_21 != '\0') {
      uStack_38 = uStack_2c;
      uStack_34 = uStack_28;
      FUN_0054ef60(param_1 + 0x318);
      uStack_14 = 1;
      FUN_00c35dd0(param_1 + 0x358,param_2,auStack_60,uStack_38,uStack_34);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 27938 ; VA 0x00c35dd0 ; FUN_00c35dd0 */

void __thiscall FUN_00c35dd0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  float fVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined8 uVar4;
  undefined auStack_8c [16];
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  float fStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808b24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa360) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efa360);
    if (DAT_01efa360 == -1) {
      uStack_8 = 0;
      uVar4 = FUN_0152dab0("Video","renderImage",0xffffffff);
      DAT_01efa35c = (undefined4)((ulonglong)uVar4 >> 0x20);
      DAT_01efa358 = (undefined4)uVar4;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efa360);
    }
  }
  uStack_1c = DAT_01efa358;
  uStack_4c = DAT_01efa358;
  uStack_18 = DAT_01efa35c;
  uStack_48 = DAT_01efa35c;
  uStack_44 = FUN_0152d930(DAT_01efa358,DAT_01efa35c);
  uStack_8 = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  FUN_00f9c280(&uStack_2c,&uStack_24,param_1 + 0xfd,param_1 + 0xff,&stack0x00000010);
  fStack_14 = DAT_018ce2f8 - (float)param_1[0xfc];
  puVar2 = (undefined4 *)FUN_0115ee70();
  uStack_3c = *puVar2;
  uStack_38 = puVar2[1];
  uStack_34 = puVar2[2];
  fStack_30 = fStack_14;
  piVar3 = (int *)FUN_00d5be40();
  if ((piVar3 == (int *)0x0) || (fVar1 = (float)param_1[0x2a], NAN(fVar1) == (fVar1 == 0.0))) {
    puVar2 = (undefined4 *)FUN_00d5c5d0(auStack_8c);
    uStack_6c = *puVar2;
    uStack_68 = puVar2[1];
    uStack_64 = puVar2[2];
    uStack_60 = puVar2[3];
    FUN_00f9c600(param_3,1,&uStack_6c,&uStack_2c,&uStack_24,&uStack_3c,param_1 + 0x2a,0,0);
  }
  else {
    puVar2 = (undefined4 *)(**(code **)(*piVar3 + 0xd4))(auStack_7c);
    uStack_5c = *puVar2;
    uStack_58 = puVar2[1];
    uStack_54 = puVar2[2];
    uStack_50 = puVar2[3];
    puVar2 = (undefined4 *)FUN_00d5c5d0(auStack_8c);
    uStack_6c = *puVar2;
    uStack_68 = puVar2[1];
    uStack_64 = puVar2[2];
    uStack_60 = puVar2[3];
    FUN_00f9c440(param_3,1,&uStack_6c,&uStack_2c,&uStack_24,&uStack_3c,&uStack_5c,0,0);
  }
  (**(code **)(*param_1 + 0x118))(param_3);
  uStack_8 = 2;
  FUN_0152dda0(uStack_1c,uStack_18,uStack_44);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27939 ; VA 0x00c36000 ; FUN_00c36000 */

void __thiscall FUN_00c36000(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x390)) {
    *(char *)(param_1 + 0x390) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27940 ; VA 0x00c36030 ; FUN_00c36030 */

void __thiscall FUN_00c36030(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  undefined uVar5;
  
  if ((char)param_2 != *(char *)(param_1 + 900)) {
    *(char *)(param_1 + 900) = (char)param_2;
    if (*(int *)(param_1 + 0x3a4) != 0) {
      FUN_00d46ea0(param_2);
      pcVar4 = (char *)(param_1 + 0x36c);
      if (*(char *)(param_1 + 900) == '\0') {
        if (0xf < *(uint *)(param_1 + 0x380)) {
          pcVar4 = *(char **)pcVar4;
        }
        uVar5 = 0;
        pcVar3 = pcVar4;
        do {
          cVar1 = *pcVar3;
          pcVar3 = pcVar3 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(pcVar4,(int)pcVar3 - (int)(pcVar4 + 1));
      }
      else {
        if (0xf < *(uint *)(param_1 + 0x380)) {
          pcVar4 = *(char **)pcVar4;
        }
        uVar5 = 0;
        pcVar3 = pcVar4;
        do {
          cVar1 = *pcVar3;
          pcVar3 = pcVar3 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(pcVar4,(int)pcVar3 - (int)(pcVar4 + 1));
      }
      FUN_006ecaa0(uVar5);
    }
    FUN_008a4940(&DAT_021348e0);
    if (*(char *)(param_1 + 900) != '\0') {
      FUN_00c37580();
      return;
    }
    if (*(int *)(param_1 + 0x3a4) != 0) {
      iVar2 = FUN_005f7790();
      if (iVar2 != 0) {
        FUN_00c27510(*(undefined4 *)(param_1 + 0x3a4));
      }
    }
  }
  return;
}



/* FUNCTION 27941 ; VA 0x00c36140 ; FUN_00c36140 */

void __thiscall FUN_00c36140(int *param_1,undefined3 param_2)

{
  undefined uVar1;
  code *pcVar2;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53a1;
  pvStack_10 = ExceptionList;
  if ((char)param_2 != *(char *)(param_1 + 0xe1)) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 0x416) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_00c341f0(param_1,*(undefined8 *)(param_1 + 0xe2));
    }
    FUN_00c36030();
    if (*(char *)((int)param_1 + 0x416) != '\0') {
      uVar1 = *(undefined *)(param_1 + 0xe1);
      uStack_14 = CONCAT31(uStack_14._1_3_,uVar1);
      _param_2 = CONCAT13(uVar1,param_2);
      uStack_28 = 0;
      uStack_24 = 0;
      FUN_005e6780(uStack_14);
      pcVar2 = *(code **)(*param_1 + 8);
      uStack_f8 = FUN_0088daf0();
      uStack_f4 = 0;
      uStack_f0 = uVar1;
      uStack_f4 = FUN_005c9ef0();
      uStack_8 = 0;
      uStack_20 = 0;
      uStack_1c = 0;
      uStack_18 = 0;
      FUN_00687980(&uStack_f8,&uStack_28,_param_2);
      uStack_8._0_1_ = 1;
      (*pcVar2)(&DAT_02134c00,&uStack_20,&uStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00577b20();
      uStack_8 = 0xffffffff;
      FUN_016f32d1(&uStack_f8,0xd0,1,FUN_0056e5b0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27942 ; VA 0x00c36290 ; FUN_00c36290 */

bool __thiscall FUN_00c36290(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808908;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00c33b80(param_3,auStack_28);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_28);
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return cVar1 != '\0';
}



/* FUNCTION 27943 ; VA 0x00c36340 ; FUN_00c36340 */

void __thiscall FUN_00c36340(int param_1,double param_2)

{
  int iVar1;
  
  if ((NAN(param_2) || NAN(*(double *)(param_1 + 0x388))) ==
      (param_2 == *(double *)(param_1 + 0x388))) {
    *(double *)(param_1 + 0x388) = param_2;
    if (*(int *)(param_1 + 0x3a4) != 0) {
      iVar1 = FUN_00d46ee0(param_2);
      if ((iVar1 != 0) && (DAT_01d84e8e != '\0')) {
        FUN_016774b0(DAT_01d84e8e,"Failed to set TimePosition",0);
      }
    }
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 27944 ; VA 0x00c363b0 ; FUN_00c363b0 */

void __thiscall FUN_00c363b0(int param_1,double param_2)

{
  int iVar1;
  
  if ((NAN(param_2) || NAN(*(double *)(param_1 + 0x388))) ==
      (param_2 == *(double *)(param_1 + 0x388))) {
    *(double *)(param_1 + 0x388) = param_2;
    if (*(int *)(param_1 + 0x3a4) != 0) {
      iVar1 = FUN_00d46ee0(param_2);
      if ((iVar1 != 0) && (DAT_01d84e8e != '\0')) {
        FUN_016774b0(DAT_01d84e8e,"Failed to set TimePosition",0);
      }
    }
    FUN_008a4940();
  }
  if (*(char *)(param_1 + 0x416) != '\0') {
    FUN_00c341f0(param_1,*(undefined8 *)(param_1 + 0x388));
  }
  return;
}



/* FUNCTION 27945 ; VA 0x00c36440 ; FUN_00c36440 */

void FUN_00c36440(undefined4 param_1)

{
  FUN_00c7bce0(param_1);
  return;
}



/* FUNCTION 27946 ; VA 0x00c36460 ; FUN_00c36460 */

void __thiscall FUN_00c36460(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808908;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c32310(aiStack_28);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27947 ; VA 0x00c364f0 ; FUN_00c364f0 */

void __thiscall FUN_00c364f0(int param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_01808b40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar1 = (undefined4 *)(param_1 + 0x36c);
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00684460();
  if (cVar4 != '\0') {
    if (*(int *)(param_1 + 0x3a4) != 0) {
      iVar5 = FUN_00d43150();
      if ((iVar5 != 0) && (DAT_01d84e8e != '\0')) {
        FUN_016774b0();
      }
      if ((*(int *)(param_1 + 0x3a4) != 0) && (iVar5 = FUN_005f7790(), iVar5 != 0)) {
        FUN_00c27510();
      }
      (**(code **)(**(int **)(param_1 + 0x3a4) + 8))();
      *(undefined4 *)(param_1 + 0x3a4) = 0;
      piVar2 = *(int **)(param_1 + 0x3a8);
      *(undefined4 *)(param_1 + 0x3a8) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar5 = piVar2[1] + -1;
        piVar2[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar5 = piVar2[2] + -1;
          piVar2[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_008a4940();
      FUN_008a4940();
      if (*(char *)(param_1 + 900) != '\0') {
        FUN_0054ef60(puVar1);
        FUN_006ecaa0();
      }
      iVar5 = FUN_016dee6d();
      if (iVar5 != 0) {
        FUN_016df3c9();
      }
      puVar3 = *(undefined4 **)(param_1 + 0x404);
      puVar6 = puVar3;
      if (0xf < (uint)puVar3[5]) {
        puVar6 = (undefined4 *)*puVar3;
      }
      puVar3[4] = 0;
      *(undefined *)puVar6 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar5 = FUN_016deec8();
      if (iVar5 != 0) {
        FUN_016df3c9();
      }
      uStack_8 = uStack_8 & 0xffffff00;
    }
    if (DAT_01d6860c != '\0') {
      iVar5 = FUN_016dee6d();
      if (iVar5 != 0) {
        FUN_016df3c9();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00c34300();
      FUN_0054ef60(puVar1);
      cVar4 = FUN_00c377c0();
      if (cVar4 == '\0') {
        FUN_00c34300();
        FUN_0054ef60(puVar1);
        FUN_00c35b90();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      iVar5 = FUN_016deec8();
      if (iVar5 != 0) {
        FUN_016df3c9();
      }
      uStack_8 = uStack_8 & 0xffffff00;
    }
    if (puVar1 != &param_2) {
      FUN_005542c0();
    }
    FUN_008a4940();
  }
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27948 ; VA 0x00c36760 ; FUN_00c36760 */

void __thiscall FUN_00c36760(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce320;
  if (fVar1 <= DAT_018ce320) {
    fVar2 = fVar1;
  }
  if ((NAN(fVar2) || NAN(*(float *)(param_1 + 0x394))) == (fVar2 == *(float *)(param_1 + 0x394))) {
    *(float *)(param_1 + 0x394) = fVar2;
    if (*(int *)(param_1 + 0x3a4) != 0) {
      FUN_00d47490(fVar2);
    }
    FUN_008a4940(&DAT_02134a30);
  }
  return;
}



/* FUNCTION 27949 ; VA 0x00c367c0 ; FUN_00c367c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c367c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa58c) {
    FUN_016f3809(&DAT_01efa58c);
    if (DAT_01efa58c == -1) {
      _DAT_01efa580 = FUN_005c65f0;
      _DAT_01efa584 = FUN_005c93a0;
      _DAT_01efa588 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01efa58c);
    }
  }
  return &DAT_01efa580;
}



/* FUNCTION 27950 ; VA 0x00c36830 ; FUN_00c36830 */

void __fastcall FUN_00c36830(undefined4 *param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  int *piVar6;
  undefined4 uStack_3d8;
  undefined ***pppuStack_3d4;
  undefined4 uStack_3d0;
  undefined **ppuStack_3cc;
  undefined4 ****ppppuStack_3c8;
  undefined4 ****ppppuStack_3c4;
  undefined auStack_3b4 [108];
  undefined auStack_348 [108];
  undefined auStack_2dc [108];
  undefined auStack_270 [108];
  undefined auStack_204 [108];
  undefined auStack_198 [108];
  undefined *puStack_12c;
  int *piStack_128;
  undefined auStack_10c [72];
  undefined4 uStack_c4;
  undefined auStack_c0 [24];
  undefined auStack_a8 [24];
  undefined auStack_90 [24];
  undefined4 uStack_78;
  undefined *puStack_70;
  int *piStack_6c;
  undefined4 *puStack_68;
  undefined4 ****appppuStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  undefined *puStack_4c;
  int *piStack_48;
  undefined **appuStack_44 [2];
  undefined *apuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined *puStack_24;
  char cStack_1d;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808c23;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_14 = &stack0xfffffc40;
  ppppuStack_3c4 = (undefined4 ****)(param_1 + 0xdb);
  ppppuStack_3c8 = (undefined4 ****)0xc3686f;
  ExceptionList = &pvStack_10;
  puStack_68 = param_1;
  FUN_0054ef60();
  puStack_70 = (undefined *)0x0;
  piStack_6c = (int *)0x0;
  ppppuStack_3c4 = (undefined4 ****)&DAT_01efa2ac;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_4c = &DAT_01efa2ac;
  piStack_48 = (int *)((uint)piStack_48 & 0xffffff00);
  ppppuStack_3c8 = (undefined4 ****)0xc36896;
  ppppuStack_3c4 = (undefined4 ****)FUN_016dee6d();
  if (ppppuStack_3c4 != (undefined4 ****)0x0) {
    ppppuStack_3c8 = (undefined4 ****)0xc368a3;
    FUN_016df3c9();
  }
  piStack_48 = (int *)CONCAT31(piStack_48._1_3_,1);
  uStack_8._0_1_ = 3;
  if (DAT_01d6860c == '\0') {
LAB_00c36934:
    ppppuStack_3c4 = (undefined4 ****)param_1[0x101];
    ppppuStack_3c8 = appppuStack_64;
    ppuStack_3cc = (undefined **)0xc36943;
    cVar2 = FUN_009cbaa0();
    if (cVar2 == '\0') {
      if ((undefined4 *****)param_1[0x101] != appppuStack_64) {
        ppppuStack_3c4 = (undefined4 ****)uStack_54;
        ppppuStack_3c8 = appppuStack_64;
        if (0xf < uStack_50) {
          ppppuStack_3c8 = appppuStack_64[0];
        }
        ppuStack_3cc = (undefined **)0xc3696e;
        FUN_005542c0();
      }
      iVar4 = param_1[0x101];
      *(undefined4 *)(iVar4 + 0x18) = 0;
      piVar6 = *(int **)(iVar4 + 0x1c);
      *(undefined4 *)(iVar4 + 0x1c) = 0;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar4 = piVar6[1] + -1;
        piVar6[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppppuStack_3c4 = (undefined4 ****)0xc3699b;
          (**(code **)*piVar6)();
          LOCK();
          iVar4 = piVar6[2] + -1;
          piVar6[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppppuStack_3c4 = (undefined4 ****)0xc369ab;
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar6 = (int *)param_1[0x102];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
        piVar6 = (int *)param_1[0x102];
      }
      puStack_70 = (undefined *)param_1[0x101];
      piStack_6c = piVar6;
      puStack_24 = puStack_70;
      if (DAT_01d6860c != '\0') {
        ppppuStack_3c4 = (undefined4 ****)0xc369e0;
        piStack_18 = (int *)FUN_00c34300();
        ppppuStack_3c4 = appppuStack_64;
        ppppuStack_3c8 = (undefined4 ****)0xc369ef;
        FUN_0054ef60();
        ppppuStack_3c4 = (undefined4 ****)apuStack_3c;
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        ppppuStack_3c8 = (undefined4 ****)0xc36a02;
        piStack_18 = (int *)FUN_00c33470();
        iVar4 = param_1[0x102];
        if (iVar4 != 0) {
          LOCK();
          *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
          UNLOCK();
          iVar4 = param_1[0x102];
        }
        *piStack_18 = param_1[0x101];
        piStack_1c = (int *)piStack_18[1];
        piStack_18[1] = iVar4;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar4 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppppuStack_3c4 = (undefined4 ****)0xc36a40;
            (**(code **)*piStack_1c)();
            LOCK();
            iVar4 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppppuStack_3c4 = (undefined4 ****)0xc36a51;
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
        uStack_8._0_1_ = 3;
        if (0xf < uStack_28) {
          ppppuStack_3c4 = (undefined4 ****)(uStack_28 + 1);
          puVar5 = apuStack_3c[0];
          if (0xfff < ppppuStack_3c4) {
            puVar5 = *(undefined **)(apuStack_3c[0] + -4);
            ppppuStack_3c4 = (undefined4 ****)(uStack_28 + 0x24);
            if ((undefined *)0x1f < apuStack_3c[0] + (-4 - (int)puVar5)) {
                    /* WARNING: Subroutine does not return */
              ppppuStack_3c4 = (undefined4 ****)&UNK_00c36f17;
              FUN_017167a3();
            }
          }
          ppuStack_3cc = (undefined **)0xc36a86;
          ppppuStack_3c8 = (undefined4 ****)puVar5;
          FUN_01674ea0();
        }
      }
      ppppuStack_3c4 = (undefined4 ****)&DAT_01efa2ac;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      ppppuStack_3c8 = (undefined4 ****)0xc36a97;
      ppppuStack_3c4 = (undefined4 ****)FUN_016deec8();
      if (ppppuStack_3c4 != (undefined4 ****)0x0) {
        ppppuStack_3c8 = (undefined4 ****)0xc36aa4;
        FUN_016df3c9();
      }
      piStack_18 = (int *)param_1[0xd];
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      piVar3 = param_1;
      if ((piStack_18 != (undefined4 *)0x0) && (piVar3 = piStack_18, piStack_18[0xd] != 0)) {
        ppppuStack_3c4 = (undefined4 ****)0xc36ac1;
        piVar3 = (int *)FUN_005c8ac0();
      }
      piStack_18 = piVar3;
      if (piStack_18 == (undefined4 *)0x0) {
LAB_00c36e24:
        if (DAT_01efa299 != 0) {
          ppppuStack_3c4 = (undefined4 ****)0x0;
          ppuStack_3cc = (undefined **)(uint)DAT_01efa299;
          ppppuStack_3c8 = (undefined4 ****)0x18fc0e0;
          uStack_3d0 = 0xc36e3d;
          FUN_016774b0();
        }
      }
      else {
        piStack_1c = (int *)piStack_18[3];
        ppppuStack_3c4 = (undefined4 ****)0xc36ade;
        iVar4 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar4 + 0x1da) <
            (uint)*(ushort *)(piStack_1c + 0x76) - (uint)*(ushort *)(iVar4 + 0x1d8))
        goto LAB_00c36e24;
        ppppuStack_3c4 = (undefined4 ****)&LAB_005c2460;
        ppppuStack_3c8 = (undefined4 ****)&DAT_01ea8c5c;
        ppuStack_3cc = (undefined **)0xc36b0f;
        FUN_005789c0();
        ppppuStack_3c4 = (undefined4 ****)0xc36b17;
        ppppuStack_3c4 = (undefined4 ****)FUN_005c36d0();
        ppppuStack_3c8 = (undefined4 ****)0xc36b20;
        piStack_1c = (int *)FUN_008aa140();
        if (*piStack_1c == 0) {
          ppppuStack_3c4 = (undefined4 ****)0xc36b31;
          ppppuStack_3c4 = (undefined4 ****)FUN_008bd920();
          ppppuStack_3c8 = (undefined4 ****)&puStack_4c;
          ppuStack_3cc = (undefined **)0xc36b3e;
          piVar3 = (int *)FUN_008a9ba0();
          iVar4 = *piVar3;
          iVar1 = piVar3[1];
          *piVar3 = 0;
          piVar3[1] = 0;
          *piStack_1c = iVar4;
          piStack_18 = (int *)piStack_1c[1];
          piStack_1c[1] = iVar1;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_18[1] + -1;
            piStack_18[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppppuStack_3c4 = (undefined4 ****)0xc36b6f;
              (**(code **)*piStack_18)();
              LOCK();
              iVar4 = piStack_18[2] + -1;
              piStack_18[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                ppppuStack_3c4 = (undefined4 ****)0xc36b80;
                (**(code **)(*piStack_18 + 4))();
              }
            }
          }
          piStack_18 = piStack_48;
          if (piStack_48 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_48[1] + -1;
            piStack_48[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppppuStack_3c4 = (undefined4 ****)0xc36b9a;
              (**(code **)*piStack_48)();
              LOCK();
              iVar4 = piStack_18[2] + -1;
              piStack_18[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                ppppuStack_3c4 = (undefined4 ****)0xc36bab;
                (**(code **)(*piStack_18 + 4))();
              }
            }
          }
        }
        piStack_18 = (int *)*piStack_1c;
        if (piStack_18 == (undefined4 *)0x0) goto LAB_00c36e24;
        ppppuStack_3c4 = (undefined4 ****)0x5;
        ppppuStack_3c8 = (undefined4 ****)0x18dbc6c;
        uStack_2c = 0;
        uStack_28 = 0xf;
        apuStack_3c[0] = (undefined *)((uint)apuStack_3c[0] & 0xffffff00);
        ppuStack_3cc = (undefined **)0xc36bdc;
        FUN_005542c0();
        ppppuStack_3c4 = (undefined4 ****)apuStack_3c;
        uStack_8._0_1_ = 8;
        ppuStack_3cc = (undefined **)0xc36bf0;
        ppppuStack_3c8 = (undefined4 ****)param_1;
        FUN_00d10320();
        ppppuStack_3c4 = (undefined4 ****)0xc36bf8;
        FUN_005507b0();
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[2] = piVar6[2] + 1;
          UNLOCK();
        }
        puStack_12c = puStack_24;
        ppppuStack_3c4 = appppuStack_64;
        uStack_8._0_1_ = 0xb;
        ppppuStack_3c8 = (undefined4 ****)0xc36c36;
        piStack_128 = piVar6;
        FUN_0054ef60();
        puStack_24 = auStack_10c;
        uStack_8._0_1_ = 0xc;
        ppppuStack_3c4 = (undefined4 ****)auStack_c0;
        ppppuStack_3c8 = (undefined4 ****)0xc36c55;
        FUN_0054ef60();
        ppppuStack_3c4 = (undefined4 ****)auStack_a8;
        uStack_8._0_1_ = 0xd;
        ppppuStack_3c8 = (undefined4 ****)0xc36c6b;
        FUN_0054ef60();
        ppppuStack_3c4 = (undefined4 ****)auStack_90;
        uStack_8._0_1_ = 0xe;
        ppppuStack_3c8 = (undefined4 ****)0xc36c81;
        FUN_0054ef60();
        uStack_c4 = uStack_78;
        ppppuStack_3c4 = (undefined4 ****)&puStack_12c;
        uStack_8._0_1_ = 0xf;
        ppppuStack_3c8 = (undefined4 ****)0xc36ca0;
        FUN_00c32530();
        ppppuStack_3c4 = (undefined4 ****)auStack_3b4;
        uStack_8._0_1_ = 0x10;
        ppppuStack_3c8 = (undefined4 ****)0xc36cb6;
        FUN_00c32530();
        ppppuStack_3c4 = (undefined4 ****)auStack_348;
        uStack_8._0_1_ = 0x11;
        appuStack_44[0] = (undefined **)0x0;
        ppppuStack_3c8 = (undefined4 ****)0xc36cd3;
        FUN_00c32530();
        ppppuStack_3c4 = (undefined4 ****)auStack_2dc;
        uStack_8._0_1_ = 0x12;
        ppppuStack_3c8 = (undefined4 ****)0xc36ce9;
        FUN_00c32530();
        ppppuStack_3c4 = (undefined4 ****)auStack_270;
        uStack_8._0_1_ = 0x13;
        ppppuStack_3c8 = (undefined4 ****)0xc36cff;
        FUN_00c32530();
        ppppuStack_3c4 = (undefined4 ****)auStack_198;
        uStack_8._0_1_ = 0x14;
        ppppuStack_3c8 = (undefined4 ****)0xc36d0f;
        cVar2 = FUN_00585a40();
        if (cVar2 == '\0') {
          ppppuStack_3c4 = (undefined4 ****)auStack_198;
          ppppuStack_3c8 = (undefined4 ****)0xc36d28;
          FUN_00c32530();
          ppppuStack_3c4 = (undefined4 ****)0x6c;
          uStack_8._0_1_ = 0x15;
          ppppuStack_3c8 = (undefined4 ****)0xc36d33;
          puStack_24 = (undefined *)FUN_01674e20();
          uStack_8._0_1_ = 0x16;
          if (puStack_24 == (undefined *)0x0) {
            apuStack_3c[0] = (undefined *)0x0;
          }
          else {
            ppppuStack_3c4 = (undefined4 ****)auStack_204;
            ppppuStack_3c8 = (undefined4 ****)0xc36d4f;
            apuStack_3c[0] = (undefined *)FUN_00c32530();
          }
          ppppuStack_3c4 = (undefined4 ****)0xc36d61;
          FUN_00c329c0();
          ppppuStack_3c4 = (undefined4 ****)0xc36d6c;
          FUN_00c329c0();
          cStack_1d = '\x01';
        }
        else {
          ppppuStack_3c4 = (undefined4 ****)0xc36d7d;
          FUN_00c329c0();
          cStack_1d = '\0';
        }
        ppppuStack_3c4 = (undefined4 ****)0xc36d8c;
        FUN_00c329c0();
        appuStack_44[0] = &PTR_FUN_019677f8;
        if (cStack_1d == '\0') {
          appuStack_44[0] = (undefined **)0x0;
        }
        ppppuStack_3c4 = (undefined4 ****)0xc36da7;
        FUN_00c329c0();
        ppppuStack_3c4 = (undefined4 ****)0xc36db2;
        FUN_00c329c0();
        ppppuStack_3c4 = (undefined4 ****)0xc36dbd;
        FUN_00c329c0();
        uStack_8._0_1_ = 0x17;
        ppppuStack_3c4 = (undefined4 ****)0xc36dc6;
        uStack_3d0 = FUN_008ccdc0();
        ppppuStack_3c4 = (undefined4 ****)0x1;
        ppppuStack_3c8 = (undefined4 ****)0x0;
        ppuStack_3cc = (undefined **)&DAT_01d62f20;
        pppuStack_3d4 = appuStack_44;
        uStack_3d8 = 0x425c0000;
        FUN_008cd330(appppuStack_64);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
        if (((appuStack_44[0] != (undefined **)0x0) && (((uint)appuStack_44[0] & 1) == 0)) &&
           (*(code **)((uint)appuStack_44[0] & 0xfffffffe) != (code *)0x0)) {
          ppuStack_3cc = apuStack_3c;
          ppppuStack_3c4 = (undefined4 ****)0x2;
          uStack_3d0 = 0xc36e09;
          ppppuStack_3c8 = (undefined4 ****)ppuStack_3cc;
          (**(code **)((uint)appuStack_44[0] & 0xfffffffe))();
        }
        ppppuStack_3c4 = (undefined4 ****)0xc36e17;
        FUN_00c329c0();
        ppppuStack_3c4 = (undefined4 ****)0xc36e22;
        FUN_00637950();
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar3 = piVar6 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          ppppuStack_3c4 = (undefined4 ****)0xc36e5b;
          (**(code **)(*piVar6 + 4))();
        }
      }
      goto LAB_00c3691b;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
  }
  else {
    ppppuStack_3c4 = (undefined4 ****)0xc368bc;
    FUN_00c34300();
    puStack_24 = (undefined *)&uStack_3d8;
    FUN_0054ef60(appppuStack_64);
    cVar2 = FUN_00c37690();
    if (cVar2 == '\0') {
      ppppuStack_3c4 = (undefined4 ****)0xc368df;
      FUN_00c34300();
      puStack_24 = (undefined *)&uStack_3d8;
      FUN_0054ef60(appppuStack_64);
      cVar2 = FUN_00c378b0();
      if (cVar2 == '\0') goto LAB_00c36934;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
  }
  ppppuStack_3c4 = (undefined4 ****)&DAT_01efa2ac;
  ppppuStack_3c8 = (undefined4 ****)0xc3690b;
  ppppuStack_3c4 = (undefined4 ****)FUN_016deec8();
  if (ppppuStack_3c4 != (undefined4 ****)0x0) {
    ppppuStack_3c8 = (undefined4 ****)0xc36918;
    FUN_016df3c9();
  }
LAB_00c3691b:
  ppppuStack_3c4 = (undefined4 ****)0xc36923;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27951 ; VA 0x00c36e60 ; Catch@00c36e60 */

undefined4 Catch_00c36e60(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  FUN_005542c0("Video",5);
  iVar1 = *(int *)(unaff_EBP + -100);
  *(undefined *)(unaff_EBP + -4) = 0x1a;
  FUN_00d10320(iVar1,unaff_EBP + -0x38);
  *(undefined *)(unaff_EBP + -4) = 0x1c;
  FUN_005507b0();
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x70) + 4))();
  FUN_00c34fc0(iVar1 + 0x36c,unaff_EBP + -0xbc,uVar2);
  FUN_005dbd10(&DAT_01efa2ac);
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  FUN_005511f0(unaff_EBP + -0x38);
  FUN_005507b0();
  FUN_005dbff0();
  FUN_00637950();
  return 0xc36923;
}



/* FUNCTION 27952 ; VA 0x00c36f20 ; FUN_00c36f20 */

void __fastcall FUN_00c36f20(int *param_1)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  float10 fVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined4 in_stack_ffffffa0;
  undefined4 in_stack_ffffffa4;
  undefined4 uVar12;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808c6a;
  pvStack_10 = ExceptionList;
  iVar7 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar7 + 0x34) < DAT_01efa340) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01efa340 == -1)) {
    uStack_8 = 0;
    uVar10 = FUN_0152dab0("Video",&DAT_019675fc,0xffffffff);
    DAT_01efa33c = (undefined4)((ulonglong)uVar10 >> 0x20);
    DAT_01efa338 = (undefined4)uVar10;
    uStack_8 = 0xffffffff;
    in_stack_ffffffa4 = 0xc37491;
    FUN_016f37bf(&DAT_01efa340);
  }
  uStack_24 = DAT_01efa338;
  uStack_20 = DAT_01efa33c;
  uVar10 = FUN_0152d930(DAT_01efa338,DAT_01efa33c);
  uStack_8 = 1;
  if ((*(int *)(iVar7 + 0x34) < DAT_01efa350) && (FUN_016f3809(), DAT_01efa350 == -1)) {
    uStack_8._0_1_ = 2;
    uVar11 = FUN_0152da50();
    DAT_01efa34c = (undefined4)((ulonglong)uVar11 >> 0x20);
    DAT_01efa348 = (undefined4)uVar11;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01efa350);
  }
  piVar8 = param_1 + 0xdb;
  piVar4 = piVar8;
  if (0xf < (uint)param_1[0xe0]) {
    piVar4 = (int *)*piVar8;
  }
  uVar12 = 0xc36fc5;
  FUN_0152d740(DAT_01efa348,DAT_01efa34c,piVar4);
  if (DAT_01efa298 != '\0') {
    uVar3 = FUN_01682de0();
    uVar12 = 0xc36fe9;
    FUN_016774b0(DAT_01efa298,"VideoFrame::step() %ims",uVar3);
  }
  if (param_1 != (int *)0x0) {
    piStack_1c = (int *)param_1[0xd];
    piVar4 = param_1;
    if ((piStack_1c != (int *)0x0) && (piVar4 = piStack_1c, piStack_1c[0xd] != 0)) {
      piVar4 = (int *)FUN_005c8ac0();
    }
    piStack_1c = piVar4;
    if ((piStack_1c != (int *)0x0) &&
       (iVar7 = piStack_1c[3], iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      uVar3 = 0xc37052;
      FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
      FUN_00560d40();
      piStack_14 = (int *)FUN_008aa140();
      if (*piStack_14 == 0) {
        uVar6 = FUN_00995770();
        uVar3 = 0xc37084;
        piVar4 = (int *)FUN_008a9ba0(&uStack_2c,uVar6);
        iVar7 = *piVar4;
        iVar5 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        *piStack_14 = iVar7;
        piStack_1c = (int *)piStack_14[1];
        piStack_14[1] = iVar5;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar7 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar7 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
        piStack_1c = piStack_28;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_28[1] + -1;
          piStack_28[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            iVar7 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
      if (*piStack_14 != 0) {
        if (param_1[0xe9] == 0) {
          if (param_1[0xdf] != 0) {
            FUN_00c36830();
            FUN_00c34480();
            uStack_8._0_1_ = 5;
            if (iStack_18 != 0) {
              uVar12 = 0xc3725a;
              piVar4 = (int *)FUN_01674e20();
              uStack_8._0_1_ = 6;
              piStack_1c = piVar4;
              if (piVar4 == (int *)0x0) {
                piVar4 = (int *)0x0;
              }
              else {
                piVar4[1] = 1;
                piVar4[2] = 1;
                *piVar4 = (int)std::_Ref_count_obj<class_RBX::VideoStream>::vftable;
                FUN_00d42560();
              }
              uStack_8._0_1_ = 5;
              if ((piVar4 + 4 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))
                 ) {
                if (piVar4 != (int *)0x0) {
                  LOCK();
                  piVar4[1] = piVar4[1] + 1;
                  UNLOCK();
                  if (piVar4 != (int *)0x0) {
                    LOCK();
                    piVar4[2] = piVar4[2] + 1;
                    UNLOCK();
                  }
                }
                piVar4[6] = (int)(piVar4 + 4);
                piVar1 = (int *)piVar4[7];
                piVar4[7] = (int)piVar4;
                if (piVar1 != (int *)0x0) {
                  LOCK();
                  iVar7 = piVar1[2] + -1;
                  piVar1[2] = iVar7;
                  UNLOCK();
                  if (iVar7 == 0) {
                    (**(code **)(*piVar1 + 4))();
                  }
                }
                if (piVar4 != (int *)0x0) {
                  LOCK();
                  iVar7 = piVar4[1] + -1;
                  piVar4[1] = iVar7;
                  UNLOCK();
                  if (iVar7 == 0) {
                    (**(code **)*piVar4)();
                    LOCK();
                    iVar7 = piVar4[2] + -1;
                    piVar4[2] = iVar7;
                    UNLOCK();
                    if (iVar7 == 0) {
                      (**(code **)(*piVar4 + 4))();
                    }
                  }
                }
              }
              uStack_2c = 0;
              param_1[0xe9] = (int)(piVar4 + 4);
              piStack_1c = (int *)param_1[0xea];
              piStack_28 = (int *)0x0;
              param_1[0xea] = (int)piVar4;
              if (piStack_1c != (int *)0x0) {
                LOCK();
                iVar7 = piStack_1c[1] + -1;
                piStack_1c[1] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  (**(code **)*piStack_1c)();
                  LOCK();
                  piVar4 = piStack_1c + 2;
                  iVar7 = *piVar4;
                  *piVar4 = *piVar4 + -1;
                  UNLOCK();
                  if (iVar7 == 1) {
                    (**(code **)(*piStack_1c + 4))();
                  }
                }
              }
              uVar11 = CONCAT44(0xc37345,uVar12);
              FUN_00550b30();
              FUN_00557fc0(&iStack_18);
              iVar7 = FUN_00d454f0(piVar8,uVar11);
              if (iVar7 != 0) {
                if (DAT_01d84e8e != '\0') {
                  FUN_016774b0(DAT_01d84e8e,"Failed to open video",0);
                }
                FUN_00c35b60();
                (**(code **)(*(int *)param_1[0xe9] + 8))();
                FUN_0058a2b0();
                FUN_00550b30();
                goto LAB_00c37417;
              }
              if (param_1[0xe9] != 0) {
                FUN_00c355d0();
              }
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            FUN_00550b30();
          }
        }
        else {
          FUN_00d46ea0();
          iVar7 = FUN_00d46550();
          fVar9 = (float10)FUN_00d44bd0();
          *(double *)(param_1 + 0xe2) = (double)fVar9;
          if (iVar7 != 0) {
            if (DAT_01d84e8e != '\0') {
              FUN_016774b0(DAT_01d84e8e,"Failed to step video",0);
            }
            goto LAB_00c37417;
          }
          cVar2 = FUN_00d44d30();
          if ((cVar2 != '\0') && (*(char *)(param_1 + 0xe1) != '\0')) {
            if (*(char *)(param_1 + 0xe4) == '\0') {
              uVar11 = 0xc37203;
              FUN_00c36030();
              if (0xf < (uint)param_1[0xe0]) {
                piVar8 = (int *)*piVar8;
              }
              FUN_0054eff0(piVar8);
              FUN_006ecaa0(in_stack_ffffffa0,in_stack_ffffffa4,uVar12,uVar3,uVar11);
            }
            else {
              uVar6 = 0xc371c7;
              uVar3 = FUN_00c36340(0);
              uVar11 = CONCAT44(CONCAT31((int3)((uint)uVar3 >> 8),*(undefined *)(param_1 + 0xe1)),
                                0xc371d9);
              FUN_00d46ea0();
              if (0xf < (uint)param_1[0xe0]) {
                piVar8 = (int *)*piVar8;
              }
              FUN_0054eff0(piVar8);
              FUN_006ecaa0(in_stack_ffffffa0,in_stack_ffffffa4,uVar12,uVar6,uVar11);
            }
          }
        }
        FUN_00c375d0();
        if (DAT_01efa298 != '\0') {
          FUN_016774d0(DAT_01efa298,"TIME_POS %f",(float)*(double *)(param_1 + 0xe2),0,0,0);
        }
      }
    }
  }
LAB_00c37417:
  uStack_8 = 8;
  FUN_0152dda0(uStack_24,uStack_20,uVar10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27953 ; VA 0x00c374f0 ; FUN_00c374f0 */

undefined4 __fastcall FUN_00c374f0(int param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807910;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01f6ac70);
  uStack_8 = 0;
  FUN_008e9840(*(undefined4 *)(param_1 + 0x128));
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00c36f20();
  FUN_008eb130();
  uStack_8 = 2;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27954 ; VA 0x00c37580 ; FUN_00c37580 */

void __fastcall FUN_00c37580(int param_1)

{
  char cVar1;
  int iVar2;
  
  if ((*(int *)(param_1 + 0x3a4) != 0) && (*(char *)(param_1 + 900) != '\0')) {
    iVar2 = FUN_005f7790();
    if (iVar2 != 0) {
      cVar1 = FUN_00c28090(*(undefined4 *)(param_1 + 0x3a4));
      if (cVar1 == '\0') {
        FUN_0086f2f0(2,"At most %d videos can play simultaneously.",DAT_01d6d070);
        FUN_00c36030(0);
      }
    }
  }
  return;
}



/* FUNCTION 27955 ; VA 0x00c375d0 ; FUN_00c375d0 */

void __fastcall FUN_00c375d0(int param_1)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_14;
  
  if (*(int *)(param_1 + 0x3a4) != 0) {
    cVar2 = '\0';
    iVar3 = FUN_00c322c0();
    uStack_14 = 0;
    if (((iVar3 == 0) || (*(int *)(iVar3 + 0x34) == 0)) ||
       (iVar3 = *(int *)(*(int *)(iVar3 + 0x34) + 0xc), iVar4 = FUN_00aff8c0(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
      uVar1 = 0;
    }
    else {
      cVar2 = '\x01';
      iVar3 = FUN_00b077e0();
      uVar1 = *(undefined8 *)(iVar3 + 0x24);
      uStack_14 = *(undefined4 *)(iVar3 + 0x2c);
    }
    FUN_00d46ce0(cVar2);
    if (cVar2 != '\0') {
      FUN_00d46c40(uVar1,uStack_14);
    }
    return;
  }
  return;
}



/* FUNCTION 27956 ; VA 0x00c37690 ; FUN_00c37690 */

bool __thiscall FUN_00c37690(int param_1,int param_2)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009cc8a0(&param_2);
  iVar5 = (*(uint *)(param_1 + 0x38) & uVar2) * 8;
  puVar7 = *(undefined4 **)(iVar5 + *(int *)(param_1 + 0x2c));
  while( true ) {
    puVar3 = *(undefined4 **)(param_1 + 0x24);
    if (*(undefined4 **)(iVar5 + *(int *)(param_1 + 0x2c)) != puVar3) {
      puVar3 = (undefined4 *)**(undefined4 **)(iVar5 + 4 + *(int *)(param_1 + 0x2c));
    }
    if (puVar7 == puVar3) goto LAB_00c37755;
    cVar1 = FUN_009cbaa0(puVar7 + 2,&param_2);
    puVar3 = puVar7;
    if (cVar1 != '\0') break;
    puVar7 = (undefined4 *)*puVar7;
  }
  while( true ) {
    puVar4 = *(undefined4 **)(param_1 + 0x24);
    if (*(undefined4 **)(iVar5 + *(int *)(param_1 + 0x2c)) != puVar4) {
      puVar4 = (undefined4 *)**(undefined4 **)(iVar5 + 4 + *(int *)(param_1 + 0x2c));
    }
    if ((puVar3 == puVar4) || (cVar1 = FUN_009cbaa0(&param_2,puVar3 + 2), cVar1 == '\0')) break;
    puVar3 = (undefined4 *)*puVar3;
  }
  if (puVar7 == puVar3) {
LAB_00c37755:
    puVar3 = *(undefined4 **)(param_1 + 0x24);
    puVar7 = puVar3;
  }
  iVar5 = 0;
  for (; puVar7 != puVar3; puVar7 = (undefined4 *)*puVar7) {
    iVar5 = iVar5 + 1;
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar6 = param_2;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  ExceptionList = pvStack_10;
  return iVar5 != 0;
}



/* FUNCTION 27957 ; VA 0x00c377c0 ; FUN_00c377c0 */

bool FUN_00c377c0(int param_1)

{
  char cVar1;
  int iVar2;
  bool bVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  cVar1 = FUN_00c37690();
  if (cVar1 == '\0') {
    FUN_0054ef60(&param_1);
    cVar1 = FUN_00c378b0();
    if (cVar1 == '\0') {
      bVar3 = false;
      goto LAB_00c37860;
    }
    iVar2 = FUN_00c33470();
    if (*(int *)(iVar2 + 4) != 0) {
      bVar3 = *(int *)(*(int *)(iVar2 + 4) + 4) != 1;
      goto LAB_00c37860;
    }
  }
  else {
    iVar2 = FUN_00c33470();
    if (*(int *)(iVar2 + 4) != 0) {
      bVar3 = *(int *)(*(int *)(iVar2 + 4) + 4) != 1;
      goto LAB_00c37860;
    }
  }
  bVar3 = true;
LAB_00c37860:
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_1 - *(int *)(param_1 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return bVar3;
}



/* FUNCTION 27958 ; VA 0x00c378b0 ; FUN_00c378b0 */

bool __thiscall FUN_00c378b0(int param_1,int param_2)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009cc8a0(&param_2);
  iVar5 = (*(uint *)(param_1 + 0x18) & uVar2) * 8;
  puVar7 = *(undefined4 **)(iVar5 + *(int *)(param_1 + 0xc));
  while( true ) {
    puVar3 = *(undefined4 **)(param_1 + 4);
    if (*(undefined4 **)(iVar5 + *(int *)(param_1 + 0xc)) != puVar3) {
      puVar3 = (undefined4 *)**(undefined4 **)(iVar5 + 4 + *(int *)(param_1 + 0xc));
    }
    if (puVar7 == puVar3) goto LAB_00c37975;
    cVar1 = FUN_009cbaa0(puVar7 + 2,&param_2);
    puVar3 = puVar7;
    if (cVar1 != '\0') break;
    puVar7 = (undefined4 *)*puVar7;
  }
  while( true ) {
    puVar4 = *(undefined4 **)(param_1 + 4);
    if (*(undefined4 **)(iVar5 + *(int *)(param_1 + 0xc)) != puVar4) {
      puVar4 = (undefined4 *)**(undefined4 **)(iVar5 + 4 + *(int *)(param_1 + 0xc));
    }
    if ((puVar3 == puVar4) || (cVar1 = FUN_009cbaa0(&param_2,puVar3 + 2), cVar1 == '\0')) break;
    puVar3 = (undefined4 *)*puVar3;
  }
  if (puVar7 == puVar3) {
LAB_00c37975:
    puVar3 = *(undefined4 **)(param_1 + 4);
    puVar7 = puVar3;
  }
  iVar5 = 0;
  for (; puVar7 != puVar3; puVar7 = (undefined4 *)*puVar7) {
    iVar5 = iVar5 + 1;
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar6 = param_2;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  ExceptionList = pvStack_10;
  return iVar5 != 0;
}



/* FUNCTION 27959 ; VA 0x00c379e0 ; FUN_00c379e0 */

void __thiscall FUN_00c379e0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808c9f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_28,param_2);
  uStack_40 = uStack_28;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_3c = uStack_24;
  uStack_38 = uStack_20;
  uStack_34 = uStack_1c;
  uStack_2c = uStack_14;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar1 == 0) {
    iVar1 = 0;
  }
  else {
    FUN_0054ef60(&uStack_40);
  }
  *(int *)(param_3 + 0x18) = iVar1;
  *(undefined4 *)(param_3 + 0x14) = 3;
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = uStack_40;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(uStack_40 - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (uStack_40 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = uStack_28;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(uStack_28 - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (uStack_28 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27960 ; VA 0x00c37b00 ; FUN_00c37b00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c37b00(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808cd0;
  pvStack_10 = ExceptionList;
  if (DAT_01efa5a4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa7b8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efa7b8);
      if (DAT_01efa7b8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c37c00();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_01967b8c,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efa7b0 = RBX::Creator<class_RBX::Hint>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efa5a8,&DAT_01efa7b0);
        FUN_016f3654(FUN_018940b0);
        FUN_016f37bf(&DAT_01efa7b8);
      }
    }
    DAT_01efa5a4 = &DAT_01efa5a8;
  }
  ExceptionList = pvStack_10;
  return DAT_01efa5a4;
}



/* FUNCTION 27961 ; VA 0x00c37c00 ; FUN_00c37c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c37c00(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808d00;
  pvStack_10 = ExceptionList;
  if (DAT_01efa7c0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efa9d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efa9d8);
      if (DAT_01efa9d8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Message",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efa9d0 = RBX::Creator<class_RBX::Message>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efa7c8,&DAT_01efa9d0);
        FUN_016f3654(FUN_01894110);
        FUN_016f37bf(&DAT_01efa9d8);
      }
    }
    DAT_01efa7c0 = &DAT_01efa7c8;
  }
  ExceptionList = pvStack_10;
  return DAT_01efa7c0;
}



/* FUNCTION 27962 ; VA 0x00c37d00 ; FUN_00c37d00 */

int __thiscall FUN_00c37d00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808d10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Hint*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27963 ; VA 0x00c37dd2 ; Catch_All@00c37dd2 */

void Catch_All_00c37dd2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27964 ; VA 0x00c37df0 ; FUN_00c37df0 */

int __thiscall FUN_00c37df0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808d20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Message*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27965 ; VA 0x00c37ec2 ; Catch_All@00c37ec2 */

void Catch_All_00c37ec2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27966 ; VA 0x00c37ee0 ; FUN_00c37ee0 */

undefined4 * FUN_00c37ee0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808d73;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c37b00();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x8c);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x8c);
    FUN_0089a650("Message");
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Message,class_RBX::Instance>::vftable;
    uVar4 = FUN_00c37c00();
    puVar3[3] = uVar4;
    puVar3[0x15] = RBX::IAdornable::vftable;
    puVar3[0x16] = 0xffffffff;
    puVar3[0x17] = 0xffffffff;
    puVar3[0x18] = 0xffffffff;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    puVar3[0x20] = 0;
    puVar3[0x21] = 0xf;
    *(undefined *)(puVar3 + 0x1c) = 0;
    *(undefined *)(puVar3 + 0x22) = 0;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Hint,class_RBX::Message>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::Hint,class_RBX::Message>::vftable;
    uVar4 = FUN_00c37b00();
    puVar3[3] = uVar4;
    *puVar3 = RBX::Hint::vftable;
    puVar3[0x15] = RBX::Hint::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c37d00(puVar3,param_1);
  uStack_8 = 8;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27967 ; VA 0x00c38050 ; FUN_00c38050 */

undefined4 * FUN_00c38050(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808dbb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c37c00();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x8c);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a650("Message");
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Message,class_RBX::Instance>::vftable;
    uVar4 = FUN_00c37c00();
    puVar3[3] = uVar4;
    puVar3[0x15] = RBX::IAdornable::vftable;
    puVar3[0x16] = 0xffffffff;
    puVar3[0x17] = 0xffffffff;
    puVar3[0x18] = 0xffffffff;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    *puVar3 = RBX::Message::vftable;
    puVar3[0x15] = RBX::Message::vftable;
    puVar3[0x20] = 0;
    puVar3[0x21] = 0xf;
    *(undefined *)(puVar3 + 0x1c) = 0;
    *(undefined *)(puVar3 + 0x22) = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c37df0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27968 ; VA 0x00c38190 ; FUN_00c38190 */

void __fastcall FUN_00c38190(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Hint>::vftable;
  uVar1 = FUN_00c37b00(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27969 ; VA 0x00c381d0 ; FUN_00c381d0 */

void __fastcall FUN_00c381d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Message>::vftable;
  uVar1 = FUN_00c37c00(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27970 ; VA 0x00c38210 ; FUN_00c38210 */

void __fastcall FUN_00c38210(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Message::vftable;
  param_1[0x15] = RBX::Message::vftable;
  if (DAT_01efa598 != (code *)0x0) {
    (*DAT_01efa598)(param_1);
  }
  uVar1 = param_1[0x21];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1c];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x20] = 0;
  param_1[0x21] = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27971 ; VA 0x00c382c0 ; FUN_00c382c0 */

undefined4 __thiscall FUN_00c382c0(undefined4 param_1,byte param_2)

{
  FUN_00c38210();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x8c);
  }
  return param_1;
}



/* FUNCTION 27972 ; VA 0x00c382f0 ; FUN_00c382f0 */

undefined4 * FUN_00c382f0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c37ee0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27973 ; VA 0x00c38360 ; FUN_00c38360 */

undefined4 * FUN_00c38360(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c38050(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27974 ; VA 0x00c383d0 ; FUN_00c383d0 */

void FUN_00c383d0(void)

{
  int iVar1;
  
  if (DAT_01efa7bc == 0) {
    iVar1 = FUN_00c37b00();
    DAT_01efa7bc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27975 ; VA 0x00c383f0 ; FUN_00c383f0 */

void FUN_00c383f0(void)

{
  int iVar1;
  
  if (DAT_01efa9dc == 0) {
    iVar1 = FUN_00c37c00();
    DAT_01efa9dc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27976 ; VA 0x00c38410 ; FUN_00c38410 */

int __fastcall FUN_00c38410(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (DAT_01efa594 != (code *)0x0) {
    (*DAT_01efa594)(param_1 + 0x70);
  }
  iVar1 = *(int *)(param_1 + 0x80) / 100;
  iVar2 = 1;
  if (1 < iVar1) {
    iVar2 = iVar1;
  }
  iVar1 = FUN_008a2610();
  return iVar1 + iVar2;
}



/* FUNCTION 27977 ; VA 0x00c38480 ; FUN_00c38480 */

uint FUN_00c38480(void)

{
  int iVar1;
  
  iVar1 = FUN_00c37b00();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27978 ; VA 0x00c384a0 ; FUN_00c384a0 */

uint FUN_00c384a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c37c00();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27979 ; VA 0x00c384c0 ; FUN_00c384c0 */

uint FUN_00c384c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c37b00();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27980 ; VA 0x00c384e0 ; FUN_00c384e0 */

uint FUN_00c384e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c37c00();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27981 ; VA 0x00c38500 ; FUN_00c38500 */

void __thiscall FUN_00c38500(int param_1,undefined4 param_2)

{
  char cVar1;
  
  FUN_008a3ee0(param_2);
  if (*(char *)(param_1 + 0x88) != '\0') {
    cVar1 = FUN_00fa0fb0(param_1 + 0x70,param_1,0);
    *(bool *)(param_1 + 0x88) = cVar1 == '\0';
  }
  return;
}



/* FUNCTION 27982 ; VA 0x00c38540 ; FUN_00c38540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00c38540(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  float *pfVar8;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  float fStack_3c;
  float fStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined auStack_1c [4];
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808e08;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  piStack_30 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d68620 != '\0') {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_01674e20(0x80);
    if (iVar5 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_009a1fe0();
    }
    FUN_0099fcc0(uVar6);
    FUN_01159c60();
    FUN_0114e3d0(&uStack_34);
  }
  (**(code **)(*param_2 + 0x30))(&fStack_2c);
  fStack_18 = fStack_24 - (float)param_2[3];
  fStack_2c = (float)param_2[1] + fStack_2c;
  fStack_50 = fStack_20 - (float)param_2[4];
  fStack_20 = fStack_18;
  if (fStack_18 <= fStack_2c) {
    fStack_20 = fStack_2c;
  }
  if (fStack_2c <= fStack_18) {
    fStack_18 = fStack_2c;
  }
  if ((float)param_2[2] + fStack_28 <= fStack_50) {
    fStack_50 = (float)param_2[2] + fStack_28;
  }
  fStack_14 = fStack_50 + DAT_019011dc;
  fStack_3c = (fStack_20 + fStack_18) * DAT_018ce2f4;
  fStack_38 = (fStack_14 + fStack_50) * DAT_018ce2f4;
  puVar7 = (undefined4 *)FUN_0115e910();
  uStack_4c = *puVar7;
  uStack_48 = puVar7[1];
  uStack_44 = puVar7[2];
  uStack_40 = 0x3f800000;
  fStack_58 = fStack_14;
  if (fStack_50 < fStack_14) {
    fStack_58 = fStack_50;
  }
  fStack_5c = fStack_20;
  if (fStack_18 < fStack_20) {
    fStack_5c = fStack_18;
  }
  if (fStack_50 <= fStack_14) {
    fStack_50 = fStack_14;
  }
  fStack_54 = fStack_18;
  if (fStack_18 <= fStack_20) {
    fStack_54 = fStack_20;
  }
  FUN_0114e910(&fStack_5c,&uStack_4c);
  if (*(char *)(param_1 + 0x34) != '\0') {
    cVar4 = FUN_00fa0fb0(param_1 + 0x1c,param_1 + -0x54,1);
    *(bool *)(param_1 + 0x34) = cVar4 == '\0';
  }
  uStack_70 = _DAT_018e3fc0;
  uStack_6c = _UNK_018e3fc4;
  uStack_68 = _UNK_018e3fc8;
  uStack_64 = _UNK_018e3fcc;
  uStack_60 = 0;
  uStack_4c = _DAT_018e3fd0;
  uStack_48 = _UNK_018e3fd4;
  uStack_44 = _UNK_018e3fd8;
  uStack_40 = _UNK_018e3fdc;
  fStack_24 = 0.0;
  fStack_20 = 0.0;
  uVar6 = FUN_011669a0();
  pfVar8 = (float *)FUN_0115ee70();
  fStack_5c = *pfVar8;
  fStack_58 = pfVar8[1];
  fStack_54 = pfVar8[2];
  fStack_50 = 1.0;
  iVar5 = FUN_0114e430(auStack_1c,param_1 + 0x1c,&fStack_3c,0x41600000,0,&fStack_5c,uVar6,0,2,1,
                       &fStack_24,&uStack_4c,&uStack_70,1);
  if (DAT_01d68620 != '\0') {
    FUN_0114e5f0();
    iVar5 = FUN_0114e5a0(&uStack_34);
  }
  piVar3 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_30 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27983 ; VA 0x00c387e0 ; FUN_00c387e0 */

void __fastcall FUN_00c387e0(int param_1)

{
  if (*(int *)(param_1 + 0x2c) != 0) {
    FUN_00c38800();
    return;
  }
  return;
}



/* FUNCTION 27984 ; VA 0x00c38800 ; FUN_00c38800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00c38800(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  float fVar8;
  float fVar9;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01808e28;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d68620 != '\0') {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_01674e20(0x80);
    if (iVar5 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_009a1fe0();
    }
    FUN_0099fcc0(uVar6);
    FUN_01159c60();
    FUN_0114e3d0(&uStack_18);
  }
  (**(code **)(*param_2 + 0x30))(&fStack_38);
  fStack_30 = fStack_30 - (float)param_2[3];
  fStack_38 = (float)param_2[1] + fStack_38;
  fVar9 = fStack_2c - (float)param_2[4];
  fStack_34 = (float)param_2[2] + fStack_34;
  fVar8 = fStack_30;
  if (fStack_30 <= fStack_38) {
    fVar8 = fStack_38;
  }
  if (fStack_38 <= fStack_30) {
    fStack_30 = fStack_38;
  }
  fStack_2c = fVar9;
  if (fStack_34 <= fVar9) {
    fStack_2c = fStack_34;
  }
  if (fVar9 <= fStack_34) {
    fVar9 = fStack_34;
  }
  fStack_28 = (fVar8 + fStack_30) * DAT_018ce2f4;
  fStack_24 = (fVar9 + fStack_2c) * DAT_018ce2f4;
  uStack_68 = _DAT_018fb5a0;
  uStack_64 = _UNK_018fb5a4;
  uStack_60 = _UNK_018fb5a8;
  uStack_5c = _UNK_018fb5ac;
  fStack_34 = fVar9;
  if (fStack_2c < fVar9) {
    fStack_34 = fStack_2c;
  }
  fStack_38 = fVar8;
  if (fStack_30 < fVar8) {
    fStack_38 = fStack_30;
  }
  if (fStack_2c <= fVar9) {
    fStack_2c = fVar9;
  }
  if (fStack_30 <= fVar8) {
    fStack_30 = fVar8;
  }
  FUN_0114e910(&fStack_38,&uStack_68);
  if (*(char *)(param_1 + 0x88) != '\0') {
    cVar4 = FUN_00fa0fb0(param_1 + 0x70,param_1,1);
    *(bool *)(param_1 + 0x88) = cVar4 == '\0';
  }
  uStack_7c = _DAT_018e3fc0;
  uStack_78 = _UNK_018e3fc4;
  uStack_74 = _UNK_018e3fc8;
  uStack_70 = _UNK_018e3fcc;
  uStack_6c = 0;
  uStack_48 = _DAT_018e3fd0;
  uStack_44 = _UNK_018e3fd4;
  uStack_40 = _UNK_018e3fd8;
  uStack_3c = _UNK_018e3fdc;
  uStack_20 = 0;
  uStack_1c = 0;
  puVar7 = (undefined4 *)FUN_0115e910();
  uStack_58 = *puVar7;
  uStack_54 = puVar7[1];
  uStack_50 = puVar7[2];
  uStack_4c = 0x3f800000;
  puVar7 = (undefined4 *)FUN_0115ee70();
  uStack_68 = *puVar7;
  uStack_64 = puVar7[1];
  uStack_60 = puVar7[2];
  uStack_5c = 0x3f800000;
  iVar5 = FUN_0114e430(&fStack_30,param_1 + 0x70,&fStack_28,0x41600000,0,&uStack_68,&uStack_58,0,2,1
                       ,&uStack_20,&uStack_48,&uStack_7c,1);
  if (DAT_01d68620 != '\0') {
    FUN_0114e5f0();
    iVar5 = FUN_0114e5a0(&uStack_18);
  }
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27985 ; VA 0x00c38a80 ; FUN_00c38a80 */

void __thiscall FUN_00c38a80(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***pppuStack_40;
  undefined4 ***apppuStack_28 [4];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  if (DAT_01d6876c < (uint)uStack_18) {
    uVar3 = DAT_01d6876c;
    if ((uint)uStack_18 < DAT_01d6876c) {
      uVar3 = (uint)uStack_18;
    }
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_18._4_4_) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    pppuStack_40 = (undefined4 ***)((uint)pppuStack_40 & 0xffffff00);
    FUN_005542c0(ppppuVar2,uVar3);
    FUN_005507b0();
    apppuStack_28[0] = pppuStack_40;
    uStack_18 = 0xf00000000;
  }
  cVar1 = FUN_00558b30((undefined4 ****)(param_1 + 0x70),apppuStack_28);
  if (cVar1 == '\0') {
    cVar1 = FUN_00fa0fb0(param_2,param_1,0);
    *(bool *)(param_1 + 0x88) = cVar1 == '\0';
    if ((undefined4 ****)(param_1 + 0x70) != apppuStack_28) {
      ppppuVar2 = apppuStack_28;
      if (0xf < uStack_18._4_4_) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_005542c0(ppppuVar2,(uint)uStack_18);
    }
    FUN_008a4940(&DAT_02134cc0);
    if (DAT_01efa590 != (code *)0x0) {
      (*DAT_01efa590)(param_1);
    }
  }
  if (0xf < uStack_18._4_4_) {
    uVar3 = uStack_18._4_4_ + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar3 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27986 ; VA 0x00c38bb0 ; FUN_00c38bb0 */

int * __thiscall
FUN_00c38bb0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808e5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c390f0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Glue,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const&_(__thiscall_RBX::Glue::*)(void)const_,void_(__thiscall_RBX::Glue::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Glue,class_G3D::Vector3>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Glue,class_G3D::Vector3>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27987 ; VA 0x00c38cb0 ; FUN_00c38cb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00c38cb0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f361f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar2 = FUN_00c391f0();
  FUN_009ca670(uVar2,&DAT_01ee40e8,param_2,param_3,param_8,param_9,param_10,param_11,param_12,
               param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::
                  RefPropDescriptor<class_RBX::JointInstance,class_RBX::PartInstance>::vftable;
  param_1[0xd] = (int)RBX::Reflection::
                      RefPropDescriptor<class_RBX::JointInstance,class_RBX::PartInstance>::vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::JointInstance,class_RBX::PartInstance*>::
              GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::JointInstance::*)(void)const_,void_(__thiscall_RBX::JointInstance::*)(class_RBX::PartInstance*)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27988 ; VA 0x00c38e10 ; FUN_00c38e10 */

int * __thiscall
FUN_00c38e10(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c393d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ManualSurfaceJointInstance,int>::
              GetSetImpl<int_(__thiscall_RBX::ManualSurfaceJointInstance::*)(void)const_,void_(__thiscall_RBX::ManualSurfaceJointInstance::*)(int)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::ManualSurfaceJointInstance,int>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::ManualSurfaceJointInstance,int>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27989 ; VA 0x00c38f10 ; FUN_00c38f10 */

int * __thiscall
FUN_00c38f10(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c395b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Motor6D,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&_(__thiscall_RBX::Motor::*)(void)const_>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::Motor6D,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::Motor6D,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27990 ; VA 0x00c39010 ; FUN_00c39010 */

undefined * FUN_00c39010(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808e7c;
  pvStack_10 = ExceptionList;
  if (DAT_01efc160 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc370) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efc370);
      if (DAT_01efc370 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"DynamicRotate",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        FUN_016f3654(&LAB_01894410);
        FUN_016f37bf(&DAT_01efc370);
      }
    }
    DAT_01efc160 = &DAT_01efc168;
  }
  ExceptionList = pvStack_10;
  return DAT_01efc160;
}



/* FUNCTION 27991 ; VA 0x00c390f0 ; FUN_00c390f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c390f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808eb0;
  pvStack_10 = ExceptionList;
  if (DAT_01efaa08 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efac20) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efac20);
      if (DAT_01efac20 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_019696e4,0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efac18 = RBX::Creator<class_RBX::Glue>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efaa10,&DAT_01efac18);
        FUN_016f3654(FUN_01894420);
        FUN_016f37bf(&DAT_01efac20);
      }
    }
    DAT_01efaa08 = &DAT_01efaa10;
  }
  ExceptionList = pvStack_10;
  return DAT_01efaa08;
}



/* FUNCTION 27992 ; VA 0x00c391f0 ; FUN_00c391f0 */

undefined * FUN_00c391f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808ecc;
  pvStack_10 = ExceptionList;
  if (DAT_01efc378 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc588) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efc588);
      if (DAT_01efc588 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"JointInstance",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        FUN_016f3654(&LAB_01894480);
        FUN_016f37bf(&DAT_01efc588);
      }
    }
    DAT_01efc378 = &DAT_01efc380;
  }
  ExceptionList = pvStack_10;
  return DAT_01efc378;
}



/* FUNCTION 27993 ; VA 0x00c392d0 ; FUN_00c392d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c392d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808f00;
  pvStack_10 = ExceptionList;
  if (DAT_01efbf40 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc158) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efc158);
      if (DAT_01efc158 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c393d0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ManualGlue",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efc150 = RBX::Creator<class_RBX::ManualGlue>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efbf48,&DAT_01efc150);
        FUN_016f3654(FUN_01894490);
        FUN_016f37bf(&DAT_01efc158);
      }
    }
    DAT_01efbf40 = &DAT_01efbf48;
  }
  ExceptionList = pvStack_10;
  return DAT_01efbf40;
}



/* FUNCTION 27994 ; VA 0x00c393d0 ; FUN_00c393d0 */

undefined * FUN_00c393d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808f1c;
  pvStack_10 = ExceptionList;
  if (DAT_01efbb08 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efbd18) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efbd18);
      if (DAT_01efbd18 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ManualSurfaceJointInstance",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        FUN_016f3654(&LAB_018944f0);
        FUN_016f37bf(&DAT_01efbd18);
      }
    }
    DAT_01efbb08 = &DAT_01efbb10;
  }
  ExceptionList = pvStack_10;
  return DAT_01efbb08;
}



/* FUNCTION 27995 ; VA 0x00c394b0 ; FUN_00c394b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c394b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808f50;
  pvStack_10 = ExceptionList;
  if (DAT_01efbd20 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efbf38) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efbf38);
      if (DAT_01efbf38 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c393d0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ManualWeld",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efbf30 = RBX::Creator<class_RBX::ManualWeld>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efbd28,&DAT_01efbf30);
        FUN_016f3654(FUN_01894500);
        FUN_016f37bf(&DAT_01efbf38);
      }
    }
    DAT_01efbd20 = &DAT_01efbd28;
  }
  ExceptionList = pvStack_10;
  return DAT_01efbd20;
}



/* FUNCTION 27996 ; VA 0x00c395b0 ; FUN_00c395b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c395b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808f80;
  pvStack_10 = ExceptionList;
  if (DAT_01efae48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efb060) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efb060);
      if (DAT_01efb060 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c396b0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Motor6D",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efb058 = RBX::Creator<class_RBX::Motor6D>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efae50,&DAT_01efb058);
        FUN_016f3654(FUN_01894560);
        FUN_016f37bf(&DAT_01efb060);
      }
    }
    DAT_01efae48 = &DAT_01efae50;
  }
  ExceptionList = pvStack_10;
  return DAT_01efae48;
}



/* FUNCTION 27997 ; VA 0x00c396b0 ; FUN_00c396b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c396b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808fb0;
  pvStack_10 = ExceptionList;
  if (DAT_01efac28 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efae40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efae40);
      if (DAT_01efae40 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Motor",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efae38 = RBX::Creator<class_RBX::Motor>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efac30,&DAT_01efae38);
        FUN_016f3654(FUN_018945c0);
        FUN_016f37bf(&DAT_01efae40);
      }
    }
    DAT_01efac28 = &DAT_01efac30;
  }
  ExceptionList = pvStack_10;
  return DAT_01efac28;
}



/* FUNCTION 27998 ; VA 0x00c397b0 ; FUN_00c397b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c397b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808fe0;
  pvStack_10 = ExceptionList;
  if (DAT_01efb068 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efb280) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efb280);
      if (DAT_01efb280 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Rotate",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efb278 = RBX::Creator<class_RBX::Rotate>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efb070,&DAT_01efb278);
        FUN_016f3654(FUN_01894620);
        FUN_016f37bf(&DAT_01efb280);
      }
    }
    DAT_01efb068 = &DAT_01efb070;
  }
  ExceptionList = pvStack_10;
  return DAT_01efb068;
}



/* FUNCTION 27999 ; VA 0x00c398b0 ; FUN_00c398b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c398b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809020;
  pvStack_10 = ExceptionList;
  if (DAT_01efb288 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efb4a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efb4a0);
      if (DAT_01efb4a0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c39010();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RotateP",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efb498 = RBX::Creator<class_RBX::RotateP>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efb290,&DAT_01efb498);
        FUN_016f3654(FUN_01894680);
        FUN_016f37bf(&DAT_01efb4a0);
      }
    }
    DAT_01efb288 = &DAT_01efb290;
  }
  ExceptionList = pvStack_10;
  return DAT_01efb288;
}


