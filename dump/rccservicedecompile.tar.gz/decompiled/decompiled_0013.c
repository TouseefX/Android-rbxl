/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 3250 ; VA 0x0056ae30 ; FUN_0056ae30 */

undefined4 * __thiscall FUN_0056ae30(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  *param_1 = boost::lock_error::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3251 ; VA 0x0056aeb0 ; FUN_0056aeb0 */

undefined4 * __thiscall FUN_0056aeb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  uVar1 = FUN_01685730();
  *param_1 = std::exception::vftable;
  uStack_c = param_3;
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(&uStack_c,param_1 + 1);
  param_1[4] = uVar1;
  param_1[3] = param_2;
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  *param_1 = boost::lock_error::vftable;
  return param_1;
}



/* FUNCTION 3252 ; VA 0x0056af20 ; FUN_0056af20 */

undefined4 * __thiscall FUN_0056af20(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  return param_1;
}



/* FUNCTION 3253 ; VA 0x0056af60 ; FUN_0056af60 */

undefined4 * __thiscall FUN_0056af60(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_2;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  return param_1;
}



/* FUNCTION 3254 ; VA 0x0056afb0 ; FUN_0056afb0 */

undefined4 * __fastcall FUN_0056afb0(undefined4 *param_1)

{
  *param_1 = ns1__Job::vftable;
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  *(undefined8 *)(param_1 + 8) = 0;
  param_1[10] = 0;
  *(undefined8 *)(param_1 + 0xc) = 0;
  param_1[0xe] = 0;
  return param_1;
}



/* FUNCTION 3255 ; VA 0x0056b020 ; FUN_0056b020 */

undefined4 * __thiscall FUN_0056b020(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  return param_1;
}



/* FUNCTION 3256 ; VA 0x0056b060 ; FUN_0056b060 */

undefined4 * __thiscall FUN_0056b060(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  puStack_c = param_2;
  FUN_0170c226(&puStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  return param_1;
}



/* FUNCTION 3257 ; VA 0x0056b0b0 ; FUN_0056b0b0 */

undefined4 * __thiscall FUN_0056b0b0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::overflow_error::vftable;
  return param_1;
}



/* FUNCTION 3258 ; VA 0x0056b0f0 ; FUN_0056b0f0 */

undefined4 * __thiscall FUN_0056b0f0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_already_satisfied::vftable;
  return param_1;
}



/* FUNCTION 3259 ; VA 0x0056b140 ; FUN_0056b140 */

undefined4 * __fastcall FUN_0056b140(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0168a9f0();
  FUN_0056abb0(3,uVar1);
  *param_1 = boost::promise_already_satisfied::vftable;
  return param_1;
}



/* FUNCTION 3260 ; VA 0x0056b170 ; FUN_0056b170 */

undefined4 * __thiscall FUN_0056b170(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = boost::promise_moved::vftable;
  return param_1;
}



/* FUNCTION 3261 ; VA 0x0056b1c0 ; FUN_0056b1c0 */

undefined4 * __fastcall FUN_0056b1c0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0168a9f0();
  FUN_0056abb0(4,uVar1);
  *param_1 = boost::promise_moved::vftable;
  return param_1;
}



/* FUNCTION 3262 ; VA 0x0056b1f0 ; FUN_0056b1f0 */

undefined4 * __thiscall FUN_0056b1f0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::range_error::vftable;
  return param_1;
}



/* FUNCTION 3263 ; VA 0x0056b230 ; FUN_0056b230 */

undefined4 * __thiscall FUN_0056b230(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017948e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  iVar2 = *param_2;
  piVar1 = *(int **)(*(int *)(iVar2 + 4) + 0x38 + (int)param_2);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 4))();
    iVar2 = *param_2;
  }
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar2 + 4) + 0xc + (int)param_2) == 0) &&
      (piVar1 = *(int **)(*(int *)(iVar2 + 4) + 0x3c + (int)param_2), piVar1 != (int *)0x0)) &&
     (piVar1 != param_2)) {
    FUN_00581480();
    iVar2 = *param_2;
  }
  *(bool *)(param_1 + 1) = *(int *)(*(int *)(iVar2 + 4) + 0xc + (int)param_2) == 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3264 ; VA 0x0056b2c0 ; FUN_0056b2c0 */

undefined4 * __fastcall FUN_0056b2c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179492c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = 0;
  param_1[3] = 0;
  *param_1 = boost::detail::shared_state_base::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  *(undefined2 *)(param_1 + 6) = 0;
  param_1[7] = 0;
  *(undefined *)(param_1 + 8) = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  uStack_8 = 3;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  uVar1 = FUN_00575b50(0,0);
  param_1[0x13] = uVar1;
  param_1[0x16] = 0;
  *(undefined *)(param_1 + 0x1e) = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3265 ; VA 0x0056b3c0 ; FUN_0056b3c0 */

undefined4 * __fastcall FUN_0056b3c0(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794974;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::detail::thread_data_base::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  uStack_8 = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = FUN_00575ab0();
  param_1[4] = uVar1;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  uStack_8._0_1_ = 3;
  iVar2 = CreateEventA(0,1,0,0);
  if (iVar2 != 0) {
    param_1[0xd] = iVar2;
    *(undefined *)(param_1 + 0xe) = 1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar1 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar1);
}



/* FUNCTION 3266 ; VA 0x0056b4a0 ; FUN_0056b4a0 */

undefined4 * __thiscall FUN_0056b4a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  uVar1 = FUN_01685730();
  *param_1 = std::exception::vftable;
  uStack_c = param_3;
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(&uStack_c,param_1 + 1);
  param_1[4] = uVar1;
  param_1[3] = param_2;
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  *param_1 = boost::thread_resource_error::vftable;
  return param_1;
}



/* FUNCTION 3267 ; VA 0x0056b510 ; FUN_0056b510 */

undefined4 * __thiscall FUN_0056b510(undefined4 *param_1,undefined4 param_2)

{
  switch(param_2) {
  default:
    *param_1 = 0xfffffffe;
    param_1[1] = 0x7fffffff;
    return param_1;
  case 1:
    *param_1 = 0;
    param_1[1] = 0x80000000;
    return param_1;
  case 2:
    *param_1 = 0xffffffff;
    param_1[1] = 0x7fffffff;
    return param_1;
  case 3:
    *param_1 = 1;
    param_1[1] = 0x80000000;
    return param_1;
  case 4:
    *param_1 = 0xfffffffd;
    param_1[1] = 0x7fffffff;
    return param_1;
  }
}



/* FUNCTION 3268 ; VA 0x0056b5a0 ; FUN_0056b5a0 */

undefined4 * __thiscall FUN_0056b5a0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::underflow_error::vftable;
  return param_1;
}



/* FUNCTION 3269 ; VA 0x0056b5e0 ; FUN_0056b5e0 */

undefined4 * __thiscall FUN_0056b5e0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  
  *param_1 = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 4);
  param_1[1] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = std::exception::vftable;
  *(undefined8 *)(param_1 + 6) = 0;
  FUN_0170c226(param_2 + 0x18,param_1 + 6);
  *param_1 = boost::unknown_exception::vftable;
  param_1[5] = boost::unknown_exception::vftable;
  return param_1;
}



/* FUNCTION 3270 ; VA 0x0056b650 ; FUN_0056b650 */

void __fastcall FUN_0056b650(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0056b6a3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 3271 ; VA 0x0056b6b0 ; FUN_0056b6b0 */

void __fastcall FUN_0056b6b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0056b729. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 3272 ; VA 0x0056b730 ; FUN_0056b730 */

void __fastcall FUN_0056b730(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 8);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0056b743. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 3273 ; VA 0x0056b750 ; FUN_0056b750 */

void __fastcall FUN_0056b750(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RCCTexturePackGenerator>::vftable;
  uVar1 = FUN_00558f80(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3274 ; VA 0x0056b790 ; FUN_0056b790 */

void __fastcall FUN_0056b790(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_ThumbnailGenerator>::vftable;
  uVar1 = FUN_00559080(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3275 ; VA 0x0056b7d0 ; FUN_0056b7d0 */

void __fastcall FUN_0056b7d0(int *param_1)

{
  int *piVar1;
  
  piVar1 = (int *)param_1[9];
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x10))(piVar1 != param_1);
    param_1[9] = 0;
  }
  return;
}



/* FUNCTION 3276 ; VA 0x0056b800 ; FUN_0056b800 */

void __fastcall FUN_0056b800(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00576720(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x28);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3277 ; VA 0x0056b860 ; FUN_0056b860 */

void __fastcall FUN_0056b860(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x28);
  return;
}



/* FUNCTION 3278 ; VA 0x0056b870 ; FUN_0056b870 */

void __fastcall FUN_0056b870(undefined4 *param_1)

{
  FUN_00559570(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 3279 ; VA 0x0056b890 ; FUN_0056b890 */

void __fastcall FUN_0056b890(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00559720(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3280 ; VA 0x0056b8d0 ; FUN_0056b8d0 */

void __fastcall FUN_0056b8d0(int param_1)

{
  int iVar1;
  int iVar2;
  
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x20) + 4) + -0x20 + param_1) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = *(int *)(*(int *)(param_1 + -0x20) + 4);
  *(int *)(iVar1 + -0x24 + param_1) = iVar1 + -0x20;
  iVar1 = param_1 + -8;
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x10) + 4) + -8 + iVar1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  iVar2 = *(int *)(*(int *)(param_1 + -0x10) + 4);
  *(int *)(iVar2 + -0xc + iVar1) = iVar2 + -8;
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x20) + 4) + -0x18 + iVar1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  iVar2 = *(int *)(*(int *)(param_1 + -0x20) + 4);
  *(int *)(iVar2 + -0x1c + iVar1) = iVar2 + -0x18;
  return;
}



/* FUNCTION 3281 ; VA 0x0056b930 ; FUN_0056b930 */

void __fastcall FUN_0056b930(int param_1)

{
  int iVar1;
  
  *(undefined ***)(*(int *)(*(int *)(param_1 + -8) + 4) + -8 + param_1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = *(int *)(*(int *)(param_1 + -8) + 4);
  *(int *)(iVar1 + -0xc + param_1) = iVar1 + -8;
  return;
}



/* FUNCTION 3282 ; VA 0x0056b950 ; FUN_0056b950 */

void __fastcall FUN_0056b950(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
  if ((*(byte *)(param_1 + 0xf) & 1) != 0) {
    if (*(int *)param_1[8] == 0) {
      iVar3 = *(int *)param_1[0xb] + *(int *)param_1[7];
    }
    else {
      iVar3 = *(int *)param_1[0xc] + *(int *)param_1[8];
    }
    iVar1 = *(int *)param_1[3];
    uVar4 = iVar3 - iVar1;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)param_1[3] = 0;
  *(undefined4 *)param_1[7] = 0;
  *(undefined4 *)param_1[0xb] = 0;
  *(undefined4 *)param_1[4] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  param_1[0xf] = param_1[0xf] & 0xfffffffe;
  param_1[0xe] = 0;
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar3 = param_1[0xd];
  if (iVar3 != 0) {
    uStack_8 = 0;
    if ((*(int **)(iVar3 + 4) != (int *)0x0) &&
       (puVar2 = (undefined4 *)(**(code **)(**(int **)(iVar3 + 4) + 8))(),
       puVar2 != (undefined4 *)0x0)) {
      (**(code **)*puVar2)(1);
    }
    FUN_01674ea0(iVar3,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3283 ; VA 0x0056ba50 ; FUN_0056ba50 */

void __fastcall FUN_0056ba50(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x48);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x34);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  FUN_005509f0();
  return;
}



/* FUNCTION 3284 ; VA 0x0056bab0 ; FUN_0056bab0 */

void FUN_0056bab0(void)

{
  FUN_0056cf50();
  return;
}



/* FUNCTION 3285 ; VA 0x0056bac0 ; FUN_0056bac0 */

void __fastcall FUN_0056bac0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0056bae9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 3286 ; VA 0x0056baf0 ; FUN_0056baf0 */

void __fastcall FUN_0056baf0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 3287 ; VA 0x0056bb40 ; FUN_0056bb40 */

void __fastcall FUN_0056bb40(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*(int *)(param_1 + 8) != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    uVar3 = *(int *)(param_1 + 8) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return;
}



/* FUNCTION 3288 ; VA 0x0056bb80 ; FUN_0056bb80 */

void __fastcall FUN_0056bb80(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3289 ; VA 0x0056bbf0 ; FUN_0056bbf0 */

void __fastcall FUN_0056bbf0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3290 ; VA 0x0056bc60 ; FUN_0056bc60 */

void __fastcall FUN_0056bc60(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3291 ; VA 0x0056bcd0 ; FUN_0056bcd0 */

void __fastcall FUN_0056bcd0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3292 ; VA 0x0056bd40 ; FUN_0056bd40 */

void __fastcall FUN_0056bd40(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3293 ; VA 0x0056bdb0 ; FUN_0056bdb0 */

void __fastcall FUN_0056bdb0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3294 ; VA 0x0056be20 ; FUN_0056be20 */

void __fastcall FUN_0056be20(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3295 ; VA 0x0056be90 ; FUN_0056be90 */

void __fastcall FUN_0056be90(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::length_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3296 ; VA 0x0056bf00 ; FUN_0056bf00 */

void __fastcall FUN_0056bf00(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3297 ; VA 0x0056bf70 ; FUN_0056bf70 */

void __fastcall FUN_0056bf70(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3298 ; VA 0x0056bff0 ; FUN_0056bff0 */

void __fastcall FUN_0056bff0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3299 ; VA 0x0056c060 ; FUN_0056c060 */

void __fastcall FUN_0056c060(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::range_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3300 ; VA 0x0056c0d0 ; FUN_0056c0d0 */

void __fastcall FUN_0056c0d0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3301 ; VA 0x0056c140 ; FUN_0056c140 */

void __fastcall FUN_0056c140(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3302 ; VA 0x0056c1b0 ; FUN_0056c1b0 */

void * __fastcall FUN_0056c1b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 4);
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 3303 ; VA 0x0056c200 ; FUN_0056c200 */

void __fastcall FUN_0056c200(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0056c213. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 3304 ; VA 0x0056c220 ; FUN_0056c220 */

void __fastcall FUN_0056c220(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::error_info_base::vftable;
  return;
}



/* FUNCTION 3305 ; VA 0x0056c230 ; FUN_0056c230 */

void __fastcall FUN_0056c230(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3306 ; VA 0x0056c2a0 ; FUN_0056c2a0 */

void __fastcall FUN_0056c2a0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3307 ; VA 0x0056c310 ; FUN_0056c310 */

void __fastcall FUN_0056c310(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3308 ; VA 0x0056c380 ; FUN_0056c380 */

void __fastcall FUN_0056c380(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3309 ; VA 0x0056c3f0 ; FUN_0056c3f0 */

void __fastcall FUN_0056c3f0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3310 ; VA 0x0056c460 ; FUN_0056c460 */

void __fastcall FUN_0056c460(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3311 ; VA 0x0056c4d0 ; FUN_0056c4d0 */

void __fastcall FUN_0056c4d0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  param_1[0xb] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[0xc] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[0xc] + 0x10))();
    if (cVar1 != '\0') {
      param_1[0xc] = 0;
    }
  }
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3312 ; VA 0x0056c540 ; FUN_0056c540 */

void __fastcall FUN_0056c540(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3313 ; VA 0x0056c5b0 ; FUN_0056c5b0 */

void __fastcall FUN_0056c5b0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3314 ; VA 0x0056c620 ; FUN_0056c620 */

void __fastcall FUN_0056c620(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x38);
  return;
}



/* FUNCTION 3315 ; VA 0x0056c630 ; FUN_0056c630 */

void __fastcall FUN_0056c630(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)*param_1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iStack_8 = *piVar3;
    ExceptionList = &pvStack_10;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    iStack_8 = iStack_8 + -1;
    if (iStack_8 == 0) {
      if ((code *)piVar3[3] != (code *)0x0) {
        (*(code *)piVar3[3])(piVar3);
      }
      FUN_0056c630();
      piVar1 = piVar3 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(piVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3316 ; VA 0x0056c6a0 ; FUN_0056c6a0 */

void __fastcall FUN_0056c6a0(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)*param_1;
  if (puVar1 != (undefined4 *)0x0) {
    LOCK();
    iVar2 = puVar1[1] + -1;
    puVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*puVar1)(0);
      uVar3 = GetProcessHeap(0,puVar1);
      HeapFree(uVar3);
    }
  }
  return;
}



/* FUNCTION 3317 ; VA 0x0056c6d0 ; FUN_0056c6d0 */

void __fastcall FUN_0056c6d0(int *param_1)

{
  int iVar1;
  
  param_1 = (int *)*param_1;
  if (param_1 != (int *)0x0) {
    LOCK();
    iVar1 = param_1[4] + -1;
    param_1[4] = iVar1;
    UNLOCK();
    if ((iVar1 == 0) && (param_1 != (int *)0x0)) {
      iVar1 = param_1[1];
      if ((iVar1 != 0) && (iVar1 != -1)) {
        CloseHandle(iVar1);
      }
      iVar1 = *param_1;
      if ((iVar1 != 0) && (iVar1 != -1)) {
        CloseHandle(iVar1);
      }
      FUN_01674ea0(param_1,0x14);
    }
  }
  return;
}



/* FUNCTION 3318 ; VA 0x0056c720 ; FUN_0056c720 */

void __fastcall FUN_0056c720(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x44);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x30);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  FUN_005509f0();
  return;
}



/* FUNCTION 3319 ; VA 0x0056c780 ; FUN_0056c780 */

void __fastcall FUN_0056c780(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 3320 ; VA 0x0056c7d0 ; thunk_FUN_0056cf50 */

void __fastcall thunk_FUN_0056cf50(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x44);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x28);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  FUN_0056cac0();
  return;
}



/* FUNCTION 3321 ; VA 0x0056c7e0 ; FUN_0056c7e0 */

void __fastcall FUN_0056c7e0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0xc);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0xc);
  return;
}



/* FUNCTION 3322 ; VA 0x0056c830 ; FUN_0056c830 */

void __fastcall FUN_0056c830(undefined4 *param_1)

{
  uint uVar1;
  uint *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puVar2 = (uint *)*param_1;
  LOCK();
  uVar1 = *puVar2;
  ExceptionList = &pvStack_10;
  *puVar2 = *puVar2 + 0x80000000;
  UNLOCK();
  if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
    LOCK();
    uVar1 = *puVar2;
    *puVar2 = *puVar2 | 0x40000000;
    UNLOCK();
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3323 ; VA 0x0056c890 ; FUN_0056c890 */

void __fastcall FUN_0056c890(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016deec8(*param_1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3324 ; VA 0x0056c8d0 ; FUN_0056c8d0 */

void __fastcall FUN_0056c8d0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00576500(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3325 ; VA 0x0056c930 ; FUN_0056c930 */

void __fastcall FUN_0056c930(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0057ed00(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3326 ; VA 0x0056c980 ; FUN_0056c980 */

void __fastcall FUN_0056c980(uint param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar1 = *(int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 4);
  puVar7 = (undefined4 *)(-(uint)(iVar1 != 0) & iVar1 + 0x30U);
  puVar3 = (undefined4 *)*puVar7;
  while (puVar3 != puVar7) {
    puVar2 = (undefined4 *)*puVar3;
    uVar6 = puVar3[-3];
    if (0xf < uVar6) {
      iVar1 = puVar3[-8];
      uVar5 = uVar6 + 1;
      iVar4 = iVar1;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar1 + -4);
        uVar5 = uVar6 + 0x24;
        if (0x1f < (iVar1 - iVar4) - 4U) goto LAB_0056ca47;
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    puVar3[-4] = 0;
    puVar3[-3] = 0xf;
    *(undefined *)(puVar3 + -8) = 0;
    FUN_01674ea0(puVar3 + -0xc,0x38);
    puVar3 = puVar2;
  }
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar1 = *(int *)(param_1 + 0x1c);
    uVar6 = *(int *)(param_1 + 0x18) * 4;
    iVar4 = iVar1;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
LAB_0056ca47:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x38);
  return;
}



/* FUNCTION 3327 ; VA 0x0056ca50 ; thunk_FUN_0056ca60 */

void __fastcall thunk_FUN_0056ca60(char *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (*param_1 != '\0') {
    uVar1 = *(uint *)(param_1 + 0x18);
    if (0xf < uVar1) {
      iVar2 = *(int *)(param_1 + 4);
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    param_1[0x14] = '\0';
    param_1[0x15] = '\0';
    param_1[0x16] = '\0';
    param_1[0x17] = '\0';
    param_1[0x18] = '\x0f';
    param_1[0x19] = '\0';
    param_1[0x1a] = '\0';
    param_1[0x1b] = '\0';
    param_1[4] = '\0';
    *param_1 = '\0';
  }
  return;
}



/* FUNCTION 3328 ; VA 0x0056ca60 ; FUN_0056ca60 */

void __fastcall FUN_0056ca60(char *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (*param_1 != '\0') {
    uVar1 = *(uint *)(param_1 + 0x18);
    if (0xf < uVar1) {
      iVar2 = *(int *)(param_1 + 4);
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    param_1[0x14] = '\0';
    param_1[0x15] = '\0';
    param_1[0x16] = '\0';
    param_1[0x17] = '\0';
    param_1[0x18] = '\x0f';
    param_1[0x19] = '\0';
    param_1[0x1a] = '\0';
    param_1[0x1b] = '\0';
    param_1[4] = '\0';
    *param_1 = '\0';
  }
  return;
}



/* FUNCTION 3329 ; VA 0x0056cac0 ; FUN_0056cac0 */

void __fastcall FUN_0056cac0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 3330 ; VA 0x0056cb40 ; FUN_0056cb40 */

void __fastcall FUN_0056cb40(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[7] != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_1[7] + 8))(param_1 + 8);
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3331 ; VA 0x0056cbd0 ; FUN_0056cbd0 */

void __fastcall FUN_0056cbd0(int *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*param_1 + 8))(param_1 + 1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3332 ; VA 0x0056cc10 ; FUN_0056cc10 */

uint __fastcall FUN_0056cc10(uint *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined **ppuStack_34;
  undefined auStack_30 [16];
  undefined auStack_20 [8];
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar6 = *param_1;
  ExceptionList = &pvStack_10;
  if (uVar6 != 0) {
    puStack_18 = (uint *)(uVar6 + 0x24);
    cStack_14 = '\0';
    ExceptionList = &pvStack_10;
    uVar6 = FUN_00587410();
    if ((*(char *)(*param_1 + 0x18) == '\0') && (*(char *)(*param_1 + 0x20) == '\0')) {
      uVar7 = FUN_0168a9f0();
      FUN_0056abb0(1,uVar7);
      ppuStack_34 = boost::broken_promise::vftable;
      uVar7 = FUN_0055dd80(auStack_20,&ppuStack_34);
      FUN_00587d90(uVar7,&puStack_18);
      FUN_00550ad0();
      ppuStack_34 = std::exception::vftable;
      uVar6 = FUN_0170c289(auStack_30);
    }
    uStack_8 = 0;
    if (cStack_14 != '\0') {
      LOCK();
      uVar6 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
        LOCK();
        uVar3 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar3 >> 0x1e & 1) == 0) {
          uVar7 = FUN_00554e40();
          uVar6 = SetEvent(uVar7);
        }
      }
    }
  }
  piVar5 = (int *)param_1[1];
  uStack_8 = 1;
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)(*piVar5 + 4))();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 3333 ; VA 0x0056cd30 ; FUN_0056cd30 */

void __fastcall FUN_0056cd30(int *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvVar6;
  char cVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  LOCK();
  iVar4 = *(int *)(*param_1 + 0x28) + -1;
  ExceptionList = &pvStack_10;
  *(int *)(*param_1 + 0x28) = iVar4;
  UNLOCK();
  if (iVar4 != 0) {
    ExceptionList = pvVar6;
    return;
  }
  FUN_00585a90();
  uVar5 = DAT_01ea8518;
  EnterCriticalSection(DAT_01ea8518);
  cVar7 = FUN_00578b90(param_1);
  if (cVar7 == '\0') goto LAB_0056ce24;
  iVar4 = *param_1;
  piVar11 = (int *)(-(uint)(iVar4 != 0) & iVar4 + 0x30U);
  piVar8 = (int *)(DAT_01ea8514 + 0x28);
  if (DAT_01ea8514 == -0xc) {
    piVar8 = (int *)0x28;
  }
  *piVar8 = *piVar8 + -1;
  puVar1 = (undefined4 *)piVar11[1];
  piVar8 = *(int **)(*piVar11 + 4);
  if (piVar8 == piVar11) {
    piVar8 = (int *)*puVar1;
    *(undefined4 **)(*piVar11 + 4) = puVar1;
    if (piVar8 == piVar11) goto LAB_0056cdd0;
    piVar8 = *(int **)piVar11[1];
  }
  else if ((int *)*puVar1 == piVar11) {
    *piVar8 = (int)puVar1;
LAB_0056cdd0:
    piVar8 = (int *)piVar11[1];
  }
  else {
    *piVar8 = 0;
    *(int *)(*piVar11 + 4) = piVar11[1];
    piVar8 = *(int **)piVar11[1];
  }
  *piVar8 = *piVar11;
  uVar2 = *(uint *)(iVar4 + 0x24);
  if (0xf < uVar2) {
    iVar3 = *(int *)(iVar4 + 0x10);
    uVar10 = uVar2 + 1;
    iVar9 = iVar3;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iVar3 + -4);
      uVar10 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0xf;
  *(undefined *)(iVar4 + 0x10) = 0;
  FUN_01674ea0(iVar4,0x38);
LAB_0056ce24:
  LeaveCriticalSection(uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3334 ; VA 0x0056ce50 ; FUN_0056ce50 */

void __fastcall FUN_0056ce50(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  return;
}



/* FUNCTION 3335 ; VA 0x0056cea0 ; FUN_0056cea0 */

void __fastcall FUN_0056cea0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 4) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00587410();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3336 ; VA 0x0056cee0 ; FUN_0056cee0 */

void __fastcall FUN_0056cee0(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = (int *)*param_1;
  if (piVar1 != (int *)0x0) {
    uVar2 = piVar1[5];
    if (0xf < uVar2) {
      iVar3 = *piVar1;
      uVar5 = uVar2 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar1[4] = 0;
    piVar1[5] = 0xf;
    *(undefined *)piVar1 = 0;
    FUN_01674ea0(piVar1,0x18);
  }
  return;
}



/* FUNCTION 3337 ; VA 0x0056cf40 ; thunk_FUN_0056cac0 */

void __fastcall thunk_FUN_0056cac0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 3338 ; VA 0x0056cf50 ; FUN_0056cf50 */

void __fastcall FUN_0056cf50(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x44);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x28);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  FUN_0056cac0();
  return;
}



/* FUNCTION 3339 ; VA 0x0056cfd0 ; FUN_0056cfd0 */

void __fastcall FUN_0056cfd0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00560a10(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 3340 ; VA 0x0056d080 ; FUN_0056d080 */

void __fastcall FUN_0056d080(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar7;
        uStack_8 = 0;
        if (puVar7[9] != 0) {
          (**(code **)(puVar7[9] + 8))(puVar7 + 10);
        }
        uVar6 = puVar7[7];
        uStack_8 = 0xffffffff;
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056d196;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0xf0);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0056d196:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3341 ; VA 0x0056d1a0 ; FUN_0056d1a0 */

void __fastcall FUN_0056d1a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00560a10(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 3342 ; VA 0x0056d1b0 ; thunk_FUN_0056d080 */

void __fastcall thunk_FUN_0056d080(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar7;
        uStack_8 = 0;
        if (puVar7[9] != 0) {
          (**(code **)(puVar7[9] + 8))(puVar7 + 10);
        }
        uVar6 = puVar7[7];
        uStack_8 = 0xffffffff;
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056d196;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0xf0);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0056d196:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3343 ; VA 0x0056d1c0 ; FUN_0056d1c0 */

void __fastcall FUN_0056d1c0(int *param_1)

{
  if ((int *)*param_1 != (int *)0x0) {
    (**(code **)(*(int *)*param_1 + 4))(1);
  }
  return;
}



/* FUNCTION 3344 ; VA 0x0056d1d0 ; FUN_0056d1d0 */

void __fastcall FUN_0056d1d0(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  param_1 = (int *)*param_1;
  if (param_1 != (int *)0x0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016899e0();
    puVar1 = (undefined4 *)*param_1;
    if (puVar1 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = puVar1[1] + -1;
      puVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*puVar1)(0);
        uVar3 = GetProcessHeap(0,puVar1);
        HeapFree(uVar3);
      }
    }
    FUN_01674ea0(param_1,4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3345 ; VA 0x0056d250 ; FUN_0056d250 */

void __fastcall FUN_0056d250(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 3346 ; VA 0x0056d2d0 ; FUN_0056d2d0 */

void __fastcall FUN_0056d2d0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3347 ; VA 0x0056d320 ; FUN_0056d320 */

void __fastcall FUN_0056d320(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3348 ; VA 0x0056d380 ; FUN_0056d380 */

void __fastcall FUN_0056d380(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3349 ; VA 0x0056d3e0 ; FUN_0056d3e0 */

void __fastcall FUN_0056d3e0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3350 ; VA 0x0056d440 ; FUN_0056d440 */

void __fastcall FUN_0056d440(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  
  piVar5 = (int *)*param_1;
  if (piVar5 != (int *)0x0) {
    piVar6 = (int *)param_1[1];
    if (piVar5 != piVar6) {
      do {
        uVar3 = piVar5[5];
        if (0xf < uVar3) {
          iVar1 = *piVar5;
          uVar4 = uVar3 + 1;
          iVar2 = iVar1;
          if (0xfff < uVar4) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar4 = uVar3 + 0x24;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_0056d4e2;
          }
          FUN_01674ea0(iVar2,uVar4);
        }
        piVar5[4] = 0;
        piVar5[5] = 0xf;
        *(undefined *)piVar5 = 0;
        piVar5 = piVar5 + 8;
      } while (piVar5 != piVar6);
      piVar5 = (int *)*param_1;
    }
    uVar3 = param_1[2] - (int)piVar5 & 0xffffffe0;
    piVar6 = piVar5;
    if (0xfff < uVar3) {
      piVar6 = (int *)piVar5[-1];
      uVar3 = uVar3 + 0x23;
      if ((undefined *)0x1f < (undefined *)((int)piVar5 + (-4 - (int)piVar6))) {
LAB_0056d4e2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar6,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3351 ; VA 0x0056d4f0 ; thunk_FUN_00577a40 */

void __fastcall thunk_FUN_00577a40(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00559570(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3352 ; VA 0x0056d500 ; FUN_0056d500 */

void __fastcall FUN_0056d500(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_005595e0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3353 ; VA 0x0056d560 ; FUN_0056d560 */

void __fastcall FUN_0056d560(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00559650(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3354 ; VA 0x0056d5f0 ; thunk_FUN_00577ac0 */

void __fastcall thunk_FUN_00577ac0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3355 ; VA 0x0056d600 ; FUN_0056d600 */

void FUN_0056d600(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3356 ; VA 0x0056d630 ; FUN_0056d630 */

void __fastcall FUN_0056d630(int *param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f3f0();
  piVar4 = (int *)FUN_01689dd0(&piStack_14);
  piVar5 = (int *)FUN_01689df0(auStack_18);
  if (*piVar4 == *piVar5) {
    uVar7 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar7);
  }
  FUN_0168a200();
  FUN_0093c7f0();
  FUN_0057ab10(auStack_18);
  _guard_check_icall();
  uVar1 = param_1[0x39];
  if (0xf < uVar1) {
    iVar2 = param_1[0x34];
    uVar8 = uVar1 + 1;
    iVar6 = iVar2;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar8 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar6) - 4U) goto LAB_0056d90e;
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  param_1[0x38] = 0;
  param_1[0x39] = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  LOCK();
  iVar2 = param_1[0x33];
  param_1[0x33] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  LOCK();
  iVar2 = param_1[0x30];
  param_1[0x30] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  uStack_8 = 0;
  FUN_0057ed00(auStack_18,*(undefined4 *)param_1[0x2d],(undefined4 *)param_1[0x2d]);
  FUN_01674ea0(param_1[0x2d],0x30);
  uStack_8 = 0xffffffff;
  if ((int *)param_1[0x2c] != (int *)0x0) {
    (**(code **)(*(int *)param_1[0x2c] + 4))(1);
  }
  uVar1 = param_1[0x2a];
  if (0xf < uVar1) {
    iVar2 = param_1[0x25];
    uVar8 = uVar1 + 1;
    iVar6 = iVar2;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar8 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar6) - 4U) goto LAB_0056d90e;
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  param_1[0x29] = 0;
  param_1[0x2a] = 0xf;
  *(undefined *)(param_1 + 0x25) = 0;
  FUN_0151f390();
  uVar1 = param_1[0x22];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1d];
    uVar8 = uVar1 + 1;
    iVar6 = iVar2;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar8 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar6) - 4U) goto LAB_0056d90e;
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  param_1[0x21] = 0;
  param_1[0x22] = 0xf;
  *(undefined *)(param_1 + 0x1d) = 0;
  uVar1 = param_1[0x1c];
  if (0xf < uVar1) {
    iVar2 = param_1[0x17];
    uVar8 = uVar1 + 1;
    iVar6 = iVar2;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar8 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_0056d90e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  *(undefined *)(param_1 + 0x17) = 0;
  FUN_0056e160();
  FUN_0151f390();
  piVar4 = (int *)param_1[1];
  piStack_14 = piVar4;
  if (piVar4 != (int *)0x0) {
    uStack_8 = 1;
    FUN_016899e0();
    puVar3 = (undefined4 *)*piVar4;
    if (puVar3 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = puVar3[1] + -1;
      puVar3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*puVar3)(0);
        uVar7 = GetProcessHeap(0,puVar3);
        HeapFree(uVar7);
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(piStack_14,4);
  }
  param_1 = (int *)*param_1;
  if (param_1 != (int *)0x0) {
    uStack_8 = 2;
    FUN_016899e0();
    puVar3 = (undefined4 *)*param_1;
    if (puVar3 != (undefined4 *)0x0) {
      LOCK();
      piVar4 = puVar3 + 1;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)*puVar3)(0);
        uVar7 = GetProcessHeap(0,puVar3);
        HeapFree(uVar7);
      }
    }
    FUN_01674ea0(param_1,4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3357 ; VA 0x0056d930 ; FUN_0056d930 */

void __fastcall FUN_0056d930(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  *param_1 = RBX::CorescriptConfigurer::vftable;
  uVar2 = param_1[0xc];
  if (0xf < uVar2) {
    iVar3 = param_1[7];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xb] = 0;
  param_1[0xc] = 0xf;
  *(undefined *)(param_1 + 7) = 0;
  *param_1 = RBX::GameConfigurer::vftable;
  piVar4 = (int *)param_1[5];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[2];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0056d9c0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar4 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 3358 ; VA 0x0056d9d0 ; FUN_0056d9d0 */

void __fastcall FUN_0056d9d0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x1d];
  if (0xf < uVar1) {
    iVar2 = param_1[0x18];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056db29;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x1c] = 0;
  param_1[0x1d] = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  uVar1 = param_1[0x17];
  if (0xf < uVar1) {
    iVar2 = param_1[0x12];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056db29;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  uVar1 = param_1[0x11];
  if (0xf < uVar1) {
    iVar2 = param_1[0xc];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056db29;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056db29;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0056db29:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 3359 ; VA 0x0056db30 ; thunk_FUN_0056e4b0 */

void __fastcall thunk_FUN_0056e4b0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = SimpleJSON::vftable;
  uVar1 = param_1[9];
  if (0xf < uVar1) {
    iVar2 = param_1[4];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  iVar2 = param_1[1];
  uStack_8 = 0;
  FUN_00576640(*(undefined4 *)(iVar2 + 4));
  *(int *)(param_1[1] + 4) = iVar2;
  *(int *)param_1[1] = iVar2;
  *(int *)(param_1[1] + 8) = iVar2;
  param_1[2] = 0;
  FUN_01674ea0(param_1[1],0x2c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3360 ; VA 0x0056db40 ; FUN_0056db40 */

void __fastcall FUN_0056db40(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x60);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x4c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056dbd1;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  FUN_0056cfd0();
  uVar1 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x18);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0056dbd1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  return;
}



/* FUNCTION 3361 ; VA 0x0056dbe0 ; FUN_0056dbe0 */

int __fastcall FUN_0056dbe0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = param_1[0x1a];
  if (0xf < uVar2) {
    iVar4 = param_1[0x15];
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0056dd0b;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x19] = 0;
  param_1[0x1a] = 0xf;
  *(undefined *)(param_1 + 0x15) = 0;
  piVar3 = (int *)param_1[0x13];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar4 = param_1[0x11];
  if (iVar4 != 0) {
    piVar3 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = FUN_0151f390();
  piVar3 = (int *)param_1[9];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[7];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar2 = param_1[5];
  if (0xf < uVar2) {
    iVar4 = *param_1;
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_0056dd0b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return iVar4;
}



/* FUNCTION 3362 ; VA 0x0056dd20 ; FUN_0056dd20 */

void FUN_0056dd20(void)

{
  FUN_0056e380();
  FUN_0056e380();
  return;
}



/* FUNCTION 3363 ; VA 0x0056dd40 ; FUN_0056dd40 */

void __fastcall FUN_0056dd40(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0xb4);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xa0);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056deff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0xf;
  *(undefined *)(param_1 + 0xa0) = 0;
  uVar1 = *(uint *)(param_1 + 0x94);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x80);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056deff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0xf;
  *(undefined *)(param_1 + 0x80) = 0;
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056deff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uVar1 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x48);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056deff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  uVar1 = *(uint *)(param_1 + 0x44);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x30);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056deff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  uVar1 = *(uint *)(param_1 + 0x28);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x14);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0056deff:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0xf;
  *(undefined *)(param_1 + 0x14) = 0;
  return;
}



/* FUNCTION 3364 ; VA 0x0056df10 ; FUN_0056df10 */

void __fastcall FUN_0056df10(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  
  uVar9 = *(uint *)(param_1 + 0xa4);
  if (0xf < uVar9) {
    iVar7 = *(int *)(param_1 + 0x90);
    uVar5 = uVar9 + 1;
    iVar4 = iVar7;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar5 = uVar9 + 0x24;
      if (0x1f < (iVar7 - iVar4) - 4U) goto LAB_0056e15a;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0xf;
  *(undefined *)(param_1 + 0x90) = 0;
  uVar9 = *(uint *)(param_1 + 0x8c);
  if (0xf < uVar9) {
    iVar7 = *(int *)(param_1 + 0x78);
    uVar5 = uVar9 + 1;
    iVar4 = iVar7;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar5 = uVar9 + 0x24;
      if (0x1f < (iVar7 - iVar4) - 4U) goto LAB_0056e15a;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0xf;
  *(undefined *)(param_1 + 0x78) = 0;
  uVar9 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar9) {
    iVar7 = *(int *)(param_1 + 0x60);
    uVar5 = uVar9 + 1;
    iVar4 = iVar7;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar5 = uVar9 + 0x24;
      if (0x1f < (iVar7 - iVar4) - 4U) goto LAB_0056e15a;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uVar9 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar9) {
    iVar7 = *(int *)(param_1 + 0x48);
    uVar5 = uVar9 + 1;
    iVar4 = iVar7;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar5 = uVar9 + 0x24;
      if (0x1f < (iVar7 - iVar4) - 4U) goto LAB_0056e15a;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  piVar3 = *(int **)(param_1 + 0x44);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[1] + -1;
    piVar3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar7 = *(int *)(param_1 + 0x3c);
  if (iVar7 != 0) {
    if (*(int *)(param_1 + 0x30) != 0) {
      puVar2 = (undefined4 *)(iVar7 + *(int *)(param_1 + 0x2c) * 4);
      puVar6 = (undefined4 *)*puVar2;
      do {
        *puVar2 = *puVar6;
        FUN_01674ea0(puVar6,0x18);
        *(int *)(param_1 + 0x30) = *(int *)(param_1 + 0x30) + -1;
        puVar6 = (undefined4 *)*puVar2;
      } while (puVar6 != (undefined4 *)0x0);
      iVar7 = *(int *)(param_1 + 0x3c);
    }
    iVar4 = *(int *)(param_1 + 0x2c) * 4;
    uVar9 = iVar4 + 4;
    iVar8 = iVar7;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar7 + -4);
      uVar9 = iVar4 + 0x27;
      if (0x1f < (iVar7 - iVar8) - 4U) {
LAB_0056e15a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x1c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[2] + -1;
    piVar3[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[1] + -1;
    piVar3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[1] + -1;
    piVar3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar7 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar7 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0056e153. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 3365 ; VA 0x0056e160 ; FUN_0056e160 */

void __fastcall FUN_0056e160(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RCCServiceSettings::vftable;
  uVar1 = param_1[0x11];
  if (0xf < uVar1) {
    iVar2 = param_1[0xc];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  FUN_0056e4b0();
  return;
}



/* FUNCTION 3366 ; VA 0x0056e1c0 ; FUN_0056e1c0 */

void __fastcall FUN_0056e1c0(int *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0151ab30(*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3367 ; VA 0x0056e200 ; FUN_0056e200 */

void __fastcall FUN_0056e200(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = SecurityDataUpdater::vftable;
  uVar1 = param_1[0xc];
  if (0xf < uVar1) {
    iVar2 = param_1[7];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056e28f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xb] = 0;
  param_1[0xc] = 0xf;
  *(undefined *)(param_1 + 7) = 0;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0056e28f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 3368 ; VA 0x0056e2a0 ; FUN_0056e2a0 */

void __fastcall FUN_0056e2a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x40);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x2c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0xf;
  *(undefined *)(param_1 + 0x2c) = 0;
  return;
}



/* FUNCTION 3369 ; VA 0x0056e2f0 ; FUN_0056e2f0 */

void __fastcall FUN_0056e2f0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x1c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0056e379;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0056e379:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 3370 ; VA 0x0056e380 ; FUN_0056e380 */

void __fastcall FUN_0056e380(int *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvVar6;
  char cVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  LOCK();
  iVar4 = *(int *)(*param_1 + 0x28) + -1;
  ExceptionList = &pvStack_10;
  *(int *)(*param_1 + 0x28) = iVar4;
  UNLOCK();
  if (iVar4 != 0) {
    ExceptionList = pvVar6;
    return;
  }
  FUN_00585a90();
  uVar5 = DAT_01ea8518;
  EnterCriticalSection(DAT_01ea8518);
  cVar7 = FUN_00578b90(param_1);
  if (cVar7 == '\0') goto LAB_0056e47b;
  iVar4 = *param_1;
  piVar11 = (int *)(-(uint)(iVar4 != 0) & iVar4 + 0x30U);
  piVar8 = (int *)(DAT_01ea8514 + 0x28);
  if (DAT_01ea8514 == -0xc) {
    piVar8 = (int *)0x28;
  }
  *piVar8 = *piVar8 + -1;
  puVar1 = (undefined4 *)piVar11[1];
  piVar8 = *(int **)(*piVar11 + 4);
  if (piVar8 == piVar11) {
    piVar8 = (int *)*puVar1;
    *(undefined4 **)(*piVar11 + 4) = puVar1;
    if (piVar8 == piVar11) goto LAB_0056e427;
    piVar8 = *(int **)piVar11[1];
  }
  else if ((int *)*puVar1 == piVar11) {
    *piVar8 = (int)puVar1;
LAB_0056e427:
    piVar8 = (int *)piVar11[1];
  }
  else {
    *piVar8 = 0;
    *(int *)(*piVar11 + 4) = piVar11[1];
    piVar8 = *(int **)piVar11[1];
  }
  *piVar8 = *piVar11;
  uVar2 = *(uint *)(iVar4 + 0x24);
  if (0xf < uVar2) {
    iVar3 = *(int *)(iVar4 + 0x10);
    uVar10 = uVar2 + 1;
    iVar9 = iVar3;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iVar3 + -4);
      uVar10 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0xf;
  *(undefined *)(iVar4 + 0x10) = 0;
  FUN_01674ea0(iVar4,0x38);
LAB_0056e47b:
  LeaveCriticalSection(uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3371 ; VA 0x0056e4b0 ; FUN_0056e4b0 */

void __fastcall FUN_0056e4b0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = SimpleJSON::vftable;
  uVar1 = param_1[9];
  if (0xf < uVar1) {
    iVar2 = param_1[4];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  iVar2 = param_1[1];
  uStack_8 = 0;
  FUN_00576640(*(undefined4 *)(iVar2 + 4));
  *(int *)(param_1[1] + 4) = iVar2;
  *(int *)param_1[1] = iVar2;
  *(int *)(param_1[1] + 8) = iVar2;
  param_1[2] = 0;
  FUN_01674ea0(param_1[1],0x2c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3372 ; VA 0x0056e570 ; FUN_0056e570 */

void FUN_0056e570(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3373 ; VA 0x0056e5b0 ; FUN_0056e5b0 */

void __fastcall FUN_0056e5b0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_1 + 4) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 4) + 8))(param_1 + 8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3374 ; VA 0x0056e5f0 ; FUN_0056e5f0 */

void __fastcall FUN_0056e5f0(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(*(int *)*param_1 + 4) + 0x38 + *param_1);
  if (piVar1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3375 ; VA 0x0056e630 ; FUN_0056e630 */

void __fastcall FUN_0056e630(undefined4 *param_1)

{
  *param_1 = _ns1__BatchJob::vftable;
  return;
}



/* FUNCTION 3376 ; VA 0x0056e640 ; FUN_0056e640 */

void __fastcall FUN_0056e640(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = _ns1__BatchJobResponse::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 3377 ; VA 0x0056e6a0 ; FUN_0056e6a0 */

void __fastcall FUN_0056e6a0(undefined4 *param_1)

{
  *param_1 = _ns1__OpenJob::vftable;
  return;
}



/* FUNCTION 3378 ; VA 0x0056e6b0 ; FUN_0056e6b0 */

void __fastcall FUN_0056e6b0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = _ns1__OpenJobResponse::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 3379 ; VA 0x0056e710 ; FUN_0056e710 */

void __fastcall FUN_0056e710(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1c);
  if ((iVar1 != 0) && (iVar1 != -1)) {
    CloseHandle(iVar1);
  }
  FUN_0056d500();
  LOCK();
  iVar1 = *(int *)(param_1 + 4);
  *(int *)(param_1 + 4) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  return;
}



/* FUNCTION 3380 ; VA 0x0056e750 ; FUN_0056e750 */

void __fastcall FUN_0056e750(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = *param_1;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  return;
}



/* FUNCTION 3381 ; VA 0x0056e770 ; FUN_0056e770 */

uint __fastcall FUN_0056e770(int *param_1)

{
  uint uVar1;
  uint *puVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puVar2 = (uint *)param_1[1];
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  LOCK();
  *(int *)(*param_1 + 8) = *(int *)(*param_1 + 8) + -1;
  UNLOCK();
  uStack_8 = 0;
  LOCK();
  uVar5 = *puVar2;
  *puVar2 = *puVar2 + 0x80000000;
  UNLOCK();
  if (((uVar5 & 0x40000000) == 0) && (-0x80000000 < (int)uVar5)) {
    LOCK();
    uVar1 = *puVar2;
    *puVar2 = *puVar2 | 0x40000000;
    UNLOCK();
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      uVar5 = SetEvent(uVar4);
    }
  }
  param_1 = (int *)*param_1;
  if (param_1 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_1 + 4);
    uVar1 = *puVar2;
    uVar5 = *puVar2;
    *puVar2 = uVar1 - 1;
    UNLOCK();
    if ((uVar1 - 1 == 0) && (param_1 != (int *)0x0)) {
      iVar3 = param_1[1];
      if ((iVar3 != 0) && (iVar3 != -1)) {
        CloseHandle(iVar3);
      }
      iVar3 = *param_1;
      if ((iVar3 != 0) && (iVar3 != -1)) {
        CloseHandle(iVar3);
      }
      uVar5 = FUN_01674ea0(param_1,0x14);
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 3382 ; VA 0x0056e830 ; FUN_0056e830 */

void __fastcall FUN_0056e830(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::error_info_container::vftable;
  return;
}



/* FUNCTION 3383 ; VA 0x0056e840 ; FUN_0056e840 */

void __fastcall FUN_0056e840(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if ((iVar1 != 0) && (iVar1 != -1)) {
    CloseHandle(iVar1);
  }
  return;
}



/* FUNCTION 3384 ; VA 0x0056e860 ; FUN_0056e860 */

void __fastcall FUN_0056e860(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::http_status_error::vftable;
  uVar1 = param_1[8];
  if (0xf < uVar1) {
    iVar2 = param_1[3];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  return;
}



/* FUNCTION 3385 ; VA 0x0056e8d0 ; FUN_0056e8d0 */

void __fastcall FUN_0056e8d0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 4) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 4) + 8))();
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3386 ; VA 0x0056e920 ; FUN_0056e920 */

void __fastcall FUN_0056e920(int param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 4);
  *(int *)(param_1 + 4) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  return;
}



/* FUNCTION 3387 ; VA 0x0056e940 ; FUN_0056e940 */

void __fastcall FUN_0056e940(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = ns1__Job::vftable;
  uVar1 = param_1[7];
  if (0xf < uVar1) {
    iVar2 = param_1[2];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  return;
}



/* FUNCTION 3388 ; VA 0x0056e9a0 ; FUN_0056e9a0 */

void __fastcall FUN_0056e9a0(undefined4 *param_1)

{
  *param_1 = ns1__ScriptExecution::vftable;
  return;
}



/* FUNCTION 3389 ; VA 0x0056e9b0 ; FUN_0056e9b0 */

void __fastcall FUN_0056e9b0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if ((iVar1 != 0) && (iVar1 != -1)) {
    CloseHandle(iVar1);
  }
  return;
}



/* FUNCTION 3390 ; VA 0x0056e9d0 ; FUN_0056e9d0 */

void __fastcall FUN_0056e9d0(undefined4 *param_1)

{
  LeaveCriticalSection(*param_1);
  return;
}



/* FUNCTION 3391 ; VA 0x0056e9e0 ; FUN_0056e9e0 */

void __fastcall FUN_0056e9e0(int *param_1)

{
  int *piVar1;
  char cVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = thunk_FUN_0170e3b7();
  if (cVar2 == '\0') {
    FUN_00577770();
  }
  uStack_8 = 0;
  piVar1 = *(int **)(*(int *)(*(int *)*param_1 + 4) + 0x38 + *param_1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3392 ; VA 0x0056ea40 ; FUN_0056ea40 */

int * __fastcall FUN_0056ea40(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::detail::shared_state_base::vftable;
  piVar5 = (int *)param_1[0x20];
  uStack_8 = 0;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[1] + -1;
    piVar5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar5 + 4))();
      LOCK();
      iVar4 = piVar5[2] + -1;
      piVar5[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar5 + 8))();
      }
    }
  }
  uVar2 = param_1[0x16];
  uStack_8 = 1;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    param_1[0x16] = 0;
  }
  FUN_0056c7e0();
  iVar4 = param_1[0x12];
  if ((iVar4 != 0) && (iVar4 != -1)) {
    CloseHandle(iVar4);
  }
  FUN_0056d500();
  LOCK();
  iVar4 = param_1[0xc];
  param_1[0xc] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  piVar5 = param_1 + 10;
  LOCK();
  iVar4 = *piVar5;
  *piVar5 = 0;
  UNLOCK();
  if (iVar4 != 0) {
    piVar5 = (int *)CloseHandle(iVar4);
  }
  piVar3 = (int *)param_1[5];
  uStack_8 = 2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar4 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      piVar5 = (int *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  piVar3 = (int *)param_1[3];
  uStack_8 = 3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      piVar5 = (int *)(**(code **)(*piVar3 + 8))();
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 3393 ; VA 0x0056eb60 ; FUN_0056eb60 */

void __fastcall FUN_0056eb60(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(code **)(param_1 + 0xc) != (code *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_1 + 0xc))(param_1);
  }
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_00563cc0(*(int *)(param_1 + 0x10));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3394 ; VA 0x0056ebb0 ; FUN_0056ebb0 */

int __fastcall FUN_0056ebb0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016899e0();
  puVar3 = (undefined4 *)*param_1;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*puVar3)(0);
      uVar5 = GetProcessHeap(0,puVar3);
      iVar4 = HeapFree(uVar5);
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 3395 ; VA 0x0056ec10 ; FUN_0056ec10 */

void __fastcall FUN_0056ec10(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::unknown_exception::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3396 ; VA 0x0056ec80 ; FUN_0056ec80 */

undefined * __thiscall FUN_0056ec80(undefined *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  
  piVar1 = *(int **)(param_1 + 4);
  if (piVar1 == (int *)0x0) goto LAB_0056ecc6;
  if (*(int *)piVar1[8] == 0) {
LAB_0056ecb5:
    uVar4 = (**(code **)(*piVar1 + 0xc))(param_2);
  }
  else {
    iVar2 = *(int *)piVar1[0xc];
    if (iVar2 < 1) goto LAB_0056ecb5;
    *(int *)piVar1[0xc] = iVar2 + -1;
    pbVar3 = *(byte **)piVar1[8];
    *(byte **)piVar1[8] = pbVar3 + 1;
    *pbVar3 = param_2;
    uVar4 = (uint)param_2;
  }
  if (uVar4 != 0xffffffff) {
    return param_1;
  }
LAB_0056ecc6:
  *param_1 = 1;
  return param_1;
}



/* FUNCTION 3397 ; VA 0x0056ecd0 ; FUN_0056ecd0 */

undefined4 * __thiscall FUN_0056ecd0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = param_2[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[1];
  }
  *param_1 = *param_2;
  piVar2 = (int *)param_1[1];
  param_1[1] = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 3398 ; VA 0x0056ed30 ; FUN_0056ed30 */

int * __thiscall FUN_0056ed30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  
  if (param_1 != param_2) {
    iVar5 = param_2[1];
    iVar1 = *param_2;
    iVar2 = *param_1;
    uVar3 = (iVar5 - iVar1) / 0xd0;
    uVar6 = (param_1[1] - iVar2) / 0xd0;
    uVar4 = (param_1[2] - iVar2) / 0xd0;
    if (uVar4 < uVar3) {
      if (0x13b13b1 < uVar3) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar6 = uVar3;
      if ((uVar4 <= 0x13b13b1 - (uVar4 >> 1)) && (uVar6 = (uVar4 >> 1) + uVar4, uVar6 < uVar3)) {
        uVar6 = uVar3;
      }
      if (iVar2 != 0) {
        FUN_00559720(iVar2,param_1[1],param_1);
        FUN_0057d370(*param_1,uVar4);
      }
      FUN_005759f0(uVar6);
      iVar5 = FUN_0055c4f0(iVar1,iVar5,*param_1);
      param_1[1] = iVar5;
      return param_1;
    }
    if (uVar6 < uVar3) {
      iVar7 = uVar6 * 0xd0 + iVar1;
      FUN_00559470(iVar1,iVar7,iVar2);
      iVar5 = FUN_0055c4f0(iVar7,iVar5,param_1[1]);
      param_1[1] = iVar5;
      return param_1;
    }
    iVar7 = uVar3 * 0xd0 + iVar2;
    FUN_00559470(iVar1,iVar5,iVar2);
    FUN_00559720(iVar7,param_1[1],param_1);
    param_1[1] = iVar7;
  }
  return param_1;
}



/* FUNCTION 3399 ; VA 0x0056ee80 ; FUN_0056ee80 */

undefined4 * __thiscall FUN_0056ee80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = param_2 + 1;
  piVar2 = param_1 + 1;
  *param_1 = *param_2;
  if (piVar1 != piVar2) {
    if (*piVar2 != 0) {
      (**(code **)(*piVar2 + 8))(param_1 + 2);
      *piVar2 = 0;
    }
    if ((undefined4 *)*piVar1 != (undefined4 *)0x0) {
      (**(code **)*piVar1)(param_2 + 2,param_1 + 2);
      *piVar2 = *piVar1;
    }
  }
  return param_1;
}



/* FUNCTION 3400 ; VA 0x0056eee0 ; FUN_0056eee0 */

undefined4 * __thiscall FUN_0056eee0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  iVar3 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
  }
  *param_1 = uVar2;
  piVar4 = (int *)param_1[1];
  param_1[1] = iVar3;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3401 ; VA 0x0056ef60 ; FUN_0056ef60 */

int * __thiscall FUN_0056ef60(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint auStack_38 [2];
  int *piStack_30;
  undefined uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949c8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  iVar7 = *param_1;
  uStack_28 = 0;
  piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  piStack_18 = param_1;
  puVar2 = &stack0xffffffbc;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar7 = *param_1;
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  iVar1 = *(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1);
  uStack_2c = iVar1 == 0;
  uStack_8 = 1;
  if (iVar1 == 0) {
    piStack_20 = *(int **)(*(int *)(*(int *)(iVar7 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_1c = piStack_20;
    (**(code **)(*piStack_20 + 4))();
    uStack_8._0_1_ = 3;
    piStack_20 = (int *)FUN_00564aa0(auStack_24);
    uStack_8._0_1_ = 4;
    if ((piStack_1c != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_1c + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar7 = *(int *)(*param_1 + 4) + (int)param_1;
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,
                                 *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uVar8 = auStack_38[0];
    (**(code **)(*piStack_20 + 0x20))
              (auStack_38,auStack_38[0],*(undefined4 *)(iVar7 + 0x38),iVar7,piStack_1c,param_2);
    piVar5 = (int *)FUN_0056f08b(uVar8);
    return piVar5;
  }
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar8;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3402 ; VA 0x0056f06c ; Catch_All@0056f06c */

undefined * Catch_All_0056f06c(void)

{
  FUN_005565b0(4,1);
  return &DAT_0056f085;
}



/* FUNCTION 3403 ; VA 0x0056f08b ; FUN_0056f08b */

void FUN_0056f08b(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 8;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 3404 ; VA 0x0056f100 ; FUN_0056f100 */

int * __thiscall FUN_0056f100(int *param_1,code *param_2)

{
  if (param_1 == (int *)0x0) {
    (*param_2)(0);
    return (int *)0x0;
  }
  (*param_2)(*(int *)(*param_1 + 4) + (int)param_1);
  return param_1;
}



/* FUNCTION 3405 ; VA 0x0056f130 ; FUN_0056f130 */

int * __thiscall FUN_0056f130(int *param_1,int *param_2)

{
  undefined *puVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  byte *pbVar7;
  uint uVar8;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949f0;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  bVar2 = false;
  iVar4 = *param_1;
  piVar5 = *(int **)(*(int *)(iVar4 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar4 = *param_1;
  }
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar4 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar4 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar4 = *param_1;
  }
  uStack_8 = 1;
  uVar6 = 0;
  if ((*(int *)(*(int *)(iVar4 + 4) + 0xc + (int)param_1) == 0) && (param_2 != (int *)0x0)) {
    uVar8 = 0xffffffff;
    do {
      piVar5 = (int *)param_2[7];
      uStack_8 = 2;
      if (uVar8 == 0xffffffff) {
LAB_0056f219:
        if (((byte *)*piVar5 == (byte *)0x0) || (*(int *)param_2[0xb] < 1)) {
          uVar8 = (**(code **)(*param_2 + 0x18))();
        }
        else {
          uVar8 = (uint)*(byte *)*piVar5;
        }
      }
      else if (*piVar5 == 0) {
LAB_0056f206:
        uVar6 = (**(code **)(*param_2 + 0x1c))();
LAB_0056f20d:
        if (uVar6 != 0xffffffff) {
          piVar5 = (int *)param_2[7];
          goto LAB_0056f219;
        }
        uVar8 = 0xffffffff;
      }
      else {
        piVar5 = (int *)param_2[0xb];
        iVar4 = *piVar5;
        if (iVar4 < 2) {
          if (iVar4 < 1) goto LAB_0056f206;
          *piVar5 = iVar4 + -1;
          pbVar7 = *(byte **)param_2[7];
          *(byte **)param_2[7] = pbVar7 + 1;
          uVar6 = (uint)*pbVar7;
          goto LAB_0056f20d;
        }
        *piVar5 = iVar4 + -1;
        pbVar7 = (byte *)(*(int *)param_2[7] + 1);
        *(int *)param_2[7] = (int)pbVar7;
        uVar8 = (uint)*pbVar7;
      }
      uStack_8 = 1;
      uVar6 = uStack_24;
      if (uVar8 == 0xffffffff) break;
      uStack_8._0_1_ = 4;
      uStack_8._1_3_ = 0;
      piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      if (*(int *)piVar5[8] == 0) {
LAB_0056f276:
        uVar6 = (**(code **)(*piVar5 + 0xc))(uVar8 & 0xff);
      }
      else {
        iVar4 = *(int *)piVar5[0xc];
        if (iVar4 < 1) goto LAB_0056f276;
        *(int *)piVar5[0xc] = iVar4 + -1;
        puVar1 = *(undefined **)piVar5[8];
        *(undefined **)piVar5[8] = puVar1 + 1;
        *puVar1 = (char)uVar8;
        uVar6 = uVar8 & 0xff;
      }
      if (uVar6 == 0xffffffff) goto code_r0x0056f286;
      bVar2 = true;
    } while( true );
  }
LAB_0056f2c4:
  iVar4 = *(int *)(*param_1 + 4);
  *(undefined4 *)(iVar4 + 0x20 + (int)param_1) = 0;
  *(undefined4 *)(iVar4 + 0x24 + (int)param_1) = 0;
  if (param_2 == (int *)0x0) {
    uVar6 = 4;
  }
  else if (!bVar2) {
    uVar6 = uVar6 | 2;
  }
  uVar6 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | uVar6;
  uVar8 = uVar6 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar8 = uVar6;
  }
  FUN_00554460(uVar8,0);
  uStack_8 = 6;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
code_r0x0056f286:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar6 = 4;
  goto LAB_0056f2c4;
}



/* FUNCTION 3406 ; VA 0x0056f28f ; Catch_All@0056f28f */

undefined * Catch_All_0056f28f(void)

{
  FUN_005565b0(4,1);
  return &DAT_0056f2a8;
}



/* FUNCTION 3407 ; VA 0x0056f350 ; Catch_All@0056f350 */

void Catch_All_0056f350(void)

{
  FUN_005565b0(2,0);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3408 ; VA 0x0056f370 ; FUN_0056f370 */

bool __thiscall FUN_0056f370(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_1 + 4,param_2 + 4);
  return iVar1 == 0;
}



/* FUNCTION 3409 ; VA 0x0056f390 ; FUN_0056f390 */

undefined4 * FUN_0056f390(undefined4 param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794a08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x98);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,void_(__cdecl*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_RBX::DataModel>_const&,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_const&,class_RBX::Timer<0>),class_boost::_bi::list6<class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>,class_boost::_bi::value<class_RBX::Timer<0>_>_>_>_>
              ::vftable;
    FUN_00565a80(param_1);
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 3410 ; VA 0x0056f400 ; Catch_All@0056f400 */

void Catch_All_0056f400(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3411 ; VA 0x0056f430 ; FUN_0056f430 */

int __thiscall FUN_0056f430(undefined4 *param_1,int param_2)

{
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  return param_2 + (int)param_1;
}



/* FUNCTION 3412 ; VA 0x0056f450 ; FUN_0056f450 */

undefined4 * __thiscall FUN_0056f450(int *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puStack_8;
  
  puVar3 = param_2;
  puStack_8 = (undefined4 *)*param_1;
  cVar1 = *(char *)((int)puStack_8[1] + 0xd);
  puVar2 = puStack_8;
  puVar7 = (undefined4 *)puStack_8[1];
  while (cVar1 == '\0') {
    piVar5 = puVar7 + 4;
    puVar6 = puVar3;
    if (0xf < (uint)puVar3[5]) {
      puVar6 = (undefined4 *)*puVar3;
    }
    if (0xf < (uint)puVar7[9]) {
      piVar5 = (int *)*piVar5;
    }
    iVar4 = FUN_0055c2d0(piVar5,puVar7[8],puVar6,puVar3[4]);
    if (iVar4 < 0) {
      puVar6 = (undefined4 *)puVar7[2];
      puVar7 = puVar2;
    }
    else {
      puVar6 = (undefined4 *)*puVar7;
    }
    puVar2 = puVar7;
    puVar7 = puVar6;
    cVar1 = *(char *)((int)puVar6 + 0xd);
  }
  if (puVar2 != puStack_8) {
    piVar5 = puVar2 + 4;
    if (0xf < (uint)puVar2[9]) {
      piVar5 = (int *)*piVar5;
    }
    puVar7 = puVar3;
    if (0xf < (uint)puVar3[5]) {
      puVar7 = (undefined4 *)*puVar3;
    }
    iVar4 = FUN_0055c2d0(puVar7,puVar3[4],piVar5,puVar2[8]);
    if (-1 < iVar4) {
      return puVar2 + 10;
    }
  }
  puStack_8 = puVar3;
  iVar4 = FUN_00559200(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_0055a7d0(&param_2,puVar2,iVar4 + 0x10,iVar4);
  return param_2 + 10;
}



/* FUNCTION 3413 ; VA 0x0056f520 ; FUN_0056f520 */

int __thiscall FUN_0056f520(int *param_1,int param_2)

{
  return param_2 * 0xd0 + *param_1;
}



/* FUNCTION 3414 ; VA 0x0056f530 ; FUN_0056f530 */

bool __fastcall FUN_0056f530(int *param_1)

{
  return *param_1 != 0;
}



/* FUNCTION 3415 ; VA 0x0056f540 ; FUN_0056f540 */

undefined2 __fastcall FUN_0056f540(undefined2 *param_1)

{
  return *param_1;
}



/* FUNCTION 3416 ; VA 0x0056f550 ; FUN_0056f550 */

int __fastcall FUN_0056f550(int *param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *param_1;
  *param_1 = *param_1 + 1;
  UNLOCK();
  return iVar1;
}



/* FUNCTION 3417 ; VA 0x0056f560 ; FUN_0056f560 */

int * __fastcall FUN_0056f560(int *param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  piVar2 = (int *)*param_1;
  if (*(char *)((int)piVar2 + 0xd) != '\0') {
    *param_1 = piVar2[2];
    return param_1;
  }
  iVar3 = *piVar2;
  if (*(char *)(iVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*(int *)(iVar3 + 8) + 0xd);
    iVar4 = *(int *)(iVar3 + 8);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar3 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *param_1 = iVar3;
  }
  else {
    cVar1 = *(char *)(piVar2[1] + 0xd);
    piVar5 = (int *)piVar2[1];
    while ((cVar1 == '\0' && (piVar2 == (int *)*piVar5))) {
      *param_1 = (int)piVar5;
      cVar1 = *(char *)(piVar5[1] + 0xd);
      piVar2 = piVar5;
      piVar5 = (int *)piVar5[1];
    }
    if (*(char *)((int)piVar2 + 0xd) == '\0') {
      *param_1 = (int)piVar5;
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 3418 ; VA 0x0056f5f0 ; FUN_0056f5f0 */

int __fastcall FUN_0056f5f0(int *param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *param_1;
  *param_1 = *param_1 + -1;
  UNLOCK();
  return iVar1;
}



/* FUNCTION 3419 ; VA 0x0056f600 ; FUN_0056f600 */

void __thiscall FUN_0056f600(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 **ppuStack_68;
  undefined8 *puStack_64;
  undefined auStack_30 [12];
  undefined **ppuStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794a30;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    puStack_18 = (undefined4 *)(param_3 + 0x74);
    if (0xf < *(uint *)(param_3 + 0x88)) {
      puStack_18 = (undefined4 *)*puStack_18;
    }
    puStack_64 = &uStack_20;
    ppuStack_24 = std::exception::vftable;
    ppuStack_68 = &puStack_18;
    uStack_20 = 0;
    uStack_14 = 1;
    ExceptionList = &pvStack_10;
    FUN_0170c226();
    ppuStack_24 = std::runtime_error::vftable;
    uStack_8 = 0;
    FUN_0055de60(&ppuStack_68,&ppuStack_24);
    FUN_0058bc20();
    puStack_64 = &uStack_20;
    ppuStack_24 = std::exception::vftable;
    ppuStack_68 = (undefined4 **)0x56f68c;
    FUN_0170c289();
    ExceptionList = pvStack_10;
    return;
  }
  iVar1 = *(int *)(param_3 + 0xc);
  if ((iVar1 - 200U < 100) && (iVar1 != 0xca)) {
    ppuStack_68 = &DAT_01d79ea8;
    if (0xf < DAT_01d79ebc) {
      ppuStack_68 = DAT_01d79ea8;
    }
    puStack_64 = (undefined8 *)DAT_01d79eb8;
    ExceptionList = &pvStack_10;
    FUN_014ca040(&puStack_18);
    puStack_64 = (undefined8 *)auStack_30;
    ppuStack_68 = (undefined4 **)0x56f6f7;
    puStack_64 = (undefined8 *)FUN_0058c4f0();
    ppuStack_68 = (undefined4 **)0x56f700;
    FUN_005511f0();
    puStack_64 = (undefined8 *)0x56f708;
    FUN_005507b0();
    if (*(int *)(*(int *)(param_1 + 8) + 0x10) == 0) {
      puStack_64 = (undefined8 *)0x7;
      ppuStack_68 = (undefined4 **)&DAT_018bf2f0;
      FUN_005542c0();
    }
    puStack_64 = (undefined8 *)(param_3 + 0x40);
    ppuStack_68 = (undefined4 **)0x56f728;
    FUN_0058bd10();
    ExceptionList = pvStack_10;
    return;
  }
  puStack_64 = (undefined8 *)(param_3 + 0x40);
  ppuStack_68 = (undefined4 **)(param_3 + 0x74);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_014cc1e0(iVar1);
  uStack_8 = 1;
  FUN_0055ddf0(&ppuStack_68,uVar2);
  FUN_0058bc20();
  puStack_64 = (undefined8 *)0x56f772;
  FUN_0056e860();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3420 ; VA 0x0056f790 ; FUN_0056f790 */

int FUN_0056f790(undefined4 param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [8];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794a68;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d5af18 == '\0') {
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_005df000(param_2,param_3,param_4,param_5,param_7,param_1);
    if (iVar4 != 0) {
      if (DAT_01d59037 != '\0') {
        FUN_01677520(DAT_01d59037,"Error! Failed to send security report from player ID %lld.",
                     param_4,param_5);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_SecurityReportFailed",0x4a
                  );
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      goto LAB_0056f968;
    }
    if (DAT_01d59037 != '\0') {
      FUN_01677520(DAT_01d59037,"Successfully sent security report from player ID %lld.",param_4,
                   param_5);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("ExternalAntiCheat_Successful_SecurityReport",0x2b);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
  }
  else {
    puVar3 = param_2 + 6;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)
             FUN_005de470(auStack_30,param_4,param_5,param_6,param_7,param_8,param_2,*puVar3);
    uStack_50 = *puVar3;
    uStack_4c = puVar3[1];
    uStack_48 = puVar3[2];
    uStack_44 = puVar3[3];
    uStack_40 = puVar3[4];
    uStack_3c = puVar3[5];
    uStack_38 = puVar3[6];
    uStack_34 = puVar3[7];
    iVar4 = FUN_005defa0(&uStack_50,param_1);
    if (iVar4 != 0) {
      if (DAT_01d59037 != '\0') {
        FUN_01677520(DAT_01d59037,"Error! Failed to send security report from player ID %lld.",
                     param_4,param_5);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_SecurityReportFailed",0x4a
                  );
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
LAB_0056f968:
      FUN_00878480(auStack_28,0);
      goto LAB_0056f976;
    }
    if (DAT_01d59037 != '\0') {
      FUN_01677520(DAT_01d59037,"Successfully sent security report from player ID %lld.",param_4,
                   param_5);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("ExternalAntiCheat_Successful_SecurityReport",0x2b);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
  }
  FUN_008783f0(auStack_28,1,0);
LAB_0056f976:
  iVar4 = FUN_005507b0();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 3421 ; VA 0x0056f9c0 ; FUN_0056f9c0 */

undefined4 ***** FUN_0056f9c0(undefined4 param_1)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  undefined4 ***pppuVar3;
  undefined4 ****ppppuVar4;
  undefined4 *****pppppuVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 ******ppppppuVar8;
  undefined4 ****ppppuVar9;
  bool bVar10;
  undefined8 uVar11;
  undefined4 uStack_e8;
  undefined *puStack_e4;
  undefined auStack_e0 [8];
  undefined4 *****pppppuStack_d8;
  undefined4 ***apppuStack_cc [8];
  undefined auStack_ac [32];
  undefined auStack_8c [24];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 ****ppppuStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *****pppppuStack_50;
  undefined4 ***pppuStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 ****ppppuStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 ****ppppuStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ad4;
  pvStack_10 = ExceptionList;
  uStack_54 = 0;
  auStack_e0._4_4_ = &ppppuStack_18;
  pppppuStack_d8 = (undefined4 *****)param_1;
  auStack_e0._0_4_ = (undefined4 *****)0x56f9f3;
  ExceptionList = &pvStack_10;
  FUN_00562c90();
  uStack_8 = 0;
  if ((undefined4 *****)ppppuStack_18 == (undefined4 *****)0x0) {
    pppppuVar5 = (undefined4 *****)(uint)DAT_01d59037;
    if (DAT_01d59037 != 0) {
      pppppuStack_d8 = (undefined4 *****)ppppuStack_18;
      auStack_e0._0_4_ = ZEXT14(DAT_01d59037);
      auStack_e0._4_4_ =
           "ERROR - Empty player in RemoveUser external anticheat callback, returning...";
      puStack_e4 = (undefined *)0x56fa23;
      pppppuVar5 = (undefined4 *****)FUN_016774b0();
    }
    goto LAB_0056fdaa;
  }
  bVar10 = DAT_01d5ace8 == '\0';
  if (bVar10) {
    pppppuStack_d8 = (undefined4 *****)0x0;
    auStack_e0._4_4_ = &DAT_018bc9b8;
    uStack_20 = 0;
    uStack_1c = 0xf;
    ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
    auStack_e0._0_4_ = (undefined4 *****)0x56fa68;
    FUN_005542c0();
    pppppuVar5 = &ppppuStack_30;
  }
  else {
    pppppuStack_d8 = (undefined4 *****)auStack_8c;
    auStack_e0._4_4_ = (undefined4 ******)0x56fa40;
    pppppuVar5 = (undefined4 *****)FUN_00927520();
  }
  pppppuStack_50 = (undefined4 *****)*pppppuVar5;
  pppuStack_4c = pppppuVar5[1];
  pppuStack_48 = pppppuVar5[2];
  pppuStack_44 = pppppuVar5[3];
  uStack_40 = *(undefined8 *)(pppppuVar5 + 4);
  pppppuVar5[4] = (undefined4 ****)0x0;
  pppppuVar5[5] = (undefined4 ****)0xf;
  *(undefined *)pppppuVar5 = 0;
  uStack_8 = 2;
  if (bVar10) {
    pppppuStack_d8 = (undefined4 *****)0x56faba;
    FUN_005507b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (!bVar10) {
    pppppuStack_d8 = (undefined4 *****)0x56fad1;
    FUN_005507b0();
  }
  ppppuVar9 = (undefined4 ****)ppppuStack_18[0xde];
  pppppuVar5 = (undefined4 *****)(ppppuStack_18 + 0xdd);
  if (ppppuVar9 != (undefined4 ****)0x0) {
    LOCK();
    ppppuVar9[1] = (undefined4 ***)((int)ppppuVar9[1] + 1);
    UNLOCK();
    ppppuVar9 = (undefined4 ****)ppppuStack_18[0xde];
  }
  ppppuVar4 = *pppppuVar5;
  if (ppppuVar9 != (undefined4 ****)0x0) {
    LOCK();
    ppppuVar1 = ppppuVar9 + 1;
    pppuVar3 = *ppppuVar1;
    pppppuVar5 = (undefined4 *****)*ppppuVar1;
    *ppppuVar1 = (undefined4 ***)((int)pppuVar3 + -1);
    UNLOCK();
    if ((undefined4 ***)((int)pppuVar3 + -1) == (undefined4 ***)0x0) {
      pppppuStack_d8 = (undefined4 *****)0x56fb06;
      (*(code *)**ppppuVar9)();
      LOCK();
      ppppuVar1 = ppppuVar9 + 2;
      pppuVar3 = *ppppuVar1;
      pppppuVar5 = (undefined4 *****)*ppppuVar1;
      *ppppuVar1 = (undefined4 ***)((int)pppuVar3 + -1);
      UNLOCK();
      if ((undefined4 ***)((int)pppuVar3 + -1) == (undefined4 ***)0x0) {
        pppppuStack_d8 = (undefined4 *****)0x56fb16;
        pppppuVar5 = (undefined4 *****)(*(code *)(*ppppuVar9)[1])();
      }
    }
  }
  if (ppppuVar4 != (undefined4 ****)0x0) {
    if (DAT_01d5af18 == '\0') {
      pppppuStack_d8 = &ppppuStack_30;
      auStack_e0._4_4_ = 0x56fc74;
      puVar6 = (undefined4 *)FUN_00927520();
      uStack_8._0_1_ = 6;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      pppppuStack_d8 = (undefined4 *****)0x56fc8a;
      auStack_e0 = (undefined  [8])FUN_00928340();
      pppppuStack_d8 = (undefined4 *****)puVar6;
      FUN_005817f0(&uStack_e8);
      iVar7 = FUN_005deed0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      pppppuStack_d8 = (undefined4 *****)0x56fcaf;
      FUN_005507b0();
      if (iVar7 == 0) {
        if (DAT_01d59037 != 0) {
          pppppuStack_d8 = (undefined4 *****)0x56fcc4;
          uVar11 = FUN_00928340();
          puStack_e4 = (undefined *)(uint)DAT_01d59037;
          auStack_e0._0_4_ =
               "Successfully removed player with ID %lld from external anticheat module.";
          uStack_e8 = 0x56fcd8;
          unique0x10000484 = uVar11;
          FUN_01677520();
        }
        pppppuStack_d8 = (undefined4 *****)0x29;
        auStack_e0._4_4_ = "ExternalAntiCheat_Successful_PlayerRemove";
        uStack_20 = 0;
        uStack_1c = 0xf;
        ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
        auStack_e0._0_4_ = 0x56fcfc;
        FUN_005542c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        goto LAB_0056fc04;
      }
      if (DAT_01d59037 != 0) {
        pppppuStack_d8 = (undefined4 *****)0x56fd16;
        uVar11 = FUN_00928340();
        puStack_e4 = (undefined *)(uint)DAT_01d59037;
        auStack_e0._0_4_ =
             "Error! Failed to remove player with ID %lld from external anticheat module.";
        uStack_e8 = 0x56fd2a;
        unique0x1000048c = uVar11;
        FUN_01677520();
      }
      pppppuStack_d8 = (undefined4 *****)0x48;
      auStack_e0._4_4_ = "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_PlayerRemoveFailed";
      uStack_20 = 0;
      uStack_1c = 0xf;
      ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
      auStack_e0._0_4_ = 0x56fd4e;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
LAB_0056fd52:
      auStack_e0._4_4_ = &ppppuStack_30;
      pppppuStack_d8 = (undefined4 *****)0x0;
      auStack_e0._0_4_ = (undefined4 *****)0x56fd5d;
      FUN_00878480();
    }
    else {
      if (DAT_01d5ace8 == '\0') {
        pppppuStack_d8 = (undefined4 *****)0x56fb6c;
        FUN_00927ca0();
        pppppuStack_d8 = (undefined4 *****)0x56fb73;
        pppppuStack_d8 = (undefined4 *****)FUN_005f7790();
        auStack_e0._4_4_ = &ppppuStack_18;
        auStack_e0._0_4_ = apppuStack_cc;
        puStack_e4 = (undefined *)0x56fb84;
        puVar6 = (undefined4 *)FUN_005de4b0();
      }
      else {
        ppppppuVar8 = &pppppuStack_50;
        if (0xf < uStack_40._4_4_) {
          ppppppuVar8 = (undefined4 ******)pppppuStack_50;
        }
        pppppuStack_d8 = (undefined4 *****)0x56fb49;
        FUN_00927ca0();
        pppppuStack_d8 = (undefined4 *****)0x56fb50;
        auStack_e0._4_4_ = FUN_005f7790();
        auStack_e0._0_4_ = &ppppuStack_18;
        puStack_e4 = auStack_ac;
        uStack_e8 = 0x56fb62;
        pppppuStack_d8 = ppppppuVar8;
        puVar6 = (undefined4 *)FUN_005de3a0();
      }
      uStack_74 = *puVar6;
      uStack_70 = puVar6[1];
      ppppuStack_6c = (undefined4 ****)puVar6[2];
      uStack_68 = puVar6[3];
      uStack_64 = puVar6[4];
      uStack_60 = puVar6[5];
      uStack_5c = puVar6[6];
      uStack_58 = puVar6[7];
      pppppuStack_d8 = (undefined4 *****)&uStack_74;
      auStack_e0._4_4_ = 0x56fbb1;
      uStack_38 = uStack_74;
      uStack_34 = uStack_70;
      ppppuStack_30 = ppppuStack_6c;
      uStack_2c = uStack_68;
      uStack_28 = uStack_64;
      uStack_24 = uStack_60;
      uStack_20 = uStack_5c;
      uStack_1c = uStack_58;
      iVar7 = FUN_005dee90();
      if (iVar7 != 0) {
        if (DAT_01d59037 != 0) {
          pppppuStack_d8 = (undefined4 *****)0x56fc2a;
          join_0x00000008_0x00000000_ = FUN_00928340();
          puStack_e4 = (undefined *)(uint)DAT_01d59037;
          auStack_e0._0_4_ =
               "Error! Failed to remove player with ID %lld from external anticheat module.";
          uStack_e8 = 0x56fc3e;
          FUN_01677520();
        }
        pppppuStack_d8 = (undefined4 *****)0x48;
        auStack_e0._4_4_ =
             "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_PlayerRemoveFailed";
        uStack_20 = 0;
        uStack_1c = 0xf;
        ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
        auStack_e0._0_4_ = 0x56fc62;
        FUN_005542c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        goto LAB_0056fd52;
      }
      if (DAT_01d59037 != 0) {
        pppppuStack_d8 = (undefined4 *****)0x56fbc8;
        join_0x00000008_0x00000000_ = FUN_00928340();
        puStack_e4 = (undefined *)(uint)DAT_01d59037;
        auStack_e0._0_4_ =
             "Successfully removed player with ID %lld from external anticheat module.";
        uStack_e8 = 0x56fbdc;
        FUN_01677520();
      }
      pppppuStack_d8 = (undefined4 *****)0x29;
      auStack_e0._4_4_ = "ExternalAntiCheat_Successful_PlayerRemove";
      uStack_20 = 0;
      uStack_1c = 0xf;
      ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
      auStack_e0._0_4_ = 0x56fc00;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
LAB_0056fc04:
      pppppuStack_d8 = (undefined4 *****)0x0;
      auStack_e0._0_4_ = &ppppuStack_30;
      auStack_e0._4_4_ = (undefined4 ******)0x1;
      puStack_e4 = (undefined *)0x56fc11;
      FUN_008783f0();
    }
    pppppuStack_d8 = (undefined4 *****)0x56fd68;
    pppppuVar5 = (undefined4 *****)FUN_005507b0();
  }
  if (0xf < uStack_40._4_4_) {
    pppppuStack_d8 = (undefined4 *****)(uStack_40._4_4_ + 1);
    ppppppuVar8 = (undefined4 ******)pppppuStack_50;
    if (0xfff < pppppuStack_d8) {
      ppppppuVar8 = (undefined4 ******)pppppuStack_50[-1];
      pppppuStack_d8 = (undefined4 *****)(uStack_40._4_4_ + 0x24);
      if ((undefined1 *)0x1f < (undefined1 *)((int)pppppuStack_50 + (-4 - (int)ppppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        pppppuStack_d8 = (undefined4 *****)&UNK_0056fde6;
        FUN_017167a3();
      }
    }
    auStack_e0._0_4_ = (undefined4 *****)0x56fd95;
    auStack_e0._4_4_ = ppppppuVar8;
    pppppuVar5 = (undefined4 *****)FUN_01674ea0();
  }
  uStack_40 = 0xf00000000;
  pppppuStack_50 = (undefined4 *****)((uint)pppppuStack_50 & 0xffffff00);
LAB_0056fdaa:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar7 = *piVar2;
    pppppuVar5 = (undefined4 *****)*piVar2;
    *piVar2 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      pppppuStack_d8 = (undefined4 *****)0x56fdc0;
      pppppuVar5 = (undefined4 *****)(**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        pppppuStack_d8 = (undefined4 *****)0x56fdcf;
        pppppuVar5 = (undefined4 *****)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pppppuVar5;
}



/* FUNCTION 3422 ; VA 0x0056fdf0 ; FUN_0056fdf0 */

uint FUN_0056fdf0(undefined4 param_1)

{
  uint *puVar1;
  undefined4 uVar2;
  undefined4 ****ppppuVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  undefined auStack_ec [4];
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined8 uStack_dc;
  int aiStack_cc [8];
  undefined auStack_ac [32];
  undefined auStack_8c [24];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 **ppuStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 ***pppuStack_54;
  undefined4 **ppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **ppuStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 ***pppuStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01794b3c;
  pvStack_10 = ExceptionList;
  uStack_dc._4_4_ = (undefined4 ****)param_1;
  uStack_dc._0_4_ = (char *)&uStack_18;
  uStack_1c = 0;
  uStack_e4._4_4_ = (char *)0x56fe23;
  ExceptionList = &pvStack_10;
  FUN_00562c90();
  iStack_8 = 0;
  if (uStack_18 == 0) {
    uStack_dc._4_4_ = (undefined4 ****)0x49;
    uStack_24 = uStack_18;
    pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
    uStack_dc._0_4_ = "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_PlayersInstanceNull";
    uStack_20 = 0xf;
    uStack_e4._4_4_ = (char *)0x56fe57;
    FUN_005542c0();
    uStack_dc._0_4_ = (char *)&pppuStack_34;
    iStack_8._0_1_ = 1;
    uStack_dc._4_4_ = (undefined4 ****)0x0;
    uStack_e4._4_4_ = (char *)0x56fe66;
    FUN_00878480();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_20) {
      uStack_dc._4_4_ = (undefined4 ****)(uStack_20 + 1);
      ppppuVar3 = (undefined4 ****)pppuStack_34;
      if (0xfff < uStack_dc._4_4_) {
        ppppuVar3 = (undefined4 ****)pppuStack_34[-1];
        uStack_dc._4_4_ = (undefined4 ****)(uStack_20 + 0x24);
        if ((undefined1 *)0x1f < (undefined1 *)((int)pppuStack_34 + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          uStack_dc._4_4_ = (undefined4 ****)0x570281;
          FUN_017167a3();
        }
      }
      uStack_e4._4_4_ = (char *)0x56fe9e;
      uStack_dc._0_4_ = (char *)ppppuVar3;
      FUN_01674ea0();
    }
    uStack_18 = (uint)DAT_01d59037;
    if (DAT_01d59037 != 0) {
      uStack_dc._4_4_ = (undefined4 ****)0x0;
      uStack_e4._4_4_ = (char *)(uint)DAT_01d59037;
      uStack_dc._0_4_ = "ERROR - Empty player in AddUser external anticheat callback, returning...";
      uStack_e4._0_4_ = (undefined *)0x56febe;
      uStack_18 = FUN_016774b0();
    }
    goto LAB_00570245;
  }
  uStack_dc._4_4_ = (undefined4 ****)0x56fecb;
  FUN_00927ca0();
  uStack_dc._4_4_ = (undefined4 ****)0x56fed2;
  uVar2 = FUN_005f7790();
  if (DAT_01d5ace8 == '\0') {
    uStack_dc._4_4_ = (undefined4 ****)0x0;
    uStack_dc._0_4_ = &DAT_018bc9b8;
    uStack_24 = 0;
    uStack_20 = 0xf;
    pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
    uStack_e4._4_4_ = (char *)0x56ff15;
    FUN_005542c0();
    ppppuVar3 = &pppuStack_34;
    uVar6 = 2;
  }
  else {
    uStack_dc._4_4_ = (undefined4 ****)auStack_8c;
    uStack_dc._0_4_ = (char *)0x56feed;
    ppppuVar3 = (undefined4 ****)FUN_00927520();
    uVar6 = 1;
  }
  pppuStack_54 = *ppppuVar3;
  ppuStack_50 = ppppuVar3[1];
  ppuStack_4c = ppppuVar3[2];
  ppuStack_48 = ppppuVar3[3];
  uStack_44 = *(undefined8 *)(ppppuVar3 + 4);
  ppppuVar3[4] = (undefined4 ***)0x0;
  ppppuVar3[5] = (undefined4 ***)0xf;
  *(undefined *)ppppuVar3 = 0;
  iStack_8 = 3;
  if ((uVar6 & 2) != 0) {
    uStack_1c = uVar6 & 0xfffffffd;
    uStack_dc._4_4_ = (undefined4 ****)0x56ff67;
    FUN_005507b0();
    uVar6 = uStack_1c;
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,4);
  if ((uVar6 & 1) != 0) {
    uStack_dc._4_4_ = (undefined4 ****)0x56ff7e;
    FUN_005507b0();
  }
  piVar7 = *(int **)(uStack_18 + 0x378);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = *(int **)(uStack_18 + 0x378);
  }
  uStack_1c = *(uint *)(uStack_18 + 0x374);
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar6 = *puVar1;
    uStack_18 = *puVar1;
    *puVar1 = uVar6 - 1;
    UNLOCK();
    if (uVar6 - 1 == 0) {
      uStack_dc._4_4_ = (undefined4 ****)0x56ffb1;
      (**(code **)*piVar7)();
      LOCK();
      puVar1 = (uint *)(piVar7 + 2);
      uVar6 = *puVar1;
      uStack_18 = *puVar1;
      *puVar1 = uVar6 - 1;
      UNLOCK();
      if (uVar6 - 1 == 0) {
        uStack_dc._4_4_ = (undefined4 ****)0x56ffc1;
        uStack_18 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (uStack_1c != 0) {
    if (DAT_01d5af18 == '\0') {
      uStack_dc._4_4_ = &pppuStack_34;
      uStack_dc._0_4_ = (char *)0x57010c;
      puVar4 = (undefined4 *)FUN_00927520();
      iStack_8._0_1_ = 7;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      uStack_dc._4_4_ = (undefined4 ****)0x570122;
      uStack_e4 = FUN_00928340();
      uStack_dc._0_4_ = (char *)puVar4;
      uStack_dc._4_4_ = (undefined4 ****)uVar2;
      FUN_005817f0(auStack_ec);
      iVar5 = FUN_005dd2d0();
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      uStack_dc._4_4_ = (undefined4 ****)0x57014a;
      FUN_005507b0();
      if (iVar5 == 0) {
        if (DAT_01d59037 != 0) {
          uStack_dc._4_4_ = (undefined4 ****)0x57015f;
          uStack_dc = FUN_00928340();
          uStack_e4._0_4_ = (undefined *)(uint)DAT_01d59037;
          uStack_e4._4_4_ = "Successfully added player with ID %lld to external anticheat module.";
          uStack_e8 = 0x570173;
          FUN_01677520();
        }
        uStack_dc._4_4_ = (undefined4 ****)0x26;
        uStack_dc._0_4_ = "ExternalAntiCheat_Successful_PlayerAdd";
        uStack_24 = 0;
        uStack_20 = 0xf;
        pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
        uStack_e4._4_4_ = (char *)0x570197;
        FUN_005542c0();
        iStack_8 = CONCAT31(iStack_8._1_3_,8);
        goto LAB_00570099;
      }
      if (DAT_01d59037 != 0) {
        uStack_dc._4_4_ = (undefined4 ****)0x5701b1;
        uStack_dc = FUN_00928340();
        uStack_e4._0_4_ = (undefined *)(uint)DAT_01d59037;
        uStack_e4._4_4_ = "Error! Failed to player with ID %lld to external anticheat module.";
        uStack_e8 = 0x5701c5;
        FUN_01677520();
      }
      uStack_dc._4_4_ = (undefined4 ****)0x45;
      uStack_dc._0_4_ = "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_PlayerAddFailed";
      uStack_24 = 0;
      uStack_20 = 0xf;
      pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
      uStack_e4._4_4_ = (char *)0x5701e9;
      FUN_005542c0();
      iStack_8 = CONCAT31(iStack_8._1_3_,9);
LAB_005701ed:
      uStack_dc._0_4_ = (char *)&pppuStack_34;
      uStack_dc._4_4_ = (undefined4 ****)0x0;
      uStack_e4._4_4_ = (char *)0x5701f8;
      FUN_00878480();
    }
    else {
      if (DAT_01d5ace8 == '\0') {
        uStack_dc._0_4_ = (char *)&uStack_18;
        uStack_e4._4_4_ = (char *)aiStack_cc;
        uStack_e4._0_4_ = (undefined *)0x570019;
        uStack_dc._4_4_ = (undefined4 ****)uVar2;
        puVar4 = (undefined4 *)FUN_005de4b0();
      }
      else {
        uStack_dc._4_4_ = &pppuStack_54;
        if (0xf < uStack_44._4_4_) {
          uStack_dc._4_4_ = (undefined4 ****)pppuStack_54;
        }
        uStack_e4._4_4_ = (char *)&uStack_18;
        uStack_e4._0_4_ = auStack_ac;
        uStack_e8 = 0x570001;
        uStack_dc._0_4_ = (char *)uVar2;
        puVar4 = (undefined4 *)FUN_005de3a0();
      }
      uStack_74 = *puVar4;
      uStack_70 = puVar4[1];
      ppuStack_6c = (undefined4 **)puVar4[2];
      uStack_68 = puVar4[3];
      uStack_64 = puVar4[4];
      uStack_60 = puVar4[5];
      uStack_5c = puVar4[6];
      uStack_58 = puVar4[7];
      uStack_dc._4_4_ = (undefined4 ****)&uStack_74;
      uStack_dc._0_4_ = (char *)0x570046;
      uStack_3c = uStack_74;
      uStack_38 = uStack_70;
      pppuStack_34 = (undefined4 ***)ppuStack_6c;
      uStack_30 = uStack_68;
      uStack_2c = uStack_64;
      uStack_28 = uStack_60;
      uStack_24 = uStack_5c;
      uStack_20 = uStack_58;
      iVar5 = FUN_005dd290();
      if (iVar5 != 0) {
        if (DAT_01d59037 != 0) {
          uStack_dc._4_4_ = (undefined4 ****)0x5700bf;
          uStack_dc = FUN_00928340();
          uStack_e4._0_4_ = (undefined *)(uint)DAT_01d59037;
          uStack_e4._4_4_ = "Error! Failed to player with ID %lld to external anticheat module.";
          uStack_e8 = 0x5700d3;
          FUN_01677520();
        }
        uStack_dc._4_4_ = (undefined4 ****)0x45;
        uStack_dc._0_4_ = "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_PlayerAddFailed";
        uStack_24 = 0;
        uStack_20 = 0xf;
        pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
        uStack_e4._4_4_ = (char *)0x5700f7;
        FUN_005542c0();
        iStack_8 = CONCAT31(iStack_8._1_3_,6);
        goto LAB_005701ed;
      }
      if (DAT_01d59037 != 0) {
        uStack_dc._4_4_ = (undefined4 ****)0x57005d;
        uStack_dc = FUN_00928340();
        uStack_e4._0_4_ = (undefined *)(uint)DAT_01d59037;
        uStack_e4._4_4_ = "Successfully added player with ID %lld to external anticheat module.";
        uStack_e8 = 0x570071;
        FUN_01677520();
      }
      uStack_dc._4_4_ = (undefined4 ****)0x26;
      uStack_dc._0_4_ = "ExternalAntiCheat_Successful_PlayerAdd";
      uStack_24 = 0;
      uStack_20 = 0xf;
      pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
      uStack_e4._4_4_ = (char *)0x570095;
      FUN_005542c0();
      iStack_8 = CONCAT31(iStack_8._1_3_,5);
LAB_00570099:
      uStack_dc._4_4_ = (undefined4 ****)0x0;
      uStack_e4._4_4_ = (char *)&pppuStack_34;
      uStack_dc._0_4_ = (char *)0x1;
      uStack_e4._0_4_ = (undefined *)0x5700a6;
      FUN_008783f0();
    }
    uStack_dc._4_4_ = (undefined4 ****)0x570203;
    uStack_18 = FUN_005507b0();
  }
  if (0xf < uStack_44._4_4_) {
    uStack_dc._4_4_ = (undefined4 ****)(uStack_44._4_4_ + 1);
    ppppuVar3 = (undefined4 ****)pppuStack_54;
    if (0xfff < uStack_dc._4_4_) {
      ppppuVar3 = (undefined4 ****)pppuStack_54[-1];
      uStack_dc._4_4_ = (undefined4 ****)(uStack_44._4_4_ + 0x24);
      if ((undefined1 *)0x1f < (undefined1 *)((int)pppuStack_54 + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        uStack_dc._4_4_ = (undefined4 ****)&UNK_00570286;
        FUN_017167a3();
      }
    }
    uStack_e4._4_4_ = (char *)0x570230;
    uStack_dc._0_4_ = (char *)ppppuVar3;
    uStack_18 = FUN_01674ea0();
  }
  uStack_44 = 0xf00000000;
  pppuStack_54 = (undefined4 ***)((uint)pppuStack_54 & 0xffffff00);
LAB_00570245:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar6 = *puVar1;
    uStack_18 = *puVar1;
    *puVar1 = uVar6 - 1;
    UNLOCK();
    if (uVar6 - 1 == 0) {
      uStack_dc._4_4_ = (undefined4 ****)0x57025b;
      uStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar7 = piStack_14 + 2;
      iVar5 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uStack_dc._4_4_ = (undefined4 ****)0x57026a;
        uStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uStack_18;
}



/* FUNCTION 3423 ; VA 0x00570290 ; FUN_00570290 */

void FUN_00570290(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0055c360(param_1,*puVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 3424 ; VA 0x005702d0 ; FUN_005702d0 */

uint FUN_005702d0(char *param_1)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  pcVar3 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar3 = *(char **)param_1;
  }
  piVar1 = (int *)(param_1 + 0x10);
  if (0xf < *(uint *)(param_1 + 0x14)) {
    param_1 = *(char **)param_1;
  }
  iVar4 = (int)(pcVar3 + *piVar1) - (int)param_1;
  uVar6 = 0;
  iVar5 = 0;
  if (pcVar3 + *piVar1 < param_1) {
    iVar4 = 0;
  }
  if (iVar4 != 0) {
    do {
      cVar2 = *param_1;
      param_1 = param_1 + 1;
      iVar5 = iVar5 + 1;
      uVar6 = uVar6 ^ cVar2 + -0x61c88647 + uVar6 * 0x40 + (uVar6 >> 2);
    } while (iVar5 != iVar4);
  }
  return uVar6;
}



/* FUNCTION 3425 ; VA 0x00570340 ; FUN_00570340 */

bool FUN_00570340(int *param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(*param_1 + 4,*param_2 + 4);
  return iVar1 < 0;
}



/* FUNCTION 3426 ; VA 0x00570370 ; FUN_00570370 */

uint FUN_00570370(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar3 = FUN_0055c2d0(param_1,*puVar2,param_2,*puVar1);
  return uVar3 >> 0x1f;
}



/* FUNCTION 3427 ; VA 0x005703b0 ; FUN_005703b0 */

void FUN_005703b0(undefined4 *param_1)

{
  FUN_008a45f0(param_1);
  if (param_1 != (undefined4 *)0x0) {
    (**(code **)*param_1)(1);
  }
  return;
}



/* FUNCTION 3428 ; VA 0x005703e0 ; FUN_005703e0 */

void __fastcall FUN_005703e0(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 0x18;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x60 + (int)piVar1) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -100 + (int)piVar1) = *(int *)(*param_1 + 4) + -0x60;
  FUN_0056b950();
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x60 + (int)piVar1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -100 + (int)piVar1) = *(int *)(*param_1 + 4) + -0x18;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3429 ; VA 0x00570460 ; FUN_00570460 */

void __fastcall FUN_00570460(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 0x1a;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x68 + (int)piVar1) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x6c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_00550570();
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x68 + (int)piVar1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x6c + (int)piVar1) = *(int *)(*param_1 + 4) + -8;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3430 ; VA 0x005704e0 ; FUN_005704e0 */

void __fastcall FUN_005704e0(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1 + 2;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -8 + (int)piVar1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0xc + (int)piVar1) = *(int *)(*param_1 + 4) + -8;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3431 ; VA 0x00570540 ; FUN_00570540 */

void __fastcall FUN_00570540(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 0x14;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x50 + (int)piVar1) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x54 + (int)piVar1) = *(int *)(*param_1 + 4) + -0x50;
  FUN_0056b950();
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x50 + (int)piVar1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x54 + (int)piVar1) = *(int *)(*param_1 + 4) + -8;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3432 ; VA 0x005705c0 ; FUN_005705c0 */

void __fastcall FUN_005705c0(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 0x1a;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x68 + (int)piVar1) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x6c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_0056b950();
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x68 + (int)piVar1) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x6c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x20;
  *(undefined ***)(*(int *)(param_1[4] + 4) + -0x58 + (int)piVar1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[4] + 4) + -0x5c + (int)piVar1) = *(int *)(param_1[4] + 4) + -8;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x68 + (int)piVar1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x6c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x18;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3433 ; VA 0x00570680 ; FUN_00570680 */

void __fastcall FUN_00570680(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3434 ; VA 0x00570720 ; FUN_00570720 */

void __fastcall FUN_00570720(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3435 ; VA 0x005707c0 ; FUN_005707c0 */

void __fastcall FUN_005707c0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3436 ; VA 0x00570860 ; FUN_00570860 */

void __fastcall FUN_00570860(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3437 ; VA 0x00570900 ; FUN_00570900 */

void __fastcall FUN_00570900(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3438 ; VA 0x005709a0 ; FUN_005709a0 */

void __fastcall FUN_005709a0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3439 ; VA 0x00570a40 ; FUN_00570a40 */

void __fastcall FUN_00570a40(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
             ::vftable;
  param_1[0xb] = boost::exception_detail::
                 clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
                 ::vftable;
  *(undefined ***)(*(int *)(param_1[0x10] + 4) + 0x40 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>::
       vftable;
  *(int *)(*(int *)(param_1[0x10] + 4) + 0x3c + (int)param_1) = *(int *)(param_1[0x10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  param_1[0xb] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[0xc] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[0xc] + 0x10))();
    if (cVar1 != '\0') {
      param_1[0xc] = 0;
    }
  }
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  param_1[0x12] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3440 ; VA 0x00570ae0 ; FUN_00570ae0 */

void __fastcall FUN_00570ae0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3441 ; VA 0x00570b80 ; FUN_00570b80 */

void __fastcall FUN_00570b80(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3442 ; VA 0x00570c20 ; FUN_00570c20 */

void __fastcall FUN_00570c20(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3443 ; VA 0x00570cc0 ; FUN_00570cc0 */

void __fastcall FUN_00570cc0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3444 ; VA 0x00570d60 ; FUN_00570d60 */

void __fastcall FUN_00570d60(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3445 ; VA 0x00570e00 ; FUN_00570e00 */

void __fastcall FUN_00570e00(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3446 ; VA 0x00570ea0 ; FUN_00570ea0 */

void __fastcall FUN_00570ea0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3447 ; VA 0x00570f40 ; FUN_00570f40 */

void __fastcall FUN_00570f40(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3448 ; VA 0x00570fe0 ; FUN_00570fe0 */

void __fastcall FUN_00570fe0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3449 ; VA 0x00571080 ; FUN_00571080 */

void __fastcall FUN_00571080(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::length_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3450 ; VA 0x00571120 ; FUN_00571120 */

void __fastcall FUN_00571120(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3451 ; VA 0x005711c0 ; FUN_005711c0 */

void __fastcall FUN_005711c0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3452 ; VA 0x00571260 ; FUN_00571260 */

void __fastcall FUN_00571260(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3453 ; VA 0x00571300 ; FUN_00571300 */

void __fastcall FUN_00571300(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::range_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3454 ; VA 0x005713a0 ; FUN_005713a0 */

void __fastcall FUN_005713a0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3455 ; VA 0x00571440 ; FUN_00571440 */

void __fastcall FUN_00571440(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3456 ; VA 0x005714e0 ; FUN_005714e0 */

void __fastcall FUN_005714e0(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(undefined ***)(*(int *)(param_1[5] + 4) + 0x14 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(int *)(*(int *)(param_1[5] + 4) + 0x10 + (int)param_1) = *(int *)(param_1[5] + 4) + -8;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[7] = boost::exception_detail::clone_base::vftable;
  return;
}



/* FUNCTION 3457 ; VA 0x00571520 ; FUN_00571520 */

void __fastcall FUN_00571520(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_0056e860();
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  return;
}



/* FUNCTION 3458 ; VA 0x00571560 ; FUN_00571560 */

void __fastcall FUN_00571560(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(undefined ***)(*(int *)(param_1[3] + 4) + 0xc + (int)param_1) =
       boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(int *)(*(int *)(param_1[3] + 4) + 8 + (int)param_1) = *(int *)(param_1[3] + 4) + -8;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[5] = boost::exception_detail::clone_base::vftable;
  return;
}



/* FUNCTION 3459 ; VA 0x005715a0 ; FUN_005715a0 */

void __fastcall FUN_005715a0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  param_1[5] = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::unknown_exception::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3460 ; VA 0x00571638 ; FUN_00571638 */

void FUN_00571638(void)

{
  FUN_00571a30();
  return;
}



/* FUNCTION 3461 ; VA 0x00571640 ; FUN_00571640 */

void FUN_00571640(void)

{
  FUN_00571ae0();
  return;
}



/* FUNCTION 3462 ; VA 0x00571648 ; FUN_00571648 */

void FUN_00571648(void)

{
  FUN_00571b10();
  return;
}



/* FUNCTION 3463 ; VA 0x00571650 ; FUN_00571650 */

void FUN_00571650(void)

{
  FUN_00571b40();
  return;
}



/* FUNCTION 3464 ; VA 0x00571658 ; FUN_00571658 */

void FUN_00571658(void)

{
  FUN_00571bb0();
  return;
}



/* FUNCTION 3465 ; VA 0x00571660 ; FUN_00571660 */

void FUN_00571660(void)

{
  FUN_00571c80();
  return;
}



/* FUNCTION 3466 ; VA 0x00571668 ; FUN_00571668 */

void FUN_00571668(void)

{
  FUN_00571cb0();
  return;
}



/* FUNCTION 3467 ; VA 0x00571673 ; FUN_00571673 */

void FUN_00571673(void)

{
  FUN_00571cb0();
  return;
}



/* FUNCTION 3468 ; VA 0x0057167b ; FUN_0057167b */

void FUN_0057167b(void)

{
  FUN_00571ce0();
  return;
}



/* FUNCTION 3469 ; VA 0x00571686 ; FUN_00571686 */

void FUN_00571686(void)

{
  FUN_00571ce0();
  return;
}



/* FUNCTION 3470 ; VA 0x0057168e ; FUN_0057168e */

void FUN_0057168e(void)

{
  FUN_00571d10();
  return;
}



/* FUNCTION 3471 ; VA 0x00571699 ; FUN_00571699 */

void FUN_00571699(void)

{
  FUN_00571d10();
  return;
}



/* FUNCTION 3472 ; VA 0x005716a1 ; FUN_005716a1 */

void FUN_005716a1(void)

{
  FUN_00571d40();
  return;
}



/* FUNCTION 3473 ; VA 0x005716ac ; FUN_005716ac */

void FUN_005716ac(void)

{
  FUN_00571d40();
  return;
}



/* FUNCTION 3474 ; VA 0x005716b4 ; FUN_005716b4 */

void FUN_005716b4(void)

{
  FUN_00571d70();
  return;
}



/* FUNCTION 3475 ; VA 0x005716bf ; FUN_005716bf */

void FUN_005716bf(void)

{
  FUN_00571d70();
  return;
}



/* FUNCTION 3476 ; VA 0x005716c7 ; FUN_005716c7 */

void FUN_005716c7(void)

{
  FUN_00571da0();
  return;
}



/* FUNCTION 3477 ; VA 0x005716d2 ; FUN_005716d2 */

void FUN_005716d2(void)

{
  FUN_00571da0();
  return;
}



/* FUNCTION 3478 ; VA 0x005716da ; FUN_005716da */

void FUN_005716da(void)

{
  FUN_00571dd0();
  return;
}



/* FUNCTION 3479 ; VA 0x005716e5 ; FUN_005716e5 */

void FUN_005716e5(void)

{
  FUN_00571dd0();
  return;
}



/* FUNCTION 3480 ; VA 0x005716ed ; FUN_005716ed */

void FUN_005716ed(void)

{
  FUN_00571e00();
  return;
}



/* FUNCTION 3481 ; VA 0x005716f8 ; FUN_005716f8 */

void FUN_005716f8(void)

{
  FUN_00571e00();
  return;
}



/* FUNCTION 3482 ; VA 0x00571700 ; FUN_00571700 */

void FUN_00571700(void)

{
  FUN_00571e30();
  return;
}



/* FUNCTION 3483 ; VA 0x0057170b ; FUN_0057170b */

void FUN_0057170b(void)

{
  FUN_00571e30();
  return;
}



/* FUNCTION 3484 ; VA 0x00571713 ; FUN_00571713 */

void FUN_00571713(void)

{
  FUN_00571e60();
  return;
}



/* FUNCTION 3485 ; VA 0x0057171e ; FUN_0057171e */

void FUN_0057171e(void)

{
  FUN_00571e60();
  return;
}



/* FUNCTION 3486 ; VA 0x00571726 ; FUN_00571726 */

void FUN_00571726(void)

{
  FUN_00571e90();
  return;
}



/* FUNCTION 3487 ; VA 0x00571731 ; FUN_00571731 */

void FUN_00571731(void)

{
  FUN_00571e90();
  return;
}



/* FUNCTION 3488 ; VA 0x00571739 ; FUN_00571739 */

void FUN_00571739(void)

{
  FUN_00571ec0();
  return;
}



/* FUNCTION 3489 ; VA 0x00571744 ; FUN_00571744 */

void FUN_00571744(void)

{
  FUN_00571ec0();
  return;
}



/* FUNCTION 3490 ; VA 0x0057174c ; FUN_0057174c */

void FUN_0057174c(void)

{
  FUN_00571ef0();
  return;
}



/* FUNCTION 3491 ; VA 0x00571757 ; FUN_00571757 */

void FUN_00571757(void)

{
  FUN_00571ef0();
  return;
}



/* FUNCTION 3492 ; VA 0x0057175f ; FUN_0057175f */

void FUN_0057175f(void)

{
  FUN_00571f20();
  return;
}



/* FUNCTION 3493 ; VA 0x0057176a ; FUN_0057176a */

void FUN_0057176a(void)

{
  FUN_00571f20();
  return;
}



/* FUNCTION 3494 ; VA 0x00571772 ; FUN_00571772 */

void FUN_00571772(void)

{
  FUN_00571f50();
  return;
}



/* FUNCTION 3495 ; VA 0x0057177d ; FUN_0057177d */

void FUN_0057177d(void)

{
  FUN_00571f50();
  return;
}



/* FUNCTION 3496 ; VA 0x00571785 ; FUN_00571785 */

void FUN_00571785(void)

{
  FUN_00571f80();
  return;
}



/* FUNCTION 3497 ; VA 0x00571790 ; FUN_00571790 */

void FUN_00571790(void)

{
  FUN_00571f80();
  return;
}



/* FUNCTION 3498 ; VA 0x00571798 ; FUN_00571798 */

void FUN_00571798(void)

{
  FUN_00571fb0();
  return;
}



/* FUNCTION 3499 ; VA 0x005717a3 ; FUN_005717a3 */

void FUN_005717a3(void)

{
  FUN_00571fb0();
  return;
}


