/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 10000 ; VA 0x0070e1f0 ; FUN_0070e1f0 */

void __thiscall FUN_0070e1f0(int param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  
  FUN_005edd10();
  cVar1 = FUN_006ee7c0(param_2);
  if ((char)param_3 == '\0') {
    iVar3 = param_1 + 0x149 + (uint)*(byte *)(param_1 + 0x148);
    uVar2 = FUN_00ca2680(param_2);
    FUN_006e16e0(&param_3,uVar2,param_2,-(uint)(iVar3 != 0) & iVar3 + 1U);
    if (cVar1 != '\0') {
      return;
    }
    if ((param_3 != 0) && (*(char *)(param_3 + 0x14) != '\0')) {
      return;
    }
  }
  else if (cVar1 == '\0') {
    return;
  }
  FUN_0070b080(param_2);
  return;
}



/* FUNCTION 10001 ; VA 0x0070e2b0 ; FUN_0070e2b0 */

uint __thiscall FUN_0070e2b0(int param_1,undefined8 *param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iStack_20;
  int iStack_1c;
  int iStack_14;
  int iStack_10;
  
  FUN_005edd10();
  uVar2 = FUN_006ee7c0(param_2);
  if ((char)uVar2 != '\0') {
    if ((char)param_3 == '\0') {
      iVar7 = param_1 + 0x149 + (uint)*(byte *)(param_1 + 0x148);
      uVar3 = FUN_00ca2680(param_2);
      FUN_006e16e0(&param_3,uVar3,param_2,-(uint)(iVar7 != 0) & iVar7 + 1U);
      if ((param_3 != 0) && (uVar2 = param_3, *(char *)(param_3 + 0x14) != '\0')) goto LAB_0070e3b4;
    }
    if ((*(int *)(param_1 + 0x250) == 0) ||
       (piVar1 = (int *)**(int **)(param_1 + 0x24c), piVar1 == *(int **)(param_1 + 0x24c))) {
      uVar2 = *(int *)(param_1 + 0x208) - *(int *)(param_2 + 1);
      iStack_1c = (int)((ulonglong)*(undefined8 *)(param_1 + 0x200) >> 0x20);
      iStack_10 = (int)((ulonglong)*param_2 >> 0x20);
      uVar6 = iStack_1c - iStack_10 >> 0x1f;
      iVar5 = (iStack_1c - iStack_10 ^ uVar6) - uVar6;
      uVar6 = (int)uVar2 >> 0x1f;
      iStack_20 = (int)*(undefined8 *)(param_1 + 0x200);
      iStack_14 = (int)*param_2;
      iVar7 = (uVar2 ^ uVar6) - uVar6;
      uVar2 = iStack_20 - iStack_14 >> 0x1f;
      iVar4 = (iStack_20 - iStack_14 ^ uVar2) - uVar2;
      if (iVar5 <= iVar4) {
        iVar5 = iVar4;
      }
      if (iVar7 <= iVar5) {
        iVar7 = iVar5;
      }
      return CONCAT31((int3)((uint)iVar4 >> 8),(int)DAT_01d5b924 < iVar7);
    }
    iStack_10 = (int)((ulonglong)*(undefined8 *)(piVar1 + 2) >> 0x20);
    iStack_1c = (int)((ulonglong)*param_2 >> 0x20);
    uVar2 = iStack_10 - iStack_1c >> 0x1f;
    iVar7 = (iStack_10 - iStack_1c ^ uVar2) - uVar2;
    uVar2 = piVar1[4] - *(int *)(param_2 + 1) >> 0x1f;
    iStack_14 = (int)*(undefined8 *)(piVar1 + 2);
    iStack_20 = (int)*param_2;
    iVar5 = (piVar1[4] - *(int *)(param_2 + 1) ^ uVar2) - uVar2;
    uVar2 = iStack_14 - iStack_20 >> 0x1f;
    iVar4 = (iStack_14 - iStack_20 ^ uVar2) - uVar2;
    if (iVar7 <= iVar4) {
      iVar7 = iVar4;
    }
    if (iVar5 <= iVar7) {
      iVar5 = iVar7;
    }
    do {
      uVar2 = DAT_01d5b924;
    } while ((int)DAT_01d5b924 < iVar5);
  }
LAB_0070e3b4:
  return uVar2 & 0xffffff00;
}



/* FUNCTION 10002 ; VA 0x0070e420 ; FUN_0070e420 */

int __thiscall FUN_0070e420(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abb1f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_2 + 0x18);
  uVar4 = *(undefined4 *)(param_2 + 0x1c);
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined4 *)FUN_01674e20(0x38);
  uStack_8._0_1_ = 1;
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    FUN_006b1a30(*(undefined4 *)(param_1 + 0x128));
    puStack_14[0xc] = uVar3;
    *puStack_14 = RBX::Network::ClientReplicator::GCJob::InstanceRemovalItem::vftable;
    puStack_14[0xd] = uVar4;
  }
  uStack_8._0_1_ = 0;
  FUN_005edd10();
  FUN_006b1f50(puStack_14);
  puVar7 = *(undefined4 **)(param_2 + 0x2c);
  if (puVar7 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_2 + 0x30);
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_2 + 0x30);
      puVar7 = *(undefined4 **)(param_2 + 0x2c);
    }
    puVar5 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    uStack_8._0_1_ = 2;
    for (; puVar7 != puVar5; puVar7 = puVar7 + 2) {
      if (puVar7[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar7[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      param_2 = FUN_0070e420(*puVar7,puVar7[1]);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        param_2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          param_2 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar6 = param_3 + 1;
    iVar2 = *piVar6;
    param_2 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10003 ; VA 0x0070e5b0 ; FUN_0070e5b0 */

void FUN_0070e5b0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined **ppuStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined ***pppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb38;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar2 = *(int *)(iVar1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00aff8c0();
  param_1 = (int *)0;
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da)) {
    param_1 = (int *)iVar1;
  }
  if (param_1 == (int *)0x0) {
    iStack_38 = *(int *)(*piVar3 + 0x34);
    if (iStack_38 != 0) {
      pppuStack_18 = &ppuStack_3c;
      ppuStack_3c = std::
                    _Func_impl_no_alloc<class_<lambda_70a9e9fdf6e7f68ee772c64181adb6d6>,bool,class_std::shared_ptr<class_RBX::Instance>_>
                    ::vftable;
      uStack_34 = uStack_14;
      uStack_8 = 0;
      FUN_006e09c0(pppuStack_18);
      if (pppuStack_18 != (undefined ***)0x0) {
        (*(code *)(*pppuStack_18)[4])(pppuStack_18 != &ppuStack_3c);
      }
    }
  }
  else {
    piVar5 = (int *)FUN_0070aa60(&param_1);
    if ((0 < *piVar5) && (iVar1 = *(int *)(*piVar3 + 0x34), iVar1 != 0)) {
      FUN_0070de60(iVar1,1);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10004 ; VA 0x0070e6a0 ; FUN_0070e6a0 */

void FUN_0070e6a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined **ppuStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined ***pppuStack_2c;
  code *pcStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb58;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  iVar1 = *(int *)(iVar4 + 0xc);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00aff8c0();
  iStack_18 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iStack_18 = iVar4;
  }
  if (iStack_18 == 0) {
    if (*param_2 != 0) {
      pppuStack_2c = &ppuStack_50;
      ppuStack_50 = std::
                    _Func_impl_no_alloc<class_<lambda_d9bcc031b686e87c6a372abe6f2045ed>,bool,class_std::shared_ptr<class_RBX::Instance>_>
                    ::vftable;
      uStack_48 = uStack_14;
      uStack_8 = 0;
      iStack_4c = *param_2;
      FUN_006e09c0(pppuStack_2c);
      uStack_8 = 0xffffffff;
      if (pppuStack_2c != (undefined ***)0x0) {
        (*(code *)(*pppuStack_2c)[4])(pppuStack_2c != &ppuStack_50);
      }
    }
  }
  else {
    piVar3 = (int *)FUN_0070aa60(&iStack_18);
    if ((0 < *piVar3) && (*param_2 != 0)) {
      FUN_0070b640(*param_2,1);
    }
  }
  if ((*(int *)(*param_1 + 0x34) == 0) || (iVar4 = FUN_006bf290(), iVar4 == 0)) {
    if (param_1[1] != 0) {
      LOCK();
      piVar3 = (int *)(param_1[1] + 4);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    FUN_0070d110(*param_1,param_1[1]);
    pcStack_28 = FUN_0070d110;
    uStack_24 = 0;
    uStack_20 = uStack_14;
    FUN_00677470(&pcStack_28);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10005 ; VA 0x0070e7f0 ; FUN_0070e7f0 */

void * __thiscall FUN_0070e7f0(int param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvVar5;
  undefined4 uVar6;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if (param_4 != '\0') {
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_006e77c0(auStack_54,param_3);
    uStack_3c = *puVar2;
    uStack_38 = puVar2[1];
    uStack_34 = puVar2[2];
    uStack_30 = puVar2[3];
    uStack_2c = *(undefined8 *)(puVar2 + 4);
    uVar3 = FUN_00b06640(param_2);
    FUN_0060dcd0(&uStack_18,uVar3);
    uStack_8 = 0;
    if ((DAT_01d5bf20 != '\0') && (iVar4 = FUN_0070ec50(param_1 + 0x14), 0 < iVar4)) {
      FUN_0070de60(uStack_18,iVar4);
    }
    pvVar5 = (void *)FUN_00709810(param_1 + 0x14,0);
    if ((char)pvVar5 == '\0') {
      uVar6 = 0;
      iVar4 = FUN_00b077e0(0);
      uVar3 = FUN_006ddab0(auStack_24,iVar4 + 0x24);
      pvVar5 = (void *)FUN_0070df00(uVar3,uVar6);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar4 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pvVar5 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 10006 ; VA 0x0070e8f0 ; FUN_0070e8f0 */

int __thiscall FUN_0070e8f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined8 uVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined auStack_70 [24];
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined8 uStack_48;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_006e77c0(&iStack_40,param_3);
  iStack_58 = *piVar3;
  iStack_54 = piVar3[1];
  iStack_50 = piVar3[2];
  iStack_4c = piVar3[3];
  uStack_48 = *(undefined8 *)(piVar3 + 4);
  iStack_28 = iStack_58;
  iStack_24 = iStack_54;
  iStack_20 = iStack_50;
  iStack_1c = iStack_4c;
  piVar3 = (int *)FUN_006e77c0(auStack_70,param_4);
  iStack_40 = *piVar3;
  iStack_3c = piVar3[1];
  iStack_38 = piVar3[2];
  iStack_34 = piVar3[3];
  uVar2 = *(undefined8 *)(piVar3 + 4);
  if ((((iStack_28 == iStack_40) && (iStack_54 == iStack_3c)) && (iStack_50 == iStack_38)) &&
     (iStack_4c == iStack_34)) {
    uStack_30._0_4_ = (int)uVar2;
    if ((int)uStack_48 == (int)uStack_30) {
      uStack_30._4_4_ = (int)((ulonglong)uVar2 >> 0x20);
      if (uStack_48._4_4_ == uStack_30._4_4_) {
        ExceptionList = pvStack_10;
        return uStack_48._4_4_;
      }
    }
  }
  uStack_30 = uVar2;
  uVar4 = FUN_00b06640(param_2);
  FUN_0060dcd0(&uStack_18,uVar4);
  uStack_8 = 0;
  if (DAT_01d5bf20 != '\0') {
    uVar5 = FUN_0070b150(param_1 + 0x14,&iStack_40);
    if ((int)uVar5 < 1) {
      if ((int)uVar5 < 0) {
        FUN_0070b640(uStack_18,(uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f));
      }
    }
    else {
      FUN_0070de60(uStack_18,uVar5);
    }
  }
  iVar6 = FUN_00709810(param_1 + 0x14,0);
  if ((char)iVar6 == '\0') {
    uVar7 = 0;
    iVar6 = FUN_00b077e0(0);
    uVar4 = FUN_006ddab0(&iStack_24,iVar6 + 0x24);
    iVar6 = FUN_0070df00(uVar4,uVar7);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_14 + 1;
    iVar1 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar3 = piStack_14 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 10007 ; VA 0x0070ea60 ; FUN_0070ea60 */

int __thiscall FUN_0070ea60(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  bool bVar6;
  undefined4 uVar7;
  undefined auStack_78 [24];
  undefined auStack_60 [24];
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  iStack_30 = 0;
  iStack_2c = 0;
  iStack_28 = 0;
  iStack_24 = 0;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_0070f2b0(auStack_60,param_3[9],param_3[10],param_3[0xb],param_3[0xc],
                               *(undefined8 *)(param_3 + 0xd));
  iStack_48 = *piVar2;
  iStack_44 = piVar2[1];
  iStack_40 = piVar2[2];
  iStack_3c = piVar2[3];
  uStack_38 = *(undefined8 *)(piVar2 + 4);
  if (*param_3 == 1) {
    piVar2 = (int *)FUN_0070f2b0(auStack_78,param_3[2],param_3[3],param_3[4],param_3[5],
                                 *(undefined8 *)(param_3 + 6));
    iStack_30 = *piVar2;
    iStack_2c = piVar2[1];
    iStack_28 = piVar2[2];
    iStack_24 = piVar2[3];
    uStack_20 = *(undefined8 *)(piVar2 + 4);
    if ((((iStack_48 == iStack_30) && (iStack_44 == iStack_2c)) && (iStack_40 == iStack_28)) &&
       (iStack_3c == iStack_24)) {
      bVar6 = (int)uStack_38 == (int)uStack_20;
      if (bVar6) {
        uStack_20._4_4_ = (int)((ulonglong)uStack_20 >> 0x20);
        bVar6 = uStack_38._4_4_ == uStack_20._4_4_;
        if (bVar6) {
          ExceptionList = pvStack_10;
          return uStack_38._4_4_;
        }
      }
    }
  }
  uVar3 = FUN_00b06640();
  FUN_0060dcd0(&uStack_18,uVar3);
  uStack_8 = 0;
  if (DAT_01d5bf20 == '\0') goto LAB_0070ebda;
  iVar5 = *param_3;
  if (iVar5 == 1) {
    uVar4 = FUN_0070b150(param_1 + 0x18,&iStack_48);
    if (0 < (int)uVar4) {
      FUN_0070de60(uStack_18,uVar4);
      goto LAB_0070ebda;
    }
    if (-1 < (int)uVar4) goto LAB_0070ebda;
    iVar5 = (uVar4 ^ (int)uVar4 >> 0x1f) - ((int)uVar4 >> 0x1f);
  }
  else {
    if (iVar5 == 0) {
      iVar5 = FUN_0070ec50();
      if (0 < iVar5) {
        FUN_0070de60(uStack_18,iVar5);
      }
      goto LAB_0070ebda;
    }
    if ((iVar5 != 2) || (iVar5 = FUN_0070ec50(), iVar5 < 1)) goto LAB_0070ebda;
  }
  FUN_0070b640(uStack_18,iVar5);
LAB_0070ebda:
  iVar5 = FUN_00709810(param_1 + 0x18,0);
  if ((char)iVar5 == '\0') {
    uVar7 = 0;
    iVar5 = FUN_00b077e0();
    uVar3 = FUN_006ddab0(&iStack_24,iVar5 + 0x24);
    iVar5 = FUN_0070df00(uVar3,uVar7);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar1 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar5 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 10008 ; VA 0x0070ec50 ; FUN_0070ec50 */

int __thiscall FUN_0070ec50(int *param_1,byte *param_2)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined8 uStack_2c;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar4 = 0;
  iStack_c = param_1[1];
  piStack_14 = param_1;
  if (iStack_c <= param_1[4]) {
    do {
      iStack_8 = param_1[2];
      iStack_1c = iStack_c;
      if (iStack_8 <= param_1[5]) {
        do {
          iVar3 = *param_1;
          if (iVar3 <= param_1[3]) {
            do {
              uStack_2c = CONCAT44(iStack_1c,iVar3);
              bVar1 = *param_2;
              iStack_24 = iStack_8;
              iStack_20 = iVar3;
              uVar2 = FUN_00ca2680(&uStack_2c);
              FUN_006e16e0(&iStack_10,uVar2,&uStack_2c,
                           -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) &
                           (uint)(param_2 + bVar1 + 1 + 1));
              if ((iStack_10 != 0) && (*(char *)(iStack_10 + 0x14) != '\0')) {
                iVar4 = iVar4 + 1;
              }
              iVar3 = iVar3 + 1;
              param_1 = piStack_14;
            } while (iVar3 <= piStack_14[3]);
          }
          iStack_8 = iStack_8 + 1;
        } while (iStack_8 <= param_1[5]);
      }
      iStack_c = iStack_c + 1;
    } while (iStack_c <= param_1[4]);
  }
  return iVar4;
}



/* FUNCTION 10009 ; VA 0x0070ed20 ; FUN_0070ed20 */

uint __thiscall FUN_0070ed20(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = *(int **)(param_1 + 0x24c);
  piVar2 = (int *)*piVar1;
  if (piVar2 != piVar1) {
    do {
      if ((uint)*(byte *)(piVar2 + 6) == *param_2) {
        return CONCAT31((int3)((uint)piVar2 >> 8),1);
      }
      piVar2 = (int *)*piVar2;
    } while (piVar2 != piVar1);
  }
  return (uint)piVar2 & 0xffffff00;
}



/* FUNCTION 10010 ; VA 0x0070ed60 ; FUN_0070ed60 */

void __fastcall FUN_0070ed60(int param_1)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int *piVar4;
  int iVar5;
  byte bVar6;
  byte bVar7;
  byte bVar8;
  int *piVar9;
  float10 fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined4 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb9f;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined4 *)0x0;
  piVar1 = *(int **)(param_1 + 0x2d8);
  piVar9 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (piVar9 != piVar1) {
    do {
      ExceptionList = ppvVar3;
      iVar2 = piVar9[2];
      piVar4 = (int *)FUN_0070aa60();
      if (*piVar4 == 0) {
        if (puStack_18 == (undefined4 *)0x0) {
          iVar5 = FUN_00b077e0();
          fVar10 = (float10)FUN_01725280((double)*(float *)(iVar5 + 0x2c));
          fVar11 = (float)fVar10;
          if (fVar11 < 0.0) {
            fVar11 = fVar11 - DAT_018ce2f4;
          }
          else {
            fVar11 = fVar11 + DAT_018ce2f4;
          }
          fVar10 = (float10)FUN_01725280((double)*(float *)(iVar5 + 0x28));
          fVar12 = (float)fVar10;
          if (fVar12 < 0.0) {
            fVar12 = fVar12 - DAT_018ce2f4;
          }
          else {
            fVar12 = fVar12 + DAT_018ce2f4;
          }
          fVar10 = (float10)FUN_01725280((double)*(float *)(iVar5 + 0x24));
          fVar13 = (float)fVar10;
          if (fVar13 < 0.0) {
            fVar13 = fVar13 - DAT_018ce2f4;
          }
          else {
            fVar13 = fVar13 + DAT_018ce2f4;
          }
          bVar6 = (byte)DAT_01d5bed0;
          bVar7 = (byte)DAT_01d5becc;
          bVar8 = (byte)DAT_01d5bec8;
          puStack_18 = (undefined4 *)FUN_01674e20();
          uStack_8 = 0;
          if (puStack_18 == (undefined4 *)0x0) {
            puStack_18 = (undefined4 *)0x0;
          }
          else {
            FUN_006b1a30();
            puStack_18[0xc] = (int)fVar13 >> (bVar8 & 0x1f);
            puStack_18[0xd] = (int)fVar12 >> (bVar7 & 0x1f);
            *puStack_18 = RBX::Network::ClientReplicator::GCJob::RegionRemovalItem::vftable;
            puStack_18[0xe] = (int)fVar11 >> (bVar6 & 0x1f);
            puStack_18[0xf] = 0;
            puStack_18[0x10] = 0;
            puStack_18[0x11] = 0;
          }
          uStack_8 = 0xffffffff;
        }
        (**(code **)(**(int **)(param_1 + 0x128) + 0xe4))
                  (*(undefined4 *)(iVar2 + 0x18),*(undefined4 *)(iVar2 + 0x1c));
        FUN_0070d1d0(iVar2,puStack_18);
        FUN_0070c9a0();
        FUN_0070cc60();
      }
      piVar9 = (int *)*piVar9;
      ppvVar3 = (void **)ExceptionList;
    } while (piVar9 != piVar1);
    if (puStack_18 != (undefined4 *)0x0) {
      FUN_006b1f50();
      (**(code **)(**(int **)(param_1 + 0x128) + 0xe4))(0xffffffff,0);
    }
  }
  piVar1 = *(int **)(param_1 + 0x2d8);
  uStack_8 = 1;
  piVar9 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*(int *)(param_1 + 0x2d8) + 4) = *(int *)(param_1 + 0x2d8);
  *(undefined4 *)(param_1 + 0x2dc) = 0;
  if (piVar9 != *(int **)(param_1 + 0x2d8)) {
    do {
      piVar1 = (int *)*piVar9;
      FUN_01674ea0(piVar9,0xc);
      piVar9 = piVar1;
    } while (piVar1 != (int *)*(int *)(param_1 + 0x2d8));
  }
  FUN_005cb500();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10011 ; VA 0x0070f020 ; FUN_0070f020 */

void __thiscall FUN_0070f020(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  int aiStack_3c [2];
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abbc8;
  pvStack_10 = ExceptionList;
  iStack_1c = *(int *)(param_1 + 0x128);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (iStack_1c != 0) {
    iVar5 = *(int *)(iStack_1c + 0x34);
    iVar1 = iStack_1c;
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (iVar1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar1 = FUN_005c8ac0();
    }
    if ((iVar1 != 0) &&
       (iVar5 = *(int *)(iVar1 + 0xc), iVar1 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
      uVar2 = FUN_00675a30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      piStack_18 = piVar3;
      if (*piVar3 == 0) {
        uVar2 = FUN_00be8560();
        piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
        piVar3 = piStack_18;
        iVar5 = *piVar4;
        iVar1 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        *piStack_18 = iVar5;
        piVar4 = (int *)piStack_18[1];
        piStack_18[1] = iVar1;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar5 = piVar4[1] + -1;
          piVar4[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar5 = piVar4[2] + -1;
            piVar4[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_20[1] + -1;
          piStack_20[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            iVar5 = piStack_20[2] + -1;
            piStack_20[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
        }
      }
      if (*piVar3 != 0) {
        aiStack_3c[0] = iStack_1c;
        FUN_00709c60(iStack_14 + 0x288);
        uStack_8 = 0;
        FUN_00709900(aiStack_3c);
        uStack_8 = 0xffffffff;
        FUN_00641040();
      }
    }
  }
  piVar3 = *(int **)(iStack_14 + 0x288);
  piStack_20 = (int *)(iStack_14 + 0x288);
  iVar5 = iStack_14;
  if (piVar3 != *(int **)(iStack_14 + 0x28c)) {
    do {
      piVar4 = (int *)piVar3[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = (int *)piVar3[1];
      }
      iStack_2c = *piVar3;
      piStack_28 = piVar4;
      iStack_1c = iStack_2c;
      if (iStack_2c != 0) {
        piStack_34 = (int *)(param_2 + 0x98);
        piStack_30 = (int *)*piStack_34;
        *piStack_34 = iStack_2c;
        uStack_8 = 2;
        piStack_18 = piStack_30;
        if (DAT_01d5bf08 == '\0') {
          FUN_008a65e0(0,0);
        }
        else {
          (**(code **)(**(int **)(iStack_14 + 0x128) + 0xe4))
                    (*(undefined4 *)(iStack_2c + 0x18),*(undefined4 *)(iStack_2c + 0x1c));
          FUN_008a65e0(0,0);
          (**(code **)(**(int **)(iStack_14 + 0x128) + 0xe4))(0xffffffff,0);
        }
        iVar5 = iStack_14;
        if ((undefined4 *)(param_2 + 0x98) != (undefined4 *)0x0) {
          *(undefined4 *)(param_2 + 0x98) = piStack_18;
        }
      }
      uStack_8 = 0xffffffff;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[1] + -1;
        piVar4[1] = iVar1;
        UNLOCK();
        iVar5 = iStack_14;
        if (iVar1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          iVar5 = iStack_14;
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
            iVar5 = iStack_14;
          }
        }
      }
      piVar3 = piVar3 + 2;
    } while (piVar3 != *(int **)(iVar5 + 0x28c));
  }
  piVar3 = piStack_20;
  FUN_005596d0(*piStack_20,piStack_20[1],piStack_20);
  piVar3[1] = *piVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10012 ; VA 0x0070f2b0 ; FUN_0070f2b0 */

void FUN_0070f2b0(undefined8 *param_1,int param_2,int param_3,int param_4,undefined8 param_5,
                 int param_6)

{
  int iVar1;
  int iVar2;
  
  iVar2 = param_5._4_4_;
  if (((param_2 < (int)param_5) && (param_3 < param_5._4_4_)) && (param_4 < param_6)) {
    param_5._0_4_ = (int)param_5 + -1;
    param_6 = param_6 + -1;
    iVar2 = param_5._4_4_ + -1;
  }
  iVar1 = (int)param_5 >> 6;
  param_5 = CONCAT44(param_3 >> 6,param_2 >> 6);
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  *param_1 = param_5;
  *(int *)(param_1 + 1) = param_4 >> 6;
  *(ulonglong *)((int)param_1 + 0xc) = CONCAT44(iVar2 >> 6,iVar1);
  *(int *)((int)param_1 + 0x14) = param_6 >> 6;
  return;
}



/* FUNCTION 10013 ; VA 0x0070f350 ; FUN_0070f350 */

bool FUN_0070f350(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eaf994);
  uStack_8 = 0;
  piVar4 = (int *)FUN_0070a8f0(param_1);
  *piVar4 = *piVar4 + -1;
  piVar4 = (int *)FUN_0070a8f0(param_1);
  iVar1 = *piVar4;
  if (iVar1 < 1) {
    FUN_0070cf20(param_1);
  }
  iVar5 = param_1 + 4;
  piVar4 = (int *)FUN_0070a8f0(iVar5);
  *piVar4 = *piVar4 + -1;
  piVar4 = (int *)FUN_0070a8f0(iVar5);
  iVar2 = *piVar4;
  if (iVar2 < 1) {
    FUN_0070cf20(iVar5);
  }
  param_1 = param_1 + 8;
  piVar4 = (int *)FUN_0070a8f0(param_1);
  *piVar4 = *piVar4 + -1;
  piVar4 = (int *)FUN_0070a8f0(param_1);
  iVar5 = *piVar4;
  if (iVar5 < 1) {
    FUN_0070cf20(param_1);
  }
  uStack_8 = 1;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return iVar5 < 1 || (iVar2 < 1 || iVar1 < 1);
}



/* FUNCTION 10014 ; VA 0x0070f440 ; FUN_0070f440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0070f440(int param_1,int *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  float fVar3;
  float fVar4;
  undefined *puVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  undefined8 *puVar9;
  int *piVar10;
  float *pfVar11;
  int iVar12;
  undefined4 *puVar13;
  float *pfVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  double dVar18;
  float fVar19;
  float fVar20;
  float fStack_dc;
  float fStack_d8;
  undefined8 uStack_d4;
  float fStack_cc;
  float fStack_c8;
  undefined4 uStack_c4;
  int iStack_c0;
  int iStack_bc;
  float fStack_b4;
  int iStack_b0;
  uint auStack_ac [2];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  float fStack_84;
  undefined8 uStack_80;
  float fStack_78;
  float fStack_74;
  undefined4 uStack_70;
  float fStack_6c;
  float fStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  char cStack_31;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  fVar19 = _UNK_018e3fbc;
  fVar4 = _UNK_018e3fb8;
  fVar3 = _UNK_018e3fb4;
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017abc5f;
  pvStack_1c = ExceptionList;
  fStack_74 = 0.0;
  cStack_31 = '\0';
  ExceptionList = &pvStack_1c;
  iStack_c0 = param_1;
  puVar5 = &stack0xfffffffc;
  if (*(int *)(param_1 + 0x128) != 0) {
    uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
    fStack_84 = _UNK_018e3fc4;
    uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
    fStack_78 = 0.0;
    uStack_30 = _DAT_018e3fd0;
    uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
    fStack_24 = (float)_UNK_018e3fdc;
    uStack_94 = 0;
    uStack_90 = 0;
    ExceptionList = &pvStack_1c;
    puVar6 = (undefined4 *)FUN_0115e910();
    uStack_5c = *puVar6;
    uStack_58 = *(undefined8 *)(puVar6 + 1);
    uStack_50 = 0x3f800000;
    puVar6 = (undefined4 *)FUN_0115eb50();
    uStack_4c = *puVar6;
    uStack_48 = *(undefined8 *)(puVar6 + 1);
    fStack_40 = 1.0;
    uStack_70 = 0x41200000;
    fStack_6c = 50.0;
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    FUN_005542c0("Streaming Enabled Debugger: ",0x1c);
    uStack_14 = 0;
    FUN_0114e430(&fStack_3c,auStack_ac,&uStack_70,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                 &uStack_94,&uStack_30,(int)&uStack_8c + 4,1);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_98) {
      uVar16 = uStack_98 + 1;
      uVar15 = auStack_ac[0];
      if (0xfff < uVar16) {
        uVar15 = *(uint *)(auStack_ac[0] - 4);
        uVar16 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar16);
    }
    uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
    fStack_84 = _UNK_018e3fc4;
    uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
    fStack_78 = 0.0;
    uStack_30 = _DAT_018e3fd0;
    uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
    fStack_24 = (float)_UNK_018e3fdc;
    uStack_94 = 0;
    uStack_90 = 0;
    puVar6 = (undefined4 *)FUN_0115e910();
    uStack_5c = *puVar6;
    uStack_58 = *(undefined8 *)(puVar6 + 1);
    uStack_50 = 0x3f800000;
    puVar6 = (undefined4 *)FUN_0115ee80();
    uStack_4c = *puVar6;
    uStack_48 = *(undefined8 *)(puVar6 + 1);
    fStack_40 = 1.0;
    uStack_70 = 0x41200000;
    fStack_6c = 66.0;
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    FUN_005542c0("Highlighted Space : Last Known Server Streaming Center\nBlue Star : Regions Streamed In outside of Min Guaranteed Region\nColored Box: Minimum Guaranteed Streamed In Area : Red (< StreamingMinRadius), Yellow (>= StreamingMinRadius and < StreamingTargetRadius), Green (> StreamingTargetRadius) "
                 ,0x123);
    uStack_14 = 1;
    FUN_0114e430(&fStack_3c,auStack_ac,&uStack_70,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                 &uStack_94,&uStack_30,(int)&uStack_8c + 4,1);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_98) {
      uVar16 = uStack_98 + 1;
      uVar15 = auStack_ac[0];
      if (0xfff < uVar16) {
        uVar15 = *(uint *)(auStack_ac[0] - 4);
        uVar16 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar16);
    }
    fStack_6c = (float)(**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
    puVar5 = puStack_20;
    if (fStack_6c != 0.0) {
      iVar7 = FUN_00927e40();
      if (iVar7 == 0) {
        uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
        fStack_84 = _UNK_018e3fc4;
        uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
        fStack_78 = 0.0;
        uStack_30 = _DAT_018e3fd0;
        uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
        fStack_24 = (float)_UNK_018e3fdc;
        fStack_3c = 0.0;
        fStack_38 = 0.0;
        puVar6 = (undefined4 *)FUN_0115e910();
        uStack_5c = *puVar6;
        uStack_58 = *(undefined8 *)(puVar6 + 1);
        uStack_50 = 0x3f800000;
        puVar6 = (undefined4 *)FUN_0115eb90();
        uStack_4c = *puVar6;
        uStack_48 = *(undefined8 *)(puVar6 + 1);
        fStack_40 = 1.0;
        uStack_64 = 0x41200000;
        uStack_60 = 0x42d40000;
        uVar8 = FUN_01675640(auStack_ac,
                             "The specified replication focus has not been streamed in to the client. This may cause streaming to function incorrectly."
                            );
        uStack_14 = 9;
        FUN_0114e430((int)&uStack_d4 + 4,uVar8,&uStack_64,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                     &fStack_3c,&uStack_30,(int)&uStack_8c + 4,1);
        uStack_14 = 0xffffffff;
        FUN_005507b0();
        puVar5 = puStack_20;
      }
      else {
        cStack_31 = '\x01';
        iStack_b0 = 0;
        iStack_bc = 0;
        iVar7 = FUN_008f78c0();
        if ((iVar7 == 0) || (iVar7 = *(int *)(iVar7 + 0x1b8), iVar7 == 0)) {
          iVar7 = 0;
        }
        else {
          iStack_b0 = *(int *)(iVar7 + 0x308);
          iVar7 = *(int *)(iVar7 + 0x304);
          iStack_bc = iVar7;
        }
        iVar17 = *(int *)(param_1 + 0x1c0);
        fVar20 = (float)iVar17;
        fStack_cc = fVar19 - fVar20;
        uStack_d4 = CONCAT44(fVar4 - fVar20,fVar3 - fVar20);
        fStack_40 = fVar20 + fVar19;
        uStack_48 = CONCAT44(fVar20 + fVar4,fVar20 + fVar3);
        fStack_24 = fStack_40;
        if (iVar17 < iStack_b0) {
          puVar6 = (undefined4 *)FUN_0115eb90();
        }
        else if (iVar17 < iVar7) {
          puVar6 = (undefined4 *)FUN_0115ee80();
        }
        else {
          puVar6 = (undefined4 *)FUN_0115eb50();
        }
        fStack_b4 = (float)puVar6[2];
        fStack_68 = (float)puVar6[1];
        uStack_2c = *(undefined8 *)(puVar6 + 1);
        uStack_90 = *puVar6;
        uStack_30 = *puVar6;
        fStack_24 = 0.5;
        FUN_00709d10(&uStack_d4,&uStack_48);
        FUN_0114c290();
        uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
        fStack_84 = _UNK_018e3fc4;
        uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
        fStack_78 = 0.0;
        uStack_30 = _DAT_018e3fd0;
        uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
        fStack_24 = (float)_UNK_018e3fdc;
        uStack_64 = 0;
        uStack_60 = 0;
        puVar6 = (undefined4 *)FUN_0115e910();
        uStack_5c = *puVar6;
        uStack_58 = *(undefined8 *)(puVar6 + 1);
        uStack_50 = 0x3f800000;
        puVar6 = (undefined4 *)FUN_0115eb50();
        uStack_4c = *puVar6;
        uStack_48 = *(undefined8 *)(puVar6 + 1);
        fStack_40 = 1.0;
        fStack_3c = 10.0;
        fStack_38 = 106.0;
        uVar8 = FUN_01675640(auStack_ac,
                             "Replication Focus Position: x: %.2f y: %.2f z : %.2f\nLast Known Server Stream Center : x: %.0f  y: %.0f z: %.0f"
                             ,(double)fVar3,(double)fVar4,(double)fVar19,
                             (double)(((float)*(int *)(param_1 + 0x23c) + DAT_018ce2f4) *
                                     DAT_018df584),
                             (double)(((float)*(int *)(param_1 + 0x240) + DAT_018ce2f4) *
                                     DAT_018df584),
                             (double)(((float)*(int *)(param_1 + 0x244) + DAT_018ce2f4) *
                                     DAT_018df584));
        uStack_14 = 2;
        FUN_0114e430((int)&uStack_d4 + 4,uVar8,&fStack_3c,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                     &uStack_64,&uStack_30,(int)&uStack_8c + 4,1);
        uStack_14 = 0xffffffff;
        FUN_005507b0();
        puVar6 = (undefined4 *)FUN_0115ee70();
        uStack_30 = *puVar6;
        uStack_2c = *(undefined8 *)(puVar6 + 1);
        fStack_24 = 0.075;
        puVar9 = (undefined8 *)FUN_0070d050(auStack_ac,(int *)(param_1 + 0x23c));
        uStack_8c = *puVar9;
        fStack_84 = *(float *)(puVar9 + 1);
        uStack_80 = *(undefined8 *)((int)puVar9 + 0xc);
        fStack_78 = *(float *)((int)puVar9 + 0x14);
        (**(code **)(*param_2 + 0x5c))(&uStack_8c,&uStack_30);
        param_1 = iStack_c0;
        uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
        fStack_84 = _UNK_018e3fc4;
        uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
        fStack_78 = 0.0;
        fStack_3c = 0.0;
        fStack_38 = 0.0;
        uStack_30 = _DAT_018e3fd0;
        uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
        fStack_24 = (float)_UNK_018e3fdc;
        if (*(int *)(iStack_c0 + 0x1cc) < 1) {
          puVar6 = (undefined4 *)FUN_0115e910();
          uStack_5c = *puVar6;
          uStack_58 = *(undefined8 *)(puVar6 + 1);
          uStack_50 = 0x3f800000;
          puVar6 = (undefined4 *)FUN_0115eb50();
          uStack_4c = *puVar6;
          uStack_48 = *(undefined8 *)(puVar6 + 1);
          fStack_40 = 1.0;
          uStack_64 = 0x41200000;
          uStack_60 = 0x43020000;
          uVar8 = FUN_01675640(auStack_ac,"Streaming Radius : Min : %d Target : %d",iStack_b0,
                               iStack_bc);
          uStack_14 = 4;
        }
        else {
          puVar6 = (undefined4 *)FUN_0115e910();
          uStack_5c = *puVar6;
          uStack_58 = *(undefined8 *)(puVar6 + 1);
          uStack_50 = 0x3f800000;
          puVar6 = (undefined4 *)FUN_0115eb50();
          uStack_4c = *puVar6;
          uStack_48 = *(undefined8 *)(puVar6 + 1);
          fStack_40 = 1.0;
          uStack_64 = 0x41200000;
          uStack_60 = 0x43020000;
          uVar8 = FUN_01675640();
          uStack_14 = 3;
        }
        FUN_0114e430((int)&uStack_d4 + 4,uVar8,&uStack_64,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                     &fStack_3c,&uStack_30,(int)&uStack_8c + 4,1);
        uStack_14 = 0xffffffff;
        FUN_005507b0();
        uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
        fStack_84 = _UNK_018e3fc4;
        uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
        fStack_78 = 0.0;
        uStack_30 = _DAT_018e3fd0;
        uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
        fStack_24 = (float)_UNK_018e3fdc;
        fStack_3c = 0.0;
        fStack_38 = 0.0;
        puVar6 = (undefined4 *)FUN_0115e910();
        uStack_5c = *puVar6;
        uStack_58 = *(undefined8 *)(puVar6 + 1);
        uStack_4c = uStack_90;
        uStack_50 = 0x3f800000;
        uStack_48 = CONCAT44(fStack_b4,fStack_68);
        fStack_40 = 1.0;
        uStack_64 = 0x41200000;
        uStack_60 = 0x430e0000;
        uVar8 = FUN_01675640();
        uStack_14 = 5;
        FUN_0114e430((int)&uStack_d4 + 4,uVar8,&uStack_64,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                     &fStack_3c,&uStack_30,(int)&uStack_8c + 4,1);
        uStack_14 = 0xffffffff;
        FUN_005507b0();
        uStack_8c = CONCAT44(_DAT_018e3fc0,(undefined4)uStack_8c);
        fStack_84 = _UNK_018e3fc4;
        uStack_80 = CONCAT44(_UNK_018e3fcc,_UNK_018e3fc8);
        fStack_78 = 0.0;
        uStack_30 = _DAT_018e3fd0;
        uStack_2c = CONCAT44(_UNK_018e3fd8,_UNK_018e3fd4);
        fStack_24 = (float)_UNK_018e3fdc;
        fStack_3c = 0.0;
        fStack_38 = 0.0;
        puVar6 = (undefined4 *)FUN_0115e910();
        uStack_5c = *puVar6;
        uStack_58 = *(undefined8 *)(puVar6 + 1);
        uStack_50 = 0x3f800000;
        puVar6 = (undefined4 *)FUN_0115ee70();
        uStack_4c = *puVar6;
        uStack_48 = *(undefined8 *)(puVar6 + 1);
        fStack_40 = 1.0;
        uStack_64 = 0x41200000;
        uStack_60 = 0x431e0000;
        piVar10 = (int *)FUN_00927d50();
        uStack_14 = 6;
        if (*piVar10 != 0) {
          FUN_00927d50();
          fStack_74 = 1.4013e-45;
          uStack_14 = CONCAT31(uStack_14._1_3_,7);
        }
        uVar8 = FUN_01675640();
        uStack_14 = 8;
        FUN_0114e430((int)&uStack_d4 + 4,uVar8,&uStack_64,0x41000000,1,&uStack_4c,&uStack_5c,0,1,0,
                     &fStack_3c,&uStack_30,(int)&uStack_8c + 4,1);
        FUN_005507b0();
        if (((uint)fStack_74 & 1) != 0) {
          FUN_00550b30();
        }
        uStack_14 = 0xffffffff;
        FUN_00550b30();
        puVar5 = puStack_20;
      }
    }
  }
  puStack_20 = puVar5;
  pfVar11 = (float *)(**(code **)(*param_2 + 0x30))();
  fStack_c8 = 20.0;
  uStack_c4 = 0x41a00000;
  fStack_6c = (pfVar11[2] - *pfVar11) - DAT_018e3fa0;
  fStack_3c = fVar3;
  fStack_38 = fVar19;
  FUN_01163100();
  if (*(int *)(param_1 + 0x150) == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x15c) + *(int *)(param_1 + 0x14c) * 4);
  }
  for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
    if (*(char *)(puVar6 + 5) != '\0') {
      uVar1 = *(undefined8 *)(puVar6 + 2);
      uVar2 = *(undefined8 *)(iStack_c0 + 0x23c);
      uVar15 = *(int *)(iStack_c0 + 0x244) - puVar6[4];
      uStack_58._4_4_ = (int)((ulonglong)uVar2 >> 0x20);
      uStack_2c._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
      uVar16 = uStack_58._4_4_ - uStack_2c._4_4_ >> 0x1f;
      iVar17 = (uStack_58._4_4_ - uStack_2c._4_4_ ^ uVar16) - uVar16;
      uVar16 = (int)uVar15 >> 0x1f;
      uStack_58._0_4_ = (int)uVar2;
      uStack_2c._0_4_ = (int)uVar1;
      iVar7 = (uVar15 ^ uVar16) - uVar16;
      uVar15 = (int)uStack_58 - (int)uStack_2c >> 0x1f;
      iVar12 = ((int)uStack_58 - (int)uStack_2c ^ uVar15) - uVar15;
      if (iVar17 <= iVar12) {
        iVar17 = iVar12;
      }
      if (iVar7 <= iVar17) {
        iVar7 = iVar17;
      }
      uStack_58 = uVar2;
      uStack_2c = uVar1;
      if (*(int *)(iStack_c0 + 0x1c0) < iVar7) {
        uStack_48 = CONCAT44(((float)(int)puVar6[3] + DAT_018ce2f4) * DAT_018df584,
                             ((float)(int)puVar6[2] + DAT_018ce2f4) * DAT_018df584);
        fStack_40 = ((float)(int)puVar6[4] + DAT_018ce2f4) * DAT_018df584;
        FUN_0115e920();
        FUN_0115e920();
        FUN_0115e920();
        FUN_0114cbc0();
      }
    }
    if (cStack_31 != '\0') {
      fStack_b4 = fStack_c8;
      fStack_68 = (float)(int)puVar6[4] - fStack_d8;
      fStack_74 = (float)(int)puVar6[2] - fStack_dc;
      dVar18 = (double)(fStack_68 * fStack_68 + fStack_74 * fStack_74);
      FUN_017267a0();
      if ((float)dVar18 <= DAT_018e3f90) {
        dVar18 = (double)((float)(int)puVar6[3] - fVar4 * DAT_018e3f7c);
        if ((float)(double)CONCAT44((uint)((ulonglong)dVar18 >> 0x20) & DAT_018c0da0._4_4_,
                                    SUB84(dVar18,0) & (uint)DAT_018c0da0) < DAT_018ce2f8) {
          if ((float)(int)puVar6[3] <= fVar4 * DAT_018e3f7c) {
            if (*(char *)(puVar6 + 5) == '\0') {
              puVar13 = (undefined4 *)FUN_0115ee80();
            }
            else {
              puVar13 = (undefined4 *)FUN_0115eb50();
            }
            uStack_a4 = *puVar13;
            uStack_a0 = puVar13[1];
            uStack_9c = puVar13[2];
            uStack_98 = 0x3e4ccccd;
            pfVar11 = (float *)FUN_01163100();
            pfVar14 = (float *)FUN_01163100();
            fVar19 = fStack_74 * fStack_b4 + fStack_6c + *pfVar14;
            fVar20 = fStack_68 * fStack_b4 + DAT_018e3fa0 + pfVar14[1];
            fStack_84 = fVar19 + *pfVar11;
            fStack_78 = pfVar11[1] + fVar20;
            fVar3 = fStack_84;
            if (fStack_84 <= fVar19) {
              fVar3 = fVar19;
            }
            if (fVar19 <= fStack_84) {
              fStack_84 = fVar19;
            }
            fVar19 = fStack_78;
            if (fVar20 <= fStack_78) {
              fVar19 = fVar20;
            }
            if (fStack_78 <= fVar20) {
              fStack_78 = fVar20;
            }
            uStack_80 = CONCAT44(fVar3,fVar19);
            FUN_0114e800(&fStack_84,fStack_c8 * DAT_018e1340,&uStack_a4);
          }
          else {
            if (*(char *)(puVar6 + 5) == '\0') {
              FUN_0115ee80();
            }
            else {
              FUN_0115eb50();
            }
            FUN_01163100();
            FUN_01163100();
            FUN_0114e910();
          }
        }
      }
    }
  }
  FUN_0115eb90();
  FUN_0114e910();
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 10015 ; VA 0x00710540 ; FUN_00710540 */

void __thiscall
FUN_00710540(int param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,uint param_5)

{
  uint *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  uint auStack_58 [2];
  undefined auStack_50 [24];
  uint auStack_38 [2];
  undefined auStack_30 [24];
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017abc97;
  pvStack_10 = ExceptionList;
  iStack_14 = *(int *)(param_1 + 0xa0);
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x110) = *(int *)(param_1 + 0x110) + 1;
  iStack_8._0_1_ = 0;
  iStack_8._1_3_ = 0;
  iVar4 = iStack_14 + 1;
  if (iStack_14 < 0) {
    iVar4 = 1;
  }
  *(int *)(param_1 + 0xa0) = iVar4;
  puVar1 = (uint *)FUN_0070a970(&iStack_14);
  auStack_38[0] = 0;
  FUN_005880d0(&param_5);
  if (puVar1 != auStack_38) {
    auStack_58[0] = 0;
    iStack_8._0_1_ = 2;
    FUN_005880d0(auStack_38);
    FUN_005880d0(puVar1);
    FUN_005880d0(auStack_58);
    iStack_8._0_1_ = 3;
    if (auStack_58[0] != 0) {
      if (((auStack_58[0] & 1) == 0) && (*(code **)(auStack_58[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_58[0] & 0xfffffffe))(auStack_50,auStack_50,2);
      }
      auStack_58[0] = 0;
    }
  }
  iStack_8._0_1_ = 4;
  if (auStack_38[0] != 0) {
    if (((auStack_38[0] & 1) == 0) && (*(code **)(auStack_38[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_38[0] & 0xfffffffe))(auStack_30,auStack_30,2);
    }
    auStack_38[0] = 0;
  }
  iStack_8._0_1_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x50);
  iVar4 = iStack_14;
  iStack_8._0_1_ = 5;
  puStack_18 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    FUN_006b1a30(*(undefined4 *)(param_1 + -0x10));
    *puVar2 = RBX::Network::Replicator::StreamJob::StreamPrefetchRequestItem::vftable;
    *(undefined8 *)(puVar2 + 0xc) = param_2;
    puVar2[0xe] = param_3;
    *(undefined8 *)(puVar2 + 0x10) = param_4;
    puVar2[0x12] = iVar4;
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (*(int *)(param_1 + -0x10) != 0) {
    iVar4 = *(int *)(*(int *)(param_1 + -0x10) + 0xc);
    iVar3 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      FUN_006b1f50(puVar2);
    }
  }
  iStack_8 = 6;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&stack0x00000020,&stack0x00000020,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10016 ; VA 0x00710700 ; FUN_00710700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00710700(int param_1)

{
  int iVar1;
  bool bVar2;
  
  *(undefined *)(param_1 + 0x17a) = 1;
  iVar1 = FUN_005c3ac0(*(undefined4 *)(param_1 + 0x128));
  if (iVar1 != 0) {
    *(uint *)(param_1 + 0x1c4) =
         *(int *)(iVar1 + 0x308) + (*(int *)(iVar1 + 0x308) >> 0x1f & 0x3fU) & 0xffffffc0;
    *(uint *)(param_1 + 0x1c8) =
         *(int *)(iVar1 + 0x304) + (*(int *)(iVar1 + 0x304) >> 0x1f & 0x3fU) & 0xffffffc0;
    if (DAT_01eaf920 != 0) {
      *(int *)(param_1 + 0x1d0) =
           (int)((double)(*(int *)(iVar1 + 0x304) * DAT_01eaf920) / _DAT_018e3f98);
    }
    bVar2 = *(int *)(iVar1 + 0x30c) == 2;
    *(bool *)(param_1 + 0x17b) = bVar2;
    *(bool *)(*(int *)(param_1 + 0x144) + 0x3d) = bVar2;
  }
  iVar1 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
  if (*(char *)(param_1 + 0x17b) != '\0') {
    FUN_00712370(iVar1);
    return;
  }
  if (iVar1 != 0) {
    FUN_00933a00(0);
  }
  return;
}



/* FUNCTION 10017 ; VA 0x007107c0 ; FUN_007107c0 */

void __fastcall FUN_007107c0(int param_1)

{
  *(int *)(param_1 + 0x248) = *(int *)(param_1 + 0x248) + 1;
  return;
}



/* FUNCTION 10018 ; VA 0x007107d0 ; FUN_007107d0 */

void __thiscall FUN_007107d0(int param_1,undefined8 *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iStack_1c;
  int iStack_18;
  int iStack_10;
  int iStack_c;
  
  *(undefined8 *)(param_1 + 0x23c) = *param_2;
  *(undefined4 *)(param_1 + 0x244) = *(undefined4 *)(param_2 + 1);
  uVar4 = *(int *)(param_1 + 0x244) - *(int *)(param_1 + 0x214);
  iVar2 = *param_3;
  *(int *)(param_1 + 0x1bc) = iVar2;
  iStack_c = (int)((ulonglong)*(undefined8 *)(param_1 + 0x23c) >> 0x20);
  iStack_18 = (int)((ulonglong)*(undefined8 *)(param_1 + 0x20c) >> 0x20);
  uVar6 = iStack_c - iStack_18 >> 0x1f;
  cVar1 = *(char *)(param_1 + 0x178);
  iVar7 = (iStack_c - iStack_18 ^ uVar6) - uVar6;
  uVar6 = (int)uVar4 >> 0x1f;
  iStack_10 = (int)*(undefined8 *)(param_1 + 0x23c);
  iStack_1c = (int)*(undefined8 *)(param_1 + 0x20c);
  iVar5 = (uVar4 ^ uVar6) - uVar6;
  uVar4 = iStack_10 - iStack_1c >> 0x1f;
  iVar3 = (iStack_10 - iStack_1c ^ uVar4) - uVar4;
  if (iVar7 <= iVar3) {
    iVar7 = iVar3;
  }
  if (iVar5 <= iVar7) {
    iVar5 = iVar7;
  }
  *(bool *)(param_1 + 0x178) = iVar2 < iVar5;
  if (((cVar1 != '\0') && (iVar5 <= iVar2)) && (DAT_01ee1b70 != '\0')) {
    FUN_016774b0(DAT_01ee1b70,"characterOutsideStreamedArea changed to false.",0);
  }
  return;
}



/* FUNCTION 10019 ; VA 0x007108a0 ; FUN_007108a0 */

void __thiscall FUN_007108a0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abcc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar3 = FUN_01675290(DAT_01eaf994);
  uStack_8 = 0;
  iVar10 = *(int *)(param_1 + 0x24c);
  puStack_18 = *(undefined4 **)(iVar10 + 4);
  uVar4 = FUN_00708640(iVar10,puStack_18,param_2,param_3,&param_4);
  if (*(int *)(param_1 + 0x250) == 0x9249248) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 0x250) = *(int *)(param_1 + 0x250) + 1;
  *(undefined4 *)(iVar10 + 4) = uVar4;
  *puStack_18 = uVar4;
  FUN_01682800(&uStack_1c);
  uVar8 = param_4 & 0xff;
  *(undefined4 *)(iStack_14 + 0x280) = uStack_1c;
  *(undefined4 **)(iStack_14 + 0x284) = puStack_18;
  *(int *)(iStack_14 + 0x248) = *(int *)(iStack_14 + 0x248) + -1;
  puStack_18 = (undefined4 *)(*(uint *)(iStack_14 + 500) & (uVar8 ^ 0x811c9dc5) * 0x502c3f11);
  param_4 = *(uint *)(iStack_14 + 0x1e8);
  puVar1 = *(undefined4 **)(iStack_14 + 0x1e0);
  puVar9 = *(undefined4 **)(param_4 + (int)puStack_18 * 8);
  puVar5 = puVar9;
  while( true ) {
    puVar6 = puVar1;
    if (puVar9 != puVar1) {
      puVar6 = (undefined4 *)**(undefined4 **)(param_4 + 4 + (int)puStack_18 * 8);
    }
    if (puVar5 == puVar6) goto LAB_007109fa;
    puVar6 = puVar5;
    if (puVar5[2] == uVar8) break;
    puVar5 = (undefined4 *)*puVar5;
  }
  while( true ) {
    puVar9 = puVar1;
    if (*(undefined4 **)(param_4 + (int)puStack_18 * 8) != puVar1) {
      puVar9 = (undefined4 *)**(undefined4 **)(param_4 + 4 + (int)puStack_18 * 8);
    }
    if ((puVar6 == puVar9) || (uVar8 != puVar6[2])) break;
    puVar6 = (undefined4 *)*puVar6;
  }
  if (puVar5 == puVar6) {
LAB_007109fa:
    puVar6 = puVar1;
    puVar5 = puVar1;
  }
  iVar10 = 0;
  if (puVar5 != puVar6) {
    do {
      puVar5 = (undefined4 *)*puVar5;
      iVar10 = iVar10 + 1;
    } while (puVar5 != puVar6);
    if (iVar10 != 0) {
      param_4 = uVar8;
      puVar7 = (uint *)FUN_0070a970(&param_4);
      if (*puVar7 == 0) {
        uVar3 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar3);
      }
      (**(code **)((*puVar7 & 0xfffffffe) + 4))(puVar7 + 2);
      param_4 = uVar8;
      FUN_0070c700(&param_4);
    }
  }
  if (DAT_01d5beac < *(uint *)(iStack_14 + 0x250)) {
    piVar2 = (int *)**(int **)(iStack_14 + 0x24c);
    *(int *)piVar2[1] = *piVar2;
    *(int *)(*piVar2 + 4) = piVar2[1];
    *(int *)(iStack_14 + 0x250) = *(int *)(iStack_14 + 0x250) + -1;
    FUN_01674ea0(piVar2,0x1c);
  }
  uStack_8 = 2;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10020 ; VA 0x00710ad0 ; FUN_00710ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __fastcall FUN_00710ad0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  double *pdVar5;
  int iVar6;
  int iVar7;
  undefined1 *puVar8;
  uint uVar9;
  byte *pbVar10;
  undefined8 *puVar11;
  byte *pbVar12;
  int iVar13;
  uint uVar14;
  undefined4 uVar15;
  float10 fVar16;
  float fVar17;
  int *piVar18;
  undefined8 uVar19;
  float fVar20;
  float fVar21;
  undefined8 *puVar22;
  int iStack_148;
  int iStack_144;
  float fStack_114;
  float fStack_110;
  float fStack_10c;
  float fStack_108;
  float fStack_104;
  float fStack_100;
  undefined4 uStack_f8;
  int iStack_f4;
  byte *pbStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined8 uStack_c8;
  float fStack_c0;
  float fStack_bc;
  byte *pbStack_b8;
  undefined8 uStack_b4;
  byte *pbStack_ac;
  undefined4 uStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  undefined8 uStack_8c;
  byte *pbStack_84;
  undefined auStack_80 [4];
  int *piStack_7c;
  undefined8 uStack_78;
  byte *pbStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  uint uStack_60;
  byte *pbStack_5c;
  byte *pbStack_58;
  byte *pbStack_54;
  uint uStack_50;
  undefined8 uStack_4c;
  byte *pbStack_44;
  int iStack_40;
  byte *pbStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 *puStack_30;
  uint uStack_2c;
  byte *pbStack_28;
  byte *pbStack_24;
  byte *pbStack_20;
  byte *pbStack_1c;
  int iStack_18;
  char cStack_14;
  char cStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abd01;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar4 = FUN_01675290(DAT_01eaf994);
  uStack_8 = 0;
  cStack_11 = '\0';
  cStack_12 = '\0';
  uStack_50 = uStack_50 & 0xffffff00;
  uStack_a8 = uVar4;
  if (*(int *)(param_1 + 0x128) == 0) {
    uVar15 = 0;
    goto LAB_00712168;
  }
  if (*(char *)(param_1 + 0x17a) == '\0') {
    uVar15 = 1;
    goto LAB_00712168;
  }
  FUN_008e9840(*(int *)(param_1 + 0x128));
  uStack_8._0_1_ = 3;
  FUN_0060efa0();
  FUN_0060efa0();
  cStack_13 = '\0';
  cStack_14 = '\0';
  iStack_40 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
  uStack_b4 = (ulonglong)DAT_018c45c4;
  if (iStack_40 != 0) {
    if ((DAT_01d5bf00 != '\0') &&
       (pdVar5 = (double *)FUN_01682800(&uStack_4c),
       DAT_018c0d60 < *pdVar5 - *(double *)(param_1 + 0x278))) {
      iVar6 = FUN_008f7870(iStack_40);
      piVar18 = *(int **)(iVar6 + 0x43c);
      uStack_4c = (double)CONCAT44(piVar18[1] - (int)piVar18,*piVar18 - (int)piVar18);
      FUN_009ee550(&fStack_a4,&uStack_4c);
      uStack_8._0_1_ = 4;
      FUN_0054ef60(&fStack_a4);
      FUN_0070bb60();
      FUN_0062b6b0(auStack_80);
      *(undefined *)(param_1 + 0x1fd) = 0;
      uStack_8._0_1_ = 3;
      FUN_005507b0();
    }
    iVar6 = FUN_00927e40(&uStack_ec);
    if (iVar6 == 0) {
      fVar17 = (float)uStack_b4;
      if ((((NAN(*(float *)(param_1 + 0x1ac)) || NAN(fVar17)) ==
            (*(float *)(param_1 + 0x1ac) == fVar17)) ||
          ((NAN(*(float *)(param_1 + 0x1b0)) || NAN(fVar17)) ==
           (*(float *)(param_1 + 0x1b0) == fVar17))) ||
         ((NAN(*(float *)(param_1 + 0x1b4)) || NAN(fVar17)) ==
          (*(float *)(param_1 + 0x1b4) == fVar17))) {
        uStack_ec = *(undefined4 *)(param_1 + 0x188);
        uStack_e8 = *(undefined4 *)(param_1 + 0x18c);
        uStack_e4 = *(undefined4 *)(param_1 + 400);
        uStack_e0 = *(undefined4 *)(param_1 + 0x194);
        uStack_dc = *(undefined4 *)(param_1 + 0x198);
        uStack_d8 = *(undefined4 *)(param_1 + 0x19c);
        uStack_d4 = *(undefined4 *)(param_1 + 0x1a0);
        uStack_d0 = *(undefined4 *)(param_1 + 0x1a4);
        uStack_cc = *(undefined4 *)(param_1 + 0x1a8);
        uStack_c8 = *(undefined8 *)(param_1 + 0x1ac);
        fStack_c0 = *(float *)(param_1 + 0x1b4);
        goto LAB_00710cf0;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x188) = uStack_ec;
      *(undefined4 *)(param_1 + 0x18c) = uStack_e8;
      *(undefined4 *)(param_1 + 400) = uStack_e4;
      *(undefined4 *)(param_1 + 0x194) = uStack_e0;
      *(undefined4 *)(param_1 + 0x198) = uStack_dc;
      *(undefined4 *)(param_1 + 0x19c) = uStack_d8;
      *(undefined4 *)(param_1 + 0x1a0) = uStack_d4;
      *(undefined4 *)(param_1 + 0x1a4) = uStack_d0;
      *(undefined4 *)(param_1 + 0x1a8) = uStack_cc;
      *(float *)(param_1 + 0x1ac) = (float)uStack_c8;
      *(float *)(param_1 + 0x1b0) = uStack_c8._4_4_;
      *(float *)(param_1 + 0x1b4) = fStack_c0;
LAB_00710cf0:
      cStack_13 = '\x01';
    }
    if ((*(int **)(iStack_40 + 100) != (int *)0x0) &&
       (iVar6 = (**(code **)(**(int **)(iStack_40 + 100) + 0xa8))(), iVar6 != 0)) {
      (**(code **)(**(int **)(iStack_40 + 100) + 0xa8))();
      iVar6 = FUN_00b077e0();
      cStack_14 = '\x01';
      fStack_114 = *(float *)(iVar6 + 0x18);
      fStack_110 = *(float *)(iVar6 + 0x1c);
      fStack_10c = *(float *)(iVar6 + 0x20);
      fStack_108 = *(float *)(iVar6 + 0x24);
      fStack_104 = *(float *)(iVar6 + 0x28);
      fStack_100 = *(float *)(iVar6 + 0x2c);
    }
  }
  pbStack_1c = *(byte **)(param_1 + 0x128);
  iVar6 = *(int *)(pbStack_1c + 0xc);
  iVar7 = FUN_005edd10();
  pbVar12 = (byte *)0x0;
  if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
      (uint)*(ushort *)(iVar7 + 0x1da)) {
    pbVar12 = pbStack_1c;
  }
  pbStack_54 = pbVar12;
  FUN_006f5200();
  FUN_006f4bc0();
  fStack_bc = 0.0;
  if (cStack_13 == '\0') {
    fStack_90 = 3.4028235e+38;
    FUN_00932fc0(CONCAT44((int)uStack_b4,(int)uStack_b4),0x7f7fffff);
    iVar6 = iStack_18;
  }
  else {
    if ((*(int *)(pbVar12 + 0x3c70) < 1) || (*(char *)(iStack_18 + 0x1fc) != '\0')) {
      cStack_12 = '\x01';
LAB_00710dc3:
      cStack_11 = '\x01';
    }
    else {
      cVar3 = FUN_006eff80();
      if (cVar3 != '\0') goto LAB_00710dc3;
    }
    puVar22 = &uStack_c8;
    puVar11 = &uStack_78;
    FUN_006ddab0();
    FUN_006ddab0(&iStack_6c,&fStack_108,puVar11,puVar22);
    iVar6 = iStack_40;
    cVar3 = FUN_006da0a0(iStack_40,&DAT_0211e3e4,0);
    pbStack_24 = pbStack_70;
    uStack_38 = uStack_78._4_4_;
    pbStack_44 = (byte *)uStack_78;
    if ((cVar3 == '\0') && (cVar3 = FUN_006da0a0(iVar6,&DAT_0211e300,0), cVar3 == '\0')) {
      FUN_00927d50(&uStack_4c);
      uStack_8._0_1_ = 5;
      pbStack_1c = (byte *)uStack_4c;
      if ((byte *)uStack_4c == (byte *)0x0) {
        if (cStack_14 == '\0') {
          uVar19 = CONCAT44((int)uStack_b4,(int)uStack_b4);
          fStack_90 = 3.4028235e+38;
        }
        else {
          fStack_90 = (float)iStack_64;
          uVar19 = CONCAT44((float)iStack_68,(float)iStack_6c);
        }
      }
      else {
        iVar6 = *(int *)((byte *)uStack_4c + 0xc);
        iVar7 = FUN_00b63e30();
        if (((uint)*(ushort *)(iVar7 + 0x1da) <
             (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) ||
           (pbStack_1c[0x140] != 0)) {
          fStack_90 = (float)(int)pbStack_24;
          uVar19 = CONCAT44((float)(int)uStack_38,(float)(int)pbStack_44);
        }
        else {
          uVar19 = CONCAT44((int)uStack_b4,(int)uStack_b4);
          fStack_90 = 3.4028235e+38;
        }
      }
      FUN_00932fc0(uVar19,fStack_90);
      uStack_8._0_1_ = 3;
      FUN_00550b30();
    }
    else {
      fStack_90 = 3.4028235e+38;
      FUN_00932fc0(CONCAT44((int)uStack_b4,(int)uStack_b4),0x7f7fffff);
    }
    iVar6 = iStack_18;
    if (((*(int *)(iStack_18 + 0x20c) != iStack_6c) || (*(int *)(iStack_18 + 0x210) != iStack_68))
       || (*(int *)(iStack_18 + 0x214) != iStack_64)) {
      cStack_14 = *(char *)(iStack_18 + 0x178);
      iVar7 = FUN_006e6190(*(undefined8 *)(iStack_18 + 0x23c),*(undefined4 *)(iStack_18 + 0x244),
                           CONCAT44(iStack_68,iStack_6c),iStack_64);
      if (*(int *)(iVar6 + 0x1bc) < iVar7) {
        pbStack_3c = (byte *)(iVar6 + 0x148);
        iVar6 = iVar6 + 0x149 + (uint)*(byte *)(iVar6 + 0x148);
        uVar15 = FUN_00ca2680(&iStack_6c);
        pbVar12 = pbStack_3c;
        FUN_006e16e0(&pbStack_1c,uVar15,&iStack_6c,-(uint)(iVar6 != 0) & iVar6 + 1U);
        if (pbStack_1c != (byte *)0x0) {
          pbStack_20 = (byte *)FUN_00ca2680(&iStack_6c);
          FUN_006e16e0(&pbStack_1c,pbStack_20,&iStack_6c,
                       -(uint)(pbVar12 + *pbVar12 + 1 != (byte *)0x0) &
                       (uint)(pbVar12 + *pbVar12 + 1 + 1));
          iVar6 = iStack_64;
          if (pbStack_1c == (byte *)0x0) {
            puStack_30 = (undefined4 *)0x0;
            uStack_34 = -(uint)(pbVar12 != (byte *)0xfffffffd) & (uint)(pbVar12 + 4);
            uStack_4c = (double)CONCAT44(iStack_68,iStack_6c);
            uStack_8._0_1_ = 6;
            uStack_2c = uStack_2c & 0xffff0000;
            puStack_30 = (undefined4 *)FUN_01674e20(0x18);
            *puStack_30 = 0;
            puStack_30[1] = 0;
            puStack_30[5] = 0;
            *(double *)(puStack_30 + 2) = uStack_4c;
            puStack_30[4] = iVar6;
            if (puStack_30 + 5 != (undefined4 *)0x0) {
              *(undefined *)(puStack_30 + 5) = 0;
            }
            uStack_2c = CONCAT22(uStack_2c._2_2_,0x101);
            FUN_005d99d0(*(int *)(pbStack_3c + 8) + 1);
            piVar18 = (int *)FUN_005c5550(&piStack_7c,&uStack_34,pbStack_20);
            uStack_8._0_1_ = 3;
            pbVar12 = (byte *)(*piVar18 + 8);
            if (puStack_30 != (undefined4 *)0x0) {
              FUN_01674ea0();
            }
          }
          else {
            pbVar12 = pbStack_1c + 8;
          }
          iVar6 = iStack_18;
          if (pbVar12[0xc] != 0) goto LAB_0071113a;
        }
        cVar3 = '\x01';
        iVar6 = iStack_18;
      }
      else {
LAB_0071113a:
        cVar3 = '\0';
      }
      *(char *)(iVar6 + 0x178) = cVar3;
      if ((cVar3 != cStack_14) && (DAT_01ee1b70 != '\0')) {
        pbStack_1c = &DAT_018bdf48;
        puVar8 = &DAT_018bdf50;
        if (cVar3 == '\0') {
          puVar8 = &DAT_018bdf48;
        }
        FUN_01677650(DAT_01ee1b70,"outsideStreamedArea changed to %s",puVar8);
      }
      *(ulonglong *)(iVar6 + 0x20c) = CONCAT44(iStack_68,iStack_6c);
      *(int *)(iVar6 + 0x214) = iStack_64;
    }
    if (((*(byte **)(iVar6 + 0x200) != pbStack_44) || (*(uint *)(iVar6 + 0x204) != uStack_38)) ||
       (*(byte **)(iVar6 + 0x208) != pbStack_24)) {
      if ((cStack_12 != '\0') ||
         (fVar21 = uStack_c8._4_4_ - *(float *)(iVar6 + 0x180),
         fVar20 = (float)uStack_c8 - *(float *)(iVar6 + 0x17c),
         fVar17 = fStack_c0 - *(float *)(iVar6 + 0x184),
         _DAT_018e3fa4 <= fVar21 * fVar21 + fVar20 * fVar20 + fVar17 * fVar17)) {
        if (DAT_01ee1b70 != '\0') {
          fVar21 = uStack_c8._4_4_ - *(float *)(iVar6 + 0x180);
          fVar20 = (float)uStack_c8 - *(float *)(iVar6 + 0x17c);
          fVar17 = fStack_c0 - *(float *)(iVar6 + 0x184);
          FUN_016774d0(DAT_01ee1b70,"Last player pos translation squared: %.0f",
                       fVar21 * fVar21 + fVar20 * fVar20 + fVar17 * fVar17,0,0,0);
        }
        *(undefined8 *)(iVar6 + 0x17c) = uStack_c8;
        *(float *)(iVar6 + 0x184) = fStack_c0;
        *(undefined8 *)(iVar6 + 0x200) = uStack_78;
        cStack_11 = '\x01';
        *(byte **)(iVar6 + 0x208) = pbStack_24;
      }
    }
  }
  if ((0 < *(int *)(iVar6 + 0x1b8)) || (*(char *)(iVar6 + 0x1fc) != '\0')) {
    cStack_11 = '\x01';
  }
  if (((DAT_01eaf914 != 0) ||
      ((((cVar3 = cStack_11, *(int *)(iVar6 + 0x1d0) != 0 && (cStack_13 != '\0')) &&
        (*(int *)(iVar6 + 0x248) == 0)) &&
       (pdVar5 = (double *)FUN_01682800(&uStack_4c), cVar3 = cStack_11,
       (double)DAT_01d5beb8 < (*pdVar5 - *(double *)(iVar6 + 0x280)) * DAT_018c0d70)))) &&
     (cVar3 = cStack_11, *(int *)(iVar6 + 0x150) != 0)) {
    FUN_006ddab0();
    pbStack_3c = (byte *)(iVar6 + 0x160);
    if (((*(int *)(iVar6 + 0x164) == 0) || (*(int *)(iVar6 + 0x16c) == 0)) ||
       (*(int *)(iVar6 + 0x174) == 0)) {
      pbVar12 = (byte *)0x0;
    }
    else {
      pbStack_1c = *(byte **)(**(int **)(iVar6 + 0x170) + 0x10);
      uVar9 = uStack_34 - *(int *)(**(int **)pbStack_3c + 0x10);
      uVar14 = (int)uVar9 >> 0x1f;
      pbVar10 = (byte *)((uVar9 ^ uVar14) - uVar14);
      uVar9 = (int)puStack_30 - *(int *)(**(int **)(iVar6 + 0x168) + 0x10);
      uVar14 = (int)uVar9 >> 0x1f;
      pbVar12 = (byte *)((uVar9 ^ uVar14) - uVar14);
      uVar9 = (int)(uStack_2c - (int)pbStack_1c) >> 0x1f;
      pbStack_20 = (byte *)((uStack_2c - (int)pbStack_1c ^ uVar9) - uVar9);
      if ((int)pbVar12 <= (int)pbVar10) {
        pbVar12 = pbVar10;
      }
      if ((int)pbStack_20 <= (int)pbVar12) {
        pbStack_20 = pbVar12;
      }
      puVar11 = (undefined8 *)FUN_0070dd60(&fStack_98);
      uVar19 = *puVar11;
      uStack_78._0_4_ = (byte *)uVar19;
      uVar9 = (int)(uStack_34 - (int)(byte *)uStack_78) >> 0x1f;
      pbVar10 = (byte *)((uStack_34 - (int)(byte *)uStack_78 ^ uVar9) - uVar9);
      uStack_78._4_4_ = (uint)((ulonglong)uVar19 >> 0x20);
      uVar9 = (int)((int)puStack_30 - uStack_78._4_4_) >> 0x1f;
      pbVar12 = (byte *)(((int)puStack_30 - uStack_78._4_4_ ^ uVar9) - uVar9);
      uVar9 = (int)(uStack_2c - *(int *)(puVar11 + 1)) >> 0x1f;
      pbStack_1c = (byte *)((uStack_2c - *(int *)(puVar11 + 1) ^ uVar9) - uVar9);
      if ((int)pbVar12 <= (int)pbVar10) {
        pbVar12 = pbVar10;
      }
      if ((int)pbStack_1c <= (int)pbVar12) {
        pbStack_1c = pbVar12;
      }
      pbVar12 = pbStack_20;
      iVar6 = iStack_18;
      uStack_78 = uVar19;
      if ((int)pbStack_20 <= (int)pbStack_1c) {
        FUN_0070dd60(&fStack_98);
        pbVar12 = pbStack_1c;
        iVar6 = iStack_18;
      }
    }
    if ((DAT_01eaf914 != 0) && (DAT_01eaf914 < (int)pbVar12)) {
      cStack_11 = '\x01';
      cStack_12 = '\x01';
      *(short *)(iVar6 + 0x1d4) = (short)DAT_01eaf914;
    }
    cVar3 = cStack_11;
    if (*(int *)(iVar6 + 0x1d0) < (int)pbVar12) {
      if (DAT_01eaf35c != '\0') {
        FUN_01677520(DAT_01eaf35c,"Stream max distance exceeded, longest distance: %i  max: %i",
                     pbVar12,*(int *)(iVar6 + 0x1d0));
      }
      uStack_50 = uStack_50 & 0xff;
      if (DAT_01d5bf18 != '\0') {
        uStack_50 = 1;
      }
      cStack_12 = '\x01';
      cVar3 = '\x01';
    }
  }
  pbStack_1c = (byte *)((uint)pbStack_1c & 0xffffff00);
  if (cVar3 != '\0') {
    cVar3 = FUN_006eff80();
    if ((cVar3 == '\0') && (cStack_12 == '\0')) {
      FUN_007121f0();
    }
    else {
      *(undefined *)(iVar6 + 0x1fd) = 1;
      *(undefined4 *)(iVar6 + 0x260) = 0;
      FUN_006ddab0();
      uStack_60 = 0;
      pbStack_5c = (byte *)0x0;
      pbStack_58 = (byte *)0x0;
      uStack_34 = 0;
      puStack_30 = (undefined4 *)0x0;
      uStack_2c = 0;
      pbStack_20 = (byte *)FUN_0070db60(&fStack_98,&uStack_60,&uStack_34);
      iVar7 = FUN_005c3ac0(*(undefined4 *)(iVar6 + 0x128));
      if (iVar7 == 0) {
        *(undefined4 *)(iVar6 + 0x1b8) = 0;
      }
      else if ((int)(*(int *)(iVar7 + 0x308) + (*(int *)(iVar7 + 0x308) >> 0x1f & 0x3fU)) >> 6 <
               (int)pbStack_20) {
        if (*(int *)(iVar6 + 0x1b8) < 1) {
          pbStack_3c = *(byte **)(iVar6 + 0x150);
          pbStack_24 = DAT_01d5be7c;
          pbStack_28 = *(byte **)(iVar6 + 0x128);
          iVar6 = *(int *)(pbStack_28 + 0xc);
          iVar7 = FUN_005edd10();
          pbVar12 = (byte *)0x0;
          if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
              (uint)*(ushort *)(iVar7 + 0x1da)) {
            pbVar12 = pbStack_28;
          }
          pbVar10 = pbStack_24;
          if ((((int)DAT_01d5be84 <= (int)DAT_01d5be7c) && (pbVar12 != (byte *)0x0)) &&
             (*(int *)(pbVar12 + 0x3c70) < 3)) {
            pbVar10 = DAT_01d5be84;
          }
          pbVar12 = pbStack_3c;
          iVar6 = iStack_18;
          if (*(char *)(iStack_18 + 0x1fc) == '\0') {
            if (pbStack_3c <= pbVar10) {
              *(undefined4 *)(iStack_18 + 0x1b8) = 1;
              goto LAB_00711660;
            }
            pbVar12 = (byte *)((uint)pbStack_3c / (uint)pbVar10);
          }
          *(byte **)(iStack_18 + 0x1b8) = pbVar12;
          if ((int)pbVar12 < 1) goto LAB_00711c1d;
        }
LAB_00711660:
        pbStack_1c = (byte *)CONCAT31(pbStack_1c._1_3_,1);
        cVar3 = FUN_006e28e0(iVar6 + 0x218);
        if ((cVar3 == '\0') || (cVar3 = FUN_006e28e0(iVar6 + 0x224), cVar3 == '\0')) {
          uStack_38 = uStack_60;
          pbStack_44 = pbStack_5c;
          *(ulonglong *)(iVar6 + 0x224) = CONCAT44(pbStack_5c,uStack_60);
          pbStack_24 = pbStack_58;
          *(ulonglong *)(iVar6 + 0x218) = CONCAT44(puStack_30,uStack_34);
          *(byte **)(iVar6 + 0x22c) = pbStack_58;
          *(uint *)(iVar6 + 0x220) = uStack_2c;
        }
        else {
          uStack_38 = *(uint *)(iVar6 + 0x230);
          pbStack_44 = *(byte **)(iVar6 + 0x234);
          pbStack_24 = *(byte **)(iVar6 + 0x238);
        }
        *(ulonglong *)(iVar6 + 0x230) = CONCAT44(pbStack_5c,uStack_60);
        *(byte **)(iVar6 + 0x238) = pbStack_58;
        if ((DAT_01eaf910 < 1) || (cStack_12 == '\0')) {
          if (DAT_01d5be70 != 0) {
            pdVar5 = (double *)FUN_01682800(&uStack_4c);
            iVar7 = DAT_01d5be70;
            goto LAB_0071171a;
          }
          pdVar5 = (double *)FUN_01682800(&uStack_4c);
          uStack_4c = *pdVar5 + _DAT_018e3f80;
        }
        else {
          pdVar5 = (double *)FUN_01682800(&uStack_4c);
          iVar7 = DAT_01eaf910;
LAB_0071171a:
          uStack_4c = (double)((float)iVar7 / DAT_018d0938) + *pdVar5;
        }
        cVar3 = '\0';
        cStack_11 = '\0';
        uVar9 = uStack_34;
        iVar7 = iStack_18;
        if ((int)pbStack_44 <= (int)puStack_30) {
          do {
            uVar4 = uStack_a8;
            iVar6 = iStack_18;
            if (cVar3 != '\0') break;
            if ((int)pbStack_24 <= (int)uStack_2c) {
              do {
                if (cVar3 != '\0') break;
                if ((int)uStack_38 <= (int)uVar9) {
                  do {
                    uVar14 = uStack_38;
                    if (cVar3 != '\0') break;
                    uStack_8c = CONCAT44(pbStack_44,uStack_38);
                    pbStack_84 = pbStack_24;
                    iVar6 = FUN_0070b7c0(&uStack_8c);
                    if (iVar6 != 0) {
                      if (DAT_01eaf35c != '\0') {
                        FUN_01677520(DAT_01eaf35c,
                                     "Deleted region (%d,%d,%d), gcdist = %d, currentRad = %d",
                                     (int)uStack_8c,uStack_8c._4_4_,pbStack_84,
                                     (int)*(short *)(iVar7 + 0x1d4),*(undefined4 *)(iVar7 + 0x1c0));
                      }
                      uVar9 = *(int *)(iVar7 + 0x244) - (int)pbStack_84;
                      iStack_148 = (int)*(undefined8 *)(iVar7 + 0x23c);
                      uVar14 = iStack_148 - (int)uStack_8c >> 0x1f;
                      pbStack_28 = (byte *)((iStack_148 - (int)uStack_8c ^ uVar14) - uVar14);
                      iStack_144 = (int)((ulonglong)*(undefined8 *)(iVar7 + 0x23c) >> 0x20);
                      uVar14 = iStack_144 - uStack_8c._4_4_ >> 0x1f;
                      pbVar10 = (byte *)((iStack_144 - uStack_8c._4_4_ ^ uVar14) - uVar14);
                      uVar14 = (int)uVar9 >> 0x1f;
                      pbVar12 = (byte *)((uVar9 ^ uVar14) - uVar14);
                      if ((int)pbVar10 <= (int)pbStack_28) {
                        pbVar10 = pbStack_28;
                      }
                      if ((int)pbVar12 <= (int)pbVar10) {
                        pbVar12 = pbVar10;
                      }
                      pbVar12 = pbVar12 + -1;
                      if (((int)pbVar12 < *(int *)(iVar7 + 0x1bc)) &&
                         (*(byte **)(iVar7 + 0x1bc) = pbVar12, DAT_01eaf35c != '\0')) {
                        FUN_01677520(DAT_01eaf35c,
                                     "Shrank current streamed in radius to %d regions due to region removal"
                                     ,pbVar12);
                      }
                      if ((*(int *)(iVar7 + 0x250) != 0) &&
                         (piVar18 = (int *)**(int **)(iVar7 + 0x24c),
                         piVar18 != *(int **)(iVar7 + 0x24c))) {
                        do {
                          fStack_108 = (float)piVar18[2];
                          fStack_104 = (float)piVar18[3];
                          iStack_f4 = piVar18[4];
                          uVar9 = (int)fStack_108 - (int)uStack_8c >> 0x1f;
                          pbStack_ac = (byte *)(((int)fStack_108 - (int)uStack_8c ^ uVar9) - uVar9);
                          uVar9 = (int)fStack_104 - uStack_8c._4_4_ >> 0x1f;
                          pbStack_28 = (byte *)(((int)fStack_104 - uStack_8c._4_4_ ^ uVar9) - uVar9)
                          ;
                          uVar9 = iStack_f4 - (int)pbStack_84 >> 0x1f;
                          pbVar10 = (byte *)((iStack_f4 - (int)pbStack_84 ^ uVar9) - uVar9);
                          pbVar12 = pbStack_28;
                          if ((int)pbStack_28 <= (int)pbStack_ac) {
                            pbVar12 = pbStack_ac;
                          }
                          if ((int)pbVar10 <= (int)pbVar12) {
                            pbVar10 = pbVar12;
                          }
                          fStack_98 = fStack_108;
                          fStack_94 = fStack_104;
                          if ((int)(pbVar10 + -1) <
                              (int)(*(int *)(iVar7 + 0x1c4) +
                                   (*(int *)(iVar7 + 0x1c4) >> 0x1f & 0x3fU)) >> 6) {
                            pbStack_28 = (byte *)piVar18[5];
                            piStack_7c = (int *)*piVar18;
                            *(int **)piVar18[1] = piStack_7c;
                            *(int *)(*piVar18 + 4) = piVar18[1];
                            *(int *)(iVar7 + 0x250) = *(int *)(iVar7 + 0x250) + -1;
                            FUN_01674ea0();
                            piVar18 = piStack_7c;
                            if ((*(uint *)(*(int *)(iVar7 + 0x128) + 0x380c) & 2) != 0) {
                              uStack_b4 = CONCAT44(DAT_01d5b924,(undefined4)uStack_b4);
                              if (((int)pbStack_28 < DAT_01d5b924) &&
                                 (pbVar10 = (byte *)-DAT_01d5b924, pbVar12 = pbVar10,
                                 iVar6 = DAT_01d5b924, pbStack_3c = pbVar10, pbStack_28 = pbVar10,
                                 -DAT_01d5b924 == DAT_01d5b924 ||
                                 SBORROW4((int)pbVar10,DAT_01d5b924) != DAT_01d5b924 * -2 < 0)) {
                                do {
                                  pbStack_ac = pbVar12;
                                  pbVar12 = pbStack_ac;
                                  pbStack_3c = pbVar10;
                                  if ((int)pbStack_ac <= iVar6) {
                                    do {
                                      iVar13 = iStack_18;
                                      pbStack_b8 = pbVar12;
                                      if ((int)pbVar12 <= iVar6) {
                                        pbStack_f0 = pbStack_ac + (int)fStack_94;
                                        do {
                                          uStack_78 = CONCAT44(pbStack_f0,pbVar10 + (int)fStack_98);
                                          pbStack_70 = pbVar12 + iStack_f4;
                                          pbStack_b8 = pbVar12;
                                          cVar3 = FUN_0070e2b0();
                                          if (cVar3 != '\0') {
                                            uStack_f8 = *(undefined4 *)(iVar13 + 0x128);
                                            FUN_005edd10();
                                            FUN_006f48e0(&uStack_78);
                                            FUN_0070f350(&uStack_78);
                                            iVar6 = uStack_b4._4_4_;
                                          }
                                          pbVar12 = pbStack_b8 + 1;
                                          pbVar10 = pbStack_3c;
                                          iVar7 = iVar13;
                                          pbStack_b8 = pbVar12;
                                        } while ((int)pbVar12 <= iVar6);
                                      }
                                      pbStack_ac = pbStack_ac + 1;
                                      pbVar12 = pbStack_28;
                                    } while ((int)pbStack_ac <= iVar6);
                                  }
                                  pbVar10 = pbVar10 + 1;
                                  piVar18 = piStack_7c;
                                  pbStack_3c = pbVar10;
                                } while ((int)pbVar10 <= iVar6);
                              }
                            }
                          }
                          else {
                            piVar18 = (int *)*piVar18;
                          }
                        } while (piVar18 != *(int **)(iVar7 + 0x24c));
                      }
                      cVar3 = FUN_0070f350(&uStack_8c);
                      if (cVar3 != '\0') {
                        *(short *)(iVar7 + 0x1d4) = (short)pbStack_20 + -1;
                      }
                      *(int *)(iVar7 + 0x1b8) = *(int *)(iVar7 + 0x1b8) + -1;
                      uVar14 = uStack_38;
                      if (((cStack_12 != '\0') && (*(char *)(iVar7 + 0x1fc) == '\0')) &&
                         ((char)uStack_50 == '\0')) {
                        piStack_7c = *(int **)(iVar7 + 0x128);
                        iVar6 = piStack_7c[3];
                        iVar13 = FUN_005edd10();
                        piVar18 = (int *)0x0;
                        if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar13 + 0x1d8) <=
                            (uint)*(ushort *)(iVar13 + 0x1da)) {
                          piVar18 = piStack_7c;
                        }
                        FUN_006f5200();
                        uVar14 = uStack_38;
                        if (3 < piVar18[0xf1c]) {
                          *(undefined8 *)(iVar7 + 0x230) = uStack_8c;
                          *(byte **)(iVar7 + 0x238) = pbStack_84;
                          cStack_11 = '\x01';
                        }
                      }
                    }
                    pdVar5 = (double *)FUN_01682800(&iStack_68);
                    if (uStack_4c < *pdVar5) {
                      *(undefined8 *)(iVar7 + 0x230) = uStack_8c;
                      *(byte **)(iVar7 + 0x238) = pbStack_84;
                      cStack_11 = '\x01';
                    }
                    if (*(int *)(iVar7 + 0x1b8) < 1) {
                      *(undefined *)(iVar7 + 0x1fc) = 0;
                      cStack_11 = '\x01';
                    }
                    uStack_38 = uVar14 + 1;
                    uVar9 = uStack_34;
                    cVar3 = cStack_11;
                  } while ((int)uStack_38 <= (int)uStack_34);
                }
                uStack_38 = uStack_60;
                pbStack_24 = pbStack_24 + 1;
              } while ((int)pbStack_24 <= (int)uStack_2c);
            }
            pbStack_24 = pbStack_58;
            pbStack_44 = pbStack_44 + 1;
            uVar4 = uStack_a8;
            iVar6 = iStack_18;
          } while ((int)pbStack_44 <= (int)puStack_30);
        }
        if ((DAT_01d5bf20 == '\0') && (*(int *)(iVar6 + 0x28c) - *(int *)(iVar6 + 0x288) >> 3 != 0))
        {
          FUN_0070f020(pbStack_54);
        }
      }
      else {
        *(undefined4 *)(iVar6 + 0x1b8) = 0;
      }
LAB_00711c1d:
      if (((*(uint *)(*(int *)(iVar6 + 0x128) + 0x380c) & 2) != 0) &&
         ((int)(*(int *)(iVar6 + 0x1c0) + (*(int *)(iVar6 + 0x1c0) >> 0x1f & 0x3fU)) >> 6 <
          DAT_01d5b924)) {
        pdVar5 = (double *)FUN_01682800(&iStack_68);
        uStack_60 = 0;
        pbStack_5c = (byte *)0x0;
        pbStack_58 = (byte *)0x0;
        uStack_34 = 0;
        puStack_30 = (undefined4 *)0x0;
        uStack_2c = 0;
        uStack_4c = (double)((float)DAT_01d5be54 / DAT_018d0938) + *pdVar5;
        iVar7 = FUN_0070db60(iVar6 + 0x200,&uStack_60,&uStack_34);
        if (DAT_01d5b924 < iVar7) {
          do {
            uStack_50 = uStack_60;
            uVar9 = uStack_2c;
            if ((int)uStack_60 <= (int)uStack_34) {
              do {
                pbStack_28 = pbStack_5c;
                if ((int)pbStack_5c <= (int)puStack_30) {
                  do {
                    pbStack_20 = pbStack_58;
                    if ((int)pbStack_58 <= (int)uVar9) {
                      do {
                        uStack_78 = CONCAT44(pbStack_28,uStack_50);
                        pbStack_70 = pbStack_20;
                        cVar3 = FUN_0070e2b0();
                        if (cVar3 != '\0') {
                          piStack_7c = *(int **)(iVar6 + 0x128);
                          FUN_005edd10();
                          FUN_006f48e0(&uStack_78);
                          FUN_0070f350(&uStack_78);
                          uVar4 = uStack_a8;
                          iVar6 = iStack_18;
                          if (((*(int *)(iStack_18 + 0x2f8) == 0) ||
                              (*(int *)(iStack_18 + 0x300) == 0)) ||
                             (*(int *)(iStack_18 + 0x308) == 0)) goto LAB_00711df9;
                        }
                        pdVar5 = (double *)FUN_01682800(&iStack_68);
                        uVar4 = uStack_a8;
                        if (uStack_4c < *pdVar5) goto LAB_00711df9;
                        pbStack_20 = pbStack_20 + 1;
                        uVar9 = uStack_2c;
                      } while ((int)pbStack_20 <= (int)uStack_2c);
                    }
                    pbStack_28 = pbStack_28 + 1;
                  } while ((int)pbStack_28 <= (int)puStack_30);
                }
                uStack_50 = uStack_50 + 1;
              } while ((int)uStack_50 <= (int)uStack_34);
            }
            iVar7 = FUN_0070db60(iVar6 + 0x200,&uStack_60,&uStack_34);
            uVar4 = uStack_a8;
          } while (DAT_01d5b924 < iVar7);
        }
      }
    }
  }
LAB_00711df9:
  if ((DAT_01d5bf20 != '\0') &&
     (FUN_0070ed60(pbStack_54), *(int *)(iVar6 + 0x28c) - *(int *)(iVar6 + 0x288) >> 3 != 0)) {
    FUN_0070f020(pbStack_54);
  }
  if (cStack_13 == '\0') {
    if ((DAT_01ee1b70 != '\0') && (*(char *)(iVar6 + 0x179) != '\0')) {
      FUN_016774b0(DAT_01ee1b70,"Player is paused, but has no streaming focus.",0);
    }
  }
  else {
    fStack_94 = -3.4028235e+38;
    fStack_90 = -3.4028235e+38;
    fStack_a4 = _DAT_018c4eb0;
    fStack_a0 = _UNK_018c4eb4;
    fStack_9c = _UNK_018c4eb8;
    fStack_98 = _UNK_018c4ebc;
    FUN_0070dac0(&fStack_a4,iVar6 + 0x23c,*(undefined4 *)(iVar6 + 0x1bc));
    if ((((((float)uStack_c8 < fStack_a4) || (uStack_c8._4_4_ < fStack_a0)) ||
         (fStack_c0 < fStack_9c)) ||
        ((fStack_98 < (float)uStack_c8 || (fStack_94 < uStack_c8._4_4_)))) ||
       (fStack_90 < fStack_c0)) {
      *(undefined4 *)(iVar6 + 0x1c0) = 0;
      iVar7 = 0;
    }
    else {
      fVar16 = (float10)FUN_0070ddd0();
      iVar7 = *(int *)(iVar6 + 0x1c0);
      pbStack_20 = (byte *)(float)fVar16;
      iVar13 = (int)fVar16;
      if (iVar13 != iVar7) {
        iVar7 = iVar13;
        if (DAT_01eaf35c != '\0') {
          FUN_01677520(DAT_01eaf35c,"Changed streamed in radius to %d based on server metadata",
                       iVar13);
          iVar7 = (int)(float)pbStack_20;
        }
        *(int *)(iVar6 + 0x1c0) = iVar7;
      }
    }
    if ((iVar7 < *(int *)(iVar6 + 0x1c4)) && (*(int *)(iVar6 + 0x250) != 0)) {
      puVar1 = *(undefined4 **)(iVar6 + 0x24c);
      for (puVar2 = (undefined4 *)*puVar1; uVar4 = uStack_a8, iVar6 = iStack_18, puVar2 != puVar1;
          puVar2 = (undefined4 *)*puVar2) {
        fStack_104 = -3.4028235e+38;
        fStack_100 = -3.4028235e+38;
        fStack_114 = _DAT_018c4eb0;
        fStack_110 = _UNK_018c4eb4;
        fStack_10c = _UNK_018c4eb8;
        fStack_108 = _UNK_018c4ebc;
        FUN_0070dac0(&fStack_114,puVar2 + 2,puVar2[5]);
        if ((((fStack_114 <= (float)uStack_c8) && (fStack_110 <= uStack_c8._4_4_)) &&
            (fStack_10c <= fStack_c0)) &&
           ((((float)uStack_c8 <= fStack_108 && (uStack_c8._4_4_ <= fStack_104)) &&
            (fStack_c0 <= fStack_100)))) {
          fVar16 = (float10)FUN_0070ddd0();
          pbStack_20 = (byte *)(float)fVar16;
          iVar6 = (int)fVar16;
          iVar7 = *(int *)(iStack_18 + 0x1c0);
          if (*(int *)(iStack_18 + 0x1c0) < iVar6) {
            if (DAT_01eaf35c != '\0') {
              FUN_01677520(DAT_01eaf35c,"Changed streamed in radius to %d based on prefetch info",
                           iVar6);
              iVar6 = (int)(float)pbStack_20;
            }
            *(int *)(iStack_18 + 0x1c0) = iVar6;
            iVar7 = iVar6;
          }
          uVar4 = uStack_a8;
          iVar6 = iStack_18;
          if (*(int *)(iStack_18 + 0x1c4) <= iVar7) break;
        }
      }
    }
    if ((*(char *)(iVar6 + 0x17b) != '\0') || (*(char *)(iVar6 + 0x179) != '\0')) {
      FUN_00712370(iStack_40);
    }
  }
  if (DAT_01d5bf28 == '\0') {
    fStack_bc = DAT_018e3f88;
  }
  piVar18 = (int *)(((float)(int)*(short *)(iVar6 + 0x1d4) - fStack_bc) * DAT_018df584);
  piStack_7c = (int *)(float)*(int *)(iVar6 + 0x1c0);
  if ((float)piVar18 <= (float)*(int *)(iVar6 + 0x1c0)) {
    piStack_7c = piVar18;
  }
  iVar7 = (**(code **)(**(int **)(iVar6 + 0x128) + 0xb4))();
  if (iVar7 != 0) {
    FUN_00933e30(piStack_7c);
  }
  piStack_7c = (int *)CONCAT31(piStack_7c._1_3_,*(int *)(iVar6 + 0x1c0) < *(int *)(iVar6 + 0x1c4));
  FUN_00631f50(CONCAT31((int3)((uint)*(int *)(iVar6 + 0x1c0) >> 8),*(undefined *)(iVar6 + 0x178)),
               piStack_7c,pbStack_1c);
  uVar15 = 1;
  FUN_008eb130();
LAB_00712168:
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return uVar15;
}



/* FUNCTION 10021 ; VA 0x00712190 ; FUN_00712190 */

void __fastcall FUN_00712190(int param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = FUN_005c3ac0(*(undefined4 *)(param_1 + 0x128));
  if ((iVar2 != 0) && (*(int *)(iVar2 + 0x1b4) != 0)) {
    if (DAT_01d69070 != '\0') {
      FUN_00bbd5e0(param_1 + 0x134);
      return;
    }
    piVar1 = *(int **)(*(int *)(*(int *)(iVar2 + 0x1b4) + 0x6ac) + 0x154);
    *(int **)(param_1 + 0x140) = piVar1;
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x5c))(param_1 + 0x130);
    }
  }
  return;
}



/* FUNCTION 10022 ; VA 0x007121f0 ; FUN_007121f0 */

bool __fastcall FUN_007121f0(int param_1)

{
  short sVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  short sVar5;
  double *pdVar6;
  int iVar7;
  int iVar8;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (DAT_01eaf914 != 0) {
    *(short *)(param_1 + 0x1d4) = (short)DAT_01eaf914;
  }
  pdVar6 = (double *)FUN_01682800(&uStack_c);
  if ((double)DAT_01d5be9c / DAT_018c0d70 < *pdVar6 - *(double *)(param_1 + 600)) {
    FUN_01682800(&uStack_c);
    *(undefined4 *)(param_1 + 600) = uStack_c;
    *(undefined4 *)(param_1 + 0x25c) = uStack_8;
    if (*(short *)(param_1 + 0x1d4) < 0x7fff) {
      iVar2 = *(int *)(param_1 + 0x128);
      iVar3 = *(int *)(iVar2 + 0xc);
      iVar7 = FUN_005edd10();
      iVar8 = 0;
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
          (uint)*(ushort *)(iVar7 + 0x1da)) {
        iVar8 = iVar2;
      }
      if (iVar8 != 0) {
        cVar4 = FUN_006efbb0();
        if (cVar4 != '\0') {
          sVar1 = *(short *)(param_1 + 0x1d4);
          if ((int)(*(int *)(param_1 + 0x1c8) + (*(int *)(param_1 + 0x1c8) >> 0x1f & 0x3fU)) >> 6 <
              (int)sVar1) {
            *(undefined2 *)(param_1 + 0x1d4) = 0x7fff;
            return sVar1 != 0x7fff;
          }
          *(int *)(param_1 + 0x260) = *(int *)(param_1 + 0x260) + 1;
          sVar5 = (short)*(undefined4 *)(param_1 + 0x260) + sVar1;
          *(short *)(param_1 + 0x1d4) = sVar5;
          return sVar1 != sVar5;
        }
      }
      *(short *)(param_1 + 0x1d4) = *(short *)(param_1 + 0x1d4) + 1;
      return true;
    }
  }
  return false;
}



/* FUNCTION 10023 ; VA 0x00712320 ; FUN_00712320 */

int __fastcall FUN_00712320(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = *(int *)(param_1 + 0x128);
  iVar1 = *(int *)(iVar3 + 0xc);
  iVar2 = FUN_005edd10();
  iVar4 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar4 = iVar3;
  }
  if (0 < *(int *)(iVar4 + 0x3c70)) {
    iVar3 = FUN_007121f0();
    return iVar3;
  }
  return (uint)(byte)(*(ushort *)(iVar2 + 0x1da) >> 8) << 8;
}



/* FUNCTION 10024 ; VA 0x00712370 ; FUN_00712370 */

void __thiscall FUN_00712370(int param_1,int param_2)

{
  int iVar1;
  double *pdVar2;
  int iVar3;
  int iVar4;
  float *pfVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  float fVar9;
  int iStack_38;
  undefined4 uStack_30;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017abd20;
  pvStack_1c = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x128);
  iVar4 = *(int *)(iVar3 + 0xc);
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_005edd10();
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da)) {
    iVar6 = iVar3;
  }
  if (((((DAT_01eaf918 < 1) || (param_2 == 0)) || (*(char *)(param_1 + 0x179) == '\0')) ||
      ((iVar6 != 0 && (*(int *)(iVar6 + 0x3cb8) < 1)))) ||
     ((DAT_01eaf91c != 0 &&
      (pdVar2 = (double *)FUN_01682800(),
      (double)DAT_01eaf91c <= (*pdVar2 - *(double *)(param_1 + 0x270)) * DAT_018c0d70)))) {
    *(undefined4 *)(param_1 + 0x1cc) = 0;
    iVar3 = 0;
  }
  else {
    FUN_0060efa0();
    iVar3 = FUN_00927e40();
    if (((iVar3 != 0) &&
        (iVar3 = *(int *)(iVar3 + 0xc), iVar4 = FUN_00aff8c0(),
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (*(int *)(param_1 + 0x128) != 0)) {
      dVar7 = *(double *)(*(int *)(param_1 + 0x128) + 0x980) / DAT_018c0d70;
      pfVar5 = (float *)FUN_00b07b30();
      dVar8 = (double)(*pfVar5 * *pfVar5 + pfVar5[1] * pfVar5[1] + pfVar5[2] * pfVar5[2]);
      FUN_017267a0();
      fVar9 = (float)dVar8;
      if ((iVar6 != 0) && (*(int *)(iVar6 + 0x3cb8) < DAT_01d5b9d8)) {
        fVar9 = fVar9 * (float)(*(int *)(iVar6 + 0x3cb8) / DAT_01d5b9d8);
      }
      iVar3 = *(int *)(param_1 + 0x1c8) - *(int *)(param_1 + 0x1c4);
      iVar4 = (int)(((double)DAT_01eaf918 / DAT_018ce318) * (double)fVar9 * dVar7);
      if (iVar4 <= iVar3) {
        iVar3 = iVar4;
      }
      *(int *)(param_1 + 0x1cc) = iVar3;
      if (DAT_01ee1b70 != '\0') {
        FUN_01677520(DAT_01ee1b70,
                     "Setting pause exit buffer to %i studs. Ping: %.2f ms. Velocity %.2f",iVar3,
                     *(undefined8 *)(*(int *)(param_1 + 0x128) + 0x980),(double)fVar9);
      }
    }
    iVar3 = *(int *)(param_1 + 0x1cc);
  }
  iVar3 = *(int *)(param_1 + 0x1c4) + iVar3;
  iVar4 = *(int *)(param_1 + 0x1c0);
  if (*(char *)(param_1 + 0x179) == '\0') {
    if (iVar4 < iVar3) {
      if (DAT_01ee1b70 != '\0') {
        FUN_01677490(DAT_01ee1b70,"Entering paused state. Outside is: %i Streamed in radius is: %i",
                     *(undefined *)(param_1 + 0x178),iVar4,0);
      }
      if (*(int *)(param_1 + 0x144) != 0) {
        FUN_00bb8460();
      }
      if (param_2 != 0) {
        FUN_00933a00();
      }
      *(undefined *)(param_1 + 0x179) = 1;
      FUN_01682800();
      *(undefined4 *)(param_1 + 0x270) = uStack_30;
      *(int *)(param_1 + 0x274) = iVar6;
      ExceptionList = pvStack_1c;
      return;
    }
  }
  else if (iVar3 <= iVar4) {
    if (DAT_01ee1b70 != '\0') {
      FUN_016774b0();
    }
    if (*(int *)(param_1 + 0x144) != 0) {
      FUN_00bb8460();
    }
    if (param_2 != 0) {
      FUN_00933a00();
    }
    *(undefined *)(param_1 + 0x179) = 0;
    pdVar2 = (double *)FUN_01682800();
    FUN_00631f20(*pdVar2 - *(double *)(param_1 + 0x270));
    ExceptionList = pvStack_1c;
    return;
  }
  if ((DAT_01ee1b70 != '\0') && (*(char *)(param_1 + 0x179) != '\0')) {
    FUN_01677490(DAT_01ee1b70,
                 "Still in paused state. Outside is: %i Streamed in radius is: %i minimum is %i",
                 *(undefined *)(param_1 + 0x178),iVar4,*(undefined4 *)(param_1 + 0x1c4));
    if ((DAT_01ee1b70 != '\0') &&
       ((FUN_01677490(DAT_01ee1b70,"Character at region %i, %i, %i",*(undefined4 *)(param_1 + 0x20c)
                      ,*(undefined4 *)(param_1 + 0x210),*(undefined4 *)(param_1 + 0x214)),
        DAT_01ee1b70 != '\0' &&
        (FUN_01677490(DAT_01ee1b70,"Center is at region %i, %i, %i",*(undefined4 *)(param_1 + 0x200)
                      ,*(undefined4 *)(param_1 + 0x204),*(undefined4 *)(param_1 + 0x208)),
        DAT_01ee1b70 != '\0')))) {
      FUN_016773b0(DAT_01ee1b70,"Last known server center at region %i, %i, %i with radius %i",
                   *(undefined4 *)(param_1 + 0x23c),*(undefined4 *)(param_1 + 0x240),
                   *(undefined4 *)(param_1 + 0x244),*(undefined4 *)(param_1 + 0x1bc),0);
    }
    iVar3 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
    if (iVar3 == 0) {
      if (DAT_01ee1b70 != '\0') {
        FUN_016774b0();
      }
    }
    else {
      FUN_00927d50();
      uStack_14 = 0;
      if (iStack_38 == 0) {
        if (DAT_01ee1b70 != '\0') {
          FUN_016774b0();
        }
      }
      else if (DAT_01ee1b70 != '\0') {
        FUN_008a2380();
        uStack_14 = CONCAT31(uStack_14._1_3_,1);
        FUN_01677760();
        FUN_005507b0();
        FUN_00550b30();
        ExceptionList = pvStack_1c;
        return;
      }
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 10025 ; VA 0x00712830 ; FUN_00712830 */

void __thiscall FUN_00712830(int param_1,byte *param_2,char param_3)

{
  byte bVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined8 uStack_88;
  int iStack_80;
  undefined8 uStack_7c;
  int iStack_74;
  undefined8 uStack_70;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_54;
  undefined8 *puStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abd38;
  pvStack_10 = ExceptionList;
  bVar1 = *param_2;
  iStack_64 = 1 << (bVar1 & 0x1f);
  iVar6 = *(int *)(param_2 + 8) << (bVar1 & 0x1f);
  iStack_68 = *(int *)(param_2 + 0xc) << (bVar1 & 0x1f);
  iVar5 = *(int *)(param_2 + 4) << (bVar1 & 0x1f);
  iStack_5c = iStack_68 + iStack_64;
  iStack_60 = iVar6 + iStack_64;
  iStack_64 = iStack_64 + iVar5;
  uStack_38 = CONCAT44(iVar6,iVar5);
  uStack_70 = uStack_38;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00a70da0(&uStack_88,4);
  puStack_48 = &uStack_88;
  uStack_44 = uStack_88;
  iStack_3c = iStack_80;
  uStack_54 = uStack_7c;
  iStack_1c = iStack_74;
  do {
    if ((int)uStack_44 == (int)uStack_54) {
      if ((uStack_44._4_4_ == uStack_54._4_4_) && (iStack_3c == iStack_1c)) {
        ExceptionList = pvStack_10;
        return;
      }
    }
    if (param_3 == '\x03') {
      iVar5 = (uint)*(byte *)(param_1 + 0x148) + param_1 + 0x149;
      uStack_38 = uStack_44;
      iStack_30 = iStack_3c;
      uVar3 = FUN_00ca2680(&uStack_38);
      FUN_006e16e0(&param_2,uVar3,&uStack_38,-(uint)(iVar5 != 0) & iVar5 + 1U);
      FUN_005edd10();
      cVar2 = FUN_006ee7c0(&uStack_38);
      if (((param_2 == (byte *)0x0) || (param_2[0x14] == 0)) && (cVar2 != '\0')) {
        FUN_0070f350(&uStack_38);
      }
    }
    else {
      uStack_2c = uStack_44;
      iStack_24 = iStack_3c;
      FUN_005edd10();
      cVar2 = FUN_006ee7c0(&uStack_2c);
      param_1 = iStack_14;
      iVar5 = iStack_14 + 0x149 + (uint)*(byte *)(iStack_14 + 0x148);
      uVar3 = FUN_00ca2680(&uStack_2c);
      FUN_006e16e0(&iStack_18,uVar3,&uStack_2c,-(uint)(iVar5 != 0) & iVar5 + 1U);
      if ((cVar2 == '\0') && ((iStack_18 == 0 || (*(char *)(iStack_18 + 0x14) == '\0')))) {
        uVar3 = FUN_01675290(DAT_01eaf994);
        uStack_8 = 2;
        uStack_20 = uVar3;
        piVar4 = (int *)FUN_0070a8f0(&uStack_2c);
        *piVar4 = *piVar4 + 1;
        piVar4 = (int *)FUN_0070a8f0((int)&uStack_2c + 4);
        *piVar4 = *piVar4 + 1;
        piVar4 = (int *)FUN_0070a8f0(&iStack_24);
        *piVar4 = *piVar4 + 1;
        uStack_8 = 3;
        FUN_01675290(uVar3);
        uStack_8 = 0xffffffff;
      }
    }
    FUN_00a6e100();
  } while( true );
}



/* FUNCTION 10026 ; VA 0x00712ac0 ; FUN_00712ac0 */

undefined4 __thiscall FUN_00712ac0(int param_1,undefined4 param_2)

{
  FUN_006b2070(param_2,0xf);
  FUN_006b92d0(param_2,param_1 + 0x30);
  return 1;
}



/* FUNCTION 10027 ; VA 0x00712af0 ; FUN_00712af0 */

undefined4 __thiscall FUN_00712af0(int param_1,uint param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  undefined auStack_40 [12];
  int iStack_34;
  int iStack_2c;
  undefined auStack_18 [4];
  char acStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7e48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006b2070(param_2,0xe);
  FUN_006ae3b0(param_1 + 0x30);
  uVar3 = *(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c) >> 3;
  param_2 = uVar3;
  FUN_006a5c10(&param_2,auStack_18,4);
  FUN_006ad5e0(auStack_18,4);
  if (((int)DAT_01d5be64 < 0) || (uVar3 <= DAT_01d5be64)) {
    acStack_14[0] = '\0';
  }
  else {
    acStack_14[0] = '\x01';
  }
  param_2._3_1_ = acStack_14[0];
  FUN_006ad5e0(acStack_14,1);
  if (param_2._3_1_ == '\0') {
    uVar3 = 0;
    if (*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c) >> 3 != 0) {
      do {
        FUN_006b92d0(uVar1,*(int *)(param_1 + 0x3c) + uVar3 * 8);
        uVar3 = uVar3 + 1;
      } while (uVar3 < (uint)(*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c) >> 3));
    }
  }
  else {
    FUN_006ab530();
    uVar3 = 0;
    uStack_8 = 0;
    if (*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c) >> 3 != 0) {
      do {
        FUN_006b92d0(auStack_40,*(int *)(param_1 + 0x3c) + uVar3 * 8);
        uVar3 = uVar3 + 1;
      } while (uVar3 < (uint)(*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c) >> 3));
    }
    FUN_00619a10(auStack_40,uVar1,DAT_01d5be5c);
    if (iStack_34 != 0) {
      uVar3 = iStack_2c - iStack_34;
      iVar2 = iStack_34;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iStack_34 + -4);
        uVar3 = uVar3 + 0x23;
        if (0x1f < (iStack_34 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 10028 ; VA 0x00712c50 ; FUN_00712c50 */

void FUN_00712c50(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar1 = *param_2;
  fVar2 = param_2[1];
  fVar5 = fVar1 + *param_3;
  fVar4 = param_3[1] + fVar2;
  fVar3 = fVar5;
  if (fVar1 <= fVar5) {
    fVar3 = fVar1;
  }
  param_1[3] = 0.0;
  *param_1 = fVar3;
  fVar3 = fVar2;
  if (fVar4 < fVar2) {
    fVar3 = fVar4;
  }
  param_1[1] = fVar3;
  if (fVar5 <= fVar1) {
    fVar5 = fVar1;
  }
  param_1[2] = fVar5;
  if (fVar4 <= fVar2) {
    fVar4 = fVar2;
  }
  param_1[3] = fVar4;
  return;
}



/* FUNCTION 10029 ; VA 0x00712cc0 ; FUN_00712cc0 */

void FUN_00712cc0(float *param_1,float param_2,float param_3,float param_4,float param_5)

{
  float fVar1;
  
  fVar1 = param_4;
  if (param_2 <= param_4) {
    fVar1 = param_2;
  }
  param_1[3] = 0.0;
  *param_1 = fVar1;
  fVar1 = param_3;
  if (param_5 < param_3) {
    fVar1 = param_5;
  }
  param_1[1] = fVar1;
  if (param_4 <= param_2) {
    param_4 = param_2;
  }
  param_1[2] = param_4;
  if (param_5 <= param_3) {
    param_5 = param_3;
  }
  param_1[3] = param_5;
  return;
}



/* FUNCTION 10030 ; VA 0x00712d20 ; FUN_00712d20 */

int FUN_00712d20(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ea8c74,&LAB_005c2480);
  uVar3 = FUN_005c37d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009d6050();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 10031 ; VA 0x00712de0 ; FUN_00712de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00712de0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::LightingTechnology>::vftable;
  _DAT_01ee46c8 = _DAT_01ee46c8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 10032 ; VA 0x00712e10 ; FUN_00712e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00712e10(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_00712f70();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eafa94) {
      FUN_016f3809(&DAT_01eafa94);
      if (DAT_01eafa94 == -1) {
        _DAT_01eafa88 = FUN_005c65e0;
        _DAT_01eafa8c = FUN_005c65e0;
        _DAT_01eafa90 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eafa94);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eafa88) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eafa88;
  }
  return;
}



/* FUNCTION 10033 ; VA 0x00712ed0 ; FUN_00712ed0 */

void FUN_00712ed0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00712f70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 10034 ; VA 0x00712f10 ; FUN_00712f10 */

int __fastcall FUN_00712f10(int param_1)

{
  return param_1 + 0x6c;
}



/* FUNCTION 10035 ; VA 0x00712f20 ; FUN_00712f20 */

undefined4 __fastcall FUN_00712f20(int param_1)

{
  return *(undefined4 *)(param_1 + 0xcc);
}



/* FUNCTION 10036 ; VA 0x00712f30 ; FUN_00712f30 */

void FUN_00712f30(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00712f70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 10037 ; VA 0x00712f70 ; FUN_00712f70 */

undefined * FUN_00712f70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abd5c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafa84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eafa84);
    if (DAT_01eafa84 == -1) {
      uStack_8 = 0;
      FUN_009d69d0();
      FUN_016f3654(&LAB_0187ea60);
      FUN_016f37bf(&DAT_01eafa84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eafa20;
}



/* FUNCTION 10038 ; VA 0x00713000 ; FUN_00713000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00713000(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafa94) {
    FUN_016f3809(&DAT_01eafa94);
    if (DAT_01eafa94 == -1) {
      _DAT_01eafa88 = FUN_005c65e0;
      _DAT_01eafa8c = FUN_005c65e0;
      _DAT_01eafa90 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eafa94);
    }
  }
  return &DAT_01eafa88;
}



/* FUNCTION 10039 ; VA 0x00713070 ; FUN_00713070 */

int FUN_00713070(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00575bc0();
  *(undefined2 *)(iVar4 + 0xc) = 0;
  *(undefined4 *)(iVar4 + 0x10) = *param_1;
  uVar1 = param_1[2];
  uVar2 = param_1[3];
  uVar3 = param_1[4];
  *(undefined4 *)(iVar4 + 0x14) = param_1[1];
  *(undefined4 *)(iVar4 + 0x18) = uVar1;
  *(undefined4 *)(iVar4 + 0x1c) = uVar2;
  *(undefined4 *)(iVar4 + 0x20) = uVar3;
  *(undefined8 *)(iVar4 + 0x24) = *(undefined8 *)(param_1 + 5);
  *(undefined4 *)(iVar4 + 0x2c) = param_1[7];
  return iVar4;
}



/* FUNCTION 10040 ; VA 0x007130b0 ; FUN_007130b0 */

void __thiscall
FUN_007130b0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_00576e30(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00713162:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00713162;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 10041 ; VA 0x00713210 ; FUN_00713210 */

void __thiscall
FUN_00713210(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abd70;
  pvStack_10 = ExceptionList;
  cVar4 = (char)param_3;
  cVar3 = '\x01';
  uStack_8 = 0;
  piVar6 = (int *)((int *)*param_1)[1];
  piVar7 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)piVar6 + 0xd) == '\0') {
    if (cVar4 == '\0') {
      cVar3 = FUN_00a6ce90(piVar6 + 4);
    }
    else {
      cVar3 = FUN_00a6ce90(param_4);
      cVar3 = cVar3 == '\0';
    }
    piVar7 = piVar6;
    if (cVar3 == '\0') {
      piVar6 = (int *)piVar6[2];
    }
    else {
      piVar6 = (int *)*piVar6;
    }
  }
  piVar6 = piVar7;
  if (cVar3 != '\0') {
    if (piVar7 == *(int **)*param_1) {
      cVar3 = '\x01';
      goto LAB_007132a6;
    }
    if (*(char *)((int)piVar7 + 0xd) == '\0') {
      piVar6 = (int *)*piVar7;
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar4 = *(char *)(piVar6[2] + 0xd);
        piVar1 = (int *)piVar6[2];
        while (cVar4 == '\0') {
          cVar4 = *(char *)(piVar1[2] + 0xd);
          piVar6 = piVar1;
          piVar1 = (int *)piVar1[2];
        }
      }
      else {
        cVar4 = *(char *)(piVar7[1] + 0xd);
        piVar1 = (int *)piVar7[1];
        piVar6 = piVar7;
        while ((piVar2 = piVar1, cVar4 == '\0' && (param_3 = piVar2, piVar6 == (int *)*piVar2))) {
          cVar4 = *(char *)(piVar2[1] + 0xd);
          piVar1 = (int *)piVar2[1];
          piVar6 = piVar2;
        }
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          piVar6 = piVar2;
        }
      }
    }
    else {
      piVar6 = (int *)piVar7[2];
    }
  }
  cVar4 = FUN_00a6ce90(param_4);
  if (cVar4 == '\0') {
    FUN_01674ea0(param_5,0x30);
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_007132a6:
  puVar5 = (undefined4 *)FUN_007130b0(&param_3,cVar3,piVar7,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10042 ; VA 0x00713379 ; Catch_All@00713379 */

void Catch_All_00713379(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10043 ; VA 0x00713390 ; FUN_00713390 */

undefined4 * __thiscall FUN_00713390(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abdac;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a360a0("Distributed Physics Ownership",1,0,param_2,param_3,4);
  *param_1 = RBX::Network::NetworkOwnerJob::vftable;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x4a] = param_2;
  param_1[0x4b] = param_3;
  uStack_8._0_1_ = 2;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  uVar3 = FUN_00575b10();
  param_1[0x4c] = uVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a361f0();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10044 ; VA 0x007134a0 ; FUN_007134a0 */

void __fastcall FUN_007134a0(undefined4 *param_1)

{
  FUN_00713560();
  FUN_01674ea0(*param_1,0x30);
  return;
}



/* FUNCTION 10045 ; VA 0x007134c0 ; FUN_007134c0 */

int __thiscall FUN_007134c0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  FUN_00713560();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x130),0x30);
  piVar1 = *(int **)(param_1 + 300);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 10046 ; VA 0x00713520 ; FUN_00713520 */

void FUN_00713520(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00713520(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_01674ea0(param_1,0x30);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 10047 ; VA 0x00713560 ; FUN_00713560 */

void __fastcall FUN_00713560(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar3 = iVar1;
  piVar4 = *(int **)(iVar1 + 4);
  ExceptionList = &pvStack_10;
  if (*(char *)((int)*(int **)(iVar1 + 4) + 0xd) == '\0') {
    do {
      FUN_00713520(piVar4[2]);
      piVar2 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x30);
      piVar4 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar3 = *param_1;
  }
  *(int *)(iVar3 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10048 ; VA 0x007135e0 ; FUN_007135e0 */

undefined4 FUN_007135e0(int param_1,int param_2)

{
  float fVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  double dVar6;
  uint uVar7;
  uint uVar8;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar2 = *(int *)(param_2 + 0x28);
  iVar4 = FUN_00c156f0();
  if (iVar2 == iVar4) {
    return 1;
  }
  uVar5 = FUN_00ca1730(*(undefined4 *)(param_1 + 0xa8));
  if ((DAT_01d5c070 != '\0') && (cVar3 = FUN_00ca0f40(), cVar3 == '\0')) {
    uVar5 = FUN_00c15700();
    FUN_00b06640(uVar5);
    FUN_008b3b00();
    fVar1 = *(float *)(param_2 + 0x20);
    dVar6 = (double)(fStack_1c - *(float *)(param_2 + 0x14));
    uVar7 = (uint)DAT_018c0da0;
    uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    if ((((float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,SUB84(dVar6,0) & uVar7) <
          fVar1) &&
        (((dVar6 = (double)(fStack_18 - *(float *)(param_2 + 0x18)),
          (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,SUB84(dVar6,0) & uVar7) <
          fVar1 && (dVar6 = (double)(fStack_14 - *(float *)(param_2 + 0x1c)),
                   (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,
                                           SUB84(dVar6,0) & uVar7) < fVar1)) &&
         (dVar6 = (double)(fStack_10 - *(float *)(param_2 + 0x14)),
         (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,SUB84(dVar6,0) & uVar7) <
         fVar1)))) &&
       ((dVar6 = (double)(fStack_c - *(float *)(param_2 + 0x18)),
        (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,SUB84(dVar6,0) & uVar7) <
        fVar1 && (dVar6 = (double)(fStack_8 - *(float *)(param_2 + 0x1c)),
                 (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,
                                         SUB84(dVar6,0) & uVar7) < fVar1)))) {
      return 1;
    }
    return 0;
  }
  uVar5 = FUN_00bb6fb0(uVar5,*(undefined8 *)(param_2 + 0x14),*(undefined4 *)(param_2 + 0x1c),
                       *(undefined4 *)(param_2 + 0x20));
  return uVar5;
}



/* FUNCTION 10049 ; VA 0x00713750 ; FUN_00713750 */

void __thiscall FUN_00713750(int *param_1,int *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)puVar2[1];
  puVar4 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      cVar1 = FUN_00a6ce90(param_3);
      if (cVar1 == '\0') {
        puVar2 = (undefined4 *)*puVar3;
        puVar4 = puVar3;
      }
      else {
        puVar2 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    puVar2 = (undefined4 *)*param_1;
  }
  if ((puVar4 != puVar2) && (cVar1 = FUN_00a6ce90(puVar4 + 4), cVar1 == '\0')) {
    *param_2 = (int)puVar4;
    return;
  }
  *param_2 = *param_1;
  return;
}



/* FUNCTION 10050 ; VA 0x007137d0 ; FUN_007137d0 */

void __fastcall FUN_007137d0(int param_1)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_00713750(&iStack_8,&stack0x00000004);
  if (iStack_8 != *(int *)(param_1 + 0x130)) {
    *(undefined *)(iStack_8 + 0x2c) = 1;
  }
  return;
}



/* FUNCTION 10051 ; VA 0x00713800 ; FUN_00713800 */

void FUN_00713800(void)

{
  char cVar1;
  float fVar2;
  
  FUN_00b07ca0();
  cVar1 = FUN_005e0cd0();
  if (cVar1 != '\0') {
    FUN_00b0df50();
    cVar1 = FUN_00a33d60();
    fVar2 = DAT_018e452c;
    if (cVar1 == '\0') {
      fVar2 = (float)DAT_01d5c030 / DAT_018ce324;
    }
    FUN_00b0c5a0((double)fVar2);
  }
  return;
}



/* FUNCTION 10052 ; VA 0x00713880 ; FUN_00713880 */

undefined4 __fastcall FUN_00713880(int param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined3 uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piVar9;
  int iVar10;
  int iVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  int *piStack_34;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abdf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar6 = FUN_01675290(DAT_01ef3710);
  iVar10 = *(int *)(param_1 + 300);
  iVar11 = 0;
  piStack_34 = (int *)0x0;
  if (iVar10 != 0) {
    piVar8 = (int *)(iVar10 + 4);
    iVar10 = *(int *)(iVar10 + 4);
    while (iVar10 != 0) {
      LOCK();
      iVar11 = *piVar8;
      if (iVar10 == iVar11) {
        *piVar8 = iVar10 + 1;
        iVar11 = iVar10;
      }
      UNLOCK();
      if (iVar11 == iVar10) {
        iVar11 = *(int *)(param_1 + 0x128);
        piStack_34 = *(int **)(param_1 + 300);
        goto LAB_007138fd;
      }
      iVar10 = *piVar8;
    }
    iVar11 = 0;
  }
LAB_007138fd:
  uStack_8._1_3_ = 0;
  uVar4 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (iVar11 == 0) {
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_34[1] + -1;
      piStack_34[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        uStack_8._1_3_ = uVar4;
        (**(code **)*piStack_34)();
        LOCK();
        piVar8 = piStack_34 + 2;
        iVar10 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    uVar7 = 0;
  }
  else {
    FUN_008e9840(iVar11 + 0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (iVar11 + 0xc != 0) {
      FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
      uVar7 = FUN_00560e40();
      piVar8 = (int *)FUN_008aa140(uVar7);
      if (*piVar8 == 0) {
        uVar7 = FUN_005ee510();
        piVar9 = (int *)FUN_008a9ba0(auStack_28,uVar7);
        iVar10 = *piVar9;
        iVar2 = piVar9[1];
        *piVar9 = 0;
        piVar9[1] = 0;
        *piVar8 = iVar10;
        piVar9 = (int *)piVar8[1];
        piVar8[1] = iVar2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar10 = piVar9[1] + -1;
          piVar9[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar10 = piVar9[2] + -1;
            piVar9[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = piStack_24;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_24[1] + -1;
          piStack_24[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar3 = piVar9 + 2;
            iVar10 = *piVar3 + -1;
            *piVar3 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      if (*piVar8 != 0) {
        FUN_00714130(*piVar8);
        iStack_1c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
        if ((*(int *)(iStack_1c + 0x34) < DAT_01eafad0) &&
           (FUN_016f3809(&DAT_01eafad0), DAT_01eafad0 == -1)) {
          uStack_8._0_1_ = 3;
          uVar12 = FUN_0152dab0("GameplayNet","updateNOUOwners",0xffffffff);
          DAT_01eafacc = (undefined4)((ulonglong)uVar12 >> 0x20);
          DAT_01eafac8 = (int *)uVar12;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_016f37bf(&DAT_01eafad0);
        }
        piStack_24 = DAT_01eafac8;
        uStack_20 = DAT_01eafacc;
        uVar12 = FUN_0152d930(DAT_01eafac8,DAT_01eafacc);
        iVar10 = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        piVar8 = (int *)(*(int *)(*(int *)(*(int *)(iVar11 + 0x1b8) + 0x1b4) + 0x6d0) + 0x40);
        iStack_18 = 10;
        do {
          piVar9 = *(int **)*piVar8;
          if (piVar9 != (int *)*piVar8) {
            do {
              uVar7 = FUN_00ca1550();
              uVar7 = FUN_00b06640(uVar7);
              FUN_00713c40(uVar7);
              piVar3 = (int *)piVar9[2];
              iVar10 = iVar10 + 1;
              if (*(char *)((int)piVar3 + 0xd) == '\0') {
                cVar1 = *(char *)(*piVar3 + 0xd);
                piVar9 = piVar3;
                piVar3 = (int *)*piVar3;
                while (cVar1 == '\0') {
                  cVar1 = *(char *)(*piVar3 + 0xd);
                  piVar9 = piVar3;
                  piVar3 = (int *)*piVar3;
                }
              }
              else {
                cVar1 = *(char *)(piVar9[1] + 0xd);
                piVar5 = (int *)piVar9[1];
                piVar3 = piVar9;
                while ((piVar9 = piVar5, cVar1 == '\0' && (piVar3 == (int *)piVar9[2]))) {
                  cVar1 = *(char *)(piVar9[1] + 0xd);
                  piVar5 = (int *)piVar9[1];
                  piVar3 = piVar9;
                }
              }
            } while (piVar9 != (int *)*piVar8);
          }
          piVar8 = piVar8 + 2;
          iStack_18 = iStack_18 + -1;
        } while (iStack_18 != 0);
        if ((*(int *)(iStack_1c + 0x34) < DAT_01eafae0) &&
           (FUN_016f3809(&DAT_01eafae0), DAT_01eafae0 == -1)) {
          uStack_8._0_1_ = 5;
          uVar13 = FUN_0152da50("GameplayNet");
          DAT_01eafadc = (undefined4)((ulonglong)uVar13 >> 0x20);
          DAT_01eafad8 = (undefined4)uVar13;
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_016f37bf(&DAT_01eafae0);
        }
        FUN_0152d760(DAT_01eafad8,DAT_01eafadc,"NOU Count: %d",iVar10);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        FUN_0152dda0(piStack_24,uStack_20,uVar12);
      }
    }
    FUN_008eb130();
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_34[1] + -1;
      piStack_34[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar8 = piStack_34 + 2;
        iVar10 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    uVar7 = 1;
  }
  uStack_8 = 8;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 10053 ; VA 0x00713c40 ; FUN_00713c40 */

int * __thiscall FUN_00713c40(int param_1,int param_2)

{
  bool bVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  float10 fVar9;
  float fVar10;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abe29;
  pvStack_10 = ExceptionList;
  piStack_20 = (int *)0x0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00b07ca0();
  iVar4 = FUN_00b07f40();
  if (iVar4 == 1) {
    FUN_00713750(&piStack_24,auStack_1c);
    piVar5 = piStack_24;
    if (piStack_24 == *(int **)(param_1 + 0x130)) {
      piVar5 = (int *)FUN_0097c020(auStack_34,auStack_1c,param_2);
      piStack_20 = (int *)0x1;
      uStack_8 = 0;
      if (*piVar5 != 0) goto LAB_00713ce5;
      piStack_24 = (int *)0x1;
      piVar5 = (int *)FUN_005e0cd0();
      cStack_11 = '\x01';
      if ((char)piVar5 == '\0') goto LAB_00713ce5;
    }
    else {
LAB_00713ce5:
      cStack_11 = '\0';
    }
    uStack_8 = 0xffffffff;
    if ((((uint)piStack_20 & 1) != 0) && (piStack_30 != (int *)0x0)) {
      LOCK();
      piVar8 = piStack_30 + 1;
      iVar4 = *piVar8;
      piVar5 = (int *)*piVar8;
      *piVar8 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        piVar5 = (int *)(**(code **)*piStack_30)();
        LOCK();
        piVar8 = piStack_30 + 2;
        iVar4 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          piVar5 = (int *)(**(code **)(*piStack_30 + 4))();
        }
      }
    }
    if (cStack_11 == '\0') {
      ExceptionList = pvStack_10;
      return piVar5;
    }
    FUN_00713800(param_2,1);
    FUN_00b0e450();
    param_1 = iStack_18;
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadcf4) &&
     (FUN_016f3809(), DAT_01eadcf4 == -1)) {
    DAT_01eadcf0 = (int *)0xffffffff;
    FUN_016f37bf();
  }
  piStack_24 = DAT_01eadcf0;
  cVar3 = FUN_00a33d60();
  if (cVar3 != '\0') {
LAB_00713fbf:
    if (((*(int *)(param_2 + 0x34) != 0) &&
        (iVar4 = *(int *)(*(int *)(param_2 + 0x34) + 0xc), iVar6 = FUN_00b63e30(),
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da))) &&
       (piStack_2c = (int *)FUN_00980070(), piStack_2c != (int *)0x0)) {
      piVar5 = *(int **)(iStack_18 + 0x130);
      piVar8 = (int *)*piVar5;
      piVar7 = piVar5;
      while (piVar8 != piVar7) {
        FUN_00927d30();
        cVar3 = FUN_00a33d60();
        if (cVar3 != '\0') {
          piVar7 = *(int **)(iStack_18 + 0x130);
          piVar5 = piVar8;
          break;
        }
        FUN_00551320();
        piVar7 = *(int **)(iStack_18 + 0x130);
      }
      if (piVar5 != piVar7) {
        *(int *)(piVar5[9] + 0x3bb4) = *(int *)(piVar5[9] + 0x3bb4) + 1;
      }
    }
    FUN_00b07ca0();
    piVar5 = (int *)FUN_005e0cd0();
    if ((char)piVar5 != '\0') {
      FUN_00b0df50();
      piStack_2c = (int *)0x1;
      cVar3 = FUN_00a33d60();
      fVar10 = DAT_018e452c;
      if (cVar3 == '\0') {
        fVar10 = (float)DAT_01d5c030 / DAT_018ce324;
      }
      piVar5 = (int *)FUN_00b0c5a0((double)fVar10);
    }
    ExceptionList = pvStack_10;
    return piVar5;
  }
  piStack_24 = (int *)0x2;
  cVar3 = FUN_00a33d60();
  if (cVar3 != '\0') goto LAB_00713fbf;
  piVar5 = (int *)FUN_00713750(&piStack_30,auStack_1c);
  piVar5 = (int *)*piVar5;
  piStack_2c = piVar5;
  if ((((DAT_01d5c068 == '\0') && (piVar5 != *(int **)(param_1 + 0x130))) &&
      (*(char *)(piVar5 + 0xb) == '\0')) && (cVar3 = FUN_00b09530(), cVar3 != '\0')) {
    if ((*(char *)(piVar5[9] + 0x37f8) == '\0') ||
       (cVar3 = FUN_007135e0(param_2,piVar5), cVar3 != '\0')) goto LAB_00713e8b;
    FUN_00713750(&piStack_24,auStack_1c);
    *(undefined *)(piStack_24 + 0xb) = 1;
  }
  iStack_28 = FUN_00b077e0();
  iVar4 = iStack_18;
  piVar8 = *(int **)(param_1 + 0x130);
  piStack_20 = DAT_018e4530;
  iStack_28 = iStack_28 + 0x24;
  piVar5 = (int *)*piVar8;
  if (piVar5 != piVar8) {
    do {
      fVar9 = (float10)FUN_00a73550(iStack_28,piVar5 + 5);
      piStack_24 = (int *)(float)fVar9;
      if (((float)piStack_24 < (float)piStack_20) &&
         (piVar8 = piVar5, piStack_20 = piStack_24,
         NAN((float)piStack_24) != ((float)piStack_24 == 0.0))) break;
      piVar7 = (int *)piVar5[2];
      if (*(char *)((int)piVar7 + 0xd) == '\0') {
        cVar3 = *(char *)(*piVar7 + 0xd);
        piVar5 = piVar7;
        piVar7 = (int *)*piVar7;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*piVar7 + 0xd);
          piVar5 = piVar7;
          piVar7 = (int *)*piVar7;
        }
      }
      else {
        cVar3 = *(char *)(piVar5[1] + 0xd);
        piVar2 = (int *)piVar5[1];
        piVar7 = piVar5;
        while ((piVar5 = piVar2, cVar3 == '\0' && (piVar7 == (int *)piVar5[2]))) {
          cVar3 = *(char *)(piVar5[1] + 0xd);
          piVar2 = (int *)piVar5[1];
          piVar7 = piVar5;
        }
      }
    } while (piVar5 != *(int **)(iVar4 + 0x130));
  }
  piVar5 = piStack_2c;
  if (piStack_2c == *(int **)(iStack_18 + 0x130)) {
LAB_00713eee:
    cStack_11 = '\0';
  }
  else {
    cVar3 = FUN_007135e0(param_2,piStack_2c);
    cStack_11 = '\x01';
    if (cVar3 == '\0') goto LAB_00713eee;
  }
  if ((((piVar8 == piVar5) || (piVar8 == *(int **)(iStack_18 + 0x130))) ||
      (cVar3 = FUN_00b09c10(), cVar3 == '\0')) ||
     (cVar3 = FUN_007135e0(param_2,piVar8), cVar3 == '\0')) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  if (cStack_11 == '\0') {
    if (!bVar1) {
      piVar5 = (int *)FUN_00713800(param_2,1);
      ExceptionList = pvStack_10;
      return piVar5;
    }
LAB_00713f75:
    FUN_00713800(param_2,piVar8[4]);
    piVar8 = (int *)piVar8[9];
    piVar5 = piVar8 + 0xeed;
    *piVar5 = *piVar5 + 1;
    ExceptionList = pvStack_10;
    return piVar8;
  }
  if ((bVar1) && (iVar4 = piVar5[10], iVar6 = FUN_00c156f0(), iVar4 != iVar6)) {
    iVar4 = FUN_00b077e0();
    cVar3 = FUN_00a73480(iVar4 + 0x24,piVar5 + 5,piVar8 + 5,0x3f800000);
    if (cVar3 != '\0') goto LAB_00713f75;
  }
LAB_00713e8b:
  piVar8 = (int *)piVar5[9];
  piVar5 = piVar8 + 0xeed;
  *piVar5 = *piVar5 + 1;
  ExceptionList = pvStack_10;
  return piVar8;
}



/* FUNCTION 10054 ; VA 0x00714130 ; FUN_00714130 */

void FUN_00714130(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined8 uVar7;
  int iStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 uStack_70;
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abe60;
  pvStack_10 = ExceptionList;
  iStack_1c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iStack_1c + 0x34) < DAT_01eafaf0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eafaf0);
    if (DAT_01eafaf0 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("GameplayNet","UpdatePlayerLocations",0xffffffff);
      DAT_01eafaec = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eafae8 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eafaf0);
    }
  }
  uStack_24 = DAT_01eafae8;
  uStack_3c = DAT_01eafae8;
  uStack_20 = DAT_01eafaec;
  uStack_38 = DAT_01eafaec;
  uStack_34 = FUN_0152d930(DAT_01eafae8,DAT_01eafaec);
  uStack_8 = 1;
  FUN_00713560();
  uVar6 = 0;
  uStack_14 = 0;
  iVar2 = FUN_005d6c30();
  if (iVar2 != 0) {
    do {
      piVar1 = *(int **)(**(int **)(param_1 + 0x2c) + uVar6 * 8);
      if (piVar1 != (int *)0x0) {
        iVar2 = piVar1[3];
        iVar3 = FUN_005ee350();
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da)) {
          uStack_4c = 0;
          uStack_48 = 0;
          uStack_44 = 0;
          uStack_40 = 0;
          iVar2 = FUN_00680cc0(&uStack_4c);
          if (iVar2 != 0) {
            uVar5 = 0;
            iVar2 = (**(code **)(*piVar1 + 0xb4))();
            if ((iVar2 != 0) && (*(int **)(iVar2 + 100) != (int *)0x0)) {
              iVar2 = (**(code **)(**(int **)(iVar2 + 100) + 0xa8))();
              if (iVar2 != 0) {
                uVar5 = FUN_00c156f0();
              }
            }
            iStack_88 = piVar1[0x25];
            uStack_64 = uStack_48;
            uStack_68 = uStack_4c;
            uStack_60 = uStack_44;
            uStack_5c = uStack_40;
            uStack_50 = uStack_50 & 0xffffff00;
            uStack_6c = uStack_50;
            uStack_84 = uStack_4c;
            uStack_80 = uStack_48;
            uStack_7c = uStack_44;
            uStack_78 = uStack_40;
            piStack_74 = piVar1;
            uStack_70 = uVar5;
            piStack_58 = piVar1;
            uStack_54 = uVar5;
            iVar2 = FUN_00713070(&iStack_88);
            FUN_00713210(auStack_2c,0,iVar2 + 0x10,iVar2);
            piVar1[0xeed] = 0;
          }
        }
      }
      uVar6 = uStack_14 + 1;
      uStack_14 = uVar6;
      uVar4 = FUN_005d6c30();
    } while (uVar6 < uVar4);
  }
  if (*(int *)(iStack_1c + 0x34) < DAT_01eafb00) {
    FUN_016f3809(&DAT_01eafb00);
    if (DAT_01eafb00 == -1) {
      uStack_8._0_1_ = 2;
      uVar7 = FUN_0152da50("GameplayNet");
      DAT_01eafafc = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eafaf8 = (undefined4)uVar7;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eafb00);
    }
  }
  FUN_0152d760(DAT_01eafaf8,DAT_01eafafc,"Num Clients: %zu",*(undefined4 *)(iStack_18 + 0x134));
  uStack_8 = 3;
  FUN_0152dda0(uStack_24,uStack_20,uStack_34);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10055 ; VA 0x007143f0 ; FUN_007143f0 */

int * __thiscall
FUN_007143f0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined auStack_3c [40];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abe98;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_0054ef60(&param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar3 = FUN_00715210(auStack_3c,in_stack_00000028,param_2,param_3,param_4);
  uStack_8._0_1_ = 2;
  iVar4 = FUN_00715490(uVar3);
  *param_1 = iVar4;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_006511a0();
  cVar2 = FUN_0168a8f0();
  if (cVar2 != '\0') {
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar4 = param_4[1] + -1;
      param_4[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar1 = param_4 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_4 + 4))();
        }
      }
    }
    if (0xf < in_stack_00000024) {
      uVar5 = in_stack_00000024 + 1;
      iVar4 = param_5;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(param_5 + -4);
        uVar5 = in_stack_00000024 + 0x24;
        if (0x1f < (param_5 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar3 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar3);
}



/* FUNCTION 10056 ; VA 0x00714520 ; FUN_00714520 */

int FUN_00714520(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abeb0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575ba0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  *(undefined4 *)(iVar1 + 0x28) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 10057 ; VA 0x00714584 ; Catch_All@00714584 */

void Catch_All_00714584(void)

{
  int unaff_EBP;
  
  FUN_00576e10(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10058 ; VA 0x007145a0 ; FUN_007145a0 */

void FUN_007145a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_0068a6a0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  *(undefined4 *)(iVar1 + 0x10) = param_3[2];
  return;
}



/* FUNCTION 10059 ; VA 0x007145d0 ; FUN_007145d0 */

int __thiscall FUN_007145d0(int *param_1,int param_2,undefined *param_3)

{
  uint uVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  
  iVar2 = *param_1;
  iVar6 = param_2 - iVar2;
  if (param_1[1] - iVar2 == 0x7fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = (param_1[1] - iVar2) + 1;
  uVar4 = param_1[2] - iVar2;
  uVar5 = uVar1;
  if ((uVar4 <= 0x7fffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  iVar2 = FUN_00554060(uVar5);
  puVar3 = (undefined *)(iVar2 + iVar6);
  *puVar3 = *param_3;
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar2,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar2,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar3 + 1,param_2,param_1[1] - param_2);
  }
  FUN_00575c00(iVar2,uVar1,uVar5);
  return *param_1 + iVar6;
}



/* FUNCTION 10060 ; VA 0x007146d0 ; FUN_007146d0 */

int __thiscall FUN_007146d0(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0x2c;
  if (iVar2 == 0x5d1745d) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0x2c;
  uVar7 = uVar1;
  if ((uVar3 <= 0x5d1745d - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  iVar4 = FUN_00716c50(uVar7);
  iVar5 = ((param_2 - iVar5) / 0x2c) * 0x2c;
  iVar6 = iVar5 + iVar4;
  FUN_007153c0(param_1,iVar6,param_3);
  if (param_2 == param_1[1]) {
    FUN_00716390(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_00716340(*param_1,param_2,iVar4);
    FUN_00716340(param_2,param_1[1],iVar6 + 0x2c);
  }
  FUN_00716090(iVar4,iVar2 + 1,uVar7);
  return *param_1 + iVar5;
}



/* FUNCTION 10061 ; VA 0x007146df ; FUN_007146df */

int __fastcall FUN_007146df(int *param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  int in_EAX;
  int iVar3;
  int iVar4;
  int iVar5;
  int unaff_EBP;
  uint uVar6;
  
  iVar3 = *param_1;
  iVar4 = param_1[1];
  iVar5 = (int)((ulonglong)((longlong)in_EAX * (longlong)(param_2 - iVar3)) >> 0x20);
  *(int *)(unaff_EBP + -4) = (iVar5 >> 3) - (iVar5 >> 0x1f);
  iVar4 = (iVar4 - iVar3) / 0x2c;
  *(int *)(unaff_EBP + -8) = iVar4;
  if (iVar4 == 0x5d1745d) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar2 = (param_1[2] - iVar3) / 0x2c;
  uVar6 = uVar1;
  if ((uVar2 <= 0x5d1745d - (uVar2 >> 1)) && (uVar6 = (uVar2 >> 1) + uVar2, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  iVar3 = FUN_00716c50(uVar6);
  iVar4 = *(int *)(unaff_EBP + -4) * 0x2c;
  *(int *)(unaff_EBP + -0xc) = iVar4;
  iVar4 = iVar4 + iVar3;
  *(int *)(unaff_EBP + -4) = iVar4;
  FUN_007153c0(param_1,iVar4,*(undefined4 *)(unaff_EBP + 0xc));
  if (*(int *)(unaff_EBP + 8) == param_1[1]) {
    FUN_00716390(*param_1,param_1[1],iVar3);
  }
  else {
    FUN_00716340(*param_1,*(int *)(unaff_EBP + 8),iVar3);
    FUN_00716340(*(undefined4 *)(unaff_EBP + 8),param_1[1],*(int *)(unaff_EBP + -4) + 0x2c);
  }
  FUN_00716090(iVar3,*(int *)(unaff_EBP + -8) + 1,uVar6);
  return *param_1 + *(int *)(unaff_EBP + -0xc);
}



/* FUNCTION 10062 ; VA 0x007147d0 ; FUN_007147d0 */

undefined4 * __thiscall
FUN_007147d0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abec0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00559fe0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      FUN_00559fe0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar1 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(iVar1 + 0x10,param_4);
    if (cVar2 != '\0') {
      FUN_00559fe0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar2 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar2 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar2 = FUN_00570370(param_3 + 4,param_4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar2 = FUN_00570370(param_4,piStack_18 + 4), cVar2 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_00714a10(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10063 ; VA 0x007149f2 ; Catch_All@007149f2 */

void Catch_All_007149f2(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10064 ; VA 0x00714a10 ; FUN_00714a10 */

void __thiscall
FUN_00714a10(int *param_1,undefined4 *param_2,char param_3,byte *param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  byte bVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  byte *pbVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  bool bVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abed0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar4 = 1;
  puVar8 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar5 = *(char *)((int)puVar8 + 0xd);
  puVar3 = (undefined4 *)*param_1;
  while (cVar5 == '\0') {
    pbVar9 = (byte *)(puVar8 + 4);
    if (param_3 == '\0') {
      uVar1 = puVar8[8];
      if (0xf < (uint)puVar8[9]) {
        pbVar9 = *(byte **)pbVar9;
      }
      uVar6 = *(uint *)(param_4 + 0x10);
      pbVar10 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar10 = *(byte **)param_4;
      }
      uVar7 = uVar6;
      if (uVar1 < uVar6) {
        uVar7 = uVar1;
      }
      while (uVar2 = uVar7 - 4, 3 < uVar7) {
        if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_00714b46;
        pbVar10 = pbVar10 + 4;
        pbVar9 = pbVar9 + 4;
        uVar7 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_00714b7a:
        uVar7 = 0;
      }
      else {
LAB_00714b46:
        bVar12 = *pbVar10 < *pbVar9;
        if ((*pbVar10 == *pbVar9) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar12 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar12 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
               ((uVar2 == 0xffffffff || (bVar12 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3])))
               ))))))))) goto LAB_00714b7a;
        uVar7 = -(uint)bVar12 | 1;
      }
      if (uVar7 == 0) {
        if (uVar6 < uVar1) {
          uVar7 = 0xffffffff;
        }
        else {
          uVar7 = 0;
        }
      }
      bVar4 = (byte)(uVar7 >> 0x1f);
    }
    else {
      pbVar10 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar10 = *(byte **)param_4;
      }
      uVar1 = puVar8[8];
      if (0xf < (uint)puVar8[9]) {
        pbVar9 = *(byte **)pbVar9;
      }
      uVar6 = uVar1;
      if (*(uint *)(param_4 + 0x10) < uVar1) {
        uVar6 = *(uint *)(param_4 + 0x10);
      }
      while (uVar7 = uVar6 - 4, 3 < uVar6) {
        if (*(int *)pbVar9 != *(int *)pbVar10) goto LAB_00714aa6;
        pbVar9 = pbVar9 + 4;
        pbVar10 = pbVar10 + 4;
        uVar6 = uVar7;
      }
      if (uVar7 == 0xfffffffc) {
LAB_00714ada:
        uVar6 = 0;
      }
      else {
LAB_00714aa6:
        bVar12 = *pbVar9 < *pbVar10;
        if ((*pbVar9 == *pbVar10) &&
           ((uVar7 == 0xfffffffd ||
            ((bVar12 = pbVar9[1] < pbVar10[1], pbVar9[1] == pbVar10[1] &&
             ((uVar7 == 0xfffffffe ||
              ((bVar12 = pbVar9[2] < pbVar10[2], pbVar9[2] == pbVar10[2] &&
               ((uVar7 == 0xffffffff || (bVar12 = pbVar9[3] < pbVar10[3], pbVar9[3] == pbVar10[3])))
               ))))))))) goto LAB_00714ada;
        uVar6 = -(uint)bVar12 | 1;
      }
      if (uVar6 == 0) {
        if (uVar1 < *(uint *)(param_4 + 0x10)) {
          bVar4 = 0;
          goto LAB_00714b96;
        }
        uVar6 = 0;
      }
      bVar4 = (byte)(uVar6 >> 0x1f) ^ 1;
    }
LAB_00714b96:
    if (bVar4 == 0) {
      puVar11 = (undefined4 *)puVar8[2];
    }
    else {
      puVar11 = (undefined4 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar11;
    cVar5 = *(char *)((int)puVar11 + 0xd);
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar4 != 0) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar4 = 1;
      ExceptionList = &pvStack_10;
      pbVar9 = param_4;
      goto LAB_00714bd1;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  pbVar9 = param_4;
  puVar8 = _param_3;
  cVar5 = FUN_00570370(_param_3 + 4,param_4);
  if (cVar5 == '\0') {
    FUN_00576370(param_5);
    *param_2 = puVar8;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00714bd1:
  puVar8 = (undefined4 *)FUN_00559fe0(&param_3,bVar4,puVar3,pbVar9,param_5);
  *param_2 = *puVar8;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10065 ; VA 0x00714c48 ; Catch_All@00714c48 */

void Catch_All_00714c48(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10066 ; VA 0x00714c60 ; FUN_00714c60 */

void __thiscall FUN_00714c60(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar2 = param_2;
  uVar7 = param_1[1];
  uVar1 = (int)(uVar7 - *param_1) / 0x18;
  uVar5 = (int)(param_1[2] - *param_1) / 0x18;
  if (param_2 <= uVar5) {
    if (param_2 <= uVar1) {
      if (param_2 != uVar1) {
        param_1[1] = *param_1 + param_2 * 0x18;
      }
      return;
    }
    if (param_2 - uVar1 == 0) {
      param_1[1] = uVar7;
      return;
    }
    iVar4 = (param_2 - uVar1) * 0x18;
    FUN_0170d1f0(uVar7,0,iVar4);
    param_1[1] = uVar7 + iVar4;
    return;
  }
  if (0xaaaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = param_2;
  if ((uVar5 <= 0xaaaaaaa - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < param_2)) {
    uVar7 = param_2;
  }
  uVar5 = uVar7 * 0x18;
  if (uVar7 < 0xaaaaaab) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_00714cf4;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00714cf4:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00714e31;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  iVar4 = uVar2 - uVar1;
  if (iVar4 != 0) {
    FUN_0170d1f0(uVar7 + uVar1 * 0x18,0,iVar4 * 0x18);
  }
  uVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar7,uVar1,param_1[1] - uVar1);
  if (*param_1 != 0) {
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - *param_1) / 0x18) * 0x18;
    uVar3 = uVar1;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar3) - 4) {
LAB_00714e31:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar2 * 0x18;
  param_1[2] = uVar5 + uVar7;
  return;
}



/* FUNCTION 10067 ; VA 0x00714e40 ; FUN_00714e40 */

void __thiscall FUN_00714e40(int *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  
  puVar4 = (undefined4 *)param_1[1];
  iVar5 = *param_1;
  uVar1 = (int)puVar4 - iVar5 >> 3;
  uVar3 = param_1[2] - iVar5 >> 3;
  if (param_2 <= uVar3) {
    if (uVar1 < param_2) {
      for (iVar5 = param_2 - uVar1; iVar5 != 0; iVar5 = iVar5 + -1) {
        *puVar4 = 0;
        puVar4[1] = 0;
        puVar4 = puVar4 + 2;
      }
      FUN_005596d0(puVar4,puVar4,param_3);
      param_1[1] = (int)puVar4;
      return;
    }
    if (param_2 != uVar1) {
      iVar5 = iVar5 + param_2 * 8;
      FUN_005596d0(iVar5,puVar4,param_1);
      param_1[1] = iVar5;
    }
    return;
  }
  if (param_2 < 0x20000000) {
    uVar6 = param_2;
    if ((uVar3 <= 0x1fffffff - (uVar3 >> 1)) && (uVar6 = (uVar3 >> 1) + uVar3, uVar6 < param_2)) {
      uVar6 = param_2;
    }
    iVar2 = FUN_00578020(uVar6);
    puVar4 = (undefined4 *)(iVar2 + uVar1 * 8);
    for (iVar5 = param_2 - uVar1; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar4 = 0;
      puVar4[1] = 0;
      puVar4 = puVar4 + 2;
    }
    FUN_005596d0(puVar4,puVar4,param_3);
    FUN_005c23f0(*param_1,param_1[1],iVar2,param_1);
    FUN_005c5230(iVar2,param_2,uVar6);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 10068 ; VA 0x00714f50 ; FUN_00714f50 */

void __thiscall FUN_00714f50(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  
  iVar3 = param_1[1];
  uVar1 = (iVar3 - *param_1) / 0x2c;
  uVar2 = (param_1[2] - *param_1) / 0x2c;
  if (param_2 <= uVar2) {
    if (uVar1 < param_2) {
      iVar3 = FUN_00715f80(iVar3,param_2 - uVar1);
      param_1[1] = iVar3;
      return;
    }
    if (param_2 != uVar1) {
      iVar6 = param_2 * 0x2c + *param_1;
      for (iVar5 = iVar6; iVar5 != iVar3; iVar5 = iVar5 + 0x2c) {
        FUN_00715e90();
      }
      param_1[1] = iVar6;
    }
    return;
  }
  if (param_2 < 0x5d1745e) {
    uVar4 = param_2;
    if ((uVar2 <= 0x5d1745d - (uVar2 >> 1)) && (uVar4 = (uVar2 >> 1) + uVar2, uVar4 < param_2)) {
      uVar4 = param_2;
    }
    iVar3 = FUN_00716c50(uVar4);
    FUN_00715f80(uVar1 * 0x2c + iVar3,param_2 - uVar1);
    FUN_00716390(*param_1,param_1[1],iVar3);
    FUN_00716090(iVar3,param_2,uVar4);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 10069 ; VA 0x00715060 ; FUN_00715060 */

void __thiscall FUN_00715060(int *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uStack_8;
  
  uVar2 = param_2;
  iVar3 = param_1[1];
  iVar1 = *param_1;
  uVar5 = iVar3 - iVar1;
  uStack_8 = param_1[2] - iVar1;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar5) {
      if (param_2 != uVar5) {
        param_1[1] = iVar1 + param_2;
      }
      return;
    }
    iVar1 = iVar1 + param_2;
    FUN_0170d1f0(iVar3,0,iVar1 - iVar3);
    param_1[1] = iVar1;
    return;
  }
  if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x7fffffff - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar3 = FUN_00554060(uStack_8);
  FUN_0170d1f0(iVar3 + uVar5,0,uVar2 - uVar5);
  iVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar3,iVar1,param_1[1] - iVar1);
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar5 = param_1[2] - iVar1;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *param_1 = iVar3;
  param_1[1] = iVar3 + uVar2;
  param_1[2] = uStack_8 + iVar3;
  return;
}



/* FUNCTION 10070 ; VA 0x00715180 ; FUN_00715180 */

void __thiscall FUN_00715180(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abee0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Security::AslrPmcSharedHasher::SectionDataVector>::vftable
    ;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10071 ; VA 0x007151ee ; Catch_All@007151ee */

void Catch_All_007151ee(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00716060(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10072 ; VA 0x00715210 ; FUN_00715210 */

undefined4 *
FUN_00715210(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,int param_6)

{
  int *piVar1;
  int iVar2;
  uint in_stack_0000002c;
  undefined4 *in_stack_00000030;
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  int iStack_68;
  undefined4 *puStack_64;
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abf20;
  pvStack_10 = ExceptionList;
  puStack_64 = &param_6;
  uStack_8 = 1;
  iStack_68 = 0x715241;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_4;
  piStack_14 = param_5;
  puStack_64 = in_stack_00000030;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  in_stack_00000030 = (undefined4 *)auStack_7c;
  FUN_0054ef60(aiStack_30);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00715760(param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_64 = (undefined4 *)0x7152ad;
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_64 = (undefined4 *)0x7152bd;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    puStack_64 = (undefined4 *)(uStack_1c + 1);
    iVar2 = aiStack_30[0];
    if (0xfff < puStack_64) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      puStack_64 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_64 = (undefined4 *)0x7153b1;
        FUN_017167a3();
      }
    }
    uStack_6c = 0x7152f2;
    iStack_68 = iVar2;
    FUN_01674ea0();
  }
  in_stack_00000030 = param_1 + 1;
  *param_1 = param_3;
  *in_stack_00000030 = 0;
  param_1[2] = 0;
  if (iStack_50 != 0) {
    LOCK();
    *(int *)(iStack_50 + 4) = *(int *)(iStack_50 + 4) + 1;
    UNLOCK();
  }
  *in_stack_00000030 = uStack_54;
  param_1[2] = iStack_50;
  puStack_64 = (undefined4 *)auStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iStack_68 = 0x715336;
  FUN_0054ef60();
  param_1[9] = uStack_34;
  puStack_64 = (undefined4 *)0x715344;
  FUN_006511a0();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_64 = (undefined4 *)0x71535a;
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_64 = (undefined4 *)0x715369;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    puStack_64 = (undefined4 *)(in_stack_0000002c + 1);
    iVar2 = param_6;
    if (0xfff < puStack_64) {
      iVar2 = *(int *)(param_6 + -4);
      puStack_64 = (undefined4 *)(in_stack_0000002c + 0x24);
      if (0x1f < (param_6 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_64 = (undefined4 *)&UNK_007153b6;
        FUN_017167a3();
      }
    }
    uStack_6c = 0x715396;
    iStack_68 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10073 ; VA 0x007153c0 ; FUN_007153c0 */

void FUN_007153c0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = param_3[2];
  *param_3 = 0;
  param_3[1] = 0;
  param_3[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[3] = param_3[3];
  param_2[4] = param_3[4];
  param_2[5] = param_3[5];
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0;
  param_2[6] = param_3[6];
  param_2[7] = param_3[7];
  param_2[8] = param_3[8];
  param_3[6] = 0;
  param_3[7] = 0;
  param_3[8] = 0;
  param_2[9] = param_3[9];
  param_2[10] = param_3[10];
  return;
}



/* FUNCTION 10074 ; VA 0x00715490 ; FUN_00715490 */

undefined4 * FUN_00715490(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abf38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = GetProcessHeap(0,100);
  puVar5 = (undefined4 *)HeapAlloc(uVar4);
  if (puVar5 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar5 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::Security::AslrPmcSharedHasher>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,unsigned_int),class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Security::AslrPmcSharedHasher>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<unsigned_int>_>_>_>
              ::vftable;
    puVar5[0xf] = *param_1;
    puVar5[0x10] = 0;
    puVar5[0x11] = 0;
    puVar5[0x10] = param_1[1];
    puVar5[0x11] = param_1[2];
    param_1[1] = 0;
    param_1[2] = 0;
    puVar5[0x16] = 0;
    puVar5[0x17] = 0;
    uVar4 = param_1[4];
    uVar2 = param_1[5];
    uVar3 = param_1[6];
    puVar5[0x12] = param_1[3];
    puVar5[0x13] = uVar4;
    puVar5[0x14] = uVar2;
    puVar5[0x15] = uVar3;
    *(undefined8 *)(puVar5 + 0x16) = *(undefined8 *)(param_1 + 7);
    param_1[7] = 0;
    param_1[8] = 0xf;
    *(undefined *)(param_1 + 3) = 0;
    puVar5[0x18] = param_1[9];
    ExceptionList = pvStack_10;
    return puVar5;
  }
  uVar4 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar4);
  pcVar1 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar1)();
  return puVar5;
}



/* FUNCTION 10075 ; VA 0x0071555e ; Catch_All@0071555e */

void Catch_All_0071555e(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10076 ; VA 0x00715590 ; FUN_00715590 */

undefined4 * FUN_00715590(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  char cVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    puVar9 = &uStack_18;
    piStack_14 = (int *)0x0;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
    uVar8 = 0;
  }
  else {
    uStack_10 = 0;
    piStack_c = (int *)0x0;
    cVar7 = FUN_00602ce0(param_2);
    uVar8 = uStack_10;
    if (cVar7 == '\0') {
      FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c21d80);
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    puVar9 = &uStack_10;
    bVar5 = true;
    bVar4 = true;
    bVar3 = false;
  }
  piVar6 = piStack_c;
  *puVar9 = 0;
  *param_1 = uVar8;
  param_1[1] = puVar9[1];
  puVar9[1] = 0;
  if (bVar3) {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (bVar4) {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar2 = piStack_c[2] + -1;
        piStack_c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
  }
  if ((bVar5) && (piVar6 != (int *)0x0)) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 10077 ; VA 0x007156c0 ; FUN_007156c0 */

void FUN_007156c0(undefined *param_1,undefined *param_2)

{
  int iVar1;
  undefined uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined *puStack_8;
  
  if (param_1 != param_2) {
    puStack_8 = param_1 + 1;
    iVar5 = (int)param_2 - (int)puStack_8;
    if (param_2 < puStack_8) {
      iVar5 = 0;
    }
    if (iVar5 != 0) {
      uVar6 = 2;
      do {
        do {
          uVar4 = 0;
          uVar3 = 0;
          if (uVar6 != 1) {
            uVar4 = FUN_01679da0();
            uVar3 = 0xffffffff;
          }
        } while ((uVar3 / uVar6 <= uVar4 / uVar6) && (uVar3 % uVar6 != uVar6 - 1));
        uVar4 = uVar4 % uVar6;
        if (uVar4 != uVar6 - 1) {
          uVar2 = *puStack_8;
          *puStack_8 = param_1[uVar4];
          param_1[uVar4] = uVar2;
        }
        puStack_8 = puStack_8 + 1;
        iVar1 = uVar6 - 1;
        uVar6 = uVar6 + 1;
      } while (iVar1 != iVar5);
    }
  }
  return;
}



/* FUNCTION 10078 ; VA 0x00715760 ; FUN_00715760 */

undefined4 * __thiscall
FUN_00715760(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017abf78;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[8] = in_stack_00000024;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10079 ; VA 0x007158e0 ; FUN_007158e0 */

int * __thiscall FUN_007158e0(int *param_1,uint param_2)

{
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00554060(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + param_2;
    iVar1 = *param_1;
    FUN_0170d1f0(iVar1,0,param_2);
    param_1[1] = iVar1 + param_2;
  }
  return param_1;
}



/* FUNCTION 10080 ; VA 0x00715940 ; FUN_00715940 */

undefined4 * __thiscall
FUN_00715940(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int *param_8)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017abfe2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = param_2;
  uStack_8 = 1;
  uStack_7 = 0;
  param_1[3] = param_3;
  FUN_0054ef60(param_4);
  param_1[10] = param_5;
  param_1[0xb] = param_6;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  puVar1 = param_1 + 0xf;
  uStack_8 = 3;
  *puVar1 = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  *puVar1 = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 **)*puVar1 = puVar1;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  param_1[0x18] = param_7;
  param_1[0x19] = param_8;
  uStack_8 = 6;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  uVar5 = FUN_0068a6a0(0,0);
  param_1[0x1a] = uVar5;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  *(undefined *)(param_1 + 0x2a) = 0;
  _uStack_8 = CONCAT31(uStack_7,7);
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  FUN_00718600();
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar3 = param_8[1] + -1;
    param_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10081 ; VA 0x00715b20 ; FUN_00715b20 */

undefined4 * __thiscall FUN_00715b20(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac037;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puVar6 = param_1 + 2;
  uStack_8 = 0;
  *puVar6 = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  piStack_18 = puVar6;
  puStack_14 = param_1;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  *puVar6 = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 **)*puVar6 = puVar6;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  puVar6 = param_1 + 0xf;
  uStack_8._0_1_ = 4;
  *puVar6 = 0;
  param_1[0x10] = 0;
  piStack_18 = puVar6;
  uVar5 = FUN_00575af0();
  *puVar6 = uVar5;
  uStack_8._0_1_ = 5;
  param_1[0x11] = param_2;
  *(undefined *)(param_1 + 0x12) = 0;
  puVar6 = (undefined4 *)FUN_01674e20(0x48);
  if (puVar6 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar6 = 0;
    puVar6[1] = 0;
    puVar6[2] = 0;
    puVar6[3] = 0;
    puVar6[4] = 0;
    puVar6[5] = 0;
    puVar6[6] = 0;
    puVar6[7] = 0;
    puVar6[8] = 0;
    puVar6[9] = 0;
    puVar6[10] = 0;
    puVar6[0xb] = 0;
    puVar6[0xe] = 0;
    puVar6[0xf] = 0;
    puVar6[0x10] = 0;
    *(undefined2 *)(puVar6 + 0x11) = 0;
    puVar4 = puVar6;
  }
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_00715180(puVar4,puVar6);
  puVar6 = (undefined4 *)param_1[0xb];
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if ((undefined4 *)param_1[0xc] == puVar6) {
    FUN_00603a30(puVar6,&uStack_1c);
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  else {
    *puVar6 = uStack_1c;
    puVar6[1] = piStack_18;
    param_1[0xb] = param_1[0xb] + 8;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10082 ; VA 0x00715d10 ; FUN_00715d10 */

int * __fastcall FUN_00715d10(int *param_1)

{
  uint uVar1;
  undefined8 uStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac06e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  *(undefined *)(param_1 + 3) = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  uStack_8 = 2;
  param_1[9] = 1;
  param_1[10] = 0;
  param_1[0xb] = 0;
  piStack_14 = param_1;
  FUN_0055b6c0(0x80,param_1);
  uVar1 = 0;
  do {
    *(char *)(uVar1 + *param_1) = (char)uVar1;
    uVar1 = uVar1 + 1;
  } while (uVar1 < 0x80);
  uStack_1c = 0;
  FUN_016799d0();
  FUN_007156c0(*param_1,param_1[1],&uStack_1c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10083 ; VA 0x00715de0 ; FUN_00715de0 */

void FUN_00715de0(void)

{
  FUN_006511a0();
  return;
}



/* FUNCTION 10084 ; VA 0x00715df0 ; thunk_FUN_006511a0 */

void __fastcall thunk_FUN_006511a0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0065120d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 10085 ; VA 0x00715e00 ; FUN_00715e00 */

void __fastcall FUN_00715e00(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00715e90();
        iVar2 = iVar2 + 0x2c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x2c) * 0x2c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10086 ; VA 0x00715e80 ; thunk_FUN_00550be0 */

void __fastcall thunk_FUN_00550be0(int *param_1)

{
  if ((undefined4 *)*param_1 != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)*param_1)(1);
  }
  return;
}



/* FUNCTION 10087 ; VA 0x00715e90 ; FUN_00715e90 */

void __fastcall FUN_00715e90(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[6];
  if (iVar1 != 0) {
    uVar3 = param_1[8] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00715f6c;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00715f6c;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00715f6c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10088 ; VA 0x00715f80 ; FUN_00715f80 */

void FUN_00715f80(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = param_1 + 5;
    do {
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      param_1[5] = 0;
      param_1[6] = 0;
      param_1[7] = 0;
      param_1[8] = 0;
      param_1[9] = 0;
      param_1[10] = 0;
      *param_1 = 0;
      param_1 = param_1 + 0xb;
      puVar1[-4] = 0;
      puVar1[-3] = 0;
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 0xb;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 10089 ; VA 0x00716030 ; FUN_00716030 */

undefined4 __thiscall FUN_00716030(undefined4 param_1,byte param_2)

{
  FUN_006511a0();
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 10090 ; VA 0x00716060 ; FUN_00716060 */

undefined4 __thiscall FUN_00716060(undefined4 param_1,byte param_2)

{
  FUN_00715e90();
  FUN_00715e00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 10091 ; VA 0x00716090 ; FUN_00716090 */

void __thiscall FUN_00716090(int *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00715e90();
        iVar2 = iVar2 + 0x2c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x2c) * 0x2c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x2c + param_2;
  param_1[2] = param_4 * 0x2c + param_2;
  return;
}



/* FUNCTION 10092 ; VA 0x00716120 ; FUN_00716120 */

void __fastcall FUN_00716120(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00715e90();
    FUN_00715e00();
    FUN_01674ea0(iVar1,0x48);
  }
  return;
}



/* FUNCTION 10093 ; VA 0x00716150 ; FUN_00716150 */

void __thiscall FUN_00716150(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x15555555 - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_0071632c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_007161b4;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_007161b4:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0071632c;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_0071632c;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 10094 ; VA 0x00716340 ; FUN_00716340 */

int __thiscall FUN_00716340(undefined4 param_1,int param_2,int param_3,int param_4)

{
  if (param_2 != param_3) {
    do {
      FUN_007153c0(param_1,param_4,param_2);
      param_2 = param_2 + 0x2c;
      param_4 = param_4 + 0x2c;
    } while (param_2 != param_3);
  }
  return param_4;
}



/* FUNCTION 10095 ; VA 0x00716390 ; FUN_00716390 */

void __thiscall FUN_00716390(undefined4 param_1,int param_2,int param_3,int param_4)

{
  if (param_2 != param_3) {
    param_4 = param_4 - param_2;
    do {
      FUN_007153c0(param_1,param_4 + param_2,param_2);
      param_2 = param_2 + 0x2c;
    } while (param_2 != param_3);
  }
  return;
}



/* FUNCTION 10096 ; VA 0x007163e0 ; FUN_007163e0 */

/* WARNING: Removing unreachable block (ram,0x00716515) */
/* WARNING: Removing unreachable block (ram,0x00716528) */
/* WARNING: Removing unreachable block (ram,0x0071652f) */
/* WARNING: Removing unreachable block (ram,0x00716536) */
/* WARNING: Removing unreachable block (ram,0x007165c9) */
/* WARNING: Removing unreachable block (ram,0x007165dc) */
/* WARNING: Removing unreachable block (ram,0x007165e3) */
/* WARNING: Removing unreachable block (ram,0x007165ea) */

undefined4 *** __thiscall FUN_007163e0(int param_1,undefined4 ****param_2,undefined *param_3)

{
  undefined4 ***pppuVar1;
  int iVar2;
  char cVar3;
  undefined4 ****ppppuVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  undefined *puVar7;
  undefined4 ***pppuVar8;
  undefined4 uStack_58;
  undefined4 ***pppuStack_54;
  undefined auStack_50 [8];
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined *puStack_40;
  undefined4 ***pppuStack_3c;
  undefined4 ***pppuStack_38;
  undefined4 ***pppuStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac098;
  pvStack_10 = ExceptionList;
  pppuStack_38 = (undefined4 ***)0x716415;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00587410();
  uStack_8 = 0;
  if (param_2[4] == (undefined4 ***)0x0) {
    ExceptionList = pvStack_10;
    return (undefined4 ***)0x0;
  }
  pppuStack_38 = param_2;
  pppuStack_3c = &pppuStack_18;
  piVar5 = (int *)(param_1 + 0x3c);
  puStack_40 = (undefined *)0x716441;
  FUN_00718820();
  ppppuVar6 = (undefined4 ****)pppuStack_18;
  ppppuVar4 = (undefined4 ****)*piVar5;
  if ((undefined4 ****)pppuStack_18 == ppppuVar4) {
LAB_0071645c:
    ppppuVar6 = ppppuVar4;
  }
  else {
    pppuStack_38 = pppuStack_18 + 4;
    pppuStack_3c = param_2;
    puStack_40 = (undefined *)0x716456;
    cVar3 = FUN_00570370();
    ppppuVar4 = (undefined4 ****)*piVar5;
    if (cVar3 != '\0') goto LAB_0071645c;
  }
  iVar2 = iStack_14;
  if (ppppuVar6 != ppppuVar4) {
    pppuStack_38 = ppppuVar6[10];
    pppuStack_3c = (undefined4 ***)0x71646d;
    cVar3 = FUN_00718780();
    if (cVar3 == '\0') {
      *param_3 = 1;
    }
    ExceptionList = pvStack_10;
    return ppppuVar6[10];
  }
  pppuStack_38 = (undefined4 ***)0x71649a;
  FUN_00587410();
  pppuStack_38 = (undefined4 ***)(iVar2 + 0x28);
  pppuVar8 = (undefined4 ***)(*(int *)(iVar2 + 0x2c) - (int)*pppuStack_38 >> 3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pppuStack_3c = (undefined4 ***)((int)pppuVar8 + 1);
  puStack_40 = (undefined *)0x7164b3;
  FUN_00714e40();
  pppuStack_38 = param_2;
  pppuStack_3c = (undefined4 ***)&param_3;
  puStack_40 = (undefined *)0x7164c1;
  FUN_00718820();
  puVar7 = param_3;
  if (param_3 != (undefined *)*piVar5) {
    pppuStack_38 = (undefined4 ***)(param_3 + 0x10);
    pppuStack_3c = param_2;
    puStack_40 = (undefined *)0x7164d6;
    cVar3 = FUN_00570370();
    if (cVar3 == '\0') goto LAB_00716508;
  }
  pppuStack_18 = param_2;
  pppuStack_38 = (undefined4 ***)((int)&param_3 + 3);
  pppuStack_3c = &pppuStack_18;
  puStack_40 = &DAT_018bdeda;
  puStack_44 = (undefined4 *)0x7164f4;
  pppuStack_38 = (undefined4 ***)FUN_00714520();
  pppuStack_3c = (undefined4 ***)((int)pppuStack_38 + 0x10);
  puStack_40 = puVar7;
  puStack_44 = &param_3;
  uStack_48 = 0x716505;
  FUN_007147d0();
  puVar7 = param_3;
LAB_00716508:
  *(undefined4 ****)(puVar7 + 0x28) = pppuVar8;
  param_3 = auStack_50;
  uStack_8._0_1_ = 0;
  pppuStack_54 = param_2;
  uStack_58 = 0x716561;
  pppuStack_38 = pppuVar8;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_00715590(&uStack_58,iStack_14);
  uStack_8._0_1_ = 0;
  FUN_007143f0(FUN_00717000);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  pppuStack_38 = (undefined4 ***)0x716593;
  FUN_016899e0();
  if (param_2 != (undefined4 ****)0x0) {
    LOCK();
    pppuVar1 = (undefined4 ***)((int)param_2[1] + -1);
    param_2[1] = pppuVar1;
    UNLOCK();
    if (pppuVar1 == (undefined4 ***)0x0) {
      pppuStack_38 = (undefined4 ***)0x0;
      pppuStack_3c = (undefined4 ***)0x7165ac;
      (*(code *)**param_2)();
      pppuStack_3c = param_2;
      puStack_40 = (undefined *)0x0;
      puStack_44 = (undefined4 *)0x7165b5;
      puStack_44 = (undefined4 *)GetProcessHeap();
      uStack_48 = 0x7165bc;
      HeapFree();
    }
  }
  ExceptionList = pvStack_10;
  return pppuVar8;
}



/* FUNCTION 10097 ; VA 0x00716610 ; FUN_00716610 */

undefined FUN_00716610(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  char *pcVar8;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_48 [2];
  ushort uStack_46;
  undefined4 uStack_44;
  ushort uStack_3a;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar5 = param_2;
  iVar7 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac0c8;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return 0;
  }
  if (*(int *)(*(int *)(*param_2 + 4) + 0xc + (int)param_2) != 0) {
    return 0;
  }
  uStack_18 = 0xffffffff;
  ExceptionList = &pvStack_10;
  FUN_005af630(&uStack_18,4,0);
  if (5 < uStack_18) {
    if (DAT_01eafb08 == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
    FUN_016774b0(DAT_01eafb08,"Invalid Gsi Version %d",uStack_18);
    ExceptionList = pvStack_10;
    return 0;
  }
  puStack_2c = (undefined4 *)FUN_01674e20(0x48);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 0;
    puStack_2c[2] = 0;
    puStack_2c[3] = 0;
    puStack_2c[4] = 0;
    puStack_2c[5] = 0;
    puStack_2c[6] = 0;
    puStack_2c[7] = 0;
    puStack_2c[8] = 0;
    puStack_2c[9] = 0;
    puStack_2c[10] = 0;
    puStack_2c[0xb] = 0;
    puStack_2c[0xe] = 0;
    puStack_2c[0xf] = 0;
    puStack_2c[0x10] = 0;
    *(undefined2 *)(puStack_2c + 0x11) = 0;
    puVar2 = puStack_2c;
  }
  iStack_38 = 0;
  piStack_34 = (int *)0x0;
  FUN_00715180(puVar2,param_1);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (4 < uStack_18) {
    uStack_1c = 0;
    FUN_005af630(&uStack_1c,4,0);
    FUN_007158e0(uStack_1c,&uStack_11);
    uStack_8._0_1_ = 1;
    FUN_005af630(uStack_44,uStack_1c,0);
    iStack_20 = -1;
    FUN_005af630(&puStack_2c,4,0);
    FUN_005af630(&iStack_20,4,0);
    iVar4 = iStack_38;
    if (iStack_20 != -0x35013502) {
      iStack_28 = iVar7 + 0x20;
      uStack_24 = uStack_24 & 0xffffff00;
      *(undefined *)(iStack_38 + 0x44) = 0;
      FUN_00587410();
      FUN_0056ecd0(&iStack_38);
      uVar3 = *(undefined *)(iVar4 + 0x44);
      FUN_00550b60();
      FUN_0056d2d0();
      goto LAB_00716c15;
    }
    uStack_8._0_1_ = 0;
    FUN_0056d2d0();
  }
  if (3 < uStack_18) {
    iStack_20 = -1;
    FUN_005af630(&iStack_20,4,0);
    if (DAT_01eafb08 != '\0') {
      FUN_016774b0(DAT_01eafb08,"Gsi VersionPart 0x%08X",iStack_20);
    }
    uStack_1c = 0xffffffff;
    FUN_005af630(&uStack_1c,4,0);
    if (uStack_1c == 0xcafecafe) goto LAB_00716879;
    if (DAT_01eafb08 != '\0') {
      pcVar8 = "Invalid Gsi Marker4 0x%08X";
LAB_007168e5:
      FUN_016774b0(DAT_01eafb08,pcVar8,uStack_1c);
    }
LAB_007168f1:
    iVar4 = iStack_38;
    iStack_30 = iVar7 + 0x20;
    puStack_2c = (undefined4 *)((uint)puStack_2c & 0xffffff00);
    *(undefined *)(iStack_38 + 0x44) = 0;
    FUN_00587410();
    FUN_0056ecd0(&iStack_38);
    uVar3 = *(undefined *)(iVar4 + 0x44);
    FUN_00550b60();
    goto LAB_00716c15;
  }
LAB_00716879:
  if (2 < uStack_18) {
    iStack_20 = -1;
    FUN_005af630(&iStack_20,4,0);
    if (DAT_01eafb08 != '\0') {
      FUN_016774b0(DAT_01eafb08,"Gsi BuildSeed 0x%08X",iStack_20);
    }
    uStack_1c = 0xffffffff;
    FUN_005af630(&uStack_1c,4,0);
    if (uStack_1c != 0xcafecafe) {
      if (DAT_01eafb08 != '\0') {
        pcVar8 = "Invalid Gsi Marker3 0x%08X";
        goto LAB_007168e5;
      }
      goto LAB_007168f1;
    }
  }
  *(undefined *)(iStack_38 + 0x44) = 1;
  iVar4 = iStack_38;
  if (1 < uStack_18) {
    FUN_005af630(&uStack_1c,4,0);
    uStack_24 = uStack_1c;
    GetLocalTime(auStack_48);
    piVar5 = param_2;
    uStack_24 = ((uint)uStack_46 + (uStack_3a / 3) * -3 + (uint)uStack_44._2_2_ + (uint)uStack_3a) %
                uStack_24;
    if (uStack_1c != 0x10) {
      if (DAT_01eafb08 != '\0') {
        FUN_016774b0(DAT_01eafb08,"Invalid Number of Items %d",uStack_1c);
      }
      iVar7 = iStack_38;
      uStack_24 = uStack_24 & 0xffffff00;
      iStack_28 = param_1 + 0x20;
      *(undefined *)(iStack_38 + 0x44) = 0;
      FUN_00587410();
      FUN_0056ecd0(&iStack_38);
      uVar3 = *(undefined *)(iVar7 + 0x44);
      FUN_00550b60();
      goto LAB_00716c15;
    }
    uVar6 = 0;
    do {
      FUN_005af630(&puStack_2c,4,0);
      iVar4 = iStack_38;
      if (uVar6 == uStack_24) {
        *(undefined4 **)(iStack_38 + 0x38) = puStack_2c;
        *(undefined **)(iStack_38 + 0x3c) = (&PTR_FUN_018e4618)[uVar6];
        *(undefined **)(iStack_38 + 0x40) = (&PTR_FUN_018e4658)[uVar6];
      }
      uVar6 = uVar6 + 1;
    } while (uVar6 < uStack_1c);
    iStack_20 = -1;
    FUN_005af630(&iStack_20,4,0);
    iVar7 = param_1;
    if (iStack_20 != -0x35013502) {
      if (DAT_01eafb08 != '\0') {
        FUN_016774b0(DAT_01eafb08,"Invalid Gsi Marker2 0x%08X",iStack_20);
      }
      *(undefined *)(iVar4 + 0x44) = 0;
      uStack_24 = uStack_24 & 0xffffff00;
      iStack_28 = param_1 + 0x20;
      FUN_00587410();
      FUN_0056ecd0(&iStack_38);
      uVar3 = *(undefined *)(iVar4 + 0x44);
      FUN_00550b60();
      goto LAB_00716c15;
    }
  }
  if (uStack_18 != 0) {
    param_1 = -1;
    FUN_007193c0(piVar5,iVar4 + 0xc,0x400000,&param_1);
    if (param_1 != -0x35013502) {
      if (DAT_01eafb08 != '\0') {
        FUN_016774b0(DAT_01eafb08,"Invalid Gsi Marker1 0x%08X",param_1);
      }
      iStack_30 = iVar7 + 0x20;
      *(undefined *)(iVar4 + 0x44) = 0;
      puStack_2c = (undefined4 *)((uint)puStack_2c & 0xffffff00);
      FUN_00587410();
      FUN_0056ecd0(&iStack_38);
      uVar3 = *(undefined *)(iVar4 + 0x44);
      FUN_00550b60();
      goto LAB_00716c15;
    }
  }
  do {
    FUN_0170d1f0(&uStack_74,0,0x2c);
    uStack_54 = 0;
    uStack_74 = 0;
    uStack_70 = 0;
    uStack_6c = 0;
    uStack_68 = 0;
    uStack_64 = 0;
    uStack_60 = 0;
    uStack_5c = 0;
    uStack_58 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(iVar4 + 8) == *(int *)(iVar4 + 4)) {
      FUN_007146d0(*(int *)(iVar4 + 4),&uStack_74);
    }
    else {
      FUN_007153c0(iVar4);
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 0x2c;
    }
    uStack_8._0_1_ = 0;
    FUN_00715e90();
    param_1 = -1;
    FUN_007193c0(piVar5,*(int *)(iVar4 + 4) + -0x2c,0x400000,&param_1);
    if (param_1 != -0x35013502) {
      if (DAT_01eafb08 != '\0') {
        FUN_016774b0(DAT_01eafb08,"Invalid Gsi Marker0 0x%08X",param_1);
      }
      FUN_00714f50(0,iVar4);
      *(undefined *)(iVar4 + 0x44) = 0;
      break;
    }
    FUN_007188f0();
  } while ((*(byte *)(*(int *)(*piVar5 + 4) + 0xc + (int)piVar5) & 1) == 0);
  iStack_30 = iVar7 + 0x20;
  puStack_2c = (undefined4 *)((uint)puStack_2c & 0xffffff00);
  FUN_00587410();
  FUN_0056ecd0(&iStack_38);
  FUN_00550b60();
  uVar3 = *(undefined *)(iVar4 + 0x44);
LAB_00716c15:
  piVar5 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_34[1] + -1;
    piStack_34[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 10098 ; VA 0x00716c50 ; FUN_00716c50 */

uint FUN_00716c50(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x2c;
  if (param_1 < 0x5d1745e) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 10099 ; VA 0x00716cc0 ; FUN_00716cc0 */

undefined4 __thiscall FUN_00716cc0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  
  iVar5 = FUN_008f78c0(param_2);
  if ((iVar5 != 0) && (iVar6 = (**(code **)(*param_2 + 0xb8))(), iVar6 != 0)) {
    piVar1 = *(int **)(iVar5 + 0x454);
    iVar6 = *piVar1;
    iVar2 = piVar1[1];
    lVar7 = FUN_00928340();
    bVar3 = lVar7 == CONCAT44(iVar2 - (int)piVar1,iVar6 - (int)piVar1);
    *(bool *)(param_1 + 0x24) = bVar3;
    if (!bVar3) {
      cVar4 = '\0';
      if (*(char *)(param_1 + 0x25) == '\0') {
        iVar6 = FUN_008fba30();
        *(bool *)(param_1 + 0x25) = DAT_01d5c094 < iVar6;
        cVar4 = *(char *)(param_1 + 0x24);
      }
      if ((cVar4 == '\0') && (*(char *)(param_1 + 0x26) == '\0')) {
        *(bool *)(param_1 + 0x26) = DAT_01d5c09c < *(int *)(iVar5 + 0x22c);
      }
    }
  }
  if ((*(double *)(param_2 + 0x188) < (double)DAT_01d5c0a4) ||
     (*(double *)(param_2 + 0x202) < (double)DAT_01d5c0ac)) {
    cVar4 = '\0';
  }
  else {
    cVar4 = '\x01';
  }
  *(char *)(param_1 + 0x27) = cVar4;
  if ((((*(char *)(param_1 + 0x24) == '\0') && (*(char *)(param_1 + 0x25) != '\0')) &&
      (*(char *)(param_1 + 0x26) != '\0')) && (cVar4 != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 10100 ; VA 0x00716dc0 ; FUN_00716dc0 */

undefined4 __thiscall FUN_00716dc0(int param_1,int param_2,uint param_3,char param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  char cStack_30;
  undefined auStack_2c [4];
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac0e8;
  pvStack_10 = ExceptionList;
  iVar3 = 0x54;
  if (param_4 == '\0') {
    iVar3 = 0x30;
  }
  uStack_14 = 0;
  piVar4 = (int *)(iVar3 + param_1);
  if (param_4 != '\0') {
    uStack_14 = 5;
  }
  ExceptionList = &pvStack_10;
  piStack_18 = piVar4;
  if (((*(char *)(param_1 + 0xa0) == '\0') &&
      (ExceptionList = &pvStack_10, cVar2 = FUN_00718600(), cVar2 == '\0')) &&
     (*piVar4 == piVar4[1])) {
    FUN_0064d540(param_3,piVar4);
  }
  if (param_3 == piVar4[1] - *piVar4 >> 3) {
    uVar5 = 0;
    if (param_3 != 0) {
      do {
        piVar1 = (int *)(*piVar4 + uVar5 * 8);
        if (*(char *)(*piVar4 + 4 + uVar5 * 8) == '\0') {
          uStack_40 = *(undefined4 *)(param_1 + 8);
          uStack_38 = *(undefined4 *)(param_1 + 0x28);
          uStack_34 = *(undefined4 *)(param_1 + 0x2c);
          cStack_30 = param_4;
          *piVar1 = *(int *)(param_2 + uVar5 * 4);
          uStack_20 = 0;
          piStack_1c = (int *)0x0;
          *(undefined *)(*piStack_18 + 4 + uVar5 * 8) = 1;
          uStack_3c = uVar5;
          cVar2 = FUN_00602ce0(param_1);
          piVar4 = piStack_1c;
          if (cVar2 == '\0') {
            FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_2c,&DAT_01c21d80);
          }
          if (piStack_1c != (int *)0x0) {
            LOCK();
            piStack_1c[2] = piStack_1c[2] + 1;
            UNLOCK();
          }
          uStack_28 = uStack_20;
          piStack_24 = piStack_1c;
          uStack_8 = 0;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar3 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              iVar3 = piVar4[2] + -1;
              piVar4[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          FUN_00717d20(&uStack_28,&uStack_40);
          uStack_8 = 0xffffffff;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar3 = piVar4[2] + -1;
            piVar4[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        else if (*piVar1 != *(int *)(param_2 + uVar5 * 4)) {
          FUN_007192f0(uStack_14,uVar5);
        }
        uVar5 = uVar5 + 1;
        piVar4 = piStack_18;
      } while (uVar5 < param_3);
    }
    FUN_00718a70();
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_007192f0(3,0);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 10101 ; VA 0x00716fa0 ; FUN_00716fa0 */

uint FUN_00716fa0(byte param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  undefined8 uVar2;
  
  uVar2 = FUN_01255890(param_3,param_4);
  uVar1 = (uint)uVar2;
  if ((param_2 == uVar1) && (uVar1 = (uint)param_1, (uint)((ulonglong)uVar2 >> 0x20) == uVar1)) {
    return 1;
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 10102 ; VA 0x00716fe0 ; FUN_00716fe0 */

void FUN_00716fe0(int param_1,undefined4 param_2)

{
  (**(code **)(param_1 + 0x18))
            (param_2,*(undefined4 *)(param_1 + 0x1c),*(undefined4 *)(param_1 + 0x20),
             *(undefined4 *)(param_1 + 0x24));
  return;
}



/* FUNCTION 10103 ; VA 0x00717000 ; FUN_00717000 */

int FUN_00717000(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined uVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 ******ppppppuVar9;
  undefined4 *puVar10;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int iStack_178;
  undefined **appuStack_174 [2];
  undefined8 uStack_16c;
  uint *puStack_158;
  uint *puStack_154;
  uint *puStack_148;
  uint *puStack_144;
  uint *puStack_138;
  uint *puStack_134;
  undefined4 *****pppppuStack_12c;
  undefined4 *puStack_128;
  undefined4 uStack_118;
  undefined **ppuStack_114;
  uint uStack_c8;
  undefined4 uStack_b8;
  uint uStack_b4;
  undefined4 *****apppppuStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined4 *****pppppuStack_98;
  undefined4 ****ppppuStack_94;
  undefined4 ****ppppuStack_90;
  undefined4 ****ppppuStack_8c;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 *****apppppuStack_74 [4];
  uint uStack_64;
  uint uStack_60;
  undefined4 *****pppppuStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  int iStack_50;
  undefined4 *****pppppuStack_4c;
  uint auStack_48 [2];
  code *pcStack_40;
  undefined8 uStack_3c;
  undefined8 *puStack_34;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 *****pppppuStack_20;
  undefined4 *puStack_1c;
  undefined4 *****pppppuStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac1f2;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffde0;
  pppppuStack_18 = (undefined4 ******)0x0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_01675290(DAT_01eadc98);
  uStack_8._0_1_ = 2;
  uStack_78 = uVar6;
  if (DAT_01d5c0e8 == '\0') {
    iStack_50 = 0;
    uStack_80 = 0;
    uVar8 = FUN_0151b370(&param_3);
    FUN_0151e8a0(apppppuStack_b0,uVar8);
    uStack_8._0_1_ = 4;
    if (DAT_01eafb08 != '\0') {
      ppppppuVar9 = apppppuStack_b0;
      if (0xf < uStack_9c) {
        ppppppuVar9 = (undefined4 ******)apppppuStack_b0[0];
      }
      FUN_01677650(DAT_01eafb08,"Attempt to fetch Gsi at: %s",ppppppuVar9);
    }
    FUN_014cc090(apppppuStack_b0,0,0);
    iStack_28 = 0;
    uStack_8._0_1_ = 6;
    uStack_2c = thunk_FUN_014d3f00();
    puStack_34 = &uStack_80;
    pppppuStack_5c = apppppuStack_b0;
    pcStack_40 = FUN_00718cc0;
    piStack_58 = &iStack_50;
    uStack_8._0_1_ = 7;
    uStack_3c._0_4_ = (undefined4 ******)pppppuStack_5c;
    uStack_3c._4_4_ = piStack_58;
    uVar8 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 8;
    uStack_54 = uVar8;
    pppppuStack_20 = (undefined4 *****)FUN_01674e20();
    if (pppppuStack_20 == (undefined4 *****)0x0) {
      pppppuStack_20 = (undefined4 *****)0x0;
    }
    else {
      *pppppuStack_20 = (undefined4 ****)0x0;
      pppppuStack_20[1] = (undefined4 ****)0x1;
      pppppuStack_20[2] = (undefined4 ****)FUN_00716fe0;
      pppppuStack_20[3] = (undefined4 ****)_guard_check_icall;
      pppppuStack_20[4] = (undefined4 ****)0x0;
      pppppuStack_20[5] = (undefined4 ****)uStack_2c;
      pppppuStack_20[6] = (undefined4 ****)pcStack_40;
      pppppuStack_20[7] = (undefined4 ******)uStack_3c;
      pppppuStack_20[8] = (undefined4 ****)uStack_3c._4_4_;
      pppppuStack_20[9] = (undefined4 ****)puStack_34;
    }
    FUN_016797d0(pppppuStack_20);
    puStack_1c = pppppuStack_20;
    if (pppppuStack_20 != (undefined4 *****)0x0) {
      LOCK();
      pppppuStack_20[1] = (undefined4 ****)((int)pppppuStack_20[1] + 1);
      UNLOCK();
    }
    pppppuStack_18 = (undefined4 *****)0x1;
    uStack_8._0_1_ = 9;
    FUN_01675290(uVar8);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    cVar5 = FUN_01679300(&puStack_1c);
    if (cVar5 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_1c);
    }
    if (puStack_1c != (undefined4 *)0x0) {
      piVar1 = puStack_1c + 1;
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(puStack_1c);
      }
    }
    uStack_64 = 0;
    uStack_60 = 0xf;
    apppppuStack_74[0] = (undefined4 *****)((uint)apppppuStack_74[0] & 0xffffff00);
    appuStack_174[0] = &PTR_018bffbc;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    pppppuStack_18 = (undefined4 *****)0x2;
    ppuStack_114 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
    uStack_118 = 0x48;
    uStack_16c = 0;
    FUN_00554f20();
    uStack_8 = 0xd;
    *(undefined ***)((int)appuStack_174 + (int)appuStack_174[0][1]) =
         std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_178 + (int)appuStack_174[0][1]) = appuStack_174[0][1] + -0x60;
    FUN_005658e0(1);
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    uStack_c8 = uStack_c8 & 0xffffff00;
    uStack_88 = 0xf00000000;
    pppppuStack_98 = (undefined4 *****)((uint)pppppuStack_98 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    puVar10 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar10 = param_3;
    }
    pppppuStack_20 = (undefined4 *****)FUN_01675640(auStack_48,"RobloxGsiFile_%s",puVar10);
    if (&pppppuStack_98 != (undefined4 ******)pppppuStack_20) {
      FUN_005507b0();
      pppppuStack_98 = (undefined4 *****)*pppppuStack_20;
      ppppuStack_94 = pppppuStack_20[1];
      ppppuStack_90 = pppppuStack_20[2];
      ppppuStack_8c = pppppuStack_20[3];
      uStack_88 = *(undefined8 *)(pppppuStack_20 + 4);
      pppppuStack_20[4] = (undefined4 *****)0x0;
      pppppuStack_20[5] = (undefined4 *****)0xf;
      *(undefined *)pppppuStack_20 = 0;
    }
    if (&DAT_0000000f < puStack_34) {
      if (((undefined *)0xfff < (undefined *)((int)puStack_34 + 1)) &&
         (0x1f < (auStack_48[0] - *(int *)(auStack_48[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    ppppppuVar9 = &pppppuStack_98;
    if (0xf < uStack_88._4_4_) {
      ppppppuVar9 = (undefined4 ******)pppppuStack_98;
    }
    FUN_00a11cc0(ppppppuVar9);
    uStack_8._0_1_ = 0x12;
    FUN_014cd0a0(apppppuStack_74,1,1);
    FUN_01530880();
    uStack_8._0_1_ = 0x13;
    FUN_015315b0();
    if (DAT_01eafb08 != '\0') {
      puVar10 = (undefined4 *)FUN_01531240(auStack_48);
      uStack_8._0_1_ = 0x14;
      if (0xf < (uint)puVar10[5]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      FUN_01677520(DAT_01eafb08,"Gsi length: %ld hash: %s",uStack_64,puVar10);
      uStack_8._0_1_ = 0x13;
      if (&DAT_0000000f < puStack_34) {
        if (((undefined *)0xfff < (undefined *)((int)puStack_34 + 1)) &&
           (0x1f < (auStack_48[0] - *(int *)(auStack_48[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        FUN_01674ea0();
      }
    }
    FUN_00577980();
    pppppuStack_18 = apppppuStack_74;
    if (0xf < uStack_60) {
      pppppuStack_18 = apppppuStack_74[0];
    }
    pppppuStack_20 = (undefined4 *****)uStack_64;
    puStack_1c = puStack_128;
    if (0x7fffffff < uStack_64) {
      FUN_010c5e30();
LAB_00717b52:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    if ((uStack_64 == 0) || (((byte)puStack_128 & 6) == 6)) {
      pppppuStack_12c = (undefined4 ******)0x0;
    }
    else {
      pppppuStack_4c = (undefined4 *****)FUN_00554060(uStack_64);
      FUN_0170c6f0(pppppuStack_4c,pppppuStack_18,pppppuStack_20);
      pppppuStack_12c = (undefined4 *****)((int)pppppuStack_4c + (int)pppppuStack_20);
      uVar3 = (uint)puStack_1c & 4;
      if (uVar3 == 0) {
        *puStack_158 = (uint)pppppuStack_4c;
        *puStack_148 = (uint)pppppuStack_4c;
        *puStack_138 = (uint)pppppuStack_20;
      }
      pppppuStack_18 = pppppuStack_12c;
      if (((uint)puStack_1c & 2) == 0) {
        ppppppuVar9 = (undefined4 ******)pppppuStack_4c;
        if (((uint)puStack_1c & 0x18) != 0) {
          ppppppuVar9 = (undefined4 ******)pppppuStack_12c;
        }
        pppppuStack_18 = (undefined4 *****)((int)pppppuStack_12c - (int)ppppppuVar9);
        *puStack_154 = (uint)pppppuStack_4c;
        *puStack_144 = (uint)ppppppuVar9;
        *puStack_134 = (uint)pppppuStack_18;
        if (uVar3 != 0) {
          *puStack_158 = (uint)pppppuStack_4c;
          *puStack_148 = 0;
          *puStack_138 = (uint)pppppuStack_4c;
        }
      }
      puStack_128 = (undefined4 *)((uint)puStack_1c | 1);
      pppppuStack_20 = (undefined4 *****)uVar3;
    }
    FUN_00716610(param_1,appuStack_174,in_stack_00000024);
    FUN_00550be0();
    FUN_00a12030();
    uStack_8._0_1_ = 0x10;
    if (0xf < uStack_88._4_4_) {
      if ((0xfff < uStack_88._4_4_ + 1) &&
         (0x1f < (uint)((int)pppppuStack_98 + (-4 - (int)pppppuStack_98[-1])))) goto LAB_00717b52;
      FUN_01674ea0();
    }
    uStack_8 = 0xf;
    if (uStack_64 == 0) {
      FUN_005542c0();
      iVar7 = FUN_00717704();
      return iVar7;
    }
    if (iStack_50 - 200U < 100) {
      piStack_58 = (int *)uStack_80;
      uStack_54 = (undefined4)((ulonglong)uStack_80 >> 0x20);
      uStack_3c._4_4_ = (int *)0x0;
      puStack_34 = (undefined8 *)0xf;
      auStack_48[0] = auStack_48[0] & 0xffffff00;
      FUN_005542c0();
      uStack_8._0_1_ = 0x18;
      FUN_00878cf0(auStack_48,CONCAT44(uStack_54,piStack_58),0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      FUN_005507b0();
    }
    uStack_3c = ZEXT48((undefined4 ******)uStack_3c);
    puStack_34 = (undefined8 *)0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 0x1a;
    FUN_008783f0(auStack_48,1,0);
    FUN_005507b0();
    uStack_8._0_1_ = 0xe;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_b4) {
      if ((0xfff < uStack_b4 + 1) && (0x1f < (uStack_c8 - *(int *)(uStack_c8 - 4)) - 4)) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    uStack_c8 = uStack_c8 & 0xffffff00;
    FUN_005703e0();
    uStack_8._0_1_ = 6;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_60) {
      if ((0xfff < uStack_60 + 1) &&
         (0x1f < (uint)((int)apppppuStack_74[0] + (-4 - (int)apppppuStack_74[0][-1])))) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_64 = 0;
    uStack_60 = 0xf;
    apppppuStack_74[0] = (undefined4 *****)((uint)apppppuStack_74[0] & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
    FUN_01679490();
    if (iStack_28 != 0) {
      piVar1 = (int *)(iStack_28 + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(iStack_28);
      }
    }
    FUN_0056db40();
    uStack_8._0_1_ = 2;
    if (0xf < uStack_9c) {
      if ((0xfff < uStack_9c + 1) &&
         (0x1f < (uint)((int)apppppuStack_b0[0] + (-4 - (int)apppppuStack_b0[0][-1])))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_a0 = 0;
    uStack_9c = 0xf;
    apppppuStack_b0[0] = (undefined4 *****)((uint)apppppuStack_b0[0] & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
    iVar7 = FUN_01675290(uVar6);
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar1 = param_2 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)*param_2)();
        LOCK();
        piVar1 = param_2 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar7 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (in_stack_00000020 < 0x10) {
      ExceptionList = pvStack_10;
      return iVar7;
    }
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (uint)((int)param_3 + (-4 - param_3[-1])))) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar7 = FUN_01675290(uVar6);
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar1 = param_2 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)*param_2)();
        LOCK();
        piVar1 = param_2 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar7 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (in_stack_00000020 < 0x10) {
      ExceptionList = pvStack_10;
      return iVar7;
    }
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (uint)((int)param_3 + (-4 - param_3[-1])))) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  iVar7 = FUN_01674ea0();
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 10104 ; VA 0x007176ae ; Catch@007176ae */

undefined * Catch_007176ae(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -200);
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_00551260(uVar2);
  if (DAT_01eafb08 != '\0') {
    uVar2 = (**(code **)(*piVar1 + 4))();
    FUN_01677650(DAT_01eafb08,"Error fetching Gsi: %s",uVar2);
  }
  return &DAT_007176f7;
}



/* FUNCTION 10105 ; VA 0x00717704 ; FUN_00717704 */

int FUN_00717704(void)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  uint *puVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBP;
  int unaff_ESI;
  
  *(undefined *)(unaff_EBP + -0x1c) = 0;
  *(int *)(unaff_EBP + -0x20) = *(int *)(unaff_EBP + 8) + 0x20;
  FUN_00587410();
  *(undefined *)(unaff_EBP + -4) = 0x16;
  puVar5 = (undefined4 *)FUN_01674e20();
  *(undefined4 **)(unaff_EBP + -0x50) = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar5[2] = 0;
    puVar5[3] = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
    puVar5[6] = 0;
    puVar5[7] = 0;
    puVar5[8] = 0;
    puVar5[9] = 0;
    puVar5[10] = 0;
    puVar5[0xb] = 0;
    puVar5[0xe] = 0;
    puVar5[0xf] = 0;
    puVar5[0x10] = 0;
    *(undefined2 *)(puVar5 + 0x11) = 0;
  }
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  FUN_00715180(puVar5,*(undefined4 *)(unaff_EBP + -0x74));
  iVar6 = *(int *)(unaff_EBP + 0x28) * 8;
  puVar7 = (undefined4 *)(*(int *)(*(int *)(unaff_EBP + 8) + 0x28) + iVar6);
  *(int *)(unaff_EBP + -0x48) = iVar6;
  *puVar7 = *(undefined4 *)(unaff_EBP + -0x2c);
  puVar5 = (undefined4 *)puVar7[1];
  *(undefined4 **)(unaff_EBP + -0x50) = puVar5;
  puVar7[1] = *(undefined4 *)(unaff_EBP + -0x28);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    iVar6 = puVar5[1] + unaff_ESI;
    puVar5[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*puVar5)();
      piVar3 = *(int **)(unaff_EBP + -0x50);
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + unaff_ESI;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar6 = *(int *)(unaff_EBP + -0x48);
  *(undefined *)(*(int *)(iVar6 + *(int *)(*(int *)(unaff_EBP + 8) + 0x28)) + 0x44) = 0;
  *(undefined *)(*(int *)(iVar6 + *(int *)(*(int *)(unaff_EBP + 8) + 0x28)) + 0x45) = 1;
  *(undefined *)(*(int *)(unaff_EBP + 8) + 0x48) = 1;
  *(undefined *)(unaff_EBP + -4) = 0x17;
  if (*(char *)(unaff_EBP + -0x1c) != '\0') {
    puVar4 = *(uint **)(unaff_EBP + -0x20);
    LOCK();
    uVar2 = *puVar4;
    *puVar4 = *puVar4 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puVar4;
      *puVar4 = *puVar4 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        FUN_00554e40();
        SetEvent();
      }
    }
  }
  *(undefined *)(unaff_EBP + -4) = 0xf;
  *(undefined4 *)(unaff_EBP + -0x34) = 0;
  *(undefined4 *)(unaff_EBP + -0x30) = 0xf;
  *(undefined *)(unaff_EBP + -0x44) = 0;
  FUN_005542c0("GsiDownload-Failure",0x13);
  *(undefined *)(unaff_EBP + -4) = 0x19;
  FUN_008783f0(unaff_EBP + -0x44,1,0);
  *(undefined *)(unaff_EBP + -4) = 0xf;
  FUN_005507b0();
  if (0 < DAT_01eafb04) {
    FUN_0151f6f0(0xffffffff,0,0);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_0151f9c0(&DAT_018d4688,*(undefined4 *)(unaff_EBP + -0x4c));
    FUN_0151fb00(&DAT_018e4300,*(undefined8 *)(unaff_EBP + -0x7c));
    FUN_0151f950(&DAT_018e483c,unaff_EBP + -0xc4);
    FUN_0151f9c0(&DAT_018e4844,*(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x44));
    FUN_0151f950(&DAT_018e4848,unaff_EBP + -0xac);
    iVar6 = DAT_01eafb04;
    *(undefined4 *)(unaff_EBP + -0x34) = 0;
    *(undefined4 *)(unaff_EBP + -0x30) = 0xf;
    *(undefined *)(unaff_EBP + -0x44) = 0;
    FUN_005542c0("GsiDownloadDebug",0x10);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    FUN_01520d20(unaff_EBP + -0x44,iVar6,0);
    FUN_005507b0();
    FUN_0151f7f0();
  }
  uVar2 = *(uint *)(unaff_EBP + -0xb0);
  *(undefined *)(unaff_EBP + -4) = 0xe;
  if (0xf < uVar2) {
    iVar6 = *(int *)(unaff_EBP + -0xc4);
    uVar9 = uVar2 + 1;
    iVar8 = iVar6;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar6 + -4);
      uVar9 = uVar2 + 0x24;
      if (0x1f < (iVar6 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  *(undefined4 *)(unaff_EBP + -0xb4) = 0;
  *(undefined4 *)(unaff_EBP + -0xb0) = 0xf;
  *(undefined *)(unaff_EBP + -0xc4) = 0;
  FUN_005703e0();
  uVar2 = *(uint *)(unaff_EBP + -0x5c);
  *(undefined *)(unaff_EBP + -4) = 6;
  if (0xf < uVar2) {
    iVar6 = *(int *)(unaff_EBP + -0x70);
    uVar9 = uVar2 + 1;
    iVar8 = iVar6;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar6 + -4);
      uVar9 = uVar2 + 0x24;
      if (0x1f < (iVar6 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  *(undefined4 *)(unaff_EBP + -0x60) = 0;
  *(undefined4 *)(unaff_EBP + -0x5c) = 0xf;
  *(undefined *)(unaff_EBP + -0x70) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x1d;
  FUN_01679490();
  if (*(int *)(unaff_EBP + -0x24) != 0) {
    piVar1 = (int *)(*(int *)(unaff_EBP + -0x24) + 4);
    LOCK();
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      FUN_01674ea0();
    }
  }
  FUN_0056db40();
  uVar2 = *(uint *)(unaff_EBP + -0x98);
  *(undefined *)(unaff_EBP + -4) = 2;
  if (0xf < uVar2) {
    iVar6 = *(int *)(unaff_EBP + -0xac);
    uVar9 = uVar2 + 1;
    iVar8 = iVar6;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar6 + -4);
      uVar9 = uVar2 + 0x24;
      if (0x1f < (iVar6 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  *(undefined4 *)(unaff_EBP + -0x9c) = 0;
  *(undefined4 *)(unaff_EBP + -0x98) = 0xf;
  *(undefined *)(unaff_EBP + -0xac) = 0;
  *(undefined *)(unaff_EBP + -4) = 0x1e;
  iVar6 = FUN_01675290();
  piVar1 = *(int **)(unaff_EBP + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar3 = piVar1 + 1;
    iVar8 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar6 = (**(code **)*piVar1)();
      LOCK();
      piVar3 = piVar1 + 2;
      iVar8 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar6 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar2 = *(uint *)(unaff_EBP + 0x24);
  if (0xf < uVar2) {
    iVar6 = *(int *)(unaff_EBP + 0x10);
    uVar9 = uVar2 + 1;
    iVar8 = iVar6;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar6 + -4);
      uVar9 = uVar2 + 0x24;
      if (0x1f < (iVar6 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(iVar8,uVar9);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return iVar6;
}



/* FUNCTION 10106 ; VA 0x00717b70 ; FUN_00717b70 */

uint __thiscall FUN_00717b70(int param_1,int param_2,uint *param_3,undefined4 *param_4,int *param_5)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar7 = 0;
  uVar2 = *(uint *)(param_1 + 0x28);
  uVar3 = *(uint *)(param_1 + 0x2c);
  if ((double)DAT_01d5c0ac <= *(double *)(param_2 + 0x808)) {
    uVar7 = 0x10;
  }
  uVar4 = 0;
  if ((double)DAT_01d5c0a4 <= *(double *)(param_2 + 0x620)) {
    uVar4 = 8;
  }
  uVar5 = 0;
  if (*(char *)(param_1 + 0x26) != '\0') {
    uVar5 = 4;
  }
  uVar6 = 0;
  if (*(char *)(param_1 + 0x25) != '\0') {
    uVar6 = 2;
  }
  cVar1 = *(char *)(param_1 + 0x24);
  *param_3 = uVar2;
  *param_4 = *(undefined4 *)(param_1 + 0x2c);
  *param_5 = *(int *)(param_1 + 0x14) - *(int *)(param_1 + 0x10);
  return uVar7 | uVar4 | uVar5 | uVar6 | (uint)(cVar1 != '\0') | -(uint)(0x80 < uVar2) & 0x400 |
         -(uint)(0x80 < uVar3) & 0x200 | -(uint)(0x20 < uVar3) & 0x80 |
         -(uint)(0x20 < uVar2) & 0x100 | -(uint)(1 < uVar3) & 0x20 | -(uint)(1 < uVar2) & 0x40;
}



/* FUNCTION 10107 ; VA 0x00717c60 ; FUN_00717c60 */

undefined4 * FUN_00717c60(undefined4 *param_1)

{
  byte bVar1;
  byte bVar2;
  char *pcVar3;
  char acStack_34 [32];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac219;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  FUN_00714c60(0x80,param_1);
  pcVar3 = acStack_34;
  bVar2 = 0;
  do {
    bVar1 = bVar2 + 1;
    *pcVar3 = (bVar2 ^ 0x55) * bVar1;
    pcVar3 = pcVar3 + 1;
    bVar2 = bVar1;
  } while (bVar1 < 0x20);
  FUN_015318b0(*param_1,0xc00,0,acStack_34,0x7df,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10108 ; VA 0x00717d20 ; FUN_00717d20 */

undefined4 __thiscall FUN_00717d20(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  uint uVar12;
  int iVar13;
  int *piVar14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac240;
  pvStack_10 = ExceptionList;
  piVar14 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar14 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar14[2] = piVar14[2] + 1;
    UNLOCK();
    piVar14 = (int *)param_2[1];
  }
  uVar4 = *param_2;
  piVar1 = piVar14 + 2;
  uVar7 = *param_3;
  uVar8 = param_3[1];
  uVar9 = param_3[2];
  uVar10 = param_3[3];
  uVar5 = param_3[4];
  if (piVar14 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*piVar14 + 4))();
    }
  }
  puVar2 = (uint *)(param_1 + 0x1c);
  do {
    LOCK();
    uVar12 = *puVar2;
    *puVar2 = *puVar2 | 1;
    UNLOCK();
  } while ((uVar12 & 1) != 0);
  uVar12 = *(uint *)(param_1 + 0x10);
  uStack_8 = 1;
  if (uVar12 <= *(int *)(param_1 + 0x18) + 1U) {
    FUN_005cdb10(1);
    uVar12 = *(uint *)(param_1 + 0x10);
  }
  *(uint *)(param_1 + 0x14) = *(uint *)(param_1 + 0x14) & uVar12 - 1;
  iVar3 = (*(int *)(param_1 + 0x18) + *(int *)(param_1 + 0x14) & *(int *)(param_1 + 0x10) - 1U) * 4;
  iVar13 = *(int *)(param_1 + 0xc);
  if (*(int *)(iVar13 + iVar3) == 0) {
    uVar11 = FUN_01674e20(0x1c);
    *(undefined4 *)(iVar3 + *(int *)(param_1 + 0xc)) = uVar11;
    iVar13 = *(int *)(param_1 + 0xc);
  }
  puVar6 = *(undefined4 **)(iVar3 + iVar13);
  *puVar6 = uVar7;
  puVar6[1] = uVar8;
  puVar6[2] = uVar9;
  puVar6[3] = uVar10;
  puVar6[4] = uVar5;
  piVar1 = piVar14 + 2;
  puVar6[5] = 0;
  puVar6[6] = 0;
  if (piVar14 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar6[5] = uVar4;
  puVar6[6] = piVar14;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (piVar14 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*piVar14 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 10109 ; VA 0x00717e80 ; FUN_00717e80 */

void __thiscall FUN_00717e80(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined auStack_10 [12];
  
  if ((((*(int *)(param_1 + 0x70) == 0) && (*(int *)(param_1 + 0x74) == 0)) &&
      (*(int *)(param_1 + 0x78) == 0)) && (*(int *)(param_1 + 0x60) != 0)) {
    puVar2 = (undefined8 *)FUN_00717ee0(auStack_10,*(undefined4 *)(param_1 + 8));
    *(undefined8 *)(param_1 + 0x70) = *puVar2;
    *(undefined4 *)(param_1 + 0x78) = *(undefined4 *)(puVar2 + 1);
  }
  uVar1 = *(undefined4 *)(param_1 + 0x78);
  *param_2 = *(undefined8 *)(param_1 + 0x70);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 10110 ; VA 0x00717ee0 ; FUN_00717ee0 */

/* WARNING: Removing unreachable block (ram,0x00717faf) */
/* WARNING: Removing unreachable block (ram,0x00717fc2) */
/* WARNING: Removing unreachable block (ram,0x00717fc9) */
/* WARNING: Removing unreachable block (ram,0x00717fd0) */

undefined8 * __thiscall FUN_00717ee0(int param_1,undefined8 *param_2,uint param_3)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  if ((param_3 < (uint)(*(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28) >> 3)) &&
     (iVar1 = *(int *)(*(int *)(param_1 + 0x28) + param_3 * 8), iVar1 != 0)) {
    if (*(char *)(iVar1 + 0x44) == '\0') {
      *(undefined4 *)param_2 = 0;
      *(undefined4 *)((int)param_2 + 4) = 0;
      *(undefined4 *)(param_2 + 1) = 0;
      FUN_00550b60();
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar2 = *(undefined4 *)(iVar1 + 0x40);
    *param_2 = *(undefined8 *)(iVar1 + 0x38);
    *(undefined4 *)(param_2 + 1) = uVar2;
    FUN_00550b60();
    ExceptionList = pvStack_10;
    return param_2;
  }
  *(undefined4 *)param_2 = 0;
  *(undefined4 *)((int)param_2 + 4) = 0;
  *(undefined4 *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10111 ; VA 0x00717ff0 ; FUN_00717ff0 */

void __fastcall FUN_00717ff0(int param_1)

{
  FUN_00bc3c50(param_1 + 0x8c,*(int *)(param_1 + 0x9c) + 0x1ff0,param_1 + 0x7c);
  return;
}



/* FUNCTION 10112 ; VA 0x00718010 ; FUN_00718010 */

undefined4 __fastcall FUN_00718010(int *param_1)

{
  byte bVar1;
  undefined8 uStack_c;
  
  bVar1 = *(byte *)(param_1 + 3);
  if ((uint)bVar1 == (param_1[1] - *param_1) - 1U) {
    uStack_c = 0;
    FUN_016799d0();
    FUN_007156c0(*param_1,param_1[1],&uStack_c);
    bVar1 = 0;
  }
  *(byte *)(param_1 + 3) = bVar1 + 1;
  return CONCAT31((int3)((uint)*param_1 >> 8),*(undefined *)((uint)bVar1 + *param_1));
}



/* FUNCTION 10113 ; VA 0x00718060 ; FUN_00718060 */

/* WARNING: Removing unreachable block (ram,0x007180d0) */
/* WARNING: Removing unreachable block (ram,0x007180e3) */
/* WARNING: Removing unreachable block (ram,0x007180ea) */
/* WARNING: Removing unreachable block (ram,0x007180f1) */

int __thiscall FUN_00718060(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  if (((uint)(*(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28) >> 3) < param_2) ||
     (piVar1 = *(int **)(*(int *)(param_1 + 0x28) + param_2 * 8), piVar1 == (int *)0x0)) {
    iVar2 = 0;
  }
  else {
    iVar2 = (piVar1[1] - *piVar1) / 0x2c;
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 10114 ; VA 0x00718110 ; FUN_00718110 */

/* WARNING: Removing unreachable block (ram,0x0071818f) */
/* WARNING: Removing unreachable block (ram,0x007181a2) */
/* WARNING: Removing unreachable block (ram,0x007181a9) */
/* WARNING: Removing unreachable block (ram,0x007181b0) */

undefined * __thiscall FUN_00718110(int param_1,undefined *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac258;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  piVar1 = *(int **)(param_1 + 0x3c);
  uStack_8 = 0;
  piVar2 = (int *)*piVar1;
  while( true ) {
    if (piVar2 == piVar1) {
      *(undefined4 *)(param_2 + 0x10) = 0;
      *(undefined4 *)(param_2 + 0x14) = 0xf;
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (piVar2[10] == param_3) break;
    FUN_00551320();
  }
  FUN_0054ef60(piVar2 + 4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10115 ; VA 0x007181f0 ; FUN_007181f0 */

undefined4 __thiscall FUN_007181f0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  
  if (*(char *)(param_1 + 0xa2) != '\0') {
    return 1;
  }
  iVar5 = FUN_008f78c0(param_2);
  if ((iVar5 != 0) && (iVar6 = (**(code **)(*param_2 + 0xb8))(), iVar6 != 0)) {
    piVar1 = *(int **)(iVar5 + 0x454);
    iVar6 = *piVar1;
    iVar2 = piVar1[1];
    lVar7 = FUN_00928340();
    bVar3 = lVar7 == CONCAT44(iVar2 - (int)piVar1,iVar6 - (int)piVar1);
    *(bool *)(param_1 + 0xa5) = bVar3;
    if (!bVar3) {
      cVar4 = '\0';
      if (*(char *)(param_1 + 0xa6) == '\0') {
        iVar6 = FUN_008fba30();
        *(bool *)(param_1 + 0xa6) = DAT_01d5c094 < iVar6;
        cVar4 = *(char *)(param_1 + 0xa5);
      }
      if ((cVar4 == '\0') && (*(char *)(param_1 + 0xa7) == '\0')) {
        *(bool *)(param_1 + 0xa7) = DAT_01d5c09c < *(int *)(iVar5 + 0x22c);
      }
    }
  }
  if ((*(double *)(param_2 + 0x188) < (double)DAT_01d5c0a4) ||
     (*(double *)(param_2 + 0x202) < (double)DAT_01d5c0ac)) {
    cVar4 = '\0';
  }
  else {
    cVar4 = '\x01';
  }
  *(char *)(param_1 + 0xa8) = cVar4;
  if ((((*(char *)(param_1 + 0xa5) == '\0') && (*(char *)(param_1 + 0xa6) != '\0')) &&
      (*(char *)(param_1 + 0xa7) != '\0')) && (cVar4 != '\0')) {
    *(undefined *)(param_1 + 0xa2) = 1;
    return 1;
  }
  *(undefined *)(param_1 + 0xa2) = 0;
  return 0;
}



/* FUNCTION 10116 ; VA 0x00718330 ; FUN_00718330 */

/* WARNING: Removing unreachable block (ram,0x007183b7) */
/* WARNING: Removing unreachable block (ram,0x007183ca) */
/* WARNING: Removing unreachable block (ram,0x007183d1) */
/* WARNING: Removing unreachable block (ram,0x007183d8) */

bool __fastcall FUN_00718330(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0xa4) != '\0') {
    return (bool)*(char *)(param_1 + 0xa4);
  }
  uVar1 = *(uint *)(param_1 + 8);
  iVar2 = *(int *)(param_1 + 0x60);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar3 = *(int *)(iVar2 + 0x28);
  if ((uVar1 < (uint)(*(int *)(iVar2 + 0x2c) - iVar3 >> 3)) &&
     (iVar2 = *(int *)(iVar3 + uVar1 * 8), iVar2 != 0)) {
    if (*(char *)(iVar2 + 0x44) != '\0') {
      bVar4 = *(int *)(iVar2 + 0x38) != 0;
      FUN_00550b60();
      goto LAB_007183e6;
    }
    FUN_00550b60();
  }
  bVar4 = false;
LAB_007183e6:
  *(bool *)(param_1 + 0xa4) = bVar4;
  ExceptionList = pvStack_10;
  return bVar4;
}



/* FUNCTION 10117 ; VA 0x00718400 ; FUN_00718400 */

/* WARNING: Removing unreachable block (ram,0x0071848b) */
/* WARNING: Removing unreachable block (ram,0x0071849e) */
/* WARNING: Removing unreachable block (ram,0x007184a5) */
/* WARNING: Removing unreachable block (ram,0x007184ac) */

void __fastcall FUN_00718400(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0xa3) != '\0') {
    return;
  }
  uVar1 = *(uint *)(param_1 + 8);
  iVar2 = *(int *)(param_1 + 0x60);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar3 = *(int *)(iVar2 + 0x28);
  if ((uVar1 < (uint)(*(int *)(iVar2 + 0x2c) - iVar3 >> 3)) &&
     (iVar2 = *(int *)(iVar3 + uVar1 * 8), iVar2 != 0)) {
    if (*(char *)(iVar2 + 0x44) != '\0') {
      iVar3 = *(int *)(iVar2 + 0x10);
      iVar2 = *(int *)(iVar2 + 0xc);
      FUN_00550b60();
      bVar4 = iVar3 != iVar2;
      goto LAB_007184ba;
    }
    FUN_00550b60();
  }
  bVar4 = false;
LAB_007184ba:
  *(bool *)(param_1 + 0xa3) = bVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10118 ; VA 0x007184e0 ; FUN_007184e0 */

/* WARNING: Removing unreachable block (ram,0x007185b9) */
/* WARNING: Removing unreachable block (ram,0x007185cc) */
/* WARNING: Removing unreachable block (ram,0x007185d3) */
/* WARNING: Removing unreachable block (ram,0x007185da) */

undefined4 __fastcall FUN_007184e0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac258;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x60);
  iVar5 = *(int *)(param_1 + 0x2c);
  uVar2 = *(uint *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar3 = *(int *)(iVar1 + 0x28);
  uVar4 = *(int *)(iVar1 + 0x2c) - iVar3 >> 3;
  uStack_8 = 0;
  if ((uVar2 < uVar4) && (iVar1 = *(int *)(iVar3 + uVar2 * 8), iVar1 != 0)) {
    FUN_00bc3f70(*(int *)(iVar1 + 0xc) + 4,*(int *)(iVar1 + 0x34) + iVar5,
                 (*(int *)(iVar1 + 0x10) - *(int *)(iVar1 + 0xc)) + -8,param_1 + 0x7c);
    *(int *)(param_1 + 0x9c) = *(int *)(iVar1 + 0x34) + iVar5;
    iVar5 = *(int *)(iVar1 + 0x10) - *(int *)(iVar1 + 0xc);
    *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(iVar5 + -0x14 + *(int *)(iVar1 + 0xc));
    *(undefined4 *)(param_1 + 0x90) = *(undefined4 *)(iVar5 + -0x10 + *(int *)(iVar1 + 0xc));
    *(undefined4 *)(param_1 + 0x94) = *(undefined4 *)(iVar5 + -0xc + *(int *)(iVar1 + 0xc));
    uVar4 = *(uint *)(iVar5 + -8 + *(int *)(iVar1 + 0xc));
    *(uint *)(param_1 + 0x98) = uVar4;
  }
  ExceptionList = pvStack_10;
  return CONCAT31((int3)(uVar4 >> 8),1);
}



/* FUNCTION 10119 ; VA 0x00718600 ; FUN_00718600 */

/* WARNING: Removing unreachable block (ram,0x007186da) */
/* WARNING: Removing unreachable block (ram,0x007186ed) */
/* WARNING: Removing unreachable block (ram,0x007186f4) */
/* WARNING: Removing unreachable block (ram,0x007186fb) */
/* WARNING: Removing unreachable block (ram,0x00718732) */
/* WARNING: Removing unreachable block (ram,0x00718745) */
/* WARNING: Removing unreachable block (ram,0x0071874c) */
/* WARNING: Removing unreachable block (ram,0x00718753) */

undefined4 __fastcall FUN_00718600(int param_1)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0xa0) != '\0') {
    return 1;
  }
  ExceptionList = &pvStack_10;
  if ((*(int *)(param_1 + 0x60) != 0) &&
     (ExceptionList = &pvStack_10, cVar3 = FUN_00718780(*(undefined4 *)(param_1 + 8)), cVar3 != '\0'
     )) {
    uVar4 = FUN_00718060(*(undefined4 *)(param_1 + 8));
    FUN_0064d540(uVar4,param_1 + 0x30);
    uVar4 = FUN_00718060(*(undefined4 *)(param_1 + 8));
    FUN_0064d540(uVar4,param_1 + 0x54);
    *(undefined *)(param_1 + 0xa0) = 1;
    ExceptionList = pvStack_10;
    return 1;
  }
  iVar1 = *(int *)(param_1 + 0x60);
  if (iVar1 != 0) {
    uVar2 = *(uint *)(param_1 + 8);
    FUN_00587410();
    if (((uVar2 < (uint)(*(int *)(iVar1 + 0x2c) - *(int *)(iVar1 + 0x28) >> 3)) &&
        (iVar1 = *(int *)(*(int *)(iVar1 + 0x28) + uVar2 * 8), iVar1 != 0)) &&
       (*(char *)(iVar1 + 0x45) != '\0')) {
      *(undefined *)(param_1 + 0xa1) = 1;
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 10120 ; VA 0x00718780 ; FUN_00718780 */

/* WARNING: Removing unreachable block (ram,0x007187de) */
/* WARNING: Removing unreachable block (ram,0x007187f1) */
/* WARNING: Removing unreachable block (ram,0x007187f8) */
/* WARNING: Removing unreachable block (ram,0x007187ff) */

undefined4 __thiscall FUN_00718780(int param_1,uint param_2)

{
  uint uVar1;
  undefined uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uVar1 = *(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28) >> 3;
  if ((param_2 < uVar1) && (uVar1 = *(uint *)(*(int *)(param_1 + 0x28) + param_2 * 8), uVar1 != 0))
  {
    uVar2 = *(undefined *)(uVar1 + 0x44);
  }
  else {
    uVar2 = 0;
  }
  ExceptionList = pvStack_10;
  return CONCAT31((int3)(uVar1 >> 8),uVar2);
}



/* FUNCTION 10121 ; VA 0x00718820 ; FUN_00718820 */

void __thiscall FUN_00718820(int *param_1,int *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar2 = *(char *)((int)puVar4 + 0xd);
  puVar1 = (undefined4 *)*param_1;
  while (cVar2 == '\0') {
    cVar2 = FUN_00570370(puVar4 + 4,param_3);
    if (cVar2 == '\0') {
      puVar3 = (undefined4 *)*puVar4;
    }
    else {
      puVar3 = (undefined4 *)puVar4[2];
      puVar4 = puVar1;
    }
    puVar1 = puVar4;
    puVar4 = puVar3;
    cVar2 = *(char *)((int)puVar3 + 0xd);
  }
  *param_2 = (int)puVar1;
  return;
}



/* FUNCTION 10122 ; VA 0x00718860 ; FUN_00718860 */

uint FUN_00718860(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  
  uVar3 = param_1[2];
  uVar6 = (uint)param_1[1] >> 4;
  piVar5 = (int *)*param_1;
  uVar2 = uVar3;
  uVar1 = uVar3;
  param_1 = (undefined4 *)uVar3;
  if (uVar6 != 0) {
    do {
      uVar1 = *piVar5 * 0xbada55 + uVar1;
      uVar1 = (uVar1 * 0x20000 | uVar1 >> 0xf) * -0x3f0011ef;
      uVar2 = piVar5[1] * 0xbada55 + uVar2;
      uVar2 = (uVar2 * 0x20000 | uVar2 >> 0xf) * -0x3f0011ef;
      uVar3 = piVar5[2] * 0xbada55 + uVar3;
      uVar3 = (uVar3 * 0x20000 | uVar3 >> 0xf) * -0x3f0011ef;
      uVar4 = piVar5[3] * 0xbada55 + (int)param_1;
      uVar4 = uVar4 * 0x20000 | uVar4 >> 0xf;
      param_1 = (undefined4 *)(uVar4 * -0x3f0011ef);
      uVar6 = uVar6 - 1;
      piVar5 = piVar5 + 4;
    } while (uVar6 != 0);
    return uVar3 + uVar4 * 0x3f0011ef + uVar2 ^ uVar1;
  }
  return 0;
}



/* FUNCTION 10123 ; VA 0x007188f0 ; FUN_007188f0 */

undefined4 __fastcall FUN_007188f0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac280;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = 0;
  param_1[3] = 0;
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 4))();
  }
  uStack_8 = 0;
  cVar3 = FUN_00593b40(1);
  uStack_8 = 1;
  if (cVar3 == '\0') {
    uVar2 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
    uVar5 = uVar2 | 4;
    if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
      uVar5 = uVar2;
    }
    FUN_00554460(uVar5,0);
    uStack_8 = 4;
    piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 8))();
    }
    ExceptionList = pvStack_10;
    return 0xffffffff;
  }
  uStack_8 = 2;
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if ((*(int *)piVar1[7] != 0) && (0 < *(int *)piVar1[0xb])) {
    uVar4 = FUN_007189b6();
    return uVar4;
  }
  (**(code **)(*piVar1 + 0x18))();
  uVar4 = FUN_007189b6();
  return uVar4;
}



/* FUNCTION 10124 ; VA 0x00718995 ; Catch_All@00718995 */

undefined * Catch_All_00718995(void)

{
  FUN_005565b0(4,1);
  return &DAT_007189ae;
}



/* FUNCTION 10125 ; VA 0x007189b6 ; FUN_007189b6 */

void FUN_007189b6(void)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  uint unaff_EBX;
  int unaff_EBP;
  int *unaff_ESI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar4 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EBX;
  uVar3 = uVar4 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar3 = uVar4;
  }
  FUN_00554460(uVar3,0);
  iVar1 = *unaff_ESI;
  *(undefined4 *)(unaff_EBP + -4) = 4;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10126 ; VA 0x00718a10 ; FUN_00718a10 */

undefined4 __thiscall FUN_00718a10(int param_1,undefined8 *param_2)

{
  int iVar1;
  int *piVar2;
  
  if (*(int *)(param_1 + 0x6c) != 0) {
    iVar1 = **(int **)(param_1 + 0x68);
    *param_2 = *(undefined8 *)(iVar1 + 8);
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(iVar1 + 0x10);
    piVar2 = (int *)**(int **)(param_1 + 0x68);
    *(int *)piVar2[1] = *piVar2;
    *(int *)(*piVar2 + 4) = piVar2[1];
    *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + -1;
    FUN_01674ea0(piVar2,0x14);
    return 1;
  }
  return 0;
}



/* FUNCTION 10127 ; VA 0x00718a70 ; FUN_00718a70 */

undefined4 __fastcall FUN_00718a70(int param_1)

{
  uint *puVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  bool bVar5;
  undefined4 *puVar6;
  char *pcVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac2a0;
  pvStack_10 = ExceptionList;
  cStack_11 = '\0';
  puVar1 = (uint *)(param_1 + 0x50);
  ExceptionList = &pvStack_10;
  while( true ) {
    do {
      LOCK();
      uVar9 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar9 & 1) != 0);
    if (*(int *)(param_1 + 0x4c) == 0) break;
    puVar6 = *(undefined4 **)(param_1 + 0x3c);
    if (puVar6 != (undefined4 *)0x0) {
      puVar6 = (undefined4 *)*puVar6;
    }
    puVar4 = *(undefined8 **)(puVar6[1] + (puVar6[2] - 1 & *(uint *)(param_1 + 0x48)) * 4);
    uVar3 = *puVar4;
    uStack_18 = *(undefined4 *)(puVar4 + 1);
    iVar2 = *(int *)(param_1 + 0x4c) + -1;
    *(int *)(param_1 + 0x4c) = iVar2;
    if (iVar2 == 0) {
      *(undefined4 *)(param_1 + 0x48) = 0;
    }
    else {
      *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 1;
    }
    uStack_20._0_4_ = (int)uVar3;
    iVar2 = (int)uStack_20;
    *puVar1 = 0;
    cStack_11 = '\x01';
    uStack_20._4_4_ = (int)((ulonglong)uVar3 >> 0x20);
    uStack_20 = uVar3;
    if ((char)uStack_18 == '\0') {
      iVar8 = *(int *)(param_1 + 0x30);
      if ((*(char *)(iVar8 + 4 + (int)uStack_20 * 8) != '\0') &&
         (*(int *)(iVar8 + (int)uStack_20 * 8) != uStack_20._4_4_)) {
        FUN_007192f0(1,iVar2);
        iVar8 = *(int *)(param_1 + 0x30);
        uVar3 = uStack_20;
      }
      uStack_20 = uVar3;
      *(undefined *)(iVar8 + 5 + iVar2 * 8) = 1;
    }
    else {
      iVar8 = *(int *)(param_1 + 0x54);
      if ((*(char *)(iVar8 + 4 + (int)uStack_20 * 8) != '\0') &&
         (*(int *)(iVar8 + (int)uStack_20 * 8) != uStack_20._4_4_)) {
        FUN_007192f0(6,iVar2);
        iVar8 = *(int *)(param_1 + 0x54);
        uVar3 = uStack_20;
      }
      uStack_20 = uVar3;
      *(undefined *)(iVar8 + 5 + iVar2 * 8) = 1;
    }
  }
  *puVar1 = 0;
  if (cStack_11 == '\0') {
    if (*(char *)(*(int *)(param_1 + 0x60) + 0x48) != '\0') {
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = 0;
      FUN_005542c0("notValidated",0xc);
      uStack_8 = 1;
      FUN_00719590(auStack_50);
      FUN_005507b0();
      *(undefined *)(*(int *)(param_1 + 0x60) + 0x48) = 0;
    }
  }
  else {
    uVar9 = 0;
    bVar5 = true;
    uVar10 = *(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 3;
    if (uVar10 != 0) {
      pcVar7 = (char *)(*(int *)(param_1 + 0x30) + 5);
      do {
        if (*pcVar7 == '\0') {
          bVar5 = false;
          break;
        }
        uVar9 = uVar9 + 1;
        pcVar7 = pcVar7 + 8;
      } while (uVar9 < uVar10);
    }
    if ((DAT_01d5ac40 == '\0') && (DAT_01d5ab28 != '\0')) {
      if (!bVar5) {
        ExceptionList = pvStack_10;
        return 1;
      }
      uVar9 = 0;
      uVar10 = *(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3;
      if (uVar10 != 0) {
        pcVar7 = (char *)(*(int *)(param_1 + 0x54) + 5);
        do {
          if (*pcVar7 == '\0') {
            ExceptionList = pvStack_10;
            return 1;
          }
          uVar9 = uVar9 + 1;
          pcVar7 = pcVar7 + 8;
        } while (uVar9 < uVar10);
      }
    }
    if (bVar5) {
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      FUN_005542c0("validated",9);
      uStack_8 = 0;
      FUN_00719590(auStack_38);
      if (0xf < uStack_24) {
        uVar10 = uStack_24 + 1;
        uVar9 = auStack_38[0];
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(auStack_38[0] - 4);
          uVar10 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar10);
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 10128 ; VA 0x00718cc0 ; FUN_00718cc0 */

void FUN_00718cc0(int param_1,undefined4 param_2,undefined4 *param_3,undefined8 *param_4)

{
  char cVar1;
  
  cVar1 = FUN_00558b30(param_1 + 0x18,param_2);
  if (cVar1 != '\0') {
    *param_3 = *(undefined4 *)(param_1 + 4);
    *param_4 = *(undefined8 *)(param_1 + 0x10);
  }
  return;
}



/* FUNCTION 10129 ; VA 0x00718d00 ; FUN_00718d00 */

undefined4 __thiscall FUN_00718d00(int param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  uint *puVar8;
  undefined4 uVar9;
  uint uVar10;
  uint *puVar11;
  char cStack_74;
  uint uStack_70;
  int *piStack_6c;
  undefined auStack_68 [12];
  uint uStack_5c;
  undefined4 uStack_58;
  undefined uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  uint *puStack_44;
  char cStack_40;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  uint uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  code *pcStack_24;
  uint *puStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ac2c8;
  pvStack_10 = ExceptionList;
  uStack_70 = 0;
  piStack_1c = (int *)0x0;
  piStack_6c = (int *)0x0;
  iStack_8 = 0;
  uStack_18 = 0;
  if (param_2 != 0) {
    puVar11 = (uint *)(param_1 + 0x1c);
    ExceptionList = &pvStack_10;
    iStack_2c = param_1;
    puStack_20 = puVar11;
    do {
      do {
        LOCK();
        uVar2 = *puVar11;
        *puVar11 = *puVar11 | 1;
        UNLOCK();
      } while ((uVar2 & 1) != 0);
      if (*(int *)(param_1 + 0x18) == 0) {
        *puVar11 = 0;
        break;
      }
      puVar5 = *(undefined4 **)(param_1 + 8);
      if (puVar5 != (undefined4 *)0x0) {
        puVar5 = (undefined4 *)*puVar5;
      }
      puVar8 = *(uint **)(puVar5[1] + (puVar5[2] - 1 & *(uint *)(param_1 + 0x14)) * 4);
      uVar10 = *puVar8;
      uVar3 = puVar8[1];
      uVar4 = puVar8[3];
      piStack_6c = (int *)puVar8[6];
      uVar2 = puVar8[4];
      if (piStack_6c != (int *)0x0) {
        LOCK();
        piStack_6c[2] = piStack_6c[2] + 1;
        UNLOCK();
        piStack_6c = (int *)puVar8[6];
      }
      uStack_70 = puVar8[5];
      piStack_34 = piStack_6c;
      uStack_30 = uStack_70;
      piVar7 = piStack_6c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        piVar7 = piStack_6c;
        if (iVar6 == 0) {
          iVar6 = *piStack_1c;
          piStack_1c = piStack_6c;
          (**(code **)(iVar6 + 4))();
          piVar7 = piStack_1c;
        }
      }
      piStack_1c = piVar7;
      piVar7 = *(int **)(*(int *)(*(int *)(param_1 + 0xc) +
                                 (*(int *)(param_1 + 0x10) - 1U & *(uint *)(param_1 + 0x14)) * 4) +
                        0x18);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar6 = piVar7[2] + -1;
        piVar7[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
      piVar7 = (int *)(param_1 + 0x18);
      *piVar7 = *piVar7 + -1;
      if (*piVar7 == 0) {
        *(undefined4 *)(param_1 + 0x14) = 0;
      }
      else {
        *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + 1;
      }
      *puVar11 = 0;
      iStack_3c = 0;
      piStack_38 = (int *)0x0;
      FUN_00602ce0(&uStack_70);
      iStack_8._0_1_ = 1;
      piVar7 = piStack_38;
      if (iStack_3c != 0) {
        iVar6 = FUN_00717ee0(auStack_68,uVar10);
        cStack_40 = '\0';
        pcStack_24 = *(code **)(iVar6 + 4);
        puStack_44 = (uint *)(param_1 + 0x20);
        FUN_00587410();
        iStack_8._0_1_ = 2;
        if (((uVar10 < (uint)(*(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28) >> 3)) &&
            (piVar7 = *(int **)(*(int *)(param_1 + 0x28) + uVar10 * 8), piVar7 != (int *)0x0)) &&
           (iVar6 = *piVar7, uVar3 < (uint)((piVar7[1] - iVar6) / 0x2c))) {
          piVar7 = (int *)(uVar3 * 0x2c + iVar6);
          iStack_14 = *piVar7;
          if (*(int *)(uVar3 * 0x2c + 0x10 + iVar6) - piVar7[3] >> 2 != 0) {
            uVar10 = 0;
            do {
              iVar6 = uVar10 * 4;
              uVar10 = uVar10 + 1;
              piVar1 = (int *)(iStack_14 + *(int *)(piVar7[3] + iVar6));
              *piVar1 = *piVar1 + (uVar4 - piVar7[9]);
              puVar11 = puStack_20;
            } while (uVar10 < (uint)(piVar7[4] - piVar7[3] >> 2));
          }
          uStack_28 = 0;
          if (piVar7[7] - piVar7[6] >> 2 != 0) {
            uVar10 = 0;
            do {
              iVar6 = uVar10 * 4;
              uVar10 = uVar10 + 1;
              piVar1 = (int *)(iStack_14 + *(int *)(piVar7[6] + iVar6));
              *piVar1 = *piVar1 - (uVar4 - piVar7[9]);
              puVar11 = puStack_20;
            } while (uVar10 < (uint)(piVar7[7] - piVar7[6] >> 2));
          }
          cStack_74 = (char)uVar2;
          piVar7[9] = uVar4;
          if (cStack_74 == '\0') {
            uStack_58 = FUN_00bc3de0(*piVar7 + 4,piVar7[10] + uVar4,(piVar7[1] - *piVar7) + -8);
            puVar8 = &uStack_5c;
            uStack_54 = 0;
            uStack_5c = uVar3;
LAB_00718fc2:
            FUN_00719230(puVar8);
          }
          else if (pcStack_24 != (code *)0x0) {
            uStack_4c = (*pcStack_24)(*piVar7 + 4,(piVar7[1] - *piVar7) + -8,piVar7[10] + uVar4,0);
            puVar8 = &uStack_50;
            uStack_48 = 1;
            uStack_50 = uVar3;
            goto LAB_00718fc2;
          }
          uStack_18 = uStack_18 + 1;
          iStack_8._0_1_ = 4;
          piVar7 = piStack_38;
          if (cStack_40 != '\0') {
            LOCK();
            uVar2 = *puStack_44;
            *puStack_44 = *puStack_44 + 0x80000000;
            UNLOCK();
            if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
              LOCK();
              uVar2 = *puStack_44;
              *puStack_44 = *puStack_44 | 0x40000000;
              UNLOCK();
              if ((uVar2 >> 0x1e & 1) == 0) {
                uVar9 = FUN_00554e40();
                SetEvent(uVar9);
                piVar7 = piStack_38;
              }
            }
          }
        }
        else {
          iStack_8._0_1_ = 3;
          piVar7 = piStack_38;
          if (cStack_40 != '\0') {
            LOCK();
            uVar2 = *puStack_44;
            *puStack_44 = *puStack_44 + 0x80000000;
            UNLOCK();
            if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
              LOCK();
              uVar2 = *puStack_44;
              *puStack_44 = *puStack_44 | 0x40000000;
              UNLOCK();
              if ((uVar2 >> 0x1e & 1) == 0) {
                uVar9 = FUN_00554e40();
                SetEvent(uVar9);
                piVar7 = piStack_38;
              }
            }
          }
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      piStack_38 = piVar7;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar6 = piVar7[1] + -1;
        piVar7[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar6 = piVar7[2] + -1;
          piVar7[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      param_1 = iStack_2c;
    } while (uStack_18 < param_2);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar7 = piStack_1c + 2;
      iVar6 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 10130 ; VA 0x007190d0 ; FUN_007190d0 */

/* WARNING: Removing unreachable block (ram,0x00719150) */
/* WARNING: Removing unreachable block (ram,0x00719168) */
/* WARNING: Removing unreachable block (ram,0x00719171) */
/* WARNING: Removing unreachable block (ram,0x00719180) */
/* WARNING: Removing unreachable block (ram,0x00719187) */
/* WARNING: Removing unreachable block (ram,0x007191d4) */
/* WARNING: Removing unreachable block (ram,0x007191dd) */
/* WARNING: Removing unreachable block (ram,0x007191ec) */

void FUN_007190d0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac2f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8._0_1_ = 1;
  FUN_016831b0();
  FUN_00602ce0(&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_01675290(uVar3);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10131 ; VA 0x00719230 ; FUN_00719230 */

void __thiscall FUN_00719230(int param_1,undefined8 *param_2)

{
  uint *puVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4d58;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar5 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar5 & 1) != 0);
  } while (uStack_8 != 0);
  uVar5 = *(uint *)(param_1 + 8);
  if (uVar5 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_00716150(1);
    uVar5 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar5 - 1;
  iVar2 = (*(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U) * 4;
  iVar6 = *(int *)(param_1 + 4);
  if (*(int *)(iVar6 + iVar2) == 0) {
    uVar4 = FUN_01674e20(0xc);
    *(undefined4 *)(iVar2 + *(int *)(param_1 + 4)) = uVar4;
    iVar6 = *(int *)(param_1 + 4);
  }
  puVar3 = *(undefined8 **)(iVar2 + iVar6);
  *puVar3 = *param_2;
  *(undefined4 *)(puVar3 + 1) = *(undefined4 *)(param_2 + 1);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10132 ; VA 0x007192f0 ; FUN_007192f0 */

uint __thiscall FUN_007192f0(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  puVar1 = *(undefined4 **)(param_1 + 0x68);
  puVar2 = (undefined4 *)*puVar1;
  while( true ) {
    if (puVar2 == puVar1) {
      uStack_c = *(undefined4 *)(param_1 + 8);
      iStack_10 = param_2;
      puVar2 = (undefined4 *)puVar1[1];
      iStack_8 = param_3;
      uVar3 = FUN_007145a0(puVar1,puVar2,&iStack_10);
      if (*(int *)(param_1 + 0x6c) != 0xccccccb) {
        iVar4 = *(int *)(param_1 + 0x6c) + 1;
        *(int *)(param_1 + 0x6c) = iVar4;
        puVar1[1] = uVar3;
        *puVar2 = uVar3;
        return CONCAT31((int3)((uint)iVar4 >> 8),1);
      }
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    if (((puVar2[4] == param_3) && (puVar2[2] == param_2)) && (puVar2[3] == *(int *)(param_1 + 8)))
    break;
    puVar2 = (undefined4 *)*puVar2;
  }
  return (uint)puVar2 & 0xffffff00;
}



/* FUNCTION 10133 ; VA 0x00719390 ; FUN_00719390 */

void __thiscall FUN_00719390(int param_1,undefined *param_2)

{
  undefined *puVar1;
  
  puVar1 = *(undefined **)(param_1 + 4);
  if (*(undefined **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
    return;
  }
  FUN_007145d0(puVar1,param_2);
  return;
}



/* FUNCTION 10134 ; VA 0x007193c0 ; FUN_007193c0 */

void FUN_007193c0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  uStack_14 = 0;
  iStack_8 = 0;
  iStack_c = 0;
  iStack_10 = 0;
  FUN_005af630(&uStack_14,4,0);
  FUN_005af630(&iStack_8,4,0);
  FUN_005af630(&iStack_c,4,0);
  FUN_005af630(&iStack_10,4,0);
  param_2[9] = param_3;
  param_2[10] = uStack_14;
  FUN_00715060(iStack_10 + 8,param_2);
  FUN_005f86c0(iStack_8,param_2 + 3);
  FUN_005f86c0(iStack_c,param_2 + 6);
  if (iStack_8 != 0) {
    FUN_005af630(param_2[3],iStack_8 << 2,0);
  }
  if (iStack_c != 0) {
    FUN_005af630(param_2[6],iStack_c << 2,0);
  }
  if (iStack_10 != 0) {
    FUN_005af630(*param_2,iStack_10 + 4,0);
  }
  FUN_005af630(param_4,4,0);
  return;
}



/* FUNCTION 10135 ; VA 0x007194c0 ; FUN_007194c0 */

/* WARNING: Removing unreachable block (ram,0x0071953f) */
/* WARNING: Removing unreachable block (ram,0x00719552) */
/* WARNING: Removing unreachable block (ram,0x00719559) */
/* WARNING: Removing unreachable block (ram,0x00719560) */

bool __thiscall FUN_007194c0(int param_1,undefined param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + 1;
  FUN_00587410();
  iVar1 = *(int *)(param_1 + 0x14);
  iVar2 = FUN_0170db20(*(int *)(param_1 + 0x10),param_2,iVar1 - *(int *)(param_1 + 0x10));
  iVar3 = iVar1;
  if (iVar2 != 0) {
    iVar3 = iVar2;
  }
  if (iVar3 != iVar1) {
    FUN_0170cc70(iVar3,iVar3 + 1,iVar1 - (iVar3 + 1));
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
  }
  ExceptionList = pvStack_10;
  return iVar3 != iVar1;
}



/* FUNCTION 10136 ; VA 0x00719590 ; FUN_00719590 */

void __thiscall FUN_00719590(int param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  undefined4 *puVar3;
  char ****ppppcVar4;
  char ****ppppcVar5;
  uint uVar6;
  uint uVar7;
  char ***apppcStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xc) < 1) {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar3 = (undefined4 *)(param_1 + 0x10);
    if (0xf < *(uint *)(param_1 + 0x24)) {
      puVar3 = (undefined4 *)*puVar3;
    }
    pcVar2 = "current";
    if (*(int *)(param_1 + 0xc) != 0) {
      pcVar2 = "old";
    }
    ExceptionList = &pvStack_10;
    FUN_01675640(apppcStack_40,"Gsi-%s-%s-%s",puVar3,pcVar2,param_2);
    uStack_8 = 0;
    ppppcVar5 = apppcStack_40;
    if (0xf < uStack_2c) {
      ppppcVar5 = (char ****)apppcStack_40[0];
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ppppcVar4 = ppppcVar5;
    do {
      cVar1 = *(char *)ppppcVar4;
      ppppcVar4 = (char ****)((int)ppppcVar4 + 1);
    } while (cVar1 != '\0');
    FUN_005542c0(ppppcVar5,(int)ppppcVar4 - (int)((int)ppppcVar5 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_008783f0(auStack_28,1,0);
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    if (0xf < uStack_2c) {
      uVar7 = uStack_2c + 1;
      ppppcVar5 = (char ****)apppcStack_40[0];
      if (0xfff < uVar7) {
        ppppcVar5 = (char ****)apppcStack_40[0][-1];
        uVar7 = uStack_2c + 0x24;
        if ((char *)0x1f < (char *)((int)apppcStack_40[0] + (-4 - (int)ppppcVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar5,uVar7);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10137 ; VA 0x007196d0 ; FUN_007196d0 */

void __fastcall FUN_007196d0(int param_1)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = *(code **)(param_1 + 0x3c);
  FUN_0054ef60(param_1 + 0x48);
  if (*(int *)(param_1 + 0x44) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x44) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*(undefined4 *)(param_1 + 0x40),*(undefined4 *)(param_1 + 0x44));
  return;
}



/* FUNCTION 10138 ; VA 0x00719720 ; FUN_00719720 */

/* WARNING: Removing unreachable block (ram,0x00719787) */
/* WARNING: Removing unreachable block (ram,0x0071979a) */
/* WARNING: Removing unreachable block (ram,0x007197a1) */
/* WARNING: Removing unreachable block (ram,0x007197a8) */

undefined4 __thiscall FUN_00719720(int param_1,undefined param_2)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined3 uVar3;
  undefined3 extraout_var;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 1;
  uVar2 = FUN_00587410();
  puVar1 = *(undefined **)(param_1 + 0x14);
  uStack_8 = 0;
  if (*(undefined **)(param_1 + 0x18) == puVar1) {
    FUN_007145d0(puVar1,&param_2);
    uVar3 = extraout_var;
  }
  else {
    uVar3 = (undefined3)((uint)uVar2 >> 8);
    *puVar1 = param_2;
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + 1;
  }
  ExceptionList = pvStack_10;
  return CONCAT31(uVar3,1);
}



/* FUNCTION 10139 ; VA 0x007197d0 ; FUN_007197d0 */

void __thiscall FUN_007197d0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int iVar6;
  
  FUN_00577980();
  uVar1 = *(uint *)(param_1 + 0x4c);
  uVar2 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar2 < 0x80000000) {
    if ((uVar2 != 0) && (((byte)uVar1 & 6) != 6)) {
      iVar5 = FUN_00554060(uVar2);
      FUN_0170c6f0(iVar5,param_2,uVar2);
      *(uint *)(param_1 + 0x48) = uVar2 + iVar5;
      if ((uVar1 & 4) == 0) {
        **(int **)(param_1 + 0x1c) = iVar5;
        **(int **)(param_1 + 0x2c) = iVar5;
        **(uint **)(param_1 + 0x3c) = uVar2;
      }
      if ((uVar1 & 2) == 0) {
        iVar3 = *(int *)(param_1 + 0x48);
        iVar6 = iVar5;
        if ((uVar1 & 0x18) != 0) {
          iVar6 = iVar3;
        }
        **(int **)(param_1 + 0x20) = iVar5;
        **(int **)(param_1 + 0x30) = iVar6;
        **(int **)(param_1 + 0x40) = iVar3 - iVar6;
        if ((uVar1 & 4) != 0) {
          **(int **)(param_1 + 0x1c) = iVar5;
          **(undefined4 **)(param_1 + 0x2c) = 0;
          **(int **)(param_1 + 0x3c) = iVar5;
        }
      }
      *(uint *)(param_1 + 0x4c) = uVar1 | 1;
      return;
    }
    *(uint *)(param_1 + 0x4c) = uVar1;
    *(undefined4 *)(param_1 + 0x48) = 0;
    return;
  }
  FUN_010c5e30();
  pcVar4 = (code *)swi(3);
  (*pcVar4)();
  return;
}



/* FUNCTION 10140 ; VA 0x007198c0 ; FUN_007198c0 */

undefined4 __fastcall FUN_007198c0(int param_1)

{
  uint uVar1;
  
  uVar1 = *(int *)(param_1 + 0x14) - *(int *)(param_1 + 0x10);
  return CONCAT31((int3)(uVar1 >> 8),DAT_01d5c0b4 < uVar1);
}



/* FUNCTION 10141 ; VA 0x007198d0 ; FUN_007198d0 */

void __fastcall FUN_007198d0(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00bc3c50(param_1 + 0x8c,*(int *)(param_1 + 0x9c) + 0x1ff0,param_1 + 0x7c);
  *(undefined4 *)(param_1 + 0x98) = uVar1;
  return;
}



/* FUNCTION 10142 ; VA 0x00719900 ; FUN_00719900 */

undefined4 * __thiscall
FUN_00719900(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac328;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_018e4a28;
  cVar3 = FUN_00719dd0(param_2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10143 ; VA 0x00719a70 ; FUN_00719a70 */

void __thiscall FUN_00719a70(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac340;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedAacChallengeItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10144 ; VA 0x00719ade ; Catch_All@00719ade */

void Catch_All_00719ade(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10145 ; VA 0x00719b00 ; FUN_00719b00 */

void __thiscall FUN_00719b00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac350;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedCcRequestItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10146 ; VA 0x00719b6e ; Catch_All@00719b6e */

void Catch_All_00719b6e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10147 ; VA 0x00719b90 ; FUN_00719b90 */

void __thiscall FUN_00719b90(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac360;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedIdChallengeItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10148 ; VA 0x00719bfe ; Catch_All@00719bfe */

void Catch_All_00719bfe(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10149 ; VA 0x00719c20 ; FUN_00719c20 */

void __thiscall FUN_00719c20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac370;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedNetPmcChallengeItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10150 ; VA 0x00719c8e ; Catch_All@00719c8e */

void Catch_All_00719c8e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10151 ; VA 0x00719cb0 ; FUN_00719cb0 */

void __thiscall FUN_00719cb0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac380;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedPmcConfigItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10152 ; VA 0x00719d1e ; Catch_All@00719d1e */

void Catch_All_00719d1e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10153 ; VA 0x00719d40 ; FUN_00719d40 */

void __thiscall FUN_00719d40(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac390;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedTimeoutInfoRequestItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10154 ; VA 0x00719dae ; Catch_All@00719dae */

void Catch_All_00719dae(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10155 ; VA 0x00719dd0 ; FUN_00719dd0 */

undefined FUN_00719dd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 param_10,undefined8 param_11,int *param_12)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 auStack_60 [2];
  undefined4 uStack_58;
  int *piStack_54;
  undefined uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ac3bb;
  pvStack_10 = ExceptionList;
  auStack_60[0] = param_1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_58 = param_3;
  uStack_48 = param_7;
  uStack_44 = param_8;
  uStack_40 = param_9;
  uStack_3c = param_10;
  piStack_54 = param_4;
  uStack_50 = param_5;
  uStack_38 = param_11;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar5 = FUN_00585a40(auStack_60);
  piVar2 = piStack_54;
  uVar4 = auStack_60[0];
  if (cVar5 == '\0') {
    if (piStack_54 != (int *)0x0) {
      LOCK();
      piStack_54[1] = piStack_54[1] + 1;
      UNLOCK();
    }
    uStack_18 = uStack_58;
    uStack_30 = uStack_48;
    uStack_2c = uStack_44;
    uStack_28 = uStack_40;
    uStack_24 = uStack_3c;
    uStack_11 = uStack_50;
    uStack_20 = uStack_38;
    uStack_8 = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x30);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar4;
      puVar6[2] = 0;
      puVar6[3] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      puVar6[2] = uStack_18;
      puVar6[3] = piVar2;
      puVar6[6] = uStack_30;
      puVar6[7] = uStack_2c;
      puVar6[8] = uStack_28;
      puVar6[9] = uStack_24;
      *(undefined *)(puVar6 + 4) = uStack_11;
      *(undefined8 *)(puVar6 + 10) = uStack_20;
    }
    *param_12 = (int)puVar6;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_54;
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_54[1] + -1;
      piStack_54[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar7 = 1;
  }
  else {
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_54[1] + -1;
      piStack_54[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar7 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
      ExceptionList = pvStack_10;
      return uVar7;
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 10156 ; VA 0x00719fd0 ; FUN_00719fd0 */

undefined4 * __thiscall FUN_00719fd0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  *(undefined *)(param_1 + 4) = *(undefined *)(param_2 + 4);
  uVar2 = param_2[7];
  uVar3 = param_2[8];
  uVar4 = param_2[9];
  param_1[6] = param_2[6];
  param_1[7] = uVar2;
  param_1[8] = uVar3;
  param_1[9] = uVar4;
  *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
  return param_1;
}



/* FUNCTION 10157 ; VA 0x0071a020 ; FUN_0071a020 */

undefined4 * __thiscall
FUN_0071a020(undefined4 *param_1,undefined4 param_2,int *param_3,undefined param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined *)(param_1 + 2) = param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[4] = param_5;
  param_1[5] = param_6;
  param_1[6] = param_7;
  param_1[7] = param_8;
  *(undefined8 *)(param_1 + 8) = param_9;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 10158 ; VA 0x0071a130 ; FUN_0071a130 */

undefined4 * __thiscall FUN_0071a130(undefined4 *param_1,undefined4 param_2)

{
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::AacChallengeItem::vftable;
  return param_1;
}



/* FUNCTION 10159 ; VA 0x0071a160 ; FUN_0071a160 */

undefined4 * __thiscall FUN_0071a160(undefined4 *param_1,undefined4 param_2)

{
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::ClientCrashRequestItem::vftable;
  return param_1;
}



/* FUNCTION 10160 ; VA 0x0071a190 ; FUN_0071a190 */

undefined4 * __thiscall FUN_0071a190(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::Replicator::IdChallengeItem::vftable;
  return param_1;
}



/* FUNCTION 10161 ; VA 0x0071a1c0 ; FUN_0071a1c0 */

undefined4 * __thiscall
FUN_0071a1c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  param_1[0xd] = param_4;
  *param_1 = RBX::Network::Replicator::IdResponseItem::vftable;
  return param_1;
}



/* FUNCTION 10162 ; VA 0x0071a1f0 ; FUN_0071a1f0 */

undefined4 * __thiscall FUN_0071a1f0(undefined4 *param_1,undefined4 param_2,undefined param_3)

{
  FUN_006b1a30(param_2);
  *(undefined *)(param_1 + 0xc) = param_3;
  *param_1 = RBX::Network::Replicator::NetPmcChallengeItem::vftable;
  return param_1;
}



/* FUNCTION 10163 ; VA 0x0071a220 ; FUN_0071a220 */

undefined4 * __thiscall
FUN_0071a220(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined param_6)

{
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  param_1[0xe] = param_4;
  param_1[0xf] = param_5;
  *(undefined *)(param_1 + 0x10) = param_6;
  *param_1 = RBX::Network::Replicator::NetPmcResponseItem::vftable;
  return param_1;
}



/* FUNCTION 10164 ; VA 0x0071a260 ; FUN_0071a260 */

undefined4 * __thiscall
FUN_0071a260(undefined4 *param_1,undefined4 param_2,undefined param_3,undefined4 param_4)

{
  FUN_006b1a30(param_2);
  *(undefined *)(param_1 + 0xc) = param_3;
  param_1[0xd] = param_4;
  *param_1 = RBX::Network::Replicator::PmcConfigItem::vftable;
  return param_1;
}



/* FUNCTION 10165 ; VA 0x0071a290 ; FUN_0071a290 */

undefined4 * __thiscall FUN_0071a290(undefined4 *param_1,undefined4 param_2)

{
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::TimeoutInfoRequestItem::vftable;
  return param_1;
}



/* FUNCTION 10166 ; VA 0x0071a2c0 ; FUN_0071a2c0 */

void FUN_0071a2c0(int *param_1)

{
  int *piVar1;
  undefined8 uVar2;
  undefined uVar3;
  undefined4 *puVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  
  puVar4 = (undefined4 *)*param_1;
  uVar3 = *(undefined *)(puVar4 + 4);
  uVar6 = puVar4[6];
  uVar7 = puVar4[7];
  uVar8 = puVar4[8];
  uVar9 = puVar4[9];
  pcVar5 = (code *)*puVar4;
  uVar2 = *(undefined8 *)(puVar4 + 10);
  if (puVar4[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar5)(puVar4[2],puVar4[3],uVar3,uVar6,uVar7,uVar8,uVar9,uVar2);
  return;
}



/* FUNCTION 10167 ; VA 0x0071a320 ; FUN_0071a320 */

void FUN_0071a320(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x30);
      if (iVar2 != 0) {
        iVar3 = FUN_00719fd0(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9e30c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::Network::ClientReplicator>,unsigned_char,struct_RBX::Security::NetPmcChallenge),class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Network::ClientReplicator>_>,class_boost::_bi::value<unsigned_char>,class_boost::_bi::value<struct_RBX::Security::NetPmcChallenge>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 10168 ; VA 0x0071a410 ; FUN_0071a410 */

undefined4 FUN_0071a410(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      _guard_check_icall();
    }
  }
  return 1;
}



/* FUNCTION 10169 ; VA 0x0071a450 ; FUN_0071a450 */

undefined4 __thiscall FUN_0071a450(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_006ee400(*(undefined4 *)(param_1 + 0x10));
    }
  }
  return 1;
}



/* FUNCTION 10170 ; VA 0x0071a4a0 ; FUN_0071a4a0 */

undefined4 FUN_0071a4a0(int param_1)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  code *pcVar9;
  undefined auStack_94 [28];
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_64;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  
  if (param_1 != 0) {
    iVar8 = *(int *)(param_1 + 0xc);
    iStack_74 = 0x71a4d1;
    iVar7 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
        (uint)*(ushort *)(iVar7 + 0x1da)) {
      iStack_74 = param_1;
      uStack_78 = 0x71a4f6;
      uStack_1c = FUN_008f7870();
      iStack_74 = 1;
      uVar3 = *(undefined4 *)((int)puStack_18 + 0x18);
      uVar4 = *(undefined4 *)((int)puStack_18 + 0x1c);
      uVar5 = *(undefined4 *)((int)puStack_18 + 0x20);
      uVar6 = *(undefined4 *)((int)puStack_18 + 0x24);
      uVar2 = *(undefined8 *)((int)puStack_18 + 0x28);
      uStack_11 = *(undefined *)((int)puStack_18 + 0x10);
      puStack_18 = auStack_94;
      FUN_0060dcd0(&uStack_28,param_1);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      iVar8 = FUN_0071a020(uStack_28,piStack_24,uStack_11,uVar3,uVar4,uVar5,uVar6,uVar2);
      pcVar9 = FUN_006ef0a0;
      if (*(int *)(iVar8 + 4) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(iVar8 + 4) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      if (piStack_64 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_64[1] + -1;
        piStack_64[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_64)(FUN_006ef0a0);
          LOCK();
          iVar8 = piStack_64[2] + -1;
          piStack_64[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piStack_64 + 4))();
          }
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_24[1] + -1;
        piStack_24[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piStack_24 + 2;
          iVar8 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar8 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      FUN_00719900(pcVar9);
      FUN_0090ca30();
    }
  }
  return 1;
}



/* FUNCTION 10171 ; VA 0x0071a630 ; FUN_0071a630 */

undefined4 __thiscall FUN_0071a630(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      if (*(char *)(param_1 + 0x10) == '\0') {
        FUN_00553510(*(undefined4 *)(param_1 + 0x14));
        return 1;
      }
      FUN_00553510(*(undefined4 *)(param_1 + 0x14));
    }
  }
  return 1;
}



/* FUNCTION 10172 ; VA 0x0071a690 ; FUN_0071a690 */

undefined4 FUN_0071a690(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_00554ed0();
    }
  }
  return 1;
}



/* FUNCTION 10173 ; VA 0x0071a6d0 ; FUN_0071a6d0 */

void FUN_0071a6d0(int *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_54 [36];
  undefined auStack_30 [24];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac3f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 == 0) {
LAB_0071a996:
    FUN_0054eff0("Server does not receive this item.");
    uStack_8 = 0;
    FUN_005f8ef0(auStack_30);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_54,&DAT_01c27108);
  }
  iVar5 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_005edd10();
  if ((uint)*(ushort *)(iVar2 + 0x1da) <
      (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) goto LAB_0071a996;
  cVar1 = FUN_006abe40();
  if (cVar1 == '\x01') {
    puVar3 = (undefined4 *)FUN_01674e20(0x30);
    if (puVar3 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar3[1] = 9;
      puVar3[2] = 1;
      puVar3[3] = 0;
      *puVar3 = RBX::Network::DeserializedNetPmcChallengeItem::vftable;
      puVar4 = puVar3;
    }
    iStack_18 = 0;
    iStack_14 = 0;
    FUN_00719c20(puVar4,puVar3);
    iVar5 = iStack_18;
    uStack_8 = 1;
    FUN_006f2270(param_3,iStack_18 + 0x10,iStack_18 + 0x18);
  }
  else if (cVar1 == '\x05') {
    puVar3 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar3 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar3[1] = 9;
      puVar3[2] = 1;
      puVar3[3] = 0;
      *puVar3 = RBX::Network::DeserializedIdChallengeItem::vftable;
      puVar4 = puVar3;
    }
    iStack_18 = 0;
    iStack_14 = 0;
    FUN_00719b90(puVar4,puVar3);
    iVar5 = iStack_18;
    uStack_8 = 2;
    FUN_006f2250(param_3,iStack_18 + 0x10);
  }
  else {
    if (cVar1 == '\a') {
      puVar3 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar3 == (undefined4 *)0x0) {
        puVar4 = (undefined4 *)0x0;
      }
      else {
        puVar3[1] = 9;
        puVar3[2] = 1;
        puVar3[3] = 0;
        *puVar3 = RBX::Network::DeserializedAacChallengeItem::vftable;
        puVar4 = puVar3;
      }
      iStack_18 = 0;
      iStack_14 = 0;
      FUN_00719a70(puVar4,puVar3);
      *param_1 = iStack_18;
      goto LAB_0071a79b;
    }
    if (cVar1 == '\t') {
      puVar3 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar3 == (undefined4 *)0x0) {
        puVar4 = (undefined4 *)0x0;
      }
      else {
        puVar3[1] = 9;
        puVar3[2] = 1;
        puVar3[3] = 0;
        *puVar3 = RBX::Network::DeserializedTimeoutInfoRequestItem::vftable;
        puVar4 = puVar3;
      }
      iStack_18 = 0;
      iStack_14 = 0;
      FUN_00719d40(puVar4,puVar3);
      *param_1 = iStack_18;
      goto LAB_0071a79b;
    }
    if (cVar1 == '\r') {
      puVar3 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar3 == (undefined4 *)0x0) {
        puVar4 = (undefined4 *)0x0;
      }
      else {
        puVar3[1] = 9;
        puVar3[2] = 1;
        puVar3[3] = 0;
        *puVar3 = RBX::Network::DeserializedCcRequestItem::vftable;
        puVar4 = puVar3;
      }
      iStack_18 = 0;
      iStack_14 = 0;
      FUN_00719b00(puVar4,puVar3);
      *param_1 = iStack_18;
      goto LAB_0071a79b;
    }
    puVar3 = (undefined4 *)FUN_01674e20(0x18);
    if (puVar3 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar3[1] = 9;
      puVar3[2] = 1;
      puVar3[3] = 0;
      *puVar3 = RBX::Network::DeserializedPmcConfigItem::vftable;
      puVar4 = puVar3;
    }
    iStack_18 = 0;
    iStack_14 = 0;
    FUN_00719cb0(puVar4,puVar3);
    iVar5 = iStack_18;
    uStack_8 = 3;
    FUN_006f22c0(param_3,iStack_18 + 0x10,iStack_18 + 0x14);
  }
  *param_1 = iVar5;
LAB_0071a79b:
  param_1[1] = iStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10174 ; VA 0x0071a9d0 ; FUN_0071a9d0 */

undefined4 FUN_0071a9d0(undefined4 param_1)

{
  undefined4 uStack_8;
  
  FUN_006b2070(param_1,9);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_006ad5e0(&uStack_8,1);
  return 1;
}



/* FUNCTION 10175 ; VA 0x0071aa00 ; FUN_0071aa00 */

undefined4 FUN_0071aa00(undefined4 param_1)

{
  undefined4 uStack_8;
  
  FUN_006b2070(param_1,9);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  FUN_006ad5e0(&uStack_8,1);
  return 1;
}



/* FUNCTION 10176 ; VA 0x0071aa30 ; FUN_0071aa30 */

undefined4 __thiscall FUN_0071aa30(int param_1,undefined4 param_2)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_006b2070(param_2,9);
  param_2 = CONCAT31(param_2._1_3_,5);
  FUN_006ad5e0(&param_2,1);
  param_2 = *(undefined4 *)(param_1 + 0x30);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  return 1;
}



/* FUNCTION 10177 ; VA 0x0071aa90 ; FUN_0071aa90 */

undefined4 __thiscall FUN_0071aa90(int param_1,undefined4 param_2)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_006b2070(param_2,9);
  param_2 = CONCAT31(param_2._1_3_,6);
  FUN_006ad5e0(&param_2,1);
  param_2 = *(undefined4 *)(param_1 + 0x30);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  param_2 = *(undefined4 *)(param_1 + 0x34);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  return 1;
}



/* FUNCTION 10178 ; VA 0x0071ab10 ; FUN_0071ab10 */

undefined4 __thiscall FUN_0071ab10(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined auStack_14 [8];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_006b2070(param_2,9);
  param_2._0_1_ = 1;
  FUN_006ad5e0(&param_2,1);
  param_2 = CONCAT31(param_2._1_3_,*(undefined *)(param_1 + 0x30));
  FUN_006ad5e0(&param_2,1);
  puVar1 = (undefined4 *)(DAT_01eafb60 + (uint)*(byte *)(param_1 + 0x30) * 0x18);
  param_2 = *puVar1;
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  param_2 = puVar1[1];
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  param_2 = puVar1[2];
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  uStack_c = puVar1[4];
  uStack_8 = puVar1[5];
  FUN_006a5c10(&uStack_c,auStack_14,8);
  FUN_006ad5e0(auStack_14,8);
  return 1;
}



/* FUNCTION 10179 ; VA 0x0071ac00 ; FUN_0071ac00 */

undefined4 __thiscall FUN_0071ac00(int param_1,undefined4 param_2)

{
  undefined auStack_14 [8];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_006b2070(param_2,9);
  param_2._0_1_ = 2;
  FUN_006ad5e0(&param_2,1);
  param_2 = CONCAT31(param_2._1_3_,*(undefined *)(param_1 + 0x40));
  FUN_006ad5e0(&param_2,1);
  param_2 = *(undefined4 *)(param_1 + 0x30);
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  uStack_c = *(undefined4 *)(param_1 + 0x38);
  uStack_8 = *(undefined4 *)(param_1 + 0x3c);
  FUN_006a5c10(&uStack_c,auStack_14,8);
  FUN_006ad5e0(auStack_14,8);
  return 1;
}



/* FUNCTION 10180 ; VA 0x0071aca0 ; FUN_0071aca0 */

undefined4 __thiscall FUN_0071aca0(int param_1,undefined4 param_2)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_006b2070(param_2,9);
  param_2._0_1_ = 4;
  FUN_006ad5e0(&param_2,1);
  param_2 = CONCAT31(param_2._1_3_,*(undefined *)(param_1 + 0x30));
  FUN_006ad5e0(&param_2,1);
  param_2 = *(undefined4 *)(param_1 + 0x34);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  return 1;
}



/* FUNCTION 10181 ; VA 0x0071ad10 ; FUN_0071ad10 */

undefined4 FUN_0071ad10(undefined4 param_1)

{
  undefined4 uStack_8;
  
  FUN_006b2070(param_1,9);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_006ad5e0(&uStack_8,1);
  return 1;
}



/* FUNCTION 10182 ; VA 0x0071ad40 ; FUN_0071ad40 */

int * FUN_0071ad40(uint *param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  
  piVar5 = (int *)*param_1;
  uVar3 = *(uint *)((int)piVar5 + 0x10);
  if (*(int *)((int)piVar5 + 0x14) != 0) {
    piVar5 = *(int **)((int)piVar5 + 0x20);
    puVar4 = *(undefined4 **)((int)piVar5 + param_2 * 4);
    if (puVar4 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar4;
    }
    do {
      if (piVar6 == (int *)0x0) {
        return (int *)(uint)piVar5;
      }
      piVar5 = piVar6 + 0x1c6;
      iVar2 = *piVar5 + param_1[1] * 8;
      iVar1 = iVar2 + 8;
      FUN_0170cc70(iVar2,iVar1,piVar6[0x1c7] - iVar1);
      piVar6[0x1c7] = piVar6[0x1c7] + -8;
      FUN_0071adf0(*(undefined4 *)(*param_1 + 0x34),piVar5);
      iVar1 = *piVar5;
      iVar2 = *(int *)(*param_1 + 0x34);
      *(undefined4 *)(iVar1 + -8 + iVar2 * 8) = 0;
      *(undefined4 *)(iVar1 + -4 + iVar2 * 8) = 0;
      piVar6 = (int *)*piVar6;
      piVar5 = piVar6;
    } while ((piVar6 == (int *)0x0) ||
            (piVar5 = (int *)((uint)piVar6[1] / uVar3), (uint)piVar6[1] % uVar3 == param_2));
  }
  return piVar5;
}



/* FUNCTION 10183 ; VA 0x0071adf0 ; FUN_0071adf0 */

void __thiscall FUN_0071adf0(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar2 = param_2;
  uVar5 = param_1[1];
  uVar1 = *param_1;
  uVar7 = (int)(uVar5 - uVar1) >> 3;
  uVar4 = (int)(param_1[2] - uVar1) >> 3;
  if (param_2 <= uVar4) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        param_1[1] = uVar1 + param_2 * 8;
      }
      return;
    }
    iVar3 = (param_2 - uVar7) * 8;
    FUN_0170d1f0(uVar5,0,iVar3);
    param_1[1] = uVar5 + iVar3;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar4 <= 0x1fffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar1 = uVar5 * 8;
  if (uVar5 < 0x20000000) {
    uVar5 = uVar1;
    if (0xfff < uVar1) goto LAB_0071ae62;
    if (uVar1 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar1);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_0071ae62:
    uVar4 = uVar5 + 0x23;
    if (uVar4 <= uVar5) {
      uVar4 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar4);
    if (iVar3 == 0) goto LAB_0071af5f;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  FUN_0170d1f0(uVar5 + uVar7 * 8,0,(uVar2 - uVar7) * 8);
  uVar4 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar5,uVar4,param_1[1] - uVar4);
  uVar4 = *param_1;
  if (uVar4 != 0) {
    uVar6 = param_1[2] - uVar4 & 0xfffffff8;
    uVar7 = uVar4;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uVar4 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar4 - uVar7) - 4) {
LAB_0071af5f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + uVar2 * 8;
  param_1[2] = uVar1 + uVar5;
  return;
}



/* FUNCTION 10184 ; VA 0x0071af70 ; FUN_0071af70 */

void FUN_0071af70(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_2 + 0x10);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_2 + 0x18) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_0071b00a;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0;
    *(undefined4 *)(param_2 + 0x18) = 0;
  }
  iVar1 = *(int *)(param_2 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_2 + 0xc) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_0071b00a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_2 + 4) = 0;
    *(undefined4 *)(param_2 + 8) = 0;
    *(undefined4 *)(param_2 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 10185 ; VA 0x0071b010 ; FUN_0071b010 */

void __thiscall FUN_0071b010(int param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac408;
  pvStack_10 = ExceptionList;
  uVar3 = *param_3;
  uVar8 = (uVar3 >> 3) + uVar3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar9 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar9;
    }
    if (piVar5 == (int *)0x0) goto LAB_0071b0ae;
    do {
      if (uVar8 == piVar5[1]) {
        if (uVar3 == piVar5[2]) break;
      }
      else if ((uint)piVar5[1] % *(uint *)(param_1 + 4) != uVar7) goto LAB_0071b0ae;
      piVar5 = (int *)*piVar5;
    } while (piVar5 != (int *)0x0);
  }
  if (piVar5 != (int *)0x0) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_0071b0ae:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_01674e20(0xc);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[2] = 0;
  piVar5[2] = *param_4;
  uVar7 = *(uint *)(param_1 + 8);
  uVar3 = uVar7 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar3);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar3) {
    uVar6 = uVar7 >> 1;
    if (uVar7 + (uVar7 >> 1) <= uVar3) {
      uVar6 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar6 + uVar7);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar9;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar2 = (int)puVar9;
          puVar9 = puVar1;
        }
        else {
          *puVar9 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar5[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar9 = piVar2;
    *piVar5 = *piVar2;
    *piVar2 = (int)piVar5;
  }
  else {
    *piVar5 = *piVar2;
    *(int **)*puVar9 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10186 ; VA 0x0071b200 ; FUN_0071b200 */

void __thiscall FUN_0071b200(byte *param_1,int *param_2,int param_3,undefined8 *param_4,int param_5)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac428;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00a6ce70(param_3);
  FUN_006e16e0(&param_3,uVar4,iVar7,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 != 0) {
    *(undefined *)(param_2 + 1) = 0;
    *param_2 = param_3;
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0x730);
  *piVar5 = 0;
  piVar5[1] = 0;
  FUN_0170d1f0(piVar5 + 2,0,0x728);
  iVar7 = param_5;
  *(undefined8 *)(piVar5 + 2) = *param_4;
  piVar5[4] = *(int *)(param_4 + 1);
  FUN_016f40fd(piVar5 + 6,param_5,0x1c,0x40,FUN_0071b470,FUN_006e2830);
  piVar5[0x1c6] = 0;
  piVar5[0x1c7] = 0;
  piVar5[0x1c8] = 0;
  piVar5[0x1c6] = *(int *)(iVar7 + 0x700);
  piVar5[0x1c7] = *(int *)(iVar7 + 0x704);
  piVar5[0x1c8] = *(int *)(iVar7 + 0x708);
  *(undefined4 *)(iVar7 + 0x700) = 0;
  *(undefined4 *)(iVar7 + 0x704) = 0;
  *(undefined4 *)(iVar7 + 0x708) = 0;
  piVar5[0x1ca] = *(int *)(iVar7 + 0x710);
  piVar5[0x1cb] = *(int *)(iVar7 + 0x714);
  uVar1 = *(uint *)(param_1 + 8);
  uVar6 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005d6bb0(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    uVar8 = uVar1 >> 1;
    if (uVar1 + uVar8 <= uVar6) {
      uVar8 = 1;
    }
    iVar7 = FUN_005d6bb0(uVar8 + uVar1);
    if (iVar7 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar7);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar3 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar9 = piVar3;
    *piVar5 = *piVar3;
    *piVar3 = (int)piVar5;
  }
  else {
    *piVar5 = *piVar3;
    *(int **)*puVar9 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = (int)piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10187 ; VA 0x0071b470 ; FUN_0071b470 */

undefined * __thiscall FUN_0071b470(undefined *param_1,int param_2)

{
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_2 + 0x10);
  *(undefined4 *)(param_1 + 0x14) = *(undefined4 *)(param_2 + 0x14);
  *(undefined4 *)(param_2 + 0x14) = 0;
  *(undefined4 *)(param_2 + 8) = 0;
  *(undefined4 *)(param_2 + 0x10) = 0;
  param_1[0x18] = *(undefined *)(param_2 + 0x18);
  return param_1;
}



/* FUNCTION 10188 ; VA 0x0071b4c0 ; FUN_0071b4c0 */

undefined * __fastcall FUN_0071b4c0(undefined *param_1)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  param_1[0x18] = 0;
  return param_1;
}



/* FUNCTION 10189 ; VA 0x0071b510 ; FUN_0071b510 */

undefined4 * __thiscall FUN_0071b510(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  param_1[1] = RBX::PrimitiveMovementCallback::vftable;
  param_1[2] = RBX::Voxel2::GridListener::vftable;
  *param_1 = RBX::Network::StreamingObserver::vftable;
  param_1[1] = RBX::Network::StreamingObserver::vftable;
  param_1[2] = RBX::Network::StreamingObserver::vftable;
  *(undefined *)(param_1 + 3) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[4] = uVar1;
  param_1[5] = 0;
  param_1[6] = 0x3f800000;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = param_2;
  param_1[0xc] = param_3;
  param_1[0xd] = DAT_01d5c224;
  *(undefined *)(param_1 + 0xe) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0xf] = uVar1;
  param_1[0x10] = 0;
  param_1[0x11] = 0x3f800000;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  return param_1;
}



/* FUNCTION 10190 ; VA 0x0071b5c0 ; FUN_0071b5c0 */

void __fastcall FUN_0071b5c0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_0071b760();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x730);
  }
  return;
}



/* FUNCTION 10191 ; VA 0x0071b5f0 ; FUN_0071b5f0 */

void __fastcall FUN_0071b5f0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_0071af70(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x3c);
  }
  return;
}



/* FUNCTION 10192 ; VA 0x0071b620 ; FUN_0071b620 */

void __fastcall FUN_0071b620(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0071bbe0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10193 ; VA 0x0071b6a0 ; FUN_0071b6a0 */

void __fastcall FUN_0071b6a0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0071bc30(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10194 ; VA 0x0071b720 ; FUN_0071b720 */

void __fastcall FUN_0071b720(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00617ad0();
  return;
}



/* FUNCTION 10195 ; VA 0x0071b760 ; FUN_0071b760 */

void __fastcall FUN_0071b760(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x700);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x708) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x700) = 0;
    *(undefined4 *)(param_1 + 0x704) = 0;
    *(undefined4 *)(param_1 + 0x708) = 0;
  }
  FUN_016f32d1(param_1,0x1c,0x40,FUN_006e2830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10196 ; VA 0x0071b800 ; FUN_0071b800 */

uint * __thiscall FUN_0071b800(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac448;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar8 = (uVar4 >> 3) + uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  uStack_8 = 0;
  piVar3 = (int *)FUN_01674e20(0x3c);
  *piVar3 = 0;
  piVar3[1] = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piVar3[10] = 0;
  piVar3[0xb] = 0;
  piVar3[0xc] = 0;
  piVar3[0xd] = 0;
  piVar3[0xe] = 0;
  piVar3[2] = uVar4;
  FUN_0170d1f0(piVar3 + 3,0,0x30);
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[9] = 0x7f7fffff;
  piVar3[10] = 0x7f7fffff;
  piVar3[0xb] = 0x7f7fffff;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[0xc] = -0x800001;
  piVar3[0xd] = -0x800001;
  piVar3[0xe] = -0x800001;
  uVar1 = *(uint *)(param_1 + 8);
  uVar4 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar4 = FUN_005d6bb0(uVar4);
    if (uVar4 <= *(uint *)(param_1 + 4)) {
      uVar4 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar4);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar4) {
    param_2 = (uint *)0x1;
    uVar6 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar4) {
      uVar6 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar6 + uVar1);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (puVar2 != (undefined4 *)0x0) {
        piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar7 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar7;
          *(undefined4 **)*piVar7 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar3[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar9 = piVar7;
    *piVar3 = *piVar7;
  }
  else {
    *piVar3 = *piVar7;
    piVar7 = (int *)*puVar9;
  }
  *piVar7 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (uint *)(piVar3 + 2);
}



/* FUNCTION 10197 ; VA 0x0071ba5b ; FUN_0071ba5b */

void FUN_0071ba5b(void)

{
  FUN_0071baa0();
  return;
}



/* FUNCTION 10198 ; VA 0x0071ba70 ; FUN_0071ba70 */

undefined4 __thiscall FUN_0071ba70(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x140);
  }
  return param_1;
}



/* FUNCTION 10199 ; VA 0x0071baa0 ; FUN_0071baa0 */

int __thiscall FUN_0071baa0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_0071b6a0();
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0071b620();
  *(undefined ***)(param_1 + 8) = RBX::Voxel2::GridListener::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 10200 ; VA 0x0071bb10 ; FUN_0071bb10 */

bool FUN_0071bb10(uint *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  undefined auStack_c [8];
  
  uVar4 = *param_1 & 3;
  iStack_24 = (int)*param_1 >> 2;
  iStack_20 = (int)param_1[1] >> 2;
  uVar3 = param_1[1] & 3;
  iStack_1c = (int)param_1[2] >> 2;
  uVar2 = (param_1[2] & 3) << 2;
  uStack_18 = (uVar2 | uVar3) << 2 | uVar4;
  uStack_14 = 1 << ((uVar2 & 7 | uVar3) << 2 | uVar4);
  uStack_10 = 0;
  if (0x1f < uStack_18) {
    uStack_10 = uStack_14;
  }
  uStack_14 = uStack_14 ^ uStack_10;
  if (0x3f < uStack_18) {
    uStack_10 = uStack_14;
  }
  iVar1 = FUN_0071bd90(&iStack_24);
  uVar3 = uStack_14 & *(uint *)(iVar1 + 0x710);
  uVar2 = uStack_10 & *(uint *)(iVar1 + 0x714);
  FUN_0071b010(auStack_c,&stack0x00000008,&stack0x00000008);
  *(uint *)(iVar1 + 0x710) = *(uint *)(iVar1 + 0x710) | uStack_14;
  *(uint *)(iVar1 + 0x714) = *(uint *)(iVar1 + 0x714) | uStack_10;
  return uVar3 == 0 && uVar2 == 0;
}



/* FUNCTION 10201 ; VA 0x0071bbe0 ; FUN_0071bbe0 */

int __thiscall FUN_0071bbe0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_0071b760();
    FUN_01674ea0(puVar1,0x730);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 10202 ; VA 0x0071bc30 ; FUN_0071bc30 */

int __thiscall FUN_0071bc30(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_0071af70(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x3c);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 10203 ; VA 0x0071bc90 ; FUN_0071bc90 */

int * __thiscall FUN_0071bc90(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_0071b760();
    FUN_01674ea0(piVar5,0x730);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_0071bd0a:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_0071bd0a;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 10204 ; VA 0x0071bd30 ; FUN_0071bd30 */

int FUN_0071bd30(void)

{
  int iVar1;
  
  iVar1 = FUN_0071b800(&stack0x00000004);
  return iVar1 + 0x10;
}



/* FUNCTION 10205 ; VA 0x0071bd50 ; FUN_0071bd50 */

int FUN_0071bd50(void)

{
  int iVar1;
  
  iVar1 = FUN_0071b800(&stack0x00000004);
  return iVar1 + 0x1c;
}



/* FUNCTION 10206 ; VA 0x0071bd70 ; FUN_0071bd70 */

int FUN_0071bd70(void)

{
  int iVar1;
  
  iVar1 = FUN_0071b800(&stack0x00000004);
  return iVar1 + 4;
}



/* FUNCTION 10207 ; VA 0x0071bd90 ; FUN_0071bd90 */

int __thiscall FUN_0071bd90(int param_1,undefined4 param_2)

{
  undefined auStack_730 [1792];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_20;
  int iStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac46b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0170d1f0(auStack_730,0,0x718);
  FUN_016f4053(auStack_730,0x1c,0x40,FUN_0071b4c0,FUN_006e2830);
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_20 = 0;
  uStack_8 = 0;
  FUN_0071b200(&iStack_18,param_2,param_2,auStack_730);
  uStack_8 = 0xffffffff;
  FUN_0071b760();
  if (cStack_14 != '\0') {
    FUN_0071adf0(*(undefined4 *)(param_1 + 0x34),iStack_18 + 0x718);
    ExceptionList = pvStack_10;
    return iStack_18 + 0x18;
  }
  ExceptionList = pvStack_10;
  return iStack_18 + 0x18;
}



/* FUNCTION 10208 ; VA 0x0071be80 ; thunk_FUN_0071dc50 */

void __fastcall thunk_FUN_0071dc50(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  float fVar4;
  
  fVar4 = (float)DAT_01d5c22c / DAT_018ce320;
  if (DAT_01eafb8c != '\0') {
    FUN_01677520(DAT_01eafb8c,"Step resize job. cap = %d threshold = %f reps = %d",
                 *(undefined4 *)(param_1 + 0x34),(double)fVar4,
                 *(int *)(*(int *)(param_1 + 0x30) + 0x1c0) -
                 *(int *)(*(int *)(param_1 + 0x30) + 0x1bc) >> 2);
  }
  iVar1 = *(int *)(*(int *)(param_1 + 0x30) + 0x1c0) - *(int *)(*(int *)(param_1 + 0x30) + 0x1bc);
  if ((float)((double)*(int *)(param_1 + 0x34) +
             (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x34) >> 0x1f)]) * fVar4 <=
      (float)((double)(iVar1 >> 2) + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)])) {
    fVar4 = (float)DAT_01d5c234 / DAT_018ce320;
    uVar2 = FUN_016f3cd0();
    *(undefined4 *)(param_1 + 0x34) = uVar2;
    if (DAT_01eafb8c != '\0') {
      FUN_01677520(DAT_01eafb8c,"Growing. mult = %f newcap = %d",(double)fVar4,uVar2);
    }
    if (*(int *)(param_1 + 0x14) == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x10) * 4);
    }
    for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
      FUN_0071adf0(*(undefined4 *)(param_1 + 0x34),puVar3 + 0x1c6);
    }
  }
  return;
}



/* FUNCTION 10209 ; VA 0x0071be90 ; FUN_0071be90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0071be90(int param_1)

{
  undefined auVar1 [16];
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined (*pauVar7) [12];
  undefined4 *puVar8;
  double *pdVar9;
  int iVar10;
  int *piVar11;
  undefined auVar12 [16];
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar18;
  float fVar19;
  undefined in_XMM2 [16];
  undefined auVar17 [16];
  uint uVar20;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  undefined auVar21 [16];
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  undefined8 uStack_88;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 *puStack_58;
  undefined8 uStack_54;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  double dStack_38;
  double dStack_30;
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac4a2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uStack_1c = FUN_01675290();
  uStack_8 = 0;
  FUN_016827e0();
  iVar6 = *(int *)(param_1 + 0x2c);
  iVar10 = *(int *)(*(int *)(iVar6 + 0x1b8) + 0x1b4);
  piVar11 = *(int **)(iVar10 + 200);
  piStack_24 = piVar11 + *(int *)(iVar10 + 0xcc);
  if (piVar11 != piStack_24) {
    do {
      iVar6 = (**(code **)(**(int **)(*piVar11 + 0x1ac) + 8))();
      if (iVar6 != 10) {
        pauVar7 = (undefined (*) [12])FUN_00c15960();
        fVar25 = SUB164(_DAT_018e0060,0);
        fVar26 = SUB164(_DAT_018e0060,4);
        fVar27 = SUB164(_DAT_018e0060,8);
        fVar28 = SUB164(_DAT_018e0060,0xc);
        auVar17 = rcpps(in_XMM2,_DAT_018e0060);
        fVar18 = auVar17._0_4_;
        fVar19 = auVar17._4_4_;
        fVar29 = auVar17._8_4_;
        fVar30 = auVar17._12_4_;
        fVar13 = (_DAT_018e0050 - fVar18 * fVar25) * fVar18;
        fVar14 = (_UNK_018e0054 - fVar19 * fVar26) * fVar19;
        fVar15 = (_UNK_018e0058 - fVar29 * fVar27) * fVar29;
        fVar16 = (_UNK_018e005c - fVar30 * fVar28) * fVar30;
        uVar20 = -(uint)((float)(~DAT_018c4ea0 & (uint)fVar13) < _DAT_018e0080) &
                 ((uint)fVar13 ^ (uint)fVar18) ^ (uint)fVar18;
        uVar22 = -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar14) < _UNK_018e0084) &
                 ((uint)fVar14 ^ (uint)fVar19) ^ (uint)fVar19;
        uVar23 = -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar15) < _UNK_018e0088) &
                 ((uint)fVar15 ^ (uint)fVar29) ^ (uint)fVar29;
        uVar24 = -(uint)((float)(~_UNK_018c4eac & (uint)fVar16) < _UNK_018e008c) &
                 ((uint)fVar16 ^ (uint)fVar30) ^ (uint)fVar30;
        fVar29 = (float)((DAT_018c4ea0 & (uint)fVar25 ^ uVar20) &
                         -(uint)((float)(~DAT_018c4ea0 & (uint)fVar25) == _DAT_018e0080) ^ uVar20);
        fVar30 = (float)((_UNK_018c4ea4 & (uint)fVar26 ^ uVar22) &
                         -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar26) == _UNK_018e0084) ^ uVar22);
        fVar25 = (float)((_UNK_018c4ea8 & (uint)fVar27 ^ uVar23) &
                         -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar27) == _UNK_018e0088) ^ uVar23);
        auVar21._0_8_ = CONCAT44(0.0 - SUB164(_DAT_018e0070,4),0.0 - SUB164(_DAT_018e0070,0));
        auVar21._8_4_ = 0.0 - SUB164(_DAT_018e0070,8);
        auVar21._12_4_ = 0.0 - SUB164(_DAT_018e0070,0xc);
        auVar12._8_4_ = auVar21._8_4_;
        auVar12._0_8_ = auVar21._0_8_;
        auVar12._12_4_ = auVar21._12_4_;
        auVar17._12_4_ = 0;
        auVar17._0_12_ = *pauVar7;
        auVar17 = maxps(auVar12,auVar17);
        auVar17 = minps(_DAT_018e0070,auVar17);
        fVar16 = auVar17._0_4_ * fVar29;
        fVar18 = auVar17._4_4_ * fVar30;
        fVar19 = auVar17._8_4_ * fVar25;
        fVar13 = (float)(int)fVar16;
        fVar14 = (float)(int)fVar18;
        fVar15 = (float)(int)fVar19;
        iStack_70 = (int)(fVar13 - (float)(_DAT_018e0040 & -(uint)(fVar16 < fVar13)));
        iStack_6c = (int)(fVar14 - (float)(_UNK_018e0044 & -(uint)(fVar18 < fVar14)));
        iStack_80 = (int)(fVar15 - (float)(_UNK_018e0048 & -(uint)(fVar19 < fVar15)));
        auVar1._4_4_ = *(undefined4 *)(pauVar7[1] + 4);
        auVar1._0_4_ = *(undefined4 *)pauVar7[1];
        auVar1._8_4_ = *(undefined4 *)(pauVar7[1] + 8);
        auVar1._12_4_ = 0;
        auVar17 = maxps(auVar21,auVar1);
        auVar17 = minps(_DAT_018e0070,auVar17);
        in_XMM2._0_4_ = auVar17._0_4_ * fVar29;
        in_XMM2._4_4_ = auVar17._4_4_ * fVar30;
        in_XMM2._8_4_ = auVar17._8_4_ * fVar25;
        in_XMM2._12_4_ =
             auVar17._12_4_ *
             (float)((_UNK_018c4eac & (uint)fVar28 ^ uVar24) &
                     -(uint)((float)(~_UNK_018c4eac & (uint)fVar28) == _UNK_018e008c) ^ uVar24);
        iStack_64 = (int)((float)(_DAT_018e0040 & -(uint)((float)(int)in_XMM2._0_4_ < in_XMM2._0_4_)
                                 ) + (float)(int)in_XMM2._0_4_);
        iStack_60 = (int)((float)(_UNK_018e0044 & -(uint)((float)(int)in_XMM2._4_4_ < in_XMM2._4_4_)
                                 ) + (float)(int)in_XMM2._4_4_);
        iStack_5c = (int)((float)(_UNK_018e0048 & -(uint)((float)(int)in_XMM2._8_4_ < in_XMM2._8_4_)
                                 ) + (float)(int)in_XMM2._8_4_);
        if (((iStack_70 < iStack_64) && (iStack_6c < iStack_60)) && (iStack_80 < iStack_5c)) {
          iStack_5c = iStack_5c + -1;
          iStack_60 = iStack_60 + -1;
          iStack_64 = iStack_64 + -1;
          iStack_3c = iStack_64;
          dStack_38._0_4_ = iStack_60;
        }
        uStack_88 = CONCAT44(iStack_6c,iStack_70);
        puStack_58 = &uStack_88;
        iStack_20 = iStack_5c + 1;
        piStack_18 = (int *)(iStack_60 + 1);
        iStack_7c = iStack_64;
        iStack_78 = iStack_60;
        iStack_74 = iStack_5c;
        iStack_68 = iStack_80;
        uStack_54 = uStack_88;
        iStack_4c = iStack_80;
        while (((param_1 = iStack_14, (int)uStack_54 != iStack_64 + 1 ||
                ((int *)uStack_54._4_4_ != piStack_18)) || (iStack_4c != iStack_20))) {
          FUN_0071bb10();
          FUN_00ca2620();
        }
        if (((DAT_01d5b9c0 != '\0') && (cVar5 = FUN_00ca1a80(), cVar5 != '\0')) &&
           ((iVar6 = FUN_00c155c0(), iVar6 != 0 &&
            ((cVar5 = FUN_00c1a1b0(), cVar5 != '\0' &&
             (piStack_18 = (int *)FUN_00b06640(), piStack_18 != (int *)0x0)))))) {
          iStack_20 = (int)piStack_18;
          iVar6 = FUN_0071b800();
          FUN_008b3b70();
          FUN_008b3a50(piStack_18);
          puVar8 = (undefined4 *)FUN_008b3b00(&iStack_70,piStack_18);
          uVar2 = puVar8[1];
          uVar3 = puVar8[2];
          uVar4 = puVar8[3];
          *(undefined4 *)(iVar6 + 0x1c) = *puVar8;
          *(undefined4 *)(iVar6 + 0x20) = uVar2;
          *(undefined4 *)(iVar6 + 0x24) = uVar3;
          *(undefined4 *)(iVar6 + 0x28) = uVar4;
          uVar2 = puVar8[5];
          *(undefined4 *)(iVar6 + 0x2c) = puVar8[4];
          *(undefined4 *)(iVar6 + 0x30) = uVar2;
          param_1 = iStack_14;
        }
      }
      piVar11 = piVar11 + 1;
    } while (piVar11 != piStack_24);
    iVar6 = *(int *)(param_1 + 0x2c);
  }
  if (DAT_01d69070 == '\0') {
    (**(code **)(**(int **)(*(int *)(*(int *)(*(int *)(iVar6 + 0x1b8) + 0x1b4) + 0x6ac) + 0x154) +
                0x58))();
  }
  else {
    FUN_007c8c00();
  }
  pdVar9 = (double *)FUN_016827e0();
  dStack_38 = *pdVar9 - dStack_30;
  piStack_18 = (int *)FUN_00a9d3e0();
  if (piStack_18 != (int *)0x0) {
    iVar6 = *(int *)((int)piStack_18 + 0xc);
    iVar10 = FUN_00af0010();
    if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
        (uint)*(ushort *)(iVar10 + 0x1da)) goto LAB_0071c22d;
  }
  piStack_18 = (int *)0x0;
LAB_0071c22d:
  FUN_00a70e60();
  uStack_8._0_1_ = 1;
  piStack_24 = (int *)iStack_44;
  iStack_20 = iStack_48;
  if (iStack_48 != iStack_44) {
    do {
      FUN_00a70da0();
      iVar6 = iStack_74;
      puStack_58 = &uStack_88;
      uStack_54 = uStack_88;
      iStack_4c = iStack_80;
      iStack_64 = iStack_7c;
      iStack_60 = iStack_78;
      while ((((int)uStack_54 != iStack_64 || (uStack_54._4_4_ != iStack_60)) ||
             (iStack_4c != iVar6))) {
        FUN_0071da80();
        FUN_00a6e100();
      }
      iStack_20 = iStack_20 + 0x18;
    } while ((int *)iStack_20 != piStack_24);
  }
  iVar6 = iStack_14;
  FUN_00a6e300();
  piVar11 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 2;
  if (piVar11 == (int *)0x0) {
    piStack_18 = (int *)0x0;
  }
  else {
    piVar11[1] = 1;
    piVar11[2] = 1;
    *piVar11 = (int)std::_Ref_count_obj<class_RBX::Network::StreamingObserver::ResizeJob>::vftable;
    piStack_24 = piVar11;
    piStack_18 = piVar11;
    FUN_005c4330(&stack0xffffff64,*(undefined4 *)(iStack_14 + 0x2c));
    FUN_00a360a0("StreamingObserverResizeJob",1,0);
    piVar11[4] = (int)RBX::Network::StreamingObserver::ResizeJob::vftable;
    piVar11[0x4e] = iStack_14;
    iVar6 = iStack_14;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((piStack_18 + 4 != (int *)0x0) &&
     ((iVar6 = iStack_14, piStack_18[7] == 0 || (*(int *)(piStack_18[7] + 4) == 0)))) {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[2] = piStack_18[2] + 1;
        UNLOCK();
      }
    }
    piStack_18[6] = (int)(piStack_18 + 4);
    piStack_24 = (int *)piStack_18[7];
    piStack_18[7] = (int)piStack_18;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_24[2] + -1;
      piStack_24[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_18[1] + -1;
      piStack_18[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar10 = piStack_18[2] + -1;
        piStack_18[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  *(int **)(iVar6 + 0x24) = piStack_18 + 4;
  piStack_24 = *(int **)(iVar6 + 0x28);
  *(int **)(iVar6 + 0x28) = piStack_18;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_24[1] + -1;
    piStack_24[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar11 = piStack_24 + 2;
      iVar10 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (*(int *)(iVar6 + 0x28) != 0) {
    LOCK();
    piVar11 = (int *)(*(int *)(iVar6 + 0x28) + 4);
    *piVar11 = *piVar11 + 1;
    UNLOCK();
  }
  FUN_0151d950();
  if (DAT_01ee420a != '\0') {
    FUN_016827e0();
    FUN_01677520(DAT_01ee420a,"Initialized StreamingObserver. Physics: %.3fms Total: %.3fms",
                 dStack_38 * DAT_018c0d70);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (iStack_48 != 0) {
    if ((0xfff < (uint)(((iStack_40 - iStack_48) / 0x18) * 0x18)) &&
       (0x1f < (iStack_48 - *(int *)(iStack_48 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
    iStack_48 = 0;
    iStack_44 = 0;
    iStack_40 = 0;
  }
  uStack_8 = 3;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10210 ; VA 0x0071c520 ; FUN_0071c520 */

uint __thiscall FUN_0071c520(int param_1,int param_2,uint *param_3)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar6 = *param_3 & 3;
  iStack_1c = (int)*param_3 >> 2;
  iStack_18 = (int)param_3[1] >> 2;
  uVar4 = param_3[1] & 3;
  iStack_14 = (int)param_3[2] >> 2;
  uVar3 = (param_3[2] & 3) << 2;
  uStack_10 = (uVar3 | uVar4) << 2 | uVar6;
  uStack_c = 1 << ((uVar3 & 7 | uVar4) << 2 | uVar6);
  uStack_8 = 0;
  if (0x1f < uStack_10) {
    uStack_8 = uStack_c;
  }
  uStack_c = uStack_c ^ uStack_8;
  if (0x3f < uStack_10) {
    uStack_8 = uStack_c;
  }
  iVar5 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar2 = FUN_00a6ce70(&iStack_1c);
  FUN_006e16e0(&param_3,uVar2,&iStack_1c,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if ((param_3 != (uint *)0x0) &&
     (puVar1 = param_3 + 0x1c6,
     param_3 = (uint *)(*(uint *)(*puVar1 + 4 + *(int *)(param_2 + 0x18e8) * 8) & uStack_8),
     (*(uint *)(*puVar1 + *(int *)(param_2 + 0x18e8) * 8) & uStack_c) != 0 || param_3 != (uint *)0x0
     )) {
    return CONCAT31((int3)((uint)param_3 >> 8),1);
  }
  return (uint)param_3 & 0xffffff00;
}



/* FUNCTION 10211 ; VA 0x0071c5f0 ; FUN_0071c5f0 */

bool __fastcall FUN_0071c5f0(int *param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 8))();
  return iVar1 == 10;
}



/* FUNCTION 10212 ; VA 0x0071c600 ; FUN_0071c600 */

void __thiscall FUN_0071c600(int param_1,uint param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_20 [24];
  int iStack_8;
  
  uVar5 = param_2;
  iVar7 = param_1 + 0x39 + (uint)*(byte *)(param_1 + 0x38);
  FUN_00606ea0(&iStack_8,(param_2 >> 3) + param_2,&param_2,-(uint)(iVar7 != 0) & iVar7 + 1U);
  if (iStack_8 != 0) {
    puVar6 = (undefined4 *)FUN_008b3b00(auStack_20,uVar5);
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    uVar1 = *(undefined8 *)(puVar6 + 4);
    *(undefined4 *)(iStack_8 + 0x24) = *puVar6;
    *(undefined4 *)(iStack_8 + 0x28) = uVar2;
    *(undefined4 *)(iStack_8 + 0x2c) = uVar3;
    *(undefined4 *)(iStack_8 + 0x30) = uVar4;
    *(undefined8 *)(iStack_8 + 0x34) = uVar1;
  }
  return;
}



/* FUNCTION 10213 ; VA 0x0071c670 ; FUN_0071c670 */

void __thiscall FUN_0071c670(int param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  if (*(int *)(param_1 + 0x40) != 0) {
    uVar2 = (param_2 >> 3) + param_2;
    uVar5 = uVar2 % *(uint *)(param_1 + 0x3c);
    piVar6 = *(int **)(uVar5 * 4 + *(int *)(param_1 + 0x4c));
    if ((piVar6 != (int *)0x0) && (piVar1 = (int *)*piVar6, (int *)*piVar6 != (int *)0x0)) {
      while (piVar4 = piVar1, (uint)piVar4[1] % *(uint *)(param_1 + 0x3c) == uVar5) {
        if ((piVar4[1] == uVar2) && (param_2 == piVar4[2])) {
          FUN_0071bc30(piVar6,*piVar4);
          if (*piVar6 != 0) {
            uVar2 = *(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 0x3c);
            if (uVar5 == uVar2) {
              return;
            }
            *(int **)(*(int *)(param_1 + 0x4c) + uVar2 * 4) = piVar6;
          }
          puVar3 = (undefined4 *)(*(int *)(param_1 + 0x4c) + uVar5 * 4);
          if ((int *)*puVar3 != piVar6) {
            return;
          }
          *puVar3 = 0;
          return;
        }
        piVar1 = (int *)*piVar4;
        piVar6 = piVar4;
        if ((int *)*piVar4 == (int *)0x0) {
          return;
        }
      }
    }
  }
  return;
}



/* FUNCTION 10214 ; VA 0x0071c730 ; FUN_0071c730 */

void FUN_0071c730(undefined4 param_1,undefined4 param_2,char param_3)

{
  undefined8 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined auStack_8c [4];
  undefined4 uStack_88;
  undefined4 *puStack_84;
  undefined4 *puStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  int *piStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  undefined8 uStack_64;
  int *piStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  undefined8 uStack_4c;
  undefined auStack_44 [8];
  int **ppiStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac4cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_01675290(DAT_01eaf294);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_006e77c0(auStack_44,param_2);
  piStack_5c = (int *)*puVar3;
  iStack_58 = puVar3[1];
  iStack_54 = puVar3[2];
  iStack_50 = puVar3[3];
  uVar1 = *(undefined8 *)(puVar3 + 4);
  uStack_4c._0_4_ = (int)uVar1;
  uStack_4c._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
  uStack_4c = uVar1;
  iStack_30 = iStack_54;
  piStack_38 = piStack_5c;
  iStack_34 = iStack_58;
  if (param_3 == '\0') {
    ppiStack_3c = &piStack_5c;
    iVar8 = uStack_4c._4_4_ + 1;
    iVar4 = (int)uStack_4c + 1;
    piVar7 = (int *)(iStack_50 + 1);
    while (((piStack_38 != piVar7 || (iStack_34 != iVar4)) ||
           (uVar6 = uStack_18, iStack_30 != iVar8))) {
      FUN_0071d860(&piStack_38,param_1);
      FUN_00ca2620();
    }
  }
  else {
    puVar10 = (undefined4 *)0x0;
    uStack_2c = 0;
    puStack_28 = (undefined4 *)0x0;
    puStack_24 = (undefined4 *)0x0;
    ppiStack_3c = &piStack_5c;
    iVar8 = uStack_4c._4_4_ + 1;
    puVar3 = (undefined4 *)0x0;
    iVar4 = (int)uStack_4c + 1;
    uStack_8._0_1_ = 1;
    piStack_1c = (int *)(iStack_50 + 1);
    while (((piStack_38 != piStack_1c || (iStack_34 != iVar4)) || (iStack_30 != iVar8))) {
      iVar5 = FUN_0071bb10(&piStack_38,param_1);
      if (iVar5 == 1) {
        if (puVar3 == puVar10) {
          FUN_00706320(puVar10,&piStack_38);
          puVar3 = puStack_24;
          puVar10 = puStack_28;
        }
        else {
          *puVar10 = piStack_38;
          puVar10[1] = iStack_34;
          puVar10[2] = iStack_30;
          puStack_28 = puVar10 + 3;
          puVar10 = puStack_28;
        }
      }
      FUN_00ca2620();
    }
    iStack_68 = 0;
    uStack_88 = 0;
    puStack_84 = (undefined4 *)0x0;
    puStack_80 = (undefined4 *)0x0;
    uStack_7c = 0;
    piStack_78 = (int *)0x0;
    piStack_74 = (int *)0x0;
    iStack_70 = 0;
    iStack_6c = 0;
    uStack_64 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    auStack_8c[0] = 0;
    FUN_00617ad0();
    uStack_88 = uStack_2c;
    puStack_80 = puStack_24;
    uStack_2c = 0;
    puStack_28 = (undefined4 *)0x0;
    puStack_24 = (undefined4 *)0x0;
    puStack_84 = puVar10;
    uVar6 = FUN_00b06640(param_1);
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar6);
    uVar6 = uStack_18;
    piVar2 = piStack_78;
    uStack_7c = *puVar3;
    piVar7 = (int *)puVar3[1];
    *puVar3 = 0;
    puVar3[1] = 0;
    if (piStack_78 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_78[1] + -1;
      piStack_78[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puVar3 = (undefined4 *)*piStack_78;
        piStack_78 = piVar7;
        (*(code *)*puVar3)();
        LOCK();
        piVar7 = piVar2 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        piVar7 = piStack_78;
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
          piVar7 = piStack_78;
        }
      }
    }
    piStack_78 = piVar7;
    piVar7 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piVar7 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    _param_3 = 0;
    piStack_74 = piStack_5c;
    iStack_70 = iStack_58;
    iStack_6c = iStack_54;
    iStack_68 = iStack_50;
    uStack_64 = uStack_4c;
    piVar7 = *(int **)(*(int *)(iStack_14 + 0x2c) + 0x1bc);
    piVar2 = *(int **)(*(int *)(iStack_14 + 0x2c) + 0x1c0);
    uVar9 = (uint)((int)piVar2 + (3 - (int)piVar7)) >> 2;
    if (piVar2 < piVar7) {
      uVar9 = 0;
    }
    if (uVar9 != 0) {
      do {
        if (*(int *)(*piVar7 + 0x1de4) != 0) {
          FUN_006e6480(auStack_8c);
        }
        _param_3 = _param_3 + 1;
        piVar7 = piVar7 + 1;
      } while (_param_3 != uVar9);
    }
    piVar7 = piStack_78;
    if (piStack_78 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_78[1] + -1;
      piStack_78[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_78)();
        LOCK();
        piVar2 = piVar7 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_00617ad0();
    FUN_00617ad0();
  }
  uStack_8 = 3;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10215 ; VA 0x0071ca50 ; FUN_0071ca50 */

void FUN_0071ca50(uint param_1,float *param_2,float *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  bool bVar10;
  undefined auStack_a8 [4];
  undefined4 uStack_a4;
  undefined4 *puStack_a0;
  undefined4 *puStack_9c;
  undefined4 uStack_98;
  int *piStack_94;
  int *piStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  undefined8 uStack_60;
  undefined auStack_58 [4];
  int *piStack_54;
  int *piStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  undefined8 uStack_40;
  undefined auStack_38 [8];
  int **ppiStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac4fb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01eaf294);
  uStack_8 = 0;
  uStack_78 = uVar2;
  if (((((NAN(*param_2) || NAN(*param_3)) == (*param_2 == *param_3)) ||
       ((NAN(param_2[1]) || NAN(param_3[1])) == (param_2[1] == param_3[1]))) ||
      ((NAN(param_2[2]) || NAN(param_3[2])) == (param_2[2] == param_3[2]))) ||
     ((((NAN(param_2[3]) || NAN(param_3[3])) == (param_2[3] == param_3[3]) ||
       ((NAN(param_2[4]) || NAN(param_3[4])) == (param_2[4] == param_3[4]))) ||
      ((NAN(param_2[5]) || NAN(param_3[5])) == (param_2[5] == param_3[5]))))) {
    piVar3 = (int *)FUN_006e77c0(auStack_38,param_2);
    piStack_70 = (int *)*piVar3;
    iStack_6c = piVar3[1];
    iStack_68 = piVar3[2];
    iStack_64 = piVar3[3];
    uStack_60 = *(undefined8 *)(piVar3 + 4);
    piVar3 = (int *)FUN_006e77c0(auStack_38,param_3);
    piStack_50 = (int *)*piVar3;
    iStack_4c = piVar3[1];
    iStack_48 = piVar3[2];
    iStack_44 = piVar3[3];
    uStack_40 = *(undefined8 *)(piVar3 + 4);
    if (((piStack_70 != piStack_50) || (iStack_6c != iStack_4c)) ||
       ((iStack_68 != iStack_48 ||
        (((iStack_64 != iStack_44 || ((int)uStack_60 != (int)uStack_40)) ||
         (uStack_40._4_4_ = (int)((ulonglong)uStack_40 >> 0x20),
         bVar10 = uStack_60._4_4_ != uStack_40._4_4_, bVar10)))))) {
      piStack_2c = piStack_70;
      iStack_28 = iStack_6c;
      ppiStack_30 = &piStack_70;
      piStack_54 = (int *)(uStack_60._4_4_ + 1);
      iStack_74 = (int)uStack_60 + 1;
      piVar3 = (int *)(iStack_64 + 1);
      iStack_24 = iStack_68;
      while( true ) {
        if (((piStack_2c == piVar3) && (iStack_28 == iStack_74)) && ((int *)iStack_24 == piStack_54)
           ) break;
        if ((((int)piStack_2c < (int)piStack_50) || (iStack_44 < (int)piStack_2c)) ||
           ((iStack_28 < iStack_4c ||
            ((((int)uStack_40 < iStack_28 || (iStack_24 < iStack_48)) ||
             (uStack_40._4_4_ < iStack_24)))))) {
          FUN_0071d860(&piStack_2c,param_1);
        }
        FUN_00ca2620();
      }
      puVar9 = (undefined4 *)0x0;
      uStack_1c = 0;
      puStack_18 = (undefined4 *)0x0;
      puStack_14 = (undefined4 *)0x0;
      ppiStack_30 = &piStack_50;
      puVar8 = (undefined4 *)0x0;
      iVar5 = uStack_40._4_4_ + 1;
      uStack_8._0_1_ = 2;
      iVar6 = (int)uStack_40 + 1;
      _piStack_2c = CONCAT44(iStack_4c,piStack_50);
      piStack_54 = (int *)(iStack_44 + 1);
      iStack_24 = iStack_48;
      while( true ) {
        if (((piStack_2c == piStack_54) && (iStack_28 == iVar6)) && (iStack_24 == iVar5)) break;
        if (((((((int)piStack_2c < (int)piStack_70) || (iStack_64 < (int)piStack_2c)) ||
              (iStack_28 < iStack_6c)) || (((int)uStack_60 < iStack_28 || (iStack_24 < iStack_68))))
            || (uStack_60._4_4_ < iStack_24)) &&
           (iVar4 = FUN_0071bb10(&piStack_2c,param_1), iVar4 == 1)) {
          if (puVar8 == puVar9) {
            FUN_00706320(puVar9,&piStack_2c);
            puVar8 = puStack_14;
            puVar9 = puStack_18;
            goto LAB_0071ccb0;
          }
          *puVar9 = piStack_2c;
          puVar9[1] = iStack_28;
          puVar9[2] = iStack_24;
          puVar9 = puVar9 + 3;
          puStack_18 = puVar9;
          FUN_00ca2620();
        }
        else {
LAB_0071ccb0:
          FUN_00ca2620();
        }
      }
      iStack_84 = 0;
      uStack_a4 = 0;
      puStack_a0 = (undefined4 *)0x0;
      puStack_9c = (undefined4 *)0x0;
      uStack_98 = 0;
      piStack_94 = (int *)0x0;
      piStack_90 = (int *)0x0;
      iStack_8c = 0;
      iStack_88 = 0;
      uStack_80 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      auStack_a8[0] = 0;
      FUN_00617ad0();
      uStack_a4 = uStack_1c;
      puStack_9c = puStack_14;
      uStack_1c = 0;
      puStack_18 = (undefined4 *)0x0;
      puStack_14 = (undefined4 *)0x0;
      puStack_a0 = puVar9;
      uVar2 = FUN_00b06640(param_1);
      puVar8 = (undefined4 *)FUN_0060dcd0(auStack_58,uVar2);
      uVar2 = uStack_78;
      piVar1 = piStack_94;
      uStack_98 = *puVar8;
      piVar3 = (int *)puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      if (piStack_94 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_94[1] + -1;
        piStack_94[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          puVar8 = (undefined4 *)*piStack_94;
          piStack_94 = piVar3;
          (*(code *)*puVar8)();
          LOCK();
          piVar3 = piVar1 + 2;
          iVar5 = *piVar3 + -1;
          *piVar3 = iVar5;
          UNLOCK();
          piVar3 = piStack_94;
          if (iVar5 == 0) {
            (**(code **)(*piVar1 + 4))();
            piVar3 = piStack_94;
          }
        }
      }
      piStack_94 = piVar3;
      piVar3 = piStack_54;
      if (piStack_54 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_54[1] + -1;
        piStack_54[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_54)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      param_1 = 0;
      piStack_90 = piStack_50;
      iStack_8c = iStack_4c;
      iStack_88 = iStack_48;
      iStack_84 = iStack_44;
      uStack_80 = uStack_40;
      piVar3 = *(int **)(*(int *)(iStack_20 + 0x2c) + 0x1bc);
      piVar1 = *(int **)(*(int *)(iStack_20 + 0x2c) + 0x1c0);
      uVar7 = (uint)((int)piVar1 + (3 - (int)piVar3)) >> 2;
      if (piVar1 < piVar3) {
        uVar7 = 0;
      }
      if (uVar7 != 0) {
        do {
          if (*(int *)(*piVar3 + 0x1de4) != 0) {
            FUN_006e6480(auStack_a8);
          }
          param_1 = param_1 + 1;
          piVar3 = piVar3 + 1;
        } while (param_1 != uVar7);
      }
      piVar3 = piStack_94;
      if (piStack_94 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_94[1] + -1;
        piStack_94[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_94)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_00617ad0();
      FUN_00617ad0();
    }
  }
  uStack_8 = 4;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10216 ; VA 0x0071ce90 ; FUN_0071ce90 */

/* WARNING: Removing unreachable block (ram,0x0071d25d) */
/* WARNING: Removing unreachable block (ram,0x0071d264) */
/* WARNING: Removing unreachable block (ram,0x0071d274) */
/* WARNING: Removing unreachable block (ram,0x0071d27b) */

void FUN_0071ce90(undefined4 param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  undefined8 *puVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined auStack_7c [4];
  int *piStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [8];
  undefined8 *puStack_68;
  int *piStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  undefined8 uStack_34;
  int iStack_2c;
  int iStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac52b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_74 = FUN_01675290();
  uStack_8 = 0;
  if (((param_2[5] < param_2[2]) || (param_2[6] < param_2[3])) || (param_2[7] < param_2[4])) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  iVar4 = *param_2;
  if (((iVar4 != 1) && (iVar4 != 2)) || (!bVar2)) {
    iStack_40 = 0;
    uStack_3c = 0;
    iStack_28 = 0;
    uStack_24 = 0;
    if ((iVar4 == 1) || (iVar4 == 2)) {
      puVar3 = (undefined8 *)
               FUN_0070f2b0(auStack_70,param_2[2],param_2[3],param_2[4],param_2[5],
                            *(undefined8 *)(param_2 + 6));
      uStack_4c = *puVar3;
      iStack_44 = *(int *)(puVar3 + 1);
      iStack_40 = *(int *)((int)puVar3 + 0xc);
      uStack_3c = puVar3[2];
      iVar4 = *param_2;
    }
    else {
      uStack_1c = 1;
      puStack_18 = (undefined4 *)0x1;
      uStack_4c = 0x100000001;
      iStack_44 = 1;
    }
    if ((iVar4 == 1) || (iVar4 == 0)) {
      puVar3 = (undefined8 *)
               FUN_0070f2b0(auStack_70,param_2[9],param_2[10],param_2[0xb],param_2[0xc],
                            *(undefined8 *)(param_2 + 0xd));
      uStack_34 = *puVar3;
      iStack_2c = *(int *)(puVar3 + 1);
      iStack_28 = *(int *)((int)puVar3 + 0xc);
      uStack_24 = puVar3[2];
      iVar4 = *param_2;
    }
    else {
      uStack_1c = 1;
      puStack_18 = (undefined4 *)0x1;
      uStack_34 = 0x100000001;
      iStack_2c = 1;
    }
    if ((((((iVar4 != 1) || ((int *)uStack_4c != (int *)uStack_34)) ||
          (uStack_4c._4_4_ != uStack_34._4_4_)) ||
         ((iStack_44 != iStack_2c || (iStack_40 != iStack_28)))) ||
        ((int)uStack_3c != (int)uStack_24)) || (uStack_3c._4_4_ != uStack_24._4_4_)) {
      if ((iVar4 == 1) || (iVar4 == 2)) {
        puStack_68 = &uStack_4c;
        iStack_58 = uStack_3c._4_4_ + 1;
        piStack_64 = (int *)uStack_4c;
        iStack_60 = uStack_4c._4_4_;
        iStack_54 = (int)uStack_3c + 1;
        iStack_5c = iStack_44;
        piVar7 = (int *)(iStack_40 + 1);
        while (((piStack_64 != piVar7 || (iStack_60 != iStack_54)) || (iStack_5c != iStack_58))) {
          if (((((int)piStack_64 < (int)(int *)uStack_34) || (iStack_28 < (int)piStack_64)) ||
              ((iStack_60 < uStack_34._4_4_ ||
               (((int)uStack_24 < iStack_60 || (iStack_5c < iStack_2c)))))) ||
             (uStack_24._4_4_ < iStack_5c)) {
            FUN_0071d860(&piStack_64,param_1);
          }
          FUN_00ca2620();
        }
        iVar4 = *param_2;
      }
      puVar9 = (undefined4 *)0x0;
      uStack_1c = 0;
      puStack_18 = (undefined4 *)0x0;
      puStack_14 = (undefined4 *)0x0;
      uStack_8._0_1_ = 3;
      if ((iVar4 == 1) || (iVar4 == 0)) {
        puStack_68 = &uStack_34;
        puVar8 = (undefined4 *)0x0;
        iStack_54 = uStack_24._4_4_ + 1;
        piStack_64 = (int *)uStack_34;
        iStack_60 = uStack_34._4_4_;
        iStack_58 = (int)uStack_24 + 1;
        piStack_78 = (int *)(iStack_28 + 1);
        iStack_5c = iStack_2c;
        while (((piStack_64 != piStack_78 || (iStack_60 != iStack_58)) || (iStack_5c != iStack_54)))
        {
          if ((((((int)piStack_64 < (int)(int *)uStack_4c) || (iStack_40 < (int)piStack_64)) ||
               ((iStack_60 < uStack_4c._4_4_ ||
                (((int)uStack_3c < iStack_60 || (iStack_5c < iStack_44)))))) ||
              (uStack_3c._4_4_ < iStack_5c)) &&
             (iVar4 = FUN_0071bb10(&piStack_64,param_1), iVar4 == 1)) {
            if (puVar8 == puVar9) {
              FUN_00706320(puVar9,&piStack_64);
              puVar8 = puStack_14;
              puVar9 = puStack_18;
              goto LAB_0071d189;
            }
            *puVar9 = piStack_64;
            puVar9[1] = iStack_60;
            puVar9[2] = iStack_5c;
            puVar9 = puVar9 + 3;
            puStack_18 = puVar9;
            FUN_00ca2620();
          }
          else {
LAB_0071d189:
            FUN_00ca2620();
          }
        }
        iVar4 = *param_2;
      }
      if ((iVar4 == 1) || (iVar4 == 0)) {
        uStack_8._0_1_ = 4;
        FUN_00617ad0();
        uStack_1c = 0;
        puStack_18 = (undefined4 *)0x0;
        puStack_14 = (undefined4 *)0x0;
        uVar5 = FUN_00b06640();
        puVar9 = (undefined4 *)FUN_0060dcd0(auStack_7c,uVar5);
        piVar10 = piStack_78;
        piVar7 = (int *)puVar9[1];
        *puVar9 = 0;
        puVar9[1] = 0;
        if (piStack_78 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_78[1] + -1;
          piStack_78[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_78)();
            LOCK();
            piVar1 = piVar10 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
        param_2 = (int *)0x0;
        piVar10 = *(int **)(*(int *)(iStack_50 + 0x30) + 0x1bc);
        piVar1 = *(int **)(*(int *)(iStack_50 + 0x30) + 0x1c0);
        uVar6 = (uint)((int)piVar1 + (3 - (int)piVar10)) >> 2;
        if (piVar1 < piVar10) {
          uVar6 = 0;
        }
        if (uVar6 != 0) {
          do {
            if (*(int *)(*piVar10 + 0x1de4) != 0) {
              FUN_006e6480();
            }
            param_2 = (int *)((int)param_2 + 1);
            piVar10 = piVar10 + 1;
          } while (param_2 != (int *)uVar6);
        }
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar4 = piVar7[1] + -1;
          piVar7[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            piVar10 = piVar7 + 2;
            iVar4 = *piVar10;
            *piVar10 = *piVar10 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        FUN_00617ad0();
      }
      FUN_00617ad0();
    }
  }
  uStack_8 = 5;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10217 ; VA 0x0071d380 ; FUN_0071d380 */

void FUN_0071d380(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined auStack_dc [16];
  int iStack_cc;
  int *piStack_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b4;
  int iStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  undefined8 uStack_9c;
  uint uStack_94;
  undefined8 uStack_90;
  uint uStack_88;
  int iStack_84;
  int iStack_80;
  undefined auStack_78 [4];
  undefined auStack_74 [4];
  undefined8 *puStack_70;
  undefined8 *puStack_6c;
  undefined8 *puStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  undefined8 *puStack_20;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac55b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eaf294);
  uStack_8 = 0;
  uStack_2c = uVar3;
  if (param_2 == 0) {
    param_2 = FUN_00a9d3e0();
    if ((param_2 == 0) ||
       (iVar6 = *(int *)(param_2 + 0xc), iVar4 = FUN_00af0010(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
      param_2 = 0;
    }
    puStack_70 = (undefined8 *)0x0;
    puStack_6c = (undefined8 *)0x0;
    puStack_68 = (undefined8 *)0x0;
    uStack_64 = 0;
    piStack_60 = (int *)0x0;
    uStack_4c = 0;
    uStack_5c = 0;
    uStack_58 = 0;
    uStack_54 = 0;
    uStack_50 = 0;
    uStack_48 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    auStack_74[0] = 1;
    FUN_00a70da0(&uStack_9c,4);
    puStack_20 = &uStack_9c;
    uStack_1c = uStack_9c;
    uStack_14 = uStack_94;
    uStack_c0 = uStack_90;
    uStack_28 = uStack_88;
    while( true ) {
      uVar3 = uStack_2c;
      if ((((uint)uStack_1c == (int)uStack_c0) && (uStack_1c._4_4_ == uStack_c0._4_4_)) &&
         (uStack_14 == uStack_28)) break;
      iStack_84 = (uint)uStack_1c * 0x10;
      iStack_a8 = iStack_84 + 0x10;
      iStack_80 = uStack_1c._4_4_ * 0x10;
      iStack_ac = uStack_14 * 0x10;
      iStack_a4 = iStack_80 + 0x10;
      uStack_b4 = CONCAT44(iStack_80,iStack_84);
      iStack_a0 = iStack_ac + 0x10;
      FUN_00a71760(auStack_dc,&uStack_b4,0,1);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (iStack_cc == 0) {
        iStack_3c = (int)uStack_14 >> 2;
        iStack_44 = (int)(uint)uStack_1c >> 2;
        uVar5 = (uStack_14 & 3) << 2;
        iStack_40 = (int)uStack_1c._4_4_ >> 2;
        uStack_38 = (uVar5 | uStack_1c._4_4_ & 3) << 2 | (uint)uStack_1c & 3;
        uStack_34 = 1 << ((uVar5 & 7 | uStack_1c._4_4_ & 3) << 2 | (uint)uStack_1c & 3);
        uStack_30 = 0;
        if (0x1f < uStack_38) {
          uStack_30 = uStack_34;
        }
        uStack_34 = uStack_34 ^ uStack_30;
        if (0x3f < uStack_38) {
          uStack_30 = uStack_34;
        }
        iVar6 = iStack_24 + 5 + (uint)*(byte *)(iStack_24 + 4);
        uVar3 = FUN_00a6ce70(&iStack_44);
        FUN_006e16e0(&param_1,uVar3,&iStack_44,-(uint)(iVar6 != 0) & iVar6 + 1U);
        if (param_1 != 0) {
          *(undefined *)(param_1 + 0x30 + uStack_38 * 0x1c) = 0;
          if ((*(int *)(param_1 + 0x20 + uStack_38 * 0x1c) == 0) &&
             (*(char *)(param_1 + 0x30 + uStack_38 * 0x1c) == '\0')) {
            *(uint *)(param_1 + 0x728) = *(uint *)(param_1 + 0x728) & ~uStack_34;
            *(uint *)(param_1 + 0x72c) = *(uint *)(param_1 + 0x72c) & ~uStack_30;
          }
          if (*(int *)(param_1 + 0x728) == 0 && *(int *)(param_1 + 0x72c) == 0) {
            FUN_0071bc90(auStack_78,param_1);
          }
        }
      }
      else {
        iVar6 = FUN_0071da80(&uStack_1c);
        if (iVar6 == 1) {
          if (puStack_68 == puStack_6c) {
            FUN_00706320(puStack_6c,&uStack_1c);
          }
          else {
            *puStack_6c = uStack_1c;
            *(uint *)(puStack_6c + 1) = uStack_14;
            puStack_6c = (undefined8 *)((int)puStack_6c + 0xc);
          }
        }
      }
      piVar2 = piStack_c8;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (piStack_c8 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_c8[1] + -1;
        piStack_c8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_c8)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_00a6e100();
    }
    if (puStack_70 != puStack_6c) {
      FUN_0071da20(auStack_74);
    }
    piVar2 = piStack_60;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_60[1] + -1;
      piStack_60[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_00617ad0();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10218 ; VA 0x0071d6f0 ; FUN_0071d6f0 */

int FUN_0071d6f0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [24];
  
  iVar4 = FUN_0071b800(&param_1);
  uVar1 = param_1;
  FUN_008b3b70(param_1,iVar4 + 4);
  FUN_008b3a50(uVar1,iVar4 + 0x10);
  puVar5 = (undefined4 *)FUN_008b3b00(auStack_1c,uVar1);
  uVar1 = puVar5[1];
  uVar2 = puVar5[2];
  uVar3 = puVar5[3];
  *(undefined4 *)(iVar4 + 0x1c) = *puVar5;
  *(undefined4 *)(iVar4 + 0x20) = uVar1;
  *(undefined4 *)(iVar4 + 0x24) = uVar2;
  *(undefined4 *)(iVar4 + 0x28) = uVar3;
  *(undefined8 *)(iVar4 + 0x2c) = *(undefined8 *)(puVar5 + 4);
  return iVar4 + 4;
}



/* FUNCTION 10219 ; VA 0x0071d750 ; FUN_0071d750 */

void __thiscall FUN_0071d750(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006d5250(param_1,param_3);
  return;
}



/* FUNCTION 10220 ; VA 0x0071d790 ; FUN_0071d790 */

undefined __thiscall FUN_0071d790(int param_1,undefined4 param_2,uint *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar5 = *param_3 & 3;
  iStack_1c = (int)*param_3 >> 2;
  iStack_18 = (int)param_3[1] >> 2;
  uVar3 = param_3[1] & 3;
  iStack_14 = (int)param_3[2] >> 2;
  uVar2 = (param_3[2] & 3) << 2;
  uStack_10 = (uVar2 | uVar3) << 2 | uVar5;
  uStack_c = 1 << ((uVar2 & 7 | uVar3) << 2 | uVar5);
  uStack_8 = 0;
  if (0x1f < uStack_10) {
    uStack_8 = uStack_c;
  }
  uStack_c = uStack_c ^ uStack_8;
  if (0x3f < uStack_10) {
    uStack_8 = uStack_c;
  }
  iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar1 = FUN_00a6ce70(&iStack_1c);
  FUN_006e16e0(&param_3,uVar1,&iStack_1c,-(uint)(iVar4 != 0) & iVar4 + 1U);
  if ((param_3 != (uint *)0x0) &&
     ((param_3[uStack_10 * 7 + 8] != 0 || (*(char *)(param_3 + uStack_10 * 7 + 0xc) != '\0')))) {
    return *(undefined *)(param_3 + uStack_10 * 7 + 0xc);
  }
  return 0;
}



/* FUNCTION 10221 ; VA 0x0071d860 ; FUN_0071d860 */

void __thiscall FUN_0071d860(int param_1,uint *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar9 = *param_2 & 3;
  iStack_30 = (int)*param_2 >> 2;
  iStack_2c = (int)param_2[1] >> 2;
  uVar7 = param_2[1] & 3;
  iStack_28 = (int)param_2[2] >> 2;
  uVar6 = (param_2[2] & 3) << 2;
  uStack_24 = (uVar6 | uVar7) << 2 | uVar9;
  uStack_20 = 1 << ((uVar6 & 7 | uVar7) << 2 | uVar9);
  uStack_1c = 0;
  if (0x1f < uStack_24) {
    uStack_1c = uStack_20;
  }
  uStack_20 = uStack_20 ^ uStack_1c;
  if (0x3f < uStack_24) {
    uStack_1c = uStack_20;
  }
  iVar8 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar3 = FUN_00a6ce70(&iStack_30);
  FUN_006e16e0(&uStack_8,uVar3,&iStack_30,-(uint)(iVar8 != 0) & iVar8 + 1U);
  uVar6 = uStack_8;
  if (uStack_8 == 0) {
    return;
  }
  iVar5 = uStack_24 * 7 + 6;
  iVar8 = uStack_8 + iVar5 * 4;
  iStack_14 = iVar8;
  if (*(int *)(uStack_8 + 8 + iVar5 * 4) != 0) {
    uStack_c = *(uint *)(iVar8 + 4);
    uStack_10 = (param_3 >> 3) + param_3;
    uStack_8 = uStack_10 % uStack_c;
    iStack_18 = uStack_8 * 4;
    piVar1 = *(int **)(iStack_18 + *(int *)(iVar8 + 0x14));
    if (piVar1 != (int *)0x0) {
      piVar2 = (int *)*piVar1;
      while( true ) {
        if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % uStack_c != uStack_8)) goto LAB_0071d979;
        if ((piVar2[1] == uStack_10) && (param_3 == piVar2[2])) break;
        piVar1 = piVar2;
        piVar2 = (int *)*piVar2;
      }
      FUN_006e4ef0(piVar1,*piVar2);
      if (*piVar1 != 0) {
        uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(iVar8 + 4);
        if (uStack_8 == uVar7) goto LAB_0071d979;
        *(int **)(*(int *)(iVar8 + 0x14) + uVar7 * 4) = piVar1;
      }
      puVar4 = (undefined4 *)(*(int *)(iVar8 + 0x14) + iStack_18);
      if ((int *)*puVar4 == piVar1) {
        *puVar4 = 0;
      }
    }
  }
LAB_0071d979:
  if ((*(int *)(uVar6 + 0x20 + uStack_24 * 0x1c) == 0) &&
     (*(char *)(uVar6 + 0x30 + uStack_24 * 0x1c) == '\0')) {
    *(uint *)(uVar6 + 0x728) = *(uint *)(uVar6 + 0x728) & ~uStack_20;
    *(uint *)(uVar6 + 0x72c) = *(uint *)(uVar6 + 0x72c) & ~uStack_1c;
  }
  if (*(int *)(uVar6 + 0x728) == 0 && *(int *)(uVar6 + 0x72c) == 0) {
    FUN_0071bc90(&param_3,uVar6);
  }
  return;
}



/* FUNCTION 10222 ; VA 0x0071da20 ; FUN_0071da20 */

void __thiscall FUN_0071da20(int param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  
  piVar3 = *(int **)(*(int *)(param_1 + 0x30) + 0x1bc);
  uVar4 = 0;
  piVar1 = *(int **)(*(int *)(param_1 + 0x30) + 0x1c0);
  uVar2 = (uint)((int)piVar1 + (3 - (int)piVar3)) >> 2;
  if (piVar1 < piVar3) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    do {
      if (*(int *)(*piVar3 + 0x1de4) != 0) {
        FUN_006e6480(param_2);
      }
      uVar4 = uVar4 + 1;
      piVar3 = piVar3 + 1;
    } while (uVar4 != uVar2);
  }
  return;
}



/* FUNCTION 10223 ; VA 0x0071da80 ; FUN_0071da80 */

bool FUN_0071da80(uint *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar4 = *param_1 & 3;
  iStack_1c = (int)*param_1 >> 2;
  iStack_18 = (int)param_1[1] >> 2;
  uVar3 = param_1[1] & 3;
  iStack_14 = (int)param_1[2] >> 2;
  uVar2 = (param_1[2] & 3) << 2;
  uStack_10 = (uVar2 | uVar3) << 2 | uVar4;
  uStack_c = 1 << ((uVar2 & 7 | uVar3) << 2 | uVar4);
  uStack_8 = 0;
  if (0x1f < uStack_10) {
    uStack_8 = uStack_c;
  }
  uStack_c = uStack_c ^ uStack_8;
  if (0x3f < uStack_10) {
    uStack_8 = uStack_c;
  }
  iVar1 = FUN_0071bd90(&iStack_1c);
  uVar2 = *(uint *)(iVar1 + 0x710);
  uVar3 = *(uint *)(iVar1 + 0x714);
  *(undefined *)(iVar1 + 0x18 + uStack_10 * 0x1c) = 1;
  *(uint *)(iVar1 + 0x710) = *(uint *)(iVar1 + 0x710) | uStack_c;
  *(uint *)(iVar1 + 0x714) = *(uint *)(iVar1 + 0x714) | uStack_8;
  return (uStack_c & uVar2) == 0 && (uStack_8 & uVar3) == 0;
}



/* FUNCTION 10224 ; VA 0x0071db40 ; FUN_0071db40 */

void __thiscall FUN_0071db40(int param_1,int param_2,uint *param_3,char param_4)

{
  undefined4 uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar6 = *param_3 & 3;
  iStack_1c = (int)*param_3 >> 2;
  iStack_18 = (int)param_3[1] >> 2;
  uVar4 = param_3[1] & 3;
  iStack_14 = (int)param_3[2] >> 2;
  uVar3 = (param_3[2] & 3) << 2;
  uStack_10 = (uVar3 | uVar4) << 2 | uVar6;
  uStack_c = 1 << ((uVar3 & 7 | uVar4) << 2 | uVar6);
  uStack_8 = 0;
  if (0x1f < uStack_10) {
    uStack_8 = uStack_c;
  }
  uStack_c = uStack_c ^ uStack_8;
  if (0x3f < uStack_10) {
    uStack_8 = uStack_c;
  }
  iVar5 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar1 = FUN_00a6ce70(&iStack_1c);
  FUN_006e16e0(&param_3,uVar1,&iStack_1c,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (param_3 != (uint *)0x0) {
    iVar5 = *(int *)(param_2 + 0x18e8) * 8;
    if (param_4 != '\0') {
      puVar2 = (uint *)(iVar5 + param_3[0x1c6]);
      *puVar2 = *puVar2 | uStack_c;
      puVar2[1] = puVar2[1] | uStack_8;
      return;
    }
    puVar2 = (uint *)(param_3[0x1c6] + iVar5);
    *puVar2 = *puVar2 & ~uStack_c;
    puVar2[1] = puVar2[1] & ~uStack_8;
  }
  return;
}



/* FUNCTION 10225 ; VA 0x0071dc30 ; FUN_0071dc30 */

undefined4 FUN_0071dc30(void)

{
  FUN_0071dc50();
  return 1;
}



/* FUNCTION 10226 ; VA 0x0071dc50 ; FUN_0071dc50 */

void __fastcall FUN_0071dc50(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  float fVar4;
  
  fVar4 = (float)DAT_01d5c22c / DAT_018ce320;
  if (DAT_01eafb8c != '\0') {
    FUN_01677520(DAT_01eafb8c,"Step resize job. cap = %d threshold = %f reps = %d",
                 *(undefined4 *)(param_1 + 0x34),(double)fVar4,
                 *(int *)(*(int *)(param_1 + 0x30) + 0x1c0) -
                 *(int *)(*(int *)(param_1 + 0x30) + 0x1bc) >> 2);
  }
  iVar1 = *(int *)(*(int *)(param_1 + 0x30) + 0x1c0) - *(int *)(*(int *)(param_1 + 0x30) + 0x1bc);
  if ((float)((double)*(int *)(param_1 + 0x34) +
             (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x34) >> 0x1f)]) * fVar4 <=
      (float)((double)(iVar1 >> 2) + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)])) {
    fVar4 = (float)DAT_01d5c234 / DAT_018ce320;
    uVar2 = FUN_016f3cd0();
    *(undefined4 *)(param_1 + 0x34) = uVar2;
    if (DAT_01eafb8c != '\0') {
      FUN_01677520(DAT_01eafb8c,"Growing. mult = %f newcap = %d",(double)fVar4,uVar2);
    }
    if (*(int *)(param_1 + 0x14) == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x10) * 4);
    }
    for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
      FUN_0071adf0(*(undefined4 *)(param_1 + 0x34),puVar3 + 0x1c6);
    }
  }
  return;
}



/* FUNCTION 10227 ; VA 0x0071dda0 ; FUN_0071dda0 */

void __fastcall FUN_0071dda0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac578;
  pvStack_10 = ExceptionList;
  piVar8 = *(int **)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = *(int **)(param_1 + 0x28);
  }
  uVar3 = *(undefined4 *)(param_1 + 0x24);
  uStack_8 = 0;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  FUN_0151dac0(uVar3,piVar8,1,0);
  uStack_8 = 0xffffffff;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = piVar8[1] + -1;
    piVar8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar5 = piVar8[2] + -1;
      piVar8[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  piVar8 = *(int **)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = piVar8[1] + -1;
    piVar8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  iVar5 = *(int *)(*(int *)(param_1 + 0x2c) + 0x1b8);
  if (iVar5 != 0) {
    iVar5 = *(int *)(iVar5 + 0x1b4);
    if (iVar5 != 0) {
      if (DAT_01d69070 == '\0') {
        iVar5 = *(int *)(iVar5 + 0x6ac);
        if ((iVar5 != 0) && (piVar8 = *(int **)(iVar5 + 0x154), piVar8 != (int *)0x0)) {
          (**(code **)(*piVar8 + 0x5c))(param_1);
        }
      }
      else {
        FUN_00bbd5e0(param_1 + 4);
      }
    }
    iVar5 = FUN_00a9d3e0();
    if (((iVar5 != 0) &&
        (iVar4 = *(int *)(iVar5 + 0xc), iVar6 = FUN_00af0010(),
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da))) && (*(int *)(iVar5 + 0x134) != 0)) {
      FUN_00a6f530(param_1 + 8);
    }
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    FUN_0071bbe0(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x10) * 4,0);
    puVar7 = *(undefined4 **)(param_1 + 0x20);
    puVar2 = puVar7 + *(int *)(param_1 + 0x10);
    for (; puVar7 != puVar2; puVar7 = puVar7 + 1) {
      *puVar7 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10228 ; VA 0x0071df50 ; FUN_0071df50 */

undefined4 __thiscall
FUN_0071df50(int param_1,int param_2,uint *param_3,int *param_4,undefined *param_5)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar6 = *param_3 & 3;
  iStack_1c = (int)*param_3 >> 2;
  iStack_18 = (int)param_3[1] >> 2;
  uVar4 = param_3[1] & 3;
  iStack_14 = (int)param_3[2] >> 2;
  uVar3 = (param_3[2] & 3) << 2;
  uStack_10 = (uVar3 | uVar4) << 2 | uVar6;
  uStack_c = 1 << ((uVar3 & 7 | uVar4) << 2 | uVar6);
  uStack_8 = 0;
  if (0x1f < uStack_10) {
    uStack_8 = uStack_c;
  }
  uStack_c = uStack_c ^ uStack_8;
  if (0x3f < uStack_10) {
    uStack_8 = uStack_c;
  }
  iVar5 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar2 = FUN_00a6ce70(&iStack_1c);
  FUN_006e16e0(&param_3,uVar2,&iStack_1c,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (param_3 != (uint *)0x0) {
    uVar3 = *(uint *)(param_3[0x1c6] + *(int *)(param_2 + 0x18e8) * 8);
    puVar1 = (uint *)(param_3[0x1c6] + *(int *)(param_2 + 0x18e8) * 8);
    if ((((uVar3 & uStack_c) != uStack_c) || ((puVar1[1] & uStack_8) != uStack_8)) &&
       ((param_3[uStack_10 * 7 + 8] != 0 || (*(char *)(param_3 + uStack_10 * 7 + 0xc) != '\0')))) {
      *puVar1 = uVar3 | uStack_c;
      puVar1[1] = puVar1[1] | uStack_8;
      *param_4 = (int)(param_3 + uStack_10 * 7 + 6);
      *param_5 = *(undefined *)(param_3 + uStack_10 * 7 + 0xc);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 10229 ; VA 0x0071e070 ; FUN_0071e070 */

undefined4 FUN_0071e070(undefined4 param_1,undefined4 param_2)

{
  FUN_0071e310(param_2,&stack0x0000000c);
  return param_1;
}



/* FUNCTION 10230 ; VA 0x0071e090 ; FUN_0071e090 */

undefined4 * __fastcall FUN_0071e090(undefined4 *param_1)

{
  *param_1 = &DAT_01d60880;
  return param_1;
}



/* FUNCTION 10231 ; VA 0x0071e0a0 ; FUN_0071e0a0 */

void FUN_0071e0a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0071e4a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10232 ; VA 0x0071e0d0 ; FUN_0071e0d0 */

int * __thiscall FUN_0071e0d0(int *param_1,int *param_2)

{
  int iVar1;
  
  FUN_0071e4a0();
  if ((undefined *)*param_2 != &DAT_01d60880) {
    FUN_00722910();
    iVar1 = *param_2;
    if (*(int *)(iVar1 + 4) == 0) {
      *param_1 = (int)&DAT_01d60880;
      FUN_00722920();
      return param_1;
    }
    *param_1 = iVar1;
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    FUN_00722920();
  }
  return param_1;
}



/* FUNCTION 10233 ; VA 0x0071e130 ; FUN_0071e130 */

int * __thiscall FUN_0071e130(int *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  FUN_0071e4a0();
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    pcVar2 = param_2;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    FUN_0071e190(pcVar2 + (1 - (int)(param_2 + 1)));
    FUN_0170c6f0(*(undefined4 *)(*param_1 + 0x10),param_2,pcVar2 + (1 - (int)(param_2 + 1)));
    return param_1;
  }
  *param_1 = (int)&DAT_01d60880;
  return param_1;
}



/* FUNCTION 10234 ; VA 0x0071e190 ; FUN_0071e190 */

void __thiscall FUN_0071e190(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac59f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0071e5d0();
  FUN_00722910();
  if (DAT_01eafbe8 == 0) {
    iVar4 = 0x80;
    do {
      puVar1 = (undefined4 *)FUN_01674f30(0x84);
      puStack_14 = puVar1;
      iVar2 = FUN_01674e20(0x18);
      uStack_8 = 0;
      if (iVar2 == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = FUN_007228f0();
      }
      *puVar1 = uVar3;
      uStack_8 = 0xffffffff;
      FUN_005fdf80(&puStack_14,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakString.cpp"
                   ,0x430);
      iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
  }
  *param_1 = *(int *)(DAT_01eafbe4 + -4 + DAT_01eafbe8 * 4);
  if (DAT_01eafbe8 - 1 < DAT_01eafbe8) {
    DAT_01eafbe8 = DAT_01eafbe8 - 1;
  }
  FUN_0071e5d0();
  FUN_00722920();
  *(undefined4 *)(*param_1 + 4) = 1;
  if (0x70 < param_2) {
    *(uint *)(*param_1 + 8) = param_2 * 2;
    uVar3 = FUN_01674f30(*(undefined4 *)(*param_1 + 8));
    *(undefined4 *)(*param_1 + 0xc) = uVar3;
    *(undefined4 *)(*param_1 + 0x10) = *(undefined4 *)(*param_1 + 0xc);
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(*param_1 + 8) = 0x70;
  *(int *)(*param_1 + 0x10) = *param_1 + 0x14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10235 ; VA 0x0071e2c0 ; FUN_0071e2c0 */

void __thiscall FUN_0071e2c0(int *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    pcVar2 = param_2;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    FUN_0071e190(pcVar2 + (1 - (int)(param_2 + 1)));
    FUN_0170c6f0(*(undefined4 *)(*param_1 + 0x10),param_2,pcVar2 + (1 - (int)(param_2 + 1)));
    return;
  }
  *param_1 = (int)&DAT_01d60880;
  return;
}



/* FUNCTION 10236 ; VA 0x0071e310 ; FUN_0071e310 */

void __thiscall FUN_0071e310(int *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  char acStack_20c [512];
  uint *puStack_c;
  int iStack_8;
  
  puStack_c = (uint *)FUN_005574c0();
  iVar2 = FUN_0171d0ba(*puStack_c | 1,puStack_c[1],acStack_20c,0x200,param_2,0,param_3);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  if (iVar2 != -1) {
    if (acStack_20c[0] == '\0') {
      *param_1 = (int)&DAT_01d60880;
      return;
    }
    pcVar5 = acStack_20c;
    do {
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    FUN_0071e190(pcVar5 + (1 - (int)(acStack_20c + 1)));
    FUN_0170c6f0(*(undefined4 *)(*param_1 + 0x10),acStack_20c,pcVar5 + (1 - (int)(acStack_20c + 1)))
    ;
    return;
  }
  iVar2 = 0x1fa0;
  iStack_8 = 0;
  for (iVar3 = FUN_01675190(0,0x1fa0); iVar3 != 0; iVar3 = FUN_01675190(iVar3,iVar2)) {
    iStack_8 = iVar3;
    iVar4 = FUN_0171d0ba(*puStack_c | 1,puStack_c[1],iVar3,iVar2,param_2,0,param_3);
    if (iVar4 < 0) {
      iVar4 = -1;
    }
    if (iVar4 != -1) goto LAB_0071e41d;
    iVar2 = iVar2 * 2;
  }
  FUN_006a35a0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakString.cpp"
               ,0x466);
  iVar3 = iStack_8;
  if (iStack_8 == 0) {
    if (acStack_20c[0] == '\0') {
      *param_1 = (int)&DAT_01d60880;
      return;
    }
    pcVar5 = acStack_20c;
    do {
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    FUN_0071e190(pcVar5 + (1 - (int)(acStack_20c + 1)));
    FUN_0170c6f0(*(undefined4 *)(*param_1 + 0x10),acStack_20c,pcVar5 + (1 - (int)(acStack_20c + 1)))
    ;
    return;
  }
LAB_0071e41d:
  FUN_0071e2c0(iVar3);
  FUN_01674ea0(iVar3);
  return;
}



/* FUNCTION 10237 ; VA 0x0071e490 ; thunk_FUN_0071e4a0 */

void __fastcall thunk_FUN_0071e4a0(int *param_1)

{
  int iVar1;
  
  if ((undefined *)*param_1 != &DAT_01d60880) {
    FUN_00722910();
    *(int *)(*param_1 + 4) = *(int *)(*param_1 + 4) + -1;
    iVar1 = *(int *)(*param_1 + 4);
    FUN_00722920();
    if (iVar1 == 0) {
      if (0x70 < *(uint *)(*param_1 + 8)) {
        FUN_01674ea0(*(undefined4 *)(*param_1 + 0xc));
      }
      FUN_0071e5d0();
      FUN_00722910();
      FUN_005fdf80(param_1,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakString.cpp"
                   ,0x4d8);
      FUN_0071e5d0();
      FUN_00722920();
    }
    *param_1 = (int)&DAT_01d60880;
  }
  return;
}



/* FUNCTION 10238 ; VA 0x0071e4a0 ; FUN_0071e4a0 */

void __fastcall FUN_0071e4a0(int *param_1)

{
  int iVar1;
  
  if ((undefined *)*param_1 != &DAT_01d60880) {
    FUN_00722910();
    *(int *)(*param_1 + 4) = *(int *)(*param_1 + 4) + -1;
    iVar1 = *(int *)(*param_1 + 4);
    FUN_00722920();
    if (iVar1 == 0) {
      if (0x70 < *(uint *)(*param_1 + 8)) {
        FUN_01674ea0(*(undefined4 *)(*param_1 + 0xc));
      }
      FUN_0071e5d0();
      FUN_00722910();
      FUN_005fdf80(param_1,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakString.cpp"
                   ,0x4d8);
      FUN_0071e5d0();
      FUN_00722920();
    }
    *param_1 = (int)&DAT_01d60880;
  }
  return;
}



/* FUNCTION 10239 ; VA 0x0071e520 ; FUN_0071e520 */

void FUN_0071e520(void)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = 0;
  if (DAT_01eafbe8 != 0) {
    do {
      iVar1 = **(int **)(DAT_01eafbe4 + uVar2 * 4);
      if (iVar1 != 0) {
        FUN_00722900();
        FUN_01674ea0(iVar1,0x18);
      }
      FUN_01674ea0(*(undefined4 *)(DAT_01eafbe4 + uVar2 * 4));
      uVar2 = uVar2 + 1;
    } while (uVar2 < DAT_01eafbe8);
  }
  if (DAT_01eafbec != 0) {
    FUN_01674ea0(DAT_01eafbe4);
    DAT_01eafbec = 0;
    DAT_01eafbe4 = 0;
    DAT_01eafbe8 = 0;
  }
  return;
}



/* FUNCTION 10240 ; VA 0x0071e5b0 ; FUN_0071e5b0 */

int __fastcall FUN_0071e5b0(int *param_1)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  
  pcVar3 = *(char **)(*param_1 + 0x10);
  pcVar1 = pcVar3 + 1;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  return (int)pcVar3 - (int)pcVar1;
}



/* FUNCTION 10241 ; VA 0x0071e5d0 ; FUN_0071e5d0 */

undefined * FUN_0071e5d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac5bc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafc0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eafc0c);
    if (DAT_01eafc0c == -1) {
      uStack_8 = 0;
      FUN_007228f0();
      FUN_016f3654(&LAB_0187ecd0);
      FUN_016f37bf(&DAT_01eafc0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eafbf4;
}



/* FUNCTION 10242 ; VA 0x0071e660 ; FUN_0071e660 */

undefined4 __thiscall FUN_0071e660(int *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  int iVar4;
  char cVar5;
  
  if ((param_2 != (char *)0x0) && (cVar5 = *param_2, cVar5 != '\0')) {
    pcVar3 = param_2;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    if ((uint)((int)pcVar3 - (int)(param_2 + 1)) < 0x10) {
      iVar4 = 0;
      pcVar3 = *(char **)(*param_1 + 0x10);
      if (*pcVar3 == cVar5) {
        pcVar2 = param_2;
        do {
          if (cVar5 == '\0') {
            return 1;
          }
          cVar5 = pcVar2[1];
          pcVar2 = pcVar2 + 1;
          iVar4 = iVar4 + 1;
        } while (pcVar2[(int)pcVar3 - (int)param_2] == cVar5);
      }
      if (((pcVar3[iVar4] != '\0') && (param_2[iVar4] != '\0')) && (pcVar3[iVar4] == '*')) {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 10243 ; VA 0x0071e6e0 ; FUN_0071e6e0 */

void FUN_0071e6e0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  char cVar2;
  
  cVar2 = (*(code *)*param_4)(*param_2,*param_1,param_4 + 1,*(undefined *)(param_4 + 4));
  if (cVar2 != '\0') {
    uVar1 = *param_2;
    *param_2 = *param_1;
    *param_1 = uVar1;
  }
  cVar2 = (*(code *)*param_4)(*param_3,*param_2,param_4 + 1,*(undefined *)(param_4 + 4));
  if (cVar2 != '\0') {
    uVar1 = *param_3;
    *param_3 = *param_2;
    *param_2 = uVar1;
    cVar2 = (*(code *)*param_4)(uVar1,*param_1,param_4 + 1,*(undefined *)(param_4 + 4));
    if (cVar2 != '\0') {
      uVar1 = *param_2;
      *param_2 = *param_1;
      *param_1 = uVar1;
    }
  }
  return;
}



/* FUNCTION 10244 ; VA 0x0071e760 ; FUN_0071e760 */

void FUN_0071e760(uint *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  
  puVar4 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  iVar3 = (int)(param_3 + -1) - (int)param_2 >> 2;
  if (iVar3 < 0x29) {
    FUN_0071e6e0(param_2,puVar4,param_3 + -1,param_4);
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    FUN_0071e6e0(param_2,param_2 + iVar3,param_2 + iVar3 * 2,param_4);
    FUN_0071e6e0(puVar4 + -iVar3,puVar4,puVar4 + iVar3,param_4);
    puVar5 = param_3 + -1;
    FUN_0071e6e0(puVar5 + iVar3 * -2,puVar5 + -iVar3,puVar5,param_4);
    FUN_0071e6e0(param_2 + iVar3,puVar4,puVar5 + -iVar3,param_4);
  }
  puVar5 = puVar4 + 1;
  if (param_2 < puVar4) {
    do {
      cVar2 = (*(code *)*param_4)(puVar4[-1],*puVar4,param_4 + 1,*(undefined *)(param_4 + 4));
      if ((cVar2 != '\0') ||
         (cVar2 = (*(code *)*param_4)(*puVar4,puVar4[-1],param_4 + 1,*(undefined *)(param_4 + 4)),
         cVar2 != '\0')) break;
      puVar4 = puVar4 + -1;
    } while (param_2 < puVar4);
  }
  puVar6 = puVar5;
  puStack_14 = puVar5;
  puStack_c = puVar5;
  puStack_10 = puVar4;
  puVar9 = puVar4;
  if (puVar5 < param_3) {
    do {
      cVar2 = (*(code *)*param_4)(*puVar5,*puVar4,param_4 + 1,*(undefined *)(param_4 + 4));
      puVar6 = puVar5;
      puStack_14 = puVar5;
      puStack_c = puVar5;
      if ((cVar2 != '\0') ||
         (cVar2 = (*(code *)*param_4)(*puVar4,*puVar5,param_4 + 1,*(undefined *)(param_4 + 4)),
         cVar2 != '\0')) break;
      puVar5 = puVar5 + 1;
      puVar6 = puVar5;
      puStack_14 = puVar5;
      puStack_c = puVar5;
    } while (puVar5 < param_3);
  }
joined_r0x0071e8b2:
  do {
    puVar7 = puStack_10;
    if (param_3 <= puVar6) {
joined_r0x0071e911:
      while (puVar8 = puVar6, param_2 < puVar4) {
        puVar7 = puVar7 + -1;
        cVar2 = (*(code *)*param_4)(*puVar7,*puVar9,param_4 + 1,*(undefined *)(param_4 + 4));
        puVar5 = puStack_c;
        if (cVar2 == '\0') {
          cVar2 = (*(code *)*param_4)(*puVar9,*puVar7,param_4 + 1,*(undefined *)(param_4 + 4));
          puVar4 = puStack_10;
          puVar8 = puStack_14;
          if (cVar2 != '\0') break;
          puVar9 = puVar9 + -1;
          if (puVar9 != puVar7) {
            uVar1 = *puVar9;
            *puVar9 = *puVar7;
            *puVar7 = uVar1;
          }
        }
        puStack_10 = puStack_10 + -1;
        puVar6 = puStack_14;
        puVar4 = puStack_10;
      }
      if (puVar4 == param_2) {
        if (puVar8 == param_3) {
          *param_1 = (uint)puVar9;
          param_1[1] = (uint)puVar5;
          return;
        }
        if (puVar5 != puVar8) {
          uVar1 = *puVar9;
          *puVar9 = *puVar5;
          *puVar5 = uVar1;
        }
        uVar1 = *puVar9;
        puVar5 = puVar5 + 1;
        *puVar9 = *puVar8;
        *puVar8 = uVar1;
        puVar6 = puVar8 + 1;
        puStack_14 = puVar8 + 1;
        puStack_c = puVar5;
        puVar9 = puVar9 + 1;
      }
      else {
        puVar4 = puVar4 + -1;
        puStack_10 = puVar4;
        if (puVar8 == param_3) {
          puVar9 = puVar9 + -1;
          if (puVar4 != puVar9) {
            uVar1 = *puVar4;
            *puVar4 = *puVar9;
            *puVar9 = uVar1;
          }
          uVar1 = *puVar9;
          puVar5 = puVar5 + -1;
          *puVar9 = *puVar5;
          *puVar5 = uVar1;
          puVar6 = puVar8;
          puStack_c = puVar5;
        }
        else {
          uVar1 = *puVar8;
          *puVar8 = *puVar4;
          *puVar4 = uVar1;
          puVar6 = puVar8 + 1;
          puStack_14 = puVar8 + 1;
        }
      }
      goto joined_r0x0071e8b2;
    }
    cVar2 = (*(code *)*param_4)(*puVar9,*puVar6,param_4 + 1,*(undefined *)(param_4 + 4));
    puVar4 = puStack_10;
    if (cVar2 == '\0') {
      cVar2 = (*(code *)*param_4)(*puVar6,*puVar9,param_4 + 1,*(undefined *)(param_4 + 4));
      puStack_c = puVar5;
      puStack_14 = puVar6;
      if (cVar2 != '\0') goto joined_r0x0071e911;
      if (puVar5 != puVar6) {
        uVar1 = *puVar5;
        *puVar5 = *puVar6;
        *puVar6 = uVar1;
      }
      puVar5 = puVar5 + 1;
    }
    puVar6 = puVar6 + 1;
    puStack_14 = puVar6;
    puStack_c = puVar5;
  } while( true );
}



/* FUNCTION 10245 ; VA 0x0071ea10 ; FUN_0071ea10 */

void FUN_0071ea10(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = param_2;
  return;
}



/* FUNCTION 10246 ; VA 0x0071ea20 ; FUN_0071ea20 */

undefined4 *
FUN_0071ea20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int param_5,undefined4 param_6,int param_7,undefined param_8)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_48 [2];
  int iStack_40;
  undefined uStack_3c;
  int aiStack_38 [2];
  int iStack_30;
  int aiStack_2c [2];
  int iStack_24;
  int aiStack_20 [2];
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac5f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0071ee30(&param_5);
  uStack_8._0_1_ = 1;
  FUN_0071ee30(aiStack_38);
  uStack_8._0_1_ = 2;
  FUN_0071ee30(aiStack_2c);
  uStack_8._0_1_ = 3;
  FUN_0071ee30(aiStack_20);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (aiStack_20[0] != 0) {
    uVar3 = (iStack_18 - aiStack_20[0] >> 2) * 4;
    iVar2 = aiStack_20[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_20[0] + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (aiStack_20[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_3c = param_8;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (aiStack_2c[0] != 0) {
    uVar3 = (iStack_24 - aiStack_2c[0] >> 2) * 4;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (aiStack_38[0] != 0) {
    uVar3 = (iStack_30 - aiStack_38[0] >> 2) * 4;
    iVar2 = aiStack_38[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_38[0] + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (aiStack_38[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *param_1 = param_2;
  FUN_0071ee30(aiStack_48);
  *(undefined *)(param_1 + 4) = uStack_3c;
  if (aiStack_48[0] != 0) {
    uVar3 = iStack_40 - aiStack_48[0] & 0xfffffffc;
    iVar2 = aiStack_48[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_48[0] + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_5 != 0) {
    uVar3 = param_7 - param_5 & 0xfffffffc;
    iVar2 = param_5;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10247 ; VA 0x0071ec00 ; FUN_0071ec00 */

void FUN_0071ec00(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
                 int param_5,undefined4 param_6,int param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  char cVar5;
  uint uVar6;
  undefined4 *puVar7;
  int *piVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac618;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_24 = param_1;
  puStack_20 = param_3;
  ppvVar4 = &pvStack_10;
  if (param_2 != param_3) {
    uVar6 = (int)param_3 - (int)param_1;
    ExceptionList = &pvStack_10;
    while (0x80 < (int)(uVar6 & 0xfffffffc)) {
      puVar7 = (undefined4 *)FUN_0071ea10(&puStack_2c,&param_4);
      FUN_0071e760(&puStack_34,param_1,param_3,*puVar7);
      if (param_2 < puStack_30) {
        puStack_20 = puStack_34;
        param_3 = puStack_34;
        ppvVar4 = (void **)ExceptionList;
        if (puStack_34 <= param_2) goto LAB_0071ed70;
      }
      else {
        puStack_24 = puStack_30;
        param_1 = puStack_30;
      }
      uVar6 = (int)param_3 - (int)param_1;
    }
    piVar8 = (int *)FUN_0071ea10(&puStack_30,&param_4);
    puVar7 = (undefined4 *)*piVar8;
    ppvVar4 = (void **)ExceptionList;
    if ((param_1 != param_3) && (puStack_28 = param_1 + 1, puStack_28 != param_3)) {
      puStack_2c = param_1 + -1;
      iStack_18 = 4;
      do {
        uStack_14 = *puStack_28;
        puStack_1c = puStack_28;
        cVar5 = (*(code *)*puVar7)(uStack_14,*param_1,puVar7 + 1,
                                   CONCAT31((int3)((uint)(puVar7 + 1) >> 8),
                                            *(undefined *)(puVar7 + 4)));
        if (cVar5 == '\0') {
          puVar10 = (undefined4 *)((int)puStack_2c + iStack_18);
          cVar5 = (*(code *)*puVar7)(uStack_14,*puVar10,puVar7 + 1,*(undefined *)(puVar7 + 4));
          uVar3 = uStack_14;
          param_1 = puStack_24;
          puVar2 = puStack_1c;
          while (puStack_1c = puVar10, puStack_24 = param_1, cVar5 != '\0') {
            uVar1 = *puStack_1c;
            puVar10 = puStack_1c + -1;
            *puVar2 = uVar1;
            cVar5 = (*(code *)*puVar7)(uVar3,*puVar10,puVar7 + 1,
                                       CONCAT31((int3)((uint)uVar1 >> 8),*(undefined *)(puVar7 + 4))
                                      );
            param_3 = puStack_20;
            param_1 = puStack_24;
            puVar2 = puStack_1c;
          }
          *puVar2 = uStack_14;
          puStack_1c = puVar2;
        }
        else {
          FUN_0170cc70(param_1 + 1,param_1,iStack_18);
          *param_1 = uStack_14;
        }
        iStack_18 = iStack_18 + 4;
        puStack_28 = puStack_28 + 1;
        ppvVar4 = (void **)ExceptionList;
      } while (puStack_28 != param_3);
    }
  }
LAB_0071ed70:
  ExceptionList = ppvVar4;
  if (param_5 != 0) {
    uVar6 = param_7 - param_5 & 0xfffffffc;
    iVar9 = param_5;
    if (0xfff < uVar6) {
      iVar9 = *(int *)(param_5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (param_5 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10248 ; VA 0x0071edc0 ; FUN_0071edc0 */

int * __thiscall FUN_0071edc0(int *param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00577ed0(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    iVar2 = param_2 * 4;
    param_1[2] = *param_1 + iVar2;
    iVar1 = *param_1;
    FUN_0170d1f0(iVar1,0,iVar2);
    param_1[1] = iVar2 + iVar1;
  }
  return param_1;
}



/* FUNCTION 10249 ; VA 0x0071ee30 ; FUN_0071ee30 */

int * __thiscall FUN_0071ee30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  
  piVar3 = param_2;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar4 = FUN_0071f4e0(param_2[1] - *param_2 >> 2);
  if (cVar4 != '\0') {
    iVar1 = *param_1;
    iVar2 = *piVar3;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar5 = piVar3[1] - iVar2;
    FUN_0170cc70(iVar1,iVar2,iVar5);
    param_1[1] = iVar1 + iVar5;
    return param_1;
  }
  return param_1;
}


