/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 2000 ; VA 0x005190d0 ; FUN_005190d0 */

void FUN_005190d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e64610(FUN_00e65000,0,s_AdjustSpeed_02148970,s_speed_02123e48,0x3f800000,0,uStack_10,0);
  FUN_016f3654(&LAB_018a2e60);
  return;
}



/* FUNCTION 2001 ; VA 0x00519130 ; FUN_00519130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00519130(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183042e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e643e0(uVar2,0);
  FUN_009cb790(uVar1,s_AdjustWeight_02148960,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02148590 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AnimationTrack,void___cdecl(float,float),2>::
       vftable;
  _DAT_021485c8 = FUN_00e65150;
  _DAT_021485cc = 0;
  DAT_021485d0 = (undefined4 *)FUN_01674e20(4);
  if (DAT_021485d0 == (undefined4 *)0x0) {
    DAT_021485d0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021485d0 = 0x3f800000;
  }
  uStack_8._0_1_ = 1;
  DAT_021485d4 = (undefined4 *)FUN_01674e20(4);
  if (DAT_021485d4 == (undefined4 *)0x0) {
    DAT_021485d4 = (undefined4 *)0x0;
  }
  else {
    *DAT_021485d4 = 0x3dcccccd;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00e65540();
  FUN_016f3654(&LAB_018a2e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2002 ; VA 0x00519220 ; FUN_00519220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00519220(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183048c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e643e0();
  FUN_009cb790(uVar1,s_GetTimeOfKeyframe_0214898c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02148620 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AnimationTrack,double___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02148658 = FUN_00e668d0;
  _DAT_0214865c = 0;
  DAT_02148660 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02148644 = FUN_0088ca00();
  if (DAT_02148660 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02148660);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_keyframeName_0214897c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a2ec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2003 ; VA 0x005193a0 ; FUN_005193a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005193a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018304c8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e643e0(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02128f90,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021484f8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AnimationTrack,void___cdecl(float,float,float),3>::
       vftable;
  _DAT_02148530 = FUN_00e66e50;
  _DAT_02148534 = 0;
  DAT_02148538 = (undefined4 *)FUN_01674e20(4);
  if (DAT_02148538 == (undefined4 *)0x0) {
    DAT_02148538 = (undefined4 *)0x0;
  }
  else {
    *DAT_02148538 = 0x3dcccccd;
  }
  uStack_8._0_1_ = 1;
  DAT_0214853c = (undefined4 *)FUN_01674e20(4);
  if (DAT_0214853c == (undefined4 *)0x0) {
    DAT_0214853c = (undefined4 *)0x0;
  }
  else {
    *DAT_0214853c = 0x3f800000;
  }
  uStack_8._0_1_ = 2;
  DAT_02148540 = (undefined4 *)FUN_01674e20(4);
  if (DAT_02148540 == (undefined4 *)0x0) {
    DAT_02148540 = (undefined4 *)0x0;
  }
  else {
    *DAT_02148540 = 0x3f800000;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00e65770(s_fadeTime_021292d8,s_weight_021292d0,s_speed_02123e48);
  FUN_016f3654(&LAB_018a2ee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2004 ; VA 0x005194b0 ; FUN_005194b0 */

void FUN_005194b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e64610(FUN_00e67c00,0,&DAT_02121ec0,s_fadeTime_021292d8,0x3dcccccd,0,uStack_10,0);
  FUN_016f3654(&LAB_018a2f30);
  return;
}



/* FUNCTION 2005 ; VA 0x00519530 ; FUN_00519530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00519530(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01830503;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e643e0();
  FUN_009cb970(uVar1,s_KeyframeReached_021489c8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021488a4 = 0x54;
  iStack_8 = 0;
  _DAT_02148870 =
       RBX::Reflection::
       EventDesc<class_RBX::AnimationTrack,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::AnimationTrack::*>
       ::vftable;
  FUN_0086e3d0(s_keyframeName_0214897c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02148898 = uStack_1c;
  _DAT_0214889c = uStack_18;
  _DAT_021488a0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02148870 =
       RBX::Reflection::
       EventDesc<class_RBX::AnimationTrack,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::AnimationTrack::*>
       ::vftable;
  FUN_016f3654(&LAB_018a2f60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2006 ; VA 0x005196a0 ; FUN_005196a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005196a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183055c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e643e0();
  FUN_009cb790(uVar1,s_GetMarkerReachedSignal_021489d8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02148918 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AnimationTrack,struct_RBX::Lua::EventInstance___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02148950 = FUN_00e664b0;
  _DAT_02148954 = 0;
  DAT_02148958 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214893c = FUN_0088caa0();
  if (DAT_02148958 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02148958);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a2f80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2007 ; VA 0x00519820 ; FUN_00519820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00519820(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01830590;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x13;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1db7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f1db7c,uVar3,0,0,0x13);
    if (DAT_01f1db7c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01f1db58 = RBX::Reflection::RefType<class_RBX::Animation*>::vftable;
      FUN_016f3654(&LAB_018a30d0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01f1db7c);
    }
  }
  uVar2 = FUN_00e643e0();
  FUN_009ca670(uVar2,&DAT_01f1db58,s_Animation_021467fc,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0)
  ;
  uStack_8 = 1;
  DAT_021487f0 = RBX::Reflection::RefPropDescriptor<class_RBX::AnimationTrack,class_RBX::Animation>
                 ::vftable;
  _DAT_02148824 =
       RBX::Reflection::RefPropDescriptor<class_RBX::AnimationTrack,class_RBX::Animation>::vftable;
  DAT_02148828 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_02148828 == (undefined4 *)0x0) {
    DAT_02148828 = (undefined4 *)0x0;
  }
  else {
    *DAT_02148828 =
         RBX::Reflection::PropDescriptor<class_RBX::AnimationTrack,class_RBX::Animation*>::
         GetImpl<class_RBX::Animation*_(__thiscall_RBX::AnimationTrack::*)(void)const_>::vftable;
    DAT_02148828[2] = FUN_00e66450;
    DAT_02148828[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_021487f0[3])();
  if (cVar1 != '\0') {
    _DAT_02148814 = _DAT_02148814 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021487f0[2])();
  if (cVar1 != '\0') {
    _DAT_02148814 = _DAT_02148814 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a2fa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2008 ; VA 0x00519a70 ; FUN_00519a70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00519a70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018305b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aeea60();
  uVar3 = FUN_00e643e0();
  FUN_009ca670(uVar3,uVar2,s_Priority_0213b47c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02148830 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::AnimationTrack,enum_RBX::KeyframeSequence::Priority>
                 ::vftable;
  _DAT_02148864 = uVar2;
  DAT_02148868 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02148868 == (undefined4 *)0x0) {
    DAT_02148868 = (undefined4 *)0x0;
  }
  else {
    *DAT_02148868 =
         RBX::Reflection::
         PropDescriptor<class_RBX::AnimationTrack,enum_RBX::KeyframeSequence::Priority>::
         GetSetImpl<enum_RBX::KeyframeSequence::Priority_(__thiscall_RBX::AnimationTrack::*)(void)const_,void_(__thiscall_RBX::AnimationTrack::*)(enum_RBX::KeyframeSequence::Priority)>
         ::vftable;
    DAT_02148868[2] = FUN_00e668b0;
    DAT_02148868[3] = 0;
    DAT_02148868[4] = FUN_00e67250;
    DAT_02148868[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214886c = FUN_00aeea60();
  cVar1 = (*(code *)DAT_02148830[3])();
  if (cVar1 != '\0') {
    _DAT_02148854 = _DAT_02148854 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02148830[2])();
  if (cVar1 != '\0') {
    _DAT_02148854 = _DAT_02148854 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a2fe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2009 ; VA 0x0051a000 ; FUN_0051a000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a000(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183099a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e68140(uVar2,0);
  FUN_009cb790(uVar1,s_GetTeleportData_02148bf0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02148a38 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportOptions,class_RBX::Reflection::Variant___cdecl(void)const_,0>
       ::vftable;
  _DAT_02148a70 = FUN_00e6b1d0;
  _DAT_02148a74 = 0;
  _DAT_02148a5c = FUN_00888410();
  FUN_016f3654(&LAB_018a30e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2010 ; VA 0x0051a0a0 ; FUN_0051a0a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a0a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018309fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e68140();
  FUN_009cb790(uVar1,s_SetTeleportData_02148be0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021489f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportOptions,void___cdecl(class_RBX::Reflection::Variant),1>::
       vftable;
  _DAT_02148a28 = FUN_00e6c1b0;
  _DAT_02148a2c = 0;
  DAT_02148a30 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_02148a14 = FUN_00888530();
  puVar4 = DAT_02148a30;
  if (DAT_02148a30 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = *DAT_02148a30;
    puStack_ec = (undefined4 *)0x0;
    puVar2 = (undefined4 *)DAT_02148a30[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)();
      puVar2 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
    puStack_ec = puVar2;
  }
  uVar1 = FUN_00888410();
  uVar3 = FUN_0086e3d0(s_teleportData_021282b4);
  FUN_00888b30(uVar3,uVar1,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(FUN_018a30f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2011 ; VA 0x0051a250 ; FUN_0051a250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a250(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffdc;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01830a40;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffdc & 0xffffff00;
  uVar3 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70(uVar2,0);
  FUN_009cb820(uVar1,s_TeleportAsync_02148c54,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02148b90 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::TeleportService,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,class_std::shared_ptr<class_RBX::Instance>),3>
       ::vftable;
  _DAT_02148bc8 = FUN_00e69da0;
  _DAT_02148bcc = 0;
  _DAT_02148bd0 = 0;
  _DAT_02148bd4 = 0;
  uStack_8._0_1_ = 3;
  _DAT_02148bd8 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_02148bd8 == (undefined4 *)0x0) {
    _DAT_02148bd8 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02148bd8 = 0;
    _DAT_02148bd8[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00e6a970(s_placeId_021200e8,s_players_02121524,s_teleportOptions_02148c44);
  FUN_016f3654(&LAB_018a3160);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2012 ; VA 0x0051a630 ; FUN_0051a630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a630(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01830a6c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e68140();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TeleportOptions,bool>::
              GetSetImpl<bool_(__thiscall_RBX::TeleportOptions::*)(void)const_,void_(__thiscall_RBX::TeleportOptions::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00e6b1a0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e6c080;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_ShouldReserveServer_02148c30,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02148ae8 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02148b1c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02148b0c = _DAT_02148b0c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02148ae8[2])();
    if (cVar1 != '\0') {
      _DAT_02148b0c = _DAT_02148b0c & 0xfffffff3;
    }
  }
  DAT_02148ae8 = RBX::Reflection::PropDescriptor<class_RBX::TeleportOptions,bool>::vftable;
  FUN_016f3654(&LAB_018a31f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2013 ; VA 0x0051a7b0 ; FUN_0051a7b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051a7b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831014;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00e6dcf0();
  FUN_009ca670(uVar3,uVar2,&DAT_01981ccc,&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f1e1f0 = RBX::Reflection::EnumPropDescriptor<class_RBX::FaceInstance,enum_RBX::NormalId>::
                 vftable;
  _DAT_01f1e224 = uVar2;
  DAT_01f1e228 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f1e228 == (undefined4 *)0x0) {
    DAT_01f1e228 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f1e228 =
         RBX::Reflection::PropDescriptor<class_RBX::FaceInstance,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::FaceInstance::*)(void)const_,void_(__thiscall_RBX::FaceInstance::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_01f1e228[2] = FUN_0074a340;
    DAT_01f1e228[3] = 0;
    DAT_01f1e228[4] = FUN_00e6df10;
    DAT_01f1e228[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1e22c = FUN_00890320();
  cVar1 = (*(code *)DAT_01f1e1f0[3])();
  if (cVar1 != '\0') {
    _DAT_01f1e214 = _DAT_01f1e214 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f1e1f0[2])();
  if (cVar1 != '\0') {
    _DAT_01f1e214 = _DAT_01f1e214 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a3290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2014 ; VA 0x0051ad00 ; FUN_0051ad00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ad00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183119c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e6f1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PostEffect,bool>::
              GetSetImpl<bool_(__thiscall_RBX::PostEffect::*)(void)const_,void_(__thiscall_RBX::PostEffect::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_00dd7240;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e6f3a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Enabled_0212c1fc,s_State_0211d030,uStack_24,0,0,0x1f,0,0,0);
  DAT_02148e44 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02148e78 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02148e68 = _DAT_02148e68 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02148e44[2])();
    if (cVar1 != '\0') {
      _DAT_02148e68 = _DAT_02148e68 & 0xfffffff3;
    }
  }
  DAT_02148e44 = RBX::Reflection::PropDescriptor<class_RBX::PostEffect,bool>::vftable;
  FUN_016f3654(&LAB_018a3480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2015 ; VA 0x0051ae40 ; FUN_0051ae40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ae40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183125c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e6f3e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BlurEffect,float>::
              GetSetImpl<float_(__thiscall_RBX::BlurEffect::*)(void)const_,void_(__thiscall_RBX::BlurEffect::*)(float)>
              ::vftable;
    puVar3[2] = FUN_00855cf0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e6f7d0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,&DAT_02124b6c,s_State_0211d030,uStack_24,0,0,0x1f,0,0,0);
  DAT_02148e7c = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02148eb0 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02148ea0 = _DAT_02148ea0 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02148e7c[2])();
    if (cVar1 != '\0') {
      _DAT_02148ea0 = _DAT_02148ea0 & 0xfffffff3;
    }
  }
  DAT_02148e7c = RBX::Reflection::PropDescriptor<class_RBX::BlurEffect,float>::vftable;
  FUN_016f3654(&LAB_018a34b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2016 ; VA 0x0051ba40 ; FUN_0051ba40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ba40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018316cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e75940();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::SpringConstraint,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Constraints::SpringConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::SpringConstraint::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_008fc860;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e77e30;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_LimitsEnabled_02140ca8,s_Spring_02149464,uStack_24,0,0,0x1f,0,0,0);
  DAT_021492dc = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02149310 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02149300 = _DAT_02149300 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021492dc[2])();
    if (cVar1 != '\0') {
      _DAT_02149300 = _DAT_02149300 & 0xfffffff3;
    }
  }
  DAT_021492dc = RBX::Reflection::PropDescriptor<class_RBX::Constraints::SpringConstraint,bool>::
                 vftable;
  FUN_016f3654(&LAB_018a3920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2017 ; VA 0x0051c0c0 ; FUN_0051c0c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051c0c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831774;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6a20();
  uVar3 = FUN_00e781e0();
  FUN_009ca670(uVar3,uVar2,s_ActuatorType_02140c98,s_Slider_02149790,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021494b0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::SlidingBallConstraint,enum_RBX::Constraints::ActuatorType>
                 ::vftable;
  _DAT_021494e4 = uVar2;
  DAT_021494e8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021494e8 == (undefined4 *)0x0) {
    DAT_021494e8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021494e8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::SlidingBallConstraint,enum_RBX::Constraints::ActuatorType>
         ::
         GetSetImpl<enum_RBX::Constraints::ActuatorType_(__thiscall_RBX::Constraints::SlidingBallConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::SlidingBallConstraint::*)(enum_RBX::Constraints::ActuatorType_const&)>
         ::vftable;
    DAT_021494e8[2] = FUN_00762f90;
    DAT_021494e8[3] = 0;
    DAT_021494e8[4] = FUN_00e79fb0;
    DAT_021494e8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021494ec = FUN_00ca6a20();
  cVar1 = (*(code *)DAT_021494b0[3])();
  if (cVar1 != '\0') {
    _DAT_021494d4 = _DAT_021494d4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021494b0[2])();
  if (cVar1 != '\0') {
    _DAT_021494d4 = _DAT_021494d4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a3a80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2018 ; VA 0x0051c1e0 ; FUN_0051c1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051c1e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183179c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e781e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::SlidingBallConstraint,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Constraints::SlidingBallConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::SlidingBallConstraint::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00926b00;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e7a080;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_LimitsEnabled_02140ca8,s_Slider_02149790,uStack_24,0,0,0x1f,0,0,0);
  DAT_021494f0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02149524 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02149514 = _DAT_02149514 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021494f0[2])();
    if (cVar1 != '\0') {
      _DAT_02149514 = _DAT_02149514 & 0xfffffff3;
    }
  }
  DAT_021494f0 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::SlidingBallConstraint,bool>
                 ::vftable;
  FUN_016f3654(&LAB_018a3aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2019 ; VA 0x0051cc00 ; FUN_0051cc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051cc00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018318ac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e7a900();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::CylindricalConstraint,class_G3D::Vector3>::
              GetImpl<class_G3D::Vector3_(__thiscall_RBX::Constraints::CylindricalConstraint::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_00e7b3b0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_WorldRotationAxis_02149bec,s_Derived_02140d60,uStack_24,0,0,0x1f,0,0,0)
  ;
  DAT_02149ad0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02149b04 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02149af4 = _DAT_02149af4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02149ad0[2])();
    if (cVar1 != '\0') {
      _DAT_02149af4 = _DAT_02149af4 & 0xfffffff3;
    }
  }
  DAT_02149ad0 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::CylindricalConstraint,class_G3D::Vector3>::
                 vftable;
  FUN_016f3654(&LAB_018a3c50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2020 ; VA 0x0051cd20 ; FUN_0051cd20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051cd20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018318d4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6a20();
  uVar3 = FUN_00e7a900();
  FUN_009ca670(uVar3,uVar2,s_AngularActuatorType_02149b60,s_Cylinder_02149b40,uStack_24,0,0,0x1f,0,0
               ,1);
  uStack_8 = 0;
  DAT_02149828 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::CylindricalConstraint,enum_RBX::Constraints::ActuatorType>
                 ::vftable;
  _DAT_0214985c = uVar2;
  DAT_02149860 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02149860 == (undefined4 *)0x0) {
    DAT_02149860 = (undefined4 *)0x0;
  }
  else {
    *DAT_02149860 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::CylindricalConstraint,enum_RBX::Constraints::ActuatorType>
         ::
         GetSetImpl<enum_RBX::Constraints::ActuatorType_(__thiscall_RBX::Constraints::CylindricalConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::CylindricalConstraint::*)(enum_RBX::Constraints::ActuatorType)>
         ::vftable;
    DAT_02149860[2] = &LAB_0074b660;
    DAT_02149860[3] = 0;
    DAT_02149860[4] = FUN_00e7d970;
    DAT_02149860[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02149864 = FUN_00ca6a20();
  cVar1 = (*(code *)DAT_02149828[3])();
  if (cVar1 != '\0') {
    _DAT_0214984c = _DAT_0214984c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02149828[2])();
  if (cVar1 != '\0') {
    _DAT_0214984c = _DAT_0214984c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a3c70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2021 ; VA 0x0051dac0 ; FUN_0051dac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051dac0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831b6c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e81630();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::VectorForce,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::Constraints::VectorForce::*)(void)const_,void_(__thiscall_RBX::Constraints::VectorForce::*)(class_G3D::Vector3)>
              ::vftable;
    puVar3[2] = FUN_00e82260;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e82ee0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_Force_02149fa4,s_VectorForce_02149f98,uStack_24,0,0,0x1f,0,0,0);
  DAT_02149dd0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02149e04 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02149df4 = _DAT_02149df4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02149dd0[2])();
    if (cVar1 != '\0') {
      _DAT_02149df4 = _DAT_02149df4 & 0xfffffff3;
    }
  }
  DAT_02149dd0 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::VectorForce,class_G3D::Vector3>::vftable;
  FUN_016f3654(&LAB_018a4010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2022 ; VA 0x0051dbf0 ; FUN_0051dbf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051dbf0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831b94;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6970();
  uVar3 = FUN_00e81630();
  FUN_009ca670(uVar3,uVar2,s_RelativeTo_02149fac,s_VectorForce_02149f98,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02149e08 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::VectorForce,enum_RBX::Constraints::ActuatorRelativeTo>
                 ::vftable;
  _DAT_02149e3c = uVar2;
  DAT_02149e40 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02149e40 == (undefined4 *)0x0) {
    DAT_02149e40 = (undefined4 *)0x0;
  }
  else {
    *DAT_02149e40 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::VectorForce,enum_RBX::Constraints::ActuatorRelativeTo>
         ::
         GetSetImpl<enum_RBX::Constraints::ActuatorRelativeTo_(__thiscall_RBX::Constraints::VectorForce::*)(void)const_,void_(__thiscall_RBX::Constraints::VectorForce::*)(enum_RBX::Constraints::ActuatorRelativeTo)>
         ::vftable;
    DAT_02149e40[2] = &LAB_00685250;
    DAT_02149e40[3] = 0;
    DAT_02149e40[4] = FUN_00e82dc0;
    DAT_02149e40[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02149e44 = FUN_00ca6970();
  cVar1 = (*(code *)DAT_02149e08[3])();
  if (cVar1 != '\0') {
    _DAT_02149e2c = _DAT_02149e2c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02149e08[2])();
  if (cVar1 != '\0') {
    _DAT_02149e2c = _DAT_02149e2c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2023 ; VA 0x0051e060 ; FUN_0051e060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e060(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831c44;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6970();
  uVar3 = FUN_00e83230();
  FUN_009ca670(uVar3,uVar2,s_RelativeTo_02149fac,s_Torque_02137b28,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214a020 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::TorqueActuator,enum_RBX::Constraints::ActuatorRelativeTo>
                 ::vftable;
  _DAT_0214a054 = uVar2;
  DAT_0214a058 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214a058 == (undefined4 *)0x0) {
    DAT_0214a058 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214a058 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::TorqueActuator,enum_RBX::Constraints::ActuatorRelativeTo>
         ::
         GetSetImpl<enum_RBX::Constraints::ActuatorRelativeTo_(__thiscall_RBX::Constraints::TorqueActuator::*)(void)const_,void_(__thiscall_RBX::Constraints::TorqueActuator::*)(enum_RBX::Constraints::ActuatorRelativeTo)>
         ::vftable;
    DAT_0214a058[2] = &LAB_00685250;
    DAT_0214a058[3] = 0;
    DAT_0214a058[4] = FUN_00e83e00;
    DAT_0214a058[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214a05c = FUN_00ca6970();
  cVar1 = (*(code *)DAT_0214a020[3])();
  if (cVar1 != '\0') {
    _DAT_0214a044 = _DAT_0214a044 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214a020[2])();
  if (cVar1 != '\0') {
    _DAT_0214a044 = _DAT_0214a044 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a41b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2024 ; VA 0x0051e180 ; FUN_0051e180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e180(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831c6c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e83230();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::TorqueActuator,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::Constraints::TorqueActuator::*)(void)const_,void_(__thiscall_RBX::Constraints::TorqueActuator::*)(class_G3D::Vector3)>
              ::vftable;
    puVar3[2] = FUN_00e82260;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e83e80;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_Torque_02137b28,s_Torque_02137b28,uStack_24,0,0,0x1f,0,0,0);
  DAT_02149fe8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a01c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a00c = _DAT_0214a00c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02149fe8[2])();
    if (cVar1 != '\0') {
      _DAT_0214a00c = _DAT_0214a00c & 0xfffffff3;
    }
  }
  DAT_02149fe8 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::TorqueActuator,class_G3D::Vector3>::vftable;
  FUN_016f3654(&LAB_018a41d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2025 ; VA 0x0051e2c0 ; FUN_0051e2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e2c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831d7c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e83f40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(void)const_,void_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(class_G3D::Vector3)>
              ::vftable;
    puVar3[2] = FUN_00e84660;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e84ff0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_AngularVelocity_02140cc0,s_Torque_02137b28,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214a060 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a094 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a084 = _DAT_0214a084 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214a060[2])();
    if (cVar1 != '\0') {
      _DAT_0214a084 = _DAT_0214a084 & 0xfffffff3;
    }
  }
  DAT_0214a060 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,class_G3D::Vector3>
                 ::vftable;
  FUN_016f3654(&LAB_018a4250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2026 ; VA 0x0051e3f0 ; FUN_0051e3f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e3f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831dac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e83f40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,float>
              ::
              GetSetImpl<float_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(void)const_,void_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00855ce0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e85070;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_MaxTorque_02139c3c,s_Torque_02137b28,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214a098 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a0cc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a0bc = _DAT_0214a0bc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214a098[2])();
    if (cVar1 != '\0') {
      _DAT_0214a0bc = _DAT_0214a0bc & 0xfffffff3;
    }
  }
  DAT_0214a098 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,float>::vftable;
  FUN_016f3654(&LAB_018a4270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2027 ; VA 0x0051e520 ; FUN_0051e520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e520(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831dd4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6970();
  uVar3 = FUN_00e83f40();
  FUN_009ca670(uVar3,uVar2,s_RelativeTo_02149fac,s_Torque_02137b28,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214a108 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::AngularVelocityActuator,enum_RBX::Constraints::ActuatorRelativeTo>
                 ::vftable;
  _DAT_0214a13c = uVar2;
  DAT_0214a140 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214a140 == (undefined4 *)0x0) {
    DAT_0214a140 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214a140 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,enum_RBX::Constraints::ActuatorRelativeTo>
         ::
         GetSetImpl<enum_RBX::Constraints::ActuatorRelativeTo_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(void)const_,void_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(enum_RBX::Constraints::ActuatorRelativeTo)>
         ::vftable;
    DAT_0214a140[2] = FUN_00849fa0;
    DAT_0214a140[3] = 0;
    DAT_0214a140[4] = FUN_00e84ee0;
    DAT_0214a140[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214a144 = FUN_00ca6970();
  cVar1 = (*(code *)DAT_0214a108[3])();
  if (cVar1 != '\0') {
    _DAT_0214a12c = _DAT_0214a12c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214a108[2])();
  if (cVar1 != '\0') {
    _DAT_0214a12c = _DAT_0214a12c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2028 ; VA 0x0051e640 ; FUN_0051e640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e640(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831dfc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e83f40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,bool>
              ::
              GetSetImpl<bool_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(void)const_,void_(__thiscall_RBX::Constraints::AngularVelocityActuator::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00d7d0e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e850f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_ReactionTorqueEnabled_0214a148,s_Torque_02137b28,uStack_24,0,0,0x1f,0,0
               ,0);
  DAT_0214a0d0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a104 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a0f4 = _DAT_0214a0f4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214a0d0[2])();
    if (cVar1 != '\0') {
      _DAT_0214a0f4 = _DAT_0214a0f4 & 0xfffffff3;
    }
  }
  DAT_0214a0d0 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::AngularVelocityActuator,bool>::vftable;
  FUN_016f3654(&LAB_018a42b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2029 ; VA 0x0051e780 ; FUN_0051e780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051e780(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831ef4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6ad0();
  uVar3 = FUN_00e853b0();
  FUN_009ca670(uVar3,uVar2,s_AlignType_0214a328,s_AlignOrientation_0214a2f0,uStack_24,0,0,0x1f,0,0,1
              );
  uStack_8 = 0;
  DAT_0214a2b0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::OrientationConstraint,enum_RBX::Constraints::AlignType>
                 ::vftable;
  _DAT_0214a2e4 = uVar2;
  DAT_0214a2e8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214a2e8 == (undefined4 *)0x0) {
    DAT_0214a2e8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214a2e8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::OrientationConstraint,enum_RBX::Constraints::AlignType>
         ::
         GetSetImpl<enum_RBX::Constraints::AlignType_(__thiscall_RBX::Constraints::OrientationConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::OrientationConstraint::*)(enum_RBX::Constraints::AlignType)>
         ::vftable;
    DAT_0214a2e8[2] = &LAB_00685250;
    DAT_0214a2e8[3] = 0;
    DAT_0214a2e8[4] = FUN_00e86ff0;
    DAT_0214a2e8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214a2ec = FUN_00ca6ad0();
  cVar1 = (*(code *)DAT_0214a2b0[3])();
  if (cVar1 != '\0') {
    _DAT_0214a2d4 = _DAT_0214a2d4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214a2b0[2])();
  if (cVar1 != '\0') {
    _DAT_0214a2d4 = _DAT_0214a2d4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4330);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2030 ; VA 0x0051ebb0 ; FUN_0051ebb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ebb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01831fac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e876b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::NoCollisionConstraint,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Constraints::NoCollisionConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::NoCollisionConstraint::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_00dd7240;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e88210;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Enabled_0212c1fc,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214a3ac = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a3e0 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a3d0 = _DAT_0214a3d0 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214a3ac[2])();
    if (cVar1 != '\0') {
      _DAT_0214a3d0 = _DAT_0214a3d0 & 0xfffffff3;
    }
  }
  DAT_0214a3ac = RBX::Reflection::PropDescriptor<class_RBX::Constraints::NoCollisionConstraint,bool>
                 ::vftable;
  FUN_016f3654(&LAB_018a4470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2031 ; VA 0x0051ed90 ; FUN_0051ed90 */

void FUN_0051ed90(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0214a650,0x10);
  FUN_00e885e0(&DAT_0214a980,&DAT_021197d4,&LAB_00a60d2f,0,0,*puVar1,puVar1[1],puVar1[2],puVar1[3],0
              );
  FUN_016f3654(&LAB_018a4530);
  return;
}



/* FUNCTION 2032 ; VA 0x0051edf0 ; FUN_0051edf0 */

void FUN_0051edf0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00e88a40(0x74,s_keyDown_0214a970,&DAT_0211f870,CONCAT44(&DAT_0212dbb8,uStack_10),0);
  FUN_016f3654(&LAB_018a4550);
  return;
}



/* FUNCTION 2033 ; VA 0x0051ee40 ; FUN_0051ee40 */

void FUN_0051ee40(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0214a76c,0x15);
  FUN_00e887e0(s_target_02127abc,&DAT_021197d4,&LAB_00a3d6e8,0,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_018a4560);
  return;
}



/* FUNCTION 2034 ; VA 0x0051efa0 ; FUN_0051efa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051efa0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183204c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e88940();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Mouse,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_(__thiscall_RBX::Mouse::*)(void)const_,void_(__thiscall_RBX::Mouse::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = &LAB_00b019a0;
    puVar3[3] = 0;
    puVar3[4] = &LAB_00e88f56;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,&DAT_0214a9c4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214a908 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a93c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a92c = _DAT_0214a92c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214a908[2])();
    if (cVar1 != '\0') {
      _DAT_0214a92c = _DAT_0214a92c & 0xfffffff3;
    }
  }
  DAT_0214a908 = RBX::Reflection::PropDescriptor<class_RBX::Mouse,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_018a45e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2035 ; VA 0x0051f0f0 ; FUN_0051f0f0 */

void FUN_0051f0f0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00e88a40(0x74,s_KeyDown_0214a968,&DAT_0211f870,CONCAT44(&DAT_0212dbb8,uStack_10),0);
  FUN_016f3654(&LAB_018a4610);
  return;
}



/* FUNCTION 2036 ; VA 0x0051f140 ; FUN_0051f140 */

void FUN_0051f140(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00e88a40(0x78,s_KeyUp_0214a978,&DAT_0211f870,CONCAT44(&DAT_0212dc38,uStack_10),0);
  FUN_016f3654(&LAB_018a4620);
  return;
}



/* FUNCTION 2037 ; VA 0x0051f4f0 ; FUN_0051f4f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051f4f0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01832080;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00e88940();
  FUN_009ca670(uVar2,&DAT_01edf850,s_TargetFilter_0214a994,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0
               ,0);
  uStack_8 = 1;
  DAT_0214a730 = RBX::Reflection::RefPropDescriptor<class_RBX::Mouse,class_RBX::Instance>::vftable;
  _DAT_0214a764 = RBX::Reflection::RefPropDescriptor<class_RBX::Mouse,class_RBX::Instance>::vftable;
  DAT_0214a768 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214a768 == (undefined4 *)0x0) {
    DAT_0214a768 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214a768 =
         RBX::Reflection::PropDescriptor<class_RBX::Mouse,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::Mouse::*)(void)const_,void_(__thiscall_RBX::Mouse::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0214a768[2] = FUN_00e896c0;
    DAT_0214a768[3] = 0;
    DAT_0214a768[4] = &LAB_00c3b2de;
    DAT_0214a768[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0214a730[3])();
  if (cVar1 != '\0') {
    _DAT_0214a754 = _DAT_0214a754 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214a730[2])();
  if (cVar1 != '\0') {
    _DAT_0214a754 = _DAT_0214a754 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2038 ; VA 0x0051f690 ; FUN_0051f690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051f690(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018320a4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00e88940();
  FUN_009ca670(uVar3,uVar2,s_TargetSurface_0213ada0,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214a7e8 = RBX::Reflection::EnumPropDescriptor<class_RBX::Mouse,enum_RBX::NormalId>::vftable;
  _DAT_0214a81c = uVar2;
  DAT_0214a820 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0214a820 == (undefined4 *)0x0) {
    DAT_0214a820 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214a820 =
         RBX::Reflection::PropDescriptor<class_RBX::Mouse,enum_RBX::NormalId>::
         GetImpl<enum_RBX::NormalId_(__thiscall_RBX::Mouse::*)(void)const_>::vftable;
    DAT_0214a820[2] = &LAB_00c3b2e6;
    DAT_0214a820[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214a824 = FUN_00890320();
  cVar1 = (*(code *)DAT_0214a7e8[3])();
  if (cVar1 != '\0') {
    _DAT_0214a80c = _DAT_0214a80c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214a7e8[2])();
  if (cVar1 != '\0') {
    _DAT_0214a80c = _DAT_0214a80c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2039 ; VA 0x0051f7a0 ; FUN_0051f7a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051f7a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018320cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e88940();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Mouse,class_RBX::RbxRay>::
              GetImpl<class_RBX::RbxRay_(__thiscall_RBX::Mouse::*)(void)const_>::vftable;
    puVar3[2] = &LAB_00c3b2ee;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d370();
  FUN_009ca670(uVar2,uVar4,s_UnitRay_0214a98c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214a6f8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::RbxRay>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214a72c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214a71c = _DAT_0214a71c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214a6f8[2])();
    if (cVar1 != '\0') {
      _DAT_0214a71c = _DAT_0214a71c & 0xfffffff3;
    }
  }
  DAT_0214a6f8 = RBX::Reflection::PropDescriptor<class_RBX::Mouse,class_RBX::RbxRay>::vftable;
  FUN_016f3654(&LAB_018a4760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2040 ; VA 0x0051f8e0 ; FUN_0051f8e0 */

void FUN_0051f8e0(void)

{
  FUN_00e8a900("shape",PTR_s_Part_01d6e9a8,0xe8b610,0,0xe8b9b0,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_018a4800);
  return;
}



/* FUNCTION 2041 ; VA 0x0051f9c0 ; FUN_0051f9c0 */

void FUN_0051f9c0(void)

{
  FUN_00e8a9e0("formFactorRaw",PTR_s_Part_01d6e9a8,0xb51a7e,0,0xe8b900,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_018a4820);
  return;
}



/* FUNCTION 2042 ; VA 0x0051fa60 ; FUN_0051fa60 */

void FUN_0051fa60(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  undefined *puStack_1c;
  undefined4 uStack_18;
  code *pcStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x14);
  pcStack_10 = FUN_00553510;
  uStack_c = 0;
  puStack_1c = &LAB_00b51a7e;
  uStack_18 = 0;
  FUN_00e8a9e0("formFactor",PTR_s_Part_01d6e9a8,0xb51a7e,0,0x553510,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_018a4840);
  return;
}



/* FUNCTION 2043 ; VA 0x0051faf0 ; FUN_0051faf0 */

void FUN_0051faf0(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  undefined *puStack_1c;
  undefined4 uStack_18;
  code *pcStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x15);
  pcStack_10 = FUN_00553510;
  uStack_c = 0;
  puStack_1c = &LAB_00b51a7e;
  uStack_18 = 0;
  FUN_00e8a9e0(&DAT_0194e7f4,PTR_s_Part_01d6e9a8,0xb51a7e,0,0x553510,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_018a4860);
  return;
}



/* FUNCTION 2044 ; VA 0x0051fb80 ; FUN_0051fb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051fb80(void)

{
  undefined *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = PTR_s_Part_01d6e9a8;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01832454;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00b0f6f0();
  uVar4 = FUN_00e8aac0();
  FUN_009ca670(uVar4,uVar3,&DAT_019a7b34,puVar1,uStack_30,0,0,4,0,0,1);
  uStack_8 = 0;
  DAT_01f21800 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::BasicPartInstance,enum_RBX::PartInstance::LegacyPartType>
                 ::vftable;
  _DAT_01f21834 = uVar3;
  DAT_01f21838 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f21838 == (undefined4 *)0x0) {
    DAT_01f21838 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f21838 + 2) = 0xe8b9b0;
    *DAT_01f21838 =
         RBX::Reflection::
         PropDescriptor<class_RBX::BasicPartInstance,enum_RBX::PartInstance::LegacyPartType>::
         SetImpl<void_(__thiscall_RBX::BasicPartInstance::*)(enum_RBX::PartInstance::LegacyPartType)>
         ::vftable;
    DAT_01f21838[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f2183c = FUN_00b0f6f0();
  cVar2 = (*(code *)DAT_01f21800[3])();
  if (cVar2 != '\0') {
    _DAT_01f21824 = _DAT_01f21824 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_01f21800[2])();
  if (cVar2 != '\0') {
    _DAT_01f21824 = _DAT_01f21824 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4880);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2045 ; VA 0x0051fcb0 ; FUN_0051fcb0 */

void FUN_0051fcb0(void)

{
  FUN_00e8a900("Shape",PTR_s_Part_01d6e9a8,0xe8b610,0,0xe8b940,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_018a48a0);
  return;
}



/* FUNCTION 2046 ; VA 0x0051fd90 ; FUN_0051fd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051fd90(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01832a88;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e8c060(uVar2,0);
  FUN_009cb790(uVar1,s_Create_0214aa8c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0214a9d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TweenService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::TweenInfo,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),3>
       ::vftable;
  _DAT_0214aa08 = FUN_00e8ecb0;
  _DAT_0214aa0c = 0;
  _DAT_0214aa10 = 0;
  _DAT_0214aa14 = 0;
  _DAT_0214aa18 = 0;
  uStack_8 = 3;
  FUN_00e8f390(s_instance_02126630,s_tweenInfo_0214aa80,s_propertyTable_0214aa70);
  FUN_016f3654(&LAB_018a4990);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2047 ; VA 0x0051fe60 ; FUN_0051fe60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051fe60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01832ac8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e8c060(uVar2,0);
  FUN_009cb790(uVar1,s_GetValue_02125ba0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0214aa20 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TweenService,float___cdecl(float,enum_RBX::TweenInfo::TweenEasingStyle,enum_RBX::TweenInfo::TweenEasingDirection),3>
       ::vftable;
  _DAT_0214aa58 = FUN_00e913d0;
  _DAT_0214aa5c = 0;
  DAT_0214aa60 = 0;
  DAT_0214aa64 = 0;
  DAT_0214aa68 = 0;
  uStack_8 = 3;
  FUN_00e8f850(s_alpha_0214aa94,s_easingStyle_021391b0,s_easingDirection_021391bc);
  FUN_016f3654(&LAB_018a49a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2048 ; VA 0x0051ff60 ; FUN_0051ff60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0051ff60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018330ac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e95050();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase3d,bool>::
              GetSetImpl<bool_(__thiscall_RBX::GuiBase3d::*)(void)const_,void_(__thiscall_RBX::GuiBase3d::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_00c23510;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e95350;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"Visible",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01f2240c = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f22440 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f22430 = _DAT_01f22430 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f2240c[2])();
    if (cVar1 != '\0') {
      _DAT_01f22430 = _DAT_01f22430 & 0xfffffff3;
    }
  }
  DAT_01f2240c = RBX::Reflection::PropDescriptor<class_RBX::GuiBase3d,bool>::vftable;
  FUN_016f3654(&LAB_018a4a10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2049 ; VA 0x00520090 ; FUN_00520090 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00520090(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018330dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e95050();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase3d,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::GuiBase3d::*)(void)const_,void_(__thiscall_RBX::GuiBase3d::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_00a6bd00;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e952c0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,"Color3","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f22364 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f22398 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f22388 = _DAT_01f22388 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f22364[2])();
    if (cVar1 != '\0') {
      _DAT_01f22388 = _DAT_01f22388 & 0xfffffff3;
    }
  }
  DAT_01f22364 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase3d,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_018a4a30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2050 ; VA 0x005201c0 ; FUN_005201c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005201c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183310c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e95050();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase3d,float>::
              GetSetImpl<float_(__thiscall_RBX::GuiBase3d::*)(void)const_,void_(__thiscall_RBX::GuiBase3d::*)(float)>
              ::vftable;
    puVar3[2] = FUN_00832170;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e95320;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,"Transparency","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f223d4 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f22408 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f223f8 = _DAT_01f223f8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f223d4[2])();
    if (cVar1 != '\0') {
      _DAT_01f223f8 = _DAT_01f223f8 & 0xfffffff3;
    }
  }
  DAT_01f223d4 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase3d,float>::vftable;
  FUN_016f3654(&LAB_018a4a50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2051 ; VA 0x005206c0 ; FUN_005206c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005206c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183322c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e956e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BillboardGui,class_RBX::UDim2>::
              GetSetImpl<class_RBX::UDim2_(__thiscall_RBX::BillboardGui::*)(void)const_,void_(__thiscall_RBX::BillboardGui::*)(class_RBX::UDim2)>
              ::vftable;
    puVar3[2] = FUN_00e97350;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e97de0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d5f0();
  FUN_009ca670(uVar2,uVar4,&DAT_02124b6c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214abf0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214ac24 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214ac14 = _DAT_0214ac14 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214abf0[2])();
    if (cVar1 != '\0') {
      _DAT_0214ac14 = _DAT_0214ac14 & 0xfffffff3;
    }
  }
  DAT_0214abf0 = RBX::Reflection::PropDescriptor<class_RBX::BillboardGui,class_RBX::UDim2>::vftable;
  FUN_016f3654(&LAB_018a4b20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2052 ; VA 0x00520da0 ; FUN_00520da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00520da0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183325c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e956e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BillboardGui,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_const&_(__thiscall_RBX::BillboardGui::*)(void)const_,void_(__thiscall_RBX::BillboardGui::*)(class_G3D::Vector2_const&)>
              ::vftable;
    puVar3[2] = &LAB_00e97370;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e97e60;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_SizeOffset_0214aeb0,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214abb8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214abec = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214abdc = _DAT_0214abdc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214abb8[2])();
    if (cVar1 != '\0') {
      _DAT_0214abdc = _DAT_0214abdc & 0xfffffff3;
    }
  }
  DAT_0214abb8 = RBX::Reflection::PropDescriptor<class_RBX::BillboardGui,class_G3D::Vector2>::
                 vftable;
  FUN_016f3654(&LAB_018a4c60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2053 ; VA 0x00521040 ; FUN_00521040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521040(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183339c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e98320();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SurfaceGui,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_(__thiscall_RBX::SurfaceGui::*)(void)const_,void_(__thiscall_RBX::SurfaceGui::*)(class_G3D::Vector2)>
              ::vftable;
    puVar3[2] = FUN_00e98fc0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e9a410;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_CanvasSize_0214b190,s_Sizing_0214b188,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214afec = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b020 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b010 = _DAT_0214b010 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214afec[2])();
    if (cVar1 != '\0') {
      _DAT_0214b010 = _DAT_0214b010 & 0xfffffff3;
    }
  }
  DAT_0214afec = RBX::Reflection::PropDescriptor<class_RBX::SurfaceGui,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_018a4d40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2054 ; VA 0x005211f0 ; FUN_005211f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005211f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018333c4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e9a720();
  uVar3 = FUN_00e98320();
  FUN_009ca670(uVar3,uVar2,s_SizingMode_0214b1b8,s_Sizing_0214b188,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214b0a0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::SurfaceGui,enum_RBX::SurfaceGui::SizingMode>::vftable
  ;
  _DAT_0214b0d4 = uVar2;
  DAT_0214b0d8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214b0d8 == (undefined4 *)0x0) {
    DAT_0214b0d8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214b0d8 =
         RBX::Reflection::PropDescriptor<class_RBX::SurfaceGui,enum_RBX::SurfaceGui::SizingMode>::
         GetSetImpl<enum_RBX::SurfaceGui::SizingMode_(__thiscall_RBX::SurfaceGui::*)(void)const_,void_(__thiscall_RBX::SurfaceGui::*)(enum_RBX::SurfaceGui::SizingMode)>
         ::vftable;
    DAT_0214b0d8[2] = &LAB_00e993c0;
    DAT_0214b0d8[3] = 0;
    DAT_0214b0d8[4] = FUN_00e9a590;
    DAT_0214b0d8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214b0dc = FUN_00e9a720();
  cVar1 = (*(code *)DAT_0214b0a0[3])();
  if (cVar1 != '\0') {
    _DAT_0214b0c4 = _DAT_0214b0c4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214b0a0[2])();
  if (cVar1 != '\0') {
    _DAT_0214b0c4 = _DAT_0214b0c4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4d80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2055 ; VA 0x00521310 ; FUN_00521310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521310(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018333e4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00e98320();
  FUN_009ca670(uVar3,uVar2,&DAT_021467d8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214b028 = RBX::Reflection::EnumPropDescriptor<class_RBX::SurfaceGui,enum_RBX::NormalId>::
                 vftable;
  _DAT_0214b05c = uVar2;
  DAT_0214b060 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214b060 == (undefined4 *)0x0) {
    DAT_0214b060 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214b060 =
         RBX::Reflection::PropDescriptor<class_RBX::SurfaceGui,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::SurfaceGui::*)(void)const_,void_(__thiscall_RBX::SurfaceGui::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_0214b060[2] = &LAB_00e99000;
    DAT_0214b060[3] = 0;
    DAT_0214b060[4] = FUN_00e9a4b0;
    DAT_0214b060[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214b064 = FUN_00890320();
  cVar1 = (*(code *)DAT_0214b028[3])();
  if (cVar1 != '\0') {
    _DAT_0214b04c = _DAT_0214b04c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214b028[2])();
  if (cVar1 != '\0') {
    _DAT_0214b04c = _DAT_0214b04c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4da0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2056 ; VA 0x00521630 ; FUN_00521630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521630(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833410;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00e98320();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Adornee_0214ae5c,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0214af08 = RBX::Reflection::RefPropDescriptor<class_RBX::SurfaceGui,class_RBX::Instance>::
                 vftable;
  _DAT_0214af3c =
       RBX::Reflection::RefPropDescriptor<class_RBX::SurfaceGui,class_RBX::Instance>::vftable;
  DAT_0214af40 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214af40 == (undefined4 *)0x0) {
    DAT_0214af40 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214af40 =
         RBX::Reflection::PropDescriptor<class_RBX::SurfaceGui,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::SurfaceGui::*)(void)const_,void_(__thiscall_RBX::SurfaceGui::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0214af40[2] = FUN_00e98f50;
    DAT_0214af40[3] = 0;
    DAT_0214af40[4] = FUN_00e9a0e0;
    DAT_0214af40[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0214af08[3])();
  if (cVar1 != '\0') {
    _DAT_0214af2c = _DAT_0214af2c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214af08[2])();
  if (cVar1 != '\0') {
    _DAT_0214af2c = _DAT_0214af2c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4e40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2057 ; VA 0x00521900 ; FUN_00521900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521900(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833680;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe1c4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efe1c4,uVar3,0,0,0x1f);
    if (DAT_01efe1c4 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01efe1a0 = RBX::Reflection::RefType<class_RBX::Humanoid*>::vftable;
      FUN_016f3654(&LAB_01895c90);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efe1c4);
    }
  }
  uVar2 = FUN_00e9ae90();
  FUN_009ca670(uVar2,&DAT_01efe1a0,"Humanoid",&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01f22b48 = RBX::Reflection::RefPropDescriptor<class_RBX::SelectionLasso,class_RBX::Humanoid>::
                 vftable;
  _DAT_01f22b7c =
       RBX::Reflection::RefPropDescriptor<class_RBX::SelectionLasso,class_RBX::Humanoid>::vftable;
  DAT_01f22b80 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f22b80 == (undefined4 *)0x0) {
    DAT_01f22b80 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f22b80 =
         RBX::Reflection::PropDescriptor<class_RBX::SelectionLasso,class_RBX::Humanoid*>::
         GetSetImpl<class_RBX::Humanoid*_(__thiscall_RBX::SelectionLasso::*)(void)const_,void_(__thiscall_RBX::SelectionLasso::*)(class_RBX::Humanoid*)>
         ::vftable;
    DAT_01f22b80[2] = FUN_00ca5a50;
    DAT_01f22b80[3] = 0;
    DAT_01f22b80[4] = FUN_00e9bc80;
    DAT_01f22b80[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01f22b48[3])();
  if (cVar1 != '\0') {
    _DAT_01f22b6c = _DAT_01f22b6c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f22b48[2])();
  if (cVar1 != '\0') {
    _DAT_01f22b6c = _DAT_01f22b6c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4f00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2058 ; VA 0x00521aa0 ; FUN_00521aa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521aa0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018336b0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c,uVar3,0,0,0x1f);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar2 = FUN_00e9af70();
  FUN_009ca670(uVar2,&DAT_01ee40e8,&DAT_018db81c,&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01f22b84 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::SelectionPartLasso,class_RBX::PartInstance>::vftable;
  _DAT_01f22bb8 =
       RBX::Reflection::RefPropDescriptor<class_RBX::SelectionPartLasso,class_RBX::PartInstance>::
       vftable;
  DAT_01f22bbc = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f22bbc == (undefined4 *)0x0) {
    DAT_01f22bbc = (undefined4 *)0x0;
  }
  else {
    *DAT_01f22bbc =
         RBX::Reflection::PropDescriptor<class_RBX::SelectionPartLasso,class_RBX::PartInstance*>::
         GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::SelectionPartLasso::*)(void)const_,void_(__thiscall_RBX::SelectionPartLasso::*)(class_RBX::PartInstance*)>
         ::vftable;
    DAT_01f22bbc[2] = FUN_00ca5ab0;
    DAT_01f22bbc[3] = 0;
    DAT_01f22bbc[4] = FUN_00e9bd60;
    DAT_01f22bbc[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01f22b84[3])();
  if (cVar1 != '\0') {
    _DAT_01f22ba8 = _DAT_01f22ba8 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f22b84[2])();
  if (cVar1 != '\0') {
    _DAT_01f22ba8 = _DAT_01f22ba8 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a4f20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2059 ; VA 0x00521c40 ; FUN_00521c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521c40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018336dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e9b070();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SelectionPointLasso,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::SelectionPointLasso::*)(void)const_,void_(__thiscall_RBX::SelectionPointLasso::*)(class_G3D::Vector3)>
              ::vftable;
    puVar3[2] = FUN_009d7be0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e9be40;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_Point_0214b20c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214b1d4 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b208 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b1f8 = _DAT_0214b1f8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214b1d4[2])();
    if (cVar1 != '\0') {
      _DAT_0214b1f8 = _DAT_0214b1f8 & 0xfffffff3;
    }
  }
  DAT_0214b1d4 = RBX::Reflection::PropDescriptor<class_RBX::SelectionPointLasso,class_G3D::Vector3>
                 ::vftable;
  FUN_016f3654(&LAB_018a4f40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2060 ; VA 0x00521e60 ; FUN_00521e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521e60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018337bc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e9c240();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::FloorWire,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_(__thiscall_RBX::FloorWire::*)(void)const_,void_(__thiscall_RBX::FloorWire::*)(class_RBX::TextureId)>
              ::vftable;
    puVar3[2] = FUN_00e9d230;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e9e010;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"Texture","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f23290 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f232c4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f232b4 = _DAT_01f232b4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f23290[2])();
    if (cVar1 != '\0') {
      _DAT_01f232b4 = _DAT_01f232b4 & 0xfffffff3;
    }
  }
  DAT_01f23290 = RBX::Reflection::PropDescriptor<class_RBX::FloorWire,class_RBX::TextureId>::vftable
  ;
  FUN_016f3654(&LAB_018a5090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2061 ; VA 0x00521f90 ; FUN_00521f90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00521f90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018337ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e9c240();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::FloorWire,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_(__thiscall_RBX::FloorWire::*)(void)const_,void_(__thiscall_RBX::FloorWire::*)(class_G3D::Vector2)>
              ::vftable;
    puVar3[2] = FUN_00e456d0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e9e0a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,"TextureSize","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f232c8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f232fc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f232ec = _DAT_01f232ec & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f232c8[2])();
    if (cVar1 != '\0') {
      _DAT_01f232ec = _DAT_01f232ec & 0xfffffff3;
    }
  }
  DAT_01f232c8 = RBX::Reflection::PropDescriptor<class_RBX::FloorWire,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_018a50b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2062 ; VA 0x00522310 ; FUN_00522310 */

void FUN_00522310(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e9e650(FUN_00ea08b0,0,s_OpenBrowserWindow_02130a60,&DAT_0211c024,5,uStack_10,0);
  FUN_016f3654(&LAB_018a5230);
  return;
}



/* FUNCTION 2063 ; VA 0x00522370 ; FUN_00522370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522370(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833b3e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e9e550(uVar2,0);
  FUN_009cb790(uVar1,s_OpenNativeOverlay_02130fa4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214b410 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::BrowserService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0214b448 = FUN_00ea0ac0;
  _DAT_0214b44c = 0;
  _DAT_0214b450 = 0;
  _DAT_0214b454 = 0;
  uStack_8 = 2;
  FUN_00b94f90();
  FUN_016f3654(&LAB_018a5250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2064 ; VA 0x00522430 ; FUN_00522430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522430(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833b5a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e9e550(uVar2,0);
  FUN_009cb790(uVar1,s_CloseBrowserWindow_0214b5a4,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214b2e8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::BrowserService,void___cdecl(void),0>::vftable;
  _DAT_0214b320 = FUN_00e9f0c0;
  _DAT_0214b324 = 0;
  _DAT_0214b30c = FUN_00888530();
  FUN_016f3654(&LAB_018a5270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2065 ; VA 0x005224d0 ; FUN_005224d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005224d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833b7a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e9e550(uVar2,0);
  FUN_009cb790(uVar1,s_CopyAuthCookieFromBrowserToEngin_0214b61c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214b458 =
       RBX::Reflection::BoundFuncDesc<class_RBX::BrowserService,void___cdecl(void),0>::vftable;
  _DAT_0214b490 = &LAB_00e9f2e0;
  _DAT_0214b494 = 0;
  _DAT_0214b47c = FUN_00888530();
  FUN_016f3654(&LAB_018a5280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2066 ; VA 0x00522570 ; FUN_00522570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522570(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833bb8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e9e550(uVar2,0);
  FUN_009cb790(uVar1,s_EmitHybridEvent_0214b60c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214b3c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::BrowserService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),3>
       ::vftable;
  _DAT_0214b3f8 = FUN_00e9f950;
  _DAT_0214b3fc = 0;
  _DAT_0214b400 = 0;
  _DAT_0214b404 = 0;
  _DAT_0214b408 = 0;
  uStack_8 = 3;
  FUN_00e9f2f0(s_moduleName_02119274,s_eventName_0214b600,s_params_0214b5d8);
  FUN_016f3654(&LAB_018a5290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2067 ; VA 0x00522640 ; FUN_00522640 */

void FUN_00522640(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e9e650(FUN_00e9fb50,0,s_ExecuteJavaScript_0214b5c4,s_javascript_0214b5b8,5,uStack_10,0);
  FUN_016f3654(&LAB_018a52c0);
  return;
}



/* FUNCTION 2068 ; VA 0x005226a0 ; FUN_005226a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005226a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833bda;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e9e550(uVar2,0);
  FUN_009cb790(uVar1,s_OpenWeChatAuthWindow_0214b578,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214b218 =
       RBX::Reflection::BoundFuncDesc<class_RBX::BrowserService,void___cdecl(void),0>::vftable;
  _DAT_0214b250 = FUN_00ea0c10;
  _DAT_0214b254 = 0;
  _DAT_0214b23c = FUN_00888530();
  FUN_016f3654(&LAB_018a52e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2069 ; VA 0x00522740 ; FUN_00522740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522740(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01833c18;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e9e550(uVar2,0);
  FUN_009cb790(uVar1,s_ReturnToJavaScript_0214b5ec,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214b370 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::BrowserService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),3>
       ::vftable;
  _DAT_0214b3a8 = FUN_00ea0ea0;
  _DAT_0214b3ac = 0;
  _DAT_0214b3b0 = 0;
  DAT_0214b3b4 = 0;
  _DAT_0214b3b8 = 0;
  uStack_8 = 3;
  FUN_00e9f5a0(s_callbackId_0214b5e0,s_success_02119b1c,s_params_0214b5d8);
  FUN_016f3654(&LAB_018a52f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2070 ; VA 0x00522810 ; FUN_00522810 */

void FUN_00522810(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e9e650(FUN_00ea1160,0,s_SendCommand_0214b598,s_command_0214b590,5,uStack_10,0);
  FUN_016f3654(&LAB_018a5330);
  return;
}



/* FUNCTION 2071 ; VA 0x00522930 ; FUN_00522930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522930(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183400c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea1530();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_00ea1dd0;
    puVar3[3] = 0;
    puVar3[4] = FUN_01008f10;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,s_ImageColor3_0213f580,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214b778 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b7ac = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b79c = _DAT_0214b79c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214b778[2])();
    if (cVar1 != '\0') {
      _DAT_0214b79c = _DAT_0214b79c & 0xfffffff3;
    }
  }
  DAT_0214b778 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,class_G3D::Color3>::
                 vftable;
  FUN_016f3654(&LAB_018a5380);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2072 ; VA 0x00522b60 ; FUN_00522b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522b60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01834034;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d1a0();
  uVar3 = FUN_00ea1530();
  FUN_009ca670(uVar3,uVar2,s_ScaleType_0214b984,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214b858 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiImageButton,enum_RBX::GuiObject::ImageScale>::
                 vftable;
  _DAT_0214b88c = uVar2;
  DAT_0214b890 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214b890 == (undefined4 *)0x0) {
    DAT_0214b890 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214b890 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,enum_RBX::GuiObject::ImageScale>
         ::
         GetSetImpl<enum_RBX::GuiObject::ImageScale_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(enum_RBX::GuiObject::ImageScale)>
         ::vftable;
    DAT_0214b890[2] = &LAB_00ea1e30;
    DAT_0214b890[3] = 0;
    DAT_0214b890[4] = FUN_010091f0;
    DAT_0214b890[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214b894 = FUN_00c7d1a0();
  cVar1 = (*(code *)DAT_0214b858[3])();
  if (cVar1 != '\0') {
    _DAT_0214b87c = _DAT_0214b87c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214b858[2])();
  if (cVar1 != '\0') {
    _DAT_0214b87c = _DAT_0214b87c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a53e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2073 ; VA 0x00522d00 ; FUN_00522d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522d00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183405c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea1530();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,bool>::
              GetImpl<bool_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(void)const_>
              ::vftable;
    puVar3[2] = &LAB_00b01988;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_IsLoaded_0211d16c,s_Image_021372fc,uStack_24,0,0,0x15,0,0,0);
  DAT_0214b898 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b8cc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b8bc = _DAT_0214b8bc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214b898[2])();
    if (cVar1 != '\0') {
      _DAT_0214b8bc = _DAT_0214b8bc & 0xfffffff3;
    }
  }
  DAT_0214b898 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,bool>::vftable;
  FUN_016f3654(&LAB_018a5420);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2074 ; VA 0x00522e20 ; FUN_00522e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522e20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183408c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea1530();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,class_G3D::Rect2D>::
              GetSetImpl<class_G3D::Rect2D_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(class_G3D::Rect2D)>
              ::vftable;
    puVar3[2] = FUN_00ea1e70;
    puVar3[3] = 0;
    puVar3[4] = FUN_01009330;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d410();
  FUN_009ca670(uVar2,uVar4,s_SliceCenter_0214b960,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214b7b0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Rect2D>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b7e4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b7d4 = _DAT_0214b7d4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214b7b0[2])();
    if (cVar1 != '\0') {
      _DAT_0214b7d4 = _DAT_0214b7d4 & 0xfffffff3;
    }
  }
  DAT_0214b7b0 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,class_G3D::Rect2D>::
                 vftable;
  FUN_016f3654(&LAB_018a5440);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2075 ; VA 0x00522fd0 ; FUN_00522fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00522fd0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018340bc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea1530();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,class_RBX::UDim2>::
              GetSetImpl<class_RBX::UDim2_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::GuiImageButton,class_RBX::DescribedCreatable<class_RBX::GuiImageButton,class_RBX::GuiButton>_>::*)(class_RBX::UDim2)>
              ::vftable;
    puVar3[2] = FUN_00ea1ea0;
    puVar3[3] = 0;
    puVar3[4] = FUN_01009530;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d5f0();
  FUN_009ca670(uVar2,uVar4,s_TileSize_0214b978,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214b820 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b854 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b844 = _DAT_0214b844 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214b820[2])();
    if (cVar1 != '\0') {
      _DAT_0214b844 = _DAT_0214b844 & 0xfffffff3;
    }
  }
  DAT_0214b820 = RBX::Reflection::PropDescriptor<class_RBX::GuiImageButton,class_RBX::UDim2>::
                 vftable;
  FUN_016f3654(&LAB_018a5480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2076 ; VA 0x00523290 ; FUN_00523290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00523290(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183415c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2500();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(class_RBX::TextureId)>
              ::vftable;
    puVar3[2] = FUN_00ea2910;
    puVar3[3] = 0;
    puVar3[4] = FUN_01008e50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_Image_021372fc,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214b9b0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214b9e4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214b9d4 = _DAT_0214b9d4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214b9b0[2])();
    if (cVar1 != '\0') {
      _DAT_0214b9d4 = _DAT_0214b9d4 & 0xfffffff3;
    }
  }
  DAT_0214b9b0 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_RBX::TextureId>::
                 vftable;
  FUN_016f3654(&LAB_018a5540);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2077 ; VA 0x005233c0 ; FUN_005233c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005233c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183418c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2500();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_00ea2930;
    puVar3[3] = 0;
    puVar3[4] = FUN_01008fa0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,s_ImageColor3_0213f580,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214ba90 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214bac4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214bab4 = _DAT_0214bab4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214ba90[2])();
    if (cVar1 != '\0') {
      _DAT_0214bab4 = _DAT_0214bab4 & 0xfffffff3;
    }
  }
  DAT_0214ba90 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_018a5560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2078 ; VA 0x005235f0 ; FUN_005235f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005235f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018341b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d1a0();
  uVar3 = FUN_00ea2500();
  FUN_009ca670(uVar3,uVar2,s_ScaleType_0214b984,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214bb70 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ImageLabel,enum_RBX::GuiObject::ImageScale>::vftable;
  _DAT_0214bba4 = uVar2;
  DAT_0214bba8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214bba8 == (undefined4 *)0x0) {
    DAT_0214bba8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214bba8 =
         RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,enum_RBX::GuiObject::ImageScale>::
         GetSetImpl<enum_RBX::GuiObject::ImageScale_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(enum_RBX::GuiObject::ImageScale)>
         ::vftable;
    DAT_0214bba8[2] = &LAB_00ea2990;
    DAT_0214bba8[3] = 0;
    DAT_0214bba8[4] = FUN_01009230;
    DAT_0214bba8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214bbac = FUN_00c7d1a0();
  cVar1 = (*(code *)DAT_0214bb70[3])();
  if (cVar1 != '\0') {
    _DAT_0214bb94 = _DAT_0214bb94 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214bb70[2])();
  if (cVar1 != '\0') {
    _DAT_0214bb94 = _DAT_0214bb94 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a55c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2079 ; VA 0x00523790 ; FUN_00523790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00523790(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018341dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2500();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,bool>::
              GetImpl<bool_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(void)const_>
              ::vftable;
    puVar3[2] = &LAB_00b01988;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_IsLoaded_0211d16c,s_Image_021372fc,uStack_24,0,0,0x15,0,0,0);
  DAT_0214bbb0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214bbe4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214bbd4 = _DAT_0214bbd4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214bbb0[2])();
    if (cVar1 != '\0') {
      _DAT_0214bbd4 = _DAT_0214bbd4 & 0xfffffff3;
    }
  }
  DAT_0214bbb0 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,bool>::vftable;
  FUN_016f3654(&LAB_018a5600);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2080 ; VA 0x005238b0 ; FUN_005238b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005238b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183420c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2500();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_G3D::Rect2D>::
              GetSetImpl<class_G3D::Rect2D_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(class_G3D::Rect2D)>
              ::vftable;
    puVar3[2] = FUN_00ea29b0;
    puVar3[3] = 0;
    puVar3[4] = FUN_010093e0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d410();
  FUN_009ca670(uVar2,uVar4,s_SliceCenter_0214b960,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214bac8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Rect2D>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214bafc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214baec = _DAT_0214baec & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214bac8[2])();
    if (cVar1 != '\0') {
      _DAT_0214baec = _DAT_0214baec & 0xfffffff3;
    }
  }
  DAT_0214bac8 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_G3D::Rect2D>::vftable;
  FUN_016f3654(&LAB_018a5620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2081 ; VA 0x00523a60 ; FUN_00523a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00523a60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183423c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2500();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_RBX::UDim2>::
              GetSetImpl<class_RBX::UDim2_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiImageMixin<class_RBX::ImageLabel,class_RBX::DescribedCreatable<class_RBX::ImageLabel,class_RBX::GuiLabel>_>::*)(class_RBX::UDim2)>
              ::vftable;
    puVar3[2] = FUN_00ea29e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_010095f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d5f0();
  FUN_009ca670(uVar2,uVar4,s_TileSize_0214b978,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214bb38 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214bb6c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214bb5c = _DAT_0214bb5c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214bb38[2])();
    if (cVar1 != '\0') {
      _DAT_0214bb5c = _DAT_0214bb5c & 0xfffffff3;
    }
  }
  DAT_0214bb38 = RBX::Reflection::PropDescriptor<class_RBX::ImageLabel,class_RBX::UDim2>::vftable;
  FUN_016f3654(&LAB_018a5660);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2082 ; VA 0x00523ba0 ; FUN_00523ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00523ba0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018343ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2d80();
  FUN_009cb790(uVar2,s_SetTextFromInput_02135e6c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214c0a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiTextButton,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214c0e0 = FUN_00fac720;
  _DAT_0214c0e4 = 0;
  DAT_0214c0e8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214c0cc = FUN_00888530();
  iVar1 = DAT_0214c0e8;
  if (DAT_0214c0e8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02126680);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a56e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2083 ; VA 0x00523e10 ; FUN_00523e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00523e10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018343d4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896cc0();
  uVar3 = FUN_00ea2d80();
  FUN_009ca670(uVar3,uVar2,&DAT_02135d78,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214bcd0 = RBX::Reflection::EnumPropDescriptor<class_RBX::GuiTextButton,enum_RBX::Text::Font>
                 ::vftable;
  _DAT_0214bd04 = uVar2;
  DAT_0214bd08 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214bd08 == (undefined4 *)0x0) {
    DAT_0214bd08 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214bd08 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,enum_RBX::Text::Font>::
         GetSetImpl<enum_RBX::Text::Font_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(enum_RBX::Text::Font)>
         ::vftable;
    DAT_0214bd08[2] = &LAB_00ea35d0;
    DAT_0214bd08[3] = 0;
    DAT_0214bd08[4] = FUN_00fab4c0;
    DAT_0214bd08[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214bd0c = FUN_00896cc0();
  cVar1 = (*(code *)DAT_0214bcd0[3])();
  if (cVar1 != '\0') {
    _DAT_0214bcf4 = _DAT_0214bcf4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214bcd0[2])();
  if (cVar1 != '\0') {
    _DAT_0214bcf4 = _DAT_0214bcf4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2084 ; VA 0x00524320 ; FUN_00524320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00524320(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183441c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2d80();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_00fa7960;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_TextBounds_02135e18,&DAT_02134cf8,uStack_24,0,0,0x15,0,0,0);
  DAT_0214bf90 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214bfc4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214bfb4 = _DAT_0214bfb4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214bf90[2])();
    if (cVar1 != '\0') {
      _DAT_0214bfb4 = _DAT_0214bfb4 & 0xfffffff3;
    }
  }
  DAT_0214bf90 = RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,class_G3D::Vector2>::
                 vftable;
  FUN_016f3654(&LAB_018a57e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2085 ; VA 0x005244c0 ; FUN_005244c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005244c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183444c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea2d80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = FUN_00ea3680;
    puVar3[3] = 0;
    puVar3[4] = FUN_00fac540;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TextColor_02135d80,&DAT_02134cf8,uStack_24,0,0,0x14,0,0,0);
  DAT_0214bd10 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214bd44 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214bd34 = _DAT_0214bd34 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214bd10[2])();
    if (cVar1 != '\0') {
      _DAT_0214bd34 = _DAT_0214bd34 & 0xfffffff3;
    }
  }
  DAT_0214bd10 = RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,class_RBX::BrickColor>::
                 vftable;
  FUN_016f3654(&LAB_018a5820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2086 ; VA 0x005248e0 ; FUN_005248e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005248e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01834474;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c458b0();
  uVar3 = FUN_00ea2d80();
  FUN_009ca670(uVar3,uVar2,s_TextTruncate_02135e08,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214bf50 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiTextButton,enum_RBX::TextService::TextTruncate>::
                 vftable;
  _DAT_0214bf84 = uVar2;
  DAT_0214bf88 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214bf88 == (undefined4 *)0x0) {
    DAT_0214bf88 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214bf88 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GuiTextButton,enum_RBX::TextService::TextTruncate>::
         GetSetImpl<enum_RBX::TextService::TextTruncate_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(enum_RBX::TextService::TextTruncate)>
         ::vftable;
    DAT_0214bf88[2] = &LAB_00ea3700;
    DAT_0214bf88[3] = 0;
    DAT_0214bf88[4] = FUN_00fad830;
    DAT_0214bf88[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214bf8c = FUN_00c458b0();
  cVar1 = (*(code *)DAT_0214bf50[3])();
  if (cVar1 != '\0') {
    _DAT_0214bf74 = _DAT_0214bf74 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214bf50[2])();
  if (cVar1 != '\0') {
    _DAT_0214bf74 = _DAT_0214bf74 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a58e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2087 ; VA 0x00524ac0 ; FUN_00524ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00524ac0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01834494;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c45940();
  uVar3 = FUN_00ea2d80();
  FUN_009ca670(uVar3,uVar2,s_TextXAlignment_02135de8,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214bed0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiTextButton,enum_RBX::TextService::XAlignment>::
                 vftable;
  _DAT_0214bf04 = uVar2;
  DAT_0214bf08 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214bf08 == (undefined4 *)0x0) {
    DAT_0214bf08 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214bf08 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,enum_RBX::TextService::XAlignment>
         ::
         GetSetImpl<enum_RBX::TextService::XAlignment_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(enum_RBX::TextService::XAlignment)>
         ::vftable;
    DAT_0214bf08[2] = &LAB_00ea3720;
    DAT_0214bf08[3] = 0;
    DAT_0214bf08[4] = FUN_00fadb90;
    DAT_0214bf08[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214bf0c = FUN_00c45940();
  cVar1 = (*(code *)DAT_0214bed0[3])();
  if (cVar1 != '\0') {
    _DAT_0214bef4 = _DAT_0214bef4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214bed0[2])();
  if (cVar1 != '\0') {
    _DAT_0214bef4 = _DAT_0214bef4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2088 ; VA 0x00524be0 ; FUN_00524be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00524be0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018344b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c459d0();
  uVar3 = FUN_00ea2d80();
  FUN_009ca670(uVar3,uVar2,s_TextYAlignment_02135df8,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214bf10 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiTextButton,enum_RBX::TextService::YAlignment>::
                 vftable;
  _DAT_0214bf44 = uVar2;
  DAT_0214bf48 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214bf48 == (undefined4 *)0x0) {
    DAT_0214bf48 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214bf48 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiTextButton,enum_RBX::TextService::YAlignment>
         ::
         GetSetImpl<enum_RBX::TextService::YAlignment_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::GuiTextButton,class_RBX::DescribedCreatable<class_RBX::GuiTextButton,class_RBX::GuiButton>_>::*)(enum_RBX::TextService::YAlignment)>
         ::vftable;
    DAT_0214bf48[2] = &LAB_00ea3730;
    DAT_0214bf48[3] = 0;
    DAT_0214bf48[4] = FUN_00fadc20;
    DAT_0214bf48[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214bf4c = FUN_00c459d0();
  cVar1 = (*(code *)DAT_0214bf10[3])();
  if (cVar1 != '\0') {
    _DAT_0214bf34 = _DAT_0214bf34 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214bf10[2])();
  if (cVar1 != '\0') {
    _DAT_0214bf34 = _DAT_0214bf34 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2089 ; VA 0x00524e80 ; FUN_00524e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00524e80(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018345cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea39d0();
  FUN_009cb790(uVar2,s_SetTextFromInput_02135e6c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214c5c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TextLabel,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214c5f8 = FUN_00fac800;
  _DAT_0214c5fc = 0;
  DAT_0214c600 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214c5e4 = FUN_00888530();
  iVar1 = DAT_0214c600;
  if (DAT_0214c600 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02126680);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a5a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2090 ; VA 0x005250f0 ; FUN_005250f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005250f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018345f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896cc0();
  uVar3 = FUN_00ea39d0();
  FUN_009ca670(uVar3,uVar2,&DAT_02135d78,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214c1e8 = RBX::Reflection::EnumPropDescriptor<class_RBX::TextLabel,enum_RBX::Text::Font>::
                 vftable;
  _DAT_0214c21c = uVar2;
  DAT_0214c220 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214c220 == (undefined4 *)0x0) {
    DAT_0214c220 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214c220 =
         RBX::Reflection::PropDescriptor<class_RBX::TextLabel,enum_RBX::Text::Font>::
         GetSetImpl<enum_RBX::Text::Font_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(enum_RBX::Text::Font)>
         ::vftable;
    DAT_0214c220[2] = &LAB_00c41fe0;
    DAT_0214c220[3] = 0;
    DAT_0214c220[4] = FUN_00fab520;
    DAT_0214c220[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214c224 = FUN_00896cc0();
  cVar1 = (*(code *)DAT_0214c1e8[3])();
  if (cVar1 != '\0') {
    _DAT_0214c20c = _DAT_0214c20c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214c1e8[2])();
  if (cVar1 != '\0') {
    _DAT_0214c20c = _DAT_0214c20c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5a40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2091 ; VA 0x005255d0 ; FUN_005255d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005255d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183463c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea39d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TextLabel,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_00fa7a50;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_TextBounds_02135e18,&DAT_02134cf8,uStack_24,0,0,0x15,0,0,0);
  DAT_0214c4a8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214c4dc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214c4cc = _DAT_0214c4cc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214c4a8[2])();
    if (cVar1 != '\0') {
      _DAT_0214c4cc = _DAT_0214c4cc & 0xfffffff3;
    }
  }
  DAT_0214c4a8 = RBX::Reflection::PropDescriptor<class_RBX::TextLabel,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_018a5b00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2092 ; VA 0x00525770 ; FUN_00525770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00525770(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183466c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea39d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TextLabel,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = FUN_00c42100;
    puVar3[3] = 0;
    puVar3[4] = FUN_00fac680;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TextColor_02135d80,&DAT_02134cf8,uStack_24,0,0,0x14,0,0,0);
  DAT_0214c228 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214c25c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214c24c = _DAT_0214c24c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214c228[2])();
    if (cVar1 != '\0') {
      _DAT_0214c24c = _DAT_0214c24c & 0xfffffff3;
    }
  }
  DAT_0214c228 = RBX::Reflection::PropDescriptor<class_RBX::TextLabel,class_RBX::BrickColor>::
                 vftable;
  FUN_016f3654(&LAB_018a5b40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2093 ; VA 0x00525b90 ; FUN_00525b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00525b90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01834694;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c458b0();
  uVar3 = FUN_00ea39d0();
  FUN_009ca670(uVar3,uVar2,s_TextTruncate_02135e08,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214c468 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextLabel,enum_RBX::TextService::TextTruncate>::
                 vftable;
  _DAT_0214c49c = uVar2;
  DAT_0214c4a0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214c4a0 == (undefined4 *)0x0) {
    DAT_0214c4a0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214c4a0 =
         RBX::Reflection::PropDescriptor<class_RBX::TextLabel,enum_RBX::TextService::TextTruncate>::
         GetSetImpl<enum_RBX::TextService::TextTruncate_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(enum_RBX::TextService::TextTruncate)>
         ::vftable;
    DAT_0214c4a0[2] = &LAB_00c421a0;
    DAT_0214c4a0[3] = 0;
    DAT_0214c4a0[4] = FUN_00fad890;
    DAT_0214c4a0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214c4a4 = FUN_00c458b0();
  cVar1 = (*(code *)DAT_0214c468[3])();
  if (cVar1 != '\0') {
    _DAT_0214c48c = _DAT_0214c48c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214c468[2])();
  if (cVar1 != '\0') {
    _DAT_0214c48c = _DAT_0214c48c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5c00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2094 ; VA 0x00525d70 ; FUN_00525d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00525d70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018346b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c45940();
  uVar3 = FUN_00ea39d0();
  FUN_009ca670(uVar3,uVar2,s_TextXAlignment_02135de8,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214c3e8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextLabel,enum_RBX::TextService::XAlignment>::vftable
  ;
  _DAT_0214c41c = uVar2;
  DAT_0214c420 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214c420 == (undefined4 *)0x0) {
    DAT_0214c420 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214c420 =
         RBX::Reflection::PropDescriptor<class_RBX::TextLabel,enum_RBX::TextService::XAlignment>::
         GetSetImpl<enum_RBX::TextService::XAlignment_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(enum_RBX::TextService::XAlignment)>
         ::vftable;
    DAT_0214c420[2] = &LAB_00c42460;
    DAT_0214c420[3] = 0;
    DAT_0214c420[4] = FUN_00fadbf0;
    DAT_0214c420[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214c424 = FUN_00c45940();
  cVar1 = (*(code *)DAT_0214c3e8[3])();
  if (cVar1 != '\0') {
    _DAT_0214c40c = _DAT_0214c40c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214c3e8[2])();
  if (cVar1 != '\0') {
    _DAT_0214c40c = _DAT_0214c40c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5c40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2095 ; VA 0x00525e90 ; FUN_00525e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00525e90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018346d4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c459d0();
  uVar3 = FUN_00ea39d0();
  FUN_009ca670(uVar3,uVar2,s_TextYAlignment_02135df8,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214c428 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextLabel,enum_RBX::TextService::YAlignment>::vftable
  ;
  _DAT_0214c45c = uVar2;
  DAT_0214c460 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214c460 == (undefined4 *)0x0) {
    DAT_0214c460 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214c460 =
         RBX::Reflection::PropDescriptor<class_RBX::TextLabel,enum_RBX::TextService::YAlignment>::
         GetSetImpl<enum_RBX::TextService::YAlignment_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextLabel,class_RBX::DescribedCreatable<class_RBX::TextLabel,class_RBX::GuiLabel>_>::*)(enum_RBX::TextService::YAlignment)>
         ::vftable;
    DAT_0214c460[2] = &LAB_00c42470;
    DAT_0214c460[3] = 0;
    DAT_0214c460[4] = FUN_00fadc80;
    DAT_0214c460[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214c464 = FUN_00c459d0();
  cVar1 = (*(code *)DAT_0214c428[3])();
  if (cVar1 != '\0') {
    _DAT_0214c44c = _DAT_0214c44c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214c428[2])();
  if (cVar1 != '\0') {
    _DAT_0214c44c = _DAT_0214c44c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5c60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2096 ; VA 0x00526160 ; FUN_00526160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00526160(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01834780;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00ea3f40();
  FUN_009ca670(uVar2,&DAT_01edf850,"Adornee",&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01f24120 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::InstanceAdornment,class_RBX::Instance>::vftable;
  _DAT_01f24154 =
       RBX::Reflection::RefPropDescriptor<class_RBX::InstanceAdornment,class_RBX::Instance>::vftable
  ;
  DAT_01f24158 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f24158 == (undefined4 *)0x0) {
    DAT_01f24158 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f24158 =
         RBX::Reflection::PropDescriptor<class_RBX::InstanceAdornment,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::InstanceAdornment::*)(void)const_,void_(__thiscall_RBX::InstanceAdornment::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_01f24158[2] = FUN_00ca5a50;
    DAT_01f24158[3] = 0;
    DAT_01f24158[4] = FUN_00ea4420;
    DAT_01f24158[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01f24120[3])();
  if (cVar1 != '\0') {
    _DAT_01f24144 = _DAT_01f24144 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f24120[2])();
  if (cVar1 != '\0') {
    _DAT_01f24144 = _DAT_01f24144 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5d20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2097 ; VA 0x00526300 ; FUN_00526300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00526300(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018347b0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c,uVar3,0,0,0x1f);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar2 = FUN_00ea4100();
  FUN_009ca670(uVar2,&DAT_01ee40e8,"Adornee",&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01f240a8 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::PartAdornment,class_RBX::PartInstance>::vftable;
  _DAT_01f240dc =
       RBX::Reflection::RefPropDescriptor<class_RBX::PartAdornment,class_RBX::PartInstance>::vftable
  ;
  DAT_01f240e0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f240e0 == (undefined4 *)0x0) {
    DAT_01f240e0 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f240e0 =
         RBX::Reflection::PropDescriptor<class_RBX::PartAdornment,class_RBX::PartInstance*>::
         GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::PartAdornment::*)(void)const_,void_(__thiscall_RBX::PartAdornment::*)(class_RBX::PartInstance*)>
         ::vftable;
    DAT_01f240e0[2] = FUN_00ca5a50;
    DAT_01f240e0[3] = 0;
    DAT_01f240e0[4] = FUN_00ea45c0;
    DAT_01f240e0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01f240a8[3])();
  if (cVar1 != '\0') {
    _DAT_01f240cc = _DAT_01f240cc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f240a8[2])();
  if (cVar1 != '\0') {
    _DAT_01f240cc = _DAT_01f240cc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5d40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2098 ; VA 0x005264a0 ; FUN_005264a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005264a0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018347e0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f247cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f247cc,uVar3,0,0,0x1f);
    if (DAT_01f247cc == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01f247a8 = RBX::Reflection::RefType<class_RBX::PVInstance*>::vftable;
      FUN_016f3654(&LAB_018a5db0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01f247cc);
    }
  }
  uVar2 = FUN_00ea4020();
  FUN_009ca670(uVar2,&DAT_01f247a8,"Adornee",&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01f240e4 = RBX::Reflection::RefPropDescriptor<class_RBX::PVAdornment,class_RBX::PVInstance>::
                 vftable;
  _DAT_01f24118 =
       RBX::Reflection::RefPropDescriptor<class_RBX::PVAdornment,class_RBX::PVInstance>::vftable;
  DAT_01f2411c = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f2411c == (undefined4 *)0x0) {
    DAT_01f2411c = (undefined4 *)0x0;
  }
  else {
    *DAT_01f2411c =
         RBX::Reflection::PropDescriptor<class_RBX::PVAdornment,class_RBX::PVInstance*>::
         GetSetImpl<class_RBX::PVInstance*_(__thiscall_RBX::PVAdornment::*)(void)const_,void_(__thiscall_RBX::PVAdornment::*)(class_RBX::PVInstance*)>
         ::vftable;
    DAT_01f2411c[2] = FUN_00ca5a50;
    DAT_01f2411c[3] = 0;
    DAT_01f2411c[4] = FUN_00ea44f0;
    DAT_01f2411c[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01f240e4[3])();
  if (cVar1 != '\0') {
    _DAT_01f24108 = _DAT_01f24108 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f240e4[2])();
  if (cVar1 != '\0') {
    _DAT_01f24108 = _DAT_01f24108 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a5d60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2099 ; VA 0x005266e0 ; FUN_005266e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005266e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183490c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea55c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SelectionBox,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::SelectionBox::*)(void)const_,void_(__thiscall_RBX::SelectionBox::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_009d7be0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ea6120;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,"SurfaceColor3","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f249ec = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f24a20 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f24a10 = _DAT_01f24a10 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f249ec[2])();
    if (cVar1 != '\0') {
      _DAT_01f24a10 = _DAT_01f24a10 & 0xfffffff3;
    }
  }
  DAT_01f249ec = RBX::Reflection::PropDescriptor<class_RBX::SelectionBox,class_G3D::Color3>::vftable
  ;
  FUN_016f3654(&LAB_018a5df0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2100 ; VA 0x005269e0 ; FUN_005269e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005269e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018349fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea61d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SelectionSphere,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::SelectionSphere::*)(void)const_,void_(__thiscall_RBX::SelectionSphere::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_009d7be0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ea6a70;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,"SurfaceColor3","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f24cf0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f24d24 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f24d14 = _DAT_01f24d14 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f24cf0[2])();
    if (cVar1 != '\0') {
      _DAT_01f24d14 = _DAT_01f24d14 & 0xfffffff3;
    }
  }
  DAT_01f24cf0 = RBX::Reflection::PropDescriptor<class_RBX::SelectionSphere,class_G3D::Color3>::
                 vftable;
  FUN_016f3654(&LAB_018a5eb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2101 ; VA 0x00526b10 ; FUN_00526b10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00526b10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01834a2c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea61d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SelectionSphere,float>::
              GetSetImpl<float_(__thiscall_RBX::SelectionSphere::*)(void)const_,void_(__thiscall_RBX::SelectionSphere::*)(float)>
              ::vftable;
    puVar3[2] = FUN_009d7b60;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ea6ae0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,"SurfaceTransparency","Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f24d60 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f24d94 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f24d84 = _DAT_01f24d84 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f24d60[2])();
    if (cVar1 != '\0') {
      _DAT_01f24d84 = _DAT_01f24d84 & 0xfffffff3;
    }
  }
  DAT_01f24d60 = RBX::Reflection::PropDescriptor<class_RBX::SelectionSphere,float>::vftable;
  FUN_016f3654(&LAB_018a5ed0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2102 ; VA 0x00526d90 ; FUN_00526d90 */

void FUN_00526d90(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ea6f90(FUN_00ea76c0,0,s_FindPartOnParabola_0214c77c,s_ignoreDescendentsTable_02127a20,5,
               uStack_10,0);
  FUN_016f3654(&LAB_018a5f70);
  return;
}



/* FUNCTION 2103 ; VA 0x005271b0 ; FUN_005271b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005271b0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01835283;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ea9400();
  FUN_009cb970(uVar1,"ProgressUpdate",5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214c974 = 0x58;
  iStack_8 = 0;
  _DAT_0214c940 =
       RBX::Reflection::
       EventDesc<class_RBX::HeightmapImporterService,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::HeightmapImporterService::*>
       ::vftable;
  FUN_0086e3d0("progressRatio");
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0214c968 = uStack_1c;
  _DAT_0214c96c = uStack_18;
  _DAT_0214c970 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0214c940 =
       RBX::Reflection::
       EventDesc<class_RBX::HeightmapImporterService,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::HeightmapImporterService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a6180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2104 ; VA 0x00527300 ; FUN_00527300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527300(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183529a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ea9400(uVar2,0);
  FUN_009cb790(uVar1,s_CancelImportHeightmap_0212a2a0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214c900 =
       RBX::Reflection::BoundFuncDesc<class_RBX::HeightmapImporterService,void___cdecl(void),0>::
       vftable;
  _DAT_0214c938 = FUN_00eacc60;
  _DAT_0214c93c = 0;
  _DAT_0214c924 = FUN_00888530();
  FUN_016f3654(&LAB_018a6190);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2105 ; VA 0x005273a0 ; FUN_005273a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005273a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018352fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ea9400();
  FUN_009cb820(uVar1,s_GetHeightmapPreviewAsync_0214c99c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214c820 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::HeightmapImporterService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_RBX::ContentId),1>
       ::vftable;
  _DAT_0214c858 = FUN_00eafaa0;
  _DAT_0214c85c = 0;
  DAT_0214c860 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214c844 = FUN_0088cbe0();
  if (DAT_0214c860 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_008bc760(DAT_0214c860);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(s_heightmapAssetId_0212a258);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a61a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2106 ; VA 0x00527520 ; FUN_00527520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527520(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835342;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ea9400(uVar2,0);
  FUN_009cb820(uVar1,s_ImportHeightmap_0212a26c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214c868 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::HeightmapImporterService,void___cdecl(class_RBX::Region3,class_RBX::ContentId_const&,class_RBX::ContentId_const&,enum_RBX::PartMaterial),4>
       ::vftable;
  _DAT_0214c8a0 = FUN_00eb08d0;
  _DAT_0214c8a4 = 0;
  DAT_0214c8a8 = 0;
  _DAT_0214c8ac = 0;
  _DAT_0214c8b0 = 0;
  DAT_0214c8b4 = 0;
  uStack_8 = 4;
  FUN_00ead030(s_region_02127980,s_heightmapAssetId_0212a258,s_colormapAssetId_0212a248,
               s_defaultMaterial_0212a238);
  FUN_016f3654(&LAB_018a61c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2107 ; VA 0x00527600 ; FUN_00527600 */

void FUN_00527600(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eaaa80(FUN_00eb0fe0,0,s_IsValidColormap_0214c98c,s_colormapAssetId_0212a248,5,uStack_10,0);
  FUN_016f3654(&LAB_018a6210);
  return;
}



/* FUNCTION 2108 ; VA 0x00527660 ; FUN_00527660 */

void FUN_00527660(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eaaa80(FUN_00eb1310,0,s_IsValidHeightmap_0214c978,s_heightmapAssetId_0212a258,5,uStack_10,0)
  ;
  FUN_016f3654(&LAB_018a6230);
  return;
}



/* FUNCTION 2109 ; VA 0x005276c0 ; FUN_005276c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005276c0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183539c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ea9400();
  FUN_009cb790(uVar2,s_SetImportHeightmapPaused_0212a284,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214c8b8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::HeightmapImporterService,void___cdecl(bool),1>::
       vftable;
  _DAT_0214c8f0 = FUN_00eb3030;
  _DAT_0214c8f4 = 0;
  DAT_0214c8f8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214c8dc = FUN_00888530();
  iVar1 = DAT_0214c8f8;
  if (DAT_0214c8f8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar4 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_1c0 = FUN_0088daf0();
    FUN_005c1650(iVar1);
    puVar4 = &uStack_1c0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_paused_0212a27c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a6250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2110 ; VA 0x00527850 ; FUN_00527850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527850(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835a2c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb3a50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,bool>::
              GetSetImpl<bool_(__thiscall_RBX::PackageLink::*)(void)const_,void_(__thiscall_RBX::PackageLink::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00eb3d90;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eb3e30;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_AutoUpdate_0214cb54,&DAT_0214cb08,uStack_24,0,0,0xf,0,0,0);
  DAT_0214ca98 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214cacc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214cabc = _DAT_0214cabc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214ca98[2])();
    if (cVar1 != '\0') {
      _DAT_0214cabc = _DAT_0214cabc & 0xfffffff3;
    }
  }
  DAT_0214ca98 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,bool>::vftable;
  FUN_016f3654(&LAB_018a62d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2111 ; VA 0x00527980 ; FUN_00527980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527980(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835a5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb3a50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,int>::
              GetSetImpl<int_(__thiscall_RBX::PackageLink::*)(void)const_,void_(__thiscall_RBX::PackageLink::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00c0b480;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eb3e50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_ModifiedState_0214cb60,&DAT_0214cb08,uStack_24,0,0,2,0,0,0);
  DAT_0214cad0 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214cb04 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214caf4 = _DAT_0214caf4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214cad0[2])();
    if (cVar1 != '\0') {
      _DAT_0214caf4 = _DAT_0214caf4 & 0xfffffff3;
    }
  }
  DAT_0214cad0 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,int>::vftable;
  FUN_016f3654(&LAB_018a62f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2112 ; VA 0x00527ab0 ; FUN_00527ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527ab0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835a7a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00eb3a50();
  FUN_009ec390(uVar3,s_PackageId_0214cb10,&DAT_0214cb08,0);
  uStack_8 = 0;
  DAT_0214c9b8 = RBX::Reflection::BoundProp<class_RBX::ContentId,0>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_RBX::ContentId,0>::
              BoundPropGetSet<class_RBX::PackageLink>::vftable;
    puVar4[1] = &DAT_0214c9b8;
    puVar4[2] = 0x54;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0214c9ec != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0214c9ec;
    DAT_0214c9ec = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0214c9ec;
  }
  DAT_0214c9ec = puVar4;
  cVar2 = (*(code *)DAT_0214c9b8[3])();
  if (cVar2 != '\0') {
    _DAT_0214c9dc = _DAT_0214c9dc & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0214c9b8[2])();
  if (cVar2 != '\0') {
    _DAT_0214c9dc = _DAT_0214c9dc & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2113 ; VA 0x00527c90 ; FUN_00527c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527c90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835aac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb3a50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,__int64>::
              GetSetImpl<__int64_(__thiscall_RBX::PackageLink::*)(void)const_,void_(__thiscall_RBX::PackageLink::*)(__int64)>
              ::vftable;
    puVar3[2] = FUN_00eb3de0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eb3f40;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088da50();
  FUN_009ca670(uVar2,uVar4,s_VersionIdSerialize_0214cb40,&DAT_0214cb08,uStack_24,0,0,0xe,0,0,0);
  DAT_0214ca60 = RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214ca94 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214ca84 = _DAT_0214ca84 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214ca60[2])();
    if (cVar1 != '\0') {
      _DAT_0214ca84 = _DAT_0214ca84 & 0xfffffff3;
    }
  }
  DAT_0214ca60 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,__int64>::vftable;
  FUN_016f3654(&LAB_018a6350);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2114 ; VA 0x00527dc0 ; FUN_00527dc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527dc0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835adc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb3a50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,__int64>::
              GetSetImpl<__int64_(__thiscall_RBX::PackageLink::*)(void)const_,void_(__thiscall_RBX::PackageLink::*)(__int64)>
              ::vftable;
    puVar3[2] = FUN_00eb3de0;
    puVar3[3] = 0;
    puVar3[4] = FUN_006159b0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088da50();
  FUN_009ca670(uVar2,uVar4,s_VersionNumber_0214cb1c,&DAT_0214cb08,uStack_24,0,0,0x15,0,7,0);
  DAT_0214c9f0 = RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214ca24 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214ca14 = _DAT_0214ca14 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214c9f0[2])();
    if (cVar1 != '\0') {
      _DAT_0214ca14 = _DAT_0214ca14 & 0xfffffff3;
    }
  }
  DAT_0214c9f0 = RBX::Reflection::PropDescriptor<class_RBX::PackageLink,__int64>::vftable;
  FUN_016f3654(&LAB_018a6370);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2115 ; VA 0x00527f10 ; FUN_00527f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00527f10(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01835b83;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb4030();
  FUN_009cb970(uVar1,s_DragEnter_0214cbb4,1,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214cba4 = 0xb4;
  iStack_8 = 0;
  _DAT_0214cb70 =
       RBX::Reflection::
       EventDesc<class_RBX::PluginMouse,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>)>_RBX::PluginMouse::*>
       ::vftable;
  FUN_0086e3d0(s_instances_0214cba8);
  FUN_0088cc80();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0214cb98 = uStack_1c;
  _DAT_0214cb9c = uStack_18;
  _DAT_0214cba0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0214cb70 =
       RBX::Reflection::
       EventDesc<class_RBX::PluginMouse,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>)>_RBX::PluginMouse::*>
       ::vftable;
  FUN_016f3654(&LAB_018a63f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2116 ; VA 0x00528630 ; FUN_00528630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00528630(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01835e8a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb4840(uVar2,0);
  FUN_009cb790(uVar1,s_CreatePlugin_0214cc98,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214cbc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PluginManager,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0214cbf8 = 0;
  _DAT_0214cbfc = 0;
  _DAT_0214cbe4 = FUN_0088cdc0();
  _DAT_0214cbc0 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::PluginManager,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0214cc00 = FUN_00eb5c90;
  _DAT_0214cc04 = 0;
  _DAT_0214cbf4 = 1;
  FUN_016f3654(&LAB_018a6410);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2117 ; VA 0x00528700 ; FUN_00528700 */

void FUN_00528700(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00eb5120(FUN_00eb5ee0,0,s_ExportPlace_0214ccb4,s_filePath_0214cca8);
  FUN_016f3654();
  return;
}



/* FUNCTION 2118 ; VA 0x005287a0 ; FUN_005287a0 */

void FUN_005287a0(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00eb5120(FUN_00eb5f70,0,s_ExportSelection_0214ccc0,s_filePath_0214cca8);
  FUN_016f3654();
  return;
}



/* FUNCTION 2119 ; VA 0x00528850 ; FUN_00528850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00528850(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183604a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6660(uVar2,0);
  FUN_009cb790(uVar1,s_CreatePlugin_0214cc98,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214ccd0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PluginManagerInterface,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0214cd08 = 0;
  _DAT_0214cd0c = 0;
  _DAT_0214ccf4 = FUN_0088cdc0();
  _DAT_0214ccd0 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::PluginManagerInterface,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0214cd10 = FUN_00eb6a40;
  _DAT_0214cd14 = 0;
  _DAT_0214cd04 = 1;
  FUN_016f3654(&LAB_018a6550);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2120 ; VA 0x00528920 ; FUN_00528920 */

void FUN_00528920(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00eb6740(FUN_00eb6ac0,0,s_ExportPlace_0214ccb4,s_filePath_0214cca8);
  FUN_016f3654();
  return;
}



/* FUNCTION 2121 ; VA 0x005289c0 ; FUN_005289c0 */

void FUN_005289c0(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00eb6740(FUN_00eb6b80,0,s_ExportSelection_0214ccc0,s_filePath_0214cca8);
  FUN_016f3654();
  return;
}



/* FUNCTION 2122 ; VA 0x00528b70 ; FUN_00528b70 */

void FUN_00528b70(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eb83b0(FUN_00ebfc10,0,s_PauseSound_0214dcfc,s_sound_0214dcdc,5,uStack_10,0);
  FUN_016f3654(&LAB_018a65d0);
  return;
}



/* FUNCTION 2123 ; VA 0x00528bd0 ; FUN_00528bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00528bd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183662e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_PlaySound_0214dce4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214d7d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,double),2>
       ::vftable;
  _DAT_0214d808 = FUN_00ebfcd0;
  _DAT_0214d80c = 0;
  _DAT_0214d810 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d814 = (undefined8 *)FUN_01674e20(8);
  if (_DAT_0214d814 == (undefined8 *)0x0) {
    _DAT_0214d814 = (undefined8 *)0x0;
  }
  else {
    *_DAT_0214d814 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00ebb970();
  FUN_016f3654(&LAB_018a6620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2124 ; VA 0x00528cb0 ; FUN_00528cb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00528cb0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836686;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_GetItem_0214d9f0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214ceb0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Reflection::Variant_const&),2>
       ::vftable;
  _DAT_0214cee8 = FUN_00ebe910;
  _DAT_0214ceec = 0;
  _DAT_0214cef0 = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_0214cef4 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_0214cef4 = puVar2;
  }
  uStack_8._0_1_ = 5;
  FUN_00ebb560();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 7;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(FUN_018a6630);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2125 ; VA 0x00528e30 ; FUN_00528e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00528e30(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018366d6;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_SetItem_0214d9e0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214ce20 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Reflection::Variant_const&),2>
       ::vftable;
  _DAT_0214ce58 = FUN_00ec0570;
  _DAT_0214ce5c = 0;
  _DAT_0214ce60 = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_0214ce64 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_0214ce64 = puVar2;
  }
  uStack_8._0_1_ = 5;
  FUN_00b5c940();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 7;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(FUN_018a66a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2126 ; VA 0x00528fb0 ; FUN_00528fb0 */

void FUN_00528fb0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eb83b0(FUN_00ec01a0,0,s_ResumeSound_0214dcf0,s_sound_0214dcdc,5,uStack_10,0);
  FUN_016f3654(&LAB_018a6710);
  return;
}



/* FUNCTION 2127 ; VA 0x00529010 ; FUN_00529010 */

void FUN_00529010(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eb83b0(FUN_00ec0a40,0,s_StartDecalDrag_0214dd50,s_decal_0214dd48,5,uStack_10,0);
  FUN_016f3654(&LAB_018a6760);
  return;
}



/* FUNCTION 2128 ; VA 0x00529070 ; FUN_00529070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529070(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183672c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_StartDrag_0214dd24,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d8e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
       ::vftable;
  _DAT_0214d920 = FUN_00ec0b20;
  _DAT_0214d924 = 0;
  DAT_0214d928 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d90c = FUN_00888530();
  if (DAT_0214d928 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_00687440(DAT_0214d928);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008881d0();
  uVar3 = FUN_0086e3d0(s_dragData_0214dd18);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a67b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2129 ; VA 0x005291f0 ; FUN_005291f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005291f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183674a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_StopAllSounds_0214dd08,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d8a8 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,void___cdecl(void),0>::vftable;
  _DAT_0214d8e0 = FUN_00ec0cb0;
  _DAT_0214d8e4 = 0;
  _DAT_0214d8cc = FUN_00888530();
  FUN_016f3654(&LAB_018a6800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2130 ; VA 0x00529290 ; FUN_00529290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529290(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018367ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb6da0();
  FUN_009cb790(uVar2,s_Activate_021362c0,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d298 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,void___cdecl(bool),1>::vftable;
  _DAT_0214d2d0 = FUN_00eb94e0;
  _DAT_0214d2d4 = 0;
  DAT_0214d2d8 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d2bc = FUN_00888530();
  puVar1 = DAT_0214d2d8;
  if (DAT_0214d2d8 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_exclusiveMouse_0214db78);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a6810);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2131 ; VA 0x00529430 ; FUN_00529430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529430(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018367de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb820(uVar1,s_CreateDockWidgetPluginGui_0214da58,1,CONCAT44(uVar3,uVar2),0);
  _DAT_0214cfc8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::DockWidgetPluginGuiInfo_const&),2>
       ::vftable;
  _DAT_0214d000 = FUN_00eb9bb0;
  _DAT_0214d004 = 0;
  _DAT_0214d008 = 0;
  DAT_0214d00c = 0;
  uStack_8 = 2;
  FUN_00ebbe70();
  FUN_016f3654(&LAB_018a6830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2132 ; VA 0x005294f0 ; FUN_005294f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005294f0(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836843;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00eb6da0();
  FUN_009cb790(uVar2,s_CreatePluginAction_0214dad4,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d058 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,bool),5>
       ::vftable;
  _DAT_0214d090 = FUN_00eb9d60;
  _DAT_0214d094 = 0;
  _DAT_0214d098 = 0;
  _DAT_0214d09c = 0;
  _DAT_0214d0a0 = 0;
  uStack_8._0_1_ = 4;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 5;
  if (iStack_14 == 0) {
    _DAT_0214d0a4 = 0;
  }
  else {
    _DAT_0214d0a4 = FUN_0054ef60(auStack_38);
  }
  uStack_8._0_1_ = 6;
  DAT_0214d0a8 = (undefined *)FUN_01674e20(1);
  if (DAT_0214d0a8 == (undefined *)0x0) {
    DAT_0214d0a8 = (undefined *)0x0;
  }
  else {
    *DAT_0214d0a8 = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00ebabc0(s_actionId_0214dac8,&DAT_02126680,s_statusTip_0214dabc,s_iconName_0214dab0,
               s_allowBinding_0214daa0);
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018a6860);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2133 ; VA 0x00529680 ; FUN_00529680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529680(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018368a6;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  puStack_14 = auStack_50;
  uStack_1c = 0;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = 0;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  pcVar3 = &DAT_0211fa6e;
  uStack_8 = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = 0;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  uStack_8 = 1;
  uVar2 = FUN_00eb6da0();
  FUN_009cb790(uVar2,s_CreatePluginMenu_0214daf0,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d0b0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),3>
       ::vftable;
  _DAT_0214d0e8 = FUN_00eba060;
  _DAT_0214d0ec = 0;
  _DAT_0214d0f0 = 0;
  uStack_8._0_1_ = 3;
  puStack_14 = (undefined *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 4;
  if (puStack_14 == (undefined *)0x0) {
    _DAT_0214d0f4 = 0;
  }
  else {
    _DAT_0214d0f4 = FUN_0054ef60(auStack_38);
  }
  uStack_8._0_1_ = 5;
  puStack_14 = (undefined *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 6;
  if (puStack_14 == (undefined *)0x0) {
    _DAT_0214d0f8 = 0;
  }
  else {
    _DAT_0214d0f8 = FUN_0054ef60(auStack_50);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00ebb040(&DAT_021347ec,s_title_02130ec0,&DAT_0214dae8);
  FUN_005509f0();
  FUN_016f3654(&LAB_018a68b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2134 ; VA 0x00529810 ; FUN_00529810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529810(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018368ce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb820(uVar1,s_CreateQWidgetPluginGui_0214da88,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214d010 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),2>
       ::vftable;
  _DAT_0214d048 = FUN_00eba350;
  _DAT_0214d04c = 0;
  _DAT_0214d050 = 0;
  DAT_0214d054 = 0;
  uStack_8 = 2;
  FUN_00ebc0f0();
  FUN_016f3654(&LAB_018a68e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2135 ; VA 0x005298d0 ; FUN_005298d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005298d0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183692c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_CreateToolbar_0214db88,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d320 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214d358 = FUN_00eba530;
  _DAT_0214d35c = 0;
  DAT_0214d360 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d344 = FUN_0088cdc0();
  if (DAT_0214d360 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0214d360);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a6940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2136 ; VA 0x00529a50 ; FUN_00529a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529a50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183694a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_Deactivate_021362cc,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d2e0 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,void___cdecl(void),0>::vftable;
  _DAT_0214d318 = FUN_00ebab80;
  _DAT_0214d31c = 0;
  _DAT_0214d304 = FUN_00888530();
  FUN_016f3654(&LAB_018a6960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2137 ; VA 0x00529af0 ; FUN_00529af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529af0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183697e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb820(uVar1,s_ImportFbxAnimation_0214db38,1,CONCAT44(uVar3,uVar2),0);
  _DAT_0214d190 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool),2>
       ::vftable;
  _DAT_0214d1c8 = FUN_00ebdfb0;
  _DAT_0214d1cc = 0;
  _DAT_0214d1d0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d1d4 = (undefined *)FUN_01674e20(1);
  if (_DAT_0214d1d4 == (undefined *)0x0) {
    _DAT_0214d1d4 = (undefined *)0x0;
  }
  else {
    *_DAT_0214d1d4 = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00ebc2d0();
  FUN_016f3654(&LAB_018a6970);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2138 ; VA 0x00529bd0 ; FUN_00529bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529bd0(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018369dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb6da0();
  FUN_009cb820(uVar2,s_ImportFbxRig_0214db1c,1,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0214d148 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(bool),1>
       ::vftable;
  _DAT_0214d180 = FUN_00ebe150;
  _DAT_0214d184 = 0;
  DAT_0214d188 = (undefined *)FUN_01674e20(1);
  if (DAT_0214d188 == (undefined *)0x0) {
    DAT_0214d188 = (undefined *)0x0;
  }
  else {
    *DAT_0214d188 = 1;
  }
  uStack_8._0_1_ = 1;
  _DAT_0214d16c = FUN_0088cdc0();
  puVar1 = DAT_0214d188;
  if (DAT_0214d188 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_isR15_0214db14);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a6980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2139 ; VA 0x00529d80 ; FUN_00529d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529d80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018369fa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_GetJoinMode_0214dcb8,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d790 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,enum_RBX::AdvArrowToolJointCreationMode___cdecl(void),0>::
       vftable;
  _DAT_0214d7c8 = &LAB_00ebeb40;
  _DAT_0214d7cc = 0;
  _DAT_0214d7b4 = thunk_FUN_008bbaf0();
  FUN_016f3654(&LAB_018a69a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2140 ; VA 0x00529e20 ; FUN_00529e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529e20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836a1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_GetMouse_0211f864,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d1d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>::
       vftable;
  _DAT_0214d210 = FUN_00dd71f0;
  _DAT_0214d214 = 0;
  _DAT_0214d1fc = FUN_0088cdc0();
  FUN_016f3654(&LAB_018a69b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2141 ; VA 0x00529ec0 ; FUN_00529ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529ec0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836a3a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_GetSelectedRibbonTool_0214dc58,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d698 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,enum_RBX::RibbonTool___cdecl(void),0>::
       vftable;
  _DAT_0214d6d0 = FUN_00ebebb0;
  _DAT_0214d6d4 = 0;
  _DAT_0214d6bc = thunk_FUN_00eb64c0();
  FUN_016f3654(&LAB_018a69c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2142 ; VA 0x00529f60 ; FUN_00529f60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00529f60(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836a9c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_GetSetting_0214dba4,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d3b0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214d3e8 = FUN_00ebecd0;
  _DAT_0214d3ec = 0;
  DAT_0214d3f0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d3d4 = FUN_00888410();
  if (DAT_0214d3f0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0214d3f0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211f870);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a69d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2143 ; VA 0x0052a0e0 ; FUN_0052a0e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a0e0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836aba;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_GetStudioUserId_0214dbb0,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d3f8 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,__int64___cdecl(void),0>::vftable
  ;
  _DAT_0214d430 = FUN_00ebee20;
  _DAT_0214d434 = 0;
  _DAT_0214d41c = FUN_0088da50();
  FUN_016f3654(&LAB_018a69f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2144 ; VA 0x0052a180 ; FUN_0052a180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a180(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836aee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_Invoke_0214d9e8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214ce68 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_0214cea0 = FUN_00ebf330;
  _DAT_0214cea4 = 0;
  _DAT_0214cea8 = 0;
  DAT_0214ceac = 0;
  uStack_8 = 2;
  FUN_00b95370();
  FUN_016f3654(&LAB_018a6a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2145 ; VA 0x0052a240 ; FUN_0052a240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a240(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836b0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_IsActivated_0214db4c,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d218 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,bool___cdecl(void),0>::vftable;
  _DAT_0214d250 = FUN_00ebf5c0;
  _DAT_0214d254 = 0;
  _DAT_0214d23c = FUN_0088daf0();
  FUN_016f3654(&LAB_018a6a60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2146 ; VA 0x0052a2e0 ; FUN_0052a2e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a2e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836b2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_IsActivatedWithExclusiveMouse_0214db58,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d258 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,bool___cdecl(void),0>::vftable;
  _DAT_0214d290 = FUN_00ebf5e0;
  _DAT_0214d294 = 0;
  _DAT_0214d27c = FUN_0088daf0();
  FUN_016f3654(&LAB_018a6a70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2147 ; VA 0x0052a380 ; FUN_0052a380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a380(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836b5e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_OnInvoke_0214d9f8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214cef8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0214cf30 = FUN_00ebf7d0;
  _DAT_0214cf34 = 0;
  _DAT_0214cf38 = 0;
  DAT_0214cf3c = 0;
  uStack_8 = 2;
  FUN_00ebb2f0();
  FUN_016f3654(&LAB_018a6a80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2148 ; VA 0x0052a440 ; FUN_0052a440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a440(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836b8e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_OnSetItem_0214da04,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214cf40 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0214cf78 = FUN_00ebf940;
  _DAT_0214cf7c = 0;
  _DAT_0214cf80 = 0;
  DAT_0214cf84 = 0;
  uStack_8 = 2;
  FUN_00ebb2f0();
  FUN_016f3654(&LAB_018a6ab0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2149 ; VA 0x0052a500 ; FUN_0052a500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a500(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836bbe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_OpenScript_0214dc38,1,CONCAT44(uVar3,uVar2),0);
  _DAT_0214d608 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int),2>
       ::vftable;
  _DAT_0214d640 = FUN_00ebfa80;
  _DAT_0214d644 = 0;
  _DAT_0214d648 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d64c = (undefined4 *)FUN_01674e20(4);
  if (_DAT_0214d64c == (undefined4 *)0x0) {
    _DAT_0214d64c = (undefined4 *)0x0;
  }
  else {
    *_DAT_0214d64c = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00ebb770();
  FUN_016f3654(&LAB_018a6ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2150 ; VA 0x0052a5e0 ; FUN_0052a5e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a5e0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836c1c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_OpenWikiPage_0214db04,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d100 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214d138 = FUN_00ebfb50;
  _DAT_0214d13c = 0;
  DAT_0214d140 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d124 = FUN_00888530();
  if (DAT_0214d140 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0214d140);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211c024);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a6af0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2151 ; VA 0x0052a760 ; FUN_0052a760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a760(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836c7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0();
  FUN_009cb820(uVar1,s_PromptForExistingAssetId_0214dc10,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d5c0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Plugin,__int64___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214d5f8 = FUN_00ebfd90;
  _DAT_0214d5fc = 0;
  DAT_0214d600 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d5e4 = FUN_0088da50();
  if (DAT_0214d600 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0214d600);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_assetType_0212b8c4);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a6b10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2152 ; VA 0x0052a8e0 ; FUN_0052a8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052a8e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836c9a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_SaveSelectedToRoblox_0214dbdc,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214d4a8 = RBX::Reflection::BoundFuncDesc<class_RBX::Plugin,void___cdecl(void),0>::vftable;
  _DAT_0214d4e0 = FUN_00ec0120;
  _DAT_0214d4e4 = 0;
  _DAT_0214d4cc = FUN_00888530();
  FUN_016f3654(&LAB_018a6b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2153 ; VA 0x0052a980 ; FUN_0052a980 */

void FUN_0052a980(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00eb8510(FUN_00ebff50,0,s_PromptSaveSelection_0214dc84,s_suggestedFileName_0214dc70);
  FUN_016f3654();
  return;
}



/* FUNCTION 2154 ; VA 0x0052aa20 ; FUN_0052aa20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052aa20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836cce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0(uVar2,0);
  FUN_009cb790(uVar1,s_SelectRibbonTool_0214dc44,1,CONCAT44(uVar3,uVar2),0);
  _DAT_0214d650 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(enum_RBX::RibbonTool,class_RBX::UDim2),2>::
       vftable;
  _DAT_0214d688 = FUN_00ec0260;
  _DAT_0214d68c = 0;
  DAT_0214d690 = 0;
  DAT_0214d694 = 0;
  uStack_8 = 2;
  FUN_00ebbbe0();
  FUN_016f3654(&LAB_018a6b60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2155 ; VA 0x0052aae0 ; FUN_0052aae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052aae0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836d26;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_SetSetting_0214db98,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d368 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant),2>
       ::vftable;
  _DAT_0214d3a0 = FUN_00ec07c0;
  _DAT_0214d3a4 = 0;
  _DAT_0214d3a8 = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_0214d3ac = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_0214d3ac = puVar2;
  }
  uStack_8._0_1_ = 5;
  FUN_00b5c940();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 7;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(FUN_018a6ba0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2156 ; VA 0x0052ac60 ; FUN_0052ac60 */

void FUN_0052ac60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eb8250(FUN_00eba8e0,0,s_Negate_0214dbfc,s_objects_0211b9f4,1,uStack_10,0);
  FUN_016f3654(&LAB_018a6c30);
  return;
}



/* FUNCTION 2157 ; VA 0x0052acc0 ; FUN_0052acc0 */

void FUN_0052acc0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00eb8250(FUN_00eba9c0,0,s_Separate_0214dc04,s_objects_0211b9f4,1,uStack_10,0);
  FUN_016f3654(&LAB_018a6c80);
  return;
}



/* FUNCTION 2158 ; VA 0x0052ad20 ; FUN_0052ad20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052ad20(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836d7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eb6da0();
  FUN_009cb790(uVar1,s_Union_0214dbf4,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214d4e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Plugin,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),1>
       ::vftable;
  _DAT_0214d520 = FUN_00ebaaa0;
  _DAT_0214d524 = 0;
  DAT_0214d528 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214d50c = FUN_0088cdc0();
  if (DAT_0214d528 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_008aa360(DAT_0214d528);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(s_objects_0211b9f4);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a6cd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2159 ; VA 0x0052af50 ; FUN_0052af50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052af50(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836dac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eb6da0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Plugin,float>::
              GetImpl<float_(__thiscall_RBX::Plugin::*)(void)const_>::vftable;
    puVar3[2] = &LAB_00ebe830;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_GridSize_0214dcac,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_0214d758 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214d78c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214d77c = _DAT_0214d77c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214d758[2])();
    if (cVar1 != '\0') {
      _DAT_0214d77c = _DAT_0214d77c & 0xfffffff3;
    }
  }
  DAT_0214d758 = RBX::Reflection::PropDescriptor<class_RBX::Plugin,float>::vftable;
  FUN_016f3654(&LAB_018a6d40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2160 ; VA 0x0052b070 ; FUN_0052b070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052b070(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836dd4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec0920();
  uVar3 = FUN_00eb6da0();
  FUN_009ca670(uVar3,uVar2,s_HostDataModelType_0214d9b0,&DAT_021197d4,uStack_24,0,0,0x13,5,5,1);
  uStack_8 = 0;
  DAT_0214cda8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Plugin,enum_RBX::StudioGameStateType>::vftable;
  _DAT_0214cddc = uVar2;
  DAT_0214cde0 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0214cde0 == (undefined4 *)0x0) {
    DAT_0214cde0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214cde0 =
         RBX::Reflection::PropDescriptor<class_RBX::Plugin,enum_RBX::StudioGameStateType>::
         GetImpl<enum_RBX::StudioGameStateType_(__thiscall_RBX::Plugin::*)(void)const_>::vftable;
    DAT_0214cde0[2] = &LAB_00ebe840;
    DAT_0214cde0[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214cde4 = FUN_00ec0920();
  cVar1 = (*(code *)DAT_0214cda8[3])();
  if (cVar1 != '\0') {
    _DAT_0214cdcc = _DAT_0214cdcc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214cda8[2])();
  if (cVar1 != '\0') {
    _DAT_0214cdcc = _DAT_0214cdcc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a6d60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2161 ; VA 0x0052b180 ; FUN_0052b180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052b180(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01836e00;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f26514) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f26514,uVar3,0,0,0x15);
    if (DAT_01f26514 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01f264f0 =
           RBX::Reflection::RefType<class_RBX::MultipleDocumentInterfaceInstance*>::vftable;
      FUN_016f3654(&LAB_018a6df0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01f26514);
    }
  }
  uVar2 = FUN_00eb6da0();
  FUN_009ca670(uVar2,&DAT_01f264f0,s_MultipleDocumentInterfaceInstanc_0214da10,&DAT_021197d4,uVar3,
               uVar4,uVar5,uVar6,5,5,0);
  uStack_8 = 1;
  DAT_0214cf88 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::Plugin,class_RBX::MultipleDocumentInterfaceInstance>::
                 vftable;
  _DAT_0214cfbc =
       RBX::Reflection::
       RefPropDescriptor<class_RBX::Plugin,class_RBX::MultipleDocumentInterfaceInstance>::vftable;
  DAT_0214cfc0 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0214cfc0 == (undefined4 *)0x0) {
    DAT_0214cfc0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214cfc0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Plugin,class_RBX::MultipleDocumentInterfaceInstance*>::
         GetImpl<class_RBX::MultipleDocumentInterfaceInstance*_(__thiscall_RBX::Plugin::*)(void)const_>
         ::vftable;
    DAT_0214cfc0[2] = &LAB_008b4220;
    DAT_0214cfc0[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0214cf88[3])();
  if (cVar1 != '\0') {
    _DAT_0214cfac = _DAT_0214cfac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214cf88[2])();
  if (cVar1 != '\0') {
    _DAT_0214cfac = _DAT_0214cfac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a6d80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2162 ; VA 0x0052b490 ; FUN_0052b490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052b490(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018375c9;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00ec0d10();
  FUN_009cb790(uVar2,s_CreateButton_0214ddd0,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214dd60 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PluginToolbar,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),4>
       ::vftable;
  _DAT_0214dd98 = FUN_00ec1120;
  _DAT_0214dd9c = 0;
  _DAT_0214dda0 = 0;
  _DAT_0214dda4 = 0;
  _DAT_0214dda8 = 0;
  uStack_8._0_1_ = 4;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 5;
  if (iStack_14 == 0) {
    _DAT_0214ddac = 0;
  }
  else {
    _DAT_0214ddac = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00ec1490(s_buttonId_0214ddc4,s_tooltip_0214ddbc,s_iconname_0214ddb0,&DAT_02126680);
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018a6e00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2163 ; VA 0x0052b610 ; FUN_0052b610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052b610(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec1da0(uVar2,0);
  FUN_009cb970(uVar1,s_Click_021191fc,1,CONCAT44(uVar3,uVar2),0);
  _DAT_0214de5c = 0xe0;
  _DAT_0214de28 =
       RBX::Reflection::
       EventDesc<class_RBX::PluginToolbarButton,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::PluginToolbarButton::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0214de50 = 0;
  _DAT_0214de54 = 0;
  _DAT_0214de58 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0214de28 =
       RBX::Reflection::
       EventDesc<class_RBX::PluginToolbarButton,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::PluginToolbarButton::*>
       ::vftable;
  FUN_016f3654(&LAB_018a6e50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2164 ; VA 0x0052b700 ; FUN_0052b700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052b700(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183773c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec1da0();
  FUN_009cb790(uVar2,s_SetActive_0214df08,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214dde0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PluginToolbarButton,void___cdecl(bool),1>::vftable;
  _DAT_0214de18 = FUN_00ec20e0;
  _DAT_0214de1c = 0;
  DAT_0214de20 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214de04 = FUN_00888530();
  puVar1 = DAT_0214de20;
  if (DAT_0214de20 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_active_02123e64);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a6e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2165 ; VA 0x0052b8f0 ; FUN_0052b8f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052b8f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183776c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec1da0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PluginToolbarButton,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_(__thiscall_RBX::PluginUIElement::*)(void)const_,void_(__thiscall_RBX::PluginUIElement::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = FUN_00c56a20;
    puVar3[3] = 0;
    puVar3[4] = FUN_010e3810;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,&DAT_0214a9c4,s_Appearance_02119800,uStack_24,0,0,0x15,0,0,0);
  DAT_0214ded0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214df04 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214def4 = _DAT_0214def4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214ded0[2])();
    if (cVar1 != '\0') {
      _DAT_0214def4 = _DAT_0214def4 & 0xfffffff3;
    }
  }
  DAT_0214ded0 = RBX::Reflection::
                 PropDescriptor<class_RBX::PluginToolbarButton,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_018a6ea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2166 ; VA 0x0052bae0 ; FUN_0052bae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052bae0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183793a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec2850(uVar2,0);
  FUN_009cb790(uVar1,s_GetAttachedReceivers_0214e084,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214dfb0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CustomEvent,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0214dfe8 = FUN_00ec2fa0;
  _DAT_0214dfec = 0;
  _DAT_0214dfd4 = FUN_0088cc80();
  FUN_016f3654(&LAB_018a6f70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2167 ; VA 0x0052bb80 ; FUN_0052bb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052bb80(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183799c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec2850();
  FUN_009cb790(uVar1,s_SetValue_0214e078,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214df68 =
       RBX::Reflection::BoundFuncDesc<class_RBX::CustomEvent,void___cdecl(float),1>::vftable;
  _DAT_0214dfa0 = FUN_00ec33a0;
  _DAT_0214dfa4 = 0;
  DAT_0214dfa8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214df8c = FUN_00888530();
  puVar3 = DAT_0214dfa8;
  if (DAT_0214dfa8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00630820();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_newValue_0211d29c);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a6f80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2168 ; VA 0x0052bd30 ; FUN_0052bd30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052bd30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018379cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec2850();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::CustomEvent,float>::
              GetSetImpl<float_(__thiscall_RBX::CustomEvent::*)(void)const_,void_(__thiscall_RBX::CustomEvent::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00927500;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ec34e0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_PersistedCurrentValue_0214e060,&DAT_021197d4,uStack_24,0,0,0xe,0,0,0);
  DAT_0214df30 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214df64 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214df54 = _DAT_0214df54 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214df30[2])();
    if (cVar1 != '\0') {
      _DAT_0214df54 = _DAT_0214df54 & 0xfffffff3;
    }
  }
  DAT_0214df30 = RBX::Reflection::PropDescriptor<class_RBX::CustomEvent,float>::vftable;
  FUN_016f3654(&LAB_018a6fa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2169 ; VA 0x0052be90 ; FUN_0052be90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052be90(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01837bea;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec3600();
  FUN_00f50070(uVar1,s_OnInvoke_0214d9f8,uStack_1c,0,0);
  uStack_8 = 0;
  _DAT_0214e110 =
       RBX::Reflection::
       BoundAsyncCallbackDesc<class_RBX::BindableFunction,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),1>
       ::vftable;
  _DAT_0214e148 = 0x68;
  _DAT_0214e150 = FUN_00ec4f70;
  _DAT_0214e154 = 0;
  _DAT_0214e134 = FUN_0088cbe0();
  uVar1 = FUN_0088cbe0();
  uVar2 = FUN_0086e3d0(s_arguments_0212bd00);
  FUN_00888aa0(uVar2,uVar1);
  FUN_016f3654(&LAB_018a7020);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2170 ; VA 0x0052bf60 ; FUN_0052bf60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052bf60(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01837c23;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec3500();
  FUN_009cb970(uVar1,s_Event_0214e1d8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214e1d4 = 0x54;
  iStack_8 = 0;
  _DAT_0214e1a0 =
       RBX::Reflection::
       EventDesc<class_RBX::BindableEvent,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::BindableEvent::*>
       ::vftable;
  FUN_0086e3d0(s_arguments_0212bd00);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0214e1c8 = uStack_1c;
  _DAT_0214e1cc = uStack_18;
  _DAT_0214e1d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0214e1a0 =
       RBX::Reflection::
       EventDesc<class_RBX::BindableEvent,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::BindableEvent::*>
       ::vftable;
  FUN_016f3654(&LAB_018a7030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2171 ; VA 0x0052c0b0 ; FUN_0052c0b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c0b0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01837c7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec3500();
  FUN_009cb790(uVar1,&DAT_02139c64,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214e158 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::BindableEvent,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),1>
       ::vftable;
  _DAT_0214e190 = FUN_00ec4ae0;
  _DAT_0214e194 = 0;
  DAT_0214e198 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214e17c = FUN_00888530();
  if (DAT_0214e198 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_0095efd0(DAT_0214e198);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(s_arguments_0212bd00);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a7040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2172 ; VA 0x0052c230 ; FUN_0052c230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c230(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01837cdc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec3600();
  FUN_009cb820(uVar1,s_Invoke_0214d9e8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214e0c8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::BindableFunction,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),1>
       ::vftable;
  _DAT_0214e100 = FUN_00ec4c50;
  _DAT_0214e104 = 0;
  DAT_0214e108 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214e0ec = FUN_0088cbe0();
  if (DAT_0214e108 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_0095efd0(DAT_0214e108);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(s_arguments_0212bd00);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a7090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2173 ; VA 0x0052c410 ; FUN_0052c410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c410(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018380fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0();
  FUN_009cb790(uVar1,s_AddDebugger_0214e450,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214e1e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::DebuggerManager,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0214e218 = FUN_00ec6b80;
  _DAT_0214e21c = 0;
  DAT_0214e220 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214e204 = FUN_0088cdc0();
  if (DAT_0214e220 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006874f0(DAT_0214e220);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_script_021205b4);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a71c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2174 ; VA 0x0052c590 ; FUN_0052c590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c590(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183811a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0(uVar2,0);
  FUN_009cb790(uVar1,s_EnableDebugging_0214e45c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e228 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Scripting::DebuggerManager,void___cdecl(void),0>::
       vftable;
  _DAT_0214e260 = &LAB_00ec6880;
  _DAT_0214e264 = 0;
  _DAT_0214e24c = FUN_00888530();
  FUN_016f3654(&LAB_018a7210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2175 ; VA 0x0052c630 ; FUN_0052c630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c630(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183813a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0(uVar2,0);
  FUN_009cb790(uVar1,s_GetDebuggers_0214e49c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e3a0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::DebuggerManager,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0214e3d8 = FUN_00ec68c0;
  _DAT_0214e3dc = 0;
  _DAT_0214e3c4 = FUN_0088cc80();
  FUN_016f3654(&LAB_018a7220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2176 ; VA 0x0052c6d0 ; FUN_0052c6d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c6d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183815a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0(uVar2,0);
  FUN_009cb790(uVar1,s_Resume_02128f98,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e2a0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Scripting::DebuggerManager,void___cdecl(void),0>::
       vftable;
  _DAT_0214e2d8 = FUN_00ec77a0;
  _DAT_0214e2dc = 0;
  _DAT_0214e2c4 = FUN_00888530();
  FUN_016f3654(&LAB_018a7230);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2177 ; VA 0x0052c770 ; FUN_0052c770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c770(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183817a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0(uVar2,0);
  FUN_009cb790(uVar1,s_StepIn_0214e48c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e320 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Scripting::DebuggerManager,void___cdecl(void),0>::
       vftable;
  _DAT_0214e358 = &LAB_00ec7cb0;
  _DAT_0214e35c = 0;
  _DAT_0214e344 = FUN_00888530();
  FUN_016f3654(&LAB_018a7240);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2178 ; VA 0x0052c810 ; FUN_0052c810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c810(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183819a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0(uVar2,0);
  FUN_009cb790(uVar1,s_StepOut_0214e494,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e360 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Scripting::DebuggerManager,void___cdecl(void),0>::
       vftable;
  _DAT_0214e398 = &LAB_00ec7d50;
  _DAT_0214e39c = 0;
  _DAT_0214e384 = FUN_00888530();
  FUN_016f3654(&LAB_018a7250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2179 ; VA 0x0052c8b0 ; FUN_0052c8b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c8b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018381ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec53e0(uVar2,0);
  FUN_009cb790(uVar1,s_StepOver_0214e480,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e2e0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Scripting::DebuggerManager,void___cdecl(void),0>::
       vftable;
  _DAT_0214e318 = &LAB_00ec7df0;
  _DAT_0214e31c = 0;
  _DAT_0214e304 = FUN_00888530();
  FUN_016f3654(&LAB_018a7260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2180 ; VA 0x0052c950 ; FUN_0052c950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052c950(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018381ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec53e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Scripting::DebuggerManager,bool>::
              GetImpl<bool_(__thiscall_RBX::Scripting::DebuggerManager::*)(void)const_>::vftable;
    puVar3[2] = FUN_00dd7240;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_DebuggingEnabled_0214e46c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214e268 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214e29c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214e28c = _DAT_0214e28c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214e268[2])();
    if (cVar1 != '\0') {
      _DAT_0214e28c = _DAT_0214e28c & 0xfffffff3;
    }
  }
  DAT_0214e268 = RBX::Reflection::PropDescriptor<class_RBX::Scripting::DebuggerManager,bool>::
                 vftable;
  FUN_016f3654(&LAB_018a7270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2181 ; VA 0x0052cc00 ; FUN_0052cc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052cc00(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0183899e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200();
  FUN_009cb970(uVar1,s_EncounteredBreak_0214ec00,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214e9c0 = 300;
  iStack_8 = 0;
  _DAT_0214e98c =
       RBX::Reflection::
       EventDesc<class_RBX::Scripting::ScriptDebugger,void___cdecl(int,enum_RBX::Scripting::ScriptDebugger::BreakReason),class_rbx::signal<void___cdecl(int,enum_RBX::Scripting::ScriptDebugger::BreakReason)>,class_rbx::signal<void___cdecl(int,enum_RBX::Scripting::ScriptDebugger::BreakReason)>_RBX::Scripting::ScriptDebugger::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02133e90);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_breakReason_0214ebf4);
  FUN_00ed0750();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0214e9b4 = uStack_1c;
  _DAT_0214e9b8 = uStack_18;
  _DAT_0214e9bc = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0214e98c =
       RBX::Reflection::
       EventDesc<class_RBX::Scripting::ScriptDebugger,void___cdecl(int,enum_RBX::Scripting::ScriptDebugger::BreakReason),class_rbx::signal<void___cdecl(int,enum_RBX::Scripting::ScriptDebugger::BreakReason)>,class_rbx::signal<void___cdecl(int,enum_RBX::Scripting::ScriptDebugger::BreakReason)>_RBX::Scripting::ScriptDebugger::*>
       ::vftable;
  FUN_016f3654(&LAB_018a7320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2182 ; VA 0x0052cd70 ; FUN_0052cd70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052cd70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200(uVar2,0);
  FUN_009cb970(uVar1,s_Resuming_0214ec14,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0214e9f8 = 0x130;
  _DAT_0214e9c4 =
       RBX::Reflection::
       EventDesc<class_RBX::Scripting::ScriptDebugger,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Scripting::ScriptDebugger::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0214e9ec = 0;
  _DAT_0214e9f0 = 0;
  _DAT_0214e9f4 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0214e9c4 =
       RBX::Reflection::
       EventDesc<class_RBX::Scripting::ScriptDebugger,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Scripting::ScriptDebugger::*>
       ::vftable;
  FUN_016f3654(&LAB_018a7330);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2183 ; VA 0x0052cec0 ; FUN_0052cec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052cec0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018389fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec8200();
  FUN_009cb790(uVar2,s_AddWatch_0214eb28,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214e560 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214e598 = FUN_00ecafc0;
  _DAT_0214e59c = 0;
  DAT_0214e5a0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214e584 = FUN_0088cdc0();
  iVar1 = DAT_0214e5a0;
  if (DAT_0214e5a0 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_expression_0214eb1c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a7360);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2184 ; VA 0x0052d070 ; FUN_0052d070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d070(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838a1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200(uVar2,0);
  FUN_009cb790(uVar1,s_GetBreakpoints_0214eb0c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e520 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0214e558 = FUN_00ecc130;
  _DAT_0214e55c = 0;
  _DAT_0214e544 = FUN_0088cc80();
  FUN_016f3654(&LAB_018a7380);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2185 ; VA 0x0052d110 ; FUN_0052d110 */

void FUN_0052d110(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ec9900(FUN_00ecc340,0,s_GetGlobals_0214eb88,s_stackFrame_0214eb64,0,0,uStack_10,0);
  FUN_016f3654(&LAB_018a7390);
  return;
}



/* FUNCTION 2186 ; VA 0x0052d170 ; FUN_0052d170 */

void FUN_0052d170(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ec9900(FUN_00ecc7b0,0,s_GetLocals_0214eb70,s_stackFrame_0214eb64,0,0,uStack_10,0);
  FUN_016f3654(&LAB_018a73b0);
  return;
}



/* FUNCTION 2187 ; VA 0x0052d1d0 ; FUN_0052d1d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d1d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838a3a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200(uVar2,0);
  FUN_009cb790(uVar1,s_GetStack_0214eb58,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e630 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0214e668 = FUN_00ecca00;
  _DAT_0214e66c = 0;
  _DAT_0214e654 = FUN_008882f0();
  FUN_016f3654(&LAB_018a73d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2188 ; VA 0x0052d270 ; FUN_0052d270 */

void FUN_0052d270(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ec9900(FUN_00ecd250,0,s_GetUpvalues_0214eb7c,s_stackFrame_0214eb64,0,0,uStack_10,0);
  FUN_016f3654(&LAB_018a73e0);
  return;
}



/* FUNCTION 2189 ; VA 0x0052d2d0 ; FUN_0052d2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d2d0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838a9c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200();
  FUN_009cb790(uVar1,s_GetWatchValue_0214eb48,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214e5e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,class_RBX::Reflection::Variant___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0214e620 = FUN_00ecd2a0;
  _DAT_0214e624 = 0;
  DAT_0214e628 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214e60c = FUN_00888410();
  if (DAT_0214e628 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006874f0(DAT_0214e628);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_watch_0214eb40);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a7400);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2190 ; VA 0x0052d450 ; FUN_0052d450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d450(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838aba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200(uVar2,0);
  FUN_009cb790(uVar1,s_GetWatches_0214eb34,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214e5a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0214e5e0 = FUN_00ecd350;
  _DAT_0214e5e4 = 0;
  _DAT_0214e5cc = FUN_0088cc80();
  FUN_016f3654(&LAB_018a7450);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2191 ; VA 0x0052d4f0 ; FUN_0052d4f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d4f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838aee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200(uVar2,0);
  FUN_009cb790(uVar1,s_SetBreakpoint_0214eafc,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0214e4d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,class_std::shared_ptr<class_RBX::Instance>___cdecl(int,bool),2>
       ::vftable;
  _DAT_0214e510 = FUN_00ecf720;
  _DAT_0214e514 = 0;
  DAT_0214e518 = 0;
  DAT_0214e51c = 0;
  uStack_8 = 2;
  FUN_00ecb420();
  FUN_016f3654(&LAB_018a7460);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2192 ; VA 0x0052d5b0 ; FUN_0052d5b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d5b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838b28;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ec8200(uVar2,0);
  FUN_009cb790(uVar1,s_SetGlobal_0214ebac,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0214e7e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Scripting::ScriptDebugger,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,int),3>
       ::vftable;
  _DAT_0214e820 = FUN_00ecfaa0;
  _DAT_0214e824 = 0;
  _DAT_0214e828 = 0;
  DAT_0214e82c = 0;
  DAT_0214e830 = 0;
  uStack_8 = 3;
  FUN_00ecb640(&DAT_0211a93c,s_value_0211ab70,s_stackFrame_0214eb64);
  FUN_016f3654(FUN_018a74a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2193 ; VA 0x0052d680 ; FUN_0052d680 */

void FUN_0052d680(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ec9a90(FUN_00ecfbe0,0,s_SetLocal_0214eb94,&DAT_0211a93c,s_value_0211ab70,
               s_stackFrame_0214eb64,0,0,uStack_10,0);
  FUN_016f3654(FUN_018a7530);
  return;
}



/* FUNCTION 2194 ; VA 0x0052d6f0 ; FUN_0052d6f0 */

void FUN_0052d6f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ec9a90(FUN_00ed0630,0,s_SetUpvalue_0214eba0,&DAT_0211a93c,s_value_0211ab70,
               s_stackFrame_0214eb64,0,0,uStack_10,0);
  FUN_016f3654(FUN_018a75c0);
  return;
}



/* FUNCTION 2195 ; VA 0x0052d7b0 ; FUN_0052d7b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d7b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838b5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec8200();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Scripting::ScriptDebugger,int>::
              GetImpl<int_(__thiscall_RBX::Scripting::ScriptDebugger::*)(void)const_>::vftable;
    puVar3[2] = &LAB_00d0b4f0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_CurrentLine_0214ebe8,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_0214e954 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214e988 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214e978 = _DAT_0214e978 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214e954[2])();
    if (cVar1 != '\0') {
      _DAT_0214e978 = _DAT_0214e978 & 0xfffffff3;
    }
  }
  DAT_0214e954 = RBX::Reflection::PropDescriptor<class_RBX::Scripting::ScriptDebugger,int>::vftable;
  FUN_016f3654(&LAB_018a7690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2196 ; VA 0x0052d970 ; FUN_0052d970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052d970(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01838b90;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00ec8200();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Script_02120320,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0214e838 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::Scripting::ScriptDebugger,class_RBX::Instance>::
                 vftable;
  _DAT_0214e86c =
       RBX::Reflection::RefPropDescriptor<class_RBX::Scripting::ScriptDebugger,class_RBX::Instance>
       ::vftable;
  DAT_0214e870 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0214e870 == (undefined4 *)0x0) {
    DAT_0214e870 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214e870 =
         RBX::Reflection::PropDescriptor<class_RBX::Scripting::ScriptDebugger,class_RBX::Instance*>
         ::GetImpl<class_RBX::Instance*_(__thiscall_RBX::Scripting::ScriptDebugger::*)(void)const_>
         ::vftable;
    DAT_0214e870[2] = FUN_00b5f140;
    DAT_0214e870[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0214e838[3])();
  if (cVar1 != '\0') {
    _DAT_0214e85c = _DAT_0214e85c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214e838[2])();
  if (cVar1 != '\0') {
    _DAT_0214e85c = _DAT_0214e85c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a76f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2197 ; VA 0x0052db00 ; FUN_0052db00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052db00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183912c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ed0a20();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Scripting::DebuggerBreakpoint,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Scripting::DebuggerBreakpoint::*)(void)const_,void_(__thiscall_RBX::Scripting::DebuggerBreakpoint::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_00ed0f70;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ed0fd0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_Condition_0214ed98,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214ed4c = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214ed80 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214ed70 = _DAT_0214ed70 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214ed4c[2])();
    if (cVar1 != '\0') {
      _DAT_0214ed70 = _DAT_0214ed70 & 0xfffffff3;
    }
  }
  DAT_0214ed4c = RBX::Reflection::
                 PropDescriptor<class_RBX::Scripting::DebuggerBreakpoint,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a7770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2198 ; VA 0x0052dcd0 ; FUN_0052dcd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052dcd0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183914a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00ed0a20();
  FUN_005c44c0(uVar3,&DAT_02133e90,&DAT_021197d4,0);
  uStack_8 = 0;
  DAT_0214eca4 = RBX::Reflection::BoundProp<int,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<int,1>::
              BoundPropGetSet<class_RBX::Scripting::DebuggerBreakpoint>::vftable;
    puVar4[1] = &DAT_0214eca4;
    puVar4[2] = 0x5c;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0214ecd8 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0214ecd8;
    DAT_0214ecd8 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0214ecd8;
  }
  DAT_0214ecd8 = puVar4;
  cVar2 = (*(code *)DAT_0214eca4[3])();
  if (cVar2 != '\0') {
    _DAT_0214ecc8 = _DAT_0214ecc8 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0214eca4[2])();
  if (cVar2 != '\0') {
    _DAT_0214ecc8 = _DAT_0214ecc8 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2199 ; VA 0x0052deb0 ; FUN_0052deb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052deb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183920c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ed10d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Scripting::DebuggerWatch,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Scripting::DebuggerWatch::*)(void)const_,void_(__thiscall_RBX::Scripting::DebuggerWatch::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_00ed15b0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ed1610;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_Expression_0214eddc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214eda4 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214edd8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214edc8 = _DAT_0214edc8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214eda4[2])();
    if (cVar1 != '\0') {
      _DAT_0214edc8 = _DAT_0214edc8 & 0xfffffff3;
    }
  }
  DAT_0214eda4 = RBX::Reflection::
                 PropDescriptor<class_RBX::Scripting::DebuggerWatch,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a7870);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2200 ; VA 0x0052e060 ; FUN_0052e060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052e060(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183927a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ed1710(uVar2,0);
  FUN_009cb790(uVar1,s_Logout_0214eee4,6,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214ee28 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LoginService,void___cdecl(void),0>::vftable;
  _DAT_0214ee60 = FUN_00ed1930;
  _DAT_0214ee64 = 0;
  _DAT_0214ee4c = FUN_00888530();
  FUN_016f3654(&LAB_018a7910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2201 ; VA 0x0052e100 ; FUN_0052e100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052e100(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183929a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ed1710(uVar2,0);
  FUN_009cb790(uVar1,s_PromptLogin_0214eed8,6,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214ede8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LoginService,void___cdecl(void),0>::vftable;
  _DAT_0214ee20 = FUN_00ed1980;
  _DAT_0214ee24 = 0;
  _DAT_0214ee0c = FUN_00888530();
  FUN_016f3654(&LAB_018a7920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2202 ; VA 0x0052e200 ; FUN_0052e200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052e200(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183938a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ed1ab0(uVar2,0);
  FUN_009cb790(uVar1,s_GetGamepadCursorPosition_0214f014,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214efa0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GamepadService,class_G3D::Vector2___cdecl(void)const_,0>::vftable;
  _DAT_0214efd8 = FUN_00b97ee0;
  _DAT_0214efdc = 0;
  _DAT_0214efc4 = FUN_0088d730();
  FUN_016f3654(&LAB_018a7950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2203 ; VA 0x0052e2a0 ; FUN_0052e2a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052e2a0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018393ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ed1ab0();
  FUN_009cb790(uVar1,s_SetGamepadCursorPosition_0214eff8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214ef58 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GamepadService,void___cdecl(class_G3D::Vector2),1>
       ::vftable;
  _DAT_0214ef90 = FUN_00ed4db0;
  _DAT_0214ef94 = 0;
  DAT_0214ef98 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_0214ef7c = FUN_00888530();
  puVar3 = DAT_0214ef98;
  if (DAT_0214ef98 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088d730();
    puStack_ec = (undefined4 *)0x0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead418) {
      FUN_016f3809(&DAT_01ead418);
      if (DAT_01ead418 == -1) {
        DAT_01ead40c = FUN_005c6620;
        _DAT_01ead410 = FUN_005c6620;
        DAT_01ead414 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead418);
      }
    }
    puStack_ec = &DAT_01ead40c;
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088d730();
  uVar2 = FUN_0086e3d0(s_position_0211fd1c);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a7960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2204 ; VA 0x0052e4b0 ; FUN_0052e4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052e4b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183941c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ed1ab0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GamepadService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::GamepadService::*)(void)const_,void_(__thiscall_RBX::GamepadService::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00832110;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ed4d30;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_GamepadCursorEnabled_0214efe0,s_State_0211d030,uStack_24,0,0,0x10,5,5,0
              );
  DAT_0214ef20 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214ef54 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214ef44 = _DAT_0214ef44 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214ef20[2])();
    if (cVar1 != '\0') {
      _DAT_0214ef44 = _DAT_0214ef44 & 0xfffffff3;
    }
  }
  DAT_0214ef20 = RBX::Reflection::PropDescriptor<class_RBX::GamepadService,bool>::vftable;
  FUN_016f3654(&LAB_018a7980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2205 ; VA 0x0052e930 ; FUN_0052e930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052e930(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183a1b6;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00ed62b0();
  FUN_009cb820(uVar1,s_PublishAsync_0214f0c8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214f030 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MessagingService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant),2>
       ::vftable;
  _DAT_0214f068 = FUN_00edf9f0;
  _DAT_0214f06c = 0;
  _DAT_0214f070 = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_0214f074 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_0214f074 = puVar2;
  }
  uStack_8._0_1_ = 5;
  FUN_00b5c940();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 7;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(FUN_018a7f70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2206 ; VA 0x0052eab0 ; FUN_0052eab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052eab0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183a1de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ed62b0(uVar2,0);
  FUN_009cb820(uVar1,s_SubscribeAsync_0214f0d8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0214f078 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MessagingService,class_rbx::signals::connection___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0214f0b0 = FUN_00ee0c70;
  _DAT_0214f0b4 = 0;
  _DAT_0214f0b8 = 0;
  DAT_0214f0bc = 0;
  uStack_8 = 2;
  FUN_00edc690();
  FUN_016f3654(&LAB_018a7fe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2207 ; VA 0x0052ebb0 ; FUN_0052ebb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052ebb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ac7e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee16f0(uVar2,0);
  FUN_009cb790(uVar1,&DAT_0214f380,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214f290 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MemStorageService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0214f2c8 = FUN_00ee2f90;
  _DAT_0214f2cc = 0;
  _DAT_0214f2d0 = 0;
  DAT_0214f2d4 = 0;
  uStack_8 = 2;
  FUN_00ee3960();
  FUN_016f3654(&LAB_018a8070);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2208 ; VA 0x0052ec70 ; FUN_0052ec70 */

void FUN_0052ec70(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00ee1d20(FUN_00ee3f20,0,&DAT_02139c64,&DAT_0211f870,s_value_0211ab70);
  FUN_016f3654();
  return;
}



/* FUNCTION 2209 ; VA 0x0052ed10 ; FUN_0052ed10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052ed10(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183acc5;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00ee16f0();
  FUN_009cb790(uVar2,s_GetItem_0214d9f0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214f178 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MemStorageService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_0214f1b0 = FUN_00ee4070;
  _DAT_0214f1b4 = 0;
  _DAT_0214f1b8 = 0;
  uStack_8._0_1_ = 2;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 3;
  if (iStack_14 == 0) {
    _DAT_0214f1bc = 0;
  }
  else {
    _DAT_0214f1bc = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_008f20f0();
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018a80c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2210 ; VA 0x0052ee60 ; FUN_0052ee60 */

void FUN_0052ee60(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00ee1d20(FUN_00ee4d80,0,s_SetItem_0214d9e0,&DAT_0211f870,s_value_0211ab70);
  FUN_016f3654();
  return;
}



/* FUNCTION 2211 ; VA 0x0052ef00 ; FUN_0052ef00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052ef00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183acee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee16f0(uVar2,0);
  FUN_009cb790(uVar1,s_BindAndFire_0214f388,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214f2d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MemStorageService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0214f310 = FUN_00ee30c0;
  _DAT_0214f314 = 0;
  _DAT_0214f318 = 0;
  DAT_0214f31c = 0;
  uStack_8 = 2;
  FUN_00ee3960();
  FUN_016f3654(&LAB_018a8100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2212 ; VA 0x0052efc0 ; FUN_0052efc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052efc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ad0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee1610(uVar2,0);
  FUN_009cb790(uVar1,s_Disconnect_0214f394,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214f320 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MemStorageConnection,void___cdecl(void),0>::vftable
  ;
  _DAT_0214f358 = &LAB_00ee3bf0;
  _DAT_0214f35c = 0;
  _DAT_0214f344 = FUN_00888530();
  FUN_016f3654(&LAB_018a8130);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2213 ; VA 0x0052f060 ; FUN_0052f060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f060(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ad2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee16f0(uVar2,0);
  FUN_009cb790(uVar1,s_GetTable_0214f360,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214f1c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MemStorageService,class_std::shared_ptr<class_std::map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_std::less<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0214f1f8 = FUN_00ee4120;
  _DAT_0214f1fc = 0;
  _DAT_0214f1e4 = FUN_008880b0();
  FUN_016f3654(&LAB_018a8140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2214 ; VA 0x0052f100 ; FUN_0052f100 */

void FUN_0052f100(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ee1e10(FUN_00ee4560,0,s_HasItem_0214f36c,&DAT_0211f870,5,uStack_10,0);
  FUN_016f3654(&LAB_018a8150);
  return;
}



/* FUNCTION 2215 ; VA 0x0052f160 ; FUN_0052f160 */

void FUN_0052f160(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ee1e10(FUN_00ee4cd0,0,s_RemoveItem_0214f374,&DAT_0211f870,5,uStack_10,0);
  FUN_016f3654(&LAB_018a8170);
  return;
}



/* FUNCTION 2216 ; VA 0x0052f240 ; FUN_0052f240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f240(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b14c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ee4f90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundGroup,float>::
              GetSetImpl<float_(__thiscall_RBX::Soundscape::SoundGroup::*)(void)const_,void_(__thiscall_RBX::Soundscape::SoundGroup::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00927500;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ee58c0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_Volume_02128ea0,s_State_0211d030,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f3a0 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f3d4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f3c4 = _DAT_0214f3c4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f3a0[2])();
    if (cVar1 != '\0') {
      _DAT_0214f3c4 = _DAT_0214f3c4 & 0xfffffff3;
    }
  }
  DAT_0214f3a0 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundGroup,float>::vftable;
  FUN_016f3654(&LAB_018a8270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2217 ; VA 0x0052f3c0 ; FUN_0052f3c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f3c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b3ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ee6d80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIListLayout,class_RBX::UDim>::
              GetSetImpl<class_RBX::UDim_(__thiscall_RBX::UIListLayout::*)(void)const_,void_(__thiscall_RBX::UIListLayout::*)(class_RBX::UDim)>
              ::vftable;
    puVar3[2] = FUN_00ee7320;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ee7480;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d690();
  FUN_009ca670(uVar2,uVar4,s_Padding_021432c8,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f3d8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f40c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f3fc = _DAT_0214f3fc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f3d8[2])();
    if (cVar1 != '\0') {
      _DAT_0214f3fc = _DAT_0214f3fc & 0xfffffff3;
    }
  }
  DAT_0214f3d8 = RBX::Reflection::PropDescriptor<class_RBX::UIListLayout,class_RBX::UDim>::vftable;
  FUN_016f3654(&LAB_018a8330);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2218 ; VA 0x0052f590 ; FUN_0052f590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f590(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b59c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee76e0();
  FUN_009cb790(uVar1,s_JumpTo_0214f8a4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214f6d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UIPageLayout,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0214f710 = FUN_00ee8bf0;
  _DAT_0214f714 = 0;
  DAT_0214f718 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214f6fc = FUN_00888530();
  if (DAT_0214f718 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006874f0(DAT_0214f718);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(&DAT_0214f89c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a83e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2219 ; VA 0x0052f710 ; FUN_0052f710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f710(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b5fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee76e0();
  FUN_009cb790(uVar1,s_JumpToIndex_0214f8b4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214f720 =
       RBX::Reflection::BoundFuncDesc<class_RBX::UIPageLayout,void___cdecl(int),1>::vftable;
  _DAT_0214f758 = FUN_00ee8d10;
  _DAT_0214f75c = 0;
  DAT_0214f760 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214f744 = FUN_00888530();
  puVar3 = DAT_0214f760;
  if (DAT_0214f760 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_index_0214f8ac);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a8430);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2220 ; VA 0x0052f8b0 ; FUN_0052f8b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f8b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b61a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee76e0(uVar2,0);
  FUN_009cb790(uVar1,&DAT_0214f888,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214f658 =
       RBX::Reflection::BoundFuncDesc<class_RBX::UIPageLayout,void___cdecl(void),0>::vftable;
  _DAT_0214f690 = FUN_00ee90d0;
  _DAT_0214f694 = 0;
  _DAT_0214f67c = FUN_00888530();
  FUN_016f3654(&LAB_018a8450);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2221 ; VA 0x0052f950 ; FUN_0052f950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052f950(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b63a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ee76e0(uVar2,0);
  FUN_009cb790(uVar1,s_Previous_0214f890,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0214f698 =
       RBX::Reflection::BoundFuncDesc<class_RBX::UIPageLayout,void___cdecl(void),0>::vftable;
  _DAT_0214f6d0 = FUN_00ee9620;
  _DAT_0214f6d4 = 0;
  _DAT_0214f6bc = FUN_00888530();
  FUN_016f3654(&LAB_018a8460);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2222 ; VA 0x0052faf0 ; FUN_0052faf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052faf0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b670;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefe7c,uVar3,0,0,0x1f);
    if (DAT_01eefe7c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01eefe58 = RBX::Reflection::RefType<class_RBX::GuiObject*>::vftable;
      FUN_016f3654(&LAB_0188e490);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eefe7c);
    }
  }
  uVar2 = FUN_00ee76e0();
  FUN_009ca670(uVar2,&DAT_01eefe58,s_CurrentPage_0214f810,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,
               0);
  uStack_8 = 1;
  DAT_0214f410 = RBX::Reflection::RefPropDescriptor<class_RBX::UIPageLayout,class_RBX::GuiObject>::
                 vftable;
  _DAT_0214f444 =
       RBX::Reflection::RefPropDescriptor<class_RBX::UIPageLayout,class_RBX::GuiObject>::vftable;
  DAT_0214f448 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0214f448 == (undefined4 *)0x0) {
    DAT_0214f448 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214f448 =
         RBX::Reflection::PropDescriptor<class_RBX::UIPageLayout,class_RBX::GuiObject*>::
         GetImpl<class_RBX::GuiObject*_(__thiscall_RBX::UIPageLayout::*)(void)const_>::vftable;
    DAT_0214f448[2] = FUN_00ee8740;
    DAT_0214f448[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0214f410[3])();
  if (cVar1 != '\0') {
    _DAT_0214f434 = _DAT_0214f434 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214f410[2])();
  if (cVar1 != '\0') {
    _DAT_0214f434 = _DAT_0214f434 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a84b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2223 ; VA 0x0052fe00 ; FUN_0052fe00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052fe00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b69c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ee76e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIPageLayout,float>::
              GetSetImpl<float_(__thiscall_RBX::UIPageLayout::*)(void)const_,void_(__thiscall_RBX::UIPageLayout::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00ee8ae0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eea000;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_TweenTime_0214f834,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f578 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f5ac = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f59c = _DAT_0214f59c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f578[2])();
    if (cVar1 != '\0') {
      _DAT_0214f59c = _DAT_0214f59c & 0xfffffff3;
    }
  }
  DAT_0214f578 = RBX::Reflection::PropDescriptor<class_RBX::UIPageLayout,float>::vftable;
  FUN_016f3654(&LAB_018a8530);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2224 ; VA 0x0052ff30 ; FUN_0052ff30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0052ff30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b6c4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d370();
  uVar3 = FUN_00ee76e0();
  FUN_009ca670(uVar3,uVar2,s_EasingDirection_02141ea4,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,1
              );
  uStack_8 = 0;
  DAT_0214f538 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIPageLayout,enum_RBX::TweenInfo::TweenEasingDirection>
                 ::vftable;
  _DAT_0214f56c = uVar2;
  DAT_0214f570 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214f570 == (undefined4 *)0x0) {
    DAT_0214f570 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214f570 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIPageLayout,enum_RBX::TweenInfo::TweenEasingDirection>::
         GetSetImpl<enum_RBX::TweenInfo::TweenEasingDirection_(__thiscall_RBX::UIPageLayout::*)(void)const_,void_(__thiscall_RBX::UIPageLayout::*)(enum_RBX::TweenInfo::TweenEasingDirection)>
         ::vftable;
    DAT_0214f570[2] = &LAB_00d66190;
    DAT_0214f570[3] = 0;
    DAT_0214f570[4] = FUN_00ee9ec0;
    DAT_0214f570[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214f574 = FUN_00c7d370();
  cVar1 = (*(code *)DAT_0214f538[3])();
  if (cVar1 != '\0') {
    _DAT_0214f55c = _DAT_0214f55c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214f538[2])();
  if (cVar1 != '\0') {
    _DAT_0214f55c = _DAT_0214f55c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a8550);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2225 ; VA 0x00530050 ; FUN_00530050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530050(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b6e4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d400();
  uVar3 = FUN_00ee76e0();
  FUN_009ca670(uVar3,uVar2,s_EasingStyle_02141e98,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0214f4f8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIPageLayout,enum_RBX::TweenInfo::TweenEasingStyle>::
                 vftable;
  _DAT_0214f52c = uVar2;
  DAT_0214f530 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0214f530 == (undefined4 *)0x0) {
    DAT_0214f530 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214f530 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIPageLayout,enum_RBX::TweenInfo::TweenEasingStyle>::
         GetSetImpl<enum_RBX::TweenInfo::TweenEasingStyle_(__thiscall_RBX::UIPageLayout::*)(void)const_,void_(__thiscall_RBX::UIPageLayout::*)(enum_RBX::TweenInfo::TweenEasingStyle)>
         ::vftable;
    DAT_0214f530[2] = &LAB_00c85270;
    DAT_0214f530[3] = 0;
    DAT_0214f530[4] = FUN_00ee9ef0;
    DAT_0214f530[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214f534 = FUN_00c7d400();
  cVar1 = (*(code *)DAT_0214f4f8[3])();
  if (cVar1 != '\0') {
    _DAT_0214f51c = _DAT_0214f51c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0214f4f8[2])();
  if (cVar1 != '\0') {
    _DAT_0214f51c = _DAT_0214f51c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a8570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2226 ; VA 0x00530170 ; FUN_00530170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530170(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b70c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ee76e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIPageLayout,class_RBX::UDim>::
              GetSetImpl<class_RBX::UDim_(__thiscall_RBX::UIPageLayout::*)(void)const_,void_(__thiscall_RBX::UIPageLayout::*)(class_RBX::UDim)>
              ::vftable;
    puVar3[2] = FUN_00ee88e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ee9f50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d690();
  FUN_009ca670(uVar2,uVar4,s_Padding_021432c8,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f484 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f4b8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f4a8 = _DAT_0214f4a8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f484[2])();
    if (cVar1 != '\0') {
      _DAT_0214f4a8 = _DAT_0214f4a8 & 0xfffffff3;
    }
  }
  DAT_0214f484 = RBX::Reflection::PropDescriptor<class_RBX::UIPageLayout,class_RBX::UDim>::vftable;
  FUN_016f3654(&LAB_018a8590);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2227 ; VA 0x005302b0 ; FUN_005302b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005302b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b9fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eea5e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,class_RBX::ColorSequence>::
              GetSetImpl<class_RBX::ColorSequence_const&_(__thiscall_RBX::UIGradient::*)(void)const_,void_(__thiscall_RBX::UIGradient::*)(class_RBX::ColorSequence_const&)>
              ::vftable;
    puVar3[2] = &LAB_00731580;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eeb830;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00a8dcc0();
  FUN_009ca670(uVar2,uVar4,s_Color_0213abec,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f91c = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ColorSequence>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f950 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f940 = _DAT_0214f940 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f91c[2])();
    if (cVar1 != '\0') {
      _DAT_0214f940 = _DAT_0214f940 & 0xfffffff3;
    }
  }
  DAT_0214f91c = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,class_RBX::ColorSequence>::
                 vftable;
  FUN_016f3654(&LAB_018a8610);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2228 ; VA 0x005303e0 ; FUN_005303e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005303e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ba2c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eea5e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,bool>::
              GetSetImpl<bool_(__thiscall_RBX::UIGradient::*)(void)const_,void_(__thiscall_RBX::UIGradient::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_007cfe50;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eeb890;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Enabled_0212c1fc,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f8e4 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f918 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f908 = _DAT_0214f908 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f8e4[2])();
    if (cVar1 != '\0') {
      _DAT_0214f908 = _DAT_0214f908 & 0xfffffff3;
    }
  }
  DAT_0214f8e4 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,bool>::vftable;
  FUN_016f3654(&LAB_018a8630);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2229 ; VA 0x00530510 ; FUN_00530510 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530510(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ba5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eea5e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,class_RBX::NumberSequence>::
              GetSetImpl<class_RBX::NumberSequence_const&_(__thiscall_RBX::UIGradient::*)(void)const_,void_(__thiscall_RBX::UIGradient::*)(class_RBX::NumberSequence_const&)>
              ::vftable;
    puVar3[2] = FUN_00d01ad0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eeba10;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00a92ae0();
  FUN_009ca670(uVar2,uVar4,s_Transparency_021392fc,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f98c = RBX::Reflection::TypedPropertyDescriptor<class_RBX::NumberSequence>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f9c0 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f9b0 = _DAT_0214f9b0 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f98c[2])();
    if (cVar1 != '\0') {
      _DAT_0214f9b0 = _DAT_0214f9b0 & 0xfffffff3;
    }
  }
  DAT_0214f98c = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,class_RBX::NumberSequence>::
                 vftable;
  FUN_016f3654(&LAB_018a8650);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2230 ; VA 0x00530640 ; FUN_00530640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530640(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ba8c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eea5e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_(__thiscall_RBX::UIGradient::*)(void)const_,void_(__thiscall_RBX::UIGradient::*)(class_G3D::Vector2_const&)>
              ::vftable;
    puVar3[2] = FUN_00eeb060;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eeb970;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_Offset_02142274,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f9c4 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f9f8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f9e8 = _DAT_0214f9e8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f9c4[2])();
    if (cVar1 != '\0') {
      _DAT_0214f9e8 = _DAT_0214f9e8 & 0xfffffff3;
    }
  }
  DAT_0214f9c4 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_018a8670);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2231 ; VA 0x00530770 ; FUN_00530770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530770(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183babc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eea5e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,float>::
              GetSetImpl<float_(__thiscall_RBX::UIGradient::*)(void)const_,void_(__thiscall_RBX::UIGradient::*)(float)>
              ::vftable;
    puVar3[2] = FUN_00832130;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eeb9d0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_Rotation_0212a764,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f954 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214f988 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214f978 = _DAT_0214f978 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f954[2])();
    if (cVar1 != '\0') {
      _DAT_0214f978 = _DAT_0214f978 & 0xfffffff3;
    }
  }
  DAT_0214f954 = RBX::Reflection::PropDescriptor<class_RBX::UIGradient,float>::vftable;
  FUN_016f3654(&LAB_018a8690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2232 ; VA 0x005308b0 ; FUN_005308b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005308b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183bbac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00eebce0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UICorner,class_RBX::UDim>::
              GetSetImpl<class_RBX::UDim_(__thiscall_RBX::UICorner::*)(void)const_,void_(__thiscall_RBX::UICorner::*)(class_RBX::UDim)>
              ::vftable;
    puVar3[2] = FUN_00d5c4e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00eec270;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d690();
  FUN_009ca670(uVar2,uVar4,s_CornerRadius_0214fa34,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214f9fc = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214fa30 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214fa20 = _DAT_0214fa20 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0214f9fc[2])();
    if (cVar1 != '\0') {
      _DAT_0214fa20 = _DAT_0214fa20 & 0xfffffff3;
    }
  }
  DAT_0214f9fc = RBX::Reflection::PropDescriptor<class_RBX::UICorner,class_RBX::UDim>::vftable;
  FUN_016f3654(&LAB_018a8710);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2233 ; VA 0x00530e40 ; FUN_00530e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530e40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183be7a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_GetClientId_021501e8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02150010 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02150048 = FUN_00eeff80;
  _DAT_0215004c = 0;
  _DAT_02150034 = FUN_0088cb40();
  FUN_016f3654(&LAB_018a89b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2234 ; VA 0x00530ee0 ; FUN_00530ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530ee0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183be9a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_GetSessionId_021501f4,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02150050 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02150088 = FUN_00eeffa0;
  _DAT_0215008c = 0;
  _DAT_02150074 = FUN_0088cb40();
  FUN_016f3654(&LAB_018a89c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2235 ; VA 0x00530f80 ; FUN_00530f80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00530f80(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183befc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910();
  FUN_009cb790(uVar1,s_ReleaseRBXEventStream_021500fc,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214fda8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0214fde0 = FUN_00ef0000;
  _DAT_0214fde4 = 0;
  DAT_0214fde8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214fdcc = FUN_00888530();
  if (DAT_0214fde8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0214fde8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_target_02127abc);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a89d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2236 ; VA 0x00531100 ; FUN_00531100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531100(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183bf2e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_ReportCounter_02150138,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fe38 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0214fe70 = FUN_00ef0080;
  _DAT_0214fe74 = 0;
  _DAT_0214fe78 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_0214fe7c = (undefined4 *)FUN_01674e20(4);
  if (DAT_0214fe7c == (undefined4 *)0x0) {
    DAT_0214fe7c = (undefined4 *)0x0;
  }
  else {
    *DAT_0214fe7c = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00eeee20();
  FUN_016f3654(&LAB_018a89f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2237 ; VA 0x005311e0 ; FUN_005311e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005311e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183bf68;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_ReportInfluxSeries_021501a0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214ff70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,int),3>
       ::vftable;
  _DAT_0214ffa8 = FUN_00ef0100;
  _DAT_0214ffac = 0;
  _DAT_0214ffb0 = 0;
  _DAT_0214ffb4 = 0;
  _DAT_0214ffb8 = 0;
  uStack_8 = 3;
  FUN_00eef270(s_seriesName_02150194,s_points_0215018c,s_throttlingPercentage_02150174);
  FUN_016f3654(&LAB_018a8a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2238 ; VA 0x005312b0 ; FUN_005312b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005312b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183bfa8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_ReportToDiagByCountryCode_021501cc,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214ffc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,double),3>
       ::vftable;
  _DAT_0214fff8 = FUN_00ef02f0;
  _DAT_0214fffc = 0;
  _DAT_02150000 = 0;
  _DAT_02150004 = 0;
  DAT_02150008 = 0;
  uStack_8 = 3;
  FUN_00eeeae0(s_featureName_021501c0,s_measureName_021501b4,s_seconds_021205a0);
  FUN_016f3654(&LAB_018a8a30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2239 ; VA 0x00531380 ; FUN_00531380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531380(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183bfde;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_ReportStats_02150148,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fe80 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,float),2>
       ::vftable;
  _DAT_0214feb8 = FUN_00ef0260;
  _DAT_0214febc = 0;
  _DAT_0214fec0 = 0;
  DAT_0214fec4 = 0;
  uStack_8 = 2;
  FUN_00eef000();
  FUN_016f3654(&LAB_018a8a70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2240 ; VA 0x00531440 ; FUN_00531440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531440(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c022;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_SendEventDeferred_021500e8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fd58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_0214fd90 = FUN_00ef03d0;
  _DAT_0214fd94 = 0;
  _DAT_0214fd98 = 0;
  _DAT_0214fd9c = 0;
  _DAT_0214fda0 = 0;
  _DAT_0214fda4 = 0;
  uStack_8 = 4;
  FUN_00eedf80(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2241 ; VA 0x00531520 ; FUN_00531520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531520(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c062;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_SendEventImmediately_021500d0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fd08 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_0214fd40 = FUN_00ef0650;
  _DAT_0214fd44 = 0;
  _DAT_0214fd48 = 0;
  _DAT_0214fd4c = 0;
  _DAT_0214fd50 = 0;
  _DAT_0214fd54 = 0;
  uStack_8 = 4;
  FUN_00eedf80(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8ab0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2242 ; VA 0x00531600 ; FUN_00531600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531600(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c0a2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_SetRBXEvent_021500b0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fc68 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_0214fca0 = FUN_00ef08d0;
  _DAT_0214fca4 = 0;
  _DAT_0214fca8 = 0;
  _DAT_0214fcac = 0;
  _DAT_0214fcb0 = 0;
  _DAT_0214fcb4 = 0;
  uStack_8 = 4;
  FUN_00eedf80(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8ac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2243 ; VA 0x005316e0 ; FUN_005316e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005316e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c0e2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_SetRBXEventStream_021500bc,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fcb8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_0214fcf0 = FUN_00ef0ba0;
  _DAT_0214fcf4 = 0;
  _DAT_0214fcf8 = 0;
  _DAT_0214fcfc = 0;
  _DAT_0214fd00 = 0;
  _DAT_0214fd04 = 0;
  uStack_8 = 4;
  FUN_00eedf80(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8ad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2244 ; VA 0x005317c0 ; FUN_005317c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005317c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c122;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_TrackEvent_02150154,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214fec8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64),4>
       ::vftable;
  _DAT_0214ff00 = FUN_00ef0e70;
  _DAT_0214ff04 = 0;
  _DAT_0214ff08 = 0;
  _DAT_0214ff0c = 0;
  _DAT_0214ff10 = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  DAT_0214ff14 = (undefined4 *)FUN_01674e20(8);
  if (DAT_0214ff14 == (undefined4 *)0x0) {
    DAT_0214ff14 = (undefined4 *)0x0;
  }
  else {
    *DAT_0214ff14 = 0;
    DAT_0214ff14[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00eee760(s_category_0211cfd0,s_action_0211cfc8,s_label_0211cfc0,s_value_0211ab70);
  FUN_016f3654(&LAB_018a8ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2245 ; VA 0x005318c0 ; FUN_005318c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005318c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c16c;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910(uVar2,0);
  FUN_009cb790(uVar1,s_TrackEventWithArgs_02150160,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0214ff18 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,__int64),5>
       ::vftable;
  _DAT_0214ff50 = FUN_00ef0fe0;
  _DAT_0214ff54 = 0;
  _DAT_0214ff58 = 0;
  _DAT_0214ff5c = 0;
  _DAT_0214ff60 = 0;
  _DAT_0214ff64 = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  _DAT_0214ff68 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_0214ff68 == (undefined4 *)0x0) {
    _DAT_0214ff68 = (undefined4 *)0x0;
  }
  else {
    *_DAT_0214ff68 = 0;
    _DAT_0214ff68[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00eee300(s_category_0211cfd0,s_action_0211cfc8,s_label_0211cfc0,&DAT_0212666c,s_value_0211ab70
              );
  FUN_016f3654(&LAB_018a8b20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2246 ; VA 0x005319d0 ; FUN_005319d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005319d0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c1cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00eed910();
  FUN_009cb790(uVar1,s_UpdateHeartbeatObject_02150114,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0214fdf0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RbxAnalyticsService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
       ::vftable;
  _DAT_0214fe28 = FUN_00ef12e0;
  _DAT_0214fe2c = 0;
  DAT_0214fe30 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214fe14 = FUN_00888530();
  if (DAT_0214fe30 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_00687440(DAT_0214fe30);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008881d0();
  uVar3 = FUN_0086e3d0(&DAT_0212666c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a8b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2247 ; VA 0x00531b60 ; FUN_00531b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531b60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c662;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef1440(uVar2,0);
  FUN_009cb790(uVar1,s_SendEventDeferred_021500e8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021502f8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::EventIngestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_02150330 = FUN_00ef1f10;
  _DAT_02150334 = 0;
  _DAT_02150338 = 0;
  _DAT_0215033c = 0;
  _DAT_02150340 = 0;
  _DAT_02150344 = 0;
  uStack_8 = 4;
  FUN_00ef1860(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8be0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2248 ; VA 0x00531c40 ; FUN_00531c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531c40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c6a2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef1440(uVar2,0);
  FUN_009cb790(uVar1,s_SendEventImmediately_021500d0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021502a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::EventIngestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_021502e0 = FUN_00ef1fd0;
  _DAT_021502e4 = 0;
  _DAT_021502e8 = 0;
  _DAT_021502ec = 0;
  _DAT_021502f0 = 0;
  _DAT_021502f4 = 0;
  uStack_8 = 4;
  FUN_00ef1860(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8bf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2249 ; VA 0x00531d20 ; FUN_00531d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531d20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c6e2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef1440(uVar2,0);
  FUN_009cb790(uVar1,s_SetRBXEvent_021500b0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02150208 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::EventIngestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_02150240 = FUN_00ef2090;
  _DAT_02150244 = 0;
  _DAT_02150248 = 0;
  _DAT_0215024c = 0;
  _DAT_02150250 = 0;
  _DAT_02150254 = 0;
  uStack_8 = 4;
  FUN_00ef1860(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8c00);
  ExceptionList = pvStack_10;
  return;
}


