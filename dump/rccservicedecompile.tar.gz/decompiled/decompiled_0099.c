/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 24750 ; VA 0x00b71410 ; FUN_00b71410 */

int * FUN_00b71410(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b714bb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b7144e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1de92fc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_1b687a9858c3247330c8ab6f3c45201f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 24751 ; VA 0x00b714d0 ; FUN_00b714d0 */

void FUN_00b714d0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_00b693a0(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0056d080();
        piVar2 = *(int **)(iVar4 + 0xc);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = *(int **)(iVar4 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(iVar4,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1de936c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_30031ea8601d7a571f17a36b51fedf87>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 24752 ; VA 0x00b71660 ; FUN_00b71660 */

void __thiscall FUN_00b71660(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  byte *pbVar2;
  int *piVar3;
  code *pcVar4;
  void *pvVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined8 *puVar9;
  undefined4 *puVar10;
  undefined auStack_60 [16];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f69b6;
  pvStack_10 = ExceptionList;
  pbVar2 = (byte *)*param_2;
  if (((pbVar2 != (byte *)0x0) && (*(int *)(param_1 + 0x58) != 0)) &&
     (*(int *)(*(int *)(param_1 + 0x58) + 0x10) != 2)) {
    auStack_30[0] = 0;
    ExceptionList = &pvStack_10;
    uStack_2c = FUN_00588320(0xb);
    uStack_28 = 0;
    uStack_24 = 0x3f800000;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = 0;
    FUN_005542c0("placeId",7);
    bVar1 = *pbVar2;
    uVar6 = FUN_005702d0(auStack_60);
    FUN_00562fc0(&param_2,uVar6,auStack_60,
                 -(uint)(pbVar2 + bVar1 + 1 != (byte *)0x0) & (uint)(pbVar2 + bVar1 + 1 + 1));
    FUN_005507b0();
    uStack_18 = CONCAT44(uStack_18._4_4_,(int)uStack_18);
    if ((param_2 != (undefined4 *)0x0) &&
       (uStack_18 = CONCAT44(uStack_18._4_4_,(int)uStack_18), *(char *)(param_2[8] + 0x21) != '\0'))
    {
      uStack_18 = FUN_00563790();
      puVar9 = &uStack_18;
      FUN_005c4c00(&DAT_01d6746c);
      FUN_00632bc0(puVar9);
      iVar7 = FUN_008f7870(param_1);
      if (iVar7 != 0) {
        piVar3 = *(int **)(iVar7 + 0x43c);
        uStack_18._0_4_ = *piVar3 - (int)piVar3;
        uStack_18._4_4_ = piVar3[1] - (int)piVar3;
        puVar9 = &uStack_18;
        FUN_005c4c00(&DAT_01d67454);
        FUN_00632bc0(puVar9);
      }
      iVar8 = FUN_005c4c00(&DAT_01d6749c);
      uVar6 = FUN_0088daf0();
      pvVar5 = ThreadLocalStoragePointer;
      iVar7 = _tls_index;
      *(undefined4 *)(iVar8 + 0x18) = uVar6;
      if (*(int *)(*(int *)((int)pvVar5 + iVar7 * 4) + 0x34) < DAT_01ea8bf8) {
        FUN_016f3809(&DAT_01ea8bf8);
        if (DAT_01ea8bf8 == -1) {
          DAT_01ea8bec = FUN_005c6640;
          DAT_01ea8bf0 = FUN_005c6640;
          DAT_01ea8bf4 = _guard_check_icall;
          FUN_016f37bf(&DAT_01ea8bf8);
        }
      }
      puVar10 = *(undefined4 **)(iVar8 + 0x1c);
      if ((code **)puVar10 == &DAT_01ea8bec) {
        *(undefined *)(iVar8 + 0x20) = (undefined)param_4;
      }
      else {
        if (puVar10 != (undefined4 *)0x0) {
          (*(code *)puVar10[2])(iVar8 + 0x20);
        }
        *(undefined *)(iVar8 + 0x20) = (undefined)param_4;
        *(code ***)(iVar8 + 0x1c) = &DAT_01ea8bec;
      }
      param_4 = param_3;
      puVar10 = &param_4;
      FUN_005c4c00(&DAT_01d67484);
      FUN_005c1740(puVar10);
      auStack_48[0] = 0;
      uStack_44 = FUN_00588320(0xb);
      uStack_40 = 0;
      uStack_3c = 0x3f800000;
      uStack_38 = 0;
      uStack_34 = 0;
      uStack_8._0_1_ = 1;
      FUN_0054ef60(&DAT_01d672bc);
      FUN_00b6e100(auStack_48);
      uVar6 = FUN_00ac3970(&uStack_18,auStack_30);
      uStack_8._0_1_ = 2;
      uVar6 = FUN_00b67b80(uVar6);
      uStack_8._0_1_ = 3;
      FUN_005c4c00(&DAT_01d67514);
      FUN_00947a40(uVar6);
      FUN_0056e5b0();
      uStack_8._0_1_ = 1;
      FUN_00550b30();
      uVar6 = FUN_00ac3970(&uStack_18,auStack_48);
      uStack_8._0_1_ = 4;
      FUN_00b67b80(uVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      FUN_00550b30();
      pcVar4 = *(code **)(**(int **)(param_1 + 0x58) + 0xc);
      FUN_0054ef60(&DAT_01d672bc);
      (*pcVar4)();
      FUN_0056e5b0();
      FUN_0056d080();
    }
    FUN_0056d080();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24753 ; VA 0x00b71990 ; FUN_00b71990 */

int __thiscall FUN_00b71990(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  undefined auStack_130 [4];
  int iStack_12c;
  undefined auStack_128 [200];
  undefined auStack_60 [8];
  undefined auStack_58 [24];
  undefined8 uStack_40;
  undefined auStack_38 [8];
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f69eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00562c90(&iStack_18,param_2);
  uStack_8 = 0;
  if (((iStack_18 != 0) && (iVar3 = *(int *)(param_1 + 0x58), iVar3 != 0)) &&
     (*(int *)(iVar3 + 0x10) != 2)) {
    FUN_0054ef60(*(undefined4 *)(iStack_18 + 0x28));
    uStack_8._0_1_ = 1;
    (**(code **)(**(int **)(param_1 + 0x58) + 8))(auStack_58);
    auStack_30[0] = 0;
    uStack_2c = FUN_00588320(0xb);
    uStack_28 = 0;
    uStack_24 = 0x3f800000;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&DAT_01d671e4);
    FUN_00b6e320(&iStack_18,auStack_30);
    uVar4 = FUN_00ac3970(auStack_38,auStack_30);
    uStack_8._0_1_ = 3;
    FUN_00b67b80(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_00550b30();
    (**(code **)(**(int **)(param_1 + 0x58) + 0x10))(auStack_58,&DAT_01d671e4,auStack_130);
    if (DAT_01d675c4 != '\0') {
      puVar5 = (undefined8 *)FUN_016830f0(auStack_60);
      uStack_40 = *puVar5;
      puVar5 = (undefined8 *)FUN_00b6a530(&iStack_18);
      *puVar5 = uStack_40;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (iStack_12c != 0) {
      (**(code **)(iStack_12c + 8))(auStack_128);
    }
    FUN_0056d080();
    iVar3 = FUN_005507b0();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 24754 ; VA 0x00b71b30 ; FUN_00b71b30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00b71b30(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  void *pvVar4;
  char *pcVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  double *pdVar9;
  int iVar10;
  undefined4 uVar11;
  uint uVar12;
  char *pcVar13;
  undefined4 *puVar14;
  undefined auStack_134 [4];
  int iStack_130;
  undefined auStack_12c [200];
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [4];
  undefined4 *puStack_48;
  undefined auStack_44 [4];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6a2b;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(param_1 + 0x58);
  if ((iVar6 != 0) && (*(int *)(iVar6 + 0x10) != 2)) {
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    iVar6 = FUN_00562c90(&uStack_24,param_2);
    uStack_8 = 0;
    if (uStack_24 != 0) {
      auStack_44[0] = 0;
      uStack_40 = FUN_00588320(0xb);
      uStack_3c = 0;
      uStack_38 = 0x3f800000;
      uStack_34 = 0;
      uStack_30 = 0;
      uStack_8._0_1_ = 1;
      FUN_0054ef60(&DAT_01d671fc);
      FUN_00b6e320(&uStack_24,auStack_44);
      if (DAT_01d675c4 != '\0') {
        iStack_28 = *(int *)(param_1 + 0x104);
        puVar2 = *(undefined4 **)(param_1 + 0xfc);
        uVar12 = *(uint *)(param_1 + 0x110) &
                 ((((uStack_24 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ (int)uStack_24 >> 8 & 0xffU) *
                   0x1000193 ^ (int)uStack_24 >> 0x10 & 0xffU) * 0x1000193 ^
                 (int)uStack_24 >> 0x18 & 0xffU) * 0x1000193;
        puStack_2c = *(undefined4 **)(iStack_28 + uVar12 * 8);
        puVar7 = puStack_2c;
        while( true ) {
          puVar8 = puVar2;
          if (puStack_2c != puVar2) {
            puVar8 = (undefined4 *)**(undefined4 **)(iStack_28 + 4 + uVar12 * 8);
          }
          if (puVar7 == puVar8) goto LAB_00b71c9b;
          if (puVar7[2] == uStack_24) break;
          puVar7 = (undefined4 *)*puVar7;
        }
        uStack_1c = (double)CONCAT44(puVar7,(undefined4)uStack_1c);
        puVar8 = puVar7;
        while( true ) {
          puVar14 = puVar2;
          if (puStack_2c != puVar2) {
            puVar14 = (undefined4 *)**(undefined4 **)(iStack_28 + 4 + uVar12 * 8);
          }
          if ((puVar8 == puVar14) || (uStack_24 != puVar8[2])) break;
          puVar8 = (undefined4 *)*puVar8;
        }
        puStack_48 = puVar7;
        if (puVar7 == puVar8) {
LAB_00b71c9b:
          puVar8 = puVar2;
          puVar7 = puVar2;
        }
        iVar6 = 0;
        param_1 = iStack_14;
        if (puVar7 != puVar8) {
          do {
            puVar7 = (undefined4 *)*puVar7;
            iVar6 = iVar6 + 1;
          } while (puVar7 != puVar8);
          if (iVar6 != 0) {
            pdVar9 = (double *)FUN_016830f0(auStack_4c);
            uStack_1c = *pdVar9;
            pdVar9 = (double *)FUN_00b6a530(&uStack_24);
            uStack_1c = uStack_1c - *pdVar9;
            uStack_54 = 0;
            uStack_50 = 0xf;
            auStack_64[0] = 0;
            pcVar5 = "sessionTime";
            do {
              pcVar13 = pcVar5;
              pcVar5 = pcVar13 + 1;
            } while (*pcVar13 != '\0');
            FUN_005542c0(&DAT_019567ec,pcVar13 + -0x19567ec);
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            iVar10 = FUN_005c4c00(auStack_64);
            uVar11 = FUN_0088ca00();
            pvVar4 = ThreadLocalStoragePointer;
            iVar6 = _tls_index;
            *(undefined4 *)(iVar10 + 0x18) = uVar11;
            if ((*(int *)(*(int *)((int)pvVar4 + iVar6 * 4) + 0x34) < DAT_01ead488) &&
               (FUN_016f3809(&DAT_01ead488), DAT_01ead488 == -1)) {
              _DAT_01ead47c = FUN_00619e80;
              _DAT_01ead480 = FUN_00619e80;
              DAT_01ead484 = _guard_check_icall;
              FUN_016f37bf(&DAT_01ead488);
            }
            puVar3 = *(undefined **)(iVar10 + 0x1c);
            if (puVar3 == &DAT_01ead47c) {
              *(double *)(iVar10 + 0x20) = uStack_1c;
            }
            else {
              if (puVar3 != (undefined *)0x0) {
                (**(code **)(puVar3 + 8))(iVar10 + 0x20);
              }
              *(double *)(iVar10 + 0x20) = uStack_1c;
              *(undefined **)(iVar10 + 0x1c) = &DAT_01ead47c;
            }
            uStack_8._0_1_ = 1;
            FUN_005507b0();
            FUN_00b6d3a0(&uStack_24);
            param_1 = iStack_14;
          }
        }
      }
      uVar11 = FUN_00ac3970(&uStack_1c,auStack_44);
      uStack_8._0_1_ = 3;
      FUN_00b67b80(uVar11);
      uStack_8._0_1_ = 5;
      FUN_00550b30();
      (**(code **)(**(int **)(param_1 + 0x58) + 0x10))
                (*(undefined4 *)(uStack_24 + 0x28),&DAT_01d671fc,auStack_134);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (iStack_130 != 0) {
        (**(code **)(iStack_130 + 8))(auStack_12c);
      }
      iVar6 = FUN_0056d080();
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar10 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        iVar6 = (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar10 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          iVar6 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 24755 ; VA 0x00b71eb0 ; FUN_00b71eb0 */

void __thiscall
FUN_00b71eb0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            char param_6,undefined4 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 *puVar2;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6a50;
  pvStack_10 = ExceptionList;
  if (((*(int *)(param_1 + 0x58) != 0) && (*(int *)(*(int *)(param_1 + 0x58) + 0x10) != 2)) &&
     (param_6 != '\0')) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_008f7870(param_1);
    if (iVar1 != 0) {
      iVar1 = FUN_005cf750();
      if (iVar1 != 0) {
        puVar2 = (undefined4 *)FUN_00980280(auStack_18,param_2,param_3);
        uStack_8 = 0;
        FUN_0060dcd0(&param_2,*puVar2);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00550b30();
        if (param_2 != 0) {
          FUN_00b71f70(&param_2,param_4,param_5,param_7,param_8);
        }
        FUN_00550b30();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24756 ; VA 0x00b71f70 ; FUN_00b71f70 */

int __thiscall
FUN_00b71f70(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int iStack_9c;
  int *piStack_98;
  undefined4 uStack_94;
  undefined4 uStack_80;
  undefined *puStack_7c;
  int *piStack_78;
  int iStack_74;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined4 *puStack_54;
  undefined auStack_44 [4];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6a8b;
  pvStack_10 = ExceptionList;
  iVar3 = param_1[0x16];
  if (iVar3 == 0) {
    return 0;
  }
  if (*(int *)(iVar3 + 0x10) == 2) {
    return iVar3;
  }
  puStack_54 = (undefined4 *)param_2;
  piStack_58 = &iStack_24;
  uStack_5c = 0xb71fb4;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar3 = FUN_00562c90();
  uStack_8 = 0;
  if (iStack_24 == 0) goto LAB_00b7215e;
  puStack_54 = (undefined4 *)0xb;
  auStack_44[0] = 0;
  piStack_58 = (int *)0xb71fd9;
  uStack_40 = FUN_00588320();
  uStack_3c = 0;
  uStack_38 = 0x3f800000;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_8._0_1_ = 1;
  if (param_5 == 0) {
    puStack_54 = (undefined4 *)&DAT_01d67394;
    piStack_58 = (int *)0xb72054;
    iVar3 = FUN_005c4c00();
    puStack_54 = (undefined4 *)0xb7205b;
    uVar4 = FUN_0088cb40();
    puStack_54 = (undefined4 *)&DAT_01d6752c;
LAB_00b72060:
    *(undefined4 *)(iVar3 + 0x18) = uVar4;
    piStack_58 = (int *)0xb7206b;
    FUN_005c17a0();
  }
  else {
    if (param_5 == 1) {
      puStack_54 = (undefined4 *)&DAT_01d67394;
      piStack_58 = (int *)0xb72039;
      iVar3 = FUN_005c4c00();
      puStack_54 = (undefined4 *)0xb72040;
      uVar4 = FUN_0088cb40();
      puStack_54 = (undefined4 *)&DAT_01d6755c;
      goto LAB_00b72060;
    }
    if (param_5 == 2) {
      puStack_54 = (undefined4 *)&DAT_01d67394;
      piStack_58 = (int *)0xb7201e;
      iVar3 = FUN_005c4c00();
      puStack_54 = (undefined4 *)0xb72025;
      uVar4 = FUN_0088cb40();
      puStack_54 = (undefined4 *)&DAT_01d67544;
      goto LAB_00b72060;
    }
  }
  puStack_54 = &param_3;
  piStack_58 = (int *)&DAT_01d673ac;
  uStack_5c = 0xb7207c;
  FUN_005c4c00();
  piStack_58 = (int *)0xb72084;
  FUN_00632bc0();
  puStack_54 = &param_3;
  piStack_58 = (int *)&DAT_01d673ac;
  uStack_5c = 0xb72095;
  FUN_005c4c00();
  piStack_58 = (int *)0xb7209d;
  FUN_00632bc0();
  iStack_74 = 0;
  piStack_78 = piStack_14;
  pcStack_18 = *(code **)(*piStack_14 + 0xa4);
  puStack_7c = auStack_2c;
  uStack_80 = 0xb720bd;
  puVar5 = (undefined4 *)FUN_0060e0c0();
  puStack_1c = (undefined *)&uStack_a4;
  uStack_a4 = *puVar5;
  uStack_a0 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  iStack_9c = iStack_24;
  piStack_98 = piStack_20;
  uStack_94 = param_6;
  uStack_8._0_1_ = 4;
  FUN_005c4580(auStack_44);
  piStack_78 = (int *)param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b67a20();
  iStack_74 = param_5;
  piStack_78 = (int *)param_4;
  puStack_7c = (undefined *)param_3;
  uStack_80 = 0xb72141;
  (*pcStack_18)();
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[2] + -1;
    piStack_28[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_54 = (undefined4 *)0xb72156;
      (**(code **)(*piStack_28 + 4))();
    }
  }
  puStack_54 = (undefined4 *)0xb7215e;
  iVar3 = FUN_0056d080();
LAB_00b7215e:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_54 = (undefined4 *)0xb72171;
      iVar3 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_54 = (undefined4 *)0xb72180;
        iVar3 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 24757 ; VA 0x00b721a0 ; FUN_00b721a0 */

void FUN_00b721a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,char param_4,
                 undefined4 param_5,undefined4 param_6)

{
  if (param_4 != '\0') {
    FUN_00b71f70(param_1,param_2,param_3,param_5,param_6);
  }
  return;
}



/* FUNCTION 24758 ; VA 0x00b721d0 ; FUN_00b721d0 */

void __thiscall FUN_00b721d0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  double *pdVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined auStack_bc [8];
  undefined4 uStack_b4;
  int **ppiStack_b0;
  int **ppiStack_ac;
  code **ppcStack_a8;
  uint uStack_94;
  uint uStack_80;
  code *pcStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  uint auStack_54 [2];
  code *pcStack_4c;
  int iStack_48;
  int *piStack_44;
  uint uStack_40;
  code *pcStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6bea;
  pvStack_10 = ExceptionList;
  piStack_24 = (int *)0x0;
  ppcStack_a8 = (code **)param_3;
  ppiStack_ac = (int **)param_2;
  piStack_14 = (int *)0x0;
  ppiStack_b0 = (int **)0xb72206;
  ExceptionList = &pvStack_10;
  FUN_008a4210();
  if (piVar4 == (int *)0x0) {
    cVar2 = *(char *)(param_1 + 0x3a);
  }
  else {
    ppiStack_ac = (int **)0xb72210;
    ppcStack_a8 = (code **)param_1;
    iVar3 = FUN_008f7870();
    if ((iVar3 != 0) && (*(int *)(iVar3 + 0x4a0) == 2)) {
      ppcStack_a8 = (code **)0xb72229;
      cVar2 = FUN_008ff0d0();
      if (cVar2 == '\0') {
        ppiStack_ac = (int **)0xb72236;
        ppcStack_a8 = (code **)(iVar3 + 0xc);
        cVar2 = FUN_00983210();
        if (cVar2 == '\0') {
          ppiStack_ac = (int **)0xb72243;
          ppcStack_a8 = (code **)(iVar3 + 0xc);
          cVar2 = FUN_00983250();
          if (cVar2 == '\0') {
            cVar2 = '\x01';
            *(undefined *)(param_1 + 0x3a) = 1;
            goto LAB_00b72264;
          }
        }
      }
    }
    cVar2 = '\0';
    *(undefined *)(param_1 + 0x3a) = 0;
  }
LAB_00b72264:
  if (cVar2 != '\0') {
    if (param_2 != (int *)0x0) {
      param_2 = (int *)param_1[0x19];
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
        param_2 = (int *)param_1[0x19];
      }
      piStack_20 = (int *)param_1[0x18];
      uStack_8 = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      piStack_1c = param_2;
      piStack_18 = piStack_20;
      FUN_0151dac0(piStack_20,param_2,1,0);
      uStack_8 = 0xffffffff;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar3 = param_2[1] + -1;
        param_2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppcStack_a8 = (code **)0xb722f6;
          (**(code **)*param_2)();
          LOCK();
          iVar3 = param_2[2] + -1;
          param_2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb72307;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      param_1[0x18] = 0;
      param_2 = (int *)param_1[0x19];
      param_1[0x19] = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar3 = param_2[1] + -1;
        param_2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppcStack_a8 = (code **)0xb7232c;
          (**(code **)*param_2)();
          LOCK();
          iVar3 = param_2[2] + -1;
          param_2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb7233d;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      ppcStack_a8 = (code **)0xb72345;
      FUN_01679490();
      ppcStack_a8 = (code **)0xb7234d;
      FUN_01679490();
      if ((int *)param_1[0x16] != (int *)0x0) {
        ppcStack_a8 = (code **)0xb72359;
        (**(code **)(*(int *)param_1[0x16] + 0x1c))();
      }
      if (DAT_01d6757c != '\0') {
        ppiStack_ac = (int **)(param_1 + 0x30);
        ppcStack_a8 = (code **)0x0;
        ppiStack_b0 = (int **)0xb72370;
        FUN_00874d70();
      }
      ppiStack_ac = (int **)(param_1 + 0x2a);
      ppcStack_a8 = (code **)0x0;
      ppiStack_b0 = (int **)0xb72381;
      FUN_008749d0();
      param_1[0x16] = 0;
      param_2 = (int *)param_1[0x17];
      param_1[0x17] = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar3 = param_2[1] + -1;
        param_2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppcStack_a8 = (code **)0xb723a9;
          (**(code **)*param_2)();
          LOCK();
          iVar3 = param_2[2] + -1;
          param_2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb723ba;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      ppcStack_a8 = (code **)0xb723c5;
      FUN_01679490();
    }
    if (param_3 != (int *)0x0) {
      ppcStack_a8 = (code **)&param_2;
      ppiStack_ac = (int **)&uStack_34;
      ppiStack_b0 = (int **)0xb723df;
      param_2 = param_1;
      piVar4 = (int *)FUN_00b68c40();
      iVar3 = *piVar4;
      iVar1 = piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      param_1[0x18] = iVar3;
      param_2 = (int *)param_1[0x19];
      param_1[0x19] = iVar1;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar3 = param_2[1] + -1;
        param_2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppcStack_a8 = (code **)0xb72411;
          (**(code **)*param_2)();
          LOCK();
          iVar3 = param_2[2] + -1;
          param_2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb72422;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      param_2 = uStack_34._4_4_;
      if (uStack_34._4_4_ != (int *)0x0) {
        LOCK();
        iVar3 = uStack_34._4_4_[1] + -1;
        uStack_34._4_4_[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppcStack_a8 = (code **)0xb72439;
          (**(code **)*uStack_34._4_4_)();
          LOCK();
          iVar3 = param_2[2] + -1;
          param_2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb7244a;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      if (param_1[0x19] != 0) {
        LOCK();
        piVar4 = (int *)(param_1[0x19] + 4);
        *piVar4 = *piVar4 + 1;
        UNLOCK();
      }
      ppiStack_ac = (int **)param_1[0x18];
      ppcStack_a8 = (code **)param_1[0x19];
      ppiStack_b0 = (int **)0xb72477;
      FUN_0151d950();
      ppiStack_b0 = &piStack_20;
      uStack_b4 = 0xb72480;
      pdVar5 = (double *)FUN_016830f0();
      uStack_34 = (double)DAT_01d67158 + *pdVar5;
      *(double *)(param_1 + 0x38) = uStack_34;
      *(longlong *)(param_1 + 0x36) = (longlong)DAT_01d67160 * (longlong)DAT_01d67158 * 0x400;
      ppcStack_a8 = (code **)0xb724dc;
      piStack_18 = (int *)FUN_005cf750();
      if (piStack_18 != (int *)0x0) {
        pcStack_3c = FUN_00b71990;
        ppcStack_a8 = &pcStack_3c;
        uStack_38 = 0;
        ppiStack_ac = &piStack_1c;
        uStack_34 = (double)CONCAT44(uStack_34._4_4_,param_1);
        ppiStack_b0 = (int **)0xb7250b;
        param_2 = (int *)FUN_00b68960();
        uStack_8 = 1;
        ppiStack_ac = (int **)0xb72520;
        ppcStack_a8 = (code **)param_2;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb7252c;
          FUN_01679490();
          ppcStack_a8 = (code **)param_2;
          ppiStack_ac = (int **)0xb72537;
          FUN_016791c0();
        }
        uStack_8 = 0xffffffff;
        if (piStack_1c != (int *)0x0) {
          piVar4 = piStack_1c + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_1c;
            ppiStack_ac = (int **)0xb7255b;
            FUN_01674ea0();
          }
        }
        ppcStack_a8 = &pcStack_3c;
        ppiStack_ac = &piStack_1c;
        pcStack_3c = FUN_00b71b30;
        uStack_38 = 0;
        uStack_34 = (double)CONCAT44(uStack_34._4_4_,param_1);
        ppiStack_b0 = (int **)0xb72585;
        param_2 = (int *)FUN_00b68960();
        uStack_8 = 2;
        ppiStack_ac = (int **)0xb7259a;
        ppcStack_a8 = (code **)param_2;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb725a6;
          FUN_01679490();
          ppcStack_a8 = (code **)param_2;
          ppiStack_ac = (int **)0xb725b1;
          FUN_016791c0();
        }
        uStack_8 = 0xffffffff;
        if (piStack_1c != (int *)0x0) {
          piVar4 = piStack_1c + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_1c;
            ppiStack_ac = (int **)0xb725d5;
            FUN_01674ea0();
          }
        }
      }
      ppcStack_a8 = (code **)0xb725e0;
      param_2 = (int *)FUN_00b15250();
      if (param_2 != (int *)0x0) {
        piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ef05ba);
        piStack_28 = (int *)CONCAT31(piStack_28._1_3_,DAT_01ef05b9);
        FUN_0054ef60(&DAT_01d67214);
        ppcStack_a8 = (code **)FUN_00b68440(&pcStack_7c,FUN_00b71f70,0,param_1,piStack_28,piStack_1c
                                            ,0);
        ppiStack_ac = &piStack_14;
        uStack_8 = 3;
        ppiStack_b0 = (int **)0xb72643;
        ppcStack_a8 = (code **)FUN_00b68a20();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        ppiStack_ac = (int **)0xb72653;
        piStack_18 = (int *)ppcStack_a8;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb7265f;
          FUN_01679490();
          ppcStack_a8 = (code **)piStack_18;
          ppiStack_ac = (int **)0xb7266a;
          FUN_016791c0();
        }
        if (piStack_14 != (int *)0x0) {
          piVar4 = piStack_14 + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_14;
            ppiStack_ac = (int **)0xb72688;
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        ppcStack_a8 = (code **)0xb7269a;
        FUN_0056ce50();
        piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ef05ba);
        piStack_28 = (int *)CONCAT31(piStack_28._1_3_,DAT_01ef05b9);
        FUN_0054ef60(&DAT_01d67244);
        ppcStack_a8 = (code **)FUN_00b68440(&pcStack_7c,FUN_00b71f70,0,param_1,piStack_28,piStack_1c
                                            ,1);
        ppiStack_ac = &piStack_14;
        uStack_8 = 5;
        ppiStack_b0 = (int **)0xb726ef;
        ppcStack_a8 = (code **)FUN_00b68a20();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        ppiStack_ac = (int **)0xb726ff;
        piStack_18 = (int *)ppcStack_a8;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb7270b;
          FUN_01679490();
          ppcStack_a8 = (code **)piStack_18;
          ppiStack_ac = (int **)0xb72716;
          FUN_016791c0();
        }
        if (piStack_14 != (int *)0x0) {
          piVar4 = piStack_14 + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_14;
            ppiStack_ac = (int **)0xb72734;
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        ppcStack_a8 = (code **)0xb72746;
        FUN_0056ce50();
        piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ef05ba);
        piStack_14 = (int *)CONCAT31(piStack_14._1_3_,DAT_01ef05b9);
        FUN_0054ef60(&DAT_01d67274);
        piStack_18 = (int *)FUN_00b68440(&pcStack_7c,FUN_00b71f70,0,param_1,piStack_14,piStack_1c,2)
        ;
        uStack_8 = 7;
        ppcStack_a8 = (code **)0xb72799;
        FUN_006eccd0();
        ppcStack_a8 = (code **)DAT_02110da8;
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        ppiStack_ac = (int **)0xb727a8;
        uVar6 = FUN_01675290();
        uStack_34 = (double)CONCAT44(uVar6,(undefined4)uStack_34);
        ppiStack_ac = (int **)0x40;
        uStack_8 = 9;
        ppiStack_b0 = (int **)0xb727bb;
        piStack_1c = (int *)FUN_01674e20();
        if (piStack_1c == (int *)0x0) {
          piStack_14 = (int *)0x0;
        }
        else {
          *piStack_1c = 0;
          piStack_1c[1] = 1;
          piStack_1c[2] = (int)FUN_00b6d080;
          piStack_1c[3] = (int)FUN_00b6d1b0;
          piStack_1c[4] = 0;
          piStack_1c[5] = (int)param_2 + 0x164;
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          piStack_1c[6] = *piStack_18;
          piStack_1c[7] = piStack_18[1];
          piStack_1c[8] = piStack_18[2];
          piStack_1c[9] = piStack_18[3];
          ppcStack_a8 = (code **)(piStack_18 + 4);
          ppiStack_ac = (int **)0xb72821;
          piStack_14 = piStack_1c;
          FUN_0054ef60();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        ppiStack_ac = (int **)0xb7283e;
        ppcStack_a8 = (code **)piStack_14;
        FUN_016797d0();
        piStack_28 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        piStack_24 = (int *)0x2;
        uStack_8 = 0xc;
        ppiStack_ac = (int **)0xb72868;
        ppcStack_a8 = (code **)uVar6;
        FUN_01675290();
        ppcStack_a8 = (code **)&piStack_28;
        uStack_8 = 0xd;
        ppiStack_ac = (int **)0xb7287e;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb7288a;
          FUN_01679490();
          ppcStack_a8 = (code **)&piStack_28;
          ppiStack_ac = (int **)0xb72896;
          FUN_016791c0();
        }
        if (piStack_28 != (int *)0x0) {
          piVar4 = piStack_28 + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_28;
            ppiStack_ac = (int **)0xb728b4;
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        ppcStack_a8 = (code **)0xb728c6;
        FUN_0056ce50();
        piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ef05bb);
        piStack_28 = (int *)CONCAT31(piStack_28._1_3_,DAT_01ef05ba);
        piStack_14 = (int *)CONCAT31(piStack_14._1_3_,DAT_01ef05b9);
        FUN_0054ef60(&DAT_01d6722c);
        ppcStack_a8 = (code **)FUN_00b685c0(&pcStack_7c,FUN_00b721a0,0,param_1,piStack_14,piStack_28
                                            ,piStack_1c,0);
        ppiStack_ac = &piStack_24;
        uStack_8 = 0xe;
        ppiStack_b0 = (int **)0xb72926;
        ppcStack_a8 = (code **)FUN_00b68b20();
        uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
        ppiStack_ac = (int **)0xb72936;
        piStack_18 = (int *)ppcStack_a8;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb72942;
          FUN_01679490();
          ppcStack_a8 = (code **)piStack_18;
          ppiStack_ac = (int **)0xb7294d;
          FUN_016791c0();
        }
        if (piStack_24 != (int *)0x0) {
          piVar4 = piStack_24 + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_24;
            ppiStack_ac = (int **)0xb7296b;
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        ppcStack_a8 = (code **)0xb7297d;
        FUN_0056ce50();
        piStack_28 = (int *)CONCAT31(piStack_28._1_3_,DAT_01ef05bb);
        piStack_14 = (int *)CONCAT31(piStack_14._1_3_,DAT_01ef05ba);
        ppcStack_a8 = (code **)&DAT_01d6725c;
        piStack_24 = (int *)CONCAT31(piStack_24._1_3_,DAT_01ef05b9);
        ppiStack_ac = (int **)0xb729a5;
        FUN_0054ef60();
        uStack_8 = 0x10;
        uStack_34 = (double)CONCAT44(auStack_bc,(undefined4)uStack_34);
        FUN_0054ef60(auStack_54);
        piVar4 = (int *)FUN_00b69960(param_1,piStack_24,piStack_14,piStack_28,1);
        iStack_70 = piVar4[1];
        iStack_74 = *piVar4;
        ppcStack_a8 = (code **)(piVar4 + 2);
        uStack_8._0_1_ = 0x11;
        pcStack_7c = FUN_00b71eb0;
        iStack_78 = 0;
        ppiStack_ac = (int **)0xb72a0a;
        FUN_0054ef60();
        piStack_24 = (int *)0x5;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
        if (0xf < uStack_80) {
          ppcStack_a8 = (code **)(uStack_80 + 1);
          uVar7 = uStack_94;
          if (0xfff < ppcStack_a8) {
            uVar7 = *(uint *)(uStack_94 - 4);
            ppcStack_a8 = (code **)(uStack_80 + 0x24);
            if (0x1f < (uStack_94 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              ppcStack_a8 = (code **)0xb72fa0;
              FUN_017167a3();
            }
          }
          ppiStack_b0 = (int **)0xb72a49;
          ppiStack_ac = (int **)uVar7;
          FUN_01674ea0();
        }
        uStack_8 = 0xffffffff;
        if (0xf < uStack_40) {
          ppcStack_a8 = (code **)(uStack_40 + 1);
          uVar7 = auStack_54[0];
          if (0xfff < ppcStack_a8) {
            uVar7 = *(uint *)(auStack_54[0] - 4);
            ppcStack_a8 = (code **)(uStack_40 + 0x24);
            if (0x1f < (auStack_54[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              ppcStack_a8 = (code **)&UNK_00b72fa5;
              FUN_017167a3();
            }
          }
          ppiStack_b0 = (int **)0xb72a99;
          ppiStack_ac = (int **)uVar7;
          FUN_01674ea0();
        }
        piStack_44 = (int *)0x0;
        uStack_40 = 0xf;
        auStack_54[0] = auStack_54[0] & 0xffffff00;
        uStack_8 = 0x12;
        ppcStack_a8 = (code **)0xb72ac0;
        FUN_006eccd0();
        ppcStack_a8 = (code **)DAT_02110da8;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        ppiStack_ac = (int **)0xb72acf;
        uVar6 = FUN_01675290();
        uStack_34 = (double)CONCAT44(uVar6,(undefined4)uStack_34);
        ppiStack_ac = (int **)0x40;
        uStack_8 = 0x14;
        ppiStack_b0 = (int **)0xb72ae2;
        piStack_18 = (int *)FUN_01674e20();
        if (piStack_18 == (int *)0x0) {
          piStack_28 = (int *)0x0;
        }
        else {
          *piStack_18 = 0;
          piStack_18[1] = 1;
          piStack_18[2] = (int)FUN_00b6d180;
          piStack_18[3] = (int)FUN_00b6d1b0;
          piStack_18[4] = 0;
          piStack_18[5] = (int)param_2 + 0x148;
          piStack_18[6] = (int)pcStack_7c;
          piStack_18[7] = iStack_78;
          piStack_18[8] = iStack_74;
          piStack_18[9] = iStack_70;
          ppcStack_a8 = (code **)auStack_6c;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
          ppiStack_ac = (int **)0xb72b46;
          piStack_28 = piStack_18;
          FUN_0054ef60();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
        ppiStack_ac = (int **)0xb72b63;
        ppcStack_a8 = (code **)piStack_28;
        FUN_016797d0();
        piStack_1c = piStack_28;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          piStack_28[1] = piStack_28[1] + 1;
          UNLOCK();
        }
        piStack_24 = (int *)0x15;
        uStack_8 = 0x17;
        ppiStack_ac = (int **)0xb72b8d;
        ppcStack_a8 = (code **)uVar6;
        FUN_01675290();
        piStack_14 = (int *)0xd;
        piStack_24 = (int *)0xd;
        ppcStack_a8 = (code **)&piStack_1c;
        uStack_8 = 0x18;
        ppiStack_ac = (int **)0xb72bb5;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb72bc4;
          FUN_01679490();
          ppcStack_a8 = (code **)&piStack_1c;
          ppiStack_ac = (int **)0xb72bd3;
          FUN_016791c0();
        }
        if (piStack_1c != (int *)0x0) {
          piVar4 = piStack_1c + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)piStack_1c;
            ppiStack_ac = (int **)0xb72bf1;
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        ppcStack_a8 = (code **)0xb72c03;
        FUN_0056ce50();
        param_2 = (int *)CONCAT31(param_2._1_3_,DAT_01ef05bb);
        piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ef05ba);
        piStack_28 = (int *)CONCAT31(piStack_28._1_3_,DAT_01ef05b9);
        FUN_0054ef60(&DAT_01d6728c);
        ppcStack_a8 = (code **)FUN_00b685c0(&pcStack_7c,FUN_00b721a0,0,param_1,piStack_28,piStack_1c
                                            ,param_2,2);
        ppiStack_ac = (int **)((int)&uStack_34 + 4);
        uStack_8 = 0x19;
        ppiStack_b0 = (int **)0xb72c63;
        param_2 = (int *)FUN_00b68b20();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
        ppiStack_ac = (int **)0xb72c76;
        ppcStack_a8 = (code **)param_2;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb72c85;
          FUN_01679490();
          ppcStack_a8 = (code **)param_2;
          ppiStack_ac = (int **)0xb72c93;
          FUN_016791c0();
        }
        if (uStack_34._4_4_ != (int *)0x0) {
          piVar4 = (int *)((int)uStack_34._4_4_ + 4);
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)uStack_34._4_4_;
            ppiStack_ac = (int **)0xb72cb3;
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        ppcStack_a8 = (code **)0xb72cc5;
        FUN_0056ce50();
      }
      ppcStack_a8 = (code **)&LAB_00605b60;
      ppiStack_ac = (int **)&DAT_01ead2e4;
      ppiStack_b0 = (int **)0xb72cd4;
      FUN_005789c0();
      ppcStack_a8 = (code **)0xb72cdc;
      ppcStack_a8 = (code **)FUN_00606020();
      ppiStack_ac = (int **)0xb72ce5;
      param_2 = (int *)FUN_008aa140();
      if (*param_2 == 0) {
        ppcStack_a8 = (code **)0xb72cf6;
        ppcStack_a8 = (code **)FUN_00ac1050();
        ppiStack_ac = (int **)auStack_2c;
        ppiStack_b0 = (int **)0xb72d03;
        piVar4 = (int *)FUN_008a9ba0();
        iVar3 = *piVar4;
        iVar1 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        *param_2 = iVar3;
        param_3 = (int *)param_2[1];
        param_2[1] = iVar1;
        if (param_3 != (int *)0x0) {
          LOCK();
          iVar3 = param_3[1] + -1;
          param_3[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb72d34;
            (**(code **)*param_3)();
            LOCK();
            iVar3 = param_3[2] + -1;
            param_3[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              ppcStack_a8 = (code **)0xb72d45;
              (**(code **)(*param_3 + 4))();
            }
          }
        }
        param_3 = piStack_28;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_28[1] + -1;
          piStack_28[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppcStack_a8 = (code **)0xb72d5f;
            (**(code **)*piStack_28)();
            LOCK();
            iVar3 = param_3[2] + -1;
            param_3[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              ppcStack_a8 = (code **)0xb72d70;
              (**(code **)(*param_3 + 4))();
            }
          }
        }
      }
      if (*param_2 != 0) {
        param_2 = (int *)(*param_2 + 0xbc);
        pcStack_4c = FUN_00b72fb0;
        iStack_48 = 0;
        ppcStack_a8 = (code **)0xb72d9e;
        piStack_44 = param_1;
        FUN_006eccd0();
        ppcStack_a8 = (code **)DAT_02110da8;
        uStack_8 = 0x1b;
        ppiStack_ac = (int **)0xb72db0;
        uVar6 = FUN_01675290();
        uStack_34 = (double)CONCAT44(uVar6,(undefined4)uStack_34);
        ppiStack_ac = (int **)0x28;
        uStack_8 = 0x1c;
        ppiStack_b0 = (int **)0xb72dc3;
        piStack_1c = (int *)FUN_01674e20();
        if (piStack_1c == (int *)0x0) {
          piStack_1c = (int *)0x0;
        }
        else {
          *piStack_1c = 0;
          piStack_1c[1] = 1;
          piStack_1c[2] = (int)FUN_00b6cfe0;
          piStack_1c[3] = (int)_guard_check_icall;
          piStack_1c[4] = 0;
          piStack_1c[5] = (int)param_2;
          piStack_1c[6] = (int)pcStack_4c;
          piStack_1c[7] = iStack_48;
          piStack_1c[8] = (int)piStack_44;
          piStack_1c[9] = uStack_40;
        }
        ppiStack_ac = (int **)0xb72e0d;
        ppcStack_a8 = (code **)piStack_1c;
        FUN_016797d0();
        param_3 = piStack_1c;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          piStack_1c[1] = piStack_1c[1] + 1;
          UNLOCK();
        }
        piStack_24 = (int *)((uint)piStack_14 | 0x40);
        uStack_8 = 0x1d;
        ppiStack_ac = (int **)0xb72e3c;
        ppcStack_a8 = (code **)uVar6;
        piStack_14 = piStack_24;
        FUN_01675290();
        piStack_24 = (int *)((uint)piStack_14 & 0xffffffbf | 0x20);
        ppcStack_a8 = (code **)&param_3;
        uStack_8 = 0x1e;
        ppiStack_ac = (int **)0xb72e64;
        piStack_14 = piStack_24;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_a8 = (code **)0xb72e73;
          FUN_01679490();
          ppcStack_a8 = (code **)&param_3;
          ppiStack_ac = (int **)0xb72e82;
          FUN_016791c0();
        }
        uStack_8 = 0xffffffff;
        if (param_3 != (int *)0x0) {
          piVar4 = param_3 + 1;
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            ppcStack_a8 = (code **)param_3;
            ppiStack_ac = (int **)0xb72ea7;
            FUN_01674ea0();
          }
        }
      }
      ppiStack_ac = (int **)0xb72eb0;
      ppcStack_a8 = (code **)param_1;
      iVar3 = FUN_008f7870();
      if (iVar3 != 0) {
        param_3 = (int *)(iVar3 + 0xa8);
        pcStack_4c = (code *)&LAB_00b704f0;
        iStack_48 = 0;
        ppcStack_a8 = (code **)DAT_02110da8;
        uStack_8 = 0x1f;
        ppiStack_ac = (int **)0xb72ee6;
        piStack_44 = param_1;
        uVar6 = FUN_01675290();
        uStack_34 = (double)CONCAT44(uVar6,(undefined4)uStack_34);
        ppiStack_ac = (int **)0x28;
        uStack_8._0_1_ = 0x20;
        ppiStack_b0 = (int **)0xb72ef6;
        param_2 = (int *)FUN_01674e20();
        if (param_2 == (int *)0x0) {
          param_2 = (int *)0x0;
        }
        else {
          *param_2 = 0;
          param_2[1] = 1;
          param_2[2] = (int)FUN_0067baa0;
          param_2[3] = (int)_guard_check_icall;
          param_2[4] = 0;
          param_2[5] = (int)param_3;
          param_2[6] = (int)pcStack_4c;
          param_2[7] = iStack_48;
          param_2[8] = (int)piStack_44;
          param_2[9] = uStack_40;
        }
        ppiStack_ac = (int **)0xb72f40;
        ppcStack_a8 = (code **)param_2;
        FUN_016797d0();
        piStack_18 = param_2;
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[1] = param_2[1] + 1;
          UNLOCK();
        }
        piStack_24 = (int *)((uint)piStack_14 | 0x80);
        uStack_8._0_1_ = 0x21;
        ppiStack_ac = (int **)0xb72f6b;
        ppcStack_a8 = (code **)uVar6;
        FUN_01675290();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
        ppcStack_a8 = (code **)&piStack_18;
        ppiStack_ac = (int **)0xb72f81;
        FUN_00614020();
        ppcStack_a8 = (code **)0xb72f89;
        FUN_0056e750();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24759 ; VA 0x00b72fb0 ; FUN_00b72fb0 */

void __thiscall FUN_00b72fb0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  undefined auStack_138 [208];
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [4];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [4];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int aiStack_20 [2];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6c3e;
  pvStack_10 = ExceptionList;
  if (((*param_3 != 0) && (*(int *)(param_1 + 0x58) != 0)) &&
     (*(int *)(*(int *)(param_1 + 0x58) + 0x10) != 2)) {
    ExceptionList = &pvStack_10;
    FUN_00562c90(aiStack_20,param_2);
    uStack_8 = 0;
    if (aiStack_20[0] != 0) {
      cVar2 = FUN_00b70c80(piVar1);
      if (cVar2 != '\0') {
        auStack_38[0] = 0;
        uStack_34 = FUN_00588320(0xb);
        uStack_30 = 0;
        uStack_2c = 0x3f800000;
        uStack_28 = 0;
        uStack_24 = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        uStack_58 = 0;
        uStack_54 = 0xf;
        auStack_68[0] = 0;
        FUN_005542c0("placeId",7);
        FUN_00580040(&param_3,auStack_68);
        FUN_005507b0();
        uStack_18 = CONCAT44(uStack_18._4_4_,(int)uStack_18);
        if ((param_3 != (int *)0x0) &&
           (uStack_18 = CONCAT44(uStack_18._4_4_,(int)uStack_18),
           *(char *)(param_3[8] + 0x21) != '\0')) {
          uStack_18 = FUN_00563790();
          puVar5 = &uStack_18;
          FUN_005c4c00(&DAT_01d6746c);
          FUN_00632bc0(puVar5);
          iVar3 = FUN_008f7870(param_1);
          if (iVar3 != 0) {
            piVar1 = *(int **)(iVar3 + 0x43c);
            uStack_18._0_4_ = *piVar1 - (int)piVar1;
            uStack_18._4_4_ = piVar1[1] - (int)piVar1;
            puVar5 = &uStack_18;
            FUN_005c4c00(&DAT_01d67454);
            FUN_00632bc0(puVar5);
          }
          auStack_50[0] = 0;
          uStack_4c = FUN_00588320(0xb);
          uStack_48 = 0;
          uStack_44 = 0x3f800000;
          uStack_40 = 0;
          uStack_3c = 0;
          uStack_8._0_1_ = 2;
          FUN_0054ef60(&DAT_01d672a4);
          FUN_00b6e320(aiStack_20,auStack_50);
          uVar4 = FUN_00ac3970(&uStack_18,auStack_38);
          uStack_8._0_1_ = 3;
          uVar4 = FUN_00b67b80(uVar4);
          uStack_8._0_1_ = 4;
          FUN_005c4c00(&DAT_01d67514);
          FUN_00947a40(uVar4);
          FUN_0056e5b0();
          uStack_8._0_1_ = 2;
          FUN_00550b30();
          uVar4 = FUN_00ac3970(&uStack_18,auStack_50);
          uStack_8._0_1_ = 5;
          FUN_00b67b80(uVar4);
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          FUN_00550b30();
          (**(code **)(**(int **)(param_1 + 0x58) + 0x10))
                    (*(undefined4 *)(aiStack_20[0] + 0x28),&DAT_01d672a4,auStack_138);
          FUN_0056e5b0();
          FUN_0056d080();
        }
        FUN_0056d080();
      }
    }
    FUN_00550b30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24760 ; VA 0x00b73230 ; FUN_00b73230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b73230(int param_1,double *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  float fVar4;
  double dVar5;
  
  if (*(int **)(param_1 + 0x58) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x58) + 0x14))(param_2);
  }
  dVar5 = *param_2;
  if ((double)DAT_01d67150 < dVar5 - *(double *)(param_1 + 0xd0)) {
    if ((*(int *)(param_1 + 0xb0) != 0) &&
       (FUN_008749d0(param_1 + 0xa8,0), *(int *)(param_1 + 0xb0) != 0)) {
      FUN_005d31b0(*(int *)(param_1 + 0xbc) + *(int *)(param_1 + 0xac) * 4,0);
      puVar3 = *(undefined4 **)(param_1 + 0xbc);
      puVar1 = puVar3 + *(int *)(param_1 + 0xac);
      for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
        *puVar3 = 0;
      }
    }
    if ((DAT_01d6757c != '\0') &&
       (puVar1 = (undefined4 *)(param_1 + 0xc0),
       *(int *)(param_1 + 0xc0) != *(int *)(param_1 + 0xc4))) {
      FUN_00874d70(puVar1,0);
      FUN_00559500(*puVar1,*(undefined4 *)(param_1 + 0xc4),puVar1);
      *(undefined4 *)(param_1 + 0xc4) = *puVar1;
    }
    *(undefined4 *)(param_1 + 0xd0) = *(undefined4 *)param_2;
    *(undefined4 *)(param_1 + 0xd4) = *(undefined4 *)((int)param_2 + 4);
    dVar5 = *param_2;
  }
  if (*(double *)(param_1 + 0xe0) <= dVar5 && dVar5 != *(double *)(param_1 + 0xe0)) {
    *(double *)(param_1 + 0xe0) = (double)DAT_01d67158 + *param_2;
    *(longlong *)(param_1 + 0xd8) = (longlong)DAT_01d67160 * (longlong)DAT_01d67158 * 0x400;
    dVar5 = *param_2;
  }
  dVar5 = dVar5 - *(double *)(param_1 + 0xf0);
  if ((double)DAT_01d67170 < dVar5) {
    iVar2 = FUN_0097fff0(param_1);
    fVar4 = ((float)dVar5 * (float)(iVar2 * DAT_01d67178 + _DAT_01d67180)) / DAT_018c0ff0 +
            *(float *)(param_1 + 0xec);
    *(float *)(param_1 + 0xec) = fVar4;
    if ((DAT_01d675b4 != '\0') && ((float)DAT_01d67188 < fVar4)) {
      *(float *)(param_1 + 0xec) = (float)DAT_01d67188;
    }
    *(undefined4 *)(param_1 + 0xf0) = *(undefined4 *)param_2;
    *(undefined4 *)(param_1 + 0xf4) = *(undefined4 *)((int)param_2 + 4);
  }
  return;
}



/* FUNCTION 24761 ; VA 0x00b73400 ; FUN_00b73400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b73400(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6c66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef09f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef09f4);
    if (DAT_01ef09f4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("AnalyticsEconomyAction");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef0990 =
           RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsEconomyAction>::vftable;
      FUN_009caf20(&DAT_01d675cc,3);
      FUN_016f3654(&LAB_0188f8a0);
      FUN_016f37bf(&DAT_01ef09f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef0990;
}



/* FUNCTION 24762 ; VA 0x00b734b0 ; FUN_00b734b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b734b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6c86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0924) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef0924);
    if (DAT_01ef0924 == -1) {
      uStack_8 = 0;
      FUN_009ca470("AnalyticsLogLevel");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef08c0 =
           RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsLogLevel>::vftable;
      FUN_009caf20(&DAT_01d6760c,6);
      FUN_016f3654(&LAB_0188f8c0);
      FUN_016f37bf(&DAT_01ef0924);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef08c0;
}



/* FUNCTION 24763 ; VA 0x00b73560 ; FUN_00b73560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b73560(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6ca6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef098c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef098c);
    if (DAT_01ef098c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AnalyticsProgressionStatus");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef0928 =
           RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsProgressionStatus>::
           vftable;
      FUN_009caf20(&DAT_01d675e4,5);
      FUN_016f3654(&LAB_0188f8e0);
      FUN_016f37bf(&DAT_01ef098c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef0928;
}



/* FUNCTION 24764 ; VA 0x00b73610 ; FUN_00b73610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b73610(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0a24) {
    FUN_016f3809(&DAT_01ef0a24);
    if (DAT_01ef0a24 == -1) {
      _DAT_01ef0a18 = FUN_005c65e0;
      _DAT_01ef0a1c = FUN_005c65e0;
      _DAT_01ef0a20 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef0a24);
    }
  }
  return &DAT_01ef0a18;
}



/* FUNCTION 24765 ; VA 0x00b73680 ; FUN_00b73680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b73680(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0a04) {
    FUN_016f3809(&DAT_01ef0a04);
    if (DAT_01ef0a04 == -1) {
      _DAT_01ef09f8 = FUN_005c65e0;
      _DAT_01ef09fc = FUN_005c65e0;
      _DAT_01ef0a00 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef0a04);
    }
  }
  return &DAT_01ef09f8;
}



/* FUNCTION 24766 ; VA 0x00b736f0 ; FUN_00b736f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b736f0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0a14) {
    FUN_016f3809(&DAT_01ef0a14);
    if (DAT_01ef0a14 == -1) {
      _DAT_01ef0a08 = FUN_005c65e0;
      _DAT_01ef0a0c = FUN_005c65e0;
      _DAT_01ef0a10 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef0a14);
    }
  }
  return &DAT_01ef0a08;
}



/* FUNCTION 24767 ; VA 0x00b73760 ; FUN_00b73760 */

undefined4 __thiscall FUN_00b73760(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if (DAT_01d67584 == '\0') {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_0086f2f0(3,"%s is not Enabled yet.",param_2);
    return 0;
  }
  if (*(char *)(param_1 + 0xe8) == '\0') {
    FUN_0086f2f0(3,"AnalyticsService can only be executed by game server.");
    return 0;
  }
  if ((DAT_01d6758c != '\0') &&
     ((*(int *)(param_1 + 0x58) == 0 || (*(int *)(*(int *)(param_1 + 0x58) + 0x10) == 2)))) {
    puVar1 = &DAT_01d67594;
    if (0xf < DAT_01d675a8) {
      puVar1 = DAT_01d67594;
    }
    FUN_0086f2f0(3,"AnalyticsService: This game isn\'t enrolled %s.",puVar1);
    return 0;
  }
  if (0.0 <= *(float *)(param_1 + 0xec)) {
    *(float *)(param_1 + 0xec) = *(float *)(param_1 + 0xec) - DAT_018ce2f8;
    return 1;
  }
  FUN_0086f2f0(3,"AnalyticsService: You have sent too many events.");
  return 0;
}



/* FUNCTION 24768 ; VA 0x00b73830 ; FUN_00b73830 */

undefined4 FUN_00b73830(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  float10 fVar4;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6cb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  fVar4 = (float10)FUN_00a36320(*(undefined8 *)(param_1 + 8),(double)DAT_01d67138,0x3f800000,
                                0x3f800000);
  uStack_18 = (double)fVar4;
  if (DAT_018c0d60 <= uStack_18) {
    FUN_00587490(&uStack_18);
    uStack_8 = 0;
    if ((int)uStack_18 != 0) {
      FUN_00b73230(param_1);
    }
    piVar3 = uStack_18._4_4_;
    if (uStack_18._4_4_ != (int *)0x0) {
      LOCK();
      iVar2 = uStack_18._4_4_[1] + -1;
      uStack_18._4_4_[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*uStack_18._4_4_)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 24769 ; VA 0x00b73900 ; FUN_00b73900 */

undefined * FUN_00b73900(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6cdc;
  pvStack_10 = ExceptionList;
  if (DAT_01ef0d58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0f68) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef0f68);
      if (DAT_01ef0f68 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00ae2430();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BaseScript",0,uStack_20,0,0,0x1b,0,&DAT_01ef0a34);
        FUN_016f3654(&LAB_0188fb10);
        FUN_016f37bf(&DAT_01ef0f68);
      }
    }
    DAT_01ef0d58 = &DAT_01ef0d60;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef0d58;
}



/* FUNCTION 24770 ; VA 0x00b739e0 ; FUN_00b739e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b739e0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6d10;
  pvStack_10 = ExceptionList;
  if (DAT_01ef0b3c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0d50) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef0d50);
      if (DAT_01ef0d50 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b73ae0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"LocalScript",0,uStack_20,0,0,0x1b,0,&DAT_01ef0a34);
        _DAT_01ef0d48 = RBX::Creator<class_RBX::LocalScript>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef0b40,&DAT_01ef0d48);
        FUN_016f3654(FUN_0188fb20);
        FUN_016f37bf(&DAT_01ef0d50);
      }
    }
    DAT_01ef0b3c = &DAT_01ef0b40;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef0b3c;
}



/* FUNCTION 24771 ; VA 0x00b73ae0 ; FUN_00b73ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b73ae0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6d40;
  pvStack_10 = ExceptionList;
  if (DAT_01ef0f70 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1188) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef1188);
      if (DAT_01ef1188 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b73900();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Script",0,uStack_20,0,0,0x1b,0,&DAT_01ef0a34);
        _DAT_01ef1180 = RBX::Creator<class_RBX::Script>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef0f78,&DAT_01ef1180);
        FUN_016f3654(FUN_0188fb80);
        FUN_016f37bf(&DAT_01ef1188);
      }
    }
    DAT_01ef0f70 = &DAT_01ef0f78;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef0f70;
}



/* FUNCTION 24772 ; VA 0x00b73be0 ; FUN_00b73be0 */

int __thiscall FUN_00b73be0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6d50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::LocalScript*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24773 ; VA 0x00b73cb2 ; Catch_All@00b73cb2 */

void Catch_All_00b73cb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24774 ; VA 0x00b73cd0 ; FUN_00b73cd0 */

int __thiscall FUN_00b73cd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6d60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RuntimeScriptService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24775 ; VA 0x00b73da2 ; Catch_All@00b73da2 */

void Catch_All_00b73da2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24776 ; VA 0x00b73dc0 ; FUN_00b73dc0 */

int __thiscall FUN_00b73dc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6d70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Script*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24777 ; VA 0x00b73e92 ; Catch_All@00b73e92 */

void Catch_All_00b73e92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24778 ; VA 0x00b73ec0 ; FUN_00b73ec0 */

undefined4 * FUN_00b73ec0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6dcb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b739e0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x104);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00b74510();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::LocalScript,class_RBX::Script>::vftable;
    uVar4 = FUN_00b739e0();
    puVar3[3] = uVar4;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::LocalScript::vftable;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_00551260("LocalScript");
    uStack_8._0_1_ = 5;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 4;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b73be0(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 9;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24779 ; VA 0x00b74010 ; FUN_00b74010 */

undefined4 * FUN_00b74010(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6e36;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0093f010();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    *(undefined *)(puVar3 + 0x15) = 1;
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::RuntimeScriptService,class_RBX::ServiceInstance>::vftable;
    uVar4 = FUN_0093f010();
    puVar3[3] = uVar4;
    *puVar3 = RBX::RuntimeScriptService::vftable;
    puVar3[0x16] = 0;
    uStack_8._0_1_ = 5;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    uVar4 = FUN_00601dc0();
    puVar3[0x17] = uVar4;
    uStack_8._0_1_ = 6;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    uVar4 = FUN_00601dc0();
    puVar3[0x19] = uVar4;
    *(undefined *)(puVar3 + 0x1b) = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b73cd0(puVar3,param_1);
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24780 ; VA 0x00b74140 ; FUN_00b74140 */

int FUN_00b74140(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6e48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ef1190,&LAB_00b73eb0);
  uVar2 = FUN_00b74390();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_0093f1f0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00b74010(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ef1190,&LAB_00b73eb0);
      uVar2 = FUN_00b74390();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 24781 ; VA 0x00b742d0 ; FUN_00b742d0 */

undefined4 * FUN_00b742d0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6e93;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b73ae0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x104);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b74510();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b73dc0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24782 ; VA 0x00b74390 ; FUN_00b74390 */

undefined4 FUN_00b74390(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6eac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef119c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef119c);
    if (DAT_01ef119c == -1) {
      uStack_8 = 0;
      DAT_01ef1198 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ef119c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1198;
}



/* FUNCTION 24783 ; VA 0x00b74410 ; FUN_00b74410 */

undefined4 * __fastcall FUN_00b74410(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6f02;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ae3ac0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::BaseScript,class_RBX::LuaSourceContainer>::vftable;
  uVar1 = FUN_00b73900();
  param_1[3] = uVar1;
  *param_1 = RBX::BaseScript::vftable;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  *(undefined2 *)(param_1 + 0x34) = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_00551260("BaseScript");
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24784 ; VA 0x00b74510 ; FUN_00b74510 */

undefined4 * __fastcall FUN_00b74510(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6f9c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ae3ac0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::BaseScript,class_RBX::LuaSourceContainer>::vftable;
  uVar3 = FUN_00b73900();
  param_1[3] = uVar3;
  *param_1 = RBX::BaseScript::vftable;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  *(undefined2 *)(param_1 + 0x34) = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  FUN_00551260("BaseScript");
  uStack_8._0_1_ = 5;
  FUN_008a6520(&uStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = uStack_34;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_34 - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_8 = 6;
  *param_1 = RBX::DescribedCreatable<class_RBX::Script,class_RBX::BaseScript>::vftable;
  uVar3 = FUN_00b73ae0();
  param_1[3] = uVar3;
  uStack_8 = 7;
  *param_1 = RBX::Script::vftable;
  puStack_18 = param_1 + 0x38;
  FUN_008866d0();
  uStack_8._0_1_ = 8;
  FUN_00a357a0(param_1 + 0x38,auStack_1c);
  FUN_0056e380();
  FUN_0056e380();
  uStack_8._0_1_ = 9;
  FUN_008866d0();
  puVar2 = param_1 + 0x3b;
  param_1[0x3f] = 0;
  param_1[0x40] = 0xf;
  *(undefined *)puVar2 = 0;
  uStack_8._0_1_ = 0xb;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  FUN_00551260("Script");
  uStack_8._0_1_ = 0xc;
  FUN_008a6520(&uStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = uStack_34;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_34 - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  if (DAT_01d67698 == '\0') {
    puVar4 = (undefined4 *)FUN_00a33fa0();
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_01531190(&uStack_34,puVar4,*puVar1);
  }
  else {
    puVar4 = (undefined4 *)FUN_00a33fa0();
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_01531190(&uStack_34,puVar4,*puVar1);
  }
  if (puVar2 != &uStack_34) {
    FUN_005507b0();
    *puVar2 = uStack_34;
    param_1[0x3c] = uStack_30;
    param_1[0x3d] = uStack_2c;
    param_1[0x3e] = uStack_28;
    *(ulonglong *)(param_1 + 0x3f) = CONCAT44(uStack_20,uStack_24);
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = uStack_34;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_34 - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24785 ; VA 0x00b747f0 ; FUN_00b747f0 */

void __fastcall FUN_00b747f0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::LocalScript>::vftable;
  uVar1 = FUN_00b739e0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24786 ; VA 0x00b74830 ; FUN_00b74830 */

void __fastcall FUN_00b74830(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Script>::vftable;
  uVar1 = FUN_00b73ae0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24787 ; VA 0x00b74870 ; thunk_FUN_00b748e0 */

void __fastcall thunk_FUN_00b748e0(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Script::vftable;
  uVar2 = param_1[0x40];
  if (0xf < uVar2) {
    iVar3 = param_1[0x3b];
    uVar7 = uVar2 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  param_1[0x3f] = 0;
  param_1[0x40] = 0xf;
  *(undefined *)(param_1 + 0x3b) = 0;
  FUN_0056e380();
  FUN_0056e380();
  piVar1 = param_1 + 0x38;
  uStack_8 = 0;
  LOCK();
  iVar3 = *(int *)(*piVar1 + 8) + -1;
  *(int *)(*piVar1 + 8) = iVar3;
  UNLOCK();
  if (iVar3 == 0) {
    FUN_005f1f00();
    uVar4 = DAT_01ea94d0;
    EnterCriticalSection(DAT_01ea94d0);
    cVar5 = FUN_0094b920(piVar1);
    if (cVar5 != '\0') {
      FUN_0094e520(*piVar1);
    }
    LeaveCriticalSection(uVar4);
  }
  FUN_00b74880();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24788 ; VA 0x00b74880 ; FUN_00b74880 */

void __fastcall FUN_00b74880(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = RBX::BaseScript::vftable;
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = (int *)param_1[0x35];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piVar2,8);
    }
  }
  FUN_009ec770();
  return;
}



/* FUNCTION 24789 ; VA 0x00b748e0 ; FUN_00b748e0 */

void __fastcall FUN_00b748e0(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Script::vftable;
  uVar2 = param_1[0x40];
  if (0xf < uVar2) {
    iVar3 = param_1[0x3b];
    uVar7 = uVar2 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  param_1[0x3f] = 0;
  param_1[0x40] = 0xf;
  *(undefined *)(param_1 + 0x3b) = 0;
  FUN_0056e380();
  FUN_0056e380();
  piVar1 = param_1 + 0x38;
  uStack_8 = 0;
  LOCK();
  iVar3 = *(int *)(*piVar1 + 8) + -1;
  *(int *)(*piVar1 + 8) = iVar3;
  UNLOCK();
  if (iVar3 == 0) {
    FUN_005f1f00();
    uVar4 = DAT_01ea94d0;
    EnterCriticalSection(DAT_01ea94d0);
    cVar5 = FUN_0094b920(piVar1);
    if (cVar5 != '\0') {
      FUN_0094e520(*piVar1);
    }
    LeaveCriticalSection(uVar4);
  }
  FUN_00b74880();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24790 ; VA 0x00b749e0 ; FUN_00b749e0 */

undefined4 __thiscall FUN_00b749e0(undefined4 param_1,byte param_2)

{
  FUN_00b748e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x104);
  }
  return param_1;
}



/* FUNCTION 24791 ; VA 0x00b74a10 ; FUN_00b74a10 */

undefined4 * __thiscall FUN_00b74a10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::LocalScript::vftable;
  FUN_00b748e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x104);
  }
  return param_1;
}



/* FUNCTION 24792 ; VA 0x00b74a40 ; FUN_00b74a40 */

int __thiscall FUN_00b74a40(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 100);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00949f40(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 100) + 4) = iVar3;
  **(int **)(param_1 + 100) = iVar3;
  *(int *)(*(int *)(param_1 + 100) + 8) = iVar3;
  *(undefined4 *)(param_1 + 0x68) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 100),0x18);
  iVar3 = *(int *)(param_1 + 0x5c);
  uStack_8 = 1;
  FUN_00949f40(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 0x5c) + 4) = iVar3;
  **(int **)(param_1 + 0x5c) = iVar3;
  *(int *)(*(int *)(param_1 + 0x5c) + 8) = iVar3;
  *(undefined4 *)(param_1 + 0x60) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x5c),0x18);
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x58);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24793 ; VA 0x00b74b30 ; FUN_00b74b30 */

undefined4 __thiscall FUN_00b74b30(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_01531190(param_2,param_3,*puVar1,param_1);
  return param_2;
}



/* FUNCTION 24794 ; VA 0x00b74b60 ; FUN_00b74b60 */

undefined4 __fastcall FUN_00b74b60(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (*(char *)(param_1 + 0xd0) == '\0') {
    iVar5 = *(int *)(param_1 + 0x34);
    cVar1 = '\0';
    if (iVar5 != 0) {
      do {
        if (cVar1 != '\0') goto LAB_00b74bbb;
        puVar2 = (undefined4 *)
                 FUN_0170d75d(iVar5,0,&RBX::Instance::RTTI_Type_Descriptor,
                              &RBX::IScriptFilter::RTTI_Type_Descriptor,0);
        if (puVar2 != (undefined4 *)0x0) {
          cVar1 = (**(code **)*puVar2)(param_1);
        }
        iVar5 = *(int *)(iVar5 + 0x34);
      } while (iVar5 != 0);
      if (cVar1 != '\0') {
LAB_00b74bbb:
        iVar5 = *(int *)(param_1 + 0x34);
        if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
          param_1 = FUN_005c8ac0();
        }
        if ((param_1 != 0) &&
           (iVar5 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
           (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da))) {
          uVar4 = FUN_00b74140();
          return uVar4;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 24795 ; VA 0x00b74c20 ; FUN_00b74c20 */

undefined4 * FUN_00b74c20(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b73ec0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24796 ; VA 0x00b74c90 ; FUN_00b74c90 */

undefined4 * FUN_00b74c90(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b742d0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24797 ; VA 0x00b74d00 ; FUN_00b74d00 */

void FUN_00b74d00(void)

{
  FUN_008a4940(&DAT_01ef0a50);
  return;
}



/* FUNCTION 24798 ; VA 0x00b74d10 ; FUN_00b74d10 */

undefined4 * FUN_00b74d10(void)

{
  return &DAT_01ef0a44;
}



/* FUNCTION 24799 ; VA 0x00b74d20 ; FUN_00b74d20 */

void FUN_00b74d20(void)

{
  int iVar1;
  
  if (DAT_01ef0f6c == 0) {
    iVar1 = FUN_00b73900();
    DAT_01ef0f6c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24800 ; VA 0x00b74d40 ; thunk_FUN_0093f1f0 */

void thunk_FUN_0093f1f0(void)

{
  int iVar1;
  
  if (DAT_01ee2fa4 == 0) {
    iVar1 = FUN_0093f010();
    DAT_01ee2fa4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24801 ; VA 0x00b74d50 ; FUN_00b74d50 */

void FUN_00b74d50(void)

{
  int iVar1;
  
  if (DAT_01ef0d54 == 0) {
    iVar1 = FUN_00b739e0();
    DAT_01ef0d54 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24802 ; VA 0x00b74d70 ; FUN_00b74d70 */

void FUN_00b74d70(void)

{
  int iVar1;
  
  if (DAT_01ef118c == 0) {
    iVar1 = FUN_00b73ae0();
    DAT_01ef118c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24803 ; VA 0x00b74d90 ; FUN_00b74d90 */

int __fastcall FUN_00b74d90(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 + 0xe4;
  if (DAT_01d67698 == '\0') {
    iVar1 = *(int *)(param_1 + 0xe0);
  }
  return iVar1;
}



/* FUNCTION 24804 ; VA 0x00b74db0 ; FUN_00b74db0 */

int __fastcall FUN_00b74db0(int param_1)

{
  return param_1 + 0xe0;
}



/* FUNCTION 24805 ; VA 0x00b74dc0 ; FUN_00b74dc0 */

undefined4 __thiscall FUN_00b74dc0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0xac))();
  FUN_0054ef60(uVar1);
  return param_2;
}



/* FUNCTION 24806 ; VA 0x00b74de0 ; FUN_00b74de0 */

undefined * FUN_00b74de0(void)

{
  return &DAT_01d67678;
}



/* FUNCTION 24807 ; VA 0x00b74df0 ; FUN_00b74df0 */

int FUN_00b74df0(void)

{
  int iVar1;
  int iVar2;
  
  if (DAT_01d67698 == '\0') {
    iVar1 = FUN_00ae4430();
    iVar1 = *(int *)(iVar1 + 0x10);
  }
  else {
    iVar1 = FUN_00ae4430();
    iVar1 = *(int *)(iVar1 + 0x10);
  }
  if (iVar1 == 0) {
    iVar1 = FUN_00a33fa0();
    iVar1 = *(int *)(iVar1 + 0x10) / 100;
    iVar2 = 1;
    if (1 < iVar1) {
      iVar2 = iVar1;
    }
    iVar1 = FUN_008a2610();
    return iVar1 + iVar2;
  }
  iVar1 = FUN_008a2610();
  return iVar1;
}



/* FUNCTION 24808 ; VA 0x00b74e70 ; FUN_00b74e70 */

bool FUN_00b74e70(void)

{
  return DAT_01d67688 != 0;
}



/* FUNCTION 24809 ; VA 0x00b74e80 ; FUN_00b74e80 */

uint FUN_00b74e80(void)

{
  uint uVar1;
  
  if (DAT_01ef0a44 == DAT_01ef0a48) {
    return DAT_01ef0a44 & 0xffffff00;
  }
  uVar1 = (uint)DAT_01ef0a28;
  if (DAT_01ef0a2a != '\0') {
    uVar1 = 1;
  }
  return uVar1;
}



/* FUNCTION 24810 ; VA 0x00b74eb0 ; FUN_00b74eb0 */

undefined4 FUN_00b74eb0(undefined4 *param_1)

{
  int iVar1;
  
  if (param_1 == &DAT_01ef0a88) {
    iVar1 = FUN_00ae4430();
    if (*(int *)(iVar1 + 0x10) == 0) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 24811 ; VA 0x00b74ee0 ; FUN_00b74ee0 */

uint FUN_00b74ee0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b739e0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24812 ; VA 0x00b74f00 ; FUN_00b74f00 */

uint FUN_00b74f00(void)

{
  int iVar1;
  
  iVar1 = FUN_00b73ae0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24813 ; VA 0x00b74f20 ; FUN_00b74f20 */

uint FUN_00b74f20(void)

{
  int iVar1;
  
  iVar1 = FUN_00b739e0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24814 ; VA 0x00b74f40 ; FUN_00b74f40 */

uint FUN_00b74f40(void)

{
  int iVar1;
  
  iVar1 = FUN_00b73ae0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24815 ; VA 0x00b74f60 ; FUN_00b74f60 */

void FUN_00b74f60(undefined4 param_1)

{
  FUN_008a3ee0(param_1);
  FUN_00b75290();
  return;
}



/* FUNCTION 24816 ; VA 0x00b74f80 ; FUN_00b74f80 */

void __fastcall FUN_00b74f80(int param_1)

{
  *(undefined *)(param_1 + 0xd1) = 0;
  FUN_00b75290();
  FUN_008a4940(&DAT_01ef0a88);
  return;
}



/* FUNCTION 24817 ; VA 0x00b74fa0 ; FUN_00b74fa0 */

void __thiscall FUN_00b74fa0(int param_1,int param_2,undefined4 param_3)

{
  if ((param_2 != 0) && (*(int *)(param_1 + 200) != 0)) {
    *(undefined4 *)(param_1 + 200) = 0;
    FUN_009589b0(param_1);
  }
  FUN_00ae5a20(param_2,param_3);
  return;
}



/* FUNCTION 24818 ; VA 0x00b74fe0 ; FUN_00b74fe0 */

undefined * FUN_00b74fe0(undefined *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_20 [8];
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7086;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00762f90();
  if (iVar1 != 1) {
    *param_1 = 0;
    puStack_18 = param_1 + 4;
    FUN_008866d0();
    uStack_8 = 2;
    FUN_00a357a0(param_1 + 4,auStack_20);
    FUN_0056e380();
    FUN_0056e380();
    uStack_8 = 3;
    FUN_008866d0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (DAT_01d67698 != '\0') {
    uVar2 = FUN_00ae4370();
    FUN_00a34850(uVar2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar2 = FUN_00ae4370();
  FUN_00a35860(&iStack_14,uVar2);
  *param_1 = 1;
  *(int *)(param_1 + 4) = iStack_14;
  LOCK();
  *(int *)(iStack_14 + 8) = *(int *)(iStack_14 + 8) + 1;
  UNLOCK();
  uStack_8 = 1;
  FUN_008866d0();
  FUN_009465c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24819 ; VA 0x00b750f0 ; FUN_00b750f0 */

undefined * __thiscall FUN_00b750f0(int param_1,undefined *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_20 [8];
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f70c1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00ae4430();
  if (*(int *)(iVar2 + 0x10) == 0) {
    if (DAT_01d67698 != '\0') {
      FUN_00a34850(param_1 + 0xe4);
      ExceptionList = pvStack_10;
      return param_2;
    }
    *param_2 = 1;
    iVar2 = *(int *)(param_1 + 0xe0);
    *(int *)(param_2 + 4) = iVar2;
    LOCK();
    piVar1 = (int *)(iVar2 + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    uStack_8 = 0;
    FUN_008866d0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = FUN_00762f90();
  if (iVar2 != 1) {
    *param_2 = 0;
    puStack_18 = param_2 + 4;
    FUN_008866d0();
    uStack_8 = 3;
    FUN_00a357a0(param_2 + 4,auStack_20);
    FUN_0056e380();
    FUN_0056e380();
    uStack_8 = 4;
    FUN_008866d0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (DAT_01d67698 != '\0') {
    uVar3 = FUN_00ae4370();
    FUN_00a34850(uVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar3 = FUN_00ae4370();
  FUN_00a35860(&iStack_14,uVar3);
  *param_2 = 1;
  *(int *)(param_2 + 4) = iStack_14;
  LOCK();
  *(int *)(iStack_14 + 8) = *(int *)(iStack_14 + 8) + 1;
  UNLOCK();
  uStack_8 = 2;
  FUN_008866d0();
  FUN_009465c0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24820 ; VA 0x00b75270 ; FUN_00b75270 */

int __fastcall FUN_00b75270(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00ae4430();
  if (*(int *)(iVar1 + 0x10) == 0) {
    return param_1 + 0xec;
  }
  iVar1 = FUN_00ae6170();
  return iVar1;
}



/* FUNCTION 24821 ; VA 0x00b75290 ; FUN_00b75290 */

int __fastcall FUN_00b75290(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_3c [4];
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f70e0;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = FUN_00b74b60();
  piVar5 = (int *)0x0;
  piStack_30 = (int *)0x0;
  iStack_14 = 0;
  iStack_34 = 0;
  uStack_8 = 0;
  iVar3 = 0;
  if (DAT_01d644e8 != '\0') {
    piStack_18 = (int *)FUN_008a1920(auStack_3c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((*piStack_18 == 0) ||
       (iVar3 = *(int *)(*piStack_18 + 0xc), iVar1 = FUN_00e70750(),
       (uint)*(ushort *)(iVar1 + 0x1da) <
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8))) {
      piStack_20 = (int *)0x0;
      puVar2 = &uStack_24;
      piVar4 = (int *)&DAT_00000006;
      iStack_14 = 0;
    }
    else {
      iStack_14 = *piStack_18;
      piStack_28 = (int *)piStack_18[1];
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[1] = piStack_28[1] + 1;
        UNLOCK();
        piStack_28 = (int *)piStack_18[1];
      }
      piVar4 = (int *)&DAT_00000005;
      puVar2 = &uStack_2c;
    }
    piVar5 = (int *)puVar2[1];
    *puVar2 = 0;
    puVar2[1] = 0;
    if ((((uint)piVar4 & 2) != 0) &&
       (piStack_18 = (int *)((uint)piVar4 & 0xfffffffd), piVar4 = piStack_18,
       piStack_20 != (int *)0x0)) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar3 = piStack_20[2] + -1;
        piStack_20[2] = iVar3;
        UNLOCK();
        piVar4 = piStack_18;
        if (iVar3 == 0) {
          (**(code **)(*piStack_20 + 4))();
          piVar4 = piStack_18;
        }
      }
    }
    if ((((uint)piVar4 & 1) != 0) && (piStack_28 != (int *)0x0)) {
      LOCK();
      iVar3 = piStack_28[1] + -1;
      piStack_28[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar3 = piStack_28[2] + -1;
        piStack_28[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    iStack_34 = iStack_14;
    uStack_8 = uStack_8 & 0xffffff00;
    piStack_18 = piStack_38;
    iVar3 = iStack_14;
    piStack_30 = piVar5;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_38 + 1;
      iVar1 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar4 = piStack_18 + 2;
        iVar1 = *piVar4;
        iVar3 = *piVar4;
        *piVar4 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if ((*(int *)(param_1 + 200) != iStack_1c) ||
     ((DAT_01d644e8 != '\0' && (iStack_14 != *(int *)(param_1 + 0xcc))))) {
    if (*(int *)(param_1 + 200) != 0) {
      *(undefined4 *)(param_1 + 200) = 0;
      FUN_009589b0(param_1);
    }
    *(int *)(param_1 + 200) = iStack_1c;
    *(int *)(param_1 + 0xcc) = iStack_14;
    iVar3 = iStack_14;
    if (iStack_1c != 0) {
      iVar3 = FUN_0095c060(param_1);
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar4 = piVar5 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*piVar5)();
      LOCK();
      piVar4 = piVar5 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 24822 ; VA 0x00b75480 ; FUN_00b75480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b75480(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f70f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00577a40();
  _DAT_01ef0a38 = CONCAT44(param_2,param_1);
  _DAT_01ef0a40 = param_3;
  FUN_00b75980();
  FUN_00b75a40();
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24823 ; VA 0x00b75500 ; FUN_00b75500 */

void __thiscall FUN_00b75500(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xd0) != param_2) {
    *(char *)(param_1 + 0xd0) = param_2;
    FUN_00b75290();
    FUN_008a4940(&DAT_01ef0ac0);
  }
  return;
}



/* FUNCTION 24824 ; VA 0x00b75530 ; FUN_00b75530 */

void __thiscall FUN_00b75530(int param_1,uint param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  int aiStack_6c [5];
  uint uStack_58;
  undefined4 uStack_54;
  char cStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [16];
  undefined auStack_24 [8];
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7162;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00ae4190(param_1);
  uVar6 = param_2;
  puVar5 = (undefined4 *)FUN_00a33fa0();
  puVar1 = puVar5 + 4;
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  FUN_00886ff0(aiStack_6c,puVar5,*puVar1);
  uStack_8 = 0;
  if (cStack_50 == '\0') {
LAB_00b755c9:
    uVar6 = FUN_008866a0(uVar6);
    uStack_8 = 2;
    param_2 = 2;
  }
  else {
    FUN_008874a0(param_1,uStack_54,1);
    if (cStack_50 == '\0') goto LAB_00b755c9;
    uVar6 = FUN_00886c00(auStack_34,aiStack_6c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_2 = 1;
  }
  uStack_14 = param_2;
  FUN_008866a0(uVar6);
  uStack_8 = 3;
  if ((param_2 & 2) != 0) {
    param_2 = param_2 & 0xfffffffd;
    FUN_0056e380();
    FUN_0056e380();
  }
  uStack_8._0_1_ = 5;
  if ((param_2 & 1) != 0) {
    FUN_0056e380();
    FUN_0056e380();
  }
  if (DAT_01d67698 == '\0') {
    cVar4 = FUN_008868d0(auStack_24);
    if (cVar4 == '\0') goto LAB_00b75882;
    uVar7 = FUN_01675290(DAT_01ef0a34);
    uStack_8._0_1_ = 8;
    uStack_1c = uVar7;
    FUN_00a35860(&param_2,auStack_24);
    LOCK();
    *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
    UNLOCK();
    uStack_14 = *(uint *)(iStack_18 + 0xe0);
    *(uint *)(iStack_18 + 0xe0) = param_2;
    uStack_8._0_1_ = 9;
    LOCK();
    iVar8 = *(int *)(uStack_14 + 8) + -1;
    *(int *)(uStack_14 + 8) = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      FUN_005f1f00();
      uVar6 = DAT_01ea94d0;
      EnterCriticalSection(DAT_01ea94d0);
      cVar4 = FUN_0094b920(&uStack_14);
      if (cVar4 != '\0') {
        FUN_0094e520(uStack_14);
      }
      LeaveCriticalSection(uVar6);
    }
    uStack_8._0_1_ = 10;
    LOCK();
    piVar2 = (int *)(param_2 + 8);
    iVar8 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      FUN_005f1f00();
      uVar6 = DAT_01ea94d0;
      EnterCriticalSection(DAT_01ea94d0);
      cVar4 = FUN_0094b920(&param_2);
      if (cVar4 != '\0') {
        FUN_0094e520(param_2);
      }
      LeaveCriticalSection(uVar6);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    puVar5 = (undefined4 *)FUN_00a33fa0();
    puVar1 = puVar5 + 4;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_01531190(&uStack_4c,puVar5,*puVar1);
    iVar8 = iStack_18;
    if ((uint *)(iStack_18 + 0xec) != &uStack_4c) {
      FUN_005507b0();
      uVar3 = uStack_4c;
      uStack_4c = uStack_4c & 0xffffff00;
      *(uint *)(iVar8 + 0xec) = uVar3;
      *(undefined4 *)(iVar8 + 0xf0) = uStack_48;
      *(undefined4 *)(iVar8 + 0xf4) = uStack_44;
      *(undefined4 *)(iVar8 + 0xf8) = uStack_40;
      *(ulonglong *)(iVar8 + 0xfc) = CONCAT44(uStack_38,uStack_3c);
      uStack_3c = 0;
      uStack_38 = 0xf;
    }
    FUN_005507b0();
    FUN_00b75290();
    FUN_008a4940(&DAT_01ef0a50);
    uStack_8._0_1_ = 0xb;
  }
  else {
    cVar4 = FUN_008868d0(auStack_24);
    if (cVar4 == '\0') goto LAB_00b75882;
    uVar7 = FUN_01675290(DAT_01ef0a34);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    param_2 = uVar7;
    FUN_00886840(auStack_24);
    puVar5 = (undefined4 *)FUN_00a33fa0();
    puVar1 = puVar5 + 4;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_01531190(&uStack_4c,puVar5,*puVar1);
    if ((uint *)(param_1 + 0xec) != &uStack_4c) {
      FUN_005507b0();
      uVar3 = uStack_4c;
      uStack_4c = uStack_4c & 0xffffff00;
      *(uint *)(param_1 + 0xec) = uVar3;
      *(undefined4 *)(param_1 + 0xf0) = uStack_48;
      *(undefined4 *)(param_1 + 0xf4) = uStack_44;
      *(undefined4 *)(param_1 + 0xf8) = uStack_40;
      *(ulonglong *)(param_1 + 0xfc) = CONCAT44(uStack_38,uStack_3c);
      uStack_3c = 0;
      uStack_38 = 0xf;
    }
    FUN_005507b0();
    FUN_00b75290();
    FUN_008a4940(&DAT_01ef0a50);
    uStack_8._0_1_ = 7;
  }
  FUN_01675290(uVar7);
LAB_00b75882:
  FUN_0056e380();
  FUN_0056e380();
  if ((cStack_50 != '\0') && (0xf < uStack_58)) {
    uVar7 = uStack_58 + 1;
    iVar8 = aiStack_6c[0];
    if (0xfff < uVar7) {
      iVar8 = *(int *)(aiStack_6c[0] + -4);
      uVar7 = uStack_58 + 0x24;
      if (0x1f < (aiStack_6c[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24825 ; VA 0x00b758e0 ; FUN_00b758e0 */

/* WARNING: Removing unreachable block (ram,0x00b75940) */
/* WARNING: Removing unreachable block (ram,0x00b7594e) */
/* WARNING: Removing unreachable block (ram,0x00b75976) */
/* WARNING: Removing unreachable block (ram,0x00b7595e) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b758e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005507b0();
  _DAT_01d67660 = param_1;
  uRam01d67664 = param_2;
  uRam01d67668 = param_3;
  uRam01d6766c = param_4;
  _DAT_01d67670 = CONCAT44(param_6,param_5);
  FUN_00b75a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24826 ; VA 0x00b75980 ; FUN_00b75980 */

void FUN_00b75980(void)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  FUN_00559570(DAT_01ef0a44,DAT_01ef0a48,&DAT_01ef0a44);
  DAT_01ef0a48 = DAT_01ef0a44;
  if (DAT_01ef0a29 != '\0') {
    iVar2 = DAT_01ef0a38;
    iVar3 = DAT_01ef0a3c;
    iVar5 = DAT_01ef0a44;
    if (DAT_01d67658 != 0) {
      if (DAT_01ef0a4c == DAT_01ef0a44) {
        FUN_00559960(DAT_01ef0a44,&DAT_01d67648);
        iVar2 = DAT_01ef0a38;
        iVar3 = DAT_01ef0a3c;
        iVar5 = DAT_01ef0a48;
      }
      else {
        FUN_0054ef60(&DAT_01d67648);
        iVar5 = DAT_01ef0a48 + 0x18;
        iVar2 = DAT_01ef0a38;
        iVar3 = DAT_01ef0a3c;
        DAT_01ef0a48 = iVar5;
      }
    }
    for (; iVar4 = DAT_01ef0a3c, bVar1 = iVar2 != DAT_01ef0a3c, DAT_01ef0a3c = iVar3, bVar1;
        iVar2 = iVar2 + 0x18) {
      if (*(int *)(iVar2 + 0x10) != 0) {
        if (DAT_01ef0a4c == iVar5) {
          FUN_00559960(iVar5,iVar2);
          iVar5 = DAT_01ef0a48;
        }
        else {
          FUN_0054ef60(iVar2);
          DAT_01ef0a48 = DAT_01ef0a48 + 0x18;
          iVar5 = DAT_01ef0a48;
        }
      }
      iVar3 = DAT_01ef0a3c;
      DAT_01ef0a3c = iVar4;
    }
  }
  return;
}



/* FUNCTION 24827 ; VA 0x00b75a40 ; FUN_00b75a40 */

void FUN_00b75a40(void)

{
  int iVar1;
  undefined uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined uVar8;
  int iVar9;
  undefined auStack_c0 [8];
  int aiStack_b8 [5];
  uint uStack_a4;
  int iStack_a0;
  uint uStack_8c;
  int aiStack_88 [5];
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f71b1;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_00551260("StarterScript.lua");
  iVar1 = DAT_01ef0a48;
  uVar8 = 0;
  iVar9 = DAT_01ef0a44;
  do {
    if (iVar9 == iVar1) {
LAB_00b75d3c:
      DAT_01ef0a28 = uVar8;
      if (0xf < uStack_2c) {
        uVar7 = uStack_2c + 1;
        uVar6 = auStack_40[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_40[0] - 4);
          uVar7 = uStack_2c + 0x24;
          if (0x1f < (auStack_40[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uVar3 = FUN_0151a8d0(auStack_70,auStack_40);
    uStack_8 = 1;
    FUN_0054f050(uVar3);
    uStack_8 = 2;
    uVar3 = FUN_0151a8d0(auStack_58,iVar9);
    uStack_8 = 3;
    FUN_0054f050(uVar3);
    uStack_8 = 4;
    FUN_0054f050(aiStack_b8);
    uStack_8 = 5;
    uVar3 = FUN_01686150(auStack_28);
    FUN_0054f050(uVar3);
    uStack_8 = 4;
    uVar2 = uStack_8;
    uStack_8 = 4;
    if (7 < uStack_8c) {
      uVar6 = uStack_8c * 2 + 2;
      iVar5 = iStack_a0;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iStack_a0 + -4);
        uVar6 = uStack_8c * 2 + 0x25;
        if (0x1f < (iStack_a0 - iVar5) - 4U) goto LAB_00b75d83;
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    uStack_8 = 7;
    if (7 < uStack_a4) {
      uVar6 = uStack_a4 * 2 + 2;
      iVar5 = aiStack_b8[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_b8[0] + -4);
        uVar6 = uStack_a4 * 2 + 0x25;
        uVar2 = uStack_8;
        if (0x1f < (aiStack_b8[0] - iVar5) - 4U) goto LAB_00b75d83;
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    uStack_8 = 8;
    if (7 < uStack_44) {
      uVar6 = uStack_44 * 2 + 2;
      uVar7 = auStack_58[0];
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(auStack_58[0] - 4);
        uVar6 = uStack_44 * 2 + 0x25;
        uVar2 = uStack_8;
        if (0x1f < (auStack_58[0] - uVar7) - 4) goto LAB_00b75d83;
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    uStack_48 = 0;
    uStack_44 = 7;
    auStack_58[0] = auStack_58[0] & 0xffff0000;
    uStack_8 = 9;
    if (7 < uStack_14) {
      uVar6 = uStack_14 * 2 + 2;
      uVar7 = auStack_28[0];
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar6 = uStack_14 * 2 + 0x25;
        uVar2 = uStack_8;
        if (0x1f < (auStack_28[0] - uVar7) - 4) goto LAB_00b75d83;
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    uStack_18 = 0;
    uStack_14 = 7;
    auStack_28[0] = auStack_28[0] & 0xffff0000;
    uStack_8 = 10;
    if (7 < uStack_5c) {
      uVar6 = uStack_5c * 2 + 2;
      uVar7 = auStack_70[0];
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(auStack_70[0] - 4);
        uVar6 = uStack_5c * 2 + 0x25;
        uVar2 = uStack_8;
        if (0x1f < (auStack_70[0] - uVar7) - 4) goto LAB_00b75d83;
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    uStack_60 = 0;
    auStack_70[0] = auStack_70[0] & 0xffff0000;
    uStack_5c = 7;
    piVar4 = (int *)FUN_0168e1c0(auStack_c0,aiStack_88,0);
    if ((*piVar4 != 0) && (*piVar4 != 1)) {
      uVar8 = 1;
      if (7 < uStack_74) {
        uVar6 = uStack_74 * 2 + 2;
        iVar9 = aiStack_88[0];
        if (0xfff < uVar6) {
          iVar9 = *(int *)(aiStack_88[0] + -4);
          uVar6 = uStack_74 * 2 + 0x25;
          uVar2 = uStack_8;
          if (0x1f < (aiStack_88[0] - iVar9) - 4U) {
LAB_00b75d83:
            uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar6);
      }
      goto LAB_00b75d3c;
    }
    uStack_8 = 0;
    if (7 < uStack_74) {
      uVar6 = uStack_74 * 2 + 2;
      iVar5 = aiStack_88[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_88[0] + -4);
        uVar6 = uStack_74 * 2 + 0x25;
        uVar2 = uStack_8;
        if (0x1f < (aiStack_88[0] - iVar5) - 4U) goto LAB_00b75d83;
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    iVar9 = iVar9 + 0x18;
  } while( true );
}



/* FUNCTION 24828 ; VA 0x00b75d90 ; FUN_00b75d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b75d90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f71e0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef1218 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1430) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef1430);
      if (DAT_01ef1430 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CoreScriptSyncService",1,uStack_20,0,0,1,7,0);
        _DAT_01ef1428 = RBX::Creator<class_RBX::CoreScriptSyncService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef1220,&DAT_01ef1428);
        FUN_016f3654(FUN_0188fc90);
        FUN_016f37bf(&DAT_01ef1430);
      }
    }
    DAT_01ef1218 = &DAT_01ef1220;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1218;
}



/* FUNCTION 24829 ; VA 0x00b75e90 ; FUN_00b75e90 */

void FUN_00b75e90(void)

{
  int iVar1;
  
  if (DAT_01ef1434 == 0) {
    iVar1 = FUN_00b75d90();
    DAT_01ef1434 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24830 ; VA 0x00b75eb0 ; FUN_00b75eb0 */

int FUN_00b75eb0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f71f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00575bc0();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  *(undefined4 *)(iVar2 + 0x10) = 0;
  *(undefined4 *)(iVar2 + 0x14) = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x10) = *param_1;
  *(undefined4 *)(iVar2 + 0x14) = param_1[1];
  uStack_8 = 1;
  FUN_0054f050(param_1 + 2);
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 24831 ; VA 0x00b75f3b ; Catch_All@00b75f3b */

void Catch_All_00b75f3b(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24832 ; VA 0x00b75f50 ; FUN_00b75f50 */

int FUN_00b75f50(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7210;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575bc0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054f050(param_1);
  *(undefined4 *)(iVar1 + 0x28) = 0;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  *(undefined4 *)(iVar1 + 0x28) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(iVar1 + 0x2c) = *(undefined4 *)(param_1 + 0x1c);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 24833 ; VA 0x00b75fd4 ; Catch_All@00b75fd4 */

void Catch_All_00b75fd4(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24834 ; VA 0x00b75ff0 ; FUN_00b75ff0 */

void __thiscall
FUN_00b75ff0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0x5555553 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00b75eb0(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00b76048;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00b76048;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00b76048:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_00b760a1:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_00b760a1;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 24835 ; VA 0x00b76150 ; FUN_00b76150 */

void __thiscall
FUN_00b76150(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0x5555553 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00b75f50(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00b761a8;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00b761a8;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00b761a8:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_00b76201:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_00b76201;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 24836 ; VA 0x00b762b0 ; FUN_00b762b0 */

undefined4 * __thiscall
FUN_00b762b0(undefined4 *param_1,undefined4 *param_2,char param_3,int param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7220;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar7 = true;
  piVar2 = (int *)*param_1;
  piVar6 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar5 = (int *)piVar2[1];
    do {
      piVar6 = piVar5;
      if (param_3 == '\0') {
        bVar7 = *(uint *)(param_4 + 4) < (uint)piVar6[5];
      }
      else {
        bVar7 = *(uint *)(param_4 + 4) <= (uint)piVar6[5];
      }
      if (bVar7 == false) {
        piVar5 = (int *)piVar6[2];
      }
      else {
        piVar5 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
  }
  piVar5 = piVar6;
  if (bVar7 != false) {
    if (piVar6 == (int *)*piVar2) {
      bVar7 = true;
      goto LAB_00b7633a;
    }
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      piVar5 = (int *)*piVar6;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar5[2] + 0xd);
        piVar2 = (int *)piVar5[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar5 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar6[1] + 0xd);
        piVar2 = (int *)piVar6[1];
        piVar5 = piVar6;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar5 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar5 = piVar3;
        }
        if (*(char *)((int)piVar5 + 0xd) == '\0') {
          piVar5 = piVar3;
        }
      }
    }
    else {
      piVar5 = (int *)piVar6[2];
    }
  }
  if (*(uint *)(param_4 + 4) <= (uint)piVar5[5]) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00b7633a:
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00b75ff0(&param_3,bVar7,piVar6,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24837 ; VA 0x00b763f1 ; Catch_All@00b763f1 */

void Catch_All_00b763f1(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24838 ; VA 0x00b76400 ; FUN_00b76400 */

void __thiscall
FUN_00b76400(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  bool bVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7230;
  pvStack_10 = ExceptionList;
  cVar1 = (char)param_3;
  bVar8 = true;
  uStack_8 = 0;
  piVar6 = (int *)((int *)*param_1)[1];
  piVar7 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)piVar6 + 0xd) == '\0') {
    if (cVar1 == '\0') {
      iVar4 = FUN_01686710(piVar6 + 4);
      bVar8 = iVar4 < 0;
    }
    else {
      iVar4 = FUN_01686710(param_4);
      bVar8 = -1 < iVar4;
    }
    piVar7 = piVar6;
    if (bVar8 == false) {
      piVar6 = (int *)piVar6[2];
    }
    else {
      piVar6 = (int *)*piVar6;
    }
  }
  piVar6 = piVar7;
  if (bVar8 != false) {
    if (piVar7 == *(int **)*param_1) {
      bVar8 = true;
      goto LAB_00b7649b;
    }
    if (*(char *)((int)piVar7 + 0xd) == '\0') {
      piVar6 = (int *)*piVar7;
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar6[2] + 0xd);
        piVar2 = (int *)piVar6[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar6 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar7[1] + 0xd);
        piVar2 = (int *)piVar7[1];
        piVar6 = piVar7;
        while ((piVar3 = piVar2, cVar1 == '\0' && (param_3 = piVar3, piVar6 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar6 = piVar3;
        }
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          piVar6 = piVar3;
        }
      }
    }
    else {
      piVar6 = (int *)piVar7[2];
    }
  }
  iVar4 = FUN_01686710(param_4);
  if (-1 < iVar4) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00b7649b:
  puVar5 = (undefined4 *)FUN_00b76150(&param_3,bVar8,piVar7,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24839 ; VA 0x00b7655e ; Catch_All@00b7655e */

void Catch_All_00b7655e(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24840 ; VA 0x00b76570 ; FUN_00b76570 */

int __thiscall FUN_00b76570(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7240;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CoreScriptSyncService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24841 ; VA 0x00b76642 ; Catch_All@00b76642 */

void Catch_All_00b76642(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24842 ; VA 0x00b76660 ; FUN_00b76660 */

undefined4 * FUN_00b76660(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f72b1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b75d90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    *(undefined *)(puVar3 + 0x15) = 1;
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::CoreScriptSyncService,class_RBX::ServiceInstance>::
              vftable;
    uVar4 = FUN_00b75d90();
    puVar3[3] = uVar4;
    *puVar3 = RBX::CoreScriptSyncService::vftable;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
    uStack_8._0_1_ = 6;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    uVar4 = FUN_00575b10();
    puVar3[0x18] = uVar4;
    uStack_8._0_1_ = 7;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    uVar4 = FUN_00575b10();
    puVar3[0x1a] = uVar4;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b76570(puVar3,param_1);
  uStack_8 = 0xb;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24843 ; VA 0x00b76790 ; FUN_00b76790 */

int FUN_00b76790(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b9e640();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 24844 ; VA 0x00b767d0 ; FUN_00b767d0 */

undefined4 __thiscall FUN_00b767d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f72c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054f050(param_2);
  uStack_8 = 0;
  FUN_0054f050(param_3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24845 ; VA 0x00b76820 ; FUN_00b76820 */

void __fastcall FUN_00b76820(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::CoreScriptSyncService>::vftable;
  uVar1 = FUN_00b75d90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24846 ; VA 0x00b76860 ; FUN_00b76860 */

void __fastcall FUN_00b76860(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b76ca0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24847 ; VA 0x00b768b0 ; FUN_00b768b0 */

int __fastcall FUN_00b768b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  if (7 < *(uint *)(param_1 + 0x1c)) {
    iVar2 = *(int *)(param_1 + 8);
    iVar5 = *(uint *)(param_1 + 0x1c) * 2;
    uVar6 = iVar5 + 2;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = iVar5 + 0x25;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  iVar5 = 0;
  *(undefined4 *)(param_1 + 0x1c) = 7;
  *(undefined2 *)(param_1 + 8) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00b76911. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar5 = (**(code **)(*piVar3 + 4))();
      return iVar5;
    }
  }
  return iVar5;
}



/* FUNCTION 24848 ; VA 0x00b76920 ; FUN_00b76920 */

void __fastcall FUN_00b76920(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = (int *)param_1[7];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (7 < (uint)param_1[5]) {
    iVar2 = *param_1;
    iVar3 = param_1[5] * 2;
    uVar5 = iVar3 + 2;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = iVar3 + 0x25;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 7;
  *(undefined2 *)param_1 = 0;
  return;
}



/* FUNCTION 24849 ; VA 0x00b76990 ; FUN_00b76990 */

undefined4 * __thiscall FUN_00b76990(undefined4 *param_1,byte param_2)

{
  int iVar1;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::CoreScriptSyncService::vftable;
  iVar1 = param_1[0x1a];
  uStack_8 = 0;
  puStack_14 = param_1;
  FUN_00b76a60(*(undefined4 *)(iVar1 + 4));
  *(int *)(param_1[0x1a] + 4) = iVar1;
  *(int *)param_1[0x1a] = iVar1;
  *(int *)(param_1[0x1a] + 8) = iVar1;
  param_1[0x1b] = 0;
  FUN_01674ea0(param_1[0x1a],0x30);
  uStack_8 = 1;
  FUN_00b76ca0(&puStack_14,*(undefined4 *)param_1[0x18],(undefined4 *)param_1[0x18]);
  FUN_01674ea0(param_1[0x18],0x30);
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24850 ; VA 0x00b76a60 ; FUN_00b76a60 */

void FUN_00b76a60(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b76a60(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00b768b0();
    FUN_01674ea0(param_1,0x30);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 24851 ; VA 0x00b76ab0 ; FUN_00b76ab0 */

void FUN_00b76ab0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b76ab0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00b76920();
    FUN_01674ea0(param_1,0x30);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 24852 ; VA 0x00b76b00 ; FUN_00b76b00 */

void FUN_00b76b00(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7368;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_0060e0c0(auStack_18,param_1);
  uStack_8 = 0;
  FUN_0054f050(param_2);
  uStack_28 = *puVar3;
  uStack_24 = puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00b76400(auStack_20,0,&uStack_40,param_1);
  FUN_00b76920();
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[2] + -1;
    piStack_14[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_14 + 4))();
    }
  }
  puVar3 = (undefined4 *)FUN_0060e0c0(auStack_20,param_1);
  uStack_40 = *puVar3;
  uStack_3c = puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054f050(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00b762b0(auStack_18,0,&uStack_40,param_1);
  FUN_00b768b0();
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24853 ; VA 0x00b76c30 ; FUN_00b76c30 */

undefined4 * FUN_00b76c30(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b76660(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24854 ; VA 0x00b76ca0 ; FUN_00b76ca0 */

void __thiscall FUN_00b76ca0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00b76ab0(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar3 = FUN_00553830(param_3);
    FUN_00b76920();
    FUN_01674ea0(uVar3,0x30);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24855 ; VA 0x00b76d70 ; FUN_00b76d70 */

undefined4 __thiscall FUN_00b76d70(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_e8 [4];
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7393;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d1340(auStack_18,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_e8,uVar3);
  uStack_8._0_1_ = 1;
  uVar3 = FUN_009d5a20(param_3,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_e4 != 0) {
    (**(code **)(iStack_e4 + 8))(auStack_e0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
      ExceptionList = pvStack_10;
      return uVar3;
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 24856 ; VA 0x00b76e60 ; FUN_00b76e60 */

undefined * __thiscall FUN_00b76e60(int param_1,undefined *param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f73a8;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_3 + 4);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[2] = piVar6[2] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_3 + 4);
  }
  puVar1 = *(undefined4 **)(param_1 + 0x68);
  uStack_8 = 0;
  puVar3 = puVar1;
  puVar5 = (undefined4 *)puVar1[1];
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      puVar4 = puVar5;
      if ((int *)puVar4[5] < piVar6) {
        puVar5 = (undefined4 *)puVar4[2];
        puVar4 = puVar3;
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if ((puVar4 != puVar1) && ((int *)puVar4[5] <= piVar6)) goto LAB_00b76ecf;
  }
  puVar4 = puVar1;
LAB_00b76ecf:
  if (puVar4 == puVar1) {
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    if (piVar6 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    LOCK();
    iVar2 = piVar6[2] + -1;
    piVar6[2] = iVar2;
    UNLOCK();
  }
  else {
    FUN_0151a940(param_2,puVar4 + 6);
    if (piVar6 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    LOCK();
    iVar2 = piVar6[2] + -1;
    piVar6[2] = iVar2;
    UNLOCK();
  }
  if (iVar2 == 0) {
    (**(code **)(*piVar6 + 4))();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24857 ; VA 0x00b76f40 ; FUN_00b76f40 */

undefined4 * __thiscall FUN_00b76f40(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  
  puVar2 = *(undefined4 **)(param_1 + 0x60);
  puVar4 = puVar2;
  puVar5 = (undefined4 *)puVar2[1];
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      puVar4 = puVar5;
      iVar1 = FUN_01686710(param_3);
      if (iVar1 < 0) {
        puVar5 = (undefined4 *)puVar4[2];
        puVar4 = puVar2;
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
      }
      puVar2 = puVar4;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    puVar2 = *(undefined4 **)(param_1 + 0x60);
  }
  if (puVar4 != puVar2) {
    iVar1 = FUN_01686710(puVar4 + 4);
    puVar2 = *(undefined4 **)(param_1 + 0x60);
    if (-1 < iVar1) goto LAB_00b76f9e;
  }
  puVar4 = puVar2;
LAB_00b76f9e:
  if (puVar4 == puVar2) {
    *param_2 = 0;
    param_2[1] = 0;
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  iVar1 = puVar4[0xb];
  if (iVar1 != 0) {
    iVar3 = *(int *)(iVar1 + 4);
    piVar6 = (int *)(iVar1 + 4);
    if (iVar3 != 0) {
      while( true ) {
        LOCK();
        iVar1 = *piVar6;
        if (iVar3 == iVar1) {
          *piVar6 = iVar3 + 1;
          iVar1 = iVar3;
        }
        UNLOCK();
        if (iVar1 == iVar3) break;
        iVar3 = *piVar6;
        if (iVar3 == 0) {
          return param_2;
        }
      }
      *param_2 = puVar4[10];
      param_2[1] = puVar4[0xb];
    }
  }
  return param_2;
}



/* FUNCTION 24858 ; VA 0x00b77010 ; FUN_00b77010 */

uint FUN_00b77010(void)

{
  int iVar1;
  
  iVar1 = FUN_00b75d90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24859 ; VA 0x00b77030 ; FUN_00b77030 */

uint FUN_00b77030(void)

{
  int iVar1;
  
  iVar1 = FUN_00b75d90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24860 ; VA 0x00b77050 ; FUN_00b77050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b77050(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f73d0;
  pvStack_10 = ExceptionList;
  piVar12 = (int *)param_3[1];
  ExceptionList = &pvStack_10;
  if (piVar12 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar12[2] = piVar12[2] + 1;
    UNLOCK();
    piVar12 = (int *)param_3[1];
  }
  uStack_18 = *param_3;
  puVar7 = *(undefined4 **)(param_1 + 0x68);
  uStack_8 = 0;
  puVar5 = (undefined4 *)puVar7[1];
  puVar9 = puVar7;
  if (*(char *)((int)puVar5 + 0xd) == '\0') {
    do {
      if ((int *)puVar5[5] < piVar12) {
        puVar6 = (undefined4 *)puVar5[2];
      }
      else {
        puVar6 = (undefined4 *)*puVar5;
        puVar9 = puVar5;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    if ((puVar9 != puVar7) && ((int *)puVar9[5] <= piVar12)) goto LAB_00b770bf;
  }
  puVar9 = puVar7;
LAB_00b770bf:
  piStack_14 = piVar12;
  if (puVar9 == puVar7) {
    uVar8 = FUN_00888530();
    *param_2 = uVar8;
    param_2[1] = 0;
    if (piVar12 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    LOCK();
    iVar1 = piVar12[2] + -1;
    piVar12[2] = iVar1;
    UNLOCK();
  }
  else {
    puVar7 = (undefined4 *)FUN_0151a940(auStack_30,puVar9 + 6);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar8 = FUN_0088cb40();
    *param_2 = uVar8;
    pvVar4 = ThreadLocalStoragePointer;
    param_2[1] = 0;
    param_2[6] = 0;
    param_2[7] = 0;
    uVar8 = puVar7[1];
    uVar2 = puVar7[2];
    uVar3 = puVar7[3];
    param_2[2] = *puVar7;
    param_2[3] = uVar8;
    param_2[4] = uVar2;
    param_2[5] = uVar3;
    *(undefined8 *)(param_2 + 6) = *(undefined8 *)(puVar7 + 4);
    iVar1 = _tls_index;
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
    if ((*(int *)(*(int *)((int)pvVar4 + iVar1 * 4) + 0x34) < DAT_01ea8c48) &&
       (FUN_016f3809(&DAT_01ea8c48), DAT_01ea8c48 == -1)) {
      _DAT_01ea8c3c = FUN_005c65f0;
      _DAT_01ea8c40 = FUN_005c93a0;
      DAT_01ea8c44 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ea8c48);
    }
    param_2[1] = &DAT_01ea8c3c;
    if (0xf < uStack_1c) {
      uVar11 = uStack_1c + 1;
      uVar10 = auStack_30[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_30[0] - 4);
        uVar11 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    if (piVar12 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    LOCK();
    iVar1 = piVar12[2] + -1;
    piVar12[2] = iVar1;
    UNLOCK();
  }
  if (iVar1 == 0) {
    (**(code **)(*piVar12 + 4))();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24861 ; VA 0x00b77230 ; FUN_00b77230 */

uint __thiscall FUN_00b77230(int param_1,undefined4 *param_2)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  int *piStack_10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  uVar6 = FUN_0060e0c0(auStack_1c,param_2);
  puVar11 = *(undefined4 **)(param_1 + 0x68);
  piVar1 = (int *)(param_1 + 0x68);
  if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
    uVar6 = *(uint *)(uVar6 + 4);
    puVar9 = (undefined4 *)puVar11[1];
    puVar12 = puVar11;
    do {
      if ((uint)puVar9[5] < uVar6) {
        puVar10 = (undefined4 *)puVar9[2];
      }
      else {
        puVar10 = (undefined4 *)*puVar9;
        puVar12 = puVar9;
      }
      puVar9 = puVar10;
    } while (*(char *)((int)puVar10 + 0xd) == '\0');
    if ((puVar12 != puVar11) && ((uint)puVar12[5] <= uVar6)) goto LAB_00b77289;
  }
  puVar12 = puVar11;
LAB_00b77289:
  param_2 = puVar12;
  piStack_14 = piVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_18 + 2);
    uVar3 = *puVar2;
    uVar6 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)(*piStack_18 + 4))();
    }
  }
  if (puVar12 != (undefined4 *)*piVar1) {
    piStack_10 = (int *)(param_1 + 0x60);
    puVar11 = (undefined4 *)*piStack_10;
    cVar4 = *(char *)((int)puVar11[1] + 0xd);
    puStack_8 = puVar12 + 6;
    puStack_c = puVar11;
    puVar9 = (undefined4 *)puVar11[1];
    puVar10 = puVar12;
    while (cVar4 == '\0') {
      iVar7 = FUN_01686710(puVar12 + 6);
      if (iVar7 < 0) {
        puVar10 = (undefined4 *)puVar9[2];
      }
      else {
        if ((*(char *)((int)puVar11 + 0xd) != '\0') && (iVar7 = FUN_01686710(puVar9 + 4), iVar7 < 0)
           ) {
          puVar11 = puVar9;
        }
        puVar10 = (undefined4 *)*puVar9;
        puStack_c = puVar9;
      }
      cVar4 = *(char *)((int)puVar10 + 0xd);
      puVar9 = puVar10;
      puVar10 = param_2;
    }
    puVar9 = puVar11;
    if (*(char *)((int)puVar11 + 0xd) != '\0') {
      puVar9 = (undefined4 *)(*piStack_10 + 4);
    }
    cVar4 = *(char *)((int)*puVar9 + 0xd);
    puVar9 = (undefined4 *)*puVar9;
    puVar12 = puStack_c;
    while (puStack_c = puVar12, puVar5 = puVar12, cVar4 == '\0') {
      iVar7 = FUN_01686710(puVar9 + 4);
      if (iVar7 < 0) {
        puVar12 = (undefined4 *)*puVar9;
        puVar11 = puVar9;
      }
      else {
        puVar12 = (undefined4 *)puVar9[2];
      }
      cVar4 = *(char *)((int)puVar12 + 0xd);
      puVar9 = puVar12;
      puVar10 = param_2;
      puVar12 = puStack_c;
    }
    while (param_2 = puVar5, param_2 != puVar11) {
      FUN_00551320();
      puVar5 = param_2;
    }
    FUN_00b76ca0(&param_2,puVar12,puVar11);
    uVar8 = FUN_00553830(puVar10);
    FUN_00b768b0();
    uVar6 = FUN_01674ea0(uVar8,0x30);
  }
  return uVar6;
}



/* FUNCTION 24862 ; VA 0x00b773a0 ; FUN_00b773a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b773a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7400;
  pvStack_10 = ExceptionList;
  if (DAT_01ef1450 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1668) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef1668);
      if (DAT_01ef1668 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"MouseService",1,uStack_20,0,0,1,0,0);
        _DAT_01ef1660 = RBX::Creator<class_RBX::MouseService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef1458,&DAT_01ef1660);
        FUN_016f3654(FUN_0188fd30);
        FUN_016f37bf(&DAT_01ef1668);
      }
    }
    DAT_01ef1450 = &DAT_01ef1458;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1450;
}



/* FUNCTION 24863 ; VA 0x00b774a0 ; FUN_00b774a0 */

void FUN_00b774a0(void)

{
  int iVar1;
  
  if (DAT_01ef166c == 0) {
    iVar1 = FUN_00b773a0();
    DAT_01ef166c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24864 ; VA 0x00b774c0 ; FUN_00b774c0 */

int __thiscall FUN_00b774c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7410;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::MouseService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24865 ; VA 0x00b77592 ; Catch_All@00b77592 */

void Catch_All_00b77592(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24866 ; VA 0x00b775b0 ; FUN_00b775b0 */

undefined4 *
FUN_00b775b0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined8 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcc13;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00d7fd90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xdc);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00d80c80(*param_2,*param_3,*param_4,*(undefined4 *)(param_4 + 1),*param_5,*param_6);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab220(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24867 ; VA 0x00b776b0 ; FUN_00b776b0 */

undefined4 * FUN_00b776b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f745b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b773a0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0xd4);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    *(undefined *)(puVar3 + 0x15) = 1;
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::MouseService,class_RBX::ServiceInstance>::vftable;
    uVar4 = FUN_00b773a0();
    puVar3[3] = uVar4;
    *puVar3 = RBX::MouseService::vftable;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    *(undefined *)(puVar3 + 0x1c) = 0;
    uVar4 = FUN_00588320(0xb);
    puVar3[0x1d] = uVar4;
    puVar3[0x1e] = 0;
    puVar3[0x1f] = 0x3f800000;
    puVar3[0x20] = 0;
    puVar3[0x21] = 0;
    puVar3[0x22] = 0;
    puVar3[0x23] = 0;
    puVar3[0x24] = 0;
    puVar3[0x25] = 0;
    puVar3[0x26] = 0;
    puVar3[0x27] = 0x3f800000;
    puVar3[0x28] = 0;
    puVar3[0x29] = 0;
    *(undefined *)(puVar3 + 0x2a) = 1;
    puVar3[0x2b] = 0;
    puVar3[0x2c] = 0;
    *(undefined *)(puVar3 + 0x2d) = 0;
    uVar4 = FUN_00588320(0xb);
    puVar3[0x2e] = uVar4;
    puVar3[0x2f] = 0;
    puVar3[0x30] = 0x3f800000;
    puVar3[0x31] = 0;
    puVar3[0x32] = 0;
    puVar3[0x33] = 0;
    puVar3[0x34] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b774c0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24868 ; VA 0x00b778b0 ; thunk_FUN_00b798a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b798a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7576;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef174c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef174c);
    if (DAT_01ef174c == -1) {
      uStack_8 = 0;
      FUN_009ca470("MouseBehavior");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef16e8 = RBX::Reflection::EnumDesc<enum_RBX::MouseService::MouseType>::vftable;
      FUN_009caf20(&DAT_01d67728,3);
      FUN_016f3654(&LAB_0188fcf0);
      FUN_016f37bf(&DAT_01ef174c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef16e8;
}



/* FUNCTION 24869 ; VA 0x00b778c0 ; thunk_FUN_00b79950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b79950(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7596;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef16e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef16e4);
    if (DAT_01ef16e4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("OverrideMouseIconBehavior");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef1680 =
           RBX::Reflection::EnumDesc<enum_RBX::MouseService::OverrideMouseIconBehavior>::vftable;
      FUN_009caf20(&DAT_01d67740,3);
      FUN_016f3654(&LAB_0188fd10);
      FUN_016f37bf(&DAT_01ef16e4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1680;
}



/* FUNCTION 24870 ; VA 0x00b778d0 ; FUN_00b778d0 */

void __fastcall FUN_00b778d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::MouseService>::vftable;
  uVar1 = FUN_00b773a0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24871 ; VA 0x00b77910 ; FUN_00b77910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_00b77910(byte *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7478;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar2,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  uStack_8 = 0;
  FUN_00619db0();
  _DAT_0000000c = 0;
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar5 = uVar3 + 1;
  _DAT_00000008 = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005d6bb0(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    param_2 = (uint *)0x1;
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar5) {
      uVar7 = 1;
    }
    iVar6 = FUN_005d6bb0(uVar7 + *(int *)(param_1 + 8));
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar9;
      while (puVar4 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar9;
          puVar9 = puVar4;
        }
        else {
          *puVar9 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar2 % *(uint *)(param_1 + 4)) * 4);
  _DAT_00000004 = uVar2;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *piVar1 = (int)piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (uint *)&DAT_00000008;
}



/* FUNCTION 24872 ; VA 0x00b77ab0 ; FUN_00b77ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b77ab0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MouseService::MouseType>::vftable;
  _DAT_01ef1670 = _DAT_01ef1670 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24873 ; VA 0x00b77ae0 ; FUN_00b77ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b77ae0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MouseService::OverrideMouseIconBehavior>::vftable;
  _DAT_01ef1678 = _DAT_01ef1678 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24874 ; VA 0x00b77b10 ; FUN_00b77b10 */

undefined4 * __thiscall FUN_00b77b10(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::MouseService::vftable;
  piVar2 = (int *)param_1[0x34];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006123a0();
  FUN_00577a40();
  piVar2 = (int *)param_1[0x23];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_006123a0();
  piVar2 = (int *)param_1[0x1b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x19];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd4);
  }
  return param_1;
}



/* FUNCTION 24875 ; VA 0x00b77c00 ; FUN_00b77c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b77c00(undefined4 param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  float fVar5;
  double dVar6;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  ulonglong uStack_28;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  iVar2 = FUN_008acee0(param_1);
  if ((iVar2 != 0) && (*(int *)(*param_2 + 0x58) == *(int *)(*param_2 + 0x54))) {
    fStack_34 = (float)FUN_00b82b00();
    if ((*(int *)(*param_2 + 0x54) != 4) && (*(int *)(*param_2 + 0x54) != 7)) {
      uVar3 = FUN_008f7870(param_1);
      cVar1 = FUN_00b83530(uVar3);
      if ((cVar1 == '\0') || (*(int *)(*param_2 + 0x54) != 4)) {
        iVar2 = FUN_00ed3bf0(fStack_34);
        if (iVar2 == -1) {
          return;
        }
        iVar2 = FUN_00ed3bf0(*(undefined4 *)(*param_2 + 0x54));
        if (iVar2 == -1) {
          return;
        }
        iVar2 = FUN_005c3ac0(param_1);
        if (iVar2 == 0) {
          return;
        }
        iVar2 = (**(code **)(*(int *)(iVar2 + 0x144) + 4))();
        uStack_18 = 0;
        iVar4 = (int)(short)((uint)*(undefined4 *)(iVar2 + 0x1cc) >> 0x10);
        fVar5 = (float)(int)(short)*(undefined4 *)(iVar2 + 0x1cc) * DAT_018ce2f4;
        uStack_28 = (ulonglong)(uint)fVar5;
        uStack_20 = CONCAT44((float)iVar4 * DAT_018ce2f4,fVar5);
        iVar2 = FUN_0097bfc0(param_1);
        if (iVar2 != 0) {
          iVar2 = FUN_008f7870(param_1);
          if ((*(int *)(iVar2 + 0x1b8) != 0) &&
             (iVar2 = (**(code **)(*(int *)(*(int *)(iVar2 + 0x1b8) + 0x144) + 4))(), iVar2 != 0)) {
            fStack_34 = *(float *)(iVar2 + 0xc0) - *(float *)(iVar2 + 0x90);
            fStack_30 = *(float *)(iVar2 + 0xc4) - *(float *)(iVar2 + 0x94);
            fStack_2c = *(float *)(iVar2 + 200) - *(float *)(iVar2 + 0x98);
            cVar1 = FUN_00b837e0();
            if (cVar1 == '\0') {
              dVar6 = (double)(fStack_34 * fStack_34 + fStack_30 * fStack_30 + fStack_2c * fStack_2c
                              );
              FUN_017267a0();
              if (_DAT_01958098 < (float)dVar6) {
                uStack_c = 0;
                uStack_18 = 0;
                uStack_20 = CONCAT44((float)iVar4 / DAT_018df580,(int)uStack_28);
              }
            }
          }
        }
        fStack_2c = (float)FUN_008f7870(param_1);
        uStack_14 = 0;
        uStack_10 = 0;
        uStack_c = 0;
        fStack_30 = 1.4013e-45;
        fStack_34 = 5.60519e-45;
        uVar3 = FUN_008ac260(&uStack_28,&fStack_34,&fStack_30,&uStack_20,&uStack_14,&fStack_2c);
        FUN_005587e0(uVar3);
        FUN_00550b30();
        return;
      }
    }
    FUN_0056ecd0(param_2);
  }
  return;
}



/* FUNCTION 24876 ; VA 0x00b77e80 ; FUN_00b77e80 */

bool __fastcall FUN_00b77e80(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  iVar2 = FUN_008f7870(param_1);
  if ((iVar2 != 0) && (iVar2 != -0xc)) {
    FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
    uVar3 = FUN_006352d0();
    piVar4 = (int *)FUN_008aa140(uVar3);
    if (*piVar4 == 0) {
      uVar3 = FUN_00b8c410();
      piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
      iVar2 = *piVar5;
      iVar1 = piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      *piVar4 = iVar2;
      piVar5 = (int *)piVar4[1];
      piVar4[1] = iVar1;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_8[1] + -1;
        piStack_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar5 = piStack_8 + 2;
          iVar2 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
    }
    if (*piVar4 != 0) {
      return *(char *)(*piVar4 + 0x16e) == '\0';
    }
  }
  return true;
}



/* FUNCTION 24877 ; VA 0x00b77f60 ; FUN_00b77f60 */

void FUN_00b77f60(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b798a0();
    *param_2 = uVar3;
    iVar4 = FUN_00b79a00();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24878 ; VA 0x00b77fc0 ; FUN_00b77fc0 */

void FUN_00b77fc0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b79950();
    *param_2 = uVar3;
    iVar4 = FUN_00b79a70();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24879 ; VA 0x00b78020 ; FUN_00b78020 */

void FUN_00b78020(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b798a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24880 ; VA 0x00b78060 ; FUN_00b78060 */

void FUN_00b78060(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b79950();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24881 ; VA 0x00b780a0 ; FUN_00b780a0 */

undefined4 * FUN_00b780a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b776b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24882 ; VA 0x00b78110 ; FUN_00b78110 */

undefined4 FUN_00b78110(undefined4 param_1,undefined4 *param_2,char param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  uint uVar5;
  undefined4 ***pppuStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  undefined8 uStack_34;
  uint uStack_2c;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f74b9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_3 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_2);
    uStack_8 = 0;
    FUN_009cbbb0(param_1);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_8 = 1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_14 = 2;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 9);
  FUN_00554150("textures/",9);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  piVar2 = (int *)FUN_00554150(&DAT_01958000,4);
  pppuStack_44 = (undefined4 ***)*piVar2;
  iStack_40 = piVar2[1];
  iStack_3c = piVar2[2];
  iStack_38 = piVar2[3];
  uStack_34 = *(undefined8 *)(piVar2 + 4);
  piVar2[4] = 0;
  piVar2[5] = 0xf;
  *(undefined *)piVar2 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar5 = uStack_2c;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(uStack_2c - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  ppppuVar3 = &pppuStack_44;
  if (0xf < uStack_34._4_4_) {
    ppppuVar3 = (undefined4 ****)pppuStack_44;
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  FUN_009cc450(param_1,ppppuVar3);
  if (0xf < uStack_34._4_4_) {
    uVar5 = uStack_34._4_4_ + 1;
    ppppuVar3 = (undefined4 ****)pppuStack_44;
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)pppuStack_44[-1];
      uVar5 = uStack_34._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_44 + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24883 ; VA 0x00b782b0 ; FUN_00b782b0 */

undefined4 __thiscall FUN_00b782b0(byte *param_1,undefined4 param_2,undefined4 *param_3)

{
  FUN_00606ea0(param_2,*param_3,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return param_2;
}



/* FUNCTION 24884 ; VA 0x00b782e0 ; FUN_00b782e0 */

void __thiscall FUN_00b782e0(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined8 *puVar3;
  int iStack_2c;
  undefined auStack_20 [8];
  uint uStack_18;
  int iStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  iStack_10 = param_1;
  iVar1 = FUN_008acee0(param_1);
  if (iVar1 == 0) {
    return;
  }
  if (*(char *)(iVar1 + 0x192) == '\0') {
    return;
  }
  FUN_0054ef60(*param_2 + 0xc0);
  cStack_5 = FUN_00558b30();
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (iStack_2c - *(int *)(iStack_2c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (cStack_5 == '\0') {
    return;
  }
  if (*(int *)(*param_2 + 0x54) != 7) {
    return;
  }
  iVar1 = *(int *)(*param_2 + 0x5c);
  if (iVar1 != 0) {
    if (iVar1 == 1) {
      uStack_c = 4;
      goto LAB_00b7839c;
    }
    if (iVar1 != 2) {
      return;
    }
  }
  uStack_c = 0;
LAB_00b7839c:
  iStack_10 = iStack_10 + 0xb4;
  piVar2 = (int *)FUN_00b782b0();
  if (*piVar2 != 0) {
    FUN_00b77910(&uStack_c);
    FUN_00d81e10();
    FUN_00b77910(&uStack_c);
    puVar3 = (undefined8 *)FUN_00d81770(auStack_20);
    FUN_00d81ed0(*puVar3,*(undefined4 *)(puVar3 + 1));
    FUN_00b77910(&uStack_c);
    FUN_00b7ef20();
  }
  return;
}



/* FUNCTION 24885 ; VA 0x00b78450 ; FUN_00b78450 */

undefined4 * __thiscall FUN_00b78450(int param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 auStack_40 [6];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined auStack_10 [4];
  int *piStack_c;
  int *piStack_8;
  
  if (param_1 == 0) {
LAB_00b785a1:
    iVar9 = FUN_008acee0(param_1);
    if ((iVar9 != 0) && (*(char *)(iVar9 + 0x231) == '\0')) {
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
      return param_2;
    }
    iVar5 = *(int *)(param_1 + 0x94) - *(int *)(param_1 + 0x90);
    iVar9 = iVar5 >> 0x1f;
    if (iVar5 / 0x18 + iVar9 != iVar9) {
      FUN_0054ef60(*(int *)(param_1 + 0x94) + -0x18);
      puVar8 = auStack_40;
      iVar5 = 8;
      iVar9 = 0;
      goto LAB_00b7862d;
    }
    iVar9 = 0x10;
  }
  else {
    iVar9 = *(int *)(param_1 + 0x34);
    iVar5 = param_1;
    if ((iVar9 != 0) && (iVar5 = iVar9, *(int *)(iVar9 + 0x34) != 0)) {
      iVar5 = FUN_005c8ac0();
    }
    if ((iVar5 == 0) ||
       (iVar9 = *(int *)(iVar5 + 0xc), iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) goto LAB_00b785a1;
    FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
    uVar6 = FUN_00560d40();
    piStack_8 = (int *)FUN_008aa140(uVar6);
    if (*piStack_8 == 0) {
      uVar6 = FUN_00995770();
      piVar7 = (int *)FUN_008a9ba0(auStack_10,uVar6);
      iVar9 = *piVar7;
      iVar5 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      *piStack_8 = iVar9;
      piVar7 = (int *)piStack_8[1];
      piStack_8[1] = iVar5;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + -1;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + -1;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (piStack_c != (int *)0x0) {
        LOCK();
        iVar9 = piStack_c[1] + -1;
        piStack_c[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_c)();
          LOCK();
          piVar7 = piStack_c + 2;
          iVar9 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          if (iVar9 == 1) {
            (**(code **)(*piStack_c + 4))();
          }
        }
      }
    }
    if ((*piStack_8 == 0) || (*(int *)(*piStack_8 + 0x68) == 1)) goto LAB_00b785a1;
    iVar5 = *(int *)(param_1 + 0x94) - *(int *)(param_1 + 0x90);
    iVar9 = iVar5 >> 0x1f;
    if (iVar5 / 0x18 + iVar9 != iVar9) {
      FUN_0054ef60(*(int *)(param_1 + 0x94) + -0x18);
      puVar8 = auStack_40;
      iVar5 = 1;
      iVar9 = 0;
      goto LAB_00b7862d;
    }
    iVar9 = 2;
  }
  uStack_18 = 0;
  puVar8 = auStack_40 + 6;
  iVar5 = 0;
  auStack_28[0] = 0;
  uStack_14 = 0xf;
LAB_00b7862d:
  uVar6 = *puVar8;
  uVar2 = puVar8[1];
  uVar3 = puVar8[2];
  uVar4 = puVar8[3];
  param_2[4] = 0;
  param_2[5] = 0;
  *param_2 = uVar6;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  uVar1 = *(undefined8 *)(puVar8 + 4);
  puVar8[4] = 0;
  puVar8[5] = 0xf;
  *(undefined *)puVar8 = 0;
  *(undefined8 *)(param_2 + 4) = uVar1;
  if (iVar9 != 0) {
    FUN_005507b0();
  }
  if (iVar5 != 0) {
    FUN_005507b0();
  }
  return param_2;
}



/* FUNCTION 24886 ; VA 0x00b78690 ; FUN_00b78690 */

undefined * __thiscall
FUN_00b78690(undefined4 param_1,undefined *param_2,char param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  char *pcVar5;
  undefined4 uVar6;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2f58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008acee0(param_1);
  if ((iVar2 == 0) || (*(char *)(iVar2 + 0x231) == '\0')) {
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = 0;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = 0;
  uStack_8 = 2;
  if (param_3 == '\0') {
    FUN_005542c0("ArrowFarCursor",0xe);
    uVar6 = 0x17;
    pcVar5 = "Cursors/Gamepad/Pointer";
  }
  else {
    FUN_005542c0("ArrowCursor",0xb);
    uVar6 = 0x1b;
    pcVar5 = "Cursors/Gamepad/PointerOver";
  }
  FUN_005542c0(pcVar5,uVar6);
  FUN_005542c0("Cursors/Gamepad/Pointer",0x17);
  iVar2 = FUN_00b82b00();
  uVar6 = FUN_008f7870(param_1);
  cVar1 = FUN_00b83530(uVar6);
  if (cVar1 == '\0') {
    iVar3 = FUN_00ed3bf0(iVar2);
    if (iVar3 == -1) {
      if ((((iVar2 == 0) || (iVar2 == 1)) || (iVar2 == 6)) ||
         (((iVar2 == 4 || (iVar2 == 3)) || ((iVar2 == 8 || (cVar1 = FUN_00b82ab0(), cVar1 != '\0')))
          ))) {
        puVar4 = auStack_40;
      }
      else {
        cVar1 = FUN_00b82610();
        if (cVar1 == '\0') {
          *(undefined4 *)(param_2 + 0x10) = 0;
          *(undefined4 *)(param_2 + 0x14) = 0xf;
          *param_2 = 0;
          goto LAB_00b7880c;
        }
        puVar4 = auStack_28;
      }
    }
    else {
      puVar4 = auStack_28;
    }
  }
  else {
    puVar4 = auStack_58;
  }
  FUN_00b78110(param_2,puVar4,param_4);
LAB_00b7880c:
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24887 ; VA 0x00b78840 ; FUN_00b78840 */

void __thiscall FUN_00b78840(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x74);
  *param_2 = *(undefined8 *)(param_1 + 0x6c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 24888 ; VA 0x00b78860 ; FUN_00b78860 */

undefined4 * __thiscall FUN_00b78860(int param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  if (DAT_01d67708 == '\0') {
    if (*(int *)(param_1 + 0x68) != 0) {
      uVar1 = *(undefined8 *)(*(int *)(param_1 + 0x68) + 0x6c);
      uStack_10 = (undefined4)uVar1;
      *param_2 = uStack_10;
      uStack_c = (undefined4)((ulonglong)uVar1 >> 0x20);
      param_2[1] = uStack_c;
      return param_2;
    }
  }
  else if (*(int *)(param_1 + 0x60) != 0) {
    FUN_01126580(param_2);
    return param_2;
  }
  param_2[1] = 0;
  *param_2 = 0;
  return param_2;
}



/* FUNCTION 24889 ; VA 0x00b788e0 ; FUN_00b788e0 */

void __thiscall FUN_00b788e0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined auStack_c [8];
  
  if (*(int *)(param_1 + 0x68) != 0) {
    puVar1 = (undefined4 *)FUN_00d814c0(auStack_c);
    *param_2 = *puVar1;
    param_2[1] = puVar1[1];
    return;
  }
  *param_2 = 0x7f800000;
  param_2[1] = 0x7f800000;
  return;
}



/* FUNCTION 24890 ; VA 0x00b78930 ; FUN_00b78930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b78930(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uStack_fc;
  undefined4 *puStack_f8;
  int iStack_f4;
  int *piStack_f0;
  int iStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f74eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_18 == (undefined4 *)0x0) {
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 1;
    puStack_18[2] = 1;
    *puStack_18 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_18[3] = 0;
    puStack_18[4] = 0;
    puStack_18[5] = 0;
  }
  puVar3 = puStack_18;
  puVar1 = puStack_18 + 3;
  iStack_8 = 0;
  puStack_24 = puVar1;
  puStack_20 = puStack_18;
  cVar4 = FUN_00b77e80();
  if (cVar4 != '\0') {
    if (*(int *)(param_1 + 0x78) == 0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = *(int **)(*(int *)(param_1 + 0x84) + *(int *)(param_1 + 0x74) * 4);
    }
    if (piVar5 != (int *)0x0) {
      piStack_1c = (int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      do {
        iStack_2c = piVar5[3];
        if (*(int *)(iStack_2c + 0x5c) == 0) {
          piVar6 = (int *)piVar5[4];
          if (piVar6 != (int *)0x0) {
            LOCK();
            piVar6[1] = piVar6[1] + 1;
            UNLOCK();
            iStack_2c = piVar5[3];
            piVar6 = (int *)piVar5[4];
          }
          iStack_8 = CONCAT31(iStack_8._1_3_,1);
          piStack_28 = piVar6;
          iStack_14 = iStack_2c;
          uStack_fc = FUN_0088cdc0();
          puStack_f8 = (undefined4 *)0x0;
          if (piVar6 != (int *)0x0) {
            LOCK();
            piVar6[1] = piVar6[1] + 1;
            UNLOCK();
          }
          iStack_f4 = iStack_14;
          piStack_f0 = piVar6;
          if ((*(int *)(*piStack_1c + 0x34) < DAT_01ead288) &&
             (FUN_016f3809(&DAT_01ead288), DAT_01ead288 == -1)) {
            DAT_01ead27c = FUN_0057bbb0;
            _DAT_01ead280 = FUN_005880a0;
            DAT_01ead284 = FUN_0057d5e0;
            FUN_016f37bf(&DAT_01ead288);
          }
          puStack_f8 = &DAT_01ead27c;
          iStack_8 = CONCAT31(iStack_8._1_3_,2);
          if (puVar3[5] == puVar3[4]) {
            FUN_005ca4f0(puVar3[4],&uStack_fc);
          }
          else {
            FUN_005caaf0(puVar1);
            puVar3[4] = puVar3[4] + 0xd0;
          }
          iStack_8._0_1_ = 3;
          if (puStack_f8 != (undefined4 *)0x0) {
            (*(code *)puStack_f8[2])(&iStack_f4);
          }
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar2 = piVar6[1] + -1;
            piVar6[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar2 = piVar6[2] + -1;
              piVar6[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        piVar5 = (int *)*piVar5;
      } while (piVar5 != (int *)0x0);
    }
  }
  param_2[1] = (int)puStack_18;
  *param_2 = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24891 ; VA 0x00b78b60 ; FUN_00b78b60 */

uint __thiscall FUN_00b78b60(uint param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  uint uStack_8;
  
  uStack_8 = param_1;
  uVar1 = FUN_00b77e80();
  if ((char)uVar1 != '\0') {
    if (((param_2 == 0) || (param_2 == 1)) || (param_2 == 2)) {
      iVar2 = param_1 + 0x71 + (uint)*(byte *)(param_1 + 0x70);
      FUN_00606ea0(&uStack_8,param_2,&param_2,-(uint)(iVar2 != 0) & iVar2 + 1U);
      uVar1 = uStack_8;
      if ((uStack_8 != 0) && (uVar1 = *(uint *)(uStack_8 + 0xc), uVar1 != 0)) {
        return CONCAT31((int3)(uVar1 >> 8),*(int *)(uVar1 + 0x5c) == 0);
      }
    }
    else {
      uVar1 = FUN_0086f2f0(2,
                           "UserInputSerice.IsMouseButtonPressed - UserInputType provided is not a mouse button."
                          );
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 24892 ; VA 0x00b78be0 ; FUN_00b78be0 */

undefined4 __fastcall FUN_00b78be0(int param_1)

{
  int iVar1;
  int iVar2;
  int aiStack_4c [2];
  int iStack_44;
  int *piStack_3c;
  int aiStack_38 [2];
  int iStack_30;
  int aiStack_24 [2];
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7510;
  pvStack_10 = ExceptionList;
  iVar1 = param_1 + 0x68;
  if (*(int *)(param_1 + 0x68) == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00906640(aiStack_4c,iVar1);
  uStack_8 = 0;
  if ((aiStack_4c[0] != 1) && (iStack_44 != 1)) {
    iVar2 = FUN_005c3ac0(param_1);
    if (iVar2 == 0) {
LAB_00b78c8f:
      FUN_008ae7d0();
      ExceptionList = pvStack_10;
      return 0;
    }
    FUN_008b4e80(aiStack_38,iVar1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((aiStack_38[0] != 1) && (iStack_30 != 1)) {
      FUN_008b4950(aiStack_24,iVar1);
      if ((aiStack_24[0] != 1) && (iStack_1c != 1)) {
        FUN_008ae7d0();
        FUN_008ae7d0();
        goto LAB_00b78c8f;
      }
      FUN_008ae7d0();
    }
    FUN_008ae7d0();
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar1 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_3c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 24893 ; VA 0x00b78cf0 ; FUN_00b78cf0 */

uint FUN_00b78cf0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b773a0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24894 ; VA 0x00b78d10 ; FUN_00b78d10 */

uint FUN_00b78d10(void)

{
  int iVar1;
  
  iVar1 = FUN_00b773a0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24895 ; VA 0x00b78d30 ; FUN_00b78d30 */

void FUN_00b78d30(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b798a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24896 ; VA 0x00b78d70 ; FUN_00b78d70 */

void FUN_00b78d70(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b79950();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24897 ; VA 0x00b78db0 ; FUN_00b78db0 */

int __thiscall FUN_00b78db0(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puStack_58;
  undefined4 *puStack_54;
  undefined *puStack_44;
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7530;
  pvStack_10 = ExceptionList;
  puStack_54 = (undefined4 *)param_3;
  puStack_58 = param_2;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar6 = FUN_008a4210();
  if (iVar2 != 0) {
    puStack_54 = (undefined4 *)iVar2;
    puStack_58 = (undefined4 *)0xb78ded;
    param_3 = FUN_008f7870();
    puStack_58 = &param_3;
    uStack_38 = 0;
    uStack_30 = 0;
    puStack_44 = &DAT_bf800000;
    puStack_40 = &DAT_bf800000;
    uStack_3c = 0;
    param_2 = (undefined4 *)0x1;
    uStack_18 = 4;
    puVar7 = (undefined4 *)FUN_008ac260(auStack_24,&uStack_18,&param_2,&puStack_44,&uStack_38);
    param_3 = param_1 + 0xb4;
    uStack_8 = 0;
    puStack_54 = &param_2;
    param_2 = (undefined4 *)0x4;
    puStack_58 = (undefined4 *)0xb78e6c;
    iVar6 = FUN_00b77910();
    uVar3 = *puVar7;
    uVar4 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(iVar6 + 4) = uVar3;
    piVar5 = *(int **)(iVar6 + 8);
    *(undefined4 *)(iVar6 + 8) = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_54 = (undefined4 *)0xb78e9d;
        (**(code **)*piVar5)();
        LOCK();
        iVar6 = piVar5[2] + -1;
        piVar5[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_54 = (undefined4 *)0xb78ead;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_20;
    uStack_8 = 0xffffffff;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_54 = (undefined4 *)0xb78eca;
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_54 = (undefined4 *)0xb78eda;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    puStack_54 = &param_2;
    param_2 = (undefined4 *)0x4;
    puStack_58 = (undefined4 *)0xb78eed;
    iVar6 = FUN_00b77910();
    puStack_54 = (undefined4 *)iVar2;
    *(undefined4 *)(*(int *)(iVar6 + 4) + 0x58) = 7;
    puStack_58 = (undefined4 *)0xb78efd;
    param_2 = (undefined4 *)FUN_008f7870();
    puStack_58 = &param_2;
    puStack_44 = (undefined *)0x0;
    puStack_40 = (undefined *)0x0;
    uStack_3c = 0;
    uStack_38 = 0xbf800000bf800000;
    uStack_30 = 0;
    uStack_18 = 0;
    uStack_1c = 0;
    puVar7 = (undefined4 *)FUN_008ac260(auStack_24,&uStack_1c,&uStack_18,&uStack_38,&puStack_44);
    puStack_54 = &param_2;
    uStack_8 = 1;
    param_2 = (undefined4 *)0x0;
    puStack_58 = (undefined4 *)0xb78f74;
    iVar6 = FUN_00b77910();
    uVar3 = *puVar7;
    uVar4 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(iVar6 + 4) = uVar3;
    piVar5 = *(int **)(iVar6 + 8);
    *(undefined4 *)(iVar6 + 8) = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_54 = (undefined4 *)0xb78fa2;
        (**(code **)*piVar5)();
        LOCK();
        iVar6 = piVar5[2] + -1;
        piVar5[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_54 = (undefined4 *)0xb78fb2;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_54 = (undefined4 *)0xb78fcf;
        (**(code **)*piStack_20)();
        LOCK();
        iVar6 = piStack_20[2] + -1;
        piStack_20[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_54 = (undefined4 *)0xb78fdf;
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    puStack_54 = &param_2;
    param_2 = (undefined4 *)0x0;
    puStack_58 = (undefined4 *)0xb78ff2;
    iVar6 = FUN_00b77910();
    uStack_38 = DAT_01957dac;
    *(undefined4 *)(*(int *)(iVar6 + 4) + 0x58) = 7;
    uStack_30 = DAT_01957db4;
    if (DAT_01d67720 == '\0') {
      uStack_38 = DAT_01957db8;
      uStack_30 = DAT_01957dc0;
    }
    puStack_54 = (undefined4 *)iVar2;
    if (DAT_01d67708 != '\0') {
      puStack_58 = (undefined4 *)0xb7903e;
      param_3 = FUN_008f7870();
      param_2 = (undefined4 *)0x0;
      uStack_1c = 3;
      uStack_18 = 4;
      FUN_00b775b0(&puStack_58,&uStack_18,&uStack_1c,&uStack_38,&param_2,&param_3);
      iVar6 = FUN_00b795a0();
      ExceptionList = pvStack_10;
      return iVar6;
    }
    puStack_58 = (undefined4 *)0xb79096;
    param_3 = FUN_008f7870();
    puStack_58 = &param_3;
    param_2 = (undefined4 *)0x0;
    uStack_1c = 3;
    uStack_18 = 4;
    puStack_54 = (undefined4 *)FUN_00b775b0(auStack_2c,&uStack_18,&uStack_1c,&uStack_38,&param_2);
    puStack_58 = (undefined4 *)0xb790da;
    iVar6 = FUN_005587e0();
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar5 = piStack_28 + 1;
      iVar2 = *piVar5;
      iVar6 = *piVar5;
      *piVar5 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_54 = (undefined4 *)0xb790f0;
        iVar6 = (**(code **)*piStack_28)();
        LOCK();
        piVar5 = piStack_28 + 2;
        iVar2 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          puStack_54 = (undefined4 *)0xb790ff;
          iVar6 = (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 24898 ; VA 0x00b79120 ; FUN_00b79120 */

void __thiscall FUN_00b79120(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  int *piVar11;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2748;
  pvStack_10 = ExceptionList;
  piVar11 = *(int **)(param_1 + 0x94);
  piVar10 = *(int **)(param_1 + 0x90);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (piVar10 != piVar11) {
    do {
      ExceptionList = ppvVar3;
      cVar4 = FUN_009cbaa0(piVar10,&param_2);
      if (cVar4 != '\0') break;
      piVar10 = piVar10 + 6;
      ppvVar3 = (void **)ExceptionList;
    } while (piVar10 != piVar11);
    piVar6 = piVar10;
    if (piVar10 != piVar11) {
      while (piVar2 = piVar6, piVar6 = piVar2 + 6, piVar6 != piVar11) {
        cVar4 = FUN_009cbaa0(piVar6,&param_2);
        if (cVar4 == '\0') {
          if (piVar10 != piVar6) {
            uVar9 = piVar10[5];
            if (0xf < uVar9) {
              iVar8 = *piVar10;
              uVar7 = uVar9 + 1;
              iVar5 = iVar8;
              if (0xfff < uVar7) {
                iVar5 = *(int *)(iVar8 + -4);
                uVar7 = uVar9 + 0x24;
                if (0x1f < (iVar8 - iVar5) - 4U) goto LAB_00b79307;
              }
              FUN_01674ea0(iVar5,uVar7);
            }
            piVar10[4] = 0;
            piVar10[5] = 0xf;
            *(undefined *)piVar10 = 0;
            iVar8 = piVar2[7];
            iVar5 = piVar2[8];
            iVar1 = piVar2[9];
            *piVar10 = *piVar6;
            piVar10[1] = iVar8;
            piVar10[2] = iVar5;
            piVar10[3] = iVar1;
            iVar8 = piVar2[0xb];
            piVar10[4] = piVar2[10];
            piVar10[5] = iVar8;
            piVar2[10] = 0;
            piVar2[0xb] = 0xf;
            *(undefined *)piVar6 = 0;
          }
          piVar10 = piVar10 + 6;
        }
      }
      if (piVar10 != piVar11) {
        piVar6 = *(int **)(param_1 + 0x94);
        if (piVar11 != piVar6) {
          do {
            if (piVar10 != piVar11) {
              uVar9 = piVar10[5];
              if (0xf < uVar9) {
                iVar8 = *piVar10;
                uVar7 = uVar9 + 1;
                iVar5 = iVar8;
                if (0xfff < uVar7) {
                  iVar5 = *(int *)(iVar8 + -4);
                  uVar7 = uVar9 + 0x24;
                  if (0x1f < (iVar8 - iVar5) - 4U) goto LAB_00b79307;
                }
                FUN_01674ea0(iVar5,uVar7);
              }
              piVar10[4] = 0;
              piVar10[5] = 0xf;
              *(undefined *)piVar10 = 0;
              iVar8 = piVar11[1];
              iVar5 = piVar11[2];
              iVar1 = piVar11[3];
              *piVar10 = *piVar11;
              piVar10[1] = iVar8;
              piVar10[2] = iVar5;
              piVar10[3] = iVar1;
              iVar8 = piVar11[5];
              piVar10[4] = piVar11[4];
              piVar10[5] = iVar8;
              piVar11[4] = 0;
              piVar11[5] = 0xf;
              *(undefined *)piVar11 = 0;
            }
            piVar11 = piVar11 + 6;
            piVar10 = piVar10 + 6;
          } while (piVar11 != piVar6);
          piVar6 = *(int **)(param_1 + 0x94);
        }
        FUN_00559570(piVar10,piVar6,(undefined4 *)(param_1 + 0x90));
        *(int **)(param_1 + 0x94) = piVar10;
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar9 = in_stack_00000018 + 1;
    iVar8 = param_2;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(param_2 + -4);
      uVar9 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar8) - 4U) {
LAB_00b79307:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24899 ; VA 0x00b79310 ; FUN_00b79310 */

undefined4 * __thiscall FUN_00b79310(int param_1,undefined4 *param_2,int *param_3)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined8 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined auStack_58 [20];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [8];
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7550;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(*param_3 + 0x54);
  if ((4 < uVar1) || (*(uint *)(*param_3 + 0x58) != uVar1)) {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    return param_2;
  }
  iVar7 = *(int *)(param_1 + 0x8c);
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  if (iVar7 != 0) {
    piVar8 = (int *)(iVar7 + 4);
    iVar7 = *(int *)(iVar7 + 4);
    ExceptionList = &pvStack_10;
    while (iVar7 != 0) {
      LOCK();
      iVar3 = *piVar8;
      if (iVar7 == iVar3) {
        *piVar8 = iVar7 + 1;
        iVar3 = iVar7;
      }
      UNLOCK();
      if (iVar3 == iVar7) {
        piStack_24 = *(int **)(param_1 + 0x88);
        uStack_20 = *(undefined4 *)(param_1 + 0x8c);
        break;
      }
      iVar7 = *piVar8;
    }
  }
  piVar8 = piStack_24;
  uStack_8 = 0;
  iStack_1c = param_1;
  if ((piStack_24 == (int *)0x0) || (piVar4 = (int *)FUN_00817fa0(), piVar4 == (int *)0x0)) {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
  }
  else {
    iVar7 = *param_3;
    puVar5 = (undefined8 *)(**(code **)(*piVar4 + 0x120))(auStack_30,param_3);
    uVar9 = *(undefined4 *)(puVar5 + 1);
    *(undefined8 *)(iVar7 + 0x78) = *puVar5;
    *(undefined4 *)(iVar7 + 0x80) = uVar9;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_38 = 0;
    iStack_1c = 0;
    uStack_34 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar7 = *param_3;
    if (*(int *)(iVar7 + 0x54) == 4) {
      puVar6 = (undefined4 *)(**(code **)(*piVar8 + 0xa4))(auStack_58,param_3);
      uVar2 = puVar6[1];
      uVar9 = *puVar6;
      uStack_14 = puVar6[2];
      uStack_18 = puVar6[3];
      iStack_1c = puVar6[4];
      puVar6[3] = 0;
      puVar6[4] = 0;
      FUN_008ae7d0();
      iVar7 = *param_3;
      param_3 = (int *)uVar2;
    }
    else {
      uVar9 = 0;
      uStack_18 = 0;
      uStack_14 = 0;
      param_3 = (int *)0x0;
    }
    *(undefined8 *)(iVar7 + 0x78) = 0;
    uStack_28 = 0;
    *(undefined4 *)(iVar7 + 0x80) = 0;
    param_2[1] = param_3;
    param_2[2] = uStack_14;
    *param_2 = uVar9;
    param_2[3] = uStack_18;
    param_2[4] = iStack_1c;
  }
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24900 ; VA 0x00b79500 ; FUN_00b79500 */

void __thiscall FUN_00b79500(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2748;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x98) == *(int *)(param_1 + 0x94)) {
    ExceptionList = &pvStack_10;
    FUN_008be0b0(*(int *)(param_1 + 0x94),&param_2);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(&param_2);
    *(int *)(param_1 + 0x94) = *(int *)(param_1 + 0x94) + 0x18;
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24901 ; VA 0x00b795a0 ; FUN_00b795a0 */

int __thiscall FUN_00b795a0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x68) = param_2;
  piVar3 = *(int **)(param_1 + 0x6c);
  *(int **)(param_1 + 0x6c) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (DAT_01d67708 != '\0') {
    param_2 = *(int *)(*(int *)(param_1 + 0x68) + 0x54);
    if ((param_2 == 4) || (param_2 == 7)) {
      param_2 = FUN_0056ecd0(param_1 + 0x68);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 24902 ; VA 0x00b79650 ; FUN_00b79650 */

void __thiscall FUN_00b79650(int param_1,float param_2)

{
  int iVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = DAT_01900c54;
  if (DAT_01900c54 <= param_2) {
    fVar2 = param_2;
  }
  fVar3 = DAT_018fde94;
  if (fVar2 <= DAT_018fde94) {
    fVar3 = fVar2;
  }
  if ((NAN(fVar3) || NAN(*(float *)(param_1 + 0x9c))) == (fVar3 == *(float *)(param_1 + 0x9c))) {
    *(float *)(param_1 + 0x9c) = fVar3;
    iVar1 = FUN_008acee0(param_1);
    if (iVar1 != 0) {
      FUN_008a4940();
      return;
    }
  }
  return;
}



/* FUNCTION 24903 ; VA 0x00b796b0 ; FUN_00b796b0 */

void __thiscall FUN_00b796b0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  if ((char)param_2 != *(char *)(param_1 + 0xa8)) {
    *(char *)(param_1 + 0xa8) = (char)param_2;
    FUN_005e6780(param_2);
    iVar1 = FUN_008acee0(param_1);
    if (iVar1 != 0) {
      FUN_008a4940();
      return;
    }
  }
  return;
}



/* FUNCTION 24904 ; VA 0x00b79700 ; FUN_00b79700 */

void __thiscall FUN_00b79700(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 != *(int *)(param_1 + 0xac)) {
    *(int *)(param_1 + 0xac) = param_2;
    if (param_2 == 0) {
      *(undefined4 *)(param_1 + 0x5c) = 0;
    }
    else if (param_2 == 1) {
      iVar5 = *(int *)(param_1 + 0x34);
      iVar1 = param_1;
      if ((iVar5 != 0) && (iVar1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
        iVar1 = FUN_005c8ac0();
      }
      if ((iVar1 != 0) &&
         (iVar5 = *(int *)(iVar1 + 0xc), iVar1 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
         (uint)*(ushort *)(iVar1 + 0x1da))) {
        FUN_005789c0(&DAT_01ee0d08,&LAB_008e0e40);
        uVar2 = FUN_008e3ba0();
        piVar3 = (int *)FUN_008aa140(uVar2);
        if (*piVar3 == 0) {
          uVar2 = FUN_00db79d0();
          piVar4 = (int *)FUN_008a9ba0(auStack_c,uVar2);
          iVar5 = *piVar4;
          iVar1 = piVar4[1];
          *piVar4 = 0;
          piVar4[1] = 0;
          *piVar3 = iVar5;
          piVar4 = (int *)piVar3[1];
          piVar3[1] = iVar1;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar5 = piVar4[1] + -1;
            piVar4[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar5 = piVar4[2] + -1;
              piVar4[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_8[1] + -1;
            piStack_8[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar4 = piStack_8 + 2;
              iVar5 = *piVar4;
              *piVar4 = *piVar4 + -1;
              UNLOCK();
              if (iVar5 == 1) {
                (**(code **)(*piStack_8 + 4))();
              }
            }
          }
        }
        if ((*piVar3 != 0) && (piVar3 = *(int **)(*piVar3 + 0x58), piVar3 != (int *)0x0)) {
          (**(code **)(*piVar3 + 0x10))();
        }
      }
    }
    iVar5 = FUN_008acee0(param_1);
    if (iVar5 != 0) {
      FUN_008a4940(&DAT_0212de48);
    }
  }
  return;
}



/* FUNCTION 24905 ; VA 0x00b79860 ; FUN_00b79860 */

void __thiscall FUN_00b79860(int param_1,int param_2)

{
  int iVar1;
  
  if (param_2 != *(int *)(param_1 + 0xb0)) {
    *(int *)(param_1 + 0xb0) = param_2;
    iVar1 = FUN_008acee0(param_1);
    if (iVar1 != 0) {
      FUN_008a4940();
      return;
    }
  }
  return;
}



/* FUNCTION 24906 ; VA 0x00b798a0 ; FUN_00b798a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b798a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7576;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef174c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef174c);
    if (DAT_01ef174c == -1) {
      uStack_8 = 0;
      FUN_009ca470("MouseBehavior");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef16e8 = RBX::Reflection::EnumDesc<enum_RBX::MouseService::MouseType>::vftable;
      FUN_009caf20(&DAT_01d67728,3);
      FUN_016f3654(&LAB_0188fcf0);
      FUN_016f37bf(&DAT_01ef174c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef16e8;
}



/* FUNCTION 24907 ; VA 0x00b79950 ; FUN_00b79950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b79950(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7596;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef16e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef16e4);
    if (DAT_01ef16e4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("OverrideMouseIconBehavior");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef1680 =
           RBX::Reflection::EnumDesc<enum_RBX::MouseService::OverrideMouseIconBehavior>::vftable;
      FUN_009caf20(&DAT_01d67740,3);
      FUN_016f3654(&LAB_0188fd10);
      FUN_016f37bf(&DAT_01ef16e4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1680;
}



/* FUNCTION 24908 ; VA 0x00b79a00 ; FUN_00b79a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b79a00(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef175c) {
    FUN_016f3809(&DAT_01ef175c);
    if (DAT_01ef175c == -1) {
      _DAT_01ef1750 = FUN_005c65e0;
      _DAT_01ef1754 = FUN_005c65e0;
      _DAT_01ef1758 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef175c);
    }
  }
  return &DAT_01ef1750;
}



/* FUNCTION 24909 ; VA 0x00b79a70 ; FUN_00b79a70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b79a70(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef176c) {
    FUN_016f3809(&DAT_01ef176c);
    if (DAT_01ef176c == -1) {
      _DAT_01ef1760 = FUN_005c65e0;
      _DAT_01ef1764 = FUN_005c65e0;
      _DAT_01ef1768 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef176c);
    }
  }
  return &DAT_01ef1760;
}



/* FUNCTION 24910 ; VA 0x00b79ae0 ; FUN_00b79ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b79ae0(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  float fVar5;
  double dVar6;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  ulonglong uStack_28;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  iVar3 = FUN_008acee0();
  if (iVar3 != 0) {
    iVar3 = *(int *)(*param_2 + 0x54);
    if (*(int *)(*param_2 + 0x58) == iVar3) {
      if (((iVar3 < 0) || (4 < iVar3)) && (iVar3 != 7)) {
        iVar3 = FUN_00ed3bf0();
        if (iVar3 != -1) {
          FUN_00b82b00();
          iVar3 = FUN_00ed3bf0();
          if ((DAT_01d67718 == '\0') || (iVar3 != -1)) {
            iVar3 = FUN_005c3ac0();
            if (iVar3 != 0) {
              fStack_34 = (float)(**(code **)(*(int *)(iVar3 + 0x144) + 4))();
              uStack_18 = 0;
              iVar4 = (int)(short)((uint)*(undefined4 *)((int)fStack_34 + 0x1cc) >> 0x10);
              fVar5 = (float)(int)(short)*(undefined4 *)((int)fStack_34 + 0x1cc) * DAT_018ce2f4;
              uStack_28 = (ulonglong)(uint)fVar5;
              uStack_20 = CONCAT44((float)iVar4 * DAT_018ce2f4,fVar5);
              iVar3 = FUN_0097bfc0();
              if (iVar3 != 0) {
                fStack_30 = *(float *)((int)fStack_34 + 0xc4) - *(float *)((int)fStack_34 + 0x94);
                fStack_2c = *(float *)((int)fStack_34 + 200) - *(float *)((int)fStack_34 + 0x98);
                fStack_34 = *(float *)((int)fStack_34 + 0xc0) - *(float *)((int)fStack_34 + 0x90);
                cVar2 = FUN_00b837e0();
                if (cVar2 == '\0') {
                  dVar6 = (double)(fStack_34 * fStack_34 + fStack_30 * fStack_30 +
                                  fStack_2c * fStack_2c);
                  FUN_017267a0();
                  if (_DAT_01958098 < (float)dVar6) {
                    uStack_c = 0;
                    uStack_18 = 0;
                    uStack_20 = CONCAT44((float)iVar4 / DAT_018df580,(int)uStack_28);
                  }
                }
              }
              if (DAT_01d67710 != '\0') {
                if (*(int *)(param_1 + 0xcc) == 0) {
                  fStack_2c = (float)FUN_008f7870();
                  uStack_14 = 0;
                  uStack_10 = 0;
                  uStack_c = 0;
                  fStack_30 = 1.4013e-45;
                  fStack_34 = 5.60519e-45;
                  FUN_008ac260(&uStack_28,&fStack_34,&fStack_30,&uStack_20,&uStack_14);
                  FUN_005587e0();
                  FUN_00550b30();
                }
                FUN_00d81ed0(uStack_20);
                FUN_00557fc0(param_1 + 0xcc);
                FUN_00b795a0();
                return;
              }
              fStack_2c = (float)FUN_008f7870();
              uStack_14 = 0;
              uStack_10 = 0;
              uStack_c = 0;
              fStack_30 = 1.4013e-45;
              fStack_34 = 5.60519e-45;
              FUN_008ac260(&stack0xffffffb8,&fStack_34,&fStack_30,&uStack_20,&uStack_14,&fStack_2c);
              FUN_00b795a0();
              return;
            }
          }
        }
      }
      else {
        if (param_2[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_2[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00b795a0();
      }
    }
  }
  return;
}



/* FUNCTION 24911 ; VA 0x00b79dc2 ; FUN_00b79dc2 */

void FUN_00b79dc2(void)

{
  int *piVar1;
  undefined4 *unaff_ESI;
  
  if (unaff_ESI[1] != 0) {
    LOCK();
    piVar1 = (int *)(unaff_ESI[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00b795a0(*unaff_ESI,unaff_ESI[1]);
  return;
}



/* FUNCTION 24912 ; VA 0x00b79e00 ; FUN_00b79e00 */

void FUN_00b79e00(int *param_1)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = param_1;
  iVar1 = *param_1;
  param_1 = *(int **)(iVar1 + 0x54);
  if (((*(int *)(iVar1 + 0x5c) == 0) &&
      (((param_1 == (int *)0x0 || (param_1 == (int *)0x1)) || (param_1 == (int *)0x2)))) &&
     (iVar1 = FUN_00b77910(&param_1), *(int *)(iVar1 + 4) != *piVar2)) {
    FUN_00b77910(&param_1);
    FUN_0056ecd0(piVar2);
  }
  return;
}



/* FUNCTION 24913 ; VA 0x00b79e60 ; FUN_00b79e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b79e60(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = thunk_FUN_00d82070();
  iVar1 = _tls_index;
  *param_1 = uVar2;
  param_1[1] = 0;
  param_1[2] = *param_2;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ef1c2c) {
    FUN_016f3809(&DAT_01ef1c2c);
    if (DAT_01ef1c2c == -1) {
      _DAT_01ef1c20 = FUN_005c65e0;
      _DAT_01ef1c24 = FUN_005c65e0;
      _DAT_01ef1c28 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef1c2c);
    }
  }
  param_1[1] = &DAT_01ef1c20;
  return param_1;
}



/* FUNCTION 24914 ; VA 0x00b79ef0 ; FUN_00b79ef0 */

int * __thiscall
FUN_00b79ef0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f75bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b7a090();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UserInputService,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::UserInputService::*)(void)const_>::vftable
    ;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::UserInputService,class_G3D::Vector2>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::UserInputService,class_G3D::Vector2>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24915 ; VA 0x00b79ff0 ; FUN_00b79ff0 */

int * __thiscall FUN_00b79ff0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b84b30();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 24916 ; VA 0x00b7a040 ; FUN_00b7a040 */

int * __thiscall FUN_00b7a040(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b84c10();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 24917 ; VA 0x00b7a090 ; FUN_00b7a090 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b7a090(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f75f0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef1790 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef19a8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef19a8);
      if (DAT_01ef19a8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"UserInputService",1,uStack_20,0,0,1,0,0);
        _DAT_01ef19a0 = RBX::Creator<class_RBX::UserInputService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef1798,&DAT_01ef19a0);
        FUN_016f3654(FUN_018905c0);
        FUN_016f37bf(&DAT_01ef19a8);
      }
    }
    DAT_01ef1790 = &DAT_01ef1798;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1790;
}



/* FUNCTION 24918 ; VA 0x00b7a190 ; FUN_00b7a190 */

void FUN_00b7a190(void)

{
  int iVar1;
  
  if (DAT_01ef19ac == 0) {
    iVar1 = FUN_00b7a090();
    DAT_01ef19ac = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24919 ; VA 0x00b7a1b0 ; FUN_00b7a1b0 */

void FUN_00b7a1b0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 1;
    do {
      piVar1 = (int *)piVar3[2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piVar3 + 4;
      piVar3 = piVar3 + 5;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 24920 ; VA 0x00b7a230 ; FUN_00b7a230 */

void __thiscall FUN_00b7a230(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7600;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::UserInputService::WindowInputState>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24921 ; VA 0x00b7a29e ; Catch_All@00b7a29e */

void Catch_All_00b7a29e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00b7d490(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24922 ; VA 0x00b7a2c0 ; FUN_00b7a2c0 */

int __thiscall FUN_00b7a2c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7610;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::KeyboardService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24923 ; VA 0x00b7a392 ; Catch_All@00b7a392 */

void Catch_All_00b7a392(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24924 ; VA 0x00b7a3c0 ; FUN_00b7a3c0 */

int * __fastcall FUN_00b7a3c0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b84860();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24925 ; VA 0x00b7a3f0 ; FUN_00b7a3f0 */

int * __fastcall FUN_00b7a3f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00d82070();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24926 ; VA 0x00b7a420 ; FUN_00b7a420 */

int * __fastcall FUN_00b7a420(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b84a30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24927 ; VA 0x00b7a450 ; FUN_00b7a450 */

undefined4 FUN_00b7a450(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_008e25a0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 24928 ; VA 0x00b7a4b0 ; FUN_00b7a4b0 */

undefined4 * FUN_00b7a4b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7653;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e44830();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xc0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e44b10();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b7a2c0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24929 ; VA 0x00b7a570 ; FUN_00b7a570 */

int FUN_00b7a570(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7668;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ef1bf0,&LAB_00b7a3b0);
  uVar2 = FUN_00b7a890();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e44910();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00b7a4b0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ef1bf0,&LAB_00b7a3b0);
      uVar2 = FUN_00b7a890();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 24930 ; VA 0x00b7a700 ; FUN_00b7a700 */

int FUN_00b7a700(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7688;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
  uVar2 = FUN_006353d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b774a0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00b776b0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
      uVar2 = FUN_006353d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 24931 ; VA 0x00b7a890 ; FUN_00b7a890 */

undefined4 FUN_00b7a890(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f76ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1c1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1c1c);
    if (DAT_01ef1c1c == -1) {
      uStack_8 = 0;
      DAT_01ef1c18 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ef1c1c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1c18;
}



/* FUNCTION 24932 ; VA 0x00b7a910 ; thunk_FUN_00b84860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b84860(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b56;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1a1c);
    if (DAT_01ef1a1c == -1) {
      uStack_8 = 0;
      FUN_009ca470("SwipeDirection");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef19b8 = RBX::Reflection::EnumDesc<enum_RBX::GuiSwipeDirection>::vftable;
      FUN_009caf20(&DAT_01d6778c,5);
      FUN_016f3654(&LAB_01890380);
      FUN_016f37bf(&DAT_01ef1a1c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef19b8;
}



/* FUNCTION 24933 ; VA 0x00b7a920 ; thunk_FUN_00b849a0 */

undefined * thunk_FUN_00b849a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b6c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1a84);
    if (DAT_01ef1a84 == -1) {
      uStack_8 = 0;
      FUN_00baf9b0();
      FUN_016f3654(&LAB_018903c0);
      FUN_016f37bf(&DAT_01ef1a84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1a20;
}



/* FUNCTION 24934 ; VA 0x00b7a930 ; thunk_FUN_00d82070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00d82070(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181cc86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0fc7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f0fc7c);
    if (DAT_01f0fc7c == -1) {
      uStack_8 = 0;
      FUN_009ca470("UserInputState");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f0fc18 = RBX::Reflection::EnumDesc<enum_RBX::InputObject::UserInputState>::vftable;
      FUN_009caf20(&DAT_01d6d2b8,5);
      FUN_016f3654(&LAB_0189d120);
      FUN_016f37bf(&DAT_01f0fc7c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f0fc18;
}



/* FUNCTION 24935 ; VA 0x00b7a940 ; thunk_FUN_00b84a30 */

undefined * thunk_FUN_00b84a30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1aec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1aec);
    if (DAT_01ef1aec == -1) {
      uStack_8 = 0;
      FUN_00d806a0();
      FUN_016f3654(&LAB_018903e0);
      FUN_016f37bf(&DAT_01ef1aec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1a88;
}



/* FUNCTION 24936 ; VA 0x00b7a950 ; FUN_00b7a950 */

void FUN_00b7a950(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *puVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f76c8;
  pvStack_10 = ExceptionList;
  iVar10 = *param_2;
  iVar8 = *(int *)(iVar10 + 0x340);
  ExceptionList = &pvStack_10;
  iVar5 = FUN_0088daf0();
  if (iVar8 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar6 = (undefined *)(iVar10 + 0x348);
  iVar8 = *param_2;
  if (*(int *)(iVar10 + 0x344) == 0) {
    puVar6 = (undefined *)0x0;
  }
  iVar10 = *(int *)(iVar8 + 0x270);
  uVar3 = *puVar6;
  iVar5 = thunk_FUN_00d82070();
  if (iVar10 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar7 = (undefined4 *)(iVar8 + 0x278);
  iVar10 = *param_2;
  if (*(int *)(iVar8 + 0x274) == 0) {
    puVar7 = (undefined4 *)0x0;
  }
  iVar8 = *(int *)(iVar10 + 0x1a0);
  uVar4 = *puVar7;
  iVar5 = FUN_0088c960();
  if (iVar8 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar7 = (undefined4 *)(iVar10 + 0x1a8);
  iVar8 = *param_2;
  if (*(int *)(iVar10 + 0x1a4) == 0) {
    puVar7 = (undefined4 *)0x0;
  }
  iVar10 = *(int *)(iVar8 + 0xd0);
  uVar1 = *puVar7;
  iVar5 = FUN_0088c960();
  if (iVar10 == iVar5) {
    puVar7 = (undefined4 *)(iVar8 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar8 + 0xd4) == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    iVar10 = *param_2;
    uVar2 = *puVar7;
    iVar8 = FUN_008882f0();
    if (iVar10 == iVar8) {
      piVar9 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar9 = (int *)0x0;
      }
      iVar10 = piVar9[1];
      if (iVar10 != 0) {
        LOCK();
        *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
        UNLOCK();
        iVar10 = piVar9[1];
      }
      uStack_8 = 0;
      FUN_00b7cb60(*piVar9,iVar10,uVar2,uVar1,uVar4,CONCAT31((int3)((uint)puVar6 >> 8),uVar3));
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24937 ; VA 0x00b7aaf0 ; FUN_00b7aaf0 */

void FUN_00b7aaf0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined uVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined *puVar9;
  undefined4 *puVar10;
  int iVar11;
  int *piVar12;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f76e8;
  pvStack_1c = ExceptionList;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x340);
  ExceptionList = &pvStack_1c;
  iVar8 = FUN_0088daf0();
  if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar9 = (undefined *)(iVar11 + 0x348);
  if (*(int *)(iVar11 + 0x344) == 0) {
    puVar9 = (undefined *)0x0;
  }
  uVar5 = *puVar9;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x270);
  iVar8 = thunk_FUN_00d82070();
  if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar10 = (undefined4 *)(iVar11 + 0x278);
  if (*(int *)(iVar11 + 0x274) == 0) {
    puVar10 = (undefined4 *)0x0;
  }
  uVar7 = *puVar10;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x1a0);
  iVar8 = FUN_0088d730();
  if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar10 = (undefined4 *)(iVar11 + 0x1a8);
  if (*(int *)(iVar11 + 0x1a4) == 0) {
    puVar10 = (undefined4 *)0x0;
  }
  uVar1 = *puVar10;
  uVar2 = puVar10[1];
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0xd0);
  iVar8 = FUN_0088d730();
  if (iVar6 == iVar8) {
    param_2 = (int *)*param_2;
    puVar10 = (undefined4 *)(iVar11 + 0xd8);
    iVar6 = *param_2;
    if (*(int *)(iVar11 + 0xd4) == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    uVar3 = *puVar10;
    uVar4 = puVar10[1];
    iVar11 = FUN_008882f0();
    if (iVar6 == iVar11) {
      piVar12 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar12 = (int *)0x0;
      }
      iVar11 = piVar12[1];
      if (iVar11 != 0) {
        LOCK();
        *(int *)(iVar11 + 4) = *(int *)(iVar11 + 4) + 1;
        UNLOCK();
        iVar11 = piVar12[1];
      }
      uStack_14 = 0;
      FUN_00b7cc80(*piVar12,iVar11,uVar3,uVar4,uVar1,uVar2,uVar7,
                   CONCAT31((int3)((uint)puVar9 >> 8),uVar5));
      ExceptionList = pvStack_1c;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24938 ; VA 0x00b7aca0 ; FUN_00b7aca0 */

undefined4 * __thiscall
FUN_00b7aca0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f774b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(enum_RBX::InputObject::UserInputType),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_008882f0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = thunk_FUN_00b84a30();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar2;
    iStack_e4 = FUN_00b84c10();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = thunk_FUN_00b84a30();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24939 ; VA 0x00b7ae20 ; FUN_00b7ae20 */

undefined4 * __thiscall
FUN_00b7ae20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f774b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::UserInputService,bool___cdecl(enum_RBX::InputObject::UserInputType),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088daf0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = thunk_FUN_00b84a30();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar2;
    iStack_e4 = FUN_00b84c10();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = thunk_FUN_00b84a30();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24940 ; VA 0x00b7afb0 ; FUN_00b7afb0 */

undefined4 * __thiscall
FUN_00b7afb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined auStack_458 [1080];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f77ad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_9,param_10,param_11);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(param_7);
  thunk_FUN_00d82070();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  FUN_0086e3d0(param_8);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_458,&puStack_20,param_9);
  iStack_8._0_1_ = 6;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 7;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_458,0xd8,5,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24941 ; VA 0x00b7b160 ; FUN_00b7b160 */

undefined4 * __thiscall
FUN_00b7b160(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined auStack_458 [1080];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f780d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_9,param_10,param_11);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(param_7);
  thunk_FUN_00d82070();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  FUN_0086e3d0(param_8);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_458,&puStack_20,param_9);
  iStack_8._0_1_ = 6;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 7;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_458,0xd8,5,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24942 ; VA 0x00b7b310 ; FUN_00b7b310 */

undefined4 *
FUN_00b7b310(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7841;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_5,CONCAT44(uStack_28,uStack_2c),0);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::UserInputService::*)(bool)>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_5);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::UserInputService::*)(bool)>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 24943 ; VA 0x00b7b450 ; FUN_00b7b450 */

undefined4 * __thiscall
FUN_00b7b450(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7871;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_5,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::UserInputService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::UserInputService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24944 ; VA 0x00b7b590 ; FUN_00b7b590 */

undefined4 *
FUN_00b7b590(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f78ac;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_6,CONCAT44(uStack_28,uStack_2c),0);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool)>*_(__thiscall_RBX::UserInputService::*)(bool)>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,param_6);
  iStack_8._0_1_ = 3;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool)>*_(__thiscall_RBX::UserInputService::*)(bool)>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 24945 ; VA 0x00b7b700 ; FUN_00b7b700 */

undefined4 * __thiscall
FUN_00b7b700(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f78e1;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_5,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::InputObject::UserInputType),class_rbx::signal<void___cdecl(enum_RBX::InputObject::UserInputType)>,class_rbx::signal<void___cdecl(enum_RBX::InputObject::UserInputType)>_RBX::UserInputService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  thunk_FUN_00b84a30();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::InputObject::UserInputType),class_rbx::signal<void___cdecl(enum_RBX::InputObject::UserInputType)>,class_rbx::signal<void___cdecl(enum_RBX::InputObject::UserInputType)>_RBX::UserInputService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24946 ; VA 0x00b7b840 ; FUN_00b7b840 */

undefined4 * __thiscall
FUN_00b7b840(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,param_3,param_4,CONCAT44(uStack_1c,uStack_20),0);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::UserInputService::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::UserInputService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::UserInputService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24947 ; VA 0x00b7b910 ; FUN_00b7b910 */

/* WARNING: Removing unreachable block (ram,0x00b7b9a3) */

int * __thiscall
FUN_00b7b910(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f790b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088d730();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24948 ; VA 0x00b7b9c0 ; FUN_00b7b9c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_00b7b9c0(undefined *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint unaff_EBX;
  undefined4 *puVar5;
  float10 fVar6;
  longlong lVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7930;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  fVar6 = (float10)FUN_01725280(((double)*(int *)(param_2 + 8) +
                                (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 8) >> 0x1f)]) /
                                (double)*(float *)(param_2 + 0xc));
  if ((double)fVar6 + DAT_018c0d60 < _DAT_018c4e98) {
    FUN_016f3eb1();
  }
  uVar3 = FUN_00588320();
  *(undefined4 *)(param_1 + 4) = uVar3;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  if (*(int *)(param_2 + 8) != 0) {
    FUN_005d2b00();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(param_2 + 8) == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    lVar7 = (ulonglong)unaff_EBX << 0x20;
    puVar2 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar5 != (undefined4 *)0x0) {
      uVar3 = (undefined4)((ulonglong)lVar7 >> 0x20);
      lVar7 = CONCAT44(uVar3,0x10);
      puVar4 = (undefined4 *)FUN_01674e20(0x10,uVar3);
      *puVar4 = 0;
      puVar4[1] = 0;
      *(undefined8 *)(puVar4 + 2) = 0;
      puVar4[2] = puVar5[2];
      puVar4[3] = puVar5[3];
      puVar4[1] = puVar5[1];
      *puVar2 = puVar4;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar1 = (undefined4 *)*puVar2;
      puVar5 = (undefined4 *)*puVar5;
      puVar4 = (undefined4 *)
               (*(int *)(param_1 + 0x14) + ((uint)puVar1[1] % *(uint *)(param_1 + 4)) * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar1[1] % *(uint *)(param_1 + 4)) * 4) == 0)
      {
        *puVar4 = puVar2;
        puVar2 = puVar1;
      }
      else {
        *puVar2 = *puVar1;
        *puVar1 = *(undefined4 *)*puVar4;
        *(undefined4 **)*puVar4 = puVar1;
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24949 ; VA 0x00b7bb80 ; FUN_00b7bb80 */

undefined4 * __fastcall FUN_00b7bb80(undefined4 *param_1)

{
  undefined4 *puVar1;
  bool bVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7c50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::UserInputService,class_RBX::ServiceInstance>::
             vftable;
  uVar4 = FUN_00b7a090();
  param_1[3] = uVar4;
  *param_1 = RBX::UserInputService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  puVar1 = param_1 + 0x4d;
  uStack_8._0_1_ = 0x2d;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x4e] = 0;
  puStack_18 = puVar1;
  uVar4 = FUN_00575b10();
  *puVar1 = uVar4;
  *(undefined2 *)(param_1 + 0x50) = 0;
  *(undefined *)((int)param_1 + 0x142) = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0x3f800000;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0x3f800000;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0x3f800000;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0x10000;
  param_1[0x65] = 0;
  *(undefined *)(param_1 + 0x66) = 0;
  *(undefined *)(param_1 + 0x68) = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0;
  *(undefined *)(param_1 + 0x7f) = 1;
  *(undefined *)(param_1 + 0x80) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x81] = uVar4;
  param_1[0x82] = 0;
  param_1[0x83] = 0x3f800000;
  param_1[0x84] = 0;
  param_1[0x85] = 0;
  *(undefined *)(param_1 + 0x86) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x87] = uVar4;
  param_1[0x88] = 0;
  param_1[0x89] = 0x3f800000;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  *(undefined2 *)(param_1 + 0x8c) = 0x101;
  param_1[0x8d] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x3a);
  if ((DAT_01d67770 == 0x13) || (DAT_01d67770 < 0xe)) {
    switch(DAT_01d67770) {
    default:
      if ((DAT_01ef1771 == '\0') || (cVar3 = FUN_00b82a50(), cVar3 == '\0')) {
        bVar2 = false;
      }
      else {
        bVar2 = true;
      }
      uVar4 = 7;
      if (!bVar2) {
        uVar4 = 4;
      }
      param_1[0x67] = uVar4;
      if (*(char *)((int)param_1 + 0x195) != '\x01') {
        *(undefined *)((int)param_1 + 0x195) = 1;
        FUN_008a4940(&DAT_0212d858);
      }
      if (*(char *)(param_1 + 0x65) != '\x01') {
        *(undefined *)(param_1 + 0x65) = 1;
        FUN_008a4940(&DAT_0212d820);
      }
      if (DAT_01d67774 != '\0') {
        uStack_1c = 0;
        puStack_18 = (undefined4 *)0x0;
        uStack_24 = 0;
        uStack_20 = 0;
        uStack_2c = 0;
        uStack_28 = 0x42000000;
        uStack_34 = 0;
        uStack_30 = 0;
        FUN_00b83ff0(&uStack_34,&uStack_2c,&uStack_24,&uStack_1c);
      }
      break;
    case 2:
    case 3:
      param_1[0x67] = 7;
      if (*(char *)((int)param_1 + 0x193) != '\x01') {
        *(undefined *)((int)param_1 + 0x193) = 1;
        FUN_008a4940(&DAT_0212d7e8);
      }
      if (DAT_01d67774 != '\0') {
        uStack_34 = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_28 = 0;
        uStack_24 = 0;
        uStack_20 = 0x42200000;
        uStack_1c = 0;
        puStack_18 = (undefined4 *)0x41c00000;
        FUN_00b83ff0(&uStack_1c,&uStack_24,&uStack_2c,&uStack_34);
      }
      break;
    case 4:
      param_1[0x67] = 0xc;
      if (*(char *)((int)param_1 + 0x196) != '\x01') {
        *(undefined *)((int)param_1 + 0x196) = 1;
        FUN_008a4940(&DAT_0212d890);
      }
      break;
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
      goto switchD_00b7c08f_caseD_5;
    }
  }
  else {
switchD_00b7c08f_caseD_5:
    param_1[0x67] = 0x16;
  }
  uVar4 = FUN_00b82fc0(&DAT_01d6d1f4);
  param_1[0x4f] = uVar4;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24950 ; VA 0x00b7c240 ; FUN_00b7c240 */

void __fastcall FUN_00b7c240(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::UserInputService>::vftable;
  uVar1 = FUN_00b7a090(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24951 ; VA 0x00b7c280 ; FUN_00b7c280 */

void __fastcall FUN_00b7c280(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056b650();
        iVar2 = iVar2 + 0x14;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x14) * 0x14;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 24952 ; VA 0x00b7c300 ; FUN_00b7c300 */

void __fastcall FUN_00b7c300(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00b7a1b0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x14) * 0x14;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 24953 ; VA 0x00b7c380 ; FUN_00b7c380 */

void __fastcall FUN_00b7c380(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::UserInputService::vftable;
  FUN_00612320();
  FUN_006123a0();
  FUN_00b7c300();
  FUN_00641040();
  FUN_00b7c280();
  FUN_00641040();
  LOCK();
  iVar1 = param_1[0x6e];
  param_1[0x6e] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  LOCK();
  iVar1 = param_1[0x6c];
  param_1[0x6c] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  LOCK();
  iVar1 = param_1[0x6a];
  param_1[0x6a] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  piVar3 = (int *)param_1[0x62];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = piVar3[1] + -1;
    piVar3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar1 = piVar3[2] + -1;
      piVar3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x60];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = piVar3[1] + -1;
    piVar3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar1 = piVar3[2] + -1;
      piVar3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x52];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = piVar3[1] + -1;
    piVar3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar1 = piVar3[2] + -1;
      piVar3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar1 = param_1[0x4d];
  piVar3 = param_1 + 0x4d;
  uStack_8 = 0;
  FUN_005766d0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*piVar3 + 4) = iVar1;
  *(int *)*piVar3 = iVar1;
  *(int *)(*piVar3 + 8) = iVar1;
  param_1[0x4e] = 0;
  FUN_01674ea0(*piVar3,0x30);
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar1 = param_1[0x35];
  if (iVar1 != 0) {
    piVar3 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  iVar1 = param_1[0x34];
  if (iVar1 != 0) {
    piVar3 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24954 ; VA 0x00b7c6f0 ; FUN_00b7c6f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b7c6f0(int param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7c68;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  uVar9 = uVar2 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar2 == puVar6[1]) {
        if (uVar2 == puVar6[2]) {
          if (puVar6 != (undefined4 *)0x0) {
            return puVar6 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00619db0();
  _DAT_0000000c = 0;
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar9 = uVar3 + 1;
  _DAT_00000008 = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + *(int *)(param_1 + 8));
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar6;
      while (puVar4 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar1 = (int)puVar6;
          puVar6 = puVar4;
        }
        else {
          *puVar6 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar2 % *(uint *)(param_1 + 4)) * 4);
  _DAT_00000004 = uVar2;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *piVar1 = (int)piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 24955 ; VA 0x00b7c8b0 ; FUN_00b7c8b0 */

uint * __thiscall FUN_00b7c8b0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7c88;
  pvStack_10 = ExceptionList;
  uVar9 = *param_2;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&iStack_14,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 == 0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0x10);
    puVar1 = (uint *)(piVar4 + 2);
    *piVar4 = 0;
    piVar4[1] = 0;
    puVar1[0] = 0;
    puVar1[1] = 0;
    *puVar1 = uVar9;
    if (piVar4 + 3 != (int *)0x0) {
      *(undefined *)(piVar4 + 3) = 0;
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar5 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      iStack_14 = 1;
      uVar7 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar10;
        while (puVar3 != (undefined4 *)0x0) {
          piVar8 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar8 = (int)puVar10;
            puVar10 = puVar3;
          }
          else {
            *puVar10 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar8;
            *(undefined4 **)*piVar8 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar10;
        }
      }
    }
    piVar4[1] = uVar9;
    uVar9 = uVar9 % *(uint *)(param_1 + 4);
    piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (piVar8 == (int *)0x0) {
      piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar8 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar10 = piVar8;
      *piVar4 = *piVar8;
    }
    else {
      *piVar4 = *piVar8;
      piVar8 = (int *)*puVar10;
    }
    *piVar8 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return (uint *)(iStack_14 + 8);
}



/* FUNCTION 24956 ; VA 0x00b7ca70 ; FUN_00b7ca70 */

/* WARNING: Removing unreachable block (ram,0x00b7cad1) */
/* WARNING: Removing unreachable block (ram,0x00b7cae1) */
/* WARNING: Removing unreachable block (ram,0x00b7cae7) */

void __fastcall FUN_00b7ca70(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7cb0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24957 ; VA 0x00b7cb3c ; Catch@00b7cb3c */

undefined * Catch_00b7cb3c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00b7cb4d;
}



/* FUNCTION 24958 ; VA 0x00b7cb60 ; FUN_00b7cb60 */

/* WARNING: Removing unreachable block (ram,0x00b7cbbe) */
/* WARNING: Removing unreachable block (ram,0x00b7cbce) */
/* WARNING: Removing unreachable block (ram,0x00b7cbd4) */

void * __thiscall FUN_00b7cb60(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24959 ; VA 0x00b7cc5b ; Catch@00b7cc5b */

undefined * Catch_00b7cc5b(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b7cc6c;
}



/* FUNCTION 24960 ; VA 0x00b7cc80 ; FUN_00b7cc80 */

/* WARNING: Removing unreachable block (ram,0x00b7ccd2) */
/* WARNING: Removing unreachable block (ram,0x00b7cce2) */
/* WARNING: Removing unreachable block (ram,0x00b7cce8) */

void * __thiscall FUN_00b7cc80(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7d08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24961 ; VA 0x00b7cd65 ; Catch@00b7cd65 */

undefined * Catch_00b7cd65(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b7cd76;
}



/* FUNCTION 24962 ; VA 0x00b7cd90 ; FUN_00b7cd90 */

/* WARNING: Removing unreachable block (ram,0x00b7cde2) */
/* WARNING: Removing unreachable block (ram,0x00b7cdf2) */
/* WARNING: Removing unreachable block (ram,0x00b7cdf8) */

void * __thiscall FUN_00b7cd90(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7d38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24963 ; VA 0x00b7ce69 ; Catch@00b7ce69 */

undefined * Catch_00b7ce69(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b7ce7a;
}



/* FUNCTION 24964 ; VA 0x00b7ce90 ; FUN_00b7ce90 */

/* WARNING: Removing unreachable block (ram,0x00b7cee2) */
/* WARNING: Removing unreachable block (ram,0x00b7cef2) */
/* WARNING: Removing unreachable block (ram,0x00b7cef8) */

void * __thiscall FUN_00b7ce90(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7d68;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24965 ; VA 0x00b7cf66 ; Catch@00b7cf66 */

undefined * Catch_00b7cf66(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b7cf77;
}



/* FUNCTION 24966 ; VA 0x00b7cf90 ; FUN_00b7cf90 */

/* WARNING: Removing unreachable block (ram,0x00b7cfee) */
/* WARNING: Removing unreachable block (ram,0x00b7cffe) */
/* WARNING: Removing unreachable block (ram,0x00b7d004) */

void * __thiscall FUN_00b7cf90(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f7d98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24967 ; VA 0x00b7d08e ; Catch@00b7d08e */

undefined * Catch_00b7d08e(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b7d09f;
}



/* FUNCTION 24968 ; VA 0x00b7d0c0 ; FUN_00b7d0c0 */

/* WARNING: Removing unreachable block (ram,0x00b7d11e) */
/* WARNING: Removing unreachable block (ram,0x00b7d12e) */
/* WARNING: Removing unreachable block (ram,0x00b7d134) */

void __fastcall FUN_00b7d0c0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7dc0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24969 ; VA 0x00b7d18b ; Catch@00b7d18b */

undefined * Catch_00b7d18b(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00b7d19c;
}



/* FUNCTION 24970 ; VA 0x00b7d1b0 ; FUN_00b7d1b0 */

int __thiscall FUN_00b7d1b0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),8);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 24971 ; VA 0x00b7d220 ; FUN_00b7d220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b7d220(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DeviceTypeEnum>::vftable;
  _DAT_01f178bc = _DAT_01f178bc + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24972 ; VA 0x00b7d250 ; FUN_00b7d250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b7d250(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiSwipeDirection>::vftable;
  _DAT_01ef19b0 = _DAT_01ef19b0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24973 ; VA 0x00b7d280 ; FUN_00b7d280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b7d280(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PlatformEnum>::vftable;
  _DAT_01f178b4 = _DAT_01f178b4 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24974 ; VA 0x00b7d2b0 ; FUN_00b7d2b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b7d2b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::VRService::UserCFrame>::vftable;
  _DAT_01ef3320 = _DAT_01ef3320 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24975 ; VA 0x00b7d2e0 ; FUN_00b7d2e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b7d2e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::InputObject::UserInputType>::vftable;
  _DAT_01f0fb98 = _DAT_01f0fb98 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24976 ; VA 0x00b7d310 ; FUN_00b7d310 */

undefined4 * __thiscall FUN_00b7d310(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 24977 ; VA 0x00b7d340 ; FUN_00b7d340 */

undefined4 * __thiscall FUN_00b7d340(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 24978 ; VA 0x00b7d370 ; FUN_00b7d370 */

undefined4 * __thiscall FUN_00b7d370(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::MouseService::MouseType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 24979 ; VA 0x00b7d3a0 ; FUN_00b7d3a0 */

undefined4 * __thiscall FUN_00b7d3a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::MouseService::OverrideMouseIconBehavior>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 24980 ; VA 0x00b7d3d0 ; FUN_00b7d3d0 */

undefined4 * __thiscall FUN_00b7d3d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24981 ; VA 0x00b7d400 ; FUN_00b7d400 */

undefined4 * __thiscall FUN_00b7d400(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::MouseService::MouseType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24982 ; VA 0x00b7d430 ; FUN_00b7d430 */

undefined4 * __thiscall FUN_00b7d430(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::MouseService::OverrideMouseIconBehavior>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24983 ; VA 0x00b7d460 ; FUN_00b7d460 */

undefined4 __thiscall FUN_00b7d460(undefined4 param_1,byte param_2)

{
  FUN_00b7c380();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x238);
  }
  return param_1;
}



/* FUNCTION 24984 ; VA 0x00b7d490 ; FUN_00b7d490 */

int __thiscall FUN_00b7d490(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006123a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 24985 ; VA 0x00b7d4f0 ; FUN_00b7d4f0 */

void __fastcall FUN_00b7d4f0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 0x20);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_006123a0();
    FUN_01674ea0(iVar2,0x30);
  }
  return;
}



/* FUNCTION 24986 ; VA 0x00b7d540 ; FUN_00b7d540 */

undefined4 * __thiscall
FUN_00b7d540(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f84a1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b7fa30;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24987 ; VA 0x00b7d6e0 ; FUN_00b7d6e0 */

undefined4 * __thiscall
FUN_00b7d6e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f84e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b7fbc0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24988 ; VA 0x00b7d880 ; FUN_00b7d880 */

undefined4 * __thiscall
FUN_00b7d880(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8521;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b7fd70;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24989 ; VA 0x00b7da20 ; FUN_00b7da20 */

undefined4 * __thiscall
FUN_00b7da20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8561;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b7ff20;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24990 ; VA 0x00b7dbc0 ; FUN_00b7dbc0 */

undefined4 * __thiscall
FUN_00b7dbc0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f85a1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b80070;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24991 ; VA 0x00b7dd60 ; FUN_00b7dd60 */

undefined4 * __thiscall
FUN_00b7dd60(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017f85c0;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    (**(code **)(param_1 + 0x38))(1);
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_4;
    piStack_14 = param_5;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00898ea0(param_2,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24992 ; VA 0x00b7de40 ; FUN_00b7de40 */

undefined4 * FUN_00b7de40(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017f85c0;
  uStack_8 = 0;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_3;
    piStack_14 = param_4;
    uStack_8 = 1;
    FUN_00898ea0(param_1,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24993 ; VA 0x00b7df20 ; FUN_00b7df20 */

undefined4 * __thiscall
FUN_00b7df20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8601;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00b801b0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24994 ; VA 0x00b7e0d0 ; FUN_00b7e0d0 */

undefined4 * __thiscall
FUN_00b7e0d0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8641;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00b80340;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24995 ; VA 0x00b7e280 ; FUN_00b7e280 */

undefined4 * __thiscall
FUN_00b7e280(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8681;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b804c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24996 ; VA 0x00b7e420 ; FUN_00b7e420 */

undefined4 * __thiscall
FUN_00b7e420(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f86c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b805c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24997 ; VA 0x00b7e5c0 ; FUN_00b7e5c0 */

undefined4 * __thiscall
FUN_00b7e5c0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8701;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b806f0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24998 ; VA 0x00b7e760 ; FUN_00b7e760 */

undefined4 * __thiscall
FUN_00b7e760(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8741;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b80840;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24999 ; VA 0x00b7e900 ; FUN_00b7e900 */

undefined4 * __thiscall
FUN_00b7e900(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8781;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b80980;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}


