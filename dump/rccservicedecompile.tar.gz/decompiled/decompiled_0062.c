/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 15500 ; VA 0x008e9e90 ; FUN_008e9e90 */

void __fastcall FUN_008e9e90(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x18);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  return;
}



/* FUNCTION 15501 ; VA 0x008e9ee0 ; FUN_008e9ee0 */

void __fastcall FUN_008e9ee0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x10) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 15502 ; VA 0x008e9f40 ; FUN_008e9f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_008e9f40(void)

{
  LOCK();
  _DAT_01ee05b4 = _DAT_01ee05b4 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 15503 ; VA 0x008e9f50 ; FUN_008e9f50 */

void FUN_008e9f50(void)

{
  FUN_0056b650();
  FUN_008ee200();
  return;
}



/* FUNCTION 15504 ; VA 0x008e9f70 ; thunk_FUN_008a9470 */

void __fastcall thunk_FUN_008a9470(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ServiceProvider::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar1 = param_1[0x18];
  uStack_8 = 0;
  FUN_0089c760(*(undefined4 *)(iVar1 + 4));
  *(int *)(param_1[0x18] + 4) = iVar1;
  *(int *)param_1[0x18] = iVar1;
  *(int *)(param_1[0x18] + 8) = iVar1;
  param_1[0x19] = 0;
  FUN_01674ea0(param_1[0x18],0x1c);
  thunk_FUN_00577ac0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15505 ; VA 0x008e9f80 ; FUN_008e9f80 */

void __fastcall FUN_008e9f80(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  while (iVar2 = iVar1, iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0x9c);
    if ((*(int *)(iVar2 + 0xa0) == param_1) && (*(int *)(iVar2 + 0xa0) != 0)) {
      iVar3 = iVar1;
      if (*(int **)(iVar2 + 0xa4) != (int *)0x0) {
        **(int **)(iVar2 + 0xa4) = iVar1;
        iVar3 = *(int *)(iVar2 + 0x9c);
      }
      if (iVar3 != 0) {
        *(undefined4 *)(iVar3 + 0xa4) = *(undefined4 *)(iVar2 + 0xa4);
      }
      **(int **)(iVar2 + 0xa0) = **(int **)(iVar2 + 0xa0) + -1;
      *(undefined4 *)(iVar2 + 0x9c) = 0;
      *(undefined4 *)(iVar2 + 0xa4) = 0;
      *(undefined4 *)(iVar2 + 0xa0) = 0;
    }
  }
  return;
}



/* FUNCTION 15506 ; VA 0x008ea000 ; FUN_008ea000 */

void __fastcall FUN_008ea000(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x50) {
    FUN_008c3510();
  }
  return;
}



/* FUNCTION 15507 ; VA 0x008ea030 ; FUN_008ea030 */

void __fastcall FUN_008ea030(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x48) {
    FUN_008c3510();
  }
  return;
}



/* FUNCTION 15508 ; VA 0x008ea060 ; FUN_008ea060 */

void __fastcall FUN_008ea060(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1,8,0xb,FUN_00550b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15509 ; VA 0x008ea0a0 ; FUN_008ea0a0 */

void __fastcall FUN_008ea0a0(uint *param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0056b650();
  uVar1 = *param_1;
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15510 ; VA 0x008ea100 ; FUN_008ea100 */

void FUN_008ea100(void)

{
  FUN_008c3510();
  return;
}



/* FUNCTION 15511 ; VA 0x008ea110 ; FUN_008ea110 */

code * __fastcall FUN_008ea110(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar4 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar4 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 15512 ; VA 0x008ea180 ; FUN_008ea180 */

void __fastcall FUN_008ea180(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x10);
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15513 ; VA 0x008ea1e0 ; FUN_008ea1e0 */

void __fastcall FUN_008ea1e0(uint *param_1)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  
  uVar2 = *param_1;
  if (uVar2 != 0) {
    piVar3 = (int *)(uVar2 + 4);
    LOCK();
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if ((iVar1 == 1) &&
       (piVar3 = (int *)(-(uint)(piVar3 != (int *)0x0) & uVar2), piVar3 != (int *)0x0)) {
      (**(code **)(*piVar3 + 4))(1);
    }
  }
  return;
}



/* FUNCTION 15514 ; VA 0x008ea210 ; FUN_008ea210 */

code * __fastcall FUN_008ea210(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar4 = *(code **)(param_1 + 8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar4 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 15515 ; VA 0x008ea280 ; thunk_FUN_008c3510 */

void __fastcall thunk_FUN_008c3510(uint *param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[8];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  uVar1 = *param_1;
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15516 ; VA 0x008ea290 ; FUN_008ea290 */

void __fastcall FUN_008ea290(undefined4 *param_1)

{
  FUN_008ef6b0();
  FUN_01674ea0(*param_1,0x28);
  return;
}



/* FUNCTION 15517 ; VA 0x008ea2b0 ; FUN_008ea2b0 */

void __fastcall FUN_008ea2b0(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_005f6cc0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15518 ; VA 0x008ea300 ; FUN_008ea300 */

void __fastcall FUN_008ea300(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_008e38f0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x1c4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15519 ; VA 0x008ea360 ; FUN_008ea360 */

void __fastcall FUN_008ea360(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_008e38f0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x1c4);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15520 ; VA 0x008ea430 ; FUN_008ea430 */

void __fastcall FUN_008ea430(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        piVar3 = (int *)puVar7[3];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x20);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 15521 ; VA 0x008ea510 ; FUN_008ea510 */

void __fastcall FUN_008ea510(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00b9ecc0();
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 15522 ; VA 0x008ea530 ; FUN_008ea530 */

void __fastcall FUN_008ea530(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x10);
  }
  return;
}



/* FUNCTION 15523 ; VA 0x008ea550 ; FUN_008ea550 */

void __fastcall FUN_008ea550(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0x30);
    if (iVar2 != 0) {
      uVar4 = *(int *)(iVar1 + 0x38) - iVar2 & 0xfffffff8;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_008ea644;
      }
      FUN_01674ea0(iVar3,uVar4);
      *(undefined4 *)(iVar1 + 0x30) = 0;
      *(undefined4 *)(iVar1 + 0x34) = 0;
      *(undefined4 *)(iVar1 + 0x38) = 0;
    }
    iVar2 = *(int *)(iVar1 + 0x1c);
    if (iVar2 != 0) {
      uVar4 = *(int *)(iVar1 + 0x24) - iVar2 & 0xfffffff8;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_008ea644;
      }
      FUN_01674ea0(iVar3,uVar4);
      *(undefined4 *)(iVar1 + 0x1c) = 0;
      *(undefined4 *)(iVar1 + 0x20) = 0;
      *(undefined4 *)(iVar1 + 0x24) = 0;
    }
    iVar2 = *(int *)(iVar1 + 8);
    if (iVar2 != 0) {
      uVar4 = *(int *)(iVar1 + 0x10) - iVar2 & 0xfffffff8;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_008ea644:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
      *(undefined4 *)(iVar1 + 8) = 0;
      *(undefined4 *)(iVar1 + 0xc) = 0;
      *(undefined4 *)(iVar1 + 0x10) = 0;
    }
    FUN_01674ea0(iVar1,0x70);
  }
  return;
}



/* FUNCTION 15524 ; VA 0x008ea650 ; FUN_008ea650 */

void __fastcall FUN_008ea650(int *param_1)

{
  if (*param_1 != 0) {
    FUN_008ec400(*param_1);
  }
  return;
}



/* FUNCTION 15525 ; VA 0x008ea660 ; FUN_008ea660 */

void __fastcall FUN_008ea660(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_008e38f0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x1c4);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15526 ; VA 0x008ea670 ; FUN_008ea670 */

void __fastcall FUN_008ea670(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        piVar3 = (int *)puVar7[3];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x20);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 15527 ; VA 0x008ea680 ; thunk_FUN_008ee280 */

void __fastcall thunk_FUN_008ee280(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3510();
        iVar2 = iVar2 + 0x50;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x50) * 0x50;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 15528 ; VA 0x008ea690 ; FUN_008ea690 */

void __fastcall FUN_008ea690(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3510();
        iVar2 = iVar2 + 0x48;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x48) * 0x48;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 15529 ; VA 0x008ea710 ; thunk_FUN_00f50100 */

void __fastcall thunk_FUN_00f50100(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::CallbackDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 15530 ; VA 0x008ea720 ; FUN_008ea720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_008ea720(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::DataModel::vftable;
  param_1[1] = RBX::DataModel::vftable;
  param_1[2] = RBX::DataModel::vftable;
  param_1[3] = RBX::DataModel::vftable;
  LOCK();
  _DAT_01ee05b0 = _DAT_01ee05b0 + -1;
  UNLOCK();
  piVar2 = (int *)param_1[0x10f];
  puStack_14 = param_1;
  if (*piVar2 - (int)piVar2 != 0 || piVar2[1] - (int)piVar2 != 0) {
    FUN_0151aa60(*piVar2 - (int)piVar2,piVar2[1] - (int)piVar2);
  }
  FUN_008ea360();
  piVar2 = (int *)param_1[0x134];
  uStack_8 = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 8))();
      }
    }
  }
  uVar6 = param_1[0x130];
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    iVar3 = param_1[299];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_008eaee9;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x12f] = 0;
  param_1[0x130] = 0xf;
  *(undefined *)(param_1 + 299) = 0;
  FUN_008ef6b0();
  FUN_01674ea0(param_1[0x124],0x28);
  iVar3 = param_1[0x123];
  if (iVar3 != 0) {
    FUN_00b9ecc0();
    FUN_01674ea0(iVar3,0x18);
  }
  if (param_1[0x122] != 0) {
    FUN_01674ea0(param_1[0x122],0x10);
  }
  uVar6 = param_1[0x11f];
  if (0xf < uVar6) {
    iVar3 = param_1[0x11a];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_008eaee9;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x11e] = 0;
  param_1[0x11f] = 0xf;
  *(undefined *)(param_1 + 0x11a) = 0;
  if (param_1[0x115] != 0) {
    FUN_01674ea0(param_1[0x115],8);
  }
  if (param_1[0x10f] != 0) {
    FUN_01674ea0(param_1[0x10f],8);
  }
  uVar6 = param_1[0x10e];
  if (0xf < uVar6) {
    iVar3 = param_1[0x109];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_008eaee9;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x10d] = 0;
  param_1[0x10e] = 0xf;
  *(undefined *)(param_1 + 0x109) = 0;
  uStack_8 = 1;
  FUN_005f6cc0(&puStack_14,*(undefined4 *)param_1[0x106],(undefined4 *)param_1[0x106]);
  FUN_01674ea0(param_1[0x106],0x30);
  FUN_016dedfb(param_1 + 0xfa);
  uStack_8 = 2;
  FUN_016f32d1(param_1 + 0xe4,8,0xb,FUN_00550b30);
  uStack_8 = 0xffffffff;
  FUN_016dedfb(param_1 + 0xd8);
  uVar6 = param_1[0xd7];
  if (0xf < uVar6) {
    iVar3 = param_1[0xd2];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_008eaee9;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0xd6] = 0;
  param_1[0xd7] = 0xf;
  *(undefined *)(param_1 + 0xd2) = 0;
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = param_1[0xd0];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[0xcc];
  piVar2 = param_1 + 0xcc;
  uStack_8 = 4;
  FUN_005766d0(*(undefined4 *)(iVar3 + 4));
  uStack_8 = 0xffffffff;
  *(int *)(*piVar2 + 4) = iVar3;
  *(int *)*piVar2 = iVar3;
  *(int *)(*piVar2 + 8) = iVar3;
  param_1[0xcd] = 0;
  FUN_01674ea0(*piVar2,0x30);
  uVar6 = param_1[0xcb];
  if (0xf < uVar6) {
    iVar3 = param_1[0xc6];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_008eaee9;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0xca] = 0;
  param_1[0xcb] = 0xf;
  *(undefined *)(param_1 + 0xc6) = 0;
  FUN_016790b0();
  uVar6 = param_1[0xb6];
  uStack_8 = 5;
  if (uVar6 != 0) {
    if ((uVar6 & 1) == 0) {
      if (*(code **)(uVar6 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar6 & 0xfffffffe))(param_1 + 0xb8,param_1 + 0xb8,2);
      }
    }
    param_1[0xb6] = 0;
  }
  FUN_00872220();
  FUN_00872220();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar6 = param_1[0xa7];
  if (0xf < uVar6) {
    iVar3 = param_1[0xa2];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_008eaee9;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0xa6] = 0;
  param_1[0xa7] = 0xf;
  *(undefined *)(param_1 + 0xa2) = 0;
  FUN_006d2070();
  iVar3 = param_1[0x9b];
  if (iVar3 != 0) {
    uVar6 = param_1[0x9d] - iVar3 & 0xfffffff8;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_008eaee9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    param_1[0x9b] = 0;
    param_1[0x9c] = 0;
    param_1[0x9d] = 0;
  }
  piVar2 = (int *)param_1[0x99];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_008ea550();
  FUN_006e27a0();
  FUN_016dedfb(param_1 + 0x78);
  if ((undefined4 *)param_1[0x72] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x72])(1);
  }
  piVar2 = (int *)param_1[0x71];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x6f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x6d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x6b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x69];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x67];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x65];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[99];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x61];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  if ((undefined4 *)param_1[0x21] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x21])(1);
  }
  FUN_008a9470();
  param_1[2] = RBX::TaskScheduler::Arbiter::vftable;
  LOCK();
  _DAT_01ee05b4 = _DAT_01ee05b4 + -1;
  UNLOCK();
  *param_1 = RBX::IMetric::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15531 ; VA 0x008eaef0 ; FUN_008eaef0 */

void __fastcall FUN_008eaef0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0xd4) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 0xd4) + 8))(param_1 + 0xd8);
  }
  uStack_8 = 1;
  if (*(int *)(param_1 + 4) != 0) {
    (**(code **)(*(int *)(param_1 + 4) + 8))(param_1 + 8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15532 ; VA 0x008eaf60 ; FUN_008eaf60 */

void __fastcall FUN_008eaf60(int param_1)

{
  int *piVar1;
  int iVar2;
  
  FUN_008ee150();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x130),8);
  *(undefined4 *)(param_1 + 0x130) = 0;
  piVar1 = *(int **)(param_1 + 300);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  return;
}



/* FUNCTION 15533 ; VA 0x008eafb0 ; FUN_008eafb0 */

int __fastcall FUN_008eafb0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  char *pcVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4202 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01ee4202,"LegacyLock::~Implementation type(%d), events (%p)",param_1[2],
                 param_1[4]);
  }
  iVar7 = param_1[6];
  param_1[6] = 0;
  if (iVar7 != 0) {
    FUN_008ec400(iVar7);
  }
  if (*(char *)(param_1 + 1) == '\0') {
    if (DAT_01ee4202 == '\0') goto LAB_008eb0bb;
    uVar10 = param_1[2];
    uVar9 = *param_1;
    pcVar8 = "LegacyLock::RecursivelyReleased DataModel: (%p), type(%d)";
  }
  else {
    FUN_005789c0(&DAT_01ee05f4,&LAB_0090a080);
    puVar4 = (undefined4 *)FUN_00909ee0();
    uVar10 = param_1[3];
    puVar5 = (undefined4 *)FUN_01674e20(4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar10;
    }
    puVar6 = (undefined4 *)FUN_01689e40(puVar4);
    if (puVar6 != puVar5) {
      uVar10 = *puVar4;
      iVar7 = puVar4[1];
      if (iVar7 != 0) {
        LOCK();
        *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
        UNLOCK();
      }
      FUN_0168a720(puVar4,uVar10,iVar7,puVar5,1);
    }
    FUN_0151f3f0();
    if (DAT_01ee4202 == '\0') goto LAB_008eb0bb;
    uVar10 = param_1[2];
    uVar9 = *param_1;
    pcVar8 = "LegacyLock::Released DataModel: (%p), type(%d)";
  }
  FUN_01677520(DAT_01ee4202,pcVar8,uVar9,uVar10);
LAB_008eb0bb:
  iVar7 = param_1[6];
  if (iVar7 != 0) {
    iVar7 = FUN_008ec400(iVar7);
  }
  piVar3 = (int *)param_1[5];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 15534 ; VA 0x008eb110 ; FUN_008eb110 */

void __fastcall FUN_008eb110(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_008eafb0();
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 15535 ; VA 0x008eb130 ; FUN_008eb130 */

void __fastcall FUN_008eb130(int *param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    iVar2 = *param_1 + 1000;
    ExceptionList = &pvStack_10;
    iVar1 = FUN_016dee6d(iVar2);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    if ((DAT_01d635a4 != '\0') &&
       (((*(int *)(*param_1 + 0x2a0) != 1 || (*(int *)(*param_1 + 0x2a4) != 0)) ||
        (iVar1 = GetCurrentThreadId(), *(int *)(*param_1 + 0x2a8) != iVar1)))) {
      FUN_01675310("InvalidAccess",&DAT_018bc9b8);
    }
    *(undefined4 *)(*param_1 + 0x2a0) = 0;
    *(undefined4 *)(*param_1 + 0x2a8) = 0;
    uStack_8 = 0;
    iVar1 = FUN_016deec8(iVar2);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    ExceptionList = pvStack_10;
    return;
  }
  return;
}



/* FUNCTION 15536 ; VA 0x008eb200 ; FUN_008eb200 */

void __fastcall FUN_008eb200(int *param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    iVar2 = *param_1 + 1000;
    ExceptionList = &pvStack_10;
    iVar1 = FUN_016dee6d(iVar2);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    if ((DAT_01d635a4 != '\0') &&
       ((*(int *)(*param_1 + 0x2a0) != 1 ||
        (iVar1 = GetCurrentThreadId(), *(int *)(*param_1 + 0x2a8) != iVar1)))) {
      FUN_01675310("InvalidAccess",&DAT_018bc9b8);
    }
    *(int *)(*param_1 + 0x2a8) = param_1[1];
    uStack_8 = 0;
    iVar1 = FUN_016deec8(iVar2);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    ExceptionList = pvStack_10;
    return;
  }
  return;
}



/* FUNCTION 15537 ; VA 0x008eb2b0 ; FUN_008eb2b0 */

undefined4 __thiscall FUN_008eb2b0(undefined4 param_1,uint *param_2)

{
  uint uVar1;
  uint uStack_30;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2be8;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uVar1 = *param_2;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_30 = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_28,0);
    }
    else {
      uStack_28 = param_2[2];
      uStack_24 = param_2[3];
      uStack_20 = param_2[4];
      uStack_1c = param_2[5];
      uStack_18 = *(undefined8 *)(param_2 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  FUN_0090cc70(param_1);
  uStack_8 = 1;
  if (((uStack_30 != 0) && ((uStack_30 & 1) == 0)) &&
     (*(code **)(uStack_30 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_30 & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15538 ; VA 0x008eb360 ; FUN_008eb360 */

undefined4 __thiscall FUN_008eb360(undefined4 param_1,uint *param_2)

{
  uint uVar1;
  uint uStack_30;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2c08;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uVar1 = *param_2;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_30 = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_28,0);
    }
    else {
      uStack_28 = param_2[2];
      uStack_24 = param_2[3];
      uStack_20 = param_2[4];
      uStack_1c = param_2[5];
      uStack_18 = *(undefined8 *)(param_2 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  FUN_0090cd00(param_1);
  uStack_8 = 1;
  if (((uStack_30 != 0) && ((uStack_30 & 1) == 0)) &&
     (*(code **)(uStack_30 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_30 & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15539 ; VA 0x008eb410 ; FUN_008eb410 */

undefined4 * __thiscall FUN_008eb410(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  iVar2 = param_2[1];
  uVar3 = *param_2;
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  *param_1 = uVar3;
  piVar4 = (int *)param_1[1];
  param_1[1] = iVar2;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  *(undefined *)(param_1 + 2) = *(undefined *)(param_2 + 2);
  *param_2 = 0;
  piVar4 = (int *)param_2[1];
  param_2[1] = 0;
  uStack_8 = 1;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  *(undefined *)(param_2 + 2) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15540 ; VA 0x008eb4e0 ; FUN_008eb4e0 */

/* WARNING: Removing unreachable block (ram,0x008eb586) */
/* WARNING: Removing unreachable block (ram,0x008eb58a) */
/* WARNING: Removing unreachable block (ram,0x008eb593) */
/* WARNING: Removing unreachable block (ram,0x008eb530) */
/* WARNING: Removing unreachable block (ram,0x008eb534) */
/* WARNING: Removing unreachable block (ram,0x008eb53d) */

int __thiscall FUN_008eb4e0(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2c30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005880d0(param_2);
  uStack_8 = 0;
  FUN_0090cc70(param_1);
  uStack_8 = 0xffffffff;
  FUN_005880d0(param_2 + 0x20);
  uStack_8 = 2;
  FUN_0090cc70(param_1 + 0x20);
  *(undefined *)(param_1 + 0x40) = *(undefined *)(param_2 + 0x40);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15541 ; VA 0x008eb5c0 ; FUN_008eb5c0 */

undefined4 * __thiscall FUN_008eb5c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uVar1 = param_2[3];
  uVar2 = param_2[4];
  param_2[3] = 0;
  param_2[4] = 0;
  param_1[3] = uVar1;
  piVar3 = (int *)param_1[4];
  param_1[4] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[2] + -1;
    piVar3[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 15542 ; VA 0x008eb620 ; FUN_008eb620 */

int __thiscall
FUN_008eb620(int param_1,int param_2,int param_3,int *param_4,int *param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  undefined **ppuVar7;
  char *pcVar8;
  char *pcVar9;
  undefined4 uVar10;
  uint in_stack_fffffde4;
  undefined auStack_1fc [80];
  undefined auStack_1ac [80];
  undefined auStack_15c [80];
  undefined auStack_10c [80];
  undefined auStack_bc [80];
  int *piStack_6c;
  int *piStack_68;
  int iStack_64;
  int *piStack_60;
  uint uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2cc4;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_1c != 0) {
    if (((param_2 == 1) && (param_5 == (int *)0x0)) && (param_3 != 0)) {
      iStack_14 = param_3;
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      piStack_6c = param_5;
      piStack_68 = param_6;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      iStack_64 = param_3;
      piStack_60 = param_4;
      uVar3 = *(uint *)(param_1 + 8);
      uStack_8._0_1_ = 4;
      uStack_5c = 0;
      if (uVar3 != 0) {
        uStack_5c = uVar3;
        if ((uVar3 & 1) == 0) {
          (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,&uStack_54,0);
        }
        else {
          uStack_54 = *(undefined4 *)(param_1 + 0x10);
          uStack_50 = *(undefined4 *)(param_1 + 0x14);
          uStack_4c = *(undefined4 *)(param_1 + 0x18);
          uStack_48 = *(undefined4 *)(param_1 + 0x1c);
          uStack_44 = *(undefined8 *)(param_1 + 0x20);
        }
      }
      uVar3 = *(uint *)(param_1 + 0x28);
      uStack_8._0_1_ = 5;
      uStack_3c = 0;
      if (uVar3 != 0) {
        uStack_3c = uVar3;
        if ((uVar3 & 1) == 0) {
          (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x30,&uStack_34,0);
        }
        else {
          uStack_34 = *(undefined4 *)(param_1 + 0x30);
          uStack_30 = *(undefined4 *)(param_1 + 0x34);
          uStack_2c = *(undefined4 *)(param_1 + 0x38);
          uStack_28 = *(undefined4 *)(param_1 + 0x3c);
          uStack_24 = *(undefined8 *)(param_1 + 0x40);
        }
      }
      uStack_8._0_1_ = 6;
      FUN_008e66d0(&piStack_6c);
      uStack_8._0_1_ = 7;
      uVar10 = 0;
      FUN_008e66d0(auStack_1fc);
      uStack_8._0_1_ = 8;
      FUN_008e66d0(auStack_1ac);
      uStack_8._0_1_ = 9;
      FUN_008e66d0(auStack_15c);
      uStack_8._0_1_ = 10;
      cVar5 = FUN_00585a40(auStack_bc,uVar10);
      if (cVar5 == '\0') {
        FUN_008e66d0(auStack_bc);
        uStack_8._0_1_ = 0xb;
        iVar6 = FUN_01674e20(0x50);
        uStack_8._0_1_ = 0xc;
        if (iVar6 != 0) {
          FUN_008e66d0(auStack_10c);
        }
        FUN_008e9ac0();
        FUN_008e9ac0();
        bVar4 = true;
      }
      else {
        FUN_008e9ac0();
        bVar4 = false;
      }
      FUN_008e9ac0();
      ppuVar7 = &PTR_FUN_0192d378;
      if (!bVar4) {
        ppuVar7 = (undefined **)0x0;
      }
      FUN_008e9ac0(ppuVar7);
      FUN_008e9ac0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_008e9ac0();
      FUN_00557fc0(&iStack_1c);
      iVar6 = FUN_00ae4ff0();
    }
    else {
      if (param_5 == (int *)0x0) {
        pcVar9 = "Unknown error for fetching asset async";
      }
      else {
        pcVar9 = (char *)(**(code **)(*param_5 + 4))();
      }
      in_stack_fffffde4 = in_stack_fffffde4 & 0xffffff00;
      pcVar8 = pcVar9;
      do {
        cVar5 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar5 != '\0');
      FUN_005542c0(pcVar9,(int)pcVar8 - (int)(pcVar9 + 1));
      iVar6 = FUN_005e65e0(in_stack_fffffde4);
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 15543 ; VA 0x008eb960 ; FUN_008eb960 */

int __thiscall FUN_008eb960(undefined4 *param_1,int param_2,int *param_3,int *param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  undefined uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2ce0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    pcVar5 = (char *)(**(code **)(*param_4 + 4))();
    uVar7 = 0;
    pcVar6 = pcVar5;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(pcVar5,(int)pcVar6 - (int)(pcVar5 + 1));
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar4 = FUN_0090ce40(*param_1,param_1[1],uVar7);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_2);
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar4 = FUN_0090cf60(*param_1,param_1[1]);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15544 ; VA 0x008ebaa0 ; FUN_008ebaa0 */

int __thiscall FUN_008ebaa0(undefined4 *param_1,int param_2,int *param_3,int *param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  undefined uVar8;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2d10;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (param_2 == 0) {
    uVar4 = param_1[10];
    ExceptionList = &pvStack_10;
    if (uVar4 != 0) {
      if ((uVar4 & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0xc,&uStack_38,0);
      }
      else {
        uStack_38 = param_1[0xc];
        uStack_34 = param_1[0xd];
        uStack_30 = param_1[0xe];
        uStack_2c = param_1[0xf];
        uStack_28 = *(undefined8 *)(param_1 + 0x10);
        ExceptionList = &pvStack_10;
      }
    }
    uStack_8._0_1_ = 3;
    pcVar6 = (char *)(**(code **)(*param_4 + 4))();
    uVar8 = 0;
    pcVar7 = pcVar6;
    do {
      cVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(pcVar6,(int)pcVar7 - (int)(pcVar6 + 1));
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar5 = FUN_008f72c0(*param_1,param_1[1],uVar8);
  }
  else {
    uVar4 = param_1[2];
    ExceptionList = &pvStack_10;
    if (uVar4 != 0) {
      if ((uVar4 & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 4,&uStack_38,0);
      }
      else {
        uStack_38 = param_1[4];
        uStack_34 = param_1[5];
        uStack_30 = param_1[6];
        uStack_2c = param_1[7];
        uStack_28 = *(undefined8 *)(param_1 + 8);
        ExceptionList = &pvStack_10;
      }
    }
    uStack_8._0_1_ = 2;
    FUN_0054ef60(param_2);
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar5 = FUN_008f7690(*param_1,param_1[1]);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_28 = CONCAT44(0x8ebc2f,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        uStack_28 = CONCAT44(0x8ebc3f,(undefined4)uStack_28);
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_28 = CONCAT44(0x8ebc55,(undefined4)uStack_28);
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0x8ebc64,(undefined4)uStack_28);
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15545 ; VA 0x008ebc80 ; FUN_008ebc80 */

void __fastcall FUN_008ebc80(int *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2d28;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc8;
  uVar2 = *(undefined4 *)(*param_1 + 0x1b8);
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  puStack_1c = (undefined *)&iStack_50;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  FUN_0054ef60(param_1 + 0x17);
  if (param_1[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0090b2f0(param_1[3],param_1[4]);
  uStack_40 = (uint)DAT_01d6f31c;
  uStack_3c = 1;
  puStack_44 = &uStack_2c;
  iStack_4c = param_1[0x16];
  iStack_50 = param_1[3];
  uStack_48 = uVar2;
  FUN_00a9d670();
  FUN_008ebd56();
  return;
}



/* FUNCTION 15546 ; VA 0x008ebd2d ; Catch@008ebd2d */

undefined * Catch_008ebd2d(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0054eff0(uVar1);
  FUN_005e65e0();
  return &DAT_008ebd53;
}



/* FUNCTION 15547 ; VA 0x008ebd56 ; FUN_008ebd56 */

void FUN_008ebd56(void)

{
  int *piVar1;
  int unaff_EBP;
  int unaff_ESI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (*(int *)(unaff_ESI + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(unaff_ESI + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008ec500(*(undefined4 *)(unaff_ESI + 0xc),*(undefined4 *)(unaff_ESI + 0x10));
  FUN_00777020();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 15548 ; VA 0x008ebdb0 ; FUN_008ebdb0 */

int __thiscall FUN_008ebdb0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_40 [40];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2d50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&uStack_18);
  uStack_8 = 0;
  if ((param_2 == 0) && (*(int *)(param_3 + 0xc) == 200)) {
    if (*(int *)(param_1 + 0xc) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(param_1 + 0xc) + 8);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_008db620(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),0);
    iVar4 = FUN_008ed690(uStack_18,param_3 + 0x40,0);
  }
  else {
    FUN_014cc1e0(*(undefined4 *)(param_3 + 0xc),param_3 + 0x10,param_3 + 0x40);
    piVar5 = *(int **)(param_1 + 0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[2] = piVar5[2] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0xc);
    }
    uVar3 = *(undefined4 *)(param_1 + 8);
    piVar1 = piVar5 + 2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_008db4f0(uVar3,piVar5,0);
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    FUN_008ed690(uStack_18,0,auStack_40);
    iVar4 = FUN_0056e860();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar2 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15549 ; VA 0x008ebf00 ; FUN_008ebf00 */

int __thiscall FUN_008ebf00(undefined4 *param_1,int param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  int *piVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  undefined **ppuVar9;
  char *pcVar10;
  char *pcVar11;
  int *in_stack_00000028;
  int *in_stack_0000002c;
  uint in_stack_fffffcf0;
  undefined auStack_2f0 [120];
  undefined auStack_278 [120];
  undefined auStack_200 [120];
  undefined auStack_188 [120];
  undefined auStack_110 [120];
  undefined4 uStack_98;
  int *piStack_94;
  int *piStack_90;
  int iStack_8c;
  int *piStack_88;
  uint uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  int iStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2dfd;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 3;
  if (iStack_20 != 0) {
    if (((param_2 == 1) && (in_stack_00000028 == (int *)0x0)) && (param_3 != 0)) {
      uVar7 = FUN_00a9d330(&stack0x00000010);
      uStack_98 = *param_1;
      iStack_14 = param_3;
      puStack_18 = &uStack_98;
      if (in_stack_0000002c != (int *)0x0) {
        LOCK();
        in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
        UNLOCK();
      }
      piStack_94 = in_stack_00000028;
      piStack_90 = in_stack_0000002c;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      iStack_8c = param_3;
      piStack_88 = param_4;
      uVar3 = param_1[4];
      uStack_8._0_1_ = 5;
      uStack_80 = 0;
      if (uVar3 != 0) {
        uStack_80 = uVar3;
        if ((uVar3 & 1) == 0) {
          (**(code **)(uVar3 & 0xfffffffe))(param_1 + 6,&uStack_78,0);
        }
        else {
          uStack_78 = param_1[6];
          uStack_74 = param_1[7];
          uStack_70 = param_1[8];
          uStack_6c = param_1[9];
          uStack_68 = *(undefined8 *)(param_1 + 10);
        }
      }
      uVar3 = param_1[0xc];
      uStack_8._0_1_ = 6;
      uStack_60 = 0;
      if (uVar3 != 0) {
        uStack_60 = uVar3;
        if ((uVar3 & 1) == 0) {
          (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0xe,&uStack_58,0);
        }
        else {
          uStack_58 = param_1[0xe];
          uStack_54 = param_1[0xf];
          uStack_50 = param_1[0x10];
          uStack_4c = param_1[0x11];
          uStack_48 = *(undefined8 *)(param_1 + 0x12);
        }
      }
      uStack_8._0_1_ = 7;
      uStack_40 = uVar7;
      FUN_0054ef60(param_1 + 0x14);
      uStack_8._0_1_ = 8;
      FUN_008e69f0(&uStack_98);
      uStack_8._0_1_ = 9;
      uVar7 = 0;
      FUN_008e69f0(auStack_2f0);
      uStack_8._0_1_ = 10;
      FUN_008e69f0(auStack_278);
      uStack_8._0_1_ = 0xb;
      FUN_008e69f0(auStack_200);
      uStack_8._0_1_ = 0xc;
      cVar6 = FUN_00585a40(auStack_110,uVar7);
      if (cVar6 == '\0') {
        FUN_008e69f0(auStack_110);
        uStack_8._0_1_ = 0xd;
        iVar8 = FUN_01674e20(0x78);
        uStack_8._0_1_ = 0xe;
        if (iVar8 != 0) {
          FUN_008e69f0(auStack_188);
        }
        FUN_008e9c70();
        FUN_008e9c70();
        bVar4 = true;
      }
      else {
        FUN_008e9c70();
        bVar4 = false;
      }
      FUN_008e9c70();
      ppuVar9 = &PTR_FUN_0192d388;
      if (!bVar4) {
        ppuVar9 = (undefined **)0x0;
      }
      FUN_008e9c70(ppuVar9);
      FUN_008e9c70();
      uStack_8._0_1_ = 3;
      FUN_008e9c70();
      FUN_00557fc0(&iStack_20);
      FUN_00ae4ff0();
    }
    else {
      if (in_stack_00000028 == (int *)0x0) {
        pcVar11 = "Unknown error for fetching asset async";
      }
      else {
        pcVar11 = (char *)(**(code **)(*in_stack_00000028 + 4))();
      }
      in_stack_fffffcf0 = in_stack_fffffcf0 & 0xffffff00;
      pcVar10 = pcVar11;
      do {
        cVar6 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar6 != '\0');
      FUN_005542c0(pcVar11,(int)pcVar10 - (int)(pcVar11 + 1));
      FUN_005e65e0(in_stack_fffffcf0);
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar8 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar8 = param_4[1] + -1;
    param_4[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar8 = param_4[2] + -1;
      param_4[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  iVar8 = FUN_0056cfd0();
  piVar5 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_0000002c + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 15550 ; VA 0x008ec2a0 ; FUN_008ec2a0 */

uint __thiscall FUN_008ec2a0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  code *pcVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 uVar9;
  uint *puStack_1c;
  char cStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2e28;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008ff200();
  puStack_1c = (uint *)(*piVar3 + 0x24);
  cStack_18 = '\0';
  FUN_00587410();
  iVar4 = *piVar3;
  uStack_8._0_1_ = 1;
  iStack_14 = iVar4;
  if (*(char *)(iVar4 + 0x18) == '\0') {
    puVar7 = (undefined4 *)FUN_01674e20(8);
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *puVar7 = 0;
      puVar7[1] = 0;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      *puVar7 = param_2;
      puVar7[1] = param_3;
    }
    iVar5 = *(int *)(iVar4 + 0x88);
    *(undefined4 **)(iVar4 + 0x88) = puVar7;
    if (iVar5 != 0) {
      piVar3 = *(int **)(iVar5 + 4);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(iVar5,8);
    }
    uVar8 = FUN_00587e20(&puStack_1c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (cStack_18 != '\0') {
      LOCK();
      uVar8 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar8 & 0x40000000) == 0) && (-0x80000000 < (int)uVar8)) {
        LOCK();
        uVar2 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar9 = FUN_00554e40();
          uVar8 = SetEvent(uVar9);
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(param_3 + 1);
      uVar2 = *puVar1;
      uVar8 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        uVar8 = (**(code **)*param_3)();
        LOCK();
        piVar3 = param_3 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          uVar8 = (**(code **)(*param_3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return uVar8;
  }
  uVar9 = FUN_0056b140();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005649e0(uVar9);
  pcVar6 = (code *)swi(3);
  uVar8 = (*pcVar6)();
  return uVar8;
}



/* FUNCTION 15551 ; VA 0x008ec400 ; FUN_008ec400 */

void FUN_008ec400(int *param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  if (param_1 != (int *)0x0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*param_1 != 0) {
      iVar2 = *param_1 + 1000;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_016dee6d(iVar2);
      if (iVar1 != 0) {
        FUN_016df3c9(iVar1);
      }
      if ((DAT_01d635a4 != '\0') &&
         ((*(int *)(*param_1 + 0x2a0) != 1 ||
          (iVar1 = GetCurrentThreadId(), *(int *)(*param_1 + 0x2a8) != iVar1)))) {
        FUN_01675310("InvalidAccess",&DAT_018bc9b8);
      }
      *(int *)(*param_1 + 0x2a8) = param_1[1];
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar1 = FUN_016deec8(iVar2);
      if (iVar1 != 0) {
        FUN_016df3c9(iVar1);
      }
    }
    FUN_01674ea0(param_1,8);
    ExceptionList = pvStack_10;
    return;
  }
  return;
}



/* FUNCTION 15552 ; VA 0x008ec4d0 ; FUN_008ec4d0 */

void FUN_008ec4d0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  (**(code **)*param_1)(0);
  uVar1 = GetProcessHeap(0,param_1);
  HeapFree(uVar1);
  return;
}



/* FUNCTION 15553 ; VA 0x008ec500 ; FUN_008ec500 */

/* WARNING: Removing unreachable block (ram,0x008ec56d) */
/* WARNING: Removing unreachable block (ram,0x008ec579) */
/* WARNING: Removing unreachable block (ram,0x008ec587) */

undefined4 __thiscall FUN_008ec500(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2e50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15554 ; VA 0x008ec5c0 ; FUN_008ec5c0 */

int __thiscall FUN_008ec5c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2e68;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15555 ; VA 0x008ec650 ; FUN_008ec650 */

/* WARNING: Removing unreachable block (ram,0x008ec6a2) */
/* WARNING: Removing unreachable block (ram,0x008ec6b2) */
/* WARNING: Removing unreachable block (ram,0x008ec6b8) */

void __fastcall FUN_008ec650(int *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2e90;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8 = 2;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15556 ; VA 0x008ec6fd ; Catch@008ec6fd */

undefined * Catch_008ec6fd(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_008ec70e;
}



/* FUNCTION 15557 ; VA 0x008ec720 ; FUN_008ec720 */

/* WARNING: Removing unreachable block (ram,0x008ec7be) */
/* WARNING: Removing unreachable block (ram,0x008ec7ce) */
/* WARNING: Removing unreachable block (ram,0x008ec7d4) */

void * __thiscall FUN_008ec720(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000018;
  int *in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2ec8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 == 0) {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (0xf < in_stack_00000018) {
      if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      ExceptionList = &pvStack_10;
      pvVar3 = (void *)FUN_01674ea0();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    pvVar3 = (void *)FUN_005507b0();
  }
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = in_stack_00000020 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_00000020 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 15558 ; VA 0x008ec860 ; Catch@008ec860 */

undefined * Catch_008ec860(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_008ec871;
}



/* FUNCTION 15559 ; VA 0x008ec890 ; FUN_008ec890 */

void FUN_008ec890(undefined4 param_1)

{
  FUN_01674ea0(param_1,4);
  return;
}



/* FUNCTION 15560 ; VA 0x008ec8a4 ; FUN_008ec8a4 */

void FUN_008ec8a4(void)

{
  FUN_008ecfa0();
  return;
}



/* FUNCTION 15561 ; VA 0x008ec8ac ; FUN_008ec8ac */

void FUN_008ec8ac(void)

{
  FUN_008ecfa0();
  return;
}



/* FUNCTION 15562 ; VA 0x008ec8b4 ; FUN_008ec8b4 */

void FUN_008ec8b4(void)

{
  FUN_008ed1c0();
  return;
}



/* FUNCTION 15563 ; VA 0x008ec8c0 ; FUN_008ec8c0 */

undefined4 __thiscall FUN_008ec8c0(undefined4 param_1,byte param_2)

{
  FUN_00f50100();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15564 ; VA 0x008ec8f0 ; FUN_008ec8f0 */

undefined4 __thiscall FUN_008ec8f0(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15565 ; VA 0x008ec930 ; FUN_008ec930 */

int __thiscall FUN_008ec930(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15566 ; VA 0x008ec970 ; FUN_008ec970 */

int __thiscall FUN_008ec970(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 15567 ; VA 0x008ec9c0 ; FUN_008ec9c0 */

int __thiscall FUN_008ec9c0(int param_1,byte param_2)

{
  if (*(int **)(param_1 + 0x40) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x40) + 4))(1);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15568 ; VA 0x008eca00 ; FUN_008eca00 */

int __thiscall FUN_008eca00(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 15569 ; VA 0x008eca50 ; FUN_008eca50 */

int __thiscall FUN_008eca50(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15570 ; VA 0x008eca90 ; FUN_008eca90 */

undefined4 __thiscall FUN_008eca90(undefined4 param_1,byte param_2)

{
  FUN_0056cee0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15571 ; VA 0x008ecac0 ; FUN_008ecac0 */

int __thiscall FUN_008ecac0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15572 ; VA 0x008ecb00 ; FUN_008ecb00 */

undefined4 __thiscall FUN_008ecb00(undefined4 param_1,byte param_2)

{
  FUN_008a9470();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 15573 ; VA 0x008ecb30 ; FUN_008ecb30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecb30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AvatarJointPositionType>::vftable;
  _DAT_01ee08d0 = _DAT_01ee08d0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15574 ; VA 0x008ecb60 ; FUN_008ecb60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecb60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GameAvatarType>::vftable;
  _DAT_01ee08c0 = _DAT_01ee08c0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15575 ; VA 0x008ecb90 ; FUN_008ecb90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecb90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::GearGenreSetting>::vftable;
  _DAT_01ee08b0 = _DAT_01ee08b0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15576 ; VA 0x008ecbc0 ; FUN_008ecbc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecbc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::GearType>::vftable;
  _DAT_01ee08b8 = _DAT_01ee08b8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15577 ; VA 0x008ecbf0 ; FUN_008ecbf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecbf0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::Genre>::vftable;
  _DAT_01ee08a8 = _DAT_01ee08a8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15578 ; VA 0x008ecc20 ; FUN_008ecc20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecc20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HttpRequestType>::vftable;
  _DAT_01ef5d40 = _DAT_01ef5d40 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15579 ; VA 0x008ecc50 ; FUN_008ecc50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008ecc50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::R15CollisionType>::vftable;
  _DAT_01ee08c8 = _DAT_01ee08c8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15580 ; VA 0x008ecc80 ; FUN_008ecc80 */

undefined4 * __thiscall FUN_008ecc80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::DataModel::CreatorType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15581 ; VA 0x008eccb0 ; FUN_008eccb0 */

undefined4 * __thiscall FUN_008eccb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::DataModel::GearGenreSetting>::GetSet
             ::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15582 ; VA 0x008ecce0 ; FUN_008ecce0 */

undefined4 * __thiscall FUN_008ecce0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::DataModel::Genre>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15583 ; VA 0x008ecd10 ; FUN_008ecd10 */

undefined4 * __thiscall FUN_008ecd10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Instance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15584 ; VA 0x008ecd40 ; FUN_008ecd40 */

undefined4 * __thiscall FUN_008ecd40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Workspace*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15585 ; VA 0x008ecd70 ; FUN_008ecd70 */

undefined4 * __thiscall FUN_008ecd70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<__int64>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15586 ; VA 0x008ecda0 ; FUN_008ecda0 */

undefined4 * __thiscall FUN_008ecda0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<bool>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 15587 ; VA 0x008ecdd0 ; FUN_008ecdd0 */

undefined4 * __thiscall FUN_008ecdd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::AvatarJointPositionType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 15588 ; VA 0x008ece00 ; FUN_008ece00 */

undefined4 * __thiscall FUN_008ece00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GameAvatarType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 15589 ; VA 0x008ece30 ; FUN_008ece30 */

undefined4 * __thiscall FUN_008ece30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::R15CollisionType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 15590 ; VA 0x008ece60 ; FUN_008ece60 */

undefined4 __thiscall FUN_008ece60(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 15591 ; VA 0x008ece80 ; FUN_008ece80 */

undefined4 __thiscall FUN_008ece80(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x160);
  }
  return param_1;
}



/* FUNCTION 15592 ; VA 0x008eceb0 ; FUN_008eceb0 */

undefined4 __thiscall FUN_008eceb0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 15593 ; VA 0x008eced0 ; FUN_008eced0 */

undefined4 * __thiscall FUN_008eced0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = param_1[0x22];
  *param_1 = boost::detail::
             shared_state<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>_>
             ::vftable;
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_0056ea40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x90);
  }
  return param_1;
}



/* FUNCTION 15594 ; VA 0x008ecf40 ; FUN_008ecf40 */

undefined4 * __thiscall FUN_008ecf40(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::detail::sp_counted_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 15595 ; VA 0x008ecf70 ; FUN_008ecf70 */

undefined4 __thiscall FUN_008ecf70(undefined4 param_1,byte param_2)

{
  FUN_0151f390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15596 ; VA 0x008ecfa0 ; FUN_008ecfa0 */

undefined4 __thiscall FUN_008ecfa0(undefined4 param_1,byte param_2)

{
  FUN_008ea720();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4f8);
  }
  return param_1;
}



/* FUNCTION 15597 ; VA 0x008ecfd0 ; FUN_008ecfd0 */

undefined4 __thiscall FUN_008ecfd0(undefined4 param_1,byte param_2)

{
  FUN_0151f390();
  FUN_0151f390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 15598 ; VA 0x008ed000 ; FUN_008ed000 */

int __thiscall FUN_008ed000(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  FUN_008ee150();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x130),8);
  *(undefined4 *)(param_1 + 0x130) = 0;
  piVar1 = *(int **)(param_1 + 300);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x150);
  }
  return param_1;
}



/* FUNCTION 15599 ; VA 0x008ed070 ; FUN_008ed070 */

undefined4 * __thiscall FUN_008ed070(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Workspace*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15600 ; VA 0x008ed0a0 ; FUN_008ed0a0 */

undefined4 * __thiscall FUN_008ed0a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::AvatarJointPositionType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15601 ; VA 0x008ed0d0 ; FUN_008ed0d0 */

undefined4 * __thiscall FUN_008ed0d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::DataModel::CreatorType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15602 ; VA 0x008ed100 ; FUN_008ed100 */

undefined4 * __thiscall FUN_008ed100(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GameAvatarType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15603 ; VA 0x008ed130 ; FUN_008ed130 */

undefined4 * __thiscall FUN_008ed130(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::DataModel::GearGenreSetting>::GetSet
             ::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15604 ; VA 0x008ed160 ; FUN_008ed160 */

undefined4 * __thiscall FUN_008ed160(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::DataModel::Genre>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15605 ; VA 0x008ed190 ; FUN_008ed190 */

undefined4 * __thiscall FUN_008ed190(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::R15CollisionType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15606 ; VA 0x008ed1c0 ; FUN_008ed1c0 */

undefined4 __thiscall FUN_008ed1c0(undefined4 param_1,byte param_2)

{
  FUN_00c9adf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,300);
  }
  return param_1;
}



/* FUNCTION 15607 ; VA 0x008ed1f0 ; FUN_008ed1f0 */

int __thiscall FUN_008ed1f0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 15608 ; VA 0x008ed240 ; FUN_008ed240 */

undefined4 * __thiscall FUN_008ed240(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::detail::tss_cleanup_function::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 15609 ; VA 0x008ed270 ; FUN_008ed270 */

void __thiscall FUN_008ed270(int param_1,int *param_2)

{
  undefined auStack_10 [12];
  
  if ((*(int *)(param_1 + 0x2d8) != 0) && (*param_2 != 0)) {
    FUN_008eb360(param_2);
    FUN_016756b0(auStack_10,"OnClose is already set");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  return;
}



/* FUNCTION 15610 ; VA 0x008ed2c0 ; FUN_008ed2c0 */

undefined4 FUN_008ed2c0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_008f78c0(param_1);
  if (iVar1 != 0) {
    return *(undefined4 *)(iVar1 + 0x158);
  }
  return 6;
}



/* FUNCTION 15611 ; VA 0x008ed2f0 ; FUN_008ed2f0 */

void FUN_008ed2f0(int param_1,int *param_2,uint param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  uint in_stack_0000002c;
  undefined in_stack_ffffffd0;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c36d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (param_1 == 0) {
    ExceptionList = &pvStack_10;
    pcVar2 = (char *)(**(code **)(*param_2 + 4))();
    in_stack_ffffffd0 = 0;
    pcVar3 = pcVar2;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1);
  }
  FUN_005e65e0(in_stack_ffffffd0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15612 ; VA 0x008ed3f0 ; FUN_008ed3f0 */

void FUN_008ed3f0(int param_1,int param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined *puVar7;
  undefined4 uStack_b0;
  int *piStack_ac;
  undefined4 uStack_a8;
  int *piStack_a4;
  undefined auStack_a0 [40];
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_70;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  TypeDescriptor *pTStack_54;
  TypeDescriptor *pTStack_50;
  undefined **ppuStack_4c;
  TypeDescriptor TStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3708;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)0x0;
  uStack_8 = 0;
  if (DAT_01d635fc != '\0') {
    ExceptionList = &pvStack_10;
    if (param_1 != 0) {
      ppuStack_4c = (undefined **)0x0;
      piStack_70 = (int *)&param_4;
      iStack_74 = 0x8ed440;
      ExceptionList = &pvStack_10;
      FUN_0054f510();
      piStack_70 = param_3;
      iStack_74 = param_2;
      uStack_78 = 0x8ed44d;
      FUN_00905b60();
    }
    goto LAB_008ed656;
  }
  ExceptionList = &pvStack_10;
  if (param_1 == 0) goto LAB_008ed656;
  if (param_2 == 0) {
    piStack_28 = (int *)0x0;
    puVar4 = &uStack_2c;
    uVar6 = 2;
    uStack_34 = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    ppuStack_4c = (undefined **)param_2;
    pTStack_50 = (TypeDescriptor *)&uStack_24;
    pTStack_54 = (TypeDescriptor *)0x8ed46d;
    ExceptionList = &pvStack_10;
    puVar4 = (undefined4 *)FUN_008c08f0();
    uVar6 = 1;
    uStack_34 = *puVar4;
  }
  piVar2 = (int *)puVar4[1];
  uStack_14 = uStack_34;
  *puVar4 = 0;
  puVar4[1] = 0;
  piStack_30 = piVar2;
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    ppuStack_4c = (undefined **)0x8ed4b3;
    FUN_00550b30();
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    ppuStack_4c = (undefined **)0x8ed4c3;
    FUN_00550b30();
  }
  uStack_2c = 0;
  piStack_28 = (int *)0x0;
  ppuStack_4c = (undefined **)0x0;
  pTStack_50 = &RBX::http_status_error::RTTI_Type_Descriptor;
  pTStack_54 = &std::exception::RTTI_Type_Descriptor;
  uStack_58 = 0;
  piStack_5c = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_60 = 0x8ed4ec;
  ppuStack_4c = (undefined **)FUN_0170d75d();
  if (ppuStack_4c == (undefined **)0x0) {
    if (param_3 == (int *)0x0) {
      uStack_24 = 0;
      ppuStack_4c = (undefined **)&uStack_24;
      puStack_20 = (undefined *)0x0;
      uVar5 = 8;
    }
    else {
      ppuStack_4c = (undefined **)0x8ed519;
      puStack_18 = (undefined *)(**(code **)(*param_3 + 4))();
      ppuStack_4c = &puStack_18;
      pTStack_50 = (TypeDescriptor *)&puStack_1c;
      puStack_1c = (undefined *)0x0;
      pTStack_54 = &TStack_3c;
      uStack_58 = 0x8ed534;
      ppuStack_4c = (undefined **)FUN_008e5230();
      uVar5 = 4;
    }
    puStack_1c = (undefined *)(uVar5 | uVar6);
    pTStack_50 = (TypeDescriptor *)0x8ed562;
    FUN_005587e0();
    puVar7 = puStack_1c;
    if (((uint)puStack_1c & 8) != 0) {
      puVar7 = (undefined *)((uint)puStack_1c & 0xfffffff7);
      ppuStack_4c = (undefined **)0x8ed575;
      FUN_00550b30();
    }
    if (((uint)puVar7 & 4) != 0) goto LAB_008ed57d;
  }
  else {
    pTStack_50 = (TypeDescriptor *)&uStack_24;
    pTStack_54 = (TypeDescriptor *)0x8ed4fd;
    ppuStack_4c = (undefined **)FUN_008e5180();
    pTStack_50 = (TypeDescriptor *)0x8ed509;
    FUN_005587e0();
LAB_008ed57d:
    ppuStack_4c = (undefined **)0x8ed582;
    FUN_00550b30();
  }
  piVar1 = piStack_28;
  ppuStack_4c = (undefined **)0x1;
  piStack_70 = (int *)0x0;
  puStack_1c = auStack_a0;
  puStack_18 = (undefined *)&uStack_a8;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piStack_28[1] = piStack_28[1] + 1;
    UNLOCK();
  }
  uStack_a8 = uStack_2c;
  piStack_a4 = piStack_28;
  puStack_20 = (undefined *)&uStack_b0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar2[1] = piVar2[1] + 1;
    UNLOCK();
  }
  uStack_b0 = uStack_14;
  uStack_8._0_1_ = 4;
  piStack_ac = piVar2;
  FUN_0054f510(&param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008e0450(puStack_1c);
  piStack_a4 = (int *)0x8ed606;
  FUN_008dba20();
  piStack_70 = (int *)0x8ed60e;
  FUN_0090ca30();
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_4c = (undefined **)0x8ed624;
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        ppuStack_4c = (undefined **)0x8ed634;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_4c = (undefined **)0x8ed647;
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppuStack_4c = (undefined **)0x8ed656;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
LAB_008ed656:
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    pTStack_54 = (TypeDescriptor *)&stack0x00000018;
    ppuStack_4c = (undefined **)0x2;
    uStack_58 = 0x8ed67a;
    pTStack_50 = pTStack_54;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15613 ; VA 0x008ed690 ; FUN_008ed690 */

void __thiscall
FUN_008ed690(undefined *param_1,int param_2,undefined4 param_3,undefined4 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11)

{
  uint *puVar1;
  uint auStack_38 [2];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3728;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_18 = 1;
    puStack_14 = (undefined *)auStack_38;
    auStack_38[0] = 0;
    ExceptionList = &pvStack_10;
    puVar1 = auStack_38;
    if (param_5 != 0) {
      auStack_38[0] = param_5;
      if ((param_5 & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_30,0);
        puVar1 = (uint *)puStack_14;
      }
      else {
        uStack_30 = param_7;
        uStack_2c = param_8;
        uStack_28 = param_9;
        uStack_24 = param_10;
        uStack_20 = param_11;
        ExceptionList = &pvStack_10;
        puVar1 = auStack_38;
      }
    }
    puStack_14 = (undefined *)puVar1;
    FUN_00905b60(param_3,param_4);
  }
  uStack_8 = 1;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    uStack_18 = 2;
    uStack_20 = CONCAT44(&param_7,&param_7);
    uStack_24 = 0x8ed72e;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15614 ; VA 0x008ed740 ; FUN_008ed740 */

int FUN_008ed740(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c1b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    FUN_0054ef60(param_3);
    iVar3 = FUN_006ecaa0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15615 ; VA 0x008ed7e0 ; FUN_008ed7e0 */

int FUN_008ed7e0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                undefined8 param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3758;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_20 != 0) {
    puVar4 = (undefined4 *)FUN_00636a50();
    iVar3 = FUN_0060dcd0(&iStack_18,*puVar4);
    uStack_8._0_1_ = 2;
    if (iStack_18 != 0) {
      iVar3 = FUN_00b5cff0(param_3,param_4,param_5);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15616 ; VA 0x008ed8d0 ; FUN_008ed8d0 */

uint __thiscall FUN_008ed8d0(uint *param_1,uint param_2)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 0x10;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 15617 ; VA 0x008ed990 ; FUN_008ed990 */

void FUN_008ed990(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x28);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 15618 ; VA 0x008ed9c0 ; FUN_008ed9c0 */

void __thiscall FUN_008ed9c0(int *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3510();
        iVar2 = iVar2 + 0x48;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x48) * 0x48;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x48;
  param_1[2] = param_2 + param_4 * 0x48;
  return;
}



/* FUNCTION 15619 ; VA 0x008eda50 ; FUN_008eda50 */

void __fastcall FUN_008eda50(int param_1)

{
  FUN_008dd740(param_1 + 8);
  return;
}



/* FUNCTION 15620 ; VA 0x008eda60 ; FUN_008eda60 */

undefined4 * __thiscall FUN_008eda60(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_c6c643c68cd5f4fa41e08dd852f2ae65>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = 0;
  param_2[4] = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  return param_2;
}



/* FUNCTION 15621 ; VA 0x008edac0 ; FUN_008edac0 */

int __thiscall FUN_008edac0(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_008e9ba0();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  if (param_2 != '\0') {
    iVar4 = FUN_01674ea0(param_1,0x58);
  }
  return iVar4;
}



/* FUNCTION 15622 ; VA 0x008edb00 ; FUN_008edb00 */

void __thiscall FUN_008edb00(int param_1,char param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x14);
  }
  return;
}



/* FUNCTION 15623 ; VA 0x008edb50 ; FUN_008edb50 */

void __fastcall FUN_008edb50(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0151f390();
    FUN_0151f390();
    FUN_01674ea0(iVar1,0xc);
  }
  return;
}



/* FUNCTION 15624 ; VA 0x008edb80 ; FUN_008edb80 */

void __fastcall FUN_008edb80(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 0xc);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    FUN_01674ea0(iVar2,0x14);
  }
  return;
}



/* FUNCTION 15625 ; VA 0x008edbd0 ; FUN_008edbd0 */

void FUN_008edbd0(void)

{
  FUN_0151f390();
  return;
}



/* FUNCTION 15626 ; VA 0x008edbe0 ; FUN_008edbe0 */

void __fastcall FUN_008edbe0(int param_1)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 0x38))(0);
  return;
}



/* FUNCTION 15627 ; VA 0x008edbf0 ; FUN_008edbf0 */

void __fastcall FUN_008edbf0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(-(uint)(*(int *)(param_1 + 0xc) != 0) & *(int *)(param_1 + 0xc) + 0xcU);
  ExceptionList = &pvStack_10;
  FUN_008a45f0(puVar1);
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15628 ; VA 0x008edc40 ; FUN_008edc40 */

void FUN_008edc40(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_008c3510();
      param_1 = param_1 + 0x48;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 15629 ; VA 0x008edc70 ; FUN_008edc70 */

void __thiscall FUN_008edc70(undefined4 param_1,int param_2)

{
  FUN_005f53f0(param_1,param_2 + 0x10);
  FUN_01674ea0(param_2,0x30);
  return;
}



/* FUNCTION 15630 ; VA 0x008edca0 ; FUN_008edca0 */

int __thiscall FUN_008edca0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_40 [40];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2d50;
  pvStack_10 = ExceptionList;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  FUN_00587490(&uStack_18);
  uStack_8 = 0;
  if ((iVar3 == 0) && (*(int *)(param_3 + 0xc) == 200)) {
    FUN_008e68f0(param_1 + 0x10);
    FUN_008db750();
    iVar3 = FUN_008ed690(uStack_18,param_3 + 0x40,0);
  }
  else {
    FUN_014cc1e0(*(undefined4 *)(param_3 + 0xc),param_3 + 0x10,param_3 + 0x40);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_008e68f0(param_1 + 0x10);
    FUN_008db750();
    FUN_008ed690(uStack_18,0,auStack_40);
    iVar3 = FUN_0056e860();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15631 ; VA 0x008edda0 ; FUN_008edda0 */

void FUN_008edda0(undefined4 *param_1,undefined4 param_2)

{
  FUN_008ebdb0(*param_1,param_2);
  return;
}



/* FUNCTION 15632 ; VA 0x008eddc0 ; thunk_FUN_0090bdc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0090bdc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5526;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee09a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee09a4);
    if (DAT_01ee09a4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("GearGenreSetting");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0940 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::GearGenreSetting>::vftable;
      FUN_009cafc0(&DAT_01d63698,2,1,0);
      FUN_016f3654(&LAB_01883020);
      FUN_016f37bf();
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0940;
}



/* FUNCTION 15633 ; VA 0x008eddd0 ; thunk_FUN_0090bf80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0090bf80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5566;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0a0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0a0c);
    if (DAT_01ee0a0c == -1) {
      uStack_8 = 0;
      FUN_009ca470("Genre");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee09a8 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::Genre>::vftable;
      FUN_009caf20(&DAT_01d63628,0xe);
      FUN_016f3654(&LAB_01883060);
      FUN_016f37bf(&DAT_01ee0a0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee09a8;
}



/* FUNCTION 15634 ; VA 0x008edde0 ; FUN_008edde0 */

void __thiscall FUN_008edde0(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x3333333 - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_008edfbc:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_008ede44;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_008ede44:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_008edfbc;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_008edfbc;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 15635 ; VA 0x008edfd0 ; FUN_008edfd0 */

void __fastcall FUN_008edfd0(int param_1)

{
  FUN_008db680(param_1 + 8);
  return;
}



/* FUNCTION 15636 ; VA 0x008edff0 ; FUN_008edff0 */

undefined4 * __thiscall FUN_008edff0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_c6c643c68cd5f4fa41e08dd852f2ae65>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  return param_2;
}



/* FUNCTION 15637 ; VA 0x008ee060 ; FUN_008ee060 */

void __thiscall FUN_008ee060(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3778;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_008ee5b0(param_2);
  iVar5 = *param_1;
  iVar3 = param_1[1];
  uStack_8 = 1;
  for (; iVar5 != iVar3; iVar5 = iVar5 + 0x48) {
    FUN_008e8ca0(iVar5);
  }
  FUN_008ed9c0(uVar4,(iVar1 - iVar2) / 0x48,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15638 ; VA 0x008ee10d ; Catch_All@008ee10d */

void Catch_All_008ee10d(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + 8);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_008f20b0(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15639 ; VA 0x008ee130 ; FUN_008ee130 */

TypeDescriptor * FUN_008ee130(void)

{
  return &<lambda_9fd023237d719cffa06f26b0b215a4d1>::RTTI_Type_Descriptor;
}



/* FUNCTION 15640 ; VA 0x008ee140 ; FUN_008ee140 */

TypeDescriptor * FUN_008ee140(void)

{
  return &<lambda_c6c643c68cd5f4fa41e08dd852f2ae65>::RTTI_Type_Descriptor;
}



/* FUNCTION 15641 ; VA 0x008ee150 ; FUN_008ee150 */

void __fastcall FUN_008ee150(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x10);
  while (iVar4 != 0) {
    FUN_008c3510();
    piVar1 = (int *)(param_1 + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    iVar4 = *(int *)(param_1 + 0x10);
  }
  iVar4 = *(int *)(param_1 + 8);
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(*(int *)(param_1 + 4) + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x50);
    }
  }
  iVar4 = *(int *)(param_1 + 4);
  if (iVar4 != 0) {
    uVar3 = *(int *)(param_1 + 8) * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 15642 ; VA 0x008ee200 ; FUN_008ee200 */

void __fastcall FUN_008ee200(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056b650();
        iVar2 = iVar2 + 0x18;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x18) * 0x18;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 15643 ; VA 0x008ee280 ; FUN_008ee280 */

void __fastcall FUN_008ee280(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3510();
        iVar2 = iVar2 + 0x50;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x50) * 0x50;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 15644 ; VA 0x008ee300 ; FUN_008ee300 */

undefined4 * FUN_008ee300(int param_1,int param_2,undefined4 *param_3)

{
  undefined *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c37a0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      *param_3 = 0;
      FUN_005880d0(param_1);
      uStack_8 = 1;
      param_3[8] = 0;
      FUN_005880d0(param_1 + 0x20);
      puVar1 = (undefined *)(param_1 + 0x40);
      param_1 = param_1 + 0x48;
      *(undefined *)(param_3 + 0x10) = *puVar1;
      param_3 = param_3 + 0x12;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 15645 ; VA 0x008ee3a0 ; FUN_008ee3a0 */

undefined4 * __thiscall FUN_008ee3a0(undefined4 param_1,int param_2,int param_3,undefined4 *param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c37b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      *param_4 = 0;
      FUN_005880d0(param_2);
      param_4 = param_4 + 8;
      param_2 = param_2 + 0x20;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 1;
  FUN_006ce110(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 15646 ; VA 0x008ee430 ; FUN_008ee430 */

void FUN_008ee430(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c37d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      FUN_008e8ca0(param_1);
      param_1 = param_1 + 0x48;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15647 ; VA 0x008ee4a0 ; FUN_008ee4a0 */

uint __fastcall FUN_008ee4a0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016dee6d(param_1 + 0x1e0);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  if (*(int *)(param_1 + 0x218) == 0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x224) + *(int *)(param_1 + 0x214) * 4);
  }
  for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
    uVar3 = uVar3 | puVar2[2];
  }
  uStack_8 = 0;
  iVar1 = FUN_016deec8(param_1 + 0x1e0);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15648 ; VA 0x008ee540 ; FUN_008ee540 */

uint FUN_008ee540(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x50;
  if (param_1 < 0x3333334) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 15649 ; VA 0x008ee5b0 ; FUN_008ee5b0 */

uint FUN_008ee5b0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x48;
  if (param_1 < 0x38e38e4) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 15650 ; VA 0x008ee620 ; FUN_008ee620 */

uint FUN_008ee620(int param_1,int param_2,int *param_3,int param_4)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  float10 fVar6;
  undefined4 uStack_f0;
  uint uStack_ec;
  int iStack_e8;
  int *piStack_e4;
  int iStack_20;
  int *piStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3855;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar5 = param_1 + 8;
  ExceptionList = &pvStack_10;
  if (*(uint *)(param_2 + 0x28) == (-(uint)(param_1 != 0) & uVar5)) {
    ExceptionList = &pvStack_10;
    FUN_005cac50(&iStack_20);
    uStack_8._0_1_ = 1;
    uStack_f0 = FUN_0088cb40();
    uStack_ec = 0;
    FUN_0054ef60(param_2 + 0x10);
    uStack_ec = FUN_005c9d30();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_20 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 3;
    if (uStack_ec != 0) {
      (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    uStack_8._0_1_ = 1;
    fVar6 = (float10)FUN_01523050();
    dStack_18 = (double)fVar6;
    FUN_006fcaa0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_20 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 5;
    if (uStack_ec != 0) {
      (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    uStack_8._0_1_ = 1;
    fVar6 = (float10)FUN_01523100();
    dStack_18 = (double)fVar6;
    FUN_006fcaa0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_20 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 7;
    if (uStack_ec != 0) {
      (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    uStack_8._0_1_ = 1;
    fVar6 = (float10)FUN_015230f0();
    dStack_18 = (double)fVar6;
    FUN_006fcaa0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_20 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 9;
    if (uStack_ec != 0) {
      (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    uStack_8._0_1_ = 1;
    uStack_f0 = FUN_0088c8c0();
    uStack_ec = 0;
    iStack_e8 = 0;
    uStack_ec = FUN_005c9cc0();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_20 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xb;
    if (uStack_ec != 0) {
      (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    uStack_8._0_1_ = 1;
    iVar4 = *(int *)(param_2 + 0x48);
    uStack_f0 = FUN_0088daf0();
    uStack_ec = 0;
    iStack_e8 = CONCAT31(iStack_e8._1_3_,iVar4 == 1);
    uStack_ec = FUN_005c9ef0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_20 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xd;
    if (uStack_ec != 0) {
      (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 0xe;
    uStack_f0 = FUN_008882f0();
    uStack_ec = 0;
    iStack_e8 = iStack_20;
    piStack_e4 = piStack_1c;
    dStack_18 = 0.0;
    uStack_ec = FUN_005c9da0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if (*(int *)(param_4 + 8) == *(int *)(param_4 + 4)) {
      FUN_005ca4f0(*(int *)(param_4 + 4),&uStack_f0);
    }
    else {
      FUN_005caf00(&uStack_f0);
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 0xd0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    uVar5 = uStack_ec;
    if (uStack_ec != 0) {
      uVar5 = (**(code **)(uStack_ec + 8))(&iStack_e8);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piStack_1c + 1);
      uVar3 = *puVar1;
      uVar5 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        puVar1 = (uint *)(piStack_1c + 2);
        uVar3 = *puVar1;
        uVar5 = *puVar1;
        *puVar1 = uVar3 - 1;
        UNLOCK();
        if (uVar3 - 1 == 0) {
          uVar5 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar5 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 15651 ; VA 0x008eea10 ; FUN_008eea10 */

undefined4 __thiscall FUN_008eea10(int param_1,undefined4 param_2)

{
  FUN_0054ef60(*(undefined4 *)(param_1 + 0x2c));
  return param_2;
}



/* FUNCTION 15652 ; VA 0x008eea30 ; FUN_008eea30 */

void __fastcall FUN_008eea30(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3868;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x49c) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_1c,"BindToClose failed because the model is already being closed.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00971ce0(param_1 + 0xc,1);
  if (cVar3 != '\0') {
    iVar1 = *(int *)(param_1 + 0x490);
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar4 = FUN_008dd040(iVar1,puVar2,&stack0x00000004);
    if (*(int *)(param_1 + 0x494) != 0x6666665) {
      *(int *)(param_1 + 0x494) = *(int *)(param_1 + 0x494) + 1;
      *(undefined4 *)(iVar1 + 4) = uVar4;
      *puVar2 = uVar4;
      FUN_00d88a30();
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  FUN_00550130("BindToClose can only be called on the server.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 15653 ; VA 0x008eeb10 ; FUN_008eeb10 */

void FUN_008eeb10(undefined4 param_1,code *param_2,undefined4 param_3,uint param_4,uint *param_5,
                 uint *param_6)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3898;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee05ac);
  auStack_6c[0] = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0x8eeb87;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_008dc110();
  uStack_8._0_1_ = 2;
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x8eec6c;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_a8 = param_4;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_a8 = 0x8eec96;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15654 ; VA 0x008eecb0 ; FUN_008eecb0 */

void FUN_008eecb0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c38c0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee05ac);
  uVar1 = *param_4;
  auStack_6c[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_6c;
  puVar4 = auStack_6c;
  if (uVar2 != 0) {
    auStack_6c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0x8eed2f;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_1c;
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_6c;
      puVar4 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_008dc2e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x8eee11;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(0x8eee2e,(undefined4)uStack_98);
  uStack_90 = uVar1;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15655 ; VA 0x008eee40 ; FUN_008eee40 */

void FUN_008eee40(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [8];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c38e0;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee05ac);
  uVar1 = *param_5;
  uStack_48 = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_7 + 2;
      uStack_58 = 0x8eeec2;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_7[2];
      uStack_3c = param_7[3];
      uStack_38 = param_7[4];
      uStack_34 = param_7[5];
      uStack_30 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_6[2];
      uStack_ac = param_6[3];
      uStack_a8 = param_6[4];
      uStack_a4 = param_6[5];
      uStack_a0 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_008e5f10);
  uStack_98 = 0x8eef39;
  FUN_008dc050();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_88 = param_4;
  uStack_8c = 0x8eef4d;
  uStack_6c = uVar1;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_88 = 0x8eef5a;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15656 ; VA 0x008eef70 ; FUN_008eef70 */

void FUN_008eef70(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 *param_7,uint *param_8,
                 uint *param_9)

{
  undefined4 uVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [8];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3910;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee05ac);
  uVar1 = *param_7;
  uStack_48 = 0;
  uVar2 = *param_9;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_9 + 2;
      uStack_58 = 0x8eeff2;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_9[2];
      uStack_3c = param_9[3];
      uStack_38 = param_9[4];
      uStack_34 = param_9[5];
      uStack_30 = *(undefined8 *)(param_9 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_8;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_8 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_8[2];
      uStack_ac = param_8[3];
      uStack_a8 = param_8[4];
      uStack_a4 = param_8[5];
      uStack_a0 = *(undefined8 *)(param_8 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_008e5f10);
  uStack_98 = 0x8ef069;
  FUN_008dc050();
  uStack_8._0_1_ = 1;
  uStack_88 = param_6;
  uStack_8c = 0x8ef080;
  uStack_6c = uVar1;
  FUN_0054ef60();
  uStack_8._0_1_ = 2;
  uStack_a0 = CONCAT44(uStack_a0._4_4_,param_5);
  uStack_a4 = 0x8ef094;
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15657 ; VA 0x008ef0d0 ; FUN_008ef0d0 */

void FUN_008ef0d0(undefined4 param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined8 uStack_30;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3948;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_30 = CONCAT44(&uStack_20,0x8ef0fd);
  ExceptionList = &pvStack_10;
  FUN_008c05f0();
  puStack_14 = (undefined *)auStack_48;
  puStack_18 = (undefined *)auStack_48;
  uStack_8._0_1_ = 3;
  auStack_48[0] = 0;
  puVar3 = auStack_48;
  if (param_10 != 0) {
    auStack_48[0] = param_10;
    if ((param_10 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      puStack_54 = &param_12;
      uStack_58 = 0x8ef145;
      (**(code **)(param_10 & 0xfffffffe))();
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_40 = param_12;
      uStack_3c = param_13;
      uStack_38 = param_14;
      puStack_34 = (undefined4 *)param_15;
      uStack_30 = param_16;
      puVar3 = auStack_48;
    }
  }
  puStack_14 = (undefined *)puVar3;
  puStack_18 = (undefined *)auStack_68;
  uStack_8._0_1_ = 4;
  auStack_68[0] = 0;
  puVar3 = auStack_68;
  if (param_3 != 0) {
    auStack_68[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_60,0);
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_60 = param_5;
      uStack_5c = param_6;
      uStack_58 = param_7;
      puStack_54 = param_8;
      uStack_50 = param_9;
      puVar3 = auStack_68;
    }
  }
  puStack_18 = (undefined *)puVar3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00f50180(param_1,param_2,uStack_20,piStack_1c);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_30 = CONCAT44(0x8ef1ff,(undefined4)uStack_30);
      (**(code **)*piStack_1c)();
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_30 = CONCAT44(0x8ef20f,(undefined4)uStack_30);
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_30 = CONCAT44(0x8ef225,(undefined4)uStack_30);
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_30 = CONCAT44(0x8ef234,(undefined4)uStack_30);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_34 = &param_5;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0x8ef255;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_34 = &param_12;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0x8ef283;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15658 ; VA 0x008ef2a0 ; FUN_008ef2a0 */

void __fastcall FUN_008ef2a0(int param_1)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined auStack_48 [24];
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3983;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x43c);
  if ((int *)*piVar2 == piVar2 && (int *)piVar2[1] == piVar2) {
    if (DAT_01d65192 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01d65192,"Place Id is zero, skipping fetch",0);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else if (*(char *)(param_1 + 0x449) == '\0') {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_005c4070();
    if (*piVar2 != 0) {
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      iStack_8 = 0;
      if (param_1 != -0xc) {
        piVar2 = (int *)FUN_0064f8c0();
        if (*piVar2 != 0) {
          piVar2 = *(int **)(param_1 + 0x43c);
          uVar3 = FUN_01675640(auStack_48,"game/GetAllowedExperimentalFeatures?placeId=%lld",
                               *piVar2 - (int)piVar2,piVar2[1] - (int)piVar2);
          iStack_8._0_1_ = 1;
          FUN_00bcaf30(uVar3,2,auStack_30,0);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_005507b0();
        }
      }
      FUN_00729510(auStack_30,3,1);
      uStack_18 = 0;
      uStack_14 = 0;
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      cVar1 = FUN_0098f070(auStack_30,&uStack_18,0);
      if ((cVar1 == '\0') && (DAT_01d65192 != '\0')) {
        FUN_016774b0(DAT_01d65192,"Can\'t parse JSON",0);
      }
      *(undefined *)(param_1 + 0x449) = 1;
      FUN_00550b30();
      FUN_005705c0();
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15659 ; VA 0x008ef420 ; FUN_008ef420 */

undefined4 __thiscall FUN_008ef420(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iStack_c;
  int iStack_8;
  
  FUN_016830f0(&iStack_c);
  if ((double)CONCAT44(iStack_8,iStack_c) - *(double *)(param_1 + 6) <= DAT_018cf108) {
    iVar1 = *param_1;
    iVar3 = param_1[1];
  }
  else {
    param_1[6] = iStack_c;
    param_1[7] = iStack_8;
    iVar1 = 0;
    iVar3 = 0;
  }
  *param_1 = iVar1 + 1;
  iVar4 = param_2;
  if (param_2 < iVar3) {
    iVar4 = iVar3;
  }
  param_1[1] = iVar4;
  if ((param_2 != 0) || (piVar2 = (int *)param_1[4], piVar2 == (int *)0x0)) {
    piVar2 = (int *)param_1[2];
  }
  iVar3 = *piVar2;
  piVar2 = (int *)param_1[3];
  if (piVar2 != (int *)0x0) {
    piVar2 = (int *)(*piVar2 * iVar4);
    iVar3 = iVar3 + (int)piVar2;
  }
  return CONCAT31((int3)((uint)piVar2 >> 8),iVar1 + 1 <= iVar3);
}



/* FUNCTION 15660 ; VA 0x008ef4a0 ; FUN_008ef4a0 */

void __thiscall FUN_008ef4a0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code **ppcVar4;
  int iVar5;
  undefined4 uVar6;
  code *pcStack_128;
  undefined4 uStack_124;
  undefined4 *puStack_120;
  uint uStack_118;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined8 uStack_100;
  uint uStack_f8;
  undefined4 uStack_e8;
  undefined *puStack_e4;
  undefined8 uStack_e0;
  undefined *puStack_d8;
  int iStack_d4;
  undefined auStack_60 [24];
  code *pcStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  ulonglong uStack_20;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c39c3;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x43c);
  uStack_8 = 0;
  iVar2 = *piVar1;
  iVar3 = piVar1[1];
  iStack_18 = param_1;
  if (iVar2 - (int)piVar1 == 0 && iVar3 - (int)piVar1 == 0) {
    if (param_2 == 0) {
      iStack_d4 = 0x8ef68d;
      ExceptionList = &pvStack_10;
      iStack_d4 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
      puStack_d8 = (undefined *)0x8ef697;
      FUN_0054e5e0();
    }
    puStack_d8 = &stack0x0000000c;
    iStack_d4 = 1;
    uStack_e0._4_4_ = (undefined *)0x8ef4f8;
    ExceptionList = &pvStack_10;
    (**(code **)((param_2 & 0xfffffffe) + 4))();
  }
  else {
    iStack_d4 = param_1 + 0xc;
    puStack_d8 = (undefined *)0x8ef509;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0097bfc0();
    if (iVar5 == 0) {
      if (param_2 == 0) {
        iStack_d4 = 0x8ef69f;
        iStack_d4 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
        puStack_d8 = &UNK_008ef6a9;
        FUN_0054e5e0();
      }
      puStack_d8 = &stack0x0000000c;
      iStack_d4 = 0;
      uStack_e0._4_4_ = (undefined *)0x8ef529;
      (**(code **)((param_2 & 0xfffffffe) + 4))();
    }
    else {
      uStack_e0._4_4_ = (undefined *)0x8ef53a;
      puStack_d8 = (undefined *)(iVar2 - (int)piVar1);
      iStack_d4 = iVar3 - (int)piVar1;
      uStack_e0 = FUN_00928340();
      puStack_e4 = auStack_60;
      uStack_e8 = 0x8ef545;
      uVar6 = FUN_00f52e50();
      iStack_d4 = 0;
      puStack_d8 = (undefined *)0x0;
      uStack_8._0_1_ = 3;
      uStack_e0._0_4_ = 0x8ef55c;
      uStack_e0._4_4_ = (undefined *)uVar6;
      FUN_014cc090();
      uStack_8._0_1_ = 5;
      iStack_d4 = 0x8ef568;
      FUN_005507b0();
      uStack_f8 = (uint)DAT_01ee05ad;
      iStack_d4 = 0;
      uStack_100 = (ulonglong)CONCAT14(DAT_01ee05ac,(undefined4)uStack_100);
      puStack_120 = &param_2;
      uStack_124 = 0x8ef590;
      FUN_0054f510();
      puStack_120 = (undefined4 *)iStack_18;
      uStack_124 = 0;
      pcStack_128 = FUN_008fc160;
      FUN_008e0c60(&pcStack_48);
      uStack_f8 = 0;
      puStack_14 = (undefined *)&pcStack_128;
      uStack_8._0_1_ = 6;
      pcStack_128 = pcStack_48;
      uStack_124 = uStack_44;
      puStack_120 = (undefined4 *)uStack_40;
      uStack_118 = 0;
      ppcVar4 = &pcStack_128;
      if (uStack_38 != 0) {
        uStack_118 = uStack_38;
        if ((uStack_38 & 1) == 0) {
          (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_110,0);
          ppcVar4 = (code **)puStack_14;
        }
        else {
          uStack_110 = uStack_30;
          uStack_10c = uStack_2c;
          uStack_108 = uStack_28;
          uStack_104 = uStack_24;
          uStack_100 = uStack_20;
          ppcVar4 = &pcStack_128;
        }
      }
      puStack_14 = (undefined *)ppcVar4;
      FUN_008dcc40();
      uStack_8._0_1_ = 7;
      if (uStack_38 != 0) {
        if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
          uStack_f8 = 2;
          uStack_100 = CONCAT44(&uStack_30,&uStack_30);
          uStack_104 = 0x8ef628;
          (**(code **)(uStack_38 & 0xfffffffe))();
        }
        uStack_38 = 0;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      uStack_f8 = 0x8ef641;
      FUN_014ccc70();
      iStack_d4 = 0x8ef64c;
      FUN_0056db40();
    }
  }
  uStack_8 = 8;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    uStack_e0._4_4_ = &stack0x0000000c;
    iStack_d4 = 2;
    uStack_e0._0_4_ = 0x8ef670;
    puStack_d8 = uStack_e0._4_4_;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15661 ; VA 0x008ef6b0 ; FUN_008ef6b0 */

void __fastcall FUN_008ef6b0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      (**(code **)(piVar2[2] + 4))(0);
      FUN_01674ea0(piVar2,0x28);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 15662 ; VA 0x008ef700 ; FUN_008ef700 */

void __thiscall FUN_008ef700(int param_1,int param_2)

{
  uint uVar1;
  undefined *puVar2;
  uint *puVar3;
  uint auStack_70 [2];
  undefined auStack_68 [24];
  uint auStack_50 [2];
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017c39e0;
  pvStack_1c = ExceptionList;
  auStack_70[0] = 0;
  pcStack_28 = *(code **)(param_1 + 0x40);
  uStack_2c = *(undefined4 *)(param_1 + 0x44);
  uStack_14 = 0;
  auStack_50[0] = 0;
  puVar3 = (uint *)(*(int *)(param_1 + 0x38) + (-(uint)(param_2 != 0) & param_2 - 0xcU));
  uVar1 = *puVar3;
  ExceptionList = &pvStack_1c;
  puVar2 = &stack0xfffffffc;
  if (uVar1 != 0) {
    auStack_50[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_1c;
      (**(code **)(uVar1 & 0xfffffffe))(puVar3 + 2,&uStack_48,0);
      puVar2 = puStack_20;
    }
    else {
      uStack_48 = puVar3[2];
      uStack_44 = puVar3[3];
      uStack_40 = puVar3[4];
      uStack_3c = puVar3[5];
      uStack_38 = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_1c;
      puVar2 = &stack0xfffffffc;
    }
  }
  puStack_20 = puVar2;
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_008eb360(auStack_70);
  if (pcStack_28 != (code *)0x0) {
    (*pcStack_28)(auStack_50);
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  if (auStack_50[0] != 0) {
    if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_50[0] & 0xfffffffe))(&uStack_48,&uStack_48,2);
    }
    auStack_50[0] = 0;
  }
  uStack_14 = 3;
  if (((auStack_70[0] != 0) && ((auStack_70[0] & 1) == 0)) &&
     (*(code **)(auStack_70[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_70[0] & 0xfffffffe))(auStack_68,auStack_68,2);
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 15663 ; VA 0x008ef830 ; FUN_008ef830 */

void __fastcall FUN_008ef830(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  uint uVar10;
  int iVar11;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3a88;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1 + 3;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  piVar1 = (int *)FUN_005641e0();
  if (*piVar1 != 0) {
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Closing Script Context",0);
    }
    FUN_0094bc70();
  }
  if (param_1[0x6e] != 0) {
    iVar2 = FUN_00a9d3e0();
    if (iVar2 != 0) {
      iVar2 = FUN_00a9d3e0();
      *(undefined *)(iVar2 + 0x22) = 0;
    }
    FUN_008bac40(0,0,0);
    iVar2 = param_1[0x6e];
    if ((*(int *)(iVar2 + 0x1b4) != 0) && (*(int *)(*(int *)(iVar2 + 0x1b4) + 0x6ac) != 0)) {
      FUN_00ce0e00();
      iVar2 = param_1[0x6e];
    }
    piStack_1c = *(int **)(iVar2 + 0x1b4);
    if (piStack_1c == (int *)0x0) {
LAB_008ef9c2:
      if (DAT_01d65192 != '\0') {
        iVar2 = param_1[0x6e];
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = FUN_00b73900();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        piVar9 = (int *)(uint)(iVar7 != 0);
        piStack_20 = piVar9;
        if (piVar1 != (int *)0x0) {
          piStack_2c = *(int **)(iVar2 + 0x30);
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 0;
          piStack_1c = piStack_2c;
          piStack_30 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0f00();
            piVar9 = (int *)((int)piVar9 + iVar7);
          }
          uStack_8 = 0xffffffff;
          piStack_20 = piVar9;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              iVar2 = piStack_1c[2] + -1;
              piStack_1c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_1c + 4))();
              }
            }
          }
        }
        iVar2 = piStack_18[0x6e];
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = FUN_00aff8c0();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        uVar10 = (uint)(iVar7 != 0);
        uStack_28 = uVar10;
        if (piVar1 != (int *)0x0) {
          piStack_2c = *(int **)(iVar2 + 0x30);
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 1;
          piStack_1c = piStack_2c;
          piStack_30 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e10a0();
            uVar10 = uVar10 + iVar7;
          }
          uStack_8 = 0xffffffff;
          uStack_28 = uVar10;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              iVar2 = piStack_1c[2] + -1;
              piStack_1c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_1c + 4))();
              }
            }
          }
        }
        iVar2 = piStack_18[0x6e];
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = thunk_FUN_00897b90();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        piVar9 = (int *)(uint)(iVar7 != 0);
        piStack_2c = piVar9;
        if (piVar1 != (int *)0x0) {
          piStack_34 = *(int **)(iVar2 + 0x30);
          if (piStack_34 != (int *)0x0) {
            LOCK();
            piStack_34[1] = piStack_34[1] + 1;
            UNLOCK();
            piStack_34 = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 2;
          piStack_1c = piStack_34;
          piStack_38 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0fd0();
            piVar9 = (int *)((int)piVar9 + iVar7);
          }
          uStack_8 = 0xffffffff;
          piStack_2c = piVar9;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              iVar2 = piStack_1c[2] + -1;
              piStack_1c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_1c + 4))();
              }
            }
          }
        }
        FUN_01677490(DAT_01d65192,"Clearing Workspace -- %d Instances, %d Parts, %d Scripts",
                     piStack_2c,uStack_28,piStack_20);
        param_1 = piStack_18;
      }
    }
    else if (DAT_01d65192 != '\0') {
      uVar3 = FUN_00bbdd20();
      uVar4 = FUN_00554ed0();
      uVar5 = FUN_00554ed0();
      FUN_01677490(DAT_01d65192,"Clearing World -- %d Bodies, %d Points, %d Constraints",uVar5,uVar4
                   ,uVar3);
      param_1 = piStack_18;
      if (DAT_01d65192 != '\0') {
        iVar2 = piStack_1c[0x191];
        uVar3 = FUN_00bbdc40();
        uVar4 = FUN_00bbdd40();
        FUN_01677490(DAT_01d65192,
                     "Clearing World -- %d HashNodes, %d MaxBucketSize, %d NumLinkCalls",uVar4,uVar3
                     ,iVar2);
        param_1 = piStack_18;
        if (DAT_01d65192 != '\0') {
          iVar2 = piStack_1c[0x33];
          iVar11 = piStack_1c[399];
          uVar3 = FUN_00bbdd30();
          FUN_01677490(DAT_01d65192,"Clearing World -- %d Contacts, %d Joints, %d Primitives",uVar3,
                       iVar11,iVar2);
          param_1 = piStack_18;
          goto LAB_008ef9c2;
        }
      }
    }
    FUN_008a50b0();
    FUN_008ba0d0(0);
  }
  iVar2 = param_1[100];
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      iVar11 = *(int *)(iVar2 + 0xc);
      iVar6 = thunk_FUN_00897b90();
      piVar1 = *(int **)(iVar2 + 0x2c);
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = iVar2;
      }
      uVar10 = (uint)(iVar7 != 0);
      uStack_28 = uVar10;
      if (piVar1 != (int *)0x0) {
        piStack_34 = *(int **)(iVar2 + 0x30);
        if (piStack_34 != (int *)0x0) {
          LOCK();
          piStack_34[1] = piStack_34[1] + 1;
          UNLOCK();
          piStack_34 = *(int **)(iVar2 + 0x30);
          piVar1 = *(int **)(iVar2 + 0x2c);
        }
        iVar2 = piVar1[1];
        iVar11 = *piVar1;
        uStack_8 = 3;
        piStack_2c = piStack_34;
        piStack_38 = piVar1;
        for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
          iVar7 = FUN_008e0fd0();
          uVar10 = uVar10 + iVar7;
        }
        uStack_8 = 0xffffffff;
        uStack_28 = uVar10;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      FUN_016774b0(DAT_01d65192,"Clearing StarterPack -- %d Instances",uStack_28);
      param_1 = piStack_18;
    }
    FUN_008a50b0();
  }
  iVar2 = param_1[0x68];
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      iVar11 = *(int *)(iVar2 + 0xc);
      iVar6 = thunk_FUN_00897b90();
      piVar1 = *(int **)(iVar2 + 0x2c);
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = iVar2;
      }
      uVar10 = (uint)(iVar7 != 0);
      uStack_28 = uVar10;
      if (piVar1 != (int *)0x0) {
        piStack_34 = *(int **)(iVar2 + 0x30);
        if (piStack_34 != (int *)0x0) {
          LOCK();
          piStack_34[1] = piStack_34[1] + 1;
          UNLOCK();
          piStack_34 = *(int **)(iVar2 + 0x30);
          piVar1 = *(int **)(iVar2 + 0x2c);
        }
        iVar2 = piVar1[1];
        iVar11 = *piVar1;
        uStack_8 = 4;
        piStack_2c = piStack_34;
        piStack_38 = piVar1;
        for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
          iVar7 = FUN_008e0fd0();
          uVar10 = uVar10 + iVar7;
        }
        uStack_8 = 0xffffffff;
        uStack_28 = uVar10;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      FUN_016774b0(DAT_01d65192,"Clearing StarterPlayer -- %d Instances",uStack_28);
      param_1 = piStack_18;
    }
    FUN_00bb5690();
  }
  iVar2 = param_1[0x66];
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      iVar11 = *(int *)(iVar2 + 0xc);
      iVar6 = thunk_FUN_00897b90();
      piVar1 = *(int **)(iVar2 + 0x2c);
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = iVar2;
      }
      uVar10 = (uint)(iVar7 != 0);
      uStack_28 = uVar10;
      if (piVar1 != (int *)0x0) {
        piStack_34 = *(int **)(iVar2 + 0x30);
        if (piStack_34 != (int *)0x0) {
          LOCK();
          piStack_34[1] = piStack_34[1] + 1;
          UNLOCK();
          piStack_34 = *(int **)(iVar2 + 0x30);
          piVar1 = *(int **)(iVar2 + 0x2c);
        }
        iVar2 = piVar1[1];
        iVar11 = *piVar1;
        uStack_8 = 5;
        piStack_2c = piStack_34;
        piStack_38 = piVar1;
        for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
          iVar7 = FUN_008e0fd0();
          uVar10 = uVar10 + iVar7;
        }
        uStack_8 = 0xffffffff;
        uStack_28 = uVar10;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      FUN_016774b0(DAT_01d65192,"Clearing StarterGui -- %d Instances",uStack_28);
      param_1 = piStack_18;
    }
    FUN_008a50b0();
  }
  iVar2 = param_1[0x60];
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      iVar11 = *(int *)(iVar2 + 0xc);
      iVar6 = thunk_FUN_00897b90();
      piVar1 = *(int **)(iVar2 + 0x2c);
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = iVar2;
      }
      uVar10 = (uint)(iVar7 != 0);
      uStack_28 = uVar10;
      if (piVar1 != (int *)0x0) {
        piStack_34 = *(int **)(iVar2 + 0x30);
        if (piStack_34 != (int *)0x0) {
          LOCK();
          piStack_34[1] = piStack_34[1] + 1;
          UNLOCK();
          piStack_34 = *(int **)(iVar2 + 0x30);
          piVar1 = *(int **)(iVar2 + 0x2c);
        }
        iVar2 = piVar1[1];
        iVar11 = *piVar1;
        uStack_8 = 6;
        piStack_2c = piStack_34;
        piStack_38 = piVar1;
        for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
          iVar7 = FUN_008e0fd0();
          uVar10 = uVar10 + iVar7;
        }
        uStack_8 = 0xffffffff;
        uStack_28 = uVar10;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      FUN_016774b0(DAT_01d65192,"Clearing CoreGui -- %d Instances",uStack_28);
    }
    FUN_008a50b0();
  }
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    FUN_005789c0(&DAT_01eadd5c,&LAB_00670d60);
    uVar3 = FUN_006763b0();
    piStack_18 = (int *)FUN_008aa140(uVar3);
    if (*piStack_18 == 0) {
      uVar3 = FUN_00bdf940();
      piVar9 = (int *)FUN_008a9ba0(&piStack_38,uVar3);
      iVar2 = *piVar9;
      iVar11 = piVar9[1];
      *piVar9 = 0;
      piVar9[1] = 0;
      *piStack_18 = iVar2;
      piVar9 = (int *)piStack_18[1];
      piStack_18[1] = iVar11;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar2 = piVar9[1] + -1;
        piVar9[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          iVar2 = piVar9[2] + -1;
          piVar9[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      piVar9 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_34[1] + -1;
        piStack_34[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar8 = piVar9 + 2;
          iVar2 = *piVar8 + -1;
          *piVar8 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    piVar9 = (int *)*piStack_18;
    piStack_1c = piVar9;
    if (piVar9 != (int *)0x0) {
      if (DAT_01d65192 != '\0') {
        iVar2 = piVar9[3];
        iVar11 = thunk_FUN_00897b90();
        piVar1 = (int *)piVar9[0xb];
        piVar8 = (int *)0x0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8) <=
            (uint)*(ushort *)(iVar11 + 0x1da)) {
          piVar8 = piVar9;
        }
        uVar10 = (uint)(piVar8 != (int *)0x0);
        uStack_28 = uVar10;
        if (piVar1 != (int *)0x0) {
          piStack_2c = (int *)piVar9[0xc];
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = (int *)piVar9[0xc];
            piVar1 = (int *)piVar9[0xb];
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 7;
          piStack_20 = piStack_2c;
          piStack_24 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0fd0();
            uVar10 = uVar10 + iVar7;
          }
          uStack_8 = 0xffffffff;
          uStack_28 = uVar10;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              iVar2 = piStack_2c[2] + -1;
              piStack_2c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
          }
        }
        FUN_016774b0(DAT_01d65192,"Clearing Teams -- %d Instances",uStack_28);
        piVar1 = piStack_14;
      }
      FUN_008a50b0();
    }
    if (piVar1 != (int *)0x0) {
      FUN_005789c0(&DAT_01ee0d38,&LAB_008e0ed0);
      uVar3 = FUN_008e4020();
      piStack_18 = (int *)FUN_008aa140(uVar3);
      if (*piStack_18 == 0) {
        uVar3 = FUN_00e46b80();
        piVar9 = (int *)FUN_008a9ba0(&piStack_38,uVar3);
        iVar2 = *piVar9;
        iVar11 = piVar9[1];
        *piVar9 = 0;
        piVar9[1] = 0;
        *piStack_18 = iVar2;
        piVar9 = (int *)piStack_18[1];
        piStack_18[1] = iVar11;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar2 = piVar9[1] + -1;
          piVar9[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar2 = piVar9[2] + -1;
            piVar9[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = piStack_34;
        if (piStack_34 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_34[1] + -1;
          piStack_34[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_34)();
            LOCK();
            piVar8 = piVar9 + 2;
            iVar2 = *piVar8 + -1;
            *piVar8 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      if (*piStack_18 != 0) {
        FUN_00e47190();
      }
    }
  }
  iVar2 = FUN_008e4410(piVar1);
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Clearing ChangeHistoryService -- %d waypoints ",
                   *(undefined4 *)(iVar2 + 0x70));
    }
    FUN_00a62440();
  }
  iVar2 = FUN_00712d20(piVar1);
  piStack_1c = (int *)iVar2;
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      iVar11 = *(int *)(iVar2 + 0xc);
      iVar6 = thunk_FUN_00897b90();
      piVar1 = *(int **)(iVar2 + 0x2c);
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = iVar2;
      }
      uVar10 = (uint)(iVar7 != 0);
      uStack_28 = uVar10;
      if (piVar1 != (int *)0x0) {
        piStack_34 = *(int **)(iVar2 + 0x30);
        if (piStack_34 != (int *)0x0) {
          LOCK();
          piStack_34[1] = piStack_34[1] + 1;
          UNLOCK();
          piStack_34 = *(int **)(iVar2 + 0x30);
          piVar1 = *(int **)(iVar2 + 0x2c);
        }
        iVar2 = piVar1[1];
        iVar11 = *piVar1;
        uStack_8 = 8;
        piStack_2c = piStack_34;
        piStack_38 = piVar1;
        for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
          iVar7 = FUN_008e0fd0();
          uVar10 = uVar10 + iVar7;
        }
        uStack_8 = 0xffffffff;
        uStack_28 = uVar10;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      FUN_016774b0(DAT_01d65192,"Clearing Lighting -- %d Instances",uStack_28);
      piVar1 = piStack_14;
    }
    FUN_008a50b0();
  }
  if (piVar1 != (int *)0x0) {
    piVar9 = (int *)FUN_006771e0();
    iVar2 = *piVar9;
    piStack_1c = (int *)iVar2;
    if (iVar2 != 0) {
      if (DAT_01d65192 != '\0') {
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = thunk_FUN_00897b90();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        uVar10 = (uint)(iVar7 != 0);
        uStack_28 = uVar10;
        if (piVar1 != (int *)0x0) {
          piStack_34 = *(int **)(iVar2 + 0x30);
          if (piStack_34 != (int *)0x0) {
            LOCK();
            piStack_34[1] = piStack_34[1] + 1;
            UNLOCK();
            piStack_34 = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 9;
          piStack_2c = piStack_34;
          piStack_38 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0fd0();
            uVar10 = uVar10 + iVar7;
          }
          uStack_8 = 0xffffffff;
          uStack_28 = uVar10;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              iVar2 = piStack_2c[2] + -1;
              piStack_2c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
          }
        }
        FUN_016774b0(DAT_01d65192,"Clearing JointsService -- %d Instances",uStack_28);
        piVar1 = piStack_14;
      }
      FUN_008a50b0();
    }
    if (piVar1 != (int *)0x0) {
      FUN_005789c0(&DAT_01eadd8c,&LAB_00670d70);
      uVar3 = FUN_00676430();
      piStack_18 = (int *)FUN_008aa140(uVar3);
      if (*piStack_18 == 0) {
        uVar3 = FUN_00c00440();
        piVar9 = (int *)FUN_008a9ba0(&piStack_38,uVar3);
        iVar2 = *piVar9;
        iVar11 = piVar9[1];
        *piVar9 = 0;
        piVar9[1] = 0;
        *piStack_18 = iVar2;
        piVar9 = (int *)piStack_18[1];
        piStack_18[1] = iVar11;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar2 = piVar9[1] + -1;
          piVar9[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar2 = piVar9[2] + -1;
            piVar9[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = piStack_34;
        if (piStack_34 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_34[1] + -1;
          piStack_34[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_34)();
            LOCK();
            piVar8 = piVar9 + 2;
            iVar2 = *piVar8 + -1;
            *piVar8 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      iVar2 = *piStack_18;
      piStack_1c = (int *)iVar2;
      if (iVar2 != 0) {
        if (DAT_01d65192 != '\0') {
          iVar11 = *(int *)(iVar2 + 0xc);
          iVar6 = thunk_FUN_00897b90();
          piVar1 = *(int **)(iVar2 + 0x2c);
          iVar7 = 0;
          if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            iVar7 = iVar2;
          }
          uVar10 = (uint)(iVar7 != 0);
          uStack_28 = uVar10;
          if (piVar1 != (int *)0x0) {
            piStack_2c = *(int **)(iVar2 + 0x30);
            if (piStack_2c != (int *)0x0) {
              LOCK();
              piStack_2c[1] = piStack_2c[1] + 1;
              UNLOCK();
              piStack_2c = *(int **)(iVar2 + 0x30);
              piVar1 = *(int **)(iVar2 + 0x2c);
            }
            iVar2 = piVar1[1];
            iVar11 = *piVar1;
            uStack_8 = 10;
            piStack_20 = piStack_2c;
            piStack_24 = piVar1;
            for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
              iVar7 = FUN_008e0fd0();
              uVar10 = uVar10 + iVar7;
            }
            uStack_8 = 0xffffffff;
            uStack_28 = uVar10;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar2 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_2c)();
                LOCK();
                iVar2 = piStack_2c[2] + -1;
                piStack_2c[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piStack_2c + 4))();
                }
              }
            }
          }
          FUN_016774b0(DAT_01d65192,"Clearing TestService -- %d Instances",uStack_28);
          piVar1 = piStack_14;
        }
        FUN_008a50b0();
      }
      if (piVar1 != (int *)0x0) {
        FUN_005789c0(&DAT_01eaddc4,&LAB_00670cf0);
        uVar3 = FUN_00676030();
        piStack_1c = (int *)FUN_008aa140(uVar3);
        if (*piStack_1c == 0) {
          uVar3 = FUN_00b624e0();
          uVar3 = FUN_008a9ba0(&piStack_38,uVar3);
          FUN_005587e0(uVar3);
          piVar9 = piStack_34;
          if (piStack_34 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_34[1] + -1;
            piStack_34[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_34)();
              LOCK();
              piVar8 = piVar9 + 2;
              iVar2 = *piVar8 + -1;
              *piVar8 = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
        }
        iVar2 = *piStack_1c;
        piStack_1c = (int *)iVar2;
        if (iVar2 != 0) {
          if (DAT_01d65192 != '\0') {
            iVar11 = *(int *)(iVar2 + 0xc);
            iVar6 = thunk_FUN_00897b90();
            piVar1 = *(int **)(iVar2 + 0x2c);
            iVar7 = 0;
            if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                (uint)*(ushort *)(iVar6 + 0x1da)) {
              iVar7 = iVar2;
            }
            uVar10 = (uint)(iVar7 != 0);
            uStack_28 = uVar10;
            if (piVar1 != (int *)0x0) {
              piStack_2c = *(int **)(iVar2 + 0x30);
              if (piStack_2c != (int *)0x0) {
                LOCK();
                piStack_2c[1] = piStack_2c[1] + 1;
                UNLOCK();
                piStack_2c = *(int **)(iVar2 + 0x30);
                piVar1 = *(int **)(iVar2 + 0x2c);
              }
              iVar2 = piVar1[1];
              iVar11 = *piVar1;
              uStack_8 = 0xb;
              piStack_20 = piStack_2c;
              piStack_24 = piVar1;
              for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
                iVar7 = FUN_008e0fd0();
                uVar10 = uVar10 + iVar7;
              }
              uStack_8 = 0xffffffff;
              uStack_28 = uVar10;
              if (piStack_2c != (int *)0x0) {
                LOCK();
                iVar2 = piStack_2c[1] + -1;
                piStack_2c[1] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)*piStack_2c)();
                  LOCK();
                  iVar2 = piStack_2c[2] + -1;
                  piStack_2c[2] = iVar2;
                  UNLOCK();
                  if (iVar2 == 0) {
                    (**(code **)(*piStack_2c + 4))();
                  }
                }
              }
            }
            FUN_016774b0(DAT_01d65192,"Clearing ServerScriptService -- %d Instances",uStack_28);
            piVar1 = piStack_14;
          }
          FUN_008a50b0();
        }
      }
    }
  }
  if (DAT_01d680f0 == '\0') {
LAB_008f08ad:
    if (piVar1 == (int *)0x0) goto LAB_008f0b76;
    FUN_005789c0(&DAT_01eadd7c,&LAB_00670cd0);
    uVar3 = FUN_00675f30();
    piStack_1c = (int *)FUN_008aa140(uVar3);
    if (*piStack_1c == 0) {
      uVar3 = FUN_00bff000();
      uVar3 = FUN_008a9ba0(&piStack_38,uVar3);
      FUN_005587e0(uVar3);
      piVar9 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_34[1] + -1;
        piStack_34[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar8 = piVar9 + 2;
          iVar2 = *piVar8 + -1;
          *piVar8 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    iVar2 = *piStack_1c;
    piStack_1c = (int *)iVar2;
    if (iVar2 != 0) {
      if (DAT_01d65192 != '\0') {
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = thunk_FUN_00897b90();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        uVar10 = (uint)(iVar7 != 0);
        uStack_28 = uVar10;
        if (piVar1 != (int *)0x0) {
          piStack_2c = *(int **)(iVar2 + 0x30);
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 0xd;
          piStack_20 = piStack_2c;
          piStack_24 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0fd0();
            uVar10 = uVar10 + iVar7;
          }
          uStack_8 = 0xffffffff;
          uStack_28 = uVar10;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              iVar2 = piStack_2c[2] + -1;
              piStack_2c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
          }
        }
        FUN_016774b0(DAT_01d65192,"Clearing ReplicatedStorage -- %d Instances",uStack_28);
        piVar1 = piStack_14;
      }
      FUN_008a50b0();
    }
    if (piVar1 == (int *)0x0) goto LAB_008f0b76;
    FUN_005789c0(&DAT_01eadd84,&LAB_00670ce0);
    uVar3 = FUN_00675fb0();
    piStack_1c = (int *)FUN_008aa140(uVar3);
    if (*piStack_1c == 0) {
      uVar3 = FUN_00bff6b0();
      uVar3 = FUN_008a9ba0(&piStack_38,uVar3);
      FUN_005587e0(uVar3);
      piVar9 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_34[1] + -1;
        piStack_34[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar8 = piVar9 + 2;
          iVar2 = *piVar8 + -1;
          *piVar8 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    iVar2 = *piStack_1c;
    piStack_1c = (int *)iVar2;
    if (iVar2 != 0) {
      if (DAT_01d65192 != '\0') {
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = thunk_FUN_00897b90();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        uVar10 = (uint)(iVar7 != 0);
        uStack_28 = uVar10;
        if (piVar1 != (int *)0x0) {
          piStack_2c = *(int **)(iVar2 + 0x30);
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 0xe;
          piStack_20 = piStack_2c;
          piStack_24 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0fd0();
            uVar10 = uVar10 + iVar7;
          }
          uStack_8 = 0xffffffff;
          uStack_28 = uVar10;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              iVar2 = piStack_2c[2] + -1;
              piStack_2c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
          }
        }
        FUN_016774b0(DAT_01d65192,"Clearing RobloxReplicatedStorage -- %d Instances",uStack_28);
        piVar1 = piStack_14;
      }
      FUN_008a50b0();
    }
    if (piVar1 == (int *)0x0) goto LAB_008f0b76;
    piVar9 = (int *)FUN_00677290();
    iVar2 = *piVar9;
  }
  else {
    if (piVar1 != (int *)0x0) {
      FUN_005789c0(&DAT_01eaddac,&LAB_00670cc0);
      uVar3 = FUN_00675eb0();
      piStack_1c = (int *)FUN_008aa140(uVar3);
      if (*piStack_1c == 0) {
        uVar3 = FUN_00bff2c0();
        uVar3 = FUN_008a9ba0(&piStack_38,uVar3);
        FUN_005587e0(uVar3);
        piVar9 = piStack_34;
        if (piStack_34 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_34[1] + -1;
          piStack_34[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_34)();
            LOCK();
            piVar8 = piVar9 + 2;
            iVar2 = *piVar8 + -1;
            *piVar8 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      iVar2 = *piStack_1c;
      piStack_1c = (int *)iVar2;
      if (iVar2 != 0) {
        if (DAT_01d65192 != '\0') {
          iVar11 = *(int *)(iVar2 + 0xc);
          iVar6 = thunk_FUN_00897b90();
          piVar1 = *(int **)(iVar2 + 0x2c);
          iVar7 = 0;
          if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            iVar7 = iVar2;
          }
          uVar10 = (uint)(iVar7 != 0);
          uStack_28 = uVar10;
          if (piVar1 != (int *)0x0) {
            piStack_2c = *(int **)(iVar2 + 0x30);
            if (piStack_2c != (int *)0x0) {
              LOCK();
              piStack_2c[1] = piStack_2c[1] + 1;
              UNLOCK();
              piStack_2c = *(int **)(iVar2 + 0x30);
              piVar1 = *(int **)(iVar2 + 0x2c);
            }
            iVar2 = piVar1[1];
            iVar11 = *piVar1;
            uStack_8 = 0xc;
            piStack_20 = piStack_2c;
            piStack_24 = piVar1;
            for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
              iVar7 = FUN_008e0fd0();
              uVar10 = uVar10 + iVar7;
            }
            uStack_8 = 0xffffffff;
            uStack_28 = uVar10;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar2 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_2c)();
                LOCK();
                iVar2 = piStack_2c[2] + -1;
                piStack_2c[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piStack_2c + 4))();
                }
              }
            }
          }
          FUN_016774b0(DAT_01d65192,"Clearing ReplicatedScriptService -- %d Instances",uStack_28);
          piVar1 = piStack_14;
        }
        FUN_008a50b0();
      }
      goto LAB_008f08ad;
    }
LAB_008f0b76:
    iVar2 = 0;
  }
  piStack_1c = (int *)iVar2;
  if (iVar2 != 0) {
    if (DAT_01d65192 != '\0') {
      iVar11 = *(int *)(iVar2 + 0xc);
      iVar6 = thunk_FUN_00897b90();
      piVar1 = *(int **)(iVar2 + 0x2c);
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = iVar2;
      }
      uVar10 = (uint)(iVar7 != 0);
      uStack_28 = uVar10;
      if (piVar1 != (int *)0x0) {
        piStack_34 = *(int **)(iVar2 + 0x30);
        if (piStack_34 != (int *)0x0) {
          LOCK();
          piStack_34[1] = piStack_34[1] + 1;
          UNLOCK();
          piStack_34 = *(int **)(iVar2 + 0x30);
          piVar1 = *(int **)(iVar2 + 0x2c);
        }
        iVar2 = piVar1[1];
        iVar11 = *piVar1;
        uStack_8 = 0xf;
        piStack_2c = piStack_34;
        piStack_38 = piVar1;
        for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
          iVar7 = FUN_008e0fd0();
          uVar10 = uVar10 + iVar7;
        }
        uStack_8 = 0xffffffff;
        uStack_28 = uVar10;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      FUN_016774b0(DAT_01d65192,"Clearing ReplicatedFirst -- %d Instances",uStack_28);
      piVar1 = piStack_14;
    }
    FUN_008a50b0();
  }
  if (piVar1 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_005789c0(&DAT_01eaddcc,&LAB_00670d00);
  uVar3 = FUN_006760b0();
  piStack_2c = (int *)FUN_008aa140(uVar3);
  iVar2 = *piStack_2c;
  if (iVar2 == 0) {
    piStack_1c = (int *)iVar2;
    uVar3 = FUN_00c09050();
    uVar3 = FUN_008a9ba0(&piStack_38,uVar3);
    piVar9 = piStack_2c;
    FUN_005587e0(uVar3);
    FUN_00550b30();
    iVar2 = *piVar9;
    piStack_1c = (int *)iVar2;
    if (iVar2 == 0) goto LAB_008f0d9b;
  }
  piStack_1c = (int *)iVar2;
  if (DAT_01d65192 != '\0') {
    iVar11 = *(int *)(iVar2 + 0xc);
    iVar6 = thunk_FUN_00897b90();
    piVar1 = *(int **)(iVar2 + 0x2c);
    iVar7 = 0;
    if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iVar7 = iVar2;
    }
    uVar10 = (uint)(iVar7 != 0);
    uStack_28 = uVar10;
    if (piVar1 != (int *)0x0) {
      piStack_2c = *(int **)(iVar2 + 0x30);
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[1] = piStack_2c[1] + 1;
        UNLOCK();
        piStack_2c = *(int **)(iVar2 + 0x30);
        piVar1 = *(int **)(iVar2 + 0x2c);
      }
      iVar2 = piVar1[1];
      iVar11 = *piVar1;
      uStack_8 = 0x10;
      piStack_20 = piStack_2c;
      piStack_24 = piVar1;
      for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
        iVar7 = FUN_008e0fd0();
        uVar10 = uVar10 + iVar7;
      }
      uStack_8 = 0xffffffff;
      uStack_28 = uVar10;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar2 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
    }
    FUN_016774b0(DAT_01d65192,"Clearing ServerStorage -- %d Instances",uStack_28);
    piVar1 = piStack_14;
  }
  FUN_008a50b0();
LAB_008f0d9b:
  if (piVar1 != (int *)0x0) {
    piVar9 = (int *)FUN_00677080();
    iVar2 = *piVar9;
    piStack_1c = (int *)iVar2;
    if (iVar2 != 0) {
      if (DAT_01d65192 != '\0') {
        iVar11 = *(int *)(iVar2 + 0xc);
        iVar6 = thunk_FUN_00897b90();
        piVar1 = *(int **)(iVar2 + 0x2c);
        iVar7 = 0;
        if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar7 = iVar2;
        }
        uVar10 = (uint)(iVar7 != 0);
        uStack_28 = uVar10;
        if (piVar1 != (int *)0x0) {
          piStack_34 = *(int **)(iVar2 + 0x30);
          if (piStack_34 != (int *)0x0) {
            LOCK();
            piStack_34[1] = piStack_34[1] + 1;
            UNLOCK();
            piStack_34 = *(int **)(iVar2 + 0x30);
            piVar1 = *(int **)(iVar2 + 0x2c);
          }
          iVar2 = piVar1[1];
          iVar11 = *piVar1;
          uStack_8 = 0x11;
          piStack_2c = piStack_34;
          piStack_38 = piVar1;
          for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
            iVar7 = FUN_008e0fd0();
            uVar10 = uVar10 + iVar7;
          }
          uStack_8 = 0xffffffff;
          uStack_28 = uVar10;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              iVar2 = piStack_2c[2] + -1;
              piStack_2c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
          }
        }
        FUN_016774b0(DAT_01d65192,"Clearing ChatService -- %d Instances",uStack_28);
        piVar1 = piStack_14;
      }
      FUN_008a50b0();
    }
    if (piVar1 != (int *)0x0) {
      piVar1 = (int *)FUN_005f5690();
      iVar2 = *piVar1;
      if (iVar2 != 0) {
        piStack_1c = (int *)iVar2;
        if (DAT_01d65192 != '\0') {
          iVar11 = *(int *)(iVar2 + 0xc);
          iVar6 = thunk_FUN_00897b90();
          piVar1 = *(int **)(iVar2 + 0x2c);
          iVar7 = 0;
          if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            iVar7 = iVar2;
          }
          uVar10 = (uint)(iVar7 != 0);
          uStack_28 = uVar10;
          if (piVar1 != (int *)0x0) {
            piStack_34 = *(int **)(iVar2 + 0x30);
            if (piStack_34 != (int *)0x0) {
              LOCK();
              piStack_34[1] = piStack_34[1] + 1;
              UNLOCK();
              piStack_34 = *(int **)(iVar2 + 0x30);
              piVar1 = *(int **)(iVar2 + 0x2c);
            }
            iVar2 = piVar1[1];
            iVar11 = *piVar1;
            uStack_8 = 0x12;
            piStack_2c = piStack_34;
            piStack_38 = piVar1;
            for (; iVar11 != iVar2; iVar11 = iVar11 + 8) {
              iVar7 = FUN_008e0fd0();
              uVar10 = uVar10 + iVar7;
            }
            uStack_8 = 0xffffffff;
            uStack_28 = uVar10;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar2 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_2c)();
                LOCK();
                piVar1 = piStack_2c + 2;
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                  (**(code **)(*piStack_2c + 4))();
                }
              }
            }
          }
          FUN_016774b0(DAT_01d65192,"Clearing LocalizationService-- %d Instances",uStack_28);
        }
        FUN_008a50b0();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15664 ; VA 0x008f0fa0 ; FUN_008f0fa0 */

uint __fastcall FUN_008f0fa0(int param_1)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01679ce0();
  uVar2 = uVar1 / 100;
  if (uVar1 % 100 < DAT_01ee04a8) {
    FUN_01530500(auStack_40);
    iStack_8 = 0;
    puVar3 = (uint *)FUN_00585d40(0,"GameClosedViaGameGUI_",0x15);
    uStack_28 = *puVar3;
    uStack_24 = puVar3[1];
    uStack_20 = puVar3[2];
    uStack_1c = puVar3[3];
    uStack_18 = *(undefined8 *)(puVar3 + 4);
    puVar3[4] = 0;
    puVar3[5] = 0xf;
    *(undefined *)puVar3 = 0;
    iStack_8._0_1_ = 1;
    uVar2 = FUN_008783f0(&uStack_28,1,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_18._4_4_) {
      uVar2 = uStack_18._4_4_ + 1;
      uVar1 = uStack_28;
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(uStack_28 - 4);
        uVar2 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uStack_28 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar2 = FUN_01674ea0(uVar1,uVar2);
    }
    uStack_18 = 0xf00000000;
    uStack_28 = uStack_28 & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar2 = uStack_2c + 1;
      uVar1 = auStack_40[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_40[0] - 4);
        uVar2 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar2 = FUN_01674ea0(uVar1,uVar2);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
  }
  if ((*(char *)(param_1 + 0x49c) == '\0') && (*(char *)(param_1 + 0x49d) == '\0')) {
    uVar2 = FUN_006eccd0();
    *(undefined *)(param_1 + 0x49d) = 1;
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 15665 ; VA 0x008f1110 ; FUN_008f1110 */

int FUN_008f1110(int param_1,int *param_2)

{
  int iVar1;
  undefined uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3ac7;
  pvStack_10 = ExceptionList;
  iVar3 = CONCAT31((int3)((uint)ExceptionList >> 8),DAT_01d65192);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d65192 != '\0') {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_016774b0(DAT_01d65192,"closeDataModel - %p",param_1);
  }
  iVar1 = DAT_01d63318;
  if (param_1 != 0) {
    piVar4 = (int *)FUN_005641e0();
    if (*piVar4 != 0) {
      FUN_0095c670((double)iVar1);
    }
    piVar4 = (int *)FUN_01674e20();
    uStack_8._0_1_ = 1;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4[1] = 1;
      piVar4[2] = 1;
      *piVar4 = (int)std::_Ref_count_obj<class_RBX::CEvent>::vftable;
      FUN_0151f360();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    FUN_009090c0(piVar4 + 3,piVar4);
    uVar2 = FUN_0151f440();
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Wait returned %u",uVar2);
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    FUN_008e9510(param_1,param_2,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Finished waiting on lock",0);
    }
    if (((-(uint)(param_1 != 0) & param_1 + 0xcU) != 0) &&
       (piVar5 = (int *)FUN_00636c60(), *piVar5 != 0)) {
      FUN_0090c170();
      FUN_00b82b00();
      FUN_00cbfb90();
    }
    if (((-(uint)(param_1 != 0) & param_1 + 0xcU) != 0) &&
       (piVar5 = (int *)FUN_005f5690(), *piVar5 != 0)) {
      FUN_00a4c000();
    }
    if (*(int *)(param_1 + 0x1b8) != 0) {
      piVar5 = *(int **)(param_1 + 0x43c);
      FUN_008b9750(*piVar5 - (int)piVar5,piVar5[1] - (int)piVar5);
    }
    FUN_008ef6b0();
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_008f34a0(param_1,param_2);
    if (iStack_18 != 0) {
      FUN_008eafb0();
      iVar3 = FUN_01674ea0(iStack_18,0x1c);
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar5 = piVar4 + 1;
      iVar1 = *piVar5;
      iVar3 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar5 = piVar4 + 2;
        iVar1 = *piVar5;
        iVar3 = *piVar5;
        *piVar5 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar4 = param_2 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar4 = param_2 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15666 ; VA 0x008f13d0 ; FUN_008f13d0 */

undefined4 * __thiscall
FUN_008f13d0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0089f8b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + -0xc + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15667 ; VA 0x008f1580 ; FUN_008f1580 */

undefined4 * __thiscall
FUN_008f1580(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3b11;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_008f44a0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + -0xc + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15668 ; VA 0x008f1730 ; FUN_008f1730 */

undefined4 * __thiscall
FUN_008f1730(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab301;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_007037b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + -0xc + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15669 ; VA 0x008f18e0 ; FUN_008f18e0 */

undefined4 * __thiscall
FUN_008f18e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3b51;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_008f4680;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + -0xc + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15670 ; VA 0x008f1a90 ; FUN_008f1a90 */

void __fastcall FUN_008f1a90(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x1c4);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    FUN_0170d1f0(puVar1 + 2,0,0x1bc);
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_008e38f0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 15671 ; VA 0x008f1af0 ; FUN_008f1af0 */

void FUN_008f1af0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_0090bc60();
    *param_2 = uVar3;
    iVar4 = FUN_0090c290();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15672 ; VA 0x008f1b50 ; FUN_008f1b50 */

void FUN_008f1b50(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_0090bd10();
    *param_2 = uVar3;
    iVar4 = FUN_0090c300();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15673 ; VA 0x008f1bb0 ; FUN_008f1bb0 */

void FUN_008f1bb0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_0090bdc0();
    *param_2 = uVar3;
    iVar4 = FUN_0090c370();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15674 ; VA 0x008f1c10 ; FUN_008f1c10 */

void FUN_008f1c10(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_0090bea0();
    *param_2 = uVar3;
    iVar4 = FUN_0090c3e0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15675 ; VA 0x008f1c70 ; FUN_008f1c70 */

void FUN_008f1c70(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_0090bf80();
    *param_2 = uVar3;
    iVar4 = FUN_0090c450();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15676 ; VA 0x008f1cd0 ; FUN_008f1cd0 */

void FUN_008f1cd0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_0090c030();
    *param_2 = uVar3;
    iVar4 = FUN_0090c4c0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15677 ; VA 0x008f1d30 ; FUN_008f1d30 */

void FUN_008f1d30(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_0090c0c0();
    *param_2 = uVar3;
    iVar4 = FUN_0090c530();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15678 ; VA 0x008f1d90 ; FUN_008f1d90 */

void FUN_008f1d90(undefined4 *param_1,undefined4 param_2)

{
  FUN_0063cc40();
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_009cb180(param_1,param_2);
  return;
}



/* FUNCTION 15679 ; VA 0x008f1db0 ; FUN_008f1db0 */

void FUN_008f1db0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bc60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15680 ; VA 0x008f1df0 ; FUN_008f1df0 */

void FUN_008f1df0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bd10();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15681 ; VA 0x008f1e30 ; FUN_008f1e30 */

void FUN_008f1e30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bdc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15682 ; VA 0x008f1e70 ; FUN_008f1e70 */

void FUN_008f1e70(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bea0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15683 ; VA 0x008f1eb0 ; FUN_008f1eb0 */

void FUN_008f1eb0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bf80();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15684 ; VA 0x008f1ef0 ; FUN_008f1ef0 */

void FUN_008f1ef0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0090c030();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15685 ; VA 0x008f1f30 ; FUN_008f1f30 */

void FUN_008f1f30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090c0c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15686 ; VA 0x008f1f70 ; FUN_008f1f70 */

undefined4 *
FUN_008f1f70(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3b79;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d65192 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01d65192,"Create DataModel - heartbeat(%d)",param_2 & 0xff);
  }
  FUN_008e1eb0(param_1,&param_3,&param_5);
  uStack_8 = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008f3c40(*param_1,param_1[1],param_2,param_4,param_6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15687 ; VA 0x008f2030 ; FUN_008f2030 */

bool __fastcall FUN_008f2030(int param_1)

{
  int iVar1;
  
  iVar1 = GetCurrentThreadId();
  return *(int *)(param_1 + 0x2a8) == iVar1;
}



/* FUNCTION 15688 ; VA 0x008f2050 ; FUN_008f2050 */

undefined4 FUN_008f2050(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    if (*(int *)(param_1 + 0x34) != 0) {
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar1 = FUN_008dcf60();
      if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
           (uint)*(ushort *)(iVar1 + 0x1da)) && (param_1 != 0xc)) {
        iVar2 = GetCurrentThreadId();
        if (*(int *)(param_1 + 0x29c) != iVar2) {
          return 0;
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 15689 ; VA 0x008f20b0 ; FUN_008f20b0 */

void FUN_008f20b0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x48;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 15690 ; VA 0x008f20f0 ; FUN_008f20f0 */

void __thiscall FUN_008f20f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar1);
    iStack_1b8 = FUN_005c9d30();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15691 ; VA 0x008f2320 ; FUN_008f2320 */

void __thiscall FUN_008f2320(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088c8c0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088c8c0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_005c9cc0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15692 ; VA 0x008f2540 ; FUN_008f2540 */

void __thiscall
FUN_008f2540(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_005c9cc0();
    puVar4 = &uStack_28c;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15693 ; VA 0x008f2950 ; FUN_008f2950 */

void __thiscall FUN_008f2950(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x44);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar2;
    iStack_1b8 = FUN_005c9ef0();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15694 ; VA 0x008f2b70 ; FUN_008f2b70 */

void __thiscall
FUN_008f2b70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_28c = thunk_FUN_0090c030();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_0090c4c0();
    puVar4 = &uStack_28c;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_0090c030();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15695 ; VA 0x008f2f80 ; FUN_008f2f80 */

void __thiscall FUN_008f2f80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = thunk_FUN_0090c030();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_0090c4c0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_0090c030();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15696 ; VA 0x008f31a0 ; FUN_008f31a0 */

undefined __thiscall FUN_008f31a0(int param_1,int param_2)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint in_stack_00000018;
  undefined3 uStack0000001c;
  undefined uStack0000001f;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar1 = FUN_008e5c30(&param_2,_uStack0000001c,1);
  uStack0000001f = uVar1;
  if (*(int *)(param_1 + 0x4ec) != 0) {
    iVar5 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
    uVar2 = FUN_005702d0(&param_2);
    FUN_00562fc0(&iStack_14,uVar2,&param_2,-(uint)(iVar5 != 0) & iVar5 + 1U);
    if ((iStack_14 != 0) &&
       (iVar5 = *(int *)(iStack_14 + 0x20), iVar3 = FUN_00888530(), iVar5 == iVar3)) {
      uStack0000001f = *(int *)(param_1 + 0x4ec) == 1;
      FUN_00602370((int)&stack0x0000001c + 3);
    }
  }
  uVar1 = uStack0000001f;
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(param_2 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15697 ; VA 0x008f32a0 ; FUN_008f32a0 */

undefined4 FUN_008f32a0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008e55e0(&param_1,in_stack_0000001c,1);
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15698 ; VA 0x008f3320 ; FUN_008f3320 */

undefined4 FUN_008f3320(undefined4 param_1,uint param_2)

{
  undefined8 uVar1;
  uint uVar2;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined4 extraout_var;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = in_stack_00000020;
  puStack_c = &LAB_017c3ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uVar1 = CONCAT44(in_stack_00000034,in_stack_00000030);
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_008e58c0(param_1,&param_2,uVar2,in_stack_00000024,in_stack_00000028,in_stack_0000002c,uVar1,1)
  ;
  uVar3 = extraout_var;
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3(extraout_var);
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    if (0xfff < in_stack_00000034 + 1) {
      if (0x1f < (in_stack_00000020 - *(int *)(in_stack_00000020 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3(uVar3);
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15699 ; VA 0x008f3420 ; FUN_008f3420 */

undefined * FUN_008f3420(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  return param_1;
}



/* FUNCTION 15700 ; VA 0x008f3450 ; FUN_008f3450 */

void FUN_008f3450(void)

{
  FUN_008f4960();
  return;
}



/* FUNCTION 15701 ; VA 0x008f3460 ; FUN_008f3460 */

void __thiscall FUN_008f3460(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = param_2 + -0xc + *(int *)(param_1 + 0x34);
  if (param_2 == 0) {
    iVar1 = *(int *)(param_1 + 0x34);
  }
  if (iVar1 != 0) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 15702 ; VA 0x008f3480 ; FUN_008f3480 */

void __fastcall FUN_008f3480(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 0xc);
  (**(code **)*puVar1)(0);
  uVar2 = GetProcessHeap(0,puVar1);
  HeapFree(uVar2);
  return;
}



/* FUNCTION 15703 ; VA 0x008f34a0 ; FUN_008f34a0 */

int FUN_008f34a0(int param_1,int *param_2)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uStack_7c;
  int iStack_74;
  int *piStack_70;
  int *piStack_6c;
  int *piStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3bdb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d65192 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01d65192,"doCloseDataModel - %p",param_1);
  }
  FUN_01255470(1,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (DAT_01d63514 != '\0') {
    do {
      lVar7 = FUN_016de945();
      uVar8 = FUN_016f39b0(lVar7 + 10000000,100,0);
      uVar9 = FUN_016f3900(uVar8,1000000000,0);
      iStack_74 = (int)uVar8 + (int)uVar9 * -1000000000;
      piStack_70 = piStack_1c;
      iStack_20 = iStack_74;
      uStack_7c = uVar9;
      uStack_28 = uVar9;
      FUN_016de839(&uStack_7c);
    } while( true );
  }
  if (DAT_01d6351c == '\0') {
    if (((-(uint)(param_1 != 0) & param_1 + 0xcU) != 0) &&
       (piVar4 = (int *)FUN_005f5690(), *piVar4 != 0)) {
      FUN_00a49940();
    }
    iVar5 = FUN_008e4410(-(uint)(param_1 != 0) & param_1 + 0xcU);
    if (iVar5 != 0) {
      FUN_00a653e0(0);
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Raising close..",0);
    }
    FUN_006eccd0();
    FUN_006eccd0();
    *(undefined *)(param_1 + 0x1dd) = 0;
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Removing all players",0);
    }
    if (((-(uint)(param_1 != 0) & param_1 + 0xcU) != 0) &&
       (piVar4 = (int *)FUN_00564080(), *piVar4 != 0)) {
      FUN_008a50b0();
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Clearing contents...",0);
    }
    FUN_008ef830();
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Visiting children with unlockParent...",0);
    }
    piVar4 = *(int **)(param_1 + 0x38);
    if (piVar4 != (int *)0x0) {
      piStack_68 = *(int **)(param_1 + 0x3c);
      if (piStack_68 != (int *)0x0) {
        LOCK();
        piStack_68[1] = piStack_68[1] + 1;
        UNLOCK();
        piStack_68 = *(int **)(param_1 + 0x3c);
        piVar4 = *(int **)(param_1 + 0x38);
      }
      iVar5 = piVar4[1];
      iVar6 = *piVar4;
      uStack_8._0_1_ = 2;
      piStack_6c = piVar4;
      piStack_14 = piStack_68;
      for (; iVar6 != iVar5; iVar6 = iVar6 + 8) {
        FUN_00631dd0();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_14[1] + -1;
        piStack_14[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          iVar5 = piStack_14[2] + -1;
          piStack_14[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Removing all Children...",0);
    }
    FUN_008a50b0();
    if (*(int *)(param_1 + 0x1b8) != 0) {
      if (DAT_01d65192 != '\0') {
        FUN_016774b0(DAT_01d65192,"Stopping model meshing job...",0);
      }
      FUN_008bc360();
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Resetting workspace...",0);
    }
    uStack_2c = 0;
    uStack_30 = 0;
    *(undefined4 *)(param_1 + 0x1b8) = 0;
    piVar4 = *(int **)(param_1 + 0x1bc);
    *(undefined4 *)(param_1 + 0x1bc) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Resetting runService...",0);
    }
    uStack_34 = 0;
    uStack_38 = 0;
    *(undefined4 *)(param_1 + 0x1a8) = 0;
    piVar4 = *(int **)(param_1 + 0x1ac);
    *(undefined4 *)(param_1 + 0x1ac) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Resetting starterPackService...",0);
    }
    uStack_3c = 0;
    uStack_40 = 0;
    *(undefined4 *)(param_1 + 400) = 0;
    piVar4 = *(int **)(param_1 + 0x194);
    *(undefined4 *)(param_1 + 0x194) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Resetting starterGuiService...",0);
    }
    uStack_44 = 0;
    uStack_48 = 0;
    *(undefined4 *)(param_1 + 0x198) = 0;
    piVar4 = *(int **)(param_1 + 0x19c);
    *(undefined4 *)(param_1 + 0x19c) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Resetting starterPlayerService...",0);
    }
    uStack_4c = 0;
    uStack_50 = 0;
    *(undefined4 *)(param_1 + 0x1a0) = 0;
    piVar4 = *(int **)(param_1 + 0x1a4);
    *(undefined4 *)(param_1 + 0x1a4) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Resetting guiRoot...",0);
    }
    uStack_54 = 0;
    uStack_58 = 0;
    *(undefined4 *)(param_1 + 0x1c0) = 0;
    piVar4 = *(int **)(param_1 + 0x1c4);
    *(undefined4 *)(param_1 + 0x1c4) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Clearing services...",0);
    }
    FUN_008a96a0();
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Removing GenericJobs...",0);
    }
    iVar5 = param_1 + 0x360;
    iStack_5c = iVar5;
    iStack_18 = iVar5;
    iVar6 = FUN_016dee6d(iVar5);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    piStack_14 = (int *)(param_1 + 0x390);
    if (piStack_14 != (int *)(param_1 + 1000)) {
      do {
        iVar5 = *piStack_14;
        if (iVar5 != 0) {
          FUN_009073c0();
          puVar1 = (uint *)(iVar5 + 0x144);
          do {
            LOCK();
            uVar2 = *puVar1;
            *puVar1 = *puVar1 | 1;
            UNLOCK();
          } while ((uVar2 & 1) != 0);
          *(undefined8 *)(iVar5 + 0x148) = 0;
          iVar6 = *(int *)(iVar5 + 0x140);
          while (iVar6 != 0) {
            FUN_008c3510();
            piVar4 = (int *)(iVar5 + 0x140);
            *piVar4 = *piVar4 + -1;
            if (*piVar4 == 0) {
              *(undefined4 *)(iVar5 + 0x13c) = 0;
            }
            else {
              *(int *)(iVar5 + 0x13c) = *(int *)(iVar5 + 0x13c) + 1;
            }
            iVar6 = *(int *)(iVar5 + 0x140);
          }
          *puVar1 = 0;
        }
        piVar3 = piStack_14;
        piVar4 = (int *)piStack_14[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
          piVar4 = (int *)piStack_14[1];
        }
        iStack_20 = *piStack_14;
        uStack_8._0_1_ = 4;
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
        }
        piStack_1c = piVar4;
        FUN_0151dac0(iStack_20,piVar4,0,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar5 = piVar4[1] + -1;
          piVar4[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar5 = piVar4[2] + -1;
            piVar4[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        *piVar3 = 0;
        piVar4 = (int *)piVar3[1];
        uStack_60 = 0;
        uStack_64 = 0;
        piVar3[1] = 0;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar5 = piVar4[1] + -1;
          piVar4[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar5 = piVar4[2] + -1;
            piVar4[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        piStack_14 = piVar3 + 2;
        iVar5 = iStack_18;
      } while (piStack_14 != (int *)(param_1 + 1000));
    }
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Close DataModel Done!",0);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar5 = FUN_016deec8(iVar5);
    if (iVar5 != 0) {
      FUN_016df3c9(iVar5);
    }
    iVar5 = FUN_01255500();
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar4 = param_2 + 1;
      iVar6 = *piVar4;
      iVar5 = *piVar4;
      *piVar4 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar5 = (**(code **)*param_2)();
        LOCK();
        piVar4 = param_2 + 2;
        iVar6 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          iVar5 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar5;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Simulated exception");
}



/* FUNCTION 15704 ; VA 0x008f3c40 ; FUN_008f3c40 */

int FUN_008f3c40(uint param_1,int *param_2,undefined4 param_3,char param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined auStack_90 [24];
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  int iStack_58;
  int *piStack_54;
  undefined8 uStack_50;
  int iStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  int iStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c28;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff64;
  uStack_28 = 0;
  uStack_40 = 0;
  piStack_3c = (int *)0x0;
  uStack_8 = 1;
  piStack_20 = (int *)0x1;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_008e5010(auStack_30,&param_1,"Write Marshalled",&piStack_20);
  uStack_40 = *puVar3;
  piVar1 = (int *)puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  piStack_20 = piStack_2c;
  piStack_3c = piVar1;
  uStack_1c = uStack_40;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x398) = uStack_1c;
  piStack_20 = *(int **)(param_1 + 0x39c);
  *(int **)(param_1 + 0x39c) = piVar1;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  FUN_0151d950(uStack_1c,piVar1);
  piStack_20 = (int *)0x0;
  puVar3 = (undefined4 *)FUN_008e4f00(auStack_30,&param_1,"Read Marshalled",&piStack_20);
  uStack_40 = *puVar3;
  piStack_3c = (int *)puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  piStack_20 = piStack_3c;
  uStack_1c = uStack_40;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar4 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  piVar1 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x390) = uStack_1c;
  piStack_24 = *(int **)(param_1 + 0x394);
  *(int **)(param_1 + 0x394) = piStack_20;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = piStack_24[2] + -1;
      piStack_24[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  FUN_0151d950(uStack_1c,piVar1);
  piStack_24 = (int *)0xa;
  puVar3 = (undefined4 *)FUN_008e4f00(&iStack_48,&param_1,"None Marshalled",&piStack_24);
  uStack_40 = *puVar3;
  piVar1 = (int *)puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  piStack_3c = piVar1;
  piStack_2c = piVar1;
  uStack_1c = uStack_40;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piStack_24 = piStack_44;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_44[1] + -1;
    piStack_44[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      iVar4 = piStack_24[2] + -1;
      piStack_24[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x3e0) = uStack_1c;
  piStack_24 = *(int **)(param_1 + 0x3e4);
  *(int **)(param_1 + 0x3e4) = piVar1;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = piStack_24[2] + -1;
      piStack_24[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  FUN_0151d950(uStack_1c,piVar1);
  if ((DAT_01d62fe8 != '\0') && (*(int *)(param_5 + 0x88) == 6)) {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    FUN_008e9510(param_1,param_2,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar4 = FUN_005c2760();
    if (iVar4 != 0) {
      FUN_008ca760(&DAT_01d62ff0,DAT_01d62ea8);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_20 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      FUN_008eafb0();
      FUN_01674ea0(piStack_20,0x1c);
    }
  }
  cVar2 = FUN_00585a40();
  if (cVar2 != '\0') {
    FUN_00ba04b0(0);
  }
  cVar2 = FUN_00585a40();
  if (cVar2 != '\0') {
    if (DAT_01d6f7e4 != '\0') {
      FUN_00ba0500((int)*(float *)(param_5 + 0x7c));
    }
    FUN_00b9fe60(&iStack_48);
    piStack_24 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_44[1] + -1;
      piStack_44[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  FUN_008e9510(param_1,param_2,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  DAT_01d633dc = GetCurrentThreadId();
  if (DAT_01d63524 != '\0') {
    do {
      lVar7 = FUN_016de945();
      uVar8 = FUN_016f39b0(lVar7 + 10000000,100,0);
      uVar9 = FUN_016f3900(uVar8,1000000000,0);
      iStack_58 = (int)uVar8 + (int)uVar9 * -1000000000;
      piStack_44 = piStack_54;
      iStack_48 = iStack_58;
      uStack_60 = uVar9;
      uStack_50 = uVar9;
      FUN_016de839(&uStack_50);
    } while( true );
  }
  if (DAT_01d6352c != '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Simulated exception");
  }
  *(undefined4 *)(param_1 + 0x158) = *(undefined4 *)(param_5 + 0x88);
  FUN_008fc870(param_3,param_5);
  *(undefined *)(param_1 + 0x1dd) = 1;
  *(undefined *)(param_1 + 0x344) = 0;
  if (DAT_01d6354c != '\0') {
    if (((-(uint)(param_1 != 0) & param_1 + 0xc) != 0) &&
       (piVar5 = (int *)FUN_00636b00(), *piVar5 != 0)) {
      FUN_00b9cea0((int)*(float *)(param_5 + 0x7c));
    }
    if (((-(uint)(param_1 != 0) & param_1 + 0xc) != 0) &&
       (piVar5 = (int *)FUN_00787b20(), *piVar5 != 0)) {
      FUN_00d2d3e0(*(undefined4 *)(param_5 + 0x7c));
    }
  }
  if (param_4 == '\0') goto LAB_008f43b9;
  if (DAT_01d6353c != '\0') {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    FUN_008ffaa0(param_1,param_2);
  }
  if (((-(uint)(param_1 != 0) & param_1 + 0xc) != 0) &&
     (piVar5 = (int *)FUN_00636b00(), *piVar5 != 0)) {
    FUN_00b9cb60(0,DAT_01d63300,0,0);
  }
  uVar6 = uStack_28;
  if (DAT_01eeb4f1 == '\0') {
LAB_008f422e:
    cStack_15 = '\0';
  }
  else {
    piVar5 = (int *)FUN_008f7c60(&iStack_48);
    uVar6 = 1;
    if (*piVar5 == 0) goto LAB_008f422e;
    cStack_15 = '\x01';
  }
  if ((uVar6 & 1) != 0) {
    FUN_00550b30();
  }
  if (cStack_15 == '\0') {
    uStack_8._0_1_ = 4;
    uStack_28 = param_1;
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = 0;
    FUN_005542c0("LoadingScript",0xd);
    uStack_8._0_1_ = 5;
    FUN_00a34a10((int)&uStack_50 + 4,auStack_78,uStack_28,0);
    uStack_8._0_1_ = 7;
    FUN_005507b0();
    if (uStack_50._4_1_ != '\0') {
      piStack_20 = (int *)FUN_008e2f30(-(uint)(param_1 != 0) & param_1 + 0xc);
      if (piStack_20 != (int *)0x0) {
        if (DAT_01d64500 == '\0') {
          FUN_01255470(3,0,0,0);
          FUN_0094ee10(auStack_90,&iStack_48,"LoadingScript");
        }
        else {
          uStack_60._4_4_ = 0;
          iStack_58 = 0;
          piStack_54 = (int *)0x0;
          uStack_8._0_1_ = 8;
          FUN_01255470(3,0,0,0);
          FUN_00951870(auStack_90,&iStack_48,"LoadingScript",(int)&uStack_60 + 4);
          uStack_8._0_1_ = 9;
          FUN_00577b20();
        }
      }
      if (uStack_50._4_1_ != '\0') {
        FUN_0056cd30();
        FUN_0056cd30();
        iVar4 = FUN_008f43b2();
        return iVar4;
      }
    }
    uStack_8 = 3;
  }
  else if (((-(uint)(param_1 != 0) & param_1 + 0xc) != 0) &&
          (piVar5 = (int *)FUN_00677290(), *piVar5 != 0)) {
    FUN_00be8470();
  }
LAB_008f43b9:
  if (DAT_01d65192 != '\0') {
    FUN_016774b0(DAT_01d65192,"DataModel created: %p",param_1);
  }
  piStack_2c = (int *)iStack_34;
  if (iStack_34 != 0) {
    FUN_008eafb0();
    iStack_34 = FUN_01674ea0(piStack_2c,0x1c);
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar5 = piVar1 + 1;
    iVar4 = *piVar5;
    iStack_34 = *piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      iStack_34 = *piVar5;
      *piVar5 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iStack_34 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar5 = param_2 + 1;
    iVar4 = *piVar5;
    iStack_34 = *piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iStack_34 = (**(code **)*param_2)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iStack_34 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_34;
}



/* FUNCTION 15705 ; VA 0x008f438c ; Catch@008f438c */

undefined * Catch_008f438c(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x34) + 4))();
  FUN_0086f2f0(3,"LoadingScript Error: %s",uVar1);
  return &DAT_008f43ac;
}



/* FUNCTION 15706 ; VA 0x008f43b2 ; FUN_008f43b2 */

int FUN_008f43b2(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  int unaff_ESI;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 3;
  if (DAT_01d65192 != '\0') {
    FUN_016774b0(DAT_01d65192,"DataModel created: %p",*(undefined4 *)(unaff_EBP + 8));
  }
  iVar4 = *(int *)(unaff_EBP + -0x30);
  *(int *)(unaff_EBP + -0x28) = iVar4;
  if (iVar4 != 0) {
    FUN_008eafb0();
    iVar4 = FUN_01674ea0(*(undefined4 *)(unaff_EBP + -0x28),0x1c);
  }
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    piVar3 = unaff_EDI + 1;
    iVar2 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar2 + unaff_ESI;
    UNLOCK();
    if (iVar2 + unaff_ESI == 0) {
      (**(code **)*unaff_EDI)();
      LOCK();
      piVar3 = unaff_EDI + 2;
      iVar2 = *piVar3;
      iVar4 = *piVar3;
      *piVar3 = iVar2 + unaff_ESI;
      UNLOCK();
      if (iVar2 + unaff_ESI == 0) {
        iVar4 = (**(code **)(*unaff_EDI + 4))();
      }
    }
  }
  piVar3 = *(int **)(unaff_EBP + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + unaff_ESI;
    UNLOCK();
    if (iVar2 + unaff_ESI == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + unaff_ESI;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return iVar4;
}



/* FUNCTION 15707 ; VA 0x008f4460 ; FUN_008f4460 */

void __thiscall FUN_008f4460(undefined4 param_1,int *param_2,undefined4 param_3)

{
  if ('\0' < *(char *)(param_2 + 3)) {
    DAT_01f02658 = DAT_01f02658 | 0x4000000;
    return;
  }
  (**(code **)(*param_2 + 0x14))(param_3,param_1);
  return;
}



/* FUNCTION 15708 ; VA 0x008f44a0 ; FUN_008f44a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_008f44a0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_f0 = FUN_009ca3d0();
  uStack_e8 = param_4;
  puStack_ec = (undefined *)0x0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf8dc) {
    FUN_016f3809(&DAT_01edf8dc);
    if (DAT_01edf8dc == -1) {
      _DAT_01edf8d0 = FUN_005c65e0;
      _DAT_01edf8d4 = FUN_005c65e0;
      _DAT_01edf8d8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf8dc);
    }
  }
  puStack_ec = &DAT_01edf8d0;
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15709 ; VA 0x008f4680 ; FUN_008f4680 */

void FUN_008f4680(int param_1,undefined param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15710 ; VA 0x008f4780 ; FUN_008f4780 */

undefined __fastcall FUN_008f4780(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  puVar5 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar2 = puVar5 + 4;
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  uVar3 = FUN_0055c360(puVar5,*puVar2,puVar4,*puVar1);
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    iVar6 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_40[0] + -4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15711 ; VA 0x008f4890 ; FUN_008f4890 */

bool __fastcall FUN_008f4890(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(param_1 + 8))();
  iVar2 = (**(code **)(param_1 + 8))();
  return iVar2 == iVar1;
}



/* FUNCTION 15712 ; VA 0x008f48d0 ; FUN_008f48d0 */

undefined4 __fastcall FUN_008f48d0(int param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = (**(code **)(param_1 + 8))();
  lVar2 = (**(code **)(param_1 + 8))();
  if (lVar1 != lVar2) {
    return 0;
  }
  return 1;
}



/* FUNCTION 15713 ; VA 0x008f4920 ; FUN_008f4920 */

bool __fastcall FUN_008f4920(int param_1)

{
  char cVar1;
  char cVar2;
  
  cVar1 = (**(code **)(param_1 + 8))();
  cVar2 = (**(code **)(param_1 + 8))();
  return cVar2 == cVar1;
}



/* FUNCTION 15714 ; VA 0x008f4960 ; FUN_008f4960 */

int __thiscall FUN_008f4960(int *param_1,int *param_2)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piStack_10;
  
  param_1 = (int *)*param_1;
  piVar8 = param_1 + 1;
  piStack_10 = (int *)*piVar8;
  cVar1 = *(char *)((int)piStack_10 + 0xd);
  piVar3 = param_1;
  puVar7 = param_2;
  while (puVar9 = param_2, param_2 = puVar9, cVar1 == '\0') {
    piVar5 = piStack_10 + 4;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    uVar2 = piStack_10[9];
    iVar6 = piStack_10[8];
    piVar10 = piVar5;
    if (0xf < uVar2) {
      piVar10 = (int *)*piVar5;
    }
    iVar4 = FUN_0055c2d0(piVar10,iVar6,puVar7,puVar9[4]);
    if (iVar4 < 0) {
      piVar5 = (int *)piStack_10[2];
      piStack_10 = piVar3;
    }
    else {
      if (*(char *)((int)param_1 + 0xd) != '\0') {
        if (0xf < uVar2) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = puVar9;
        if (0xf < (uint)puVar9[5]) {
          puVar7 = (undefined4 *)*puVar9;
        }
        iVar6 = FUN_0055c2d0(puVar7,puVar9[4],piVar5,iVar6);
        if (iVar6 < 0) {
          param_1 = piStack_10;
        }
      }
      piVar5 = (int *)*piStack_10;
    }
    piVar3 = piStack_10;
    piStack_10 = piVar5;
    puVar7 = puVar9;
    cVar1 = *(char *)((int)piVar5 + 0xd);
  }
  if (*(char *)((int)param_1 + 0xd) == '\0') {
    piVar8 = param_1;
  }
  cVar1 = *(char *)(*piVar8 + 0xd);
  piVar8 = (int *)*piVar8;
  while (cVar1 == '\0') {
    piVar5 = piVar8 + 4;
    if (0xf < (uint)piVar8[9]) {
      piVar5 = (int *)*piVar5;
    }
    puVar9 = puVar7;
    if (0xf < (uint)puVar7[5]) {
      puVar9 = (undefined4 *)*puVar7;
    }
    iVar6 = FUN_0055c2d0(puVar9,puVar7[4],piVar5,piVar8[8]);
    if (iVar6 < 0) {
      piVar5 = (int *)*piVar8;
      param_1 = piVar8;
    }
    else {
      piVar5 = (int *)piVar8[2];
    }
    piVar8 = piVar5;
    cVar1 = *(char *)((int)piVar5 + 0xd);
  }
  iVar6 = 0;
  param_2 = piVar3;
  while (param_2 != param_1) {
    iVar6 = iVar6 + 1;
    FUN_00551320();
  }
  FUN_005f6cc0(&param_2,piVar3,param_1);
  return iVar6;
}



/* FUNCTION 15715 ; VA 0x008f4a90 ; FUN_008f4a90 */

void FUN_008f4a90(void)

{
  FUN_005789c0(&DAT_01ee05e0,&LAB_0090a090);
  FUN_00909f90();
  return;
}



/* FUNCTION 15716 ; VA 0x008f4ab0 ; FUN_008f4ab0 */

void FUN_008f4ab0(int param_1,int *param_2,uint param_3)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined uVar4;
  char cVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  uint in_stack_0000002c;
  undefined4 uStack_214;
  int iStack_210;
  undefined auStack_20c [200];
  undefined4 uStack_144;
  int iStack_140;
  undefined auStack_13c [200];
  int aiStack_74 [5];
  uint uStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  int aiStack_44 [3];
  undefined auStack_38 [8];
  uint uStack_30;
  undefined uStack_2c;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  puStack_c = &LAB_017c3ce9;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar6 = (**(code **)*param_2)();
  if (uVar6 < 4) {
LAB_008f4b8f:
    if (*(undefined4 **)(iStack_14 + 0x4c) == (undefined4 *)0x0) {
      uVar7 = 4;
      goto LAB_008f4ede;
    }
    param_2 = (int *)**(undefined4 **)(iStack_14 + 0x4c);
  }
  else {
    pcVar1 = *(code **)(*piVar3 + 0x38);
    uVar7 = FUN_0090c030();
    cVar5 = (*pcVar1)(4,uVar7,&param_2);
    if (cVar5 == '\0') {
      uStack_144 = FUN_00888530();
      iStack_140 = 0;
      uStack_8._0_1_ = 2;
      cVar5 = (**(code **)(*piVar3 + 4))(4,&uStack_144);
      if (cVar5 == '\0') {
        uStack_8._0_1_ = 4;
        if (iStack_140 != 0) {
          (**(code **)(iStack_140 + 8))(auStack_13c);
        }
        uStack_8._0_1_ = 1;
        goto LAB_008f4b8f;
      }
      puVar8 = (undefined4 *)FUN_00bc51f0();
      piVar2 = (int *)*puVar8;
      uStack_8._0_1_ = 3;
      if (iStack_140 != 0) {
        (**(code **)(iStack_140 + 8))(auStack_13c);
      }
      uStack_8._0_1_ = 1;
      param_2 = piVar2;
    }
  }
  uVar6 = (**(code **)*piVar3)();
  if (uVar6 < 3) {
LAB_008f4c5f:
    if (*(int *)(iStack_14 + 0x48) == 0) {
      uVar7 = 3;
LAB_008f4ede:
      FUN_016756b0(auStack_20,"Argument %d missing or nil",uVar7);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    FUN_0054ef60(*(int *)(iStack_14 + 0x48));
    iVar9 = iStack_14;
  }
  else {
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = 0;
    uStack_8._0_1_ = 5;
    uStack_144 = FUN_00888530();
    iStack_140 = 0;
    uStack_8._0_1_ = 6;
    cVar5 = (**(code **)(*piVar3 + 4))(3,&uStack_144);
    if (cVar5 == '\0') {
      uStack_8._0_1_ = 8;
      if (iStack_140 != 0) {
        (**(code **)(iStack_140 + 8))(auStack_13c);
      }
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      goto LAB_008f4c5f;
    }
    uVar7 = FUN_008898b0();
    FUN_0054ef60(uVar7);
    uStack_8._0_1_ = 7;
    if (iStack_140 != 0) {
      (**(code **)(iStack_140 + 8))(auStack_13c);
    }
    FUN_005507b0();
    iVar9 = iStack_14;
  }
  uStack_8._0_1_ = 9;
  uVar6 = (**(code **)*piVar3)();
  if (1 < uVar6) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = 0;
    uStack_8._0_1_ = 10;
    uStack_214 = FUN_00888530();
    iStack_210 = 0;
    uStack_8._0_1_ = 0xb;
    cVar5 = (**(code **)(*piVar3 + 4))(2,&uStack_214);
    if (cVar5 != '\0') {
      uVar7 = FUN_008898b0();
      FUN_0054ef60(uVar7);
      uStack_8._0_1_ = 0xc;
      if (iStack_210 != 0) {
        (**(code **)(iStack_210 + 8))(auStack_20c);
      }
      FUN_005507b0();
      goto LAB_008f4d48;
    }
    uStack_8._0_1_ = 0xd;
    if (iStack_210 != 0) {
      (**(code **)(iStack_210 + 8))(auStack_20c);
    }
    uStack_8._0_1_ = 9;
    FUN_005507b0();
  }
  if (*(int *)(iVar9 + 0x44) == 0) {
    FUN_016756b0(auStack_38,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_38,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(iVar9 + 0x44));
LAB_008f4d48:
  uStack_8._0_1_ = 0xe;
  uVar7 = FUN_008cca80(auStack_5c,piVar3,iVar9 + 0x40);
  uStack_8._0_1_ = 0xf;
  FUN_008eef70(-(uint)(param_1 != 0) & param_1 - 0xcU,*(undefined4 *)(iVar9 + 0x38),
               *(undefined4 *)(iVar9 + 0x3c),uVar7,aiStack_44,aiStack_74,&param_2,&param_3,
               &stack0x0000002c);
  uStack_8._0_1_ = 0xe;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if (0xf < uStack_48) {
    uVar10 = uStack_48 + 1;
    uVar6 = auStack_5c[0];
    if (0xfff < uVar10) {
      uVar6 = *(uint *)(auStack_5c[0] - 4);
      uVar10 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar10);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  uStack_8._0_1_ = 9;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_30) {
    uVar6 = uStack_30 + 1;
    iVar9 = aiStack_44[0];
    if (0xfff < uVar6) {
      iVar9 = *(int *)(aiStack_44[0] + -4);
      uVar6 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar9) - 4U) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar6);
  }
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_60) {
    uVar6 = uStack_60 + 1;
    iVar9 = aiStack_74[0];
    if (0xfff < uVar6) {
      iVar9 = *(int *)(aiStack_74[0] + -4);
      uVar6 = uStack_60 + 0x24;
      if (0x1f < (aiStack_74[0] - iVar9) - 4U) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar6);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 0x11;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15717 ; VA 0x008f4f00 ; FUN_008f4f00 */

void FUN_008f4f00(int param_1,int *param_2,uint param_3)

{
  code *pcVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint in_stack_0000002c;
  undefined4 uStack_10c;
  int iStack_108;
  undefined auStack_104 [200];
  undefined auStack_3c [12];
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  puStack_c = &LAB_017c3d23;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar5 = (**(code **)*param_2)();
  if (1 < uVar5) {
    pcVar1 = *(code **)(*piVar2 + 0x38);
    uVar6 = FUN_0090c030();
    cVar4 = (*pcVar1)(2,uVar6,&param_2);
    piStack_18 = param_2;
    if (cVar4 != '\0') goto LAB_008f4fef;
    uStack_10c = FUN_00888530();
    iStack_108 = 0;
    uStack_8._0_1_ = 2;
    cVar4 = (**(code **)(*piVar2 + 4))(2,&uStack_10c);
    if (cVar4 != '\0') {
      puVar7 = (undefined4 *)FUN_00bc51f0();
      piStack_18 = (int *)*puVar7;
      uStack_8._0_1_ = 3;
      if (iStack_108 != 0) {
        (**(code **)(iStack_108 + 8))(auStack_104);
      }
      uStack_8._0_1_ = 1;
      goto LAB_008f4fef;
    }
    uStack_8._0_1_ = 4;
    if (iStack_108 != 0) {
      (**(code **)(iStack_108 + 8))(auStack_104);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(iStack_14 + 0x44) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_3c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_3c,&DAT_01c17198);
  }
  piStack_18 = (int *)**(undefined4 **)(iStack_14 + 0x44);
LAB_008f4fef:
  uVar6 = FUN_008cca80(auStack_30,piVar2,iStack_14 + 0x40);
  uStack_8._0_1_ = 5;
  FUN_008eee40(-(uint)(param_1 != 0) & param_1 - 0xcU,*(undefined4 *)(iStack_14 + 0x38),
               *(undefined4 *)(iStack_14 + 0x3c),uVar6,&piStack_18,&param_3,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar8);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15718 ; VA 0x008f5110 ; FUN_008f5110 */

void __thiscall FUN_008f5110(int param_1,int param_2,int *param_3,uint param_4)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint in_stack_0000002c;
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [200];
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d5b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    uStack_28 = 0;
    uStack_8._0_1_ = 2;
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_110);
    if (cVar2 != '\0') {
      uVar4 = FUN_0088a920();
      FUN_0054ef60(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      FUN_005507b0();
      goto LAB_008f520a;
    }
    uStack_8._0_1_ = 5;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x40) == 0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(param_1 + 0x40));
LAB_008f520a:
  uStack_8._0_1_ = 6;
  FUN_008eeb10(-(uint)(param_2 != 0) & param_2 - 0xcU,*(undefined4 *)(param_1 + 0x38),
               *(undefined4 *)(param_1 + 0x3c),aiStack_40,&param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15719 ; VA 0x008f5300 ; FUN_008f5300 */

void __thiscall FUN_008f5300(int param_1,int param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  param_3 = FUN_008f7920(param_3,param_1 + 0x40);
  FUN_008eecb0(-(uint)(param_2 != 0) & param_2 - 0xcU,*(undefined4 *)(param_1 + 0x38),
               *(undefined4 *)(param_1 + 0x3c),&param_3,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15720 ; VA 0x008f53c0 ; FUN_008f53c0 */

undefined4 FUN_008f53c0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uStack_98;
  int iStack_94;
  undefined4 uStack_90;
  int iStack_8c;
  int iStack_88;
  undefined4 uStack_84;
  int aiStack_78 [5];
  uint uStack_64;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c3db0;
  pvStack_1c = ExceptionList;
  uStack_84 = param_2;
  iStack_88 = 0x8f53fc;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  iStack_88 = (int)pcStack_28 + 0x44;
  uStack_90 = 2;
  iStack_94 = param_3;
  uStack_98 = param_2;
  iStack_8c = iVar1 - param_3;
  uStack_2c = FUN_009d09d0(aiStack_78);
  uStack_14 = 0;
  uVar2 = FUN_009d09d0(auStack_48,param_2,param_3,1,iVar1 - param_3,(int)pcStack_28 + 0x40);
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  puStack_30 = (undefined *)&uStack_98;
  FUN_0054ef60(uStack_2c);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14._0_1_ = 1;
  uVar2 = (*pcStack_28)(aiStack_60);
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  uVar2 = FUN_009d5710(param_2,uVar2);
  if (0xf < uStack_4c) {
    uVar3 = uStack_4c + 1;
    iVar1 = aiStack_60[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_60[0] + -4);
      uVar3 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  if (0xf < uStack_34) {
    uVar4 = uStack_34 + 1;
    uVar3 = auStack_48[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_48[0] - 4);
      uVar4 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (0xf < uStack_64) {
    uVar3 = uStack_64 + 1;
    iVar1 = aiStack_78[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_78[0] + -4);
      uVar3 = uStack_64 + 0x24;
      if (0x1f < (aiStack_78[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_1c;
  return uVar2;
}



/* FUNCTION 15721 ; VA 0x008f5570 ; FUN_008f5570 */

undefined4 __thiscall FUN_008f5570(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3dd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_44,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)(aiStack_2c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5710(param_3,uVar3);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  if (0xf < uStack_30) {
    uVar4 = uStack_30 + 1;
    iVar2 = aiStack_44[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      uVar4 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15722 ; VA 0x008f5680 ; FUN_008f5680 */

undefined4 __thiscall FUN_008f5680(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 0x38))(aiStack_28);
  uStack_8 = 0;
  uVar1 = FUN_009d5710(param_3,uVar1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15723 ; VA 0x008f5720 ; FUN_008f5720 */

undefined4 __thiscall FUN_008f5720(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3df0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_01256300();
  uVar3 = FUN_008cc740(aiStack_34);
  pcVar2 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar2)(auStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5920(param_3,uVar3);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_18[1] + -1;
    piStack_18[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    iVar4 = aiStack_34[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_34[0] + -4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15724 ; VA 0x008f5830 ; FUN_008f5830 */

code * __thiscall FUN_008f5830(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c3e10;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d11e0(auStack_38,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = (*pcStack_28)(auStack_30,*puVar3,puVar3[1]);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  pcStack_28 = (code *)FUN_009d5950(param_3,uVar4);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcStack_28;
}



/* FUNCTION 15725 ; VA 0x008f5960 ; FUN_008f5960 */

undefined4 __thiscall FUN_008f5960(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18);
  uStack_8 = 0;
  uVar3 = FUN_009d5950(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15726 ; VA 0x008f59f0 ; FUN_008f59f0 */

undefined4 __thiscall FUN_008f59f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_2c,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)();
  uVar3 = FUN_009d5650(param_3,uVar3);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15727 ; VA 0x008f5ac0 ; FUN_008f5ac0 */

undefined4 FUN_008f5ac0(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  FUN_009d05b0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uVar3 = FUN_009d09d0(aiStack_2c,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)();
  uVar3 = FUN_009d5650(param_2,uVar3);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15728 ; VA 0x008f5bb0 ; FUN_008f5bb0 */

undefined4 FUN_008f5bb0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iStack_bc;
  int *piStack_b8;
  undefined4 uStack_b4;
  int iStack_b0;
  undefined4 uStack_ac;
  int iStack_a8;
  int iStack_a4;
  uint *puStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int aiStack_7c [5];
  uint uStack_68;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c3e48;
  pvStack_1c = ExceptionList;
  iStack_8c = param_2;
  iStack_90 = 0x8f5bec;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  iStack_90 = (int)pcStack_28 + 0x4c;
  iVar1 = iVar1 - param_3;
  iStack_98 = 4;
  iStack_9c = param_3;
  puStack_a0 = (uint *)param_2;
  iStack_a4 = 0x8f5c06;
  iStack_94 = iVar1;
  puStack_2c = (undefined *)FUN_009d05b0();
  iStack_a4 = (int)pcStack_28 + 0x48;
  uStack_ac = 3;
  iStack_b0 = param_3;
  uStack_b4 = param_2;
  piStack_b8 = aiStack_7c;
  iStack_bc = 0x8f5c20;
  iStack_a8 = iVar1;
  puStack_30 = (undefined *)FUN_009d09d0();
  iStack_bc = (int)pcStack_28 + 0x44;
  uStack_14 = 0;
  uStack_34 = FUN_009d09d0(auStack_64,param_2,param_3,2,iVar1);
  puStack_a0 = auStack_4c;
  iStack_8c = (int)pcStack_28 + 0x40;
  uStack_14._0_1_ = 1;
  iStack_94 = 1;
  iStack_98 = param_3;
  iStack_9c = param_2;
  iStack_a4 = 0x8f5c62;
  iStack_90 = iVar1;
  uVar2 = FUN_009d09d0();
  iStack_8c = (int)puStack_2c;
  uStack_14._0_1_ = 2;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  puStack_2c = (undefined *)&iStack_a4;
  iStack_a8 = (int)puStack_30;
  uStack_ac = 0x8f5c96;
  FUN_0054ef60();
  puStack_30 = (undefined *)&iStack_bc;
  uStack_14._0_1_ = 3;
  FUN_0054ef60(uStack_34);
  uStack_14._0_1_ = 4;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  (*pcStack_28)();
  if (0xf < uStack_38) {
    uVar3 = uStack_38 + 1;
    uVar4 = auStack_4c[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_4c[0] - 4);
      uVar3 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  if (0xf < uStack_50) {
    uVar3 = uStack_50 + 1;
    uVar4 = auStack_64[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_64[0] - 4);
      uVar3 = uStack_50 + 0x24;
      if (0x1f < (auStack_64[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  if (0xf < uStack_68) {
    uVar4 = uStack_68 + 1;
    iVar1 = aiStack_7c[0];
    if (0xfff < uVar4) {
      iVar1 = *(int *)(aiStack_7c[0] + -4);
      uVar4 = uStack_68 + 0x24;
      if (0x1f < (aiStack_7c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar4);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 15729 ; VA 0x008f5db0 ; FUN_008f5db0 */

undefined4 __fastcall FUN_008f5db0(int param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_01256300();
  uVar2 = FUN_008cc740(aiStack_2c);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar2);
  (*pcVar1)();
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 15730 ; VA 0x008f5e70 ; FUN_008f5e70 */

undefined4 __thiscall FUN_008f5e70(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_34 [32];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3e68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d1820(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  iVar2 = iStack_14;
  FUN_00d88580(uVar3);
  (*pcVar1)(iVar2);
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 15731 ; VA 0x008f5f00 ; FUN_008f5f00 */

undefined4 __fastcall FUN_008f5f00(int param_1)

{
  (**(code **)(param_1 + 0x38))();
  return 0;
}



/* FUNCTION 15732 ; VA 0x008f5f30 ; FUN_008f5f30 */

undefined4 __thiscall FUN_008f5f30(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_2c,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)();
  uVar3 = FUN_009d5ac0(param_3,uVar3);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15733 ; VA 0x008f6000 ; FUN_008f6000 */

undefined4 FUN_008f6000(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  FUN_009d1aa0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uVar3 = FUN_009d09d0(aiStack_2c,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)();
  uVar3 = FUN_009d5ac0(param_2,uVar3);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15734 ; VA 0x008f60f0 ; FUN_008f60f0 */

void __thiscall FUN_008f60f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = param_3;
  iVar3 = FUN_01256300(param_3);
  iVar3 = iVar3 - param_4;
  if (0 < iVar3) {
    uVar4 = FUN_0090bea0();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_4 + 1,&param_3);
    uVar4 = param_3;
    if (cVar2 != '\0') goto LAB_008f6146;
  }
  uVar4 = FUN_008e6470(uVar1,param_4,1,iVar3,param_1 + 0x40);
LAB_008f6146:
  uVar4 = (**(code **)(param_1 + 0x38))(uVar4);
  FUN_009d5ac0(uVar1,uVar4);
  return;
}



/* FUNCTION 15735 ; VA 0x008f6170 ; FUN_008f6170 */

void __thiscall FUN_008f6170(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  
  uVar1 = (**(code **)(param_1 + 0x38))();
  FUN_009d5ac0(param_3,uVar1);
  return;
}



/* FUNCTION 15736 ; VA 0x008f61a0 ; FUN_008f61a0 */

char * FUN_008f61a0(undefined4 param_1)

{
  switch(param_1) {
  case 1:
    return "log";
  case 2:
    return "string";
  case 3:
    return "int";
  case 4:
    return "flag";
  default:
    return "invalid";
  }
}



/* FUNCTION 15737 ; VA 0x008f61f0 ; FUN_008f61f0 */

int * FUN_008f61f0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint in_stack_0000001c;
  undefined4 uVar8;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3e98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_005c2760();
  uVar8 = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar4 = FUN_008ccd70(1);
  puVar5 = (undefined4 *)FUN_008ce100(&puStack_20,&param_2,uVar4,uVar8);
  uStack_14 = *puVar5;
  piVar3 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 1;
    puVar5[2] = 1;
    *puVar5 = std::
              _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
              ::vftable;
    puVar5[3] = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = puVar5 + 3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_20 = puVar1;
  piStack_1c = puVar5;
  FUN_00f26000(uStack_14,puVar1);
  FUN_00ae40e0(uStack_18,puVar1);
  *param_1 = (int)puVar1;
  param_1[1] = (int)puVar5;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    iVar6 = param_2;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(param_2 + -4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15738 ; VA 0x008f6370 ; FUN_008f6370 */

void FUN_008f6370(uint param_1)

{
  int iVar1;
  char cVar2;
  undefined **ppuVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined8 in_stack_00000054;
  undefined4 uVar6;
  undefined auStack_1d4 [72];
  undefined auStack_18c [72];
  undefined auStack_144 [72];
  undefined auStack_fc [72];
  undefined auStack_b4 [72];
  undefined4 uStack_6c;
  int *piStack_68;
  uint uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3f31;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_005c2760();
  FUN_0060e0c0(&uStack_24,uStack_1c);
  uStack_8._0_1_ = 3;
  FUN_008ccd70();
  puStack_18 = &uStack_6c;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  uStack_6c = uStack_24;
  piStack_68 = piStack_20;
  uStack_8._0_1_ = 4;
  uStack_64 = 0;
  if (in_stack_0000001c != 0) {
    uStack_64 = in_stack_0000001c;
    if ((in_stack_0000001c & 1) == 0) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&uStack_5c,0);
    }
    else {
      uStack_5c = in_stack_00000024;
      uStack_58 = in_stack_00000028;
      uStack_54 = in_stack_0000002c;
      uStack_50 = in_stack_00000030;
      uStack_4c = in_stack_00000034;
    }
  }
  uStack_8._0_1_ = 5;
  uStack_44 = 0;
  if (in_stack_0000003c != 0) {
    uStack_44 = in_stack_0000003c;
    if ((in_stack_0000003c & 1) == 0) {
      (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_3c,0);
    }
    else {
      uStack_3c = in_stack_00000044;
      uStack_38 = in_stack_00000048;
      uStack_34 = in_stack_0000004c;
      uStack_30 = in_stack_00000050;
      uStack_2c = in_stack_00000054;
    }
  }
  uStack_8._0_1_ = 6;
  FUN_008e67f0(&uStack_6c);
  uStack_8._0_1_ = 7;
  uVar6 = 0;
  FUN_008e67f0(auStack_1d4);
  uStack_8._0_1_ = 8;
  FUN_008e67f0(auStack_18c);
  uStack_8._0_1_ = 9;
  FUN_008e67f0(auStack_144);
  uStack_8._0_1_ = 10;
  cVar2 = FUN_00585a40(auStack_b4,uVar6);
  if (cVar2 == '\0') {
    FUN_008e67f0(auStack_b4);
    uStack_8._0_1_ = 0xb;
    puStack_18 = (undefined4 *)FUN_01674e20(0x48);
    uStack_8._0_1_ = 0xc;
    if (puStack_18 != (undefined4 *)0x0) {
      FUN_008e67f0(auStack_fc);
    }
    FUN_008e9ba0();
    FUN_008e9ba0();
    cStack_11 = '\x01';
  }
  else {
    FUN_008e9ba0();
    cStack_11 = '\0';
  }
  FUN_008e9ba0();
  ppuVar3 = &PTR_FUN_0192d380;
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  FUN_008e9ba0(ppuVar3);
  FUN_008e9ba0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008e9ba0();
  FUN_008d0b40(&param_1,0x41f00000,ppuVar3);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_20[2] + -1;
    piStack_20[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_1;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_1 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15739 ; VA 0x008f6670 ; FUN_008f6670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_008f6670(int *param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined **ppuVar6;
  int *piVar7;
  int *piVar8;
  uint *puVar9;
  int *piVar10;
  undefined auStack_18c [20];
  undefined4 uStack_178;
  uint *puStack_174;
  uint *puStack_170;
  uint **ppuStack_16c;
  undefined4 uStack_160;
  undefined *puStack_15c;
  int iStack_158;
  int iStack_154;
  undefined4 *puStack_90;
  int *piStack_8c;
  int *piStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  int *piStack_78;
  int *piStack_74;
  uint *puStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  int *piStack_60;
  uint uStack_5c;
  uint *puStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int *piStack_40;
  int iStack_3c;
  int iStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  uint *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3fd2;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_8 = 1;
  if (param_2 == (undefined4 *)0x0) {
    ppuStack_16c = (uint **)0x192b524;
                    /* WARNING: Subroutine does not return */
    puStack_170 = (uint *)0x8f6d2c;
    ExceptionList = &pvStack_10;
    FUN_016757c0();
  }
  ppuStack_16c = (uint **)0x8f66b0;
  ExceptionList = &pvStack_10;
  piStack_30 = (int *)FUN_005c2760();
  puStack_28 = (uint *)0x0;
  puStack_24 = (uint *)0x0;
  puStack_20 = (uint *)0x0;
  uStack_8._0_1_ = 2;
  piVar10 = (int *)*param_2;
  piStack_1c = (int *)param_2[1];
  piStack_18 = piVar10;
  if (piVar10 != piStack_1c) {
    do {
      iVar1 = *piVar10;
      ppuStack_16c = (uint **)0x8f66e9;
      piStack_18 = piVar10;
      iVar4 = FUN_0088cb40();
      if (iVar1 == iVar4) {
        iVar1 = *piVar10;
        ppuStack_16c = (uint **)0x8f66f8;
        iVar4 = FUN_0088cb40();
        if (iVar1 != iVar4) {
          ppuStack_16c = (uint **)0x18c072c;
                    /* WARNING: Subroutine does not return */
          puStack_170 = (uint *)0x8f6d36;
          FUN_016757c0();
        }
        puVar9 = (uint *)(piVar10 + 2);
        if (piStack_18[1] == 0) {
          puVar9 = (uint *)0x0;
        }
        piStack_14 = (int *)puVar9[4];
        if (0xf < puVar9[5]) {
          puVar9 = (uint *)*puVar9;
        }
        if (&DAT_0000000f < piStack_14) {
          uVar5 = (uint)piStack_14 | 0xf;
          if (0x7fffffff < uVar5) {
            uVar5 = 0x7fffffff;
          }
          ppuStack_16c = (uint **)(uVar5 + 1);
          puStack_170 = (uint *)0x8f6750;
          puStack_174 = (uint *)FUN_00554060();
          ppuStack_16c = (uint **)((int)piStack_14 + 1);
          uStack_178 = 0x8f675f;
          puStack_170 = puVar9;
          puStack_70 = puStack_174;
          FUN_0170c6f0();
          uStack_5c = uVar5;
        }
        else {
          puStack_70 = (uint *)*puVar9;
          uStack_6c = puVar9[1];
          uStack_68 = puVar9[2];
          uStack_64 = puVar9[3];
          uStack_5c = 0xf;
        }
        ppuStack_16c = &puStack_70;
        uStack_8._0_1_ = 3;
        puStack_170 = (uint *)0x8f677b;
        piStack_60 = piStack_14;
        FUN_0054ef60();
        ppuStack_16c = &puStack_58;
        uStack_8._0_1_ = 4;
        puStack_170 = (uint *)0x8f6788;
        FUN_009cbbb0();
        uStack_8._0_1_ = 5;
        if (puStack_20 == puStack_24) {
          ppuStack_16c = &puStack_58;
          puStack_170 = puStack_24;
          puStack_174 = (uint *)0x8f67dc;
          FUN_008dd570();
        }
        else {
          puStack_24[4] = 0;
          puStack_24[5] = 0;
          *puStack_24 = (uint)puStack_58;
          puStack_24[1] = uStack_54;
          puStack_24[2] = uStack_50;
          puStack_24[3] = uStack_4c;
          puStack_24[4] = uStack_48;
          puStack_24[5] = uStack_44;
          puStack_24 = puStack_24 + 6;
          uStack_48 = 0;
          uStack_44 = 0xf;
          puStack_58 = (uint *)((uint)puStack_58 & 0xffffff00);
        }
        uStack_8._0_1_ = 3;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 3;
        if (0xf < uStack_44) {
          ppuStack_16c = (uint **)(uStack_44 + 1);
          puVar9 = puStack_58;
          if (0xfff < ppuStack_16c) {
            puVar9 = (uint *)puStack_58[-1];
            ppuStack_16c = (uint **)(uStack_44 + 0x24);
            if (0x1f < (uint)((int)puStack_58 + (-4 - (int)puVar9))) goto LAB_008f6db6;
          }
          puStack_174 = (uint *)0x8f6813;
          puStack_170 = puVar9;
          FUN_01674ea0();
        }
        uStack_8._0_1_ = 2;
        piVar10 = piStack_18;
        if (0xf < uStack_5c) {
          ppuStack_16c = (uint **)(uStack_5c + 1);
          puVar9 = puStack_70;
          if (0xfff < ppuStack_16c) {
            puVar9 = (uint *)puStack_70[-1];
            ppuStack_16c = (uint **)(uStack_5c + 0x24);
            uVar2 = (undefined)uStack_8;
            if (0x1f < (uint)((int)puStack_70 + (-4 - (int)puVar9))) goto LAB_008f6db6;
          }
          puStack_174 = (uint *)0x8f684b;
          puStack_170 = puVar9;
          FUN_01674ea0();
          piVar10 = piStack_18;
        }
      }
      piVar10 = piVar10 + 0x34;
      piStack_18 = piVar10;
    } while (piVar10 != piStack_1c);
  }
  ppuStack_16c = (uint **)0x18;
  puStack_170 = (uint *)0x8f686a;
  piStack_18 = (int *)FUN_01674e20();
  if (piStack_18 == (int *)0x0) {
    piStack_18 = (int *)0x0;
  }
  else {
    piStack_18[1] = 1;
    piStack_18[2] = 1;
    *piStack_18 = (int)std::
                       _Ref_count_obj<class_boost::promise<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>_>_>
                       ::vftable;
    piStack_18[3] = 0;
    piStack_18[4] = 0;
    *(undefined *)(piStack_18 + 5) = 0;
  }
  piVar8 = piStack_18;
  piVar10 = piStack_18 + 3;
  uStack_2c = 2;
  uStack_8._0_1_ = 6;
  ppuStack_16c = (uint **)0x8f68be;
  piStack_78 = piVar10;
  piStack_74 = piStack_18;
  FUN_008ff200();
  piStack_14 = (int *)*piVar10;
  if (piStack_14 == (int *)0x0) {
    ppuStack_16c = (uint **)0x8f6d3e;
    ppuStack_16c = (uint **)FUN_0056b1c0();
    uStack_8._0_1_ = 7;
    puStack_170 = (uint *)0x8f6d48;
    FUN_00564a30();
  }
  else if (*(char *)(piVar8 + 5) == '\0') {
    *(undefined *)(piVar8 + 5) = 1;
    piVar7 = (int *)piVar8[4];
    piVar10 = piVar7 + 1;
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar10 = *piVar10 + 1;
      UNLOCK();
      if (piVar7 != (int *)0x0) {
        LOCK();
        *piVar10 = *piVar10 + 1;
        UNLOCK();
        if (piVar7 != (int *)0x0) {
          LOCK();
          *piVar10 = *piVar10 + 1;
          UNLOCK();
        }
      }
    }
    uStack_8._0_1_ = 9;
    piStack_40 = piVar7;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar10;
      *piVar10 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        ppuStack_16c = (uint **)0x8f690f;
        (**(code **)(*piVar7 + 4))();
        LOCK();
        iVar1 = piVar7[2] + -1;
        piVar7[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f6920;
          (**(code **)(*piVar7 + 8))();
        }
      }
    }
    uStack_8._0_1_ = 10;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar1 = piVar7[1] + -1;
      piVar7[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppuStack_16c = (uint **)0x8f693b;
        (**(code **)(*piVar7 + 4))();
        LOCK();
        iVar1 = piVar7[2] + -1;
        piVar7[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f694c;
          (**(code **)(*piVar7 + 8))();
        }
      }
    }
    piVar10 = piVar7 + 1;
    uStack_2c = 6;
    piStack_80 = piStack_14;
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar10 = *piVar10 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 0xb;
    piStack_7c = piVar7;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar10;
      *piVar10 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        ppuStack_16c = (uint **)0x8f697e;
        (**(code **)(*piVar7 + 4))();
        LOCK();
        iVar1 = piVar7[2] + -1;
        piVar7[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f698f;
          (**(code **)(*piVar7 + 8))();
        }
      }
    }
    piStack_1c = piVar8 + 1;
    LOCK();
    *piStack_1c = *piStack_1c + 1;
    UNLOCK();
    piStack_88 = piVar8 + 3;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    ppuStack_16c = (uint **)0x8f69ad;
    piStack_84 = piVar8;
    puStack_174 = (uint *)FUN_008ccd60();
    ppuStack_16c = (uint **)0x1;
    puStack_170 = (uint *)0x0;
    piVar10 = piVar8 + 1;
    LOCK();
    *piVar10 = *piVar10 + 1;
    UNLOCK();
    LOCK();
    *piVar10 = *piVar10 + 1;
    UNLOCK();
    LOCK();
    *piVar10 = *piVar10 + 1;
    UNLOCK();
    LOCK();
    *piVar10 = *piVar10 + 1;
    UNLOCK();
    ppuVar6 = &PTR_FUN_0192d370;
    cVar3 = FUN_0055c750(piVar8 + 3,piVar8,auStack_18c);
    piVar8 = piStack_18;
    if (cVar3 == '\0') {
      ppuVar6 = (undefined **)0x0;
    }
    piVar10 = (int *)0xffffffff;
    LOCK();
    iVar1 = *piStack_1c;
    *piStack_1c = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_18)(ppuVar6);
      LOCK();
      iVar1 = piVar8[2] + -1;
      piVar8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
    LOCK();
    iVar1 = piVar8[1] + -1;
    piVar8[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar1 = piVar8[2] + -1;
      piVar8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
    LOCK();
    iVar1 = piVar8[1] + -1;
    piVar8[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar1 = piVar8[2] + -1;
      piVar8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
    FUN_008d16d0(&puStack_28,0x40000000,ppuVar6);
    if (piStack_14 != (int *)0x0) {
      ppuStack_16c = (uint **)0x0;
      puStack_170 = (uint *)0x8f6a8e;
      (**(code **)(*piStack_14 + 8))();
      puStack_170 = (uint *)&iStack_3c;
      puStack_174 = (uint *)0x8f6a97;
      FUN_005cac50();
      uStack_8._0_1_ = 0x10;
      puStack_170 = (uint *)0x8f6aaa;
      puStack_90 = (undefined4 *)(**(code **)(*piStack_14 + 0x14))();
      piStack_8c = (int *)puStack_90[1];
      if (piStack_8c != (int *)0x0) {
        LOCK();
        piStack_8c[1] = piStack_8c[1] + 1;
        UNLOCK();
        piStack_8c = (int *)puStack_90[1];
      }
      puStack_90 = (undefined4 *)*puStack_90;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
      piStack_14 = piStack_8c;
      if (puStack_90 != (undefined4 *)0x0) {
        piVar7 = (int *)*puStack_90;
        piStack_34 = (int *)puStack_90[1];
        piStack_30 = piVar7;
        if (piVar7 != piStack_34) {
          piStack_1c = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
          goto LAB_008f6b00;
        }
      }
LAB_008f6bcc:
      *param_1 = iStack_3c;
      param_1[1] = iStack_38;
      uStack_2c = 7;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_14[1] + (int)piVar10;
        piStack_14[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f6bf2;
          (**(code **)*piStack_14)();
          LOCK();
          iVar1 = piStack_14[2] + (int)piVar10;
          piStack_14[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            ppuStack_16c = (uint **)0x8f6c03;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      LOCK();
      iVar1 = piVar8[1] + (int)piVar10;
      piVar8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppuStack_16c = (uint **)0x8f6c14;
        (**(code **)*piVar8)();
        LOCK();
        iVar1 = piVar8[2] + (int)piVar10;
        piVar8[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f6c24;
          (**(code **)(*piVar8 + 4))();
        }
      }
      piVar10 = piStack_40;
      uStack_8._0_1_ = 0x15;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_40[1] + -1;
        piStack_40[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f6c40;
          (**(code **)(*piStack_40 + 4))();
          LOCK();
          piVar7 = piVar10 + 2;
          iVar1 = *piVar7 + -1;
          *piVar7 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            ppuStack_16c = (uint **)0x8f6c51;
            (**(code **)(*piVar10 + 8))();
          }
        }
      }
      LOCK();
      iVar1 = piVar8[1] + -1;
      piVar8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppuStack_16c = (uint **)0x8f6c65;
        (**(code **)*piVar8)();
        LOCK();
        iVar1 = piVar8[2] + -1;
        piVar8[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f6c75;
          (**(code **)(*piVar8 + 4))();
        }
      }
      if (puStack_28 != (uint *)0x0) {
        ppuStack_16c = &puStack_28;
        puStack_170 = puStack_24;
        puStack_174 = puStack_28;
        uStack_178 = 0x8f6c89;
        FUN_00559570();
        ppuStack_16c = (uint **)((((int)puStack_20 - (int)puStack_28) / 0x18) * 0x18);
        puVar9 = puStack_28;
        if (0xfff < ppuStack_16c) {
          puVar9 = (uint *)puStack_28[-1];
          ppuStack_16c = (uint **)((int)ppuStack_16c + 0x23);
          uVar2 = (undefined)uStack_8;
          if (0x1f < (uint)((int)puStack_28 + (-4 - (int)puVar9))) {
LAB_008f6db6:
            uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            ppuStack_16c = (uint **)&UNK_008f6dbb;
            FUN_017167a3();
          }
        }
        puStack_174 = (uint *)0x8f6cd0;
        puStack_170 = puVar9;
        FUN_01674ea0();
        puStack_28 = (uint *)0x0;
        puStack_24 = (uint *)0x0;
        puStack_20 = (uint *)0x0;
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar1 = param_3[1] + -1;
        param_3[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppuStack_16c = (uint **)0x8f6cfe;
          (**(code **)*param_3)();
          LOCK();
          piVar10 = param_3 + 2;
          iVar1 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            ppuStack_16c = (uint **)0x8f6d0d;
            (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    goto LAB_008f6d5a;
  }
  ppuStack_16c = (uint **)0x8f6d50;
  ppuStack_16c = (uint **)FUN_0056ab30();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puStack_170 = (uint *)0x8f6d5a;
  FUN_005648f0();
LAB_008f6d5a:
  ppuStack_16c = (uint **)0x8f6d62;
  ppuStack_16c = (uint **)FUN_0056acb0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  puStack_170 = (uint *)0x8f6d6c;
  FUN_00564940();
  do {
    ppuStack_16c = (uint **)&DAT_01ee0c4c;
    puStack_170 = (uint *)0x8f6d76;
    FUN_016f3809();
    if (DAT_01ee0c4c == -1) {
      ppuStack_16c = (uint **)&DAT_01ee0c4c;
      _DAT_01ee0c40 = FUN_0057bbb0;
      _DAT_01ee0c44 = FUN_005880a0;
      DAT_01ee0c48 = FUN_0057d5e0;
      puStack_170 = (uint *)0x8f6dae;
      FUN_016f37bf();
    }
    do {
      puStack_15c = &DAT_01ee0c40;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
      puStack_170 = *(uint **)(iStack_3c + 4);
      if (*(uint **)(iStack_3c + 8) == puStack_170) {
        ppuStack_16c = (uint **)&uStack_160;
        puStack_174 = (uint *)0x8f6b99;
        FUN_005ca4f0();
      }
      else {
        ppuStack_16c = (uint **)&uStack_160;
        puStack_170 = (uint *)0x8f6b7e;
        FUN_005caf00();
        *(int *)(iStack_3c + 4) = *(int *)(iStack_3c + 4) + 0xd0;
      }
      uStack_8._0_1_ = 0x14;
      if (puStack_15c != (undefined *)0x0) {
        ppuStack_16c = (uint **)&iStack_158;
        puStack_170 = (uint *)0x8f6bb3;
        (**(code **)(puStack_15c + 8))();
      }
      piVar7 = piVar8 + 2;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
      piVar8 = piStack_18;
      if (piVar7 == piStack_34) goto LAB_008f6bcc;
LAB_008f6b00:
      ppuStack_16c = (uint **)0x8f6b05;
      uStack_160 = FUN_0088cc80();
      iStack_154 = piVar7[1];
      puStack_15c = (undefined *)0x0;
      if (iStack_154 != 0) {
        LOCK();
        *(int *)(iStack_154 + 4) = *(int *)(iStack_154 + 4) + 1;
        UNLOCK();
        iStack_154 = piVar7[1];
      }
      iStack_158 = *piVar7;
      piVar8 = piVar7;
    } while (DAT_01ee0c4c <= piStack_1c[0xd]);
  } while( true );
}



/* FUNCTION 15740 ; VA 0x008f6dc0 ; FUN_008f6dc0 */

/* WARNING: Removing unreachable block (ram,0x008f6e67) */
/* WARNING: Removing unreachable block (ram,0x008f6e75) */
/* WARNING: Removing unreachable block (ram,0x008f6eab) */
/* WARNING: Removing unreachable block (ram,0x008f6e85) */

void FUN_008f6dc0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)*param_2;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    FUN_0054ef60();
    uStack_8 = 0;
    FUN_006ecaa0(uStack_2c,uStack_28,uStack_24,uStack_20,CONCAT44(uStack_18,uStack_1c));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 15741 ; VA 0x008f6ec0 ; FUN_008f6ec0 */

void FUN_008f6ec0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009ca3d0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  param_2 = (int *)*param_2;
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = *param_2;
  uVar1 = *puVar3;
  iVar4 = FUN_0088cdc0();
  if (iVar6 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar6 = piVar5[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
      UNLOCK();
      iVar6 = piVar5[1];
    }
    uStack_8 = 0;
    FUN_0089bf10(*piVar5,iVar6,uVar1);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15742 ; VA 0x008f6fa0 ; FUN_008f6fa0 */

void FUN_008f6fa0(void)

{
  FUN_006eccd0();
  return;
}



/* FUNCTION 15743 ; VA 0x008f6fc0 ; FUN_008f6fc0 */

void FUN_008f6fc0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088daf0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*(undefined *)piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15744 ; VA 0x008f7020 ; FUN_008f7020 */

/* WARNING: Removing unreachable block (ram,0x008f70c2) */
/* WARNING: Removing unreachable block (ram,0x008f70d0) */
/* WARNING: Removing unreachable block (ram,0x008f716d) */
/* WARNING: Removing unreachable block (ram,0x008f70e4) */

undefined4 FUN_008f7020(undefined4 param_1,int *param_2)

{
  double dVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  float fVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_2 + 0xa4))();
  dVar1 = *(double *)(param_2 + 0x16);
  FUN_005542c0(&DAT_018dbc90,4);
  uStack_8 = 0;
  piVar3 = (int *)FUN_008a1240();
  iVar2 = piVar3[3];
  iVar4 = FUN_009fb200();
  piVar5 = (int *)0x0;
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da)) {
    piVar5 = piVar3;
  }
  uStack_8 = 0xffffffff;
  if (piVar5 == (int *)0x0) {
    fVar6 = 0.0;
  }
  else {
    (**(code **)(*piVar5 + 0xa4))();
    fVar6 = (float)*(double *)(piVar5 + 0x16);
  }
  FUN_01675640(param_1,"%.2f, %.2fB, %.2f",(double)((fVar6 * (float)dVar1) / DAT_018ce324),
               (double)fVar6,(double)(float)dVar1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15745 ; VA 0x008f7180 ; FUN_008f7180 */

void __fastcall FUN_008f7180(int param_1)

{
  if (*(char *)(param_1 + 0x240) == '\0') {
    *(undefined *)(param_1 + 0x240) = 1;
    FUN_006eccd0();
    return;
  }
  return;
}



/* FUNCTION 15746 ; VA 0x008f71a0 ; FUN_008f71a0 */

int FUN_008f71a0(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint in_stack_00000020;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3ff8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01ee04ac != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee04ac,"DataModel::gameStartInfoLoadedHelperError",0);
  }
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_18 != 0) {
    if (DAT_01ee04ac != '\0') {
      puVar4 = &param_3;
      if (0xf < in_stack_00000020) {
        puVar4 = param_3;
      }
      FUN_01677650(DAT_01ee04ac,"DataModel::gameStartInfoLoadedHelperError %s",puVar4);
    }
    iVar3 = FUN_0087afe0();
    *(undefined *)(iStack_18 + 0x249) = 0;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    puVar4 = param_3;
    if (0xfff < uVar5) {
      puVar4 = (undefined4 *)param_3[-1];
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(puVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15747 ; VA 0x008f72c0 ; FUN_008f72c0 */

void FUN_008f72c0(undefined4 param_1,int *param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 extraout_var;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017c4028;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uVar4 = extraout_var;
  FUN_008f71a0(param_1,param_2);
  if (in_stack_00000024 != 0) {
    FUN_0054ef60(&param_3);
    FUN_005e65e0();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[2] + -1;
    param_2[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_2 + 4))(uVar4);
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    uVar2 = param_3;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_3 - 4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = 3;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15748 ; VA 0x008f73e0 ; FUN_008f73e0 */

int FUN_008f73e0(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  int in_stack_0000001c;
  uint in_stack_00000020;
  int iStack_f8;
  int iStack_f4;
  undefined4 auStack_f0 [50];
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c406b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01ee04ac != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee04ac,"DataModel::gameStartInfoLoadedHelperSuccess",0);
  }
  iVar4 = FUN_00587490(&iStack_28);
  uStack_8._0_1_ = 2;
  if (iStack_28 != 0) {
    if (in_stack_0000001c == 0) {
      iVar4 = FUN_0087afe0();
      *(undefined *)(iStack_28 + 0x249) = 0;
    }
    else {
      if (DAT_01ee04ac != '\0') {
        puVar6 = &param_3;
        if (0xf < in_stack_00000020) {
          puVar6 = param_3;
        }
        FUN_01677650(DAT_01ee04ac,"DataModel::gameStartInfoLoadedHelperSuccess %s",puVar6);
      }
      iStack_f8 = FUN_00888530();
      iStack_f4 = 0;
      uStack_8._0_1_ = 3;
      cVar2 = FUN_0098ef90(&param_3,&iStack_f8,0);
      iVar4 = iStack_f8;
      if (cVar2 != '\0') {
        iVar5 = FUN_008881d0();
        if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        puVar6 = auStack_f0;
        uStack_1c = 0;
        if (iStack_f4 == 0) {
          puVar6 = (undefined4 *)0x0;
        }
        iStack_18 = 0;
        iStack_18 = puVar6[1];
        if (iStack_18 != 0) {
          LOCK();
          *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
          UNLOCK();
          iStack_18 = puVar6[1];
        }
        uStack_1c = *puVar6;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        uVar3 = FUN_00f586a0(&uStack_1c);
        uStack_20 = CONCAT31(uStack_20._1_3_,uVar3);
        FUN_00bb49e0(uStack_20);
        uVar7 = FUN_00f58720(&uStack_1c);
        if (*(int *)(iStack_28 + 0x1a0) != 0) {
          FUN_00bb4d70(uVar7);
        }
        iVar4 = FUN_00f58cb0(&uStack_1c);
        if (iVar4 != *(int *)(iStack_28 + 0x244)) {
          *(int *)(iStack_28 + 0x244) = iVar4;
          FUN_008a4940(&DAT_0211c718);
        }
        uVar7 = FUN_00f58b40(&uStack_1c);
        if ((*(int *)(iStack_28 + 0x1a0) != 0) &&
           (FUN_00bb4c60(uVar7), *(int *)(iStack_28 + 0x1a0) != 0)) {
          FUN_00bb3bb0(&uStack_1c);
        }
        if (DAT_01d63584 != '\0') {
          cStack_11 = FUN_00f58d90(&uStack_1c);
          if (iStack_28 != -0xc) {
            FUN_00672ab0();
          }
          FUN_00c0ea00((cStack_11 == '\0') + '\x01');
        }
        uStack_8._0_1_ = 3;
        FUN_00550b30();
      }
      FUN_0087afe0();
      *(undefined *)(iStack_28 + 0x249) = 0;
      uStack_8._0_1_ = 5;
      iVar4 = iStack_f4;
      if (iStack_f4 != 0) {
        iVar4 = (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar5 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar8 = in_stack_00000020 + 1;
    puVar6 = param_3;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)param_3[-1];
      uVar8 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(puVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15749 ; VA 0x008f7690 ; FUN_008f7690 */

void FUN_008f7690(undefined4 param_1,int *param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 extraout_var;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017c4098;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uVar4 = extraout_var;
  FUN_008f73e0(param_1,param_2);
  if (in_stack_00000024 != 0) {
    (**(code **)((in_stack_00000024 & 0xfffffffe) + 4))(&stack0x0000002c,uVar4);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[2] + -1;
    param_2[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    uVar2 = param_3;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_3 - 4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = 4;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}


