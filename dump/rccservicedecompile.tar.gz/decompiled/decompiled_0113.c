/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 28250 ; VA 0x00c421c0 ; FUN_00c421c0 */

void __thiscall FUN_00c421c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00896cc0();
  *param_3 = uVar3;
  iVar4 = FUN_008972d0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28251 ; VA 0x00c42220 ; FUN_00c42220 */

void __thiscall FUN_00c42220(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00c456c0();
  *param_3 = uVar3;
  iVar4 = FUN_00c45a60();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28252 ; VA 0x00c42280 ; FUN_00c42280 */

void __thiscall FUN_00c42280(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c45750();
  *param_3 = uVar3;
  iVar4 = FUN_00c45ad0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28253 ; VA 0x00c422e0 ; FUN_00c422e0 */

void __thiscall FUN_00c422e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c45800();
  *param_3 = uVar3;
  iVar4 = FUN_00c45b40();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28254 ; VA 0x00c42340 ; FUN_00c42340 */

void __thiscall FUN_00c42340(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00c458b0();
  *param_3 = uVar3;
  iVar4 = FUN_00c45bb0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28255 ; VA 0x00c423a0 ; FUN_00c423a0 */

void __thiscall FUN_00c423a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00c45940();
  *param_3 = uVar3;
  iVar4 = FUN_00c45c20();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28256 ; VA 0x00c42400 ; FUN_00c42400 */

void __thiscall FUN_00c42400(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00c459d0();
  *param_3 = uVar3;
  iVar4 = FUN_00c45c90();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28257 ; VA 0x00c42480 ; FUN_00c42480 */

undefined FUN_00c42480(char param_1)

{
  if (((param_1 != ' ') && (param_1 != '\t')) && (param_1 != '\n')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 28258 ; VA 0x00c424a0 ; FUN_00c424a0 */

void FUN_00c424a0(void)

{
  FUN_00fa7c20();
  return;
}



/* FUNCTION 28259 ; VA 0x00c424b0 ; FUN_00c424b0 */

uint FUN_00c424b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c3ebd0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28260 ; VA 0x00c424d0 ; FUN_00c424d0 */

uint FUN_00c424d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c3ebd0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28261 ; VA 0x00c424f0 ; FUN_00c424f0 */

void __thiscall
FUN_00c424f0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if ((*(int *)(param_1 + 0x5e0) == 0) || (*(int *)(param_1 + 0x5e0) == 1)) {
    FUN_00c415a0(param_2,param_4,param_5);
    *(undefined4 *)(param_1 + 0x5cc) = param_3;
    *(int *)(param_1 + 0x5c8) = param_2;
    *(char *)(param_1 + 0x5d0) = (char)param_4;
    if (param_2 != 4) {
      *(undefined4 *)(param_1 + 0x5e0) = 1;
    }
    iVar1 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    if ((iVar1 != 0) && (iVar2 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if ((iVar2 != 0) &&
       (iVar1 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
      uVar3 = FUN_00560d40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00995770();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      if (*piVar4 != 0) {
        *(undefined8 *)(param_1 + 0x5d8) = *(undefined8 *)(*piVar4 + 0x80);
      }
    }
  }
  return;
}



/* FUNCTION 28262 ; VA 0x00c42650 ; FUN_00c42650 */

void __thiscall FUN_00c42650(int param_1,int param_2,int param_3)

{
  char cVar1;
  
  if (*(int *)(param_1 + 0x5e0) != 1) {
    if (*(int *)(param_1 + 0x5e0) != 2) {
      return;
    }
    cVar1 = FUN_00554b40();
    if (cVar1 != '\0') {
      return;
    }
  }
  if ((param_2 == *(int *)(param_1 + 0x5c8)) && (param_3 == *(int *)(param_1 + 0x5cc))) {
    *(undefined4 *)(param_1 + 0x5e0) = 0;
  }
  return;
}



/* FUNCTION 28263 ; VA 0x00c426a0 ; FUN_00c426a0 */

void FUN_00c426a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c456c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28264 ; VA 0x00c426e0 ; FUN_00c426e0 */

void FUN_00c426e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c45750();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28265 ; VA 0x00c42720 ; FUN_00c42720 */

void FUN_00c42720(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c45800();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28266 ; VA 0x00c42760 ; FUN_00c42760 */

void FUN_00c42760(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c458b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28267 ; VA 0x00c427a0 ; FUN_00c427a0 */

void FUN_00c427a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c45940();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28268 ; VA 0x00c427e0 ; FUN_00c427e0 */

void FUN_00c427e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c459d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28269 ; VA 0x00c42820 ; FUN_00c42820 */

void __thiscall FUN_00c42820(int param_1,int param_2)

{
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809958;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a461b0(param_1,param_1 + 0x5f4,param_1 + 0x60c);
  FUN_00fad240();
  FUN_00faa3a0(param_2);
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  FUN_00c449d0(0,&uStack_18,*(undefined4 *)(param_2 + 4));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28270 ; VA 0x00c428a0 ; FUN_00c428a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c428a0(int param_1,double *param_2)

{
  char cVar1;
  double dVar2;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018099f0;
  pvStack_10 = ExceptionList;
  if ((DAT_01d6e86c == '\0') &&
     (ExceptionList = &pvStack_10, cVar1 = FUN_00c401e0(param_1 + -0x540), cVar1 != '\0')) {
    if (*(int *)(param_1 + 0xa0) == 1) {
      if ((*(double *)(param_1 + 0x98) + _PTR_018cf0f8 < *param_2) &&
         (cVar1 = FUN_00554b40(), cVar1 == '\0')) {
        uStack_18 = 0;
        uStack_14 = 0;
        uStack_8 = 0;
        FUN_00c415a0(*(undefined4 *)(param_1 + 0x88),*(undefined *)(param_1 + 0x90),&uStack_18);
        FUN_00550b30();
        *(undefined4 *)(param_1 + 0xa0) = 2;
        *(double *)(param_1 + 0x98) = *param_2;
      }
    }
    else if (((*(int *)(param_1 + 0xa0) == 2) && (cVar1 = FUN_00554b40(), cVar1 == '\0')) &&
            (*(double *)(param_1 + 0x98) + DAT_018ce300 < *param_2)) {
      uStack_18 = 0;
      uStack_14 = 0;
      do {
        uStack_8 = 1;
        FUN_00c415a0(*(undefined4 *)(param_1 + 0x88),*(undefined *)(param_1 + 0x90),&uStack_18);
        dVar2 = *(double *)(param_1 + 0x98) + DAT_018ce300;
        *(double *)(param_1 + 0x98) = dVar2;
      } while (dVar2 + DAT_018ce300 < *param_2);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28271 ; VA 0x00c42a30 ; FUN_00c42a30 */

void __thiscall FUN_00c42a30(int param_1,undefined *param_2)

{
  byte bVar1;
  int iVar2;
  char cVar3;
  byte *pbVar4;
  uint uVar5;
  undefined4 uVar6;
  byte *pbVar7;
  int *piVar8;
  int iVar9;
  byte *pbVar10;
  uint uVar11;
  int iVar12;
  byte *pbVar13;
  bool bVar14;
  undefined auStack_24 [12];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809a10;
  pvStack_10 = ExceptionList;
  if (DAT_01d686d0 == '\0') {
    ExceptionList = &pvStack_10;
    if (param_2 == &DAT_02135700) {
      pbVar13 = (byte *)(param_1 + 0x374);
      ExceptionList = &pvStack_10;
      if ((byte *)(param_1 + 0x564) != pbVar13) {
        pbVar7 = pbVar13;
        if (0xf < *(uint *)(param_1 + 0x388)) {
          pbVar7 = *(byte **)pbVar13;
        }
        ExceptionList = &pvStack_10;
        FUN_005542c0(pbVar7,*(undefined4 *)(param_1 + 900));
      }
      if ((DAT_01d686e0 != '\0') && (cVar3 = FUN_00c401e0(param_1), cVar3 == '\0')) {
        FUN_00fab480(*(int *)(param_1 + 0x574) != 0);
      }
      uVar5 = *(uint *)(param_1 + 0x5b8);
      if (uVar5 != 0xffffffff) {
        uVar11 = *(uint *)(param_1 + 0x574);
        if (uVar5 < *(uint *)(param_1 + 0x574)) {
          uVar11 = uVar5;
        }
        piVar8 = (int *)(param_1 + 0x57c);
        if (0xf < *(uint *)(param_1 + 0x590)) {
          piVar8 = (int *)*piVar8;
        }
        FUN_00585d40(uVar11,piVar8,*(undefined4 *)(param_1 + 0x58c));
      }
      FUN_00fad240();
      auStack_24[0] = 0;
      uStack_8 = 1;
      (**(code **)(*(int *)(param_1 + 0x348) + 4))(auStack_18,auStack_24,0);
      pbVar7 = (byte *)(param_1 + 0x54c);
      uStack_8 = 0xffffffff;
      pbVar10 = pbVar7;
      if (0xf < *(uint *)(param_1 + 0x560)) {
        pbVar10 = *(byte **)pbVar7;
      }
      pbVar4 = pbVar13;
      if (0xf < *(uint *)(param_1 + 0x388)) {
        pbVar4 = *(byte **)pbVar13;
      }
      do {
        bVar1 = *pbVar4;
        bVar14 = bVar1 < *pbVar10;
        if (bVar1 != *pbVar10) {
LAB_00c42ce0:
          uVar5 = -(uint)bVar14 | 1;
          goto LAB_00c42ce5;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar4[1];
        bVar14 = bVar1 < pbVar10[1];
        if (bVar1 != pbVar10[1]) goto LAB_00c42ce0;
        pbVar4 = pbVar4 + 2;
        pbVar10 = pbVar10 + 2;
      } while (bVar1 != 0);
      uVar5 = 0;
LAB_00c42ce5:
      if (uVar5 != 0) {
        if (pbVar7 != pbVar13) {
          if (0xf < *(uint *)(param_1 + 0x388)) {
            pbVar13 = *(byte **)pbVar13;
          }
          FUN_005542c0(pbVar13,*(undefined4 *)(param_1 + 900));
        }
        iVar2 = *(int *)(param_1 + 0x55c);
        iVar12 = *(int *)(param_1 + 0x5c0);
        if (iVar2 < *(int *)(param_1 + 0x5c0)) {
          iVar12 = iVar2;
        }
        iVar9 = *(int *)(param_1 + 0x5b8);
        if (iVar2 < *(int *)(param_1 + 0x5b8)) {
          iVar9 = iVar2;
        }
        FUN_00c44da0(iVar9,iVar12,0xffffffff);
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_2 == &DAT_02135700) {
      pbVar13 = (byte *)(param_1 + 0x374);
      ExceptionList = &pvStack_10;
      if ((byte *)(param_1 + 0x564) != pbVar13) {
        pbVar7 = pbVar13;
        if (0xf < *(uint *)(param_1 + 0x388)) {
          pbVar7 = *(byte **)pbVar13;
        }
        ExceptionList = &pvStack_10;
        FUN_005542c0(pbVar7,*(undefined4 *)(param_1 + 900));
      }
      if ((DAT_01d686e0 != '\0') && (cVar3 = FUN_00c401e0(param_1), cVar3 == '\0')) {
        FUN_00fab480(*(int *)(param_1 + 0x574) != 0);
      }
      uVar5 = *(uint *)(param_1 + 0x5b8);
      if (uVar5 != 0xffffffff) {
        uVar11 = *(uint *)(param_1 + 0x574);
        if (uVar5 < *(uint *)(param_1 + 0x574)) {
          uVar11 = uVar5;
        }
        piVar8 = (int *)(param_1 + 0x57c);
        if (0xf < *(uint *)(param_1 + 0x590)) {
          piVar8 = (int *)*piVar8;
        }
        FUN_00585d40(uVar11,piVar8,*(undefined4 *)(param_1 + 0x58c));
      }
      FUN_00fad240();
      auStack_24[0] = 0;
      uStack_8 = 0;
      (**(code **)(*(int *)(param_1 + 0x348) + 4))(auStack_18,auStack_24,0);
      pbVar7 = (byte *)(param_1 + 0x54c);
      uStack_8 = 0xffffffff;
      pbVar10 = pbVar7;
      if (0xf < *(uint *)(param_1 + 0x560)) {
        pbVar10 = *(byte **)pbVar7;
      }
      pbVar4 = pbVar13;
      if (0xf < *(uint *)(param_1 + 0x388)) {
        pbVar4 = *(byte **)pbVar13;
      }
      do {
        bVar1 = *pbVar4;
        bVar14 = bVar1 < *pbVar10;
        if (bVar1 != *pbVar10) {
LAB_00c42b61:
          uVar5 = -(uint)bVar14 | 1;
          goto LAB_00c42b66;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar4[1];
        bVar14 = bVar1 < pbVar10[1];
        if (bVar1 != pbVar10[1]) goto LAB_00c42b61;
        pbVar4 = pbVar4 + 2;
        pbVar10 = pbVar10 + 2;
      } while (bVar1 != 0);
      uVar5 = 0;
LAB_00c42b66:
      if (uVar5 != 0) {
        if (pbVar7 != pbVar13) {
          if (0xf < *(uint *)(param_1 + 0x388)) {
            pbVar13 = *(byte **)pbVar13;
          }
          FUN_005542c0(pbVar13,*(undefined4 *)(param_1 + 900));
        }
        iVar2 = *(int *)(param_1 + 0x55c);
        iVar12 = *(int *)(param_1 + 0x5c0);
        if (iVar2 < *(int *)(param_1 + 0x5c0)) {
          iVar12 = iVar2;
        }
        iVar9 = *(int *)(param_1 + 0x5b8);
        if (iVar2 < *(int *)(param_1 + 0x5b8)) {
          iVar9 = iVar2;
        }
        FUN_00c44da0(iVar9,iVar12,0xffffffff);
      }
      if (*(char *)(param_1 + 0x5a5) != '\0') {
        FUN_00faae80(param_1 + 0x408);
        uVar6 = FUN_00d7f080(*(undefined4 *)(param_1 + 0x5b8));
        FUN_00d7f5f0(uVar6);
      }
    }
  }
  FUN_00faaab0(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28272 ; VA 0x00c42d50 ; FUN_00c42d50 */

void __thiscall FUN_00c42d50(int param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar2 = param_3;
  iVar1 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01809a49;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_018bc9b8,0);
    FUN_01679490();
    if (iVar2 == 0) {
      iStack_20 = iVar2;
      puStack_1c = (undefined4 *)iVar2;
      iStack_8 = iVar2;
      FUN_00c449d0(0,&iStack_20,0);
      iStack_8 = 0xffffffff;
    }
  }
  FUN_00c79070(iVar1,iVar2);
  if (DAT_01d6e86c == '\0') {
    FUN_00f45260(iVar1,iVar2);
  }
  if (iVar2 != 0) {
    *(undefined *)(param_1 + 0x5a3) = 1;
    FUN_008a4940(&DAT_02135568);
    piVar4 = (int *)(param_1 + 0x374);
    if ((int *)(param_1 + 0x54c) != piVar4) {
      if (0xf < *(uint *)(param_1 + 0x388)) {
        piVar4 = (int *)*piVar4;
      }
      FUN_005542c0(piVar4,*(undefined4 *)(param_1 + 900));
    }
    param_3 = FUN_00634d90();
    if (param_3 != 0) {
      param_3 = param_3 + 0xcc;
      iStack_8 = 1;
      uVar5 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 2;
      uStack_18 = uVar5;
      puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
      if (puStack_1c == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puStack_1c = 0;
        puStack_1c[1] = 1;
        puStack_1c[2] = FUN_00c41640;
        puStack_1c[3] = _guard_check_icall;
        puStack_1c[4] = 0;
        puStack_1c[5] = param_3;
        puStack_1c[6] = param_1;
        puVar6 = puStack_1c;
      }
      FUN_016797d0(puVar6);
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_14 = 1;
      iStack_8._0_1_ = 3;
      param_2 = puVar6;
      FUN_01675290(uVar5);
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      cVar3 = FUN_01679300(&param_2);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      if (param_2 != (undefined4 *)0x0) {
        piVar4 = param_2 + 1;
        LOCK();
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28273 ; VA 0x00c42f20 ; FUN_00c42f20 */

undefined4 * __thiscall FUN_00c42f20(int *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  code *pcVar2;
  int *piVar3;
  char cVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4f08;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00c45590();
  if (cVar4 != '\0') {
    iVar7 = *param_3;
    if ((*(int *)(iVar7 + 0x54) == 9) && (*(int *)(iVar7 + 0x5c) == 2)) {
      FUN_00c449d0();
      iVar7 = *param_3;
    }
    iVar7 = *(int *)(iVar7 + 0x54);
    if ((iVar7 < 0) || (4 < iVar7)) {
      if (iVar7 == 8) {
        (**(code **)(*param_1 + 0x13c))();
        ExceptionList = pvStack_10;
        return param_2;
      }
      if (iVar7 == 0x14) {
        cVar4 = FUN_00c401e0();
        if (param_1[0x178] == 0) {
          cVar5 = FUN_00554b40();
          if (cVar5 != '\0') {
            cVar5 = FUN_00c401e0();
            if (cVar5 != '\0') {
              FUN_0054ef60();
              uStack_14 = 0x10;
              uStack_8 = 0;
              FUN_00c40a80();
              uStack_8 = 0xffffffff;
              FUN_005507b0();
            }
          }
        }
        if (cVar4 == '\0') {
          puVar8 = &uStack_38;
          uVar6 = 0;
          piStack_34 = (int *)0x0;
          param_3 = (int *)0x0;
          uVar10 = uStack_14 | 4;
          uVar9 = 0;
          uStack_38 = 0;
          uVar11 = 0;
        }
        else {
          uStack_30 = 1;
          uStack_2c = 0;
          uStack_28 = 0;
          FUN_0060e0c0();
          puVar8 = &uStack_24;
          uVar10 = uStack_14 | 0x22;
          param_3 = (int *)uStack_24;
          uVar6 = uStack_30;
          uVar9 = uStack_2c;
          uVar11 = uStack_28;
        }
        *puVar8 = 0;
        *param_2 = uVar6;
        param_2[2] = uVar11;
        param_2[1] = uVar9;
        param_2[3] = param_3;
        param_2[4] = puVar8[1];
        puVar8[1] = 0;
        if ((uVar10 & 4) != 0) {
          uVar10 = uVar10 & 0xfffffffb;
          if (piStack_34 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_34[2] + -1;
            piStack_34[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piStack_34 + 4))();
            }
          }
        }
        if (((uVar10 & 2) != 0) && (piStack_20 != (int *)0x0)) {
          LOCK();
          piVar3 = piStack_20 + 2;
          iVar7 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
        ExceptionList = pvStack_10;
        return param_2;
      }
      if (iVar7 == 0x15) {
        FUN_00d81770();
        FUN_0054ef60(*param_3 + 0x90);
        FUN_00c45d20();
        FUN_0090cc40();
        ExceptionList = pvStack_10;
        return param_2;
      }
      if (iVar7 == 7) {
        if (DAT_01d686f0 == '\0') {
          (**(code **)(*param_1 + 300))();
          ExceptionList = pvStack_10;
          return param_2;
        }
        *(undefined *)(param_1 + 0x168) = 1;
        pcVar2 = *(code **)(*param_1 + 0x10c);
        FUN_00d814c0();
        cVar4 = (*pcVar2)();
        if (cVar4 == '\0') {
          cVar4 = FUN_00c401e0();
          if (((cVar4 != '\0') && (*(int *)(*param_3 + 0x5c) == 0)) &&
             (*(char *)((int)param_1 + 0x5a1) == '\0')) {
            FUN_00c449d0();
            goto LAB_00c431da;
          }
        }
        if ((*param_3 == param_1[0x16a]) && (*(int *)(*param_3 + 0x5c) == 2)) {
          param_1[0x16a] = 0;
          piVar3 = (int *)param_1[0x16b];
          param_1[0x16b] = 0;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar7 = piVar3[1] + -1;
            piVar3[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar7 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
      }
      else {
        cVar4 = FUN_00d81a20();
        if (cVar4 != '\0') {
          (**(code **)(*param_1 + 0x140))();
          ExceptionList = pvStack_10;
          return param_2;
        }
      }
    }
    else {
      cVar4 = FUN_00d81cb0();
      if (cVar4 != '\0') {
        (**(code **)(*param_1 + 0x138))();
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
LAB_00c431da:
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = 0;
  param_2[3] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28274 ; VA 0x00c432c0 ; FUN_00c432c0 */

undefined4 * __thiscall FUN_00c432c0(int *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  undefined uVar4;
  undefined4 uVar5;
  float *pfVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int *piVar9;
  uint uVar10;
  int iVar11;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [16];
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined auStack_1c [8];
  int iStack_14;
  int *piStack_10;
  uint uStack_c;
  char cStack_5;
  
  uStack_c = 0;
  (**(code **)(*param_1 + 0xd4))(auStack_1c);
  uVar5 = FUN_00d5c5d0(auStack_3c);
  FUN_00802e80(&fStack_2c,uVar5);
  pfVar6 = (float *)FUN_00d814c0(&iStack_14);
  if ((((*pfVar6 < fStack_2c) || (pfVar6[1] < fStack_28)) || (fStack_24 < *pfVar6)) ||
     (fStack_20 < pfVar6[1])) {
    cStack_5 = '\0';
  }
  else {
    cStack_5 = '\x01';
  }
  iVar11 = *param_3;
  if (DAT_01d686f0 == '\0') {
    uVar10 = *(uint *)(iVar11 + 0xb0) & 0x80000003;
    if ((int)uVar10 < 0) {
      uVar10 = (uVar10 - 1 | 0xfffffffc) + 1;
    }
    if ((((*(int *)(iVar11 + 0x5c) == 0) && (*(int *)(iVar11 + 0x54) == 0)) &&
        (*(char *)(param_1 + 0x168) != '\0')) &&
       (((cStack_5 != '\0' && (uVar10 == 0)) && (cVar3 = FUN_00c401e0(param_1), cVar3 == '\0')))) {
      cVar3 = FUN_00c41a50(param_3);
      if (cVar3 != '\0') {
LAB_00c4360a:
        FUN_0090cc40(param_2);
        return param_2;
      }
    }
    else if (((*(int *)(*param_3 + 0x5c) == 0) &&
             (((iVar11 = *(int *)(*param_3 + 0x54), iVar11 == 0 || (iVar11 == 1)) || (iVar11 == 2)))
             ) && (((uVar10 == 1 && (cStack_5 != '\0')) &&
                   (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')))) {
      if (DAT_01d686d0 == '\0') {
        puVar8 = (undefined4 *)FUN_00d814c0(&fStack_24);
        uVar7 = FUN_00c41ee0(*puVar8,puVar8[1]);
        uVar5 = FUN_00c41890(uVar7,param_1 + 0x153);
        uVar7 = FUN_00c41900(uVar7,param_1 + 0x153);
LAB_00c43529:
        FUN_00c44da0(uVar5,uVar7,0xffffffff);
      }
      else {
        uVar5 = FUN_00d814c0(&fStack_24);
        FUN_00c41e50(&iStack_14,uVar5);
        uVar5 = FUN_00c41890(iStack_14,param_1 + 0x153);
        uVar7 = FUN_00c41900(iStack_14,param_1 + 0x153);
        FUN_00c44da0(uVar5,uVar7,piStack_10);
      }
    }
    else {
      if (((*(int *)(*param_3 + 0x5c) != 0) ||
          (((iVar11 = *(int *)(*param_3 + 0x54), iVar11 != 0 && (iVar11 != 1)) && (iVar11 != 2))))
         || (((uVar10 != 2 || (cStack_5 == '\0')) || (cVar3 = FUN_00c401e0(param_1), cVar3 == '\0'))
            )) {
        if ((*(int *)(*param_3 + 0x5c) != 0) ||
           (((((iVar11 = *(int *)(*param_3 + 0x54), iVar11 != 0 && (iVar11 != 1)) && (iVar11 != 2))
             || ((uVar10 != 3 || (cStack_5 == '\0')))) ||
            (cVar3 = FUN_00c401e0(param_1), cVar3 == '\0')))) {
          if (((*(int *)(*param_3 + 0x5c) == 0) && (*(int *)(*param_3 + 0x54) == 0)) &&
             ((cStack_5 != '\0' && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')))) {
            if (DAT_01d686d0 == '\0') {
              puVar8 = (undefined4 *)FUN_00d814c0(&fStack_24);
              piVar9 = (int *)0xffffffff;
              uVar5 = 0xffffffff;
              iStack_14 = FUN_00c41ee0(*puVar8,puVar8[1]);
            }
            else {
              uVar5 = FUN_00d814c0(&fStack_24);
              FUN_00c41e50(&iStack_14,uVar5);
              uVar5 = 0xffffffff;
              piVar9 = piStack_10;
            }
            FUN_00c44da0(iStack_14,uVar5,piVar9);
            if (param_1[0x16e] != -1) {
              FUN_0088ddf0(param_3);
            }
            goto LAB_00c4360a;
          }
          if ((((*(int *)(*param_3 + 0x5c) == 0) && (*(int *)(*param_3 + 0x54) == 0)) &&
              (cStack_5 == '\0')) && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')) {
            if (*(char *)((int)param_1 + 0x5a1) == '\0') {
              FUN_00c449d0(0,param_3,0);
            }
            FUN_008b6b50(param_2);
            return param_2;
          }
          if ((*(int *)(*param_3 + 0x54) == 3) && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0'))
          goto LAB_00c4375d;
          iVar11 = *param_3;
          if ((((*(int *)(iVar11 + 0x5c) == 2) && (*(int *)(iVar11 + 0x54) == 0)) ||
              (*(int *)(iVar11 + 0x54) == 4)) && (*(char *)(param_1 + 0x168) != '\0')) {
            piVar9 = (int *)FUN_00587490(&iStack_14);
            uStack_c = 2;
            if (*piVar9 == 0) goto LAB_00c436c9;
            bVar2 = true;
          }
          else {
LAB_00c436c9:
            bVar2 = false;
          }
          if ((uStack_c & 2) != 0) {
            uStack_c = uStack_c & 0xfffffffd;
            FUN_00550b30();
          }
          goto LAB_00c436e0;
        }
        iVar11 = 0;
        iStack_14 = param_1[0x157];
        piVar9 = (int *)0xffffffff;
        goto LAB_00c4383f;
      }
      if (DAT_01d686d0 == '\0') {
        puVar8 = (undefined4 *)FUN_00d814c0(&fStack_24);
        uVar7 = FUN_00c41ee0(*puVar8,puVar8[1]);
        uVar5 = FUN_00c41820(uVar7,param_1 + 0x153);
        uVar7 = FUN_00c41860(uVar7,param_1 + 0x153);
        goto LAB_00c43529;
      }
      uVar5 = FUN_00d814c0(&fStack_24);
      FUN_00c41e50(&iStack_14,uVar5);
      uVar5 = FUN_00c41820(iStack_14,param_1 + 0x153);
      uVar7 = FUN_00c41860(iStack_14,param_1 + 0x153);
      FUN_00c44da0(uVar5,uVar7,piStack_10);
    }
  }
  else {
    if (((*(int *)(iVar11 + 0x5c) == 0) && (*(int *)(iVar11 + 0x54) == 0)) &&
       ((cStack_5 == '\0' && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')))) {
      if (*(char *)((int)param_1 + 0x5a1) == '\0') {
        FUN_00c449d0(0,param_3,0);
      }
LAB_00c4375d:
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
      return param_2;
    }
    iVar11 = *param_3;
    if ((((*(int *)(iVar11 + 0x5c) == 2) && (*(int *)(iVar11 + 0x54) == 0)) ||
        (*(int *)(iVar11 + 0x54) == 4)) && (*(char *)(param_1 + 0x168) != '\0')) {
      piVar9 = (int *)FUN_00587490(&iStack_14);
      uStack_c = 4;
      if (*piVar9 == 0) goto LAB_00c437cd;
      bVar2 = true;
    }
    else {
LAB_00c437cd:
      bVar2 = false;
    }
    piVar9 = piStack_10;
    if (((uStack_c & 4) != 0) && (uStack_c = uStack_c & 0xfffffffb, piStack_10 != (int *)0x0)) {
      LOCK();
      iVar11 = piStack_10[1] + -1;
      piStack_10[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar11 = *piVar1 + -1;
        *piVar1 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
LAB_00c436e0:
    if (bVar2) {
      if (DAT_01d686d0 == '\0') {
        puVar8 = (undefined4 *)FUN_00d814c0(&fStack_24);
        iStack_14 = FUN_00c41ee0(*puVar8,puVar8[1]);
        iVar11 = param_1[0x170];
        if (iVar11 == -1) {
          iVar11 = param_1[0x16e];
        }
        piVar9 = (int *)0xffffffff;
      }
      else {
        uVar5 = FUN_00d814c0(&fStack_24);
        FUN_00c41e50(&iStack_14,uVar5);
        iVar11 = param_1[0x170];
        piVar9 = piStack_10;
        if (iVar11 == -1) {
          iVar11 = param_1[0x16e];
        }
      }
LAB_00c4383f:
      FUN_00c44da0(iStack_14,iVar11,piVar9);
    }
  }
  uVar10 = uStack_c;
  if ((*(int *)(*param_3 + 0x5c) == 2) && (*(int *)(*param_3 + 0x54) == 0)) {
    piVar9 = (int *)FUN_00587490(&iStack_14);
    uVar10 = uStack_c | 8;
    if (*piVar9 != 0) {
      bVar2 = true;
      goto LAB_00c4387b;
    }
  }
  bVar2 = false;
LAB_00c4387b:
  if (((uVar10 & 8) != 0) && (piStack_10 != (int *)0x0)) {
    LOCK();
    iVar11 = piStack_10[1] + -1;
    piStack_10[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      iVar11 = piStack_10[2] + -1;
      piStack_10[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
  }
  if (bVar2) {
    param_1[0x16c] = 0;
    piVar9 = (int *)param_1[0x16d];
    param_1[0x16d] = 0;
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar1 = piVar9 + 2;
      iVar11 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
    if (param_1[0x170] == param_1[0x16e]) {
      if (DAT_01d686d0 == '\0') {
        iVar11 = -1;
      }
      else {
        iVar11 = param_1[0x125];
      }
      FUN_00c44da0(param_1[0x16e],0xffffffff,iVar11);
    }
  }
  uVar4 = FUN_00c401e0(param_1);
  FUN_00c79d60(&uStack_50,param_3,uVar4);
  param_2[1] = uStack_4c;
  param_2[2] = uStack_48;
  *param_2 = uStack_50;
  param_2[3] = uStack_44;
  param_2[4] = uStack_40;
  return param_2;
}



/* FUNCTION 28275 ; VA 0x00c43950 ; FUN_00c43950 */

undefined4 * FUN_00c43950(undefined4 *param_1,int *param_2)

{
  char cVar1;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809a68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00c45590();
  if (cVar1 == '\0') {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00c790a0(&uStack_24,param_2);
  uStack_8 = 0;
  if ((*(int *)(*param_2 + 0x54) == 9) && (*(int *)(*param_2 + 0x5c) == 2)) {
    FUN_00c449d0(0,param_2,0);
  }
  param_1[1] = uStack_20;
  param_1[2] = uStack_1c;
  *param_1 = uStack_24;
  param_1[3] = uStack_18;
  param_1[4] = uStack_14;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28276 ; VA 0x00c43a20 ; FUN_00c43a20 */

undefined4 * __thiscall FUN_00c43a20(undefined4 param_1,undefined4 *param_2,int *param_3)

{
  char cVar1;
  
  if ((*(int *)(*param_3 + 0xa8) == 0x3ea) && (*(int *)(*param_3 + 0x5c) == 0)) {
    cVar1 = FUN_00c78600();
    if (cVar1 != '\0') {
      cVar1 = FUN_00c401e0(param_1);
      if (cVar1 == '\0') {
        FUN_00c40390();
      }
      else {
        FUN_00c449d0(0,param_3,0);
      }
      *param_2 = 1;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
      return param_2;
    }
  }
  FUN_00c35a30(param_2,param_3);
  return param_2;
}



/* FUNCTION 28277 ; VA 0x00c43ab0 ; FUN_00c43ab0 */

undefined4 * __thiscall FUN_00c43ab0(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  char cVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint *puVar10;
  undefined4 *puVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined uVar14;
  undefined4 ***apppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint *puStack_38;
  uint *puStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint *puStack_24;
  uint *puStack_20;
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809a98;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x548) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00c41a50(param_3);
    *(undefined *)(param_1 + 0x548) = 0;
  }
  FUN_0054ef60(param_1 + 0x54c);
  uStack_8 = 0;
  cVar4 = FUN_00c401e0(param_1);
  FUN_00c35a30(&uStack_40,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar5 = FUN_00c401e0(param_1);
  if (cVar5 == '\0') {
    cVar5 = FUN_00c401e0(param_1);
    if (((((cVar5 == '\0') && (*(int *)(*param_3 + 0x54) == 8)) &&
         (iVar6 = *(int *)(*param_3 + 0x5c), iVar6 != 2)) &&
        ((iVar6 != 4 && (cVar5 = FUN_00c78600(), cVar5 != '\0')))) &&
       (*(int *)(*param_3 + 0xa8) == 0xd)) {
      FUN_00c40390();
    }
    goto LAB_00c43ff6;
  }
  iVar6 = *param_3;
  if (*(int *)(iVar6 + 0x54) == 8) {
    if ((*(int *)(iVar6 + 0x5c) == 2) || (*(int *)(iVar6 + 0x5c) == 4)) {
      if (*(int *)(iVar6 + 0x5c) == 2) {
        cVar5 = FUN_00d81970();
        if (cVar5 == '\0') {
          cVar5 = FUN_00d819d0();
          if (cVar5 == '\0') {
            cVar5 = FUN_00d81960();
            if (cVar5 == '\0') {
              cVar5 = FUN_00d81b10();
              if (cVar5 == '\0') {
                cVar5 = FUN_00d81cd0();
                if (cVar5 == '\0') {
                  if ((DAT_01d6e86c == '\0') && (cVar5 = FUN_00d81270(), cVar5 != '\0')) {
                    uVar14 = *(undefined *)(*param_3 + 0xbc);
                    uVar13 = *(undefined4 *)(*param_3 + 0xa8);
                    goto LAB_00c43fae;
                  }
                  goto LAB_00c43fb7;
                }
                uVar14 = 0x72;
                uVar13 = *(undefined4 *)(*param_3 + 0xa8);
                uVar12 = 7;
              }
              else {
                uVar14 = 0x6c;
                uVar13 = *(undefined4 *)(*param_3 + 0xa8);
                uVar12 = 6;
              }
            }
            else {
              uVar14 = 0;
              uVar13 = *(undefined4 *)(*param_3 + 0xa8);
              uVar12 = 0;
            }
          }
          else {
            uVar14 = 0;
            uVar13 = *(undefined4 *)(*param_3 + 0xa8);
            uVar12 = 1;
          }
        }
        else {
          if (*(char *)(param_1 + 0x5e8) == '\0') goto LAB_00c43fb7;
          uVar14 = 10;
          uVar13 = *(undefined4 *)(*param_3 + 0xa8);
LAB_00c43fae:
          uVar12 = 5;
        }
        FUN_00c42650(uVar12,uVar13,uVar14);
      }
    }
    else {
      cVar5 = FUN_00d81a10();
      if (cVar5 == '\0') {
        cVar5 = FUN_00d81970();
        if (cVar5 == '\0') {
          if (DAT_01d686d0 == '\0') {
LAB_00c43c39:
            cVar5 = FUN_00d81a40();
            if (cVar5 == '\0') {
              cVar5 = FUN_00d819e0();
              if (cVar5 == '\0') {
                cVar5 = FUN_008ff110(0x114);
                if (cVar5 == '\0') {
                  cVar5 = FUN_008ff110(0x113);
                  if (cVar5 == '\0') {
                    cVar5 = FUN_00d81b10();
                    if (cVar5 == '\0') {
                      cVar5 = FUN_00d81cd0();
                      if (cVar5 == '\0') {
                        cVar5 = FUN_00d81990();
                        if (cVar5 == '\0') {
                          cVar5 = FUN_00d819d0();
                          if (cVar5 == '\0') {
                            cVar5 = FUN_00d81960();
                            if (cVar5 == '\0') {
                              cVar5 = FUN_008ff110(0x78);
                              if (cVar5 == '\0') {
                                cVar5 = FUN_008ff110(99);
                                if (cVar5 == '\0') {
                                  cVar5 = FUN_008ff110(0x61);
                                  if (cVar5 == '\0') {
                                    if ((DAT_01d6e86c == '\0') &&
                                       (cVar5 = FUN_00d81270(), cVar5 != '\0')) {
                                      if ((*(int *)(*param_3 + 0xa8) == 0x76) &&
                                         (iVar6 = FUN_008acee0(param_1), iVar6 != 0)) {
                                        FUN_00b82430(&puStack_24);
                                        uStack_8._0_1_ = 2;
                                        puVar10 = puStack_24;
                                        if (puStack_24 != puStack_20) {
                                          do {
                                            uVar9 = FUN_00d816c0();
                                            if ((*puVar10 & uVar9) != 0) {
                                              uStack_8 = CONCAT31(uStack_8._1_3_,1);
                                              if (puStack_24 != (uint *)0x0) {
                                                uVar9 = (int)piStack_1c - (int)puStack_24 &
                                                        0xfffffffc;
                                                puVar10 = puStack_24;
                                                if (0xfff < uVar9) {
                                                  puVar10 = (uint *)puStack_24[-1];
                                                  uVar9 = uVar9 + 0x23;
                                                  if (0x1f < (uint)((int)puStack_24 +
                                                                   (-4 - (int)puVar10))) {
                    /* WARNING: Subroutine does not return */
                                                    FUN_017167a3();
                                                  }
                                                }
                                                FUN_01674ea0(puVar10,uVar9);
                                              }
                                              FUN_00c424f0(4,*(undefined4 *)(*param_3 + 0xa8),0x76,
                                                           param_3);
                                              goto LAB_00c43fb7;
                                            }
                                            puVar10 = puVar10 + 1;
                                          } while (puVar10 != puStack_20);
                                        }
                                        uStack_8 = CONCAT31(uStack_8._1_3_,1);
                                        if (puStack_24 != (uint *)0x0) {
                                          uVar9 = (int)piStack_1c - (int)puStack_24 & 0xfffffffc;
                                          puVar10 = puStack_24;
                                          if (0xfff < uVar9) {
                                            puVar10 = (uint *)puStack_24[-1];
                                            uVar9 = uVar9 + 0x23;
                                            if (0x1f < (uint)((int)puStack_24 + (-4 - (int)puVar10))
                                               ) {
                    /* WARNING: Subroutine does not return */
                                              FUN_017167a3();
                                            }
                                          }
                                          FUN_01674ea0(puVar10,uVar9);
                                        }
                                      }
                                      FUN_00c424f0(5,*(undefined4 *)(*param_3 + 0xa8),
                                                   *(undefined *)(*param_3 + 0xbc),param_3);
                                    }
                                  }
                                  else {
                                    FUN_00c415a0(8,0x61,param_3);
                                  }
                                }
                                else {
                                  FUN_00c415a0(3,99,param_3);
                                }
                              }
                              else {
                                FUN_00c415a0(2,0x78,param_3);
                              }
                            }
                            else {
                              cVar5 = FUN_00d81a70();
                              FUN_00c424f0(0,*(undefined4 *)(*param_3 + 0xa8),cVar5 != '\0',param_3)
                              ;
                            }
                          }
                          else {
                            FUN_00c424f0(1,*(undefined4 *)(*param_3 + 0xa8),0,param_3);
                          }
                        }
                        else {
                          FUN_005542c0(&DAT_018bc9b8,0);
                        }
                      }
                      else {
                        FUN_00c424f0(7,*(undefined4 *)(*param_3 + 0xa8),0x72,param_3);
                      }
                    }
                    else {
                      FUN_00c424f0(6,*(undefined4 *)(*param_3 + 0xa8),0x6c,param_3);
                    }
                  }
                  else {
                    FUN_00c424f0(0xb,*(undefined4 *)(*param_3 + 0xa8),0x72,param_3);
                  }
                }
                else {
                  FUN_00c424f0(0xc,*(undefined4 *)(*param_3 + 0xa8),0x6c,param_3);
                }
              }
              else {
                FUN_00c415a0(10,0x65,param_3);
              }
            }
            else {
              FUN_00c415a0(9,0x68,param_3);
            }
          }
          else {
            cVar5 = FUN_008ff110(0x111);
            if ((cVar5 == '\0') && (cVar5 = FUN_008ff110(0x116), cVar5 == '\0')) {
              if ((DAT_01d686d0 == '\0') ||
                 ((cVar5 = FUN_008ff110(0x112), cVar5 == '\0' &&
                  (cVar5 = FUN_008ff110(0x117), cVar5 == '\0')))) goto LAB_00c43c39;
              FUN_00c415a0(0xe,0x65,param_3);
            }
            else {
              FUN_00c415a0(0xd,0x68,param_3);
            }
          }
        }
        else {
          cVar5 = FUN_00c78600();
          if (cVar5 == '\0') {
            if (*(char *)(param_1 + 0x5e8) == '\0') {
              FUN_00c449d0(1,param_3,0);
            }
            else {
              FUN_00c424f0(5,*(undefined4 *)(*param_3 + 0xa8),10,param_3);
            }
          }
          else {
            FUN_00c449d0(0,param_3,0);
          }
        }
      }
      else {
        FUN_00c449d0(0,param_3,0);
      }
    }
  }
LAB_00c43fb7:
  if (((*(int *)(*param_3 + 0xa8) == 0x130) || (*(int *)(*param_3 + 0xa8) == 0x12f)) &&
     ((*(int *)(param_1 + 0x5e0) == 1 ||
      ((*(int *)(param_1 + 0x5e0) == 2 && (cVar5 = FUN_00554b40(), cVar5 == '\0')))))) {
    *(undefined4 *)(param_1 + 0x5e0) = 0;
  }
LAB_00c43ff6:
  puVar11 = (undefined4 *)(param_1 + 0x54c);
  puVar8 = puVar11;
  if (0xf < *(uint *)(param_1 + 0x560)) {
    puVar8 = (undefined4 *)*puVar11;
  }
  ppppuVar7 = apppuStack_6c;
  if (0xf < uStack_58) {
    ppppuVar7 = (undefined4 ****)apppuStack_6c[0];
  }
  cVar5 = FUN_0055c360(ppppuVar7,uStack_5c,puVar8,*(undefined4 *)(param_1 + 0x55c));
  if (cVar5 == '\0') {
    FUN_0054ef60(puVar11);
    FUN_00fac790();
  }
  if (cVar4 == '\0') {
    uStack_2c = uStack_40;
    uStack_28 = uStack_3c;
    puStack_24 = puStack_38;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[2] = piStack_30[2] + 1;
      UNLOCK();
    }
    puVar8 = &uStack_2c;
    puStack_20 = puStack_34;
    bVar3 = false;
    bVar2 = true;
    piStack_1c = piStack_30;
  }
  else {
    uStack_54 = 1;
    uStack_50 = 0;
    uStack_4c = 0;
    FUN_0060e0c0(auStack_48,param_1);
    puVar8 = &uStack_54;
    bVar3 = true;
    bVar2 = false;
  }
  *param_2 = *puVar8;
  param_2[1] = puVar8[1];
  param_2[2] = puVar8[2];
  param_2[3] = puVar8[3];
  param_2[4] = puVar8[4];
  puVar8[3] = 0;
  puVar8[4] = 0;
  if ((bVar2) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar6 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  if ((bVar3) && (piStack_44 != (int *)0x0)) {
    LOCK();
    iVar6 = piStack_44[2] + -1;
    piStack_44[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piStack_44 + 4))();
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_30 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (0xf < uStack_58) {
    uVar9 = uStack_58 + 1;
    ppppuVar7 = (undefined4 ****)apppuStack_6c[0];
    if (0xfff < uVar9) {
      ppppuVar7 = (undefined4 ****)apppuStack_6c[0][-1];
      uVar9 = uStack_58 + 0x24;
      if (0x1f < (uint)((int)apppuStack_6c[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar9);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28278 ; VA 0x00c441d0 ; FUN_00c441d0 */

undefined4 * __thiscall FUN_00c441d0(int *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  float *pfVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  bool bVar9;
  undefined auStack_90 [16];
  int *piStack_80;
  int *piStack_6c;
  undefined auStack_68 [16];
  int *piStack_58;
  undefined auStack_50 [12];
  int *piStack_44;
  undefined auStack_40 [4];
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  int *piStack_30;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809ab8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  (**(code **)(*param_1 + 0xd4))(auStack_2c);
  uVar4 = FUN_00d5c5d0(auStack_50);
  FUN_00802e80(&fStack_3c,uVar4);
  cVar3 = FUN_00d81cb0();
  if (cVar3 == '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  pfVar5 = (float *)FUN_00d814c0(&uStack_24);
  if ((((*pfVar5 < fStack_3c) || (pfVar5[1] < fStack_38)) || (fStack_34 < *pfVar5)) ||
     ((float)piStack_30 < pfVar5[1])) {
    cStack_11 = '\0';
  }
  else {
    cStack_11 = '\x01';
  }
  iVar2 = *param_3;
  if (DAT_01d686f0 == '\0') {
    if (*(int *)(iVar2 + 0x5c) == 0) {
      if (((*(int *)(iVar2 + 0x54) == 0) && (*(char *)(param_1 + 0x168) != '\0')) &&
         (cStack_11 != '\0')) {
        FUN_00c41a50(param_3);
        goto LAB_00c444de;
      }
      if (((*(int *)(iVar2 + 0x54) == 0) && (cStack_11 == '\0')) &&
         (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')) goto LAB_00c44456;
    }
    if (((*(int *)(*param_3 + 0x54) == 3) && (cStack_11 == '\0')) &&
       (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')) {
      FUN_008b6b50(param_2);
      ExceptionList = pvStack_10;
      return param_2;
    }
    goto LAB_00c444de;
  }
  uVar8 = *(uint *)(iVar2 + 0xb0) & 0x80000003;
  if ((int)uVar8 < 0) {
    uVar8 = (uVar8 - 1 | 0xfffffffc) + 1;
  }
  if (((*(int *)(iVar2 + 0x5c) == 0) && (*(int *)(iVar2 + 0x54) == 0)) &&
     ((*(char *)(param_1 + 0x168) != '\0' &&
      ((cStack_11 != '\0' && (cVar3 = FUN_00c401e0(param_1), cVar3 == '\0')))))) {
    FUN_00c41a50(param_3);
  }
  else if ((*(int *)(*param_3 + 0x5c) == 0) &&
          (((*(int *)(*param_3 + 0x54) == 0 && (cStack_11 == '\0')) &&
           (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')))) {
LAB_00c44456:
    if (*(char *)((int)param_1 + 0x5a1) == '\0') {
      FUN_00c449d0(0,param_3,0);
    }
    goto LAB_00c4446b;
  }
  if (((*(int *)(*param_3 + 0x5c) == 0) &&
      ((((iVar2 = *(int *)(*param_3 + 0x54), iVar2 == 0 || (iVar2 == 1)) || (iVar2 == 2)) &&
       ((uVar8 == 1 && (cStack_11 != '\0')))))) && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')) {
    if (DAT_01d686d0 == '\0') {
      puVar7 = (undefined4 *)FUN_00d814c0(&fStack_34);
      uVar6 = FUN_00c41ee0(*puVar7,puVar7[1]);
      uVar4 = FUN_00c41890(uVar6,param_1 + 0x153);
      uVar6 = FUN_00c41900(uVar6,param_1 + 0x153);
LAB_00c444b5:
      uStack_20 = 0xffffffff;
    }
    else {
      uVar4 = FUN_00d814c0(&fStack_34);
      FUN_00c41e50(&uStack_24,uVar4);
      uVar4 = FUN_00c41890(uStack_24,param_1 + 0x153);
      uVar6 = FUN_00c41900(uStack_24,param_1 + 0x153);
    }
LAB_00c444ba:
    param_1 = piStack_18;
    FUN_00c44da0(uVar4,uVar6,uStack_20);
  }
  else {
    if ((*(int *)(*param_3 + 0x5c) == 0) &&
       (((((iVar2 = *(int *)(*param_3 + 0x54), iVar2 == 0 || (iVar2 == 1)) || (iVar2 == 2)) &&
         ((uVar8 == 2 && (cStack_11 != '\0')))) && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0'))))
    {
      if (DAT_01d686d0 == '\0') {
        puVar7 = (undefined4 *)FUN_00d814c0(&fStack_34);
        uVar6 = FUN_00c41ee0(*puVar7,puVar7[1]);
        uVar4 = FUN_00c41820(uVar6,param_1 + 0x153);
        uVar6 = FUN_00c41860(uVar6,param_1 + 0x153);
        goto LAB_00c444b5;
      }
      uVar4 = FUN_00d814c0(&fStack_34);
      FUN_00c41e50(&uStack_24,uVar4);
      uVar4 = FUN_00c41820(uStack_24,param_1 + 0x153);
      uVar6 = FUN_00c41860(uStack_24,param_1 + 0x153);
      goto LAB_00c444ba;
    }
    if ((*(int *)(*param_3 + 0x5c) == 0) &&
       ((((iVar2 = *(int *)(*param_3 + 0x54), iVar2 == 0 || (iVar2 == 1)) || (iVar2 == 2)) &&
        (((uVar8 == 3 && (cStack_11 != '\0')) && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0'))))))
    {
      FUN_00c44da0(param_1[0x157],0,0xffffffff);
    }
    else if (((*(int *)(*param_3 + 0x5c) == 0) && (*(int *)(*param_3 + 0x54) == 0)) &&
            ((cStack_11 != '\0' && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')))) {
      if (DAT_01d686d0 == '\0') {
        puVar7 = (undefined4 *)FUN_00d814c0(&fStack_34);
        uVar4 = 0xffffffff;
        uVar6 = 0xffffffff;
        uStack_24 = FUN_00c41ee0(*puVar7,puVar7[1]);
      }
      else {
        uVar4 = FUN_00d814c0(&fStack_34);
        FUN_00c41e50(&uStack_24,uVar4);
        uVar6 = 0xffffffff;
        uVar4 = uStack_20;
      }
      FUN_00c44da0(uStack_24,uVar6,uVar4);
      if (param_1[0x16e] != -1) {
        FUN_0088ddf0(param_3);
      }
      FUN_0090cc40(param_2);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  if ((*(int *)(*param_3 + 0x54) == 3) && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')) {
LAB_00c4446b:
    FUN_008b6b50(param_2);
    ExceptionList = pvStack_10;
    return param_2;
  }
LAB_00c444de:
  FUN_00c79d40(auStack_68,param_3);
  uStack_8 = 0;
  if (*(char *)((int)param_1 + 0x5a1) == '\0') {
    cVar3 = FUN_00c401e0(param_1);
    bVar9 = cVar3 == '\0';
    if (bVar9) {
      puVar7 = (undefined4 *)FUN_00c3f200(auStack_68);
    }
    else {
      puVar7 = (undefined4 *)FUN_008bc460(auStack_90,param_1);
    }
    *param_2 = *puVar7;
    param_2[1] = puVar7[1];
    param_2[2] = puVar7[2];
    param_2[3] = 0;
    param_2[4] = 0;
    param_2[3] = puVar7[3];
    param_2[4] = puVar7[4];
    puVar7[3] = 0;
    puVar7[4] = 0;
    if ((bVar9) && (piStack_6c != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_6c[2] + -1;
      piStack_6c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_6c + 4))();
      }
    }
  }
  else {
    bVar9 = cStack_11 == '\0';
    if (bVar9) {
      puVar7 = (undefined4 *)FUN_00c3f200(auStack_68);
    }
    else {
      puVar7 = (undefined4 *)FUN_008bc460(auStack_40,param_1);
    }
    *param_2 = *puVar7;
    param_2[1] = puVar7[1];
    param_2[2] = puVar7[2];
    param_2[3] = 0;
    param_2[4] = 0;
    param_2[3] = puVar7[3];
    param_2[4] = puVar7[4];
    puVar7[3] = 0;
    puVar7[4] = 0;
    piStack_80 = piStack_30;
    if ((bVar9) && (piStack_44 != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_44[2] + -1;
      piStack_44[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_44 + 4))();
        piStack_80 = piStack_30;
      }
    }
  }
  if ((!bVar9) && (piStack_80 != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_80[2] + -1;
    piStack_80[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_80 + 4))();
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_58 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piStack_58 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28279 ; VA 0x00c44820 ; FUN_00c44820 */

undefined4 * __thiscall FUN_00c44820(int *param_1,undefined4 *param_2,int *param_3)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  undefined auStack_10 [11];
  char cStack_5;
  
  if (*(int *)(*param_3 + 0x54) != 7) {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    return param_2;
  }
  *(undefined *)(param_1 + 0x168) = 1;
  pcVar1 = *(code **)(*param_1 + 0x10c);
  uVar5 = FUN_00d814c0(auStack_10);
  cStack_5 = (*pcVar1)(uVar5,0);
  if ((cStack_5 != '\0') && (*(char *)((int)param_1 + 0x341) != '\0')) {
    iVar7 = *param_3;
    iVar6 = param_1[0x16a];
    if ((iVar7 == iVar6) && (*(int *)(iVar7 + 0x5c) == 2)) {
      FUN_0058a2b0();
      FUN_00c41a50(param_3);
    }
    else if ((*(int *)(iVar7 + 0x5c) == 0) && ((iVar6 == 0 || (*(int *)(iVar6 + 0x5c) == 2)))) {
      iVar6 = param_3[1];
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar7 = *param_3;
        iVar6 = param_3[1];
      }
      param_1[0x16a] = iVar7;
      piVar2 = (int *)param_1[0x16b];
      param_1[0x16b] = iVar6;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar7 = piVar2[1] + -1;
        piVar2[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar7 = piVar2[2] + -1;
          piVar2[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    iVar7 = FUN_00b599b0();
    if (iVar7 != 0) {
      cVar3 = FUN_00dd2190(param_3);
      cVar4 = FUN_01083200();
      *(bool *)(param_1 + 0x168) = cVar4 == '\0';
      if (cVar3 != '\0') {
        FUN_0090cc40(param_2);
        return param_2;
      }
    }
  }
  if (DAT_01d686f0 == '\0') {
    if ((((cStack_5 == '\0') && (cVar3 = FUN_00c401e0(param_1), cVar3 != '\0')) &&
        (*(int *)(*param_3 + 0x5c) == 0)) && (*(char *)((int)param_1 + 0x5a1) == '\0')) {
      FUN_00c449d0(0,param_3,0);
    }
    else if ((*param_3 == param_1[0x16a]) && (*(int *)(*param_3 + 0x5c) == 2)) {
      FUN_0058a2b0();
    }
  }
  FUN_00c7a4f0(param_2,param_3);
  return param_2;
}



/* FUNCTION 28280 ; VA 0x00c449d0 ; FUN_00c449d0 */

void __thiscall FUN_00c449d0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  undefined4 uVar4;
  int iVar5;
  byte bVar6;
  
  cVar2 = FUN_00c401e0(param_1);
  if (cVar2 != '\0') {
    iVar5 = param_1;
    if (param_4 != 0) {
      iVar5 = param_4;
    }
    uVar4 = FUN_0097bf90(iVar5);
    iVar5 = FUN_009ba880(uVar4);
    if (iVar5 != 0) {
      bVar3 = FUN_01679ce0();
      bVar6 = 1;
      if ((bVar3 & 0x7f) != 0) {
        bVar6 = bVar3 & 0x7f;
      }
      *(byte *)(iVar5 + 0x224) = -bVar6;
    }
    FUN_0054ef60(param_1 + 0x54c);
    FUN_00fac790();
    FUN_00c44da0(0xffffffff,0xffffffff,0xffffffff);
    *(undefined4 *)(param_1 + 0x5b0) = 0;
    piVar1 = *(int **)(param_1 + 0x5b4);
    *(undefined4 *)(param_1 + 0x5b4) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_00c40130(param_1,0);
    FUN_00fad240();
    if (*(char *)(param_1 + 0x549) != '\0') {
      *(undefined *)(param_1 + 0x549) = 0;
      iVar5 = FUN_00817fa0();
      if (iVar5 != 0) {
        FUN_00d66da0();
      }
    }
    *(undefined4 *)(param_1 + 0x5e0) = 0;
    iVar5 = FUN_008f7870(param_1);
    if (iVar5 != 0) {
      *(undefined *)(iVar5 + 0x344) = 0;
    }
    FUN_00c44ec0(param_2,param_3);
  }
  return;
}



/* FUNCTION 28281 ; VA 0x00c44ae0 ; FUN_00c44ae0 */

void FUN_00c44ae0(undefined4 param_1)

{
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809958;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c449d0(param_1,&uStack_18,0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28282 ; VA 0x00c44b30 ; FUN_00c44b30 */

void __thiscall FUN_00c44b30(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_14 [16];
  
  uVar1 = FUN_00c77710(auStack_14);
  FUN_00c7b030(param_2,uVar1);
  FUN_00faace0(param_2);
  (**(code **)(*(int *)(param_1 + -0x54) + 0x118))(param_2);
  return;
}



/* FUNCTION 28283 ; VA 0x00c44b70 ; FUN_00c44b70 */

void __fastcall FUN_00c44b70(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = 0;
  piVar1 = (int *)param_1[1];
  param_1[1] = 0;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00c44b92. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 28284 ; VA 0x00c44ba0 ; FUN_00c44ba0 */

int __fastcall FUN_00c44ba0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_1c [4];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809ad8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_1);
  uStack_8 = 0;
  uVar3 = *puVar5;
  uVar4 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  iVar6 = FUN_0089be10(uVar3,uVar4);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 28285 ; VA 0x00c44c40 ; FUN_00c44c40 */

void __fastcall FUN_00c44c40(int param_1)

{
  FUN_00a461b0(param_1,param_1 + 0x5f4,param_1 + 0x60c);
  FUN_00fad240();
  return;
}



/* FUNCTION 28286 ; VA 0x00c44c70 ; FUN_00c44c70 */

void __thiscall FUN_00c44c70(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x54a)) {
    *(char *)(param_1 + 0x54a) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28287 ; VA 0x00c44ca0 ; FUN_00c44ca0 */

void __thiscall FUN_00c44ca0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined auStack_24 [12];
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809af8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x100))("CursorPosition");
  auStack_24[0] = 0;
  uStack_8 = 0;
  (**(code **)(param_1[0xd2] + 4))(aiStack_18,auStack_24,0);
  piVar1 = param_1 + 0xdd;
  iVar2 = param_1[0xe1];
  uStack_8 = 0xffffffff;
  if (0xf < (uint)param_1[0xe2]) {
    piVar1 = (int *)*piVar1;
  }
  if (param_2 == -1) {
    iVar2 = -1;
  }
  else if (param_2 < 2) {
    iVar2 = 0;
  }
  else if (param_2 <= iVar2) {
    FUN_01543480(aiStack_18,piVar1,iVar2,param_2 + -1);
    iVar2 = aiStack_18[0];
  }
  if (iVar2 == -1) {
    if (param_1[0x16e] != -1) {
      FUN_00c40130(param_1,0);
    }
  }
  else if (param_1[0x16e] == -1) {
    FUN_00c40130(param_1,param_1);
    FUN_00fab480(0);
  }
  FUN_00c44da0(iVar2,param_1[0x170],0xffffffff);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28288 ; VA 0x00c44da0 ; FUN_00c44da0 */

void __thiscall FUN_00c44da0(int param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined auStack_28 [12];
  undefined auStack_1c [4];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b18;
  pvStack_10 = ExceptionList;
  iStack_14 = *(int *)(param_1 + 0x5b8);
  iStack_18 = *(int *)(param_1 + 0x5c0);
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x5b8) = param_2;
  *(int *)(param_1 + 0x5c0) = param_3;
  if ((param_3 == -1) || (param_2 == -1)) {
    *(undefined4 *)(param_1 + 0x5b0) = 0;
    piVar1 = *(int **)(param_1 + 0x5b4);
    *(undefined4 *)(param_1 + 0x5b4) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (iStack_14 != param_2) {
    FUN_008a4940(&DAT_021355a0);
  }
  if (iStack_18 != param_3) {
    FUN_008a4940(&DAT_021355d8);
  }
  if (param_4 == -1) {
    auStack_28[0] = 0;
    uStack_8 = 0;
    (**(code **)(*(int *)(param_1 + 0x348) + 4))(auStack_1c,auStack_28,0);
    uStack_8 = 0xffffffff;
    auStack_28[0] = 0;
    param_4 = FUN_00d7f080(*(undefined4 *)(param_1 + 0x5b8));
  }
  FUN_00d7f5f0(param_4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28289 ; VA 0x00c44eb0 ; FUN_00c44eb0 */

void __thiscall FUN_00c44eb0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x5a6) = param_2;
  return;
}



/* FUNCTION 28290 ; VA 0x00c44ec0 ; FUN_00c44ec0 */

int __thiscall FUN_00c44ec0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  bool bVar7;
  undefined uVar8;
  undefined auStack_1c [4];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809ad8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x5a4) != '\0') {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x5a4) = 0;
    FUN_00fad240();
  }
  uVar8 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_00c45d20(uVar8);
  iVar5 = *(int *)(param_1 + 0x34);
  iVar4 = param_1;
  if ((iVar5 != 0) && (iVar4 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
    iVar4 = FUN_005c8ac0();
  }
  if ((iVar4 == 0) ||
     (iVar5 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
    iVar5 = 0;
  }
  else {
    iVar5 = FUN_00634d90();
  }
  if (DAT_01d686e0 == '\0') {
    bVar7 = true;
  }
  else {
    bVar7 = *(int *)(param_1 + 0x574) != 0;
  }
  FUN_00fab480(bVar7);
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_009a5dd0(param_2,*param_3,param_3[1]);
  if ((iVar5 != 0) && (iVar4 = FUN_00d5c860(), (char)iVar4 != '\0')) {
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_1);
    uStack_8 = 0;
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    iVar4 = FUN_0089be10(uVar2,uVar3);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar5 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          iVar4 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28291 ; VA 0x00c45060 ; FUN_00c45060 */

void __thiscall FUN_00c45060(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x5a1)) {
    *(char *)(param_1 + 0x5a1) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28292 ; VA 0x00c45090 ; FUN_00c45090 */

void __thiscall FUN_00c45090(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x5e8)) {
    *(char *)(param_1 + 0x5e8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28293 ; VA 0x00c450c0 ; FUN_00c450c0 */

void __thiscall FUN_00c450c0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x5a3) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 28294 ; VA 0x00c450e0 ; FUN_00c450e0 */

void __thiscall FUN_00c450e0(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(*(float *)(param_1 + 0x624)) || NAN(param_2)) ==
        (*(float *)(param_1 + 0x624) == param_2)) ||
      ((NAN(*(float *)(param_1 + 0x628)) || NAN(param_3)) ==
       (*(float *)(param_1 + 0x628) == param_3))) ||
     ((NAN(*(float *)(param_1 + 0x62c)) || NAN(param_4)) == (*(float *)(param_1 + 0x62c) == param_4)
     )) {
    *(float *)(param_1 + 0x624) = param_2;
    *(float *)(param_1 + 0x628) = param_3;
    *(float *)(param_1 + 0x62c) = param_4;
    FUN_008a4940(&DAT_021354c0);
  }
  return;
}



/* FUNCTION 28295 ; VA 0x00c45150 ; FUN_00c45150 */

void __thiscall FUN_00c45150(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar5 = in_stack_00000018;
  piVar6 = param_2;
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar7 = (int *)(param_1 + 0x5f4);
  uStack_8 = 0;
  piVar2 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar2 = param_2;
  }
  piVar3 = piVar7;
  if (0xf < *(uint *)(param_1 + 0x608)) {
    piVar3 = (int *)*piVar7;
  }
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar3,*(undefined4 *)(param_1 + 0x604),piVar2,in_stack_00000014);
  if (cVar1 == '\0') {
    if ((int **)piVar7 != &param_2) {
      piVar2 = (int *)&param_2;
      if (0xf < uVar5) {
        piVar2 = piVar6;
      }
      FUN_005542c0(piVar2,in_stack_00000014);
    }
    FUN_00fad240();
    FUN_008a4940(&DAT_02135488);
    FUN_00a461b0(param_1,piVar7,param_1 + 0x60c);
    FUN_00fad240();
    uVar5 = in_stack_00000018;
    piVar6 = param_2;
  }
  if (0xf < uVar5) {
    uVar4 = uVar5 + 1;
    piVar7 = piVar6;
    if (0xfff < uVar4) {
      piVar7 = (int *)piVar6[-1];
      uVar4 = uVar5 + 0x24;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar7,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28296 ; VA 0x00c45240 ; FUN_00c45240 */

void __thiscall FUN_00c45240(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x5f0)) {
    *(int *)(param_1 + 0x5f0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28297 ; VA 0x00c45270 ; FUN_00c45270 */

void __thiscall FUN_00c45270(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int aiStack_c [2];
  
  piVar2 = (int *)(param_1 + 0x374);
  iVar1 = *(int *)(param_1 + 900);
  if (0xf < *(uint *)(param_1 + 0x388)) {
    piVar2 = (int *)*piVar2;
  }
  if (param_2 == -1) {
    iVar1 = -1;
  }
  else if (param_2 < 2) {
    iVar1 = 0;
  }
  else if (param_2 <= iVar1) {
    FUN_01543480(aiStack_c,piVar2,iVar1,param_2 + -1);
    iVar1 = aiStack_c[0];
  }
  FUN_00c44da0(*(undefined4 *)(param_1 + 0x5b8),iVar1,0xffffffff);
  return;
}



/* FUNCTION 28298 ; VA 0x00c452e0 ; FUN_00c452e0 */

void __thiscall FUN_00c452e0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x5a2) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 28299 ; VA 0x00c45300 ; FUN_00c45300 */

void __thiscall FUN_00c45300(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x5a5) != param_2) {
    *(char *)(param_1 + 0x5a5) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28300 ; VA 0x00c45330 ; FUN_00c45330 */

void __thiscall FUN_00c45330(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x5ec)) {
    *(int *)(param_1 + 0x5ec) = param_2;
    FUN_00fad240();
    FUN_008a4940(&DAT_02135648);
  }
  return;
}



/* FUNCTION 28301 ; VA 0x00c45360 ; FUN_00c45360 */

void __thiscall FUN_00c45360(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00896cc0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28302 ; VA 0x00c453b0 ; FUN_00c453b0 */

void __thiscall FUN_00c453b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00c456c0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28303 ; VA 0x00c45400 ; FUN_00c45400 */

void __thiscall FUN_00c45400(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c45750();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28304 ; VA 0x00c45450 ; FUN_00c45450 */

void __thiscall FUN_00c45450(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c45800();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28305 ; VA 0x00c454a0 ; FUN_00c454a0 */

void __thiscall FUN_00c454a0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00c458b0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28306 ; VA 0x00c454f0 ; FUN_00c454f0 */

void __thiscall FUN_00c454f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00c45940();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28307 ; VA 0x00c45540 ; FUN_00c45540 */

void __thiscall FUN_00c45540(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00c459d0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28308 ; VA 0x00c45590 ; FUN_00c45590 */

uint __fastcall FUN_00c45590(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  uint3 uVar6;
  uint uVar5;
  undefined auStack_10 [4];
  int *piStack_c;
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iVar4 != 0) && (iVar1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      iVar1 = FUN_005c8ac0();
    }
    if ((iVar1 != 0) &&
       (iVar4 = *(int *)(iVar1 + 0xc), iVar1 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
      uVar2 = FUN_00560f40();
      piStack_8 = (int *)FUN_008aa140(uVar2);
      if (*piStack_8 == 0) {
        uVar2 = FUN_008aa950();
        piVar3 = (int *)FUN_008a9ba0(auStack_10,uVar2);
        iVar4 = *piVar3;
        iVar1 = piVar3[1];
        *piVar3 = 0;
        piVar3[1] = 0;
        *piStack_8 = iVar4;
        piVar3 = (int *)piStack_8[1];
        piStack_8[1] = iVar1;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        if (piStack_c != (int *)0x0) {
          LOCK();
          iVar4 = piStack_c[1] + -1;
          piStack_c[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_c)();
            LOCK();
            piVar3 = piStack_c + 2;
            iVar4 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piStack_c + 4))();
            }
          }
        }
      }
      iVar4 = *piStack_8;
      goto LAB_00c45694;
    }
  }
  iVar4 = 0;
LAB_00c45694:
  uVar6 = (uint3)((uint)iVar4 >> 8);
  if (iVar4 == *(int *)(param_1 + 0x34)) {
    return (uint)uVar6 << 8;
  }
  if (*(int *)(param_1 + 0x34) == 0) {
    return (uint)uVar6 << 8 ^ 1;
  }
  uVar5 = FUN_00620ec0(iVar4);
  return uVar5 ^ 1;
}



/* FUNCTION 28309 ; VA 0x00c456c0 ; FUN_00c456c0 */

undefined * FUN_00c456c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b3c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efca74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efca74);
    if (DAT_01efca74 == -1) {
      uStack_8 = 0;
      FUN_00d28600();
      FUN_016f3654(&LAB_01894bc0);
      FUN_016f37bf(&DAT_01efca74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efca10;
}



/* FUNCTION 28310 ; VA 0x00c45750 ; FUN_00c45750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45750(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc86c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efc86c);
    if (DAT_01efc86c == -1) {
      uStack_8 = 0;
      FUN_009ca470("ReturnKeyType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efc808 = RBX::Reflection::EnumDesc<enum_RBX::TextBox::ReturnKeyType>::vftable;
      FUN_009caf20(&DAT_01d68738,6);
      FUN_016f3654(&LAB_01894be0);
      FUN_016f37bf(&DAT_01efc86c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc808;
}



/* FUNCTION 28311 ; VA 0x00c45800 ; FUN_00c45800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45800(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc8d4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efc8d4);
    if (DAT_01efc8d4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TextInputType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efc870 = RBX::Reflection::EnumDesc<enum_RBX::TextBox::TextInputType>::vftable;
      FUN_009caf20(&DAT_01d686f8,8);
      FUN_016f3654(&LAB_01894c00);
      FUN_016f37bf(&DAT_01efc8d4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc870;
}



/* FUNCTION 28312 ; VA 0x00c458b0 ; FUN_00c458b0 */

undefined * FUN_00c458b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b9c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc93c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efc93c);
    if (DAT_01efc93c == -1) {
      uStack_8 = 0;
      FUN_00d28660();
      FUN_016f3654(&LAB_01894c20);
      FUN_016f37bf(&DAT_01efc93c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc8d8;
}



/* FUNCTION 28313 ; VA 0x00c45940 ; FUN_00c45940 */

undefined * FUN_00c45940(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809bbc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efca0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efca0c);
    if (DAT_01efca0c == -1) {
      uStack_8 = 0;
      FUN_00d286c0();
      FUN_016f3654(&LAB_01894c40);
      FUN_016f37bf(&DAT_01efca0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc9a8;
}



/* FUNCTION 28314 ; VA 0x00c459d0 ; FUN_00c459d0 */

undefined * FUN_00c459d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809bdc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc9a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efc9a4);
    if (DAT_01efc9a4 == -1) {
      uStack_8 = 0;
      FUN_00d28720();
      FUN_016f3654(&LAB_01894c60);
      FUN_016f37bf(&DAT_01efc9a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc940;
}



/* FUNCTION 28315 ; VA 0x00c45a60 ; FUN_00c45a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45a60(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efca84) {
    FUN_016f3809(&DAT_01efca84);
    if (DAT_01efca84 == -1) {
      _DAT_01efca78 = FUN_005c65e0;
      _DAT_01efca7c = FUN_005c65e0;
      _DAT_01efca80 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efca84);
    }
  }
  return &DAT_01efca78;
}



/* FUNCTION 28316 ; VA 0x00c45ad0 ; FUN_00c45ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45ad0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efcac4) {
    FUN_016f3809(&DAT_01efcac4);
    if (DAT_01efcac4 == -1) {
      _DAT_01efcab8 = FUN_005c65e0;
      _DAT_01efcabc = FUN_005c65e0;
      _DAT_01efcac0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efcac4);
    }
  }
  return &DAT_01efcab8;
}



/* FUNCTION 28317 ; VA 0x00c45b40 ; FUN_00c45b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45b40(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efcad4) {
    FUN_016f3809(&DAT_01efcad4);
    if (DAT_01efcad4 == -1) {
      _DAT_01efcac8 = FUN_005c65e0;
      _DAT_01efcacc = FUN_005c65e0;
      _DAT_01efcad0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efcad4);
    }
  }
  return &DAT_01efcac8;
}



/* FUNCTION 28318 ; VA 0x00c45bb0 ; FUN_00c45bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45bb0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efcab4) {
    FUN_016f3809(&DAT_01efcab4);
    if (DAT_01efcab4 == -1) {
      _DAT_01efcaa8 = FUN_005c65e0;
      _DAT_01efcaac = FUN_005c65e0;
      _DAT_01efcab0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efcab4);
    }
  }
  return &DAT_01efcaa8;
}



/* FUNCTION 28319 ; VA 0x00c45c20 ; FUN_00c45c20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45c20(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efca94) {
    FUN_016f3809(&DAT_01efca94);
    if (DAT_01efca94 == -1) {
      _DAT_01efca88 = FUN_005c65e0;
      _DAT_01efca8c = FUN_005c65e0;
      _DAT_01efca90 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efca94);
    }
  }
  return &DAT_01efca88;
}



/* FUNCTION 28320 ; VA 0x00c45c90 ; FUN_00c45c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c45c90(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efcaa4) {
    FUN_016f3809(&DAT_01efcaa4);
    if (DAT_01efcaa4 == -1) {
      _DAT_01efca98 = FUN_005c65e0;
      _DAT_01efca9c = FUN_005c65e0;
      _DAT_01efcaa0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efcaa4);
    }
  }
  return &DAT_01efca98;
}



/* FUNCTION 28321 ; VA 0x00c45d00 ; FUN_00c45d00 */

undefined __fastcall FUN_00c45d00(int param_1)

{
  if ((*(int *)(param_1 + 0x5b8) != -1) && (*(int *)(param_1 + 0x5c0) != -1)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 28322 ; VA 0x00c45d20 ; FUN_00c45d20 */

void __thiscall FUN_00c45d20(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_ffffffb8;
  undefined4 in_stack_ffffffbc;
  undefined4 in_stack_ffffffc0;
  undefined4 in_stack_ffffffc4;
  undefined4 in_stack_ffffffc8;
  undefined4 uVar7;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01809c00;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((DAT_01d686d8 != '\0') && (ExceptionList = &pvStack_10, in_stack_00000014 != 0)) {
    uVar7 = 0xc45d5b;
    ExceptionList = &pvStack_10;
    FUN_00c41790();
    FUN_0054ef60(param_1 + 0x54c);
    FUN_00fac790(in_stack_ffffffb8,in_stack_ffffffbc,in_stack_ffffffc0,in_stack_ffffffc4,
                 in_stack_ffffffc8,uVar7);
  }
  piVar5 = (int *)(param_1 + 0x57c);
  if ((undefined4 **)piVar5 != &param_2) {
    puVar1 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar1 = param_2;
    }
    FUN_005542c0(puVar1,in_stack_00000014);
  }
  *(undefined4 *)(param_1 + 0x5bc) = in_stack_0000001c;
  piVar2 = (int *)(param_1 + 0x374);
  if ((int *)(param_1 + 0x564) != piVar2) {
    if (0xf < *(uint *)(param_1 + 0x388)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_005542c0(piVar2,*(undefined4 *)(param_1 + 900));
  }
  if (*(int *)(param_1 + 0x5b8) != -1) {
    if (0xf < *(uint *)(param_1 + 0x590)) {
      piVar5 = (int *)*piVar5;
    }
    FUN_00585d40(*(int *)(param_1 + 0x5b8),piVar5,*(undefined4 *)(param_1 + 0x58c));
  }
  FUN_00fad240();
  auStack_24[0] = 0;
  iStack_8._0_1_ = 1;
  (**(code **)(*(int *)(param_1 + 0x348) + 4))(&uStack_18,auStack_24,0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016830f0(&uStack_18);
  if (*(char *)(param_1 + 0x549) != '\x01') {
    *(undefined *)(param_1 + 0x549) = 1;
    iVar3 = FUN_00817fa0();
    if (iVar3 != 0) {
      FUN_00d66da0();
    }
  }
  *(undefined4 *)(param_1 + 0x598) = uStack_18;
  *(undefined4 *)(param_1 + 0x59c) = uStack_14;
  iVar3 = FUN_00817fa0();
  if (iVar3 != 0) {
    FUN_00d66da0();
  }
  iVar6 = *(int *)(param_1 + 0x5b8) + *(int *)(param_1 + 0x5bc);
  iVar3 = FUN_00d7f1a0(iVar6);
  if (iVar3 == iVar6) {
    uVar7 = FUN_00d7f080(iVar6 + 1);
    FUN_00d7f5f0(uVar7);
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar1 = param_2;
    if (0xfff < uVar4) {
      puVar1 = (undefined4 *)param_2[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28323 ; VA 0x00c45ee0 ; FUN_00c45ee0 */

void __fastcall FUN_00c45ee0(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x5a4) == '\0') {
    if (*(int *)(param_1 + 0x574) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00d7fae0(param_1 + 0x564);
      goto LAB_00c45fde;
    }
    ExceptionList = &pvStack_10;
    FUN_00d7fae0(param_1 + 0x60c);
  }
  else {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00d7fae0(auStack_28);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
LAB_00c45fde:
    if (*(int *)(param_1 + 0x5ec) == 5) {
      uVar1 = 1;
      goto LAB_00c45f9a;
    }
  }
  uVar1 = 0;
LAB_00c45f9a:
  FUN_00d7f680(uVar1);
  FUN_00d7f660(0);
  FUN_00d7fb70(*(int *)(param_1 + 0x400) == 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28324 ; VA 0x00c46000 ; FUN_00c46000 */

void __fastcall FUN_00c46000(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  if (*(int *)(param_1 + 0x574) == 0) {
    uStack_14 = *(undefined4 *)(param_1 + 0x624);
    uStack_10 = *(undefined4 *)(param_1 + 0x628);
    uVar4 = *(undefined4 *)(param_1 + 0x62c);
  }
  else {
    uStack_14 = *(undefined4 *)(param_1 + 0x3c8);
    uStack_10 = *(undefined4 *)(param_1 + 0x3cc);
    uVar4 = *(undefined4 *)(param_1 + 0x3d0);
  }
  FUN_00d7f550(uStack_14,uStack_10,uVar4,DAT_018ce2f8 - *(float *)(param_1 + 0x3d4));
  FUN_00d7f780(*(undefined4 *)(param_1 + 0x3d8),*(undefined4 *)(param_1 + 0x3dc),
               *(undefined4 *)(param_1 + 0x3e0),DAT_018ce2f8 - *(float *)(param_1 + 0x3e4));
  iVar3 = *(int *)(param_1 + 0x5bc) + *(int *)(param_1 + 0x5b8);
  if (*(int *)(param_1 + 0x5bc) == -1) {
    iVar3 = *(int *)(param_1 + 0x5b8);
  }
  cVar1 = FUN_00c401e0(param_1);
  if ((cVar1 == '\0') || (*(char *)(param_1 + 0x5a4) != '\0')) {
    iVar2 = -1;
  }
  else {
    iVar2 = -1;
    if (*(char *)(param_1 + 0x549) != '\0') {
      iVar2 = iVar3;
    }
  }
  FUN_00d7f5d0(iVar2);
  iVar3 = *(int *)(param_1 + 0x5b8);
  if ((iVar3 != -1) && (iVar2 = *(int *)(param_1 + 0x5c0), iVar2 != -1)) {
    if (iVar3 <= iVar2) {
      iVar2 = iVar3;
    }
    FUN_00d7faa0(iVar2);
    iVar3 = *(int *)(param_1 + 0x5c0);
    if (*(int *)(param_1 + 0x5c0) <= *(int *)(param_1 + 0x5b8)) {
      iVar3 = *(int *)(param_1 + 0x5b8);
    }
    FUN_00d7fa80(iVar3);
    return;
  }
  FUN_00d7faa0(0xffffffff);
  FUN_00d7fa80(0xffffffff);
  return;
}



/* FUNCTION 28325 ; VA 0x00c46180 ; FUN_00c46180 */

int * __thiscall
FUN_00c46180(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808e5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c46280();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Tool,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const_(__thiscall_RBX::Tool::*)(void)const_,void_(__thiscall_RBX::Tool::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Tool,class_G3D::Vector3>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Tool,class_G3D::Vector3>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28326 ; VA 0x00c46280 ; FUN_00c46280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c46280(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809c30;
  pvStack_10 = ExceptionList;
  if (DAT_01efcae0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efccf8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efccf8);
      if (DAT_01efccf8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00bd36f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_0195e060,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efccf0 = RBX::Creator<class_RBX::Tool>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efcae8,&DAT_01efccf0);
        FUN_016f3654(FUN_01894f80);
        FUN_016f37bf(&DAT_01efccf8);
      }
    }
    DAT_01efcae0 = &DAT_01efcae8;
  }
  ExceptionList = pvStack_10;
  return DAT_01efcae0;
}



/* FUNCTION 28327 ; VA 0x00c46380 ; FUN_00c46380 */

int __thiscall FUN_00c46380(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809c40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Mouse*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28328 ; VA 0x00c46452 ; Catch_All@00c46452 */

void Catch_All_00c46452(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28329 ; VA 0x00c46470 ; FUN_00c46470 */

int __thiscall FUN_00c46470(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809c50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Tool*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28330 ; VA 0x00c46542 ; Catch_All@00c46542 */

void Catch_All_00c46542(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28331 ; VA 0x00c46560 ; FUN_00c46560 */

int __thiscall FUN_00c46560(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809c60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ToolMouseCommand*,class_RBX::Creatable<class_RBX::MouseCommand>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0x20) == 0 || (*(int *)(*(int *)(param_2 + 0x20) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 0x1c) = param_2;
    piVar3 = *(int **)(param_2 + 0x20);
    *(int **)(param_2 + 0x20) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28332 ; VA 0x00c46632 ; Catch_All@00c46632 */

void Catch_All_00c46632(void)

{
  int unaff_EBP;
  
  FUN_008af4d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28333 ; VA 0x00c46650 ; FUN_00c46650 */

void __thiscall FUN_00c46650(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_c = param_4;
  uStack_10 = param_3;
  puStack_8 = param_1;
  cVar4 = FUN_00585a40(&uStack_14);
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_10;
    param_1[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = false;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar5 = &PTR_FUN_0196ade4;
  if (!bVar3) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_8 = ppuVar5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 28334 ; VA 0x00c46760 ; FUN_00c46760 */

undefined4 * FUN_00c46760(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809cdb;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 2;
  uStack_30 = uVar4;
  puStack_20 = (undefined4 *)FUN_01674e20(0x20);
  if (puStack_20 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puStack_20 = 0;
    puStack_20[1] = 1;
    puStack_20[2] = FUN_00922c30;
    puStack_20[3] = FUN_0068b170;
    puStack_20[4] = 0;
    puStack_20[5] = iStack_14;
    puStack_20[6] = 0;
    puStack_20[7] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar6 = (int *)(param_2[1] + 4);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    puStack_20[6] = *param_2;
    puStack_20[7] = param_2[1];
    puVar7 = puStack_20;
  }
  FUN_016797d0(puVar7);
  *param_1 = puVar7;
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_1c = 2;
  uStack_8 = 3;
  FUN_01675290(uVar4);
  iVar3 = iStack_14;
  uStack_1c = 1;
  if (*(char *)(iStack_14 + 4) != '\0') {
    iVar1 = *(int *)(iStack_14 + 0xc);
    uStack_18 = 0;
    iStack_14 = 0;
    if (iVar1 != 0) {
      piVar6 = (int *)(iVar1 + 4);
      iVar1 = *(int *)(iVar1 + 4);
      while (iVar1 != 0) {
        LOCK();
        iVar5 = *piVar6;
        if (iVar1 == iVar5) {
          *piVar6 = iVar1 + 1;
          iVar5 = iVar1;
        }
        UNLOCK();
        if (iVar5 == iVar1) {
          uStack_18 = *(undefined4 *)(iVar3 + 8);
          iStack_14 = *(undefined4 *)(iVar3 + 0xc);
          break;
        }
        iVar1 = *piVar6;
      }
    }
    uStack_8 = 4;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 5;
    pcVar2 = *(code **)(*(int *)*param_2 + 4);
    puStack_20 = (undefined4 *)uVar4;
    uStack_100 = FUN_0088cdc0();
    uStack_f8 = uStack_18;
    uStack_fc = 0;
    uStack_f4 = iStack_14;
    uStack_18 = 0;
    iStack_14 = 0;
    uStack_fc = FUN_006309e0();
    uStack_8._0_1_ = 6;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    FUN_00687980(&uStack_100,&uStack_30,param_1);
    uStack_8._0_1_ = 7;
    (*pcVar2)(&uStack_2c);
    uStack_8._0_1_ = 8;
    FUN_00577b20();
    uStack_8._0_1_ = 5;
    FUN_016f32d1(&uStack_100,0xd0,1,FUN_0056e5b0);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_01675290(uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28335 ; VA 0x00c469a0 ; FUN_00c469a0 */

undefined4 FUN_00c469a0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined **appuStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined **ppuStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809d18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuStack_40 = (undefined **)0x0;
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  cVar4 = FUN_0055c750(param_2,param_3,&uStack_38);
  ppuStack_40 = &PTR_FUN_0196ae28;
  if (cVar4 == '\0') {
    ppuStack_40 = (undefined **)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    ppuStack_14 = ppuStack_40;
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_14 = ppuStack_40;
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  appuStack_68[0] = (undefined **)0x0;
  uVar2 = *(undefined4 *)(iStack_18 + 4);
  ppuStack_14 = (undefined **)uVar2;
  if (ppuStack_40 != (undefined **)0x0) {
    appuStack_68[0] = ppuStack_40;
    if (((uint)ppuStack_40 & 1) == 0) {
      (**(code **)((uint)ppuStack_40 & 0xfffffffe))(&uStack_38,&uStack_60,0);
    }
    else {
      uStack_60 = uStack_38;
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
    }
  }
  uStack_8._0_1_ = 2;
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar2);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_48 = *puVar5;
  uStack_44 = puVar5[1];
  uStack_8._0_1_ = 3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_00b09010();
  uStack_8._0_1_ = 4;
  FUN_0099e760(param_1,appuStack_68);
  FUN_009a4a10();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (ppuStack_40 != (undefined **)0x0) {
    if ((((uint)ppuStack_40 & 1) == 0) &&
       (*(code **)((uint)ppuStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)ppuStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
    }
    ppuStack_40 = (undefined **)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28336 ; VA 0x00c46be0 ; FUN_00c46be0 */

undefined4 * FUN_00c46be0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809d63;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e88940();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e88c40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c46380(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28337 ; VA 0x00c46ca0 ; FUN_00c46ca0 */

undefined4 * FUN_00c46ca0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809da3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c46280();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x1c8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c47140();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c46470(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28338 ; VA 0x00c46d60 ; FUN_00c46d60 */

undefined4 * FUN_00c46d60(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_01809dd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8 = 1;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_01083de0(*param_2,*param_3);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c46560(uVar2,param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28339 ; VA 0x00c46df0 ; FUN_00c46df0 */

int * FUN_00c46df0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00c39bb0(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 28340 ; VA 0x00c46ee0 ; FUN_00c46ee0 */

void FUN_00c46ee0(undefined4 param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  
  FUN_0056f520(0);
  uVar2 = FUN_00605c00();
  FUN_00557fc0(uVar2);
  FUN_00c48420(param_1);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 28341 ; VA 0x00c46f20 ; FUN_00c46f20 */

void * __thiscall FUN_00c46f20(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvVar4;
  void *pvVar5;
  int iVar6;
  int iVar7;
  void *pvVar8;
  int *piVar9;
  int *piVar10;
  undefined4 *puVar11;
  int *piVar12;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_01809e00;
  puVar11 = *(undefined4 **)(param_1 + 0x2c);
  pvVar8 = ExceptionList;
  if (puVar11 != (undefined4 *)0x0) {
    piVar9 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar9 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
      piVar9 = *(int **)(param_1 + 0x30);
      puVar11 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar2 = (int *)puVar11[1];
    piVar12 = (int *)*puVar11;
    iStack_8 = 0;
    pvVar8 = pvStack_10;
    for (; piVar12 != piVar2; piVar12 = piVar12 + 2) {
      piVar10 = (int *)piVar12[1];
      iVar3 = param_2[1];
      pvVar4 = (void *)*param_2;
      if (piVar10 != (int *)0x0) {
        LOCK();
        piVar10[1] = piVar10[1] + 1;
        UNLOCK();
        piVar10 = (int *)piVar12[1];
      }
      pvVar5 = (void *)*piVar12;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      pvVar8 = pvVar5;
      if (pvVar5 != (void *)0x0) {
        iVar6 = *(int *)((int)pvVar5 + 0xc);
        iVar7 = FUN_00c46280();
        pvVar8 = (void *)(uint)*(ushort *)(iVar7 + 0x1da);
        if (((void *)((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) <= pvVar8
            ) && (pvVar5 != pvVar4)) {
          pvVar8 = (void *)FUN_008a65e0(iVar3,0);
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar10 != (int *)0x0) {
        LOCK();
        piVar1 = piVar10 + 1;
        iVar3 = *piVar1;
        pvVar8 = (void *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar10)();
          LOCK();
          piVar1 = piVar10 + 2;
          iVar3 = *piVar1;
          pvVar8 = (void *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            pvVar8 = (void *)(**(code **)(*piVar10 + 4))();
          }
        }
      }
    }
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar2 = piVar9 + 1;
      iVar3 = *piVar2;
      pvVar8 = (void *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        piVar2 = piVar9 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        pvVar8 = (void *)(iVar3 + -1);
        if (pvVar8 == (void *)0x0) {
          pvVar8 = (void *)(**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar8;
}



/* FUNCTION 28342 ; VA 0x00c47060 ; FUN_00c47060 */

undefined4 * __thiscall
FUN_00c47060(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c46280();
  FUN_009cb970(uVar1,param_3,param_4,uStack_18,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Tool,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Tool::*>
             ::vftable;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  param_1[0xe] = param_8;
  param_1[0xf] = param_7;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Tool,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Tool::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28343 ; VA 0x00c47140 ; FUN_00c47140 */

undefined4 * __fastcall FUN_00c47140(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809f1e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0xf4);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::BackpackItem,class_RBX::Instance>::vftable;
  uVar1 = FUN_00bd36f0();
  param_1[3] = uVar1;
  param_1[0x19] = 0;
  param_1[0x1a] = 0xf;
  *(undefined *)(param_1 + 0x15) = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0xf;
  *(undefined *)(param_1 + 0x1b) = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x25] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0xf;
  *(undefined *)(param_1 + 0x26) = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0xf;
  *(undefined *)(param_1 + 0x2c) = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0xf;
  *(undefined *)(param_1 + 0x32) = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::Tool,class_RBX::BackpackItem>::vftable;
  uVar1 = FUN_00c46280();
  param_1[3] = uVar1;
  param_1[0x3d] = RBX::IAdornable::vftable;
  param_1[0x3e] = 0xffffffff;
  param_1[0x3f] = 0xffffffff;
  param_1[0x40] = 0xffffffff;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = RBX::IHasLocation::vftable;
  *param_1 = RBX::Tool::vftable;
  param_1[0x3d] = RBX::Tool::vftable;
  param_1[0x44] = RBX::Tool::vftable;
  param_1[0x45] = 0;
  param_1[0x46] = 0x3f800000;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0x3f800000;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0x3f800000;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  *(undefined2 *)(param_1 + 0x52) = 0x101;
  *(undefined *)((int)param_1 + 0x14a) = 1;
  param_1[0x57] = 0;
  param_1[0x58] = 0xf;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  *(undefined *)(param_1 + 0x53) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  *(undefined2 *)(param_1 + 0x5d) = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x69] = 0;
  *(undefined *)(param_1 + 0x6a) = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  uStack_8._0_1_ = 0x13;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0(&DAT_0195e060,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28344 ; VA 0x00c47530 ; FUN_00c47530 */

void __fastcall FUN_00c47530(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Tool>::vftable;
  uVar1 = FUN_00c46280(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28345 ; VA 0x00c47570 ; FUN_00c47570 */

void __fastcall FUN_00c47570(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Tool::vftable;
  param_1[0x3d] = RBX::Tool::vftable;
  param_1[0x44] = RBX::Tool::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = (int *)param_1[0x6c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_016790b0();
  piVar2 = (int *)param_1[0x68];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x66];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[99];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x62];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x61];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0x60];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar4 = param_1[0x5f];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar4 = param_1[0x5e];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar2 = (int *)param_1[0x5c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x5a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uVar3 = param_1[0x58];
  if (0xf < uVar3) {
    iVar4 = param_1[0x53];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x57] = 0;
  param_1[0x58] = 0xf;
  *(undefined *)(param_1 + 0x53) = 0;
  param_1[0x44] = RBX::IHasLocation::vftable;
  FUN_0115a710();
  FUN_00bd4320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28346 ; VA 0x00c47860 ; FUN_00c47860 */

void __fastcall FUN_00c47860(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_016790b0();
  return;
}



/* FUNCTION 28347 ; VA 0x00c47890 ; FUN_00c47890 */

void FUN_00c47890(void)

{
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00550130("Don\'t use Event.fireEvent for equipped signal!");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 28348 ; VA 0x00c478ce ; FUN_00c478ce */

void FUN_00c478ce(void)

{
  FUN_00c478e0();
  return;
}



/* FUNCTION 28349 ; VA 0x00c478e0 ; FUN_00c478e0 */

undefined4 __thiscall FUN_00c478e0(undefined4 param_1,byte param_2)

{
  FUN_00c47570();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c8);
  }
  return param_1;
}



/* FUNCTION 28350 ; VA 0x00c47910 ; FUN_00c47910 */

void __thiscall FUN_00c47910(int param_1,char param_2)

{
  if ((param_2 != '\0') || (*(char *)(param_1 + 0x174) == '\0')) {
    if (DAT_01ee41ed != '\0') {
      FUN_016774b0(DAT_01ee41ed,"Tool::activate",0);
    }
    FUN_00c48390(param_1);
  }
  return;
}



/* FUNCTION 28351 ; VA 0x00c47960 ; FUN_00c47960 */

undefined4 FUN_00c47960(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  
  if (param_1 != 0) {
    iVar1 = FUN_009ba880(param_1);
    if (iVar1 != 0) {
      piVar2 = (int *)FUN_008ad100();
      if (piVar2 != (int *)0x0) {
        iVar1 = piVar2[3];
        iVar3 = FUN_00c46280();
        if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da)) {
                    /* WARNING: Could not recover jumptable at 0x00c479b6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          uVar4 = (**(code **)(*piVar2 + 0xb4))();
          return uVar4;
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 28352 ; VA 0x00c479c0 ; FUN_00c479c0 */

undefined4 FUN_00c479c0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009ba880(param_1);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return 2;
  }
  iVar2 = FUN_009b7250();
  if (iVar2 == 0) {
    ExceptionList = pvStack_10;
    return 3;
  }
  if (*(int *)(iVar1 + 0x228) == 0) {
    iVar1 = FUN_009b6d20();
    if (iVar1 == 0) {
      ExceptionList = pvStack_10;
      return 4;
    }
    iVar1 = FUN_009b6d60();
  }
  else {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("RightHand",9);
    uStack_8 = 0;
    uVar3 = FUN_008a1240(auStack_28);
    iVar1 = FUN_006e16a0(uVar3);
    FUN_005507b0();
  }
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return 4;
  }
  ExceptionList = pvStack_10;
  return 5;
}



/* FUNCTION 28353 ; VA 0x00c47ac0 ; FUN_00c47ac0 */

undefined4 __fastcall FUN_00c47ac0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = FUN_00c48580();
  if ((iVar2 != 0) || (*(char *)(param_1 + 0x14a) == '\0')) {
    cVar1 = FUN_008b0500(param_1);
    if (cVar1 != '\0') {
      uVar3 = FUN_00c479c0(*(undefined4 *)(param_1 + 0x34));
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 28354 ; VA 0x00c47b00 ; FUN_00c47b00 */

undefined4 * FUN_00c47b00(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_0180a030;
  uStack_8 = 0;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_3;
    piStack_14 = param_4;
    uStack_8 = 1;
    FUN_00c46760(param_1,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28355 ; VA 0x00c47be0 ; FUN_00c47be0 */

int __fastcall FUN_00c47be0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  iVar4 = FUN_00c48580();
  if (iVar4 == 0) {
    iVar4 = FUN_01679490();
  }
  else {
    FUN_008a4100();
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_24,param_1);
    uStack_8 = 0;
    uVar6 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    uVar6 = FUN_00c469a0(&iStack_18,uVar6,uVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar4 = FUN_01679300(uVar6);
    if ((char)iVar4 != '\0') {
      FUN_01679490();
      iVar4 = FUN_016791c0(uVar6);
    }
    if (iStack_18 != 0) {
      piVar1 = (int *)(iStack_18 + 4);
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      iVar4 = iVar4 + -1;
      if (iVar4 == 0) {
        iVar4 = FUN_01674ea0(iStack_18);
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piStack_20 + 4))();
          ExceptionList = pvStack_10;
          return iVar4;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28356 ; VA 0x00c47d00 ; FUN_00c47d00 */

undefined4 * FUN_00c47d00(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c46ca0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28357 ; VA 0x00c47d70 ; FUN_00c47d70 */

void __fastcall FUN_00c47d70(int *param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  (**(code **)(*param_1 + 8))(&DAT_02136160,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28358 ; VA 0x00c47e00 ; FUN_00c47e00 */

int FUN_00c47e00(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x18);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (param_2 != iVar2) {
    param_2 = FUN_00c49520();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28359 ; VA 0x00c47eb0 ; FUN_00c47eb0 */

int FUN_00c47eb0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c492b0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28360 ; VA 0x00c47f40 ; FUN_00c47f40 */

int FUN_00c47f40(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x24);
  uVar4 = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar5 = FUN_00c49160(param_2,param_3,uVar4,uVar3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28361 ; VA 0x00c47fe0 ; FUN_00c47fe0 */

void __thiscall FUN_00c47fe0(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  float *pfVar5;
  int iVar6;
  undefined auStack_50 [36];
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined8 uStack_14;
  float fStack_c;
  float fStack_8;
  
  iVar6 = 0;
  if (*(int *)(param_1 + 0x16c) != 0) {
    FUN_01679490();
    iVar2 = FUN_00c3c010();
    if ((iVar2 != 0) &&
       ((iVar6 = *(int *)(iVar2 + 0x34), iVar6 == 0 ||
        (iVar2 = *(int *)(iVar6 + 0xc), iVar3 = FUN_00b63e30(),
        (uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))))) {
      iVar6 = 0;
    }
    FUN_008a65e0(0,0);
    *(undefined4 *)(param_1 + 0x16c) = 0;
    piVar4 = *(int **)(param_1 + 0x170);
    *(undefined4 *)(param_1 + 0x170) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[1] + -1;
      piVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar2 = piVar4[2] + -1;
        piVar4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    *(undefined4 *)(param_1 + 0x164) = 0;
    piVar4 = *(int **)(param_1 + 0x168);
    *(undefined4 *)(param_1 + 0x168) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)FUN_00c48580();
  if (((piVar4 != (int *)0x0) && ((**(code **)(*piVar4 + 0x124))(1), iVar6 != 0)) &&
     (iVar2 = FUN_009ba880(iVar6), iVar2 != 0)) {
    (*(code *)**(undefined4 **)(*(int *)(*(int *)(iVar6 + 0x54) + 4) + 0x54 + iVar6))(auStack_50);
    uStack_14._0_4_ = fStack_2c;
    fStack_8 = fStack_28 + DAT_018e3f8c;
    fStack_c = fStack_24;
    pfVar5 = (float *)FUN_011612d0();
    fStack_c = fStack_c - pfVar5[2] * DAT_018f997c;
    FUN_00e705b0(CONCAT44(fStack_8 - pfVar5[1] * DAT_018f997c,
                          (float)uStack_14 - *pfVar5 * DAT_018f997c),fStack_c);
    uStack_14 = 0x3f8000003f800000;
    fStack_c = 1.0;
    (**(code **)(*piVar4 + 0x110))(&uStack_14);
  }
  if (param_2 != '\0') {
    FUN_00c47be0();
  }
  return;
}



/* FUNCTION 28362 ; VA 0x00c481d0 ; FUN_00c481d0 */

bool __fastcall FUN_00c481d0(int param_1)

{
  return 4 < *(int *)(param_1 + 0x114);
}



/* FUNCTION 28363 ; VA 0x00c481e0 ; FUN_00c481e0 */

void FUN_00c481e0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  
  iVar1 = *(int *)(param_1 + 100);
  if ((iVar1 != 0) && (iVar6 = FUN_008b2e60(iVar1), iVar6 != 0)) {
    while (puVar2 = *(undefined4 **)(iVar1 + 0x2c), puVar2 != (undefined4 *)0x0) {
      piVar3 = (int *)puVar2[1];
      piVar9 = (int *)*puVar2;
      while( true ) {
        if (piVar9 == piVar3) {
          return;
        }
        iVar4 = *piVar9;
        if ((iVar4 != 0) &&
           (iVar5 = *(int *)(iVar4 + 0xc), iVar7 = FUN_00c46280(),
           (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
           (uint)*(ushort *)(iVar7 + 0x1da))) break;
        piVar9 = piVar9 + 2;
      }
      if (iVar4 == 0) {
        return;
      }
      if (*(char *)(iVar4 + 0x149) == '\0') {
        uVar8 = thunk_FUN_0068f830();
        FUN_008a65e0(uVar8,0);
      }
      else {
        FUN_008a65e0(iVar6,0);
      }
    }
  }
  return;
}



/* FUNCTION 28364 ; VA 0x00c48290 ; FUN_00c48290 */

int FUN_00c48290(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int *piVar9;
  uint uStack_8;
  
  if ((param_1 != 0) && (piVar9 = *(int **)(param_1 + 0x2c), piVar9 != (int *)0x0)) {
    iVar6 = *piVar9;
    uStack_8 = 0;
    if (piVar9[1] - iVar6 >> 3 != 0) {
      do {
        iVar6 = *(int *)(iVar6 + uStack_8 * 8);
        if ((iVar6 != 0) &&
           (iVar2 = *(int *)(iVar6 + 0xc), iVar4 = FUN_00d6bbd0(),
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
           (uint)*(ushort *)(iVar4 + 0x1da))) {
          piVar5 = *(int **)(iVar6 + 0x28);
          puVar7 = param_2;
          if (0xf < (uint)param_2[5]) {
            puVar7 = (undefined4 *)*param_2;
          }
          piVar1 = piVar5 + 4;
          if (0xf < (uint)piVar5[5]) {
            piVar5 = (int *)*piVar5;
          }
          cVar3 = FUN_0055c360(piVar5,*piVar1,puVar7,param_2[4]);
          if (cVar3 != '\0') {
            return iVar6;
          }
        }
        uStack_8 = uStack_8 + 1;
        iVar6 = *piVar9;
      } while (uStack_8 < (uint)(piVar9[1] - iVar6 >> 3));
      piVar9 = *(int **)(param_1 + 0x2c);
    }
    if (piVar9 != (int *)0x0) {
      uVar8 = 0;
      iVar6 = *piVar9;
      if (piVar9[1] - iVar6 >> 3 != 0) {
        do {
          iVar6 = FUN_00c48290(*(undefined4 *)(iVar6 + uVar8 * 8),param_2);
          if (iVar6 != 0) {
            return iVar6;
          }
          uVar8 = uVar8 + 1;
          iVar6 = *piVar9;
        } while (uVar8 < (uint)(piVar9[1] - iVar6 >> 3));
      }
    }
  }
  return 0;
}



/* FUNCTION 28365 ; VA 0x00c48390 ; FUN_00c48390 */

void __thiscall FUN_00c48390(undefined4 param_1,int *param_2)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  (**(code **)(*param_2 + 8))(param_1,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28366 ; VA 0x00c48420 ; FUN_00c48420 */

void FUN_00c48420(undefined4 param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c486d0(param_1,1);
  uVar2 = FUN_0054db60(&stack0x00000008);
  FUN_00557f90(uVar2);
  FUN_00c47890();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 28367 ; VA 0x00c48470 ; FUN_00c48470 */

void FUN_00c48470(undefined4 param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_0054db60(param_1,param_2,param_2);
  FUN_00c46ee0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 28368 ; VA 0x00c48490 ; FUN_00c48490 */

void FUN_00c48490(void)

{
  int iVar1;
  
  if (DAT_01efccfc == 0) {
    iVar1 = FUN_00c46280();
    DAT_01efccfc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28369 ; VA 0x00c484c0 ; FUN_00c484c0 */

void FUN_00c484c0(uint *param_1)

{
  uint uVar1;
  uint *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (uint *)FUN_011612d0(auStack_10,2);
  uVar1 = DAT_018c4ea0;
  *param_1 = *puVar2 ^ DAT_018c4ea0;
  param_1[1] = puVar2[1] ^ uVar1;
  param_1[2] = puVar2[2] ^ uVar1;
  return;
}



/* FUNCTION 28370 ; VA 0x00c48510 ; FUN_00c48510 */

void __thiscall FUN_00c48510(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x144);
  *param_2 = *(undefined8 *)(param_1 + 0x13c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 28371 ; VA 0x00c48530 ; FUN_00c48530 */

undefined4 FUN_00c48530(undefined4 param_1)

{
  FUN_011612d0(param_1,0);
  return param_1;
}



/* FUNCTION 28372 ; VA 0x00c48550 ; FUN_00c48550 */

undefined4 FUN_00c48550(undefined4 param_1)

{
  FUN_011612d0(param_1,1);
  return param_1;
}



/* FUNCTION 28373 ; VA 0x00c48570 ; thunk_FUN_00c48580 */

int thunk_FUN_00c48580(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Handle",6);
  uStack_8 = 0;
  iVar2 = FUN_008a0cb0(auStack_28);
  if (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar3 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_00c485fd;
  }
  iVar2 = 0;
LAB_00c485fd:
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 28374 ; VA 0x00c48580 ; FUN_00c48580 */

int FUN_00c48580(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Handle",6);
  uStack_8 = 0;
  iVar2 = FUN_008a0cb0(auStack_28);
  if (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar3 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_00c485fd;
  }
  iVar2 = 0;
LAB_00c485fd:
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 28375 ; VA 0x00c48650 ; FUN_00c48650 */

void FUN_00c48650(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar4 = FUN_00c48580();
  if (iVar4 == 0) {
    puVar6 = (undefined4 *)FUN_0060efa0();
  }
  else {
    puVar5 = (undefined4 *)FUN_00b077e0();
    puVar6 = &uStack_34;
    uStack_34 = *puVar5;
    uStack_30 = puVar5[1];
    uStack_2c = puVar5[2];
    uStack_28 = puVar5[3];
    uStack_24 = puVar5[4];
    uStack_20 = puVar5[5];
    uStack_1c = puVar5[6];
    uStack_18 = puVar5[7];
    uStack_14 = puVar5[8];
    uStack_10 = puVar5[9];
    uStack_c = puVar5[10];
    uStack_8 = puVar5[0xb];
  }
  uVar1 = puVar6[1];
  uVar2 = puVar6[2];
  uVar3 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar6[5];
  uVar2 = puVar6[6];
  uVar3 = puVar6[7];
  param_1[4] = puVar6[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar6[9];
  uVar2 = puVar6[10];
  uVar3 = puVar6[0xb];
  param_1[8] = puVar6[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return;
}



/* FUNCTION 28376 ; VA 0x00c486d0 ; FUN_00c486d0 */

int __thiscall FUN_00c486d0(int param_1,int param_2)

{
  return *(int *)(param_1 + 0x34) + param_2;
}



/* FUNCTION 28377 ; VA 0x00c486e0 ; FUN_00c486e0 */

undefined4 __thiscall FUN_00c486e0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x14c);
  return param_2;
}



/* FUNCTION 28378 ; VA 0x00c48700 ; FUN_00c48700 */

void FUN_00c48700(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c48c40(*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8));
  return;
}



/* FUNCTION 28379 ; VA 0x00c48740 ; FUN_00c48740 */

int FUN_00c48740(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined3 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *puVar6;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180a078;
  pvStack_10 = ExceptionList;
  param_1 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_7 = 0;
  uVar3 = uStack_7;
  uStack_8 = 1;
  uStack_7 = 0;
  if ((param_1[0x45] == 2) && (uVar3 = uStack_7, param_2 != 0)) {
    uVar2 = *(undefined4 *)(param_2 + 0x34);
    param_2 = FUN_00c479c0(uVar2);
    uVar3 = uStack_7;
    if (param_2 == 5) {
      uVar4 = FUN_007097d0(uVar2);
      param_2 = FUN_00c47960(uVar4);
      uVar3 = uStack_7;
      if ((char)param_2 != '\0') {
        iVar5 = FUN_00980070(uVar2);
        param_2 = iVar5;
        uVar3 = uStack_7;
        if (iVar5 != 0) {
          param_2 = (**(code **)(*param_1 + 0xb8))(iVar5);
          uVar3 = uStack_7;
          if ((char)param_2 != '\0') {
            FUN_00c48bb0(iVar5);
            FUN_008a65e0(uVar2,0);
            puVar6 = auStack_18;
            FUN_0060e0c0(puVar6,iVar5);
            uStack_8 = 2;
            FUN_005587b0(auStack_18);
            FUN_00c4a360(puVar6,iVar5);
            param_2 = FUN_0056c200();
            uVar3 = uStack_7;
          }
        }
      }
    }
  }
  uStack_7 = uVar3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar5 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar5 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar5 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28380 ; VA 0x00c48880 ; FUN_00c48880 */

uint FUN_00c48880(void)

{
  int iVar1;
  
  iVar1 = FUN_00c46280();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28381 ; VA 0x00c488a0 ; FUN_00c488a0 */

bool FUN_00c488a0(void)

{
  int iVar1;
  
  iVar1 = FUN_008e10a0();
  return 0 < iVar1;
}



/* FUNCTION 28382 ; VA 0x00c488c0 ; FUN_00c488c0 */

uint FUN_00c488c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c46280();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28383 ; VA 0x00c488e0 ; FUN_00c488e0 */

void __fastcall FUN_00c488e0(int param_1)

{
  if (*(int *)(param_1 + 0x114) == 5) {
    FUN_00c4a080();
    if (DAT_01ee41ed != '\0') {
      FUN_016774b0(DAT_01ee41ed,"Tool::activate",0);
    }
    FUN_00c48390(param_1);
    return;
  }
  FUN_0086f2f0(2,
               "Tool:Activate() called from script when tool is not equipped. Tool will not be activated."
              );
  return;
}



/* FUNCTION 28384 ; VA 0x00c48930 ; FUN_00c48930 */

void __fastcall FUN_00c48930(int *param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  if (param_1[0x45] == 5) {
    ExceptionList = &pvStack_10;
    FUN_00c4a080();
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_006eccd0();
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    (**(code **)(*param_1 + 8))(&DAT_02136160,&uStack_24,&uStack_18);
    uStack_8 = 1;
    FUN_00577b20();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(2,
               "Tool:Deactivate() called from script when tool is not equipped. Tool will not be deactivated."
              );
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28385 ; VA 0x00c489f0 ; FUN_00c489f0 */

int * FUN_00c489f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c48aa2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c48a2e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e047e4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_f34a29e34a62cf7727cdea79b64a4f7f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28386 ; VA 0x00c48ac0 ; FUN_00c48ac0 */

int * FUN_00c48ac0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c48b97. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c48b16. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e0481c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_f94c30df944111c632083967e492965c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28387 ; VA 0x00c48bb0 ; FUN_00c48bb0 */

void FUN_00c48bb0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  
  if ((param_1 != 0) && (iVar1 = *(int *)(param_1 + 100), iVar1 != 0)) {
    while (puVar2 = *(undefined4 **)(iVar1 + 0x2c), puVar2 != (undefined4 *)0x0) {
      piVar3 = (int *)puVar2[1];
      piVar8 = (int *)*puVar2;
      while( true ) {
        if (piVar8 == piVar3) {
          return;
        }
        iVar4 = *piVar8;
        if ((iVar4 != 0) &&
           (iVar5 = *(int *)(iVar4 + 0xc), iVar6 = FUN_00c46280(),
           (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
           (uint)*(ushort *)(iVar6 + 0x1da))) break;
        piVar8 = piVar8 + 2;
      }
      if (iVar4 == 0) {
        return;
      }
      uVar7 = thunk_FUN_0068f830();
      FUN_008a65e0(uVar7,0);
    }
  }
  return;
}



/* FUNCTION 28388 ; VA 0x00c48c40 ; FUN_00c48c40 */

int __thiscall FUN_00c48c40(int param_1,int param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a0a0;
  pvStack_10 = ExceptionList;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    piVar4 = param_3 + 1;
    iVar1 = param_3[1];
    ExceptionList = &pvStack_10;
    while (iVar1 != 0) {
      LOCK();
      iVar3 = *piVar4;
      if (iVar1 == iVar3) {
        *piVar4 = iVar1 + 1;
        iVar3 = iVar1;
      }
      UNLOCK();
      if (iVar3 == iVar1) {
        iStack_20 = param_2;
        piStack_1c = param_3;
        break;
      }
      iVar1 = *piVar4;
    }
  }
  piVar4 = piStack_1c;
  iVar1 = iStack_20;
  uStack_8 = 1;
  iStack_14 = param_1;
  if ((((*(int *)(param_1 + 0x114) < 5) || (iStack_20 == 0)) ||
      (param_1 = thunk_FUN_0068f830(), iStack_18 = param_1, param_1 == 0)) ||
     (*(int *)(iVar1 + 100) == 0)) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar2 = piVar4 + 1;
      iVar1 = *piVar2;
      param_1 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar1 = *piVar2;
        param_1 = *piVar2;
        *piVar2 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          param_1 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  else {
    iStack_28 = iStack_14;
    iStack_24 = param_1;
    FUN_00c46f20(&iStack_28);
    piVar4 = *(int **)(iStack_18 + 0x2c);
    if (piVar4 != (int *)0x0) {
      piVar2 = (int *)piVar4[1];
      piVar4 = (int *)*piVar4;
      if (piVar4 != piVar2) {
        do {
          iStack_18 = *piVar4;
          if ((iStack_18 != 0) &&
             (iVar1 = *(int *)(iStack_18 + 0xc), iVar3 = FUN_00bd37d0(),
             (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
             (uint)*(ushort *)(iVar3 + 0x1da))) {
            if (iStack_18 != 0) {
              FUN_00bd46c0();
            }
            goto LAB_00c48d61;
          }
          piVar4 = piVar4 + 2;
        } while (piVar4 != piVar2);
        param_1 = FUN_00550b30();
        goto LAB_00c48d8e;
      }
    }
LAB_00c48d61:
    param_1 = FUN_00550b30();
  }
LAB_00c48d8e:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 2;
    iVar1 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      param_1 = (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28389 ; VA 0x00c48dc0 ; FUN_00c48dc0 */

void __thiscall FUN_00c48dc0(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iStack_8;
  
  iVar4 = *(int *)(param_2 + 4);
  if (iVar4 == 0) {
LAB_00c48e0f:
    iVar4 = 0;
  }
  else {
    iVar1 = *(int *)(iVar4 + 0x34);
    if ((iVar1 != 0) && (iVar4 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 == 0) ||
       (iVar1 = *(int *)(iVar4 + 0xc), iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) goto LAB_00c48e0f;
  }
  iStack_8 = *(int *)(param_2 + 8);
  if (iStack_8 != 0) {
    iVar1 = *(int *)(iStack_8 + 0x34);
    if ((iVar1 != 0) && (iStack_8 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iStack_8 = FUN_005c8ac0();
    }
    if ((iStack_8 != 0) &&
       (iVar1 = *(int *)(iStack_8 + 0xc), iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) goto LAB_00c48e69;
  }
  iStack_8 = 0;
LAB_00c48e69:
  if (iVar4 != 0) {
    *(undefined *)(param_1 + 0x175) = 0;
    cVar2 = FUN_00971ce0(iVar4,1);
    if (cVar2 == '\0') {
      FUN_00c49620(0);
    }
    else {
      FUN_00c498b0(0,iVar4);
    }
  }
  FUN_008a3ee0(param_2);
  if (iStack_8 != 0) {
    cVar2 = FUN_0097c970(iStack_8,1);
    cVar3 = FUN_00971ce0(iStack_8,1);
    if (cVar3 != '\0') {
      if ((cVar2 != '\0') ||
         ((iVar4 = FUN_009ba880(*(undefined4 *)(param_1 + 0x34)), iVar4 != 0 &&
          ((iVar4 = FUN_00980070(*(undefined4 *)(param_1 + 0x34)), iVar4 == 0 ||
           (iVar4 = thunk_FUN_0068f830(), *(int *)(param_2 + 4) != iVar4)))))) {
        *(undefined *)(param_1 + 0x175) = 1;
      }
      FUN_00c49520();
      return;
    }
    iVar4 = FUN_0097bfc0(param_1);
    if ((iVar4 != 0) && (*(int *)(param_1 + 0x34) == *(int *)(iVar4 + 100))) {
      iVar4 = thunk_FUN_0068f830();
      if (*(int *)(param_2 + 4) == iVar4) {
        *(undefined *)(param_1 + 0x175) = 1;
      }
      FUN_00c49520();
    }
    if ((*(int *)(param_1 + 0x16c) != 0) && (iVar4 = FUN_008b33d0(param_1), iVar4 == 0)) {
      FUN_008a65e0(0,0);
      FUN_0058a2b0();
      FUN_00c44b70();
    }
  }
  return;
}



/* FUNCTION 28390 ; VA 0x00c48f80 ; FUN_00c48f80 */

void __fastcall FUN_00c48f80(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_00c49520();
    }
  }
  return;
}



/* FUNCTION 28391 ; VA 0x00c48fe0 ; FUN_00c48fe0 */

undefined4 * __thiscall FUN_00c48fe0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a0b8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x34) != 0) {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_0097c970(param_1,1);
    if (cVar3 != '\0') {
      iVar4 = FUN_0097bfc0(param_1);
      if ((iVar4 != 0) && (*(int *)(iVar4 + 100) == *(int *)(param_1 + 0x34))) {
        iVar4 = FUN_008b2e60(param_1);
        *(int *)(param_1 + 400) = iVar4;
        if (iVar4 != 0) {
          iStack_14 = param_1;
          FUN_00c46d60(&iStack_1c,param_1 + 400,&iStack_14);
          uStack_8 = 0;
          if (iStack_18 != 0) {
            LOCK();
            *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
            UNLOCK();
          }
          FUN_008bac40(iStack_1c,iStack_18,0);
          if (iStack_18 != 0) {
            LOCK();
            *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
            UNLOCK();
          }
          *(int *)(param_1 + 0x19c) = iStack_1c;
          piVar2 = *(int **)(param_1 + 0x1a0);
          *(int *)(param_1 + 0x1a0) = iStack_18;
          if (piVar2 != (int *)0x0) {
            LOCK();
            iVar4 = piVar2[1] + -1;
            piVar2[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar2)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar4 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          iVar4 = *(int *)(iStack_1c + 0x48);
          *param_2 = 0;
          param_2[1] = 0;
          if (iVar4 != 0) {
            LOCK();
            *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
            UNLOCK();
            iVar4 = *(int *)(iStack_1c + 0x48);
          }
          *param_2 = *(undefined4 *)(iStack_1c + 0x44);
          param_2[1] = iVar4;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
      }
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28392 ; VA 0x00c49160 ; FUN_00c49160 */

int FUN_00c49160(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a0e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00c46df0(&iStack_18,&param_1);
  uStack_8._0_1_ = 1;
  piVar5 = piStack_14;
  if (iStack_18 == 0) goto LAB_00c49255;
  FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 2;
  cVar3 = FUN_00691510();
  if (cVar3 == '\0') {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_00c4a650(iStack_18,piStack_14,param_3,param_4);
    if ((char)iVar4 != '\0') {
      piVar5 = &iStack_18;
      goto LAB_00c49210;
    }
  }
  else {
    iVar4 = iStack_18;
    if (iStack_18 == iStack_20) {
      piVar5 = &iStack_20;
LAB_00c49210:
      FUN_0056ecd0(piVar5);
      FUN_0058a2b0();
      iVar4 = FUN_01679490();
    }
  }
  piVar5 = piStack_14;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
LAB_00c49255:
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28393 ; VA 0x00c492b0 ; FUN_00c492b0 */

void * __thiscall FUN_00c492b0(void *param_1,void *param_2,int *param_3)

{
  int *piVar1;
  void *pvVar2;
  int iVar3;
  void *pvVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (void *)0x0) {
    pvVar2 = *(void **)((int)param_1 + 0x34);
    pvVar4 = param_1;
    ExceptionList = &pvStack_10;
    if ((pvVar2 != (void *)0x0) &&
       (pvVar4 = pvVar2, ExceptionList = &pvStack_10, *(int *)((int)pvVar2 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      pvVar4 = (void *)FUN_005c8ac0();
    }
    if (pvVar4 != (void *)0x0) {
      iVar3 = *(int *)((int)pvVar4 + 0xc);
      iVar5 = FUN_008a8c30();
      pvVar4 = (void *)(uint)*(ushort *)(iVar5 + 0x1da);
      if (((void *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= pvVar4)
         && (pvVar4 = param_2, param_2 != param_1)) {
        if (param_2 == *(void **)((int)param_1 + 0x16c)) {
          uVar6 = FUN_005c8880(param_1);
          FUN_00c498b0(4,uVar6);
        }
        pvVar4 = (void *)FUN_00c49520();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar3 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 28394 ; VA 0x00c49380 ; FUN_00c49380 */

void __fastcall FUN_00c49380(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = FUN_0097bfc0(param_1);
  if (iVar3 != 0) {
    cVar2 = FUN_00c47960(*(undefined4 *)(iVar3 + 100));
    if (cVar2 != '\0') {
      iVar1 = *(int *)(param_1 + 0x34);
      iVar4 = thunk_FUN_0068f830();
      if (iVar1 == iVar4) {
        FUN_00c48bb0(iVar3);
        FUN_008a65e0(*(undefined4 *)(iVar3 + 100),0);
        return;
      }
      uVar5 = thunk_FUN_0068f830();
      FUN_008a65e0(uVar5,0);
    }
  }
  return;
}



/* FUNCTION 28395 ; VA 0x00c493e0 ; FUN_00c493e0 */

void __fastcall FUN_00c493e0(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar2 = FUN_0097bfc0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_00c47960(*(undefined4 *)(iVar2 + 100));
    if (cVar1 != '\0') {
      iVar2 = *(int *)(param_1 + 0x34);
      iVar3 = thunk_FUN_0068f830();
      if (iVar2 != iVar3) {
        uVar4 = thunk_FUN_0068f830();
        FUN_008a65e0(uVar4,0);
      }
    }
  }
  return;
}



/* FUNCTION 28396 ; VA 0x00c49430 ; FUN_00c49430 */

void __thiscall FUN_00c49430(int param_1,undefined *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int iStack_8;
  
  if (((param_2 == &DAT_02136120) || (param_2 == &DAT_02136160)) &&
     ((iVar4 = FUN_008f7870(param_1), iVar4 == 0 || (*(int *)(iVar4 + 0x4a0) == 2)))) {
    if (param_1 != 0) {
      while (param_1 = *(int *)(param_1 + 0x34), param_1 != 0) {
        puVar1 = *(undefined4 **)(param_1 + 0x2c);
        if (puVar1 != (undefined4 *)0x0) {
          piVar2 = (int *)puVar1[1];
          for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
            iStack_8 = param_1;
            if ((*piVar6 != 0) &&
               (iVar4 = *(int *)(*piVar6 + 0xc), iVar5 = FUN_0099be20(),
               (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
               (uint)*(ushort *)(iVar5 + 0x1da))) {
              iVar4 = FUN_00980070(iStack_8);
              if (iVar4 == 0) {
                return;
              }
              FUN_00927d30(&iStack_8);
              cVar3 = FUN_00a33d60(param_4);
              if (cVar3 == '\0') {
                return;
              }
              goto LAB_00c49504;
            }
            param_1 = iStack_8;
          }
        }
      }
    }
  }
  else {
LAB_00c49504:
    FUN_009cba80(param_2,param_3,param_4);
  }
  return;
}



/* FUNCTION 28397 ; VA 0x00c49520 ; FUN_00c49520 */

void __fastcall FUN_00c49520(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_8;
  
  iVar2 = FUN_00c48580();
  if ((iVar2 == 0) && (*(char *)(param_1 + 0x14a) != '\0')) {
    uStack_8 = 0;
  }
  else {
    cVar1 = FUN_008b0500(param_1);
    if (cVar1 == '\0') {
      uStack_8 = 0;
    }
    else {
      uStack_8 = FUN_00c479c0(*(undefined4 *)(param_1 + 0x34));
    }
  }
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar2 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) goto LAB_00c495a9;
  }
  param_1 = 0;
LAB_00c495a9:
  FUN_00c498b0(uStack_8,param_1);
  return;
}



/* FUNCTION 28398 ; VA 0x00c495c0 ; FUN_00c495c0 */

void __thiscall FUN_00c495c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  uint uVar2;
  
  for (uVar2 = 0;
      (piVar1 = *(int **)(param_1 + -200), piVar1 != (int *)0x0 &&
      (uVar2 < (uint)(piVar1[1] - *piVar1 >> 3))); uVar2 = uVar2 + 1) {
    piVar1 = (int *)FUN_0170d75d(*(undefined4 *)(*piVar1 + uVar2 * 8),0,
                                 &RBX::Instance::RTTI_Type_Descriptor,
                                 &RBX::IAdornable::RTTI_Type_Descriptor,0);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x1c))(param_2,param_3);
    }
  }
  return;
}



/* FUNCTION 28399 ; VA 0x00c49620 ; FUN_00c49620 */

void __thiscall FUN_00c49620(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a131;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  iVar1 = *(int *)(param_1 + 0x114);
  if (param_2 != iVar1) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x114) = param_2;
    if (iVar1 < 5) {
      if (4 < param_2) {
        FUN_00c48fe0(&iStack_1c);
        uStack_8 = 0;
        param_2 = iStack_1c;
        piVar4 = piStack_18;
        if (iStack_1c == 0) {
          uStack_8 = 1;
          piVar3 = (int *)FUN_00c46be0(&iStack_24);
          piStack_14 = (int *)0x1;
          FUN_00e8a020(0);
          param_2 = *piVar3;
          piVar4 = (int *)piVar3[1];
          *piVar3 = 0;
          piVar3[1] = 0;
          piStack_14 = piStack_18;
          iStack_1c = param_2;
          piVar3 = piVar4;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_18[1] + -1;
            piStack_18[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              puVar2 = (undefined4 *)*piStack_18;
              piStack_18 = piVar4;
              (*(code *)*puVar2)();
              LOCK();
              iVar1 = piStack_14[2] + -1;
              piStack_14[2] = iVar1;
              UNLOCK();
              piVar3 = piStack_18;
              if (iVar1 == 0) {
                (**(code **)(*piStack_14 + 4))();
                piVar3 = piStack_18;
              }
            }
          }
          piStack_18 = piVar3;
          FUN_00550b30();
        }
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
        }
        *(int *)(param_1 + 0x194) = param_2;
        piStack_14 = *(int **)(param_1 + 0x198);
        *(int **)(param_1 + 0x198) = piVar4;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_14[1] + -1;
          piStack_14[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            iVar1 = piStack_14[2] + -1;
            piStack_14[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        *(undefined *)(param_1 + 0x1a8) = 1;
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[2] = piVar4[2] + 1;
          UNLOCK();
        }
        *(int *)(param_1 + 0x1ac) = param_2;
        piVar3 = *(int **)(param_1 + 0x1b0);
        *(int **)(param_1 + 0x1b0) = piVar4;
        iStack_24 = param_2;
        piStack_20 = piVar4;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar1 = piVar3[2] + -1;
          piVar3[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
        }
        FUN_0089be10(param_2,piVar4);
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar1 = piVar4[1] + -1;
          piVar4[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar3 = piVar4 + 2;
            iVar1 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
    }
    else if (param_2 < 5) {
      *(undefined *)(param_1 + 0x1a8) = 0;
      *(undefined4 *)(param_1 + 0x1ac) = 0;
      piVar4 = *(int **)(param_1 + 0x1b0);
      *(undefined4 *)(param_1 + 0x1b0) = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      FUN_006eccd0();
      if (*(int **)(param_1 + 0x194) != (int *)0x0) {
        uStack_2c = 0;
        uStack_28 = 0xf;
        auStack_3c[0] = 0;
        uStack_8 = 3;
        (**(code **)(**(int **)(param_1 + 0x194) + 0xc4))(auStack_3c);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
      }
      if (*(int *)(param_1 + 400) != 0) {
        FUN_008ba310();
        *(undefined4 *)(param_1 + 400) = 0;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28400 ; VA 0x00c498b0 ; FUN_00c498b0 */

void __thiscall FUN_00c498b0(int param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  
  if (param_2 == 5) {
    if (*(int *)(param_1 + 0x114) == 0) {
      cVar1 = FUN_00971ce0(param_3,1);
      FUN_00c49620(5);
      if (cVar1 != '\0') {
        cVar1 = FUN_00971ce0(param_1,1);
        if (cVar1 != '\0') {
          FUN_00c47be0();
        }
        FUN_00c4af10();
        FUN_00c4abb0();
      }
      FUN_00c4a730();
      return;
    }
  }
  else if ((param_2 == 0) && (*(int *)(param_1 + 0x114) == 5)) {
    FUN_00c47fe0(0);
    FUN_01679490();
    FUN_01679490();
    FUN_01679490();
    FUN_01679490();
    FUN_01679490();
    FUN_00c49620(0);
    return;
  }
  iVar3 = *(int *)(param_1 + 0x114);
  if (iVar3 < param_2) {
    do {
      switch(iVar3) {
      case 1:
        cVar1 = FUN_00971ce0(param_1,1);
        if (cVar1 != '\0') {
          FUN_00c47be0();
        }
        break;
      case 2:
        FUN_00c4af10();
        break;
      case 3:
        FUN_00c4abb0();
        break;
      case 4:
        FUN_00c4a730();
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < param_2);
    FUN_00c49620(iVar3);
    return;
  }
  do {
    if (iVar3 <= param_2) {
      FUN_00c49620(iVar3);
      return;
    }
    iVar3 = iVar3 + -1;
    switch(iVar3) {
    default:
      goto switchD_00c499d9_caseD_0;
    case 1:
      break;
    case 2:
      FUN_01679490();
      break;
    case 3:
      FUN_01679490();
      break;
    case 4:
      uVar2 = FUN_00971ce0(param_3,1);
      FUN_00c47fe0(uVar2);
      goto switchD_00c499d9_caseD_0;
    }
    FUN_01679490();
switchD_00c499d9_caseD_0:
  } while( true );
}



/* FUNCTION 28401 ; VA 0x00c49a70 ; FUN_00c49a70 */

void __thiscall FUN_00c49a70(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x149) != param_2) {
    *(char *)(param_1 + 0x149) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28402 ; VA 0x00c49aa0 ; FUN_00c49aa0 */

void __thiscall FUN_00c49aa0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  float fStack_10;
  undefined *puStack_c;
  undefined *puStack_8;
  
  puVar1 = (undefined4 *)(param_1 + 0x118);
  if (((((NAN((float)param_2[9]) || NAN(*(float *)(param_1 + 0x13c))) ==
         ((float)param_2[9] == *(float *)(param_1 + 0x13c))) ||
       ((NAN((float)param_2[10]) || NAN(*(float *)(param_1 + 0x140))) ==
        ((float)param_2[10] == *(float *)(param_1 + 0x140)))) ||
      ((NAN((float)param_2[0xb]) || NAN(*(float *)(param_1 + 0x144))) ==
       ((float)param_2[0xb] == *(float *)(param_1 + 0x144)))) ||
     (cVar5 = FUN_01160ab0(puVar1), cVar5 == '\0')) {
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    *(undefined4 *)(param_1 + 0x11c) = uVar2;
    *(undefined4 *)(param_1 + 0x120) = uVar3;
    *(undefined4 *)(param_1 + 0x124) = uVar4;
    uVar2 = param_2[5];
    uVar3 = param_2[6];
    uVar4 = param_2[7];
    *(undefined4 *)(param_1 + 0x128) = param_2[4];
    *(undefined4 *)(param_1 + 300) = uVar2;
    *(undefined4 *)(param_1 + 0x130) = uVar3;
    *(undefined4 *)(param_1 + 0x134) = uVar4;
    uVar2 = param_2[9];
    uVar3 = param_2[10];
    uVar4 = param_2[0xb];
    iVar6 = 0;
    *(undefined4 *)(param_1 + 0x138) = param_2[8];
    *(undefined4 *)(param_1 + 0x13c) = uVar2;
    *(undefined4 *)(param_1 + 0x140) = uVar3;
    *(undefined4 *)(param_1 + 0x144) = uVar4;
    do {
      FUN_011612d0(&fStack_10,iVar6);
      if (fStack_10 * fStack_10 + (float)puStack_c * (float)puStack_c +
          (float)puStack_8 * (float)puStack_8 < DAT_018f76ac) {
        fStack_10 = 0.0;
        puStack_c = &DAT_bf800000;
        puStack_8 = (undefined *)0x0;
        FUN_01162b00(0,&fStack_10);
        fStack_10 = 1.0;
        puStack_c = (undefined *)0x0;
        puStack_8 = (undefined *)0x0;
        FUN_01162b00(1,&fStack_10);
        fStack_10 = 0.0;
        puStack_c = (undefined *)0x0;
        puStack_8 = &DAT_bf800000;
        FUN_01162b00(2,&fStack_10);
        break;
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < 3);
    FUN_00c94b40(puVar1);
    FUN_008a4940(&DAT_02135e80);
    if (*(int *)(param_1 + 0x16c) != 0) {
      FUN_00c3cee0(puVar1);
    }
  }
  return;
}



/* FUNCTION 28403 ; VA 0x00c49bf0 ; FUN_00c49bf0 */

void __thiscall FUN_00c49bf0(int param_1,undefined4 param_2)

{
  uint *puVar1;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [12];
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uStack_70 = *(undefined4 *)(param_1 + 0x118);
  uStack_6c = *(undefined4 *)(param_1 + 0x11c);
  uStack_68 = *(undefined4 *)(param_1 + 0x120);
  uStack_64 = *(undefined4 *)(param_1 + 0x124);
  uStack_60 = *(undefined4 *)(param_1 + 0x128);
  uStack_5c = *(undefined4 *)(param_1 + 300);
  uStack_58 = *(undefined4 *)(param_1 + 0x130);
  uStack_54 = *(undefined4 *)(param_1 + 0x134);
  uStack_50 = *(undefined4 *)(param_1 + 0x138);
  uStack_4c = *(undefined4 *)(param_1 + 0x13c);
  uStack_48 = *(undefined4 *)(param_1 + 0x140);
  uStack_44 = *(undefined4 *)(param_1 + 0x144);
  FUN_011612d0(&fStack_34,1);
  puVar1 = (uint *)FUN_00c94eb0(auStack_40,param_2);
  fStack_1c = (float)(*puVar1 ^ DAT_018c4ea0);
  fStack_18 = (float)(puVar1[1] ^ DAT_018c4ea0);
  fStack_14 = (float)(puVar1[2] ^ DAT_018c4ea0);
  fStack_10 = fStack_30 * fStack_14 - fStack_2c * fStack_18;
  fStack_c = fStack_1c * fStack_2c - fStack_34 * fStack_14;
  fStack_8 = fStack_34 * fStack_18 - fStack_1c * fStack_30;
  FUN_01165610(0x358637bd);
  fStack_28 = fStack_8 * fStack_18 - fStack_c * fStack_14;
  fStack_24 = fStack_10 * fStack_14 - fStack_8 * fStack_1c;
  fStack_20 = fStack_c * fStack_1c - fStack_10 * fStack_18;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_10);
  FUN_01162b00(1,&fStack_28);
  FUN_01162b00(2,&fStack_1c);
  FUN_00c49aa0(&uStack_70);
  return;
}



/* FUNCTION 28404 ; VA 0x00c49d60 ; FUN_00c49d60 */

void __thiscall FUN_00c49d60(int param_1,undefined8 *param_2)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  uStack_34 = *(undefined4 *)(param_1 + 0x118);
  uStack_30 = *(undefined4 *)(param_1 + 0x11c);
  uStack_2c = *(undefined4 *)(param_1 + 0x120);
  uStack_28 = *(undefined4 *)(param_1 + 0x124);
  uStack_14 = *(undefined4 *)(param_1 + 0x138);
  uStack_24 = *(undefined4 *)(param_1 + 0x128);
  uStack_20 = *(undefined4 *)(param_1 + 300);
  uStack_1c = *(undefined4 *)(param_1 + 0x130);
  uStack_18 = *(undefined4 *)(param_1 + 0x134);
  uStack_10 = *param_2;
  uStack_8 = *(undefined4 *)(param_2 + 1);
  FUN_00c49aa0(&uStack_34);
  return;
}



/* FUNCTION 28405 ; VA 0x00c49db0 ; FUN_00c49db0 */

void __thiscall FUN_00c49db0(int param_1,undefined4 param_2)

{
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uStack_64 = *(undefined4 *)(param_1 + 0x118);
  uStack_60 = *(undefined4 *)(param_1 + 0x11c);
  uStack_5c = *(undefined4 *)(param_1 + 0x120);
  uStack_58 = *(undefined4 *)(param_1 + 0x124);
  uStack_54 = *(undefined4 *)(param_1 + 0x128);
  uStack_50 = *(undefined4 *)(param_1 + 300);
  uStack_4c = *(undefined4 *)(param_1 + 0x130);
  uStack_48 = *(undefined4 *)(param_1 + 0x134);
  uStack_44 = *(undefined4 *)(param_1 + 0x138);
  uStack_40 = *(undefined4 *)(param_1 + 0x13c);
  uStack_3c = *(undefined4 *)(param_1 + 0x140);
  uStack_38 = *(undefined4 *)(param_1 + 0x144);
  FUN_011612d0(&fStack_34,1);
  FUN_00c94eb0(&fStack_10,param_2);
  fStack_1c = fStack_c * fStack_2c - fStack_30 * fStack_8;
  fStack_18 = fStack_34 * fStack_8 - fStack_10 * fStack_2c;
  fStack_14 = fStack_10 * fStack_30 - fStack_34 * fStack_c;
  FUN_01165610(0x358637bd);
  fStack_28 = fStack_18 * fStack_8 - fStack_14 * fStack_c;
  fStack_20 = fStack_1c * fStack_c - fStack_18 * fStack_10;
  fStack_24 = fStack_14 * fStack_10 - fStack_1c * fStack_8;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_10);
  FUN_01162b00(1,&fStack_28);
  FUN_01162b00(2,&fStack_1c);
  FUN_00c49aa0(&uStack_64);
  return;
}



/* FUNCTION 28406 ; VA 0x00c49f00 ; FUN_00c49f00 */

void __thiscall FUN_00c49f00(int param_1,undefined4 param_2)

{
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uStack_64 = *(undefined4 *)(param_1 + 0x118);
  uStack_60 = *(undefined4 *)(param_1 + 0x11c);
  uStack_5c = *(undefined4 *)(param_1 + 0x120);
  uStack_58 = *(undefined4 *)(param_1 + 0x124);
  uStack_54 = *(undefined4 *)(param_1 + 0x128);
  uStack_50 = *(undefined4 *)(param_1 + 300);
  uStack_4c = *(undefined4 *)(param_1 + 0x130);
  uStack_48 = *(undefined4 *)(param_1 + 0x134);
  uStack_44 = *(undefined4 *)(param_1 + 0x138);
  uStack_40 = *(undefined4 *)(param_1 + 0x13c);
  uStack_3c = *(undefined4 *)(param_1 + 0x140);
  uStack_38 = *(undefined4 *)(param_1 + 0x144);
  FUN_011612d0(&fStack_34,0);
  FUN_00c94eb0(&fStack_10,param_2);
  fStack_1c = fStack_30 * fStack_8 - fStack_c * fStack_2c;
  fStack_18 = fStack_10 * fStack_2c - fStack_34 * fStack_8;
  fStack_14 = fStack_34 * fStack_c - fStack_10 * fStack_30;
  FUN_01165610(0x358637bd);
  fStack_28 = fStack_14 * fStack_c - fStack_18 * fStack_8;
  fStack_24 = fStack_1c * fStack_8 - fStack_14 * fStack_10;
  fStack_20 = fStack_18 * fStack_10 - fStack_1c * fStack_c;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_28);
  FUN_01162b00(1,&fStack_10);
  FUN_01162b00(2,&fStack_1c);
  FUN_00c49aa0(&uStack_64);
  return;
}



/* FUNCTION 28407 ; VA 0x00c4a050 ; FUN_00c4a050 */

void __thiscall FUN_00c4a050(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x174)) {
    *(char *)(param_1 + 0x174) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28408 ; VA 0x00c4a080 ; FUN_00c4a080 */

void __fastcall FUN_00c4a080(int param_1)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int iStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a150;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    iStack_1c = param_1;
    if ((iVar2 != 0) && (param_1 = iVar2, ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar2 = *(int *)(param_1 + 0xc), iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      FUN_005789c0(&DAT_01ead600,&LAB_00634100);
      uVar6 = FUN_00635450();
      piVar7 = (int *)FUN_008aa140(uVar6);
      piStack_14 = piVar7;
      if (*piVar7 == 0) {
        uVar6 = FUN_00b7a190();
        piVar8 = (int *)FUN_008a9ba0(auStack_28,uVar6);
        piVar7 = piStack_14;
        iVar2 = *piVar8;
        iVar5 = piVar8[1];
        *piVar8 = 0;
        piVar8[1] = 0;
        *piStack_14 = iVar2;
        piVar8 = (int *)piStack_14[1];
        piStack_14[1] = iVar5;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar2 = piVar8[1] + -1;
          piVar8[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar2 = piVar8[2] + -1;
            piVar8[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        piVar8 = piStack_24;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_24[1] + -1;
          piStack_24[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar1 = piVar8 + 2;
            iVar2 = *piVar1 + -1;
            *piVar1 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      if ((*piVar7 != 0) && (cVar4 = FUN_00b82610(), cVar4 != '\0')) {
        iVar2 = *(int *)(iStack_1c + 0x34);
        iVar5 = iStack_1c;
        if ((iVar2 != 0) && (iVar5 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
          iVar5 = FUN_005c8ac0();
        }
        if ((iVar5 != 0) &&
           (iVar2 = *(int *)(iVar5 + 0xc), iVar5 = FUN_008a8c30(),
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) {
          FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
          uVar6 = FUN_006353d0();
          piVar7 = (int *)FUN_008aa140(uVar6);
          if (*piVar7 == 0) {
            piStack_14 = piVar7;
            uVar6 = FUN_00b774a0();
            piVar8 = (int *)FUN_008a9ba0(auStack_28,uVar6);
            piVar7 = piStack_14;
            iVar2 = *piVar8;
            iVar5 = piVar8[1];
            *piVar8 = 0;
            piVar8[1] = 0;
            *piStack_14 = iVar2;
            piVar8 = (int *)piStack_14[1];
            piStack_14[1] = iVar5;
            if (piVar8 != (int *)0x0) {
              LOCK();
              iVar2 = piVar8[1] + -1;
              piVar8[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piVar8)();
                LOCK();
                iVar2 = piVar8[2] + -1;
                piVar8[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar8 + 4))();
                }
              }
            }
            if (piStack_24 != (int *)0x0) {
              LOCK();
              iVar2 = piStack_24[1] + -1;
              piStack_24[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_24)();
                LOCK();
                piVar8 = piStack_24 + 2;
                iVar2 = *piVar8;
                *piVar8 = *piVar8 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                  (**(code **)(*piStack_24 + 4))();
                }
              }
            }
          }
          iVar2 = iStack_1c;
          piStack_14 = (int *)*piVar7;
          if (piStack_14 != (int *)0x0) {
            if (*(int **)(iStack_1c + 0x194) != (int *)0x0) {
              pcVar3 = *(code **)(**(int **)(iStack_1c + 0x194) + 0xa4);
              uVar6 = FUN_008b3500(auStack_20);
              uStack_8 = 0;
              (*pcVar3)(uVar6);
              uStack_8 = 0xffffffff;
              FUN_00550b30();
            }
            if (*(int **)(iVar2 + 0x19c) != (int *)0x0) {
              pcVar3 = *(code **)(**(int **)(iVar2 + 0x19c) + 0x24);
              uVar6 = FUN_008b3500(auStack_18);
              uStack_8 = 1;
              (*pcVar3)(auStack_20,uVar6);
              FUN_00550b30();
              FUN_00550b30();
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28409 ; VA 0x00c4a330 ; FUN_00c4a330 */

void __thiscall FUN_00c4a330(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x14a) != param_2) {
    *(char *)(param_1 + 0x14a) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28410 ; VA 0x00c4a360 ; FUN_00c4a360 */

/* WARNING: Removing unreachable block (ram,0x00c4a48c) */
/* WARNING: Removing unreachable block (ram,0x00c4a4a7) */
/* WARNING: Removing unreachable block (ram,0x00c4a493) */
/* WARNING: Removing unreachable block (ram,0x00c4a4ce) */
/* WARNING: Removing unreachable block (ram,0x00c4a4d2) */
/* WARNING: Removing unreachable block (ram,0x00c4a4db) */

void __thiscall FUN_00c4a360(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a170;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar3 != 0) && (param_1 = iVar3, ExceptionList = &pvStack_10, *(int *)(iVar3 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar3 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar3 = FUN_005cf2a0(), iVar3 != 0)) {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      FUN_00c46650();
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar3 = param_3[2] + -1;
        param_3[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*param_3 + 4))();
        }
        LOCK();
        iVar3 = param_3[2] + -1;
        param_3[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
      uStack_8._0_1_ = 1;
      FUN_009eef30();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28411 ; VA 0x00c4a520 ; FUN_00c4a520 */

void __thiscall
FUN_00c4a520(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d6876c < (uint)param_6) {
    uVar5 = DAT_01d6876c;
    if ((uint)param_6 < DAT_01d6876c) {
      uVar5 = (uint)param_6;
    }
    puVar2 = &param_2;
    if (0xf < param_6._4_4_) {
      puVar2 = param_2;
    }
    puStack_34 = (undefined4 *)((uint)puStack_34 & 0xffffff00);
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar2,uVar5);
    FUN_005507b0();
    param_2 = puStack_34;
    param_3 = uStack_30;
    param_4 = uStack_2c;
    param_5 = uStack_28;
    param_6 = 0xf00000000;
    param_6._0_4_ = 0;
  }
  puVar2 = param_2;
  uVar5 = param_6._4_4_;
  piVar3 = (int *)(param_1 + 0x14c);
  puVar4 = &param_2;
  if (0xf < param_6._4_4_) {
    puVar4 = param_2;
  }
  if (0xf < *(uint *)(param_1 + 0x160)) {
    piVar3 = (int *)*piVar3;
  }
  cVar1 = FUN_0055c360(piVar3,*(undefined4 *)(param_1 + 0x15c),puVar4,(uint)param_6);
  if (cVar1 == '\0') {
    if ((undefined4 **)(param_1 + 0x14c) != &param_2) {
      puVar4 = &param_2;
      if (0xf < uVar5) {
        puVar4 = puVar2;
      }
      FUN_005542c0(puVar4,(uint)param_6);
    }
    FUN_008a4940(&DAT_02135f98);
    puVar2 = param_2;
    uVar5 = param_6._4_4_;
  }
  if (0xf < uVar5) {
    uVar6 = uVar5 + 1;
    puVar4 = puVar2;
    if (0xfff < uVar6) {
      puVar4 = (undefined4 *)puVar2[-1];
      uVar6 = uVar5 + 0x24;
      if (0x1f < (uint)((int)puVar2 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28412 ; VA 0x00c4a650 ; FUN_00c4a650 */

undefined FUN_00c4a650(int param_1,int *param_2,int param_3,int param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar5 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00c39bb0();
  iVar7 = 0;
  if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar7 = param_1;
  }
  if (iVar7 != 0) {
    piVar4 = *(int **)(iVar7 + 0x28);
    piVar1 = piVar4 + 4;
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    cVar2 = FUN_0055c360(piVar4,*piVar1,"RightGrip",9);
    if (cVar2 != '\0') {
      iVar5 = FUN_00c3c020();
      if ((iVar5 != 0) && (iVar5 == param_3)) {
        iVar5 = FUN_00c3c010();
        if ((iVar5 != 0) && (iVar5 == param_4)) {
          uVar6 = 1;
          goto LAB_00c4a6e8;
        }
      }
    }
  }
  uVar6 = 0;
LAB_00c4a6e8:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar5 = param_2[1] + -1;
    param_2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 28413 ; VA 0x00c4a730 ; FUN_00c4a730 */

void __fastcall FUN_00c4a730(int param_1)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 in_stack_ffffff3c;
  int *piVar8;
  int iVar9;
  undefined auStack_a8 [48];
  undefined auStack_78 [8];
  undefined auStack_70 [8];
  int *piStack_68;
  int iStack_64;
  int *piStack_60;
  int iStack_5c;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a1d9;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  piStack_18 = (int *)FUN_009ba880(*(undefined4 *)(param_1 + 0x34));
  if (piStack_18 != (int *)0x0) {
    if (piStack_18[0x8a] == 0) {
      iVar3 = FUN_009b6d20();
      iStack_1c = iVar3;
    }
    else {
      piStack_60 = (int *)0x0;
      iStack_5c = 0xf;
      auStack_70[0] = 0;
      FUN_005542c0("RightHand",9);
      uStack_8 = 0;
      iVar3 = FUN_008a1240(auStack_70);
      if ((iVar3 == 0) ||
         (iVar9 = *(int *)(iVar3 + 0xc), iStack_1c = iVar3, iVar4 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar4 + 0x1da) <
         (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
        iVar3 = 0;
        iStack_1c = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    if (iVar3 != 0) {
      piVar5 = (int *)FUN_00c48580();
      piStack_14 = piVar5;
      if (*(char *)(param_1 + 0x175) == '\0') {
        cVar2 = FUN_00971ce0(param_1,1);
        if ((cVar2 != '\0') && (piVar5 != (int *)0x0)) {
          cVar2 = FUN_00691510();
          if (cVar2 == '\0') {
            uStack_48 = 0;
            uStack_44 = 0xf;
            auStack_58[0] = 0;
            FUN_005542c0("RightGrip",9);
            uStack_8 = 2;
            uVar6 = FUN_008a1240(auStack_58);
            puVar7 = (undefined4 *)FUN_0060dcd0(auStack_34,uVar6);
            uStack_3c = *puVar7;
            uStack_38 = puVar7[1];
            *puVar7 = 0;
            puVar7[1] = 0;
            uStack_20 = 4;
            piStack_18 = piStack_30;
            if (piStack_30 != (int *)0x0) {
              LOCK();
              iVar9 = piStack_30[1] + -1;
              piStack_30[1] = iVar9;
              UNLOCK();
              piVar5 = piStack_14;
              if (iVar9 == 0) {
                (**(code **)*piStack_30)();
                LOCK();
                piVar5 = piStack_18 + 2;
                iVar9 = *piVar5;
                *piVar5 = *piVar5 + -1;
                UNLOCK();
                piVar5 = piStack_14;
                if (iVar9 == 1) {
                  (**(code **)(*piStack_18 + 4))();
                  piVar5 = piStack_14;
                }
              }
            }
            uStack_8 = 4;
            uVar6 = 0xc4a9eb;
            FUN_00c46df0(&iStack_28,&uStack_3c);
            FUN_00550b30();
            uStack_8 = CONCAT31(uStack_8._1_3_,7);
            FUN_005507b0();
            if (iStack_28 == 0) {
              FUN_0058a2b0();
            }
            else {
              piVar8 = piVar5;
              iVar9 = iVar3;
              FUN_00557fc0(&iStack_28);
              cVar2 = FUN_00c4a650(in_stack_ffffff3c,uVar6,piVar8,iVar9);
              if (cVar2 != '\0') {
                FUN_0056ecd0(&iStack_28);
                FUN_00c44b70();
              }
            }
            uStack_8 = 0xffffffff;
            FUN_00550b30();
          }
          else {
            puVar7 = (undefined4 *)FUN_00587490(&iStack_28);
            uVar6 = *puVar7;
            uVar1 = puVar7[1];
            *puVar7 = 0;
            puVar7[1] = 0;
            *(undefined4 *)(param_1 + 0x16c) = uVar6;
            piStack_18 = *(int **)(param_1 + 0x170);
            *(undefined4 *)(param_1 + 0x170) = uVar1;
            if (piStack_18 != (int *)0x0) {
              LOCK();
              iVar9 = piStack_18[1] + -1;
              piStack_18[1] = iVar9;
              UNLOCK();
              piVar5 = piStack_14;
              if (iVar9 == 0) {
                (**(code **)*piStack_18)();
                LOCK();
                piVar5 = piStack_18 + 2;
                iVar9 = *piVar5;
                *piVar5 = *piVar5 + -1;
                UNLOCK();
                piVar5 = piStack_14;
                if (iVar9 == 1) {
                  (**(code **)(*piStack_18 + 4))();
                  piVar5 = piStack_14;
                }
              }
            }
            FUN_00550b30();
            FUN_00c44b70();
          }
          if (*(int *)(param_1 + 0x16c) == 0) {
            iStack_2c = FUN_008a4100();
            iStack_2c = iStack_2c + 8;
            puVar7 = (undefined4 *)FUN_0060dcd0(auStack_78,param_1);
            piStack_68 = (int *)*puVar7;
            iStack_64 = puVar7[1];
            *puVar7 = 0;
            puVar7[1] = 0;
            uStack_8._0_1_ = 10;
            uStack_8._1_3_ = 0;
            piStack_60 = piVar5;
            iStack_5c = iVar3;
            iStack_40 = iStack_64;
            piStack_30 = piStack_68;
            uVar6 = FUN_01675290(DAT_02110da8);
            uStack_8._0_1_ = 0xb;
            uStack_38 = uVar6;
            piStack_24 = (int *)FUN_01674e20(0x28);
            if (piStack_24 == (int *)0x0) {
              piVar5 = (int *)0x0;
            }
            else {
              *piStack_24 = 0;
              piStack_24[1] = 1;
              piStack_24[2] = (int)FUN_00c47f40;
              piStack_24[3] = (int)FUN_0068b170;
              piStack_24[4] = 0;
              piStack_24[5] = iStack_2c;
              piStack_24[6] = 0;
              piStack_24[7] = 0;
              if (iStack_40 != 0) {
                LOCK();
                *(int *)(iStack_40 + 4) = *(int *)(iStack_40 + 4) + 1;
                UNLOCK();
              }
              piStack_24[7] = iStack_40;
              piStack_24[6] = (int)piStack_30;
              piStack_24[8] = (int)piStack_14;
              piStack_24[9] = iStack_1c;
              piVar5 = piStack_24;
            }
            FUN_016797d0(piVar5);
            if (piVar5 != (int *)0x0) {
              LOCK();
              piVar5[1] = piVar5[1] + 1;
              UNLOCK();
            }
            uStack_20 = uStack_20 | 8;
            uStack_8._0_1_ = 0xc;
            piStack_18 = piVar5;
            FUN_01675290(uVar6);
            uStack_8 = CONCAT31(uStack_8._1_3_,10);
            FUN_00614020(&piStack_18);
            FUN_0056e750();
            FUN_00550b30();
            uStack_8 = 0xffffffff;
            FUN_00550b30();
          }
          (**(code **)(*piStack_14 + 0x124))(0);
        }
      }
      else if (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + 0x124))(0);
        uVar6 = FUN_009b6b40(auStack_a8);
        uStack_48 = 0;
        uStack_44 = 0xf;
        auStack_58[0] = 0;
        FUN_005542c0("RightGrip",9);
        uStack_8 = 1;
        FUN_00c3b990(param_1 + 0x16c,auStack_58,iVar3,piStack_14,uVar6,param_1 + 0x118);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28414 ; VA 0x00c4abb0 ; FUN_00c4abb0 */

int __fastcall FUN_00c4abb0(int param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 *puStack_3c;
  int *piStack_38;
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a252;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  FUN_009ba880(*(undefined4 *)(param_1 + 0x34));
  uStack_2c = FUN_009b7250();
  iStack_20 = FUN_008a4100();
  iStack_20 = iStack_20 + 8;
  piVar3 = (int *)FUN_0060dcd0(&uStack_44,param_1);
  puStack_3c = (undefined4 *)*piVar3;
  piVar7 = (int *)piVar3[1];
  *piVar3 = 0;
  piVar3[1] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piStack_38 = piVar7;
  piStack_28 = piVar7;
  puStack_1c = puStack_3c;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  puStack_30 = (undefined4 *)uVar4;
  piStack_34 = (int *)FUN_01674e20(0x20);
  if (piStack_34 == (int *)0x0) {
    piVar7 = (int *)0x0;
  }
  else {
    *piStack_34 = 0;
    piStack_34[1] = 1;
    piStack_34[2] = (int)FUN_00c47e00;
    piStack_34[3] = (int)FUN_0068b170;
    piStack_34[4] = 0;
    piStack_34[5] = iStack_20;
    piStack_34[6] = 0;
    piStack_34[7] = 0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
    }
    piStack_34[6] = (int)puStack_1c;
    piStack_34[7] = (int)piVar7;
    piVar7 = piStack_34;
  }
  FUN_016797d0(piVar7);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  uStack_18 = 1;
  uStack_8._0_1_ = 4;
  piStack_14 = piVar7;
  FUN_01675290(uVar4);
  iVar6 = iStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar2 = FUN_01679300(&piStack_14);
  if (cVar2 != '\0') {
    FUN_01679490();
    FUN_016791c0(&piStack_14);
  }
  uStack_18 = 0;
  if (piStack_14 != (int *)0x0) {
    piVar7 = piStack_14 + 1;
    LOCK();
    iVar1 = *piVar7;
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(piStack_14);
    }
  }
  piVar7 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_28[1] + -1;
    piStack_28[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar1 = *piVar3 + -1;
      *piVar3 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_40[1] + -1;
    piStack_40[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar1 = piStack_40[2] + -1;
      piStack_40[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  iStack_20 = FUN_008a4100();
  iStack_20 = iStack_20 + 0xc;
  puVar5 = (undefined4 *)FUN_0060dcd0(&puStack_3c,iVar6);
  uStack_44 = *puVar5;
  piStack_40 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8._0_1_ = 7;
  uStack_8._1_3_ = 0;
  uStack_2c = uStack_44;
  piStack_14 = piStack_40;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 8;
  piStack_34 = (int *)uVar4;
  puStack_30 = (undefined4 *)FUN_01674e20(0x20);
  if (puStack_30 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puStack_30 = 0;
    puStack_30[1] = 1;
    puStack_30[2] = FUN_00c47eb0;
    puStack_30[3] = FUN_0068b170;
    puStack_30[4] = 0;
    puStack_30[5] = iStack_20;
    puStack_30[6] = 0;
    puStack_30[7] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    puStack_30[6] = uStack_2c;
    puStack_30[7] = piStack_14;
    puVar5 = puStack_30;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_18 = 2;
  uStack_8._0_1_ = 9;
  puStack_1c = puVar5;
  FUN_01675290(uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_01679300(&puStack_1c);
  if ((char)iVar6 != '\0') {
    FUN_01679490();
    iVar6 = FUN_016791c0(&puStack_1c);
  }
  if (puStack_1c != (undefined4 *)0x0) {
    piVar7 = puStack_1c + 1;
    LOCK();
    iVar6 = *piVar7;
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    iVar6 = iVar6 + -1;
    if (iVar6 == 0) {
      iVar6 = FUN_01674ea0(puStack_1c);
    }
  }
  piVar7 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_14 + 1;
    iVar1 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar1 = *piVar3;
      iVar6 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar6 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  piVar7 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_38 + 1;
    iVar1 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar6 = (**(code **)*piStack_38)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar6 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 28415 ; VA 0x00c4af10 ; FUN_00c4af10 */

int __fastcall FUN_00c4af10(int param_1)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_44 [4];
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a2c2;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  iStack_1c = param_1;
  if (*(int *)(param_1 + 0x34) != 0) {
    ExceptionList = &pvStack_10;
    iStack_24 = FUN_008a4100();
    iStack_24 = iStack_24 + 8;
    piVar4 = (int *)FUN_0060dcd0(&uStack_3c,param_1);
    puStack_34 = (undefined4 *)*piVar4;
    piVar2 = (int *)piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_30 = piVar2;
    puStack_20 = puStack_34;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 3;
    uStack_28 = uVar5;
    piStack_2c = (int *)FUN_01674e20(0x20);
    if (piStack_2c == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      *piStack_2c = 0;
      piStack_2c[1] = 1;
      piStack_2c[2] = (int)FUN_00c47e00;
      piStack_2c[3] = (int)FUN_0068b170;
      piStack_2c[4] = 0;
      piStack_2c[5] = iStack_24;
      piStack_2c[6] = 0;
      piStack_2c[7] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      piStack_2c[6] = (int)puStack_20;
      piStack_2c[7] = (int)piVar2;
      piVar4 = piStack_2c;
    }
    FUN_016797d0(piVar4);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    uStack_18 = 1;
    uStack_8._0_1_ = 4;
    piStack_14 = piVar4;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    cVar3 = FUN_01679300(&piStack_14);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_14);
    }
    uStack_18 = 0;
    if (piStack_14 != (int *)0x0) {
      piVar4 = piStack_14 + 1;
      LOCK();
      iVar7 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_14);
      }
    }
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar7 = piVar2[1] + -1;
      piVar2[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar7 = piVar2[2] + -1;
        piVar2[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_38[1] + -1;
      piStack_38[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar7 = piStack_38[2] + -1;
        piStack_38[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    iVar7 = iStack_1c;
    iStack_24 = FUN_008a4100();
    iStack_24 = iStack_24 + 0xc;
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_44,iVar7);
    uStack_3c = *puVar6;
    piStack_38 = (int *)puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    uStack_8._0_1_ = 7;
    uStack_8._1_3_ = 0;
    uStack_28 = uStack_3c;
    piStack_14 = piStack_38;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 8;
    piStack_2c = (int *)uVar5;
    piStack_30 = (int *)FUN_01674e20(0x20);
    if (piStack_30 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *piStack_30 = 0;
      piStack_30[1] = 1;
      piStack_30[2] = (int)FUN_00c47eb0;
      piStack_30[3] = (int)FUN_0068b170;
      piStack_30[4] = 0;
      piStack_30[5] = iStack_24;
      piStack_30[6] = 0;
      piStack_30[7] = 0;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
      }
      piStack_30[6] = uStack_28;
      piStack_30[7] = (int)piStack_14;
      puVar6 = piStack_30;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_18 = 2;
    uStack_8._0_1_ = 9;
    puStack_20 = puVar6;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    iVar7 = FUN_01679300(&puStack_20);
    if ((char)iVar7 != '\0') {
      FUN_01679490();
      iVar7 = FUN_016791c0(&puStack_20);
    }
    if (puStack_20 != (undefined4 *)0x0) {
      piVar2 = puStack_20 + 1;
      LOCK();
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      iVar7 = iVar7 + -1;
      if (iVar7 == 0) {
        iVar7 = FUN_01674ea0(puStack_20);
      }
    }
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar1 = *piVar4;
      iVar7 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piVar2 + 2;
        iVar1 = *piVar4;
        iVar7 = *piVar4;
        *piVar4 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar7 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_40 + 1;
      iVar1 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar7 = (**(code **)*piStack_40)();
        LOCK();
        piVar2 = piStack_40 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          iVar7 = (**(code **)(*piStack_40 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar7;
  }
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar7 = FUN_01679490();
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 28416 ; VA 0x00c4b280 ; FUN_00c4b280 */

int * __thiscall FUN_00c4b280(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a2d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_0089c660();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00c4bb40(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28417 ; VA 0x00c4b33e ; Catch_All@00c4b33e */

void Catch_All_00c4b33e(void)

{
  thunk_FUN_009abb30();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28418 ; VA 0x00c4b350 ; FUN_00c4b350 */

int * __thiscall FUN_00c4b350(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a2f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_0089c660();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00c4bb40(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28419 ; VA 0x00c4b40e ; Catch_All@00c4b40e */

void Catch_All_00c4b40e(void)

{
  thunk_FUN_009abb30();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28420 ; VA 0x00c4b420 ; FUN_00c4b420 */

int * __thiscall FUN_00c4b420(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a318;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_0089c660();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00c4bb40(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28421 ; VA 0x00c4b4de ; Catch_All@00c4b4de */

void Catch_All_00c4b4de(void)

{
  thunk_FUN_009abb30();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28422 ; VA 0x00c4b4f0 ; FUN_00c4b4f0 */

int * __thiscall FUN_00c4b4f0(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a338;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_0089c660();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00c4bb40(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28423 ; VA 0x00c4b5ae ; Catch_All@00c4b5ae */

void Catch_All_00c4b5ae(void)

{
  thunk_FUN_009abb30();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28424 ; VA 0x00c4b5c0 ; FUN_00c4b5c0 */

undefined4 * __thiscall FUN_00c4b5c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_2[6] = 0;
  param_2[7] = 0;
  return param_1;
}



/* FUNCTION 28425 ; VA 0x00c4b630 ; FUN_00c4b630 */

int * __thiscall FUN_00c4b630(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c51690();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 28426 ; VA 0x00c4b680 ; FUN_00c4b680 */

int * __thiscall FUN_00c4b680(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c51700();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 28427 ; VA 0x00c4b6d0 ; FUN_00c4b6d0 */

int * __thiscall FUN_00c4b6d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c51770();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 28428 ; VA 0x00c4b720 ; FUN_00c4b720 */

int * __thiscall FUN_00c4b720(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c517e0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 28429 ; VA 0x00c4b770 ; FUN_00c4b770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c4b770(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a370;
  pvStack_10 = ExceptionList;
  if (DAT_01efcd3c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efcf50) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efcf50);
      if (DAT_01efcf50 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PlayerScripts",0,uStack_20,0,0,1,0,0);
        _DAT_01efcf48 = RBX::Creator<class_RBX::PlayerScripts>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efcd40,&DAT_01efcf48);
        FUN_016f3654(FUN_01895200);
        FUN_016f37bf(&DAT_01efcf50);
      }
    }
    DAT_01efcd3c = &DAT_01efcd40;
  }
  ExceptionList = pvStack_10;
  return DAT_01efcd3c;
}



/* FUNCTION 28430 ; VA 0x00c4b870 ; FUN_00c4b870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c4b870(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a3a0;
  pvStack_10 = ExceptionList;
  if (DAT_01efd178 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd390) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efd390);
      if (DAT_01efd390 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c4b970();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StarterCharacterScripts",0,uStack_20,0,0,0xb,0,0);
        _DAT_01efd388 = RBX::Creator<class_RBX::StarterCharacterScripts>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efd180,&DAT_01efd388);
        FUN_016f3654(FUN_01895260);
        FUN_016f37bf(&DAT_01efd390);
      }
    }
    DAT_01efd178 = &DAT_01efd180;
  }
  ExceptionList = pvStack_10;
  return DAT_01efd178;
}



/* FUNCTION 28431 ; VA 0x00c4b970 ; FUN_00c4b970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c4b970(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a3d0;
  pvStack_10 = ExceptionList;
  if (DAT_01efcf58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd170) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efd170);
      if (DAT_01efd170 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StarterPlayerScripts",0,uStack_20,0,0,0xb,0,0);
        _DAT_01efd168 = RBX::Creator<class_RBX::StarterPlayerScripts>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efcf60,&DAT_01efd168);
        FUN_016f3654(FUN_018952c0);
        FUN_016f37bf(&DAT_01efd170);
      }
    }
    DAT_01efcf58 = &DAT_01efcf60;
  }
  ExceptionList = pvStack_10;
  return DAT_01efcf58;
}



/* FUNCTION 28432 ; VA 0x00c4ba70 ; FUN_00c4ba70 */

int FUN_00c4ba70(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a3e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575bc0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054f050(*param_2);
  *(undefined4 *)(iVar1 + 0x28) = 0;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 28433 ; VA 0x00c4badb ; Catch_All@00c4badb */

void Catch_All_00c4badb(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28434 ; VA 0x00c4baf0 ; FUN_00c4baf0 */

int FUN_00c4baf0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  
  iVar3 = FUN_00575b80();
  *(undefined2 *)(iVar3 + 0xc) = 0;
  puVar2 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar3 + 0x10) = 0;
  *(undefined4 *)(iVar3 + 0x14) = 0;
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + 0x10) = *puVar2;
  *(undefined4 *)(iVar3 + 0x14) = puVar2[1];
  *(undefined *)(iVar3 + 0x18) = 0;
  return iVar3;
}



/* FUNCTION 28435 ; VA 0x00c4bb40 ; FUN_00c4bb40 */

undefined4 * __thiscall
FUN_00c4bb40(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a3f0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_00897cc0(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_00c4bb40(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_00c4bb40(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 28436 ; VA 0x00c4bbd4 ; Catch_All@00c4bbd4 */

void Catch_All_00c4bbd4(void)

{
  int unaff_EBP;
  
  FUN_0089c7e0(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28437 ; VA 0x00c4bbf0 ; FUN_00c4bbf0 */

void __thiscall
FUN_00c4bbf0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x9249247 < (uint)param_1[1]) {
    FUN_00c4e650(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00c4bca2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00c4bca2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 28438 ; VA 0x00c4bd50 ; FUN_00c4bd50 */

void __thiscall
FUN_00c4bd50(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_00c4e6a0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00c4be02:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00c4be02;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 28439 ; VA 0x00c4beb0 ; FUN_00c4beb0 */

undefined4 * __thiscall
FUN_00c4beb0(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a400;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00c4bbf0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00c4bbf0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00c4bbf0(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[4] < *param_4;
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x10) < *param_4) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00c4bbf0(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00c4bbf0(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[4] < *param_4;
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      piVar2 = (int *)FUN_00551320();
      if ((*piVar2 == *param_1) || (*param_4 < (uint)piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00c4bbf0(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00c4bbf0(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_00c4c270(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28440 ; VA 0x00c4c09d ; Catch_All@00c4c09d */

void Catch_All_00c4c09d(void)

{
  int unaff_EBP;
  
  FUN_00c4e650(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28441 ; VA 0x00c4c0c0 ; FUN_00c4c0c0 */

undefined4 * __thiscall
FUN_00c4c0c0(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a410;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    param_3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
  }
  else {
    if (param_3 != *(int **)*param_1) {
      if (param_3 != (int *)*param_1) {
        ExceptionList = &pvStack_10;
        iVar1 = FUN_01686710(param_3 + 4);
        if (iVar1 < 0) {
          piStack_18 = param_3;
          FUN_0056f560();
          iVar1 = FUN_01686710(param_4);
          if (iVar1 < 0) {
            if (*(char *)(piStack_18[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = param_3;
            }
            else {
              uVar4 = 0;
              param_3 = piStack_18;
            }
            goto LAB_00c4c109;
          }
        }
        iVar1 = FUN_01686710(param_4);
        if (iVar1 < 0) {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_00551320();
          if ((*piVar2 == *param_1) || (iVar1 = FUN_01686710(piStack_18 + 4), iVar1 < 0)) {
            if (*(char *)(param_3[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = piStack_18;
            }
            else {
              uVar4 = 0;
              param_3 = param_3;
            }
            goto LAB_00c4c109;
          }
        }
LAB_00c4c21a:
        uStack_8 = 0xffffffff;
        puVar3 = (undefined4 *)FUN_00c4c380(auStack_20,0,param_4,param_5);
        *param_2 = *puVar3;
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      iVar1 = FUN_01686710(param_4);
      if (-1 < iVar1) goto LAB_00c4c21a;
      param_3 = *(int **)(*param_1 + 8);
      uVar4 = 0;
      goto LAB_00c4c109;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar1 = FUN_01686710(param_3 + 4);
    if (-1 < iVar1) goto LAB_00c4c21a;
  }
  uVar4 = 1;
LAB_00c4c109:
  FUN_00c4bd50(param_2,uVar4,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28442 ; VA 0x00c4c24c ; Catch_All@00c4c24c */

void Catch_All_00c4c24c(void)

{
  int unaff_EBP;
  
  FUN_00c4e6a0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28443 ; VA 0x00c4c270 ; FUN_00c4c270 */

void __thiscall
FUN_00c4c270(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  bool bVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a420;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar3 = true;
  piVar1 = (int *)*param_1;
  piVar4 = piVar1;
  if (*(char *)(piVar1[1] + 0xd) == '\0') {
    piVar1 = (int *)piVar1[1];
    do {
      piVar4 = piVar1;
      if (param_3 == '\0') {
        bVar3 = *param_4 < (uint)piVar4[4];
      }
      else {
        bVar3 = *param_4 <= (uint)piVar4[4];
      }
      if (bVar3 == false) {
        piVar1 = (int *)piVar4[2];
      }
      else {
        piVar1 = (int *)*piVar4;
      }
    } while (*(char *)((int)piVar1 + 0xd) == '\0');
    piVar1 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar4;
  if (bVar3 != false) {
    if (piVar4 == (int *)*piVar1) {
      bVar3 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00c4c2f7;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  piVar1 = _param_3;
  if (*param_4 <= (uint)_param_3[4]) {
    FUN_00c4e650(param_5);
    *param_2 = piVar1;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00c4c2f7:
  puVar2 = (undefined4 *)FUN_00c4bbf0(&param_3,bVar3,piVar4,param_4,param_5);
  *param_2 = *puVar2;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28444 ; VA 0x00c4c362 ; Catch_All@00c4c362 */

void Catch_All_00c4c362(void)

{
  int unaff_EBP;
  
  FUN_00c4e650(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28445 ; VA 0x00c4c380 ; FUN_00c4c380 */

void __thiscall
FUN_00c4c380(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_4;
  puStack_c = &LAB_0180a430;
  pvStack_10 = ExceptionList;
  bVar6 = true;
  uStack_8 = 0;
  puVar4 = (undefined4 *)((undefined4 *)*param_1)[1];
  puVar5 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)puVar4 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      iVar3 = FUN_01686710(puVar4 + 4);
      bVar6 = iVar3 < 0;
    }
    else {
      iVar3 = FUN_01686710(uVar1);
      bVar6 = -1 < iVar3;
    }
    puVar5 = puVar4;
    if (bVar6 == false) {
      puVar4 = (undefined4 *)puVar4[2];
    }
    else {
      puVar4 = (undefined4 *)*puVar4;
    }
  }
  param_3 = puVar5;
  if (bVar6 != false) {
    if (puVar5 == *(undefined4 **)*param_1) {
      bVar6 = true;
      goto LAB_00c4c40f;
    }
    FUN_0056f560();
  }
  puVar4 = param_3;
  iVar3 = FUN_01686710(uVar1);
  uVar2 = param_5;
  if (-1 < iVar3) {
    FUN_00ba2000();
    FUN_01674ea0(uVar2,0x30);
    *param_2 = puVar4;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00c4c40f:
  puVar4 = (undefined4 *)FUN_00c4bd50(&param_3,bVar6,puVar5,uVar1,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28446 ; VA 0x00c4c48d ; Catch_All@00c4c48d */

void Catch_All_00c4c48d(void)

{
  int unaff_EBP;
  
  FUN_00c4e6a0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28447 ; VA 0x00c4c4b0 ; FUN_00c4c4b0 */

undefined4 * __thiscall
FUN_00c4c4b0(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  bool bVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_4;
  puStack_c = &LAB_0180a440;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar5 = true;
  piVar1 = (int *)*param_1;
  piVar6 = piVar1;
  if (*(char *)(piVar1[1] + 0xd) == '\0') {
    piVar3 = (int *)piVar1[1];
    do {
      piVar6 = piVar3;
      if (param_3 == '\0') {
        bVar5 = *param_4 < piVar6[4];
      }
      else {
        bVar5 = *param_4 <= piVar6[4];
      }
      if (bVar5 == false) {
        piVar3 = (int *)piVar6[2];
      }
      else {
        piVar3 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar3 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar6;
  if (bVar5 != false) {
    if (piVar6 == (int *)*piVar1) {
      bVar5 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00c4c542;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  if (*piVar2 <= _param_3[4]) {
    *param_2 = _param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
LAB_00c4c542:
  puVar4 = (undefined4 *)FUN_00898100(&param_3,bVar5,piVar6,piVar2,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28448 ; VA 0x00c4c5a5 ; Catch_All@00c4c5a5 */

void Catch_All_00c4c5a5(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28449 ; VA 0x00c4c5b0 ; FUN_00c4c5b0 */

void __thiscall FUN_00c4c5b0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180a450;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::LuaScriptFileDesc>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28450 ; VA 0x00c4c61e ; Catch_All@00c4c61e */

void Catch_All_00c4c61e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00c4d530(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28451 ; VA 0x00c4c640 ; FUN_00c4c640 */

void __thiscall FUN_00c4c640(byte *param_1,int *param_2,uint *param_3,int param_4)

{
  uint *puVar1;
  int *piVar2;
  byte bVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a468;
  pvStack_10 = ExceptionList;
  bVar3 = *param_1;
  ExceptionList = &pvStack_10;
  uVar7 = FUN_005702d0(param_3);
  FUN_009da8d0(&param_3,uVar7,iVar6,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (param_3 == (uint *)0x0) {
    uStack_8 = 0;
    piVar8 = (int *)FUN_01674e20(0x28);
    iVar6 = param_4;
    *piVar8 = 0;
    piVar8[1] = 0;
    piVar8[2] = 0;
    piVar8[3] = 0;
    piVar8[4] = 0;
    piVar8[5] = 0;
    piVar8[6] = 0;
    piVar8[7] = 0;
    piVar8[8] = 0;
    piVar8[9] = 0;
    FUN_0054ef60(param_4);
    piVar8[8] = 0;
    piVar8[9] = 0;
    piVar8[8] = *(int *)(iVar6 + 0x18);
    piVar8[9] = *(int *)(iVar6 + 0x1c);
    *(undefined4 *)(iVar6 + 0x18) = 0;
    *(undefined4 *)(iVar6 + 0x1c) = 0;
    uVar4 = *(uint *)(param_1 + 8);
    uVar9 = uVar4 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar9 = FUN_005c9310(uVar9);
      if (uVar9 <= *(uint *)(param_1 + 4)) {
        uVar9 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar9);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar9) {
      param_3 = (uint *)0x1;
      uVar10 = uVar4 >> 1;
      if ((uVar4 >> 1) + uVar4 <= uVar9) {
        uVar10 = 1;
      }
      uVar9 = FUN_005c9310(uVar10 + uVar4);
      puVar1 = (uint *)(param_1 + 4);
      if (uVar9 != *puVar1) {
        param_3 = puVar1;
        FUN_005d2b00(uVar9);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar5 = (undefined4 *)*puVar11;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_3) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_3) * 4) == 0) {
            *piVar2 = (int)puVar11;
            puVar11 = puVar5;
          }
          else {
            *puVar11 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          puVar5 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar8[1] = uVar7;
    uVar9 = *(uint *)(param_1 + 4);
    iVar6 = *(int *)(param_1 + 0x14);
    puVar11 = (undefined4 *)(iVar6 + (uVar7 % uVar9) * 4);
    if (*(int *)(iVar6 + (uVar7 % uVar9) * 4) == 0) {
      piVar2 = (int *)(iVar6 + uVar9 * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar9) * 4) = piVar8;
      }
      *puVar11 = piVar2;
      *piVar8 = *piVar2;
      *piVar2 = (int)piVar8;
    }
    else {
      *piVar8 = *(int *)*puVar11;
      *(int **)*puVar11 = piVar8;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = (int)piVar8;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  *param_2 = (int)param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28452 ; VA 0x00c4c850 ; FUN_00c4c850 */

int FUN_00c4c850(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead790,&LAB_0063ee60);
      uVar3 = FUN_0063f700();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00bb26e0();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 28453 ; VA 0x00c4c960 ; thunk_FUN_00c51450 */

undefined * thunk_FUN_00c51450(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ae8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd3fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd3fc);
    if (DAT_01efd3fc == -1) {
      uStack_8 = 0;
      FUN_00cbe0b0();
      FUN_016f3654(&LAB_01895180);
      FUN_016f37bf(&DAT_01efd3fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd398;
}



/* FUNCTION 28454 ; VA 0x00c4c970 ; thunk_FUN_00c514e0 */

undefined * thunk_FUN_00c514e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aeac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd4cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd4cc);
    if (DAT_01efd4cc == -1) {
      uStack_8 = 0;
      FUN_00cbe110();
      FUN_016f3654(&LAB_018951a0);
      FUN_016f37bf(&DAT_01efd4cc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd468;
}



/* FUNCTION 28455 ; VA 0x00c4c980 ; thunk_FUN_00c51570 */

undefined * thunk_FUN_00c51570(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aecc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd464) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd464);
    if (DAT_01efd464 == -1) {
      uStack_8 = 0;
      FUN_00cbe170();
      FUN_016f3654(&LAB_018951c0);
      FUN_016f37bf(&DAT_01efd464);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd400;
}



/* FUNCTION 28456 ; VA 0x00c4c990 ; thunk_FUN_00c51600 */

undefined * thunk_FUN_00c51600(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aeec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd534) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd534);
    if (DAT_01efd534 == -1) {
      uStack_8 = 0;
      FUN_00cbe1d0();
      FUN_016f3654(&LAB_018951e0);
      FUN_016f37bf(&DAT_01efd534);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd4d0;
}



/* FUNCTION 28457 ; VA 0x00c4c9a0 ; FUN_00c4c9a0 */

uint * __thiscall FUN_00c4c9a0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  uint *puVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint *puVar9;
  int *piStack_30;
  int *piStack_2c;
  uint *puStack_28;
  undefined4 *puStack_24;
  int **ppiStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180a490;
  pvStack_10 = ExceptionList;
  piVar8 = *(int **)(param_1 + 0x2c);
  puVar6 = (uint *)ExceptionList;
  if (piVar8 != (int *)0x0) {
    piStack_1c = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
      piStack_1c = *(int **)(param_1 + 0x30);
      piVar8 = *(int **)(param_1 + 0x2c);
    }
    puVar6 = (uint *)piVar8[1];
    puVar9 = (uint *)*piVar8;
    iStack_8 = 0;
    puStack_28 = puVar6;
    if (puVar9 != puVar6) {
      do {
        piStack_2c = (int *)puVar9[1];
        piStack_18 = (int *)*param_2;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          piStack_2c[1] = piStack_2c[1] + 1;
          UNLOCK();
          piStack_2c = (int *)puVar9[1];
        }
        piStack_30 = (int *)*puVar9;
        puVar2 = (undefined4 *)*piStack_18;
        uStack_11 = *(undefined *)((int)piStack_30 + 0x21);
        iStack_8._0_1_ = 1;
        puVar3 = (undefined4 *)puVar2[1];
        puVar7 = puVar2;
        if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
          do {
            if ((int *)puVar3[4] < piStack_30) {
              puVar4 = (undefined4 *)puVar3[2];
            }
            else {
              puVar4 = (undefined4 *)*puVar3;
              puVar7 = puVar3;
            }
            puVar3 = puVar4;
          } while (*(char *)((int)puVar4 + 0xd) == '\0');
          if ((puVar7 == puVar2) || (piStack_30 < (int *)puVar7[4])) goto LAB_00c4ca62;
        }
        else {
LAB_00c4ca62:
          ppiStack_20 = &piStack_30;
          iVar5 = FUN_00c4baf0(&DAT_018bdeda,&ppiStack_20,&uStack_12);
          FUN_00c4beb0(&puStack_24,puVar7,iVar5 + 0x10,iVar5);
          puVar7 = puStack_24;
        }
        *(undefined *)(puVar7 + 6) = uStack_11;
        (**(code **)(*piStack_30 + 0x1c))(1);
        piVar8 = piStack_2c;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar5 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            piVar1 = piVar8 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        puVar6 = (uint *)FUN_00c4c9a0(param_2);
        puVar9 = puVar9 + 2;
      } while (puVar9 != puStack_28);
    }
    piVar8 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar5 = *piVar1;
      puVar6 = (uint *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (uint *)(**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          puVar6 = (uint *)(**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 28458 ; VA 0x00c4cb20 ; FUN_00c4cb20 */

undefined4 * __thiscall
FUN_00c4cb20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_00c4b770();
  FUN_009cb970(uVar1,param_3,param_4,CONCAT44(uStack_1c,uStack_20),0);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::PlayerScripts,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::PlayerScripts::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::PlayerScripts,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::PlayerScripts::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28459 ; VA 0x00c4cbf0 ; FUN_00c4cbf0 */

undefined4 * __fastcall FUN_00c4cbf0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [8];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a516;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::PlayerScripts,class_RBX::Instance>::vftable;
  uVar2 = FUN_00c4b770();
  param_1[3] = uVar2;
  param_1[0x15] = RBX::IScriptFilter::vftable;
  *param_1 = RBX::PlayerScripts::vftable;
  param_1[0x15] = RBX::PlayerScripts::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  puVar1 = param_1 + 0x1b;
  *(undefined *)(param_1 + 0x1a) = 0;
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x1c] = 0;
  puStack_14 = puVar1;
  uVar2 = FUN_0089c660();
  *puVar1 = uVar2;
  puVar1 = param_1 + 0x1e;
  *(undefined *)(param_1 + 0x1d) = 0;
  uStack_8._0_1_ = 6;
  *puVar1 = 0;
  param_1[0x1f] = 0;
  puStack_14 = puVar1;
  uVar2 = FUN_0089c660();
  *puVar1 = uVar2;
  puStack_14 = param_1 + 0x21;
  *(undefined *)(param_1 + 0x20) = 0;
  uStack_8._0_1_ = 7;
  *puStack_14 = 0;
  param_1[0x22] = 0;
  uVar2 = FUN_0089c660();
  param_1[0x21] = uVar2;
  puStack_14 = param_1 + 0x24;
  *(undefined *)(param_1 + 0x23) = 0;
  uStack_8._0_1_ = 8;
  *puStack_14 = 0;
  param_1[0x25] = 0;
  uVar2 = FUN_0089c660();
  param_1[0x24] = uVar2;
  uStack_8._0_1_ = 9;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("PlayerScripts",0xd);
  uStack_8._0_1_ = 10;
  FUN_008a6520(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    uVar3 = auStack_38[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_38[0] - 4);
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  puStack_14 = (undefined4 *)0x0;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  if (DAT_01d687c4 == '\0') {
    puStack_14 = (undefined4 *)0x1;
    FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  }
  puStack_14 = (undefined4 *)0x4;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x5;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x0;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x1;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x2;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x0;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x1;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x2;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x0;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x1;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  puStack_14 = (undefined4 *)0x2;
  FUN_00c4c4b0(auStack_20,0,&puStack_14,puStack_18);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28460 ; VA 0x00c4cf10 ; FUN_00c4cf10 */

undefined4 * __fastcall FUN_00c4cf10(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a538;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00c4cfe0();
  uStack_8 = 0;
  *param_1 = RBX::
             DescribedCreatable<class_RBX::StarterCharacterScripts,class_RBX::StarterPlayerScripts>
             ::vftable;
  uVar1 = FUN_00c4b870();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::StarterCharacterScripts::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("StarterCharacterScripts",0x17);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28461 ; VA 0x00c4cfe0 ; FUN_00c4cfe0 */

undefined4 * __fastcall FUN_00c4cfe0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a589;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::StarterPlayerScripts,class_RBX::Instance>::vftable;
  uVar1 = FUN_00c4b970();
  param_1[3] = uVar1;
  *param_1 = RBX::StarterPlayerScripts::vftable;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  *(undefined2 *)(param_1 + 0x18) = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("StarterPlayerScripts",0x14);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28462 ; VA 0x00c4d0c0 ; FUN_00c4d0c0 */

void __fastcall FUN_00c4d0c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::PlayerScripts>::vftable;
  uVar1 = FUN_00c4b770(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28463 ; VA 0x00c4d100 ; FUN_00c4d100 */

void __fastcall FUN_00c4d100(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::StarterCharacterScripts>::vftable;
  uVar1 = FUN_00c4b870(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28464 ; VA 0x00c4d140 ; FUN_00c4d140 */

void __fastcall FUN_00c4d140(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::StarterPlayerScripts>::vftable;
  uVar1 = FUN_00c4b970(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28465 ; VA 0x00c4d180 ; thunk_FUN_00c4d300 */

void __fastcall thunk_FUN_00c4d300(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x58);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x54);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28466 ; VA 0x00c4d190 ; FUN_00c4d190 */

void __fastcall FUN_00c4d190(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x14);
  return;
}



/* FUNCTION 28467 ; VA 0x00c4d1a0 ; FUN_00c4d1a0 */

void __fastcall FUN_00c4d1a0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00882a90(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28468 ; VA 0x00c4d200 ; FUN_00c4d200 */

void __fastcall FUN_00c4d200(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c4e6c0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28469 ; VA 0x00c4d260 ; FUN_00c4d260 */

void __fastcall FUN_00c4d260(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056cac0();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 28470 ; VA 0x00c4d2f0 ; FUN_00c4d2f0 */

void __fastcall FUN_00c4d2f0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056cac0();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 28471 ; VA 0x00c4d300 ; FUN_00c4d300 */

void __fastcall FUN_00c4d300(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x58);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x54);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28472 ; VA 0x00c4d3a0 ; FUN_00c4d3a0 */

undefined4 * __thiscall FUN_00c4d3a0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piStack_8;
  
  piVar1 = param_2;
  puVar3 = (undefined4 *)*param_1;
  puVar4 = puVar3;
  puVar5 = (undefined4 *)puVar3[1];
  piStack_8 = param_1;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    do {
      puVar4 = puVar5;
      iVar2 = FUN_01686710(piVar1);
      if (iVar2 < 0) {
        puVar5 = (undefined4 *)puVar4[2];
        puVar4 = puVar3;
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    puVar3 = (undefined4 *)*piStack_8;
  }
  if ((puVar4 != puVar3) && (iVar2 = FUN_01686710(puVar4 + 4), -1 < iVar2)) {
    return puVar4 + 10;
  }
  piStack_8 = piVar1;
  iVar2 = FUN_00c4ba70(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_00c4c0c0(&param_2,puVar4,iVar2 + 0x10,iVar2);
  return param_2 + 10;
}



/* FUNCTION 28473 ; VA 0x00c4d440 ; FUN_00c4d440 */

undefined4 __thiscall FUN_00c4d440(undefined4 param_1,byte param_2)

{
  FUN_00c4d300();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28474 ; VA 0x00c4d470 ; FUN_00c4d470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c4d470(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GameBasicSettings::ComputerCameraMovementMode>::
             vftable;
  _DAT_01f04498 = _DAT_01f04498 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28475 ; VA 0x00c4d4a0 ; FUN_00c4d4a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c4d4a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GameBasicSettings::ComputerMovementMode>::vftable;
  _DAT_01f044a8 = _DAT_01f044a8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28476 ; VA 0x00c4d4d0 ; FUN_00c4d4d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c4d4d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GameBasicSettings::TouchCameraMovementMode>::
             vftable;
  _DAT_01f04490 = _DAT_01f04490 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28477 ; VA 0x00c4d500 ; FUN_00c4d500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c4d500(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GameBasicSettings::TouchMovementMode>::vftable;
  _DAT_01f044a0 = _DAT_01f044a0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28478 ; VA 0x00c4d530 ; FUN_00c4d530 */

int __thiscall FUN_00c4d530(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x48);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x34);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00c4d618;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  uVar1 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x1c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00c4d618;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00c4d618:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4c);
  }
  return param_1;
}



/* FUNCTION 28479 ; VA 0x00c4d620 ; FUN_00c4d620 */

int __thiscall FUN_00c4d620(int param_1,byte param_2)

{
  FUN_009abb30();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x90),0x14);
  FUN_009abb30();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x84),0x14);
  FUN_009abb30();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x78),0x14);
  FUN_009abb30();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x6c),0x14);
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  return param_1;
}



/* FUNCTION 28480 ; VA 0x00c4d6d0 ; FUN_00c4d6d0 */

/* WARNING: Type propagation algorithm not settling */

void __fastcall FUN_00c4d6d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  undefined *puVar4;
  undefined uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined **ppuVar8;
  int iVar9;
  undefined4 *******pppppppuVar10;
  undefined4 *puVar11;
  undefined **ppuVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  char cVar16;
  int iVar17;
  undefined4 *******pppppppuVar18;
  undefined8 uVar19;
  undefined4 uVar20;
  undefined auStack_170 [32];
  undefined auStack_150 [8];
  int aiStack_148 [5];
  uint uStack_134;
  undefined4 *******apppppppuStack_130 [4];
  int iStack_120;
  uint uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined8 uStack_110;
  undefined4 uStack_108;
  int iStack_f8;
  uint uStack_f4;
  undefined auStack_f0 [4];
  undefined *puStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  uint auStack_cc [4];
  undefined4 uStack_bc;
  uint uStack_b8;
  uint auStack_b4 [4];
  undefined4 uStack_a4;
  uint uStack_a0;
  int iStack_9c;
  int *piStack_98;
  undefined4 *******apppppppuStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  undefined auStack_70 [8];
  ushort auStack_68 [8];
  int iStack_58;
  int *piStack_54;
  int iStack_50;
  undefined4 *puStack_4c;
  undefined4 *******apppppppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  int iStack_30;
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aa35;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  if (*(char *)(param_1 + 0x60) != '\0') {
    return;
  }
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efcd38) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01efcd38), DAT_01efcd38 == -1)) {
    uStack_8 = 0;
    uVar19 = FUN_0152dab0("Systems","InstallDefaultScripts",0xffffffff);
    DAT_01efcd34 = (undefined4)((ulonglong)uVar19 >> 0x20);
    DAT_01efcd30 = (undefined4)uVar19;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efcd38);
  }
  uStack_d4 = DAT_01efcd30;
  uStack_118 = DAT_01efcd30;
  uStack_d8 = DAT_01efcd34;
  uStack_114 = DAT_01efcd34;
  uStack_110 = FUN_0152d930(DAT_01efcd30,DAT_01efcd34);
  iStack_7c = 0;
  iStack_78 = 0;
  iStack_74 = 0;
  iStack_f8 = 0;
  uStack_f4 = 7;
  uStack_108 = (undefined4 *)((uint)uStack_108._2_2_ << 0x10);
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  uStack_84 = 0;
  uStack_80 = 0xf;
  apppppppuStack_94[0] = (undefined4 *******)((uint)apppppppuStack_94[0] & 0xffffff00);
  FUN_005542c0("rbxasset://scripts/PlayerScripts",0x20);
  uStack_8._0_1_ = 4;
  FUN_009cbbb0(apppppppuStack_94);
  uStack_8._0_1_ = 5;
  uVar6 = FUN_008cb670(auStack_cc,apppppppuStack_94);
  uStack_8._0_1_ = 6;
  uVar6 = FUN_0151a8d0(auStack_68,uVar6);
  uStack_8._0_1_ = 7;
  FUN_0054f050(uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar7 = (undefined4 *)FUN_01688610();
  if (&uStack_108 != puVar7) {
    puVar11 = puVar7 + 4;
    if (7 < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    FUN_0058ed10(puVar7,*puVar11);
  }
  FUN_00550800();
  FUN_00550800();
  uStack_8._0_1_ = 5;
  if (0xf < uStack_b8) {
    uVar13 = uStack_b8 + 1;
    uVar14 = auStack_cc[0];
    if (0xfff < uVar13) {
      uVar14 = *(uint *)(auStack_cc[0] - 4);
      uVar13 = uStack_b8 + 0x24;
      if (0x1f < (auStack_cc[0] - uVar14) - 4) {
LAB_00c4e621:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar13);
  }
  uStack_bc = 0;
  uStack_b8 = 0xf;
  auStack_cc[0] = auStack_cc[0] & 0xffffff00;
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_80) {
    uVar14 = uStack_80 + 1;
    pppppppuVar10 = apppppppuStack_94[0];
    if (0xfff < uVar14) {
      pppppppuVar10 = (undefined4 *******)apppppppuStack_94[0][-1];
      uVar14 = uStack_80 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_94[0] + (-4 - (int)pppppppuVar10))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar10,uVar14);
  }
  uStack_8._0_1_ = 9;
  uStack_84 = 0;
  uStack_80 = 0xf;
  apppppppuStack_94[0] = (undefined4 *******)((uint)apppppppuStack_94[0] & 0xffffff00);
  uStack_18 = 8;
  if (iStack_f8 != 0) {
    puVar7 = &uStack_108;
    if (7 < uStack_f4) {
      puVar7 = uStack_108;
    }
    iVar17 = iStack_f8 * 2;
    puVar11 = &uStack_108;
    if (7 < uStack_f4) {
      puVar11 = uStack_108;
    }
    uVar6 = FUN_01686580();
    FUN_01685a20(puVar11,(int)puVar7 + iVar17,apppppppuStack_94,uVar6);
  }
  FUN_0063a800(apppppppuStack_94,&uStack_108,&iStack_7c,1);
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_80) {
    uVar14 = uStack_80 + 1;
    pppppppuVar10 = apppppppuStack_94[0];
    if (0xfff < uVar14) {
      pppppppuVar10 = (undefined4 *******)apppppppuStack_94[0][-1];
      uVar14 = uStack_80 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_94[0] + (-4 - (int)pppppppuVar10))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar10,uVar14);
  }
  auStack_f0[0] = 0;
  iStack_50 = 0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_50);
  ppuVar12 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar12 = ppuVar8;
  }
  puStack_ec = *ppuVar12;
  iStack_e8 = 0;
  uStack_e4 = 0x3f800000;
  uStack_e0 = 0;
  iStack_dc = 0;
  iVar17 = *(int *)(param_1 + 0x34);
  uStack_8._0_1_ = 10;
  if ((iVar17 != 0) && (param_1 = iVar17, *(int *)(iVar17 + 0x34) != 0)) {
    param_1 = FUN_005c8ac0();
  }
  if (param_1 == 0) {
LAB_00c4da47:
    iStack_50 = 0;
  }
  else {
    iVar17 = *(int *)(param_1 + 0xc);
    iVar9 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar9 + 0x1da) <
        (uint)*(ushort *)(iVar17 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8)) goto LAB_00c4da47;
    iStack_50 = FUN_005c2760();
  }
  uVar14 = 0;
  if ((iStack_50 != 0) && (iStack_7c != iStack_78)) {
    uStack_28 = 0;
    uStack_18 = 0;
    iVar17 = iStack_7c;
    do {
      uStack_a4 = 0;
      uStack_a0 = 7;
      auStack_b4[0] = auStack_b4[0] & 0xffff0000;
      uStack_8._0_1_ = 0xb;
      iStack_38 = 0;
      uStack_34 = 0xf;
      apppppppuStack_48[0] = (undefined4 *******)((uint)apppppppuStack_48[0] & 0xffffff00);
      FUN_005542c0("scripts/PlayerScripts",0x15);
      uStack_8._0_1_ = 0xc;
      if (iStack_38 != 0) {
        pppppppuVar10 = apppppppuStack_48;
        if (0xf < uStack_34) {
          pppppppuVar10 = apppppppuStack_48[0];
        }
        iVar9 = (int)pppppppuVar10 + iStack_38;
        pppppppuVar10 = apppppppuStack_48;
        if (0xf < uStack_34) {
          pppppppuVar10 = apppppppuStack_48[0];
        }
        uVar6 = FUN_01686580();
        FUN_01685950(pppppppuVar10,iVar9,auStack_b4,uVar6);
        uVar14 = uStack_28;
      }
      uStack_8._0_1_ = 0xb;
      if (0xf < uStack_34) {
        uVar13 = uStack_34 + 1;
        pppppppuVar10 = apppppppuStack_48[0];
        if (0xfff < uVar13) {
          pppppppuVar10 = (undefined4 *******)apppppppuStack_48[0][-1];
          uVar13 = uStack_34 + 0x24;
          if (0x1f < (uint)((int)apppppppuStack_48[0] + (-4 - (int)pppppppuVar10)))
          goto LAB_00c4e621;
        }
        FUN_01674ea0(pppppppuVar10,uVar13);
      }
      iStack_38 = 0;
      uStack_34 = 0xf;
      apppppppuStack_48[0] = (undefined4 *******)((uint)apppppppuStack_48[0] & 0xffffff00);
      uStack_8._0_1_ = 0xd;
      FUN_01688610();
      FUN_01686150(iVar17);
      FUN_005569d0(apppppppuStack_94);
      uStack_8._0_1_ = 0xe;
      pppppppuVar10 = apppppppuStack_94;
      if (0xf < uStack_80) {
        pppppppuVar10 = apppppppuStack_94[0];
      }
      FUN_009cc450(auStack_cc,pppppppuVar10);
      uVar20 = 1;
      uStack_8._0_1_ = 0xf;
      uVar6 = FUN_008ccd70(1);
      FUN_008cdc80(&iStack_30,auStack_cc,uVar6,uVar20);
      uStack_8._0_1_ = 0x10;
      if (iStack_30 != 0) {
        FUN_0054f050(iVar17);
        iStack_58 = 0;
        piStack_54 = (int *)&DAT_00000007;
        auStack_68[0] = 0;
        uStack_8._0_1_ = 0x12;
        iStack_38 = 0;
        uStack_34 = 0xf;
        apppppppuStack_48[0] = (undefined4 *******)((uint)apppppppuStack_48[0] & 0xffffff00);
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8._0_1_ = 0x13;
        if (iStack_38 != 0) {
          pppppppuVar10 = apppppppuStack_48;
          if (0xf < uStack_34) {
            pppppppuVar10 = apppppppuStack_48[0];
          }
          iVar9 = (int)pppppppuVar10 + iStack_38;
          pppppppuVar10 = apppppppuStack_48;
          if (0xf < uStack_34) {
            pppppppuVar10 = apppppppuStack_48[0];
          }
          uVar6 = FUN_01686580();
          FUN_01685950(pppppppuVar10,iVar9,auStack_68,uVar6);
        }
        uStack_8._0_1_ = 0x12;
        if (0xf < uStack_34) {
          uVar14 = uStack_34 + 1;
          pppppppuVar10 = apppppppuStack_48[0];
          if (0xfff < uVar14) {
            pppppppuVar10 = (undefined4 *******)apppppppuStack_48[0][-1];
            uVar14 = uStack_34 + 0x24;
            if (0x1f < (uint)((int)apppppppuStack_48[0] + (-4 - (int)pppppppuVar10)))
            goto LAB_00c4e621;
          }
          FUN_01674ea0(pppppppuVar10,uVar14);
        }
        iStack_38 = 0;
        uStack_34 = 0xf;
        apppppppuStack_48[0] = (undefined4 *******)((uint)apppppppuStack_48[0] & 0xffffff00);
        uStack_8._0_1_ = 0x14;
        FUN_01688950(auStack_68);
        uStack_8._0_1_ = 0x11;
        FUN_00550800();
        FUN_00c506f0(aiStack_148,apppppppuStack_130,&uStack_d0);
        uStack_8._0_1_ = 0x15;
        puStack_4c = (undefined4 *)FUN_01674e20(0x4c);
        iVar9 = iStack_30;
        uStack_8._0_1_ = 0x16;
        if (puStack_4c == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)0x0;
          uVar14 = uStack_28;
        }
        else {
          uVar6 = FUN_005569d0(auStack_68);
          uVar14 = uStack_28 | 1;
          *puStack_4c = uStack_d0;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
          uStack_18 = uVar14;
          FUN_0054ef60(uVar6);
          uStack_8 = 0x18;
          FUN_0054ef60(aiStack_148);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
          FUN_0054ef60(iVar9);
          puVar7 = puStack_4c;
        }
        uStack_8 = 0x1a;
        iStack_9c = 0;
        piStack_98 = (int *)0x0;
        FUN_00c4c5b0(puVar7,uStack_d4);
        uStack_8 = 0x1b;
        if ((uVar14 & 1) != 0) {
          uVar14 = uVar14 & 0xfffffffe;
          FUN_005507b0();
        }
        uStack_18 = uVar14 | 0x20;
        uStack_8._0_1_ = 0x1d;
        iStack_38 = 0;
        uStack_34 = 0xf;
        apppppppuStack_48[0] = (undefined4 *******)((uint)apppppppuStack_48[0] & 0xffffff00);
        uStack_28 = uVar14;
        if (iStack_120 != 0) {
          pppppppuVar10 = apppppppuStack_130;
          if (7 < uStack_11c) {
            pppppppuVar10 = apppppppuStack_130[0];
          }
          iVar9 = iStack_120 * 2;
          pppppppuVar18 = apppppppuStack_130;
          if (7 < uStack_11c) {
            pppppppuVar18 = apppppppuStack_130[0];
          }
          uVar6 = FUN_01686580();
          FUN_01685a20(pppppppuVar18,(int)pppppppuVar10 + iVar9,apppppppuStack_48,uVar6);
        }
        FUN_0054ef60(apppppppuStack_48);
        piVar2 = piStack_98;
        if (piStack_98 != (int *)0x0) {
          LOCK();
          piStack_98[1] = piStack_98[1] + 1;
          UNLOCK();
        }
        uVar14 = uStack_28 | 0x60;
        iStack_58 = iStack_9c;
        piStack_54 = piStack_98;
        uStack_18 = uVar14;
        FUN_00c4b5c0(auStack_70);
        uStack_8._0_1_ = 0x1f;
        FUN_00c4c640(auStack_150,auStack_170,auStack_170);
        FUN_0056cac0();
        FUN_0056cac0();
        uVar14 = uVar14 & 0xffffffdf;
        uStack_8._0_1_ = 0x1c;
        uStack_28 = uVar14;
        uStack_18 = uVar14;
        if (0xf < uStack_34) {
          uVar13 = uStack_34 + 1;
          pppppppuVar10 = apppppppuStack_48[0];
          if (0xfff < uVar13) {
            pppppppuVar10 = (undefined4 *******)apppppppuStack_48[0][-1];
            uVar13 = uStack_34 + 0x24;
            if (0x1f < (uint)((int)apppppppuStack_48[0] + (-4 - (int)pppppppuVar10)))
            goto LAB_00c4e621;
          }
          FUN_01674ea0(pppppppuVar10,uVar13);
        }
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar9 = piVar2[1] + -1;
          piVar2[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar9 = piVar2[2] + -1;
            piVar2[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 0x11;
        if (0xf < uStack_134) {
          uVar13 = uStack_134 + 1;
          iVar9 = aiStack_148[0];
          if (0xfff < uVar13) {
            iVar9 = *(int *)(aiStack_148[0] + -4);
            uVar13 = uStack_134 + 0x24;
            if (0x1f < (aiStack_148[0] - iVar9) - 4U) goto LAB_00c4e621;
          }
          FUN_01674ea0(iVar9,uVar13);
        }
        FUN_00550800();
      }
      piVar2 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar9 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar9 = *piVar1 + -1;
          *piVar1 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      uStack_8._0_1_ = 0xe;
      if (0xf < uStack_b8) {
        uVar15 = uStack_b8 + 1;
        uVar13 = auStack_cc[0];
        if (0xfff < uVar15) {
          uVar13 = *(uint *)(auStack_cc[0] - 4);
          uVar15 = uStack_b8 + 0x24;
          if (0x1f < (auStack_cc[0] - uVar13) - 4) goto LAB_00c4e621;
        }
        FUN_01674ea0(uVar13,uVar15);
      }
      uStack_bc = 0;
      uStack_b8 = 0xf;
      auStack_cc[0] = auStack_cc[0] & 0xffffff00;
      uStack_8._0_1_ = 0xd;
      if (0xf < uStack_80) {
        uVar13 = uStack_80 + 1;
        pppppppuVar10 = apppppppuStack_94[0];
        if (0xfff < uVar13) {
          pppppppuVar10 = (undefined4 *******)apppppppuStack_94[0][-1];
          uVar13 = uStack_80 + 0x24;
          if (0x1f < (uint)((int)apppppppuStack_94[0] + (-4 - (int)pppppppuVar10)))
          goto LAB_00c4e621;
        }
        FUN_01674ea0(pppppppuVar10,uVar13);
      }
      uStack_84 = 0;
      uStack_80 = 0xf;
      apppppppuStack_94[0] = (undefined4 *******)((uint)apppppppuStack_94[0] & 0xffffff00);
      uStack_8._0_1_ = 10;
      if (7 < uStack_a0) {
        uVar13 = uStack_a0 * 2 + 2;
        uVar15 = auStack_b4[0];
        if (0xfff < uVar13) {
          uVar15 = *(uint *)(auStack_b4[0] - 4);
          uVar13 = uStack_a0 * 2 + 0x25;
          if (0x1f < (auStack_b4[0] - uVar15) - 4) goto LAB_00c4e621;
        }
        FUN_01674ea0(uVar15,uVar13);
      }
      iVar17 = iVar17 + 0x18;
    } while (iVar17 != iStack_78);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  piStack_24 = (int *)FUN_00575b10();
  uStack_8._0_1_ = 0x20;
  cStack_11 = '\0';
  cStack_12 = '\0';
  iVar17 = FUN_00c4c850(iStack_1c);
  if (iVar17 != 0) {
    iVar17 = FUN_00917510();
    if (iVar17 != 0) {
      iStack_58 = 0;
      piStack_54 = (int *)&DAT_0000000f;
      auStack_68[0] = auStack_68[0] & 0xff00;
      FUN_005542c0("Sound",5);
      uStack_8._0_1_ = 0x21;
      iVar17 = FUN_008a1240(auStack_68);
      cStack_11 = iVar17 != 0;
      uStack_8._0_1_ = 0x20;
      FUN_005507b0();
    }
    iVar17 = FUN_00bb2a60();
    if (iVar17 != 0) {
      uStack_bc = 0;
      uStack_b8 = 0xf;
      auStack_cc[0] = auStack_cc[0] & 0xffffff00;
      FUN_005542c0("CameraScript",0xc);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
      uVar13 = uVar14 | 2;
      uStack_18 = uVar13;
      iVar17 = FUN_008a1240(auStack_cc);
      if (iVar17 == 0) {
        piStack_54 = (int *)&DAT_0000000f;
        auStack_68[0] = auStack_68[0] & 0xff00;
        iStack_58 = iVar17;
        FUN_005542c0("ControlScript",0xd);
        uStack_8 = 0x23;
        uVar13 = uVar14 | 6;
        uStack_18 = uVar13;
        iVar17 = FUN_008a1240(auStack_68);
        cStack_12 = '\0';
        if (iVar17 != 0) goto LAB_00c4e12e;
      }
      else {
LAB_00c4e12e:
        cStack_12 = '\x01';
      }
      if ((uVar13 & 4) != 0) {
        FUN_005507b0();
      }
      uStack_8._0_1_ = 0x20;
      uStack_8._1_3_ = 0;
      FUN_005507b0();
    }
    cVar16 = cStack_11;
    if (cStack_11 != '\0') goto LAB_00c4e28d;
  }
  cVar16 = cStack_11;
  puVar7 = (undefined4 *)FUN_0060dcd0(&iStack_30,iStack_1c);
  puVar3 = PTR_s_StarterPlayerScriptsCommon_0196aea0;
  uStack_a4 = 0;
  uStack_a0 = 7;
  auStack_b4[0] = auStack_b4[0] & 0xffff0000;
  uStack_8._0_1_ = 0x25;
  uVar6 = FUN_01686580();
  FUN_01685950(puVar3,0,auStack_b4,uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
  puVar11 = (undefined4 *)FUN_00c4d3a0(auStack_b4);
  uVar6 = *puVar7;
  uVar20 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *puVar11 = uVar6;
  piVar2 = (int *)puVar11[1];
  puVar11[1] = uVar20;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar17 = piVar2[1] + -1;
    piVar2[1] = iVar17;
    UNLOCK();
    if (iVar17 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar17 = piVar2[2] + -1;
      piVar2[2] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 0x24;
  if (7 < uStack_a0) {
    uVar14 = uStack_a0 * 2 + 2;
    uVar13 = auStack_b4[0];
    if (0xfff < uVar14) {
      uVar13 = *(uint *)(auStack_b4[0] - 4);
      uVar14 = uStack_a0 * 2 + 0x25;
      if (0x1f < (auStack_b4[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar14);
  }
  piVar2 = piStack_2c;
  uStack_a4 = 0;
  uStack_a0 = 7;
  auStack_b4[0] = auStack_b4[0] & 0xffff0000;
  uStack_8._0_1_ = 0x20;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar17 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar17;
    UNLOCK();
    if (iVar17 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar17 = *piVar1 + -1;
      *piVar1 = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
LAB_00c4e28d:
  uVar6 = FUN_0060dcd0(&iStack_30,iStack_1c);
  puVar4 = PTR_s_StarterPlayerScripts_NewStructur_0196ae9c;
  puVar3 = PTR_s_StarterPlayerScripts_0196ae98;
  if (cStack_12 == '\0') {
    iStack_58 = 0;
    piStack_54 = (int *)0x7;
    auStack_68[0] = 0;
    uStack_8._0_1_ = 0x2b;
    uVar20 = FUN_01686580();
    FUN_01685950(puVar4,0,auStack_68,uVar20);
    uStack_8._0_1_ = 0x2c;
  }
  else {
    iStack_58 = 0;
    piStack_54 = (int *)0x7;
    auStack_68[0] = 0;
    uStack_8._0_1_ = 0x28;
    uVar20 = FUN_01686580();
    FUN_01685950(puVar3,0,auStack_68,uVar20);
    uStack_8._0_1_ = 0x29;
  }
  FUN_00c4d3a0(auStack_68);
  FUN_005587e0(uVar6);
  FUN_00550800();
  piVar2 = piStack_2c;
  uStack_8._0_1_ = 0x20;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar17 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar17;
    UNLOCK();
    if (iVar17 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar17 = *piVar1 + -1;
      *piVar1 = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar17 = iStack_1c;
  iVar9 = FUN_00c4c850(iStack_1c);
  if (iVar9 != 0) {
    iVar9 = FUN_00917510();
    if ((iVar9 != 0) && (cVar16 != '\0')) {
      puVar7 = (undefined4 *)FUN_0060dcd0(&iStack_30,iVar9);
      uStack_8._0_1_ = 0x2d;
      uVar6 = FUN_0054d730("StarterCharacterScripts",0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2e);
      puVar11 = (undefined4 *)FUN_00c4d3a0(uVar6);
      uVar6 = *puVar7;
      uVar20 = puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      *puVar11 = uVar6;
      piVar2 = (int *)puVar11[1];
      puVar11[1] = uVar20;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar9 = piVar2[1] + -1;
        piVar2[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar9 = piVar2[2] + -1;
          piVar2[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_00550800();
      uStack_8._0_1_ = 0x20;
      FUN_00550b30();
    }
  }
  piVar2 = piStack_24;
  if (iStack_e8 == 0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puVar7 = *(undefined4 **)(iStack_dc + (int)puStack_ec * 4);
  }
  for (; piStack_24 = piVar2, puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
    puVar11 = (undefined4 *)FUN_0060dcd0(&iStack_9c,iVar17);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x2f);
    uVar6 = *puVar11;
    uVar20 = puVar11[1];
    *puVar11 = 0;
    puVar11[1] = 0;
    FUN_00c4f9c0(&iStack_30,auStack_f0,&piStack_24,puVar7 + 2,uVar6,uVar20);
    piVar2 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar17 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar17 = *piVar1 + -1;
        *piVar1 = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_98;
    uStack_8._0_1_ = 0x20;
    if (piStack_98 != (int *)0x0) {
      LOCK();
      iVar17 = piStack_98[1] + -1;
      piStack_98[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*piStack_98)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar17 = *piVar1 + -1;
        *piVar1 = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_24;
    iVar17 = iStack_1c;
  }
  *(undefined *)(iVar17 + 0x60) = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
  FUN_00c4e6c0(piVar2[1]);
  piStack_24[1] = (int)piVar2;
  *piStack_24 = (int)piVar2;
  piStack_24[2] = (int)piVar2;
  uStack_20 = 0;
  FUN_01674ea0(piStack_24,0x30);
  FUN_00c4d260();
  FUN_00550800();
  iVar9 = iStack_78;
  iVar17 = iStack_7c;
  if (iStack_7c != 0) {
    for (; iVar17 != iVar9; iVar17 = iVar17 + 0x18) {
      FUN_00550800();
    }
    FUN_0054db70(iStack_7c,((iStack_74 - iStack_7c) / 0x18) * 0x18);
    iStack_7c = 0;
    iStack_78 = 0;
    iStack_74 = 0;
  }
  uStack_8 = 0x31;
  FUN_0152dda0(uStack_d4,uStack_d8,uStack_110);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28481 ; VA 0x00c4e640 ; FUN_00c4e640 */

void __fastcall FUN_00c4e640(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00c4d530(1);
  }
  return;
}



/* FUNCTION 28482 ; VA 0x00c4e650 ; FUN_00c4e650 */

void FUN_00c4e650(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_1,0x1c);
  return;
}



/* FUNCTION 28483 ; VA 0x00c4e6a0 ; FUN_00c4e6a0 */

void FUN_00c4e6a0(undefined4 param_1)

{
  FUN_00ba2000();
  FUN_01674ea0(param_1,0x30);
  return;
}



/* FUNCTION 28484 ; VA 0x00c4e6c0 ; FUN_00c4e6c0 */

void FUN_00c4e6c0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00c4e6c0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00ba2000();
    FUN_01674ea0(param_1,0x30);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 28485 ; VA 0x00c4e710 ; thunk_FUN_009abb30 */

void __fastcall thunk_FUN_009abb30(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar3 = iVar1;
  piVar4 = *(int **)(iVar1 + 4);
  ExceptionList = &pvStack_10;
  if (*(char *)((int)*(int **)(iVar1 + 4) + 0xd) == '\0') {
    do {
      FUN_0089c7e0(piVar4[2]);
      piVar2 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x14);
      piVar4 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar3 = *param_1;
  }
  *(int *)(iVar3 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28486 ; VA 0x00c4e720 ; FUN_00c4e720 */

bool FUN_00c4e720(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b9e640();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return true;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_009ec190();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return true;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b739e0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00c4e797;
  }
  param_1 = 0;
LAB_00c4e797:
  return param_1 != 0;
}



/* FUNCTION 28487 ; VA 0x00c4e7b0 ; FUN_00c4e7b0 */

bool FUN_00c4e7b0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return true;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b9e640();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return true;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_009ec190();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return true;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b739e0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00c4e856;
  }
  param_1 = 0;
LAB_00c4e856:
  return param_1 != 0;
}



/* FUNCTION 28488 ; VA 0x00c4e870 ; FUN_00c4e870 */

bool FUN_00c4e870(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00bb25e0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00c4e8a2;
  }
  param_1 = 0;
LAB_00c4e8a2:
  return param_1 != 0;
}



/* FUNCTION 28489 ; VA 0x00c4e8b0 ; FUN_00c4e8b0 */

int __thiscall FUN_00c4e8b0(byte *param_1,int param_2)

{
  byte bVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 8) != 0) {
    bVar1 = *param_1;
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005702d0(param_2);
    FUN_009da8d0(&param_2,uVar3,param_2,
                 -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
    if (param_2 != 0) {
      ExceptionList = pvStack_10;
      return param_2 + 0x20;
    }
  }
  uVar3 = FUN_0091a050("Unable to find key in unordered_map.");
  uStack_8 = 0;
  FUN_00917680(uVar3);
  pcVar2 = (code *)swi(3);
  iVar4 = (*pcVar2)();
  return iVar4;
}



/* FUNCTION 28490 ; VA 0x00c4e940 ; FUN_00c4e940 */

void FUN_00c4e940(void)

{
  FUN_009abb30();
  FUN_006eccd0();
  return;
}



/* FUNCTION 28491 ; VA 0x00c4e960 ; FUN_00c4e960 */

void FUN_00c4e960(void)

{
  FUN_009abb30();
  FUN_006eccd0();
  return;
}



/* FUNCTION 28492 ; VA 0x00c4e980 ; FUN_00c4e980 */

void FUN_00c4e980(void)

{
  FUN_009abb30();
  FUN_006eccd0();
  return;
}



/* FUNCTION 28493 ; VA 0x00c4e9a0 ; FUN_00c4e9a0 */

void FUN_00c4e9a0(void)

{
  FUN_009abb30();
  FUN_006eccd0();
  return;
}



/* FUNCTION 28494 ; VA 0x00c4e9c0 ; FUN_00c4e9c0 */

void FUN_00c4e9c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c51450();
    *param_2 = uVar3;
    iVar4 = FUN_00c51690();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28495 ; VA 0x00c4ea20 ; FUN_00c4ea20 */

void FUN_00c4ea20(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c514e0();
    *param_2 = uVar3;
    iVar4 = FUN_00c51700();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28496 ; VA 0x00c4ea80 ; FUN_00c4ea80 */

void FUN_00c4ea80(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c51570();
    *param_2 = uVar3;
    iVar4 = FUN_00c51770();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28497 ; VA 0x00c4eae0 ; FUN_00c4eae0 */

void FUN_00c4eae0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c51600();
    *param_2 = uVar3;
    iVar4 = FUN_00c517e0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28498 ; VA 0x00c4eb40 ; FUN_00c4eb40 */

void FUN_00c4eb40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c51450();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28499 ; VA 0x00c4eb80 ; FUN_00c4eb80 */

void FUN_00c4eb80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c514e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}


