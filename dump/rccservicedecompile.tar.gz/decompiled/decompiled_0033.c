/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 8250 ; VA 0x0068afb0 ; FUN_0068afb0 */

int FUN_0068afb0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a58a4;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  FUN_005c13e0(&param_2);
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_00000020;
  piStack_e4 = in_stack_00000024;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_01675290(uVar5);
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    uVar7 = param_2;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_2 - 4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 8251 ; VA 0x0068b160 ; FUN_0068b160 */

void FUN_0068b160(void)

{
  FUN_0068bd60();
  return;
}



/* FUNCTION 8252 ; VA 0x0068b170 ; FUN_0068b170 */

int FUN_0068b170(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_1 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0068b1a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*piVar2 + 4))();
        return iVar3;
      }
    }
  }
  return param_1;
}



/* FUNCTION 8253 ; VA 0x0068b1b0 ; FUN_0068b1b0 */

void FUN_0068b1b0(undefined4 *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0x34);
    if ((iVar2 != 0) && (param_2 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_2 = FUN_005c8ac0();
    }
    if ((((param_2 != 0) &&
         (iVar2 = *(int *)(param_2 + 0xc), iVar1 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
         (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005eee40(), iVar2 != 0)) &&
       (iVar2 = FUN_00688090(), iVar2 != 0)) {
      *param_1 = *(undefined4 *)(iVar2 + 0x3b88);
      return;
    }
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadcf4) &&
     (FUN_016f3809(&DAT_01eadcf4), DAT_01eadcf4 == -1)) {
    DAT_01eadcf0 = 0xffffffff;
    FUN_016f37bf(&DAT_01eadcf4);
  }
  *param_1 = DAT_01eadcf0;
  return;
}



/* FUNCTION 8254 ; VA 0x0068b280 ; FUN_0068b280 */

void FUN_0068b280(undefined4 param_1,undefined4 param_2)

{
  FUN_006880f0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 8255 ; VA 0x0068b2a0 ; FUN_0068b2a0 */

void FUN_0068b2a0(undefined4 param_1,undefined4 param_2)

{
  FUN_006882e0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 8256 ; VA 0x0068b2c0 ; thunk_FUN_005ee430 */

void thunk_FUN_005ee430(void)

{
  int iVar1;
  
  if (DAT_01ea96ec == 0) {
    iVar1 = FUN_005edc10();
    DAT_01ea96ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 8257 ; VA 0x0068b2d0 ; FUN_0068b2d0 */

undefined * __thiscall FUN_0068b2d0(int param_1,undefined *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  uint uVar9;
  char acStack_408 [1028];
  
  iVar2 = *(int *)(param_1 + 0x440);
  uVar9 = 0;
  iVar5 = *(int *)(param_1 + 0x444) - iVar2;
  iVar3 = iVar5 >> 0x1f;
  iVar5 = iVar5 / 0x3c + iVar3;
  if (iVar5 != iVar3) {
    piVar4 = (int *)(iVar2 + 0x20);
    do {
      if (*piVar4 == 2) {
        pcVar8 = (char *)(iVar2 + uVar9 * 0x3c);
        pcVar7 = pcVar8;
        if (0xf < *(uint *)(iVar2 + 0x14 + uVar9 * 0x3c)) {
          pcVar7 = *(char **)pcVar8;
        }
        pcVar6 = pcVar7;
        do {
          cVar1 = *pcVar6;
          pcVar6 = pcVar6 + 1;
          pcVar6[(int)(acStack_408 + (-1 - (int)pcVar7))] = cVar1;
        } while (cVar1 != '\0');
        pcVar7 = acStack_408;
        do {
          cVar1 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar1 != '\0');
        pcVar7[(int)(acStack_408 + -(int)(acStack_408 + 1))] = '|';
        FUN_00694630(*(undefined4 *)(pcVar8 + 0x18),
                     pcVar7 + (int)(acStack_408 + (1 - (int)(acStack_408 + 1))),10);
        if (DAT_01ee420b != '\0') {
          FUN_01677520(DAT_01ee420b,"getConnectedServer::: returning %s",acStack_408);
        }
        pcVar8 = acStack_408;
        *(undefined4 *)(param_2 + 0x10) = 0;
        *(undefined4 *)(param_2 + 0x14) = 0xf;
        *param_2 = 0;
        do {
          cVar1 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(acStack_408,(int)pcVar8 - (int)(acStack_408 + 1));
        return param_2;
      }
      uVar9 = uVar9 + 1;
      piVar4 = piVar4 + 0xf;
    } while (uVar9 < (uint)(iVar5 - iVar3));
  }
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  return param_2;
}



/* FUNCTION 8258 ; VA 0x0068b410 ; FUN_0068b410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_0068b410(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a58d0;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadfec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadfec,param_1);
    if (DAT_01eadfec == -1) {
      uStack_8 = 1;
      DAT_01eadfa8 = FUN_0068a6a0(0,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      DAT_01eadfb0 = 0;
      _DAT_01eadfb4 = 0;
      DAT_01eadfb0 = FUN_00601dc0();
      FUN_016dee4c(&DAT_01eadfb8,2);
      FUN_016f3654(FUN_0187dc40);
      FUN_016f37bf(&DAT_01eadfec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eadfa0;
}



/* FUNCTION 8259 ; VA 0x0068b4e0 ; FUN_0068b4e0 */

char * __fastcall FUN_0068b4e0(int param_1)

{
  switch(*(undefined4 *)(param_1 + 0x17c)) {
  case 0:
    return "_NotStartedYet";
  case 1:
    return "_BeforeConnected";
  case 2:
    return "_BeforeLoadFinished";
  case 3:
    return "_AfterLoadFinished";
  default:
    return "";
  }
}



/* FUNCTION 8260 ; VA 0x0068b520 ; FUN_0068b520 */

float10 FUN_0068b520(int param_1)

{
  int iVar1;
  int iVar2;
  float10 fVar3;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005eee40(), iVar2 != 0)) {
      fVar3 = (float10)FUN_006af9e0();
      return fVar3;
    }
  }
  return (float10)0;
}



/* FUNCTION 8261 ; VA 0x0068b590 ; FUN_0068b590 */

void __thiscall FUN_0068b590(int param_1,char *param_2,char param_3,undefined4 param_4,int param_5)

{
  undefined4 *puVar1;
  int iVar2;
  char cVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  char *pcVar9;
  undefined8 uVar10;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0068ee80(param_4,param_5,param_2);
  }
  cVar3 = FUN_0068bd00();
  if ((param_3 == '\0') || (cVar3 != '\0')) {
    FUN_016830f0(auStack_18);
    uVar10 = FUN_016f3ec0();
    if ((cVar3 == '\0') || (pcVar9 = "ConnectionFailure", *(char *)(param_1 + 0x15f) != '\0')) {
      pcVar9 = param_2;
    }
    FUN_0068d5d0("ClientNetwork",pcVar9,cVar3,uVar10);
    if (DAT_01eadf30 != 0) {
      if ((cVar3 == '\0') || (pcVar9 = "ConnectionFailure", *(char *)(param_1 + 0x15f) != '\0')) {
        pcVar9 = param_2;
      }
      FUN_0151f6f0(DAT_01eadf30,0,0);
      iStack_8 = 0;
      FUN_0151f850("Metric",pcVar9);
      piVar5 = (int *)(param_1 + 0x180);
      if (0xf < *(uint *)(param_1 + 0x194)) {
        piVar5 = (int *)*piVar5;
      }
      FUN_0151f850("PreviousMetric",piVar5);
      FUN_0151fc50("TimeDeltaMs",uVar10);
      FUN_0151fcf0("EndsSession",cVar3);
      FUN_0151fcf0("SessionAlreadyOver",*(undefined *)(param_1 + 0x15e));
      FUN_0151f9c0("DatacenterId",*(undefined4 *)(param_1 + 0x154));
      FUN_0151f950("GameInstanceId",&DAT_01d79c68);
      iVar2 = DAT_01eadf30;
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      FUN_005542c0("ClientNetwork",0xd);
      iStack_8._0_1_ = 1;
      FUN_01520d20(auStack_38,iVar2,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_24) {
        uVar8 = uStack_24 + 1;
        uVar7 = auStack_38[0];
        if (0xfff < uVar8) {
          uVar7 = *(uint *)(auStack_38[0] - 4);
          uVar8 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar8);
      }
      iStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    if ((*(char *)(param_1 + 0x15e) == '\0') && (cVar3 == '\0')) {
      uVar4 = 0;
    }
    else {
      uVar4 = 1;
    }
    *(undefined *)(param_1 + 0x15e) = uVar4;
    pcVar9 = param_2;
    do {
      cVar3 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(param_2,(int)pcVar9 - (int)(param_2 + 1));
    puVar6 = (undefined4 *)FUN_016830f0(auStack_20);
    *(undefined4 *)(param_1 + 0x198) = *puVar6;
    *(undefined4 *)(param_1 + 0x19c) = puVar6[1];
  }
  FUN_0068db20("ClientNetwork",param_2);
  if ((DAT_01eadf30 != 0) && (*(char *)(param_1 + 0x44c) == '\0')) {
    for (puVar6 = *(undefined4 **)(param_1 + 0x440); puVar6 != *(undefined4 **)(param_1 + 0x444);
        puVar6 = puVar6 + 0xf) {
      iVar2 = puVar6[8];
      if ((iVar2 == 1) || (iVar2 == 0)) {
        if (DAT_01ee420b == '\0') {
          ExceptionList = pvStack_10;
          return;
        }
        puVar1 = puVar6 + 6;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_01677520(DAT_01ee420b,"reportPerServerMetric::: sc(%s:%d).state = %d :: returning false"
                     ,puVar6,*puVar1,iVar2);
        ExceptionList = pvStack_10;
        return;
      }
    }
    FUN_0068c890("ClientNetworkDetailed");
    *(undefined *)(param_1 + 0x44c) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8262 ; VA 0x0068b870 ; FUN_0068b870 */

void FUN_0068b870(undefined4 param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 *puVar9;
  int aiStack_28 [4];
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a58e8;
  pvStack_10 = ExceptionList;
  aiStack_28[0] = 0;
  aiStack_28[1] = 0;
  aiStack_28[2] = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006c5870(param_1,&cStack_11,&uStack_18,aiStack_28);
  if (cStack_11 == '\0') {
    FUN_005e6780(aiStack_28);
    if (DAT_01ea9464 != 0) {
      FUN_005e6780(aiStack_28);
    }
    goto LAB_0068b9a8;
  }
  if (cStack_11 != '\x01') goto LAB_0068b9a8;
  iVar3 = FUN_0068b410();
  iVar4 = FUN_016dee6d(iVar3 + 0x18);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  puVar1 = *(undefined4 **)(iVar3 + 0x10);
  aiStack_28[3] = iVar3 + 0x10;
  puVar5 = (undefined4 *)puVar1[1];
  puVar9 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      if ((uint)puVar5[4] < uStack_18) {
        puVar6 = (undefined4 *)puVar5[2];
      }
      else {
        puVar6 = (undefined4 *)*puVar5;
        puVar9 = puVar5;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    if ((puVar9 == puVar1) || (uStack_18 < (uint)puVar9[4])) goto LAB_0068b951;
  }
  else {
LAB_0068b951:
    puVar9 = puVar1;
  }
  if (puVar9 != puVar1) {
    piVar2 = (int *)puVar9[5];
    *(int *)piVar2[1] = *piVar2;
    *(int *)(*piVar2 + 4) = piVar2[1];
    *(int *)(iVar3 + 0xc) = *(int *)(iVar3 + 0xc) + -1;
    FUN_0068a6f0(piVar2);
    uVar7 = FUN_00553830(puVar9);
    FUN_01674ea0(uVar7,0x18);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_016deec8(iVar3 + 0x18);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
LAB_0068b9a8:
  if (aiStack_28[0] != 0) {
    uVar8 = aiStack_28[2] - aiStack_28[0];
    iVar3 = aiStack_28[0];
    if (0xfff < uVar8) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8263 ; VA 0x0068b9f0 ; FUN_0068b9f0 */

void FUN_0068b9f0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  
  FUN_00687eb0(&uStack_c,param_2,param_2);
  *param_1 = uStack_c;
  *(undefined *)(param_1 + 1) = uStack_8;
  return;
}



/* FUNCTION 8264 ; VA 0x0068ba20 ; FUN_0068ba20 */

void FUN_0068ba20(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_005eee40();
  if (iVar1 != 0) {
    FUN_006c5a80(param_1,*(undefined4 *)(iVar1 + 0x110),*(undefined4 *)(iVar1 + 0x114),
                 *(undefined4 *)(iVar1 + 0x118),*(undefined4 *)(iVar1 + 0x11c),
                 *(undefined4 *)(iVar1 + 0x120),*(undefined4 *)(iVar1 + 0x124),
                 *(undefined4 *)(iVar1 + 0x128),*(undefined4 *)(iVar1 + 300),
                 *(undefined4 *)(param_1 + 0xc));
  }
  return;
}



/* FUNCTION 8265 ; VA 0x0068ba60 ; FUN_0068ba60 */

bool __fastcall FUN_0068ba60(int param_1)

{
  return *(int *)(param_1 + 0x43c) == 2;
}



/* FUNCTION 8266 ; VA 0x0068ba70 ; FUN_0068ba70 */

bool __fastcall FUN_0068ba70(int param_1)

{
  return *(int *)(param_1 + 0x43c) == 1;
}



/* FUNCTION 8267 ; VA 0x0068ba80 ; FUN_0068ba80 */

int __fastcall FUN_0068ba80(int param_1)

{
  int iVar1;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if ((DAT_01eadf34 != 0) && (DAT_01eadf9d == '\0')) {
    DAT_01eadf9d = '\x01';
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850("Signal","ConnectionAccepted");
    iVar1 = DAT_01eadf34;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("ClientConnectionSignals",0x17);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,iVar1,0);
    FUN_005507b0();
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return param_1 + 0x430;
}



/* FUNCTION 8268 ; VA 0x0068bb50 ; FUN_0068bb50 */

int __fastcall FUN_0068bb50(int param_1)

{
  int iVar1;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if ((DAT_01eadf34 != 0) && (DAT_01eadf9e == '\0')) {
    DAT_01eadf9e = '\x01';
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850("Signal","ConnectionFailed");
    iVar1 = DAT_01eadf34;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("ClientConnectionSignals",0x17);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,iVar1,0);
    FUN_005507b0();
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return param_1 + 0x434;
}



/* FUNCTION 8269 ; VA 0x0068bc20 ; FUN_0068bc20 */

void FUN_0068bc20(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_006400f0(param_1);
      param_2[3] = param_1[3];
      if ((param_3 == 1) && (iVar1 = *param_1, iVar1 != 0)) {
        uVar4 = param_1[2] - iVar1;
        iVar2 = iVar1;
        if (0xfff < uVar4) {
          iVar2 = *(int *)(iVar1 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar2,uVar4);
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00688ef0(0);
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9a75c);
      piVar3 = (int *)0x0;
      if (iVar1 == 0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return;
    }
  }
  *param_2 = (int)&<lambda_acd8de19f2509e641a88a2ee213d9a1f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 8270 ; VA 0x0068bd00 ; FUN_0068bd00 */

undefined __fastcall FUN_0068bd00(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined uVar3;
  undefined4 *puVar4;
  
  puVar4 = *(undefined4 **)(param_1 + 0x440);
  uVar3 = 1;
  if (puVar4 != *(undefined4 **)(param_1 + 0x444)) {
    while (((iVar2 = puVar4[8], iVar2 != 2 && (iVar2 != 1)) && (iVar2 != 0))) {
      puVar4 = puVar4 + 0xf;
      if (puVar4 == *(undefined4 **)(param_1 + 0x444)) {
        return uVar3;
      }
    }
    if (DAT_01ee420b != '\0') {
      puVar1 = puVar4 + 6;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_01677520(DAT_01ee420b,"noViableConnectionsLeft::: sc(%s:%d).state = %d :: returning false"
                   ,puVar4,*puVar1,iVar2);
    }
    uVar3 = 0;
  }
  return uVar3;
}



/* FUNCTION 8271 ; VA 0x0068bd60 ; FUN_0068bd60 */

void __fastcall FUN_0068bd60(int param_1)

{
  char cVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  char *pcVar5;
  undefined4 ****ppppuVar6;
  undefined4 ****ppppuVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  int iVar11;
  char *pcVar12;
  uint uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined2 uVar16;
  char *pcVar17;
  int iVar18;
  char acStack_44c [1028];
  undefined4 ***apppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5910;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_2c = param_1;
  if (*(char *)(param_1 + 0x15e) == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    ExceptionList = &pvStack_10;
    FUN_005542c0("OtherDisconnect",0xf);
    uStack_8 = 0;
    if (DAT_01d5b038 == '\0') {
      ppppuVar7 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar7 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_0068de80(ppppuVar7,1);
    }
    else {
      iVar18 = *(int *)(param_1 + 0x440);
      uVar13 = 0;
      iVar11 = *(int *)(param_1 + 0x444) - iVar18;
      iVar4 = iVar11 >> 0x1f;
      iVar11 = iVar11 / 0x3c + iVar4;
      if (iVar11 != iVar4) {
        piVar10 = (int *)(iVar18 + 0x20);
LAB_0068bdf0:
        if (*piVar10 != 2) goto code_r0x0068bdf5;
        pcVar17 = (char *)(iVar18 + uVar13 * 0x3c);
        pcVar5 = pcVar17;
        if (0xf < *(uint *)(iVar18 + 0x14 + uVar13 * 0x3c)) {
          pcVar5 = *(char **)pcVar17;
        }
        pcVar12 = pcVar5;
        do {
          cVar1 = *pcVar12;
          pcVar12 = pcVar12 + 1;
          pcVar12[(int)(acStack_44c + (-1 - (int)pcVar5))] = cVar1;
        } while (cVar1 != '\0');
        pcVar5 = acStack_44c;
        do {
          cVar1 = *pcVar5;
          pcVar5 = pcVar5 + 1;
        } while (cVar1 != '\0');
        pcVar5[(int)(acStack_44c + -(int)(acStack_44c + 1))] = '|';
        FUN_00694630(*(undefined4 *)(pcVar17 + 0x18),
                     pcVar5 + (int)(acStack_44c + (1 - (int)(acStack_44c + 1))),10);
        if (DAT_01ee420b != '\0') {
          FUN_01677520(DAT_01ee420b,"getConnectedServer::: returning %s",acStack_44c);
        }
        pcVar17 = acStack_44c;
        uStack_38 = 0;
        uStack_34 = 0xf;
        do {
          cVar1 = *pcVar17;
          pcVar17 = pcVar17 + 1;
        } while (cVar1 != '\0');
        iVar18 = (int)pcVar17 - (int)(acStack_44c + 1);
        pcVar17 = acStack_44c;
        goto LAB_0068be16;
      }
LAB_0068bdfd:
      iVar18 = 0;
      pcVar17 = "";
LAB_0068be16:
      apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
      uStack_34 = 0xf;
      uStack_38 = 0;
      FUN_005542c0(pcVar17,iVar18);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pcVar5 = (char *)FUN_0068b4e0();
      pcVar17 = pcVar5;
      do {
        cVar1 = *pcVar17;
        pcVar17 = pcVar17 + 1;
      } while (cVar1 != '\0');
      FUN_00554150(pcVar5,(int)pcVar17 - (int)(pcVar5 + 1));
      ppppuVar7 = apppuStack_48;
      if (0xf < uStack_34) {
        ppppuVar7 = (undefined4 ****)apppuStack_48[0];
      }
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_0068b590(ppppuVar6,1,ppppuVar7,4);
      FUN_005507b0();
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar13 = uStack_14 + 1;
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar13) {
        ppppuVar7 = (undefined4 ****)apppuStack_28[0][-1];
        uVar13 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar7,uVar13);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  }
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Client:Disconnect",0);
  }
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar8 != (undefined4 *)0x0) {
    piVar10 = *(int **)(param_1 + 0x30);
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar10[1] = piVar10[1] + 1;
      UNLOCK();
      puVar8 = *(undefined4 **)(param_1 + 0x2c);
      piVar10 = *(int **)(param_1 + 0x30);
    }
    piVar2 = (int *)puVar8[1];
    for (piVar9 = (int *)*puVar8; piVar9 != piVar2; piVar9 = piVar9 + 2) {
      *(undefined *)(*piVar9 + 0x22) = 0;
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar18 = piVar10[1] + -1;
      piVar10[1] = iVar18;
      UNLOCK();
      if (iVar18 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        piVar2 = piVar10 + 2;
        iVar18 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar18 == 1) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  FUN_008a50b0();
  if (*(int *)(param_1 + 200) != 0) {
    piStack_30 = (int *)FUN_0054db20();
    pcVar3 = *(code **)(*piStack_30 + 0x68);
    FUN_005f70a0();
    FUN_005f7140();
    uVar14 = DAT_01d5b000;
    uVar15 = DAT_01d5b004;
    uVar16 = DAT_01d5b008;
    FUN_005f7170(iStack_2c + 0x110);
    (*pcVar3)(uVar14,uVar15,uVar16);
    piVar10 = (int *)FUN_0054db20();
    (**(code **)(*piVar10 + 0x34))(3000,0,3);
  }
  ExceptionList = pvStack_10;
  return;
code_r0x0068bdf5:
  uVar13 = uVar13 + 1;
  piVar10 = piVar10 + 0xf;
  if ((uint)(iVar11 - iVar4) <= uVar13) goto LAB_0068bdfd;
  goto LAB_0068bdf0;
}



/* FUNCTION 8272 ; VA 0x0068c0a0 ; FUN_0068c0a0 */

int FUN_0068c0a0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5930;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_008f7870(param_1);
  iVar6 = iVar5;
  if (iVar5 != 0) {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iVar6 = FUN_0068a7e0(param_1,param_2);
    if ((char)iVar6 != '\0') {
      puVar7 = (undefined4 *)FUN_0068b410();
      puVar9 = puVar7 + 6;
      puStack_14 = puVar9;
      iVar6 = FUN_016dee6d(puVar9);
      if (iVar6 != 0) {
        FUN_016df3c9(iVar6);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar8 = (undefined4 *)FUN_005e5de0(auStack_1c,iVar5);
      uVar3 = *puVar8;
      uVar4 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      *puVar7 = uVar3;
      piVar10 = (int *)puVar7[1];
      puVar7[1] = uVar4;
      if (piVar10 != (int *)0x0) {
        LOCK();
        iVar6 = piVar10[2] + -1;
        piVar10[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_18[2] + -1;
        piStack_18[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      if (puVar7[3] == 0) {
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
      }
      else {
        piVar10 = *(int **)puVar7[2];
        if (piVar10 != (int *)puVar7[2]) {
          piVar1 = puVar7 + 0x12;
          do {
            *piVar1 = *piVar1 + 1;
            puVar9 = (undefined4 *)FUN_00688b50(piVar1);
            *puVar9 = piVar10;
            iVar6 = *piVar1;
            if (puVar7[1] != 0) {
              LOCK();
              piVar2 = (int *)(puVar7[1] + 8);
              *piVar2 = *piVar2 + 1;
              UNLOCK();
            }
            FUN_0068df80(*puVar7,puVar7[1],piVar10 + 2,iVar6);
            piVar10 = (int *)*piVar10;
            puVar9 = puStack_14;
          } while (piVar10 != (int *)puVar7[2]);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
      }
      iVar6 = FUN_016deec8(puVar9);
      if (iVar6 != 0) {
        iVar6 = FUN_016df3c9(iVar6);
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar10 = param_2 + 1;
    iVar5 = *piVar10;
    iVar6 = *piVar10;
    *piVar10 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar6 = (**(code **)*param_2)();
      LOCK();
      piVar10 = param_2 + 2;
      iVar5 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 8273 ; VA 0x0068c250 ; FUN_0068c250 */

int FUN_0068c250(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5948;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0068a7e0(param_1,param_2);
  if ((char)iVar3 != '\0') {
    puVar4 = (undefined4 *)FUN_0068b410();
    iVar3 = FUN_016dee6d(puVar4 + 6);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    *puVar4 = 0;
    piVar2 = (int *)puVar4[1];
    puVar4[1] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    FUN_00601ea0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_016deec8(puVar4 + 6);
    if (iVar3 != 0) {
      iVar3 = FUN_016df3c9(iVar3);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar1 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 8274 ; VA 0x0068c350 ; FUN_0068c350 */

void __thiscall FUN_0068c350(int param_1,code *param_2,code *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5991;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
    FUN_01679490();
    FUN_01679490();
    FUN_0068bd60();
    FUN_00564080();
    FUN_0098c810(0);
  }
  FUN_006c4db0(iVar4,param_3);
  if (param_3 != (code *)0x0) {
    iVar4 = FUN_008f7870(param_1);
    if ((iVar4 != 0) && (*(int **)(iVar4 + 0x84) != (int *)0x0)) {
      (**(code **)(**(int **)(iVar4 + 0x84) + 0x14))(0);
    }
    iVar4 = (int)param_3;
    param_2 = (code *)FUN_0055e560();
    FUN_0098c810(*(undefined4 *)(param_1 + 200));
    pcStack_14 = FUN_0068c0a0;
    param_3 = (code *)FUN_00687cc0(&iStack_18,&pcStack_14);
    uStack_8 = 0;
    cVar3 = FUN_01679300(param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(param_3);
    }
    uStack_8 = 0xffffffff;
    if (iStack_18 != 0) {
      piVar1 = (int *)(iStack_18 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iStack_18);
      }
    }
    param_2 = FUN_0068c250;
    param_3 = (code *)FUN_00687cc0(&iStack_18,&param_2);
    uStack_8 = 1;
    cVar3 = FUN_01679300(param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(param_3);
    }
    if (iStack_18 != 0) {
      piVar1 = (int *)(iStack_18 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iStack_18);
      }
    }
    param_2 = (code *)(iVar4 + 0x68);
    uStack_8 = 2;
    iVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 3;
    iStack_18 = iVar4;
    pcStack_14 = (code *)FUN_01674e20(0x1c);
    if (pcStack_14 == (code *)0x0) {
      pcVar6 = (code *)0x0;
    }
    else {
      *(undefined4 *)pcStack_14 = 0;
      *(undefined4 *)(pcStack_14 + 4) = 1;
      *(code **)(pcStack_14 + 8) = FUN_0068b160;
      *(code **)(pcStack_14 + 0xc) = _guard_check_icall;
      *(undefined4 *)(pcStack_14 + 0x10) = 0;
      *(code **)(pcStack_14 + 0x14) = param_2;
      *(int *)(pcStack_14 + 0x18) = param_1;
      pcVar6 = pcStack_14;
    }
    FUN_016797d0(pcVar6);
    if (pcVar6 != (code *)0x0) {
      LOCK();
      *(int *)(pcVar6 + 4) = *(int *)(pcVar6 + 4) + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
    param_3 = pcVar6;
    FUN_01675290(iVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    cVar3 = FUN_01679300(&param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_3);
    }
    uStack_8 = 0xffffffff;
    if (param_3 != (code *)0x0) {
      pcVar6 = param_3 + 4;
      LOCK();
      iVar4 = *(int *)pcVar6;
      *(int *)pcVar6 = *(int *)pcVar6 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(param_3);
      }
    }
    uVar5 = FUN_008f7870(param_1);
    FUN_005f1d60(param_1 + 0x428,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8275 ; VA 0x0068c610 ; FUN_0068c610 */

undefined4 FUN_0068c610(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((((param_1 != 0) &&
         (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
         (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005eee40(), iVar2 != 0)) &&
       (iVar2 = FUN_00688090(), iVar2 != 0)) {
      uVar3 = FUN_006efe40();
      return uVar3;
    }
  }
  return 1;
}



/* FUNCTION 8276 ; VA 0x0068c680 ; FUN_0068c680 */

int FUN_0068c680(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  char cVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c168;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_005f1cd0();
  cVar5 = (char)iVar6;
  while (cVar5 == '\0') {
    cVar5 = FUN_00bc36f0();
    if (cVar5 != '\0') {
      for (uVar3 = 0; (0x100U >> uVar3 & 1) == 0; uVar3 = uVar3 + 1) {
      }
      pbVar4 = (byte *)((int)&DAT_01eec540 + ((int)uVar3 >> 3));
      *pbVar4 = *pbVar4 | '\x01' << (uVar3 & 7);
    }
    FUN_005ef740(2000,0);
    FUN_01689e80(0xffffffff);
    iVar6 = FUN_005f1cd0();
    cVar5 = (char)iVar6;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 8277 ; VA 0x0068c740 ; FUN_0068c740 */

undefined * FUN_0068c740(undefined *param_1,undefined4 param_2)

{
  switch(param_2) {
  case 0x11:
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0("Connection attempt failed.",0x1a);
    return param_1;
  default:
    FUN_01675640(param_1,"Network error %d",param_2);
    return param_1;
  case 0x18:
  case 0x94:
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0("Roblox version is out of date. Please uninstall and try again.",0x3e);
    return param_1;
  case 0x95:
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0("Version not compatible with server. Please uninstall and try again.",0x43);
    return param_1;
  }
}



/* FUNCTION 8278 ; VA 0x0068c890 ; FUN_0068c890 */

void __thiscall FUN_0068c890(int param_1,char *param_2)

{
  char cVar1;
  short sVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  int *piVar10;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2790;
  pvStack_10 = ExceptionList;
  puStack_18 = *(undefined4 **)(param_1 + 0x444);
  puVar9 = *(undefined4 **)(param_1 + 0x440);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (puVar9 != puStack_18) {
    do {
      if ((puVar9[8] == 3) || (puVar9[8] == 2)) {
        FUN_0151f6f0(DAT_01eadf30,0,0);
        piVar10 = puVar9 + 9;
        iStack_8 = 0;
        FUN_0151f950("Metric",piVar10);
        FUN_0151f9c0("DatacenterId",*(undefined4 *)(param_1 + 0x154));
        puVar5 = puVar9;
        if (0xf < (uint)puVar9[5]) {
          puVar5 = (undefined4 *)*puVar9;
        }
        FUN_0151f850("ServerIp",puVar5);
        FUN_0151f9c0("ServerPort",puVar9[6]);
        sVar2 = *(short *)(puVar9 + 7);
        if (sVar2 == 0x17) {
          iVar4 = 6;
        }
        else if (sVar2 == 2) {
          iVar4 = 4;
        }
        else {
          iVar4 = -(uint)(sVar2 != 0);
        }
        FUN_0151f9c0("ClientSocketIPVersion",iVar4);
        FUN_0151f9c0("ServerConnectionState",puVar9[8]);
        FUN_0151f9c0("ClientJoinState",*(undefined4 *)(param_1 + 0x17c));
        FUN_0151f950("GameInstanceId",&DAT_01d79c68);
        uVar3 = DAT_01eadf30;
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = auStack_30[0] & 0xffffff00;
        pcVar6 = param_2;
        do {
          cVar1 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(param_2,(int)pcVar6 - (int)(param_2 + 1));
        iStack_8._0_1_ = 1;
        FUN_01520d20(auStack_30,uVar3,0);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (0xf < uStack_1c) {
          uVar8 = uStack_1c + 1;
          uVar7 = auStack_30[0];
          if (0xfff < uVar8) {
            uVar7 = *(uint *)(auStack_30[0] - 4);
            uVar8 = uStack_1c + 0x24;
            if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,uVar8);
        }
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = auStack_30[0] & 0xffffff00;
        if (DAT_01ee420b != '\0') {
          if (0xf < (uint)puVar9[0xe]) {
            piVar10 = (int *)*piVar10;
          }
          puVar5 = puVar9;
          if (0xf < (uint)puVar9[5]) {
            puVar5 = (undefined4 *)*puVar9;
          }
          FUN_01677520(DAT_01ee420b,"Reporting per server(%s:%d) metric to influx: %s.",puVar5,
                       puVar9[6],piVar10);
        }
        iStack_8 = 0xffffffff;
        FUN_0151f7f0();
        param_1 = iStack_14;
      }
      puVar9 = puVar9 + 0xf;
    } while (puVar9 != puStack_18);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8279 ; VA 0x0068cab0 ; FUN_0068cab0 */

void __thiscall FUN_0068cab0(int param_1,char *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined uVar4;
  double *pdVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 ****ppppuVar9;
  int *piVar10;
  undefined4 ****ppppuVar11;
  uint uVar12;
  uint uVar13;
  char *pcVar14;
  int *piVar15;
  double dVar16;
  undefined4 ***apppuStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  undefined4 ***apppuStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 ***apppuStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  int aiStack_7c [5];
  uint uStack_68;
  undefined8 uStack_64;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  double dStack_2c;
  double dStack_24;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5a2c;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("ClientNetwork",0xd);
  uStack_8 = 0;
  pcVar14 = param_2;
  if (*(char *)(param_1 + 0x15e) != '\0') {
    pcVar14 = "EventAfterEndOfSession";
    FUN_00554150(" (After End Of Session)",0x17);
  }
  pdVar5 = (double *)FUN_016830f0(&dStack_24);
  dVar16 = (*pdVar5 - *(double *)(param_1 + 0x198)) * DAT_018c0d70;
  uStack_64 = FUN_016f3ec0();
  if (DAT_01ee420b != '\0') {
    FUN_01677520(DAT_01ee420b,"Reporting network metric: %s. Time since last metric = %u",param_2,
                 (int)uStack_64);
  }
  uStack_1c = 0;
  puStack_18 = (undefined4 *)0x0;
  puStack_14 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  FUN_016f3fe0();
  dStack_2c = dVar16;
  dStack_24 = dVar16;
  puVar6 = (undefined4 *)FUN_01675640(auStack_5c,"%s_%s","ClientNetwork",pcVar14);
  uStack_8._0_1_ = 2;
  if (puStack_14 == puStack_18) {
    FUN_00633500(puStack_18,puVar6,&dStack_24);
  }
  else {
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    uVar7 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *puStack_18 = *puVar6;
    puStack_18[1] = uVar7;
    puStack_18[2] = uVar2;
    puStack_18[3] = uVar3;
    *(undefined8 *)(puStack_18 + 4) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
    *(double *)(puStack_18 + 6) = dStack_2c;
    puStack_18 = puStack_18 + 8;
  }
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_48) {
    uVar12 = uStack_48 + 1;
    uVar13 = auStack_5c[0];
    if (0xfff < uVar12) {
      uVar13 = *(uint *)(auStack_5c[0] - 4);
      uVar12 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar13) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar12);
  }
  dStack_24 = dStack_2c;
  puVar6 = (undefined4 *)FUN_01530500(aiStack_7c);
  uStack_8._0_1_ = 3;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  puVar6 = (undefined4 *)FUN_01675640(auStack_5c,"%s_%s_Platform_%s","ClientNetwork",pcVar14,puVar6)
  ;
  uStack_8._0_1_ = 4;
  if (puStack_14 == puStack_18) {
    FUN_00633500(puStack_18,puVar6,&dStack_24);
  }
  else {
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    uVar7 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *puStack_18 = *puVar6;
    puStack_18[1] = uVar7;
    puStack_18[2] = uVar2;
    puStack_18[3] = uVar3;
    *(undefined8 *)(puStack_18 + 4) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
    *(double *)(puStack_18 + 6) = dStack_2c;
    puStack_18 = puStack_18 + 8;
  }
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_48) {
    uVar12 = uStack_48 + 1;
    uVar13 = auStack_5c[0];
    if (0xfff < uVar12) {
      uVar13 = *(uint *)(auStack_5c[0] - 4);
      uVar12 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar13) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar12);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_68) {
    uVar13 = uStack_68 + 1;
    iVar8 = aiStack_7c[0];
    if (0xfff < uVar13) {
      iVar8 = *(int *)(aiStack_7c[0] + -4);
      uVar13 = uStack_68 + 0x24;
      if (0x1f < (aiStack_7c[0] - iVar8) - 4U) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar13);
  }
  dStack_24 = dStack_2c;
  puVar6 = (undefined4 *)
           FUN_01675640(aiStack_7c,"%s_%s_DatacenterId_%d","ClientNetwork",pcVar14,
                        *(undefined4 *)(param_1 + 0x154));
  uStack_8._0_1_ = 5;
  if (puStack_14 == puStack_18) {
    FUN_00633500(puStack_18,puVar6,&dStack_24);
  }
  else {
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    uVar7 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *puStack_18 = *puVar6;
    puStack_18[1] = uVar7;
    puStack_18[2] = uVar2;
    puStack_18[3] = uVar3;
    *(undefined8 *)(puStack_18 + 4) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
    *(double *)(puStack_18 + 6) = dStack_2c;
    puStack_18 = puStack_18 + 8;
  }
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_68) {
    uVar13 = uStack_68 + 1;
    iVar8 = aiStack_7c[0];
    if (0xfff < uVar13) {
      iVar8 = *(int *)(aiStack_7c[0] + -4);
      uVar13 = uStack_68 + 0x24;
      if (0x1f < (aiStack_7c[0] - iVar8) - 4U) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar13);
  }
  puVar6 = &DAT_01d7a8b8;
  if (0xf < DAT_01d7a8cc) {
    puVar6 = DAT_01d7a8b8;
  }
  dStack_24 = dStack_2c;
  dVar16 = dStack_2c;
  puVar6 = (undefined4 *)FUN_01675640(aiStack_7c,"%s_%s_Country_%s","ClientNetwork",pcVar14,puVar6);
  uStack_8._0_1_ = 6;
  if (puStack_14 == puStack_18) {
    FUN_00633500(puStack_18,puVar6,&dStack_24);
  }
  else {
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    uVar7 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *puStack_18 = *puVar6;
    puStack_18[1] = uVar7;
    puStack_18[2] = uVar2;
    puStack_18[3] = uVar3;
    *(undefined8 *)(puStack_18 + 4) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
    *(double *)(puStack_18 + 6) = dStack_2c;
    puStack_18 = puStack_18 + 8;
    dVar16 = dStack_2c;
  }
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_68) {
    uVar13 = uStack_68 + 1;
    iVar8 = aiStack_7c[0];
    if (0xfff < uVar13) {
      iVar8 = *(int *)(aiStack_7c[0] + -4);
      uVar13 = uStack_68 + 0x24;
      if (0x1f < (aiStack_7c[0] - iVar8) - 4U) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar13);
  }
  if (DAT_01d5b028 != '\0') {
    puVar6 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar6 = DAT_01d79c80;
    }
    dStack_24 = dStack_2c;
    dVar16 = dStack_2c;
    uVar7 = FUN_01675640(aiStack_7c,"%s_%s_PlaceId_%s","ClientNetwork",pcVar14,puVar6);
    uStack_8._0_1_ = 7;
    FUN_00635550(uVar7,&dStack_24);
    uStack_8._0_1_ = 1;
    if (0xf < uStack_68) {
      uVar13 = uStack_68 + 1;
      iVar8 = aiStack_7c[0];
      if (0xfff < uVar13) {
        iVar8 = *(int *)(aiStack_7c[0] + -4);
        uVar13 = uStack_68 + 0x24;
        if (0x1f < (aiStack_7c[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar13);
    }
  }
  if ((*(int *)(param_1 + 0x17c) == 2) && ((char)param_3 != '\0')) {
    iVar8 = FUN_00688090();
    if (iVar8 != 0) {
      FUN_016f3fe0();
      dStack_2c = dVar16;
      dStack_24 = dVar16;
      uVar7 = FUN_01675640(aiStack_7c,"%s_%s_RakRecvBeforeFail","ClientNetwork",pcVar14);
      uStack_8._0_1_ = 8;
      FUN_00635550(uVar7,&dStack_24);
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      puVar6 = &DAT_01d79c80;
      if (0xf < DAT_01d79c94) {
        puVar6 = DAT_01d79c80;
      }
      dStack_24 = dStack_2c;
      uVar7 = FUN_01675640(aiStack_7c,"%s_%s_RakRecvBeforeFailWithPlace_%s","ClientNetwork",pcVar14,
                           puVar6);
      uStack_8._0_1_ = 9;
      FUN_00635550(uVar7,&dStack_24);
      uStack_8._0_1_ = 1;
      FUN_005507b0();
    }
  }
  FUN_00874d70(&uStack_1c,0);
  puVar6 = (undefined4 *)FUN_01530500(auStack_5c);
  uStack_8._0_1_ = 10;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  FUN_01675640(apppuStack_c4,"%s_ByVersionForPlatform_%s",param_2,puVar6);
  uStack_8._0_1_ = 0xc;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (0xf < uStack_48) {
    uVar12 = uStack_48 + 1;
    uVar13 = auStack_5c[0];
    if (0xfff < uVar12) {
      uVar13 = *(uint *)(auStack_5c[0] - 4);
      uVar12 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar13) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar12);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  FUN_01675640(apppuStack_ac,"%s_ByIPForDatacenterId_%d",param_2,*(undefined4 *)(param_1 + 0x154));
  uStack_8._0_1_ = 0xd;
  FUN_01675640(apppuStack_94,"%s_ByLocationForDatacenterId_%d",param_2,
               *(undefined4 *)(param_1 + 0x154));
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  puVar6 = &DAT_01d7a888;
  if (0xf < DAT_01d7a89c) {
    puVar6 = DAT_01d7a888;
  }
  ppppuVar11 = apppuStack_c4;
  if (0xf < uStack_b0) {
    ppppuVar11 = (undefined4 ****)apppuStack_c4[0];
  }
  ppppuVar9 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar9 = (undefined4 ****)apppuStack_44[0];
  }
  FUN_0087c450(ppppuVar9,ppppuVar11,puVar6,0,0,0);
  piVar15 = (int *)(param_1 + 0x164);
  piVar10 = piVar15;
  if (0xf < *(uint *)(param_1 + 0x178)) {
    piVar10 = (int *)*piVar15;
  }
  ppppuVar11 = apppuStack_ac;
  if (0xf < uStack_98) {
    ppppuVar11 = (undefined4 ****)apppuStack_ac[0];
  }
  ppppuVar9 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar9 = (undefined4 ****)apppuStack_44[0];
  }
  FUN_0087c450(ppppuVar9,ppppuVar11,piVar10,0,0,0);
  puVar6 = &DAT_01d7a8b8;
  if (0xf < DAT_01d7a8cc) {
    puVar6 = DAT_01d7a8b8;
  }
  ppppuVar11 = apppuStack_94;
  if (0xf < uStack_80) {
    ppppuVar11 = (undefined4 ****)apppuStack_94[0];
  }
  ppppuVar9 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar9 = (undefined4 ****)apppuStack_44[0];
  }
  FUN_0087c450(ppppuVar9,ppppuVar11,puVar6,0,0,0);
  if ((0 < DAT_01eadf2c) && (DAT_01eadf2c == *(int *)(param_1 + 0x154))) {
    FUN_00554150(" [Unthrottled]",0xe);
    puVar6 = &DAT_01d7a888;
    if (0xf < DAT_01d7a89c) {
      puVar6 = DAT_01d7a888;
    }
    ppppuVar11 = apppuStack_c4;
    if (0xf < uStack_b0) {
      ppppuVar11 = (undefined4 ****)apppuStack_c4[0];
    }
    ppppuVar9 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar9 = (undefined4 ****)apppuStack_44[0];
    }
    FUN_0087c6f0(ppppuVar9,ppppuVar11,puVar6,0,0,0,3);
    piVar10 = piVar15;
    if (0xf < *(uint *)(param_1 + 0x178)) {
      piVar10 = (int *)*piVar15;
    }
    ppppuVar11 = apppuStack_ac;
    if (0xf < uStack_98) {
      ppppuVar11 = (undefined4 ****)apppuStack_ac[0];
    }
    ppppuVar9 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar9 = (undefined4 ****)apppuStack_44[0];
    }
    FUN_0087c6f0(ppppuVar9,ppppuVar11,piVar10,0,0,0,3);
    puVar6 = &DAT_01d7a8b8;
    if (0xf < DAT_01d7a8cc) {
      puVar6 = DAT_01d7a8b8;
    }
    ppppuVar11 = apppuStack_94;
    if (0xf < uStack_80) {
      ppppuVar11 = (undefined4 ****)apppuStack_94[0];
    }
    ppppuVar9 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar9 = (undefined4 ****)apppuStack_44[0];
    }
    FUN_0087c6f0(ppppuVar9,ppppuVar11,puVar6,0,0,0,3);
  }
  if (DAT_01eadf30 != 0) {
    FUN_0151f6f0(DAT_01eadf30,0,0);
    uStack_8._0_1_ = 0xf;
    FUN_0151f850("Metric",param_2);
    piVar10 = (int *)(param_1 + 0x180);
    if (0xf < *(uint *)(param_1 + 0x194)) {
      piVar10 = (int *)*piVar10;
    }
    FUN_0151f850("PreviousMetric",piVar10);
    FUN_0151fc50("TimeDeltaMs",uStack_64);
    FUN_0151fcf0("EndsSession",param_3);
    FUN_0151fcf0("SessionAlreadyOver",*(undefined *)(param_1 + 0x15e));
    FUN_0151f9c0("DatacenterId",*(undefined4 *)(param_1 + 0x154));
    if (0xf < *(uint *)(param_1 + 0x178)) {
      piVar15 = (int *)*piVar15;
    }
    FUN_0151f850("ServerIp",piVar15);
    FUN_0151f950("GameInstanceId",&DAT_01d79c68);
    FUN_0151f9c0("AnalyticsSocketFamily",*(undefined4 *)(param_1 + 0x158));
    iVar8 = DAT_01eadf30;
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    FUN_005542c0("ClientNetwork",0xd);
    uStack_8._0_1_ = 0x10;
    FUN_01520d20(auStack_5c,iVar8,0);
    uStack_8._0_1_ = 0xf;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_48) {
      uVar12 = uStack_48 + 1;
      uVar13 = auStack_5c[0];
      if (0xfff < uVar12) {
        uVar13 = *(uint *)(auStack_5c[0] - 4);
        uVar12 = uStack_48 + 0x24;
        if (0x1f < (auStack_5c[0] - uVar13) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar12);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    FUN_0151f7f0();
  }
  if ((*(char *)(param_1 + 0x15e) == '\0') && ((char)param_3 == '\0')) {
    uVar4 = 0;
  }
  else {
    uVar4 = 1;
  }
  *(undefined *)(param_1 + 0x15e) = uVar4;
  pcVar14 = param_2;
  do {
    cVar1 = *pcVar14;
    pcVar14 = pcVar14 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar14 - (int)(param_2 + 1));
  puVar6 = (undefined4 *)FUN_016830f0(&dStack_24);
  *(undefined4 *)(param_1 + 0x198) = *puVar6;
  *(undefined4 *)(param_1 + 0x19c) = puVar6[1];
  if (0xf < uStack_80) {
    uVar13 = uStack_80 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_94[0];
    if (0xfff < uVar13) {
      ppppuVar11 = (undefined4 ****)apppuStack_94[0][-1];
      uVar13 = uStack_80 + 0x24;
      if (0x1f < (uint)((int)apppuStack_94[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar11,uVar13);
  }
  uStack_84 = 0;
  uStack_80 = 0xf;
  apppuStack_94[0] = (undefined4 ***)((uint)apppuStack_94[0] & 0xffffff00);
  if (0xf < uStack_98) {
    uVar13 = uStack_98 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_ac[0];
    if (0xfff < uVar13) {
      ppppuVar11 = (undefined4 ****)apppuStack_ac[0][-1];
      uVar13 = uStack_98 + 0x24;
      if (0x1f < (uint)((int)apppuStack_ac[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar11,uVar13);
  }
  uStack_9c = 0;
  uStack_98 = 0xf;
  apppuStack_ac[0] = (undefined4 ***)((uint)apppuStack_ac[0] & 0xffffff00);
  if (0xf < uStack_b0) {
    uVar13 = uStack_b0 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_c4[0];
    if (0xfff < uVar13) {
      ppppuVar11 = (undefined4 ****)apppuStack_c4[0][-1];
      uVar13 = uStack_b0 + 0x24;
      if (0x1f < (uint)((int)apppuStack_c4[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar11,uVar13);
  }
  uStack_b4 = 0;
  uStack_b0 = 0xf;
  apppuStack_c4[0] = (undefined4 ***)((uint)apppuStack_c4[0] & 0xffffff00);
  FUN_0056d3e0();
  if (0xf < uStack_30) {
    uVar13 = uStack_30 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar13) {
      ppppuVar11 = (undefined4 ****)apppuStack_44[0][-1];
      uVar13 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar11,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8280 ; VA 0x0068d5d0 ; FUN_0068d5d0 */

void __thiscall
FUN_0068d5d0(int param_1,undefined4 param_2,char *param_3,char param_4,undefined8 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  char *pcVar9;
  undefined8 in_XMM0_Qa;
  undefined8 uVar10;
  int aiStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5a88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ee420b != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01ee420b,"Reporting network metric: %s to diag. Time since last metric = %u",
                 param_3,(undefined4)param_5);
  }
  uStack_28 = 0;
  puStack_24 = (undefined4 *)0x0;
  puStack_20 = (undefined4 *)0x0;
  uStack_8 = 0;
  pcVar9 = "EventAfterEndOfSession";
  if (*(char *)(param_1 + 0x15e) == '\0') {
    pcVar9 = param_3;
  }
  FUN_016f3fe0();
  param_5 = in_XMM0_Qa;
  puVar4 = (undefined4 *)FUN_01675640(auStack_40,"%s_%s",param_2,pcVar9);
  uStack_8._0_1_ = 1;
  if (puStack_20 == puStack_24) {
    FUN_00633500(puStack_24,puVar4,&uStack_1c);
  }
  else {
    puStack_24[4] = 0;
    puStack_24[5] = 0;
    uVar5 = puVar4[1];
    uVar1 = puVar4[2];
    uVar2 = puVar4[3];
    *puStack_24 = *puVar4;
    puStack_24[1] = uVar5;
    puStack_24[2] = uVar1;
    puStack_24[3] = uVar2;
    *(undefined8 *)(puStack_24 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    *(undefined8 *)(puStack_24 + 6) = param_5;
    puStack_24 = puStack_24 + 8;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_1c = param_5;
  puVar4 = (undefined4 *)FUN_01530500(aiStack_58);
  uStack_8._0_1_ = 2;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar4 = (undefined4 *)FUN_01675640(auStack_40,"%s_%s_Platform_%s",param_2,pcVar9,puVar4);
  uStack_8._0_1_ = 3;
  if (puStack_20 == puStack_24) {
    FUN_00633500(puStack_24,puVar4,&uStack_1c);
  }
  else {
    puStack_24[4] = 0;
    puStack_24[5] = 0;
    uVar5 = puVar4[1];
    uVar1 = puVar4[2];
    uVar2 = puVar4[3];
    *puStack_24 = *puVar4;
    puStack_24[1] = uVar5;
    puStack_24[2] = uVar1;
    puStack_24[3] = uVar2;
    *(undefined8 *)(puStack_24 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    *(undefined8 *)(puStack_24 + 6) = param_5;
    puStack_24 = puStack_24 + 8;
  }
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    iVar6 = aiStack_58[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_58[0] + -4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar6) - 4U) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  uStack_1c = param_5;
  puVar4 = (undefined4 *)
           FUN_01675640(aiStack_58,"%s_%s_DatacenterId_%d",param_2,pcVar9,
                        *(undefined4 *)(iStack_14 + 0x154));
  uStack_8._0_1_ = 4;
  if (puStack_20 == puStack_24) {
    FUN_00633500(puStack_24,puVar4,&uStack_1c);
  }
  else {
    puStack_24[4] = 0;
    puStack_24[5] = 0;
    uVar5 = puVar4[1];
    uVar1 = puVar4[2];
    uVar2 = puVar4[3];
    *puStack_24 = *puVar4;
    puStack_24[1] = uVar5;
    puStack_24[2] = uVar1;
    puStack_24[3] = uVar2;
    *(undefined8 *)(puStack_24 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    *(undefined8 *)(puStack_24 + 6) = param_5;
    puStack_24 = puStack_24 + 8;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    iVar6 = aiStack_58[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_58[0] + -4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar6) - 4U) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  puVar4 = &DAT_01d7a8b8;
  if (0xf < DAT_01d7a8cc) {
    puVar4 = DAT_01d7a8b8;
  }
  uStack_1c = param_5;
  uVar10 = param_5;
  puVar4 = (undefined4 *)FUN_01675640(aiStack_58,"%s_%s_Country_%s",param_2,pcVar9,puVar4);
  uStack_8._0_1_ = 5;
  if (puStack_20 == puStack_24) {
    FUN_00633500(puStack_24,puVar4,&uStack_1c);
  }
  else {
    puStack_24[4] = 0;
    puStack_24[5] = 0;
    uVar5 = puVar4[1];
    uVar1 = puVar4[2];
    uVar2 = puVar4[3];
    *puStack_24 = *puVar4;
    puStack_24[1] = uVar5;
    puStack_24[2] = uVar1;
    puStack_24[3] = uVar2;
    *(undefined8 *)(puStack_24 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    *(undefined8 *)(puStack_24 + 6) = param_5;
    puStack_24 = puStack_24 + 8;
    uVar10 = param_5;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    iVar6 = aiStack_58[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_58[0] + -4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar6) - 4U) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  if (DAT_01d5b028 != '\0') {
    puVar4 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar4 = DAT_01d79c80;
    }
    uVar10 = param_5;
    uVar5 = FUN_01675640(aiStack_58,"%s_%s_PlaceId_%s",param_2,pcVar9,puVar4);
    uStack_8._0_1_ = 6;
    FUN_00635550(uVar5,&param_5);
    uStack_8._0_1_ = 0;
    if (0xf < uStack_44) {
      uVar8 = uStack_44 + 1;
      iVar6 = aiStack_58[0];
      if (0xfff < uVar8) {
        iVar6 = *(int *)(aiStack_58[0] + -4);
        uVar8 = uStack_44 + 0x24;
        if (0x1f < (aiStack_58[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar8);
    }
  }
  if ((*(int *)(iStack_14 + 0x17c) == 2) && (param_4 != '\0')) {
    iVar6 = FUN_00688090();
    if (iVar6 != 0) {
      FUN_016f3fe0();
      uStack_1c = uVar10;
      uVar5 = FUN_01675640(aiStack_58,"%s_%s_RakRecvBeforeFail",param_2,pcVar9);
      uStack_8._0_1_ = 7;
      FUN_00635550(uVar5,&param_5);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      puVar4 = &DAT_01d79c80;
      if (0xf < DAT_01d79c94) {
        puVar4 = DAT_01d79c80;
      }
      param_5 = uStack_1c;
      uVar5 = FUN_01675640(aiStack_58,"%s_%s_RakRecvBeforeFailWithPlace_%s",param_2,pcVar9,puVar4);
      uStack_8._0_1_ = 8;
      FUN_00635550(uVar5,&param_5);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
    }
  }
  FUN_00874d70(&uStack_28,0);
  FUN_0056d3e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8281 ; VA 0x0068db20 ; FUN_0068db20 */

void __thiscall FUN_0068db20(int param_1,char *param_2,undefined4 param_3)

{
  char cVar1;
  undefined uVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 ****ppppuVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5acb;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  pcVar6 = param_2;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_2,(int)pcVar6 - (int)(param_2 + 1));
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x15e) != '\0') {
    FUN_00554150(" (After End Of Session)",0x17);
  }
  puVar3 = (undefined4 *)FUN_01530500(auStack_70);
  uStack_8._0_1_ = 1;
  if (0xf < (uint)puVar3[5]) {
    puVar3 = (undefined4 *)*puVar3;
  }
  FUN_01675640(apppuStack_58,"%s_ByVersionForPlatform_%s",param_3,puVar3);
  uStack_8._0_1_ = 3;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_5c) {
    uVar7 = uStack_5c + 1;
    uVar8 = auStack_70[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_70[0] - 4);
      uVar7 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_01675640(auStack_88,"%s_ByIPForDatacenterId_%d",param_3,*(undefined4 *)(param_1 + 0x154));
  uStack_8._0_1_ = 4;
  FUN_01675640(apppuStack_40,"%s_ByLocationForDatacenterId_%d",param_3,
               *(undefined4 *)(param_1 + 0x154));
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar3 = &DAT_01d7a888;
  if (0xf < DAT_01d7a89c) {
    puVar3 = DAT_01d7a888;
  }
  ppppuVar5 = apppuStack_58;
  if (0xf < uStack_44) {
    ppppuVar5 = (undefined4 ****)apppuStack_58[0];
  }
  ppppuVar4 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar4 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0087c450(ppppuVar4,ppppuVar5,puVar3,0,0,0);
  puVar3 = &DAT_01d7a8b8;
  if (0xf < DAT_01d7a8cc) {
    puVar3 = DAT_01d7a8b8;
  }
  ppppuVar5 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar5 = (undefined4 ****)apppuStack_40[0];
  }
  ppppuVar4 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar4 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0087c450(ppppuVar4,ppppuVar5,puVar3,0,0,0);
  if ((0 < DAT_01eadf2c) && (DAT_01eadf2c == *(int *)(param_1 + 0x154))) {
    FUN_00554150(" [Unthrottled]",0xe);
    puVar3 = &DAT_01d7a888;
    if (0xf < DAT_01d7a89c) {
      puVar3 = DAT_01d7a888;
    }
    ppppuVar5 = apppuStack_58;
    if (0xf < uStack_44) {
      ppppuVar5 = (undefined4 ****)apppuStack_58[0];
    }
    ppppuVar4 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0087c6f0(ppppuVar4,ppppuVar5,puVar3,0,0,0,3);
    puVar3 = &DAT_01d7a8b8;
    if (0xf < DAT_01d7a8cc) {
      puVar3 = DAT_01d7a8b8;
    }
    ppppuVar5 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar5 = (undefined4 ****)apppuStack_40[0];
    }
    ppppuVar4 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0087c6f0(ppppuVar4,ppppuVar5,puVar3,0,0,0,3);
  }
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar8) {
      ppppuVar5 = (undefined4 ****)apppuStack_40[0][-1];
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar8);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  if (0xf < uStack_74) {
    uVar7 = uStack_74 + 1;
    uVar8 = auStack_88[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_88[0] - 4);
      uVar7 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_58[0];
    if (0xfff < uVar8) {
      ppppuVar5 = (undefined4 ****)apppuStack_58[0][-1];
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar8);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar8) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0][-1];
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8282 ; VA 0x0068de80 ; FUN_0068de80 */

void __thiscall FUN_0068de80(int param_1,char *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  char *pcVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_2,(int)pcVar3 - (int)(param_2 + 1));
  uStack_8 = 0;
  switch(*(undefined4 *)(param_1 + 0x17c)) {
  case 0:
    uVar5 = 0xe;
    pcVar3 = "_NotStartedYet";
    break;
  case 1:
    uVar5 = 0x10;
    pcVar3 = "_BeforeConnected";
    break;
  case 2:
    uVar5 = 0x13;
    pcVar3 = "_BeforeLoadFinished";
    break;
  case 3:
    uVar5 = 0x12;
    pcVar3 = "_AfterLoadFinished";
    break;
  default:
    goto switchD_0068dedd_caseD_4;
  }
  FUN_00554150(pcVar3,uVar5);
switchD_0068dedd_caseD_4:
  ppppuVar2 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0068cab0(ppppuVar2,param_3);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar4) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8283 ; VA 0x0068df80 ; FUN_0068df80 */

int FUN_0068df80(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  undefined auStack_7c [4];
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_50;
  int *piStack_4c;
  int aiStack_3c [2];
  int iStack_34;
  undefined4 uStack_30;
  int aiStack_2c [2];
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5b00;
  pvStack_10 = ExceptionList;
  piStack_4c = &iStack_1c;
  uStack_8 = 0;
  uStack_50 = 0x68dfb1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_1c != 0) {
    piStack_4c = (int *)0x1;
    piStack_70 = (int *)param_3;
    iStack_74 = 0x68dfd4;
    FUN_006400f0();
    uStack_30 = param_4;
    piStack_70 = aiStack_3c;
    uStack_8._0_1_ = 2;
    iStack_74 = 0x68dfea;
    FUN_006400f0();
    uStack_20 = uStack_30;
    puStack_14 = auStack_7c;
    uStack_8._0_1_ = 3;
    uStack_6c = 0;
    FUN_006400f0(aiStack_2c);
    piStack_70 = (int *)uStack_20;
    FUN_00687b50();
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (aiStack_2c[0] != 0) {
      piStack_70 = (int *)(iStack_24 - aiStack_2c[0]);
      iVar4 = aiStack_2c[0];
      if (0xfff < piStack_70) {
        iVar4 = *(int *)(aiStack_2c[0] + -4);
        piStack_70 = (int *)((int)piStack_70 + 0x23);
        if (0x1f < (aiStack_2c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_70 = (int *)0x68e0de;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      uStack_78 = 0x68e04f;
      iStack_74 = iVar4;
      FUN_01674ea0();
    }
    uStack_8._0_1_ = 1;
    if (aiStack_3c[0] != 0) {
      piStack_70 = (int *)(iStack_34 - aiStack_3c[0]);
      iVar4 = aiStack_3c[0];
      if (0xfff < piStack_70) {
        iVar4 = *(int *)(aiStack_3c[0] + -4);
        piStack_70 = (int *)((int)piStack_70 + 0x23);
        if (0x1f < (aiStack_3c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_70 = (int *)&UNK_0068e0e3;
          FUN_017167a3();
        }
      }
      uStack_78 = 0x68e083;
      iStack_74 = iVar4;
      FUN_01674ea0();
    }
    piStack_70 = (int *)0x68e08e;
    iVar4 = FUN_0090ca30();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0x68e0a4;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_4c = (int *)0x68e0b4;
        iVar4 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      piStack_4c = (int *)0x68e0c8;
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 8284 ; VA 0x0068e0f0 ; FUN_0068e0f0 */

void __fastcall FUN_0068e0f0(int param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  undefined auStack_60 [12];
  int iStack_54;
  int iStack_4c;
  int aiStack_38 [5];
  uint uStack_24;
  int *piStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5b20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_006ab530();
  iStack_8 = 0;
  auStack_14[0] = 0x8f;
  FUN_006ad5e0(auStack_14,1);
  uVar2 = FUN_00acb320(auStack_60);
  FUN_006ad360(uVar2);
  if (DAT_01ee420a != '\0') {
    puVar3 = (undefined4 *)FUN_006b1620(aiStack_38,param_1 + 0x110,1,0x7c);
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677650(DAT_01ee420a,"serverId: %s",puVar3);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      iVar4 = aiStack_38[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_38[0] + -4);
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (aiStack_38[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
  }
  piStack_1c = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*piStack_1c + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar2 = DAT_01d5b000;
  uVar6 = DAT_01d5b004;
  uVar7 = DAT_01d5b008;
  FUN_005f7170(iStack_18 + 0x110);
  (*pcVar1)(auStack_60,2,3,0,uVar2,uVar6,uVar7);
  if (iStack_54 != 0) {
    uVar5 = iStack_4c - iStack_54;
    iVar4 = iStack_54;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iStack_54 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_54 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8285 ; VA 0x0068e270 ; FUN_0068e270 */

int __fastcall FUN_0068e270(int param_1)

{
  code *pcVar1;
  undefined uVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  undefined4 ******ppppppuVar9;
  int iVar10;
  uint uVar11;
  byte bVar12;
  int *piVar13;
  uint uVar14;
  int iVar15;
  undefined4 uVar16;
  undefined2 uVar17;
  uint auStack_1b4 [4];
  undefined4 uStack_1a4;
  uint uStack_1a0;
  int iStack_19c;
  int *piStack_198;
  uint uStack_194;
  undefined **appuStack_190 [2];
  undefined8 uStack_188;
  undefined *****apppppuStack_180 [6];
  undefined *****pppppuStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 *puStack_15c;
  undefined4 *puStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 *puStack_14c;
  undefined4 *puStack_148;
  int iStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_12c;
  undefined **ppuStack_128;
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  uint auStack_c8 [4];
  undefined4 uStack_b8;
  uint uStack_b4;
  uint auStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  double dStack_98;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint uStack_78;
  undefined auStack_74 [4];
  undefined auStack_70 [4];
  undefined4 uStack_6c;
  undefined auStack_68 [12];
  int iStack_5c;
  int iStack_54;
  undefined4 *****apppppuStack_40 [4];
  uint uStack_30;
  uint uStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5bbf;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  FUN_006ab530();
  uStack_8 = 0;
  auStack_14[0] = 0x8a;
  FUN_006ad5e0(auStack_14,1);
  FUN_006ad310(*(undefined4 *)(param_1 + 0x130),*(undefined4 *)(param_1 + 0x134),auStack_68);
  piVar13 = (int *)(param_1 + 0x138);
  FUN_006ad360(piVar13,auStack_68);
  FUN_006ad360(&DAT_01d633e4,auStack_68);
  uStack_6c = *(undefined4 *)(param_1 + 0xd0);
  FUN_006a5c10(&uStack_6c,auStack_70,4);
  FUN_006ad5e0(auStack_70,4);
  piVar4 = (int *)FUN_00910e00();
  piStack_198 = (int *)piVar4[1];
  if (piStack_198 != (int *)0x0) {
    LOCK();
    piStack_198[1] = piStack_198[1] + 1;
    UNLOCK();
    piStack_198 = (int *)piVar4[1];
  }
  iVar10 = *piVar4;
  appuStack_190[0] = &PTR_018bf148;
  apppppuStack_180[0] = (undefined *****)&DAT_018bf150;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_20 = 1;
  ppuStack_128 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  uStack_12c = 0x50;
  uStack_188 = 0;
  iStack_19c = iVar10;
  piStack_28 = piStack_198;
  FUN_00554f20(apppppuStack_180 + 2,0);
  *(undefined ***)((int)apppppuStack_180 + (int)apppppuStack_180[0][1]) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined *****)((int)apppppuStack_180 + (int)(apppppuStack_180[0][1] + -1)) =
       apppppuStack_180[0][1] + -2;
  *(undefined ***)((int)appuStack_190 + (int)appuStack_190[0][1]) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)appuStack_190 + (int)(appuStack_190[0][1] + -4)) =
       appuStack_190[0][1] + -0x20;
  uStack_8 = 7;
  *(undefined ***)((int)appuStack_190 + (int)appuStack_190[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)appuStack_190 + (int)(appuStack_190[0][1] + -4)) =
       appuStack_190[0][1] + -0x68;
  apppppuStack_180[2] =
       (undefined *****)std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iStack_144 = FUN_01674e20(8);
  if (iStack_144 == 0) {
    iStack_144 = 0;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    uVar5 = FUN_016de181(1);
    *(undefined4 *)(iStack_144 + 4) = uVar5;
  }
  apppppuStack_180[5] = (undefined *****)(apppppuStack_180 + 3);
  pppppuStack_168 = (undefined *****)(apppppuStack_180 + 4);
  puStack_15c = &uStack_164;
  puStack_158 = &uStack_160;
  puStack_14c = &uStack_154;
  puStack_148 = &uStack_150;
  apppppuStack_180[4] = (undefined *****)0x0;
  uStack_160 = 0;
  uStack_150 = 0;
  apppppuStack_180[3] = (undefined *****)0x0;
  uStack_164 = 0;
  uStack_154 = 0;
  apppppuStack_180[2] =
       (undefined *****)
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_140 = 0;
  uStack_13c = 0;
  uStack_8._0_1_ = 9;
  if ((DAT_01d5b030 == '\0') ||
     (uStack_18 = CONCAT31(uStack_18._1_3_,0x3f), *(uint *)(iVar10 + 0xa4) < 0x23)) {
    uStack_18 = CONCAT31(uStack_18._1_3_,0x3e);
  }
  FUN_005f1810(auStack_e0,&DAT_01ea9490,uStack_18);
  uStack_8._0_1_ = 10;
  FUN_006ad360(auStack_e0,auStack_68);
  uVar5 = FUN_01530500(auStack_1b4);
  uStack_8._0_1_ = 0xb;
  FUN_006ad360(uVar5,auStack_68);
  uStack_8._0_1_ = 10;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_1a0) {
    uVar11 = uStack_1a0 + 1;
    uVar14 = auStack_1b4[0];
    if (0xfff < uVar11) {
      uVar14 = *(uint *)(auStack_1b4[0] - 4);
      uVar11 = uStack_1a0 + 0x24;
      if (0x1f < (auStack_1b4[0] - uVar14) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar11);
  }
  uStack_1a4 = 0;
  uStack_1a0 = 0xf;
  auStack_1b4[0] = auStack_1b4[0] & 0xffffff00;
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  FUN_005542c0(&DAT_018d743c,1);
  uStack_8._0_1_ = 0xc;
  FUN_006ad360(auStack_90,auStack_68);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (0xf < uStack_7c) {
    uVar11 = uStack_7c + 1;
    uVar14 = auStack_90[0];
    if (0xfff < uVar11) {
      uVar14 = *(uint *)(auStack_90[0] - 4);
      uVar11 = uStack_7c + 0x24;
      if (0x1f < (auStack_90[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar11);
  }
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  if ((DAT_01d5b030 != '\0') && (0x22 < *(uint *)(iVar10 + 0xa4))) {
    uVar14 = 0x22;
    do {
      if (*(uint *)(iVar10 + 0xa4) <= uVar14) {
        FUN_00554050();
        goto LAB_0068eaff;
      }
      puVar6 = (undefined4 *)(iVar10 + 0x94);
      if (0xf < *(uint *)(iVar10 + 0xa8)) {
        puVar6 = *(undefined4 **)(iVar10 + 0x94);
      }
      FUN_005af260((int)*(char *)((int)puVar6 + uVar14) ^ 0xca);
      uVar14 = uVar14 - 1;
    } while (3 < uVar14);
    FUN_0058c420(auStack_c8);
    uStack_20 = 0x11;
    uStack_8._0_1_ = 0xd;
    FUN_006ad360(auStack_c8,auStack_68);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (0xf < uStack_b4) {
      uVar11 = uStack_b4 + 1;
      uVar14 = auStack_c8[0];
      if (0xfff < uVar11) {
        uVar14 = *(uint *)(auStack_c8[0] - 4);
        uVar11 = uStack_b4 + 0x24;
        if (0x1f < (auStack_c8[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar14,uVar11);
    }
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    auStack_c8[0] = auStack_c8[0] & 0xffffff00;
  }
  iVar10 = iStack_24;
  if (0xf < *(uint *)(param_1 + 0x14c)) {
    piVar13 = (int *)*piVar13;
  }
  iVar7 = FUN_014ebd40(piVar13,*(undefined4 *)(iStack_24 + 0x148),1);
  uVar14 = ((iVar7 + 0x76114cfbU) * 0x80 | iVar7 + 0x76114cfbU >> 0x19) * 0x76114cfb + 0x8e9460a5;
  uVar14 = 0x76114cfb - (uVar14 * 0x2000 | uVar14 >> 0x13) ^ 0x4beda921;
  uVar14 = (uVar14 >> 0x11 | uVar14 << 0xf) + 0xd5dc5c26;
  uVar14 = 0xc1fef61c - (uVar14 >> 0x17 | uVar14 * 0x200);
  iVar15 = -((uVar14 * 0x20000000 | uVar14 >> 3) ^ 0x4beda921);
  FUN_006ad4e0(iVar15,auStack_68);
  cVar3 = FUN_0151eaa0();
  iVar8 = iVar15 + 0xbadf00d;
  if (cVar3 == '\0') {
    iVar8 = iVar15 + -0xbadf00d;
  }
  FUN_006ad4e0(iVar8,auStack_68);
  dStack_98 = 0.0;
  FUN_005f2960(&dStack_98,iVar15,iVar7,iVar10 + 0x428,iVar10);
  FUN_006ad340((int)dStack_98,auStack_68);
  FUN_0054ef60(&DAT_01d59b18);
  uStack_8._0_1_ = 0xe;
  FUN_005f1cf0(auStack_b0,iVar15,iVar7);
  FUN_006ad360(auStack_b0,auStack_68);
  FUN_006ad360(&DAT_01d79c50,auStack_68);
  uStack_18 = GetModuleHandleA(0);
  FUN_006a5c10(&uStack_18,auStack_74,4);
  FUN_006ad5e0(auStack_74,4);
  iVar8 = FUN_008f7870(iVar10);
  FUN_01675640(apppppuStack_40,"%d%d%d%d",**(int **)(iVar8 + 0x43c) - (int)*(int **)(iVar8 + 0x43c),
               DAT_018c8a94,DAT_018c8a9c,DAT_018c8a98);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (uStack_30 < 0x10) {
    FUN_00578160(0x10 - uStack_30,0);
  }
  else {
    uStack_30 = 0x10;
    ppppppuVar9 = apppppuStack_40;
    if (0xf < uStack_2c) {
      ppppppuVar9 = (undefined4 ******)apppppuStack_40[0];
    }
    *(undefined *)(ppppppuVar9 + 4) = 0;
  }
  ppppppuVar9 = apppppuStack_40;
  if (0xf < uStack_2c) {
    ppppppuVar9 = (undefined4 ******)apppppuStack_40[0];
  }
  FUN_006c4bc0(auStack_68,ppppppuVar9);
  bVar12 = 0x1f;
  uStack_194 = *DAT_01eadf98 - (int)DAT_01eadf98;
  do {
    if ((uStack_194 & 1 << (bVar12 & 0x1f)) != 0) break;
    bVar12 = bVar12 - 1;
  } while (bVar12 != 0);
  DAT_01eaf550 = (((byte)uStack_194 & 3) + bVar12 * '\x04') * '\x02' + (DAT_01ea9460 != '\0');
  piStack_1c = (int *)0xb4da1a74;
  DAT_01eaf551 = *(undefined *)(iVar10 + 0x160);
  DAT_01eaf54c = 0x55aacc33;
  uStack_78 = uStack_194;
  piStack_1c = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*piStack_1c + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar5 = DAT_01d5b000;
  uVar16 = DAT_01d5b004;
  uVar17 = DAT_01d5b008;
  FUN_005f7170(iStack_24 + 0x110);
  (*pcVar1)(auStack_68,2,3,0,uVar5,uVar16,uVar17);
  if (0xf < uStack_2c) {
    uVar14 = uStack_2c + 1;
    ppppppuVar9 = (undefined4 ******)apppppuStack_40[0];
    if (0xfff < uVar14) {
      ppppppuVar9 = (undefined4 ******)apppppuStack_40[0][-1];
      uVar14 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppppuStack_40[0] + (-4 - (int)ppppppuVar9))) {
LAB_0068eaff:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppppuVar9,uVar14);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppppuStack_40[0] = (undefined4 *****)((uint)apppppuStack_40[0] & 0xffffff00);
  if (0xf < uStack_9c) {
    uVar11 = uStack_9c + 1;
    uVar14 = auStack_b0[0];
    if (0xfff < uVar11) {
      uVar14 = *(uint *)(auStack_b0[0] - 4);
      uVar11 = uStack_9c + 0x24;
      if (0x1f < (auStack_b0[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar11);
  }
  uStack_a0 = 0;
  uStack_9c = 0xf;
  auStack_b0[0] = auStack_b0[0] & 0xffffff00;
  if (0xf < uStack_cc) {
    uVar11 = uStack_cc + 1;
    uVar14 = auStack_e0[0];
    if (0xfff < uVar11) {
      uVar14 = *(uint *)(auStack_e0[0] - 4);
      uVar11 = uStack_cc + 0x24;
      if (0x1f < (auStack_e0[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar11);
  }
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = auStack_e0[0] & 0xffffff00;
  iVar10 = FUN_005705c0();
  piVar13 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_28 + 1;
    iVar8 = *piVar4;
    iVar10 = *piVar4;
    *piVar4 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar10 = (**(code **)*piStack_28)();
      LOCK();
      piVar4 = piVar13 + 2;
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar10 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  if (iStack_5c != 0) {
    uVar14 = iStack_54 - iStack_5c;
    iVar10 = iStack_5c;
    if (0xfff < uVar14) {
      iVar10 = *(int *)(iStack_5c + -4);
      uVar14 = uVar14 + 0x23;
      if (0x1f < (iStack_5c - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar10 = FUN_01674ea0(iVar10,uVar14);
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 8286 ; VA 0x0068eb20 ; FUN_0068eb20 */

void __fastcall FUN_0068eb20(int param_1)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  undefined auStack_48 [12];
  int iStack_3c;
  int iStack_34;
  int iStack_1c;
  int *piStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5bd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab530();
  uStack_8 = 0;
  pcStack_14._0_1_ = 0x90;
  FUN_006ad5e0(&pcStack_14,1);
  pcStack_14 = (code *)CONCAT31(pcStack_14._1_3_,1);
  FUN_006ad5e0(&pcStack_14,1);
  pcStack_14 = *(code **)(param_1 + 0xd0);
  FUN_006a5c10(&pcStack_14,&piStack_18,4);
  FUN_006ad5e0(&piStack_18,4);
  piVar2 = (int *)FUN_0054db20();
  iStack_1c = param_1 + 0x110;
  cVar1 = (**(code **)(*piVar2 + 0x154))
                    (*(undefined4 *)(param_1 + 0x110),*(undefined4 *)(param_1 + 0x114),
                     *(undefined4 *)(param_1 + 0x118),*(undefined4 *)(param_1 + 0x11c),
                     *(undefined4 *)(param_1 + 0x120),*(undefined4 *)(param_1 + 0x124),
                     *(undefined4 *)(param_1 + 0x128),*(undefined4 *)(param_1 + 300),0x800,0);
  if (cVar1 != '\0') {
    pcStack_14 = (code *)CONCAT31(pcStack_14._1_3_,1);
    FUN_006ad5e0(&pcStack_14,1);
  }
  uVar3 = FUN_01677950();
  piStack_18 = (int *)(uVar3 & 0xffff);
  FUN_006a5c10(&piStack_18,&pcStack_14,2);
  FUN_006ad5e0(&pcStack_14,2);
  FUN_01677790(FUN_0068a970,auStack_48,4);
  FUN_006ad360(param_1 + 0x1a0,auStack_48);
  piStack_18 = DAT_018c8a94;
  FUN_006a5c10(&piStack_18,&pcStack_14,4);
  FUN_006ad5e0(&pcStack_14,4);
  if (((uint)DAT_018c8a94 & 0xc) == 0) {
    piStack_18 = DAT_018c8a94;
    FUN_006a5c10(&piStack_18,&pcStack_14,4);
    FUN_006ad5e0(&pcStack_14,4);
  }
  piStack_18 = DAT_018c8a98;
  FUN_006a5c10(&piStack_18,&pcStack_14,4);
  FUN_006ad5e0(&pcStack_14,4);
  if (((uint)DAT_018c8a94 & 0x50) == 0) {
    piStack_18 = DAT_018c8a94;
    FUN_006a5c10(&piStack_18,&pcStack_14,4);
    FUN_006ad5e0(&pcStack_14,4);
  }
  piStack_18 = DAT_018c8a9c;
  FUN_006a5c10(&piStack_18,&pcStack_14,4);
  FUN_006ad5e0(&pcStack_14,4);
  if (((uint)DAT_018c8a94 & 0xa0) == 0) {
    piStack_18 = DAT_018c8a94;
    FUN_006a5c10(&piStack_18,&pcStack_14,4);
    FUN_006ad5e0(&pcStack_14,4);
  }
  piStack_18 = DAT_018c8aa8;
  FUN_006a5c10(&piStack_18,&pcStack_14,4);
  FUN_006ad5e0(&pcStack_14,4);
  if (((uint)DAT_018c8a94 & 0x900) == 0) {
    piStack_18 = DAT_018c8a94;
    FUN_006a5c10(&piStack_18,&pcStack_14,4);
    FUN_006ad5e0(&pcStack_14,4);
  }
  piStack_18 = DAT_018c8aa4;
  FUN_006a5c10(&piStack_18,&pcStack_14,4);
  FUN_006ad5e0(&pcStack_14,4);
  FUN_006c4af0(auStack_48);
  piStack_18 = (int *)FUN_0054db20();
  pcStack_14 = *(code **)(*piStack_18 + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar5 = DAT_01d5b000;
  uVar6 = DAT_01d5b004;
  uVar7 = DAT_01d5b008;
  FUN_005f7170(iStack_1c);
  (*pcStack_14)(auStack_48,2,3,0,uVar5,uVar6,uVar7);
  if (iStack_3c != 0) {
    uVar3 = iStack_34 - iStack_3c;
    iVar4 = iStack_3c;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iStack_3c + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iStack_3c - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8287 ; VA 0x0068ee70 ; FUN_0068ee70 */

void __fastcall FUN_0068ee70(int param_1)

{
  *(undefined4 *)(param_1 + 0x17c) = 3;
  return;
}



/* FUNCTION 8288 ; VA 0x0068ee80 ; FUN_0068ee80 */

void __thiscall FUN_0068ee80(int param_1,byte *param_2,undefined4 param_3,char *param_4)

{
  undefined4 *puVar1;
  char cVar2;
  byte bVar3;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  double *pdVar7;
  undefined4 *puVar8;
  char *pcVar9;
  char *pcVar10;
  byte *pbVar11;
  char *pcVar12;
  int iVar13;
  int iVar14;
  bool bVar15;
  byte abStack_418 [1028];
  undefined auStack_14 [4];
  int iStack_10;
  int iStack_c;
  uint uStack_8;
  
  uStack_8 = 0;
  iVar14 = *(int *)(param_1 + 0x440);
  iVar13 = *(int *)(param_1 + 0x444) - iVar14;
  iStack_c = param_1;
  iVar6 = iVar13 >> 0x1f;
  if (iVar13 / 0x3c + iVar6 == iVar6) {
    return;
  }
  iStack_10 = 0;
  do {
    pcVar12 = (char *)(iStack_10 + iVar14);
    pcVar9 = pcVar12;
    if (0xf < *(uint *)(iStack_10 + 0x14 + iVar14)) {
      pcVar9 = *(char **)pcVar12;
    }
    pcVar10 = pcVar9;
    do {
      cVar2 = *pcVar10;
      pcVar10 = pcVar10 + 1;
      pcVar10[(int)(abStack_418 + (-1 - (int)pcVar9))] = cVar2;
    } while (cVar2 != '\0');
    pbVar11 = abStack_418;
    do {
      bVar3 = *pbVar11;
      pbVar11 = pbVar11 + 1;
    } while (bVar3 != 0);
    pbVar11[(int)(abStack_418 + -(int)(abStack_418 + 1))] = 0x7c;
    FUN_00694630(*(undefined4 *)(pcVar12 + 0x18),
                 pbVar11 + (int)(abStack_418 + (1 - (int)(abStack_418 + 1))),10);
    pbVar11 = abStack_418;
    pbVar4 = param_2;
    do {
      bVar3 = *pbVar4;
      bVar15 = bVar3 < *pbVar11;
      if (bVar3 != *pbVar11) {
LAB_0068ef46:
        uVar5 = -(uint)bVar15 | 1;
        goto LAB_0068ef4b;
      }
      if (bVar3 == 0) break;
      bVar3 = pbVar4[1];
      bVar15 = bVar3 < pbVar11[1];
      if (bVar3 != pbVar11[1]) goto LAB_0068ef46;
      pbVar4 = pbVar4 + 2;
      pbVar11 = pbVar11 + 2;
    } while (bVar3 != 0);
    uVar5 = 0;
LAB_0068ef4b:
    if (uVar5 == 0) {
      if (DAT_01ee420b != '\0') {
        FUN_01677520(DAT_01ee420b,
                     "updateServerConnectionState::: sc(%s).old_state = %d -> new_state = %d :: returning false"
                     ,abStack_418,
                     *(undefined4 *)(*(int *)(param_1 + 0x440) + 0x20 + uStack_8 * 0x3c),param_3);
      }
      iVar14 = uStack_8 * 0x3c;
      *(undefined4 *)(iVar14 + 0x20 + *(int *)(param_1 + 0x440)) = param_3;
      pcVar12 = param_4;
      do {
        cVar2 = *pcVar12;
        pcVar12 = pcVar12 + 1;
      } while (cVar2 != '\0');
      FUN_005542c0(param_4,(int)pcVar12 - (int)(param_4 + 1));
      if (*(int *)(iVar14 + 0x20 + *(int *)(param_1 + 0x440)) != 2) {
        return;
      }
      iVar6 = FUN_008f7870(param_1);
      if (iVar6 != 0) {
        iVar13 = FUN_008f7870(iStack_c);
        pdVar7 = (double *)FUN_016830f0(auStack_14);
        *(float *)(iVar6 + 0x308) = (float)(*pdVar7 - *(double *)(iVar13 + 0x300));
        puVar8 = (undefined4 *)(*(int *)(iStack_c + 0x440) + iVar14);
        if ((undefined4 *)(iVar6 + 0x318) != puVar8) {
          puVar1 = puVar8 + 4;
          if (0xf < (uint)puVar8[5]) {
            puVar8 = (undefined4 *)*puVar8;
          }
          FUN_005542c0(puVar8,*puVar1);
        }
      }
      iVar6 = iStack_c;
      puVar8 = (undefined4 *)(*(int *)(iStack_c + 0x440) + iVar14);
      if (0xf < (uint)puVar8[5]) {
        puVar8 = (undefined4 *)*puVar8;
      }
      FUN_0151aae0(puVar8);
      *(undefined *)(iVar6 + 0x15f) = 1;
      return;
    }
    iVar14 = *(int *)(param_1 + 0x440);
    iStack_10 = iStack_10 + 0x3c;
    uStack_8 = uStack_8 + 1;
    if ((uint)((*(int *)(param_1 + 0x444) - iVar14) / 0x3c) <= uStack_8) {
      return;
    }
  } while( true );
}



/* FUNCTION 8289 ; VA 0x0068f100 ; thunk_FUN_00c6de80 */

undefined * thunk_FUN_00c6de80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d71c;
  pvStack_10 = ExceptionList;
  if (DAT_01efeb1c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efed28) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efed28);
      if (DAT_01efed28 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00d59db0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuiObject",0,uStack_20,0,0,0x1b,0,&DAT_01efeae4);
        FUN_016f3654(&LAB_01896840);
        FUN_016f37bf(&DAT_01efed28);
      }
    }
    DAT_01efeb1c = &DAT_01efeb20;
  }
  ExceptionList = pvStack_10;
  return DAT_01efeb1c;
}



/* FUNCTION 8290 ; VA 0x0068f130 ; thunk_FUN_0099be20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0099be20(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2220;
  pvStack_10 = ExceptionList;
  if (DAT_01ee3b48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3d60) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee3d60);
      if (DAT_01ee3d60 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Humanoid",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee3d58 = RBX::Creator<class_RBX::Humanoid>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee3b50,&DAT_01ee3d58);
        FUN_016f3654(FUN_01887270);
        FUN_016f37bf(&DAT_01ee3d60);
      }
    }
    DAT_01ee3b48 = &DAT_01ee3b50;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee3b48;
}



/* FUNCTION 8291 ; VA 0x0068f1b0 ; thunk_FUN_00c67ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c67ac0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cff0;
  pvStack_10 = ExceptionList;
  if (DAT_01efe1cc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe3e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efe3e0);
      if (DAT_01efe3e0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00db7610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SkateboardController",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efe3d8 = RBX::Creator<class_RBX::SkateboardController>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efe1d0,&DAT_01efe3d8);
        FUN_016f3654(FUN_01895cf0);
        FUN_016f37bf(&DAT_01efe3e0);
      }
    }
    DAT_01efe1cc = &DAT_01efe1d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efe1cc;
}



/* FUNCTION 8292 ; VA 0x0068f210 ; FUN_0068f210 */

void __thiscall FUN_0068f210(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5bf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Network::StrictNetworkFilter::WhiteList>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8293 ; VA 0x0068f27e ; Catch_All@0068f27e */

void Catch_All_0068f27e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0068fef0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8294 ; VA 0x0068f2a0 ; FUN_0068f2a0 */

int * __fastcall FUN_0068f2a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b00260();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 8295 ; VA 0x0068f2d0 ; FUN_0068f2d0 */

int __fastcall FUN_0068f2d0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00c8dce0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 8296 ; VA 0x0068f300 ; FUN_0068f300 */

int FUN_0068f300(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_0099be20();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 8297 ; VA 0x0068f340 ; FUN_0068f340 */

int __fastcall FUN_0068f340(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00913630();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 8298 ; VA 0x0068f370 ; FUN_0068f370 */

int __fastcall FUN_0068f370(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00c46280();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 8299 ; VA 0x0068f3a0 ; FUN_0068f3a0 */

int FUN_0068f3a0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c46280();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 8300 ; VA 0x0068f3e0 ; FUN_0068f3e0 */

int * FUN_0068f3e0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 8301 ; VA 0x0068f4d0 ; FUN_0068f4d0 */

undefined4 FUN_0068f4d0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00bd39b0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        *param_2 = 1;
        return 1;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 8302 ; VA 0x0068f520 ; FUN_0068f520 */

undefined4 FUN_0068f520(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b56f90();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        *param_2 = 1;
        return 1;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 8303 ; VA 0x0068f570 ; FUN_0068f570 */

undefined4 FUN_0068f570(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00bd3ab0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        *param_2 = 1;
        return 1;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 8304 ; VA 0x0068f5c0 ; FUN_0068f5c0 */

undefined4 FUN_0068f5c0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00bb25e0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        *param_2 = 1;
        return 1;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 8305 ; VA 0x0068f610 ; FUN_0068f610 */

undefined4 FUN_0068f610(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00bdf840();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        *param_2 = 1;
        return 1;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 8306 ; VA 0x0068f660 ; FUN_0068f660 */

int FUN_0068f660(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd3c,&LAB_00670d20);
  uVar3 = FUN_006761b0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00c1b420();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 8307 ; VA 0x0068f720 ; FUN_0068f720 */

int FUN_0068f720(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01eadd3c,&LAB_00670d20);
      uVar3 = FUN_006761b0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00c1b420();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 8308 ; VA 0x0068f830 ; FUN_0068f830 */

int __fastcall FUN_0068f830(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c91ca0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 8309 ; VA 0x0068f8a0 ; FUN_0068f8a0 */

int __fastcall FUN_0068f8a0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_0099be20(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 8310 ; VA 0x0068f900 ; FUN_0068f900 */

undefined4 FUN_0068f900(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  
  FUN_00c51e00();
  uVar1 = FUN_0086e8f0(param_1);
  piVar2 = (int *)FUN_00691400(uVar1);
  if (piVar2 != (int *)0x0) {
    param_1 = *piVar2;
    if (param_1 != 0) {
      iVar3 = FUN_0068fd30(&param_1);
      *(undefined4 *)(iVar3 + 4) = param_2;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 8311 ; VA 0x0068f950 ; FUN_0068f950 */

undefined4 FUN_0068f950(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  
  FUN_009ef640();
  uVar1 = FUN_0086e8f0(param_1);
  piVar2 = (int *)FUN_00691400(uVar1);
  if (piVar2 != (int *)0x0) {
    param_1 = *piVar2;
    if (param_1 != 0) {
      iVar3 = FUN_0068fd30(&param_1);
      *(undefined4 *)(iVar3 + 4) = param_2;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 8312 ; VA 0x0068f9a0 ; FUN_0068f9a0 */

undefined4 * FUN_0068f9a0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    puVar7 = &uStack_10;
    uStack_10 = 0;
    piStack_c = (int *)0x0;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
    piVar8 = (int *)0x0;
LAB_0068fa21:
    piVar1 = piStack_14;
    iVar2 = puVar7[1];
    *param_1 = 0;
    param_1[1] = 0;
    if (iVar2 != 0) {
      LOCK();
      *(int *)(puVar7[1] + 8) = *(int *)(puVar7[1] + 8) + 1;
      UNLOCK();
    }
    *param_1 = *puVar7;
    param_1[1] = iVar2;
    if ((bVar3) && (piStack_c != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar2 = piStack_c[2] + -1;
        piStack_c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    if ((bVar4) && (piVar1 != (int *)0x0)) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if ((bVar5) && (piVar8 != (int *)0x0)) {
      LOCK();
      iVar2 = piVar8[1] + -1;
      piVar8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    return param_1;
  }
  iVar2 = *(int *)(param_2 + 8);
  if (iVar2 != 0) {
    piVar8 = (int *)(iVar2 + 4);
    iVar2 = *(int *)(iVar2 + 4);
    while (iVar2 != 0) {
      LOCK();
      iVar6 = *piVar8;
      if (iVar2 == iVar6) {
        *piVar8 = iVar2 + 1;
        iVar6 = iVar2;
      }
      UNLOCK();
      if (iVar6 == iVar2) {
        piVar8 = *(int **)(param_2 + 8);
        uStack_18 = *(undefined4 *)(param_2 + 4);
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[1] = piVar8[1] + 1;
          UNLOCK();
        }
        piStack_14 = piVar8;
        puVar7 = &uStack_18;
        bVar5 = true;
        bVar4 = true;
        bVar3 = false;
        goto LAB_0068fa21;
      }
      iVar2 = *piVar8;
    }
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c21d80);
}



/* FUNCTION 8313 ; VA 0x0068fb00 ; FUN_0068fb00 */

undefined4 * __fastcall FUN_0068fb00(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("FilterResult");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Network::FilterResult>::vftable;
  FUN_009caf20(&DAT_01d5b0d8,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8314 ; VA 0x0068fb60 ; FUN_0068fb60 */

undefined4 * __thiscall
FUN_0068fb60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_3;
  param_1[3] = param_4;
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  param_1[4] = param_5;
  param_1[5] = param_6;
  *(undefined *)(param_1 + 6) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[7] = uVar3;
  param_1[8] = 0;
  param_1[9] = 0x3f800000;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 8315 ; VA 0x0068fc60 ; FUN_0068fc60 */

void __fastcall FUN_0068fc60(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x10);
  }
  return;
}



/* FUNCTION 8316 ; VA 0x0068fc80 ; FUN_0068fc80 */

void __fastcall FUN_0068fc80(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x8c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x78);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0xf;
  *(undefined *)(param_1 + 0x78) = 0;
  piVar4 = *(int **)(param_1 + 0x40);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0068fd1e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 8317 ; VA 0x0068fd30 ; FUN_0068fd30 */

uint * __thiscall FUN_0068fd30(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5c08;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar9 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0x10);
    puVar1 = (uint *)(piVar4 + 2);
    *piVar4 = 0;
    piVar4[1] = 0;
    puVar1[0] = 0;
    puVar1[1] = 0;
    *puVar1 = uVar5;
    if (piVar4 + 3 != (int *)0x0) {
      piVar4[3] = 0;
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar5 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (uint *)0x1;
      uVar7 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar10;
        while (puVar3 != (undefined4 *)0x0) {
          piVar8 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar8 = (int)puVar10;
            puVar10 = puVar3;
          }
          else {
            *puVar10 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar8;
            *(undefined4 **)*piVar8 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar10;
        }
      }
    }
    piVar4[1] = uVar9;
    uVar9 = uVar9 % *(uint *)(param_1 + 4);
    piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (piVar8 == (int *)0x0) {
      piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar8 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar10 = piVar8;
      *piVar4 = *piVar8;
    }
    else {
      *piVar4 = *piVar8;
      piVar8 = (int *)*puVar10;
    }
    *piVar8 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 8318 ; VA 0x0068fef0 ; FUN_0068fef0 */

undefined4 __thiscall FUN_0068fef0(undefined4 param_1,byte param_2)

{
  FUN_00612320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 8319 ; VA 0x0068ff20 ; FUN_0068ff20 */

void __fastcall FUN_0068ff20(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00612320();
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 8320 ; VA 0x0068ff40 ; FUN_0068ff40 */

undefined4 FUN_0068ff40(int param_1,undefined4 *param_2,uint *param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_c [8];
  
  cVar1 = FUN_0068f520(param_1,param_3);
  if ((((cVar1 == '\0') && (cVar1 = FUN_0068f570(param_1,param_3), cVar1 == '\0')) &&
      (cVar1 = FUN_0068f5c0(param_1,param_3), cVar1 == '\0')) &&
     (cVar1 = FUN_0068f610(param_1,param_3), cVar1 == '\0')) {
    if (param_2 != (undefined4 *)&DAT_01eed8e0) {
      if (param_2 == &DAT_0211e3e4) {
        piVar2 = (int *)FUN_0061f420(auStack_c);
        iVar3 = *piVar2;
        FUN_00550b30();
        *param_3 = (uint)(iVar3 != param_1);
        return 1;
      }
      iVar3 = FUN_0068f300(param_1);
      if (iVar3 == 0) {
        return 0;
      }
      uVar4 = FUN_009b4820(iVar3);
      iVar5 = FUN_00980070(uVar4);
      piVar2 = (int *)FUN_0061f420(auStack_c);
      iVar3 = *piVar2;
      FUN_00550b30();
      if (iVar5 != iVar3) {
        return 0;
      }
      cVar1 = FUN_009b8aa0(param_2);
      if (cVar1 == '\0') {
        return 0;
      }
    }
    *param_3 = 0;
  }
  return 1;
}



/* FUNCTION 8321 ; VA 0x00690040 ; FUN_00690040 */

uint __thiscall FUN_00690040(undefined4 *param_1,int param_2,undefined4 *param_3)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iStack_c;
  undefined4 *puStack_8;
  
  if (param_3 == &DAT_0211a3d8) {
    return 0;
  }
  pbVar1 = (byte *)param_1[2];
  if (pbVar1 == (byte *)0x0) {
LAB_0069009c:
    iVar3 = 0;
  }
  else {
    puStack_8 = param_3;
    FUN_00606ea0(&iStack_c,((uint)param_3 >> 3) + (int)param_3,&puStack_8,
                 -(uint)(pbVar1 + *pbVar1 + 1 != (byte *)0x0) & (uint)(pbVar1 + *pbVar1 + 1 + 1));
    if (iStack_c == 0) goto LAB_0069009c;
    iVar3 = *(int *)(iStack_c + 0xc);
  }
  param_3 = (undefined4 *)(uint)(iVar3 == 0);
  if (iVar3 == 5) {
    if ((param_2 == 0) ||
       (iVar3 = *(int *)(param_2 + 0xc), iVar2 = FUN_00913630(), iVar4 = param_2,
       (uint)*(ushort *)(iVar2 + 0x1da) <
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
      iVar4 = 0;
    }
    iVar3 = (**(code **)(*(int *)*param_1 + 0xb4))();
    if (iVar4 != iVar3) {
      return 1;
    }
  }
  else {
    if (iVar3 == 2) {
      iVar3 = FUN_0068f300(param_2);
      if ((iVar3 != 0) && (iVar4 = (**(code **)(*(int *)*param_1 + 0xb4))(), iVar4 != 0)) {
        iVar3 = FUN_009b48a0(iVar3);
        iVar4 = (**(code **)(*(int *)*param_1 + 0xb4))();
        if (iVar3 == *(int *)(iVar4 + 100)) goto LAB_00690162;
      }
      return 1;
    }
    if (((DAT_01d5b0d0 != '\0') || (DAT_01ee37b0 != '\0')) && (iVar3 == 3)) {
      param_3 = (undefined4 *)FUN_006912e0(param_2,*param_1);
    }
  }
LAB_00690162:
  if (param_3 != (undefined4 *)0x1) {
    FUN_006908c0(param_2,&param_3);
  }
  if (param_3 == (undefined4 *)0x0) {
    FUN_0068f4d0(param_2,&param_3);
  }
  return (uint)param_3;
}



/* FUNCTION 8322 ; VA 0x006901a0 ; FUN_006901a0 */

bool FUN_006901a0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  if (param_2 != 0) {
    do {
      iVar5 = *(int *)(param_2 + 0xc);
      iVar3 = FUN_008aa870();
      iVar4 = 0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        iVar4 = param_2;
      }
      if (iVar4 != 0) {
        return false;
      }
      iVar5 = *(int *)(param_2 + 0xc);
      iVar3 = FUN_00961580();
      iVar4 = 0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        iVar4 = param_2;
      }
      if (iVar4 != 0) {
        return false;
      }
      iVar5 = *(int *)(param_2 + 0xc);
      iVar3 = FUN_00913630();
      iVar4 = 0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        iVar4 = param_2;
      }
      if (iVar4 != 0) {
        iVar5 = (**(code **)(*param_1 + 0xb4))();
        return iVar4 != iVar5;
      }
      puVar1 = *(undefined4 **)(param_2 + 0x2c);
      if (puVar1 != (undefined4 *)0x0) {
        piVar2 = (int *)puVar1[1];
        for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
          if ((*piVar6 != 0) &&
             (iVar5 = *(int *)(*piVar6 + 0xc), iVar4 = FUN_0099be20(),
             (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
             (uint)*(ushort *)(iVar4 + 0x1da))) {
            iVar5 = FUN_00980070(param_2);
            if ((iVar5 != 0) && (iVar4 = (**(code **)(*param_1 + 0xb4))(), iVar5 == iVar4)) {
              return false;
            }
            return true;
          }
        }
      }
      param_2 = *(int *)(param_2 + 0x34);
    } while (param_2 != 0);
  }
  return false;
}



/* FUNCTION 8323 ; VA 0x006902e0 ; FUN_006902e0 */

bool FUN_006902e0(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_00690e10(param_1,0,param_2);
  return cVar1 != '\0';
}



/* FUNCTION 8324 ; VA 0x00690300 ; FUN_00690300 */

undefined4 __thiscall FUN_00690300(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_60 [56];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5c5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)(**(code **)(*(int *)*param_1 + 0xb4))();
  if (piVar2 != (int *)0x0) {
    if (param_2 == piVar2) {
      param_1 = (int *)*param_1;
      if ((param_1 != (int *)0x0) &&
         (iVar4 = param_1[3], iVar3 = FUN_005ee350(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        iVar4 = (**(code **)(*param_1 + 0xb8))();
        if (iVar4 == 0) {
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 0;
          if (param_2 == (int *)0x0) {
            puVar5 = (undefined4 *)&DAT_018d4a30;
          }
          else {
            puVar5 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
            if (0xf < (uint)puVar5[5]) {
              puVar5 = (undefined4 *)*puVar5;
            }
          }
          FUN_0151f850(&DAT_018d20dc,puVar5);
          (**(code **)(*param_1 + 0x294))(0x10f,"PlayerlessParent",6,2,auStack_60,0);
          FUN_0151f7f0();
        }
        else {
          (**(code **)(*param_1 + 0x290))("Playerless",7,2,"MovedPlayerFe");
        }
      }
    }
    else {
      iVar4 = piVar2[0x19];
      if (iVar4 == 0) {
        cVar1 = FUN_00620ec0(piVar2);
        if (cVar1 != '\0') {
          if (DAT_01eadff4 == 0) {
            ExceptionList = pvStack_10;
            return 0;
          }
          if (DAT_01eae041 != '\0') {
            ExceptionList = pvStack_10;
            return 0;
          }
          DAT_01eae041 = 1;
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 4;
          piVar2 = *(int **)(param_2[3] + 4);
          if (0xf < (uint)piVar2[5]) {
            piVar2 = (int *)*piVar2;
          }
          FUN_0151f850(&DAT_018bf030,piVar2);
          uVar6 = FUN_008a2380(auStack_28);
          uStack_8._0_1_ = 5;
          FUN_0151f950(&DAT_018d8974,uVar6);
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          iVar4 = DAT_01eadff4;
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0("NetworkFilterDeleteUnderPlayer",0x1e);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          FUN_01520d20(auStack_28,iVar4,0);
          FUN_005507b0();
          FUN_0151f7f0();
          ExceptionList = pvStack_10;
          return 0;
        }
      }
      else {
        cVar1 = FUN_00620ec0(iVar4);
        if (cVar1 != '\0') {
          if ((DAT_01eadff0 != 0) && (DAT_01eae040 == '\0')) {
            DAT_01eae040 = '\x01';
            FUN_0151f6f0(0xffffffff,0,0);
            uStack_8 = 1;
            piVar2 = *(int **)(param_2[3] + 4);
            if (0xf < (uint)piVar2[5]) {
              piVar2 = (int *)*piVar2;
            }
            FUN_0151f850(&DAT_018bf030,piVar2);
            uVar6 = FUN_008a2380(auStack_28);
            uStack_8._0_1_ = 2;
            FUN_0151f950(&DAT_018d8974,uVar6);
            uStack_8._0_1_ = 1;
            FUN_005507b0();
            iVar3 = DAT_01eadff0;
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = 0;
            FUN_005542c0("NetworkFilterDeleteUnderCharacter",0x21);
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            FUN_01520d20(auStack_28,iVar3,0);
            FUN_005507b0();
            uStack_8 = 0xffffffff;
            FUN_0151f7f0();
          }
          iVar4 = FUN_008f7870(iVar4);
          if ((iVar4 != 0) && (*(int *)(iVar4 + 0x4a0) == 2)) {
            iVar4 = param_2[3];
            iVar3 = FUN_0099be20();
            piVar2 = (int *)0x0;
            if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
                (uint)*(ushort *)(iVar3 + 0x1da)) {
              piVar2 = param_2;
            }
            if (piVar2 != (int *)0x0) {
              FUN_0092e970();
            }
          }
          ExceptionList = pvStack_10;
          return 0;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8325 ; VA 0x00690650 ; FUN_00690650 */

uint __thiscall FUN_00690650(int *param_1,int param_2,uint param_3)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 uVar8;
  int *piVar9;
  int *piVar10;
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  pbVar2 = (byte *)param_1[4];
  piStack_c = param_1;
  if ((pbVar2 == (byte *)0x0) ||
     (FUN_00606ea0(&iStack_8,(param_3 >> 3) + param_3,&param_3,
                   -(uint)(pbVar2 + *pbVar2 + 1 != (byte *)0x0) & (uint)(pbVar2 + *pbVar2 + 1 + 1)),
     iStack_8 == 0)) {
    iVar6 = 0;
  }
  else {
    iVar6 = *(int *)(iStack_8 + 0xc);
  }
  uVar7 = (uint)(iVar6 == 0);
  iVar4 = (**(code **)(*(int *)*param_1 + 0xb4))();
  if (iVar6 == 2) {
    if ((((param_2 != 0) &&
         (iVar6 = *(int *)(param_2 + 0xc), iVar5 = FUN_0099be20(),
         (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) && (iVar4 != 0)) &&
       (iVar6 = FUN_009b48a0(param_2), iVar6 == *(int *)(iVar4 + 100))) {
      return uVar7;
    }
    return 1;
  }
  if (iVar6 == 3) {
    uVar7 = FUN_006912e0(param_2,*piStack_c);
    return uVar7;
  }
  if (iVar6 == 4) {
    if (param_2 == 0) {
      return 1;
    }
    iVar6 = *(int *)(param_2 + 0xc);
    iVar5 = FUN_00ae6b40();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
      return 1;
    }
    if (iVar4 == 0) {
      return 1;
    }
    if (*(int *)(iVar4 + 100) != 0) {
      cVar3 = FUN_00620ec0(*(int *)(iVar4 + 100));
      if (cVar3 != '\0') {
        return uVar7;
      }
      return 1;
    }
    return 1;
  }
  if (iVar6 != 6) {
    return uVar7;
  }
  if (param_2 != 0) {
    iVar6 = *(int *)(param_2 + 0x34);
    if ((iVar6 != 0) && (param_2 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      param_2 = FUN_005c8ac0();
    }
    if ((param_2 != 0) &&
       (iVar6 = *(int *)(param_2 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      FUN_005789c0(&DAT_01eadd3c,&LAB_00670d20);
      uVar8 = FUN_006761b0();
      piVar9 = (int *)FUN_008aa140(uVar8);
      if (*piVar9 == 0) {
        uVar8 = FUN_00c1b420();
        piVar10 = (int *)FUN_008a9ba0(auStack_10,uVar8);
        iVar6 = *piVar10;
        iVar4 = piVar10[1];
        *piVar10 = 0;
        piVar10[1] = 0;
        *piVar9 = iVar6;
        piVar10 = (int *)piVar9[1];
        piVar9[1] = iVar4;
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar6 = piVar10[1] + -1;
          piVar10[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar10)();
            LOCK();
            iVar6 = piVar10[2] + -1;
            piVar10[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
        piVar10 = piStack_c;
        if (piStack_c != (int *)0x0) {
          LOCK();
          iVar6 = piStack_c[1] + -1;
          piStack_c[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_c)();
            LOCK();
            piVar1 = piVar10 + 2;
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
      }
      iVar6 = *piVar9;
      goto LAB_00690888;
    }
  }
  iVar6 = 0;
LAB_00690888:
  cVar3 = FUN_00983210(iVar6);
  if (((cVar3 == '\0') && (iVar6 != 0)) && (cVar3 = FUN_00c23510(), cVar3 != '\0')) {
    uVar7 = 1;
  }
  return uVar7;
}



/* FUNCTION 8326 ; VA 0x006908c0 ; FUN_006908c0 */

undefined FUN_006908c0(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_0068f520(param_1,param_2);
  if (cVar1 == '\0') {
    cVar1 = FUN_0068f570(param_1,param_2);
    if (cVar1 == '\0') {
      cVar1 = FUN_0068f5c0(param_1,param_2);
      if (cVar1 == '\0') {
        cVar1 = FUN_0068f610(param_1,param_2);
        if (cVar1 == '\0') {
          return 0;
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 8327 ; VA 0x00690910 ; FUN_00690910 */

bool FUN_00690910(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  
  cVar1 = FUN_00690e10(param_1,param_2,param_3);
  return cVar1 != '\0';
}



/* FUNCTION 8328 ; VA 0x00690930 ; FUN_00690930 */

undefined4 FUN_00690930(int param_1,int param_2,int *param_3,undefined *param_4,undefined4 *param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 uStack_108;
  int *piStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  int iStack_cc;
  int *piStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined uStack_94;
  int iStack_90;
  uint uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a5c91;
  pvStack_1c = ExceptionList;
  if ((((param_1 != 0) &&
       (iVar4 = *(int *)(param_1 + 0xc), ExceptionList = &pvStack_1c, iVar3 = FUN_00c39bb0(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) &&
      (iVar4 = (**(code **)(*(int *)*puStack_30 + 0xb4))(), iVar4 != 0)) &&
     (iStack_44 = *(int *)(iVar4 + 100), iStack_44 != 0)) {
    if (*(int *)(param_1 + 0x34) == 0) {
      if (param_2 == 0) {
        ExceptionList = pvStack_1c;
        return 1;
      }
      cVar2 = FUN_00620ec0(iStack_44);
    }
    else {
      cVar2 = FUN_006915a0(param_1,param_2,iStack_44);
    }
    if (cVar2 != '\0') {
      puVar5 = (undefined4 *)FUN_00c3bd10();
      piVar9 = *(int **)(param_1 + 0x78);
      uStack_78 = *puVar5;
      uStack_74 = puVar5[1];
      uStack_70 = puVar5[2];
      uStack_6c = puVar5[3];
      uStack_68 = puVar5[4];
      uStack_64 = puVar5[5];
      uStack_60 = puVar5[6];
      uStack_5c = puVar5[7];
      uStack_58 = puVar5[8];
      uStack_54 = puVar5[9];
      uStack_50 = puVar5[10];
      uStack_4c = puVar5[0xb];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[2] = piVar9[2] + 1;
        UNLOCK();
        piVar9 = *(int **)(param_1 + 0x78);
      }
      uStack_28 = *(undefined4 *)(param_1 + 0x74);
      piStack_24 = piVar9;
      FUN_00587490(&uStack_38);
      uStack_108 = uStack_38;
      uStack_100 = uStack_78;
      uStack_fc = uStack_74;
      uStack_f8 = uStack_70;
      uStack_f4 = uStack_6c;
      piStack_104 = piStack_34;
      uStack_38 = 0;
      piStack_34 = (int *)0x0;
      uStack_f0 = uStack_68;
      uStack_ec = uStack_64;
      uStack_e8 = uStack_60;
      uStack_e4 = uStack_5c;
      uStack_d0 = 0;
      uStack_e0 = uStack_58;
      uStack_dc = uStack_54;
      uStack_d8 = uStack_50;
      uStack_d4 = uStack_4c;
      uStack_14 = 0;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar4 = piVar9[2] + -1;
        piVar9[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
      puVar5 = (undefined4 *)FUN_00c3bd20();
      piVar9 = *(int **)(param_1 + 0x80);
      uStack_78 = *puVar5;
      uStack_74 = puVar5[1];
      uStack_70 = puVar5[2];
      uStack_6c = puVar5[3];
      uStack_68 = puVar5[4];
      uStack_64 = puVar5[5];
      uStack_60 = puVar5[6];
      uStack_5c = puVar5[7];
      uStack_58 = puVar5[8];
      uStack_54 = puVar5[9];
      uStack_50 = puVar5[10];
      uStack_4c = puVar5[0xb];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[2] = piVar9[2] + 1;
        UNLOCK();
        piVar9 = *(int **)(param_1 + 0x80);
      }
      uStack_28 = *(undefined4 *)(param_1 + 0x7c);
      piStack_24 = piVar9;
      FUN_00587490(&iStack_40);
      iStack_cc = iStack_40;
      uStack_c4 = uStack_78;
      uStack_c0 = uStack_74;
      uStack_bc = uStack_70;
      uStack_b8 = uStack_6c;
      piStack_c8 = piStack_3c;
      iStack_40 = 0;
      piStack_3c = (int *)0x0;
      uStack_b4 = uStack_68;
      uStack_b0 = uStack_64;
      uStack_ac = uStack_60;
      uStack_a8 = uStack_5c;
      uStack_94 = 0;
      uStack_a4 = uStack_58;
      uStack_a0 = uStack_54;
      uStack_9c = uStack_50;
      uStack_98 = uStack_4c;
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar4 = piVar9[2] + -1;
        piVar9[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
      FUN_0054ef60(*(undefined4 *)(param_1 + 0x28));
      iStack_2c = 0;
      uStack_14 = 2;
      iVar4 = *param_3;
      if (0 < (param_3[1] - iVar4) / 0xd8) {
        iVar3 = 0;
        do {
          puVar5 = *(undefined4 **)(iVar3 + iVar4);
          if (puVar5 == &DAT_02134d38) {
            iVar4 = *(int *)(iVar3 + 4 + iVar4);
            iVar6 = FUN_00888530();
            if (iVar4 == iVar6) {
              uStack_d0 = 1;
              uStack_50 = 0;
              uStack_4c = 0;
              FUN_005587e0(&uStack_50);
              FUN_00550b30();
            }
            else {
              uVar7 = FUN_00605c00();
              uVar7 = FUN_0068f3e0(&uStack_60,uVar7);
              FUN_005587e0(uVar7);
              FUN_00550b30();
            }
          }
          else if (puVar5 == &DAT_02134d74) {
            iVar4 = *(int *)(iVar3 + 4 + iVar4);
            iVar6 = FUN_00888530();
            if (iVar4 == iVar6) {
              uStack_28 = 0;
              piStack_24 = (int *)0x0;
              FUN_005587e0(&uStack_28);
              FUN_00550b30();
              uStack_94 = 1;
            }
            else {
              uVar7 = FUN_00605c00();
              uVar7 = FUN_0068f3e0(&uStack_70,uVar7);
              FUN_005587e0(uVar7);
              FUN_00550b30();
            }
          }
          else if (puVar5 == (undefined4 *)&DAT_0211a3a0) {
            uVar7 = FUN_0055d610();
            FUN_00551230(uVar7);
          }
          else if (puVar5 == (undefined4 *)&DAT_02134e5c) {
            puVar5 = (undefined4 *)FUN_0068f2a0();
            uStack_100 = *puVar5;
            uStack_fc = puVar5[1];
            uStack_f8 = puVar5[2];
            uStack_f4 = puVar5[3];
            uStack_f0 = puVar5[4];
            uStack_ec = puVar5[5];
            uStack_e8 = puVar5[6];
            uStack_e4 = puVar5[7];
            uStack_e0 = puVar5[8];
            uStack_dc = puVar5[9];
            uStack_d8 = puVar5[10];
            uStack_d4 = puVar5[0xb];
          }
          else if (puVar5 == (undefined4 *)&DAT_02134e94) {
            puVar5 = (undefined4 *)FUN_0068f2a0();
            uStack_c4 = *puVar5;
            uStack_c0 = puVar5[1];
            uStack_bc = puVar5[2];
            uStack_b8 = puVar5[3];
            uStack_b4 = puVar5[4];
            uStack_b0 = puVar5[5];
            uStack_ac = puVar5[6];
            uStack_a8 = puVar5[7];
            uStack_a4 = puVar5[8];
            uStack_a0 = puVar5[9];
            uStack_9c = puVar5[10];
            uStack_98 = puVar5[0xb];
          }
          iVar3 = iVar3 + 0xd8;
          iStack_2c = iStack_2c + 1;
          iVar4 = *param_3;
        } while (iStack_2c < (param_3[1] - iVar4) / 0xd8);
      }
      cVar2 = FUN_006943f0(param_1,&uStack_108,iStack_44,param_2);
      if (cVar2 == '\0') {
        uVar7 = 1;
      }
      else {
        if (param_5 != (undefined4 *)0x0) {
          uVar7 = FUN_0068f3a0(*(undefined4 *)(iStack_cc + 0x34));
          *param_5 = uVar7;
        }
        if (param_4 != (undefined *)0x0) {
          *param_4 = 1;
        }
        uVar7 = 0;
      }
      if (0xf < uStack_7c) {
        uVar8 = uStack_7c + 1;
        iVar4 = iStack_90;
        if (0xfff < uVar8) {
          iVar4 = *(int *)(iStack_90 + -4);
          uVar8 = uStack_7c + 0x24;
          if (0x1f < (iStack_90 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar8);
      }
      piVar9 = piStack_c8;
      if (piStack_c8 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_c8[1] + -1;
        piStack_c8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_c8)();
          LOCK();
          piVar1 = piVar9 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      piVar9 = piStack_104;
      if (piStack_104 == (int *)0x0) {
        ExceptionList = pvStack_1c;
        return uVar7;
      }
      LOCK();
      iVar4 = piStack_104[1] + -1;
      piStack_104[1] = iVar4;
      UNLOCK();
      if (iVar4 != 0) {
        ExceptionList = pvStack_1c;
        return uVar7;
      }
      (**(code **)*piStack_104)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar9 + 4))();
        ExceptionList = pvStack_1c;
        return uVar7;
      }
      ExceptionList = pvStack_1c;
      return uVar7;
    }
  }
  ExceptionList = pvStack_1c;
  return 1;
}



/* FUNCTION 8329 ; VA 0x00690e10 ; FUN_00690e10 */

undefined4 FUN_00690e10(int *param_1,int param_2,uint *param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_4c [56];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_1 != (int *)0x0) &&
     (iVar4 = param_1[3], ExceptionList = &pvStack_10, iVar2 = FUN_00913630(),
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    if (param_1[0xd] == 0) {
      if ((param_2 == 0) ||
         (iVar4 = *(int *)(param_2 + 0xc), iVar2 = FUN_00961580(),
         (uint)*(ushort *)(iVar2 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
        param_2 = 0;
      }
      *param_3 = (uint)(param_2 == 0);
      ExceptionList = pvStack_10;
      return 1;
    }
    if (param_2 != param_1[0xd]) {
      piVar3 = (int *)FUN_00606b30(*puStack_14);
      if (piVar3 != (int *)0x0) {
        iVar4 = (**(code **)(*piVar3 + 0xb8))();
        if (iVar4 == 0) {
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 0;
          puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x10))();
          if (0xf < (uint)puVar5[5]) {
            puVar5 = (undefined4 *)*puVar5;
          }
          FUN_0151f850(&DAT_018d20dc,puVar5);
          (**(code **)(*piVar3 + 0x294))(0x10f,"PlayerlessParent",6,2,auStack_4c,0);
          FUN_0151f7f0();
        }
        else {
          (**(code **)(*piVar3 + 0x290))("Playerless",7,2,"MovedPlayerFe");
        }
      }
      *param_3 = 1;
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  cVar1 = FUN_0068f520(param_2,param_3);
  if ((((cVar1 == '\0') && (cVar1 = FUN_0068f570(param_2,param_3), cVar1 == '\0')) &&
      (cVar1 = FUN_0068f5c0(param_2,param_3), cVar1 == '\0')) &&
     ((cVar1 = FUN_0068f610(param_2,param_3), cVar1 == '\0' &&
      (cVar1 = FUN_006908c0(param_1,param_3), cVar1 == '\0')))) {
    if ((param_1 == (int *)0x0) || (*(char *)((int)param_1 + 0x22) == '\0')) {
      ExceptionList = pvStack_10;
      return 0;
    }
    FUN_0086f2f0(2,"trying to set locked parent!");
    *param_3 = 1;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8330 ; VA 0x00690ff0 ; FUN_00690ff0 */

int __thiscall FUN_00690ff0(undefined4 *param_1,int param_2,int param_3)

{
  bool bVar1;
  bool bVar2;
  bool bVar3;
  undefined4 *puVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  double *pdVar10;
  double dVar11;
  undefined auStack_1c [4];
  int iStack_18;
  int iStack_14;
  int iStack_10;
  undefined4 *puStack_c;
  char cStack_5;
  
  iStack_10 = 1;
  puStack_c = param_1;
  if (((param_2 != 0) &&
      (iVar7 = *(int *)(param_2 + 0xc), iVar6 = FUN_00c39bb0(),
      (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
      (uint)*(ushort *)(iVar6 + 0x1da))) && (param_3 != 0)) {
    return 1;
  }
  puVar4 = puStack_c;
  if (param_2 == puStack_c[1]) {
    iVar7 = FUN_006901a0(*puStack_c,param_3);
    return iVar7;
  }
  if (param_3 == 0) goto LAB_006912cb;
  uVar8 = (**(code **)(*(int *)*puStack_c + 0xb4))();
  cVar5 = FUN_006915f0(param_2,uVar8);
  if ((cVar5 == '\0') || (iStack_14 = (**(code **)(*(int *)*puVar4 + 0xb4))(), iStack_14 == 0))
  goto LAB_006912cb;
  if ((*(int *)(iStack_14 + 100) == 0) ||
     (cVar5 = FUN_006915a0(param_2,param_3,*(int *)(iStack_14 + 100)), cVar5 == '\0')) {
    iVar7 = iStack_10;
    if (iStack_10 == 1) {
      cVar5 = FUN_006915a0(param_2,param_3,iStack_14);
      iStack_10 = iVar7;
      if (cVar5 == '\0') goto LAB_006912cb;
      goto LAB_006910d3;
    }
    iStack_10 = iVar7;
    if (iStack_10 != 0) goto LAB_006912cb;
  }
  else {
LAB_006910d3:
    iStack_10 = 0;
  }
  FUN_006908c0(param_3,&iStack_10);
  if ((iStack_10 != 0) || (FUN_0068f4d0(param_3,&iStack_10), iStack_10 != 0)) goto LAB_006912cb;
  iVar7 = FUN_0068f370();
  if ((iVar7 == 0) || (iVar6 = *(int *)(iVar7 + 0x34), iVar6 == param_3)) {
LAB_006911d5:
    if (iStack_10 != 0) goto LAB_006912cb;
    iVar7 = FUN_0068f2d0();
    if ((iVar7 == 0) ||
       (iVar7 = *(int *)(param_3 + 0xc), iVar6 = FUN_008aa870(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
       (uint)*(ushort *)(iVar6 + 0x1da))) {
      if (iStack_10 != 0) goto LAB_006912cb;
      if ((DAT_01d5b0b0 != '\0') || (iVar7 = FUN_0068f2d0(), iVar7 != 0)) {
        iVar7 = *(int *)(iStack_14 + 0x90);
        dVar11 = *(double *)(iStack_14 + 0x88);
        pdVar10 = (double *)FUN_016830f0(auStack_1c);
        dVar11 = *pdVar10 - dVar11;
        if (((10 < iVar7) && (dVar11 < DAT_018d8a10)) || ((0 < iVar7 && (dVar11 < DAT_018c0d60))))
        goto LAB_006912be;
      }
      if ((iStack_10 != 0) ||
         (((iStack_10 = FUN_006901a0(*puStack_c,param_3), iStack_10 != 0 || (param_2 == 0)) ||
          (*(char *)(param_2 + 0x22) == '\0')))) goto LAB_006912cb;
      FUN_0086f2f0(2,"trying to set locked parent!");
    }
  }
  else {
    iVar9 = thunk_FUN_0068f830();
    iStack_18 = *(int *)(iStack_14 + 100);
    if ((iVar6 != iVar9) || (bVar2 = true, param_3 != iStack_18)) {
      bVar2 = false;
    }
    if ((iVar6 != iStack_18) || (bVar3 = true, param_3 != iVar9)) {
      bVar3 = false;
    }
    iVar9 = FUN_00c47ac0();
    if ((iVar9 != 2) || (cStack_5 = '\x01', param_3 != iStack_18)) {
      cStack_5 = '\0';
    }
    if (((*(char *)(iVar7 + 0x149) == '\0') || (iVar6 != iStack_18)) ||
       (iVar7 = *(int *)(param_3 + 0xc), iVar6 = FUN_008aa870(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      bVar1 = false;
    }
    else {
      bVar1 = true;
    }
    if (((bVar2) || (bVar3)) || ((cStack_5 != '\0' || (bVar1)))) goto LAB_006911d5;
  }
LAB_006912be:
  iStack_10 = 1;
LAB_006912cb:
  puStack_c[1] = 0;
  return iStack_10;
}



/* FUNCTION 8331 ; VA 0x006912e0 ; FUN_006912e0 */

undefined4 FUN_006912e0(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_0099be20();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar3 = FUN_009b7250();
      if (iVar3 != 0) {
        iVar3 = FUN_00c15700();
        if (iVar3 != 0) {
          FUN_00b06640(iVar3);
          FUN_00b07ca0(&param_1);
          if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
              DAT_01eadcf4) {
            FUN_016f3809(&DAT_01eadcf4);
            if (DAT_01eadcf4 == -1) {
              DAT_01eadcf0 = 0xffffffff;
              FUN_016f37bf(&DAT_01eadcf4);
            }
          }
          uStack_8 = DAT_01eadcf0;
          cVar1 = FUN_00a33d60(&uStack_8);
          if (cVar1 == '\0') {
            uStack_c = 2;
            cVar1 = FUN_00a33d60(&uStack_c);
            if (cVar1 == '\0') {
              uVar4 = (**(code **)(*param_2 + 0xb0))(&uStack_c);
              cVar1 = FUN_005e0cd0(uVar4);
              if (cVar1 == '\0') {
                return 0;
              }
            }
          }
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 8332 ; VA 0x00691400 ; FUN_00691400 */

uint __thiscall FUN_00691400(int param_1,uint param_2)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  
  if (*(int *)(param_1 + 0x1f0) == *(int *)(param_1 + 500)) {
    return 0;
  }
  if (param_2 == *(uint *)(param_1 + 0x200)) {
    return 0;
  }
  uVar1 = (param_2 >> 3) + param_2;
  uVar4 = (*(int *)(param_1 + 500) - *(int *)(param_1 + 0x1f0)) / 0xc - 1;
  uVar3 = 0;
  do {
    uVar1 = uVar1 & uVar4;
    puVar2 = (uint *)(*(int *)(param_1 + 0x1f0) + uVar1 * 0xc);
    if (*puVar2 == param_2) goto LAB_00691499;
    if (*puVar2 == *(uint *)(param_1 + 0x200)) break;
    uVar1 = uVar1 + 1 + uVar3;
    uVar3 = uVar3 + 1;
  } while (uVar3 <= uVar4);
  puVar2 = (uint *)0x0;
LAB_00691499:
  return (uint)(puVar2 + 1) & -(uint)(puVar2 != (uint *)0x0);
}



/* FUNCTION 8333 ; VA 0x006914b0 ; FUN_006914b0 */

undefined4 __thiscall FUN_006914b0(int param_1,uint param_2)

{
  byte *pbVar1;
  int iStack_8;
  
  pbVar1 = *(byte **)(param_1 + 8);
  if (pbVar1 != (byte *)0x0) {
    iStack_8 = param_1;
    FUN_00606ea0(&iStack_8,(param_2 >> 3) + param_2,&param_2,
                 -(uint)(pbVar1 + *pbVar1 + 1 != (byte *)0x0) & (uint)(pbVar1 + *pbVar1 + 1 + 1));
    if (iStack_8 != 0) {
      return *(undefined4 *)(iStack_8 + 0xc);
    }
  }
  return 0;
}



/* FUNCTION 8334 ; VA 0x00691510 ; FUN_00691510 */

bool __fastcall FUN_00691510(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  iVar1 = 0;
  piVar4 = (int *)0x0;
  iVar2 = *(int *)(param_1 + 0x168);
  if (iVar2 != 0) {
    iVar3 = *(int *)(iVar2 + 4);
    piVar5 = (int *)(iVar2 + 4);
    if (iVar3 != 0) {
      do {
        LOCK();
        iVar2 = *piVar5;
        if (iVar3 == iVar2) {
          *piVar5 = iVar3 + 1;
          iVar2 = iVar3;
        }
        UNLOCK();
        if (iVar2 == iVar3) {
          iVar1 = *(int *)(param_1 + 0x164);
          piVar4 = *(int **)(param_1 + 0x168);
          goto LAB_00691553;
        }
        iVar3 = *piVar5;
      } while (iVar3 != 0);
      iVar1 = 0;
    }
  }
LAB_00691553:
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar5 = piVar4 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return iVar1 != 0;
}



/* FUNCTION 8335 ; VA 0x006915a0 ; FUN_006915a0 */

undefined4 FUN_006915a0(int param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  
  iVar1 = *(int *)(param_1 + 0x34);
  if (iVar1 == param_2) {
    if (param_2 == param_3) {
      return 1;
    }
    if (param_3 == *(int *)(param_2 + 0x34)) {
      return 1;
    }
    if (*(int *)(param_2 + 0x34) == 0) {
      return 0;
    }
  }
  else {
    if (iVar1 == 0) {
      return 0;
    }
    if (iVar1 == param_3) {
      return 1;
    }
  }
  cVar2 = FUN_00620ec0(param_3);
  if (cVar2 == '\0') {
    return 0;
  }
  return 1;
}



/* FUNCTION 8336 ; VA 0x006915f0 ; FUN_006915f0 */

undefined4 FUN_006915f0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  iVar2 = *(int *)(param_1 + 0xc);
  iVar4 = FUN_00c46280();
  iVar5 = 0;
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da)) {
    iVar5 = param_1;
  }
  if (iVar5 == 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar4 = FUN_00c8dce0();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar5 = param_1;
    }
    if (iVar5 == 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar4 = FUN_00c86e90();
      iVar5 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        iVar5 = param_1;
      }
      if (iVar5 == 0) {
        iVar2 = *(int *)(param_1 + 0xc);
        iVar4 = FUN_00c88fe0();
        iVar5 = 0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
            (uint)*(ushort *)(iVar4 + 0x1da)) {
          iVar5 = param_1;
        }
        if (iVar5 == 0) {
          if (param_2 != 0) {
            iVar2 = *(int *)(param_2 + 100);
            iVar5 = FUN_00676c30();
            if ((iVar2 != 0) && (iVar5 != 0)) {
              piVar6 = *(int **)(iVar5 + 0x28);
              piVar1 = piVar6 + 4;
              if (0xf < (uint)piVar6[5]) {
                piVar6 = (int *)*piVar6;
              }
              cVar3 = FUN_0055c360(piVar6,*piVar1,"RightGrip",9);
              if (cVar3 != '\0') {
                return 1;
              }
              iVar5 = FUN_00c3c010();
              if (iVar5 == 0) {
                return 1;
              }
              FUN_00c3c010();
              cVar3 = FUN_00620ec0(iVar2);
              if (cVar3 == '\0') {
                return 1;
              }
              return 0;
            }
          }
          return 0;
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 8337 ; VA 0x00691720 ; FUN_00691720 */

undefined4 * FUN_00691720(undefined4 *param_1)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5cd9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined *)FUN_01674e20(0x18);
  puStack_18 = puVar1;
  if (puVar1 == (undefined *)0x0) {
    puVar1 = (undefined *)0x0;
  }
  else {
    *puVar1 = 0;
    uVar2 = FUN_00588320(0xb);
    *(undefined4 *)(puVar1 + 4) = uVar2;
    *(undefined4 *)(puVar1 + 8) = 0;
    *(undefined4 *)(puVar1 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar1 + 0x10) = 0;
    *(undefined4 *)(puVar1 + 0x14) = 0;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0068f210(puVar1,param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  FUN_00c58600();
  uVar2 = FUN_0086e8f0("OnServerEvent");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptProductPurchaseFinished");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptPurchaseFinished");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptPremiumPurchaseFinished");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d66edc != '\0') {
    FUN_00b12040();
    uVar2 = FUN_0086e8f0("PromptBundlePurchaseFinished");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("ConfirmPlayerMembership");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("MockPurchasePremium");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d63cb0 != '\0') {
    FUN_00b12040();
    uVar2 = FUN_0086e8f0("MockPurchaseSubscription");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
  }
  if (DAT_01d5b0c8 == '\0') {
    FUN_00b12040();
    uVar2 = FUN_0086e8f0("PromptThirdPartyPurchaseRequested");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00b12040();
    uVar2 = FUN_0086e8f0("PromptNativePurchaseRequested");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00b12040();
    uVar2 = FUN_0086e8f0("ServerPurchaseVerification");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptPurchaseRequested");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptProductPurchaseRequested");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptGamePassPurchaseRequested");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d66edc != '\0') {
    FUN_00b12040();
    uVar2 = FUN_0086e8f0("PromptBundlePurchaseRequested");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("ClientPurchaseSuccess");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("PromptGamePassPurchaseFinished");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c46280();
  uVar2 = FUN_0086e8f0("Activated");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c46280();
  uVar2 = FUN_0086e8f0("Deactivated");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("SimulationRadiusChanged");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00b12040();
  uVar2 = FUN_0086e8f0("LuaDialogCallbackSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00ae2430();
  uVar2 = FUN_0086e8f0("RequestLock");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00ae2430();
  uVar2 = FUN_0086e8f0("LockGrantedOrNot");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00ae2430();
  uVar2 = FUN_0086e8f0("RequestScriptHash");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00ae2430();
  uVar2 = FUN_0086e8f0("VerifyScriptHash");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("RequestCloudEditKick");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("RequestCloudEditShutdown");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("RequestCloudEditImmediatePublish");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("RequestTeamCreateImmediateSave");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("CloudEditServerMessage");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("CloudEditApplyEditsMessage");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00961580();
  uVar2 = FUN_0086e8f0("OnLinkedScriptsUpdated");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d656d0 != '\0') {
    FUN_009ef640();
    uVar2 = FUN_0086e8f0("ScriptStartEdit");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_009ef640();
    uVar2 = FUN_0086e8f0("ScriptStopEdit");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_009ef640();
    uVar2 = FUN_0086e8f0("ScriptSubmitChanges");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    if (DAT_01d656d8 != '\0') {
      FUN_0068f950("RequestAllEditorsSignal",1);
    }
    if (DAT_01d65700 != '\0') {
      FUN_0068f950("ScriptBatchCommit",1);
    }
    if (DAT_01d65718 != '\0') {
      FUN_0068f950("LockedScriptBatchCommit",1);
    }
  }
  FUN_00c8d8e0();
  uVar2 = FUN_0086e8f0("RemoteDestroyMotor6D");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c8d8e0();
  uVar2 = FUN_0086e8f0("RemoteCreateMotor6D");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c88fe0();
  uVar2 = FUN_0086e8f0("RemoteDestroyMotor6D");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c88fe0();
  uVar2 = FUN_0086e8f0("RemoteCreateMotor6D");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c86e90();
  uVar2 = FUN_0086e8f0("RemoteDestroySeatWeld");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c86e90();
  uVar2 = FUN_0086e8f0("RemoteCreateSeatWeld");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c63380();
  uVar2 = FUN_0086e8f0("RemoteDestroySeatWeld");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c63380();
  uVar2 = FUN_0086e8f0("RemoteCreateSeatWeld");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("ServerEquipTool");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  if (DAT_01ee37b0 == '\0') {
    FUN_0099be20();
    uVar2 = FUN_0086e8f0("SetNetworkedHumanoidState");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 3;
    }
  }
  FUN_00ae6b40();
  uVar2 = FUN_0086e8f0("OnCombinedUpdate");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 4;
  }
  FUN_00c55950();
  uVar2 = FUN_0086e8f0("MouseActionReplicated");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d68228 != '\0') {
    FUN_00c51e00();
    uVar2 = FUN_0086e8f0("TriggeredActionReplicated");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c51e00();
    uVar2 = FUN_0086e8f0("TriggerEndedActionReplicated");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    if (DAT_01d68824 != '\0') {
      FUN_0068f900("ButtonHoldBeganActionReplicated",1);
      FUN_0068f900("ButtonHoldEndedActionReplicated",1);
    }
  }
  FUN_00ac0f70();
  uVar2 = FUN_0086e8f0("TeleportInitFailed");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00ac0f70();
  uVar2 = FUN_0086e8f0("TeleportInProgress");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0(&DAT_018d8440);
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bd5c00();
  uVar2 = FUN_0086e8f0("RequestScriptExecutionSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bd5c00();
  uVar2 = FUN_0086e8f0("RequestServerOutputSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bd5c00();
  uVar2 = FUN_0086e8f0("RequestServerHttpResultSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bd5c00();
  uVar2 = FUN_0086e8f0("RequestHttpResultApprovedSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c58700();
  uVar2 = FUN_0086e8f0("RemoteOnInvokeServer");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c58700();
  uVar2 = FUN_0086e8f0("RemoteOnInvokeClient");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c58700();
  uVar2 = FUN_0086e8f0("RemoteOnInvokeSuccess");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c58700();
  uVar2 = FUN_0086e8f0("RemoteOnInvokeError");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c8dce0();
  uVar2 = FUN_0086e8f0("ServerEquipAccoutrement");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c8dce0();
  uVar2 = FUN_0086e8f0("ServerUnequipAccoutrement");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00add460();
  uVar2 = FUN_0086e8f0("TimePositionUpdatedFromClient");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 6;
  }
  FUN_00add460();
  uVar2 = FUN_0086e8f0("PlayingUpdatedFromClient");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 6;
  }
  FUN_00add460();
  uVar2 = FUN_0086e8f0("playbackActionSync");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 6;
  }
  FUN_00a75310();
  uVar2 = FUN_0086e8f0("ClientToServerFilterMessageSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00a75310();
  uVar2 = FUN_0086e8f0("ServerToClientUnderOver13FilteredResponseSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00a75310();
  uVar2 = FUN_0086e8f0("ClientToServerReportUnfilteredSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00a75310();
  uVar2 = FUN_0086e8f0("ClientToServerFilterMessageSignalV2");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bea180();
  uVar2 = FUN_0086e8f0("RemoteFriendStatusSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bea180();
  uVar2 = FUN_0086e8f0("RemoteFriendEventSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00bd37d0();
  uVar2 = FUN_0086e8f0("ReplicatedSelected");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b85410();
  uVar2 = FUN_0086e8f0("InsertRequestAsset");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b85410();
  uVar2 = FUN_0086e8f0("InsertRequestAssetVersion");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b85410();
  uVar2 = FUN_0086e8f0("InsertReady");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b85410();
  uVar2 = FUN_0086e8f0("InsertError");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00b85410();
  uVar2 = FUN_0086e8f0("InternalDelete");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00aff8c0();
  uVar2 = FUN_0086e8f0("NetworkOwnerChangedBroadcast");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00aff8c0();
  uVar2 = FUN_0086e8f0("NetworkOwnerChanged");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c4b970();
  uVar2 = FUN_0086e8f0("ConfirmDefaultScripts");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c4b970();
  uVar2 = FUN_0086e8f0("RequestDefaultScripts");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("RemoteFriendServiceSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("RemoteFriendRequestSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("SetShutdownMessage");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("ScriptSecurityError");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("RemoteInsert");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("StatsAvailable");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("ConnectDiedSignalBackend");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("CloudEditSelectionChanged");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("OnTeleportInternal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("BlockedRequestFinishedSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("BlockUserSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00a36d80();
  uVar2 = FUN_0086e8f0("TextScraperClientMessageWithPlayerSignal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c2a7d0();
  uVar2 = FUN_0086e8f0("GameInvitePromptClosed");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d5b0b8 != '\0') {
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseEnter");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseLeave");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseDrag");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseButton1Down");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseButton1Up");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseEnter");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseLeave");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseMoved");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseWheelForward");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseWheelBackward");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("DragStopped");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("DragBegin");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton1Click");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton2Click");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton1Down");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton1Up");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton2Down");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton2Up");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseEnter");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseLeave");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseDrag");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseButton1Down");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseButton1Up");
    piVar5 = (int *)FUN_00691400(uVar2);
    if ((piVar5 != (int *)0x0) &&
       (puStack_18 = (undefined *)*piVar5, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8338 ; VA 0x00693470 ; FUN_00693470 */

undefined4 * FUN_00693470(undefined4 *param_1)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5cd9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined *)FUN_01674e20(0x18);
  puStack_18 = puVar1;
  if (puVar1 == (undefined *)0x0) {
    puVar1 = (undefined *)0x0;
  }
  else {
    *puVar1 = 0;
    uVar2 = FUN_00588320(0xb);
    *(undefined4 *)(puVar1 + 4) = uVar2;
    *(undefined4 *)(puVar1 + 8) = 0;
    *(undefined4 *)(puVar1 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar1 + 0x10) = 0;
    *(undefined4 *)(puVar1 + 0x14) = 0;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0068f210(puVar1,param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  FUN_0099be20();
  uVar2 = FUN_0086e8f0(&DAT_018d7b94);
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("JumpReplicate");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0(&DAT_018d7bac);
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("WalkDirection");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("MoveDirectionInternal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("WalkAngleError");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("Strafe");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("CameraMinDistance");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("CameraMaxDistance");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("CameraMode");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 2;
  }
  FUN_0099be20();
  uVar2 = FUN_0086e8f0("FloorMaterialInternal");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 3;
  }
  if (DAT_01ee37b0 != '\0') {
    FUN_0099be20();
    uVar2 = FUN_0086e8f0("NetworkHumanoidState");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 3;
    }
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("ChatPrivacyMode");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("OsPlatform");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("FollowUserIdReplicated");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("GameplayPaused");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("ChararacterRegionId");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00c67ac0();
  uVar2 = FUN_0086e8f0("Throttle");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c67ac0();
  uVar2 = FUN_0086e8f0("Steer");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c63380();
  uVar2 = FUN_0086e8f0("ThrottleFloat");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c63380();
  uVar2 = FUN_0086e8f0("SteerFloat");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("MaxSimulationRadius");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00913630();
  uVar2 = FUN_0086e8f0("CloudEditCameraCoordinateFrame");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 5;
  }
  FUN_00aff8c0();
  uVar2 = FUN_0086e8f0("NetworkIsSleeping");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c68a10();
  uVar2 = FUN_0086e8f0("ReplicatingAbsoluteSize");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c68a10();
  uVar2 = FUN_0086e8f0("ReplicatingAbsolutePosition");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c88fe0();
  uVar2 = FUN_0086e8f0("MoveState");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c8dce0();
  uVar2 = FUN_0086e8f0("BackendAccoutrementState");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  FUN_00c809f0();
  uVar2 = FUN_0086e8f0("Active");
  puVar3 = (undefined4 *)FUN_00691400(uVar2);
  if ((puVar3 != (undefined4 *)0x0) &&
     (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  if (DAT_01d5b0c0 == '\0') {
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseEnterConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseLeaveConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseDragConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseButton1DownConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c7e1e0();
    uVar2 = FUN_0086e8f0("MouseButton1UpConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseEnterConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseLeaveConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseMovedConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseWheelForwardConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("MouseWheelBackwardConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("DragStoppedConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6de80();
    uVar2 = FUN_0086e8f0("DragBeginConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton1ClickConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton2ClickConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton1DownConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton1UpConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton2DownConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6dcc0();
    uVar2 = FUN_0086e8f0("MouseButton2UpConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseEnterConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseLeaveConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseDragConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseButton1DownConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
    FUN_00c6ac40();
    uVar2 = FUN_0086e8f0("MouseButton1UpConnectionCount");
    puVar3 = (undefined4 *)FUN_00691400(uVar2);
    if ((puVar3 != (undefined4 *)0x0) &&
       (puStack_18 = (undefined *)*puVar3, puStack_18 != (undefined *)0x0)) {
      iVar4 = FUN_0068fd30(&puStack_18);
      *(undefined4 *)(iVar4 + 4) = 1;
    }
  }
  thunk_FUN_00897b90();
  uVar2 = FUN_0086e8f0("Parent");
  piVar5 = (int *)FUN_00691400(uVar2);
  if ((piVar5 != (int *)0x0) && (puStack_18 = (undefined *)*piVar5, puStack_18 != (undefined *)0x0))
  {
    iVar4 = FUN_0068fd30(&puStack_18);
    *(undefined4 *)(iVar4 + 4) = 1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8339 ; VA 0x006941e0 ; FUN_006941e0 */

void __thiscall FUN_006941e0(undefined4 *param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  param_1[1] = 0;
  iVar2 = (**(code **)(*(int *)*param_1 + 0xb4))();
  if (iVar2 != 0) {
    if (*(int *)(iVar2 + 100) != 0) {
      iVar2 = *(int *)(iVar2 + 100);
    }
    if ((param_3 == iVar2) || (cVar1 = FUN_00620ec0(iVar2), cVar1 != '\0')) {
      uVar3 = (**(code **)(*(int *)*param_1 + 0xb4))();
      cVar1 = FUN_006915f0(param_2,uVar3);
      if ((cVar1 != '\0') || (*(int *)(param_2 + 0x34) == 0)) {
        param_1[1] = param_2;
      }
    }
  }
  return;
}



/* FUNCTION 8340 ; VA 0x00694250 ; FUN_00694250 */

undefined4 FUN_00694250(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    piVar8 = *(int **)(iVar1 + 0x28);
    piVar7 = piVar8 + 4;
    if (0xf < (uint)piVar8[5]) {
      piVar8 = (int *)*piVar8;
    }
    cVar3 = FUN_0055c360(piVar8,*piVar7,"Handle",6);
    if ((((cVar3 != '\0') && (iVar1 = *(int *)(iVar1 + 0x34), iVar1 != 0)) &&
        (iVar5 = *(int *)(iVar1 + 0xc), iVar4 = FUN_00c46280(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) &&
       ((cVar3 = FUN_00971ce0(param_2,1), cVar3 == '\0' || (*(int *)(iVar1 + 0x16c) == 0)))) {
      iVar5 = *(int *)(iVar1 + 0x168);
      piVar7 = (int *)0x0;
      param_1 = (int *)0x0;
      if (iVar5 != 0) {
        piVar8 = (int *)(iVar5 + 4);
        iVar5 = *(int *)(iVar5 + 4);
        while (iVar5 != 0) {
          LOCK();
          iVar4 = *piVar8;
          if (iVar5 == iVar4) {
            *piVar8 = iVar5 + 1;
            iVar4 = iVar5;
          }
          UNLOCK();
          if (iVar4 == iVar5) {
            param_1 = *(int **)(iVar1 + 0x164);
            piVar7 = *(int **)(iVar1 + 0x168);
            break;
          }
          iVar5 = *piVar8;
        }
      }
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar8 = piVar7 + 2;
          iVar5 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (param_1 == (int *)0x0) {
        cVar3 = FUN_00620ec0(param_2);
        if (cVar3 != '\0') {
          return 1;
        }
        iVar5 = FUN_00980070(param_2);
        if ((iVar5 != 0) && (puVar2 = *(undefined4 **)(iVar5 + 0x2c), puVar2 != (undefined4 *)0x0))
        {
          piVar7 = (int *)puVar2[1];
          for (piVar8 = (int *)*puVar2; piVar8 != piVar7; piVar8 = piVar8 + 2) {
            iVar5 = *piVar8;
            if ((iVar5 != 0) &&
               (iVar4 = *(int *)(iVar5 + 0xc), iVar6 = FUN_00c91ca0(),
               (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
               (uint)*(ushort *)(iVar6 + 0x1da))) {
              if (iVar5 == 0) {
                return 0;
              }
              if (iVar5 == *(int *)(iVar1 + 0x34)) {
                return 1;
              }
              if (*(int *)(iVar1 + 0x34) == 0) {
                return 0;
              }
              cVar3 = FUN_00620ec0(iVar5);
              if (cVar3 == '\0') {
                return 0;
              }
              return 1;
            }
          }
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 8341 ; VA 0x006943f0 ; FUN_006943f0 */

undefined4 FUN_006943f0(undefined4 param_1,int *param_2,int param_3,int param_4)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_10 [8];
  int iStack_8;
  
  piVar5 = param_2 + 0x1e;
  if (0xf < (uint)param_2[0x23]) {
    piVar5 = (int *)*piVar5;
  }
  cVar2 = FUN_0055c360(piVar5,param_2[0x22],"RightGrip",9);
  if ((((cVar2 != '\0') && (*(char *)(param_2 + 0xe) == '\0')) &&
      (*(char *)(param_2 + 0x1d) == '\0')) &&
     ((iVar1 = *param_2, iVar1 != 0 && (param_2[0xf] != 0)))) {
    iVar4 = *(int *)(iVar1 + 0x34);
    if (param_3 != iVar4) {
      if (iVar4 == 0) {
        cVar2 = '\0';
      }
      else {
        cVar2 = FUN_00620ec0(param_3);
      }
      if (cVar2 == '\0') {
        return 0;
      }
    }
    if ((param_4 == iVar1) && (iVar4 == param_3)) {
      piVar5 = *(int **)(iVar1 + 0x28);
      iVar1 = piVar5[4];
      piVar6 = piVar5;
      if (0xf < (uint)piVar5[5]) {
        piVar6 = (int *)*piVar5;
      }
      cVar2 = FUN_0055c360(piVar6,iVar1,"RightHand",9);
      if (cVar2 == '\0') {
        if (0xf < (uint)piVar5[5]) {
          piVar5 = (int *)*piVar5;
        }
        cVar2 = FUN_0055c360(piVar5,iVar1,"Right Arm",9);
        if (cVar2 == '\0') {
          return 0;
        }
      }
      cVar2 = FUN_00694250(param_2 + 0xf,param_3);
      if (cVar2 != '\0') {
        puVar3 = (undefined4 *)FUN_0068f9a0(auStack_10,param_1);
        param_3 = 0;
        piVar5 = (int *)0x0;
        iVar1 = puVar3[1];
        if (iVar1 != 0) {
          piVar6 = (int *)(iVar1 + 4);
          iVar1 = *(int *)(iVar1 + 4);
          while (iVar1 != 0) {
            LOCK();
            iVar4 = *piVar6;
            if (iVar1 == iVar4) {
              *piVar6 = iVar1 + 1;
              iVar4 = iVar1;
            }
            UNLOCK();
            if (iVar4 == iVar1) {
              piVar5 = (int *)puVar3[1];
              param_3 = *puVar3;
              if (piVar5 != (int *)0x0) {
                LOCK();
                piVar5[2] = piVar5[2] + 1;
                UNLOCK();
                LOCK();
                iVar1 = piVar5[1] + -1;
                piVar5[1] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)*piVar5)();
                  LOCK();
                  iVar1 = piVar5[2] + -1;
                  piVar5[2] = iVar1;
                  UNLOCK();
                  if (iVar1 == 0) {
                    (**(code **)(*piVar5 + 4))();
                  }
                }
              }
              break;
            }
            iVar1 = *piVar6;
          }
        }
        *puVar3 = 0;
        piVar6 = (int *)puVar3[1];
        puVar3[1] = 0;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar1 = piVar6[2] + -1;
          piVar6[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
        *(int *)(iStack_8 + 0x30) = param_3;
        piVar6 = *(int **)(iStack_8 + 0x34);
        *(int **)(iStack_8 + 0x34) = piVar5;
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar5 = piVar6 + 2;
          iVar1 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
        FUN_0056c200();
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 8342 ; VA 0x006945d0 ; FUN_006945d0 */

void FUN_006945d0(void)

{
  undefined auStack_194 [400];
  
  DAT_01eae060 = DAT_01eae060 + 1;
  if (DAT_01eae060 == 1) {
    Ordinal_115(0x202,auStack_194);
  }
  return;
}



/* FUNCTION 8343 ; VA 0x00694600 ; FUN_00694600 */

void FUN_00694600(void)

{
  if (DAT_01eae060 != 0) {
    if (1 < DAT_01eae060) {
      DAT_01eae060 = DAT_01eae060 + -1;
      return;
    }
    Ordinal_116();
    DAT_01eae060 = 0;
  }
  return;
}



/* FUNCTION 8344 ; VA 0x00694630 ; FUN_00694630 */

char * FUN_00694630(int param_1,char *param_2,int param_3)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  char *pcVar5;
  
  pcVar3 = param_2;
  iVar2 = param_1;
  if (0xe < param_3 - 2U) {
    *param_2 = '\0';
    return param_2;
  }
  do {
    pcVar5 = pcVar3;
    uVar4 = iVar2 % param_3 >> 0x1f;
    *pcVar5 = "0123456789abcdef"[(iVar2 % param_3 ^ uVar4) - uVar4];
    pcVar3 = pcVar5 + 1;
    iVar2 = iVar2 / param_3;
  } while (iVar2 != 0);
  if ((param_1 < 0) && (param_3 == 10)) {
    *pcVar3 = '-';
    pcVar3 = pcVar5 + 2;
  }
  *pcVar3 = '\0';
  pcVar3 = pcVar3 + -1;
  pcVar5 = param_2;
  if (param_2 < pcVar3) {
    do {
      cVar1 = *pcVar5;
      *pcVar5 = *pcVar3;
      pcVar5 = pcVar5 + 1;
      *pcVar3 = cVar1;
      pcVar3 = pcVar3 + -1;
    } while (pcVar5 < pcVar3);
  }
  return param_2;
}



/* FUNCTION 8345 ; VA 0x006946b0 ; FUN_006946b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_006946b0(uint param_1,undefined param_2,char *param_3,int param_4,ushort param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  code *pcVar9;
  undefined auStack_74 [32];
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined auStack_34 [24];
  undefined2 uStack_1c;
  undefined2 uStack_1a;
  undefined4 uStack_18;
  undefined8 uStack_14;
  char *pcStack_c;
  int iStack_8;
  
  if (DAT_01eae064 != '\0') {
    FUN_01677520(DAT_01eae064,
                 "CreateBoundSocket() port=%d, blockingSocket=%d, forceHostAddress=%s, sleepOn10048=%d, socketFamily=%d"
                 ,param_1 & 0xffff,param_2,param_3,param_4,(uint)param_5);
  }
  if (DAT_01d5b1e4 != '\0') {
    if (param_4 == 0) {
      FUN_00722890(100);
    }
    iStack_8 = 0;
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    uStack_4c = 2;
    uStack_50 = (uint)param_5;
    FUN_00694630(param_1 & 0xffff,auStack_74,10);
    pcStack_c = (char *)0x0;
    if (((param_3 == (char *)0x0) ||
        (iVar3 = FUN_01717aae(param_3,"UNASSIGNED_SYSTEM_ADDRESS"), iVar3 == 0)) ||
       (*param_3 == '\0')) {
      uStack_54 = 0xd00;
      iVar3 = getaddrinfo(0,auStack_74,&uStack_54,&iStack_8);
    }
    else {
      uStack_54 = 0xc00;
      iVar3 = getaddrinfo(param_3,auStack_74,&uStack_54,&iStack_8);
      pcStack_c = param_3;
    }
    if ((iVar3 != 0) && (DAT_01ee420a != '\0')) {
      FUN_01677520(DAT_01ee420a,"getaddrinfo(...) failed:Error code - %d\n",iVar3);
    }
    pcVar9 = Ordinal_23_exref;
    iVar3 = iStack_8;
    if (DAT_01d5b130 != '\0') {
      for (; iVar3 != 0; iVar3 = *(int *)(iVar3 + 0x1c)) {
        if ((*(int *)(iVar3 + 4) == 2) &&
           (iVar5 = (*pcVar9)(2,*(undefined4 *)(iVar3 + 8),*(undefined4 *)(iVar3 + 0xc)),
           pcVar9 = Ordinal_23_exref, iVar5 != -1)) {
          iVar8 = Ordinal_2(iVar5,*(undefined4 *)(iVar3 + 0x18),*(undefined4 *)(iVar3 + 0x10));
          if (-1 < iVar8) {
            FUN_00695530(iVar5,*(undefined2 *)(iVar3 + 4));
            freeaddrinfo(iStack_8);
            return iVar5;
          }
          pcVar9 = Ordinal_23_exref;
          if (DAT_01ee420a != '\0') {
            puVar7 = (undefined4 *)FUN_0171689d();
            FUN_01677520(DAT_01ee420a,"1.bind__(...) failed:Error code - %d\n",*puVar7);
            pcVar9 = Ordinal_23_exref;
          }
        }
      }
    }
    iVar3 = iStack_8;
    if (iStack_8 != 0) {
      do {
        if (((DAT_01d5b130 == '\0') || (*(int *)(iVar3 + 4) != 2)) &&
           (iVar5 = (*pcVar9)(*(undefined4 *)(iVar3 + 4),*(undefined4 *)(iVar3 + 8),
                              *(undefined4 *)(iVar3 + 0xc)), uVar2 = _UNK_01abb6cc,
           uVar1 = _UNK_01abb6c8, uVar6 = _UNK_01abb6c4, iVar5 != -1)) {
          if ((DAT_01d5b138 != '\0') && ((param_3 == (char *)0x0 || (*param_3 == '\0')))) {
            iVar8 = *(int *)(iVar3 + 0x18);
            if (*(int *)(iVar3 + 4) == 2) {
              *(undefined4 *)(iVar8 + 4) = 0;
              pcStack_c = "inaddr_any";
            }
            else {
              pcStack_c = "in6addr_any";
              *(undefined4 *)(iVar8 + 8) = _DAT_01abb6c0;
              *(undefined4 *)(iVar8 + 0xc) = uVar6;
              *(undefined4 *)(iVar8 + 0x10) = uVar1;
              *(undefined4 *)(iVar8 + 0x14) = uVar2;
            }
          }
          if (((DAT_01d5b140 != '\0') &&
              (FUN_00695530(iVar5,*(undefined2 *)(iVar3 + 4)), DAT_01d5b140 != '\0')) &&
             (DAT_01ee420a != '\0')) {
            FUN_01677520(DAT_01ee420a,"binding socket on %s:%s\n",pcStack_c,auStack_74);
          }
          iVar8 = Ordinal_2(iVar5,*(undefined4 *)(iVar3 + 0x18),*(undefined4 *)(iVar3 + 0x10));
          if (-1 < iVar8) {
            if (DAT_01d5b140 == '\0') {
              FUN_00695530(iVar5,*(undefined2 *)(iVar3 + 4));
            }
            freeaddrinfo(iStack_8);
            return iVar5;
          }
          if (DAT_01ee420a != '\0') {
            puVar7 = (undefined4 *)FUN_0171689d();
            uVar6 = FUN_01726a3e(*puVar7);
            puVar7 = (undefined4 *)FUN_0171689d();
            FUN_01677520(DAT_01ee420a,"bind failed:Error : %d - %s\n",*puVar7,uVar6);
          }
        }
        iVar3 = *(int *)(iVar3 + 0x1c);
        pcVar9 = Ordinal_23_exref;
      } while (iVar3 != 0);
      if (iStack_8 != 0) {
        freeaddrinfo(iStack_8);
      }
    }
    return -1;
  }
  uStack_14 = 0;
  uStack_1a = Ordinal_9(param_1);
  iVar3 = Ordinal_23(2,2,0);
  if (iVar3 != -1) {
    FUN_00695530(iVar3,2);
    uStack_1c = 2;
    if ((param_3 == (char *)0x0) || (*param_3 == '\0')) {
      uStack_18 = 0;
    }
    else {
      uStack_18 = Ordinal_11(param_3);
    }
    uVar4 = Ordinal_2(iVar3,&uStack_1c,0x10);
    if (uVar4 < 0x80000000) {
      return iVar3;
    }
    iVar5 = GetLastError();
    if (iVar5 == 0x2740) {
      if (param_4 == 0) {
        return -1;
      }
      FUN_00722890(100);
      Ordinal_3(iVar3);
      uStack_1a = Ordinal_9(param_1);
      iVar3 = Ordinal_23(2,2,0);
      if (iVar3 == -1) {
        return 0;
      }
      FUN_00695530(iVar3,2);
      uStack_1c = 2;
      if ((param_3 == (char *)0x0) || (*param_3 == '\0')) {
        uStack_18 = 0;
      }
      else {
        uStack_18 = Ordinal_11(param_3);
      }
      iVar5 = Ordinal_2(iVar3,&uStack_1c,0x10);
      if (-1 < iVar5) {
        return iVar3;
      }
    }
    uVar6 = GetLastError();
    puVar7 = (undefined4 *)FUN_016757a0(auStack_34,uVar6);
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    FUN_00557c40("bind__(...) failed:Error code - %d\n%s\n",uVar6,puVar7);
    FUN_005507b0();
  }
  return -1;
}



/* FUNCTION 8346 ; VA 0x00694af0 ; FUN_00694af0 */

undefined * FUN_00694af0(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined *puVar3;
  char *pcVar4;
  char *pcVar5;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  if (DAT_01d5b1e4 == '\0') {
    iVar2 = Ordinal_52(param_1);
    if ((iVar2 != 0) && ((undefined4 *)**(int **)(iVar2 + 0xc) != (undefined4 *)0x0)) {
      puVar3 = (undefined *)Ordinal_12(*(undefined4 *)**(int **)(iVar2 + 0xc));
      return puVar3;
    }
  }
  else {
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_1c = 0;
    uStack_20 = 2;
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_10 = 0;
    uStack_c = 0;
    iVar2 = getaddrinfo(param_1,0,&uStack_28,&iStack_8);
    if (iVar2 == 0) {
      if (*(int *)(iStack_8 + 4) == 2) {
        pcVar4 = (char *)Ordinal_12(*(undefined4 *)(*(int *)(iStack_8 + 0x18) + 4));
        pcVar5 = pcVar4;
        do {
          cVar1 = *pcVar5;
          pcVar5 = pcVar5 + 1;
          pcVar5[0x1eae0a7 - (int)pcVar4] = cVar1;
        } while (cVar1 != '\0');
      }
      else {
        getnameinfo(*(int *)(iStack_8 + 0x18),0x1c,&DAT_01eae0a8,0x401,0,0,2);
      }
      if (iStack_8 != 0) {
        freeaddrinfo(iStack_8);
      }
      return &DAT_01eae0a8;
    }
  }
  return (undefined *)0x0;
}



/* FUNCTION 8347 ; VA 0x00694bb0 ; thunk_FUN_00694bc0 */

void thunk_FUN_00694bc0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  int iVar9;
  undefined auStack_78 [80];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int aiStack_20 [7];
  
  iVar5 = Ordinal_57(auStack_78,0x50);
  if (iVar5 == -1) {
    uVar6 = GetLastError();
    puVar7 = (undefined4 *)FUN_016757a0(aiStack_20,uVar6);
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    FUN_00557c40("gethostname failed:Error code - %d\n%s\n",uVar6,puVar7);
    if ((uint)aiStack_20[5] < 0x10) {
      return;
    }
    uVar8 = aiStack_20[5] + 1;
    iVar5 = aiStack_20[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_20[0] + -4);
      uVar8 = aiStack_20[5] + 0x24;
      if (0x1f < (aiStack_20[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
    return;
  }
  if (DAT_01d5b1e4 == '\0') {
    iVar5 = Ordinal_52(auStack_78);
    if (iVar5 == 0) {
      uVar6 = GetLastError();
      puVar7 = (undefined4 *)FUN_016757a0(aiStack_20,uVar6);
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_00557c40("gethostbyname failed:Error code - %d\n%s\n",uVar6,puVar7);
      FUN_005507b0();
      return;
    }
    iVar9 = 0;
    param_1 = param_1 + 1;
    while (puVar7 = *(undefined4 **)(*(int *)(iVar5 + 0xc) + iVar9 * 4), puVar7 != (undefined4 *)0x0
          ) {
      iVar9 = iVar9 + 1;
      *param_1 = *puVar7;
      param_1 = param_1 + 8;
      if (9 < iVar9) {
        return;
      }
    }
  }
  else {
    aiStack_20[6] = 0;
    uStack_24 = 0;
    aiStack_20[1] = 0;
    aiStack_20[2] = 0;
    aiStack_20[3] = 0;
    aiStack_20[4] = 0;
    aiStack_20[5] = 0;
    aiStack_20[0] = 2;
    uStack_28 = 0xc00;
    getaddrinfo(auStack_78,&DAT_018bc9b8,&uStack_28,aiStack_20 + 6);
    iVar9 = 0;
    iVar5 = aiStack_20[6];
    if (aiStack_20[6] == 0) goto LAB_00694cd2;
    do {
      if (9 < iVar9) break;
      puVar7 = *(undefined4 **)(iVar5 + 0x18);
      iVar2 = *(int *)(iVar5 + 4);
      uVar6 = puVar7[1];
      uVar3 = puVar7[2];
      uVar4 = puVar7[3];
      *param_1 = *puVar7;
      param_1[1] = uVar6;
      param_1[2] = uVar3;
      param_1[3] = uVar4;
      if (iVar2 != 2) {
        *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar7 + 4);
        param_1[6] = puVar7[6];
      }
      piVar1 = (int *)(iVar5 + 0x1c);
      iVar9 = iVar9 + 1;
      param_1 = param_1 + 8;
      iVar5 = *piVar1;
    } while (*piVar1 != 0);
    freeaddrinfo(aiStack_20[6]);
  }
  if (9 < iVar9) {
    return;
  }
LAB_00694cd2:
  iVar9 = 10 - iVar9;
  do {
    FUN_005f7170(&DAT_01eae068);
    iVar9 = iVar9 + -1;
  } while (iVar9 != 0);
  return;
}



/* FUNCTION 8348 ; VA 0x00694bc0 ; FUN_00694bc0 */

void FUN_00694bc0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  int iVar9;
  undefined auStack_78 [80];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int aiStack_20 [7];
  
  iVar5 = Ordinal_57(auStack_78,0x50);
  if (iVar5 == -1) {
    uVar6 = GetLastError();
    puVar7 = (undefined4 *)FUN_016757a0(aiStack_20,uVar6);
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    FUN_00557c40("gethostname failed:Error code - %d\n%s\n",uVar6,puVar7);
    if ((uint)aiStack_20[5] < 0x10) {
      return;
    }
    uVar8 = aiStack_20[5] + 1;
    iVar5 = aiStack_20[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_20[0] + -4);
      uVar8 = aiStack_20[5] + 0x24;
      if (0x1f < (aiStack_20[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
    return;
  }
  if (DAT_01d5b1e4 == '\0') {
    iVar5 = Ordinal_52(auStack_78);
    if (iVar5 == 0) {
      uVar6 = GetLastError();
      puVar7 = (undefined4 *)FUN_016757a0(aiStack_20,uVar6);
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_00557c40("gethostbyname failed:Error code - %d\n%s\n",uVar6,puVar7);
      FUN_005507b0();
      return;
    }
    iVar9 = 0;
    param_1 = param_1 + 1;
    while (puVar7 = *(undefined4 **)(*(int *)(iVar5 + 0xc) + iVar9 * 4), puVar7 != (undefined4 *)0x0
          ) {
      iVar9 = iVar9 + 1;
      *param_1 = *puVar7;
      param_1 = param_1 + 8;
      if (9 < iVar9) {
        return;
      }
    }
  }
  else {
    aiStack_20[6] = 0;
    uStack_24 = 0;
    aiStack_20[1] = 0;
    aiStack_20[2] = 0;
    aiStack_20[3] = 0;
    aiStack_20[4] = 0;
    aiStack_20[5] = 0;
    aiStack_20[0] = 2;
    uStack_28 = 0xc00;
    getaddrinfo(auStack_78,&DAT_018bc9b8,&uStack_28,aiStack_20 + 6);
    iVar9 = 0;
    iVar5 = aiStack_20[6];
    if (aiStack_20[6] == 0) goto LAB_00694cd2;
    do {
      if (9 < iVar9) break;
      puVar7 = *(undefined4 **)(iVar5 + 0x18);
      iVar2 = *(int *)(iVar5 + 4);
      uVar6 = puVar7[1];
      uVar3 = puVar7[2];
      uVar4 = puVar7[3];
      *param_1 = *puVar7;
      param_1[1] = uVar6;
      param_1[2] = uVar3;
      param_1[3] = uVar4;
      if (iVar2 != 2) {
        *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar7 + 4);
        param_1[6] = puVar7[6];
      }
      piVar1 = (int *)(iVar5 + 0x1c);
      iVar9 = iVar9 + 1;
      param_1 = param_1 + 8;
      iVar5 = *piVar1;
    } while (*piVar1 != 0);
    freeaddrinfo(aiStack_20[6]);
  }
  if (9 < iVar9) {
    return;
  }
LAB_00694cd2:
  iVar9 = 10 - iVar9;
  do {
    FUN_005f7170(&DAT_01eae068);
    iVar9 = iVar9 + -1;
  } while (iVar9 != 0);
  return;
}



/* FUNCTION 8349 ; VA 0x00694d80 ; FUN_00694d80 */

void FUN_00694d80(undefined4 param_1,undefined4 *param_2)

{
  undefined2 uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  bool bVar6;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined2 uStack_18;
  undefined2 uStack_16;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (DAT_01d5b1e4 == '\0') {
    uStack_8 = 0x10;
    uStack_1c._0_2_ = 0;
    uStack_1c._2_2_ = 0;
    uStack_18 = 0;
    uStack_16 = 0;
    uStack_14 = 0;
    uStack_10 = 0;
    iVar2 = Ordinal_6(param_1,&uStack_1c,&uStack_8);
    if (iVar2 == 0) {
      FUN_005f7a40(CONCAT22(uStack_18,uStack_1c._2_2_));
      param_2[1] = CONCAT22(uStack_16,uStack_18);
      return;
    }
    FUN_005f7170(&DAT_01eae068);
    return;
  }
  uStack_8 = 0x1c;
  iVar2 = Ordinal_6(param_1,&uStack_38,&uStack_8);
  if (iVar2 == 0) {
    *param_2 = uStack_38;
    param_2[1] = uStack_34;
    param_2[2] = uStack_30;
    param_2[3] = uStack_2c;
    if ((short)uStack_38 == 2) {
      uVar1 = Ordinal_15(*(undefined2 *)((int)param_2 + 2));
      *(undefined2 *)(param_2 + 7) = uVar1;
      uStack_c = 0;
      if (param_2[1] == 0) {
        FUN_005f7a60(4);
        return;
      }
    }
    else {
      *(undefined8 *)(param_2 + 4) = uStack_28;
      param_2[6] = uStack_20;
      uVar1 = Ordinal_15(*(undefined2 *)((int)param_2 + 2));
      *(undefined2 *)(param_2 + 7) = uVar1;
      uStack_1c._0_2_ = 0;
      uStack_1c._2_2_ = 0;
      uStack_18 = 0;
      uStack_16 = 0;
      uStack_14 = 0;
      uStack_10 = 0;
      piVar3 = param_2 + 2;
      uVar5 = 0xc;
      piVar4 = &uStack_1c;
      do {
        if (*piVar3 != *piVar4) {
          return;
        }
        piVar3 = piVar3 + 1;
        piVar4 = piVar4 + 1;
        bVar6 = 3 < uVar5;
        uVar5 = uVar5 - 4;
      } while (bVar6);
      FUN_005f7a60(6);
    }
    return;
  }
  FUN_005f7480(0,0x7c,0);
  return;
}



/* FUNCTION 8350 ; VA 0x00694ea0 ; FUN_00694ea0 */

bool FUN_00694ea0(uint param_1,char *param_2,ushort param_3)

{
  int iVar1;
  int iVar2;
  char *pcVar3;
  undefined auStack_5c [32];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined2 uStack_1a;
  undefined4 uStack_18;
  undefined8 uStack_14;
  int iStack_c;
  int iStack_8;
  
  if (DAT_01d5b1e4 == '\0') {
    uStack_14 = 0;
    uStack_1a = Ordinal_9(param_1);
    iVar1 = Ordinal_23(2,2,0);
    if (iVar1 == -1) {
      return true;
    }
    uStack_1c = 2;
    if ((param_2 == (char *)0x0) || (*param_2 == '\0')) {
      uStack_18 = 0;
    }
    else {
      uStack_18 = Ordinal_11(param_2);
    }
    iVar2 = Ordinal_2(iVar1,&uStack_1c,0x10);
    Ordinal_3(iVar1);
    return iVar2 < 0;
  }
  uStack_38 = (uint)param_3;
  iStack_8 = 0;
  uStack_30 = 0;
  uStack_28 = 0;
  uStack_20 = 0;
  uStack_34 = 2;
  FUN_00694630(param_1 & 0xffff,auStack_5c,10);
  if (((param_2 == (char *)0x0) ||
      (iVar1 = FUN_01717aae(param_2,"UNASSIGNED_SYSTEM_ADDRESS"), iVar1 == 0)) || (*param_2 == '\0')
     ) {
    uStack_3c = 1;
    pcVar3 = (char *)0x0;
  }
  else {
    uStack_3c = 0xc00;
    pcVar3 = param_2;
  }
  getaddrinfo(pcVar3,auStack_5c,&uStack_3c,&iStack_8);
  for (iVar1 = iStack_8; iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x1c)) {
    iStack_c = Ordinal_23(*(undefined4 *)(iVar1 + 4),*(undefined4 *)(iVar1 + 8),
                          *(undefined4 *)(iVar1 + 0xc));
    if (iStack_c != -1) {
      iVar2 = Ordinal_2(iStack_c,*(undefined4 *)(iVar1 + 0x18),*(undefined4 *)(iVar1 + 0x10));
      Ordinal_3(iStack_c);
      if (-1 < iVar2) {
        freeaddrinfo(iStack_8);
        return false;
      }
    }
    if ((param_2 == (char *)0x0) || (*param_2 == '\0')) break;
  }
  if ((DAT_01d5b1e4 == '\0') || (iStack_8 != 0)) {
    freeaddrinfo(iStack_8);
  }
  return true;
}



/* FUNCTION 8351 ; VA 0x00695040 ; FUN_00695040 */

bool FUN_00695040(char *param_1,ushort param_2)

{
  int iVar1;
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined8 uStack_14;
  undefined4 uStack_c;
  int iStack_8;
  
  if (DAT_01d5b1e4 == '\0') {
    return param_2 == 2;
  }
  uStack_24 = (uint)param_2;
  uStack_1c = 0;
  uStack_14 = 0;
  uStack_c = 0;
  uStack_20 = 2;
  iStack_8 = 0;
  if (param_1 != (char *)0x0) {
    iVar1 = FUN_01717aae(param_1,"UNASSIGNED_SYSTEM_ADDRESS");
    if ((iVar1 != 0) && (*param_1 != '\0')) {
      uStack_28 = 0xc00;
      goto LAB_006950d0;
    }
  }
  uStack_28 = 1;
  param_1 = (char *)0x0;
LAB_006950d0:
  getaddrinfo(param_1,&DAT_018d0474,&uStack_28,&iStack_8);
  if (iStack_8 != 0) {
    freeaddrinfo(iStack_8);
    return true;
  }
  return false;
}



/* FUNCTION 8352 ; VA 0x00695100 ; FUN_00695100 */

void FUN_00695100(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 *param_5
                 ,undefined8 *param_6)

{
  undefined2 uVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 uStack_130;
  int iStack_12c;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined2 uStack_20;
  undefined2 uStack_1e;
  undefined2 uStack_1c;
  undefined2 uStack_1a;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  undefined4 uStack_8;
  
  if (DAT_01d5b1e4 == '\0') {
    uStack_1c = 0;
    uStack_1a = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_8 = 0x10;
    iStack_10 = DAT_01d5b104 / 1000;
    uStack_20 = 2;
    uStack_1e = 0;
    iStack_12c = param_1;
    uStack_130 = 1;
    iStack_c = (DAT_01d5b104 % 1000) * 1000;
    iVar2 = Ordinal_18(param_1 + 1,&uStack_130,0,0,&iStack_10);
    if ((0 < iVar2) && (iVar2 = Ordinal_151(param_1,&uStack_130), iVar2 != 0)) {
      iVar2 = Ordinal_17(param_1,param_3,0x5d4,0,&uStack_20,&uStack_8);
      *param_4 = iVar2;
      if (iVar2 < 1) {
        return;
      }
      uVar3 = FUN_006a6920();
      *param_6 = uVar3;
      FUN_005f7a40(CONCAT22(uStack_1c,uStack_1e));
      param_5[1] = CONCAT22(uStack_1a,uStack_1c);
      return;
    }
LAB_006951e3:
    *param_4 = 0;
    return;
  }
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1e = 0;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_1a = 0;
  uStack_18 = 0;
  uStack_8 = 0x1c;
  if (DAT_01d5b148 != '\0') {
    iStack_12c = param_1;
    iStack_10 = DAT_01d5b104 / 1000;
    uStack_130 = 1;
    iStack_c = (DAT_01d5b104 % 1000) * 1000;
    iVar2 = Ordinal_18(param_1 + 1,&uStack_130,0,0,&iStack_10);
    if ((iVar2 < 1) || (iVar2 = Ordinal_151(param_1,&uStack_130), iVar2 == 0)) goto LAB_006951e3;
  }
  iVar2 = Ordinal_17(param_1,param_3,0x5d4,0,&uStack_2c,&uStack_8);
  *param_4 = iVar2;
  if (0 < iVar2) {
    uVar3 = FUN_006a6920();
    *param_6 = uVar3;
    *param_5 = uStack_2c;
    param_5[1] = uStack_28;
    param_5[2] = uStack_24;
    param_5[3] = CONCAT22(uStack_1e,uStack_20);
    if ((short)uStack_2c != 2) {
      *(ulonglong *)(param_5 + 4) = CONCAT44(uStack_18,CONCAT22(uStack_1a,uStack_1c));
      param_5[6] = uStack_14;
    }
    uVar1 = Ordinal_15(*(undefined2 *)((int)param_5 + 2));
    *(undefined2 *)(param_5 + 7) = uVar1;
  }
  return;
}



/* FUNCTION 8353 ; VA 0x006952f0 ; FUN_006952f0 */

int FUN_006952f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  
  if (param_1 == -1) {
    return -1;
  }
  iVar1 = FUN_00695350(param_1,param_2,param_3,param_4,param_5,param_6);
  if (iVar1 != -1) {
    return 0;
  }
  iVar1 = Ordinal_111();
  if ((iVar1 != 0x2746) && (((iVar1 == 0x2743 || (iVar1 == 0x2751)) && (DAT_01d59d08 != '\0')))) {
    iVar1 = 2;
  }
  return iVar1;
}



/* FUNCTION 8354 ; VA 0x00695350 ; FUN_00695350 */

int FUN_00695350(undefined4 param_1,char *param_2,undefined4 param_3,short *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_34 [28];
  undefined auStack_18 [16];
  undefined4 uStack_8;
  
  iVar3 = 0;
  do {
    if (*param_4 == 2) {
      uVar4 = 0x10;
LAB_00695388:
      iVar3 = Ordinal_20(param_1,param_2,param_3,0,param_4,uVar4);
    }
    else if (DAT_01d5b1e4 != '\0') {
      uVar4 = 0x1c;
      goto LAB_00695388;
    }
    if (iVar3 < 0) {
      if (DAT_01d5b1e4 == '\0') {
        if (DAT_01eae065 != '\0') {
          FUN_01677520(DAT_01eae065,"sendto failed with code %i for char %i and length %i.",iVar3,
                       (int)*param_2,param_3);
        }
        FUN_00557c40("sendto failed with code %i for char %i and length %i.\n",iVar3,(int)*param_2,
                     param_3);
      }
      else {
        if (DAT_01eae065 != '\0') {
          puVar1 = (undefined4 *)FUN_0171689d();
          uVar4 = FUN_01726a3e(*puVar1);
          FUN_01677520(DAT_01eae065,"sendto failed with code %i for char %i and length %i.errno %s",
                       iVar3,(int)*param_2,param_3,uVar4);
        }
        puVar1 = (undefined4 *)FUN_0171689d();
        uVar4 = FUN_01726a3e(*puVar1);
        FUN_00557c40("sendto failed with code %i for char %i and length %i.errno %s\n",iVar3,
                     (int)*param_2,param_3,uVar4);
        if (*param_4 == 2) {
          uStack_8 = 0x10;
          iVar2 = Ordinal_6(param_1,auStack_18,&uStack_8);
          if (iVar2 != 0) {
            if (DAT_01eae065 != '\0') {
              puVar1 = (undefined4 *)FUN_0171689d();
              FUN_01677520(DAT_01eae065,"getsockname returned errno 0x%x",*puVar1);
            }
            puVar1 = (undefined4 *)FUN_0171689d();
            FUN_00557c40("getsockname returned errno 0x%x\n",*puVar1);
          }
        }
        else {
          uStack_8 = 0x1c;
          iVar2 = Ordinal_6(param_1,auStack_34,&uStack_8);
          if (iVar2 != 0) {
            if (DAT_01eae065 != '\0') {
              puVar1 = (undefined4 *)FUN_0171689d();
              FUN_01677520(DAT_01eae065,"getsockname returned errno 0x%x",*puVar1);
            }
            puVar1 = (undefined4 *)FUN_0171689d();
            FUN_00557c40("getsockname returned errno 0x%x\n",*puVar1);
          }
        }
      }
    }
    if (iVar3 != 0) {
      return iVar3;
    }
  } while( true );
}



/* FUNCTION 8355 ; VA 0x00695510 ; FUN_00695510 */

void FUN_00695510(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  Ordinal_21(param_1,param_3,0xe,&param_2,4);
  return;
}



/* FUNCTION 8356 ; VA 0x00695530 ; FUN_00695530 */

void FUN_00695530(undefined4 param_1,short param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5d18;
  pvStack_10 = ExceptionList;
  uStack_14 = 0x40000;
  ExceptionList = &pvStack_10;
  iVar1 = Ordinal_21(param_1,0xffff,0x1002,&uStack_14,4);
  if ((iVar1 == -1) && (DAT_01d5b140 != '\0')) {
    uStack_1c = GetLastError();
    if (DAT_01ee420a != '\0') {
      puVar2 = (undefined4 *)FUN_016757a0(aiStack_38,uStack_1c);
      uStack_8 = 0;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_01677520(DAT_01ee420a,"setsockopt SO_RCVBUF failed : errno=%d, errString=%s",uStack_1c,
                   puVar2);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_24) {
        uVar4 = uStack_24 + 1;
        iVar1 = aiStack_38[0];
        if (0xfff < uVar4) {
          iVar1 = *(int *)(aiStack_38[0] + -4);
          uVar4 = uStack_24 + 0x24;
          if (0x1f < (aiStack_38[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar1,uVar4);
      }
    }
  }
  uStack_18 = 0;
  iVar1 = Ordinal_21(param_1,0xffff,0x80,&uStack_18,4);
  if ((iVar1 == -1) && (DAT_01d5b140 != '\0')) {
    uStack_1c = GetLastError();
    if (DAT_01ee420a != '\0') {
      puVar2 = (undefined4 *)FUN_016757a0(aiStack_38,uStack_1c);
      uStack_8 = 1;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_01677520(DAT_01ee420a,"setsockopt SO_LINGER failed : errno=%d, errString=%s",uStack_1c,
                   puVar2);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_24) {
        uVar4 = uStack_24 + 1;
        iVar1 = aiStack_38[0];
        if (0xfff < uVar4) {
          iVar1 = *(int *)(aiStack_38[0] + -4);
          uVar4 = uStack_24 + 0x24;
          if (0x1f < (aiStack_38[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar1,uVar4);
      }
    }
  }
  uStack_14 = 0x4000;
  iVar1 = Ordinal_21(param_1,0xffff,0x1001,&uStack_14,4);
  if ((iVar1 == -1) && (DAT_01d5b140 != '\0')) {
    uStack_1c = GetLastError();
    if (DAT_01ee420a != '\0') {
      puVar2 = (undefined4 *)FUN_016757a0(aiStack_38,uStack_1c);
      uStack_8 = 2;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_01677520(DAT_01ee420a,"setsockopt SO_SNDBUF failed : errno=%d, errString=%s",uStack_1c,
                   puVar2);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_24) {
        uVar4 = uStack_24 + 1;
        iVar1 = aiStack_38[0];
        if (0xfff < uVar4) {
          iVar1 = *(int *)(aiStack_38[0] + -4);
          uVar4 = uStack_24 + 0x24;
          if (0x1f < (aiStack_38[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar1,uVar4);
      }
    }
  }
  if (((DAT_01d5b1e4 != '\0') && (DAT_01d5b138 != '\0')) &&
     ((DAT_01d5b060 == '\0' || (param_2 == 0x17)))) {
    uStack_1c = 0;
    iVar1 = Ordinal_21(param_1,0x29,0x1b,&uStack_1c,4);
    if ((iVar1 == -1) && (DAT_01d5b140 != '\0')) {
      uStack_20 = GetLastError();
      if (DAT_01ee420a != '\0') {
        puVar2 = (undefined4 *)FUN_016757a0(aiStack_38,uStack_20);
        uStack_8 = 3;
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_01677520(DAT_01ee420a,"setsockopt IPV6_V6ONLY failed : errno=%d, errString=%s",uStack_20
                     ,puVar2);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
      }
    }
  }
  uStack_14 = 1;
  iVar1 = Ordinal_21(param_1,0xffff,0x20,&uStack_14,4);
  if ((iVar1 == -1) && (DAT_01d5b140 != '\0')) {
    uVar3 = GetLastError();
    if (DAT_01ee420a != '\0') {
      puVar2 = (undefined4 *)FUN_016757a0(aiStack_38,uVar3);
      uStack_8 = 4;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_01677520(DAT_01ee420a,"setsockopt SO_BROADCAST failed : errno=%d, errString=%s",uVar3,
                   puVar2);
      if (0xf < uStack_24) {
        uVar4 = uStack_24 + 1;
        iVar1 = aiStack_38[0];
        if (0xfff < uVar4) {
          iVar1 = *(int *)(aiStack_38[0] + -4);
          uVar4 = uStack_24 + 0x24;
          if (0x1f < (aiStack_38[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar1,uVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8357 ; VA 0x006958c0 ; FUN_006958c0 */

int FUN_006958c0(ushort *param_1,uint param_2,uint param_3)

{
  ushort *puVar1;
  ushort uVar2;
  uint uVar3;
  int iVar4;
  
  if (((int)param_2 < 1) || (param_1 == (ushort *)0x0)) {
    return 0;
  }
  uVar3 = param_2 & 3;
  for (iVar4 = (int)param_2 >> 2; 0 < iVar4; iVar4 = iVar4 + -1) {
    uVar2 = *param_1;
    puVar1 = param_1 + 1;
    param_1 = param_1 + 2;
    param_3 = param_3 + uVar2 ^ ((uint)*puVar1 ^ (param_3 + uVar2) * 0x20) << 0xb;
    param_3 = param_3 + (param_3 >> 0xb);
  }
  if (uVar3 == 1) {
    param_3 = param_3 + (int)*(char *)param_1 ^ (param_3 + (int)*(char *)param_1) * 0x400;
    uVar3 = param_3 >> 1;
  }
  else if (uVar3 == 2) {
    param_3 = param_3 + *param_1 ^ (param_3 + *param_1) * 0x800;
    uVar3 = param_3 >> 0x11;
  }
  else {
    if (uVar3 != 3) goto LAB_00695962;
    param_3 = param_3 + *param_1 ^ ((int)*(char *)(param_1 + 1) << 2 ^ param_3 + *param_1) << 0x10;
    uVar3 = param_3 >> 0xb;
  }
  param_3 = param_3 + uVar3;
LAB_00695962:
  param_3 = param_3 ^ param_3 * 8;
  param_3 = param_3 + (param_3 >> 5);
  param_3 = param_3 ^ param_3 * 0x10;
  param_3 = param_3 + (param_3 >> 0x11);
  param_3 = param_3 ^ param_3 * 0x2000000;
  return param_3 + (param_3 >> 6);
}



/* FUNCTION 8358 ; VA 0x006959a0 ; FUN_006959a0 */

uint * FUN_006959a0(uint param_1)

{
  uint *puVar1;
  uint uVar2;
  
  if (param_1 == 0) {
    return (uint *)0x0;
  }
  uVar2 = -(uint)((int)((ulonglong)param_1 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_1 * 8);
  puVar1 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar2) | uVar2 + 4);
  if (puVar1 != (uint *)0x0) {
    *puVar1 = param_1;
    FUN_016f4053(puVar1 + 1,8,param_1,FUN_005502b0,FUN_00550b30);
    return puVar1 + 1;
  }
  return (uint *)0x0;
}



/* FUNCTION 8359 ; VA 0x00695a10 ; FUN_00695a10 */

undefined4 FUN_00695a10(undefined4 param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_c [8];
  
  cVar1 = FUN_005fda50();
  if (cVar1 != '\0') {
    uVar2 = FUN_006a5ae0(param_1,0x40,1);
    return uVar2;
  }
  cVar1 = FUN_006a5ae0(auStack_c,0x40,1);
  if (cVar1 != '\0') {
    FUN_006a5c10(auStack_c,param_1,8);
    return 1;
  }
  return 0;
}



/* FUNCTION 8360 ; VA 0x00695a70 ; FUN_00695a70 */

undefined FUN_00695a70(undefined2 *param_1)

{
  undefined2 *puVar1;
  undefined uVar2;
  undefined2 uVar3;
  char cStack_5;
  
  FUN_006a5ae0(&cStack_5,8,1);
  puVar1 = param_1;
  if (cStack_5 == '\x04') {
    *param_1 = 2;
    FUN_006a5ae0(&param_1,0x20,1);
    *(uint *)(puVar1 + 2) = ~(uint)param_1;
    uVar2 = FUN_006a5ae0(puVar1 + 1,0x10,1);
    uVar3 = Ordinal_15(puVar1[1]);
    puVar1[0xe] = uVar3;
    return uVar2;
  }
  return 0;
}



/* FUNCTION 8361 ; VA 0x00695af0 ; FUN_00695af0 */

void FUN_00695af0(undefined4 param_1)

{
  char cVar1;
  undefined auStack_c [8];
  
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(param_1,auStack_c,8);
    FUN_006a6060(auStack_c,0x40,1);
    return;
  }
  FUN_006a6060(param_1,0x40,1);
  return;
}



/* FUNCTION 8362 ; VA 0x00695b40 ; FUN_00695b40 */

void FUN_00695b40(uint param_1)

{
  int iVar1;
  undefined uVar2;
  char cVar3;
  uint uStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  iVar1 = param_1;
  if (DAT_01d5b1e4 != '\0') {
    uStack_5 = 4;
    FUN_006a6060(&uStack_5,8,1);
    uStack_c = ~*(uint *)(param_1 + 4);
    FUN_006a6060(&uStack_c,0x20,1);
    uStack_10 = FUN_005f7820();
    uStack_10 = uStack_10 & 0xffff;
    FUN_006a6060(&uStack_10,0x10,1);
    return;
  }
  uVar2 = FUN_005f77c0();
  param_1 = CONCAT13(uVar2,(undefined3)param_1);
  FUN_006a6060((int)&param_1 + 3,8,1);
  cVar3 = FUN_005f77c0();
  if (cVar3 == '\x04') {
    param_1 = ~*(uint *)(iVar1 + 4);
    FUN_006a6060(&param_1,0x20,1);
    uStack_10 = FUN_005f7820();
    uStack_10 = uStack_10 & 0xffff;
    FUN_006a6060(&uStack_10,0x10,1);
  }
  return;
}



/* FUNCTION 8363 ; VA 0x00695c30 ; FUN_00695c30 */

void __thiscall FUN_00695c30(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5d30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RakNet::RakNetSocket>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8364 ; VA 0x00695c9e ; Catch_All@00695c9e */

void Catch_All_00695c9e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00696bd0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8365 ; VA 0x00695cc0 ; FUN_00695cc0 */

void __thiscall FUN_00695cc0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5d40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Security::RakPeerCrypto>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8366 ; VA 0x00695d2e ; Catch_All@00695d2e */

void Catch_All_00695d2e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8367 ; VA 0x00695d50 ; FUN_00695d50 */

void __thiscall FUN_00695d50(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5d50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::Rupp::Rupp>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8368 ; VA 0x00695dbe ; Catch_All@00695dbe */

void Catch_All_00695dbe(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00696d30(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8369 ; VA 0x00695de0 ; FUN_00695de0 */

int __thiscall FUN_00695de0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_00695cc0(param_2,param_2);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 8370 ; VA 0x00695e50 ; FUN_00695e50 */

undefined4 * __fastcall FUN_00695e50(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined8 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5f27;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::RakPeer::vftable;
  *(undefined *)(param_1 + 1) = 0;
  FUN_00722a00();
  FUN_006a5600();
  param_1[0x94] = 0;
  param_1[0x95] = 0;
  param_1[0x96] = 0x4000;
  uStack_8._0_1_ = 2;
  FUN_016f4053(param_1 + 0x97,0x18,2,FUN_007228f0,FUN_00722900);
  uStack_8._0_1_ = 3;
  FUN_007228f0();
  uStack_8._0_1_ = 4;
  FUN_007228f0();
  param_1[0xb5] = 0;
  param_1[0xb3] = 0;
  param_1[0xb4] = 0;
  param_1[0xb8] = 0;
  param_1[0xb6] = 0;
  param_1[0xb7] = 0;
  param_1[0xbb] = 0;
  param_1[0xb9] = 0;
  param_1[0xba] = 0;
  param_1[0xbf] = 0;
  param_1[0xbc] = 0;
  param_1[0xbd] = 0;
  param_1[0xbe] = 0;
  uStack_8._0_1_ = 9;
  FUN_007228f0();
  param_1[200] = 0;
  param_1[0xc9] = 0;
  param_1[0xca] = 0x4000;
  uStack_8._0_1_ = 0xb;
  FUN_007228f0();
  param_1[0xd4] = 0;
  param_1[0xd1] = 0;
  param_1[0xd2] = 0;
  param_1[0xd3] = 0;
  uStack_8._0_1_ = 0xd;
  FUN_007228f0();
  param_1[0xdd] = 0;
  param_1[0xde] = 0;
  param_1[0xdf] = 0x4000;
  uStack_8._0_1_ = 0xf;
  FUN_007228f0();
  param_1[0xe9] = 0;
  param_1[0xe6] = 0;
  param_1[0xe7] = 0;
  param_1[0xe8] = 0;
  uStack_8._0_1_ = 0x11;
  FUN_007228f0();
  param_1[0xf2] = 0;
  param_1[0xf3] = 0;
  param_1[0xf4] = 0x4000;
  uStack_8._0_1_ = 0x13;
  FUN_007228f0();
  param_1[0xfe] = 0;
  param_1[0xfb] = 0;
  param_1[0xfc] = 0;
  param_1[0xfd] = 0;
  uStack_8._0_1_ = 0x15;
  FUN_007228f0();
  uStack_8._0_1_ = 0x16;
  FUN_007228f0();
  param_1[0x110] = 0;
  param_1[0x10e] = 0;
  param_1[0x10f] = 0;
  uStack_8._0_1_ = 0x18;
  FUN_005f7140();
  FUN_005f70a0();
  FUN_005f7140();
  param_1[0x12f] = 0;
  param_1[0x12d] = 0;
  param_1[0x12e] = 0;
  uStack_8._0_1_ = 0x19;
  iVar4 = 10;
  do {
    iVar5 = iVar4;
    FUN_005f7140();
    iVar4 = iVar5 + -1;
  } while (iVar4 != 0);
  FUN_00722980();
  uStack_8._0_1_ = 0x1a;
  FUN_007228f0();
  param_1[0x18d] = 0;
  param_1[0x18e] = 0;
  param_1[399] = 0x4000;
  uStack_8._0_1_ = 0x1c;
  FUN_007228f0();
  param_1[0x199] = 0;
  param_1[0x196] = 0;
  param_1[0x197] = 0;
  param_1[0x198] = 0;
  puVar1 = param_1 + 0x19a;
  uStack_8._0_1_ = 0x1e;
  *puVar1 = 0;
  param_1[0x19b] = 0;
  param_1[0x19c] = 0;
  param_1[0x19d] = 0;
  param_1[0x19e] = 0;
  puVar3 = (undefined4 *)FUN_01674e20(8);
  *puVar1 = puVar3;
  *puVar3 = 0;
  puVar3[1] = 0;
  *(undefined4 **)*puVar1 = puVar1;
  puVar1 = param_1 + 0x19f;
  uStack_8._0_1_ = 0x1f;
  *puVar1 = 0;
  param_1[0x1a0] = 0;
  param_1[0x1a1] = 0;
  param_1[0x1a2] = 0;
  param_1[0x1a3] = 0;
  puVar3 = (undefined4 *)FUN_01674e20(8);
  *puVar1 = puVar3;
  *puVar3 = 0;
  puVar3[1] = 0;
  *(undefined4 **)*puVar1 = puVar1;
  uStack_8._0_1_ = 0x20;
  FUN_007228f0();
  param_1[0x1ac] = 0;
  param_1[0x1ad] = 0;
  param_1[0x1ae] = 0;
  param_1[0x1af] = 0;
  param_1[0x1b0] = 0;
  param_1[0x1b1] = 0;
  param_1[0x1b2] = 0;
  param_1[0x1b3] = 0;
  param_1[0x1b4] = 0;
  param_1[0x1b5] = 0;
  param_1[0x1b6] = 0;
  param_1[0x1b7] = 0;
  *(undefined8 *)(param_1 + 0x1b8) = 0;
  *(undefined *)(param_1 + 0x1ba) = 0;
  param_1[0x1be] = 0;
  param_1[0x1bf] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
  FUN_006945d0();
  param_1[0x10b] = 0x240;
  *(undefined4 *)((int)param_1 + 0xe) = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  param_1[0x91] = 0;
  param_1[0xa5] = 0;
  param_1[0xa4] = 0;
  *(undefined *)(param_1 + 0x10c) = 0;
  LOCK();
  *(undefined *)((int)param_1 + 5) = 1;
  UNLOCK();
  LOCK();
  *(undefined *)((int)param_1 + 6) = 0;
  UNLOCK();
  param_1[0x90] = 0;
  iVar5 = iVar5 + 9;
  param_1[0x10d] = 0xffffffff;
  uVar2 = DAT_01d5b168;
  *(undefined *)(param_1 + 3) = 0;
  *(undefined *)(param_1 + 0x180) = 0;
  param_1[0x121] = uVar2;
  do {
    FUN_005f7170(&DAT_01eae4bc);
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  *(undefined *)(param_1 + 0x122) = 0;
  *(undefined *)(param_1 + 0x8c) = 0;
  param_1[299] = 0;
  param_1[300] = 1000;
  param_1[0x120] = 0;
  FUN_005f7170(&DAT_01eae4bc);
  param_1[0x11c] = DAT_01d5b1f0;
  param_1[0x11d] = DAT_01d5b1f4;
  *(undefined2 *)(param_1 + 0x11e) = DAT_01d5b1f8;
  param_1[0x181] = 0;
  param_1[0x182] = 0;
  param_1[0x11b] = DAT_01d5b170;
  *(undefined *)(param_1 + 0x1ab) = 0;
  param_1[0x1bc] = 0;
  param_1[0x1bd] = 0;
  param_1[0xca] = 0x800;
  param_1[0xf4] = 0x60;
  param_1[0xdf] = 0x3040;
  FUN_00722910();
  param_1[399] = 0x900;
  FUN_00722920();
  param_1[0x96] = 0x180;
  uVar6 = FUN_01679c60();
  *(undefined8 *)(param_1 + 0x11c) = uVar6;
  FUN_007229b0();
  *(undefined *)(param_1 + 0x184) = 0;
  FUN_00722910();
  param_1[0x1aa] = 1;
  FUN_00722920();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8371 ; VA 0x006963c0 ; FUN_006963c0 */

int __fastcall FUN_006963c0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5f4e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f7140();
  FUN_005f7140();
  iVar1 = 10;
  do {
    FUN_005f7140();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  FUN_005f89e0();
  iStack_8 = iVar1;
  FUN_005f70a0();
  *(undefined4 *)(param_1 + 0xb44) = 0;
  *(undefined4 *)(param_1 + 0xb48) = 0;
  *(undefined *)(param_1 + 0xb60) = 0;
  *(undefined4 *)(param_1 + 0xb64) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8372 ; VA 0x00696460 ; FUN_00696460 */

int __fastcall FUN_00696460(int param_1)

{
  FUN_005f7140();
  *(undefined4 *)(param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x150) = 0;
  *(undefined4 *)(param_1 + 0x154) = 0;
  *(undefined4 *)(param_1 + 0x158) = 0;
  return param_1;
}



/* FUNCTION 8373 ; VA 0x006964a0 ; FUN_006964a0 */

void __fastcall FUN_006964a0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if ((param_1[2] != 0) && (iVar1 = *param_1, iVar1 != 0)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),FUN_00550b30);
    FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8374 ; VA 0x00696510 ; FUN_00696510 */

void __fastcall FUN_00696510(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if ((param_1[2] != 0) && (iVar1 = *param_1, iVar1 != 0)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,4,*(undefined4 *)(iVar1 + -4),FUN_0071e0a0);
    FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 4 + 4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8375 ; VA 0x00696580 ; FUN_00696580 */

void __fastcall FUN_00696580(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00722900();
  if (*(int *)(param_1 + 0x38) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x2c));
  }
  FUN_00722900();
  uStack_8 = 0;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8376 ; VA 0x006965e0 ; FUN_006965e0 */

void __fastcall FUN_006965e0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5f60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::RakPeer::vftable;
  FUN_006a1bb0(0,0,3);
  uVar4 = 0;
  FUN_00722910();
  if (param_1[0xb4] != 0) {
    do {
      FUN_01674ea0(**(undefined4 **)(param_1[0xb3] + uVar4 * 4));
      FUN_01674ea0(*(undefined4 *)(param_1[0xb3] + uVar4 * 4),8);
      uVar4 = uVar4 + 1;
    } while (uVar4 < (uint)param_1[0xb4]);
  }
  if (param_1[0xb5] != 0) {
    FUN_01674ea0(param_1[0xb3]);
    param_1[0xb5] = 0;
    param_1[0xb3] = 0;
    param_1[0xb4] = 0;
  }
  FUN_00722920();
  FUN_00694600();
  FUN_00722990();
  piVar2 = (int *)param_1[0x1bf];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00722900();
  FUN_00611300();
  FUN_00611300();
  if (param_1[0x199] != 0) {
    FUN_01674ea0(param_1[0x196]);
  }
  FUN_00722900();
  uStack_8 = 0;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  FUN_00722900();
  _guard_check_icall();
  if ((param_1[0x12f] != 0) && (iVar3 = param_1[0x12d], iVar3 != 0)) {
    uStack_8 = 1;
    FUN_016f32d1(iVar3,4,*(undefined4 *)(iVar3 + -4),FUN_0071e0a0);
    FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 4 + 4);
  }
  if ((param_1[0x110] != 0) && (iVar3 = param_1[0x10e], iVar3 != 0)) {
    uStack_8 = 2;
    FUN_016f32d1(iVar3,8,*(undefined4 *)(iVar3 + -4),FUN_00550b30);
    FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 8 + 4);
  }
  FUN_00722900();
  FUN_00722900();
  if (param_1[0xfe] != 0) {
    FUN_01674ea0(param_1[0xfb]);
  }
  FUN_00722900();
  uStack_8 = 3;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  FUN_00722900();
  if (param_1[0xe9] != 0) {
    FUN_01674ea0(param_1[0xe6]);
  }
  FUN_00722900();
  uStack_8 = 4;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  FUN_00722900();
  if (param_1[0xd4] != 0) {
    FUN_01674ea0(param_1[0xd1]);
  }
  FUN_00722900();
  uStack_8 = 5;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  uStack_8 = 0xffffffff;
  FUN_00722900();
  if (param_1[0xbf] != 0) {
    FUN_01674ea0(param_1[0xbc]);
  }
  if (param_1[0xbb] != 0) {
    FUN_01674ea0(param_1[0xb9]);
  }
  if (param_1[0xb8] != 0) {
    FUN_01674ea0(param_1[0xb6]);
  }
  if (param_1[0xb5] != 0) {
    FUN_01674ea0(param_1[0xb3]);
  }
  FUN_00722900();
  FUN_00722900();
  FUN_016f32d1(param_1 + 0x97,0x18,2,FUN_00722900);
  uStack_8 = 6;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  FUN_006a5640();
  *param_1 = RakNet::RakPeerInterface::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8377 ; VA 0x00696970 ; FUN_00696970 */

void __fastcall FUN_00696970(undefined4 *param_1)

{
  *param_1 = RakNet::RakPeerInterface::vftable;
  return;
}



/* FUNCTION 8378 ; VA 0x00696980 ; FUN_00696980 */

void __fastcall FUN_00696980(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xb48);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_005f9150();
  return;
}



/* FUNCTION 8379 ; VA 0x006969c0 ; FUN_006969c0 */

void __fastcall FUN_006969c0(int param_1)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 8);
    if (piVar2 != piVar3) {
      do {
        if ((undefined4 *)*piVar2 != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)*piVar2)(1);
        }
        piVar2 = piVar2 + 1;
      } while (piVar2 != piVar3);
      piVar2 = *(int **)(param_1 + 4);
    }
    uVar1 = *(int *)(param_1 + 0xc) - (int)piVar2 & 0xfffffffc;
    piVar3 = piVar2;
    if (0xfff < uVar1) {
      piVar3 = (int *)piVar2[-1];
      uVar1 = uVar1 + 0x23;
      if (0x1f < (uint)((int)piVar2 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar3,uVar1);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 8380 ; VA 0x00696a40 ; FUN_00696a40 */

int * __thiscall FUN_00696a40(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    ExceptionList = &pvStack_10;
    if (param_1[2] != 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      if (iVar2 != 0) {
        uStack_8 = 0;
        ExceptionList = &pvStack_10;
        FUN_016f32d1(iVar2,8,*(undefined4 *)(iVar2 + -4),FUN_00550b30);
        FUN_01674ea0((int *)(iVar2 + -4),*(int *)(iVar2 + -4) * 8 + 4);
      }
      param_1[2] = 0;
      *param_1 = 0;
      param_1[1] = 0;
    }
    uStack_8 = 0xffffffff;
    if (param_2[1] == 0) {
      param_1[1] = 0;
      param_1[2] = 0;
    }
    else {
      iVar2 = FUN_006959a0(param_2[1],
                           "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_List.h"
                           ,0xb2);
      *param_1 = iVar2;
      uVar4 = param_2[1];
      uVar6 = 0;
      if (uVar4 != 0) {
        do {
          puVar3 = (undefined4 *)(*param_2 + uVar6 * 8);
          puVar5 = (undefined4 *)(*param_1 + uVar6 * 8);
          iVar2 = puVar3[1];
          if (iVar2 != 0) {
            LOCK();
            *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
            UNLOCK();
            iVar2 = puVar3[1];
          }
          *puVar5 = *puVar3;
          piVar1 = (int *)puVar5[1];
          puVar5[1] = iVar2;
          if (piVar1 != (int *)0x0) {
            LOCK();
            iVar2 = piVar1[1] + -1;
            piVar1[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar1)();
              LOCK();
              iVar2 = piVar1[2] + -1;
              piVar1[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar1 + 4))();
              }
            }
          }
          uVar6 = uVar6 + 1;
          uVar4 = param_2[1];
        } while (uVar6 < uVar4);
      }
      param_1[2] = uVar4;
      param_1[1] = uVar4;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8381 ; VA 0x00696b70 ; FUN_00696b70 */

undefined4 * __thiscall FUN_00696b70(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = DAT_01d5b1f0;
  param_1[1] = DAT_01d5b1f4;
  *(undefined2 *)(param_1 + 2) = DAT_01d5b1f8;
  FUN_005f7170(param_2);
  return param_1;
}



/* FUNCTION 8382 ; VA 0x00696bbf ; FUN_00696bbf */

void __fastcall FUN_00696bbf(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00696bc1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x40))();
  return;
}



/* FUNCTION 8383 ; VA 0x00696bd0 ; FUN_00696bd0 */

undefined4 __thiscall FUN_00696bd0(undefined4 param_1,byte param_2)

{
  FUN_007228c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 8384 ; VA 0x00696c00 ; FUN_00696c00 */

undefined4 __thiscall FUN_00696c00(undefined4 param_1,byte param_2)

{
  FUN_006965e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x700);
  }
  return param_1;
}



/* FUNCTION 8385 ; VA 0x00696c30 ; FUN_00696c30 */

undefined4 * __thiscall FUN_00696c30(undefined4 *param_1,byte param_2)

{
  int iVar1;
  
  *param_1 = RBX::Security::SessionCrypto::vftable;
  iVar1 = param_1[8];
  if (iVar1 != 0) {
    FUN_00686090();
    FUN_01674ea0(iVar1,0xe0);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 8386 ; VA 0x00696c80 ; FUN_00696c80 */

undefined4 * __thiscall FUN_00696c80(undefined4 *param_1,byte param_2)

{
  *param_1 = RakNet::RakPeerInterface::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 8387 ; VA 0x00696cb0 ; FUN_00696cb0 */

int __thiscall FUN_00696cb0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x158);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x150);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x160);
  }
  return param_1;
}



/* FUNCTION 8388 ; VA 0x00696d30 ; FUN_00696d30 */

undefined4 __thiscall FUN_00696d30(undefined4 param_1,byte param_2)

{
  FUN_006969c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 8389 ; VA 0x00696d60 ; FUN_00696d60 */

void FUN_00696d60(void)

{
  FUN_00722910();
  FUN_005fe020(&stack0x00000004,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0x119f);
  FUN_00722920();
  return;
}



/* FUNCTION 8390 ; VA 0x00696da0 ; FUN_00696da0 */

void __thiscall FUN_00696da0(int param_1,byte *param_2,int param_3)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  byte *pbVar8;
  int iVar9;
  uint uVar10;
  bool bVar11;
  
  iVar2 = FUN_006a6900();
  if (param_2 == (byte *)0x0) {
    return;
  }
  if (*param_2 == 0) {
    return;
  }
  pbVar8 = param_2;
  do {
    bVar1 = *pbVar8;
    pbVar8 = pbVar8 + 1;
  } while (bVar1 != 0);
  if (0xf < (uint)((int)pbVar8 - (int)(param_2 + 1))) {
    return;
  }
  uVar10 = 0;
  FUN_00722910();
  if (*(int *)(param_1 + 0x2d0) != 0) {
    puVar5 = *(undefined4 **)(param_1 + 0x2cc);
    do {
      pbVar8 = *(byte **)*puVar5;
      pbVar3 = param_2;
      do {
        bVar1 = *pbVar3;
        bVar11 = bVar1 < *pbVar8;
        if (bVar1 != *pbVar8) {
LAB_00696e30:
          uVar4 = -(uint)bVar11 | 1;
          goto LAB_00696e35;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar3[1];
        bVar11 = bVar1 < pbVar8[1];
        if (bVar1 != pbVar8[1]) goto LAB_00696e30;
        pbVar3 = pbVar3 + 2;
        pbVar8 = pbVar8 + 2;
      } while (bVar1 != 0);
      uVar4 = 0;
LAB_00696e35:
      if (uVar4 == 0) {
        iVar9 = *(int *)(*(int *)(param_1 + 0x2cc) + uVar10 * 4);
        if (param_3 == 0) {
          *(undefined4 *)(iVar9 + 4) = 0;
          FUN_00722920();
          return;
        }
        *(int *)(iVar9 + 4) = param_3 + iVar2;
        FUN_00722920();
        return;
      }
      uVar10 = uVar10 + 1;
      puVar5 = puVar5 + 1;
    } while (uVar10 < *(uint *)(param_1 + 0x2d0));
  }
  FUN_00722920();
  puVar5 = (undefined4 *)FUN_01674e20(8);
  uVar6 = FUN_01674f30(0x10);
  *puVar5 = uVar6;
  puVar5[1] = -(uint)(param_3 != 0) & iVar2 + param_3;
  pbVar8 = (byte *)*puVar5;
  do {
    bVar1 = *param_2;
    param_2 = param_2 + 1;
    *pbVar8 = bVar1;
    pbVar8 = pbVar8 + 1;
  } while (bVar1 != 0);
  FUN_00722910();
  iVar9 = *(int *)(param_1 + 0x2d0);
  iVar2 = *(int *)(param_1 + 0x2d4);
  if (iVar9 != iVar2) {
    iVar2 = *(int *)(param_1 + 0x2cc);
    goto LAB_00696f82;
  }
  if (iVar2 == 0) {
    *(undefined4 *)(param_1 + 0x2d4) = 0x10;
    uVar10 = 0x10;
LAB_00696ec6:
    iVar2 = FUN_01674e20(-(uint)((int)((ulonglong)uVar10 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)uVar10 * 4));
    iVar9 = *(int *)(param_1 + 0x2d0);
  }
  else {
    uVar10 = iVar2 * 2;
    *(uint *)(param_1 + 0x2d4) = uVar10;
    if (uVar10 != 0) goto LAB_00696ec6;
    iVar2 = 0;
  }
  iVar7 = *(int *)(param_1 + 0x2cc);
  if (iVar7 != 0) {
    uVar10 = 0;
    if (iVar9 != 0) {
      do {
        *(undefined4 *)(iVar2 + uVar10 * 4) =
             *(undefined4 *)(*(int *)(param_1 + 0x2cc) + uVar10 * 4);
        uVar10 = uVar10 + 1;
      } while (uVar10 < *(uint *)(param_1 + 0x2d0));
      iVar7 = *(int *)(param_1 + 0x2cc);
    }
    FUN_01674ea0(iVar7);
  }
  *(int *)(param_1 + 0x2cc) = iVar2;
LAB_00696f82:
  *(undefined4 **)(iVar2 + *(int *)(param_1 + 0x2d0) * 4) = puVar5;
  *(int *)(param_1 + 0x2d0) = *(int *)(param_1 + 0x2d0) + 1;
  FUN_00722920();
  return;
}



/* FUNCTION 8391 ; VA 0x00696fb0 ; FUN_00696fb0 */

void __thiscall FUN_00696fb0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  uint uVar7;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5fa5;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00722910();
  uVar1 = FUN_0071e070(auStack_14,param_2);
  iVar5 = *(int *)(param_1 + 0x4b8);
  iVar3 = *(int *)(param_1 + 0x4bc);
  iStack_8 = 0;
  if (iVar5 != iVar3) goto LAB_006970f8;
  if (iVar3 == 0) {
    *(undefined4 *)(param_1 + 0x4bc) = 0x10;
    uVar7 = 0x10;
LAB_0069701b:
    uVar4 = -(uint)((int)((ulonglong)uVar7 * 4 >> 0x20) != 0) | (uint)((ulonglong)uVar7 * 4);
    puVar2 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    iStack_8._0_1_ = 1;
    if (puVar2 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar2 + 1;
      *puVar2 = uVar7;
      FUN_016f4053(puVar6,4,uVar7,FUN_0071e090,FUN_0071e0a0);
    }
    iVar5 = *(int *)(param_1 + 0x4b8);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
  }
  else {
    uVar7 = iVar3 * 2;
    *(uint *)(param_1 + 0x4bc) = uVar7;
    if (uVar7 != 0) goto LAB_0069701b;
    puVar6 = (uint *)0x0;
  }
  iVar3 = *(int *)(param_1 + 0x4b4);
  if (iVar3 != 0) {
    uVar7 = 0;
    if (iVar5 != 0) {
      do {
        FUN_0071e0d0(*(int *)(param_1 + 0x4b4) + uVar7 * 4);
        uVar7 = uVar7 + 1;
      } while (uVar7 < *(uint *)(param_1 + 0x4b8));
      iVar3 = *(int *)(param_1 + 0x4b4);
    }
    if (iVar3 != 0) {
      iStack_8._0_1_ = 2;
      FUN_016f32d1(iVar3,4,*(undefined4 *)(iVar3 + -4),FUN_0071e0a0);
      FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 4 + 4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
    }
  }
  *(uint **)(param_1 + 0x4b4) = puVar6;
LAB_006970f8:
  FUN_0071e0d0(uVar1);
  *(int *)(param_1 + 0x4b8) = *(int *)(param_1 + 0x4b8) + 1;
  iStack_8 = 0xffffffff;
  FUN_0071e0a0();
  FUN_00722920();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8392 ; VA 0x00697140 ; FUN_00697140 */

undefined __thiscall
FUN_00697140(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined uVar1;
  int iStack_128;
  undefined4 uStack_11c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5fbb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006a5600();
  uStack_8 = 0;
  uStack_11 = 0x1d;
  FUN_006a6060(&uStack_11,8,1);
  FUN_006a5ee0(param_4,param_5);
  uVar1 = (**(code **)(*param_1 + 0x144))(param_2,param_3,uStack_11c,iStack_128 + 7U >> 3,param_6);
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 8393 ; VA 0x006971f0 ; FUN_006971f0 */

int FUN_006971f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  FUN_00722910();
  iVar1 = FUN_00697300(param_3,param_4);
  FUN_00722920();
  FUN_005f7140();
  FUN_005f70a0();
  *(int *)(iVar1 + 0x30) = param_1;
  *(undefined4 *)(iVar1 + 0x38) = param_2;
  *(int *)(iVar1 + 0x34) = param_1 << 3;
  *(undefined *)(iVar1 + 0x3c) = 1;
  *(undefined4 *)(iVar1 + 0x20) = DAT_01d5b1f0;
  *(undefined4 *)(iVar1 + 0x24) = DAT_01d5b1f4;
  *(undefined2 *)(iVar1 + 0x28) = DAT_01d5b1f8;
  *(undefined *)(iVar1 + 0x3d) = 0;
  return iVar1;
}



/* FUNCTION 8394 ; VA 0x00697270 ; FUN_00697270 */

int FUN_00697270(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  FUN_00722910();
  iVar1 = FUN_00697300(param_2,param_3);
  FUN_00722920();
  FUN_005f7140();
  FUN_005f70a0();
  uVar2 = FUN_01674f30(param_1);
  *(undefined4 *)(iVar1 + 0x38) = uVar2;
  *(int *)(iVar1 + 0x30) = param_1;
  *(int *)(iVar1 + 0x34) = param_1 * 8;
  *(undefined *)(iVar1 + 0x3c) = 1;
  *(undefined4 *)(iVar1 + 0x20) = DAT_01d5b1f0;
  *(undefined4 *)(iVar1 + 0x24) = DAT_01d5b1f4;
  *(undefined2 *)(iVar1 + 0x28) = DAT_01d5b1f8;
  *(undefined *)(iVar1 + 0x3d) = 0;
  return iVar1;
}



/* FUNCTION 8395 ; VA 0x00697300 ; FUN_00697300 */

undefined4 __fastcall FUN_00697300(int *param_1)

{
  undefined4 uVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  if (param_1[2] < 1) {
    piVar2 = (int *)FUN_01674f30(0x14);
    *param_1 = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      param_1[2] = 1;
      uVar3 = (uint)param_1[4] / 0x48;
      iVar6 = 0;
      iVar5 = FUN_01674f30(param_1[4]);
      piVar2[2] = iVar5;
      if (iVar5 != 0) {
        iVar4 = FUN_01674f30(uVar3 << 2);
        iVar5 = piVar2[2];
        *piVar2 = iVar4;
        if (iVar4 != 0) {
          if (uVar3 != 0) {
            do {
              *(int **)(iVar5 + 0x40) = piVar2;
              *(int *)(iVar4 + iVar6 * 4) = iVar5;
              iVar5 = iVar5 + 0x48;
              iVar6 = iVar6 + 1;
            } while (iVar6 < (int)uVar3);
          }
          piVar2[1] = uVar3;
          piVar2[3] = *param_1;
          piVar2[4] = (int)piVar2;
          param_1 = (int *)*param_1;
          param_1[1] = param_1[1] + -1;
          return *(undefined4 *)(*param_1 + param_1[1] * 4);
        }
        FUN_01674ea0(iVar5);
      }
    }
    return 0;
  }
  piVar2 = (int *)*param_1;
  iVar5 = piVar2[1] + -1;
  piVar2[1] = iVar5;
  uVar1 = *(undefined4 *)(*piVar2 + iVar5 * 4);
  if (iVar5 == 0) {
    param_1[2] = param_1[2] + -1;
    *param_1 = piVar2[3];
    *(int *)(piVar2[3] + 0x10) = piVar2[4];
    *(int *)(piVar2[4] + 0xc) = piVar2[3];
    iVar5 = param_1[3];
    param_1[3] = iVar5 + 1;
    if (iVar5 == 0) {
      param_1[1] = (int)piVar2;
      piVar2[3] = (int)piVar2;
      piVar2[4] = (int)piVar2;
      return uVar1;
    }
    piVar2[3] = param_1[1];
    piVar2[4] = *(int *)(param_1[1] + 0x10);
    *(int **)(*(int *)(param_1[1] + 0x10) + 0xc) = piVar2;
    *(int **)(param_1[1] + 0x10) = piVar2;
  }
  return uVar1;
}



/* FUNCTION 8396 ; VA 0x00697440 ; FUN_00697440 */

undefined4 * __fastcall FUN_00697440(int *param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5fd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00722910();
  if (param_1[2] < 1) {
    piVar2 = (int *)FUN_01674f30(0x14);
    *param_1 = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      param_1[2] = 1;
      uVar3 = (uint)param_1[4] / 0x88;
      iVar5 = 0;
      iVar1 = FUN_01674f30(param_1[4]);
      piVar2[2] = iVar1;
      if (iVar1 != 0) {
        iVar1 = FUN_01674f30(uVar3 << 2);
        *piVar2 = iVar1;
        if (iVar1 != 0) {
          iVar4 = piVar2[2];
          if (uVar3 != 0) {
            do {
              *(int **)(iVar4 + 0x80) = piVar2;
              *(int *)(iVar1 + iVar5 * 4) = iVar4;
              iVar4 = iVar4 + 0x88;
              iVar5 = iVar5 + 1;
            } while (iVar5 < (int)uVar3);
          }
          piVar2[1] = uVar3;
          piVar2[3] = *param_1;
          piVar2[4] = (int)piVar2;
          param_1 = (int *)*param_1;
          param_1[1] = param_1[1] + -1;
          puVar6 = *(undefined4 **)(*param_1 + param_1[1] * 4);
          goto LAB_0069753d;
        }
        FUN_01674ea0(piVar2[2]);
      }
    }
    puVar6 = (undefined4 *)0x0;
  }
  else {
    piVar2 = (int *)*param_1;
    iVar1 = piVar2[1] + -1;
    piVar2[1] = iVar1;
    puVar6 = *(undefined4 **)(*piVar2 + iVar1 * 4);
    if (iVar1 == 0) {
      param_1[2] = param_1[2] + -1;
      *param_1 = piVar2[3];
      *(int *)(piVar2[3] + 0x10) = piVar2[4];
      *(int *)(piVar2[4] + 0xc) = piVar2[3];
      iVar1 = param_1[3];
      param_1[3] = iVar1 + 1;
      if (iVar1 == 0) {
        param_1[1] = (int)piVar2;
        piVar2[3] = (int)piVar2;
        piVar2[4] = (int)piVar2;
      }
      else {
        piVar2[3] = param_1[1];
        piVar2[4] = *(int *)(param_1[1] + 0x10);
        *(int **)(*(int *)(param_1[1] + 0x10) + 0xc) = piVar2;
        *(int **)(param_1[1] + 0x10) = piVar2;
      }
    }
  }
LAB_0069753d:
  FUN_00722920();
  *puVar6 = 0;
  puVar6[1] = 0;
  uStack_8 = 0;
  FUN_005f70a0();
  FUN_005f7140();
  puVar6[0x17] = 0;
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 8397 ; VA 0x006975d0 ; FUN_006975d0 */

int __fastcall FUN_006975d0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  FUN_00722910();
  if (param_1[2] < 1) {
    piVar1 = (int *)FUN_01674f30(0x14);
    iVar5 = 0;
    *param_1 = (int)piVar1;
    if (piVar1 != (int *)0x0) {
      param_1[2] = 1;
      uVar2 = (uint)param_1[4] / 0x610;
      iVar4 = FUN_01674f30(param_1[4]);
      piVar1[2] = iVar4;
      if (iVar4 != 0) {
        iVar3 = FUN_01674f30(uVar2 << 2);
        iVar4 = piVar1[2];
        *piVar1 = iVar3;
        if (iVar3 != 0) {
          if (uVar2 != 0) {
            do {
              *(int **)(iVar4 + 0x608) = piVar1;
              *(int *)(iVar3 + iVar5 * 4) = iVar4;
              iVar4 = iVar4 + 0x610;
              iVar5 = iVar5 + 1;
            } while (iVar5 < (int)uVar2);
          }
          piVar1[1] = uVar2;
          piVar1[3] = *param_1;
          piVar1[4] = (int)piVar1;
          param_1 = (int *)*param_1;
          param_1[1] = param_1[1] + -1;
          iVar5 = *(int *)(*param_1 + param_1[1] * 4);
          goto LAB_006976c3;
        }
        FUN_01674ea0(iVar4);
      }
      iVar5 = 0;
    }
  }
  else {
    piVar1 = (int *)*param_1;
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    iVar5 = *(int *)(*piVar1 + iVar4 * 4);
    if (iVar4 == 0) {
      param_1[2] = param_1[2] + -1;
      *param_1 = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      iVar4 = param_1[3];
      param_1[3] = iVar4 + 1;
      if (iVar4 == 0) {
        param_1[1] = (int)piVar1;
        piVar1[3] = (int)piVar1;
        piVar1[4] = (int)piVar1;
      }
      else {
        piVar1[3] = param_1[1];
        piVar1[4] = *(int *)(param_1[1] + 0x10);
        *(int **)(*(int *)(param_1[1] + 0x10) + 0xc) = piVar1;
        *(int **)(param_1[1] + 0x10) = piVar1;
      }
    }
  }
LAB_006976c3:
  FUN_00722920();
  FUN_005f7140();
  return iVar5;
}



/* FUNCTION 8398 ; VA 0x00697730 ; FUN_00697730 */

undefined4 * __fastcall FUN_00697730(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  FUN_00722910();
  if (param_1[2] < 1) {
    piVar1 = (int *)FUN_01674f30(0x14);
    puVar5 = (undefined4 *)0x0;
    *param_1 = (int)piVar1;
    if (piVar1 != (int *)0x0) {
      uVar4 = (uint)param_1[4] >> 4;
      param_1[2] = 1;
      iVar3 = FUN_01674f30(param_1[4]);
      piVar1[2] = iVar3;
      if (iVar3 != 0) {
        iVar2 = FUN_01674f30(uVar4 << 2);
        iVar3 = piVar1[2];
        *piVar1 = iVar2;
        if (iVar2 != 0) {
          if (uVar4 != 0) {
            do {
              *(int **)(iVar3 + 0xc) = piVar1;
              *(int *)(iVar2 + (int)puVar5 * 4) = iVar3;
              iVar3 = iVar3 + 0x10;
              puVar5 = (undefined4 *)((int)puVar5 + 1);
            } while ((int)puVar5 < (int)uVar4);
          }
          piVar1[1] = uVar4;
          piVar1[3] = *param_1;
          piVar1[4] = (int)piVar1;
          param_1 = (int *)*param_1;
          param_1[1] = param_1[1] + -1;
          puVar5 = *(undefined4 **)(*param_1 + param_1[1] * 4);
          goto LAB_00697813;
        }
        FUN_01674ea0(iVar3);
      }
      puVar5 = (undefined4 *)0x0;
    }
  }
  else {
    piVar1 = (int *)*param_1;
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    puVar5 = *(undefined4 **)(*piVar1 + iVar3 * 4);
    if (iVar3 == 0) {
      param_1[2] = param_1[2] + -1;
      *param_1 = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      iVar3 = param_1[3];
      param_1[3] = iVar3 + 1;
      if (iVar3 == 0) {
        param_1[1] = (int)piVar1;
        piVar1[3] = (int)piVar1;
        piVar1[4] = (int)piVar1;
      }
      else {
        piVar1[3] = param_1[1];
        piVar1[4] = *(int *)(param_1[1] + 0x10);
        *(int **)(*(int *)(param_1[1] + 0x10) + 0xc) = piVar1;
        *(int **)(param_1[1] + 0x10) = piVar1;
      }
    }
  }
LAB_00697813:
  FUN_00722920();
  puVar5[2] = 0;
  *puVar5 = 0;
  puVar5[1] = 0;
  return puVar5;
}



/* FUNCTION 8399 ; VA 0x00697870 ; FUN_00697870 */

void FUN_00697870(undefined4 param_1)

{
  FUN_00697270(param_1,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0xb02);
  return;
}



/* FUNCTION 8400 ; VA 0x00697890 ; FUN_00697890 */

void __thiscall FUN_00697890(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x488) = param_2;
  return;
}



/* FUNCTION 8401 ; VA 0x006978a0 ; FUN_006978a0 */

bool __fastcall FUN_006978a0(int *param_1)

{
  char *pcVar1;
  ushort uVar2;
  short sVar3;
  uint uVar4;
  ushort uVar5;
  
  if ((param_1[0x8d] != 0) && (*(char *)((int)param_1 + 5) == '\0')) {
    uVar5 = 0;
    uVar4 = 0;
    if (param_1[0x8f] != 0) {
      do {
        pcVar1 = *(char **)(param_1[0x8e] + uVar4 * 4);
        if (((*pcVar1 != '\0') && (*(int *)(pcVar1 + 0xb68) == 7)) && (pcVar1[1] == '\0')) {
          uVar5 = uVar5 + 1;
        }
        uVar4 = uVar4 + 1;
      } while (uVar4 < (uint)param_1[0x8f]);
    }
    uVar2 = (**(code **)(*param_1 + 0x20))();
    return uVar5 < uVar2;
  }
  sVar3 = (**(code **)(*param_1 + 0x20))();
  return sVar3 != 0;
}



/* FUNCTION 8402 ; VA 0x00697920 ; FUN_00697920 */

char * __thiscall FUN_00697920(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  char *pcVar7;
  undefined4 in_stack_00000024;
  int in_stack_00000028;
  int *in_stack_0000002c;
  int *in_stack_00000030;
  int in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined2 in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  int *in_stack_00000078;
  undefined auStack_450 [1028];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined2 uStack_44;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6000;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_006a6900();
  if (*(char *)(param_1 + 0x610) != '\0') {
    FUN_005f70a0();
    FUN_005f7140();
    uStack_48 = DAT_01d5b1f4;
    uStack_44 = DAT_01d5b1f8;
    uStack_4c = DAT_01d5b1f0;
    FUN_005f7170(&stack0x00000004);
    cVar4 = FUN_0069b470(&uStack_4c,0);
    if ((cVar4 == '\0') && (uVar5 = 0, *(short *)(param_1 + 0xe) != 0)) {
      iVar6 = 0;
      do {
        if ((*(char *)(iVar6 + *(int *)(param_1 + 0x234)) == '\x01') &&
           (cVar4 = FUN_005f72a0(&stack0x00000004), cVar4 != '\0')) {
          iStack_18 = *(int *)(iVar6 + 0xb2c + *(int *)(param_1 + 0x234));
          uVar2 = *(uint *)(iVar6 + 0xb28 + *(int *)(param_1 + 0x234));
          if ((iStack_18 == 0) && (uVar2 <= uStack_14)) {
            iStack_18 = -(uint)(uStack_14 < uVar2);
            if ((iStack_18 == 0) && (uStack_14 - uVar2 < 100)) {
              *(undefined *)in_stack_00000030 = 1;
              goto LAB_00697a50;
            }
          }
        }
        uVar5 = uVar5 + 1;
        iVar6 = iVar6 + 0xb70;
      } while (uVar5 < *(ushort *)(param_1 + 0xe));
    }
  }
  FUN_005f7280(in_stack_00000028 + 8);
  uVar5 = 0;
  *(undefined *)in_stack_00000030 = 0;
  if (*(ushort *)(param_1 + 0xe) != 0) {
    pcVar7 = *(char **)(param_1 + 0x234);
    do {
      if (*pcVar7 == '\0') {
        FUN_0069d8a0(&stack0x00000004,uVar5);
        *(undefined4 *)(pcVar7 + 0xb40) = *(undefined4 *)(param_1 + 0x42c);
        *(undefined4 *)(pcVar7 + 0xb30) = in_stack_00000058;
        *(undefined4 *)(pcVar7 + 0xb34) = in_stack_0000005c;
        *(undefined2 *)(pcVar7 + 0xb38) = in_stack_00000060;
        *pcVar7 = '\x01';
        if (*(int *)(pcVar7 + 0xb40) < in_stack_00000054) {
          *(int *)(pcVar7 + 0xb40) = in_stack_00000054;
        }
        *(undefined4 *)(pcVar7 + 0xb58) = in_stack_0000006c;
        *(undefined4 *)(pcVar7 + 0xb5c) = in_stack_00000070;
        if (in_stack_00000078 != (int *)0x0) {
          LOCK();
          in_stack_00000078[1] = in_stack_00000078[1] + 1;
          UNLOCK();
        }
        *(undefined4 *)(pcVar7 + 0x188) = in_stack_00000074;
        in_stack_00000030 = *(int **)(pcVar7 + 0x18c);
        *(int **)(pcVar7 + 0x18c) = in_stack_00000078;
        if (in_stack_00000030 != (int *)0x0) {
          LOCK();
          iVar6 = in_stack_00000030[1] + -1;
          in_stack_00000030[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*in_stack_00000030)();
            LOCK();
            iVar6 = in_stack_00000030[2] + -1;
            in_stack_00000030[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*in_stack_00000030 + 4))();
            }
          }
        }
        FUN_005fec80(1,*(undefined4 *)(pcVar7 + 0xb40),in_stack_00000068);
        FUN_005ffa40(*(undefined4 *)(param_1 + 0x4ac));
        FUN_005ffa60(*(undefined4 *)(param_1 + 0x4b0));
        FUN_005ffa50(*(undefined4 *)(param_1 + 0x46c));
        *(uint *)(*(int *)(param_1 + 0x238) + *(int *)(param_1 + 0x23c) * 4) =
             uVar5 * 0xb70 + *(int *)(param_1 + 0x234);
        *(int *)(param_1 + 0x23c) = *(int *)(param_1 + 0x23c) + 1;
        cVar4 = FUN_005f71d0(&stack0x00000034);
        if (cVar4 != '\0') goto LAB_00697c26;
        FUN_005f7b20(1,auStack_450,0x401,0x7c);
        uVar5 = 0;
        param_1 = param_1 + 0x4c0;
        goto LAB_00697c00;
      }
      uVar5 = uVar5 + 1;
      pcVar7 = pcVar7 + 0xb70;
    } while (uVar5 < *(ushort *)(param_1 + 0xe));
  }
LAB_00697a50:
  pcVar7 = (char *)0x0;
  goto LAB_00697a52;
  while( true ) {
    uVar5 = uVar5 + 1;
    param_1 = param_1 + 0x20;
    if (9 < uVar5) break;
LAB_00697c00:
    cVar4 = FUN_005f71d0(&DAT_01eae4bc);
    if ((cVar4 != '\0') || (cVar4 = FUN_005f72a0(param_1), cVar4 != '\0')) break;
  }
LAB_00697c26:
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  *(int *)(pcVar7 + 0xb44) = in_stack_00000028;
  piVar3 = *(int **)(pcVar7 + 0xb48);
  *(int **)(pcVar7 + 0xb48) = in_stack_0000002c;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar6 = piVar3[2] + -1;
      piVar3[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar5 = uStack_14;
  pcVar7[0xac0] = -1;
  pcVar7[0xac1] = -1;
  pcVar7[0xad0] = -1;
  pcVar7[0xad1] = -1;
  pcVar7[0xae0] = -1;
  pcVar7[0xae1] = -1;
  pcVar7[0xaf0] = -1;
  pcVar7[0xaf1] = -1;
  pcVar7[0xb00] = -1;
  pcVar7[0xb01] = -1;
  pcVar7[0xac8] = '\0';
  pcVar7[0xac9] = '\0';
  pcVar7[0xaca] = '\0';
  pcVar7[0xacb] = '\0';
  pcVar7[0xacc] = '\0';
  pcVar7[0xacd] = '\0';
  pcVar7[0xace] = '\0';
  pcVar7[0xacf] = '\0';
  pcVar7[0xad8] = '\0';
  pcVar7[0xad9] = '\0';
  pcVar7[0xada] = '\0';
  pcVar7[0xadb] = '\0';
  pcVar7[0xadc] = '\0';
  pcVar7[0xadd] = '\0';
  pcVar7[0xade] = '\0';
  pcVar7[0xadf] = '\0';
  pcVar7[0xae8] = '\0';
  pcVar7[0xae9] = '\0';
  pcVar7[0xaea] = '\0';
  pcVar7[0xaeb] = '\0';
  pcVar7[0xaec] = '\0';
  pcVar7[0xaed] = '\0';
  pcVar7[0xaee] = '\0';
  pcVar7[0xaef] = '\0';
  pcVar7[0xaf8] = '\0';
  pcVar7[0xaf9] = '\0';
  pcVar7[0xafa] = '\0';
  pcVar7[0xafb] = '\0';
  pcVar7[0xafc] = '\0';
  pcVar7[0xafd] = '\0';
  pcVar7[0xafe] = '\0';
  pcVar7[0xaff] = '\0';
  pcVar7[0xb08] = '\0';
  pcVar7[0xb09] = '\0';
  pcVar7[0xb0a] = '\0';
  pcVar7[0xb0b] = '\0';
  pcVar7[0xb0c] = '\0';
  pcVar7[0xb0d] = '\0';
  pcVar7[0xb0e] = '\0';
  pcVar7[0xb0f] = '\0';
  pcVar7[2] = -1;
  pcVar7[3] = -1;
  *(undefined4 *)(pcVar7 + 0xb68) = in_stack_00000024;
  pcVar7[0xb10] = '\0';
  pcVar7[0xb11] = '\0';
  pcVar7[0xb12] = '\0';
  pcVar7[0xb13] = '\0';
  pcVar7[0xb14] = '\0';
  pcVar7[0xb15] = '\0';
  pcVar7[0xb16] = '\0';
  pcVar7[0xb17] = '\0';
  pcVar7[0xb18] = '\0';
  pcVar7[0xb19] = '\0';
  pcVar7[0xb1a] = '\0';
  pcVar7[0xb1b] = '\0';
  pcVar7[0xb1c] = '\0';
  pcVar7[0xb1d] = '\0';
  pcVar7[0xb1e] = '\0';
  pcVar7[0xb1f] = '\0';
  pcVar7[1] = '\0';
  *(uint *)(pcVar7 + 0xb28) = uStack_14;
  pcVar7[0xb2c] = '\0';
  pcVar7[0xb2d] = '\0';
  pcVar7[0xb2e] = '\0';
  pcVar7[0xb2f] = '\0';
  FUN_005f7170(&DAT_01eae4bc);
  *(uint *)(pcVar7 + 0xb20) = uVar5;
  pcVar7[0xb24] = '\0';
  pcVar7[0xb25] = '\0';
  pcVar7[0xb26] = '\0';
  pcVar7[0xb27] = '\0';
LAB_00697a52:
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000078;
  if (in_stack_00000078 != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_00000078[1] + -1;
    in_stack_00000078[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*in_stack_00000078)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar7;
}



/* FUNCTION 8403 ; VA 0x00697d70 ; FUN_00697d70 */

void __thiscall FUN_00697d70(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  
  piVar1 = param_2;
  cVar2 = (**(code **)(*param_2 + 0x44))();
  if ((DAT_01d5b280 == '\0') && (cVar2 == '\0')) {
    uVar3 = 0;
    if (*(uint *)(param_1 + 0x2dc) != 0) {
      puVar4 = *(undefined4 **)(param_1 + 0x2d8);
      do {
        if ((int *)*puVar4 == piVar1) {
          if (uVar3 != 0xffffffff) {
            return;
          }
          break;
        }
        uVar3 = uVar3 + 1;
        puVar4 = puVar4 + 1;
      } while (uVar3 < *(uint *)(param_1 + 0x2dc));
    }
    FUN_00598640(param_1);
    (**(code **)(*piVar1 + 4))();
    FUN_005fdf80(&param_2,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0xaaa);
    if (DAT_01eadf38 != '\0') {
      FUN_016774b0(DAT_01eadf38,"RakPeer successfully inserted plugin (thread safe)",0);
      return;
    }
  }
  else {
    uVar3 = 0;
    if (*(uint *)(param_1 + 0x2e8) != 0) {
      puVar4 = *(undefined4 **)(param_1 + 0x2e4);
      do {
        if ((int *)*puVar4 == piVar1) {
          if (uVar3 != 0xffffffff) {
            return;
          }
          break;
        }
        uVar3 = uVar3 + 1;
        puVar4 = puVar4 + 1;
      } while (uVar3 < *(uint *)(param_1 + 0x2e8));
    }
    FUN_00598640(param_1);
    (**(code **)(*piVar1 + 4))();
    FUN_005fdf80(&param_2,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0xaa0);
    if (DAT_01eadf38 != '\0') {
      FUN_016774b0(DAT_01eadf38,"RakPeer successfully inserted plugin (not thread safe)",0);
    }
  }
  return;
}



/* FUNCTION 8404 ; VA 0x00697e80 ; FUN_00697e80 */

void __thiscall FUN_00697e80(int param_1,code *param_2,undefined4 param_3)

{
  uint uVar1;
  
  uVar1 = 0;
  if (*(int *)(param_1 + 0x2e8) != 0) {
    do {
      (*param_2)(param_3);
      uVar1 = uVar1 + 1;
    } while (uVar1 < *(uint *)(param_1 + 0x2e8));
  }
  if ((DAT_01d5b280 == '\0') && (uVar1 = 0, *(int *)(param_1 + 0x2dc) != 0)) {
    do {
      (*param_2)(param_3);
      uVar1 = uVar1 + 1;
    } while (uVar1 < *(uint *)(param_1 + 0x2dc));
  }
  return;
}



/* FUNCTION 8405 ; VA 0x00697ef0 ; FUN_00697ef0 */

void FUN_00697ef0(int *param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  
  uVar1 = 0;
  if (param_1[1] != 0) {
    do {
      switch(**(undefined **)(param_2 + 0x38)) {
      case 10:
        uVar2 = 8;
        break;
      case 0xb:
        uVar2 = 9;
        break;
      case 0xc:
        uVar2 = 10;
        break;
      default:
        goto switchD_00697f18_caseD_d;
      case 0x10:
        if (DAT_01eadf38 != '\0') {
          FUN_016774b0(DAT_01eadf38,
                       "RakPeer received ID_CONNECTION_REQUEST_ACCEPTED packet, calling OnNewConnection callback of plugin"
                       ,0);
        }
        uVar2 = 0;
        goto LAB_00697f46;
      case 0x11:
        uVar2 = 0;
        break;
      case 0x12:
        uVar2 = 1;
        break;
      case 0x13:
        uVar2 = 1;
LAB_00697f46:
        (**(code **)(**(int **)(*param_1 + uVar1 * 4) + 0x20))
                  (param_2,*(undefined4 *)(param_2 + 0x20),*(undefined4 *)(param_2 + 0x24),
                   *(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_2 + 0x2c),uVar2);
        goto switchD_00697f18_caseD_d;
      case 0x14:
        uVar2 = 2;
        break;
      case 0x15:
        uVar2 = 1;
        goto LAB_00697f21;
      case 0x16:
        uVar2 = 2;
LAB_00697f21:
        (**(code **)(**(int **)(*param_1 + uVar1 * 4) + 0x1c))
                  (param_2,*(undefined4 *)(param_2 + 0x20),*(undefined4 *)(param_2 + 0x24),
                   *(undefined4 *)(param_2 + 0x28),*(undefined4 *)(param_2 + 0x2c),uVar2);
        goto switchD_00697f18_caseD_d;
      case 0x17:
        uVar2 = 4;
        break;
      case 0x18:
        uVar2 = 5;
        break;
      case 0x19:
        uVar2 = 6;
        break;
      case 0x1a:
        uVar2 = 7;
      }
      (**(code **)(**(int **)(*param_1 + uVar1 * 4) + 0x24))(param_2,uVar2);
switchD_00697f18_caseD_d:
      uVar1 = uVar1 + 1;
    } while (uVar1 < (uint)param_1[1]);
  }
  return;
}



/* FUNCTION 8406 ; VA 0x00698010 ; FUN_00698010 */

void FUN_00698010(undefined4 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int iVar1;
  
  iVar1 = FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0xaf8);
  *(undefined4 *)(iVar1 + 0x5c) = 0;
  FUN_005f7170(param_5);
  *(undefined4 *)(iVar1 + 0x18) = param_1;
  *(undefined4 *)(iVar1 + 0x1c) = param_2;
  *(undefined2 *)(iVar1 + 0x20) = param_3;
  *(undefined4 *)(iVar1 + 0x78) = 3;
  FUN_0069cc60(iVar1);
  return;
}



/* FUNCTION 8407 ; VA 0x00698070 ; FUN_00698070 */

void __thiscall FUN_00698070(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00722910();
  uVar5 = 0;
  while( true ) {
    uVar3 = *(uint *)(param_1 + 0x30);
    if (*(uint *)(param_1 + 0x34) < uVar3) {
      iVar2 = *(int *)(param_1 + 0x38) - uVar3;
    }
    else {
      iVar2 = -uVar3;
    }
    if (*(uint *)(param_1 + 0x34) + iVar2 <= uVar5) break;
    uVar6 = *(uint *)(param_1 + 0x38);
    uVar4 = uVar3 + uVar5;
    if (uVar6 <= uVar4) {
      uVar4 = (uVar3 - uVar6) + uVar5;
    }
    piVar1 = *(int **)(*(int *)(param_1 + 0x2c) + uVar4 * 4);
    if ((piVar1[2] != 0) && (iVar2 = *piVar1, iVar2 != 0)) {
      uStack_8 = 0;
      FUN_016f32d1(iVar2,8,*(undefined4 *)(iVar2 + -4),FUN_00550b30);
      FUN_01674ea0((int *)(iVar2 + -4),*(int *)(iVar2 + -4) * 8 + 4);
      uVar6 = *(uint *)(param_1 + 0x38);
      uStack_8 = 0xffffffff;
    }
    uVar3 = *(int *)(param_1 + 0x30) + uVar5;
    if (uVar6 <= uVar3) {
      uVar3 = (*(int *)(param_1 + 0x30) - uVar6) + uVar5;
    }
    FUN_0069dba0(*(undefined4 *)(*(int *)(param_1 + 0x2c) + uVar3 * 4),param_2,param_3);
    uVar5 = uVar5 + 1;
  }
  if (*(uint *)(param_1 + 0x38) != 0) {
    if (0x20 < *(uint *)(param_1 + 0x38)) {
      FUN_01674ea0(*(undefined4 *)(param_1 + 0x2c));
      *(undefined4 *)(param_1 + 0x38) = 0;
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
  }
  FUN_00722920();
  FUN_00722910();
  FUN_005f9da0(param_2,param_3);
  FUN_00722920();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8408 ; VA 0x006981b0 ; FUN_006981b0 */

void __fastcall FUN_006981b0(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  FUN_00722910();
  if (*(int *)(param_1 + 0x2d0) != 0) {
    do {
      FUN_01674ea0(**(undefined4 **)(*(int *)(param_1 + 0x2cc) + uVar1 * 4));
      FUN_01674ea0(*(undefined4 *)(*(int *)(param_1 + 0x2cc) + uVar1 * 4),8);
      uVar1 = uVar1 + 1;
    } while (uVar1 < *(uint *)(param_1 + 0x2d0));
  }
  if (*(int *)(param_1 + 0x2d4) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x2cc));
    *(undefined4 *)(param_1 + 0x2d4) = 0;
    *(undefined4 *)(param_1 + 0x2cc) = 0;
    *(undefined4 *)(param_1 + 0x2d0) = 0;
  }
  FUN_00722920();
  return;
}



/* FUNCTION 8409 ; VA 0x00698240 ; FUN_00698240 */

void __fastcall FUN_00698240(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  
  while( true ) {
    FUN_00722910();
    if (*(int *)(param_1 + 0x348) == *(int *)(param_1 + 0x34c)) {
      piVar5 = (int *)0x0;
    }
    else {
      iVar2 = *(int *)(param_1 + 0x348) + 1;
      *(int *)(param_1 + 0x348) = iVar2;
      if (iVar2 == *(int *)(param_1 + 0x350)) {
        *(undefined4 *)(param_1 + 0x348) = 0;
        iVar2 = 0;
      }
      if (iVar2 == 0) {
        piVar5 = *(int **)(*(int *)(param_1 + 0x344) + -4 + *(int *)(param_1 + 0x350) * 4);
      }
      else {
        piVar5 = *(int **)(*(int *)(param_1 + 0x344) + -4 + iVar2 * 4);
      }
    }
    FUN_00722920();
    if (piVar5 == (int *)0x0) break;
    if ((piVar5[0x17] != 0) && (*piVar5 == 0)) {
      FUN_01674ea0(piVar5[0x17]);
    }
    piVar1 = (int *)piVar5[1];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_00722910();
    FUN_0069d9d0(piVar5,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x1174);
    FUN_00722920();
  }
  FUN_00722910();
  uVar6 = 0;
  while( true ) {
    uVar3 = *(uint *)(param_1 + 0x348);
    if (*(uint *)(param_1 + 0x34c) < uVar3) {
      iVar2 = *(int *)(param_1 + 0x350) - uVar3;
    }
    else {
      iVar2 = -uVar3;
    }
    if (*(uint *)(param_1 + 0x34c) + iVar2 <= uVar6) break;
    uVar4 = uVar3 + uVar6;
    if (*(uint *)(param_1 + 0x350) <= uVar4) {
      uVar4 = (uVar3 - *(uint *)(param_1 + 0x350)) + uVar6;
    }
    piVar5 = *(int **)(*(int *)(*(int *)(param_1 + 0x344) + uVar4 * 4) + 4);
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[1] + -1;
      piVar5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar2 = piVar5[2] + -1;
        piVar5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uVar3 = *(int *)(param_1 + 0x348) + uVar6;
    if (*(uint *)(param_1 + 0x350) <= uVar3) {
      uVar3 = (*(int *)(param_1 + 0x348) - *(uint *)(param_1 + 0x350)) + uVar6;
    }
    FUN_0069d9d0(*(undefined4 *)(*(int *)(param_1 + 0x344) + uVar3 * 4),
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x1176);
    uVar6 = uVar6 + 1;
  }
  if (*(uint *)(param_1 + 0x350) != 0) {
    if (0x20 < *(uint *)(param_1 + 0x350)) {
      FUN_01674ea0(*(undefined4 *)(param_1 + 0x344));
      *(undefined4 *)(param_1 + 0x350) = 0;
    }
    *(undefined4 *)(param_1 + 0x348) = 0;
    *(undefined4 *)(param_1 + 0x34c) = 0;
  }
  FUN_00722920();
  FUN_00722910();
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0x1176);
  FUN_00722920();
  return;
}



/* FUNCTION 8410 ; VA 0x00698420 ; FUN_00698420 */

void __fastcall FUN_00698420(int param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  
  while( true ) {
    FUN_00722910();
    if (*(int *)(param_1 + 0x39c) == *(int *)(param_1 + 0x3a0)) {
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)(param_1 + 0x39c) + 1;
      *(int *)(param_1 + 0x39c) = iVar4;
      if (iVar4 == *(int *)(param_1 + 0x3a4)) {
        *(undefined4 *)(param_1 + 0x39c) = 0;
        iVar4 = 0;
      }
      if (iVar4 == 0) {
        iVar4 = *(int *)(*(int *)(param_1 + 0x398) + -4 + *(int *)(param_1 + 0x3a4) * 4);
      }
      else {
        iVar4 = *(int *)(*(int *)(param_1 + 0x398) + -4 + iVar4 * 4);
      }
    }
    FUN_00722920();
    FUN_00722910();
    if (iVar4 == 0) break;
    FUN_0069dab0(iVar4,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x117f);
    FUN_00722920();
  }
  uVar5 = 0;
  while( true ) {
    uVar1 = *(uint *)(param_1 + 0x39c);
    if (*(uint *)(param_1 + 0x3a0) < uVar1) {
      iVar4 = *(int *)(param_1 + 0x3a4) - uVar1;
    }
    else {
      iVar4 = -uVar1;
    }
    uVar2 = *(uint *)(param_1 + 0x3a4);
    if (*(uint *)(param_1 + 0x3a0) + iVar4 <= uVar5) break;
    uVar3 = uVar1 + uVar5;
    if (uVar2 <= uVar3) {
      uVar3 = (uVar1 - uVar2) + uVar5;
    }
    FUN_0069dab0(*(undefined4 *)(*(int *)(param_1 + 0x398) + uVar3 * 4),
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x1181);
    uVar5 = uVar5 + 1;
  }
  if (uVar2 != 0) {
    if (0x20 < uVar2) {
      FUN_01674ea0(*(undefined4 *)(param_1 + 0x398));
      *(undefined4 *)(param_1 + 0x3a4) = 0;
    }
    *(undefined4 *)(param_1 + 0x39c) = 0;
    *(undefined4 *)(param_1 + 0x3a0) = 0;
  }
  FUN_00722920();
  FUN_00722910();
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0x1181);
  FUN_00722920();
  return;
}



/* FUNCTION 8411 ; VA 0x00698530 ; FUN_00698530 */

/* WARNING: Removing unreachable block (ram,0x00698651) */
/* WARNING: Removing unreachable block (ram,0x00698663) */
/* WARNING: Removing unreachable block (ram,0x00698658) */
/* WARNING: Removing unreachable block (ram,0x00698665) */
/* WARNING: Removing unreachable block (ram,0x0069866b) */
/* WARNING: Removing unreachable block (ram,0x00698675) */
/* WARNING: Removing unreachable block (ram,0x0069867f) */
/* WARNING: Removing unreachable block (ram,0x0069868f) */
/* WARNING: Removing unreachable block (ram,0x00698696) */
/* WARNING: Removing unreachable block (ram,0x006986a0) */
/* WARNING: Removing unreachable block (ram,0x006986aa) */
/* WARNING: Removing unreachable block (ram,0x006986ba) */
/* WARNING: Removing unreachable block (ram,0x006986c1) */
/* WARNING: Removing unreachable block (ram,0x006986d8) */
/* WARNING: Removing unreachable block (ram,0x00698645) */
/* WARNING: Removing unreachable block (ram,0x006986e8) */

void __fastcall FUN_00698530(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6018;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eae4ac != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01eae4ac,"RakNet: Clearing Requested Connection List");
  }
  uStack_8 = 0;
  FUN_00722910();
  while( true ) {
    uVar1 = *(uint *)(param_1 + 0x2f4);
    if (*(uint *)(param_1 + 0x2f8) < uVar1) {
      iVar2 = *(int *)(param_1 + 0x2fc) - uVar1;
    }
    else {
      iVar2 = -uVar1;
    }
    if (*(uint *)(param_1 + 0x2f8) + iVar2 == 0) break;
    iVar2 = *(int *)(param_1 + 0x2fc);
    iVar3 = uVar1 + 1;
    *(int *)(param_1 + 0x2f4) = iVar3;
    if (iVar3 == iVar2) {
      *(undefined4 *)(param_1 + 0x2f4) = 0;
      uStack_14 = *(undefined4 *)(*(int *)(param_1 + 0x2f0) + -4 + iVar2 * 4);
    }
    else if (iVar3 == 0) {
      uStack_14 = *(undefined4 *)(*(int *)(param_1 + 0x2f0) + -4 + iVar2 * 4);
    }
    else {
      uStack_14 = *(undefined4 *)(*(int *)(param_1 + 0x2f0) + -4 + iVar3 * 4);
    }
    FUN_005fe020(&uStack_14,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x118f);
  }
  FUN_00722920();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8412 ; VA 0x00698710 ; FUN_00698710 */

void __thiscall
FUN_00698710(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 *param_16)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  undefined2 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined auStack_48 [32];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uVar8 = param_14;
  piStack_8 = param_1;
  FUN_006988c0(&param_2,param_14,0,param_15,param_16);
  if ((char)uVar8 == '\0') {
    pcVar1 = *(code **)(*param_1 + 0x6c);
    FUN_005f70a0();
    FUN_005f7140();
    uVar8 = param_2;
    uVar9 = param_3;
    uVar4 = (undefined2)param_4;
    FUN_005f7170(&param_6);
    piVar2 = piStack_8;
    iVar5 = (*pcVar1)(uVar8,uVar9,uVar4);
    if (iVar5 == 2) {
      if (DAT_01ee420a != '\0') {
        FUN_016774b0(DAT_01ee420a,"Closing connection internally",0);
      }
      puVar6 = (undefined4 *)
               FUN_00697270(1,
                            "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                            ,0x70c);
      *(undefined *)puVar6[0xe] = 0x16;
      cVar3 = FUN_005f71b0(&DAT_01d5b1f0);
      if (cVar3 == '\0') {
        puVar7 = &param_2;
      }
      else {
        puVar7 = (undefined4 *)
                 (**(code **)(*piVar2 + 0xc0))
                           (param_6,param_7,param_8,param_9,param_10,param_11,param_12,param_13);
      }
      puVar6[8] = *puVar7;
      puVar6[9] = puVar7[1];
      *(undefined2 *)(puVar6 + 10) = *(undefined2 *)(puVar7 + 2);
      cVar3 = FUN_005f71d0(&DAT_01eae4bc);
      if (cVar3 == '\0') {
        puVar7 = &uStack_28;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
        uStack_18 = param_10;
        uStack_14 = param_11;
        uStack_10 = param_12;
        uStack_c = param_13;
      }
      else {
        puVar7 = (undefined4 *)
                 (**(code **)(*piVar2 + 0xc4))(auStack_48,param_2,param_3,param_4,param_5);
      }
      FUN_005f7170(puVar7);
      uVar4 = (**(code **)(*piVar2 + 0x70))
                        (*puVar6,puVar6[1],puVar6[2],puVar6[3],puVar6[4],puVar6[5],puVar6[6],
                         puVar6[7]);
      *(undefined2 *)((int)puVar6 + 0x1e) = uVar4;
      *(undefined2 *)(puVar6 + 10) = uVar4;
      *(undefined *)((int)puVar6 + 0x3d) = 1;
      param_16 = puVar6;
      FUN_00722910();
      FUN_005fe020(&param_16,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0x119f);
      FUN_00722920();
    }
  }
  return;
}



/* FUNCTION 8413 ; VA 0x006988c0 ; FUN_006988c0 */

void __thiscall
FUN_006988c0(int *param_1,undefined4 *param_2,char param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined auStack_44 [32];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_2 + 4;
  cVar2 = FUN_005f71b0(&DAT_01d5b1f0);
  if ((((cVar2 == '\0') || (cVar2 = FUN_005f71d0(&DAT_01eae4bc), cVar2 == '\0')) &&
      (param_1[0x8d] != 0)) && (*(char *)((int)param_1 + 5) == '\0')) {
    FUN_005f7140();
    cVar2 = FUN_005f7260(&DAT_01eae4bc);
    if (cVar2 == '\0') {
      puVar3 = (undefined4 *)
               (**(code **)(*param_1 + 0xc4))(auStack_44,*param_2,param_2[1],param_2[2],param_2[3]);
    }
    FUN_005f7170(puVar3);
    cVar2 = FUN_005f7260(&DAT_01eae4bc);
    if ((cVar2 != '\0') && ((char)param_4 != '\0')) {
      FUN_005f7320(*(int *)param_1[0x10e] + 8);
    }
    if (param_3 != '\0') {
      FUN_0069b580(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,uStack_8,
                   param_4,param_5,param_6,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0x103f);
      return;
    }
    if ((char)param_4 == '\0') {
      iVar4 = FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                           ,0x1062);
      *(undefined4 *)(iVar4 + 0x78) = 1;
      FUN_00696b70(&uStack_24);
      *(undefined4 *)(iVar4 + 0x5c) = 0;
      *(undefined *)(iVar4 + 0x14) = (undefined)param_5;
      *(undefined4 *)(iVar4 + 0xc) = param_6;
      FUN_0069cc60(iVar4);
    }
    else {
      iVar4 = FUN_0069a270(&uStack_24);
      if ((iVar4 != -1) && (iVar4 = iVar4 * 0xb70, *(char *)(iVar4 + param_1[0x8d]) != '\0')) {
        uVar5 = 0;
        if (param_1[0x8f] != 0) {
          do {
            cVar2 = FUN_005f71d0(&uStack_24);
            if (cVar2 != '\0') {
              *(undefined4 *)(param_1[0x8e] + uVar5 * 4) =
                   *(undefined4 *)(param_1[0x8e] + -4 + param_1[0x8f] * 4);
              param_1[0x8f] = param_1[0x8f] + -1;
              break;
            }
            uVar5 = uVar5 + 1;
          } while (uVar5 < (uint)param_1[0x8f]);
        }
        *(undefined *)(iVar4 + param_1[0x8d]) = 0;
        iVar1 = param_1[0x8d];
        *(undefined4 *)(iVar1 + 0xb30 + iVar4) = DAT_01d5b1f0;
        *(undefined4 *)(iVar1 + 0xb34 + iVar4) = DAT_01d5b1f4;
        *(undefined2 *)(iVar1 + 0xb38 + iVar4) = DAT_01d5b1f8;
        FUN_005fec80(0,*(undefined4 *)(iVar4 + 0xb40 + param_1[0x8d]),0);
        FUN_0058a2b0();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 8414 ; VA 0x00698af0 ; FUN_00698af0 */

undefined4 __thiscall
FUN_00698af0(int param_1,int param_2,undefined4 param_3,int param_4,uint param_5,undefined4 param_6,
            uint param_7,undefined4 param_8,undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  uint uVar2;
  
  if (((param_2 != 0) && (*(char *)(param_1 + 5) == '\0')) && (param_7 < *(uint *)(param_1 + 0x43c))
     ) {
    uVar1 = FUN_0069a070(param_7);
    uVar2 = 0xff;
    if ((int)param_5 < 0x100) {
      uVar2 = param_5;
    }
    if (DAT_01eae4ac != '\0') {
      FUN_01677520(DAT_01eae4ac,
                   "RakNet: Connect requested with attempt count %u , time between attempts %u",
                   param_8,param_9);
    }
    uVar1 = FUN_006a10d0(param_2,param_3,param_4,-(uint)(param_4 != 0) & uVar2,param_6,uVar1,0,
                         param_8,param_9,param_10);
    return uVar1;
  }
  return 1;
}



/* FUNCTION 8415 ; VA 0x00698b90 ; FUN_00698b90 */

void FUN_00698b90(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_1[2] != 0) && (iVar1 = *param_1, ExceptionList = &pvStack_10, iVar1 != 0)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),FUN_00550b30);
    FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
  }
  uStack_8 = 0xffffffff;
  FUN_00722910();
  FUN_0069dba0(param_1,param_2,param_3);
  FUN_00722920();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8416 ; VA 0x00698c30 ; FUN_00698c30 */

void __thiscall FUN_00698c30(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_2 != 0) {
    if (*(char *)(param_2 + 0x3c) != '\0') {
      FUN_01674ea0(*(undefined4 *)(param_2 + 0x38));
      FUN_00722910();
      piVar1 = *(int **)(param_2 + 0x40);
      if (piVar1[1] != 0) {
        ((int *)*piVar1)[piVar1[1]] = param_2;
        piVar1[1] = piVar1[1] + 1;
        if ((piVar1[1] == *(uint *)(param_1 + 0x63c) / 0x48) && (3 < *(int *)(param_1 + 0x634))) {
          if (piVar1 == *(int **)(param_1 + 0x62c)) {
            *(int *)(param_1 + 0x62c) = piVar1[3];
          }
          *(int *)(piVar1[4] + 0xc) = piVar1[3];
          *(int *)(piVar1[3] + 0x10) = piVar1[4];
          *(int *)(param_1 + 0x634) = *(int *)(param_1 + 0x634) + -1;
          FUN_01674ea0(*piVar1);
          FUN_01674ea0(piVar1[2]);
          FUN_01674ea0(piVar1);
        }
        FUN_00722920();
        return;
      }
      *(int *)*piVar1 = param_2;
      piVar1[1] = piVar1[1] + 1;
      *(int *)(param_1 + 0x638) = *(int *)(param_1 + 0x638) + -1;
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      if ((0 < *(int *)(param_1 + 0x638)) && (piVar1 == *(int **)(param_1 + 0x630))) {
        *(int *)(param_1 + 0x630) = (*(int **)(param_1 + 0x630))[3];
      }
      iVar2 = *(int *)(param_1 + 0x634);
      *(int *)(param_1 + 0x634) = iVar2 + 1;
      if (iVar2 == 0) {
        *(int **)(param_1 + 0x62c) = piVar1;
        piVar1[3] = (int)piVar1;
        piVar1[4] = (int)piVar1;
        FUN_00722920();
        return;
      }
      piVar1[3] = *(int *)(param_1 + 0x62c);
      piVar1[4] = *(int *)(*(int *)(param_1 + 0x62c) + 0x10);
      *(int **)(*(int *)(*(int *)(param_1 + 0x62c) + 0x10) + 0xc) = piVar1;
      *(int **)(*(int *)(param_1 + 0x62c) + 0x10) = piVar1;
      FUN_00722920();
      return;
    }
    FUN_01674ea0(param_2);
  }
  return;
}



/* FUNCTION 8417 ; VA 0x00698da0 ; FUN_00698da0 */

void * __fastcall FUN_00698da0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void **ppvVar4;
  void *pvVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar6 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  ppvVar4 = &pvStack_10;
  if (*(int *)(param_1 + 0x43c) != 0) {
    do {
      ExceptionList = ppvVar4;
      pvVar5 = *(void **)(param_1 + 0x438);
      *(undefined4 *)((int)pvVar5 + uVar6 * 8) = 0;
      piVar3 = *(int **)((int)pvVar5 + uVar6 * 8 + 4);
      *(undefined4 *)((int)pvVar5 + uVar6 * 8 + 4) = 0;
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar2 = *piVar1;
        pvVar5 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          pvVar5 = (void *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            pvVar5 = (void *)(**(code **)(*piVar3 + 4))();
          }
        }
      }
      uVar6 = uVar6 + 1;
      ppvVar4 = (void **)ExceptionList;
    } while (uVar6 < *(uint *)(param_1 + 0x43c));
  }
  if (*(int *)(param_1 + 0x440) != 0) {
    pvVar5 = *(void **)(param_1 + 0x438);
    if (pvVar5 != (void *)0x0) {
      uStack_8 = 0;
      FUN_016f32d1(pvVar5,8,*(undefined4 *)((int)pvVar5 + -4),FUN_00550b30);
      pvVar5 = (void *)FUN_01674ea0((int *)((int)pvVar5 + -4),*(int *)((int)pvVar5 + -4) * 8 + 4);
    }
    *(undefined4 *)(param_1 + 0x440) = 0;
    *(undefined4 *)(param_1 + 0x438) = 0;
    *(undefined4 *)(param_1 + 0x43c) = 0;
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 8418 ; VA 0x00698e90 ; FUN_00698e90 */

int __thiscall FUN_00698e90(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iStack_8;
  
  uVar4 = FUN_005f7a90(param_2);
  iVar5 = *(int *)(param_1 + 0x244);
  iVar1 = (int)((ulonglong)uVar4 % ((ulonglong)*(ushort *)(param_1 + 0xe) << 3)) * 4;
  iVar2 = *(int *)(iVar1 + iVar5);
  iStack_8 = 0;
  if (iVar2 != 0) {
    while( true ) {
      iVar6 = iVar2;
      iVar5 = FUN_005f71d0(param_2);
      if ((char)iVar5 != '\0') break;
      iVar2 = *(int *)(iVar6 + 4);
      iStack_8 = iVar6;
      if (*(int *)(iVar6 + 4) == 0) {
        return iVar5;
      }
    }
    if (iStack_8 == 0) {
      *(undefined4 *)(iVar1 + *(int *)(param_1 + 0x244)) = *(undefined4 *)(iVar6 + 4);
    }
    else {
      *(undefined4 *)(iStack_8 + 4) = *(undefined4 *)(iVar6 + 4);
    }
    piVar3 = *(int **)(iVar6 + 8);
    if (piVar3[1] == 0) {
      *(int *)*piVar3 = iVar6;
      piVar3[1] = piVar3[1] + 1;
      *(int *)(param_1 + 0x254) = *(int *)(param_1 + 0x254) + -1;
      *(int *)(piVar3[3] + 0x10) = piVar3[4];
      *(int *)(piVar3[4] + 0xc) = piVar3[3];
      if ((0 < *(int *)(param_1 + 0x254)) && (piVar3 == *(int **)(param_1 + 0x24c))) {
        *(int *)(param_1 + 0x24c) = (*(int **)(param_1 + 0x24c))[3];
      }
      iVar5 = *(int *)(param_1 + 0x250);
      iVar1 = iVar5 + 1;
      *(int *)(param_1 + 0x250) = iVar1;
      if (iVar5 == 0) {
        *(int **)(param_1 + 0x248) = piVar3;
        piVar3[3] = (int)piVar3;
        piVar3[4] = (int)piVar3;
        return iVar1;
      }
      piVar3[3] = *(int *)(param_1 + 0x248);
      piVar3[4] = *(int *)(*(int *)(param_1 + 0x248) + 0x10);
      *(int **)(*(int *)(*(int *)(param_1 + 0x248) + 0x10) + 0xc) = piVar3;
      iVar1 = *(int *)(param_1 + 0x248);
      *(int **)(iVar1 + 0x10) = piVar3;
      return iVar1;
    }
    ((int *)*piVar3)[piVar3[1]] = iVar6;
    piVar3[1] = piVar3[1] + 1;
    iVar5 = *(uint *)(param_1 + 600) * -0x55555555;
    if ((piVar3[1] == *(uint *)(param_1 + 600) / 0xc) && (3 < *(int *)(param_1 + 0x250))) {
      if (piVar3 == *(int **)(param_1 + 0x248)) {
        *(int *)(param_1 + 0x248) = piVar3[3];
      }
      *(int *)(piVar3[4] + 0xc) = piVar3[3];
      *(int *)(piVar3[3] + 0x10) = piVar3[4];
      *(int *)(param_1 + 0x250) = *(int *)(param_1 + 0x250) + -1;
      FUN_01674ea0(*piVar3);
      FUN_01674ea0(piVar3[2]);
      iVar5 = FUN_01674ea0(piVar3);
    }
  }
  return iVar5;
}



/* FUNCTION 8419 ; VA 0x00699030 ; FUN_00699030 */

void __thiscall FUN_00699030(int param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  uint uVar3;
  char *pcVar4;
  
  if (param_2 != (int *)0x0) {
    cVar1 = (**(code **)(*param_2 + 0x44))();
    if ((DAT_01d5b280 == '\0') && (cVar1 == '\0')) {
      uVar3 = 0;
      if (*(uint *)(param_1 + 0x2dc) != 0) {
        puVar2 = *(undefined4 **)(param_1 + 0x2d8);
        do {
          if ((int *)*puVar2 == param_2) {
            if (uVar3 != 0xffffffff) {
              *(undefined4 *)(*(int *)(param_1 + 0x2d8) + uVar3 * 4) =
                   *(undefined4 *)(*(int *)(param_1 + 0x2d8) + -4 + *(int *)(param_1 + 0x2dc) * 4);
              *(int *)(param_1 + 0x2dc) = *(int *)(param_1 + 0x2dc) + -1;
              if (DAT_01eadf38 != '\0') {
                pcVar4 = "RakPeer found plugin and removed it (thread safe)";
LAB_00699103:
                FUN_016774b0(DAT_01eadf38,pcVar4,0);
              }
            }
            break;
          }
          uVar3 = uVar3 + 1;
          puVar2 = puVar2 + 1;
        } while (uVar3 < *(uint *)(param_1 + 0x2dc));
      }
    }
    else {
      uVar3 = 0;
      if (*(uint *)(param_1 + 0x2e8) != 0) {
        puVar2 = *(undefined4 **)(param_1 + 0x2e4);
        do {
          if ((int *)*puVar2 == param_2) {
            if (uVar3 != 0xffffffff) {
              *(undefined4 *)(*(int *)(param_1 + 0x2e4) + uVar3 * 4) =
                   *(undefined4 *)(*(int *)(param_1 + 0x2e4) + -4 + *(int *)(param_1 + 0x2e8) * 4);
              *(int *)(param_1 + 0x2e8) = *(int *)(param_1 + 0x2e8) + -1;
              if (DAT_01eadf38 != '\0') {
                pcVar4 = "RakPeer found plugin and removed it (not thread safe)";
                goto LAB_00699103;
              }
            }
            break;
          }
          uVar3 = uVar3 + 1;
          puVar2 = puVar2 + 1;
        } while (uVar3 < *(uint *)(param_1 + 0x2e8));
      }
    }
    (**(code **)(*param_2 + 8))();
    FUN_00598640(0);
  }
  return;
}



/* FUNCTION 8420 ; VA 0x00699130 ; FUN_00699130 */

int FUN_00699130(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  int iVar2;
  ushort *puVar3;
  int iVar4;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar1 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,0);
  }
  else {
    iVar2 = FUN_0069a100(param_1,param_2,param_3,uStack_28,0);
  }
  if (iVar2 != 0) {
    iVar4 = 0;
    puVar3 = (ushort *)(iVar2 + 0xac0);
    iVar2 = 0;
    do {
      if (*puVar3 == 0xffff) break;
      iVar2 = iVar2 + 1;
      iVar4 = iVar4 + (uint)*puVar3;
      puVar3 = puVar3 + 8;
    } while (iVar2 < 5);
    if (0 < iVar2) {
      return iVar4 / iVar2;
    }
  }
  return -1;
}



/* FUNCTION 8421 ; VA 0x006991f0 ; FUN_006991f0 */

undefined4 __thiscall
FUN_006991f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  int iVar1;
  
  iVar1 = FUN_0069a190(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0,0);
  if ((iVar1 != 0) && (*(char *)(param_1 + 5) == '\0')) {
    FUN_005fb190(param_10);
    return 1;
  }
  return 0;
}



/* FUNCTION 8422 ; VA 0x00699240 ; FUN_00699240 */

undefined FUN_00699240(void)

{
  return 0;
}



/* FUNCTION 8423 ; VA 0x00699250 ; FUN_00699250 */

undefined4 __thiscall FUN_00699250(int *param_1,int param_2,ushort *param_3)

{
  ushort uVar1;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6040;
  pvStack_10 = ExceptionList;
  if (param_3 != (ushort *)0x0) {
    if ((param_1[0x8d] != 0) && (*(char *)((int)param_1 + 5) == '\0')) {
      iStack_14 = 0;
      iStack_1c = 0;
      uStack_18 = 0;
      iStack_20 = 0;
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_8 = 1;
      ExceptionList = &pvStack_10;
      (**(code **)(*param_1 + 0x7c))(&iStack_1c,&uStack_28);
      if (param_2 == 0) {
        *param_3 = (ushort)uStack_18;
      }
      else {
        uVar1 = 0;
        if (*param_3 != 0) {
          do {
            if (uStack_18 <= uVar1) break;
            FUN_005f7170(iStack_1c + (uint)uVar1 * 0x20);
            uVar1 = uVar1 + 1;
          } while (uVar1 < *param_3);
        }
        *param_3 = uVar1;
      }
      if (iStack_20 != 0) {
        FUN_01674ea0(uStack_28);
      }
      if (iStack_14 != 0) {
        FUN_01674ea0(iStack_1c);
      }
      ExceptionList = pvStack_10;
      return 1;
    }
    *param_3 = 0;
  }
  return 0;
}



/* FUNCTION 8424 ; VA 0x00699360 ; FUN_00699360 */

undefined4 __thiscall
FUN_00699360(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13)

{
  uint uVar1;
  char cVar2;
  ushort uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  cVar2 = FUN_005f7260(&DAT_01eae4bc);
  if (cVar2 != '\0') {
    iStack_8 = param_1 + 0x300;
    uVar5 = 0;
    FUN_00722910();
    while( true ) {
      uVar1 = *(uint *)(param_1 + 0x2f4);
      if (*(uint *)(param_1 + 0x2f8) < uVar1) {
        iVar4 = *(int *)(param_1 + 0x2fc) - uVar1;
      }
      else {
        iVar4 = -uVar1;
      }
      if (*(uint *)(param_1 + 0x2f8) + iVar4 <= uVar5) break;
      cVar2 = FUN_005f71d0(&param_6);
      if (cVar2 != '\0') {
        FUN_00722920();
        return 0;
      }
      uVar5 = uVar5 + 1;
    }
    FUN_00722920();
  }
  cVar2 = FUN_005f7260(&DAT_01eae4bc);
  if (cVar2 == '\0') {
    uStack_18 = param_2;
    uStack_14 = param_3;
    uStack_10 = param_4;
    uStack_c = param_5;
    cVar2 = FUN_005f71b0(&DAT_01d5b1f0);
    if (cVar2 != '\0') {
      return 6;
    }
    if (((((ushort)uStack_10 == 0xffff) || (*(ushort *)(param_1 + 0xe) <= (ushort)uStack_10)) ||
        (cVar2 = FUN_005f71b0(&uStack_18), cVar2 == '\0')) ||
       (uVar5 = uStack_10 & 0xffff, *(char *)(uVar5 * 0xb70 + *(int *)(param_1 + 0x234)) == '\0')) {
      uVar3 = *(ushort *)(param_1 + 0xe);
      uVar5 = 0;
      if (uVar3 != 0) {
        iVar4 = 0;
        do {
          if ((*(char *)(*(int *)(param_1 + 0x234) + iVar4) != '\0') &&
             (cVar2 = FUN_005f71b0(&uStack_18), cVar2 != '\0')) goto LAB_00699430;
          uVar3 = *(ushort *)(param_1 + 0xe);
          uVar5 = uVar5 + 1;
          iVar4 = iVar4 + 0xb70;
        } while (uVar5 < uVar3);
      }
      uVar5 = 0;
      if (uVar3 == 0) {
        return 6;
      }
      while (cVar2 = FUN_005f71b0(&uStack_18), cVar2 == '\0') {
        uVar5 = uVar5 + 1;
        if (*(ushort *)(param_1 + 0xe) <= uVar5) {
          return 6;
        }
      }
    }
  }
  else {
    uVar5 = FUN_00699980(param_6,param_7,param_8,param_9,param_10,param_11,param_12,param_13,0);
  }
LAB_00699430:
  if (uVar5 != 0xffffffff) {
    if (*(char *)(*(int *)(param_1 + 0x234) + uVar5 * 0xb70) == '\0') {
      return 5;
    }
    switch(*(undefined4 *)(*(int *)(param_1 + 0x234) + 0xb68 + uVar5 * 0xb70)) {
    case 1:
    case 3:
      return 3;
    case 2:
      return 4;
    case 4:
    case 5:
    case 6:
      return 1;
    case 7:
      return 2;
    }
  }
  return 6;
}



/* FUNCTION 8425 ; VA 0x006995d0 ; FUN_006995d0 */

undefined4 __fastcall FUN_006995d0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x14);
}



/* FUNCTION 8426 ; VA 0x006995e0 ; FUN_006995e0 */

undefined4 __thiscall FUN_006995e0(int param_1,undefined4 param_2,undefined4 *param_3,char param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  uVar7 = 0;
  if (*(int *)(param_1 + 0x23c) != 0) {
    do {
      cVar5 = FUN_005f71d0(param_2);
      if (cVar5 != '\0') {
        iVar1 = *(int *)(*(int *)(param_1 + 0x238) + uVar7 * 4);
        uVar2 = *(undefined4 *)(iVar1 + 0x354);
        uVar3 = *(undefined4 *)(iVar1 + 0x358);
        uVar4 = *(undefined4 *)(iVar1 + 0x35c);
        *param_3 = *(undefined4 *)(iVar1 + 0x350);
        param_3[1] = uVar2;
        param_3[2] = uVar3;
        param_3[3] = uVar4;
        uVar2 = *(undefined4 *)(iVar1 + 0x364);
        uVar3 = *(undefined4 *)(iVar1 + 0x368);
        uVar4 = *(undefined4 *)(iVar1 + 0x36c);
        param_3[4] = *(undefined4 *)(iVar1 + 0x360);
        param_3[5] = uVar2;
        param_3[6] = uVar3;
        param_3[7] = uVar4;
        uVar2 = *(undefined4 *)(iVar1 + 0x374);
        uVar3 = *(undefined4 *)(iVar1 + 0x378);
        uVar4 = *(undefined4 *)(iVar1 + 0x37c);
        param_3[8] = *(undefined4 *)(iVar1 + 0x370);
        param_3[9] = uVar2;
        param_3[10] = uVar3;
        param_3[0xb] = uVar4;
        uVar2 = *(undefined4 *)(iVar1 + 900);
        uVar3 = *(undefined4 *)(iVar1 + 0x388);
        uVar4 = *(undefined4 *)(iVar1 + 0x38c);
        param_3[0xc] = *(undefined4 *)(iVar1 + 0x380);
        param_3[0xd] = uVar2;
        param_3[0xe] = uVar3;
        param_3[0xf] = uVar4;
        uVar2 = *(undefined4 *)(iVar1 + 0x394);
        uVar3 = *(undefined4 *)(iVar1 + 0x398);
        uVar4 = *(undefined4 *)(iVar1 + 0x39c);
        param_3[0x10] = *(undefined4 *)(iVar1 + 0x390);
        param_3[0x11] = uVar2;
        param_3[0x12] = uVar3;
        param_3[0x13] = uVar4;
        *(undefined8 *)(param_3 + 0x14) = *(undefined8 *)(iVar1 + 0x3a0);
        return 1;
      }
      uVar7 = uVar7 + 1;
    } while (uVar7 < *(uint *)(param_1 + 0x23c));
  }
  if (((param_4 != '\0') && (*(int *)(param_1 + 0x234) != 0)) &&
     (uVar7 = 0, *(short *)(param_1 + 0xe) != 0)) {
    do {
      cVar5 = FUN_005f71d0(param_2);
      if (cVar5 != '\0') {
        puVar6 = (undefined4 *)(uVar7 * 0xb70 + *(int *)(param_1 + 0x234) + 0x350);
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        *param_3 = *puVar6;
        param_3[1] = uVar2;
        param_3[2] = uVar3;
        param_3[3] = uVar4;
        uVar2 = puVar6[5];
        uVar3 = puVar6[6];
        uVar4 = puVar6[7];
        param_3[4] = puVar6[4];
        param_3[5] = uVar2;
        param_3[6] = uVar3;
        param_3[7] = uVar4;
        uVar2 = puVar6[9];
        uVar3 = puVar6[10];
        uVar4 = puVar6[0xb];
        param_3[8] = puVar6[8];
        param_3[9] = uVar2;
        param_3[10] = uVar3;
        param_3[0xb] = uVar4;
        uVar2 = puVar6[0xd];
        uVar3 = puVar6[0xe];
        uVar4 = puVar6[0xf];
        param_3[0xc] = puVar6[0xc];
        param_3[0xd] = uVar2;
        param_3[0xe] = uVar3;
        param_3[0xf] = uVar4;
        uVar2 = puVar6[0x11];
        uVar3 = puVar6[0x12];
        uVar4 = puVar6[0x13];
        param_3[0x10] = puVar6[0x10];
        param_3[0x11] = uVar2;
        param_3[0x12] = uVar3;
        param_3[0x13] = uVar4;
        *(undefined8 *)(param_3 + 0x14) = *(undefined8 *)(puVar6 + 0x14);
        return 1;
      }
      uVar7 = uVar7 + 1;
    } while (uVar7 < *(ushort *)(param_1 + 0xe));
  }
  return 0;
}



/* FUNCTION 8427 ; VA 0x00699700 ; FUN_00699700 */

void __thiscall FUN_00699700(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f7140();
  FUN_005f7170(&DAT_01eae4bc);
  cVar6 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar6 != '\0') {
    uVar3 = *(undefined4 *)(param_1 + 0x490);
    uVar4 = *(undefined4 *)(param_1 + 0x494);
    uVar5 = *(undefined4 *)(param_1 + 0x498);
    *param_2 = *(undefined4 *)(param_1 + 0x48c);
    param_2[1] = uVar3;
    param_2[2] = uVar4;
    param_2[3] = uVar5;
    uVar3 = *(undefined4 *)(param_1 + 0x4a0);
    uVar4 = *(undefined4 *)(param_1 + 0x4a4);
    uVar5 = *(undefined4 *)(param_1 + 0x4a8);
    param_2[4] = *(undefined4 *)(param_1 + 0x49c);
    param_2[5] = uVar3;
    param_2[6] = uVar4;
    param_2[7] = uVar5;
    return;
  }
  uVar7 = 0;
  if (*(short *)(param_1 + 0xe) != 0) {
    iVar8 = 0;
    do {
      cVar6 = FUN_005f71d0(&stack0x00000008);
      if (cVar6 != '\0') {
        iVar2 = *(int *)(param_1 + 0x234);
        if (*(char *)(iVar8 + iVar2) != '\0') {
          puVar1 = (undefined4 *)(iVar8 + 0x24 + iVar2);
          uVar3 = puVar1[1];
          uVar4 = puVar1[2];
          uVar5 = puVar1[3];
          *param_2 = *puVar1;
          param_2[1] = uVar3;
          param_2[2] = uVar4;
          param_2[3] = uVar5;
          puVar1 = (undefined4 *)(iVar8 + 0x34 + iVar2);
          uVar3 = puVar1[1];
          uVar4 = puVar1[2];
          uVar5 = puVar1[3];
          param_2[4] = *puVar1;
          param_2[5] = uVar3;
          param_2[6] = uVar4;
          param_2[7] = uVar5;
          return;
        }
        cVar6 = FUN_005f7260(&DAT_01eae4bc);
        if (cVar6 != '\0') {
          FUN_005f7170(*(int *)(param_1 + 0x234) + 0x24 + iVar8);
        }
      }
      uVar7 = uVar7 + 1;
      iVar8 = iVar8 + 0xb70;
    } while (uVar7 < *(ushort *)(param_1 + 0xe));
  }
  *param_2 = uStack_24;
  param_2[1] = uStack_20;
  param_2[2] = uStack_1c;
  param_2[3] = uStack_18;
  param_2[4] = uStack_14;
  param_2[5] = uStack_10;
  param_2[6] = uStack_c;
  param_2[7] = uStack_8;
  return;
}



/* FUNCTION 8428 ; VA 0x00699800 ; FUN_00699800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00699800(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  uVar5 = uRam01d5b1fc;
  uVar4 = _DAT_01d5b1f8;
  uVar3 = DAT_01d5b1f4;
  if ((-1 < param_3) && (param_3 < (int)(uint)*(ushort *)(param_1 + 0xe))) {
    iVar2 = *(int *)(param_1 + 0x234);
    param_3 = param_3 * 0xb70;
    if ((*(char *)(param_3 + iVar2) != '\0') && (*(int *)(param_3 + 0xb68 + iVar2) == 7)) {
      puVar1 = (undefined4 *)(param_3 + 0xb30 + iVar2);
      uVar3 = puVar1[1];
      uVar4 = puVar1[2];
      uVar5 = puVar1[3];
      *param_2 = *puVar1;
      param_2[1] = uVar3;
      param_2[2] = uVar4;
      param_2[3] = uVar5;
      return;
    }
  }
  *param_2 = DAT_01d5b1f0;
  param_2[1] = uVar3;
  param_2[2] = uVar4;
  param_2[3] = uVar5;
  return;
}



/* FUNCTION 8429 ; VA 0x00699860 ; FUN_00699860 */

undefined4 * __thiscall FUN_00699860(int param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 in_stack_00000020;
  
  cVar1 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar1 != '\0') {
    return (undefined4 *)(param_1 + 0x470);
  }
  if (((in_stack_00000020._2_2_ != 0xffff) && (in_stack_00000020._2_2_ < *(ushort *)(param_1 + 0xe))
      ) && (cVar1 = FUN_005f71d0(&stack0x00000004), cVar1 != '\0')) {
    return (undefined4 *)(*(int *)(param_1 + 0x234) + (uint)in_stack_00000020._2_2_ * 0xb70 + 0xb30)
    ;
  }
  uVar2 = 0;
  if (*(short *)(param_1 + 0xe) != 0) {
    do {
      cVar1 = FUN_005f71d0(&stack0x00000004);
      if (cVar1 != '\0') {
        return (undefined4 *)(*(int *)(param_1 + 0x234) + 0xb30 + uVar2 * 0xb70);
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < *(ushort *)(param_1 + 0xe));
  }
  return &DAT_01d5b1f0;
}



/* FUNCTION 8430 ; VA 0x00699930 ; FUN_00699930 */

void __thiscall FUN_00699930(int param_1,int param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  
  uVar2 = (uint)*(byte *)(param_1 + 0x230);
  if (param_2 == 0) {
    *param_3 = uVar2;
    return;
  }
  uVar1 = *param_3;
  if ((int)uVar2 < (int)*param_3) {
    *param_3 = uVar2;
    uVar1 = uVar2;
  }
  if (0 < (int)uVar1) {
    FUN_0170c6f0(param_2,param_1 + 0x130,uVar1);
  }
  return;
}



/* FUNCTION 8431 ; VA 0x00699980 ; FUN_00699980 */

uint __thiscall FUN_00699980(int param_1)

{
  char cVar1;
  uint uVar2;
  ushort uVar3;
  int iVar4;
  undefined4 in_stack_00000020;
  char in_stack_00000024;
  
  cVar1 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar1 == '\0') {
    if ((((in_stack_00000020._2_2_ != 0xffff) &&
         (in_stack_00000020._2_2_ < *(ushort *)(param_1 + 0xe))) &&
        (cVar1 = FUN_005f71d0(&stack0x00000004), cVar1 != '\0')) &&
       (*(char *)((uint)in_stack_00000020._2_2_ * 0xb70 + *(int *)(param_1 + 0x234)) != '\0')) {
      return (uint)in_stack_00000020._2_2_;
    }
    if (in_stack_00000024 != '\0') {
      uVar2 = FUN_0069a270(&stack0x00000004);
      return uVar2;
    }
    uVar3 = *(ushort *)(param_1 + 0xe);
    uVar2 = 0;
    if (uVar3 != 0) {
      iVar4 = 0;
      do {
        if ((*(char *)(iVar4 + *(int *)(param_1 + 0x234)) != '\0') &&
           (cVar1 = FUN_005f71d0(&stack0x00000004), cVar1 != '\0')) {
          return uVar2;
        }
        uVar3 = *(ushort *)(param_1 + 0xe);
        uVar2 = uVar2 + 1;
        iVar4 = iVar4 + 0xb70;
      } while (uVar2 < uVar3);
    }
    uVar2 = 0;
    if (uVar3 != 0) {
      do {
        cVar1 = FUN_005f71d0(&stack0x00000004);
        if (cVar1 != '\0') {
          return uVar2;
        }
        uVar2 = uVar2 + 1;
      } while (uVar2 < *(ushort *)(param_1 + 0xe));
    }
  }
  return 0xffffffff;
}



/* FUNCTION 8432 ; VA 0x00699aa0 ; FUN_00699aa0 */

void FUN_00699aa0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  FUN_00699980(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,0);
  return;
}



/* FUNCTION 8433 ; VA 0x00699ad0 ; FUN_00699ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00699ad0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,int param_11)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  
  cVar5 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar5 != '\0') {
    iVar6 = (param_11 + 0x26) * 0x20;
    puVar1 = (undefined4 *)(iVar6 + param_1);
    uVar2 = puVar1[1];
    uVar3 = puVar1[2];
    uVar4 = puVar1[3];
    *param_2 = *puVar1;
    param_2[1] = uVar2;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    puVar1 = (undefined4 *)(iVar6 + 0x10 + param_1);
    uVar2 = puVar1[1];
    uVar3 = puVar1[2];
    uVar4 = puVar1[3];
    param_2[4] = *puVar1;
    param_2[5] = uVar2;
    param_2[6] = uVar3;
    param_2[7] = uVar4;
    return;
  }
  iVar6 = FUN_0069a190(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,0,1);
  uVar4 = uRam01eae4c8;
  uVar3 = uRam01eae4c4;
  uVar2 = uRam01eae4c0;
  if (iVar6 == 0) {
    *param_2 = _DAT_01eae4bc;
    param_2[1] = uVar2;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    uVar4 = uRam01eae4d8;
    uVar3 = uRam01eae4d4;
    uVar2 = uRam01eae4d0;
    param_2[4] = _DAT_01eae4cc;
    param_2[5] = uVar2;
    param_2[6] = uVar3;
    param_2[7] = uVar4;
    return;
  }
  iVar6 = iVar6 + param_11 * 0x20;
  uVar2 = *(undefined4 *)(iVar6 + 0x48);
  uVar3 = *(undefined4 *)(iVar6 + 0x4c);
  uVar4 = *(undefined4 *)(iVar6 + 0x50);
  *param_2 = *(undefined4 *)(iVar6 + 0x44);
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  uVar2 = *(undefined4 *)(iVar6 + 0x58);
  uVar3 = *(undefined4 *)(iVar6 + 0x5c);
  uVar4 = *(undefined4 *)(iVar6 + 0x60);
  param_2[4] = *(undefined4 *)(iVar6 + 0x54);
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  param_2[7] = uVar4;
  return;
}



/* FUNCTION 8434 ; VA 0x00699b70 ; FUN_00699b70 */

void FUN_00699b70(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  undefined4 *in_stack_00000034;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar4 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar4 == '\0') {
    iVar5 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,0);
  }
  else {
    iVar5 = FUN_0069a100(param_1,param_2,param_3,uStack_28,0);
  }
  if (iVar5 != 0) {
    uVar1 = *(undefined4 *)(iVar5 + 0x41c);
    uVar2 = *(undefined4 *)(iVar5 + 0x420);
    uVar3 = *(undefined4 *)(iVar5 + 0x424);
    *in_stack_00000034 = *(undefined4 *)(iVar5 + 0x418);
    in_stack_00000034[1] = uVar1;
    in_stack_00000034[2] = uVar2;
    in_stack_00000034[3] = uVar3;
  }
  return;
}



/* FUNCTION 8435 ; VA 0x00699c10 ; FUN_00699c10 */

uint FUN_00699c10(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar1 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,0);
  }
  else {
    iVar2 = FUN_0069a100(param_1,param_2,param_3,uStack_28,0);
  }
  if (iVar2 == 0) {
    return 0xffffffff;
  }
  if (*(int *)(iVar2 + 0xb10) == 0 && *(int *)(iVar2 + 0xb14) == 0) {
    return (uint)*(ushort *)(iVar2 + 0xb00);
  }
  return (uint)*(ushort *)(iVar2 + (*(int *)(iVar2 + 0xb10) + 0xab) * 0x10);
}



/* FUNCTION 8436 ; VA 0x00699cd0 ; FUN_00699cd0 */

undefined * __fastcall FUN_00699cd0(int *param_1)

{
  char cVar1;
  
  cVar1 = (**(code **)(*param_1 + 0x38))();
  if (cVar1 == '\0') {
    thunk_FUN_00694bc0(param_1 + 0x130);
  }
  FUN_005f7b20(0,&DAT_01eae560,0x401,0x7c);
  return &DAT_01eae560;
}



/* FUNCTION 8437 ; VA 0x00699d20 ; FUN_00699d20 */

uint FUN_00699d20(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar1 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,0);
  }
  else {
    iVar2 = FUN_0069a100(param_1,param_2,param_3,uStack_28,0);
  }
  if (iVar2 == 0) {
    return 0xffffffff;
  }
  return (uint)*(ushort *)(iVar2 + 2);
}



/* FUNCTION 8438 ; VA 0x00699dc0 ; FUN_00699dc0 */

undefined4 __thiscall
FUN_00699dc0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_005f7260(&DAT_01eae4bc);
  if (cVar1 != '\0') {
    iVar2 = FUN_0069a190(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0,1);
    if (iVar2 != 0) {
      return *(undefined4 *)(iVar2 + 0xb40);
    }
  }
  return *(undefined4 *)(param_1 + 0x42c);
}



/* FUNCTION 8439 ; VA 0x00699e10 ; FUN_00699e10 */

undefined2 __fastcall FUN_00699e10(int param_1)

{
  return *(undefined2 *)(param_1 + 0x10);
}



/* FUNCTION 8440 ; VA 0x00699e20 ; FUN_00699e20 */

undefined2 __fastcall FUN_00699e20(int param_1)

{
  return *(undefined2 *)(param_1 + 0xe);
}



/* FUNCTION 8441 ; VA 0x00699e30 ; FUN_00699e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00699e30(int *param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6058;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  iStack_1c = 0;
  iStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x114))(&iStack_1c);
  uVar3 = uRam01eae4c8;
  uVar2 = uRam01eae4c4;
  uVar5 = uRam01eae4c0;
  if (iStack_18 == 0) {
    *param_2 = _DAT_01eae4bc;
    param_2[1] = uVar5;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    uVar3 = uRam01eae4d8;
    uVar2 = uRam01eae4d4;
    uVar5 = uRam01eae4d0;
    param_2[4] = _DAT_01eae4cc;
    param_2[5] = uVar5;
    param_2[6] = uVar2;
    param_2[7] = uVar3;
    if (iStack_14 == 0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (iStack_1c == 0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar5 = *(undefined4 *)(iStack_1c + -4);
    uStack_8 = 2;
  }
  else {
    iVar1 = *(int *)(iStack_1c + param_3 * 8);
    uVar5 = *(undefined4 *)(iVar1 + 0xc);
    uVar2 = *(undefined4 *)(iVar1 + 0x10);
    uVar3 = *(undefined4 *)(iVar1 + 0x14);
    *param_2 = *(undefined4 *)(iVar1 + 8);
    param_2[1] = uVar5;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    uVar5 = *(undefined4 *)(iVar1 + 0x1c);
    uVar2 = *(undefined4 *)(iVar1 + 0x20);
    uVar3 = *(undefined4 *)(iVar1 + 0x24);
    param_2[4] = *(undefined4 *)(iVar1 + 0x18);
    param_2[5] = uVar5;
    param_2[6] = uVar2;
    param_2[7] = uVar3;
    if (iStack_14 == 0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (iStack_1c == 0) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar5 = *(undefined4 *)(iStack_1c + -4);
    uStack_8 = 1;
  }
  piVar4 = (int *)(iStack_1c + -4);
  FUN_016f32d1(iStack_1c,8,uVar5,FUN_00550b30);
  FUN_01674ea0(piVar4,*piVar4 * 8 + 4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8442 ; VA 0x00699f30 ; FUN_00699f30 */

void __thiscall FUN_00699f30(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x474);
  uVar2 = *(undefined4 *)(param_1 + 0x478);
  uVar3 = *(undefined4 *)(param_1 + 0x47c);
  *param_2 = *(undefined4 *)(param_1 + 0x470);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  return;
}



/* FUNCTION 8443 ; VA 0x00699f50 ; FUN_00699f50 */

undefined4 __fastcall FUN_00699f50(int param_1)

{
  undefined4 uVar1;
  
  FUN_00722910();
  uVar1 = *(undefined4 *)(param_1 + 0x6a8);
  FUN_00722920();
  return uVar1;
}



/* FUNCTION 8444 ; VA 0x00699f80 ; FUN_00699f80 */

int FUN_00699f80(void)

{
  char cVar1;
  int iVar2;
  
  iVar2 = 0;
  cVar1 = FUN_005f7260(&DAT_01eae4bc);
  while (cVar1 != '\0') {
    iVar2 = iVar2 + 1;
    cVar1 = FUN_005f7260(&DAT_01eae4bc);
  }
  return iVar2;
}



/* FUNCTION 8445 ; VA 0x00699fc0 ; FUN_00699fc0 */

uint __fastcall FUN_00699fc0(int param_1)

{
  return *(int *)(param_1 + 8) + 7U >> 3;
}



/* FUNCTION 8446 ; VA 0x00699fd0 ; FUN_00699fd0 */

void __thiscall FUN_00699fd0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  FUN_00722910();
  uVar1 = (**(code **)(*(int *)(param_1 + 0x14) + 4))();
  *param_2 = uVar1;
  uVar1 = (**(code **)(*(int *)(param_1 + 0x14) + 8))();
  *param_3 = uVar1;
  FUN_00722920();
  return;
}



/* FUNCTION 8447 ; VA 0x0069a010 ; FUN_0069a010 */

undefined4 __thiscall
FUN_0069a010(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 *param_10)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_0069a190(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0,0);
  if ((iVar4 != 0) && (*(char *)(param_1 + 5) == '\0')) {
    uVar1 = *(undefined4 *)(iVar4 + 0x3ac);
    uVar2 = *(undefined4 *)(iVar4 + 0x3b0);
    uVar3 = *(undefined4 *)(iVar4 + 0x3b4);
    *param_10 = *(undefined4 *)(iVar4 + 0x3a8);
    param_10[1] = uVar1;
    param_10[2] = uVar2;
    param_10[3] = uVar3;
    uVar1 = *(undefined4 *)(iVar4 + 0x3bc);
    uVar2 = *(undefined4 *)(iVar4 + 0x3c0);
    uVar3 = *(undefined4 *)(iVar4 + 0x3c4);
    param_10[4] = *(undefined4 *)(iVar4 + 0x3b8);
    param_10[5] = uVar1;
    param_10[6] = uVar2;
    param_10[7] = uVar3;
    return 1;
  }
  return 0;
}



/* FUNCTION 8448 ; VA 0x0069a070 ; FUN_0069a070 */

uint __thiscall FUN_0069a070(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  
  uVar2 = 0;
  if (*(uint *)(param_1 + 0x43c) != 0) {
    piVar1 = *(int **)(param_1 + 0x438);
    do {
      if (*(int *)(*piVar1 + 4) == param_2) {
        return uVar2;
      }
      uVar2 = uVar2 + 1;
      piVar1 = piVar1 + 2;
    } while (uVar2 < *(uint *)(param_1 + 0x43c));
  }
  return 0xffffffff;
}



/* FUNCTION 8449 ; VA 0x0069a0b0 ; FUN_0069a0b0 */

int __fastcall FUN_0069a0b0(int param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  
  FUN_00722910();
  uVar1 = *(uint *)(param_1 + 0x65c);
  uVar2 = *(uint *)(param_1 + 0x660);
  if (uVar1 <= uVar2) {
    FUN_00722920();
    return uVar2 - uVar1;
  }
  iVar3 = *(int *)(param_1 + 0x664);
  FUN_00722920();
  return uVar2 + (iVar3 - uVar1);
}



/* FUNCTION 8450 ; VA 0x0069a100 ; FUN_0069a100 */

int __thiscall FUN_0069a100(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  char in_stack_00000014;
  
  cVar1 = FUN_005f71b0(&DAT_01d5b1f0);
  if ((cVar1 == '\0') && (uVar3 = 0, *(short *)(param_1 + 0xe) != 0)) {
    iVar2 = 0;
    do {
      cVar1 = FUN_005f71b0(&stack0x00000004);
      if ((cVar1 != '\0') &&
         ((in_stack_00000014 == '\0' || (*(char *)(iVar2 + *(int *)(param_1 + 0x234)) != '\0')))) {
        return uVar3 * 0xb70 + *(int *)(param_1 + 0x234);
      }
      uVar3 = uVar3 + 1;
      iVar2 = iVar2 + 0xb70;
    } while (uVar3 < *(ushort *)(param_1 + 0xe));
  }
  return 0;
}



/* FUNCTION 8451 ; VA 0x0069a190 ; FUN_0069a190 */

char * __thiscall FUN_0069a190(int param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  char cStack00000024;
  char in_stack_00000028;
  
  cVar1 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar1 == '\0') {
    if (cStack00000024 == '\0') {
      uVar5 = 0xffffffff;
      uVar4 = 0;
      if (*(short *)(param_1 + 0xe) != 0) {
        _cStack00000024 = 0;
        do {
          cVar1 = FUN_005f71d0(&stack0x00000004);
          if (cVar1 != '\0') {
            pcVar3 = (char *)(*(int *)(param_1 + 0x234) + _cStack00000024);
            if (*pcVar3 != '\0') {
              return pcVar3;
            }
            if (uVar5 == 0xffffffff) {
              uVar5 = uVar4;
            }
          }
          uVar4 = uVar4 + 1;
          _cStack00000024 = _cStack00000024 + 0xb70;
        } while (uVar4 < *(ushort *)(param_1 + 0xe));
        if ((uVar5 != 0xffffffff) && (in_stack_00000028 == '\0')) {
          return (char *)(uVar5 * 0xb70 + *(int *)(param_1 + 0x234));
        }
      }
    }
    else {
      iVar2 = FUN_0069a270(&stack0x00000004);
      if (iVar2 != -1) {
        if ((in_stack_00000028 == '\0') ||
           (*(char *)(*(int *)(param_1 + 0x234) + iVar2 * 0xb70) == '\x01')) {
          return (char *)(*(int *)(param_1 + 0x234) + iVar2 * 0xb70);
        }
      }
    }
  }
  return (char *)0x0;
}



/* FUNCTION 8452 ; VA 0x0069a270 ; FUN_0069a270 */

undefined4 __thiscall FUN_0069a270(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  
  uVar3 = FUN_005f7a90(param_2);
  puVar1 = *(undefined4 **)
            (*(int *)(param_1 + 0x244) +
            (int)((ulonglong)uVar3 % ((ulonglong)*(ushort *)(param_1 + 0xe) << 3)) * 4);
  while( true ) {
    if (puVar1 == (undefined4 *)0x0) {
      return 0xffffffff;
    }
    cVar2 = FUN_005f71d0(param_2);
    if (cVar2 != '\0') break;
    puVar1 = (undefined4 *)puVar1[1];
  }
  return *puVar1;
}



/* FUNCTION 8453 ; VA 0x0069a2e0 ; FUN_0069a2e0 */

/* WARNING: Removing unreachable block (ram,0x0069a456) */
/* WARNING: Removing unreachable block (ram,0x0069a452) */
/* WARNING: Removing unreachable block (ram,0x0069a50c) */
/* WARNING: Removing unreachable block (ram,0x0069a526) */
/* WARNING: Removing unreachable block (ram,0x0069a52d) */

undefined4 * __thiscall FUN_0069a2e0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6078;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0xb09);
  *(undefined4 *)(iVar2 + 0x78) = 2;
  *(undefined4 *)(iVar2 + 0x18) = DAT_01d5b1f0;
  *(undefined4 *)(iVar2 + 0x1c) = DAT_01d5b1f4;
  *(undefined2 *)(iVar2 + 0x20) = DAT_01d5b1f8;
  FUN_005f7170(&stack0x00000008);
  *(undefined4 *)(iVar2 + 0x5c) = 0;
  FUN_0069cc60(iVar2);
  iVar2 = FUN_006a6900();
  iStack_8 = 0;
  uVar3 = FUN_006a6900();
  do {
    if (iVar2 + 1000U <= uVar3) {
LAB_0069a435:
      *param_2 = 0;
      param_2[1] = 0;
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (*(char *)(param_1 + 6) == '\0') {
      *param_2 = 0;
      param_2[1] = 0;
      ExceptionList = pvStack_10;
      return param_2;
    }
    FUN_00722890(0);
    FUN_00722910();
    if (*(int *)(param_1 + 0x3f0) == *(int *)(param_1 + 0x3f4)) {
      FUN_00722920();
    }
    else {
      iVar4 = *(int *)(param_1 + 0x3f0) + 1;
      *(int *)(param_1 + 0x3f0) = iVar4;
      iVar1 = *(int *)(param_1 + 0x3f8);
      if (iVar4 == iVar1) {
        *(undefined4 *)(param_1 + 0x3f0) = 0;
        piVar5 = *(int **)(*(int *)(param_1 + 0x3ec) + -4 + iVar1 * 4);
      }
      else if (iVar4 == 0) {
        piVar5 = *(int **)(*(int *)(param_1 + 0x3ec) + -4 + iVar1 * 4);
      }
      else {
        piVar5 = *(int **)(*(int *)(param_1 + 0x3ec) + -4 + iVar4 * 4);
      }
      FUN_00722920();
      if (piVar5 != (int *)0x0) {
        FUN_00696a40(piVar5);
        if (piVar5[2] != 0) {
          iVar2 = *piVar5;
          if (iVar2 != 0) {
            iStack_8._0_1_ = 2;
            FUN_016f32d1(iVar2,8,*(undefined4 *)(iVar2 + -4),FUN_00550b30);
            FUN_01674ea0((int *)(iVar2 + -4),*(int *)(iVar2 + -4) * 8 + 4);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
          }
          piVar5[2] = 0;
          *piVar5 = 0;
          piVar5[1] = 0;
        }
        FUN_00698b90(piVar5,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                     ,0xb1f);
        goto LAB_0069a435;
      }
    }
    uVar3 = FUN_006a6900();
  } while( true );
}



/* FUNCTION 8454 ; VA 0x0069a580 ; FUN_0069a580 */

void __thiscall FUN_0069a580(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6098;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2[2] != 0) {
    iVar1 = *param_2;
    ExceptionList = &pvStack_10;
    if (iVar1 != 0) {
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),FUN_00550b30);
      FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
    }
    param_2[2] = 0;
    *param_2 = 0;
    param_2[1] = 0;
  }
  uStack_8 = 0xffffffff;
  iVar1 = FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0xb2f);
  *(undefined4 *)(iVar1 + 0x78) = 2;
  *(undefined4 *)(iVar1 + 0x18) = DAT_01d5b1f0;
  *(undefined4 *)(iVar1 + 0x1c) = DAT_01d5b1f4;
  *(undefined2 *)(iVar1 + 0x20) = DAT_01d5b1f8;
  FUN_005f7170(&DAT_01eae4bc);
  *(undefined4 *)(iVar1 + 0x5c) = 0;
  FUN_0069cc60(iVar1);
  uStack_8 = 1;
  do {
    while( true ) {
      if (*(char *)(param_1 + 6) == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      FUN_00722890(0);
      FUN_00722910();
      if (*(int *)(param_1 + 0x3f0) != *(int *)(param_1 + 0x3f4)) break;
      FUN_00722920();
    }
    iVar2 = *(int *)(param_1 + 0x3f0) + 1;
    *(int *)(param_1 + 0x3f0) = iVar2;
    iVar1 = *(int *)(param_1 + 0x3f8);
    if (iVar2 == iVar1) {
      *(undefined4 *)(param_1 + 0x3f0) = 0;
      piVar3 = *(int **)(*(int *)(param_1 + 0x3ec) + -4 + iVar1 * 4);
    }
    else if (iVar2 == 0) {
      piVar3 = *(int **)(*(int *)(param_1 + 0x3ec) + -4 + iVar1 * 4);
    }
    else {
      piVar3 = *(int **)(*(int *)(param_1 + 0x3ec) + -4 + iVar2 * 4);
    }
    FUN_00722920();
  } while (piVar3 == (int *)0x0);
  FUN_00696a40(piVar3);
  if (piVar3[2] != 0) {
    iVar1 = *piVar3;
    if (iVar1 != 0) {
      uStack_8._0_1_ = 2;
      FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),FUN_00550b30);
      FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
    }
    piVar3[2] = 0;
    *piVar3 = 0;
    piVar3[1] = 0;
  }
  FUN_00698b90(piVar3,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0xb44);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8455 ; VA 0x0069a790 ; FUN_0069a790 */

undefined4 __fastcall FUN_0069a790(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4ac);
}



/* FUNCTION 8456 ; VA 0x0069a7a0 ; FUN_0069a7a0 */

uint * __thiscall
FUN_0069a7a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            uint *param_10)

{
  uint uVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  uint auStack_16c [4];
  uint uStack_15c;
  int iStack_158;
  uint uStack_154;
  int iStack_150;
  uint uStack_14c;
  int iStack_148;
  uint uStack_144;
  int iStack_140;
  uint uStack_13c;
  int iStack_138;
  uint uStack_134;
  int iStack_130;
  uint uStack_12c;
  int iStack_128;
  uint uStack_124;
  int iStack_120;
  uint uStack_11c;
  int iStack_118;
  uint uStack_114;
  int iStack_110;
  uint uStack_10c;
  int iStack_108;
  uint uStack_104;
  int iStack_100;
  int iStack_d4;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  double dStack_c4;
  double dStack_bc;
  double dStack_b4;
  double dStack_ac;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_c;
  uint uStack_8;
  
  iStack_c = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaeac8) &&
     (FUN_016f3809(&DAT_01eaeac8), DAT_01eaeac8 == -1)) {
    FUN_005f8980();
    FUN_016f37bf(&DAT_01eaeac8);
  }
  puVar5 = (uint *)&DAT_01eae968;
  if (param_10 != (uint *)0x0) {
    puVar5 = param_10;
  }
  cVar3 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar3 == '\0') {
    iVar4 = FUN_0069a190(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0,0);
    if ((iVar4 != 0) && (*(char *)(param_1 + 5) == '\0')) {
      FUN_005fb630(puVar5);
      return puVar5;
    }
    return (uint *)0x0;
  }
  bVar2 = false;
  uStack_8 = 0;
  if (*(short *)(param_1 + 0xe) != 0) {
    do {
      if (*(char *)((uStack_8 & 0xffff) * 0xb70 + *(int *)(param_1 + 0x234)) != '\0') {
        uStack_34 = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_28 = 0;
        uStack_24 = 0;
        uStack_20 = 0;
        uStack_1c = 0;
        uStack_18 = 0;
        FUN_005fb630(auStack_16c);
        if (bVar2) {
          puVar5[0x26] = puVar5[0x26] + iStack_d4;
          *(double *)(puVar5 + 0x2a) = *(double *)(puVar5 + 0x2a) + dStack_c4;
          puVar5[0x27] = puVar5[0x27] + iStack_d0;
          *(double *)(puVar5 + 0x2c) = *(double *)(puVar5 + 0x2c) + dStack_bc;
          puVar5[0x28] = puVar5[0x28] + iStack_cc;
          *(double *)(puVar5 + 0x2e) = dStack_b4 + *(double *)(puVar5 + 0x2e);
          puVar5[0x29] = puVar5[0x29] + iStack_c8;
          *(double *)(puVar5 + 0x30) = dStack_ac + *(double *)(puVar5 + 0x30);
          uVar1 = *puVar5;
          *puVar5 = *puVar5 + auStack_16c[0];
          puVar5[1] = puVar5[1] + auStack_16c[1] + (uint)CARRY4(uVar1,auStack_16c[0]);
          puVar6 = puVar5 + 0xe;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_134;
          puVar5[0xf] = puVar5[0xf] + iStack_130 + (uint)CARRY4(uVar1,uStack_134);
          puVar6 = puVar5 + 2;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + auStack_16c[2];
          puVar5[3] = puVar5[3] + auStack_16c[3] + (uint)CARRY4(uVar1,auStack_16c[2]);
          puVar6 = puVar5 + 0x10;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_12c;
          puVar5[0x11] = puVar5[0x11] + iStack_128 + (uint)CARRY4(uVar1,uStack_12c);
          puVar6 = puVar5 + 4;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_15c;
          puVar5[5] = puVar5[5] + iStack_158 + (uint)CARRY4(uVar1,uStack_15c);
          puVar6 = puVar5 + 0x12;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_124;
          puVar5[0x13] = puVar5[0x13] + iStack_120 + (uint)CARRY4(uVar1,uStack_124);
          puVar6 = puVar5 + 6;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_154;
          puVar5[7] = puVar5[7] + iStack_150 + (uint)CARRY4(uVar1,uStack_154);
          puVar6 = puVar5 + 0x14;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_11c;
          puVar5[0x15] = puVar5[0x15] + iStack_118 + (uint)CARRY4(uVar1,uStack_11c);
          puVar6 = puVar5 + 8;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_14c;
          puVar5[9] = puVar5[9] + iStack_148 + (uint)CARRY4(uVar1,uStack_14c);
          puVar6 = puVar5 + 0x16;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_114;
          puVar5[0x17] = puVar5[0x17] + iStack_110 + (uint)CARRY4(uVar1,uStack_114);
          puVar6 = puVar5 + 10;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_144;
          puVar5[0xb] = puVar5[0xb] + iStack_140 + (uint)CARRY4(uVar1,uStack_144);
          puVar6 = puVar5 + 0x18;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_10c;
          puVar5[0x19] = puVar5[0x19] + iStack_108 + (uint)CARRY4(uVar1,uStack_10c);
          puVar6 = puVar5 + 0xc;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_13c;
          puVar5[0xd] = puVar5[0xd] + iStack_138 + (uint)CARRY4(uVar1,uStack_13c);
          puVar6 = puVar5 + 0x1a;
          uVar1 = *puVar6;
          *puVar6 = *puVar6 + uStack_104;
          puVar5[0x1b] = puVar5[0x1b] + iStack_100 + (uint)CARRY4(uVar1,uStack_104);
        }
        else {
          bVar2 = true;
          puVar6 = auStack_16c;
          puVar7 = puVar5;
          for (iVar4 = 0x58; param_1 = iStack_c, iVar4 != 0; iVar4 = iVar4 + -1) {
            *puVar7 = *puVar6;
            puVar6 = puVar6 + 1;
            puVar7 = puVar7 + 1;
          }
        }
      }
      uStack_8 = uStack_8 + 1;
    } while ((ushort)uStack_8 < *(ushort *)(param_1 + 0xe));
  }
  return puVar5;
}



/* FUNCTION 8457 ; VA 0x0069aac0 ; FUN_0069aac0 */

undefined4 __thiscall FUN_0069aac0(int param_1,int param_2,undefined4 param_3)

{
  if ((param_2 < (int)(uint)*(ushort *)(param_1 + 0xe)) &&
     (*(char *)(param_2 * 0xb70 + *(int *)(param_1 + 0x234)) != '\0')) {
    FUN_005fb630(param_3);
    return 1;
  }
  return 0;
}



/* FUNCTION 8458 ; VA 0x0069ab00 ; FUN_0069ab00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_0069ab00(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,ushort param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  
  cVar4 = FUN_005f71b0(&DAT_01d5b1f0);
  if (cVar4 == '\0') {
    cVar4 = FUN_005f71b0(param_1 + 0x11c);
    if (cVar4 != '\0') {
      (**(code **)(*param_1 + 0xb0))
                (param_2,_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                 uRam01eae4d0,uRam01eae4d4,uRam01eae4d8,0);
      return param_2;
    }
    if (((param_5 != 0xffff) && (param_5 < *(ushort *)((int)param_1 + 0xe))) &&
       (cVar4 = FUN_005f71b0(&param_3), cVar4 != '\0')) {
      iVar5 = (uint)param_5 * 0xb70 + param_1[0x8d];
      uVar1 = *(undefined4 *)(iVar5 + 8);
      uVar2 = *(undefined4 *)(iVar5 + 0xc);
      uVar3 = *(undefined4 *)(iVar5 + 0x10);
      *param_2 = *(undefined4 *)(iVar5 + 4);
      param_2[1] = uVar1;
      param_2[2] = uVar2;
      param_2[3] = uVar3;
      uVar1 = *(undefined4 *)(iVar5 + 0x18);
      uVar2 = *(undefined4 *)(iVar5 + 0x1c);
      uVar3 = *(undefined4 *)(iVar5 + 0x20);
      param_2[4] = *(undefined4 *)(iVar5 + 0x14);
      param_2[5] = uVar1;
      param_2[6] = uVar2;
      param_2[7] = uVar3;
      return param_2;
    }
    uVar6 = 0;
    if (*(short *)((int)param_1 + 0xe) != 0) {
      do {
        cVar4 = FUN_005f71b0(&param_3);
        if (cVar4 != '\0') {
          iVar5 = uVar6 * 0xb70 + param_1[0x8d];
          uVar1 = *(undefined4 *)(iVar5 + 8);
          uVar2 = *(undefined4 *)(iVar5 + 0xc);
          uVar3 = *(undefined4 *)(iVar5 + 0x10);
          *param_2 = *(undefined4 *)(iVar5 + 4);
          param_2[1] = uVar1;
          param_2[2] = uVar2;
          param_2[3] = uVar3;
          uVar1 = *(undefined4 *)(iVar5 + 0x18);
          uVar2 = *(undefined4 *)(iVar5 + 0x1c);
          uVar3 = *(undefined4 *)(iVar5 + 0x20);
          param_2[4] = *(undefined4 *)(iVar5 + 0x14);
          param_2[5] = uVar1;
          param_2[6] = uVar2;
          param_2[7] = uVar3;
          return param_2;
        }
        uVar6 = uVar6 + 1;
      } while (uVar6 < *(ushort *)((int)param_1 + 0xe));
    }
  }
  uVar3 = uRam01eae4c8;
  uVar2 = uRam01eae4c4;
  uVar1 = uRam01eae4c0;
  *param_2 = _DAT_01eae4bc;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar3 = uRam01eae4d8;
  uVar2 = uRam01eae4d4;
  uVar1 = uRam01eae4d0;
  param_2[4] = _DAT_01eae4cc;
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  return param_2;
}



/* FUNCTION 8459 ; VA 0x0069ac40 ; FUN_0069ac40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0069ac40(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  
  uVar3 = uRam01eae4c8;
  uVar2 = uRam01eae4c4;
  uVar1 = uRam01eae4c0;
  if ((((-1 < param_3) && (param_3 < (int)(uint)*(ushort *)(param_1 + 0xe))) &&
      (pcVar4 = (char *)(param_3 * 0xb70 + *(int *)(param_1 + 0x234)), *pcVar4 != '\0')) &&
     (*(int *)(pcVar4 + 0xb68) == 7)) {
    uVar1 = *(undefined4 *)(pcVar4 + 8);
    uVar2 = *(undefined4 *)(pcVar4 + 0xc);
    uVar3 = *(undefined4 *)(pcVar4 + 0x10);
    *param_2 = *(undefined4 *)(pcVar4 + 4);
    param_2[1] = uVar1;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    uVar1 = *(undefined4 *)(pcVar4 + 0x18);
    uVar2 = *(undefined4 *)(pcVar4 + 0x1c);
    uVar3 = *(undefined4 *)(pcVar4 + 0x20);
    param_2[4] = *(undefined4 *)(pcVar4 + 0x14);
    param_2[5] = uVar1;
    param_2[6] = uVar2;
    param_2[7] = uVar3;
    return;
  }
  *param_2 = _DAT_01eae4bc;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar3 = uRam01eae4d8;
  uVar2 = uRam01eae4d4;
  uVar1 = uRam01eae4d0;
  param_2[4] = _DAT_01eae4cc;
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  return;
}



/* FUNCTION 8460 ; VA 0x0069acb0 ; FUN_0069acb0 */

void __thiscall FUN_0069acb0(int param_1,int *param_2,int *param_3)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a60f2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2[2] != 0) {
    ExceptionList = &pvStack_10;
    FUN_01674ea0(*param_2);
    param_2[2] = 0;
    *param_2 = 0;
    param_2[1] = 0;
  }
  if (param_3[2] != 0) {
    FUN_01674ea0(*param_3);
    param_3[2] = 0;
    *param_3 = 0;
    param_3[1] = 0;
  }
  if (((*(int *)(param_1 + 0x234) != 0) && (*(char *)(param_1 + 5) == '\0')) &&
     (uStack_18 = 0, *(int *)(param_1 + 0x23c) != 0)) {
    do {
      pcVar1 = *(char **)(*(int *)(param_1 + 0x238) + uStack_18 * 4);
      if ((*pcVar1 != '\0') && (*(int *)(pcVar1 + 0xb68) == 7)) {
        iVar3 = param_2[1];
        iVar7 = param_2[2];
        if (iVar3 == iVar7) {
          if (iVar7 == 0) {
            param_2[2] = 0x10;
            uVar6 = 0x10;
LAB_0069ad93:
            iStack_14 = FUN_01674e20(-(uint)((int)((ulonglong)uVar6 * 0x20 >> 0x20) != 0) |
                                     (uint)((ulonglong)uVar6 * 0x20));
            uStack_8 = 0;
            if (iStack_14 == 0) {
              iStack_14 = 0;
            }
            else {
              for (; uVar6 != 0; uVar6 = uVar6 - 1) {
                FUN_005f7140();
              }
            }
            iVar3 = param_2[1];
            uStack_8 = 0xffffffff;
          }
          else {
            uVar6 = iVar7 * 2;
            param_2[2] = uVar6;
            if (uVar6 != 0) goto LAB_0069ad93;
            iStack_14 = 0;
          }
          iVar7 = *param_2;
          if (iVar7 != 0) {
            uVar6 = 0;
            if (iVar3 != 0) {
              iVar7 = 0;
              do {
                FUN_005f7170(*param_2 + iVar7);
                uVar6 = uVar6 + 1;
                iVar7 = iVar7 + 0x20;
              } while (uVar6 < (uint)param_2[1]);
              iVar7 = *param_2;
            }
            FUN_01674ea0(iVar7);
          }
          *param_2 = iStack_14;
        }
        FUN_005f7170(pcVar1 + 4);
        param_2[1] = param_2[1] + 1;
        iVar5 = param_3[1];
        iVar7 = *(int *)(*(int *)(param_1 + 0x238) + uStack_18 * 4);
        iVar3 = param_3[2];
        if (iVar5 == iVar3) {
          if (iVar3 == 0) {
            param_3[2] = 0x10;
            uVar6 = 0x10;
LAB_0069ae8a:
            iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)uVar6 * 0x10 >> 0x20) != 0) |
                                 (uint)((ulonglong)uVar6 * 0x10));
            uStack_8 = 1;
            if (iVar3 == 0) {
              iVar3 = 0;
            }
            else {
              for (; uVar6 != 0; uVar6 = uVar6 - 1) {
                FUN_005f70a0();
              }
            }
            uStack_8 = 0xffffffff;
            iVar5 = param_3[1];
          }
          else {
            uVar6 = iVar3 * 2;
            param_3[2] = uVar6;
            if (uVar6 != 0) goto LAB_0069ae8a;
            iVar3 = 0;
          }
          iVar4 = *param_3;
          if (iVar4 != 0) {
            if (iVar5 != 0) {
              uVar6 = 0;
              iVar5 = 0;
              do {
                iVar2 = *param_3;
                iVar4 = iVar5 + 0x10;
                uVar6 = uVar6 + 1;
                *(undefined4 *)(iVar5 + iVar3) = *(undefined4 *)(iVar2 + -0x10 + iVar4);
                *(undefined4 *)(iVar5 + 4 + iVar3) = *(undefined4 *)(iVar2 + -0xc + iVar4);
                *(undefined2 *)(iVar5 + 8 + iVar3) = *(undefined2 *)(iVar2 + -8 + iVar4);
                iVar5 = iVar4;
              } while (uVar6 < (uint)param_3[1]);
              iVar4 = *param_3;
            }
            FUN_01674ea0(iVar4);
          }
          *param_3 = iVar3;
        }
        else {
          iVar3 = *param_3;
        }
        iVar5 = param_3[1];
        *(undefined4 *)(iVar3 + iVar5 * 0x10) = *(undefined4 *)(iVar7 + 0xb30);
        *(undefined4 *)(iVar3 + 4 + iVar5 * 0x10) = *(undefined4 *)(iVar7 + 0xb34);
        *(undefined2 *)(iVar3 + 8 + iVar5 * 0x10) = *(undefined2 *)(iVar7 + 0xb38);
        param_3[1] = param_3[1] + 1;
      }
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < *(uint *)(param_1 + 0x23c));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8461 ; VA 0x0069af90 ; FUN_0069af90 */

undefined4 __thiscall
FUN_0069af90(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,0,1);
    if (iVar2 != 0) {
      FUN_005fb8c0();
    }
  }
  return *(undefined4 *)(param_1 + 0x46c);
}



/* FUNCTION 8462 ; VA 0x0069afe0 ; FUN_0069afe0 */

int __fastcall FUN_0069afe0(int param_1)

{
  int iVar1;
  int iVar2;
  
  FUN_00722910();
  iVar2 = *(int *)(param_1 + 0x6a8);
  iVar1 = iVar2 + 1;
  *(int *)(param_1 + 0x6a8) = iVar1;
  if (iVar1 == 0) {
    *(undefined4 *)(param_1 + 0x6a8) = 1;
  }
  FUN_00722920();
  return iVar2;
}



/* FUNCTION 8463 ; VA 0x0069b020 ; FUN_0069b020 */

int __thiscall FUN_0069b020(int *param_1,int *param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar3 = param_1[1];
  iVar1 = param_1[2];
  if (iVar3 == iVar1) {
    if (iVar1 == 0) {
      ExceptionList = &pvStack_10;
      param_1[2] = 0x10;
      iVar1 = 0x10;
    }
    else {
      iVar1 = iVar1 * 2;
      ExceptionList = &pvStack_10;
      param_1[2] = iVar1;
    }
    iVar1 = FUN_006959a0(iVar1,param_3,param_4);
    iVar3 = *param_1;
    if (iVar3 != 0) {
      param_4 = 0;
      if (param_1[1] != 0) {
        piVar4 = (int *)(iVar1 + 4);
        do {
          piVar2 = (int *)((int)piVar4 + *param_1 + (-4 - iVar1));
          iVar3 = piVar2[1];
          if (iVar3 != 0) {
            LOCK();
            *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
            UNLOCK();
            iVar3 = piVar2[1];
          }
          piVar4[-1] = *piVar2;
          piVar2 = (int *)*piVar4;
          *piVar4 = iVar3;
          if (piVar2 != (int *)0x0) {
            LOCK();
            iVar3 = piVar2[1] + -1;
            piVar2[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piVar2)();
              LOCK();
              iVar3 = piVar2[2] + -1;
              piVar2[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          piVar4 = piVar4 + 2;
          param_4 = param_4 + 1;
        } while (param_4 < (uint)param_1[1]);
        iVar3 = *param_1;
      }
      if (iVar3 != 0) {
        uStack_8 = 0;
        FUN_016f32d1(iVar3,8,*(undefined4 *)(iVar3 + -4),FUN_00550b30);
        FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 8 + 4);
      }
    }
    iVar3 = param_1[1];
    *param_1 = iVar1;
  }
  else {
    iVar1 = *param_1;
    ExceptionList = &pvStack_10;
  }
  piVar4 = (int *)(iVar1 + iVar3 * 8);
  iVar1 = param_2[1];
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = param_2[1];
  }
  iVar3 = *param_2;
  *piVar4 = iVar3;
  piVar2 = (int *)piVar4[1];
  piVar4[1] = iVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar4 = piVar2 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*piVar2)();
      LOCK();
      piVar4 = piVar2 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[1] = param_1[1] + 1;
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 8464 ; VA 0x0069b190 ; FUN_0069b190 */

bool __fastcall FUN_0069b190(int param_1)

{
  return *(char *)(param_1 + 5) == '\0';
}



/* FUNCTION 8465 ; VA 0x0069b1a0 ; FUN_0069b1a0 */

undefined4 __thiscall FUN_0069b1a0(int param_1,char *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  uint uVar5;
  char *pcVar6;
  uint uVar7;
  
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    pcVar6 = param_2;
    do {
      cVar4 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar4 != '\0');
    if (((uint)((int)pcVar6 - (int)(param_2 + 1)) < 0x10) &&
       (uVar7 = 0, *(int *)(param_1 + 0x2d0) != 0)) {
      uVar2 = FUN_006a6900();
      FUN_00722910();
      uVar5 = *(uint *)(param_1 + 0x2d0);
      if (uVar5 != 0) {
        do {
          iVar3 = *(int *)(param_1 + 0x2cc);
          puVar1 = *(undefined4 **)(iVar3 + uVar7 * 4);
          if ((puVar1[1] == 0) || (uVar2 <= (uint)puVar1[1])) {
            pcVar6 = (char *)*puVar1;
            iVar3 = 0;
            cVar4 = *param_2;
            if (*pcVar6 == cVar4) {
              do {
                if (cVar4 == '\0') goto LAB_0069b293;
                cVar4 = param_2[iVar3 + 1];
                iVar3 = iVar3 + 1;
              } while (pcVar6[iVar3] == cVar4);
            }
            if (((pcVar6[iVar3] != '\0') && (param_2[iVar3] != '\0')) && (pcVar6[iVar3] == '*')) {
LAB_0069b293:
              FUN_00722920();
              return 1;
            }
            uVar7 = uVar7 + 1;
          }
          else {
            *(undefined4 *)(iVar3 + uVar7 * 4) = *(undefined4 *)(iVar3 + -4 + uVar5 * 4);
            FUN_0069dd00(*(int *)(param_1 + 0x2d0) + -1);
            FUN_01674ea0(*puVar1);
            FUN_01674ea0(puVar1,8);
          }
          uVar5 = *(uint *)(param_1 + 0x2d0);
        } while (uVar7 < uVar5);
      }
      FUN_00722920();
    }
  }
  return 0;
}



/* FUNCTION 8466 ; VA 0x0069b2c0 ; FUN_0069b2c0 */

undefined4 __thiscall FUN_0069b2c0(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  
  if (*(int *)(param_1 + 0x4b8) == 0) {
    return 0;
  }
  uVar2 = 0;
  FUN_00722910();
  if (*(int *)(param_1 + 0x4b8) != 0) {
    do {
      cVar1 = FUN_0071e660(param_2);
      if (cVar1 != '\0') {
        FUN_00722920();
        return 1;
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < *(uint *)(param_1 + 0x4b8));
  }
  FUN_00722920();
  return 0;
}



/* FUNCTION 8467 ; VA 0x0069b340 ; FUN_0069b340 */

uint __thiscall FUN_0069b340(int *param_1,byte *param_2)

{
  byte bVar1;
  uint in_EAX;
  byte *pbVar2;
  uint uVar3;
  byte *pbVar4;
  int iVar5;
  bool bVar6;
  
  if ((param_2 == (byte *)0x0) || (*param_2 == 0)) {
LAB_0069b450:
    return in_EAX & 0xffffff00;
  }
  pbVar4 = &DAT_018c92b8;
  pbVar2 = param_2;
  do {
    bVar1 = *pbVar2;
    bVar6 = bVar1 < *pbVar4;
    if (bVar1 != *pbVar4) {
LAB_0069b387:
      in_EAX = -(uint)bVar6 | 1;
      goto LAB_0069b38c;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar2[1];
    bVar6 = bVar1 < pbVar4[1];
    if (bVar1 != pbVar4[1]) goto LAB_0069b387;
    pbVar2 = pbVar2 + 2;
    pbVar4 = pbVar4 + 2;
  } while (bVar1 != 0);
  in_EAX = 0;
LAB_0069b38c:
  if (in_EAX != 0) {
    pbVar4 = &DAT_018bfc3c;
    pbVar2 = param_2;
    do {
      bVar1 = *pbVar2;
      bVar6 = bVar1 < *pbVar4;
      if (bVar1 != *pbVar4) {
LAB_0069b3c0:
        in_EAX = -(uint)bVar6 | 1;
        goto LAB_0069b3c5;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar2[1];
      bVar6 = bVar1 < pbVar4[1];
      if (bVar1 != pbVar4[1]) goto LAB_0069b3c0;
      pbVar2 = pbVar2 + 2;
      pbVar4 = pbVar4 + 2;
    } while (bVar1 != 0);
    in_EAX = 0;
LAB_0069b3c5:
    if (in_EAX != 0) {
      pbVar4 = &DAT_018c92b4;
      pbVar2 = param_2;
      do {
        bVar1 = *pbVar2;
        bVar6 = bVar1 < *pbVar4;
        if (bVar1 != *pbVar4) {
LAB_0069b3f4:
          in_EAX = -(uint)bVar6 | 1;
          goto LAB_0069b3f9;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar2[1];
        bVar6 = bVar1 < pbVar4[1];
        if (bVar1 != pbVar4[1]) goto LAB_0069b3f4;
        pbVar2 = pbVar2 + 2;
        pbVar4 = pbVar4 + 2;
      } while (bVar1 != 0);
      in_EAX = 0;
LAB_0069b3f9:
      if (in_EAX != 0) {
        uVar3 = (**(code **)(*param_1 + 0xdc))();
        iVar5 = 0;
        in_EAX = uVar3;
        if (0 < (int)uVar3) {
          do {
            pbVar4 = (byte *)(**(code **)(*param_1 + 0xe0))(iVar5);
            pbVar2 = param_2;
            do {
              bVar1 = *pbVar2;
              bVar6 = bVar1 < *pbVar4;
              if (bVar1 != *pbVar4) {
LAB_0069b442:
                in_EAX = -(uint)bVar6 | 1;
                goto LAB_0069b447;
              }
              if (bVar1 == 0) break;
              bVar1 = pbVar2[1];
              bVar6 = bVar1 < pbVar4[1];
              if (bVar1 != pbVar4[1]) goto LAB_0069b442;
              pbVar2 = pbVar2 + 2;
              pbVar4 = pbVar4 + 2;
            } while (bVar1 != 0);
            in_EAX = 0;
LAB_0069b447:
            if (in_EAX == 0) goto LAB_0069b45b;
            iVar5 = iVar5 + 1;
          } while (iVar5 < (int)uVar3);
        }
        goto LAB_0069b450;
      }
    }
  }
LAB_0069b45b:
  return CONCAT31((int3)(in_EAX >> 8),1);
}



/* FUNCTION 8468 ; VA 0x0069b470 ; FUN_0069b470 */

undefined4 __thiscall FUN_0069b470(int param_1,int param_2,char param_3)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  
  iVar1 = param_2;
  cVar2 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar2 != '\0') {
    uVar3 = FUN_005f71b0(param_1 + 0x470);
    return uVar3;
  }
  param_2 = 0;
  do {
    cVar2 = FUN_005f7260(&DAT_01eae4bc);
    if (cVar2 == '\0') break;
    if (param_3 == '\0') {
      cVar2 = FUN_005f72a0(iVar1 + 0x10);
    }
    else {
      cVar2 = FUN_005f71d0(iVar1 + 0x10);
    }
    if (cVar2 != '\0') {
      return 1;
    }
    param_2 = param_2 + 1;
  } while (param_2 < 10);
  if (param_3 == '\x01') {
    cVar2 = FUN_005f71d0(param_1 + 0x48c);
  }
  else {
    if (param_3 != '\0') {
      return 0;
    }
    cVar2 = FUN_005f72a0(param_1 + 0x48c);
  }
  if (cVar2 == '\0') {
    return 0;
  }
  return 1;
}



/* FUNCTION 8469 ; VA 0x0069b550 ; FUN_0069b550 */

undefined FUN_0069b550(void)

{
  char cVar1;
  
  cVar1 = FUN_005f71b0(&DAT_01d5b1f0);
  if (cVar1 != '\0') {
    cVar1 = FUN_005f71d0(&DAT_01eae4bc);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 8470 ; VA 0x0069b580 ; FUN_0069b580 */

void __thiscall
FUN_0069b580(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,int param_13,
            undefined4 param_14)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 in_stack_fffffe64;
  undefined4 uVar7;
  undefined4 in_stack_fffffe68;
  undefined2 in_stack_fffffe6c;
  undefined2 uVar8;
  int iVar9;
  undefined4 uStack_14c;
  undefined4 uStack_140;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar8 = (undefined2)((uint)in_stack_fffffe64 >> 0x10);
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a610b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_006a54a0(1);
  uStack_8 = 0;
  if (DAT_01d5a2c0 == '\0') {
    if (DAT_01ee420a == '\0') goto LAB_0069b5fc;
    iVar9 = *(int *)(param_1 + 0x434);
  }
  else {
    iVar9 = *(int *)(param_1 + 0x434);
    if ((iVar9 == 0x119) || (DAT_01ee420a == '\0')) goto LAB_0069b5fc;
  }
  FUN_01677520(DAT_01ee420a,"Sending disconnect with reason: %d",iVar9);
LAB_0069b5fc:
  if ((param_13 != 0) && (DAT_01ee420a != '\0')) {
    FUN_01677520(DAT_01ee420a,"Disconnect generated from: %s : %u",param_13,param_14);
  }
  param_13 = CONCAT13(0x15,(undefined3)param_13);
  FUN_006a6060((int)&param_13 + 3,8,1);
  uStack_14 = *(undefined4 *)(param_1 + 0x434);
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(&uStack_14,&param_13,4);
    puVar2 = &param_13;
  }
  else {
    puVar2 = &uStack_14;
  }
  FUN_006a6060(puVar2,0x20,1);
  if ((char)param_10 == '\0') {
    param_10 = uStack_14c;
    param_13 = uStack_140;
    FUN_005f70a0();
    FUN_005f7140();
    uVar5 = DAT_01d5b1f0;
    uVar6 = DAT_01d5b1f4;
    uVar8 = DAT_01d5b1f8;
    FUN_005f7170(&param_2);
    FUN_006a0d60(param_13,param_10,param_12,3,param_11,uVar5,uVar6,uVar8);
  }
  else {
    FUN_006a6920();
    param_10 = uStack_14c;
    param_13 = uStack_140;
    FUN_005f70a0();
    FUN_005f7140();
    uVar7 = CONCAT22(uVar8,DAT_01d5b1f8);
    uVar5 = DAT_01d5b1f0;
    uVar6 = DAT_01d5b1f4;
    FUN_005f7170(&param_2);
    iVar9 = iStack_18;
    FUN_006a1380(param_13,param_10,param_12,3,param_11,uVar5,uVar6,uVar7,in_stack_fffffe68,
                 in_stack_fffffe6c);
    uStack_38 = param_2;
    uStack_34 = param_3;
    uStack_30 = param_4;
    uStack_2c = param_5;
    uStack_28 = param_6;
    uStack_24 = param_7;
    uStack_20 = param_8;
    uStack_1c = param_9;
    cVar1 = FUN_005f71d0(&DAT_01eae4bc);
    if (((cVar1 != '\0') || (iVar3 = FUN_0069a270(&uStack_38), iVar3 == -1)) ||
       (pcVar4 = (char *)(*(int *)(iVar9 + 0x234) + iVar3 * 0xb70), *pcVar4 != '\x01')) {
      pcVar4 = (char *)0x0;
    }
    if ((DAT_01d5b2a0 == '\0') || (pcVar4 != (char *)0x0)) {
      pcVar4[0xb68] = '\x01';
      pcVar4[0xb69] = '\0';
      pcVar4[0xb6a] = '\0';
      pcVar4[0xb6b] = '\0';
    }
  }
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8471 ; VA 0x0069b7d0 ; FUN_0069b7d0 */

undefined4 __fastcall FUN_0069b7d0(int *param_1)

{
  undefined2 uVar1;
  undefined2 extraout_var;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  undefined2 uVar2;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6040;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  iStack_20 = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x7c))(&uStack_1c,&uStack_28);
  uVar1 = (undefined2)uStack_18;
  uVar2 = extraout_var;
  if (iStack_20 != 0) {
    FUN_01674ea0(uStack_28);
    uVar2 = extraout_var_00;
  }
  if (iStack_14 != 0) {
    FUN_01674ea0(uStack_1c);
    uVar2 = extraout_var_01;
  }
  ExceptionList = pvStack_10;
  return CONCAT22(uVar2,uVar1);
}



/* FUNCTION 8472 ; VA 0x0069b870 ; FUN_0069b870 */

/* WARNING: Removing unreachable block (ram,0x0069b88f) */

void FUN_0069b870(uint param_1,uint param_2,uint param_3,int param_4,int param_5)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  ulonglong uVar6;
  int iStack_10;
  
  uVar6 = FUN_006a6900();
  if (CONCAT44(param_2,param_1) < uVar6) {
    iStack_10 = (int)uVar6 - param_1;
  }
  else {
    iStack_10 = 0;
  }
  *(short *)(param_5 + (*(int *)(param_5 + 0xb10) + 0xac) * 0x10) = (short)iStack_10;
  uVar3 = (uint)(uVar6 >> 1);
  uVar4 = param_3 - uVar3;
  uVar5 = param_1 >> 1 | param_2 << 0x1f;
  iVar2 = *(int *)(param_5 + 0xb10);
  *(uint *)(param_5 + 0xac8 + iVar2 * 0x10) = uVar4 - uVar5;
  *(uint *)(param_5 + 0xacc + iVar2 * 0x10) =
       (((param_4 - (int)((uVar6 >> 1) >> 0x20)) - (uint)(param_3 < uVar3)) - (param_2 >> 1)) -
       (uint)(uVar4 < uVar5);
  if ((*(ushort *)(param_5 + 2) == 0xffff) || (iStack_10 < (int)(uint)*(ushort *)(param_5 + 2))) {
    *(short *)(param_5 + 2) = (short)iStack_10;
  }
  puVar1 = (uint *)(param_5 + 0xb10);
  uVar3 = *puVar1;
  *puVar1 = *puVar1 + 1;
  *(int *)(param_5 + 0xb14) = *(int *)(param_5 + 0xb14) + (uint)(0xfffffffe < uVar3);
  if ((*(int *)(param_5 + 0xb10) == 5) && (*(int *)(param_5 + 0xb14) == 0)) {
    *(undefined4 *)(param_5 + 0xb10) = 0;
    *(undefined4 *)(param_5 + 0xb14) = 0;
  }
  return;
}



/* FUNCTION 8473 ; VA 0x0069b950 ; FUN_0069b950 */

void __thiscall FUN_0069b950(int param_1,uint param_2)

{
  uint uVar1;
  char cVar2;
  uint *puVar3;
  undefined8 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined2 uVar9;
  uint uStack_188;
  undefined4 uStack_17c;
  uint uStack_2c;
  undefined8 uStack_28;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a612b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006a5600();
  uStack_8 = 0;
  uStack_11 = 0x10;
  FUN_006a6060(&uStack_11,8,1);
  uVar1 = param_2;
  puVar5 = (undefined4 *)(param_2 + 4);
  FUN_00695b40(puVar5);
  uStack_20 = FUN_00699980(*puVar5,*(undefined4 *)(uVar1 + 8),*(undefined4 *)(uVar1 + 0xc),
                           *(undefined4 *)(uVar1 + 0x10),*(undefined4 *)(uVar1 + 0x14),
                           *(undefined4 *)(uVar1 + 0x18),*(undefined4 *)(uVar1 + 0x1c),
                           *(undefined4 *)(uVar1 + 0x20),1);
  uStack_20 = uStack_20 & 0xffff;
  cVar2 = FUN_005fda50();
  if (cVar2 == '\0') {
    FUN_006a5c10(&uStack_20,&param_2,2);
    puVar3 = &param_2;
  }
  else {
    puVar3 = &uStack_20;
  }
  FUN_006a6060(puVar3,0x10,1);
  param_1 = param_1 + 0x4c0;
  iVar6 = 10;
  do {
    if (DAT_01d5b1e4 == '\0') {
      uStack_11 = FUN_005f77c0();
      FUN_006a6060(&uStack_11,8,1);
      cVar2 = FUN_005f77c0();
      if (cVar2 == '\x04') {
        param_2 = ~*(uint *)(param_1 + 4);
        FUN_006a6060(&param_2,0x20,1);
        uStack_1c._4_4_ = FUN_005f7820();
        uStack_1c._4_4_ = uStack_1c._4_4_ & 0xffff;
        puVar4 = &uStack_1c;
        goto LAB_0069bad3;
      }
    }
    else {
      param_2 = CONCAT13(4,(undefined3)param_2);
      FUN_006a6060((int)&param_2 + 3,8,1);
      uStack_2c = ~*(uint *)(param_1 + 4);
      FUN_006a6060(&uStack_2c,0x20,1);
      uStack_28._4_4_ = FUN_005f7820();
      uStack_28._4_4_ = uStack_28._4_4_ & 0xffff;
      puVar4 = &uStack_28;
LAB_0069bad3:
      FUN_006a6060((int)puVar4 + 4,0x10,1);
    }
    param_1 = param_1 + 0x20;
    iVar6 = iVar6 + -1;
    if (iVar6 == 0) {
      cVar2 = FUN_005fda50();
      if (cVar2 == '\0') {
        FUN_006a5c10(&stack0x00000008,&uStack_1c,8);
        puVar4 = &uStack_1c;
      }
      else {
        puVar4 = (undefined8 *)&stack0x00000008;
      }
      FUN_006a6060(puVar4,0x40,1);
      uStack_1c = FUN_006a6900();
      cVar2 = FUN_005fda50();
      if (cVar2 == '\0') {
        FUN_006a5c10(&uStack_1c,&uStack_28,8);
        puVar4 = &uStack_28;
      }
      else {
        puVar4 = &uStack_1c;
      }
      FUN_006a6060(puVar4,0x40,1);
      FUN_006a6920();
      param_2 = uStack_188;
      uStack_1c._4_4_ = uStack_17c;
      FUN_005f70a0();
      FUN_005f7140();
      uVar7 = DAT_01d5b1f0;
      uVar8 = DAT_01d5b1f4;
      uVar9 = DAT_01d5b1f8;
      FUN_005f7170(puVar5);
      FUN_006a1380(uStack_1c._4_4_,param_2,0,3,0,uVar7,uVar8,uVar9);
      FUN_006a5640();
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 8474 ; VA 0x0069bbf0 ; FUN_0069bbf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_0069bbf0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,uint param_5)

{
  uint uVar1;
  char cVar2;
  undefined *puVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined2 uVar9;
  int iStack_268;
  undefined4 uStack_25c;
  int iStack_144;
  int iStack_140;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6156;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  FUN_006a5530(param_4,param_5,0);
  uStack_8 = 0;
  FUN_006a57f0(1);
  FUN_005f70a0();
  cVar2 = FUN_005fda50();
  if (cVar2 == '\0') {
    cVar2 = FUN_006a5ae0(auStack_18,0x40,1);
    if (cVar2 != '\0') {
      FUN_006a5c10(auStack_18,auStack_38,8);
    }
  }
  else {
    FUN_006a5ae0(auStack_38,0x40,1);
  }
  cVar2 = FUN_005fda50();
  if (cVar2 == '\0') {
    cVar2 = FUN_006a5ae0(auStack_18,0x40,1);
    if (cVar2 != '\0') {
      FUN_006a5c10(auStack_18,&uStack_28,8);
    }
  }
  else {
    FUN_006a5ae0(&uStack_28,0x40,1);
  }
  FUN_006a5ae0((int)&param_4 + 3,8,1);
  uVar4 = iStack_144 + 7U >> 3;
  piVar6 = (int *)(iStack_140 + uVar4);
  if ((uint)*(byte *)(param_1 + 0x8c) == param_5 - uVar4) {
    piVar5 = param_1 + 0x4c;
    uVar4 = (uint)*(byte *)(param_1 + 0x8c);
    while (uVar1 = uVar4 - 4, 3 < uVar4) {
      if (*piVar6 != *piVar5) goto LAB_0069bd1a;
      piVar6 = piVar6 + 1;
      piVar5 = piVar5 + 1;
      uVar4 = uVar1;
    }
    if (uVar1 != 0xfffffffc) {
LAB_0069bd1a:
      if ((*(char *)piVar6 != *(char *)piVar5) ||
         ((uVar1 != 0xfffffffd &&
          ((*(char *)((int)piVar6 + 1) != *(char *)((int)piVar5 + 1) ||
           ((uVar1 != 0xfffffffe &&
            ((*(char *)((int)piVar6 + 2) != *(char *)((int)piVar5 + 2) ||
             ((uVar1 != 0xffffffff && (*(char *)((int)piVar6 + 3) != *(char *)((int)piVar5 + 3))))))
            ))))))) goto LAB_0069bd86;
    }
    *(undefined4 *)(param_2 + 0xb68) = 5;
    if ((*(int *)(param_2 + 0x188) != 0) && (cVar2 = FUN_006871f0(), cVar2 == '\0')) {
      FUN_00687220(0);
    }
    FUN_0069b950(param_2,uStack_28,uStack_24);
  }
  else {
LAB_0069bd86:
    FUN_006a5600();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_5 = CONCAT13(0x18,(undefined3)param_5);
    FUN_006a6060((int)&param_5 + 3,8,1);
    puVar3 = (undefined *)
             (**(code **)(*param_1 + 0xc0))
                       (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                        uRam01eae4d0,uRam01eae4d4,uRam01eae4d8);
    cVar2 = FUN_005fda50();
    if (cVar2 == '\0') {
      FUN_006a5c10(puVar3,auStack_18,8);
      puVar3 = auStack_18;
    }
    FUN_006a6060(puVar3,0x40,1);
    FUN_006a6920();
    param_5 = iStack_268 + 7U >> 3;
    uStack_20 = uStack_25c;
    FUN_005f70a0();
    FUN_005f7140();
    uVar7 = DAT_01d5b1f0;
    uVar8 = DAT_01d5b1f4;
    uVar9 = DAT_01d5b1f8;
    FUN_005f7170(param_3);
    FUN_006a1380(uStack_20,param_5,0,2,0,uVar7,uVar8,uVar9);
    *(undefined4 *)(param_2 + 0xb68) = 2;
    FUN_006a5640();
  }
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8475 ; VA 0x0069beb0 ; FUN_0069beb0 */

void __thiscall FUN_0069beb0(int *param_1)

{
  code *pcVar1;
  char cVar2;
  undefined8 *puVar3;
  char cStack00000024;
  undefined4 in_stack_00000028;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 in_stack_fffffe70;
  undefined4 uVar6;
  undefined4 in_stack_fffffe74;
  undefined4 in_stack_fffffe78;
  undefined4 in_stack_fffffe7c;
  undefined2 in_stack_fffffe80;
  undefined2 uVar7;
  undefined auStack_144 [8];
  undefined4 uStack_13c;
  undefined4 uStack_130;
  undefined8 uStack_28;
  undefined8 uStack_20;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar7 = (undefined2)((uint)in_stack_fffffe70 >> 0x10);
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a616b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  cVar2 = (**(code **)(*param_1 + 0x38))();
  if (cVar2 != '\0') {
    FUN_006a54a0(9);
    uStack_8 = 0;
    uStack_11 = 0;
    FUN_006a6060(&uStack_11,8,1);
    uStack_20 = FUN_006a6900();
    cVar2 = FUN_005fda50();
    if (cVar2 == '\0') {
      FUN_006a5c10(&uStack_20,&uStack_28,8);
      puVar3 = &uStack_28;
    }
    else {
      puVar3 = &uStack_20;
    }
    FUN_006a6060(puVar3,0x40,1);
    if (cStack00000024 == '\0') {
      pcVar1 = *(code **)(*param_1 + 0x4c);
      FUN_005f70a0();
      FUN_005f7140();
      uVar4 = DAT_01d5b1f0;
      uVar5 = DAT_01d5b1f4;
      uVar7 = DAT_01d5b1f8;
      FUN_005f7170(&stack0x00000004);
      (*pcVar1)(auStack_144,0,in_stack_00000028,0,uVar4,uVar5,uVar7);
    }
    else {
      FUN_006a6920();
      _cStack00000024 = uStack_130;
      FUN_005f70a0();
      FUN_005f7140();
      uVar6 = CONCAT22(uVar7,DAT_01d5b1f8);
      uVar4 = DAT_01d5b1f0;
      uVar5 = DAT_01d5b1f4;
      FUN_005f7170(&stack0x00000004);
      FUN_006a1380(_cStack00000024,uStack_13c,0,in_stack_00000028,0,uVar4,uVar5,uVar6,
                   in_stack_fffffe74,in_stack_fffffe78,in_stack_fffffe7c,in_stack_fffffe80);
    }
    FUN_006a5640();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8476 ; VA 0x0069c040 ; FUN_0069c040 */

uint FUN_0069c040(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 int param_9,int param_10,int param_11,undefined4 *param_12,int *param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  undefined auStack_168 [284];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [16];
  int iStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  iVar4 = param_11;
  iVar8 = param_10;
  puStack_c = &LAB_017a619b;
  pvStack_10 = ExceptionList;
  uVar7 = 0;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (((DAT_01d59d40 != '\0') && (ExceptionList = &pvStack_10, *(char *)(param_11 + 4) != '\0')) &&
     (ExceptionList = &pvStack_10, 4 < param_10)) {
    ExceptionList = &pvStack_10;
    FUN_006a6350(1,0);
    uStack_8 = 1;
    FUN_006a5530(param_9,iVar8,0);
    uStack_8 = 2;
    iVar6 = FUN_006a6530(auStack_2c,auStack_168);
    if (iVar6 != 0) {
      FUN_006a5640();
      uVar7 = FUN_006969c0();
      goto LAB_0069c202;
    }
    uStack_18 = FUN_006a6780();
    uStack_18 = uStack_18 & 0xffff;
    FUN_006a5640();
    uStack_8 = 0;
    FUN_006969c0();
    uVar7 = uStack_18;
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    param_13[1] = param_13[1] + 1;
    UNLOCK();
  }
  iVar8 = iVar8 - (uVar7 & 0xffff);
  iStack_1c = (uVar7 & 0xffff) + param_9;
  uVar7 = FUN_0069c240(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,iStack_1c,
                       iVar8,iVar4,param_12,param_13,&cStack_11,param_14,param_15,uVar7);
  if ((char)uVar7 == '\0') {
    uStack_4c = param_1;
    uStack_48 = param_2;
    uStack_44 = param_3;
    uStack_40 = param_4;
    uStack_3c = param_5;
    uStack_38 = param_6;
    uStack_34 = param_7;
    uStack_30 = param_8;
    uVar7 = FUN_005f71d0(&DAT_01eae4bc);
    if ((char)uVar7 == '\0') {
      uVar7 = FUN_0069a270(&uStack_4c);
      if (uVar7 != 0xffffffff) {
        uVar7 = uVar7 * 0xb70;
        if (*(char *)(*(int *)(iVar4 + 0x234) + uVar7) == '\x01') {
          uVar7 = uVar7 + *(int *)(iVar4 + 0x234);
          uStack_18 = uVar7;
          if ((uVar7 != 0) && (cStack_11 == '\0')) {
            uVar7 = FUN_005fb8d0(iStack_1c,iVar8,&param_1,iVar4 + 0x2e4,
                                 *(undefined4 *)(uVar7 + 0xb40),*param_12,param_14,param_15,param_16
                                 ,*(char *)(uVar7 + 0xb60) != '\0',iVar4 + 0x6f8);
          }
        }
      }
    }
  }
LAB_0069c202:
  piVar5 = param_13;
  if (param_13 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_13 + 1);
    uVar3 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar7 = (**(code **)*param_13)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar7 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 8477 ; VA 0x0069c240 ; FUN_0069c240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_0069c240(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 char *param_9,uint param_10,int *param_11,undefined4 *param_12,int *param_13,
                 char *param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17)

{
  int *piVar1;
  uint uVar2;
  char *pcVar3;
  char cVar4;
  byte bVar5;
  undefined2 uVar6;
  undefined *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  uint uVar11;
  int *piVar12;
  uint uVar13;
  bool bVar14;
  undefined auStack_670 [1312];
  undefined auStack_150 [8];
  int iStack_148;
  undefined4 uStack_13c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [2];
  undefined uStack_21;
  undefined auStack_20 [4];
  uint uStack_1c;
  undefined auStack_18 [4];
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a6215;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_005f7b20(0,auStack_670,0x401,0x7c);
  piVar12 = param_11;
  cVar4 = (**(code **)(*param_11 + 0x8c))(auStack_670);
  pcVar3 = param_9;
  if (cVar4 != '\0') {
    FUN_006a5600();
    uStack_8 = 1;
    if ((DAT_01d59d40 != '\0') && (piVar12[0x1be] != 0)) {
      FUN_006a32d0(auStack_20);
      uStack_8 = 2;
      FUN_006a67e0(auStack_150);
      uStack_8 = 1;
      FUN_00550b30();
    }
    param_11 = (int *)CONCAT13(0x17,param_11._0_3_);
    FUN_006a6060((int)&param_11 + 3,8,1);
    FUN_006a5ee0(&DAT_018d94a4,0x10);
    puVar7 = (undefined *)
             (**(code **)(*piVar12 + 0xc0))
                       (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                        uRam01eae4d0,uRam01eae4d4,uRam01eae4d8);
    cVar4 = FUN_005fda50();
    if (cVar4 == '\0') {
      FUN_006a5c10(puVar7,auStack_20,8);
      puVar7 = auStack_20;
    }
    FUN_006a6060(puVar7,0x40,1);
    FUN_006952f0(*param_12,uStack_13c,iStack_148 + 7U >> 3,&param_1,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x11ea);
    FUN_006a5640();
    bVar5 = 1;
    goto LAB_0069cc03;
  }
  if (2 < (int)param_10) {
    cVar4 = *param_9;
    if (((cVar4 == '\x01') || (cVar4 == '\x02')) && (param_10 == 0x19)) {
      piVar12 = (int *)(param_9 + 9);
      pbStack_14 = (byte *)&DAT_018d94a4;
      uStack_1c = 0xc;
      do {
        if (*piVar12 != *(int *)pbStack_14) {
          bVar5 = (byte)*piVar12;
          bVar14 = bVar5 < *pbStack_14;
          if ((((bVar5 == *pbStack_14) &&
               (bVar14 = *(byte *)((int)piVar12 + 1) < pbStack_14[1],
               *(byte *)((int)piVar12 + 1) == pbStack_14[1])) &&
              (bVar14 = *(byte *)((int)piVar12 + 2) < pbStack_14[2],
              *(byte *)((int)piVar12 + 2) == pbStack_14[2])) &&
             (bVar14 = *(byte *)((int)piVar12 + 3) < pbStack_14[3],
             *(byte *)((int)piVar12 + 3) == pbStack_14[3])) {
            bVar14 = true;
          }
          else {
            bVar14 = (-(uint)bVar14 | 1) == 0;
          }
          goto LAB_0069c59f;
        }
        pbStack_14 = pbStack_14 + 4;
        piVar12 = piVar12 + 1;
        bVar14 = 3 < uStack_1c;
        uStack_1c = uStack_1c - 4;
      } while (bVar14);
      bVar14 = true;
LAB_0069c59f:
      *param_14 = bVar14;
      piVar12 = param_11;
      if (bVar14 != false) goto LAB_0069c5ac;
    }
    else {
      if (cVar4 == '\x1c') {
        if (0x1c < param_10) {
          piVar12 = (int *)(param_9 + 0x11);
          pbStack_14 = (byte *)&DAT_018d94a4;
          uStack_1c = 0xc;
          do {
            if (*piVar12 != *(int *)pbStack_14) goto LAB_0069c59d;
            pbStack_14 = pbStack_14 + 4;
            piVar12 = piVar12 + 1;
            bVar14 = 3 < uStack_1c;
            uStack_1c = uStack_1c - 4;
          } while (bVar14);
          bVar14 = true;
          goto LAB_0069c59f;
        }
      }
      else {
        if (cVar4 == '\r') {
          if (param_10 < 0x19) goto LAB_0069cbfb;
          piVar12 = (int *)(param_9 + 9);
          pbStack_14 = (byte *)&DAT_018d94a4;
          uStack_1c = 0xc;
          do {
            if (*piVar12 != *(int *)pbStack_14) goto LAB_0069c59d;
            pbStack_14 = pbStack_14 + 4;
            piVar12 = piVar12 + 1;
            bVar14 = 3 < uStack_1c;
            uStack_1c = uStack_1c - 4;
          } while (bVar14);
          bVar14 = true;
          goto LAB_0069c59f;
        }
        if ((((((cVar4 == '\x06') || (cVar4 == '\b')) ||
              ((cVar4 == '\x05' || ((cVar4 == '\a' || (cVar4 == '~')))))) || (cVar4 == '}')) ||
            (((((cVar4 == '{' || (cVar4 == 'x')) || (cVar4 == '\x11')) ||
              ((cVar4 == '\x14' || (cVar4 == '\x17')))) || (cVar4 == '\x12')))) || (cVar4 == '\x1a')
           ) {
LAB_0069c529:
          if (0x18 < param_10) {
            piVar12 = (int *)(param_9 + 1);
            pbStack_14 = (byte *)&DAT_018d94a4;
            uStack_1c = 0xc;
            do {
              if (*piVar12 != *(int *)pbStack_14) goto LAB_0069c59d;
              pbStack_14 = pbStack_14 + 4;
              piVar12 = piVar12 + 1;
              bVar14 = 3 < uStack_1c;
              uStack_1c = uStack_1c - 4;
            } while (bVar14);
            bVar14 = true;
            goto LAB_0069c59f;
          }
        }
        else if (cVar4 == '\v') {
          if (DAT_01d5b238 == 0) goto LAB_0069cbfb;
          goto LAB_0069c529;
        }
        if ((cVar4 == '\x19') && (param_10 == 0x1a)) {
          piVar12 = (int *)(param_9 + 2);
          pbStack_14 = (byte *)&DAT_018d94a4;
          uStack_1c = 0xc;
          do {
            if (*piVar12 != *(int *)pbStack_14) goto LAB_0069c59d;
            pbStack_14 = pbStack_14 + 4;
            piVar12 = piVar12 + 1;
            bVar14 = 3 < uStack_1c;
            uStack_1c = uStack_1c - 4;
          } while (bVar14);
          bVar14 = true;
          goto LAB_0069c59f;
        }
      }
LAB_0069cbfb:
      *param_14 = '\0';
    }
    bVar5 = 0;
    goto LAB_0069cc03;
  }
  *param_14 = '\x01';
LAB_0069c5ac:
  cVar4 = *param_9;
  if (((cVar4 == '\x02') || (cVar4 == '\x01')) && (param_10 == 0x19)) {
    if ((cVar4 == '\x01') || (cVar4 = FUN_006978a0(), cVar4 != '\0')) {
      FUN_006a5530(pcVar3,0x19,0);
      uStack_8 = 3;
      FUN_006a57e0(8);
      FUN_00695a10(auStack_18);
      FUN_006a5600();
      uStack_8 = 4;
      if ((DAT_01d59d40 != '\0') && (piVar12[0x1be] != 0)) {
        FUN_006a32d0(auStack_20);
        uStack_8 = 5;
        FUN_006a67e0(auStack_150);
        uStack_8 = 4;
        FUN_00550b30();
      }
      uStack_21 = 0x1c;
      FUN_006a6060(&uStack_21,8,1);
      FUN_00695af0(auStack_18);
      FUN_00695af0(piVar12 + 0x11c);
      FUN_006a5ee0(&DAT_018d94a4,0x10);
      FUN_00722910();
      uVar8 = (**(code **)(piVar12[5] + 8))();
      uVar9 = (**(code **)(piVar12[5] + 4))();
      FUN_006a5e80(uVar9,uVar8);
      FUN_00722920();
      FUN_006952f0(*param_12,uStack_13c,iStack_148 + 7U >> 3,&param_1,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0x123b);
      iVar10 = FUN_00697270(1,
                            "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                            ,0x123d);
      **(char **)(iVar10 + 0x38) = *param_9;
      FUN_005f7170(&param_1);
      *(undefined4 *)(iVar10 + 0x20) = DAT_01d5b1f0;
      *(undefined4 *)(iVar10 + 0x24) = DAT_01d5b1f4;
      *(undefined2 *)(iVar10 + 0x28) = DAT_01d5b1f8;
LAB_0069c74a:
      uVar6 = FUN_00699980(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,1);
      *(undefined2 *)(iVar10 + 0x1e) = uVar6;
      *(undefined2 *)(iVar10 + 0x28) = uVar6;
      FUN_00696d60(iVar10);
      FUN_006a5640();
      FUN_006a5640();
      bVar5 = 1;
      goto LAB_0069cc03;
    }
  }
  else if (cVar4 == '\x1c') {
    pbStack_14 = (byte *)(param_10 - 0x21);
    if (pbStack_14 < (byte *)0x190) {
      iVar10 = FUN_00697270(param_10 - 0x1c,
                            "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                            ,0x124f);
      FUN_006a5530(param_9,param_10,0);
      uStack_8 = 6;
      FUN_006a57f0(1);
      FUN_00695a10(auStack_2c);
      FUN_00695a10(iVar10 + 0x20);
      FUN_006a5530(*(undefined4 *)(iVar10 + 0x38),*(undefined4 *)(iVar10 + 0x30),0);
      uStack_8 = 7;
      FUN_006a5c00();
      param_11 = (int *)CONCAT13(0x1c,param_11._0_3_);
      FUN_006a6060((int)&param_11 + 3,8,1);
      uStack_1c = auStack_2c[0];
      FUN_005f80d0(&uStack_1c);
      FUN_006a5ee0(param_9 + 0x21,pbStack_14);
      FUN_005f7170(&param_1);
      goto LAB_0069c74a;
    }
  }
  else if (cVar4 == '\r') {
    if (param_10 - 0x1a < 399) {
      uStack_1c = param_10 - 0x19;
      param_11 = (int *)FUN_00697270(param_10 - 0x18,
                                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                     ,0x126a);
      FUN_006a5530(pcVar3,param_10,0);
      uStack_8 = 8;
      FUN_006a57f0(1);
      FUN_00695a10(param_11 + 8);
      piVar12 = param_11;
      if (pcVar3[0x19] == '\x1d') {
        param_11[0xc] = param_11[0xc] + -1;
        param_11[0xd] = param_11[0xc] << 3;
        *(undefined *)param_11[0xe] = 0x1d;
        FUN_0170c6f0(param_11[0xe] + 1,pcVar3 + 0x1a,uStack_1c - 1);
        piVar12 = param_11;
      }
      else {
        *(undefined *)param_11[0xe] = 0xd;
        FUN_0170c6f0(param_11[0xe] + 1,pcVar3 + 0x19,uStack_1c);
      }
      FUN_005f7170(&param_1);
      uVar6 = FUN_00699980(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,1);
      *(undefined2 *)((int)piVar12 + 0x1e) = uVar6;
      *(undefined2 *)(piVar12 + 10) = uVar6;
      FUN_00696d60(piVar12);
      FUN_006a5640();
      bVar5 = 1;
      goto LAB_0069cc03;
    }
  }
  else {
    bVar5 = DAT_01d5b238;
    if ((cVar4 == '\x06') || (cVar4 == '\b')) goto LAB_0069cc03;
    if (((cVar4 == '\x11') || (((cVar4 == '\x14' || (cVar4 == '\x17')) || (cVar4 == '\x12')))) ||
       (((cVar4 == '\x18' || (cVar4 == '\x1a')) || (cVar4 == '\x19')))) {
LAB_0069c9d0:
      FUN_006a5530(param_9,param_10,0);
      uStack_8 = 9;
      FUN_006a57f0(1);
      FUN_006a57f0(0x10);
      if (*pcVar3 == '\x19') {
        FUN_006a57f0(1);
      }
      FUN_005f70a0();
      FUN_00695a10(&uStack_34);
      if (DAT_01eae4ac != '\0') {
        FUN_01677520(DAT_01eae4ac,"RakNet: Bad Offline message received, message id : %u",*pcVar3);
      }
      param_11 = (int *)((uint)param_11 & 0xffffff);
      FUN_00722910();
      uVar13 = 0;
      do {
        uVar2 = piVar12[0xbd];
        if ((uint)piVar12[0xbe] < uVar2) {
          iVar10 = piVar12[0xbf] - uVar2;
        }
        else {
          iVar10 = -uVar2;
        }
        if ((uint)(piVar12[0xbe] + iVar10) <= uVar13) goto LAB_0069cb8e;
        uVar11 = uVar2 + uVar13;
        if ((uint)piVar12[0xbf] <= uVar11) {
          uVar11 = (uVar2 - piVar12[0xbf]) + uVar13;
        }
        uStack_1c = *(uint *)(piVar12[0xbc] + uVar11 * 4);
        if (*(int *)(uStack_1c + 0x15c) == 1) {
          cVar4 = FUN_005f71d0(&param_1);
          if (cVar4 != '\0') goto LAB_0069cb74;
        }
        uVar13 = uVar13 + 1;
      } while( true );
    }
    if (cVar4 == '\v') {
      if (DAT_01d5b238 != 0) goto LAB_0069c9d0;
    }
    else if (cVar4 == '\x05') {
      if (0x11 < (int)param_10) goto LAB_0069cc03;
    }
    else {
      if (cVar4 == '\a') goto LAB_0069cc03;
      if (cVar4 == '{') {
        FUN_006a3d70(param_9,param_10,&param_1,&param_12,param_17);
        bVar5 = 1;
        goto LAB_0069cc03;
      }
      if (cVar4 == '~') {
        FUN_006a35d0(param_9,param_10,&param_1,&param_12);
        bVar5 = 1;
        goto LAB_0069cc03;
      }
      if (cVar4 == 'x') {
        FUN_006a3fa0(param_9,param_10,&param_1,&param_12,param_17);
        bVar5 = 1;
        goto LAB_0069cc03;
      }
      if (cVar4 == '}') {
        FUN_006a3790(param_9,param_10,&param_1,&param_12,param_15,param_16);
        bVar5 = 1;
        goto LAB_0069cc03;
      }
    }
  }
LAB_0069cbf7:
  bVar5 = 1;
LAB_0069cc03:
  piVar12 = param_13;
  param_11 = (int *)CONCAT13(bVar5,param_11._0_3_);
  if (param_13 != (int *)0x0) {
    LOCK();
    iVar10 = param_13[1] + -1;
    param_13[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*param_13)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piVar12 + 4))();
      }
      ExceptionList = pvStack_10;
      return (uint)param_11 >> 0x18;
    }
  }
  ExceptionList = pvStack_10;
  return (uint)bVar5;
LAB_0069c59d:
  bVar14 = false;
  goto LAB_0069c59f;
LAB_0069cb74:
  param_11 = (int *)CONCAT13(1,param_11._0_3_);
  FUN_0069dd40(uVar13);
  FUN_00696cb0(1);
LAB_0069cb8e:
  FUN_00722920();
  if (param_11._3_1_ != '\0') {
    iVar10 = FUN_00697270(1,
                          "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                          ,0x12b8);
    **(char **)(iVar10 + 0x38) = *param_9;
    *(undefined4 *)(iVar10 + 0x34) = 8;
    FUN_005f7170(&param_1);
    *(undefined4 *)(iVar10 + 0x20) = uStack_34;
    *(undefined4 *)(iVar10 + 0x24) = uStack_30;
    *(undefined2 *)(iVar10 + 0x28) = (undefined2)auStack_2c[0];
    FUN_00696d60(iVar10);
  }
  FUN_006a5640();
  goto LAB_0069cbf7;
}



/* FUNCTION 8478 ; VA 0x0069cc60 ; FUN_0069cc60 */

void __thiscall FUN_0069cc60(int param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00722910();
  if (*(int *)(param_1 + 0x38) != 0) {
    *(undefined4 *)(*(int *)(param_1 + 0x2c) + *(int *)(param_1 + 0x34) * 4) = param_2;
    iVar3 = *(int *)(param_1 + 0x34) + 1;
    *(int *)(param_1 + 0x34) = iVar3;
    if (iVar3 == *(int *)(param_1 + 0x38)) {
      *(undefined4 *)(param_1 + 0x34) = 0;
      iVar3 = 0;
    }
    if (((iVar3 == *(int *)(param_1 + 0x30)) && (uVar4 = *(int *)(param_1 + 0x38) * 2, uVar4 != 0))
       && (lVar1 = (ulonglong)uVar4 * 4,
          iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)lVar1 >> 0x20) != 0) | (uint)lVar1),
          iVar3 != 0)) {
      uVar4 = 0;
      if (*(int *)(param_1 + 0x38) != 0) {
        do {
          *(undefined4 *)(iVar3 + uVar4 * 4) =
               *(undefined4 *)
                (*(int *)(param_1 + 0x2c) +
                ((*(int *)(param_1 + 0x30) + uVar4) % *(uint *)(param_1 + 0x38)) * 4);
          uVar4 = uVar4 + 1;
        } while (uVar4 < *(uint *)(param_1 + 0x38));
      }
      *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x38);
      *(undefined4 *)(param_1 + 0x30) = 0;
      *(int *)(param_1 + 0x38) = *(int *)(param_1 + 0x38) * 2;
      FUN_01674ea0(*(undefined4 *)(param_1 + 0x2c));
      *(int *)(param_1 + 0x2c) = iVar3;
    }
    FUN_00722920();
    return;
  }
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  *(undefined4 **)(param_1 + 0x2c) = puVar2;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 1;
  *puVar2 = param_2;
  *(undefined4 *)(param_1 + 0x38) = 0x10;
  FUN_00722920();
  return;
}



/* FUNCTION 8479 ; VA 0x0069cd50 ; FUN_0069cd50 */

void __thiscall FUN_0069cd50(int param_1,undefined4 *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uStack_8;
  
  puVar3 = param_2;
  if (param_2 != (undefined4 *)0x0) {
    if ((DAT_01d5b280 == '\0') && (uStack_8 = 0, *(int *)(param_1 + 0x2dc) != 0)) {
      do {
        (**(code **)(**(int **)(*(int *)(param_1 + 0x2d8) + uStack_8 * 4) + 0x4c))
                  (puVar3[0xe],puVar3[0xd],*puVar3,puVar3[1],puVar3[2],puVar3[3],puVar3[4],puVar3[5]
                   ,puVar3[6],puVar3[7]);
        uStack_8 = uStack_8 + 1;
      } while (uStack_8 < *(uint *)(param_1 + 0x2dc));
    }
    uStack_8 = 0;
    if (*(int *)(param_1 + 0x2e8) != 0) {
      do {
        (**(code **)(**(int **)(*(int *)(param_1 + 0x2e4) + uStack_8 * 4) + 0x4c))
                  (puVar3[0xe],puVar3[0xd],*puVar3,puVar3[1],puVar3[2],puVar3[3],puVar3[4],puVar3[5]
                   ,puVar3[6],puVar3[7]);
        uStack_8 = uStack_8 + 1;
      } while (uStack_8 < *(uint *)(param_1 + 0x2e8));
    }
    FUN_00722910();
    if ((char)param_3 == '\0') {
      FUN_005fe020(&param_2,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0xaef);
    }
    else {
      FUN_005fe020(&param_2,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0xaed);
      uVar1 = *(uint *)(param_1 + 0x65c);
      uVar7 = *(uint *)(param_1 + 0x660);
      iVar8 = uVar7 - uVar1;
      iVar4 = iVar8;
      if (uVar7 < uVar1) {
        iVar4 = (*(int *)(param_1 + 0x664) - uVar1) + uVar7;
      }
      if (iVar4 != 1) {
        if (uVar7 < uVar1) {
          iVar8 = (*(int *)(param_1 + 0x664) - uVar1) + uVar7;
        }
        param_3 = iVar8 + -2;
        while( true ) {
          iVar8 = iVar8 + -1;
          iVar4 = *(int *)(param_1 + 0x65c);
          uVar1 = *(uint *)(param_1 + 0x664);
          iVar2 = *(int *)(param_1 + 0x65c);
          iVar5 = iVar4 - uVar1;
          if ((uint)(iVar4 + param_3) < uVar1) {
            iVar5 = iVar2;
          }
          iVar6 = iVar2 - uVar1;
          if ((uint)(iVar4 + iVar8) < uVar1) {
            iVar6 = iVar2;
          }
          *(undefined4 *)(*(int *)(param_1 + 0x658) + (iVar6 + iVar8) * 4) =
               *(undefined4 *)(*(int *)(param_1 + 0x658) + (iVar5 + param_3) * 4);
          if (param_3 == 0) break;
          param_3 = param_3 + -1;
        }
        uVar1 = *(uint *)(param_1 + 0x65c);
        uVar7 = uVar1 - *(int *)(param_1 + 0x664);
        if (uVar1 < *(uint *)(param_1 + 0x664)) {
          uVar7 = uVar1;
        }
        *(undefined4 **)(*(int *)(param_1 + 0x658) + uVar7 * 4) = param_2;
        FUN_00722920();
        return;
      }
    }
    FUN_00722920();
  }
  return;
}



/* FUNCTION 8480 ; VA 0x0069cf10 ; FUN_0069cf10 */

undefined4 * __thiscall FUN_0069cf10(int *param_1,char param_2)

{
  uint *puVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 **ppuVar9;
  char *pcVar10;
  uint uVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 *puVar14;
  bool bVar15;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *apuStack_4c [2];
  undefined auStack_44 [8];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  undefined8 uStack_24;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a622b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01eadf38 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01eadf38,
                   "RakPeer has distributed %d packets to plugins since last debug time",
                   param_1[0x1bc]);
    }
    if (DAT_01d5b260 != '\0') {
      param_1[0x1bc] = 0;
      param_1[0x1bd] = 0;
    }
  }
  cVar5 = (**(code **)(*param_1 + 0x38))();
  if (cVar5 == '\0') {
    if ((param_2 != '\0') && (DAT_01eadf38 != '\0')) {
      FUN_016774b0(DAT_01eadf38,"RakPeer is NOT active, returning",0);
    }
    ExceptionList = pvStack_10;
    return (undefined4 *)0x0;
  }
  cStack_12 = DAT_01d5b168 <= param_1[0x121];
  if ((DAT_01d5b280 == '\0') && (uVar13 = 0, param_1[0xb7] != 0)) {
    do {
      (**(code **)(**(int **)(param_1[0xb6] + uVar13 * 4) + 0xc))();
      uVar13 = uVar13 + 1;
    } while (uVar13 < (uint)param_1[0xb7]);
  }
  uVar13 = 0;
  if (param_1[0xba] != 0) {
    do {
      (**(code **)(**(int **)(param_1[0xb9] + uVar13 * 4) + 0xc))();
      uVar13 = uVar13 + 1;
    } while (uVar13 < (uint)param_1[0xba]);
  }
  uStack_3c = 0xffff;
LAB_0069d030:
  do {
    cStack_11 = '\0';
    if (cStack_12 == '\0') {
LAB_0069d176:
      FUN_00722910();
      if (param_1[0x197] == param_1[0x198]) {
        puVar14 = (undefined4 *)0x0;
      }
      else {
        iVar6 = param_1[0x199];
        iVar7 = param_1[0x197] + 1;
        param_1[0x197] = iVar7;
        if (iVar7 == iVar6) {
          param_1[0x197] = 0;
          puVar14 = *(undefined4 **)(param_1[0x196] + -4 + iVar6 * 4);
        }
        else if (iVar7 == 0) {
          puVar14 = *(undefined4 **)(param_1[0x196] + -4 + iVar6 * 4);
        }
        else {
          puVar14 = *(undefined4 **)(param_1[0x196] + -4 + iVar7 * 4);
        }
      }
      puStack_1c = puVar14;
      puStack_18 = puVar14;
      FUN_00722920();
      cVar5 = cStack_11;
      if (puVar14 == (undefined4 *)0x0) {
        if (param_1[0x121] < DAT_01d5b168) {
          param_1[0x121] = param_1[0x121] + 1;
        }
        if ((param_2 != '\0') && (DAT_01eadf38 != '\0')) {
          FUN_016774b0(DAT_01eadf38,"PacketReturnQueue is empty, no work to do",0);
        }
        ExceptionList = pvStack_10;
        return (undefined4 *)0x0;
      }
    }
    else {
      iVar6 = 0x68c;
      if (DAT_01d5b250 != '\0') {
        iVar6 = 0x678;
      }
      if (*(int *)(iVar6 + (int)param_1) == 0) goto LAB_0069d176;
      if (DAT_01d5b250 == '\0') {
        puVar14 = (undefined4 *)param_1[0x19f];
        if (puVar14 != (undefined4 *)0x0) {
          puVar14 = (undefined4 *)*puVar14;
        }
        puVar14 = *(undefined4 **)
                   (*(int *)(puVar14[1] + (puVar14[2] - 1 & (uint)param_1[0x1a2] >> 2) * 4) +
                   (param_1[0x1a2] & 3U) * 4);
        piVar3 = param_1 + 0x1a3;
        *piVar3 = *piVar3 + -1;
        cVar5 = '\0';
        puStack_18 = puVar14;
        if (*piVar3 == 0) {
          param_1[0x1a2] = 0;
        }
        else {
          param_1[0x1a2] = param_1[0x1a2] + 1;
        }
      }
      else {
        piVar3 = (int *)param_1[0x19a];
        uStack_2c = CONCAT44(param_1[0x19d],(undefined4 *)uStack_2c);
        if (piVar3 == (int *)0x0) {
          iVar6 = 0;
        }
        else {
          iVar6 = *piVar3;
        }
        puStack_18 = (undefined4 *)
                     **(undefined4 **)
                       (*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & param_1[0x19d]) * 4);
        if ((param_1 == (int *)0xfffff998) || (piVar3 == (int *)0x0)) {
          iVar6 = 0;
        }
        else {
          iVar6 = *piVar3;
        }
        uStack_24 = CONCAT44(*(undefined4 *)
                              (*(int *)(*(int *)(iVar6 + 4) +
                                       (*(int *)(iVar6 + 8) - 1U & param_1[0x19d]) * 4) + 0xc),
                             (undefined4)uStack_24);
        if ((param_1 == (int *)0xfffff998) || (piVar3 == (int *)0x0)) {
          iVar6 = 0;
        }
        else {
          iVar6 = *piVar3;
        }
        iVar6 = *(int *)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & param_1[0x19d]) * 4);
        iVar7 = FUN_006a6900();
        puVar14 = (undefined4 *)param_1[0x19a];
        if (puVar14 != (undefined4 *)0x0) {
          puVar14 = (undefined4 *)*puVar14;
        }
        iVar4 = *(int *)(puVar14[1] + (puVar14[2] - 1 & param_1[0x19d]) * 4);
        FUN_006a4650(CONCAT31((int3)((uint)iVar4 >> 8),*(undefined *)(iVar4 + 8)),
                     iVar7 - *(int *)(iVar6 + 4),uStack_24._4_4_);
        piVar3 = param_1 + 0x19e;
        *piVar3 = *piVar3 + -1;
        puVar14 = puStack_18;
        cVar5 = '\x01';
        if (*piVar3 == 0) {
          param_1[0x19d] = 0;
        }
        else {
          param_1[0x19d] = param_1[0x19d] + 1;
        }
      }
    }
    cVar2 = *(char *)puVar14[0xe];
    if (((cVar2 == -0x76) || (cVar2 == '\x15')) || (cVar2 == '\x16')) {
      uStack_38 = CONCAT31(uStack_38._1_3_,cVar2 == -0x76);
      if (cStack_12 == '\0') {
        if (DAT_01d5b250 == '\0') {
          uVar13 = param_1[0x1a2];
          if (((param_1[0x1a3] + uVar13 & 3) == 0) &&
             ((uint)param_1[0x1a1] <= param_1[0x1a3] + 4U >> 2)) {
            FUN_006a2af0(1);
            uVar13 = param_1[0x1a2];
          }
          uVar13 = param_1[0x1a1] * 4 - 1U & uVar13;
          param_1[0x1a2] = uVar13;
          uVar13 = param_1[0x1a3] + uVar13;
          uStack_2c = CONCAT44(uVar13,(undefined4 *)uStack_2c);
          uStack_24 = CONCAT44(param_1[0x1a0],(undefined4)uStack_24);
          puStack_1c = (undefined4 *)((uVar13 >> 2 & param_1[0x1a1] - 1U) * 4);
          if (*(int *)((int)puStack_1c + param_1[0x1a0]) == 0) {
            uVar8 = FUN_01674e20(0x10);
            *(undefined4 *)((int)puStack_1c + param_1[0x1a0]) = uVar8;
            uStack_24 = CONCAT44(param_1[0x1a0],(undefined4)uStack_24);
            puVar14 = puStack_18;
          }
          *(undefined4 **)(*(int *)(uStack_24._4_4_ + (int)puStack_1c) + (uStack_2c._4_4_ & 3) * 4)
               = puVar14;
          param_1[0x1a3] = param_1[0x1a3] + 1;
        }
        else {
          uStack_24 = CONCAT44(param_1[0x19e],(undefined4)uStack_24);
          uVar8 = FUN_006a6900();
          uVar13 = param_1[0x19c];
          uStack_2c = CONCAT44(uVar8,(undefined4 *)uStack_2c);
          if (uVar13 <= param_1[0x19e] + 1U) {
            FUN_00617300(1);
            uVar13 = param_1[0x19c];
          }
          param_1[0x19d] = param_1[0x19d] & uVar13 - 1;
          puStack_1c = (undefined4 *)((param_1[0x19e] + param_1[0x19d] & param_1[0x19c] - 1U) * 4);
          iVar6 = param_1[0x19b];
          if (*(int *)((int)puStack_1c + iVar6) == 0) {
            uVar8 = FUN_01674e20(0x10);
            *(undefined4 *)((int)puStack_1c + param_1[0x19b]) = uVar8;
            iVar6 = param_1[0x19b];
            puVar14 = puStack_18;
          }
          puVar12 = *(undefined4 **)(iVar6 + (int)puStack_1c);
          puVar12[1] = uStack_2c._4_4_;
          *(undefined *)(puVar12 + 2) = (undefined)uStack_38;
          *puVar12 = puVar14;
          puVar12[3] = uStack_24._4_4_;
          param_1[0x19e] = param_1[0x19e] + 1;
        }
        goto LAB_0069d030;
      }
      if ((DAT_01d5b250 != '\0') && (cVar5 == '\0')) {
        FUN_006a4650(uStack_38,0,0);
      }
      param_1[0x121] = 0;
      cStack_12 = '\0';
    }
    if ((8 < (uint)puVar14[0xc]) && (*(char *)puVar14[0xe] == '\x1b')) {
      FUN_006a5530((char *)puVar14[0xe] + 1,8,0);
      uStack_8 = 0;
      cVar5 = FUN_005fda50();
      if (cVar5 == '\0') {
        cVar5 = FUN_006a5ae0(auStack_44,0x40,1);
        if (cVar5 != '\0') {
          FUN_006a5c10(auStack_44,&puStack_34,8);
        }
      }
      else {
        FUN_006a5ae0(&puStack_34,0x40,1);
      }
      uStack_6c = *puVar14;
      uStack_68 = puVar14[1];
      uStack_64 = puVar14[2];
      uStack_60 = puVar14[3];
      uStack_5c = puVar14[4];
      uStack_58 = puVar14[5];
      uStack_54 = puVar14[6];
      uStack_50 = puVar14[7];
      cVar5 = FUN_005f71d0(&DAT_01eae4bc);
      if ((((cVar5 == '\0') && (iVar6 = FUN_0069a270(&uStack_6c), iVar6 != -1)) &&
          (pcVar10 = (char *)(iVar6 * 0xb70 + param_1[0x8d]), *pcVar10 == '\x01')) &&
         (pcVar10 != (char *)0x0)) {
        iVar6 = 0;
        pcVar10 = pcVar10 + 0xac8;
        uStack_2c = uStack_2c & 0xffffffff;
        puStack_1c = (undefined4 *)0x0;
        uVar13 = 0xffff;
        do {
          uVar11 = (uint)*(ushort *)(pcVar10 + -8);
          uStack_24 = (ulonglong)uVar13 << 0x20;
          puVar12 = puStack_1c;
          puVar14 = puStack_18;
          if (*(ushort *)(pcVar10 + -8) == (ushort)uStack_3c) break;
          if (uVar11 < uVar13) {
            puStack_1c = *(undefined4 **)pcVar10;
            uStack_2c = CONCAT44(*(undefined4 *)(pcVar10 + 4),(undefined4 *)uStack_2c);
          }
          iVar6 = iVar6 + 1;
          pcVar10 = pcVar10 + 0x10;
          if (uVar13 <= uVar11) {
            uVar11 = uVar13;
          }
          uVar13 = uVar11;
          puVar12 = puStack_1c;
        } while (iVar6 < 5);
      }
      else {
        uStack_2c = 0;
        uStack_2c._0_4_ = (undefined4 *)0x0;
        puVar12 = (undefined4 *)uStack_2c;
      }
      bVar15 = puStack_34 < puVar12;
      puStack_34 = (undefined4 *)((int)puStack_34 - (int)puVar12);
      iStack_30 = (iStack_30 - uStack_2c._4_4_) - (uint)bVar15;
      FUN_006a5c40(0,0);
      cVar5 = FUN_005fda50();
      if (cVar5 == '\0') {
        FUN_006a5c10(&puStack_34,apuStack_4c,8);
        ppuVar9 = apuStack_4c;
      }
      else {
        ppuVar9 = &puStack_34;
      }
      FUN_006a6060(ppuVar9,0x40,1);
      uStack_8 = 0xffffffff;
      FUN_006a5640();
    }
    if (DAT_01d5b260 != '\0') {
      puVar1 = (uint *)(param_1 + 0x1bc);
      uVar13 = *puVar1;
      *puVar1 = *puVar1 + 1;
      param_1[0x1bd] = param_1[0x1bd] + (uint)(0xfffffffe < uVar13);
    }
    if (DAT_01d5b280 == '\0') {
      FUN_00697ef0(param_1 + 0xb6,puVar14);
    }
    FUN_00697ef0(param_1 + 0xb9,puVar14);
    if ((DAT_01d5b280 == '\0') && (uVar13 = 0, param_1[0xb7] != 0)) {
      do {
        iVar6 = (**(code **)(**(int **)(param_1[0xb6] + uVar13 * 4) + 0x10))(puStack_18);
        if (iVar6 == 0) goto LAB_0069d5e3;
        if (iVar6 == 2) goto LAB_0069d030;
        uVar13 = uVar13 + 1;
      } while (uVar13 < (uint)param_1[0xb7]);
    }
    uVar13 = 0;
    if (param_1[0xba] == 0) {
      ExceptionList = pvStack_10;
      return puStack_18;
    }
    while (iVar6 = (**(code **)(**(int **)(param_1[0xb9] + uVar13 * 4) + 0x10))(puStack_18),
          iVar6 != 0) {
      if (iVar6 == 2) goto LAB_0069d030;
      uVar13 = uVar13 + 1;
      if ((uint)param_1[0xba] <= uVar13) {
        ExceptionList = pvStack_10;
        return puStack_18;
      }
    }
LAB_0069d5e3:
    (**(code **)(*param_1 + 0x60))(puStack_18);
  } while( true );
}



/* FUNCTION 8481 ; VA 0x0069d640 ; FUN_0069d640 */

undefined4 FUN_0069d640(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01eae558);
  uStack_8 = 0;
  FUN_0151a220("RakNet::RecvFromLoop");
  iVar1 = param_1[1];
  uVar2 = *param_1;
  FUN_00722a20();
  while (*(char *)(iVar1 + 5) == '\0') {
    iVar5 = FUN_006975d0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                         ,0x16d0);
    if (iVar5 == 0) {
      FUN_00722890(0x1e);
    }
    else {
      *(undefined4 *)(iVar5 + 0x600) = uVar2;
      FUN_00695100(uVar2,iVar1,iVar5,(int *)(iVar5 + 0x5d4),iVar5 + 0x5d8,iVar5 + 0x5f8);
      if (*(int *)(iVar5 + 0x5d4) < 1) {
        FUN_00722910();
        FUN_0069dab0(iVar5,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                     ,0x16df);
        FUN_00722920();
      }
      else {
        FUN_00722910();
        if (*(int *)(iVar1 + 0x3a4) == 0) {
          piVar6 = (int *)FUN_01674e20(0x40);
          *(int **)(iVar1 + 0x398) = piVar6;
          *(undefined4 *)(iVar1 + 0x39c) = 0;
          *(undefined4 *)(iVar1 + 0x3a0) = 1;
          *piVar6 = iVar5;
          *(undefined4 *)(iVar1 + 0x3a4) = 0x10;
        }
        else {
          *(int *)(*(int *)(iVar1 + 0x398) + *(int *)(iVar1 + 0x3a0) * 4) = iVar5;
          *(int *)(iVar1 + 0x3a0) = *(int *)(iVar1 + 0x3a0) + 1;
          iVar5 = *(int *)(iVar1 + 0x3a0);
          if (iVar5 == *(int *)(iVar1 + 0x3a4)) {
            *(undefined4 *)(iVar1 + 0x3a0) = 0;
            iVar5 = 0;
          }
          if (((iVar5 == *(int *)(iVar1 + 0x39c)) &&
              (uVar7 = *(int *)(iVar1 + 0x3a4) * 2, uVar7 != 0)) &&
             (lVar3 = (ulonglong)uVar7 * 4,
             iVar5 = FUN_01674e20(-(uint)((int)((ulonglong)lVar3 >> 0x20) != 0) | (uint)lVar3),
             iVar5 != 0)) {
            uVar7 = *(uint *)(iVar1 + 0x3a4);
            uVar8 = 0;
            if (uVar7 != 0) {
              do {
                *(undefined4 *)(iVar5 + uVar8 * 4) =
                     *(undefined4 *)
                      (*(int *)(iVar1 + 0x398) +
                      ((*(int *)(iVar1 + 0x39c) + uVar8) % *(uint *)(iVar1 + 0x3a4)) * 4);
                uVar8 = uVar8 + 1;
                uVar7 = *(uint *)(iVar1 + 0x3a4);
              } while (uVar8 < uVar7);
            }
            *(uint *)(iVar1 + 0x3a0) = uVar7;
            *(undefined4 *)(iVar1 + 0x39c) = 0;
            *(uint *)(iVar1 + 0x3a4) = uVar7 * 2;
            FUN_01674ea0(*(undefined4 *)(iVar1 + 0x398));
            *(int *)(iVar1 + 0x398) = iVar5;
          }
        }
        FUN_00722920();
        FUN_007229d0();
      }
    }
  }
  FUN_00722a10();
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 8482 ; VA 0x0069d8a0 ; FUN_0069d8a0 */

void __thiscall FUN_0069d8a0(int param_1,undefined4 param_2,int param_3)

{
  undefined4 *puVar1;
  ushort uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_3 * 0xb70;
  puVar1 = (undefined4 *)(*(int *)(param_1 + 0x234) + 4 + iVar7);
  uStack_24 = *puVar1;
  uStack_20 = puVar1[1];
  uStack_1c = puVar1[2];
  uStack_18 = puVar1[3];
  puVar1 = (undefined4 *)(*(int *)(param_1 + 0x234) + 0x14 + iVar7);
  uStack_14 = *puVar1;
  uStack_10 = puVar1[1];
  uStack_c = puVar1[2];
  uStack_8 = puVar1[3];
  cVar3 = FUN_005f7260(&DAT_01eae4bc);
  if (cVar3 != '\0') {
    iVar4 = FUN_0069a270(&uStack_24);
    if (iVar4 == -1) {
      iVar4 = 0;
    }
    else {
      iVar4 = iVar4 * 0xb70 + *(int *)(param_1 + 0x234);
    }
    if (iVar4 == *(int *)(param_1 + 0x234) + iVar7) {
      FUN_00698e90(&uStack_24);
    }
  }
  FUN_00698e90(param_2);
  FUN_005f7170(param_2);
  uVar5 = FUN_005f7a90(param_2);
  uVar2 = *(ushort *)(param_1 + 0xe);
  piVar6 = (int *)FUN_005f97b0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                               ,0xf52);
  iVar7 = (int)((ulonglong)uVar5 % ((ulonglong)uVar2 << 3)) * 4;
  iVar4 = *(int *)(iVar7 + *(int *)(param_1 + 0x244));
  if (iVar4 != 0) {
    for (iVar7 = *(int *)(iVar4 + 4); iVar7 != 0; iVar7 = *(int *)(iVar7 + 4)) {
      iVar4 = iVar7;
    }
    piVar6 = (int *)FUN_005f97b0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                 ,0xf61);
    *piVar6 = param_3;
    piVar6[1] = 0;
    *(int **)(iVar4 + 4) = piVar6;
    return;
  }
  piVar6[1] = 0;
  *piVar6 = param_3;
  *(int **)(iVar7 + *(int *)(param_1 + 0x244)) = piVar6;
  return;
}



/* FUNCTION 8483 ; VA 0x0069d9d0 ; FUN_0069d9d0 */

int __thiscall FUN_0069d9d0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_2 + 0x80);
  if (piVar1[1] != 0) {
    ((int *)*piVar1)[piVar1[1]] = param_2;
    piVar1[1] = piVar1[1] + 1;
    iVar3 = param_1[4] * -0xf0f0f0f;
    if ((piVar1[1] == (uint)param_1[4] / 0x88) && (3 < param_1[2])) {
      if (piVar1 == (int *)*param_1) {
        *param_1 = piVar1[3];
      }
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      param_1[2] = param_1[2] + -1;
      FUN_01674ea0(*piVar1);
      FUN_01674ea0(piVar1[2]);
      iVar3 = FUN_01674ea0(piVar1);
    }
    return iVar3;
  }
  *(int *)*piVar1 = param_2;
  piVar1[1] = piVar1[1] + 1;
  param_1[3] = param_1[3] + -1;
  *(int *)(piVar1[3] + 0x10) = piVar1[4];
  *(int *)(piVar1[4] + 0xc) = piVar1[3];
  if ((0 < param_1[3]) && (piVar1 == (int *)param_1[1])) {
    param_1[1] = ((int *)param_1[1])[3];
  }
  iVar2 = param_1[2];
  iVar3 = iVar2 + 1;
  param_1[2] = iVar3;
  if (iVar2 == 0) {
    *param_1 = (int)piVar1;
    piVar1[3] = (int)piVar1;
    piVar1[4] = (int)piVar1;
    return iVar3;
  }
  piVar1[3] = *param_1;
  piVar1[4] = *(int *)(*param_1 + 0x10);
  *(int **)(*(int *)(*param_1 + 0x10) + 0xc) = piVar1;
  iVar3 = *param_1;
  *(int **)(iVar3 + 0x10) = piVar1;
  return iVar3;
}



/* FUNCTION 8484 ; VA 0x0069dab0 ; FUN_0069dab0 */

int __thiscall FUN_0069dab0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_2 + 0x608);
  if (piVar1[1] != 0) {
    ((int *)*piVar1)[piVar1[1]] = param_2;
    piVar1[1] = piVar1[1] + 1;
    iVar3 = param_1[4] * 0x51d07eaf;
    if ((piVar1[1] == (uint)param_1[4] / 0x610) && (3 < param_1[2])) {
      if (piVar1 == (int *)*param_1) {
        *param_1 = piVar1[3];
      }
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      param_1[2] = param_1[2] + -1;
      FUN_01674ea0(*piVar1);
      FUN_01674ea0(piVar1[2]);
      iVar3 = FUN_01674ea0(piVar1);
    }
    return iVar3;
  }
  *(int *)*piVar1 = param_2;
  piVar1[1] = piVar1[1] + 1;
  param_1[3] = param_1[3] + -1;
  *(int *)(piVar1[3] + 0x10) = piVar1[4];
  *(int *)(piVar1[4] + 0xc) = piVar1[3];
  if ((0 < param_1[3]) && (piVar1 == (int *)param_1[1])) {
    param_1[1] = ((int *)param_1[1])[3];
  }
  iVar2 = param_1[2];
  iVar3 = iVar2 + 1;
  param_1[2] = iVar3;
  if (iVar2 == 0) {
    *param_1 = (int)piVar1;
    piVar1[3] = (int)piVar1;
    piVar1[4] = (int)piVar1;
    return iVar3;
  }
  piVar1[3] = *param_1;
  piVar1[4] = *(int *)(*param_1 + 0x10);
  *(int **)(*(int *)(*param_1 + 0x10) + 0xc) = piVar1;
  iVar3 = *param_1;
  *(int **)(iVar3 + 0x10) = piVar1;
  return iVar3;
}



/* FUNCTION 8485 ; VA 0x0069dba0 ; FUN_0069dba0 */

void __thiscall FUN_0069dba0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_2 + 0xc);
  if (piVar1[1] != 0) {
    ((int *)*piVar1)[piVar1[1]] = param_2;
    piVar1[1] = piVar1[1] + 1;
    if ((piVar1[1] == (uint)param_1[4] >> 4) && (3 < param_1[2])) {
      if (piVar1 == (int *)*param_1) {
        *param_1 = piVar1[3];
      }
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      param_1[2] = param_1[2] + -1;
      FUN_01674ea0(*piVar1);
      FUN_01674ea0(piVar1[2]);
      FUN_01674ea0(piVar1);
    }
    return;
  }
  *(int *)*piVar1 = param_2;
  piVar1[1] = piVar1[1] + 1;
  param_1[3] = param_1[3] + -1;
  *(int *)(piVar1[3] + 0x10) = piVar1[4];
  *(int *)(piVar1[4] + 0xc) = piVar1[3];
  if ((0 < param_1[3]) && (piVar1 == (int *)param_1[1])) {
    param_1[1] = ((int *)param_1[1])[3];
  }
  iVar2 = param_1[2];
  param_1[2] = iVar2 + 1;
  if (iVar2 == 0) {
    *param_1 = (int)piVar1;
    piVar1[3] = (int)piVar1;
    piVar1[4] = (int)piVar1;
    return;
  }
  piVar1[3] = *param_1;
  piVar1[4] = *(int *)(*param_1 + 0x10);
  *(int **)(*(int *)(*param_1 + 0x10) + 0xc) = piVar1;
  *(int **)(*param_1 + 0x10) = piVar1;
  return;
}



/* FUNCTION 8486 ; VA 0x0069dc80 ; FUN_0069dc80 */

void FUN_0069dc80(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1[2] != 0) {
    iVar1 = *param_1;
    if (iVar1 != 0) {
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),FUN_00550b30);
      FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
    }
    param_1[2] = 0;
    *param_1 = 0;
    param_1[1] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8487 ; VA 0x0069dd00 ; FUN_0069dd00 */

void __thiscall FUN_0069dd00(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  
  uVar2 = param_1[1];
  if (param_2 < uVar2) {
    if (param_2 < uVar2 - 1) {
      do {
        puVar1 = (undefined4 *)(*param_1 + param_2 * 4);
        param_2 = param_2 + 1;
        *puVar1 = puVar1[1];
        uVar2 = param_1[1];
      } while (param_2 < uVar2 - 1);
    }
    param_1[1] = uVar2 - 1;
  }
  return;
}



/* FUNCTION 8488 ; VA 0x0069dd40 ; FUN_0069dd40 */

void __thiscall FUN_0069dd40(int *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar2 = param_1[1];
  uVar4 = param_1[2];
  if (uVar2 != uVar4) {
    if (uVar4 < uVar2) {
      iVar1 = param_1[3] - uVar2;
    }
    else {
      iVar1 = -uVar2;
    }
    if (param_2 < uVar4 + iVar1) {
      uVar5 = param_1[3];
      uVar3 = uVar2 - uVar5;
      if (uVar2 + param_2 < uVar5) {
        uVar3 = uVar2;
      }
      param_2 = param_2 + uVar3;
      uVar2 = 0;
      if (param_2 + 1 != uVar5) {
        uVar2 = param_2 + 1;
      }
      if (uVar2 != uVar4) {
        do {
          uVar3 = uVar2;
          *(undefined4 *)(*param_1 + param_2 * 4) = *(undefined4 *)(*param_1 + uVar3 * 4);
          uVar5 = param_1[3];
          uVar4 = param_1[2];
          uVar2 = 0;
          if (uVar3 + 1 != uVar5) {
            uVar2 = uVar3 + 1;
          }
          param_2 = uVar3;
        } while (uVar2 != uVar4);
      }
      if (uVar4 != 0) {
        uVar5 = uVar4;
      }
      param_1[2] = uVar5 - 1;
    }
  }
  return;
}



/* FUNCTION 8489 ; VA 0x0069ddd0 ; FUN_0069ddd0 */

void __thiscall FUN_0069ddd0(int param_1,byte *param_2)

{
  undefined4 *puVar1;
  byte bVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  undefined4 *puVar7;
  uint uVar8;
  bool bVar9;
  
  if ((param_2 != (byte *)0x0) && (*param_2 != 0)) {
    pbVar6 = param_2;
    do {
      bVar2 = *pbVar6;
      pbVar6 = pbVar6 + 1;
    } while (bVar2 != 0);
    if ((uint)((int)pbVar6 - (int)(param_2 + 1)) < 0x10) {
      puVar7 = (undefined4 *)0x0;
      uVar8 = 0;
      FUN_00722910();
      if (*(int *)(param_1 + 0x2d0) != 0) {
        puVar7 = *(undefined4 **)(param_1 + 0x2cc);
        do {
          pbVar6 = *(byte **)*puVar7;
          pbVar4 = param_2;
          do {
            bVar2 = *pbVar4;
            bVar9 = bVar2 < *pbVar6;
            if (bVar2 != *pbVar6) {
LAB_0069de57:
              uVar5 = -(uint)bVar9 | 1;
              goto LAB_0069de5c;
            }
            if (bVar2 == 0) break;
            bVar2 = pbVar4[1];
            bVar9 = bVar2 < pbVar6[1];
            if (bVar2 != pbVar6[1]) goto LAB_0069de57;
            pbVar4 = pbVar4 + 2;
            pbVar6 = pbVar6 + 2;
          } while (bVar2 != 0);
          uVar5 = 0;
LAB_0069de5c:
          if (uVar5 == 0) {
            iVar3 = *(int *)(param_1 + 0x2cc);
            puVar7 = *(undefined4 **)(iVar3 + uVar8 * 4);
            *(undefined4 *)(iVar3 + uVar8 * 4) =
                 *(undefined4 *)(iVar3 + -4 + *(int *)(param_1 + 0x2d0) * 4);
            uVar8 = *(uint *)(param_1 + 0x2d0);
            uVar5 = *(int *)(param_1 + 0x2d0) - 1;
            if (uVar5 < uVar8) {
              if (uVar5 < uVar8 - 1) {
                do {
                  puVar1 = (undefined4 *)(*(int *)(param_1 + 0x2cc) + uVar5 * 4);
                  uVar5 = uVar5 + 1;
                  *puVar1 = puVar1[1];
                  uVar8 = *(uint *)(param_1 + 0x2d0);
                } while (uVar5 < uVar8 - 1);
              }
              *(uint *)(param_1 + 0x2d0) = uVar8 - 1;
            }
            goto LAB_0069dec5;
          }
          uVar8 = uVar8 + 1;
          puVar7 = puVar7 + 1;
        } while (uVar8 < *(uint *)(param_1 + 0x2d0));
        puVar7 = (undefined4 *)0x0;
      }
LAB_0069dec5:
      FUN_00722920();
      if (puVar7 != (undefined4 *)0x0) {
        FUN_01674ea0(*puVar7);
        FUN_01674ea0(puVar7,8);
      }
    }
  }
  return;
}



/* FUNCTION 8490 ; VA 0x0069def0 ; FUN_0069def0 */

void __thiscall FUN_0069def0(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x4b8) != 0) {
    if (param_2 == 0) {
      ExceptionList = &pvStack_10;
      FUN_00722910();
      if (*(int *)(param_1 + 0x4bc) != 0) {
        iVar1 = *(int *)(param_1 + 0x4b4);
        if (iVar1 != 0) {
          uStack_8 = 0;
          FUN_016f32d1(iVar1,4,*(undefined4 *)(iVar1 + -4),FUN_0071e0a0);
          FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 4 + 4);
          uStack_8 = 0xffffffff;
        }
        *(undefined4 *)(param_1 + 0x4bc) = 0;
        *(undefined4 *)(param_1 + 0x4b4) = 0;
        *(undefined4 *)(param_1 + 0x4b8) = 0;
      }
    }
    else {
      uVar4 = 0;
      ExceptionList = &pvStack_10;
      FUN_00722910();
      if (*(int *)(param_1 + 0x4b8) != 0) {
        do {
          cVar2 = FUN_0071e660(param_2);
          if (cVar2 == '\0') {
            uVar4 = uVar4 + 1;
          }
          else {
            FUN_0071e0d0(*(int *)(param_1 + 0x4b4) + (*(int *)(param_1 + 0x4b8) + -1) * 4);
            uVar3 = *(uint *)(param_1 + 0x4b8);
            uVar5 = *(int *)(param_1 + 0x4b8) - 1;
            if (uVar5 < uVar3) {
              if (uVar5 < uVar3 - 1) {
                do {
                  FUN_0071e0d0(*(int *)(param_1 + 0x4b4) + uVar5 * 4 + 4);
                  uVar3 = *(uint *)(param_1 + 0x4b8);
                  uVar5 = uVar5 + 1;
                } while (uVar5 < uVar3 - 1);
              }
              *(uint *)(param_1 + 0x4b8) = uVar3 - 1;
            }
          }
        } while (uVar4 < *(uint *)(param_1 + 0x4b8));
      }
    }
    FUN_00722920();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8491 ; VA 0x0069e070 ; FUN_0069e070 */

void __thiscall
FUN_0069e070(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  
  cVar1 = FUN_005f7260(&DAT_01eae4bc);
  if ((cVar1 != '\0') && (uVar3 = 0, *(short *)((int)param_1 + 0xe) != 0)) {
    while (cVar1 = FUN_005f71d0(&param_2), cVar1 == '\0') {
      uVar3 = uVar3 + 1;
      if (*(ushort *)((int)param_1 + 0xe) <= uVar3) {
        return;
      }
    }
    uVar2 = (**(code **)(*param_1 + 0xd8))
                      (param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
    FUN_005fed10(uVar2);
  }
  return;
}



/* FUNCTION 8492 ; VA 0x0069e110 ; FUN_0069e110 */

undefined4 __thiscall
FUN_0069e110(int *param_1,int param_2,int param_3,double param_4,undefined4 param_5)

{
  undefined uVar1;
  byte bVar2;
  undefined auVar3 [16];
  undefined auVar4 [16];
  undefined auVar5 [16];
  bool bVar6;
  byte *pbVar7;
  char cVar8;
  undefined2 uVar9;
  uint uVar10;
  int iVar11;
  undefined4 uVar12;
  double *pdVar13;
  uint *puVar14;
  uint uVar15;
  undefined4 *puVar16;
  uint uVar17;
  int *piVar18;
  char *pcVar19;
  code *pcVar20;
  char *pcVar21;
  int iVar22;
  double dVar23;
  double dVar24;
  double dVar25;
  undefined8 uVar26;
  longlong lVar27;
  undefined8 uVar28;
  undefined4 uVar29;
  undefined in_stack_fffff8b4 [16];
  undefined auVar30 [16];
  undefined auVar31 [14];
  double in_stack_fffff8c4;
  double in_stack_fffff8cc;
  double in_stack_fffff8d4;
  undefined8 uVar32;
  undefined4 uVar33;
  undefined4 uVar34;
  undefined4 uVar35;
  int iVar36;
  undefined4 uVar37;
  undefined *puVar38;
  undefined4 uVar39;
  undefined auStack_704 [672];
  undefined auStack_464 [76];
  undefined4 uStack_418;
  undefined4 uStack_40c;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined4 uStack_320;
  undefined4 uStack_31c;
  undefined4 uStack_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined auStack_300 [8];
  undefined auStack_2f8 [8];
  undefined auStack_2f0 [8];
  undefined auStack_2e8 [8];
  int iStack_2e0;
  int *piStack_2d4;
  int aiStack_1cc [2];
  undefined auStack_1c4 [8];
  undefined auStack_1bc [8];
  double dStack_1b4;
  double dStack_1ac;
  undefined auStack_1a4 [8];
  undefined auStack_19c [8];
  undefined auStack_194 [8];
  undefined auStack_18c [8];
  undefined auStack_184 [8];
  undefined auStack_17c [12];
  undefined auStack_170 [16];
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined2 uStack_158;
  int iStack_150;
  int iStack_14c;
  int iStack_148;
  int iStack_144;
  undefined auStack_140 [16];
  undefined auStack_130 [8];
  undefined auStack_128 [24];
  double dStack_110;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  uint uStack_f8;
  uint uStack_f4;
  uint uStack_f0;
  undefined auStack_ec [4];
  uint uStack_e8;
  undefined8 uStack_e4;
  double dStack_dc;
  undefined8 uStack_d4;
  double dStack_cc;
  double dStack_c4;
  undefined8 uStack_bc;
  undefined8 uStack_b4;
  int iStack_a4;
  int iStack_a0;
  undefined2 uStack_9c;
  undefined6 uStack_9a;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  undefined auStack_84 [16];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined auStack_64 [16];
  char *pcStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  uint uStack_44;
  undefined uStack_3f;
  char cStack_3e;
  char cStack_3d;
  int iStack_3c;
  char *pcStack_38;
  char cStack_31;
  byte *pbStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a62d9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_2c = param_1;
  FUN_005f7140();
  if (DAT_01d5b218 != '\0') {
    FUN_016830f0(&iStack_50);
    if ((*(char *)(param_1 + 0x1ba) != '\0') &&
       (dStack_dc = ((double)CONCAT44(iStack_4c,iStack_50) - *(double *)(param_1 + 0x1ac)) *
                    DAT_018c0d70, (double)DAT_01d5b188 < dStack_dc)) {
      dVar23 = *(double *)(param_1 + 0x1ae) * DAT_018c0d70;
      dVar24 = *(double *)(param_1 + 0x1b0) * DAT_018c0d70;
      dVar25 = *(double *)(param_1 + 0x1b2) * DAT_018c0d70;
      uStack_bc = *(double *)(param_1 + 0x1b4) * DAT_018c0d70;
      uStack_b4 = *(double *)(param_1 + 0x1b6) * DAT_018c0d70;
      uStack_e4 = *(double *)(param_1 + 0x1b8) * DAT_018c0d70;
      uStack_d4 = dVar23;
      dStack_cc = dVar24;
      dStack_c4 = dVar25;
      if (DAT_01ee420a != 0) {
        auVar30._8_8_ = dStack_dc;
        auVar30._0_8_ = 0x18d9f3800000000;
        in_stack_fffff8b4._4_12_ = auVar30._4_12_;
        in_stack_fffff8b4._0_4_ = CONCAT31(0,DAT_01ee420a);
        FUN_01677520(CONCAT31(0,DAT_01ee420a));
        in_stack_fffff8c4 = dVar23;
        in_stack_fffff8cc = dVar24;
        in_stack_fffff8d4 = dVar25;
      }
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0151fb00("TimeSinceLastCycleMs",SUB84(dStack_dc,0),(int)((ulonglong)dStack_dc >> 0x20));
      FUN_0151fb00("CycleStartToAfterBufferedHandlingMs",SUB84(uStack_d4,0),
                   (int)((ulonglong)uStack_d4 >> 0x20));
      FUN_0151fb00("CycleStartToAfterRequestConnectionMs",SUB84(dStack_cc,0),
                   (int)((ulonglong)dStack_cc >> 0x20));
      FUN_0151fb00("CycleStartToAfterDisconnectChecksMs",SUB84(dStack_c4,0),
                   (int)((ulonglong)dStack_c4 >> 0x20));
      FUN_0151fb00("CycleStartToAfterPingInternalMs",SUB84(uStack_bc,0),
                   (int)((ulonglong)uStack_bc >> 0x20));
      FUN_0151fb00("CycleStartToAfterReliableReceiveMs",SUB84(uStack_b4,0),
                   (int)((ulonglong)uStack_b4 >> 0x20));
      FUN_0151fb00("CycleStartToReturn",SUB84(uStack_e4,0),(int)((ulonglong)uStack_e4 >> 0x20));
      uVar12 = DAT_01eae4b8;
      FUN_0054eff0("LongRunUpdateCycle");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_01520d20(auStack_128,uVar12,0);
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    param_1[0x1ac] = iStack_50;
    param_1[0x1ad] = iStack_4c;
  }
  *(char *)(param_1 + 0x1ba) = DAT_01d5b218;
  do {
    if (DAT_01d5b200 == '\0') {
      if (param_1[0xe7] == param_1[0xe8]) {
        uStack_1c = (uint)param_4._4_4_;
        uStack_18 = param_4._0_4_;
        iStack_3c = param_3;
        iStack_20 = param_2;
        goto LAB_0069e595;
      }
      FUN_00722910();
      iVar11 = param_1[0xe7];
      if (iVar11 != param_1[0xe8]) goto LAB_0069e43b;
      iStack_20 = 0;
LAB_0069e464:
      FUN_00722920();
    }
    else {
      FUN_00722910();
      iVar11 = param_1[0xe7];
      if (iVar11 != param_1[0xe8]) {
LAB_0069e43b:
        iVar11 = iVar11 + 1;
        param_1[0xe7] = iVar11;
        iVar22 = param_1[0xe9];
        if (iVar11 == iVar22) {
          param_1[0xe7] = 0;
          iStack_20 = *(int *)(param_1[0xe6] + -4 + iVar22 * 4);
        }
        else if (iVar11 == 0) {
          iStack_20 = *(int *)(param_1[0xe6] + -4 + iVar22 * 4);
        }
        else {
          iStack_20 = *(int *)(param_1[0xe6] + -4 + iVar11 * 4);
        }
        goto LAB_0069e464;
      }
      FUN_00722920();
      iStack_20 = 0;
    }
    if (iStack_20 == 0) break;
    uVar10 = param_1[0x10f];
    uVar15 = 0;
    if (uVar10 != 0) {
      piStack_28 = (int *)param_1[0x10e];
      do {
        param_1 = piStack_2c;
        if (*(int *)piStack_28[uVar15 * 2] == *(int *)(iStack_20 + 0x600)) break;
        uVar15 = uVar15 + 1;
      } while (uVar15 < uVar10);
    }
    if (uVar15 != uVar10) {
      pcStack_38 = *(char **)(iStack_20 + 0x5d4);
      in_stack_fffff8b4 = *(undefined (*) [16])(iStack_20 + 0x5d8);
      iStack_48 = param_1[0x10e];
      in_stack_fffff8c4 = *(double *)(iStack_20 + 0x5e8);
      in_stack_fffff8cc = *(double *)(iStack_20 + 0x5f0);
      if (*(int *)(iStack_48 + 4 + uVar15 * 8) != 0) {
        LOCK();
        piVar18 = (int *)(*(int *)(iStack_48 + 4 + uVar15 * 8) + 4);
        *piVar18 = *piVar18 + 1;
        UNLOCK();
        param_1 = piStack_2c;
      }
      in_stack_fffff8d4 = (double)CONCAT44(pcStack_38,iStack_20);
      FUN_0069c040(in_stack_fffff8b4);
    }
    FUN_00722910();
    FUN_0069dab0(iStack_20,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x1392);
    FUN_00722920();
  } while( true );
  uStack_1c = (uint)param_4._4_4_;
  iStack_3c = param_3;
  uStack_18 = param_4._0_4_;
  iStack_20 = param_2;
  do {
    if (DAT_01d5b200 == '\0') {
LAB_0069e595:
      if (param_1[0xd2] == param_1[0xd3]) break;
      FUN_00722910();
      if (param_1[0xd2] == param_1[0xd3]) {
        piVar18 = (int *)0x0;
      }
      else {
        iVar11 = param_1[0xd2] + 1;
        param_1[0xd2] = iVar11;
        iVar22 = param_1[0xd4];
        if (iVar11 != iVar22) goto LAB_0069e5e7;
        param_1[0xd2] = 0;
        piVar18 = *(int **)(param_1[0xd1] + -4 + iVar22 * 4);
      }
LAB_0069e605:
      param_4 = (double)CONCAT44(piVar18,param_4._0_4_);
      FUN_00722920();
    }
    else {
      FUN_00722910();
      if (param_1[0xd2] != param_1[0xd3]) {
        iVar11 = param_1[0xd2] + 1;
        param_1[0xd2] = iVar11;
        iVar22 = param_1[0xd4];
        if (iVar11 == iVar22) {
          param_1[0xd2] = 0;
          piVar18 = *(int **)(param_1[0xd1] + -4 + iVar22 * 4);
        }
        else {
LAB_0069e5e7:
          if (iVar11 == 0) {
            piVar18 = *(int **)(param_1[0xd1] + -4 + iVar22 * 4);
          }
          else {
            piVar18 = *(int **)(param_1[0xd1] + -4 + iVar11 * 4);
          }
        }
        goto LAB_0069e605;
      }
      FUN_00722920();
      piVar18 = (int *)0x0;
      param_4 = (double)((ulonglong)param_4 & 0xffffffff);
    }
    auVar31 = in_stack_fffff8b4._2_14_;
    if (piVar18 == (int *)0x0) break;
    iVar11 = piVar18[0x1e];
    if (iVar11 == 0) {
      if (iStack_20 == 0 && iStack_3c == 0) {
        uVar26 = FUN_006a6920();
        iStack_3c = (int)((ulonglong)uVar26 >> 0x20);
        iStack_20 = (int)uVar26;
        uStack_18 = FUN_016f3c60(uVar26,1000,0);
        uStack_1c = 0;
      }
      uVar1 = *(undefined *)(piVar18 + 5);
      uVar15 = (uint)*(byte *)(piVar18 + 0x1d);
      uVar17 = (uint)*(byte *)(piVar18 + 0x12);
      piStack_28 = (int *)piVar18[4];
      iVar11 = piVar18[0x1c];
      iStack_48 = piVar18[3];
      pcStack_38 = (char *)piVar18[2];
      piStack_24 = (int *)piVar18[0x17];
      uVar10 = (uint)(*piVar18 == 0);
      iVar22 = iStack_20;
      iVar36 = iStack_3c;
      FUN_005f70a0();
      FUN_005f7140();
      uVar12 = *(undefined4 *)((int)param_4._4_4_ + 0x18);
      uVar29 = *(undefined4 *)((int)param_4._4_4_ + 0x1c);
      in_stack_fffff8b4._2_14_ = auVar31;
      in_stack_fffff8b4._0_2_ = *(undefined2 *)((int)param_4._4_4_ + 0x20);
      FUN_005f7170((int)param_4._4_4_ + 0x28);
      param_1 = piStack_2c;
      cVar8 = FUN_006a1380(piStack_24,pcStack_38,iStack_48,piStack_28,uVar1,uVar12,uVar29,
                           in_stack_fffff8b4,in_stack_fffff8c4,in_stack_fffff8cc,in_stack_fffff8d4,
                           uVar17,uVar10,iVar22,iVar36,iVar11,uVar15);
      piVar18 = param_4._4_4_;
      if ((*param_4._4_4_ == 0) && (cVar8 == '\0')) {
        FUN_01674ea0(param_4._4_4_[0x17]);
      }
      if (piVar18[0x13] != 0) {
        FUN_005f70a0();
        FUN_005f7140();
        iStack_a4 = *(int *)((int)param_4._4_4_ + 0x18);
        iStack_a0 = *(int *)((int)param_4._4_4_ + 0x1c);
        uStack_9c = *(undefined2 *)((int)param_4._4_4_ + 0x20);
        FUN_005f7170((int)param_4._4_4_ + 0x28);
        cVar8 = FUN_005f7240(&DAT_01d5b1f0);
        if (cVar8 == '\0') {
          in_stack_fffff8cc = (double)CONCAT44(iStack_90,iStack_94);
          in_stack_fffff8d4 = (double)CONCAT44(iStack_88,iStack_8c);
          in_stack_fffff8c4 = (double)CONCAT44(0x69e78f,SUB84(in_stack_fffff8c4,0));
          iVar11 = FUN_0069a190(iStack_94,iStack_90,iStack_8c,iStack_88,auStack_84._0_4_,
                                auStack_84._4_4_,auStack_84._8_4_,auStack_84._12_4_,1,1);
        }
        else {
          auVar3._4_4_ = iStack_a0;
          auVar3._0_4_ = iStack_a4;
          auVar3._8_2_ = uStack_9c;
          auVar3._10_6_ = uStack_9a;
          iVar11 = FUN_0069a100(iStack_a4,iStack_a0,auVar3._8_4_,(int)((uint6)uStack_9a >> 0x10),1);
        }
        piVar18 = param_4._4_4_;
        if (iVar11 != 0) {
          *(int *)(iVar11 + 0xb68) = param_4._4_4_[0x13];
        }
      }
    }
    else {
      if (iVar11 == 1) {
        if (DAT_01ee420a != 0) {
          FUN_016774b0(DAT_01ee420a,"Closing connection internally",0);
        }
        FUN_006988c0(piVar18 + 6,0,1,*(undefined *)(piVar18 + 5),piVar18[3]);
      }
      else if (iVar11 == 3) {
        FUN_005f70a0();
        FUN_005f7140();
        iStack_a4 = piVar18[6];
        iStack_a0 = piVar18[7];
        uStack_9c = *(undefined2 *)(piVar18 + 8);
        FUN_005f7170(&DAT_01eae4bc);
        cVar8 = FUN_005f7240(&DAT_01d5b1f0);
        if (cVar8 == '\0') {
          in_stack_fffff8cc = (double)CONCAT44(iStack_90,iStack_94);
          in_stack_fffff8d4 = (double)CONCAT44(iStack_88,iStack_8c);
          in_stack_fffff8c4 = (double)CONCAT44(0x69e87f,SUB84(in_stack_fffff8c4,0));
          iVar11 = FUN_0069a190(iStack_94,iStack_90,iStack_8c,iStack_88,auStack_84._0_4_,
                                auStack_84._4_4_,auStack_84._8_4_,auStack_84._12_4_,1,1);
        }
        else {
          auVar4._4_4_ = iStack_a0;
          auVar4._0_4_ = iStack_a4;
          auVar4._8_2_ = uStack_9c;
          auVar4._10_6_ = uStack_9a;
          iVar11 = FUN_0069a100(iStack_a4,iStack_a0,auVar4._8_4_,(int)((uint6)uStack_9a >> 0x10),1);
        }
        if (iVar11 != 0) {
          uVar12 = FUN_0069a270(iVar11 + 4);
          FUN_0069d8a0(piVar18 + 10,uVar12);
        }
      }
      else if (iVar11 == 2) {
        cVar8 = FUN_005f71b0(&DAT_01d5b1f0);
        if ((cVar8 == '\0') || (cVar8 = FUN_005f71d0(&DAT_01eae4bc), cVar8 == '\0')) {
          FUN_005f70a0();
          FUN_005f7140();
          iStack_a4 = piVar18[6];
          iStack_a0 = piVar18[7];
          uStack_9c = *(undefined2 *)(piVar18 + 8);
          FUN_005f7170(piVar18 + 10);
          cVar8 = FUN_005f7240(&DAT_01d5b1f0);
          if (cVar8 == '\0') {
            in_stack_fffff8cc = (double)CONCAT44(iStack_90,iStack_94);
            in_stack_fffff8d4 = (double)CONCAT44(iStack_88,iStack_8c);
            in_stack_fffff8c4 = (double)CONCAT44(0x69e998,SUB84(in_stack_fffff8c4,0));
            iVar11 = FUN_0069a190(iStack_94,iStack_90,iStack_8c,iStack_88,auStack_84._0_4_,
                                  auStack_84._4_4_,auStack_84._8_4_,auStack_84._12_4_,1,1);
          }
          else {
            auVar5._4_4_ = iStack_a0;
            auVar5._0_4_ = iStack_a4;
            auVar5._8_2_ = uStack_9c;
            auVar5._10_6_ = uStack_9a;
            iVar11 = FUN_0069a100(iStack_a4,iStack_a0,auVar5._8_4_,(int)((uint6)uStack_9a >> 0x10),1
                                 );
          }
          piStack_28 = (int *)FUN_00697730("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                           ,0x13d3);
          if (piStack_28[2] != 0) {
            iVar22 = *piStack_28;
            if (iVar22 != 0) {
              uStack_8 = 2;
              FUN_016f32d1(iVar22,8,*(undefined4 *)(iVar22 + -4),FUN_00550b30);
              FUN_01674ea0((int *)(iVar22 + -4),*(int *)(iVar22 + -4) * 8 + 4);
              uStack_8 = 0xffffffff;
            }
            piStack_28[2] = 0;
            *piStack_28 = 0;
            piStack_28[1] = 0;
          }
          piVar18 = piStack_28;
          if (iVar11 != 0) {
            FUN_0069b020(iVar11 + 0xb44,
                         "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                         ,0x13d8);
          }
          FUN_0069cc60(piVar18);
        }
        else {
          uVar12 = FUN_00697730("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                ,0x13cc);
          FUN_00696a40(piStack_2c + 0x10e);
          FUN_0069cc60(uVar12);
          param_1 = piStack_2c;
        }
      }
      piVar18 = param_4._4_4_;
    }
    piVar18 = (int *)piVar18[1];
    if (piVar18 != (int *)0x0) {
      LOCK();
      iVar11 = piVar18[1] + -1;
      piVar18[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piVar18)();
        LOCK();
        iVar11 = piVar18[2] + -1;
        piVar18[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar18 + 4))();
        }
      }
    }
    FUN_00722910();
    FUN_0069d9d0(param_4._4_4_,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x13e6);
    FUN_00722920();
  } while( true );
  if (DAT_01d5b218 != '\0') {
    pdVar13 = (double *)FUN_016830f0(&param_4);
    param_4 = *pdVar13 - *(double *)(param_1 + 0x1ac);
    *(double *)(param_1 + 0x1ae) = param_4;
  }
  if (DAT_01d5b200 == '\0') {
    cVar8 = param_1[0xbd] != param_1[0xbe];
  }
  else {
    FUN_00722910();
    param_4 = (double)CONCAT17(param_1[0xbd] != param_1[0xbe],param_4._0_7_);
    FUN_00722920();
    cVar8 = param_4._7_1_;
  }
  if (cVar8 != '\0') {
    if (iStack_20 == 0 && iStack_3c == 0) {
      uVar26 = FUN_006a6920();
      iStack_3c = (int)((ulonglong)uVar26 >> 0x20);
      iStack_20 = (int)uVar26;
      uStack_18 = FUN_016f3c60(uVar26,1000,0);
      uStack_1c = 0;
    }
    uVar10 = 0;
    uStack_44 = uVar10;
    while( true ) {
      FUN_00722910();
      uVar15 = param_1[0xbd];
      if ((uint)param_1[0xbe] < uVar15) {
        iVar11 = param_1[0xbf] - uVar15;
      }
      else {
        iVar11 = -uVar15;
      }
      if ((uint)(param_1[0xbe] + iVar11) <= uVar10) break;
      if ((uint)param_1[0xbf] <= uVar15 + uVar10) {
        uVar15 = uVar15 - param_1[0xbf];
      }
      pcVar21 = *(char **)(param_1[0xbc] + (uVar15 + uVar10) * 4);
      pcStack_14 = pcVar21;
      FUN_00722920();
      if ((uStack_1c < *(uint *)(pcVar21 + 0x24)) ||
         ((uStack_1c <= *(uint *)(pcVar21 + 0x24) && (uStack_18 <= *(uint *)(pcVar21 + 0x20))))) {
        uVar10 = uStack_44 + 1;
        uStack_44 = uVar10;
      }
      else {
        if (DAT_01eae4ac != '\0') {
          FUN_01677520(DAT_01eae4ac,
                       "RakNet : OpenRequest1 next request time triggered, requestsMade %u",
                       pcVar21[0x28]);
        }
        pcStack_38 = (char *)(*(int *)(pcVar21 + 0x13c) + 1);
        bVar2 = pcVar21[0x28];
        cVar8 = FUN_005f71d0(&DAT_01eae4bc);
        cVar8 = cVar8 == '\x01';
        param_4 = (double)CONCAT17(cVar8,param_4._0_7_);
        if (((char *)(uint)bVar2 == pcStack_38) || ((bool)cVar8)) {
          if (*(int *)(pcVar21 + 0x2c) != 0) {
            FUN_01674ea0(*(int *)(pcVar21 + 0x2c));
            pcVar21[0x2c] = '\0';
            pcVar21[0x2d] = '\0';
            pcVar21[0x2e] = '\0';
            pcVar21[0x2f] = '\0';
            cVar8 = param_4._7_1_;
          }
          if ((((char *)(uint)bVar2 == pcStack_38) && (cVar8 == '\0')) &&
             (*(int *)(pcVar21 + 0x15c) == 1)) {
            if (DAT_01eae4ac != '\0') {
              FUN_01677520(DAT_01eae4ac,
                           "RakNet : Too many attempts tries : timed out, inform failure");
            }
            iVar11 = FUN_00697270(1,
                                  "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                  ,0x141b);
            **(undefined **)(iVar11 + 0x38) = 0x11;
            *(undefined4 *)(iVar11 + 0x34) = 8;
            FUN_005f7170(pcStack_14);
            param_4 = (double)CONCAT44(iVar11,param_4._0_4_);
            FUN_00722910();
            FUN_005fe020((int)&param_4 + 4,
                         "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                         ,0x119f);
            FUN_00722920();
            pcVar21 = pcStack_14;
            FUN_00697e80(&LAB_00696bab,pcStack_14);
          }
          piVar18 = *(int **)(pcVar21 + 0x158);
          if (piVar18 != (int *)0x0) {
            LOCK();
            iVar11 = piVar18[1] + -1;
            piVar18[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              param_4._4_4_ = piVar18;
              (**(code **)*piVar18)();
              LOCK();
              iVar11 = param_4._4_4_[2] + -1;
              param_4._4_4_[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*param_4._4_4_ + 4))();
              }
            }
          }
          puVar16 = *(undefined4 **)(pcVar21 + 0x150);
          param_4 = (double)CONCAT44(puVar16,param_4._0_4_);
          if (puVar16 != (undefined4 *)0x0) {
            LOCK();
            iVar11 = puVar16[1] + -1;
            puVar16[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*puVar16)();
              LOCK();
              iVar11 = param_4._4_4_[2] + -1;
              param_4._4_4_[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*param_4._4_4_ + 4))();
              }
            }
          }
          FUN_01674ea0(pcVar21,0x160);
          FUN_00722910();
          piVar18 = (int *)param_1[0xbd];
          uVar10 = 0;
          param_3 = (int)piVar18 * 4;
          piStack_24 = piVar18;
          while( true ) {
            param_4 = (double)CONCAT44(uVar10,param_4._0_4_);
            if ((int *)param_1[0xbe] < piVar18) {
              uVar15 = (param_1[0xbf] - (int)piVar18) + param_1[0xbe];
            }
            else {
              uVar15 = param_1[0xbe] - (int)piVar18;
            }
            if (uVar15 <= uVar10) goto LAB_0069f1f6;
            piStack_28 = (int *)param_1[0xbf];
            iVar11 = param_3;
            if (piStack_28 <= piStack_24) {
              iVar11 = (int)((int)piVar18 + (uVar10 - (int)piStack_28)) * 4;
            }
            if (*(char **)(param_1[0xbc] + iVar11) == pcStack_14) break;
            param_3 = param_3 + 4;
            uVar10 = uVar10 + 1;
            piStack_24 = (int *)((int)piStack_24 + 1);
          }
          FUN_0069dd40(uVar10);
LAB_0069f1f6:
          FUN_00722920();
          uVar10 = uStack_44;
        }
        else {
          uVar10 = (uint)((ulonglong)(byte)pcVar21[0x28] /
                         ((ulonglong)*(uint *)(pcVar21 + 0x13c) / 3));
          FUN_006a5600();
          uStack_8 = 3;
          if ((DAT_01d59d40 != '\0') && (param_1[0x1be] != 0)) {
            FUN_006a67e0(auStack_2e8);
          }
          if (2 < uVar10) {
            uVar10 = 2;
          }
          if (DAT_01eae4ac != '\0') {
            FUN_016774b0(DAT_01eae4ac,"RakNet: Create OpenRequest1 with MTU %d",
                         (&DAT_018d9498)[uVar10]);
          }
          iVar11 = (&DAT_018d9498)[uVar10];
          param_4 = (double)CONCAT17(0x7b,param_4._0_7_);
          FUN_006a6060((int)&param_4 + 7,8,1);
          FUN_006a5ee0(&DAT_018d94a4,0x10);
          param_4 = (double)CONCAT17(5,param_4._0_7_);
          FUN_006a6060((int)&param_4 + 7,8,1);
          FUN_006a5860(iVar11 + -0x28);
          pcVar21 = pcStack_14;
          pcStack_14[0x28] = pcStack_14[0x28] + '\x01';
          *(uint *)(pcStack_14 + 0x20) = *(uint *)(pcStack_14 + 0x140) + uStack_18;
          *(uint *)(pcStack_14 + 0x24) = uStack_1c + CARRY4(*(uint *)(pcStack_14 + 0x140),uStack_18)
          ;
          if (*(int *)(pcStack_14 + 0x14c) == 0) {
            FUN_005f7320(*(int *)(param_1[0x10e] + *(int *)(pcStack_14 + 0x134) * 8) + 8);
            uVar12 = FUN_005f77a0();
            FUN_00695510(**(undefined4 **)(param_1[0x10e] + *(int *)(pcVar21 + 0x134) * 8),1,uVar12)
            ;
            uVar26 = FUN_006a6900();
            piStack_28 = (int *)((ulonglong)uVar26 >> 0x20);
            param_4 = (double)CONCAT44((int)uVar26,param_4._0_4_);
            if (DAT_01eae4ac != '\0') {
              FUN_016774b0(DAT_01eae4ac,"RakNet: Sending OpenRequest1",0);
            }
            iVar11 = FUN_006952f0(**(undefined4 **)(param_1[0x10e] + *(int *)(pcVar21 + 0x134) * 8),
                                  piStack_2d4,iStack_2e0 + 7U >> 3,pcVar21,
                                  "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                  ,0x1450);
            if (iVar11 == -0x2738) {
              if (DAT_01eae4ac != '\0') {
                FUN_016774b0(DAT_01eae4ac,"RakNet: Could not send OpenRequest1",0);
              }
              cVar8 = (char)(*(uint *)(pcVar21 + 0x13c) / 3) * ((char)uVar10 + '\x01');
              *(uint *)(pcVar21 + 0x20) = uStack_18;
              *(uint *)(pcVar21 + 0x24) = uStack_1c;
LAB_0069eec0:
              pcVar21[0x28] = cVar8;
            }
            else {
              lVar27 = FUN_006a6900();
              lVar27 = lVar27 - CONCAT44(piStack_28,param_4._4_4_);
              iVar11 = (int)((ulonglong)lVar27 >> 0x20);
              param_4 = (double)CONCAT44(iVar11,param_4._0_4_);
              if ((iVar11 != 0) || (100 < (uint)lVar27)) {
                uVar10 = (uint)((ulonglong)*(uint *)(pcVar21 + 0x13c) * 0xaaaaaaab >> 0x20) &
                         0xfffffffe;
                if ((int)uVar10 <= (int)(uint)(byte)pcVar21[0x28]) {
                  cVar8 = (char)*(uint *)(pcVar21 + 0x13c) + '\x01';
                  goto LAB_0069eec0;
                }
                *(uint *)(pcVar21 + 0x20) = uStack_18;
                pcVar21[0x28] = (char)uVar10;
                *(uint *)(pcVar21 + 0x24) = uStack_1c;
              }
            }
            uVar12 = FUN_005f77a0();
            puVar16 = *(undefined4 **)(param_1[0x10e] + *(int *)(pcVar21 + 0x134) * 8);
          }
          else {
            FUN_005f7320(*(int *)(pcStack_14 + 0x14c) + 8);
            uVar12 = FUN_005f77a0();
            FUN_00695510(**(undefined4 **)(pcVar21 + 0x14c),1,uVar12);
            uVar26 = FUN_006a6900();
            piStack_28 = (int *)((ulonglong)uVar26 >> 0x20);
            param_4 = (double)CONCAT44((int)uVar26,param_4._0_4_);
            if (DAT_01eae4ac != '\0') {
              FUN_016774b0(DAT_01eae4ac,"RakNet: Sending OpenRequest1",0);
            }
            iVar11 = FUN_006952f0(**(undefined4 **)(pcVar21 + 0x14c),piStack_2d4,
                                  iStack_2e0 + 7U >> 3,pcVar21,
                                  "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                  ,0x1470);
            if (iVar11 == -0x2738) {
              if (DAT_01eae4ac != '\0') {
                FUN_016774b0(DAT_01eae4ac,"RakNet: Could not send OpenRequest1",0);
              }
              cVar8 = (char)(*(uint *)(pcVar21 + 0x13c) / 3) * ((char)uVar10 + '\x01');
              *(uint *)(pcVar21 + 0x20) = uStack_18;
              *(uint *)(pcVar21 + 0x24) = uStack_1c;
LAB_0069effc:
              pcVar21[0x28] = cVar8;
            }
            else {
              lVar27 = FUN_006a6900();
              lVar27 = lVar27 - CONCAT44(piStack_28,param_4._4_4_);
              iVar11 = (int)((ulonglong)lVar27 >> 0x20);
              param_4 = (double)CONCAT44(iVar11,param_4._0_4_);
              if ((iVar11 != 0) || (100 < (uint)lVar27)) {
                uVar10 = (uint)((ulonglong)*(uint *)(pcVar21 + 0x13c) * 0xaaaaaaab >> 0x20) &
                         0xfffffffe;
                if ((int)uVar10 <= (int)(uint)(byte)pcVar21[0x28]) {
                  cVar8 = (char)*(uint *)(pcVar21 + 0x13c) + '\x01';
                  goto LAB_0069effc;
                }
                *(uint *)(pcVar21 + 0x20) = uStack_18;
                pcVar21[0x28] = (char)uVar10;
                *(uint *)(pcVar21 + 0x24) = uStack_1c;
              }
            }
            uVar12 = FUN_005f77a0();
            puVar16 = *(undefined4 **)(pcVar21 + 0x14c);
          }
          FUN_00695510(*puVar16,0,uVar12);
          uStack_8 = 0xffffffff;
          uVar10 = uStack_44 + 1;
          uStack_44 = uVar10;
          FUN_006a5640();
        }
      }
    }
    FUN_00722920();
  }
  if (DAT_01d5b218 != '\0') {
    pdVar13 = (double *)FUN_016830f0(&param_4);
    param_4 = *pdVar13 - *(double *)(param_1 + 0x1ac);
    *(double *)(param_1 + 0x1b0) = param_4;
  }
  pcVar21 = (char *)param_1[0x8f];
  cStack_31 = '\0';
  piVar18 = (int *)param_1[0x90];
  pcVar19 = (char *)0x0;
  if (pcVar21 != (char *)0x0) {
    do {
      if (pcVar21 <= (char *)((int)piVar18 + 1U)) {
        piVar18 = (int *)0xffffffff;
      }
      piStack_28 = (int *)((int)piVar18 + 1);
      pcStack_54 = pcVar19 + 1;
      pcVar21 = *(char **)(param_1[0x8e] + (int)piStack_28 * 4);
      piStack_24 = (int *)(pcVar21 + 4);
      pcStack_14 = pcVar21;
      FUN_005f7170(piStack_24);
      if (iStack_20 == 0 && iStack_3c == 0) {
        uVar26 = FUN_006a6920();
        iStack_3c = (int)((ulonglong)uVar26 >> 0x20);
        iStack_20 = (int)uVar26;
        uStack_18 = FUN_016f3c60(uVar26,1000,0);
        uStack_1c = 0;
      }
      if ((*(uint *)(pcVar21 + 0xb24) <= uStack_1c) &&
         ((*(uint *)(pcVar21 + 0xb24) < uStack_1c || (*(uint *)(pcVar21 + 0xb20) < uStack_18)))) {
        uVar10 = FUN_005fb8c0();
        if (((uStack_1c - *(int *)(pcVar21 + 0xb24) !=
              (uint)(uStack_18 < *(uint *)(pcVar21 + 0xb20))) ||
            (uVar10 >> 1 < uStack_18 - *(uint *)(pcVar21 + 0xb20))) &&
           (*(int *)(pcVar21 + 0xb68) == 7)) {
          uStack_32c = 0;
          uStack_328 = 0;
          uStack_324 = 0;
          uStack_320 = 0;
          uStack_31c = 0;
          uStack_318 = 0;
          uStack_314 = 0;
          uStack_310 = 0;
          iVar11 = FUN_005fb630(auStack_464);
          if (*(int *)(iVar11 + 200) == 0) {
            in_stack_fffff8c4 = (double)CONCAT44(0x69f3b9,SUB84(in_stack_fffff8c4,0));
            FUN_0069beb0(uStack_74,uStack_70,uStack_6c,uStack_68,auStack_64._0_4_,auStack_64._4_4_,
                         auStack_64._8_4_,auStack_64._12_4_,1,2);
            *(uint *)(pcVar21 + 0xb20) = uStack_18;
            *(uint *)(pcVar21 + 0xb24) = uStack_1c;
          }
        }
      }
      pcStack_38 = pcVar21 + 0x188;
      uVar32 = CONCAT44(*(undefined4 *)(pcVar21 + 0xb40),&uStack_74);
      uVar26 = CONCAT44(**(undefined4 **)(pcVar21 + 0xb44),0x69f408);
      cStack_3d = FUN_006001f0();
      uVar10 = *(uint *)(pcVar21 + 0xb28);
      if ((uStack_1c < *(uint *)(pcVar21 + 0xb2c)) ||
         ((uStack_1c <= *(uint *)(pcVar21 + 0xb2c) && (uStack_18 <= uVar10)))) {
LAB_0069f445:
        bVar6 = false;
      }
      else {
        iVar11 = (uStack_1c - *(int *)(pcVar21 + 0xb2c)) - (uint)(uStack_18 < uVar10);
        param_4 = (double)CONCAT44(iVar11,param_4._0_4_);
        if ((iVar11 == 0) && (uStack_18 - uVar10 < 0x2711)) goto LAB_0069f445;
        bVar6 = true;
      }
      iVar11 = *(int *)(pcVar21 + 0xb68);
      if (((iVar11 == 4) || (iVar11 == 5)) ||
         (param_4 = (double)((ulonglong)param_4 & 0xffffffffffffff), iVar11 == 6)) {
        param_4 = (double)CONCAT17(1,param_4._0_7_);
      }
      cVar8 = FUN_005fda40();
      if (((cVar8 != '\0') ||
          ((((*(int *)(pcVar21 + 0xb68) == 1 || (*(int *)(pcVar21 + 0xb68) == 2)) &&
            (cVar8 = FUN_005fdb20(), cVar8 == '\0')) ||
           ((*(int *)(pcVar21 + 0xb68) == 3 &&
            ((cVar8 = FUN_005f9a60(), cVar8 == '\0' ||
             (cVar8 = FUN_005f9560(uStack_18,uStack_1c), cVar8 == '\x01')))))))) ||
         ((param_4._7_1_ != '\0' && (bVar6)))) {
        iVar11 = *(int *)(pcVar21 + 0xb68);
        if ((iVar11 != 1) && (iVar11 != 2)) {
          if (iVar11 == 3) {
            param_4 = (double)((ulonglong)param_4 & 0xffffffff);
            dVar23 = param_4;
            if (param_1[0xba] != 0) {
              param_4._4_4_ = (int *)0x0;
              uVar10 = (uint)param_4._4_4_;
              param_4 = dVar23;
              do {
                FUN_00696bbf(piStack_24);
                uVar10 = uVar10 + 1;
                pcVar21 = pcStack_14;
              } while (uVar10 < (uint)param_1[0xba]);
            }
            if ((DAT_01d5b280 == '\0') &&
               (param_4 = (double)((ulonglong)param_4 & 0xffffffff), dVar23 = param_4,
               param_1[0xb7] != 0)) {
              param_4._4_4_ = (int *)0x0;
              uVar10 = (uint)param_4._4_4_;
              param_4 = dVar23;
              do {
                FUN_00696bbf(piStack_24);
                uVar10 = uVar10 + 1;
                pcVar21 = pcStack_14;
              } while (uVar10 < (uint)param_1[0xb7]);
            }
          }
          else {
            cVar8 = FUN_005fda40();
            if (cVar8 == '\0') {
              if ((param_4._7_1_ == '\0') || (!bVar6)) goto LAB_006a0605;
              puVar38 = &LAB_00696bb5;
            }
            else {
              puVar38 = &LAB_00696bba;
            }
            FUN_00697e80(puVar38,pcVar21 + 4);
          }
        }
LAB_006a0605:
        iVar11 = *(int *)(pcVar21 + 0xb68);
        if ((((iVar11 == 7) || (iVar11 == 4)) || (iVar11 == 1)) || (iVar11 == 3)) {
          if ((DAT_01ee420a != 0) &&
             (FUN_016774b0(DAT_01ee420a,"Connection lost",0), DAT_01ee420a != 0)) {
            FUN_006a3030(*(undefined4 *)(pcVar21 + 0xb68));
            FUN_01677520();
            if (DAT_01ee420a != 0) {
              cVar8 = FUN_005fdb20();
              param_4 = (double)(ulonglong)CONCAT14(cVar8 != '\0',param_4._0_4_);
              cVar8 = FUN_005f9560(uStack_18,uStack_1c);
              FUN_01677490(DAT_01ee420a,"Connection lost: AckTimeout %d, IsOutgoingDataWaiting %d",
                           cVar8 != '\0',param_4._4_4_,0);
            }
          }
          FUN_00722910();
          iVar11 = FUN_00697300("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                ,0x1509);
          param_4._4_4_ = (int *)iVar11;
          FUN_00722920();
          iVar11 = (int)param_4._4_4_;
          FUN_005f7140();
          FUN_005f70a0();
          uVar12 = FUN_01674f30(1);
          pcVar21 = pcStack_14;
          *(undefined4 *)(iVar11 + 0x38) = uVar12;
          *(undefined4 *)(iVar11 + 0x30) = 1;
          *(undefined4 *)(iVar11 + 0x34) = 8;
          *(undefined *)(iVar11 + 0x3c) = 1;
          *(undefined4 *)(iVar11 + 0x20) = DAT_01d5b1f0;
          *(undefined4 *)(iVar11 + 0x24) = DAT_01d5b1f4;
          *(undefined2 *)(iVar11 + 0x28) = DAT_01d5b1f8;
          *(undefined *)(iVar11 + 0x3d) = 0;
          if (*(int *)(pcStack_14 + 0xb68) == 4) {
            if (DAT_01ee420a != 0) {
              FUN_016774b0(DAT_01ee420a,"Connection attempt failed",0);
            }
            **(undefined **)((int)param_4._4_4_ + 0x38) = 0x11;
          }
          else if (*(int *)(pcStack_14 + 0xb68) == 7) {
            if (DAT_01ee420a != 0) {
              FUN_016774b0(DAT_01ee420a,"Connection lost - Cannot contact server/client",0);
            }
            **(undefined **)((int)param_4._4_4_ + 0x38) = 0x16;
          }
          else {
            if (DAT_01d5a2c0 == '\0') {
              if (DAT_01ee420a != 0) {
                iVar11 = param_1[0x10d];
                goto LAB_006a07e0;
              }
            }
            else {
              iVar11 = param_1[0x10d];
              if ((iVar11 != 0x119) && (DAT_01ee420a != 0)) {
LAB_006a07e0:
                FUN_01677520(DAT_01ee420a,"Disconnection Notification. Reason: %d",iVar11);
              }
            }
            **(undefined **)((int)param_4._4_4_ + 0x38) = 0x15;
          }
          *(undefined4 *)((int)param_4._4_4_ + 0x20) = *(undefined4 *)(pcVar21 + 0xb30);
          *(undefined4 *)((int)param_4._4_4_ + 0x24) = *(undefined4 *)(pcVar21 + 0xb34);
          *(undefined2 *)((int)param_4._4_4_ + 0x28) = *(undefined2 *)(pcVar21 + 0xb38);
          FUN_005f7170(&uStack_74);
          uVar9 = *(undefined2 *)(pcVar21 + 0xb4c);
          *(undefined2 *)((int)param_4._4_4_ + 0x1e) = uVar9;
          *(undefined2 *)((int)param_4._4_4_ + 0x28) = uVar9;
          FUN_00722910();
          FUN_005fe020((int)&param_4 + 4,
                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0x119f);
          FUN_00722920();
        }
        FUN_005f70a0();
        FUN_005f7140();
        uStack_160 = DAT_01d5b1f0;
        uStack_15c = DAT_01d5b1f4;
        uStack_158 = DAT_01d5b1f8;
        FUN_005f7170(&uStack_74);
        FUN_006988c0(&uStack_160,0,1,0,3);
      }
      else {
        if (((cStack_3d == '\0') && (cStack_31 == '\0')) && ((int *)param_1[0x90] != piStack_28)) {
          param_1[0x90] = (int)piStack_28;
          cStack_31 = '\x01';
        }
        if (DAT_01d5b218 != '\0') {
          pdVar13 = (double *)FUN_016830f0(auStack_2f0);
          param_4 = *pdVar13 - *(double *)(param_1 + 0x1ac);
          *(double *)(param_1 + 0x1b2) = param_4;
        }
        if ((((*(int *)(pcVar21 + 0xb68) == 7) && (*(uint *)(pcVar21 + 0xb1c) <= uStack_1c)) &&
            ((*(uint *)(pcVar21 + 0xb1c) < uStack_1c || (*(uint *)(pcVar21 + 0xb18) < uStack_18))))
           && ((*(char *)(param_1 + 3) != '\0' || (*(short *)(pcVar21 + 2) == -1)))) {
          *(uint *)(pcVar21 + 0xb18) = uStack_18 + 5000;
          *(uint *)(pcVar21 + 0xb1c) = uStack_1c + (0xffffec77 < uStack_18);
          uVar26 = CONCAT44(uStack_70,uStack_74);
          uVar32 = CONCAT44(uStack_68,uStack_6c);
          in_stack_fffff8c4 = (double)CONCAT44(0x69f5a2,SUB84(in_stack_fffff8c4,0));
          FUN_0069beb0(uStack_74,uStack_70,uStack_6c,uStack_68,auStack_64._0_4_,auStack_64._4_4_,
                       auStack_64._8_4_,auStack_64._12_4_,1,0);
          FUN_007229d0();
        }
        if (DAT_01d5b218 != '\0') {
          pdVar13 = (double *)FUN_016830f0(auStack_2f8);
          param_4 = *pdVar13 - *(double *)(param_1 + 0x1ac);
          *(double *)(param_1 + 0x1b4) = param_4;
        }
        piStack_24 = (int *)FUN_005fe500(&pbStack_30);
        piVar18 = piStack_2c;
        while ((auVar31 = in_stack_fffff8b4._2_14_, piStack_2c = piVar18, piStack_24 != (int *)0x0
               && (bVar2 = *pbStack_30, bVar2 != 0x11))) {
          iVar11 = *(int *)(pcVar21 + 0xb68);
          uVar10 = (uint)((int)piStack_24 + 7) >> 3;
          param_4 = (double)CONCAT44(uVar10,param_4._0_4_);
          if (iVar11 == 6) {
            if (bVar2 != 9) {
              FUN_005f70a0();
              FUN_005f7140();
              uStack_160 = DAT_01d5b1f0;
              uStack_15c = DAT_01d5b1f4;
              uStack_158 = DAT_01d5b1f8;
              FUN_005f7170(&uStack_74);
              FUN_006988c0(&uStack_160,0,1,0,3);
              if (DAT_01d5b1e4 == '\0') {
                FUN_005f7b20(0,auStack_170,0x40,0x7c);
                pcVar20 = *(code **)(*piVar18 + 0x80);
                uVar12 = FUN_005fb8c0();
                puVar38 = auStack_170;
              }
              else {
                FUN_005f7b20(0,auStack_704,0x401,0x7c);
                pcVar20 = *(code **)(*piVar18 + 0x80);
                uVar12 = FUN_005fb8c0();
                puVar38 = auStack_704;
              }
              (*pcVar20)(puVar38,uVar12);
              FUN_01674ea0(pbStack_30);
              pcVar21 = pcStack_14;
              goto LAB_006a04e1;
            }
            FUN_0069bbf0(pcVar21,&uStack_74,pbStack_30,uVar10);
LAB_006a04d9:
            FUN_01674ea0(pbStack_30);
          }
          else {
            if (bVar2 == 9) {
              if (iVar11 == 4) {
                FUN_0069bbf0(pcVar21,&uStack_74,pbStack_30,uVar10);
              }
              else {
                FUN_006a5530(pbStack_30,uVar10,0);
                uStack_8 = 4;
                FUN_006a57f0(1);
                FUN_006a57f0(0x10);
                FUN_006a57f0(8);
                cVar8 = FUN_005fda50();
                if (cVar8 == '\0') {
                  cVar8 = FUN_006a5ae0(auStack_17c,0x40,1);
                  if (cVar8 != '\0') {
                    FUN_006a5c10(auStack_17c,&uStack_108,8);
                  }
                }
                else {
                  FUN_006a5ae0(&uStack_108,0x40,1);
                }
                FUN_0069b950(pcVar21,uStack_108,uStack_104);
                uStack_8 = 0xffffffff;
                FUN_006a5640();
              }
              goto LAB_006a04d9;
            }
            if ((bVar2 == 0x13) && (0x17 < uVar10)) {
              if (iVar11 == 5) {
                pcVar21[0xb68] = '\a';
                pcVar21[0xb69] = '\0';
                pcVar21[0xb6a] = '\0';
                pcVar21[0xb6b] = '\0';
                uVar26 = CONCAT44(uStack_70,uStack_74);
                uVar32 = CONCAT44(uStack_68,uStack_6c);
                in_stack_fffff8c4 = (double)CONCAT44(0x69f83b,SUB84(in_stack_fffff8c4,0));
                FUN_0069beb0(uStack_74,uStack_70,uStack_6c,uStack_68,auStack_64._0_4_,
                             auStack_64._4_4_,auStack_64._8_4_,auStack_64._12_4_,1,0);
                FUN_007229d0();
                FUN_006a5530(pbStack_30,param_4._4_4_,0);
                uStack_8 = 5;
                FUN_005f7140();
                FUN_006a57e0(8);
                FUN_00695a70(auStack_130);
                pcVar21 = pcVar21 + 0x46;
                iVar11 = 10;
                do {
                  FUN_006a5ae0(&cStack_3e,8,1);
                  if (cStack_3e == '\x04') {
                    pcVar21[-0xffffffff00000002] = '\x02';
                    pcVar21[-0xffffffff00000001] = '\0';
                    FUN_006a5ae0(&uStack_e8,0x20,1);
                    *(uint *)(pcVar21 + 2) = ~uStack_e8;
                    FUN_006a5ae0(pcVar21,0x10,1);
                    uVar9 = Ordinal_15(*(undefined2 *)pcVar21);
                    *(undefined2 *)(pcVar21 + 0x1a) = uVar9;
                  }
                  pcVar21 = pcVar21 + 0x20;
                  iVar11 = iVar11 + -1;
                } while (iVar11 != 0);
                cVar8 = FUN_005fda50();
                if (cVar8 == '\0') {
                  cVar8 = FUN_006a5ae0(auStack_184,0x40,1);
                  if (cVar8 != '\0') {
                    FUN_006a5c10(auStack_184,&uStack_e4,8);
                  }
                }
                else {
                  FUN_006a5ae0(&uStack_e4,0x40,1);
                }
                cVar8 = FUN_005fda50();
                if (cVar8 == '\0') {
                  cVar8 = FUN_006a5ae0(auStack_18c,0x40,1);
                  if (cVar8 != '\0') {
                    FUN_006a5c10(auStack_18c,&uStack_100,8);
                  }
                }
                else {
                  FUN_006a5ae0(&uStack_100,0x40,1);
                }
                piVar18 = piStack_2c;
                FUN_0069b870((undefined4)uStack_e4,uStack_e4._4_4_,uStack_100,uStack_fc,pcStack_14);
                FUN_005f7170(auStack_130);
                FUN_005f7170(auStack_130);
                uVar9 = Ordinal_15(*(undefined2 *)((int)piVar18 + 0x48e));
                pbVar7 = pbStack_30;
                *(undefined2 *)(piVar18 + 0x12a) = uVar9;
                FUN_00722910();
                iVar11 = FUN_00697300("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                      ,0x15c9);
                FUN_00722920();
                FUN_005f7140();
                FUN_005f70a0();
                *(byte **)(iVar11 + 0x38) = pbVar7;
                *(int **)(iVar11 + 0x30) = param_4._4_4_;
                *(int *)(iVar11 + 0x34) = (int)param_4._4_4_ << 3;
                *(undefined *)(iVar11 + 0x3c) = 1;
                *(undefined4 *)(iVar11 + 0x20) = DAT_01d5b1f0;
                *(undefined4 *)(iVar11 + 0x24) = DAT_01d5b1f4;
                *(undefined2 *)(iVar11 + 0x28) = DAT_01d5b1f8;
                *(int **)(iVar11 + 0x34) = piStack_24;
                *(undefined *)(iVar11 + 0x3d) = 0;
                FUN_005f7170(&uStack_74);
                piVar18 = piStack_2c;
                param_4 = (double)CONCAT44(iVar11,param_4._0_4_);
                *(undefined2 *)(iVar11 + 0x1e) = *(undefined2 *)(pcStack_14 + 0xb4c);
                *(undefined4 *)(iVar11 + 0x20) = *(undefined4 *)(pcStack_14 + 0xb30);
                *(undefined4 *)(iVar11 + 0x24) = *(undefined4 *)(pcStack_14 + 0xb34);
                *(undefined2 *)(iVar11 + 0x28) = *(undefined2 *)(pcStack_14 + 0xb38);
                *(undefined2 *)(iVar11 + 0x28) = *(undefined2 *)(iVar11 + 0x1e);
                FUN_00722910();
                FUN_005fe020((int)&param_4 + 4,
                             "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                             ,0x119f);
                FUN_00722920();
LAB_0069fdb1:
                uStack_8 = 0xffffffff;
                FUN_006a5640();
                pcVar21 = pcStack_14;
              }
            }
            else {
              if ((bVar2 != 3) || (uVar10 != 0x11)) {
                if ((bVar2 == 0) && (uVar10 == 9)) {
                  FUN_006a5530(pbStack_30,9,0);
                  uStack_8 = 7;
                  FUN_006a57e0(8);
                  cVar8 = FUN_005fda50();
                  if (cVar8 == '\0') {
                    cVar8 = FUN_006a5ae0(auStack_1a4,0x40,1);
                    if (cVar8 != '\0') {
                      FUN_006a5c10(auStack_1a4,&dStack_c4,8);
                    }
                  }
                  else {
                    FUN_006a5ae0(&dStack_c4,0x40,1);
                  }
                  FUN_006a5600();
                  uStack_8 = CONCAT31(uStack_8._1_3_,8);
                  param_4 = (double)CONCAT17(3,param_4._0_7_);
                  FUN_006a6060((int)&param_4 + 7,8,1);
                  cVar8 = FUN_005fda50();
                  if (cVar8 == '\0') {
                    FUN_006a5c10(&dStack_c4,&dStack_1ac,8);
                    pdVar13 = &dStack_1ac;
                  }
                  else {
                    pdVar13 = &dStack_c4;
                  }
                  FUN_006a6060(pdVar13,0x40,1);
                  dStack_cc = (double)FUN_006a6900();
                  cVar8 = FUN_005fda50();
                  if (cVar8 == '\0') {
                    FUN_006a5c10(&dStack_cc,&dStack_1b4,8);
                    pdVar13 = &dStack_1b4;
                  }
                  else {
                    pdVar13 = &dStack_cc;
                  }
                  FUN_006a6060(pdVar13,0x40,1);
                  uVar28 = FUN_006a6920();
                  uVar12 = uStack_40c;
                  uVar39 = 0;
                  uVar37 = 0;
                  uVar35 = 0;
                  uVar33 = 0;
                  param_4 = (double)CONCAT44(uStack_418,param_4._0_4_);
                  FUN_005f70a0();
                  FUN_005f7140();
                  in_stack_fffff8b4._2_14_ = auVar31;
                  in_stack_fffff8b4._0_2_ = DAT_01d5b1f8;
                  uVar29 = DAT_01d5b1f0;
                  uVar34 = DAT_01d5b1f4;
                  FUN_005f7170(&uStack_74);
                  piVar18 = piStack_2c;
                  FUN_006a1380(uVar12,param_4._4_4_,0,0,0,uVar29,uVar34,in_stack_fffff8b4,
                               in_stack_fffff8c4,uVar26,uVar32,uVar33,uVar35,uVar28,uVar37,uVar39);
                  FUN_007229d0();
                  FUN_01674ea0(pbStack_30);
                  FUN_006a5640();
                  goto LAB_0069fdb1;
                }
                if (bVar2 == 0x15) {
                  if ((int *)0x27 < piStack_24) {
                    FUN_006a5530(pbStack_30,uVar10,0);
                    uStack_8 = 9;
                    FUN_006a57e0(8);
                    cVar8 = FUN_005fda50();
                    if (cVar8 == '\0') {
                      cVar8 = FUN_006a5ae0(auStack_ec,0x20,1);
                      if (cVar8 != '\0') {
                        FUN_006a5c10(auStack_ec,&iStack_48,4);
                      }
                    }
                    else {
                      FUN_006a5ae0(&iStack_48,0x20,1);
                    }
                    piVar18[0x10d] = iStack_48;
                    if (((DAT_01d5a2c0 == '\0') || (iStack_48 != 0x119)) && (DAT_01ee420a != 0)) {
                      FUN_01677520(DAT_01ee420a,"Disconnect reason received: %d",iStack_48);
                    }
                    uStack_8 = 0xffffffff;
                    FUN_006a5640();
                  }
                  pcVar21[0xb68] = '\x03';
                  pcVar21[0xb69] = '\0';
                  pcVar21[0xb6a] = '\0';
                  pcVar21[0xb6b] = '\0';
                }
                else if ((bVar2 != 4) || (uVar10 != 1)) {
                  if (bVar2 == 0x18) {
                    if (iVar11 == 4) {
                      iVar11 = FUN_006971f0(uVar10,pbStack_30,
                                            "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                            ,0x1624);
                      *(int **)(iVar11 + 0x34) = piStack_24;
                      FUN_005f7170(&uStack_74);
                      param_4 = (double)CONCAT44(iVar11,param_4._0_4_);
                      *(undefined2 *)(iVar11 + 0x1e) = *(undefined2 *)(pcStack_14 + 0xb4c);
                      *(undefined4 *)(iVar11 + 0x20) = *(undefined4 *)(pcStack_14 + 0xb30);
                      *(undefined4 *)(iVar11 + 0x24) = *(undefined4 *)(pcStack_14 + 0xb34);
                      *(undefined2 *)(iVar11 + 0x28) = *(undefined2 *)(pcStack_14 + 0xb38);
                      *(undefined2 *)(iVar11 + 0x28) = *(undefined2 *)(iVar11 + 0x1e);
                      FUN_00722910();
                      FUN_005fe020((int)&param_4 + 4,
                                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                   ,0x119f);
                      FUN_00722920();
                      pcStack_14[0xb68] = '\x02';
                      pcStack_14[0xb69] = '\0';
                      pcStack_14[0xb6a] = '\0';
                      pcStack_14[0xb6b] = '\0';
                      pcVar21 = pcStack_14;
                      goto LAB_006a04e1;
                    }
                  }
                  else if (bVar2 == 0x10) {
                    if (0x19 < uVar10) {
                      if (((iVar11 == 5) || (iVar11 == 4)) || (*(char *)(piVar18 + 0x122) != '\0'))
                      {
                        bVar6 = true;
                      }
                      else {
                        bVar6 = false;
                      }
                      if (bVar6) {
                        FUN_005f7140();
                        FUN_006a5530(pbStack_30,param_4._4_4_,0);
                        uStack_8 = 10;
                        FUN_006a57e0(8);
                        FUN_00695a70(auStack_130);
                        FUN_005f7f10(&uStack_44);
                        pcVar21 = pcVar21 + 0x44;
                        iVar22 = 10;
                        do {
                          FUN_00695a70(pcVar21);
                          pcVar21 = pcVar21 + 0x20;
                          iVar22 = iVar22 + -1;
                        } while (iVar22 != 0);
                        cVar8 = FUN_005fda50();
                        if (cVar8 == '\0') {
                          cVar8 = FUN_006a5ae0(auStack_1bc,0x40,1);
                          if (cVar8 != '\0') {
                            FUN_006a5c10(auStack_1bc,&uStack_d4,8);
                          }
                        }
                        else {
                          FUN_006a5ae0(&uStack_d4,0x40,1);
                        }
                        cVar8 = FUN_005fda50();
                        if (cVar8 == '\0') {
                          cVar8 = FUN_006a5ae0(auStack_1c4,0x40,1);
                          if (cVar8 != '\0') {
                            FUN_006a5c10(auStack_1c4,&iStack_50,8);
                          }
                        }
                        else {
                          FUN_006a5ae0(&iStack_50,0x40,1);
                        }
                        pcVar21 = pcStack_14;
                        piVar18 = piStack_2c;
                        FUN_0069b870((undefined4)uStack_d4,uStack_d4._4_4_,iStack_50,iStack_4c,
                                     pcStack_14);
                        if (DAT_01eae4ac != '\0') {
                          FUN_016774b0(DAT_01eae4ac,"RakNet: App Level connection accepted!",0);
                        }
                        FUN_005f7170(auStack_130);
                        pcVar21[0xb68] = '\a';
                        pcVar21[0xb69] = '\0';
                        pcVar21[0xb6a] = '\0';
                        pcVar21[0xb6b] = '\0';
                        FUN_005f7170(auStack_130);
                        uVar9 = Ordinal_15(*(undefined2 *)((int)piVar18 + 0x48e));
                        *(undefined2 *)(piVar18 + 0x12a) = uVar9;
                        iVar22 = FUN_006971f0(param_4._4_4_,pbStack_30,
                                              "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                              ,0x1667);
                        *(int *)(iVar22 + 0x34) = (int)param_4._4_4_ * 8;
                        FUN_005f7170(&uStack_74);
                        uVar32 = CONCAT44(uStack_6c,uStack_70);
                        uVar26 = CONCAT44(uStack_74,0x6a015a);
                        uVar9 = FUN_00699980();
                        *(undefined2 *)(iVar22 + 0x1e) = uVar9;
                        param_4 = (double)CONCAT44(iVar22,param_4._0_4_);
                        *(undefined4 *)(iVar22 + 0x20) = *(undefined4 *)(pcStack_14 + 0xb30);
                        *(undefined4 *)(iVar22 + 0x24) = *(undefined4 *)(pcStack_14 + 0xb34);
                        *(undefined2 *)(iVar22 + 0x28) = *(undefined2 *)(pcStack_14 + 0xb38);
                        *(undefined2 *)(iVar22 + 0x28) = *(undefined2 *)(iVar22 + 0x1e);
                        FUN_00722910();
                        FUN_005fe020((int)&param_4 + 4,
                                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                     ,0x119f);
                        FUN_00722920();
                        FUN_006a5600();
                        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
                        param_4 = (double)CONCAT17(0x13,param_4._0_7_);
                        FUN_006a6060((int)&param_4 + 7,8,1);
                        FUN_00695b40(&uStack_74);
                        piVar18 = piVar18 + 0x130;
                        iVar22 = 10;
                        do {
                          if (DAT_01d5b1e4 == '\0') {
                            uStack_3f = FUN_005f77c0();
                            FUN_006a6060(&uStack_3f,8,1);
                            cVar8 = FUN_005f77c0();
                            if (cVar8 == '\x04') {
                              iStack_94 = *piVar18;
                              iStack_90 = piVar18[1];
                              iStack_8c = piVar18[2];
                              iStack_88 = piVar18[3];
                              param_4 = (double)CONCAT44(~piVar18[1],param_4._0_4_);
                              auStack_84 = *(undefined (*) [16])(piVar18 + 4);
                              FUN_006a6060((int)&param_4 + 4,0x20,1);
                              uStack_f8 = FUN_005f7820();
                              uStack_f8 = uStack_f8 & 0xffff;
                              puVar14 = &uStack_f8;
                              goto LAB_006a02e1;
                            }
                          }
                          else {
                            param_4 = (double)CONCAT17(4,param_4._0_7_);
                            FUN_006a6060((int)&param_4 + 7,8,1);
                            iStack_150 = *piVar18;
                            iStack_14c = piVar18[1];
                            iStack_148 = piVar18[2];
                            iStack_144 = piVar18[3];
                            uStack_f0 = ~piVar18[1];
                            auStack_140 = *(undefined (*) [16])(piVar18 + 4);
                            FUN_006a6060(&uStack_f0,0x20,1);
                            uStack_f4 = FUN_005f7820();
                            uStack_f4 = uStack_f4 & 0xffff;
                            puVar14 = &uStack_f4;
LAB_006a02e1:
                            FUN_006a6060(puVar14,0x10,1);
                          }
                          auVar31 = in_stack_fffff8b4._2_14_;
                          piVar18 = piVar18 + 8;
                          iVar22 = iVar22 + -1;
                        } while (iVar22 != 0);
                        cVar8 = FUN_005fda50();
                        if (cVar8 == '\0') {
                          FUN_006a5c10(&iStack_50,aiStack_1cc,8);
                          piVar18 = aiStack_1cc;
                        }
                        else {
                          piVar18 = &iStack_50;
                        }
                        FUN_006a6060(piVar18,0x40,1);
                        dStack_dc = (double)FUN_006a6900();
                        cVar8 = FUN_005fda50();
                        if (cVar8 == '\0') {
                          FUN_006a5c10(&dStack_dc,&dStack_110,8);
                          pdVar13 = &dStack_110;
                        }
                        else {
                          pdVar13 = &dStack_dc;
                        }
                        FUN_006a6060(pdVar13,0x40,1);
                        uVar28 = FUN_006a6920();
                        uVar37 = 0;
                        uVar35 = 0;
                        uVar33 = 0;
                        uVar34 = 0;
                        param_4 = (double)CONCAT44(iStack_2e0,param_4._0_4_);
                        piStack_24 = piStack_2d4;
                        FUN_005f70a0();
                        FUN_005f7140();
                        in_stack_fffff8b4._2_14_ = auVar31;
                        in_stack_fffff8b4._0_2_ = DAT_01d5b1f8;
                        uVar12 = DAT_01d5b1f0;
                        uVar29 = DAT_01d5b1f4;
                        FUN_005f7170(&uStack_74);
                        piVar18 = piStack_2c;
                        FUN_006a1380(piStack_24,param_4._4_4_,0,3,0,uVar12,uVar29,in_stack_fffff8b4,
                                     in_stack_fffff8c4,uVar26,uVar32,uVar34,uVar33,uVar28,uVar35,
                                     uVar37);
                        if (iVar11 != 5) {
                          uVar26 = CONCAT44(uStack_70,uStack_74);
                          uVar32 = CONCAT44(uStack_68,uStack_6c);
                          in_stack_fffff8c4 = (double)CONCAT44(0x6a041b,SUB84(in_stack_fffff8c4,0));
                          FUN_0069beb0(uStack_74,uStack_70,uStack_6c,uStack_68,auStack_64._0_4_,
                                       auStack_64._4_4_,auStack_64._8_4_,auStack_64._12_4_,1,0);
                        }
                        pcVar21 = pcStack_14;
                        if (DAT_01eace54 != 0) {
                          LOCK();
                          pcStack_14[0xb60] = '\x01';
                          UNLOCK();
                          uVar12 = FUN_006a6900();
                          *(undefined4 *)(pcVar21 + 0xb64) = uVar12;
                        }
                        FUN_006a5640();
                        uStack_8 = 0xffffffff;
                        FUN_006a5640();
                        goto LAB_006a04e1;
                      }
                    }
                  }
                  else if ((((0x1a < bVar2) || (bVar2 == 0xe)) || (bVar2 == 0xf)) &&
                          (*pcVar21 != '\0')) {
                    iVar11 = FUN_006971f0(uVar10,pbStack_30,
                                          "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                          ,0x169f);
                    *(int **)(iVar11 + 0x34) = piStack_24;
                    FUN_005f7170(&uStack_74);
                    *(undefined2 *)(iVar11 + 0x1e) = *(undefined2 *)(pcStack_14 + 0xb4c);
                    *(undefined4 *)(iVar11 + 0x20) = *(undefined4 *)(pcStack_14 + 0xb30);
                    *(undefined4 *)(iVar11 + 0x24) = *(undefined4 *)(pcStack_14 + 0xb34);
                    *(undefined2 *)(iVar11 + 0x28) = *(undefined2 *)(pcStack_14 + 0xb38);
                    *(undefined2 *)(iVar11 + 0x28) = *(undefined2 *)(iVar11 + 0x1e);
                    FUN_00696d60(iVar11);
                    pcVar21 = pcStack_14;
                    goto LAB_006a04e1;
                  }
                }
                goto LAB_006a04d9;
              }
              FUN_006a5530(pbStack_30,0x11,0);
              uStack_8 = 6;
              FUN_006a57e0(8);
              cVar8 = FUN_005fda50();
              if (cVar8 == '\0') {
                cVar8 = FUN_006a5ae0(auStack_194,0x40,1);
                if (cVar8 != '\0') {
                  FUN_006a5c10(auStack_194,&uStack_bc,8);
                }
              }
              else {
                FUN_006a5ae0(&uStack_bc,0x40,1);
              }
              cVar8 = FUN_005fda50();
              if (cVar8 == '\0') {
                cVar8 = FUN_006a5ae0(auStack_19c,0x40,1);
                if (cVar8 != '\0') {
                  FUN_006a5c10(auStack_19c,&uStack_b4,8);
                }
              }
              else {
                FUN_006a5ae0(&uStack_b4,0x40,1);
              }
              FUN_0069b870((undefined4)uStack_bc,uStack_bc._4_4_,(undefined4)uStack_b4,
                           uStack_b4._4_4_,pcVar21);
              FUN_01674ea0(pbStack_30);
              uStack_8 = 0xffffffff;
              FUN_006a5640();
            }
          }
LAB_006a04e1:
          piStack_24 = (int *)FUN_005fe500(&pbStack_30);
          param_1 = piVar18;
          piVar18 = piStack_2c;
        }
        if (DAT_01d5b218 != '\0') {
          pdVar13 = (double *)FUN_016830f0(auStack_300);
          param_4 = *pdVar13 - *(double *)(param_1 + 0x1ac);
          *(double *)(param_1 + 0x1b6) = param_4;
        }
      }
      pcVar21 = (char *)param_1[0x8f];
      piVar18 = piStack_28;
      pcVar19 = pcStack_54;
    } while (pcStack_54 < pcVar21);
  }
  if (DAT_01d5b218 != '\0') {
    pdVar13 = (double *)FUN_016830f0(&dStack_110);
    *(double *)(param_1 + 0x1b8) = *pdVar13 - *(double *)(param_1 + 0x1ac);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8493 ; VA 0x006a0930 ; FUN_006a0930 */

int __thiscall FUN_006a0930(int *param_1,int *param_2,int param_3,int param_4,undefined param_5)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  char in_stack_00000044;
  undefined3 uStack00000048;
  undefined uStack0000004b;
  int iStack_40;
  int iStack_3c;
  undefined2 uStack_38;
  undefined auStack_30 [32];
  int iStack_10;
  undefined uStack_c;
  int *piStack_8;
  
  iVar4 = (**(code **)(*(int *)*param_2 + 8))();
  if (((iVar4 == 0) || (param_1[0x8d] == 0)) || (*(char *)((int)param_1 + 5) != '\0')) {
    return 0;
  }
  if ((in_stack_00000044 == '\0') && (cVar3 = FUN_0069b550(), cVar3 != '\0')) {
    return 0;
  }
  if (_uStack00000048 == 0) {
    _uStack00000048 = (**(code **)(*param_1 + 0x44))();
  }
  iVar4 = _uStack00000048;
  if ((in_stack_00000044 == '\0') && (cVar3 = FUN_0069b470(&stack0x00000014,1), cVar3 != '\0')) {
    pcVar1 = *(code **)(*param_1 + 0x54);
    uVar5 = (**(code **)(*(int *)*param_2 + 8))();
    uVar6 = (**(code **)(*(int *)*param_2 + 4))();
    (*pcVar1)(uVar6,uVar5);
    if (4 < param_4) {
      iStack_10 = CONCAT31(iStack_10._1_3_,0xe);
      FUN_00722910();
      iStack_10._1_3_ = (undefined3)param_1[0x1aa];
      uStack_c = (undefined)((uint)param_1[0x1aa] >> 0x18);
      FUN_00722920();
      (**(code **)(*param_1 + 0x54))(&iStack_10,5);
    }
    return _uStack00000048;
  }
  _uStack00000048 = CONCAT13(*(undefined *)((int *)*param_2 + 1),uStack00000048);
  iStack_10 = (**(code **)(*(int *)*param_2 + 8))();
  iStack_10 = iStack_10 << 3;
  FUN_00677af0(&stack0x00000014);
  piStack_8 = (int *)FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                  ,0x1095);
  iVar7 = param_2[1];
  if (iVar7 != 0) {
    LOCK();
    *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
    UNLOCK();
    iVar7 = param_2[1];
  }
  *piStack_8 = *param_2;
  piVar2 = (int *)piStack_8[1];
  piStack_8[1] = iVar7;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar7 = piVar2[1] + -1;
    piVar2[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar7 = piVar2[2] + -1;
      piVar2[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar7 = (**(code **)(*(int *)*param_2 + 4))();
  piStack_8[0x17] = iVar7;
  piStack_8[2] = iStack_10;
  piStack_8[4] = param_4;
  *(undefined *)(piStack_8 + 5) = param_5;
  piStack_8[3] = param_3;
  piStack_8[6] = iStack_40;
  piStack_8[7] = iStack_3c;
  *(undefined2 *)(piStack_8 + 8) = uStack_38;
  FUN_005f7170(auStack_30);
  *(char *)(piStack_8 + 0x12) = in_stack_00000044;
  piStack_8[0x13] = 0;
  piStack_8[0x1c] = iVar4;
  *(undefined *)(piStack_8 + 0x1d) = uStack0000004b;
  piStack_8[0x1e] = 0;
  FUN_0069cc60(piStack_8);
  if (param_3 == 0) {
    FUN_007229d0();
  }
  return iVar4;
}



/* FUNCTION 8494 ; VA 0x006a0b20 ; FUN_006a0b20 */

int __thiscall
FUN_006a0b20(int *param_1,int param_2,int param_3,undefined4 param_4,int param_5,undefined4 param_6)

{
  char cVar1;
  int iVar2;
  char cStack00000048;
  int in_stack_0000004c;
  undefined uStack_c;
  int iStack_b;
  
  if (((((param_2 == 0) || (param_3 < 0)) || (param_1[0x8d] == 0)) ||
      (*(char *)((int)param_1 + 5) != '\0')) ||
     ((cStack00000048 == '\0' && (cVar1 = FUN_0069b550(), cVar1 != '\0')))) {
    return 0;
  }
  iVar2 = in_stack_0000004c;
  if (in_stack_0000004c == 0) {
    iVar2 = (**(code **)(*param_1 + 0x44))();
  }
  if (((char)_cStack00000048 == '\0') && (cVar1 = FUN_0069b470(&stack0x00000018,1), cVar1 != '\0'))
  {
    (**(code **)(*param_1 + 0x54))(param_2,param_3);
    if (4 < param_5) {
      uStack_c = 0xe;
      FUN_00722910();
      iStack_b = param_1[0x1aa];
      FUN_00722920();
      (**(code **)(*param_1 + 0x54))(&uStack_c,5);
    }
    return iVar2;
  }
  FUN_00677af0(&stack0x00000018);
  FUN_006a0d60(param_2,param_3 * 8,param_4,param_5,param_6);
  return iVar2;
}



/* FUNCTION 8495 ; VA 0x006a0c30 ; FUN_006a0c30 */

int __thiscall
FUN_006a0c30(int *param_1,int *param_2,undefined4 param_3,int param_4,undefined4 param_5)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  char cStack00000044;
  int in_stack_00000048;
  undefined uStack_10;
  int iStack_f;
  int *piStack_8;
  
  piStack_8 = param_1;
  iVar3 = (**(code **)(*param_2 + 8))();
  if (((iVar3 == 0) || (param_1[0x8d] == 0)) || (*(char *)((int)param_1 + 5) != '\0')) {
    return 0;
  }
  if ((cStack00000044 == '\0') && (cVar2 = FUN_0069b550(), cVar2 != '\0')) {
    return 0;
  }
  if (in_stack_00000048 == 0) {
    in_stack_00000048 = (**(code **)(*param_1 + 0x44))();
  }
  if ((cStack00000044 == '\0') && (cVar2 = FUN_0069b470(&stack0x00000014,1), cVar2 != '\0')) {
    pcVar1 = *(code **)(*param_1 + 0x54);
    uVar4 = (**(code **)(*param_2 + 8))();
    uVar5 = (**(code **)(*param_2 + 4))();
    (*pcVar1)(uVar5,uVar4);
    if (4 < param_4) {
      uStack_10 = 0xe;
      FUN_00722910();
      iStack_f = param_1[0x1aa];
      FUN_00722920();
      (**(code **)(*param_1 + 0x54))(&uStack_10,5);
    }
    return in_stack_00000048;
  }
  iVar6 = (**(code **)(*param_2 + 8))();
  uVar4 = (**(code **)(*param_2 + 4))();
  iVar3 = in_stack_00000048;
  FUN_00677af0(&stack0x00000014);
  FUN_006a0d60(uVar4,iVar6 << 3,param_3,param_4,param_5);
  return iVar3;
}



/* FUNCTION 8496 ; VA 0x006a0d60 ; FUN_006a0d60 */

void FUN_006a0d60(undefined4 param_1,int param_2,int param_3,undefined4 param_4,undefined param_5,
                 undefined4 param_6,undefined4 param_7,undefined2 param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined in_stack_00000054;
  
  iVar3 = FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0x1073);
  uVar5 = param_2 + 7U >> 3;
  iVar4 = FUN_01674f30(uVar5);
  *(int *)(iVar3 + 0x5c) = iVar4;
  if (iVar4 == 0) {
    if (DAT_01ee420a != '\0') {
      FUN_01677520(DAT_01ee420a,"out of memory in raknet file %s, line %ld",
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0x1077);
    }
    piVar2 = *(int **)(iVar3 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_00722910();
    FUN_0069d9d0(iVar3,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0x1078);
    FUN_00722920();
    return;
  }
  FUN_0170c6f0(iVar4,param_1,uVar5);
  *(undefined4 *)(iVar3 + 0x10) = param_4;
  *(undefined *)(iVar3 + 0x14) = param_5;
  *(int *)(iVar3 + 8) = param_2;
  *(int *)(iVar3 + 0xc) = param_3;
  *(undefined4 *)(iVar3 + 0x18) = param_6;
  *(undefined4 *)(iVar3 + 0x1c) = param_7;
  *(undefined2 *)(iVar3 + 0x20) = param_8;
  FUN_005f7170(&stack0x00000028);
  *(undefined *)(iVar3 + 0x48) = in_stack_00000048;
  *(undefined4 *)(iVar3 + 0x4c) = in_stack_0000004c;
  *(undefined4 *)(iVar3 + 0x70) = in_stack_00000050;
  *(undefined *)(iVar3 + 0x74) = in_stack_00000054;
  *(undefined4 *)(iVar3 + 0x78) = 0;
  FUN_0069cc60(iVar3);
  if (param_3 == 0) {
    FUN_007229d0();
  }
  return;
}



/* FUNCTION 8497 ; VA 0x006a0eb0 ; FUN_006a0eb0 */

void __thiscall
FUN_006a0eb0(int *param_1,int param_2,int *param_3,uint param_4,int param_5,undefined4 param_6,
            undefined param_7,undefined4 param_8,undefined4 param_9,undefined2 param_10)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  char in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  int iStack_8;
  
  iVar4 = 0;
  iStack_8 = 0;
  if (0 < (int)param_4) {
    if (7 < param_4) {
      uVar3 = param_4 & 0x80000007;
      if ((int)uVar3 < 0) {
        uVar3 = (uVar3 - 1 | 0xfffffff8) + 1;
      }
      uVar14 = 0;
      uVar15 = 0;
      uVar16 = 0;
      uVar17 = 0;
      uVar10 = 0;
      uVar11 = 0;
      uVar12 = 0;
      uVar13 = 0;
      do {
        piVar1 = param_3 + iVar4;
        uVar6 = -(uint)(0 < *piVar1);
        uVar7 = -(uint)(0 < piVar1[1]);
        uVar8 = -(uint)(0 < piVar1[2]);
        uVar9 = -(uint)(0 < piVar1[3]);
        uVar14 = *piVar1 + uVar14 & uVar6 | ~uVar6 & uVar14;
        uVar15 = piVar1[1] + uVar15 & uVar7 | ~uVar7 & uVar15;
        uVar16 = piVar1[2] + uVar16 & uVar8 | ~uVar8 & uVar16;
        uVar17 = piVar1[3] + uVar17 & uVar9 | ~uVar9 & uVar17;
        piVar1 = param_3 + iVar4 + 4;
        iVar4 = iVar4 + 8;
        uVar6 = -(uint)(0 < *piVar1);
        uVar7 = -(uint)(0 < piVar1[1]);
        uVar8 = -(uint)(0 < piVar1[2]);
        uVar9 = -(uint)(0 < piVar1[3]);
        uVar10 = *piVar1 + uVar10 & uVar6 | ~uVar6 & uVar10;
        uVar11 = piVar1[1] + uVar11 & uVar7 | ~uVar7 & uVar11;
        uVar12 = piVar1[2] + uVar12 & uVar8 | ~uVar8 & uVar12;
        uVar13 = piVar1[3] + uVar13 & uVar9 | ~uVar9 & uVar13;
      } while (iVar4 < (int)(param_4 - uVar3));
      iStack_8 = uVar10 + uVar14 + uVar12 + uVar16 + uVar11 + uVar15 + uVar13 + uVar17;
    }
    for (; iVar4 < (int)param_4; iVar4 = iVar4 + 1) {
      iVar5 = iStack_8 + param_3[iVar4];
      if (param_3[iVar4] < 1) {
        iVar5 = iStack_8;
      }
      iStack_8 = iVar5;
    }
    if (iStack_8 != 0) {
      iVar4 = FUN_01674f30(iStack_8);
      if (iVar4 == 0) {
        if (DAT_01ee420a != '\0') {
          FUN_01677520(DAT_01ee420a,"out of memory in raknet file %s, line %ld",
                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0x10bf);
          return;
        }
      }
      else {
        iVar5 = 0;
        param_2 = param_2 - (int)param_3;
        do {
          if (0 < *param_3) {
            FUN_0170c6f0(iVar5 + iVar4,*(undefined4 *)(param_2 + (int)param_3),*param_3);
            iVar5 = iVar5 + *param_3;
          }
          param_3 = param_3 + 1;
          param_4 = param_4 - 1;
        } while (param_4 != 0);
        if ((in_stack_0000004c == '\0') && (cVar2 = FUN_0069b470(&param_8,1), cVar2 != '\0')) {
          (**(code **)(*param_1 + 0x54))(iVar4,iStack_8);
          FUN_01674ea0(iVar4);
          return;
        }
        iVar5 = FUN_00697440("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                             ,0x10d2);
        *(int *)(iVar5 + 8) = iStack_8 << 3;
        *(undefined4 *)(iVar5 + 0x10) = param_6;
        *(int *)(iVar5 + 0x5c) = iVar4;
        *(undefined *)(iVar5 + 0x14) = param_7;
        *(int *)(iVar5 + 0xc) = param_5;
        *(undefined4 *)(iVar5 + 0x18) = param_8;
        *(undefined4 *)(iVar5 + 0x1c) = param_9;
        *(undefined2 *)(iVar5 + 0x20) = param_10;
        FUN_005f7170(&stack0x0000002c);
        *(char *)(iVar5 + 0x48) = in_stack_0000004c;
        *(undefined4 *)(iVar5 + 0x4c) = in_stack_00000050;
        *(undefined4 *)(iVar5 + 0x70) = in_stack_00000054;
        *(undefined *)(iVar5 + 0x74) = 0;
        *(undefined4 *)(iVar5 + 0x78) = 0;
        FUN_0069cc60(iVar5);
        if (param_5 == 0) {
          FUN_007229d0();
        }
      }
    }
  }
  return;
}



/* FUNCTION 8498 ; VA 0x006a10d0 ; FUN_006a10d0 */

undefined4 __thiscall
FUN_006a10d0(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 *param_5,
            undefined4 param_6,int param_7,undefined4 param_8,undefined4 param_9,undefined4 param_10
            ,undefined4 param_11)

{
  uint uVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined *puVar7;
  uint uVar8;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6311;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f7140();
  uVar2 = FUN_005f77c0();
  cVar3 = FUN_005f7750(param_2,param_3,uVar2);
  if (cVar3 == '\0') {
    ExceptionList = pvStack_10;
    return 2;
  }
  iVar4 = FUN_0069a190(uStack_30,uStack_2c,uStack_28,uStack_24,uStack_20,uStack_1c,uStack_18,
                       uStack_14,0,1);
  if (iVar4 != 0) {
    ExceptionList = pvStack_10;
    return 3;
  }
  param_3 = FUN_01674e20(0x160);
  uStack_8 = 0;
  if (param_3 == 0) {
    param_3 = 0;
  }
  else {
    param_3 = FUN_00696460();
  }
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  param_2 = param_3;
  FUN_005f7170(&uStack_30);
  uVar5 = FUN_006a6900();
  *(undefined4 *)(iVar4 + 0x20) = uVar5;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  *(undefined *)(iVar4 + 0x28) = 0;
  *(undefined4 *)(iVar4 + 0x2c) = 0;
  *(undefined4 *)(iVar4 + 0x138) = param_8;
  *(int *)(iVar4 + 0x134) = param_7;
  *(undefined4 *)(iVar4 + 0x15c) = 1;
  *(undefined4 *)(iVar4 + 0x13c) = param_9;
  *(undefined4 *)(iVar4 + 0x140) = param_10;
  FUN_0170c6f0(iVar4 + 0x32,param_4,param_5);
  *(char *)(iVar4 + 0x132) = (char)param_5;
  *(undefined4 *)(iVar4 + 0x144) = param_11;
  param_7 = iVar4 + 0x154;
  puVar6 = (undefined4 *)FUN_01674e20(0x70);
  uStack_8 = 1;
  param_5 = puVar6;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    FUN_00686030();
    *puVar6 = RBX::Security::RakPeerCrypto::vftable;
  }
  uStack_8 = 0xffffffff;
  FUN_00695de0(puVar6);
  puVar7 = &DAT_018d6c48;
  if (*(char *)(param_1 + 0x6ac) == '\0') {
    puVar7 = &DAT_018d6c68;
  }
  FUN_00687020(puVar7,0x20);
  param_7 = param_1 + 0x300;
  uVar8 = 0;
  FUN_00722910();
  param_5 = (undefined4 *)(param_1 + 0x2f0);
  while( true ) {
    uVar1 = *(uint *)(param_1 + 0x2f4);
    if (*(uint *)(param_1 + 0x2f8) < uVar1) {
      iVar4 = *(int *)(param_1 + 0x2fc) - uVar1;
    }
    else {
      iVar4 = -uVar1;
    }
    if (*(uint *)(param_1 + 0x2f8) + iVar4 <= uVar8) break;
    cVar3 = FUN_005f71d0(&uStack_30);
    if (cVar3 != '\0') {
      FUN_00722920();
      FUN_00696cb0(1);
      ExceptionList = pvStack_10;
      return 4;
    }
    uVar8 = uVar8 + 1;
  }
  if (DAT_01eae4ac != '\0') {
    FUN_01677520(DAT_01eae4ac,"RakNet: Added connect request to queue");
  }
  FUN_005fe020(&param_2,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0xcfc);
  FUN_00722920();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 8499 ; VA 0x006a1380 ; FUN_006a1380 */

/* WARNING: Function: __alloca_probe_16 replaced with injection: alloca_probe */
/* WARNING: Unable to track spacebase fully for stack */

uint __thiscall
FUN_006a1380(int param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            uint param_18,char param_19,char param_20,undefined4 param_21,undefined4 param_22,
            undefined4 param_23,undefined4 *param_24)

{
  int iVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  byte bStack0000004b;
  uint uStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_10 = uStack_10 & 0xffffff00;
  puStack_30 = (undefined4 *)&DAT_01eae4bc;
  uStack_8 = 0;
  uStack_34 = 0x6a13a3;
  cVar3 = FUN_005f7260();
  if (cVar3 == '\0') {
    puStack_30 = &DAT_01d5b1f0;
    uStack_34 = 0x6a13d8;
    cVar3 = FUN_005f7240();
    if (cVar3 != '\0') {
      puStack_30 = &DAT_01d5b1f0;
      uStack_20 = param_7;
      uStack_1c = param_8;
      uStack_18 = param_9;
      uStack_14 = param_10;
      uStack_34 = 0x6a13f5;
      cVar3 = FUN_005f71b0();
      if (cVar3 == '\0') {
        puStack_30 = (undefined4 *)(param_1 + 0x470);
        uStack_34 = 0x6a140c;
        cVar3 = FUN_005f71b0();
        if (cVar3 == '\0') {
          if (((ushort)uStack_18 != 0xffff) && ((ushort)uStack_18 < *(ushort *)(param_1 + 0xe))) {
            puStack_30 = &uStack_20;
            uStack_34 = 0x6a1443;
            cVar3 = FUN_005f71b0();
            if (cVar3 != '\0') {
              uVar4 = uStack_18 & 0xffff;
              goto LAB_006a148d;
            }
          }
          uVar4 = 0;
          if (*(short *)(param_1 + 0xe) != 0) {
            do {
              puStack_30 = &uStack_20;
              uStack_34 = 0x6a1477;
              cVar3 = FUN_005f71b0();
              if (cVar3 != '\0') goto LAB_006a148d;
              uVar4 = uVar4 + 1;
            } while (uVar4 < *(ushort *)(param_1 + 0xe));
          }
        }
      }
    }
    uVar4 = 0xffffffff;
  }
  else {
    puStack_30 = (undefined4 *)0x1;
    uStack_34 = param_18;
    uVar4 = FUN_00699980(param_11,param_12,param_13,param_14,param_15,param_16,param_17);
  }
LAB_006a148d:
  if (param_19 == '\0') {
    if (uVar4 != 0xffffffff) {
      puStack_30 = (undefined4 *)0x6a14a6;
      FUN_016f40d0();
      if (((*(char *)(uVar4 * 0xb70 + *(int *)(param_1 + 0x234)) != '\0') &&
          (iVar1 = *(int *)(uVar4 * 0xb70 + 0xb68 + *(int *)(param_1 + 0x234)), iVar1 != 1)) &&
         ((iVar1 != 2 && (iVar1 != 3)))) {
        uStack_8 = 1;
        puStack_c = &stack0xffffffd4;
LAB_006a1568:
        uVar4 = 0;
        if (uStack_8 != 0) {
          do {
            if (((param_20 == '\0') || ((char)uStack_10 != '\0')) ||
               (bStack0000004b = 1, uVar4 + 1 != uStack_8)) {
              bStack0000004b = 0;
            }
            if ((DAT_01d59d40 == '\0') || (*(int *)(param_1 + 0x6f8) == 0)) {
              uStack_34 = 0;
            }
            else {
              puStack_30 = (undefined4 *)0x6a15a8;
              uStack_34 = FUN_006a6780();
              uStack_34 = uStack_34 & 0xffff;
            }
            puStack_30 = param_24;
            FUN_005fed30(param_2,param_3,param_4,param_5,param_6,bStack0000004b ^ 1,
                         *(undefined4 *)
                          (*(int *)(puStack_c + uVar4 * 4) * 0xb70 + *(int *)(param_1 + 0x234) +
                          0xb40),param_21,param_22,param_23);
            uStack_10 = uStack_10 & 0xff;
            if (bStack0000004b != 0) {
              uStack_10 = 1;
            }
            if ((((param_5 == 2) || (param_5 == 3)) || (param_5 == 4)) ||
               ((param_5 == 6 || (param_5 == 7)))) {
              puStack_30 = (undefined4 *)0x0;
              uStack_34 = 1000;
              uVar5 = FUN_016f3c60(param_21,param_22);
              iVar1 = *(int *)(puStack_c + uVar4 * 4);
              iVar2 = *(int *)(param_1 + 0x234);
              *(undefined4 *)(iVar1 * 0xb70 + 0xb20 + iVar2) = uVar5;
              *(undefined4 *)(iVar1 * 0xb70 + 0xb24 + iVar2) = 0;
            }
            uVar4 = uVar4 + 1;
          } while (uVar4 < uStack_8);
        }
        if (param_4 == 0) {
          puStack_30 = (undefined4 *)0x6a1672;
          FUN_007229d0();
        }
        return uStack_10 & 0xff;
      }
    }
  }
  else {
    uVar6 = (uint)*(ushort *)(param_1 + 0xe);
    puStack_30 = (undefined4 *)0x6a14ff;
    puStack_c = &stack0xffffffd4;
    if (uVar6 != 0) {
      uVar7 = 0;
      _param_19 = 0;
      do {
        if (((uVar4 == 0xffffffff) || (uVar7 != uVar4)) &&
           (*(char *)(*(int *)(param_1 + 0x234) + _param_19) != '\0')) {
          (&puStack_30)[-uVar6] = (undefined4 *)&DAT_01eae4bc;
          (&uStack_34)[-uVar6] = 0x6a153a;
          cVar3 = FUN_005f7260();
          if (cVar3 != '\0') {
            *(uint *)(puStack_c + uStack_8 * 4) = uVar7;
            uStack_8 = uStack_8 + 1;
          }
        }
        uVar7 = uVar7 + 1;
        _param_19 = _param_19 + 0xb70;
      } while (uVar7 < *(ushort *)(param_1 + 0xe));
      if (uStack_8 != 0) goto LAB_006a1568;
    }
  }
  return 0;
}


