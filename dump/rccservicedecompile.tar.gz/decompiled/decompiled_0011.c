/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 2750 ; VA 0x00554d40 ; FUN_00554d40 */

uint __thiscall FUN_00554d40(int param_1,uint *param_2,uint param_3)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 4);
  if ((uVar1 == *(uint *)(param_2[1] + 4)) && (uVar1 = *param_2, uVar1 == param_3)) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 2751 ; VA 0x00554d70 ; FUN_00554d70 */

uint __thiscall FUN_00554d70(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined auStack_c [8];
  
  piVar1 = (int *)(**(code **)(*param_1 + 0xc))(auStack_c,param_2);
  if ((*(int *)(piVar1[1] + 4) == *(int *)(param_3[1] + 4)) &&
     (piVar1 = (int *)*piVar1, piVar1 == (int *)*param_3)) {
    return CONCAT31((int3)((uint)piVar1 >> 8),1);
  }
  return (uint)piVar1 & 0xffffff00;
}



/* FUNCTION 2752 ; VA 0x00554db0 ; FUN_00554db0 */

undefined4 * __thiscall FUN_00554db0(undefined4 *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  code *pcVar2;
  undefined4 *puVar3;
  
  uVar1 = param_1[4];
  if (param_2 <= uVar1) {
    if (uVar1 - param_2 < param_3) {
      param_3 = uVar1 - param_2;
    }
    puVar3 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar3 = (undefined4 *)*param_1;
    }
    param_1[4] = uVar1 - param_3;
    FUN_0170cc70((int)puVar3 + param_2,(int)puVar3 + param_2 + param_3,
                 ((uVar1 - param_3) - param_2) + 1);
    return param_1;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar2)();
  return puVar3;
}



/* FUNCTION 2753 ; VA 0x00554e00 ; FUN_00554e00 */

void FUN_00554e00(undefined4 param_1,undefined4 param_2)

{
  FUN_00557c40(&DAT_018bcfa4,param_2);
  OutputDebugStringA(param_2);
  OutputDebugStringA(&DAT_018bcfa8);
  return;
}



/* FUNCTION 2754 ; VA 0x00554e30 ; FUN_00554e30 */

undefined4 FUN_00554e30(void)

{
  return 0;
}



/* FUNCTION 2755 ; VA 0x00554e40 ; FUN_00554e40 */

int __fastcall FUN_00554e40(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792248;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == 0) {
    ExceptionList = &pvStack_10;
    iVar1 = CreateEventA(0,0,0,0);
    if (iVar1 == 0) {
      uVar3 = FUN_005503c0();
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar3);
    }
    LOCK();
    iVar2 = *(int *)(param_1 + 4);
    if (iVar2 == 0) {
      *(int *)(param_1 + 4) = iVar1;
      iVar2 = 0;
    }
    UNLOCK();
    if (iVar2 != 0) {
      CloseHandle(iVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 2756 ; VA 0x00554ed0 ; FUN_00554ed0 */

undefined4 FUN_00554ed0(void)

{
  return 0;
}



/* FUNCTION 2757 ; VA 0x00554ee0 ; FUN_00554ee0 */

void __thiscall FUN_00554ee0(int param_1,undefined4 param_2)

{
  char cVar1;
  int *piVar2;
  
  piVar2 = (int *)FUN_0054e680(param_2);
  cVar1 = (**(code **)(*piVar2 + 0xc))();
  if (cVar1 != '\0') {
    *(undefined4 *)(param_1 + 0x38) = 0;
    return;
  }
  *(int **)(param_1 + 0x38) = piVar2;
  FUN_00553ca0();
  return;
}



/* FUNCTION 2758 ; VA 0x00554f20 ; FUN_00554f20 */

void __thiscall FUN_00554f20(int param_1,undefined4 param_2,char param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792268;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0x201;
  *(undefined4 *)(param_1 + 0x18) = 6;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  iVar3 = FUN_01674e20(8);
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    uStack_8 = 0;
    uVar4 = FUN_016de181(1);
    *(undefined4 *)(iVar3 + 4) = uVar4;
  }
  *(int *)(param_1 + 0x30) = iVar3;
  *(undefined4 *)(param_1 + 0x38) = param_2;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  piVar1 = *(int **)(iVar3 + 4);
  uStack_8 = 1;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 2;
  piVar5 = (int *)FUN_0054e7d0(auStack_18);
  uVar2 = (**(code **)(*piVar5 + 0x20))(0x20);
  uStack_8 = 3;
  if (piVar1 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  *(undefined *)(param_1 + 0x40) = uVar2;
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x38) == 0) {
    FUN_00554460(*(uint *)(param_1 + 0xc) | 4,0);
  }
  if (param_3 != '\0') {
    FUN_016de505(param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2759 ; VA 0x00555060 ; FUN_00555060 */

void FUN_00555060(char param_1)

{
  undefined auStack_90 [24];
  undefined auStack_78 [24];
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  undefined auStack_30 [24];
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017922ac;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01e90cf8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01e90cf8), DAT_01e90cf8 == -1)) {
    iStack_8 = 0;
    FUN_0054eff0(&DAT_018bc9b8);
    iStack_8._0_1_ = 1;
    FUN_0054eff0("RCCService");
    iStack_8._0_1_ = 2;
    uStack_11 = param_1 == '\0';
    FUN_00591f00(uStack_11,auStack_48,auStack_60);
    iStack_8._0_1_ = 1;
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
    FUN_016f3654(FUN_0187b020);
    iStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01e90cf8);
  }
  FUN_0054f030();
  iStack_8 = 3;
  FUN_0054eff0(&DAT_018bc9b8);
  iStack_8._0_1_ = 4;
  uStack_18 = FUN_0086de90(auStack_90,auStack_78);
  FUN_005511f0(uStack_18);
  FUN_005507b0();
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  FUN_005507b0();
  FUN_00592c90(auStack_30);
  iStack_8 = 0xffffffff;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2760 ; VA 0x005551d0 ; FUN_005551d0 */

bool FUN_005551d0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = OpenSCManagerA(0,0,0);
  iVar2 = OpenServiceA(iVar1,param_1,4);
  if (iVar2 != 0) {
    CloseServiceHandle(iVar2);
  }
  if (iVar1 != 0) {
    CloseServiceHandle(iVar1);
  }
  return iVar2 != 0;
}



/* FUNCTION 2761 ; VA 0x00555230 ; FUN_00555230 */

int FUN_00555230(char *param_1)

{
  char *pcVar1;
  char cVar2;
  
  pcVar1 = param_1 + 1;
  do {
    cVar2 = *param_1;
    param_1 = param_1 + 1;
  } while (cVar2 != '\0');
  return (int)param_1 - (int)pcVar1;
}



/* FUNCTION 2762 ; VA 0x00555250 ; FUN_00555250 */

void FUN_00555250(undefined4 *param_1,undefined4 param_2)

{
  code *pcVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 uVar4;
  
  iVar2 = FUN_016de3db(&DAT_01e90d14,FUN_0054dbd0,&DAT_01e90d18);
  if (iVar2 != 0) {
    *param_1 = param_2;
    param_1[1] = &DAT_01e90d18;
    return;
  }
  uVar4 = 8;
  puVar3 = &DAT_01d51160;
  FUN_016f4b80(&DAT_01d51160,8);
  iVar2 = FUN_01733dcb();
  pcVar1 = *(code **)(iVar2 + 0xc);
  if (pcVar1 != (code *)0x0) {
    (*(code *)PTR__guard_check_icall_018b37b4)(puVar3,0);
    (*pcVar1)();
    uVar4 = 0xfffffffe;
  }
  FUN_0171d6f3(puVar3,uVar4);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 2763 ; VA 0x00555290 ; FUN_00555290 */

undefined4 FUN_00555290(void)

{
  return 0x7fffffff;
}



/* FUNCTION 2764 ; VA 0x005552a0 ; FUN_005552a0 */

undefined * FUN_005552a0(undefined *param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)FUN_016de42b(param_2);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  return param_1;
}



/* FUNCTION 2765 ; VA 0x005552f0 ; FUN_005552f0 */

undefined * FUN_005552f0(undefined *param_1,int param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  if (param_2 == 1) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0("iostream stream error",0x15);
    return param_1;
  }
  pcVar2 = (char *)FUN_016de42b(param_2);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  return param_1;
}



/* FUNCTION 2766 ; VA 0x00555370 ; FUN_00555370 */

undefined4 __thiscall FUN_00555370(undefined4 *param_1,undefined4 param_2)

{
  (**(code **)(*(int *)param_1[1] + 8))(param_2,*param_1);
  return param_2;
}



/* FUNCTION 2767 ; VA 0x00555390 ; FUN_00555390 */

char * FUN_00555390(void)

{
  return "generic";
}



/* FUNCTION 2768 ; VA 0x005553a0 ; FUN_005553a0 */

char * FUN_005553a0(void)

{
  return "iostream";
}



/* FUNCTION 2769 ; VA 0x005553b0 ; FUN_005553b0 */

int __thiscall FUN_005553b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x4c) == 0) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_016de722(param_2,param_3,param_4);
    if (iVar3 != 0) {
      FUN_00553bc0(iVar3,1);
      piVar1 = *(int **)(*(int *)(param_1 + 0x34) + 4);
      uStack_8 = 0;
      piStack_14 = piVar1;
      (**(code **)(*piVar1 + 4))();
      uStack_8 = 1;
      piVar4 = (int *)FUN_0054e680(auStack_18);
      cVar2 = (**(code **)(*piVar4 + 0xc))();
      if (cVar2 == '\0') {
        *(int **)(param_1 + 0x38) = piVar4;
        FUN_00553ca0();
      }
      else {
        *(undefined4 *)(param_1 + 0x38) = 0;
      }
      uStack_8 = 2;
      if (piVar1 != (int *)0x0) {
        puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))();
        if (puVar5 != (undefined4 *)0x0) {
          (**(code **)*puVar5)(1);
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 2770 ; VA 0x00555490 ; FUN_00555490 */

int __thiscall FUN_00555490(int param_1,int param_2)

{
  uint uVar1;
  char *pcVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined auStack_2c [32];
  undefined4 *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_2;
  if (param_2 == -1) {
    return 0;
  }
  uVar1 = **(uint **)(param_1 + 0x20);
  cVar4 = (char)param_2;
  if (uVar1 != 0) {
    iVar6 = **(int **)(param_1 + 0x30);
    if (uVar1 < iVar6 + uVar1) {
      **(int **)(param_1 + 0x30) = iVar6 + -1;
      pcVar2 = (char *)**(int **)(param_1 + 0x20);
      **(int **)(param_1 + 0x20) = (int)(pcVar2 + 1);
      *pcVar2 = cVar4;
      return param_2;
    }
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    if (**(int **)(param_1 + 0xc) == param_1 + 0x3c) {
      iVar6 = *(int *)(param_1 + 0x54);
      iVar5 = *(int *)(param_1 + 0x50);
      **(int **)(param_1 + 0xc) = iVar5;
      **(int **)(param_1 + 0x1c) = iVar5;
      **(int **)(param_1 + 0x2c) = iVar6 - iVar5;
    }
    if (*(int **)(param_1 + 0x38) == (int *)0x0) {
      iVar5 = FUN_01718701((int)cVar4,*(undefined4 *)(param_1 + 0x4c));
      iVar6 = -1;
      if (iVar5 != -1) {
        iVar6 = iVar3;
      }
      return iVar6;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,cVar4);
    iVar6 = (**(code **)(**(int **)(param_1 + 0x38) + 0x1c))
                      (param_1 + 0x40,&uStack_8,(int)&uStack_8 + 1,&puStack_c,auStack_2c,&puStack_c,
                       &param_2);
    if (-1 < iVar6) {
      if (iVar6 < 2) {
        iVar6 = param_2 - (int)auStack_2c;
        if ((iVar6 != 0) &&
           (iVar5 = FUN_01719056(auStack_2c,1,iVar6,*(undefined4 *)(param_1 + 0x4c)), iVar6 != iVar5
           )) {
          return -1;
        }
        *(undefined *)(param_1 + 0x3d) = 1;
        if (puStack_c != &uStack_8) {
          return iVar3;
        }
      }
      else if (iVar6 == 3) {
        cVar4 = FUN_0054dbb0(uStack_8,*(undefined4 *)(param_1 + 0x4c));
        iVar6 = -1;
        if (cVar4 != '\0') {
          iVar6 = iVar3;
        }
        return iVar6;
      }
    }
  }
  return -1;
}



/* FUNCTION 2771 ; VA 0x005555c0 ; FUN_005555c0 */

undefined4 FUN_005555c0(void)

{
  return 0xffffffff;
}



/* FUNCTION 2772 ; VA 0x005555d0 ; FUN_005555d0 */

uint FUN_005555d0(int param_1,int param_2)

{
  uint in_EAX;
  int iVar1;
  uint uStack_8;
  
  uStack_8 = 1;
  while( true ) {
    if (param_1 <= (int)uStack_8) {
      return in_EAX & 0xffffff00;
    }
    if (**(char **)(param_2 + uStack_8 * 4) == '/') {
      **(undefined **)(param_2 + uStack_8 * 4) = 0x2d;
    }
    iVar1 = FUN_01717aae(*(undefined4 *)(param_2 + uStack_8 * 4),"-Break");
    if (iVar1 == 0) break;
    in_EAX = uStack_8 + 1;
    uStack_8 = in_EAX;
  }
  return 1;
}



/* FUNCTION 2773 ; VA 0x00555650 ; FUN_00555650 */

char * FUN_00555650(int param_1,int param_2)

{
  int iVar1;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined2 uStack_10;
  int iStack_c;
  int iStack_8;
  
  uStack_18 = DAT_018bcd24;
  uStack_14 = DAT_018bcd28;
  uStack_10 = DAT_018bcd2c;
  iStack_c = 10;
  iStack_8 = 1;
  while( true ) {
    if (param_1 <= iStack_8) {
      return "Content\\";
    }
    if (**(char **)(param_2 + iStack_8 * 4) == '/') {
      **(undefined **)(param_2 + iStack_8 * 4) = 0x2d;
    }
    iVar1 = FUN_01717b91(*(undefined4 *)(param_2 + iStack_8 * 4),&uStack_18,iStack_c + -1);
    if (iVar1 == 0) break;
    iStack_8 = iStack_8 + 1;
  }
  return (char *)(*(int *)(param_2 + iStack_8 * 4) + -1 + iStack_c);
}



/* FUNCTION 2774 ; VA 0x00555700 ; FUN_00555700 */

undefined4 FUN_00555700(int param_1,int param_2)

{
  undefined4 uStack_c;
  int iStack_8;
  
  uStack_c = 0xfddd;
  for (iStack_8 = 1; iStack_8 < param_1; iStack_8 = iStack_8 + 1) {
    if ((**(char **)(param_2 + iStack_8 * 4) != '/') && (**(char **)(param_2 + iStack_8 * 4) != '-')
       ) {
      uStack_c = FUN_01717832(*(undefined4 *)(param_2 + iStack_8 * 4));
    }
  }
  return uStack_c;
}



/* FUNCTION 2775 ; VA 0x00555780 ; FUN_00555780 */

uint __thiscall FUN_00555780(int param_1,uint param_2)

{
  undefined *puVar1;
  uint uVar2;
  undefined *puVar3;
  int iVar4;
  
  uVar2 = **(uint **)(param_1 + 0x1c);
  if (((uVar2 != 0) && (**(uint **)(param_1 + 0xc) < uVar2)) &&
     ((param_2 == 0xffffffff || (*(byte *)(uVar2 - 1) == param_2)))) {
    **(int **)(param_1 + 0x2c) = **(int **)(param_1 + 0x2c) + 1;
    **(int **)(param_1 + 0x1c) = **(int **)(param_1 + 0x1c) + -1;
    if (param_2 == 0xffffffff) {
      param_2 = 0;
    }
    return param_2;
  }
  if ((*(int *)(param_1 + 0x4c) != 0) && (param_2 != 0xffffffff)) {
    if ((*(int *)(param_1 + 0x38) == 0) &&
       (iVar4 = FUN_01719357(param_2 & 0xff,*(int *)(param_1 + 0x4c)), iVar4 != -1)) {
      return param_2;
    }
    puVar1 = (undefined *)(param_1 + 0x3c);
    if ((undefined *)**(int **)(param_1 + 0x1c) != puVar1) {
      *puVar1 = (char)param_2;
      puVar3 = (undefined *)**(int **)(param_1 + 0xc);
      if (puVar3 != puVar1) {
        *(undefined **)(param_1 + 0x50) = puVar3;
        *(int *)(param_1 + 0x54) = **(int **)(param_1 + 0x2c) + **(int **)(param_1 + 0x1c);
      }
      **(int **)(param_1 + 0xc) = (int)puVar1;
      **(int **)(param_1 + 0x1c) = (int)puVar1;
      **(int **)(param_1 + 0x2c) = (param_1 - (int)puVar1) + 0x3d;
      return param_2;
    }
  }
  return 0xffffffff;
}



/* FUNCTION 2776 ; VA 0x00555830 ; FUN_00555830 */

undefined4 FUN_00555830(int param_1)

{
  FUN_005515c0();
  if (param_1 != 0) {
    FUN_00550990();
    FUN_01674ea0(param_1,0x20);
  }
  return 0;
}



/* FUNCTION 2777 ; VA 0x005558a0 ; FUN_005558a0 */

void __thiscall FUN_005558a0(int *param_1,undefined param_2)

{
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  uVar2 = param_1[5];
  uVar6 = param_1[4];
  if (uVar6 < uVar2) {
    param_1[4] = uVar6 + 1;
    if (0xf < uVar2) {
      param_1 = (int *)*param_1;
    }
    *(undefined *)((int)param_1 + uVar6) = param_2;
    *(undefined *)((int)param_1 + uVar6 + 1) = 0;
    return;
  }
  if (uVar6 == 0x7fffffff) {
    FUN_00554040();
LAB_005559a8:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  uVar7 = uVar6 + 1 | 0xf;
  if (uVar7 < 0x80000000) {
    if (0x7fffffff - (uVar2 >> 1) < uVar2) {
      uVar7 = 0x7fffffff;
    }
    else {
      uVar4 = (uVar2 >> 1) + uVar2;
      if (uVar7 < uVar4) {
        uVar7 = uVar4;
      }
    }
  }
  else {
    uVar7 = 0x7fffffff;
  }
  iVar5 = FUN_00554060(uVar7 + 1);
  param_1[5] = uVar7;
  puVar1 = (undefined *)(iVar5 + uVar6);
  param_1[4] = uVar6 + 1;
  if (uVar2 < 0x10) {
    FUN_0170c6f0(iVar5,param_1,uVar6);
    *puVar1 = param_2;
    puVar1[1] = 0;
    *param_1 = iVar5;
    return;
  }
  iVar3 = *param_1;
  FUN_0170c6f0(iVar5,iVar3,uVar6);
  *puVar1 = param_2;
  puVar1[1] = 0;
  uVar6 = uVar2 + 1;
  iVar8 = iVar3;
  if (0xfff < uVar6) {
    iVar8 = *(int *)(iVar3 + -4);
    uVar6 = uVar2 + 0x24;
    if (0x1f < (iVar3 - iVar8) - 4U) goto LAB_005559a8;
  }
  FUN_01674ea0(iVar8,uVar6);
  *param_1 = iVar5;
  return;
}



/* FUNCTION 2778 ; VA 0x005559b0 ; FUN_005559b0 */

void FUN_005559b0(void)

{
  int iVar1;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017922f7;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x20);
  iStack_8._0_1_ = 1;
  if (iVar1 == 0) {
    uStack_18 = 0;
  }
  else {
    uStack_18 = FUN_0054f510(&stack0x00000004);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar1 = QueueUserWorkItem(FUN_00555830,uStack_18,0x10);
  if (iVar1 == 0) {
    FUN_01675310("WinAPIError",&DAT_018bc9b8);
  }
  iStack_8 = 0xffffffff;
  FUN_00550990();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2779 ; VA 0x00555a50 ; FUN_00555a50 */

int __fastcall FUN_00555a50(int param_1)

{
  return param_1 + 0x10;
}



/* FUNCTION 2780 ; VA 0x00555a60 ; FUN_00555a60 */

undefined4 FUN_00555a60(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  int iStack_8;
  
  iStack_8 = 1;
  while( true ) {
    if (param_2 <= iStack_8) {
      iVar1 = FUN_01679040("ApplicationName");
      if (iVar1 == 0) {
        FUN_0054eff0(&DAT_018bc9b8);
      }
      else {
        FUN_0054eff0(iVar1);
      }
      return param_1;
    }
    iVar1 = FUN_01717aae(*(undefined4 *)(param_3 + iStack_8 * 4),"-ApplicationName");
    if ((iVar1 == 0) && (iStack_8 + 1 < param_2)) break;
    iStack_8 = iStack_8 + 1;
  }
  FUN_0054eff0(*(undefined4 *)(param_3 + 4 + iStack_8 * 4));
  return param_1;
}



/* FUNCTION 2781 ; VA 0x00555b20 ; FUN_00555b20 */

undefined4 FUN_00555b20(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined auStack_e4 [24];
  undefined auStack_cc [24];
  undefined auStack_b4 [60];
  undefined auStack_78 [24];
  undefined auStack_60 [24];
  undefined auStack_48 [8];
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179235f;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = FUN_01679040("BaseUrl");
  if (iStack_1c == 0) {
    FUN_01518d10(auStack_78,0,3,0);
    iStack_8 = 0;
    if (DAT_01d84e8d != '\0') {
      uStack_28 = FUN_005569d0(auStack_cc);
      iStack_8._0_1_ = 1;
      uStack_24 = uStack_28;
      uStack_2c = FUN_005543f0();
      cStack_11 = DAT_01d84e8d;
      FUN_01677650(DAT_01d84e8d,"Loading AppSettings.xml, current path: %s",uStack_2c);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
    FUN_0054d730("AppSettings.xml",0);
    iStack_8._0_1_ = 2;
    uStack_34 = FUN_005514a0(auStack_e4,auStack_78,auStack_b4);
    iStack_8._0_1_ = 3;
    uVar4 = 1;
    uVar3 = 0x40;
    uVar2 = 1;
    uStack_30 = uStack_34;
    FUN_0054eb90(1,0x40,1);
    uVar1 = FUN_00554400();
    FUN_0054ebd0(uVar1,uVar2,uVar3,uVar4);
    iStack_8._0_1_ = 5;
    FUN_00550800();
    iStack_8._0_1_ = 6;
    FUN_00550800();
    uVar1 = FUN_00555a50();
    FUN_0054f7e0(uVar1);
    iStack_8._0_1_ = 7;
    FUN_00883a10(auStack_48);
    iStack_8._0_1_ = 8;
    uStack_3c = FUN_0054db20();
    uStack_38 = FUN_0086e3d0("BaseUrl");
    iStack_20 = FUN_0087cde0(uStack_38);
    if (iStack_20 == 0) {
      FUN_0054eff0(&DAT_018bc9b8);
      uStack_18 = uStack_18 | 1;
      iStack_8._0_1_ = 7;
      FUN_00550b30();
      iStack_8._0_1_ = 6;
      FUN_005504e0();
      FUN_00550da0();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005506a0();
      FUN_005506f0();
      iStack_8 = 0xffffffff;
      FUN_00550800();
    }
    else {
      FUN_0054f030();
      iStack_8 = CONCAT31(iStack_8._1_3_,9);
      iStack_40 = iStack_20 + 0x10;
      FUN_0087d060(auStack_60);
      if (DAT_01d59034 != '\0') {
        FUN_01677760(DAT_01d59034,"Got Base url: %s",auStack_60);
      }
      FUN_0054ef20(auStack_60);
      uStack_18 = uStack_18 | 1;
      iStack_8._0_1_ = 8;
      FUN_005507b0();
      iStack_8._0_1_ = 7;
      FUN_00550b30();
      iStack_8._0_1_ = 6;
      FUN_005504e0();
      FUN_00550da0();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005506a0();
      FUN_005506f0();
      iStack_8 = 0xffffffff;
      FUN_00550800();
    }
  }
  else {
    FUN_0054eff0(iStack_1c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2782 ; VA 0x00555e00 ; FUN_00555e00 */

undefined4 FUN_00555e00(undefined4 param_1)

{
  undefined auStack_40c [1024];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  uStack_c = 0x400;
  GetComputerNameA(auStack_40c,&uStack_c);
  FUN_0054eff0(auStack_40c);
  return param_1;
}



/* FUNCTION 2783 ; VA 0x00555e50 ; FUN_00555e50 */

undefined4 FUN_00555e50(undefined4 param_1)

{
  int iVar1;
  undefined auStack_128 [272];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792378;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054f570(0);
  uStack_8 = 0;
  iVar1 = FUN_00552ac0(0x80000002,"Software\\ROBLOX Corporation\\Roblox\\",0x20019);
  if (iVar1 == 0) {
    iStack_18 = 0x103;
    iVar1 = FUN_00552bf0("AccessKey",auStack_128,&iStack_18);
    if (iVar1 == 0) {
      auStack_128[iStack_18] = 0;
      FUN_0054eff0(auStack_128);
      uStack_14 = uStack_14 | 1;
      uStack_8 = 0xffffffff;
      FUN_00550c10();
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  FUN_0054eff0(&DAT_018bc9b8);
  uStack_14 = uStack_14 | 1;
  uStack_8 = 0xffffffff;
  FUN_00550c10();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2784 ; VA 0x00555f40 ; FUN_00555f40 */

undefined4 FUN_00555f40(undefined4 param_1)

{
  undefined auStack_110 [256];
  undefined4 uStack_10;
  undefined1 *puStack_c;
  int iStack_8;
  
  uStack_10 = 0;
  iStack_8 = GetUserGeoID(0x10);
  if (iStack_8 != -1) {
    GetGeoInfoA(iStack_8,4,auStack_110,0x100,0);
  }
  if (iStack_8 == -1) {
    puStack_c = &DAT_018bc9b8;
  }
  else {
    puStack_c = auStack_110;
  }
  FUN_0054eff0(puStack_c);
  return param_1;
}



/* FUNCTION 2785 ; VA 0x00555fb0 ; FUN_00555fb0 */

void FUN_00555fb0(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iStack_8;
  
  *(undefined *)(param_1 + 300) = 0;
  FUN_00551260(&DAT_018bc9b8);
  iStack_8 = 1;
  while( true ) {
    if (param_2 <= iStack_8) {
      return;
    }
    iVar1 = FUN_01717aae(*(undefined4 *)(param_3 + iStack_8 * 4),"-SettingsFile");
    if ((iVar1 == 0) && (iStack_8 + 1 < param_2)) break;
    iStack_8 = iStack_8 + 1;
  }
  *(undefined *)(param_1 + 300) = 1;
  FUN_00551260(*(undefined4 *)(param_3 + 4 + iStack_8 * 4));
  return;
}



/* FUNCTION 2786 ; VA 0x00556040 ; FUN_00556040 */

undefined4 FUN_00556040(undefined4 param_1)

{
  int iVar1;
  undefined auStack_15c [284];
  undefined auStack_40 [36];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017923a0;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054f030();
  uStack_8 = 0;
  FUN_0054f570(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar1 = FUN_00552ac0(0x80000002,"Software\\ROBLOX Corporation\\Roblox\\",0x20019);
  if (iVar1 == 0) {
    iStack_14 = 0x103;
    iVar1 = FUN_00552bf0("SettingsKey",auStack_15c,&iStack_14);
    if (iVar1 == 0) {
      auStack_15c[iStack_14] = 0;
      uStack_1c = FUN_0054eff0(auStack_15c);
      FUN_005511f0(uStack_1c);
      FUN_005507b0();
      if (DAT_01d59034 != '\0') {
        FUN_01677760(DAT_01d59034,"Read settings key: %s",auStack_40);
      }
    }
  }
  FUN_0054ef20(auStack_40);
  uStack_18 = uStack_18 | 1;
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_00550c10();
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2787 ; VA 0x00556160 ; FUN_00556160 */

void FUN_00556160(void)

{
  undefined auStack_5c [24];
  undefined auStack_44 [44];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017923b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00590910();
  uStack_8 = 0;
  FUN_005910b0(DAT_0211374c);
  uStack_14 = FUN_00590f00(auStack_44);
  FUN_005511f0(uStack_14);
  FUN_005507b0();
  uStack_18 = FUN_005909f0(auStack_5c);
  FUN_005511f0(uStack_18);
  FUN_005507b0();
  uStack_8 = 0xffffffff;
  FUN_005909b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2788 ; VA 0x00556200 ; FUN_00556200 */

void FUN_00556200(undefined4 param_1)

{
  if (DAT_01d84e8d != '\0') {
    FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,param_1);
  }
  FUN_005531f0(4,param_1);
  return;
}



/* FUNCTION 2789 ; VA 0x00556240 ; FUN_00556240 */

void FUN_00556240(void)

{
  undefined4 uVar1;
  undefined auStack_c [8];
  
  DAT_01e90c48 = 1;
  uVar1 = FUN_0054d820(&DAT_01d59004);
  FUN_0054daf0(uVar1);
  FUN_00556a60(auStack_c);
  return;
}



/* FUNCTION 2790 ; VA 0x00556273 ; FUN_00556273 */

void FUN_00556273(void)

{
  FUN_00556280();
  return;
}



/* FUNCTION 2791 ; VA 0x00556280 ; FUN_00556280 */

void __fastcall FUN_00556280(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_0054f0e0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c173d4);
}



/* FUNCTION 2792 ; VA 0x005562a3 ; FUN_005562a3 */

void FUN_005562a3(void)

{
  FUN_005562b0();
  return;
}



/* FUNCTION 2793 ; VA 0x005562b0 ; FUN_005562b0 */

void __fastcall FUN_005562b0(int param_1)

{
  undefined auStack_50 [76];
  
  FUN_0054f1c0(param_1 + -0x48,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c172bc);
}



/* FUNCTION 2794 ; VA 0x005562d3 ; FUN_005562d3 */

void FUN_005562d3(void)

{
  FUN_005562e0();
  return;
}



/* FUNCTION 2795 ; VA 0x005562e0 ; FUN_005562e0 */

void __fastcall FUN_005562e0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_0054f250(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c174d8);
}



/* FUNCTION 2796 ; VA 0x00556303 ; FUN_00556303 */

void FUN_00556303(void)

{
  FUN_00556310();
  return;
}



/* FUNCTION 2797 ; VA 0x00556310 ; FUN_00556310 */

void __fastcall FUN_00556310(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_0054f2e0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c17458);
}



/* FUNCTION 2798 ; VA 0x00556340 ; FUN_00556340 */

void __thiscall FUN_00556340(int param_1,int *param_2,int param_3,int param_4,int param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = param_4;
  iVar3 = param_3;
  if (((**(int **)(param_1 + 0x1c) == param_1 + 0x3c) && (param_5 == 1)) &&
     (*(int *)(param_1 + 0x38) == 0)) {
    iVar2 = param_4 + -1 + (uint)(param_3 != 0);
    iVar3 = param_3 + -1;
  }
  if ((((*(int *)(param_1 + 0x4c) != 0) && (cVar1 = FUN_00553750(), cVar1 != '\0')) &&
      (((iVar3 == 0 && iVar2 == 0 && (param_5 == 1)) ||
       (iVar2 = FUN_01718e07(*(undefined4 *)(param_1 + 0x4c),iVar3,iVar2,param_5), iVar2 == 0)))) &&
     (iVar2 = FUN_0171867d(*(undefined4 *)(param_1 + 0x4c),&param_3), iVar2 == 0)) {
    FUN_00553f20();
    iVar2 = *(int *)(param_1 + 0x40);
    param_2[5] = *(int *)(param_1 + 0x44);
    *param_2 = param_3;
    param_2[1] = param_4;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = iVar2;
    return;
  }
  *param_2 = -1;
  param_2[1] = -1;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  return;
}



/* FUNCTION 2799 ; VA 0x00556420 ; FUN_00556420 */

void FUN_00556420(undefined4 *param_1)

{
  *param_1 = 0xffffffff;
  param_1[1] = 0xffffffff;
  param_1[2] = 0;
  param_1[3] = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 2800 ; VA 0x00556450 ; FUN_00556450 */

void __thiscall
FUN_00556450(int param_1,int *param_2,uint param_3,int param_4,uint param_5,int param_6,
            undefined4 param_7,undefined4 param_8)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iStack_c;
  int iStack_8;
  
  iStack_c = param_3 + param_5;
  iStack_8 = param_4 + param_6 + (uint)CARRY4(param_3,param_5);
  if (*(int *)(param_1 + 0x4c) != 0) {
    cVar2 = FUN_00553750();
    if (cVar2 != '\0') {
      iVar3 = FUN_01718b1a(*(undefined4 *)(param_1 + 0x4c),&iStack_c);
      if (iVar3 == 0) {
        *(undefined4 *)(param_1 + 0x40) = param_7;
        *(undefined4 *)(param_1 + 0x44) = param_8;
        if (**(int **)(param_1 + 0xc) == param_1 + 0x3c) {
          iVar3 = *(int *)(param_1 + 0x54);
          iVar1 = *(int *)(param_1 + 0x50);
          **(int **)(param_1 + 0xc) = iVar1;
          **(int **)(param_1 + 0x1c) = iVar1;
          **(int **)(param_1 + 0x2c) = iVar3 - iVar1;
        }
        iVar3 = *(int *)(param_1 + 0x40);
        iVar1 = *(int *)(param_1 + 0x44);
        *param_2 = iStack_c;
        param_2[5] = iVar1;
        param_2[1] = iStack_8;
        param_2[2] = 0;
        param_2[3] = 0;
        param_2[4] = iVar3;
        return;
      }
    }
  }
  *param_2 = -1;
  param_2[1] = -1;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  return;
}



/* FUNCTION 2801 ; VA 0x00556520 ; FUN_00556520 */

void FUN_00556520(undefined4 *param_1)

{
  *param_1 = 0xffffffff;
  param_1[1] = 0xffffffff;
  param_1[2] = 0;
  param_1[3] = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 2802 ; VA 0x00556550 ; FUN_00556550 */

int __thiscall FUN_00556550(int param_1,int param_2,int param_3,int param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    if ((param_2 == 0) && (param_3 == 0 && param_4 == 0)) {
      uVar1 = 4;
    }
    else {
      uVar1 = 0;
    }
    iVar2 = FUN_017191d9(*(int *)(param_1 + 0x4c),param_2,uVar1,param_3);
    if (iVar2 == 0) {
      FUN_00553bc0(*(undefined4 *)(param_1 + 0x4c),1);
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 2803 ; VA 0x005565a0 ; FUN_005565a0 */

undefined4 __fastcall FUN_005565a0(undefined4 param_1)

{
  return param_1;
}



/* FUNCTION 2804 ; VA 0x005565b0 ; FUN_005565b0 */

void __thiscall FUN_005565b0(int param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  
  param_2 = *(uint *)(param_1 + 0xc) | param_2;
  uVar1 = param_2 | 4;
  if (*(int *)(param_1 + 0x38) != 0) {
    uVar1 = param_2;
  }
  FUN_00554460(uVar1,param_3);
  return;
}



/* FUNCTION 2805 ; VA 0x005565e0 ; FUN_005565e0 */

undefined8 FUN_005565e0(void)

{
  return 0;
}



/* FUNCTION 2806 ; VA 0x005565f0 ; FUN_005565f0 */

undefined4 __fastcall FUN_005565f0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}



/* FUNCTION 2807 ; VA 0x00556600 ; FUN_00556600 */

void FUN_00556600(undefined4 param_1,undefined4 param_2,undefined param_3,char param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_440 [500];
  undefined auStack_24c [24];
  undefined auStack_234 [72];
  undefined4 uStack_1ec;
  undefined uStack_1d0;
  undefined uStack_154;
  char cStack_120;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined auStack_f8 [24];
  undefined auStack_e0 [24];
  undefined auStack_c8 [24];
  undefined auStack_b0 [24];
  undefined auStack_98 [24];
  undefined auStack_80 [24];
  undefined auStack_68 [12];
  undefined4 uStack_5c;
  code *pcStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [4];
  undefined auStack_34 [4];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  code *pcStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017923fb;
  pvStack_10 = ExceptionList;
  uStack_5c = 0;
  ExceptionList = &pvStack_10;
  FUN_0054f770(DAT_01e90d74);
  iStack_8 = 0;
  FUN_0054f590();
  iStack_8._0_1_ = 1;
  uStack_1ec = FUN_00555700(param_1,param_2);
  cVar1 = FUN_00554d00();
  if (cVar1 == '\0') {
    FUN_00551230(param_6);
  }
  else {
    uStack_18 = FUN_00555650(param_1,param_2);
    iVar2 = PathIsRelativeA(uStack_18);
    if (iVar2 == 0) {
      FUN_00551260(uStack_18);
    }
    else {
      GetModuleFileNameA(DAT_0211374c,auStack_440,500);
      FUN_0054e940(auStack_440);
      iStack_8._0_1_ = 2;
      FUN_00552d40();
      uStack_28 = FUN_00551380(auStack_38,auStack_14,&DAT_018bd1cc);
      iStack_8._0_1_ = 3;
      uStack_24 = uStack_28;
      uStack_30 = FUN_00551380(auStack_34,uStack_28,uStack_18);
      iStack_8._0_1_ = 4;
      uStack_2c = uStack_30;
      uVar3 = FUN_0054db20();
      FUN_00551260(uVar3);
      iStack_8._0_1_ = 3;
      FUN_00550450();
      iStack_8._0_1_ = 2;
      FUN_00550450();
      iStack_8._0_1_ = 1;
      FUN_00550450();
    }
  }
  uStack_3c = FUN_00555e00(auStack_80);
  FUN_005511f0(uStack_3c);
  FUN_005507b0();
  FUN_00556160(auStack_24c,auStack_234);
  uStack_40 = FUN_00555f40(auStack_98);
  FUN_005511f0(uStack_40);
  FUN_005507b0();
  uStack_44 = FUN_00556040(auStack_b0);
  FUN_005511f0(uStack_44);
  FUN_005507b0();
  uStack_48 = FUN_00555e50(auStack_c8);
  FUN_005511f0(uStack_48);
  FUN_005507b0();
  uStack_1d0 = param_3;
  uStack_4c = FUN_00555b20(auStack_e0,param_1,param_2);
  FUN_005511f0(uStack_4c);
  FUN_005507b0();
  uStack_50 = FUN_00555a60(auStack_f8,param_1,param_2);
  FUN_005511f0(uStack_50);
  FUN_005507b0();
  if ((param_4 == '\0') && (cVar1 = FUN_005551d0("Roblox.Thumbnails.Relay"), cVar1 == '\0')) {
    uStack_1c = 0;
  }
  else {
    uStack_1c = 1;
  }
  uStack_154 = (undefined)uStack_1c;
  FUN_00555fb0(auStack_24c,param_1,param_2);
  uStack_104 = param_7;
  uStack_100 = param_8;
  cVar1 = FUN_00554d00();
  if ((cVar1 != '\0') && (cStack_120 == '\0')) {
    FUN_016756b0(auStack_68,"Settings key must be defined");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_68,&DAT_01c17198);
  }
  DAT_01ea8b14 = 1;
  FUN_0054db20();
  FUN_0058e730();
  FUN_0054db20();
  FUN_005902e0();
  FUN_0058c160(auStack_24c);
  uVar3 = GetModuleHandleA("Kernel32","SetProcessDEPPolicy");
  pcStack_20 = (code *)GetProcAddress(uVar3);
  if (pcStack_20 != (code *)0x0) {
    pcStack_54 = pcStack_20;
    (*pcStack_20)(1);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00550c50();
  iStack_8 = 0xffffffff;
  FUN_00550d20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2808 ; VA 0x005569d0 ; FUN_005569d0 */

undefined * __thiscall FUN_005569d0(undefined4 *param_1,undefined *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  iVar1 = param_1[4];
  uStack_8 = 0;
  if (iVar1 != 0) {
    puVar3 = param_1;
    if (7 < (uint)param_1[5]) {
      puVar3 = (undefined4 *)*param_1;
    }
    if (7 < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uVar2 = FUN_01686580();
    FUN_01685a20(param_1,(int)puVar3 + iVar1 * 2,param_2,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2809 ; VA 0x00556a60 ; FUN_00556a60 */

void FUN_00556a60(undefined4 *param_1)

{
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = 0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01e90ce4) {
    FUN_016f3809(&DAT_01e90ce4);
    if (DAT_01e90ce4 == -1) {
      FUN_005502b0();
      FUN_016f3654(FUN_0187b150);
      FUN_016f37bf(&DAT_01e90ce4);
    }
  }
  if (DAT_01e90ce8 == '\0') {
    uStack_14 = *param_1;
    uStack_10 = param_1[1];
    uStack_8 = FUN_0054d850(&uStack_14);
    FUN_00551290(uStack_8);
    FUN_005511c0();
    FUN_00554ad0();
    DAT_01e90ce8 = '\x01';
  }
  return;
}



/* FUNCTION 2810 ; VA 0x00556b20 ; FUN_00556b20 */

undefined4 __fastcall FUN_00556b20(int *param_1)

{
  int iVar1;
  
  if (param_1[0x13] != 0) {
    iVar1 = (**(code **)(*param_1 + 0xc))(0xffffffff);
    if (iVar1 != -1) {
      iVar1 = FUN_017184e1(param_1[0x13]);
      if (iVar1 < 0) {
        return 0xffffffff;
      }
    }
  }
  return 0;
}



/* FUNCTION 2811 ; VA 0x00556b50 ; FUN_00556b50 */

uint __fastcall FUN_00556b50(int param_1)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  char *****pppppcVar5;
  uint uVar6;
  char *pcVar7;
  char *****pppppcVar8;
  char ****appppcStack_3c [4];
  uint uStack_2c;
  uint uStack_28;
  byte *pbStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uVar2 = **(uint **)(param_1 + 0x1c);
  if (uVar2 != 0) {
    iVar3 = **(int **)(param_1 + 0x2c);
    if (uVar2 < iVar3 + uVar2) {
      **(int **)(param_1 + 0x2c) = iVar3 + -1;
      pbVar1 = (byte *)**(int **)(param_1 + 0x1c);
      **(int **)(param_1 + 0x1c) = (int)(pbVar1 + 1);
      return (uint)*pbVar1;
    }
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    ExceptionList = &pvStack_10;
    if (**(int **)(param_1 + 0xc) == param_1 + 0x3c) {
      iVar3 = *(int *)(param_1 + 0x54);
      iVar4 = *(int *)(param_1 + 0x50);
      ExceptionList = &pvStack_10;
      **(int **)(param_1 + 0xc) = iVar4;
      **(int **)(param_1 + 0x1c) = iVar4;
      **(int **)(param_1 + 0x2c) = iVar3 - iVar4;
    }
    iStack_1c = param_1;
    if (*(int *)(param_1 + 0x38) != 0) {
      uStack_2c = 0;
      uStack_28 = 0xf;
      appppcStack_3c[0] = (char ****)((uint)appppcStack_3c[0] & 0xffffff00);
      uStack_8 = 0;
      iVar3 = FUN_0171857f(*(undefined4 *)(param_1 + 0x4c));
      if (iVar3 != -1) {
        iStack_20 = param_1 + 0x40;
        do {
          FUN_005558a0(iVar3);
          pppppcVar5 = appppcStack_3c;
          if (0xf < uStack_28) {
            pppppcVar5 = (char *****)appppcStack_3c[0];
          }
          pppppcVar8 = appppcStack_3c;
          if (0xf < uStack_28) {
            pppppcVar8 = (char *****)appppcStack_3c[0];
          }
          iVar4 = (**(code **)(**(int **)(param_1 + 0x38) + 0x18))
                            (iStack_20,pppppcVar8,(char *)((int)pppppcVar5 + uStack_2c),&iStack_18,
                             &bStack_11,&pvStack_10,&pbStack_24);
          iVar3 = iStack_1c;
          if (iVar4 < 0) break;
          if (1 < iVar4) {
            if (iVar4 == 3) {
              pppppcVar5 = appppcStack_3c;
              if (0xf < uStack_28) {
                pppppcVar5 = (char *****)appppcStack_3c[0];
              }
              uVar2 = (uint)*(char *)pppppcVar5;
              goto LAB_00556ce4;
            }
            break;
          }
          if (pbStack_24 != &bStack_11) {
            pppppcVar5 = appppcStack_3c;
            if (0xf < uStack_28) {
              pppppcVar5 = (char *****)appppcStack_3c[0];
            }
            for (pcVar7 = (char *)((int)pppppcVar5 + (uStack_2c - iStack_18)); 0 < (int)pcVar7;
                pcVar7 = pcVar7 + -1) {
              FUN_01719357((int)pcVar7[iStack_18 + -1],*(undefined4 *)(iVar3 + 0x4c));
            }
            uVar2 = (uint)bStack_11;
            goto LAB_00556ce4;
          }
          pppppcVar5 = appppcStack_3c;
          if (0xf < uStack_28) {
            pppppcVar5 = (char *****)appppcStack_3c[0];
          }
          uVar2 = iStack_18 - (int)pppppcVar5;
          if (uStack_2c < (uint)(iStack_18 - (int)pppppcVar5)) {
            uVar2 = uStack_2c;
          }
          pppppcVar5 = appppcStack_3c;
          if (0xf < uStack_28) {
            pppppcVar5 = (char *****)appppcStack_3c[0];
          }
          uStack_2c = uStack_2c - uVar2;
          FUN_0170cc70(pppppcVar5,(char *)((int)pppppcVar5 + uVar2),uStack_2c + 1);
          param_1 = iStack_1c;
          iVar3 = FUN_0171857f(*(undefined4 *)(iStack_1c + 0x4c));
        } while (iVar3 != -1);
      }
      uVar2 = 0xffffffff;
LAB_00556ce4:
      if (0xf < uStack_28) {
        uVar6 = uStack_28 + 1;
        pppppcVar5 = (char *****)appppcStack_3c[0];
        if (0xfff < uVar6) {
          pppppcVar5 = (char *****)appppcStack_3c[0][-1];
          uVar6 = uStack_28 + 0x24;
          if ((char *)0x1f < (char *)((int)appppcStack_3c[0] + (-4 - (int)pppppcVar5))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppcVar5,uVar6);
      }
      ExceptionList = pvStack_10;
      return uVar2;
    }
    uVar2 = FUN_0171857f(*(undefined4 *)(param_1 + 0x4c));
    if (uVar2 != 0xffffffff) {
      ExceptionList = pvStack_10;
      return uVar2 & 0xff;
    }
  }
  ExceptionList = pvStack_10;
  return 0xffffffff;
}



/* FUNCTION 2812 ; VA 0x00556d80 ; FUN_00556d80 */

uint __fastcall FUN_00556d80(int *param_1)

{
  byte *pbVar1;
  int iVar2;
  
  iVar2 = (**(code **)(*param_1 + 0x18))();
  if (iVar2 == -1) {
    return 0xffffffff;
  }
  *(int *)param_1[0xb] = *(int *)param_1[0xb] + -1;
  pbVar1 = *(byte **)param_1[7];
  *(byte **)param_1[7] = pbVar1 + 1;
  return (uint)*pbVar1;
}



/* FUNCTION 2813 ; VA 0x00556db0 ; FUN_00556db0 */

uint __fastcall FUN_00556db0(int *param_1)

{
  byte *pbVar1;
  uint uVar2;
  
  pbVar1 = *(byte **)param_1[7];
  if ((pbVar1 != (byte *)0x0) && (pbVar1 < pbVar1 + *(int *)param_1[0xb])) {
    return (uint)*pbVar1;
  }
  uVar2 = (**(code **)(*param_1 + 0x1c))();
  if (uVar2 == 0xffffffff) {
    return 0xffffffff;
  }
  (**(code **)(*param_1 + 0x10))(uVar2);
  return uVar2;
}



/* FUNCTION 2814 ; VA 0x00556df0 ; FUN_00556df0 */

undefined4 FUN_00556df0(void)

{
  return 0xffffffff;
}



/* FUNCTION 2815 ; VA 0x00556e00 ; FUN_00556e00 */

void __fastcall FUN_00556e00(uint *param_1)

{
  uint uVar1;
  undefined4 uVar2;
  
  LOCK();
  uVar1 = *param_1;
  *param_1 = *param_1 + 0x80000000;
  UNLOCK();
  if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
    LOCK();
    uVar1 = *param_1;
    *param_1 = *param_1 | 0x40000000;
    UNLOCK();
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar2 = FUN_00554e40();
      SetEvent(uVar2);
    }
  }
  return;
}



/* FUNCTION 2816 ; VA 0x00556e30 ; FUN_00556e30 */

char * __fastcall FUN_00556e30(int param_1)

{
  char *pcVar1;
  
  pcVar1 = "Unknown exception";
  if (*(char **)(param_1 + 4) != (char *)0x0) {
    pcVar1 = *(char **)(param_1 + 4);
  }
  return pcVar1;
}



/* FUNCTION 2817 ; VA 0x00556e40 ; FUN_00556e40 */

int __fastcall FUN_00556e40(int param_1)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  int *piVar6;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792468;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc4;
  piVar6 = (int *)(param_1 + 0x14);
  if (*(int *)(param_1 + 0x24) == 0) {
    uStack_8 = 0;
    pcVar4 = "Unknown exception";
    if (*(char **)(param_1 + 4) != (char *)0x0) {
      pcVar4 = *(char **)(param_1 + 4);
    }
    pcVar3 = pcVar4;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    FUN_005542c0(pcVar4,(int)pcVar3 - (int)(pcVar4 + 1));
    if (*(int *)(param_1 + 0x24) != 0) {
      FUN_00554150(&DAT_018bcaac,2);
    }
    (**(code **)(**(int **)(param_1 + 0x10) + 8))(apppuStack_30,*(undefined4 *)(param_1 + 0xc));
    ppppuVar2 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00554150(ppppuVar2,uStack_20);
    if (0xf < uStack_1c) {
      uVar5 = uStack_1c + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar5) {
        ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
        uVar5 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar2,uVar5);
    }
  }
  if (0xf < *(uint *)(param_1 + 0x28)) {
    piVar6 = (int *)*piVar6;
  }
  ExceptionList = pvStack_10;
  return (int)piVar6;
}



/* FUNCTION 2818 ; VA 0x00556f2a ; Catch_All@00556f2a */

undefined * Catch_All_00556f2a(void)

{
  char *pcVar1;
  char *pcVar2;
  int unaff_EBP;
  
  pcVar1 = *(char **)(*(int *)(unaff_EBP + -0x14) + 4);
  pcVar2 = "Unknown exception";
  if (pcVar1 != (char *)0x0) {
    pcVar2 = pcVar1;
  }
  *(char **)(unaff_EBP + -0x14) = pcVar2;
  return &LAB_00556f43;
}



/* FUNCTION 2819 ; VA 0x00556f60 ; FUN_00556f60 */

undefined __thiscall FUN_00556f60(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_1 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  piVar3 = (int *)FUN_0054e7d0(auStack_18);
  uVar2 = (**(code **)(*piVar3 + 0x20))(param_2);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar4 != (undefined4 *)0x0) {
      (**(code **)*puVar4)(1);
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 2820 ; VA 0x00556ff0 ; FUN_00556ff0 */

/* WARNING: Removing unreachable block (ram,0x0055703a) */
/* WARNING: Removing unreachable block (ram,0x00557044) */

undefined8 __thiscall FUN_00556ff0(int *param_1,undefined *param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  longlong lVar7;
  int iStack_c;
  
  iVar3 = param_4;
  if (param_1[0xe] == 0) {
    if (*(int *)param_1[7] == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(uint *)param_1[0xb];
    }
    iVar2 = (int)uVar5 >> 0x1f;
    uVar4 = param_3;
    if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
      if ((-1 < iVar2) && (((int)uVar5 < 0 && -1 < iVar2 || (uVar5 != 0)))) {
        if ((param_4 <= iVar2) && ((param_4 < iVar2 || (param_3 < uVar5)))) {
          uVar5 = param_3;
          iVar2 = param_4;
        }
        param_4 = iVar2;
        FUN_0170c6f0(param_2,*(int *)param_1[7],uVar5);
        param_2 = param_2 + uVar5;
        param_4 = (iVar3 - param_4) - (uint)(param_3 < uVar5);
        *(int *)param_1[0xb] = *(int *)param_1[0xb] - uVar5;
        *(int *)param_1[7] = *(int *)param_1[7] + uVar5;
        uVar4 = param_3 - uVar5;
      }
      if ((-1 < param_4) && (((0 < param_4 || (uVar4 != 0)) && (iVar2 = param_1[0x13], iVar2 != 0)))
         ) {
        if (*(int **)param_1[3] == param_1 + 0xf) {
          iVar2 = param_1[0x15];
          iVar1 = param_1[0x14];
          *(int *)param_1[3] = iVar1;
          *(int *)param_1[7] = iVar1;
          *(int *)param_1[0xb] = iVar2 - iVar1;
          iVar2 = param_1[0x13];
        }
        uVar5 = FUN_017189e9(param_2,1,uVar4,iVar2);
        bVar6 = uVar4 < uVar5;
        uVar4 = uVar4 - uVar5;
        param_4 = param_4 - (uint)bVar6;
      }
    }
    return CONCAT44((iVar3 - param_4) - (uint)(param_3 < uVar4),param_3 - uVar4);
  }
  uVar5 = param_3;
  if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
    do {
      lVar7 = FUN_00553ae0();
      if (lVar7 < 1) {
        iVar2 = (**(code **)(*param_1 + 0x1c))();
        if (iVar2 == -1) break;
        bVar6 = uVar5 != 0;
        uVar5 = uVar5 - 1;
        uVar4 = 1;
        iVar3 = iVar3 + -1 + (uint)bVar6;
        *param_2 = (char)iVar2;
      }
      else {
        if (CONCAT44(iVar3,uVar5) < lVar7) {
          lVar7 = CONCAT44(iVar3,uVar5);
        }
        iStack_c = (int)((ulonglong)lVar7 >> 0x20);
        uVar4 = (uint)lVar7;
        FUN_0170c6f0(param_2,*(undefined4 *)param_1[7],uVar4);
        bVar6 = uVar5 < uVar4;
        uVar5 = uVar5 - uVar4;
        iVar3 = (iVar3 - iStack_c) - (uint)bVar6;
        *(int *)param_1[0xb] = *(int *)param_1[0xb] - uVar4;
        *(int *)param_1[7] = *(int *)param_1[7] + uVar4;
      }
      param_2 = param_2 + uVar4;
      if ((iVar3 < 1) && ((iVar3 < 0 || (uVar5 == 0)))) break;
    } while( true );
  }
  return CONCAT44((param_4 - iVar3) - (uint)(param_3 < uVar5),param_3 - uVar5);
}



/* FUNCTION 2821 ; VA 0x005571a0 ; FUN_005571a0 */

/* WARNING: Removing unreachable block (ram,0x005571e2) */
/* WARNING: Removing unreachable block (ram,0x005571ec) */

undefined8 __thiscall FUN_005571a0(int *param_1,undefined *param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  longlong lVar7;
  
  iVar1 = param_4;
  iVar3 = param_4;
  uVar5 = param_3;
  if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
    do {
      lVar7 = FUN_00553ae0();
      if (lVar7 < 1) {
        iVar2 = (**(code **)(*param_1 + 0x1c))();
        if (iVar2 == -1) break;
        bVar6 = uVar5 != 0;
        uVar5 = uVar5 - 1;
        uVar4 = 1;
        iVar3 = iVar3 + -1 + (uint)bVar6;
        *param_2 = (char)iVar2;
      }
      else {
        if (CONCAT44(iVar3,uVar5) < lVar7) {
          lVar7 = CONCAT44(iVar3,uVar5);
        }
        param_4 = (int)((ulonglong)lVar7 >> 0x20);
        uVar4 = (uint)lVar7;
        FUN_0170c6f0(param_2,*(undefined4 *)param_1[7],uVar4);
        bVar6 = uVar5 < uVar4;
        uVar5 = uVar5 - uVar4;
        iVar3 = (iVar3 - param_4) - (uint)bVar6;
        *(int *)param_1[0xb] = *(int *)param_1[0xb] - uVar4;
        *(int *)param_1[7] = *(int *)param_1[7] + uVar4;
      }
      param_2 = param_2 + uVar4;
      if ((iVar3 < 1) && ((iVar3 < 0 || (uVar5 == 0)))) break;
    } while( true );
  }
  return CONCAT44((iVar1 - iVar3) - (uint)(param_3 < uVar5),param_3 - uVar5);
}



/* FUNCTION 2822 ; VA 0x00557270 ; FUN_00557270 */

/* WARNING: Removing unreachable block (ram,0x005572ba) */
/* WARNING: Removing unreachable block (ram,0x005572c4) */

undefined8 __thiscall FUN_00557270(int *param_1,undefined *param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  bool bVar5;
  longlong lVar6;
  int iStack_c;
  
  iVar2 = param_4;
  if (param_1[0xe] == 0) {
    if (*(int *)param_1[8] == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = *(uint *)param_1[0xc];
    }
    iVar1 = (int)uVar4 >> 0x1f;
    uVar3 = param_3;
    if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
      if ((-1 < iVar1) && (((int)uVar4 < 0 && -1 < iVar1 || (uVar4 != 0)))) {
        if ((param_4 <= iVar1) && ((param_4 < iVar1 || (param_3 < uVar4)))) {
          uVar4 = param_3;
          iVar1 = param_4;
        }
        param_4 = iVar1;
        FUN_0170c6f0(*(int *)param_1[8],param_2,uVar4);
        param_2 = param_2 + uVar4;
        param_4 = (iVar2 - param_4) - (uint)(param_3 < uVar4);
        *(int *)param_1[0xc] = *(int *)param_1[0xc] - uVar4;
        *(int *)param_1[8] = *(int *)param_1[8] + uVar4;
        uVar3 = param_3 - uVar4;
      }
      if ((-1 < param_4) && (((0 < param_4 || (uVar3 != 0)) && (param_1[0x13] != 0)))) {
        uVar4 = FUN_01719056(param_2,1,uVar3,param_1[0x13]);
        bVar5 = uVar3 < uVar4;
        uVar3 = uVar3 - uVar4;
        param_4 = param_4 - (uint)bVar5;
      }
    }
    return CONCAT44((iVar2 - param_4) - (uint)(param_3 < uVar3),param_3 - uVar3);
  }
  uVar4 = param_3;
  if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
    do {
      lVar6 = FUN_00553f00();
      if (lVar6 < 1) {
        iVar1 = (**(code **)(*param_1 + 0xc))(*param_2);
        if (iVar1 == -1) break;
        bVar5 = uVar4 != 0;
        uVar4 = uVar4 - 1;
        uVar3 = 1;
        iVar2 = iVar2 + -1 + (uint)bVar5;
      }
      else {
        if (CONCAT44(iVar2,uVar4) < lVar6) {
          lVar6 = CONCAT44(iVar2,uVar4);
        }
        iStack_c = (int)((ulonglong)lVar6 >> 0x20);
        uVar3 = (uint)lVar6;
        FUN_0170c6f0(*(undefined4 *)param_1[8],param_2,uVar3);
        bVar5 = uVar4 < uVar3;
        uVar4 = uVar4 - uVar3;
        iVar2 = (iVar2 - iStack_c) - (uint)bVar5;
        *(int *)param_1[0xc] = *(int *)param_1[0xc] - uVar3;
        *(int *)param_1[8] = *(int *)param_1[8] + uVar3;
      }
      param_2 = param_2 + uVar3;
      if ((iVar2 < 1) && ((iVar2 < 0 || (uVar4 == 0)))) break;
    } while( true );
  }
  return CONCAT44((param_4 - iVar2) - (uint)(param_3 < uVar4),param_3 - uVar4);
}



/* FUNCTION 2823 ; VA 0x005573f0 ; FUN_005573f0 */

/* WARNING: Removing unreachable block (ram,0x00557432) */
/* WARNING: Removing unreachable block (ram,0x0055743c) */

undefined8 __thiscall FUN_005573f0(int *param_1,undefined *param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  longlong lVar7;
  
  iVar1 = param_4;
  iVar3 = param_4;
  uVar5 = param_3;
  if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
    do {
      lVar7 = FUN_00553f00();
      if (lVar7 < 1) {
        iVar2 = (**(code **)(*param_1 + 0xc))(*param_2);
        if (iVar2 == -1) break;
        bVar6 = uVar5 != 0;
        uVar5 = uVar5 - 1;
        uVar4 = 1;
        iVar3 = iVar3 + -1 + (uint)bVar6;
      }
      else {
        if (CONCAT44(iVar3,uVar5) < lVar7) {
          lVar7 = CONCAT44(iVar3,uVar5);
        }
        param_4 = (int)((ulonglong)lVar7 >> 0x20);
        uVar4 = (uint)lVar7;
        FUN_0170c6f0(*(undefined4 *)param_1[8],param_2,uVar4);
        bVar6 = uVar5 < uVar4;
        uVar5 = uVar5 - uVar4;
        iVar3 = (iVar3 - param_4) - (uint)bVar6;
        *(int *)param_1[0xc] = *(int *)param_1[0xc] - uVar4;
        *(int *)param_1[8] = *(int *)param_1[8] + uVar4;
      }
      param_2 = param_2 + uVar4;
      if ((iVar3 < 1) && ((iVar3 < 0 || (uVar5 == 0)))) break;
    } while( true );
  }
  return CONCAT44((iVar1 - iVar3) - (uint)(param_3 < uVar5),param_3 - uVar5);
}



/* FUNCTION 2824 ; VA 0x005574c0 ; FUN_005574c0 */

undefined * FUN_005574c0(void)

{
  return &DAT_01e90c78;
}



/* FUNCTION 2825 ; VA 0x005574d0 ; FUN_005574d0 */

void FUN_005574d0(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_d8 [40];
  int iStack_b0;
  int iStack_ac;
  undefined uStack_78;
  undefined auStack_70 [8];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  char *pcStack_5c;
  code *pcStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_44;
  undefined4 uStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  char cStack_23;
  undefined uStack_22;
  char cStack_21;
  undefined uStack_20;
  char cStack_1f;
  char cStack_1e;
  char cStack_1d;
  int iStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017924a6;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff1c;
  ExceptionList = &pvStack_10;
  FUN_0054f770(DAT_01e90d74);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  cStack_15 = '\x01';
  cStack_1e = '\0';
  cStack_1d = '\0';
  uStack_20 = 0;
  cStack_1f = '\0';
  cStack_21 = '\0';
  uStack_22 = 0;
  uStack_60 = FUN_0054eff0(&DAT_018bc9b8);
  uStack_8._0_1_ = 2;
  uStack_64 = FUN_0054f790();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_78 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  for (iStack_1c = 1; iStack_1c < param_1; iStack_1c = iStack_1c + 1) {
    if (**(char **)(param_2 + iStack_1c * 4) == '/') {
      **(undefined **)(param_2 + iStack_1c * 4) = 0x2d;
    }
    iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-Install");
    if (iVar2 == 0) {
      FUN_005525b0();
      FUN_00552fb0();
      cStack_15 = '\0';
    }
    else {
      iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-AQTime");
      if (iVar2 == 0) {
        DAT_01d7a638 = 0;
      }
      else {
        iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-Uninstall");
        if (iVar2 == 0) {
          FUN_005533e0("RCCService");
          FUN_005526a0();
          cStack_15 = '\0';
        }
        else {
          iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-Start");
          if (iVar2 == 0) {
            FUN_00553250("RCCService");
            cStack_15 = '\0';
          }
          else {
            iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-Stop");
            if (iVar2 == 0) {
              FUN_00553320("RCCService");
              cStack_15 = '\0';
            }
            else {
              iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-Console");
              if (iVar2 == 0) {
                cStack_1d = '\x01';
                cStack_15 = '\0';
              }
              else {
                iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-LocalTest");
                if ((iVar2 == 0) && (iStack_1c + 1 < param_1)) {
                  cStack_1d = '\x01';
                  cStack_15 = '\0';
                  iStack_1c = iStack_1c + 1;
                  FUN_00551260(*(undefined4 *)(param_2 + iStack_1c * 4));
                }
                else {
                  iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-ConsoleOutput");
                  if ((iVar2 == 0) && (iStack_1c + 1 < param_1)) {
                    iStack_1c = iStack_1c + 1;
                    FUN_00551260(*(undefined4 *)(param_2 + iStack_1c * 4));
                  }
                  else {
                    iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-TestBatchJob");
                    if ((iVar2 == 0) && (iStack_1c + 1 < param_1)) {
                      cStack_1d = '\x01';
                      cStack_15 = '\0';
                      uStack_20 = 1;
                      uStack_78 = 1;
                      iStack_1c = iStack_1c + 1;
                      FUN_00551260(*(undefined4 *)(param_2 + iStack_1c * 4));
                    }
                    else {
                      iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),
                                           "-TestSingleRequest");
                      if (iVar2 == 0) {
                        cStack_21 = '\x01';
                      }
                      else {
                        iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),
                                             "-CrashReporter");
                        if (iVar2 == 0) {
                          cStack_1d = '\x01';
                          cStack_15 = '\0';
                          cStack_1e = '\x01';
                        }
                        else {
                          iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),"-Verbose");
                          if (iVar2 == 0) {
                            cStack_1f = '\x01';
                          }
                          else {
                            iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),
                                                 "-MaximumThreads");
                            if ((iVar2 == 0) && (iStack_1c + 1 < param_1)) {
                              iStack_1c = iStack_1c + 1;
                              uStack_2c = FUN_01717832(*(undefined4 *)(param_2 + iStack_1c * 4));
                            }
                            else {
                              iVar2 = FUN_01717aae(*(undefined4 *)(param_2 + iStack_1c * 4),
                                                   "-MaximumMemory");
                              if ((iVar2 == 0) && (iStack_1c + 1 < param_1)) {
                                iStack_1c = iStack_1c + 1;
                                uStack_28 = FUN_01717832(*(undefined4 *)(param_2 + iStack_1c * 4));
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iStack_30 = FUN_01717a5d("MAXIMUM_THREADS");
  if (iStack_30 != 0) {
    uStack_2c = FUN_01717832(iStack_30);
  }
  iStack_34 = FUN_01717a5d("MAXIMUM_MEMORY");
  if (iStack_34 != 0) {
    uStack_28 = FUN_01717832(iStack_34);
  }
  uStack_68 = FUN_0054f770(DAT_01ea8b1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_005ecfd0();
  if (cStack_1f == '\0') {
    FUN_00557c40("To enable debug output, run with the -verbose flag\n");
  }
  else {
    FUN_005ecfc0(FUN_00554e00);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00550d20();
  if (cStack_1d == '\0') {
    if (cStack_15 != '\0') {
      pcStack_5c = "RCCService";
      pcStack_58 = FUN_00552db0;
      uStack_54 = 0;
      uStack_50 = 0;
      iVar2 = StartServiceCtrlDispatcherA(&pcStack_5c);
      if (iVar2 == 0) {
        uVar3 = GetLastError();
        FUN_00557c40("StartServiceCtrlDispatcher failed (%d)\n",uVar3);
      }
    }
  }
  else {
    FUN_00556600(param_1,param_2,cStack_1e,uStack_20,uStack_22,auStack_d8,uStack_2c,uStack_28);
    cVar1 = FUN_00554d00();
    if ((cVar1 == '\0') || (iStack_b0 != 0 || iStack_ac != 0)) {
      FUN_0058abf0(&iStack_b0);
    }
    if ((cStack_1e == '\0') && (cStack_21 == '\0')) {
      uStack_38 = 1;
    }
    else {
      uStack_38 = 0;
    }
    cStack_23 = (char)uStack_38;
    if ((char)uStack_38 != '\0') {
      SetConsoleCtrlHandler(FUN_005523c0,1);
      while ((DAT_01e90c48 == '\0' &&
             ((iVar2 = FUN_0171d554(), iVar2 == 0 || (iVar2 = FUN_0171d33e(), iVar2 != 0x1b))))) {
        FUN_00577ce0();
      }
    }
    uStack_44 = FUN_0054d820(&DAT_01d59004);
    FUN_0054daf0(uStack_44);
    FUN_00556a60(auStack_70);
    FUN_0057ffd0();
  }
  uStack_8._0_1_ = 2;
  FUN_005507b0();
  FUN_005507b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_005507b0();
  FUN_00557af3();
  return;
}



/* FUNCTION 2826 ; VA 0x00557ac5 ; Catch@00557ac5 */

undefined * Catch_00557ac5(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0x38),6);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x38) + 4))();
  FUN_005531f0(1,uVar1);
  return &DAT_00557afc;
}



/* FUNCTION 2827 ; VA 0x00557af3 ; FUN_00557af3 */

undefined4 FUN_00557af3(void)

{
  char cVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 0;
  cVar1 = FUN_005542b0();
  if ((cVar1 != '\0') && (cVar1 = FUN_005512d0(), cVar1 != '\0')) {
    do {
      *(undefined4 *)(unaff_EBP + -0x44) = 1;
      uVar2 = FUN_0054d820(unaff_EBP + -0x44);
      FUN_0054e4d0(uVar2);
    } while( true );
  }
  FUN_0087b360();
  cVar1 = FUN_005512d0();
  if ((cVar1 != '\0') && (cVar1 = FUN_01675410(), cVar1 == '\0')) {
    FUN_01716b6f(0);
  }
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_00550d20();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 0;
}



/* FUNCTION 2828 ; VA 0x00557ba0 ; FUN_00557ba0 */

undefined4 FUN_00557ba0(int param_1,uint param_2,int param_3,uint param_4)

{
  undefined4 *puVar1;
  
  if (param_4 == 0) {
    return 0;
  }
  if (param_1 == 0) {
    puVar1 = (undefined4 *)FUN_0171689d();
    *puVar1 = 0x16;
    FUN_01716793();
    return 0x16;
  }
  if ((param_3 != 0) && (param_4 <= param_2)) {
    FUN_0170c6f0(param_1,param_3,param_4);
    return 0;
  }
  FUN_0170d1f0(param_1,0,param_2);
  if (param_3 == 0) {
    puVar1 = (undefined4 *)FUN_0171689d();
    *puVar1 = 0x16;
    FUN_01716793();
  }
  else if (param_2 < param_4) {
    puVar1 = (undefined4 *)FUN_0171689d();
    *puVar1 = 0x22;
    FUN_01716793();
    return 0x22;
  }
  return 0x16;
}



/* FUNCTION 2829 ; VA 0x00557c40 ; FUN_00557c40 */

void FUN_00557c40(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_0171804f(1);
  puVar2 = (undefined4 *)FUN_005574c0(uVar1,param_1,0,&stack0x00000008);
  FUN_0171cf89(*puVar2,puVar2[1]);
  return;
}



/* FUNCTION 2830 ; VA 0x00557c70 ; FUN_00557c70 */

undefined4 * __thiscall FUN_00557c70(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_00557d10(param_2);
  uVar2 = param_1[1];
  param_1[1] = *puVar4;
  *puVar4 = uVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  _guard_check_icall(param_1,param_2,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2831 ; VA 0x00557d10 ; FUN_00557d10 */

undefined4 * __thiscall FUN_00557d10(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::sp_counted_impl_p<class_boost::exception_detail::clone_base_const_>::
              vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2832 ; VA 0x00557d85 ; Catch_All@00557d85 */

void Catch_All_00557d85(void)

{
  int unaff_EBP;
  
  FUN_0055d6d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2833 ; VA 0x00557da0 ; FUN_00557da0 */

undefined * __thiscall FUN_00557da0(undefined *param_1,int param_2,int param_3)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (param_2 != param_3) {
    FUN_005542c0(param_2,param_3 - param_2);
  }
  return param_1;
}



/* FUNCTION 2834 ; VA 0x00557de0 ; FUN_00557de0 */

int * __thiscall FUN_00557de0(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  piVar3 = (int *)FUN_00557f00(param_2);
  iVar1 = param_1[1];
  param_1[1] = *piVar3;
  *piVar3 = iVar1;
  uStack_8._0_1_ = 1;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  piVar3 = (int *)(-(uint)(param_2 != 0) & param_2 + 8U);
  if ((piVar3 != (int *)0x0) && ((piVar3[1] == 0 || (*(int *)(piVar3[1] + 4) == 0)))) {
    piVar2 = (int *)param_1[1];
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    *piVar3 = param_2;
    piVar4 = (int *)piVar3[1];
    uStack_8._0_1_ = 2;
    if (piVar2 != piVar4) {
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[2] = piVar2[2] + 1;
        UNLOCK();
        piVar4 = (int *)piVar3[1];
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 8))();
        }
      }
      piVar3[1] = (int)piVar2;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        piVar3 = piVar2 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2835 ; VA 0x00557f00 ; FUN_00557f00 */

undefined4 * __thiscall FUN_00557f00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792500;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<struct_boost::detail::shared_state<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2836 ; VA 0x00557f75 ; Catch_All@00557f75 */

void Catch_All_00557f75(void)

{
  int unaff_EBP;
  
  FUN_0055d6f0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2837 ; VA 0x00557f90 ; FUN_00557f90 */

undefined4 * __thiscall FUN_00557f90(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  return param_1;
}



/* FUNCTION 2838 ; VA 0x00557fc0 ; FUN_00557fc0 */

undefined4 * __thiscall FUN_00557fc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  return param_1;
}



/* FUNCTION 2839 ; VA 0x00557ff0 ; FUN_00557ff0 */

undefined4 * __thiscall FUN_00557ff0(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0055ba30(param_2,param_2);
  return param_1;
}



/* FUNCTION 2840 ; VA 0x00558020 ; FUN_00558020 */

undefined4 * __thiscall FUN_00558020(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_7850e3f498f96950946230d03482994b>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[2];
  param_1[4] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[5] = param_2[4];
  param_1[6] = param_2[5];
  param_2[4] = 0;
  param_2[5] = 0;
  return param_1;
}



/* FUNCTION 2841 ; VA 0x005580b0 ; FUN_005580b0 */

undefined4 * __thiscall FUN_005580b0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_ce3ec86729cff41111bf35de00f2a9a5>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[2];
  param_1[4] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[5] = param_2[4];
  param_1[6] = param_2[5];
  param_2[4] = 0;
  param_2[5] = 0;
  return param_1;
}



/* FUNCTION 2842 ; VA 0x00558140 ; FUN_00558140 */

undefined2 * __thiscall FUN_00558140(undefined2 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 10) = 7;
  *param_1 = 0;
  uStack_8 = 0;
  iVar1 = param_2[4];
  if (iVar1 != 0) {
    puVar2 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar2 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uVar3 = FUN_01686580();
    FUN_01685950(param_2,iVar1 + (int)puVar2,param_1,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2843 ; VA 0x005581c0 ; FUN_005581c0 */

undefined4 * __thiscall FUN_005581c0(undefined4 *param_1)

{
  uint uVar1;
  uint in_stack_00000038;
  undefined4 in_stack_00000048;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined auStack_b8 [64];
  undefined4 uStack_78;
  uint uStack_74;
  undefined4 *puStack_70;
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792560;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_60;
  puStack_70 = (undefined4 *)&stack0x00000008;
  uStack_8 = 0;
  uStack_74 = 0x558201;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puStack_70 = (undefined4 *)&stack0x00000020;
  uStack_8._0_1_ = 1;
  uStack_74 = 0x558211;
  FUN_0054ef60();
  puStack_70 = &stack0x00000038;
  uStack_8._0_1_ = 2;
  uStack_74 = 0x558221;
  FUN_0054ef60();
  uStack_18 = in_stack_00000050;
  *param_1 = 0;
  uStack_8._0_1_ = 3;
  puStack_14 = auStack_b8;
  FUN_0054ef60(auStack_60);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_48);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puStack_70 = (undefined4 *)uStack_18;
  FUN_0055ca00();
  if (0xf < uStack_1c) {
    puStack_70 = (undefined4 *)(uStack_1c + 1);
    uVar1 = auStack_30[0];
    if (0xfff < puStack_70) {
      uVar1 = *(uint *)(auStack_30[0] - 4);
      puStack_70 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (auStack_30[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_70 = (undefined4 *)0x558331;
        FUN_017167a3();
      }
    }
    uStack_78 = 0x5582b1;
    uStack_74 = uVar1;
    FUN_01674ea0();
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  puStack_70 = (undefined4 *)0x5582ce;
  FUN_005509f0();
  if (0xf < in_stack_0000004c) {
    puStack_70 = (undefined4 *)(in_stack_0000004c + 1);
    uVar1 = in_stack_00000038;
    if (0xfff < puStack_70) {
      uVar1 = *(uint *)(in_stack_00000038 - 4);
      puStack_70 = (undefined4 *)(in_stack_0000004c + 0x24);
      if (0x1f < (in_stack_00000038 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_70 = (undefined4 *)&UNK_00558336;
        FUN_017167a3();
      }
    }
    uStack_78 = 0x5582fb;
    uStack_74 = uVar1;
    FUN_01674ea0();
  }
  in_stack_00000048 = 0;
  in_stack_0000004c = 0xf;
  in_stack_00000038 = in_stack_00000038 & 0xffffff00;
  puStack_70 = (undefined4 *)0x558318;
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2844 ; VA 0x00558340 ; FUN_00558340 */

undefined4 * __thiscall
FUN_00558340(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_018c0c68;
  cVar3 = FUN_0055cb90(param_2,param_3,param_4,param_5,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 2845 ; VA 0x00558440 ; FUN_00558440 */

undefined4 * __thiscall
FUN_00558440(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  int in_stack_0000002c;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  int *piStack_78;
  int aiStack_64 [5];
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792588;
  pvStack_10 = ExceptionList;
  piStack_78 = &param_4;
  uStack_8 = 0;
  iStack_7c = 0x558481;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_4c = in_stack_00000024;
  uStack_48 = in_stack_00000028;
  iStack_44 = in_stack_0000002c;
  uStack_40 = param_2;
  uStack_3c = param_3;
  piStack_78 = aiStack_64;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_7c = 0x5584b5;
  FUN_0054ef60();
  uStack_20 = uStack_4c;
  uStack_1c = uStack_48;
  iStack_18 = iStack_44;
  piStack_78 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = &uStack_a4;
  uStack_a4 = uStack_40;
  uStack_a0 = uStack_3c;
  FUN_0054ef60(aiStack_38);
  uStack_84 = uStack_20;
  uStack_80 = uStack_1c;
  iStack_7c = iStack_18;
  ppuVar3 = &PTR_FUN_018c0c60;
  cVar1 = FUN_0055ccc0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_24) {
    piStack_78 = (int *)(uStack_24 + 1);
    iVar2 = aiStack_38[0];
    if (0xfff < piStack_78) {
      iVar2 = *(int *)(aiStack_38[0] + -4);
      piStack_78 = (int *)(uStack_24 + 0x24);
      if (0x1f < (aiStack_38[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_78 = (int *)0x5585be;
        FUN_017167a3();
      }
    }
    uStack_80 = 0x558542;
    iStack_7c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_50) {
    piStack_78 = (int *)(uStack_50 + 1);
    iVar2 = aiStack_64[0];
    if (0xfff < piStack_78) {
      iVar2 = *(int *)(aiStack_64[0] + -4);
      piStack_78 = (int *)(uStack_50 + 0x24);
      if (0x1f < (aiStack_64[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_78 = (int *)0x5585c3;
        FUN_017167a3();
      }
    }
    uStack_80 = 0x558572;
    iStack_7c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000020) {
    piStack_78 = (int *)(in_stack_00000020 + 1);
    iVar2 = param_4;
    if (0xfff < piStack_78) {
      iVar2 = *(int *)(param_4 + -4);
      piStack_78 = (int *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_78 = (int *)&UNK_005585c8;
        FUN_017167a3();
      }
    }
    uStack_80 = 0x5585a2;
    iStack_7c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2846 ; VA 0x005585d0 ; FUN_005585d0 */

undefined4 * __thiscall FUN_005585d0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_00558670(param_2);
  uVar2 = param_1[1];
  param_1[1] = *puVar4;
  *puVar4 = uVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  _guard_check_icall(param_1,param_2,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2847 ; VA 0x00558670 ; FUN_00558670 */

undefined4 * __thiscall FUN_00558670(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017925a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<class_boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2848 ; VA 0x005586e5 ; Catch_All@005586e5 */

void Catch_All_005586e5(void)

{
  int unaff_EBP;
  
  FUN_0055d6f0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2849 ; VA 0x00558700 ; FUN_00558700 */

int * __thiscall FUN_00558700(int *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  uint auStack_34 [2];
  undefined auStack_2c [24];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017925c8;
  pvStack_10 = ExceptionList;
  auStack_34[0] = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_005880d0(param_2);
  uStack_8 = 0;
  iVar2 = FUN_00563bf0(auStack_34);
  *param_1 = iVar2;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  if (auStack_34[0] != 0) {
    if (((auStack_34[0] & 1) == 0) && (*(code **)(auStack_34[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_34[0] & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    auStack_34[0] = 0;
  }
  uStack_8._0_1_ = 2;
  cVar1 = FUN_0168a8f0();
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar3 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar3);
}



/* FUNCTION 2850 ; VA 0x005587b0 ; FUN_005587b0 */

undefined4 * __thiscall FUN_005587b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  return param_1;
}



/* FUNCTION 2851 ; VA 0x005587e0 ; FUN_005587e0 */

undefined4 * __thiscall FUN_005587e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  uVar2 = *param_2;
  uVar3 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar2;
  piVar4 = (int *)param_1[1];
  param_1[1] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 2852 ; VA 0x00558840 ; FUN_00558840 */

void FUN_00558840(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_0055b3b0(param_1,param_2,*puVar1);
  return;
}



/* FUNCTION 2853 ; VA 0x00558860 ; FUN_00558860 */

int * FUN_00558860(int *param_1,undefined4 *param_2)

{
  (*(code *)*param_2)(*(int *)(*param_1 + 4) + (int)param_1,param_2[2],param_2[3]);
  return param_1;
}



/* FUNCTION 2854 ; VA 0x00558890 ; FUN_00558890 */

int * FUN_00558890(int *param_1,char *param_2)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  char cVar4;
  uint uVar5;
  int *piVar6;
  char *pcVar7;
  uint uVar8;
  int iVar9;
  undefined8 uVar10;
  int iStack_30;
  int iStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017925f0;
  pvStack_10 = ExceptionList;
  pcVar7 = param_2;
  do {
    cVar4 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar4 != '\0');
  uVar8 = (int)pcVar7 - (int)(param_2 + 1);
  iVar9 = *param_1;
  iVar2 = *(int *)(iVar9 + 4);
  iStack_2c = *(int *)((int)param_1 + iVar2 + 0x24);
  uVar5 = *(uint *)((int)param_1 + iVar2 + 0x20);
  if ((iStack_2c < 0) ||
     ((iStack_2c < 1 && (((uVar5 == 0 || (iStack_2c < 0)) || ((iStack_2c < 1 && (uVar5 <= uVar8)))))
      ))) {
    iStack_2c = 0;
    iStack_30 = 0;
  }
  else {
    iStack_30 = uVar5 - uVar8;
    iStack_2c = iStack_2c - (uint)(uVar5 < uVar8);
  }
  piVar6 = *(int **)((int)param_1 + iVar2 + 0x38);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar6 + 4))();
    iVar9 = *param_1;
  }
  iVar2 = *(int *)(iVar9 + 4);
  uStack_8 = 0;
  if (((*(int *)((int)param_1 + iVar2 + 0xc) == 0) && (*(int *)((int)param_1 + iVar2 + 0x3c) != 0))
     && (*(int **)((int)param_1 + iVar2 + 0x3c) != param_1)) {
    FUN_00581480();
    iVar9 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar9 + 4) + 0xc + (int)param_1) != 0) {
    FUN_00554460(*(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | 4,0);
    uStack_8 = 4;
    cVar4 = thunk_FUN_0170e3b7();
    if (cVar4 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar6 != (int *)0x0) {
      (**(code **)(*piVar6 + 8))();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_8 = 2;
  if ((*(uint *)(*(int *)(iVar9 + 4) + 0x14 + (int)param_1) & 0x1c0) != 0x40) {
    for (; (-1 < iStack_2c && ((0 < iStack_2c || (iStack_30 != 0)))); iStack_30 = iStack_30 + -1) {
      piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      bVar1 = *(byte *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1);
      if (*(int *)piVar6[8] == 0) {
LAB_005589e2:
        uVar5 = (**(code **)(*piVar6 + 0xc))(bVar1);
      }
      else {
        iVar2 = *(int *)piVar6[0xc];
        if (iVar2 < 1) goto LAB_005589e2;
        *(int *)piVar6[0xc] = iVar2 + -1;
        pbVar3 = *(byte **)piVar6[8];
        *(byte **)piVar6[8] = pbVar3 + 1;
        *pbVar3 = bVar1;
        uVar5 = (uint)bVar1;
      }
      if (uVar5 == 0xffffffff) goto LAB_00558a88;
      iStack_2c = iStack_2c + -1 + (uint)(iStack_30 != 0);
    }
    iVar9 = *param_1;
  }
  uVar10 = (**(code **)(**(int **)(*(int *)(iVar9 + 4) + 0x38 + (int)param_1) + 0x24))
                     (param_2,uVar8,0);
  if (((uint)uVar10 == uVar8) && ((int)((ulonglong)uVar10 >> 0x20) == 0)) {
    for (; (-1 < iStack_2c && ((0 < iStack_2c || (iStack_30 != 0)))); iStack_30 = iStack_30 + -1) {
      piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      bVar1 = *(byte *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1);
      if (*(int *)piVar6[8] == 0) {
LAB_00558a66:
        uVar5 = (**(code **)(*piVar6 + 0xc))(bVar1);
      }
      else {
        iVar2 = *(int *)piVar6[0xc];
        if (iVar2 < 1) goto LAB_00558a66;
        *(int *)piVar6[0xc] = iVar2 + -1;
        pbVar3 = *(byte **)piVar6[8];
        *(byte **)piVar6[8] = pbVar3 + 1;
        *pbVar3 = bVar1;
        uVar5 = (uint)bVar1;
      }
      if (uVar5 == 0xffffffff) break;
      iStack_2c = iStack_2c + -1 + (uint)(iStack_30 != 0);
    }
  }
LAB_00558a88:
  iVar2 = *(int *)(*param_1 + 4);
  *(undefined4 *)(iVar2 + 0x20 + (int)param_1) = 0;
  *(undefined4 *)(iVar2 + 0x24 + (int)param_1) = 0;
  piVar6 = (int *)FUN_00558abe();
  return piVar6;
}



/* FUNCTION 2855 ; VA 0x00558a9f ; Catch_All@00558a9f */

undefined * Catch_All_00558a9f(void)

{
  FUN_005565b0(4,1);
  return &DAT_00558ab8;
}



/* FUNCTION 2856 ; VA 0x00558abe ; FUN_00558abe */

void FUN_00558abe(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int *unaff_EBX;
  int unaff_EBP;
  uint unaff_ESI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_EBX + *(int *)(*unaff_EBX + 4) + 0xc) | unaff_ESI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_EBX + *(int *)(*unaff_EBX + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 4;
  cVar3 = thunk_FUN_0170e3b7();
  piVar1 = *(int **)(unaff_EBP + -0x2c);
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar2 = *piVar1;
  *(undefined *)(unaff_EBP + -4) = 5;
  piVar1 = *(int **)(*(int *)(iVar2 + 4) + 0x38 + (int)piVar1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 2857 ; VA 0x00558b30 ; FUN_00558b30 */

void FUN_00558b30(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0055c360(param_1,*puVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 2858 ; VA 0x00558b60 ; FUN_00558b60 */

void FUN_00558b60(undefined4 *param_1,char *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0055c360(param_1,*puVar1,param_2,(int)pcVar3 - (int)(param_2 + 1));
  return;
}



/* FUNCTION 2859 ; VA 0x00558ba0 ; FUN_00558ba0 */

undefined4 * FUN_00558ba0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  
  uVar1 = param_2[4];
  uVar2 = param_3[4];
  if ((param_2[5] - uVar1 < uVar2) && (uVar1 <= param_3[5] - uVar2)) {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar6 = (undefined4 *)FUN_00585d40(0,param_2,uVar1);
  }
  else {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    puVar6 = (undefined4 *)FUN_00554150(param_3,uVar2);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  uVar3 = puVar6[1];
  uVar4 = puVar6[2];
  uVar5 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar3;
  param_1[2] = uVar4;
  param_1[3] = uVar5;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  return param_1;
}



/* FUNCTION 2860 ; VA 0x00558c20 ; FUN_00558c20 */

undefined4 * FUN_00558c20(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  puVar4 = (undefined4 *)FUN_00554150(param_3,*puVar4);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  return param_1;
}



/* FUNCTION 2861 ; VA 0x00558c80 ; FUN_00558c80 */

undefined4 * FUN_00558c80(undefined4 *param_1,undefined4 param_2,char *param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char *pcVar5;
  undefined4 *puVar6;
  
  pcVar5 = param_3;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  puVar6 = (undefined4 *)FUN_00554150(param_3,(int)pcVar5 - (int)(param_3 + 1));
  param_1[4] = 0;
  param_1[5] = 0;
  uVar2 = puVar6[1];
  uVar3 = puVar6[2];
  uVar4 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  return param_1;
}



/* FUNCTION 2862 ; VA 0x00558ce0 ; FUN_00558ce0 */

undefined * FUN_00558ce0(undefined *param_1,undefined4 *param_2,char *param_3)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  pcVar3 = param_3;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  FUN_0058a190(pcVar3 + (param_2[4] - (int)(param_3 + 1)));
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  pcVar3 = param_3;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  FUN_00554150(param_3,(int)pcVar3 - (int)(param_3 + 1));
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2863 ; VA 0x00558d90 ; FUN_00558d90 */

undefined4 * FUN_00558d90(undefined4 *param_1,char *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char *pcVar5;
  undefined4 *puVar6;
  
  pcVar5 = param_2;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  puVar6 = (undefined4 *)FUN_00585d40(0,param_2,(int)pcVar5 - (int)(param_2 + 1));
  param_1[4] = 0;
  param_1[5] = 0;
  uVar2 = puVar6[1];
  uVar3 = puVar6[2];
  uVar4 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  return param_1;
}



/* FUNCTION 2864 ; VA 0x00558df0 ; FUN_00558df0 */

undefined * FUN_00558df0(undefined *param_1,char *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  FUN_0058a190(pcVar3 + (param_3[4] - (int)(param_2 + 1)));
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  FUN_00554150(param_2,(int)pcVar3 - (int)(param_2 + 1));
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_00554150(param_3,*puVar1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2865 ; VA 0x00558ea0 ; FUN_00558ea0 */

uint FUN_00558ea0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar3 = FUN_0055c2d0(param_1,*puVar2,param_2,*puVar1);
  return uVar3 >> 0x1f;
}



/* FUNCTION 2866 ; VA 0x00558f10 ; thunk_FUN_00913630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00913630(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6150;
  pvStack_10 = ExceptionList;
  if (DAT_01ee1c80 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1e98) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee1e98);
      if (DAT_01ee1e98 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Player",0,uStack_20,0,0,0x13,0,0);
        _DAT_01ee1e90 = RBX::Creator<class_RBX::Player>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee1c88,&DAT_01ee1e90);
        FUN_016f3654(FUN_01884f20);
        FUN_016f37bf(&DAT_01ee1e98);
      }
    }
    DAT_01ee1c80 = &DAT_01ee1c88;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee1c80;
}



/* FUNCTION 2867 ; VA 0x00558f80 ; FUN_00558f80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00558f80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792620;
  pvStack_10 = ExceptionList;
  if (DAT_01ea8748 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8960) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea8960);
      if (DAT_01ea8960 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RCCTexturePackGenerator",1,uStack_20,0,0,0x1b,0,0);
        _DAT_01ea8958 = RBX::Creator<class_RCCTexturePackGenerator>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ea8750,&DAT_01ea8958);
        FUN_016f3654(FUN_0187b360);
        FUN_016f37bf(&DAT_01ea8960);
      }
    }
    DAT_01ea8748 = &DAT_01ea8750;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8748;
}



/* FUNCTION 2868 ; VA 0x00559080 ; FUN_00559080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00559080(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792650;
  pvStack_10 = ExceptionList;
  if (DAT_01ea852c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8740) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea8740);
      if (DAT_01ea8740 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ThumbnailGenerator",1,uStack_20,0,0,0x1b,0,0);
        _DAT_01ea8738 = RBX::Creator<class_ThumbnailGenerator>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ea8530,&DAT_01ea8738);
        FUN_016f3654(FUN_0187b3c0);
        FUN_016f37bf(&DAT_01ea8740);
      }
    }
    DAT_01ea852c = &DAT_01ea8530;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea852c;
}



/* FUNCTION 2869 ; VA 0x00559180 ; FUN_00559180 */

void FUN_00559180(void)

{
  int iVar1;
  
  if (DAT_01ea8964 == 0) {
    iVar1 = FUN_00558f80();
    DAT_01ea8964 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 2870 ; VA 0x005591a0 ; FUN_005591a0 */

void FUN_005591a0(void)

{
  int iVar1;
  
  if (DAT_01ea8744 == 0) {
    iVar1 = FUN_00559080();
    DAT_01ea8744 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 2871 ; VA 0x005591c0 ; FUN_005591c0 */

int FUN_005591c0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00575b80();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  *(undefined4 *)(iVar2 + 0x10) = *param_1;
  *(undefined4 *)(iVar2 + 0x14) = param_1[1];
  iVar1 = param_1[2];
  *(int *)(iVar2 + 0x18) = iVar1;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
  }
  return iVar2;
}



/* FUNCTION 2872 ; VA 0x00559200 ; FUN_00559200 */

void FUN_00559200(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00575ba0();
  *(undefined2 *)(iVar4 + 0xc) = 0;
  param_2 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(iVar4 + 0x10) = *param_2;
  *(undefined4 *)(iVar4 + 0x14) = uVar1;
  *(undefined4 *)(iVar4 + 0x18) = uVar2;
  *(undefined4 *)(iVar4 + 0x1c) = uVar3;
  *(undefined8 *)(iVar4 + 0x20) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *(undefined4 *)(iVar4 + 0x28) = 0;
  return;
}



/* FUNCTION 2873 ; VA 0x00559250 ; FUN_00559250 */

void FUN_00559250(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_00575b80();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)*param_2;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  return;
}



/* FUNCTION 2874 ; VA 0x00559280 ; FUN_00559280 */

int FUN_00559280(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792660;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575bc0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  *(undefined4 *)(iVar1 + 0x28) = 0;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 2875 ; VA 0x005592eb ; Catch_All@005592eb */

void Catch_All_005592eb(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2876 ; VA 0x00559300 ; FUN_00559300 */

int FUN_00559300(undefined4 param_1)

{
  int iVar1;
  undefined4 *unaff_FS_OFFSET;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792670;
  uStack_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &uStack_10;
  iVar1 = FUN_00575be0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(param_1);
  *unaff_FS_OFFSET = uStack_10;
  return iVar1;
}



/* FUNCTION 2877 ; VA 0x0055935b ; Catch_All@0055935b */

void Catch_All_0055935b(void)

{
  int unaff_EBP;
  
  FUN_00576e50(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2878 ; VA 0x00559370 ; FUN_00559370 */

void FUN_00559370(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00575be0();
  *(undefined2 *)(iVar4 + 0xc) = 0;
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *(undefined4 *)(iVar4 + 0x10) = *param_1;
  *(undefined4 *)(iVar4 + 0x14) = uVar1;
  *(undefined4 *)(iVar4 + 0x18) = uVar2;
  *(undefined4 *)(iVar4 + 0x1c) = uVar3;
  *(undefined8 *)(iVar4 + 0x20) = *(undefined8 *)(param_1 + 4);
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 2879 ; VA 0x005593c0 ; FUN_005593c0 */

undefined4 * __thiscall
FUN_005593c0(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792680;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_005591c0(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_005593c0(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_005593c0(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 2880 ; VA 0x00559454 ; Catch_All@00559454 */

void Catch_All_00559454(void)

{
  int unaff_EBP;
  
  FUN_005765a0(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2881 ; VA 0x00559470 ; FUN_00559470 */

undefined4 * FUN_00559470(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    iVar2 = (int)param_1 - (int)param_3;
    piVar3 = param_3 + 1;
    do {
      *param_3 = *param_1;
      if ((int *)(iVar2 + (int)piVar3) != piVar3) {
        if (*piVar3 != 0) {
          (**(code **)(*piVar3 + 8))(piVar3 + 1);
          *piVar3 = 0;
        }
        puVar1 = *(undefined4 **)(iVar2 + (int)piVar3);
        if (puVar1 != (undefined4 *)0x0) {
          (*(code *)*puVar1)((int)(piVar3 + 1) + iVar2,piVar3 + 1);
          *piVar3 = *(int *)(iVar2 + (int)piVar3);
        }
      }
      param_1 = param_1 + 0x34;
      param_3 = param_3 + 0x34;
      piVar3 = piVar3 + 0x34;
    } while (param_1 != param_2);
  }
  return param_3;
}



/* FUNCTION 2882 ; VA 0x00559500 ; FUN_00559500 */

void FUN_00559500(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar1 = param_1[5];
      if (0xf < uVar1) {
        iVar2 = *param_1;
        uVar4 = uVar1 + 1;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar1 + 0x24;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      param_1[4] = 0;
      param_1[5] = 0xf;
      *(undefined *)param_1 = 0;
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 2883 ; VA 0x00559570 ; FUN_00559570 */

void FUN_00559570(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar1 = param_1[5];
      if (0xf < uVar1) {
        iVar2 = *param_1;
        uVar4 = uVar1 + 1;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar1 + 0x24;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      param_1[4] = 0;
      param_1[5] = 0xf;
      *(undefined *)param_1 = 0;
      param_1 = param_1 + 6;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 2884 ; VA 0x005595e0 ; FUN_005595e0 */

void FUN_005595e0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = (int *)*param_1;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[4] + -1;
        piVar1[4] = iVar2;
        UNLOCK();
        if ((iVar2 == 0) && (piVar1 != (int *)0x0)) {
          iVar2 = piVar1[1];
          if ((iVar2 != 0) && (iVar2 != -1)) {
            CloseHandle(iVar2);
          }
          iVar2 = *piVar1;
          if ((iVar2 != 0) && (iVar2 != -1)) {
            CloseHandle(iVar2);
          }
          FUN_01674ea0(piVar1,0x14);
        }
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 2885 ; VA 0x00559650 ; FUN_00559650 */

void FUN_00559650(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      uStack_8 = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 8))();
          }
        }
      }
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2886 ; VA 0x005596d0 ; FUN_005596d0 */

void FUN_005596d0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 2887 ; VA 0x00559720 ; FUN_00559720 */

void FUN_00559720(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    piVar2 = param_1 + 1;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      if (*piVar2 != 0) {
        (**(code **)(*piVar2 + 8))(piVar2 + 1);
      }
      piVar1 = piVar2 + 0x33;
      piVar2 = piVar2 + 0x34;
    } while (piVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2888 ; VA 0x00559790 ; FUN_00559790 */

int __thiscall FUN_00559790(uint *param_1,uint param_2,undefined4 param_3,undefined8 *param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792690;
  pvStack_10 = ExceptionList;
  uVar7 = *param_1;
  iVar2 = (int)(param_1[1] - uVar7) >> 5;
  if (iVar2 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar5 = (int)(param_1[2] - uVar7) >> 5;
  uVar8 = uVar1;
  if ((uVar5 <= 0x7ffffff - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar5 = uVar8 * 0x20;
  if (uVar8 < 0x8000000) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_0055981b;
    if (uVar5 == 0) {
      uVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_0055981b:
    uVar3 = uVar8 + 0x23;
    if (uVar3 <= uVar8) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(uVar3);
    if (iVar2 == 0) goto LAB_0055994e;
    uVar8 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar2;
  }
  uVar7 = param_2 - uVar7 & 0xffffffe0;
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined8 *)(uVar7 + 0x18 + uVar8) = *param_4;
  if (param_2 == param_1[1]) {
    FUN_0055c650(*param_1,param_1[1],uVar8,param_1);
  }
  else {
    FUN_0055c650(*param_1,param_2,uVar8,param_1);
    FUN_0055c650(param_2,param_1[1],uVar7 + uVar8 + 0x20,param_1);
  }
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    uVar3 = *param_1;
    uVar6 = param_1[2] - uVar3 & 0xffffffe0;
    uVar4 = uVar3;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uVar3 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar3 - uVar4) - 4) {
LAB_0055994e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar1 * 0x20 + uVar8;
  param_1[2] = uVar5 + uVar8;
  ExceptionList = pvStack_10;
  return *param_1 + uVar7;
}



/* FUNCTION 2889 ; VA 0x00559925 ; Catch_All@00559925 */

void Catch_All_00559925(void)

{
  int unaff_EBP;
  
  FUN_00576230(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2890 ; VA 0x00559960 ; FUN_00559960 */

int __thiscall FUN_00559960(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017926a0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0x18;
  if (iVar2 == 0xaaaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0x18;
  uVar8 = uVar6;
  if ((uVar3 <= 0xaaaaaaa - (uVar3 >> 1)) && (uVar8 = (uVar3 >> 1) + uVar3, uVar8 < uVar6)) {
    uVar8 = uVar6;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00577fb0(uVar8);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0x18) * 0x18;
  FUN_0054ef60(param_3);
  if (param_2 == param_1[1]) {
    FUN_0055c6d0(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_0055c6d0(*param_1,param_2,iVar4,param_1);
    FUN_0055c6d0(param_2,param_1[1],iVar5 + iVar4 + 0x18,param_1);
  }
  if (*param_1 != 0) {
    FUN_00559570(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar6 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar7 = iVar1;
    if (0xfff < uVar6) {
      iVar7 = *(int *)(iVar1 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar1 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar6);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + (iVar2 * 3 + 3) * 8;
  param_1[2] = iVar4 + uVar8 * 0x18;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 2891 ; VA 0x00559aed ; Catch_All@00559aed */

void Catch_All_00559aed(void)

{
  int unaff_EBP;
  
  FUN_005762c0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x14));
  FUN_0057d2f0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2892 ; VA 0x00559b20 ; FUN_00559b20 */

int __thiscall FUN_00559b20(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int iVar11;
  
  iVar6 = *param_1;
  iVar11 = (int)param_2 - iVar6 >> 2;
  iVar2 = param_1[1] - iVar6 >> 2;
  if (iVar2 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar7 = param_1[2] - iVar6 >> 2;
  uVar4 = uVar3;
  if ((uVar7 <= 0x3fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  uVar7 = uVar4 * 4;
  if (uVar4 < 0x40000000) {
    if (0xfff < uVar7) goto LAB_00559b92;
    if (uVar7 == 0) {
      piVar9 = (int *)0x0;
    }
    else {
      piVar9 = (int *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00559b92:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_00559cd4;
    piVar9 = (int *)(iVar6 + 0x23U & 0xffffffe0);
    piVar9[-1] = iVar6;
  }
  iVar6 = *param_3;
  piVar9[iVar11] = iVar6;
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 0x10) = *(int *)(iVar6 + 0x10) + 1;
    UNLOCK();
  }
  piVar1 = (int *)param_1[1];
  piVar8 = (int *)*param_1;
  piVar10 = piVar9;
  if (param_2 == piVar1) {
    for (; piVar8 != piVar1; piVar8 = piVar8 + 1) {
      iVar6 = *piVar8;
      *piVar10 = iVar6;
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 0x10) = *(int *)(iVar6 + 0x10) + 1;
        UNLOCK();
      }
      piVar10 = piVar10 + 1;
    }
  }
  else {
    for (; piVar8 != param_2; piVar8 = piVar8 + 1) {
      *piVar10 = *piVar8;
      *piVar8 = 0;
      piVar10 = piVar10 + 1;
    }
    FUN_005595e0(piVar10,piVar10,param_1);
    piVar1 = (int *)param_1[1];
    piVar10 = piVar9 + iVar11 + 1;
    if (param_2 != piVar1) {
      do {
        *piVar10 = *param_2;
        piVar10 = piVar10 + 1;
        *param_2 = 0;
        param_2 = param_2 + 1;
      } while (param_2 != piVar1);
    }
  }
  FUN_005595e0(piVar10,piVar10,param_1);
  if (*param_1 != 0) {
    FUN_005595e0(*param_1,param_1[1],param_1);
    iVar6 = *param_1;
    uVar7 = param_1[2] - iVar6 & 0xfffffffc;
    iVar2 = iVar6;
    if (0xfff < uVar7) {
      iVar2 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar2) - 4U) {
LAB_00559cd4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar7);
  }
  *param_1 = (int)piVar9;
  param_1[1] = (int)(piVar9 + uVar3);
  param_1[2] = (int)(piVar9 + uVar4);
  return *param_1 + iVar11 * 4;
}



/* FUNCTION 2893 ; VA 0x00559ce0 ; FUN_00559ce0 */

int __thiscall FUN_00559ce0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined4 *puVar12;
  
  iVar6 = *param_1;
  iVar11 = (int)param_2 - iVar6 >> 3;
  iVar2 = param_1[1] - iVar6 >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar7 = param_1[2] - iVar6 >> 3;
  uVar4 = uVar3;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  uVar7 = uVar4 * 8;
  if (uVar4 < 0x20000000) {
    if (0xfff < uVar7) goto LAB_00559d52;
    if (uVar7 == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00559d52:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_00559e6d;
    puVar9 = (undefined4 *)(iVar6 + 0x23U & 0xffffffe0);
    puVar9[-1] = iVar6;
  }
  puVar1 = puVar9 + iVar11 * 2;
  *puVar1 = *param_3;
  puVar1[1] = param_3[1];
  puVar12 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar10 = puVar9;
  if (param_2 == puVar12) {
    for (; puVar8 != puVar12; puVar8 = puVar8 + 2) {
      *puVar10 = *puVar8;
      puVar10[1] = puVar8[1];
      puVar10 = puVar10 + 2;
    }
  }
  else {
    if (puVar8 != param_2) {
      do {
        *puVar10 = *puVar8;
        puVar12 = puVar8 + 1;
        puVar8 = puVar8 + 2;
        puVar10[1] = *puVar12;
        puVar10 = puVar10 + 2;
      } while (puVar8 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      do {
        puVar1[2] = *param_2;
        puVar8 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar1[3] = *puVar8;
        puVar1 = puVar1 + 2;
      } while (param_2 != puVar12);
    }
  }
  iVar6 = *param_1;
  if (iVar6 != 0) {
    uVar7 = param_1[2] - iVar6 & 0xfffffff8;
    iVar2 = iVar6;
    if (0xfff < uVar7) {
      iVar2 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar2) - 4U) {
LAB_00559e6d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar7);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)(puVar9 + uVar3 * 2);
  param_1[2] = (int)(puVar9 + uVar4 * 2);
  return *param_1 + iVar11 * 8;
}



/* FUNCTION 2894 ; VA 0x00559e80 ; FUN_00559e80 */

void __thiscall
FUN_00559e80(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x9249247 < (uint)param_1[1]) {
    FUN_00576300(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00559f32:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00559f32;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 2895 ; VA 0x00559fe0 ; FUN_00559fe0 */

void __thiscall
FUN_00559fe0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5d1745b < (uint)param_1[1]) {
    FUN_00576370(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_0055a092:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_0055a092;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 2896 ; VA 0x0055a140 ; FUN_0055a140 */

void __thiscall
FUN_0055a140(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_005763d0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_0055a1f2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_0055a1f2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 2897 ; VA 0x0055a2a0 ; FUN_0055a2a0 */

void __thiscall
FUN_0055a2a0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0x6666664 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00559300(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_0055a2f8;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_0055a2f8;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_0055a2f8:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_0055a351:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_0055a351;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 2898 ; VA 0x0055a400 ; FUN_0055a400 */

void __thiscall
FUN_0055a400(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0x6666664 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00559370(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_0055a458;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_0055a458;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_0055a458:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_0055a4b1:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_0055a4b1;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 2899 ; VA 0x0055a560 ; FUN_0055a560 */

undefined4 * __thiscall
FUN_0055a560(int *param_1,undefined4 *param_2,int *param_3,int *param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017926b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00559e80(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0170d8dd(*param_4 + 4,param_3[4] + 4);
    if (iVar2 < 0) {
      FUN_00559e80(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0170d8dd(*(int *)(piVar3[2] + 0x10) + 4,*param_4 + 4);
    if (iVar2 < 0) {
      FUN_00559e80(param_2,0,*(undefined4 *)(*param_1 + 8),param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0170d8dd(*param_4 + 4,param_3[4] + 4);
    if (iVar2 < 0) {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570340(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00559e80(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559e80(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570340(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_00551320();
      if ((*piVar3 == *param_1) || (cVar1 = FUN_00570340(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00559e80(param_2,1,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559e80(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_0055ac90(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2900 ; VA 0x0055a7ad ; Catch_All@0055a7ad */

void Catch_All_0055a7ad(void)

{
  int unaff_EBP;
  
  FUN_00576300(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2901 ; VA 0x0055a7d0 ; FUN_0055a7d0 */

undefined4 * __thiscall
FUN_0055a7d0(int *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017926c0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00559fe0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar5 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar5 = (undefined4 *)*param_4;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(puVar5,param_4[4],piVar3,param_3[8]);
    if (iVar2 < 0) {
      FUN_00559fe0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00570370(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_00559fe0(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00570370(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570370(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar4 = (int *)FUN_00551320();
      piVar3 = piStack_18;
      if ((*piVar4 == *param_1) || (cVar1 = FUN_00570370(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_0055add0(auStack_20,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2902 ; VA 0x0055aa18 ; Catch_All@0055aa18 */

void Catch_All_0055aa18(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2903 ; VA 0x0055aa30 ; FUN_0055aa30 */

undefined4 * __thiscall
FUN_0055aa30(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017926d0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_0055a140(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar4 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar4 = (undefined4 *)*param_4;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(puVar4,param_4[4],piVar3,param_3[8]);
    if (iVar2 < 0) {
      FUN_0055a140(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00570370(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_0055a140(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00570370(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_0055a140(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0055a140(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570370(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar1 = FUN_00570370(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_0055a140(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0055a140(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_0055af70(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2904 ; VA 0x0055ac76 ; Catch_All@0055ac76 */

void Catch_All_0055ac76(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2905 ; VA 0x0055ac90 ; FUN_0055ac90 */

void __thiscall
FUN_0055ac90(int *param_1,undefined4 *param_2,undefined4 *param_3,int *param_4,undefined4 param_5)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_4;
  puStack_c = &LAB_017926e0;
  bVar7 = true;
  uStack_8 = 0;
  puVar5 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar1 = *(char *)((int)puVar5 + 0xd);
  puVar2 = (undefined4 *)*param_1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    if ((char)param_3 == '\0') {
      iVar4 = FUN_0170d8dd(*piVar3 + 4,puVar5[4] + 4);
      bVar7 = iVar4 < 0;
    }
    else {
      iVar4 = FUN_0170d8dd(puVar5[4] + 4,*piVar3 + 4);
      bVar7 = -1 < iVar4;
    }
    if (bVar7 == false) {
      puVar6 = (undefined4 *)puVar5[2];
    }
    else {
      puVar6 = (undefined4 *)*puVar5;
    }
    puVar2 = puVar5;
    puVar5 = puVar6;
    cVar1 = *(char *)((int)puVar6 + 0xd);
  }
  param_3 = puVar2;
  if (bVar7 != false) {
    if (puVar2 == *(undefined4 **)*param_1) {
      bVar7 = true;
      goto LAB_0055ad3b;
    }
    FUN_0056f560();
  }
  puVar5 = param_3;
  iVar4 = FUN_0170d8dd(param_3[4] + 4,*piVar3 + 4);
  if (-1 < iVar4) {
    FUN_00576300(param_5);
    *param_2 = puVar5;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_0055ad3b:
  puVar5 = (undefined4 *)FUN_00559e80(&param_3,bVar7,puVar2,piVar3,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2906 ; VA 0x0055adb4 ; Catch_All@0055adb4 */

void Catch_All_0055adb4(void)

{
  int unaff_EBP;
  
  FUN_00576300(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2907 ; VA 0x0055add0 ; FUN_0055add0 */

void __thiscall
FUN_0055add0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  byte bVar3;
  int *piVar4;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_4;
  puStack_c = &LAB_017926f0;
  piVar6 = (int *)*param_1;
  bVar3 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar6[1] + 0xd);
  piVar4 = piVar6;
  piVar2 = (int *)piVar6[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar4 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      FUN_0055c2d0(puVar8,puVar5[4],piVar4,piVar2[8]);
      bVar3 = extraout_var_00 >> 7;
    }
    else {
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_0055c2d0(piVar4,piVar2[8],puVar8,puVar5[4]);
      bVar3 = extraout_var >> 7 ^ 1;
    }
    if (bVar3 == 0) {
      piVar9 = (int *)piVar2[2];
    }
    else {
      piVar9 = (int *)*piVar2;
    }
    piVar4 = piVar2;
    piVar2 = piVar9;
    cVar1 = *(char *)((int)piVar9 + 0xd);
  }
  param_3 = piVar4;
  if (bVar3 != 0) {
    if (piVar4 == (int *)*piVar6) {
      puVar5 = (undefined4 *)FUN_00559fe0(&param_3,1,piVar4,puVar5,param_5);
      *param_2 = *puVar5;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar6 = param_3 + 4;
  puVar8 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar8 = (undefined4 *)*puVar5;
  }
  if (0xf < (uint)param_3[9]) {
    piVar6 = (int *)*piVar6;
  }
  iVar7 = FUN_0055c2d0(piVar6,param_3[8],puVar8,puVar5[4]);
  if (iVar7 < 0) {
    puVar5 = (undefined4 *)FUN_00559fe0(&param_3,bVar3,piVar4,puVar5,param_5);
    *param_2 = *puVar5;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00576370(param_5);
  *param_2 = piVar2;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2908 ; VA 0x0055af4e ; Catch_All@0055af4e */

void Catch_All_0055af4e(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2909 ; VA 0x0055af70 ; FUN_0055af70 */

void __thiscall
FUN_0055af70(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  byte bVar4;
  int *piVar5;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = param_4;
  puStack_c = &LAB_01792700;
  piVar7 = (int *)*param_1;
  bVar4 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar7[1] + 0xd);
  piVar5 = piVar7;
  piVar2 = (int *)piVar7[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar5 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      FUN_0055c2d0(puVar9,puVar6[4],piVar5,piVar2[8]);
      bVar4 = extraout_var_00 >> 7;
    }
    else {
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      FUN_0055c2d0(piVar5,piVar2[8],puVar9,puVar6[4]);
      bVar4 = extraout_var >> 7 ^ 1;
    }
    if (bVar4 == 0) {
      piVar10 = (int *)piVar2[2];
    }
    else {
      piVar10 = (int *)*piVar2;
    }
    piVar5 = piVar2;
    piVar2 = piVar10;
    cVar1 = *(char *)((int)piVar10 + 0xd);
  }
  param_3 = piVar5;
  if (bVar4 != 0) {
    if (piVar5 == (int *)*piVar7) {
      bVar4 = 1;
      goto LAB_0055b03c;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar7 = param_3 + 4;
  puVar9 = puVar6;
  if (0xf < (uint)puVar6[5]) {
    puVar9 = (undefined4 *)*puVar6;
  }
  if (0xf < (uint)param_3[9]) {
    piVar7 = (int *)*piVar7;
  }
  iVar8 = FUN_0055c2d0(piVar7,param_3[8],puVar9,puVar6[4]);
  uVar3 = param_5;
  if (-1 < iVar8) {
    FUN_0056cac0();
    FUN_01674ea0(uVar3,0x30);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_0055b03c:
  puVar6 = (undefined4 *)FUN_0055a140(&param_3,bVar4,piVar5,puVar6,param_5);
  *param_2 = *puVar6;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2910 ; VA 0x0055b0da ; Catch_All@0055b0da */

void Catch_All_0055b0da(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2911 ; VA 0x0055b0f0 ; FUN_0055b0f0 */

void __thiscall
FUN_0055b0f0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  byte bVar3;
  int *piVar4;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 *unaff_FS_OFFSET;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_4;
  puStack_c = &LAB_01792710;
  uStack_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &uStack_10;
  piVar6 = (int *)*param_1;
  bVar3 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar6[1] + 0xd);
  piVar4 = piVar6;
  piVar2 = (int *)piVar6[1];
  while (cVar1 == '\0') {
    piVar4 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      FUN_0055c2d0(puVar8,puVar5[4],piVar4,piVar2[8]);
      bVar3 = extraout_var_00 >> 7;
    }
    else {
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_0055c2d0(piVar4,piVar2[8],puVar8,puVar5[4]);
      bVar3 = extraout_var >> 7 ^ 1;
    }
    if (bVar3 == 0) {
      piVar9 = (int *)piVar2[2];
    }
    else {
      piVar9 = (int *)*piVar2;
    }
    piVar4 = piVar2;
    piVar2 = piVar9;
    cVar1 = *(char *)((int)piVar9 + 0xd);
  }
  param_3 = piVar4;
  if (bVar3 != 0) {
    if (piVar4 == (int *)*piVar6) {
      bVar3 = 1;
      goto LAB_0055b1bc;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar6 = param_3 + 4;
  puVar8 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar8 = (undefined4 *)*puVar5;
  }
  if (0xf < (uint)param_3[9]) {
    piVar6 = (int *)*piVar6;
  }
  iVar7 = FUN_0055c2d0(piVar6,param_3[8],puVar8,puVar5[4]);
  if (-1 < iVar7) {
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    *unaff_FS_OFFSET = uStack_10;
    return;
  }
LAB_0055b1bc:
  puVar5 = (undefined4 *)FUN_0055a2a0(&param_3,bVar3,piVar4,puVar5,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  *unaff_FS_OFFSET = uStack_10;
  return;
}



/* FUNCTION 2912 ; VA 0x0055b244 ; Catch_All@0055b244 */

void Catch_All_0055b244(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2913 ; VA 0x0055b250 ; FUN_0055b250 */

void __thiscall
FUN_0055b250(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  byte bVar3;
  int *piVar4;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_4;
  puStack_c = &LAB_01792720;
  piVar6 = (int *)*param_1;
  bVar3 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar6[1] + 0xd);
  piVar4 = piVar6;
  piVar2 = (int *)piVar6[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar4 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      FUN_0055c2d0(puVar8,puVar5[4],piVar4,piVar2[8]);
      bVar3 = extraout_var_00 >> 7;
    }
    else {
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_0055c2d0(piVar4,piVar2[8],puVar8,puVar5[4]);
      bVar3 = extraout_var >> 7 ^ 1;
    }
    if (bVar3 == 0) {
      piVar9 = (int *)piVar2[2];
    }
    else {
      piVar9 = (int *)*piVar2;
    }
    piVar4 = piVar2;
    piVar2 = piVar9;
    cVar1 = *(char *)((int)piVar9 + 0xd);
  }
  param_3 = piVar4;
  if (bVar3 != 0) {
    if (piVar4 == (int *)*piVar6) {
      bVar3 = 1;
      goto LAB_0055b31c;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar6 = param_3 + 4;
  puVar8 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar8 = (undefined4 *)*puVar5;
  }
  if (0xf < (uint)param_3[9]) {
    piVar6 = (int *)*piVar6;
  }
  iVar7 = FUN_0055c2d0(piVar6,param_3[8],puVar8,puVar5[4]);
  if (-1 < iVar7) {
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_0055b31c:
  puVar5 = (undefined4 *)FUN_0055a400(&param_3,bVar3,piVar4,puVar5,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2914 ; VA 0x0055b3a4 ; Catch_All@0055b3a4 */

void Catch_All_0055b3a4(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2915 ; VA 0x0055b3b0 ; FUN_0055b3b0 */

int * FUN_0055b3b0(int *param_1,undefined4 param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  char cVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  undefined8 uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792740;
  pvStack_10 = ExceptionList;
  iVar7 = *param_1;
  iVar2 = *(int *)(iVar7 + 4);
  uVar5 = *(uint *)(iVar2 + 0x20 + (int)param_1);
  iVar8 = *(int *)(iVar2 + 0x24 + (int)param_1);
  if ((iVar8 < 0) || (((iVar8 < 1 && (uVar5 == 0)) || (uVar5 <= param_3)))) {
    iVar8 = 0;
  }
  else {
    iVar8 = uVar5 - param_3;
  }
  piVar6 = *(int **)(iVar2 + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar6 + 4))();
    iVar7 = *param_1;
  }
  iVar2 = *(int *)(iVar7 + 4);
  uStack_8 = 0;
  if (((*(int *)((int)param_1 + iVar2 + 0xc) == 0) && (*(int *)((int)param_1 + iVar2 + 0x3c) != 0))
     && (*(int **)((int)param_1 + iVar2 + 0x3c) != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) != 0) {
    FUN_00554460(*(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | 4,0);
    uStack_8 = 4;
    cVar4 = thunk_FUN_0170e3b7();
    if (cVar4 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar6 != (int *)0x0) {
      (**(code **)(*piVar6 + 8))();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_8 = 2;
  if ((*(uint *)(*(int *)(iVar7 + 4) + 0x14 + (int)param_1) & 0x1c0) != 0x40) {
    for (; iVar8 != 0; iVar8 = iVar8 + -1) {
      piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      bVar1 = *(byte *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1);
      if (*(int *)piVar6[8] == 0) {
LAB_0055b4d3:
        uVar5 = (**(code **)(*piVar6 + 0xc))(bVar1);
      }
      else {
        iVar2 = *(int *)piVar6[0xc];
        if (iVar2 < 1) goto LAB_0055b4d3;
        *(int *)piVar6[0xc] = iVar2 + -1;
        pbVar3 = *(byte **)piVar6[8];
        *(byte **)piVar6[8] = pbVar3 + 1;
        *pbVar3 = bVar1;
        uVar5 = (uint)bVar1;
      }
      if (uVar5 == 0xffffffff) goto LAB_0055b512;
    }
    iVar7 = *param_1;
  }
  uVar9 = (**(code **)(**(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1) + 0x24))
                    (param_2,param_3,0);
  if (((uint)uVar9 == param_3) && ((int)((ulonglong)uVar9 >> 0x20) == 0)) {
LAB_0055b512:
    do {
      if (iVar8 == 0) break;
      piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      bVar1 = *(byte *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1);
      if (*(int *)piVar6[8] == 0) {
LAB_0055b54e:
        uVar5 = (**(code **)(*piVar6 + 0xc))(bVar1);
      }
      else {
        iVar2 = *(int *)piVar6[0xc];
        if (iVar2 < 1) goto LAB_0055b54e;
        *(int *)piVar6[0xc] = iVar2 + -1;
        pbVar3 = *(byte **)piVar6[8];
        *(byte **)piVar6[8] = pbVar3 + 1;
        *pbVar3 = bVar1;
        uVar5 = (uint)bVar1;
      }
      if (uVar5 == 0xffffffff) break;
      iVar8 = iVar8 + -1;
    } while( true );
  }
  iVar2 = *(int *)(*param_1 + 4);
  *(undefined4 *)(iVar2 + 0x20 + (int)param_1) = 0;
  *(undefined4 *)(iVar2 + 0x24 + (int)param_1) = 0;
  piVar6 = (int *)FUN_0055b5a2();
  return piVar6;
}



/* FUNCTION 2916 ; VA 0x0055b583 ; Catch_All@0055b583 */

undefined * Catch_All_0055b583(void)

{
  FUN_005565b0(4,1);
  return &DAT_0055b59c;
}



/* FUNCTION 2917 ; VA 0x0055b5a2 ; FUN_0055b5a2 */

void FUN_0055b5a2(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  uint unaff_EBX;
  int unaff_EBP;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0xc) | unaff_EBX;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 4;
  cVar3 = thunk_FUN_0170e3b7();
  piVar1 = *(int **)(unaff_EBP + -0x28);
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar2 = *piVar1;
  *(undefined *)(unaff_EBP + -4) = 5;
  piVar1 = *(int **)(*(int *)(iVar2 + 4) + 0x38 + (int)piVar1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 2918 ; VA 0x0055b610 ; FUN_0055b610 */

undefined4 * __thiscall FUN_0055b610(int *param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar5 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar1 = *(char *)((int)puVar5 + 0xd);
  puVar2 = (undefined4 *)*param_1;
  while (cVar1 == '\0') {
    iVar3 = FUN_0170d8dd(puVar5[4] + 4,*param_2 + 4);
    if (iVar3 < 0) {
      puVar4 = (undefined4 *)puVar5[2];
      puVar5 = puVar2;
    }
    else {
      puVar4 = (undefined4 *)*puVar5;
    }
    puVar2 = puVar5;
    puVar5 = puVar4;
    cVar1 = *(char *)((int)puVar4 + 0xd);
  }
  return puVar2;
}



/* FUNCTION 2919 ; VA 0x0055b660 ; FUN_0055b660 */

int FUN_0055b660(char *param_1)

{
  char cVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  
  pcVar5 = param_1;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  pcVar5 = pcVar5 + (1 - (int)(param_1 + 1));
  iVar3 = FUN_0171d6c7(pcVar5,1);
  if (iVar3 != 0) {
    if (pcVar5 != (char *)0x0) {
      iVar4 = iVar3 - (int)param_1;
      do {
        cVar1 = *param_1;
        param_1 = param_1 + 1;
        param_1[iVar4 + -1] = cVar1;
        pcVar5 = pcVar5 + -1;
      } while (pcVar5 != (char *)0x0);
    }
    return iVar3;
  }
  FUN_010c5e30();
  pcVar2 = (code *)swi(3);
  iVar3 = (*pcVar2)();
  return iVar3;
}



/* FUNCTION 2920 ; VA 0x0055b6b0 ; FUN_0055b6b0 */

void FUN_0055b6b0(undefined *param_1)

{
  *param_1 = 0;
  return;
}



/* FUNCTION 2921 ; VA 0x0055b6c0 ; FUN_0055b6c0 */

void __thiscall FUN_0055b6c0(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uStack_c;
  
  uVar2 = param_2;
  uVar1 = param_1[1];
  uVar3 = *param_1;
  uVar6 = uVar1 - uVar3;
  uStack_c = param_1[2] - uVar3;
  if (param_2 <= uStack_c) {
    if (param_2 <= uVar6) {
      if (param_2 != uVar6) {
        param_1[1] = uVar3 + param_2;
      }
      return;
    }
    uVar3 = uVar3 + param_2;
    FUN_0170d1f0(uVar1,0,uVar3 - uVar1);
    param_1[1] = uVar3;
    return;
  }
  if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x7fffffff - (uStack_c >> 1) < uStack_c) {
    uStack_c = param_2;
  }
  else {
    uStack_c = uStack_c + (uStack_c >> 1);
    if (uStack_c < param_2) {
      uStack_c = param_2;
    }
  }
  if (uStack_c < 0x1000) {
    if (uStack_c == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_01674e20(uStack_c);
    }
  }
  else {
    uVar3 = uStack_c + 0x23;
    if (uVar3 <= uStack_c) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_0055b80b;
    uVar3 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar4;
  }
  FUN_0170d1f0(uVar3 + uVar6,0,uVar2 - uVar6);
  uVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar3,uVar1,param_1[1] - uVar1);
  uVar1 = *param_1;
  if (uVar1 != 0) {
    uVar5 = param_1[2] - uVar1;
    uVar6 = uVar1;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(uVar1 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar1 - uVar6) - 4) {
LAB_0055b80b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  *param_1 = uVar3;
  param_1[1] = uVar3 + uVar2;
  param_1[2] = uStack_c + uVar3;
  return;
}



/* FUNCTION 2922 ; VA 0x0055b820 ; FUN_0055b820 */

void __thiscall FUN_0055b820(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar2 = param_2;
  uVar5 = param_1[1];
  uVar1 = *param_1;
  uVar7 = (int)(uVar5 - uVar1) >> 2;
  uVar4 = (int)(param_1[2] - uVar1) >> 2;
  if (param_2 <= uVar4) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        param_1[1] = uVar1 + param_2 * 4;
      }
      return;
    }
    iVar3 = (param_2 - uVar7) * 4;
    FUN_0170d1f0(uVar5,0,iVar3);
    param_1[1] = uVar5 + iVar3;
    return;
  }
  if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar4 <= 0x3fffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar1 = uVar5 * 4;
  if (uVar5 < 0x40000000) {
    uVar5 = uVar1;
    if (0xfff < uVar1) goto LAB_0055b892;
    if (uVar1 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar1);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_0055b892:
    uVar4 = uVar5 + 0x23;
    if (uVar4 <= uVar5) {
      uVar4 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar4);
    if (iVar3 == 0) goto LAB_0055b98f;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  FUN_0170d1f0(uVar5 + uVar7 * 4,0,(uVar2 - uVar7) * 4);
  uVar4 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar5,uVar4,param_1[1] - uVar4);
  uVar4 = *param_1;
  if (uVar4 != 0) {
    uVar6 = param_1[2] - uVar4 & 0xfffffffc;
    uVar7 = uVar4;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uVar4 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar4 - uVar7) - 4) {
LAB_0055b98f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + uVar2 * 4;
  param_1[2] = uVar1 + uVar5;
  return;
}



/* FUNCTION 2923 ; VA 0x0055b9a0 ; FUN_0055b9a0 */

void __thiscall FUN_0055b9a0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792750;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_CWebService::JobItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2924 ; VA 0x0055ba0e ; Catch_All@0055ba0e */

void Catch_All_0055ba0e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00573130(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2925 ; VA 0x0055ba30 ; FUN_0055ba30 */

void __thiscall FUN_0055ba30(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792760;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Reflection::Tuple>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2926 ; VA 0x0055ba9e ; Catch_All@0055ba9e */

void Catch_All_0055ba9e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00573320(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2927 ; VA 0x0055bac0 ; FUN_0055bac0 */

void __thiscall FUN_0055bac0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792770;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::RCCJobProfilingInfo>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2928 ; VA 0x0055bb2e ; Catch_All@0055bb2e */

void Catch_All_0055bb2e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_005731c0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2929 ; VA 0x0055bb50 ; FUN_0055bb50 */

int __thiscall FUN_0055bb50(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792780;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CSGDictionaryService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2930 ; VA 0x0055bc22 ; Catch_All@0055bc22 */

void Catch_All_0055bc22(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2931 ; VA 0x0055bc40 ; FUN_0055bc40 */

int __thiscall FUN_0055bc40(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792790;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GameSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2932 ; VA 0x0055bd12 ; Catch_All@0055bd12 */

void Catch_All_0055bd12(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2933 ; VA 0x0055bd30 ; FUN_0055bd30 */

int __thiscall FUN_0055bd30(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017927a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::NonReplicatedCSGDictionaryService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2934 ; VA 0x0055be02 ; Catch_All@0055be02 */

void Catch_All_0055be02(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2935 ; VA 0x0055be20 ; FUN_0055be20 */

int __thiscall FUN_0055be20(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017927b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Players*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2936 ; VA 0x0055bef2 ; Catch_All@0055bef2 */

void Catch_All_0055bef2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2937 ; VA 0x0055bf10 ; FUN_0055bf10 */

int __thiscall FUN_0055bf10(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017927c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RCCTexturePackGenerator*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2938 ; VA 0x0055bfe2 ; Catch_All@0055bfe2 */

void Catch_All_0055bfe2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2939 ; VA 0x0055c000 ; FUN_0055c000 */

int __thiscall FUN_0055c000(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017927d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ScriptContext*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2940 ; VA 0x0055c0d2 ; Catch_All@0055c0d2 */

void Catch_All_0055c0d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2941 ; VA 0x0055c0f0 ; FUN_0055c0f0 */

int __thiscall FUN_0055c0f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017927e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TaskSchedulerSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2942 ; VA 0x0055c1c2 ; Catch_All@0055c1c2 */

void Catch_All_0055c1c2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2943 ; VA 0x0055c1e0 ; FUN_0055c1e0 */

int __thiscall FUN_0055c1e0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017927f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_ThumbnailGenerator*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 2944 ; VA 0x0055c2b2 ; Catch_All@0055c2b2 */

void Catch_All_0055c2b2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2945 ; VA 0x0055c2d0 ; FUN_0055c2d0 */

uint FUN_0055c2d0(byte *param_1,uint param_2,byte *param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  uVar2 = param_2;
  if (param_4 < param_2) {
    uVar2 = param_4;
  }
  while (uVar1 = uVar2 - 4, 3 < uVar2) {
    if (*(int *)param_1 != *(int *)param_3) goto LAB_0055c306;
    param_1 = param_1 + 4;
    param_3 = param_3 + 4;
    uVar2 = uVar1;
  }
  if (uVar1 != 0xfffffffc) {
LAB_0055c306:
    bVar3 = *param_1 < *param_3;
    if ((*param_1 != *param_3) ||
       ((uVar1 != 0xfffffffd &&
        ((bVar3 = param_1[1] < param_3[1], param_1[1] != param_3[1] ||
         ((uVar1 != 0xfffffffe &&
          ((bVar3 = param_1[2] < param_3[2], param_1[2] != param_3[2] ||
           ((uVar1 != 0xffffffff && (bVar3 = param_1[3] < param_3[3], param_1[3] != param_3[3]))))))
         )))))) {
      uVar2 = -(uint)bVar3 | 1;
      goto LAB_0055c33c;
    }
  }
  uVar2 = 0;
LAB_0055c33c:
  if (uVar2 == 0) {
    if (param_2 < param_4) {
      return 0xffffffff;
    }
    uVar2 = (uint)(param_4 < param_2);
  }
  return uVar2;
}



/* FUNCTION 2946 ; VA 0x0055c360 ; FUN_0055c360 */

uint FUN_0055c360(byte *param_1,uint param_2,byte *param_3,uint param_4)

{
  uint in_EAX;
  uint uVar1;
  bool bVar2;
  
  if (param_2 != param_4) goto LAB_0055c3cc;
  uVar1 = param_2 - 4;
  if (3 < param_2) {
    do {
      if (*(int *)param_1 != *(int *)param_3) goto LAB_0055c38d;
      param_1 = param_1 + 4;
      param_3 = param_3 + 4;
      bVar2 = 3 < uVar1;
      uVar1 = uVar1 - 4;
    } while (bVar2);
  }
  if (uVar1 == 0xfffffffc) {
LAB_0055c3c1:
    in_EAX = 0;
  }
  else {
LAB_0055c38d:
    bVar2 = *param_1 < *param_3;
    if ((*param_1 == *param_3) &&
       ((uVar1 == 0xfffffffd ||
        ((bVar2 = param_1[1] < param_3[1], param_1[1] == param_3[1] &&
         ((uVar1 == 0xfffffffe ||
          ((bVar2 = param_1[2] < param_3[2], param_1[2] == param_3[2] &&
           ((uVar1 == 0xffffffff || (bVar2 = param_1[3] < param_3[3], param_1[3] == param_3[3]))))))
         )))))) goto LAB_0055c3c1;
    in_EAX = -(uint)bVar2 | 1;
  }
  if (in_EAX == 0) {
    return 1;
  }
LAB_0055c3cc:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 2947 ; VA 0x0055c3d0 ; FUN_0055c3d0 */

char * FUN_0055c3d0(char *param_1,uint param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  
  uVar4 = CONCAT44(param_3,param_2);
  if (param_3 != 0) {
    do {
      iVar2 = (int)uVar4;
      uVar4 = FUN_016f3c60(uVar4,1000000000,0);
      param_2 = (uint)uVar4;
      iVar3 = 9;
      uVar1 = iVar2 + param_2 * -1000000000;
      do {
        param_1 = param_1 + -1;
        *param_1 = (char)uVar1 + (char)(uVar1 / 10) * -10 + '0';
        iVar3 = iVar3 + -1;
        uVar1 = uVar1 / 10;
      } while (iVar3 != 0);
    } while ((int)((ulonglong)uVar4 >> 0x20) != 0);
  }
  do {
    param_1 = param_1 + -1;
    uVar1 = param_2 / 10;
    *param_1 = (char)param_2 + (char)uVar1 * -10 + '0';
    param_2 = uVar1;
  } while (uVar1 != 0);
  return param_1;
}



/* FUNCTION 2948 ; VA 0x0055c480 ; FUN_0055c480 */

undefined4 * __thiscall FUN_0055c480(undefined4 param_1,int param_2,int param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_2 != param_3) {
    param_2 = param_2 - (int)param_4;
    do {
      *param_4 = 0;
      param_4[1] = 0;
      iVar2 = *(int *)(param_2 + 4 + (int)param_4);
      if (iVar2 != 0) {
        LOCK();
        piVar1 = (int *)(iVar2 + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_4 = *(undefined4 *)(param_2 + (int)param_4);
      param_4[1] = *(undefined4 *)(param_2 + 4 + (int)param_4);
      param_4 = param_4 + 2;
    } while (param_2 + (int)param_4 != param_3);
  }
  FUN_005596d0(param_4,param_4,param_1);
  return param_4;
}



/* FUNCTION 2949 ; VA 0x0055c4f0 ; FUN_0055c4f0 */

int * __thiscall FUN_0055c4f0(undefined4 param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792808;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    piVar3 = param_2 + 1;
    ExceptionList = &pvStack_10;
    do {
      *param_4 = piVar3[-1];
      param_4[1] = 0;
      puVar2 = (undefined4 *)*piVar3;
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)*puVar2)(piVar3 + 1,param_4 + 2);
        puVar2 = (undefined4 *)*piVar3;
      }
      param_4[1] = (int)puVar2;
      param_4 = param_4 + 0x34;
      piVar1 = piVar3 + 0x33;
      piVar3 = piVar3 + 0x34;
    } while (piVar1 != param_3);
  }
  uStack_8 = 1;
  FUN_00559720(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 2950 ; VA 0x0055c5a0 ; FUN_0055c5a0 */

int * FUN_0055c5a0(int *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792828;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    piVar3 = param_1 + 1;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = piVar3[-1];
      param_3[1] = 0;
      puVar2 = (undefined4 *)*piVar3;
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)*puVar2)(piVar3 + 1,param_3 + 2);
        puVar2 = (undefined4 *)*piVar3;
      }
      param_3[1] = (int)puVar2;
      param_3 = param_3 + 0x34;
      piVar1 = piVar3 + 0x33;
      piVar3 = piVar3 + 0x34;
    } while (piVar1 != param_2);
  }
  uStack_8 = 1;
  FUN_00559720(param_3,param_3,param_4);
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 2951 ; VA 0x0055c650 ; FUN_0055c650 */

undefined4 *
FUN_0055c650(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 5;
    do {
      puVar6[4] = 0;
      *(undefined4 *)((int)param_3 + (-0x20 - (int)param_1) + (int)(puVar5 + 8)) = 0;
      puVar1 = puVar5 + 3;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *puVar6 = puVar5[-5];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      *(undefined8 *)(puVar6 + 6) = *(undefined8 *)(puVar5 + 1);
      puVar6 = puVar6 + 8;
      puVar5 = puVar5 + 8;
    } while (puVar1 != param_2);
  }
  FUN_00559500(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 2952 ; VA 0x0055c6d0 ; FUN_0055c6d0 */

undefined4 *
FUN_0055c6d0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar5 = param_3;
  if (param_1 != param_2) {
    puVar4 = param_1;
    do {
      puVar5[4] = 0;
      *(undefined4 *)((int)param_3 + (0x14 - (int)param_1) + (int)puVar4) = 0;
      uVar1 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      *puVar5 = *puVar4;
      puVar5[1] = uVar1;
      puVar5[2] = uVar2;
      puVar5[3] = uVar3;
      *(undefined8 *)(puVar5 + 4) = *(undefined8 *)(puVar4 + 4);
      puVar5 = puVar5 + 6;
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
      puVar4 = puVar4 + 6;
    } while (puVar4 != param_2);
  }
  FUN_00559570(puVar5,puVar5,param_4);
  return puVar5;
}



/* FUNCTION 2953 ; VA 0x0055c740 ; FUN_0055c740 */

void FUN_0055c740(undefined4 param_1,undefined4 param_2)

{
  FUN_005702d0(param_2);
  return;
}



/* FUNCTION 2954 ; VA 0x0055c750 ; FUN_0055c750 */

undefined FUN_0055c750(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_c = param_1;
  piStack_8 = param_2;
  cVar4 = FUN_00585a40(&uStack_c);
  piVar2 = piStack_8;
  if (cVar4 == '\0') {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    *param_3 = 0;
    param_3[1] = 0;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    *param_3 = uStack_c;
    param_3[1] = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 2955 ; VA 0x0055c860 ; FUN_0055c860 */

undefined FUN_0055c860(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  undefined uVar6;
  uint in_stack_00000038;
  undefined4 in_stack_00000048;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  int *in_stack_00000054;
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0179287f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    puStack_14 = (undefined4 *)auStack_64;
    FUN_0054ef60(&stack0x00000008);
    uStack_8 = 1;
    FUN_0054ef60(&stack0x00000020);
    uStack_8 = 2;
    FUN_0054ef60(&stack0x00000038);
    uStack_1c = in_stack_00000050;
    uStack_8 = 3;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8 = 4;
    uVar6 = uStack_8;
    uStack_8 = 4;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
      uStack_8 = uVar6;
    }
    else {
      puStack_18 = puVar3 + 1;
      *puVar3 = uVar1;
      FUN_0054ef60(auStack_64);
      uStack_8 = 5;
      FUN_0054ef60(auStack_4c);
      uStack_8 = 6;
      FUN_0054ef60(auStack_34);
      puVar3[0x13] = uStack_1c;
    }
    *in_stack_00000054 = (int)puVar3;
    if (0xf < uStack_20) {
      uVar5 = uStack_20 + 1;
      uVar4 = auStack_34[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_34[0] - 4);
        uVar5 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005509f0();
    uVar6 = 1;
  }
  else {
    uVar6 = 0;
  }
  if (0xf < in_stack_0000004c) {
    uVar5 = in_stack_0000004c + 1;
    uVar4 = in_stack_00000038;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(in_stack_00000038 - 4);
      uVar5 = in_stack_0000004c + 0x24;
      if (0x1f < (in_stack_00000038 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000048 = 0;
  in_stack_0000004c = 0xf;
  in_stack_00000038 = in_stack_00000038 & 0xffffff00;
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 2956 ; VA 0x0055ca00 ; FUN_0055ca00 */

void __thiscall FUN_0055ca00(undefined4 *param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 *in_stack_00000038;
  undefined4 in_stack_00000048;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined auStack_c4 [72];
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  undefined4 *puStack_74;
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  undefined4 *apuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792560;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_60;
  uStack_8 = 0;
  puStack_74 = (undefined4 *)&stack0x00000008;
  puStack_78 = (undefined4 *)0x55ca42;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puStack_74 = (undefined4 *)&stack0x00000020;
  uStack_8._0_1_ = 1;
  puStack_78 = (undefined4 *)0x55ca52;
  FUN_0054ef60();
  puStack_74 = &stack0x00000038;
  uStack_8._0_1_ = 2;
  puStack_78 = (undefined4 *)0x55ca62;
  FUN_0054ef60();
  uStack_18 = in_stack_00000050;
  puStack_74 = (undefined4 *)in_stack_00000050;
  uStack_8._0_1_ = 3;
  puStack_14 = auStack_c4;
  puStack_78 = param_1 + 2;
  FUN_0054ef60(auStack_60);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_48);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(apuStack_30);
  uStack_7c = uStack_18;
  ppuVar3 = &PTR_FUN_018c0c78;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  cVar1 = FUN_0055c860();
  if (0xf < uStack_1c) {
    puStack_74 = (undefined4 *)(uStack_1c + 1);
    puVar2 = apuStack_30[0];
    if (0xfff < puStack_74) {
      puVar2 = (undefined4 *)apuStack_30[0][-1];
      puStack_74 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (uint)((int)apuStack_30[0] + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = (undefined4 *)0x55cb7f;
        FUN_017167a3();
      }
    }
    uStack_7c = 0x55caf7;
    puStack_78 = puVar2;
    FUN_01674ea0();
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  apuStack_30[0] = (undefined4 *)((uint)apuStack_30[0] & 0xffffff00);
  puStack_74 = (undefined4 *)0x55cb14;
  FUN_005509f0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < in_stack_0000004c) {
    puStack_74 = (undefined4 *)(in_stack_0000004c + 1);
    puVar2 = in_stack_00000038;
    if (0xfff < puStack_74) {
      puVar2 = (undefined4 *)in_stack_00000038[-1];
      puStack_74 = (undefined4 *)(in_stack_0000004c + 0x24);
      if (0x1f < (uint)((int)in_stack_00000038 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = (undefined4 *)&UNK_0055cb84;
        FUN_017167a3();
      }
    }
    uStack_7c = 0x55cb4a;
    puStack_78 = puVar2;
    FUN_01674ea0();
  }
  in_stack_00000048 = 0;
  in_stack_0000004c = 0xf;
  in_stack_00000038 = (undefined4 *)((uint)in_stack_00000038 & 0xffffff00);
  puStack_74 = (undefined4 *)0x55cb67;
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2957 ; VA 0x0055cb90 ; FUN_0055cb90 */

undefined FUN_0055cb90(int param_1,int param_2,int param_3,int *param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int *piStack_8;
  
  iStack_14 = param_1;
  iStack_10 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iStack_c = param_3;
  piStack_8 = param_4;
  cVar4 = FUN_00585a40(&iStack_14);
  piVar2 = piStack_8;
  if (cVar4 == '\0') {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    *param_5 = iStack_14;
    param_5[1] = iStack_10;
    param_5[2] = 0;
    param_5[3] = 0;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    param_5[2] = iStack_c;
    param_5[3] = (int)piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 2958 ; VA 0x0055ccc0 ; FUN_0055ccc0 */

undefined FUN_0055ccc0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined uVar8;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  int aiStack_64 [5];
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017928b7;
  pvStack_10 = ExceptionList;
  uStack_40 = param_1;
  uStack_3c = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  uStack_20 = in_stack_00000024;
  uStack_1c = in_stack_00000028;
  uStack_18 = in_stack_0000002c;
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_40);
  uVar2 = uStack_3c;
  uVar1 = uStack_40;
  if (cVar3 == '\0') {
    FUN_0054ef60(auStack_38);
    uStack_4c = uStack_20;
    uStack_48 = uStack_1c;
    uStack_44 = uStack_18;
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x2c);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_0054ef60(aiStack_64);
      puVar4[8] = uStack_4c;
      puVar4[9] = uStack_48;
      puVar4[10] = uStack_44;
    }
    *in_stack_00000030 = (int)puVar4;
    if (0xf < uStack_50) {
      uVar6 = uStack_50 + 1;
      iVar5 = aiStack_64[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_64[0] + -4);
        uVar6 = uStack_50 + 0x24;
        if (0x1f < (aiStack_64[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    if (0xf < uStack_24) {
      uVar7 = uStack_24 + 1;
      uVar6 = auStack_38[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar7 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 1;
  }
  else {
    if (0xf < uStack_24) {
      uVar7 = uStack_24 + 1;
      uVar6 = auStack_38[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar7 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 0;
  }
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_24 = 0xf;
  uStack_28 = 0;
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    iVar5 = param_3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_3 + -4);
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 2959 ; VA 0x0055ceb0 ; FUN_0055ceb0 */

undefined4 * FUN_0055ceb0(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000034;
  uint in_stack_00000038;
  int in_stack_0000003c;
  uint in_stack_00000050;
  undefined4 *in_stack_00000054;
  undefined auStack_8c [16];
  undefined4 uStack_7c;
  uint uStack_78;
  undefined *puStack_74;
  uint uStack_34;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792910;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puStack_74 = (undefined *)in_stack_00000054;
  ExceptionList = &pvStack_10;
  in_stack_00000054 = (undefined4 *)auStack_8c;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  iVar1 = FUN_00568460();
  uStack_8._0_1_ = 5;
  in_stack_00000054 = param_1 + 1;
  *param_1 = param_2;
  uStack_78 = 0x55cf46;
  puStack_74 = (undefined *)iVar1;
  FUN_0054ef60();
  puStack_74 = (undefined *)(iVar1 + 0x18);
  uStack_8._0_1_ = 6;
  uStack_78 = 0x55cf56;
  FUN_0054ef60();
  puStack_74 = (undefined *)(iVar1 + 0x30);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_78 = 0x55cf66;
  FUN_0054ef60();
  param_1[0x13] = *(undefined4 *)(iVar1 + 0x48);
  if (0xf < uStack_20) {
    puStack_74 = (undefined *)(uStack_20 + 1);
    uVar2 = uStack_34;
    if (0xfff < puStack_74) {
      uVar2 = *(uint *)(uStack_34 - 4);
      puStack_74 = (undefined *)(uStack_20 + 0x24);
      if (0x1f < (uStack_34 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = (undefined *)0x55d08a;
        FUN_017167a3();
      }
    }
    uStack_7c = 0x55cf9d;
    uStack_78 = uVar2;
    FUN_01674ea0();
  }
  puStack_74 = (undefined *)0x55cfba;
  FUN_005509f0();
  if (0xf < in_stack_00000020) {
    puStack_74 = (undefined *)(in_stack_00000020 + 1);
    uVar2 = param_3;
    if (0xfff < puStack_74) {
      uVar2 = *(uint *)(param_3 - 4);
      puStack_74 = (undefined *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_3 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = (undefined *)0x55d08f;
        FUN_017167a3();
      }
    }
    uStack_7c = 0x55cfeb;
    uStack_78 = uVar2;
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (0xf < in_stack_00000038) {
    puStack_74 = (undefined *)(in_stack_00000038 + 1);
    uVar2 = in_stack_00000024;
    if (0xfff < puStack_74) {
      uVar2 = *(uint *)(in_stack_00000024 - 4);
      puStack_74 = (undefined *)(in_stack_00000038 + 0x24);
      if (0x1f < (in_stack_00000024 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = (undefined *)0x55d094;
        FUN_017167a3();
      }
    }
    uStack_7c = 0x55d02d;
    uStack_78 = uVar2;
    FUN_01674ea0();
  }
  in_stack_00000034 = 0;
  in_stack_00000038 = 0xf;
  in_stack_00000024 = in_stack_00000024 & 0xffffff00;
  if (0xf < in_stack_00000050) {
    puStack_74 = (undefined *)(in_stack_00000050 + 1);
    iVar1 = in_stack_0000003c;
    if (0xfff < puStack_74) {
      iVar1 = *(int *)(in_stack_0000003c + -4);
      puStack_74 = (undefined *)(in_stack_00000050 + 0x24);
      if (0x1f < (in_stack_0000003c - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = &UNK_0055d099;
        FUN_017167a3();
      }
    }
    uStack_7c = 0x55d06f;
    uStack_78 = iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2960 ; VA 0x0055d0a0 ; FUN_0055d0a0 */

undefined4 * FUN_0055d0a0(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 *in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  undefined4 in_stack_0000004c;
  int *in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 uStack_b0;
  int *piStack_ac;
  undefined4 uStack_a8;
  undefined4 *puStack_a4;
  undefined4 uStack_88;
  int *piStack_84;
  uint uStack_80;
  undefined *puStack_7c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01792968;
  pvStack_10 = ExceptionList;
  uStack_80 = in_stack_00000054;
  puStack_7c = (undefined *)in_stack_00000058;
  ExceptionList = &pvStack_10;
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000050[1] = in_stack_00000050[1] + 1;
    UNLOCK();
  }
  uStack_88 = in_stack_0000004c;
  piStack_84 = in_stack_00000050;
  uStack_8 = 4;
  uStack_7 = 0;
  puStack_a4 = &stack0x00000034;
  uStack_a8 = 0x55d118;
  FUN_0054ef60();
  uStack_a8 = in_stack_0000002c;
  puStack_a4 = in_stack_00000030;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_b0 = in_stack_00000024;
  piStack_ac = in_stack_00000028;
  uStack_8 = 6;
  in_stack_00000030 = &uStack_b0;
  FUN_0054ef60(&param_3);
  uStack_8 = 3;
  iVar3 = FUN_005685c0();
  uStack_8 = 7;
  *param_1 = param_2;
  uStack_80 = 0x55d190;
  puStack_7c = (undefined *)iVar3;
  FUN_0054ef60();
  param_1[8] = 0;
  param_1[9] = 0;
  if (*(int *)(iVar3 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar3 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = *(undefined4 *)(iVar3 + 0x18);
  param_1[9] = *(undefined4 *)(iVar3 + 0x1c);
  param_1[10] = *(undefined4 *)(iVar3 + 0x20);
  param_1[0xb] = *(undefined4 *)(iVar3 + 0x24);
  puStack_7c = (undefined *)(iVar3 + 0x28);
  _uStack_8 = CONCAT31(uStack_7,8);
  uStack_80 = 0x55d1d1;
  FUN_0054ef60();
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  if (*(int *)(iVar3 + 0x44) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar3 + 0x44) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x12] = *(undefined4 *)(iVar3 + 0x40);
  param_1[0x13] = *(undefined4 *)(iVar3 + 0x44);
  param_1[0x14] = *(undefined4 *)(iVar3 + 0x48);
  param_1[0x15] = *(undefined4 *)(iVar3 + 0x4c);
  puStack_7c = (undefined *)0x55d20a;
  FUN_0056cf50();
  if (0xf < in_stack_00000020) {
    puStack_7c = (undefined *)(in_stack_00000020 + 1);
    uVar4 = param_3;
    if (0xfff < puStack_7c) {
      uVar4 = *(uint *)(param_3 - 4);
      puStack_7c = (undefined *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_7c = (undefined *)0x55d2f8;
        FUN_017167a3();
      }
    }
    piStack_84 = (int *)0x55d23b;
    uStack_80 = uVar4;
    FUN_01674ea0();
  }
  piVar1 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_7c = (undefined *)0x55d269;
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2 + -1;
      *piVar2 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_7c = (undefined *)0x55d279;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000048) {
    puStack_7c = (undefined *)(in_stack_00000048 + 1);
    uVar4 = in_stack_00000034;
    if (0xfff < puStack_7c) {
      uVar4 = *(uint *)(in_stack_00000034 - 4);
      puStack_7c = (undefined *)(in_stack_00000048 + 0x24);
      if (0x1f < (in_stack_00000034 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_7c = &UNK_0055d2fd;
        FUN_017167a3();
      }
    }
    piStack_84 = (int *)0x55d2a6;
    uStack_80 = uVar4;
    FUN_01674ea0();
  }
  piVar1 = in_stack_00000050;
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000050[1] + -1;
    in_stack_00000050[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_7c = (undefined *)0x55d2d1;
      (**(code **)*in_stack_00000050)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_7c = (undefined *)0x55d2e0;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2961 ; VA 0x0055d300 ; FUN_0055d300 */

undefined4 *
FUN_0055d300(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 2962 ; VA 0x0055d3f0 ; FUN_0055d3f0 */

undefined4 * FUN_0055d3f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  uint uVar2;
  int iVar3;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined *in_stack_00000030;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  uint uStack_60;
  uint *puStack_5c;
  undefined4 uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792998;
  pvStack_10 = ExceptionList;
  puStack_5c = (uint *)&param_4;
  uStack_8 = 0;
  uStack_60 = 0x55d41f;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puStack_5c = (uint *)in_stack_00000030;
  uStack_8._0_1_ = 1;
  uStack_60 = in_stack_0000002c;
  uStack_64 = in_stack_00000028;
  in_stack_00000030 = auStack_7c;
  FUN_0054ef60(aiStack_2c);
  FUN_00568ee0(param_3);
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_18) {
    puStack_5c = (uint *)(uStack_18 + 1);
    iVar3 = aiStack_2c[0];
    if (0xfff < puStack_5c) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      puStack_5c = (uint *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_5c = (uint *)0x55d538;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    uStack_64 = 0x55d47d;
    uStack_60 = iVar3;
    FUN_01674ea0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *param_1 = param_2;
  param_1[1] = uStack_54;
  puStack_5c = auStack_50;
  uStack_60 = 0x55d49e;
  FUN_0054ef60();
  param_1[8] = uStack_38;
  param_1[9] = uStack_34;
  param_1[10] = uStack_30;
  if (0xf < uStack_3c) {
    puStack_5c = (uint *)(uStack_3c + 1);
    uVar2 = auStack_50[0];
    if (0xfff < puStack_5c) {
      uVar2 = *(uint *)(auStack_50[0] - 4);
      puStack_5c = (uint *)(uStack_3c + 0x24);
      if (0x1f < (auStack_50[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_5c = (uint *)0x55d53d;
        FUN_017167a3();
      }
    }
    uStack_64 = 0x55d4dd;
    uStack_60 = uVar2;
    FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  if (0xf < in_stack_00000024) {
    puStack_5c = (uint *)(in_stack_00000024 + 1);
    iVar3 = param_4;
    if (0xfff < puStack_5c) {
      iVar3 = *(int *)(param_4 + -4);
      puStack_5c = (uint *)(in_stack_00000024 + 0x24);
      if (0x1f < (param_4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_5c = (uint *)&UNK_0055d542;
        FUN_017167a3();
      }
    }
    uStack_64 = 0x55d51f;
    uStack_60 = iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2963 ; VA 0x0055d5e0 ; FUN_0055d5e0 */

int * __fastcall FUN_0055d5e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088c8c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 2964 ; VA 0x0055d610 ; FUN_0055d610 */

int * __fastcall FUN_0055d610(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 2965 ; VA 0x0055d640 ; FUN_0055d640 */

int * __fastcall FUN_0055d640(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008881d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 2966 ; VA 0x0055d670 ; FUN_0055d670 */

int * __fastcall FUN_0055d670(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008882f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 2967 ; VA 0x0055d6a0 ; FUN_0055d6a0 */

int * __fastcall FUN_0055d6a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088da50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 2968 ; VA 0x0055d6d0 ; FUN_0055d6d0 */

void FUN_0055d6d0(int *param_1)

{
  if (param_1 != (int *)0x0) {
    (**(code **)(*param_1 + 8))(1);
  }
  return;
}



/* FUNCTION 2969 ; VA 0x0055d6f0 ; FUN_0055d6f0 */

void FUN_0055d6f0(int *param_1)

{
  if (param_1 != (int *)0x0) {
    (**(code **)(*param_1 + 4))(1);
  }
  return;
}



/* FUNCTION 2970 ; VA 0x0055d710 ; FUN_0055d710 */

void FUN_0055d710(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *param_2 = *param_3;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  *(undefined8 *)(param_2 + 6) = *(undefined8 *)(param_3 + 6);
  return;
}



/* FUNCTION 2971 ; VA 0x0055d760 ; FUN_0055d760 */

void FUN_0055d760(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017929b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561910(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1f0b0);
}



/* FUNCTION 2972 ; VA 0x0055d7a5 ; Catch_All@0055d7a5 */

undefined * Catch_All_0055d7a5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055d7b6;
}



/* FUNCTION 2973 ; VA 0x0055d7d0 ; FUN_0055d7d0 */

void FUN_0055d7d0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017929c0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005619f0(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1f114);
}



/* FUNCTION 2974 ; VA 0x0055d815 ; Catch_All@0055d815 */

undefined * Catch_All_0055d815(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055d826;
}



/* FUNCTION 2975 ; VA 0x0055d840 ; FUN_0055d840 */

void FUN_0055d840(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017929d0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561ad0(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1f1f8);
}



/* FUNCTION 2976 ; VA 0x0055d885 ; Catch_All@0055d885 */

undefined * Catch_All_0055d885(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055d896;
}



/* FUNCTION 2977 ; VA 0x0055d8b0 ; FUN_0055d8b0 */

void FUN_0055d8b0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017929e0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561bb0(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1f178);
}



/* FUNCTION 2978 ; VA 0x0055d8f5 ; Catch_All@0055d8f5 */

undefined * Catch_All_0055d8f5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055d906;
}



/* FUNCTION 2979 ; VA 0x0055d920 ; FUN_0055d920 */

void FUN_0055d920(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017929f0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561c90(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1ebf8);
}



/* FUNCTION 2980 ; VA 0x0055d965 ; Catch_All@0055d965 */

undefined * Catch_All_0055d965(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055d976;
}



/* FUNCTION 2981 ; VA 0x0055d990 ; FUN_0055d990 */

void FUN_0055d990(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_48 [52];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a00;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561d70(auStack_48,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_48,&DAT_01c1efdc);
}



/* FUNCTION 2982 ; VA 0x0055d9d5 ; Catch_All@0055d9d5 */

undefined * Catch_All_0055d9d5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055d9e6;
}



/* FUNCTION 2983 ; VA 0x0055da00 ; FUN_0055da00 */

void FUN_0055da00(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a10;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561e70(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1ec7c);
}



/* FUNCTION 2984 ; VA 0x0055da45 ; Catch_All@0055da45 */

undefined * Catch_All_0055da45(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055da56;
}



/* FUNCTION 2985 ; VA 0x0055da70 ; FUN_0055da70 */

void FUN_0055da70(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a20;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00561f70(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1ed00);
}



/* FUNCTION 2986 ; VA 0x0055dab5 ; Catch_All@0055dab5 */

undefined * Catch_All_0055dab5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055dac6;
}



/* FUNCTION 2987 ; VA 0x0055dae0 ; FUN_0055dae0 */

void FUN_0055dae0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a30;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562050(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1edec);
}



/* FUNCTION 2988 ; VA 0x0055db25 ; Catch_All@0055db25 */

undefined * Catch_All_0055db25(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055db36;
}



/* FUNCTION 2989 ; VA 0x0055db50 ; FUN_0055db50 */

void FUN_0055db50(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a40;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562130(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1ed84);
}



/* FUNCTION 2990 ; VA 0x0055db95 ; Catch_All@0055db95 */

undefined * Catch_All_0055db95(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055dba6;
}



/* FUNCTION 2991 ; VA 0x0055dbc0 ; FUN_0055dbc0 */

void FUN_0055dbc0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a50;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562210(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1eed4);
}



/* FUNCTION 2992 ; VA 0x0055dc05 ; Catch_All@0055dc05 */

undefined * Catch_All_0055dc05(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055dc16;
}



/* FUNCTION 2993 ; VA 0x0055dc30 ; FUN_0055dc30 */

void FUN_0055dc30(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a60;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005622f0(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1ee50);
}



/* FUNCTION 2994 ; VA 0x0055dc75 ; Catch_All@0055dc75 */

undefined * Catch_All_0055dc75(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055dc86;
}



/* FUNCTION 2995 ; VA 0x0055dca0 ; FUN_0055dca0 */

void FUN_0055dca0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a70;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005623d0(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1f04c);
}



/* FUNCTION 2996 ; VA 0x0055dce5 ; Catch_All@0055dce5 */

undefined * Catch_All_0055dce5(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055dcf6;
}



/* FUNCTION 2997 ; VA 0x0055dd10 ; FUN_0055dd10 */

void FUN_0055dd10(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_40 [44];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a80;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005624b0(auStack_40,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_40,&DAT_01c1ef58);
}



/* FUNCTION 2998 ; VA 0x0055dd55 ; Catch_All@0055dd55 */

undefined * Catch_All_0055dd55(void)

{
  int unaff_EBP;
  
  FUN_0057cb20(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0055dd66;
}



/* FUNCTION 2999 ; VA 0x0055dd80 ; FUN_0055dd80 */

void FUN_0055dd80(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_34 [32];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792a90;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562590(auStack_34,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_34,&DAT_01c1e788);
}


