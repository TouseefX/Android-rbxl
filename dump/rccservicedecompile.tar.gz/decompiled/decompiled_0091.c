/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 22750 ; VA 0x00af2300 ; FUN_00af2300 */

void __fastcall FUN_00af2300(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::MegaClusterInstance>::vftable;
  uVar1 = FUN_00af0010(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22751 ; VA 0x00af2340 ; thunk_FUN_00b013e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall thunk_FUN_00b013e0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::PartInstance::vftable;
  param_1[0x16] = RBX::PartInstance::vftable;
  param_1[0x1e] = RBX::PartInstance::vftable;
  param_1[0x25] = RBX::PartInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::PartInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xa8;
  if (DAT_01ee41fb != '\0') {
    FUN_01677490(DAT_01ee41fb,"PartInstance destroyed: %p, primitive: %p",param_1,param_1[0x2a],0);
  }
  FUN_016790b0();
  piVar2 = (int *)param_1[0x37];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x31];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((undefined4 *)param_1[0x2a] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x2a])(1);
  }
  if (param_1[0x28] != 0) {
    if ((undefined4 *)param_1[0x29] != (undefined4 *)0x0) {
      *(undefined4 *)param_1[0x29] = param_1[0x27];
    }
    if (param_1[0x27] != 0) {
      *(undefined4 *)(param_1[0x27] + 0xa4) = param_1[0x29];
    }
    *(int *)param_1[0x28] = *(int *)param_1[0x28] + -1;
    param_1[0x27] = 0;
    param_1[0x29] = 0;
    param_1[0x28] = 0;
  }
  LOCK();
  _DAT_01eedc58 = _DAT_01eedc58 + -1;
  UNLOCK();
  param_1[0x25] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x26] + 4) + 0x98 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_00c3e200();
  FUN_00e704a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22752 ; VA 0x00af2350 ; FUN_00af2350 */

void __fastcall FUN_00af2350(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00d59010();
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 22753 ; VA 0x00af2370 ; FUN_00af2370 */

void __fastcall FUN_00af2370(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,6);
  }
  return;
}



/* FUNCTION 22754 ; VA 0x00af2390 ; thunk_FUN_00af3750 */

void __fastcall thunk_FUN_00af3750(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 3) * 3;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 22755 ; VA 0x00af23a0 ; FUN_00af23a0 */

int __fastcall FUN_00af23a0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x194);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0x180);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00af250a;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 400) = 0;
  *(undefined4 *)(param_1 + 0x194) = 0xf;
  *(undefined *)(param_1 + 0x180) = 0;
  FUN_016dedfb(param_1 + 0x14c);
  FUN_016df150(param_1 + 0x108);
  FUN_016dedfb(param_1 + 0xd8);
  iVar4 = FUN_016dedfb(param_1 + 0xa8);
  piVar3 = *(int **)(param_1 + 0xa4);
  if (piVar3 != (int *)0x0) {
    iVar4 = (**(code **)(*piVar3 + 0x10))(piVar3 != (int *)(param_1 + 0x80));
    *(undefined4 *)(param_1 + 0xa4) = 0;
  }
  uVar2 = *(uint *)(param_1 + 0x78);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 100);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00af250a;
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0xf;
  *(undefined *)(param_1 + 100) = 0;
  uVar2 = *(uint *)(param_1 + 0x60);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0x4c);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00af250a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00af2504. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 22756 ; VA 0x00af2510 ; FUN_00af2510 */

void __fastcall FUN_00af2510(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0x3e] = RBX::MegaClusterInstance::vftable;
  *param_1 = RBX::MegaClusterInstance::vftable;
  param_1[0x16] = RBX::MegaClusterInstance::vftable;
  param_1[0x1e] = RBX::MegaClusterInstance::vftable;
  param_1[0x25] = RBX::MegaClusterInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::MegaClusterInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x170
  ;
  if (DAT_01d6517b != '\0') {
    FUN_016774b0(DAT_01d6517b,"MegaCluster destroyed - %p",param_1);
  }
  if (((DAT_01d6eaf4 == '\0') && (DAT_01d6eab4 != '\0')) && (param_1[0x5e] != 0)) {
    thunk_FUN_00eb28e0();
    FUN_0058a2b0();
  }
  FUN_00a6f530(param_1 + 0x3e);
  iVar4 = FUN_0170d75d(param_1[0xd],0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Workspace::RTTI_Type_Descriptor,0);
  if (iVar4 != 0) {
    FUN_008bb6e0(0);
  }
  FUN_00c18400(3);
  uVar2 = param_1[0x68];
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x6a,param_1 + 0x6a,2);
      }
    }
    param_1[0x68] = 0;
  }
  uVar2 = param_1[0x60];
  uStack_8 = 1;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x62,param_1 + 0x62,2);
      }
    }
    param_1[0x60] = 0;
  }
  piVar3 = (int *)param_1[0x5f];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00af3750();
  FUN_00af3750();
  iVar4 = param_1[0x4f];
  if (iVar4 != 0) {
    FUN_00d59010();
    FUN_01674ea0(iVar4,0x2c);
  }
  piVar3 = (int *)param_1[0x4e];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_016790b0();
  param_1[0x3e] = RBX::Voxel2::GridListener::vftable;
  FUN_00b013e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22757 ; VA 0x00af2720 ; FUN_00af2720 */

int __thiscall FUN_00af2720(int *param_1,char param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ebfb8;
  pvStack_10 = ExceptionList;
  iVar2 = param_1[1];
  iVar5 = 0;
  piVar6 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar6 = (int *)(iVar2 + 4);
    iVar5 = *(int *)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    while (iVar5 != 0) {
      LOCK();
      iVar2 = *piVar6;
      if (iVar5 == iVar2) {
        *piVar6 = iVar5 + 1;
        iVar2 = iVar5;
      }
      UNLOCK();
      if (iVar2 == iVar5) {
        iVar5 = *param_1;
        piVar6 = (int *)param_1[1];
        goto LAB_00af277b;
      }
      iVar5 = *piVar6;
    }
    iVar5 = 0;
    piVar6 = (int *)0x0;
  }
LAB_00af277b:
  uStack_8 = 1;
  uStack_7 = 0;
  if (iVar5 != 0) {
    *(undefined4 *)(iVar5 + 0x178) = 0;
    piVar1 = *(int **)(iVar5 + 0x17c);
    *(undefined4 *)(iVar5 + 0x17c) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (param_2 == '\0') {
      if (*(uint *)(iVar5 + 0x180) == 0) {
        uVar3 = FUN_0054fda0();
        _uStack_8 = CONCAT31(uStack_7,2);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar3);
      }
      iVar2 = (**(code **)((*(uint *)(iVar5 + 0x180) & 0xfffffffe) + 4))(iVar5 + 0x188);
    }
    else {
      FUN_0054ef60(&param_3);
      iVar2 = FUN_005e65e0();
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 1;
    iVar5 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar2 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar2 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar2 = param_3;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(param_3 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar2 = FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 22758 ; VA 0x00af2896 ; FUN_00af2896 */

void FUN_00af2896(void)

{
  FUN_00af2e50();
  return;
}



/* FUNCTION 22759 ; VA 0x00af28a4 ; FUN_00af28a4 */

void FUN_00af28a4(void)

{
  FUN_00af3090();
  return;
}



/* FUNCTION 22760 ; VA 0x00af28b2 ; FUN_00af28b2 */

void FUN_00af28b2(void)

{
  FUN_00af3090();
  return;
}



/* FUNCTION 22761 ; VA 0x00af28c0 ; FUN_00af28c0 */

int __thiscall FUN_00af28c0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22762 ; VA 0x00af2910 ; FUN_00af2910 */

int __thiscall FUN_00af2910(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 22763 ; VA 0x00af2950 ; FUN_00af2950 */

undefined4 __thiscall FUN_00af2950(undefined4 param_1,byte param_2)

{
  FUN_00af20e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 22764 ; VA 0x00af2980 ; FUN_00af2980 */

undefined4 __thiscall FUN_00af2980(undefined4 param_1,byte param_2)

{
  FUN_00af2160();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22765 ; VA 0x00af29b0 ; FUN_00af29b0 */

int __thiscall FUN_00af29b0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),0x3c);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22766 ; VA 0x00af2a00 ; FUN_00af2a00 */

undefined4 __thiscall FUN_00af2a00(undefined4 param_1,byte param_2)

{
  FUN_00af21d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22767 ; VA 0x00af2a30 ; FUN_00af2a30 */

int __thiscall FUN_00af2a30(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x30);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22768 ; VA 0x00af2aa0 ; FUN_00af2aa0 */

int __thiscall FUN_00af2aa0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x30);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22769 ; VA 0x00af2b00 ; FUN_00af2b00 */

undefined4 __thiscall FUN_00af2b00(undefined4 param_1,byte param_2)

{
  FUN_00af2240();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22770 ; VA 0x00af2b30 ; FUN_00af2b30 */

int __thiscall FUN_00af2b30(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22771 ; VA 0x00af2ba0 ; FUN_00af2ba0 */

int __thiscall FUN_00af2ba0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22772 ; VA 0x00af2c00 ; FUN_00af2c00 */

int __thiscall FUN_00af2c00(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22773 ; VA 0x00af2c70 ; FUN_00af2c70 */

int __thiscall FUN_00af2c70(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22774 ; VA 0x00af2cd0 ; FUN_00af2cd0 */

int __thiscall FUN_00af2cd0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22775 ; VA 0x00af2d20 ; FUN_00af2d20 */

int __thiscall FUN_00af2d20(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  FUN_0056cee0();
  FUN_0056cee0();
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22776 ; VA 0x00af2d80 ; FUN_00af2d80 */

int __thiscall FUN_00af2d80(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 22777 ; VA 0x00af2dd0 ; FUN_00af2dd0 */

int __thiscall FUN_00af2dd0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),0x3c);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 22778 ; VA 0x00af2e20 ; FUN_00af2e20 */

undefined4 __thiscall FUN_00af2e20(undefined4 param_1,byte param_2)

{
  FUN_00af2240();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x68);
  }
  return param_1;
}



/* FUNCTION 22779 ; VA 0x00af2e50 ; FUN_00af2e50 */

int __thiscall FUN_00af2e50(int param_1,byte param_2)

{
  FUN_00b013e0();
  *(undefined ***)(param_1 + 0xfc) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x100);
  }
  return param_1;
}



/* FUNCTION 22780 ; VA 0x00af2e80 ; FUN_00af2e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00af2e80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellBlock>::vftable;
  _DAT_01eec9e0 = _DAT_01eec9e0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22781 ; VA 0x00af2eb0 ; FUN_00af2eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00af2eb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellMaterial>::vftable;
  _DAT_01eec9d8 = _DAT_01eec9d8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22782 ; VA 0x00af2ee0 ; FUN_00af2ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00af2ee0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellOrientation>::vftable;
  _DAT_01eec9e8 = _DAT_01eec9e8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22783 ; VA 0x00af2f10 ; FUN_00af2f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00af2f10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::WaterCellDirection>::vftable;
  _DAT_01eec9f8 = _DAT_01eec9f8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22784 ; VA 0x00af2f40 ; FUN_00af2f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00af2f40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::WaterCellForce>::vftable;
  _DAT_01eec9f0 = _DAT_01eec9f0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22785 ; VA 0x00af2f70 ; FUN_00af2f70 */

undefined4 * __thiscall FUN_00af2f70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Region3int16>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 22786 ; VA 0x00af2fa0 ; FUN_00af2fa0 */

undefined4 * __thiscall FUN_00af2fa0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 22787 ; VA 0x00af2fd0 ; FUN_00af2fd0 */

undefined4 * __thiscall FUN_00af2fd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 22788 ; VA 0x00af3000 ; FUN_00af3000 */

undefined4 __thiscall FUN_00af3000(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1a8);
  }
  return param_1;
}



/* FUNCTION 22789 ; VA 0x00af3030 ; FUN_00af3030 */

undefined4 * __thiscall FUN_00af3030(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Region3int16>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 22790 ; VA 0x00af3060 ; FUN_00af3060 */

undefined4 __thiscall FUN_00af3060(undefined4 param_1,byte param_2)

{
  FUN_00a6de50();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 22791 ; VA 0x00af3090 ; FUN_00af3090 */

int __thiscall FUN_00af3090(int param_1,byte param_2)

{
  FUN_00af2510();
  *(undefined ***)(param_1 + 0x1c4) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c8);
  }
  return param_1;
}



/* FUNCTION 22792 ; VA 0x00af30c0 ; FUN_00af30c0 */

void __fastcall FUN_00af30c0(int param_1)

{
  undefined auStack_10 [12];
  
  if (DAT_01d6eaf4 == '\0') {
    if (*(int *)(param_1 + 0x178) != 0) {
      FUN_00eb28e0();
    }
    return;
  }
  FUN_00550130(
              "Terrain:CancelImportHeightmap() is deprecated when FFlag::TerrainImportUseService is on. Use HeightmapImporterService:CancelImportHeightmap()"
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22793 ; VA 0x00af3100 ; FUN_00af3100 */

undefined4 __thiscall FUN_00af3100(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec788;
  pvStack_10 = ExceptionList;
  if (DAT_01d6eab4 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_0060e0c0(&uStack_18,param_1);
    uStack_8 = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    FUN_00fea8c0(uStack_18,piStack_14,param_2);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_00550130(
              "Terrain:ImportHeightMap() is deprecated when FFlagTerrainImportNewYieldMethod is on. Use Terrain:ImportHeightmap()"
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 22794 ; VA 0x00af31b0 ; FUN_00af31b0 */

void __thiscall FUN_00af31b0(int param_1)

{
  int *piVar1;
  undefined uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  uint in_stack_00000040;
  undefined4 in_stack_00000050;
  uint in_stack_00000054;
  uint in_stack_00000058;
  undefined4 in_stack_00000068;
  uint in_stack_0000006c;
  uint in_stack_00000074;
  undefined4 in_stack_0000007c;
  undefined4 in_stack_00000080;
  undefined4 in_stack_00000084;
  undefined4 in_stack_00000088;
  undefined8 in_stack_0000008c;
  uint in_stack_00000094;
  undefined4 in_stack_0000009c;
  undefined4 in_stack_000000a0;
  undefined4 in_stack_000000a4;
  undefined4 in_stack_000000a8;
  undefined8 in_stack_000000ac;
  undefined4 in_stack_ffffff74;
  uint3 uVar7;
  int iVar6;
  undefined4 in_stack_ffffff78;
  undefined4 in_stack_ffffff7c;
  undefined4 in_stack_ffffff80;
  undefined4 uVar8;
  undefined4 uVar9;
  uint auStack_6c [2];
  undefined auStack_64 [24];
  uint auStack_4c [2];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ec7f3;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  uVar7 = (uint3)((uint)in_stack_ffffff74 >> 8);
  iStack_14 = param_1;
  if (DAT_01d6eaf4 == '\0') {
    if (*(int *)(param_1 + 0x178) == 0) {
      auStack_4c[0] = 0;
      ExceptionList = &pvStack_10;
      if (in_stack_00000074 != 0) {
        auStack_4c[0] = in_stack_00000074;
        if ((in_stack_00000074 & 1) == 0) {
          ExceptionList = &pvStack_10;
          (**(code **)(in_stack_00000074 & 0xfffffffe))(&stack0x0000007c,&uStack_44,0);
        }
        else {
          uStack_44 = in_stack_0000007c;
          uStack_40 = in_stack_00000080;
          uStack_3c = in_stack_00000084;
          uStack_38 = in_stack_00000088;
          uStack_34 = in_stack_0000008c;
          ExceptionList = &pvStack_10;
        }
      }
      if ((uint *)(param_1 + 0x180) != auStack_4c) {
        auStack_6c[0] = 0;
        uStack_8._0_1_ = 5;
        FUN_005880d0(auStack_4c);
        FUN_005880d0((uint *)(param_1 + 0x180));
        FUN_005880d0(auStack_6c);
        uStack_8._0_1_ = 6;
        if (((auStack_6c[0] != 0) && ((auStack_6c[0] & 1) == 0)) &&
           (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_6c[0] & 0xfffffffe))(auStack_64,auStack_64,2);
        }
      }
      uStack_8._0_1_ = 7;
      if (((auStack_4c[0] != 0) && ((auStack_4c[0] & 1) == 0)) &&
         (*(code **)(auStack_4c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_4c[0] & 0xfffffffe))(&uStack_44,&uStack_44,2);
      }
      uStack_8._0_1_ = 3;
      auStack_4c[0] = 0;
      if (in_stack_00000094 != 0) {
        auStack_4c[0] = in_stack_00000094;
        if ((in_stack_00000094 & 1) == 0) {
          (**(code **)(in_stack_00000094 & 0xfffffffe))(&stack0x0000009c,&uStack_44,0);
        }
        else {
          uStack_44 = in_stack_0000009c;
          uStack_40 = in_stack_000000a0;
          uStack_3c = in_stack_000000a4;
          uStack_38 = in_stack_000000a8;
          uStack_34 = in_stack_000000ac;
        }
      }
      if ((uint *)(param_1 + 0x1a0) != auStack_4c) {
        auStack_6c[0] = 0;
        uStack_8._0_1_ = 9;
        FUN_005880d0(auStack_4c);
        FUN_005880d0((uint *)(param_1 + 0x1a0));
        FUN_005880d0(auStack_6c);
        uStack_8._0_1_ = 10;
        if (((auStack_6c[0] != 0) && ((auStack_6c[0] & 1) == 0)) &&
           (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_6c[0] & 0xfffffffe))(auStack_64,auStack_64,2);
        }
      }
      uStack_8._0_1_ = 0xb;
      if (((auStack_4c[0] != 0) && ((auStack_4c[0] & 1) == 0)) &&
         (*(code **)(auStack_4c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_4c[0] & 0xfffffffe))(&uStack_44,&uStack_44,2);
      }
      uStack_8._0_1_ = 3;
      FUN_0060e0c0(&uStack_1c,param_1);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[2] = piStack_18[2] + 1;
        UNLOCK();
      }
      uStack_24 = uStack_1c;
      piStack_20 = piStack_18;
      uStack_8._0_1_ = 0xd;
      puVar3 = (undefined4 *)
               FUN_00af0df0(auStack_2c,&uStack_1c,&stack0x00000004,&stack0x00000040,&stack0x00000058
                            ,&stack0x00000070,&uStack_24);
      uVar8 = *puVar3;
      uVar9 = puVar3[1];
      *puVar3 = 0;
      puVar3[1] = 0;
      *(undefined4 *)(param_1 + 0x178) = uVar8;
      piVar1 = *(int **)(param_1 + 0x17c);
      *(undefined4 *)(param_1 + 0x17c) = uVar9;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar6 = piVar1[1] + -1;
        piVar1[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar6 = piVar1[2] + -1;
          piVar1[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_28[1] + -1;
        piStack_28[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          iVar6 = piStack_28[2] + -1;
          piStack_28[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
      FUN_00eac7b0();
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_20[2] + -1;
        piStack_20[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    else {
      uVar8 = 0;
      uVar9 = 0xf;
      iVar6 = (uint)uVar7 << 8;
      ExceptionList = &pvStack_10;
      FUN_005542c0("Terrain import is already in process",0x24);
      FUN_005e65e0(iVar6,in_stack_ffffff78,in_stack_ffffff7c,in_stack_ffffff80,uVar8,uVar9);
    }
  }
  else {
    uVar8 = 0;
    uVar9 = 0xf;
    iVar6 = (uint)uVar7 << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Terrain:ImportHeightmap() is deprecated when FFlag::TerrainImportUseService is on. Use HeightmapImporterService:ImportHeightmap()"
                 ,0x81);
    FUN_005e65e0(iVar6,in_stack_ffffff78,in_stack_ffffff7c,in_stack_ffffff80,uVar8,uVar9);
  }
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000054) {
    uVar5 = in_stack_00000054 + 1;
    uVar4 = in_stack_00000040;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(in_stack_00000040 - 4);
      uVar5 = in_stack_00000054 + 0x24;
      if (0x1f < (in_stack_00000040 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000050 = 0;
  in_stack_00000054 = 0xf;
  in_stack_00000040 = in_stack_00000040 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000006c) {
    uVar5 = in_stack_0000006c + 1;
    uVar4 = in_stack_00000058;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(in_stack_00000058 - 4);
      uVar5 = in_stack_0000006c + 0x24;
      if (0x1f < (in_stack_00000058 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000068 = 0;
  in_stack_0000006c = 0xf;
  in_stack_00000058 = in_stack_00000058 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (in_stack_00000074 != 0) {
    if (((in_stack_00000074 & 1) == 0) &&
       (*(code **)(in_stack_00000074 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000074 & 0xfffffffe))(&stack0x0000007c,&stack0x0000007c,2);
    }
    in_stack_00000074 = 0;
  }
  uStack_8 = 0xf;
  if (((in_stack_00000094 != 0) && ((in_stack_00000094 & 1) == 0)) &&
     (*(code **)(in_stack_00000094 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000094 & 0xfffffffe))(&stack0x0000009c,&stack0x0000009c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22795 ; VA 0x00af35e0 ; FUN_00af35e0 */

void __thiscall FUN_00af35e0(int param_1,char param_2)

{
  undefined auStack_10 [12];
  
  if (DAT_01d6eaf4 != '\0') {
    FUN_00550130(
                "Terrain:SetImportHeightmapPaused() is deprecated when FFlag::TerrainImportUseService is on. Use HeightmapImporterService:SetImportHeightmapPaused()"
                );
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  if (*(int *)(param_1 + 0x178) != 0) {
    if (param_2 != '\0') {
      FUN_00eb2990();
      return;
    }
    FUN_00eb2a30();
  }
  return;
}



/* FUNCTION 22796 ; VA 0x00af3640 ; FUN_00af3640 */

void __thiscall FUN_00af3640(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_944d125a0d3203046dac3810d4370bf8>,void,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 22797 ; VA 0x00af3680 ; FUN_00af3680 */

void __fastcall FUN_00af3680(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00a6de50();
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 22798 ; VA 0x00af36a0 ; FUN_00af36a0 */

void FUN_00af36a0(void)

{
  FUN_00af23a0();
  return;
}



/* FUNCTION 22799 ; VA 0x00af36b0 ; FUN_00af36b0 */

void FUN_00af36b0(undefined *param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  undefined uVar2;
  undefined4 uVar3;
  
  uVar2 = *param_1;
  uVar3 = *param_2;
  uVar1 = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  FUN_00af2720(uVar2,uVar3,param_2[1],param_2[2],param_2[3],uVar1);
  return;
}



/* FUNCTION 22800 ; VA 0x00af3700 ; FUN_00af3700 */

void __thiscall FUN_00af3700(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_944d125a0d3203046dac3810d4370bf8>,void,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 22801 ; VA 0x00af3740 ; FUN_00af3740 */

TypeDescriptor * FUN_00af3740(void)

{
  return &<lambda_944d125a0d3203046dac3810d4370bf8>::RTTI_Type_Descriptor;
}



/* FUNCTION 22802 ; VA 0x00af3750 ; FUN_00af3750 */

void __fastcall FUN_00af3750(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 3) * 3;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 22803 ; VA 0x00af37c0 ; FUN_00af37c0 */

uint FUN_00af37c0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 3;
  if (param_1 < 0x55555556) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 22804 ; VA 0x00af3830 ; FUN_00af3830 */

void FUN_00af3830(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
                 uint *param_9,uint *param_10)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  uint uStack_2a4;
  uint uStack_2a0;
  uint uStack_29c;
  uint uStack_298;
  undefined8 uStack_294;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined auStack_1bc [128];
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  undefined4 uStack_100;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_cc;
  undefined4 uStack_b8;
  uint *puStack_b4;
  uint *puStack_b0;
  undefined4 uStack_ac;
  uint uStack_a8;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint uStack_94;
  undefined8 uStack_90;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ec820;
  pvStack_1c = ExceptionList;
  uVar2 = *param_8;
  uVar5 = *param_5;
  uVar6 = param_5[1];
  uVar7 = param_5[2];
  uVar8 = param_5[3];
  uVar9 = param_5[4];
  uVar10 = param_5[5];
  uVar11 = param_5[6];
  uVar12 = param_5[7];
  uVar13 = param_5[8];
  uVar14 = param_5[9];
  uVar15 = param_5[10];
  uVar16 = param_5[0xb];
  uVar1 = *(undefined8 *)(param_5 + 0xc);
  uVar3 = param_5[0xe];
  uStack_a8 = 0;
  uVar4 = *param_10;
  ExceptionList = &pvStack_1c;
  if (uVar4 != 0) {
    uStack_a8 = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_b0 = &uStack_a0;
      uStack_ac = 0;
      puStack_b4 = param_10 + 2;
      uStack_b8 = 0xaf38f6;
      ExceptionList = &pvStack_1c;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_a0 = param_10[2];
      uStack_9c = param_10[3];
      uStack_98 = param_10[4];
      uStack_94 = param_10[5];
      uStack_90 = *(undefined8 *)(param_10 + 6);
      ExceptionList = &pvStack_1c;
    }
  }
  uStack_14 = 0;
  uStack_cc = 0;
  uStack_294 = CONCAT44(0xaf3926,(undefined4)uStack_294);
  uStack_28c = FUN_00888530();
  uStack_288 = 0;
  uStack_14._0_1_ = 1;
  uVar4 = *param_9;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_9 + 2,&uStack_2a4,0);
    }
    else {
      uStack_2a4 = param_9[2];
      uStack_2a0 = param_9[3];
      uStack_29c = param_9[4];
      uStack_298 = param_9[5];
      uStack_294 = *(undefined8 *)(param_9 + 6);
    }
  }
  uStack_14._0_1_ = 0;
  FUN_008bf820(auStack_1bc);
  uStack_1c0 = 0xaf3992;
  FUN_008bd310();
  uStack_14._0_1_ = 2;
  uStack_e8 = param_7;
  uStack_ec = 0xaf39ac;
  uStack_cc = uVar2;
  FUN_0054ef60();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  uStack_100 = param_6;
  uStack_108 = CONCAT44(0xaf39c0,(undefined4)uStack_108);
  FUN_0054ef60();
  uStack_14 = 0xffffffff;
  uStack_13c = 0xaf39f9;
  uStack_138 = uVar5;
  uStack_134 = uVar6;
  uStack_130 = uVar7;
  uStack_12c = uVar8;
  uStack_128 = uVar9;
  uStack_124 = uVar10;
  uStack_120 = uVar11;
  uStack_11c = uVar12;
  uStack_118 = uVar13;
  uStack_114 = uVar14;
  uStack_110 = uVar15;
  uStack_10c = uVar16;
  uStack_108 = uVar1;
  uStack_100 = uVar3;
  (*param_2)();
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 22805 ; VA 0x00af3a10 ; FUN_00af3a10 */

void FUN_00af3a10(float *param_1,short param_2,short param_3,short param_4)

{
  float fVar1;
  
  fVar1 = DAT_018daf58;
  *param_1 = (float)((int)param_2 << 2) + DAT_018daf58;
  param_1[1] = (float)((int)param_3 << 2) + fVar1;
  param_1[2] = (float)((int)param_4 << 2) + fVar1;
  return;
}



/* FUNCTION 22806 ; VA 0x00af3a70 ; FUN_00af3a70 */

void FUN_00af3a70(float *param_1,short param_2,short param_3,short param_4)

{
  *param_1 = (float)((int)param_2 << 2);
  param_1[1] = (float)((int)param_3 << 2);
  param_1[2] = (float)((int)param_4 << 2);
  return;
}



/* FUNCTION 22807 ; VA 0x00af3ac0 ; FUN_00af3ac0 */

void FUN_00af3ac0(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined auStack_3c [20];
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec840;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a70e60(&iStack_24);
  uVar5 = 0;
  iStack_8 = 0;
  iVar4 = iStack_20 - iStack_24 >> 0x1f;
  if ((iStack_20 - iStack_24) / 0x18 + iVar4 != iVar4) {
    iVar4 = 0;
    do {
      FUN_00a6dbd0(*(int *)(iVar4 + 0xc + iStack_24) - *(int *)(iVar4 + iStack_24),
                   *(int *)(iVar4 + 0x10 + iStack_24) - *(int *)(iVar4 + 4 + iStack_24),
                   *(int *)(iVar4 + 0x14 + iStack_24) - *(int *)(iVar4 + 8 + iStack_24));
      iStack_8._0_1_ = 1;
      FUN_00a72960(iStack_24 + iVar4,auStack_3c,0);
      piVar3 = piStack_28;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_28[1] + -1;
        piStack_28[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uVar5 = uVar5 + 1;
      iVar4 = iVar4 + 0x18;
    } while (uVar5 < (uint)((iStack_20 - iStack_24) / 0x18));
  }
  FUN_00612d60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22808 ; VA 0x00af3bd0 ; FUN_00af3bd0 */

float * FUN_00af3bd0(float *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int *piVar4;
  int iVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  int iStack_10;
  int iStack_c;
  
  *param_1 = 3.4028235e+38;
  param_1[1] = 3.4028235e+38;
  param_1[2] = 3.4028235e+38;
  param_1[3] = -3.4028235e+38;
  param_1[4] = -3.4028235e+38;
  param_1[5] = -3.4028235e+38;
  FUN_00a70e60(&iStack_10);
  fVar3 = DAT_018e3f8c;
  iVar5 = (iStack_c - iStack_10) / 0x18;
  if (iVar5 != 0) {
    piVar4 = (int *)(iStack_10 + 0x14);
    do {
      fVar8 = (float)piVar4[-3] * fVar3;
      fVar7 = (float)piVar4[-5] * fVar3;
      fVar6 = (float)piVar4[-4] * fVar3;
      fVar9 = param_1[2];
      if (fVar8 <= param_1[2]) {
        fVar9 = fVar8;
      }
      fVar1 = param_1[1];
      if (fVar6 <= param_1[1]) {
        fVar1 = fVar6;
      }
      fVar2 = *param_1;
      if (fVar7 <= *param_1) {
        fVar2 = fVar7;
      }
      *(ulonglong *)param_1 = CONCAT44(fVar1,fVar2);
      param_1[2] = fVar9;
      fVar9 = param_1[5];
      if (param_1[5] <= fVar8) {
        fVar9 = fVar8;
      }
      fVar8 = param_1[4];
      if (param_1[4] <= fVar6) {
        fVar8 = fVar6;
      }
      fVar6 = param_1[3];
      if (param_1[3] <= fVar7) {
        fVar6 = fVar7;
      }
      *(ulonglong *)(param_1 + 3) = CONCAT44(fVar8,fVar6);
      param_1[5] = fVar9;
      fVar8 = (float)*piVar4 * fVar3;
      fVar7 = (float)piVar4[-2] * fVar3;
      fVar6 = (float)piVar4[-1] * fVar3;
      fVar9 = param_1[2];
      if (fVar8 <= param_1[2]) {
        fVar9 = fVar8;
      }
      fVar1 = param_1[1];
      if (fVar6 <= param_1[1]) {
        fVar1 = fVar6;
      }
      fVar2 = *param_1;
      if (fVar7 <= *param_1) {
        fVar2 = fVar7;
      }
      *(ulonglong *)param_1 = CONCAT44(fVar1,fVar2);
      param_1[2] = fVar9;
      fVar9 = param_1[5];
      if (param_1[5] <= fVar8) {
        fVar9 = fVar8;
      }
      fVar8 = param_1[4];
      if (param_1[4] <= fVar6) {
        fVar8 = fVar6;
      }
      fVar6 = param_1[3];
      if (param_1[3] <= fVar7) {
        fVar6 = fVar7;
      }
      piVar4 = piVar4 + 6;
      *(ulonglong *)(param_1 + 3) = CONCAT44(fVar8,fVar6);
      param_1[5] = fVar9;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
  }
  FUN_00612d60();
  return param_1;
}



/* FUNCTION 22809 ; VA 0x00af3d90 ; FUN_00af3d90 */

undefined4 * __thiscall
FUN_00af3d90(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4481;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x54) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00922680;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x54 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22810 ; VA 0x00af3f40 ; FUN_00af3f40 */

void FUN_00af3f40(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00afe380();
    *param_2 = uVar3;
    iVar4 = FUN_00afe6f0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22811 ; VA 0x00af3fa0 ; FUN_00af3fa0 */

void FUN_00af3fa0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00afe430();
    *param_2 = uVar3;
    iVar4 = FUN_00afe760();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22812 ; VA 0x00af4000 ; FUN_00af4000 */

void FUN_00af4000(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00afe4e0();
    *param_2 = uVar3;
    iVar4 = FUN_00afe7d0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22813 ; VA 0x00af4060 ; FUN_00af4060 */

void FUN_00af4060(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00afe590();
    *param_2 = uVar3;
    iVar4 = FUN_00afe840();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22814 ; VA 0x00af40c0 ; FUN_00af40c0 */

void FUN_00af40c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00afe640();
    *param_2 = uVar3;
    iVar4 = FUN_00afe8b0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22815 ; VA 0x00af4120 ; FUN_00af4120 */

void FUN_00af4120(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("Terrain is already smooth!");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22816 ; VA 0x00af4150 ; FUN_00af4150 */

void FUN_00af4150(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe380();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22817 ; VA 0x00af4190 ; FUN_00af4190 */

void FUN_00af4190(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe430();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22818 ; VA 0x00af41d0 ; FUN_00af41d0 */

void FUN_00af41d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe4e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22819 ; VA 0x00af4210 ; FUN_00af4210 */

void FUN_00af4210(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe590();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22820 ; VA 0x00af4250 ; FUN_00af4250 */

void FUN_00af4250(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe640();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22821 ; VA 0x00af4290 ; FUN_00af4290 */

undefined4 * __thiscall FUN_00af4290(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = *(undefined4 *)(param_1 + 0x134);
  puVar4 = (undefined4 *)FUN_00af0d20(auStack_10,&uStack_8,&stack0x00000008);
  *param_2 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar2;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_c[1] + -1;
    piStack_c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piStack_c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    return param_2;
  }
  return param_2;
}



/* FUNCTION 22822 ; VA 0x00af4320 ; FUN_00af4320 */

undefined4 * FUN_00af4320(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_008ac370(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 22823 ; VA 0x00af4390 ; FUN_00af4390 */

void FUN_00af4390(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 3;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 22824 ; VA 0x00af43d0 ; FUN_00af43d0 */

void __thiscall FUN_00af43d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_005c9cc0();
    puVar3 = &uStack_28c;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22825 ; VA 0x00af46e0 ; FUN_00af46e0 */

void __thiscall FUN_00af46e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_00630820();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22826 ; VA 0x00af48e0 ; FUN_00af48e0 */

void __thiscall FUN_00af48e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088d870();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_005c9cc0();
    puVar3 = &uStack_28c;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22827 ; VA 0x00af4bf0 ; FUN_00af4bf0 */

void __thiscall
FUN_00af4bf0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798d19;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x50);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    uStack_ec = FUN_00afe430();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00afe760();
    puVar3 = &uStack_ec;
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_00afe430();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x40) != 0) {
    uVar4 = uVar4 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x54);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 0x11;
    uVar4 = uVar4 | 0x200;
  }
  else {
    uStack_ec = FUN_00afe380();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00afe6f0();
    puVar3 = &uStack_ec;
    uStack_8 = 0x10;
    uVar4 = uVar4 | 0x100;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_00afe380();
  uVar2 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x200) != 0) {
    uVar4 = uVar4 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x100) != 0) {
    uVar4 = uVar4 & 0xfffffeff;
    uStack_8 = 0x13;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x58);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 0x15;
    uVar4 = uVar4 | 0x800;
  }
  else {
    uStack_28c = FUN_00afe4e0();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_00afe7d0();
    puVar3 = &uStack_28c;
    uStack_8 = 0x14;
    uVar4 = uVar4 | 0x400;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_00afe4e0();
  uVar2 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x800) != 0) {
    uVar4 = uVar4 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x400) != 0) && (uStack_8 = 0x17, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22828 ; VA 0x00af51f0 ; FUN_00af51f0 */

void __thiscall
FUN_00af51f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf757;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x50);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    uStack_ec = FUN_00afe640();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00afe8b0();
    puVar3 = &uStack_ec;
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_00afe640();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x40) != 0) {
    uVar4 = uVar4 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x54);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 0x11;
    uVar4 = uVar4 | 0x200;
  }
  else {
    uStack_28c = FUN_00afe590();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_00afe840();
    puVar3 = &uStack_28c;
    uStack_8 = 0x10;
    uVar4 = uVar4 | 0x100;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_00afe590();
  uVar2 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x200) != 0) {
    uVar4 = uVar4 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x100) != 0) && (uStack_8 = 0x13, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22829 ; VA 0x00af56f0 ; FUN_00af56f0 */

void __thiscall FUN_00af56f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec8f8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    puVar4 = (undefined4 *)FUN_00a93e70(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22830 ; VA 0x00af59f0 ; FUN_00af59f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00af59f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288)
       && (FUN_016f3809(&DAT_01ead288), DAT_01ead288 == -1)) {
      DAT_01ead27c = FUN_0057bbb0;
      _DAT_01ead280 = FUN_005880a0;
      DAT_01ead284 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead288);
    }
    puStack_e8 = &DAT_01ead27c;
    puVar6 = &uStack_ec;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(iStack_1c + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088d910();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar6;
    uStack_e0 = CONCAT22(uStack_e0._2_2_,*(undefined2 *)(puVar6 + 1));
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3e8)
       && (FUN_016f3809(&DAT_01ead3e8), DAT_01ead3e8 == -1)) {
      _DAT_01ead3dc = FUN_0061a030;
      _DAT_01ead3e0 = FUN_0061a030;
      DAT_01ead3e4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3e8);
    }
    puStack_e8 = (undefined4 *)&DAT_01ead3dc;
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088d910();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(iStack_1c + 0x4c);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = FUN_0088daf0();
    iStack_288 = 0;
    auStack_284[0] = *puVar2;
    iStack_288 = FUN_005c9ef0();
    puVar6 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22831 ; VA 0x00af5e10 ; FUN_00af5e10 */

void __thiscall
FUN_00af5e10(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec9f5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93d20(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_00b00260();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_28c = thunk_FUN_00896e70();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_008973b0();
    puVar4 = &uStack_28c;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22832 ; VA 0x00af6200 ; FUN_00af6200 */

void __thiscall FUN_00af6200(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecaa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93d20(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_00b00260();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_00912980(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_1bc = thunk_FUN_00896e70();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_008973b0();
    puVar5 = &uStack_1bc;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22833 ; VA 0x00af64d0 ; FUN_00af64d0 */

void __thiscall
FUN_00af64d0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6655;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1420(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x50) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1420(*(int *)(param_1 + 0x50));
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22834 ; VA 0x00af6880 ; FUN_00af6880 */

void __thiscall
FUN_00af6880(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec9f5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = thunk_FUN_00896e70();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_008973b0();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_28c = thunk_FUN_00896e70();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_008973b0();
    puVar4 = &uStack_28c;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22835 ; VA 0x00af6c70 ; FUN_00af6c70 */

void __thiscall FUN_00af6c70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1ec8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = thunk_FUN_00896e70();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_008973b0();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22836 ; VA 0x00af6f60 ; FUN_00af6f60 */

void __thiscall
FUN_00af6f60(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar1 = *(undefined8 **)(param_1 + 0x44);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_00b33940();
    iStack_e8 = 0;
    uStack_e4 = *puVar1;
    uStack_dc = *(undefined4 *)(puVar1 + 1);
    iStack_e8 = FUN_006312a0();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar1 == (undefined8 *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_00b33940();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_00afe430();
    iStack_e8 = 0;
    uStack_e4 = CONCAT44(uStack_e4._4_4_,*puVar4);
    iStack_e8 = FUN_00afe760();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00afe430();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = FUN_00afe380();
    iStack_e8 = 0;
    uStack_e4 = CONCAT44(uStack_e4._4_4_,*puVar4);
    iStack_e8 = FUN_00afe6f0();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00afe380();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_28c = FUN_00afe4e0();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_00afe7d0();
    puVar4 = &uStack_28c;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00afe4e0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22837 ; VA 0x00af7370 ; FUN_00af7370 */

void __thiscall FUN_00af7370(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1ec8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00912980(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = thunk_FUN_00896e70();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_008973b0();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22838 ; VA 0x00af7660 ; FUN_00af7660 */

void __thiscall FUN_00af7660(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_1bc = thunk_FUN_00896e70();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_008973b0();
    puStack_18 = &uStack_1bc;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined8 **)(param_1 + 0x48);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088d050();
    iStack_e8 = 0;
    uStack_e4 = *puVar1;
    uStack_dc = *(undefined4 *)(puVar1 + 1);
    iStack_e8 = FUN_005c9e10();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d050();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22839 ; VA 0x00af7890 ; FUN_00af7890 */

void __thiscall FUN_00af7890(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_005c9cc0();
    puVar3 = &uStack_28c;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22840 ; VA 0x00af7ba0 ; FUN_00af7ba0 */

void __thiscall
FUN_00af7ba0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [51];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_008bc760(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_008bc760(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x50);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    uStack_28c = thunk_FUN_00896e70();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_008973b0();
    puVar5 = &uStack_28c;
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_00896e70();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22841 ; VA 0x00af7f40 ; FUN_00af7f40 */

void FUN_00af7f40(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("Cannot Destroy() Terrain");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22842 ; VA 0x00af7f70 ; FUN_00af7f70 */

void __thiscall FUN_00af7f70(int param_1,int param_2)

{
  if (param_2 + 0x54 +
      *(int *)(*(int *)(param_2 + 0x54) + *(int *)(param_1 + 0x3c)) + *(int *)(param_1 + 0x38) != 0)
  {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 22843 ; VA 0x00af7fa0 ; FUN_00af7fa0 */

uint __fastcall FUN_00af7fa0(int param_1)

{
  short *psVar1;
  short *psVar2;
  short *psVar3;
  undefined auStack_1c [12];
  undefined auStack_10 [12];
  undefined2 uVar4;
  
  psVar1 = (short *)(**(code **)(param_1 + 8))(auStack_10);
  psVar2 = (short *)(**(code **)(param_1 + 8))(auStack_1c);
  psVar3 = psVar2;
  if (((*psVar1 == *psVar2) && (psVar1[1] == psVar2[1])) && (psVar1[2] == psVar2[2])) {
    uVar4 = (undefined2)((uint)psVar2 >> 0x10);
    psVar3 = (short *)CONCAT22(uVar4,psVar1[3]);
    if (((psVar1[3] == psVar2[3]) &&
        (psVar3 = (short *)CONCAT22(uVar4,psVar1[4]), psVar1[4] == psVar2[4])) &&
       (psVar3 = (short *)CONCAT22(uVar4,psVar1[5]), psVar1[5] == psVar2[5])) {
      return CONCAT31((int3)((uint)psVar3 >> 8),1);
    }
  }
  return (uint)psVar3 & 0xffffff00;
}



/* FUNCTION 22844 ; VA 0x00af8040 ; FUN_00af8040 */

undefined __fastcall FUN_00af8040(int param_1)

{
  uint *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined uVar7;
  bool bVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbVar2 = (byte *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  pbVar3 = (byte *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = (uint *)(pbVar3 + 0x10);
  if (0xf < *(uint *)(pbVar3 + 0x14)) {
    pbVar3 = *(byte **)pbVar3;
  }
  uVar4 = *(uint *)(pbVar2 + 0x10);
  if (0xf < *(uint *)(pbVar2 + 0x14)) {
    pbVar2 = *(byte **)pbVar2;
  }
  if (uVar4 == *puVar1) {
    while (uVar6 = uVar4 - 4, 3 < uVar4) {
      if (*(int *)pbVar2 != *(int *)pbVar3) goto LAB_00af80da;
      pbVar2 = pbVar2 + 4;
      pbVar3 = pbVar3 + 4;
      uVar4 = uVar6;
    }
    if (uVar6 == 0xfffffffc) {
LAB_00af810e:
      uVar4 = 0;
    }
    else {
LAB_00af80da:
      bVar8 = *pbVar2 < *pbVar3;
      if ((*pbVar2 == *pbVar3) &&
         ((uVar6 == 0xfffffffd ||
          ((bVar8 = pbVar2[1] < pbVar3[1], pbVar2[1] == pbVar3[1] &&
           ((uVar6 == 0xfffffffe ||
            ((bVar8 = pbVar2[2] < pbVar3[2], pbVar2[2] == pbVar3[2] &&
             ((uVar6 == 0xffffffff || (bVar8 = pbVar2[3] < pbVar3[3], pbVar2[3] == pbVar3[3]))))))))
          )))) goto LAB_00af810e;
      uVar4 = -(uint)bVar8 | 1;
    }
    if (uVar4 == 0) {
      uVar7 = 1;
      goto LAB_00af811a;
    }
  }
  uVar7 = 0;
LAB_00af811a:
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 22845 ; VA 0x00af81b0 ; FUN_00af81b0 */

int __fastcall FUN_00af81b0(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined auStack_1c [12];
  undefined auStack_10 [12];
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))(auStack_10);
  pfVar5 = (float *)(**(code **)(param_1 + 8))(auStack_1c);
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 22846 ; VA 0x00af8240 ; FUN_00af8240 */

void FUN_00af8240(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("can\'t get value");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22847 ; VA 0x00af8270 ; FUN_00af8270 */

void __thiscall FUN_00af8270(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  code *pcVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined *puVar9;
  int iVar10;
  uint in_stack_0000002c;
  undefined4 uStack_248;
  int iStack_244;
  undefined auStack_240 [200];
  undefined4 uStack_178;
  int iStack_174;
  undefined auStack_170 [200];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  int aiStack_6c [5];
  uint uStack_58;
  int aiStack_54 [5];
  uint uStack_40;
  undefined auStack_3c [12];
  int *piStack_30;
  undefined uStack_2c;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  puStack_c = &LAB_017ecc0c;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = (**(code **)*param_3)();
  if (uVar5 < 4) {
LAB_00af8360:
    if (*(undefined4 **)(param_1 + 0x50) == (undefined4 *)0x0) {
      FUN_016756b0(auStack_20,"Argument %d missing or nil",4);
      puVar9 = auStack_20;
      goto LAB_00af876d;
    }
    param_3 = (int *)**(undefined4 **)(param_1 + 0x50);
    iVar10 = param_1;
  }
  else {
    pcVar1 = *(code **)(*piVar2 + 0x38);
    uVar6 = FUN_00896e70();
    cVar4 = (*pcVar1)(4,uVar6,&param_3);
    iVar10 = iStack_14;
    if (cVar4 == '\0') {
      uStack_178 = FUN_00888530();
      iStack_174 = 0;
      uStack_8._0_1_ = 2;
      cVar4 = (**(code **)(*piVar2 + 4))(4,&uStack_178);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 4;
        if (iStack_174 != 0) {
          (**(code **)(iStack_174 + 8))(auStack_170);
        }
        uStack_8._0_1_ = 1;
        param_1 = iStack_14;
        goto LAB_00af8360;
      }
      puVar8 = (undefined4 *)FUN_00b000c0();
      piStack_30 = (int *)*puVar8;
      uStack_8._0_1_ = 3;
      if (iStack_174 != 0) {
        (**(code **)(iStack_174 + 8))(auStack_170);
      }
      uStack_8._0_1_ = 1;
      param_3 = piStack_30;
      iVar10 = iStack_14;
    }
  }
  uVar5 = (**(code **)*piVar2)();
  if (uVar5 < 3) {
LAB_00af842a:
    if (*(int *)(iVar10 + 0x4c) != 0) {
      FUN_0054ef60(*(int *)(iVar10 + 0x4c));
      goto LAB_00af843e;
    }
    uVar6 = 3;
  }
  else {
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = 0;
    uStack_8._0_1_ = 5;
    uStack_178 = FUN_00888530();
    iStack_174 = 0;
    uStack_8._0_1_ = 6;
    cVar4 = (**(code **)(*piVar2 + 4))(3,&uStack_178);
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 8;
      if (iStack_174 != 0) {
        (**(code **)(iStack_174 + 8))(auStack_170);
      }
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      goto LAB_00af842a;
    }
    uVar6 = FUN_0088a920();
    FUN_0054ef60(uVar6);
    uStack_8._0_1_ = 7;
    if (iStack_174 != 0) {
      (**(code **)(iStack_174 + 8))(auStack_170);
    }
    FUN_005507b0();
LAB_00af843e:
    uStack_8._0_1_ = 9;
    uVar5 = (**(code **)*piVar2)();
    if (uVar5 < 2) {
LAB_00af84fc:
      if (*(int *)(iVar10 + 0x48) == 0) {
        FUN_016756b0(auStack_20,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_20,&DAT_01c17198);
      }
      FUN_0054ef60(*(int *)(iVar10 + 0x48));
    }
    else {
      uStack_1c = 0;
      uStack_18 = 0xf;
      uStack_2c = 0;
      uStack_8._0_1_ = 10;
      uStack_248 = FUN_00888530();
      iStack_244 = 0;
      uStack_8._0_1_ = 0xb;
      cVar4 = (**(code **)(*piVar2 + 4))(2,&uStack_248);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 0xd;
        if (iStack_244 != 0) {
          (**(code **)(iStack_244 + 8))(auStack_240);
        }
        uStack_8._0_1_ = 9;
        FUN_005507b0();
        goto LAB_00af84fc;
      }
      uVar6 = FUN_0088a920();
      FUN_0054ef60(uVar6);
      uStack_8._0_1_ = 0xc;
      if (iStack_244 != 0) {
        (**(code **)(iStack_244 + 8))(auStack_240);
      }
      FUN_005507b0();
    }
    uStack_8._0_1_ = 0xe;
    iVar7 = (**(code **)*piVar2)();
    if (iVar7 != 0) {
      FUN_00a73410();
      uStack_178 = FUN_00888530();
      iStack_174 = 0;
      uStack_8._0_1_ = 0xf;
      cVar4 = (**(code **)(*piVar2 + 4))(1,&uStack_178);
      if (cVar4 != '\0') {
        puVar8 = (undefined4 *)FUN_0088b0e0();
        uStack_a8 = *puVar8;
        uStack_a4 = puVar8[1];
        uStack_a0 = puVar8[2];
        uStack_9c = puVar8[3];
        uStack_98 = puVar8[4];
        uStack_94 = puVar8[5];
        uStack_90 = puVar8[6];
        uStack_8c = puVar8[7];
        uStack_88 = puVar8[8];
        uStack_84 = puVar8[9];
        uStack_80 = puVar8[10];
        uStack_7c = puVar8[0xb];
        uStack_78 = *(undefined8 *)(puVar8 + 0xc);
        uStack_70 = puVar8[0xe];
        uStack_8._0_1_ = 0x10;
        if (iStack_174 != 0) {
          (**(code **)(iStack_174 + 8))(auStack_170);
        }
        uStack_8._0_1_ = 0xe;
        goto LAB_00af8619;
      }
      uStack_8._0_1_ = 0x11;
      if (iStack_174 != 0) {
        (**(code **)(iStack_174 + 8))(auStack_170);
      }
      uStack_8._0_1_ = 0xe;
    }
    puVar8 = *(undefined4 **)(iVar10 + 0x44);
    if (puVar8 != (undefined4 *)0x0) {
      uStack_a8 = *puVar8;
      uStack_a4 = puVar8[1];
      uStack_a0 = puVar8[2];
      uStack_9c = puVar8[3];
      uStack_98 = puVar8[4];
      uStack_94 = puVar8[5];
      uStack_90 = puVar8[6];
      uStack_8c = puVar8[7];
      uStack_88 = puVar8[8];
      uStack_84 = puVar8[9];
      uStack_80 = puVar8[10];
      uStack_7c = puVar8[0xb];
      uStack_78 = *(undefined8 *)(puVar8 + 0xc);
      uStack_70 = puVar8[0xe];
LAB_00af8619:
      FUN_00af3830(param_2,*(undefined8 *)(iVar10 + 0x38),*(undefined4 *)(iVar10 + 0x40),&uStack_a8,
                   aiStack_54,aiStack_6c,&param_3,&param_4,&stack0x0000002c);
      uStack_8._0_1_ = 9;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 9;
      if (0xf < uStack_40) {
        uVar5 = uStack_40 + 1;
        iVar10 = aiStack_54[0];
        if (0xfff < uVar5) {
          iVar10 = *(int *)(aiStack_54[0] + -4);
          uVar5 = uStack_40 + 0x24;
          if (0x1f < (aiStack_54[0] - iVar10) - 4U) {
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar10,uVar5);
      }
      uStack_8._0_1_ = 1;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_58) {
        uVar5 = uStack_58 + 1;
        iVar10 = aiStack_6c[0];
        if (0xfff < uVar5) {
          iVar10 = *(int *)(aiStack_6c[0] + -4);
          uVar5 = uStack_58 + 0x24;
          if (0x1f < (aiStack_6c[0] - iVar10) - 4U) {
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar10,uVar5);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
      if (param_4 != 0) {
        if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
        }
        param_4 = 0;
      }
      uStack_8 = 0x13;
      if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uVar6 = 1;
  }
  FUN_016756b0(auStack_3c,"Argument %d missing or nil",uVar6);
  puVar9 = auStack_3c;
LAB_00af876d:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(puVar9,&DAT_01c17198);
}



/* FUNCTION 22848 ; VA 0x00af87a0 ; FUN_00af87a0 */

void __thiscall FUN_00af87a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x50))(param_3);
  return;
}



/* FUNCTION 22849 ; VA 0x00af87d0 ; FUN_00af87d0 */

void __thiscall FUN_00af87d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x58))(param_3);
  return;
}



/* FUNCTION 22850 ; VA 0x00af8800 ; FUN_00af8800 */

int FUN_00af8800(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ecc28;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_28 = FUN_009d05b0(param_2,param_3,3,iVar2,iStack_24 + 0x4c);
  uVar3 = FUN_009d05b0(param_2,param_3,2,iVar2,iStack_24 + 0x48);
  uVar4 = FUN_009d05b0(param_2,param_3,1,iVar2,iStack_24 + 0x44);
  pcStack_40 = (code *)*(undefined8 *)(iStack_24 + 0x38);
  uVar3 = (*pcStack_40)(auStack_30,uVar4,uVar3,uStack_28);
  uStack_14 = 0;
  iStack_24 = FUN_009d5730(param_2,uVar3);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_24;
}



/* FUNCTION 22851 ; VA 0x00af8910 ; FUN_00af8910 */

int FUN_00af8910(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  float10 fVar5;
  undefined auStack_7c [60];
  undefined8 uStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  float fStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ecc28;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  fVar5 = (float10)FUN_009d0730(param_2,param_3,2,iVar2 - param_3,iStack_24 + 0x48);
  fStack_28 = (float)fVar5;
  puVar3 = (undefined4 *)FUN_00a9cec0(auStack_7c,param_2,param_3,1,iVar2 - param_3,iStack_24 + 0x44)
  ;
  uStack_40 = *(undefined8 *)(iStack_24 + 0x38);
  uVar4 = (*(code *)uStack_40)
                    (auStack_30,*puVar3,puVar3[1],puVar3[2],puVar3[3],puVar3[4],puVar3[5],puVar3[6],
                     puVar3[7],puVar3[8],puVar3[9],puVar3[10],puVar3[0xb],
                     *(undefined8 *)(puVar3 + 0xc),puVar3[0xe],fStack_28);
  uStack_14 = 0;
  iStack_24 = FUN_009d5730(param_2,uVar4);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_24;
}



/* FUNCTION 22852 ; VA 0x00af8a40 ; FUN_00af8a40 */

undefined4 __thiscall FUN_00af8a40(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined auStack_4c [12];
  undefined8 uStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bc228;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined8 *)FUN_00afb9c0(auStack_4c,param_3,param_4,1,iVar2 - param_4,param_1 + 0x44);
  uStack_40 = *(undefined8 *)(param_1 + 0x38);
  uVar4 = (*(code *)uStack_40)(auStack_2c,*puVar3,*(undefined4 *)(puVar3 + 1));
  uStack_14 = 0;
  uStack_24 = FUN_009d5980(param_3,uVar4);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 22853 ; VA 0x00af8b20 ; FUN_00af8b20 */

undefined4 __thiscall FUN_00af8b20(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  undefined auStack_2c [12];
  undefined8 uStack_20;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00afbb30(param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_20 = *(undefined8 *)(param_1 + 0x38);
  puVar3 = (undefined8 *)(*(code *)uStack_20)(auStack_2c,uVar2);
  uStack_20 = *puVar3;
  uVar2 = *(undefined4 *)(puVar3 + 1);
  puVar3 = (undefined8 *)FUN_0087ddc0(param_3,PTR_s_Color3_01d6d38c,0xc,DAT_01ea8be8);
  *puVar3 = uStack_20;
  *(undefined4 *)(puVar3 + 1) = uVar2;
  return 1;
}



/* FUNCTION 22854 ; VA 0x00af8bd0 ; FUN_00af8bd0 */

void FUN_00af8bd0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  uStack_18 = FUN_009d05b0(param_2,param_3,3,iVar1,iStack_14 + 0x4c);
  uVar2 = FUN_009d05b0(param_2,param_3,2,iVar1,iStack_14 + 0x48);
  uVar3 = FUN_009d05b0(param_2,param_3,1,iVar1,iStack_14 + 0x44);
  uStack_28 = *(undefined8 *)(iStack_14 + 0x38);
  uVar2 = (*(code *)uStack_28)(auStack_34,uVar3,uVar2,uStack_18);
  FUN_009d5a70(param_2,uVar2);
  return;
}



/* FUNCTION 22855 ; VA 0x00af8c90 ; FUN_00af8c90 */

void __thiscall FUN_00af8c90(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined8 uStack_20;
  
  iVar1 = FUN_01256300(param_3);
  puVar2 = (undefined8 *)FUN_009d16a0(auStack_2c,param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_20 = *(undefined8 *)(param_1 + 0x38);
  uVar3 = (*(code *)uStack_20)(auStack_38,*puVar2,*(undefined4 *)(puVar2 + 1));
  FUN_009d5a70(param_3,uVar3);
  return;
}



/* FUNCTION 22856 ; VA 0x00af8d20 ; FUN_00af8d20 */

undefined4 FUN_00af8d20(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcStack_38;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  if (iVar2 < 6) {
LAB_00af8d7a:
    uStack_18 = FUN_00af1420(param_2,param_3,6,iVar2,iStack_14 + 0x58);
  }
  else {
    uVar3 = FUN_00afe4e0();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 6,&uStack_20);
    uStack_18 = uStack_20;
    if (cVar1 == '\0') goto LAB_00af8d7a;
  }
  if (iVar2 < 5) {
LAB_00af8dbb:
    uStack_1c = FUN_00af1020(param_2,param_3,5,iVar2,iStack_14 + 0x54);
  }
  else {
    uVar3 = FUN_00afe380();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 5,&uStack_20);
    uStack_1c = uStack_20;
    if (cVar1 == '\0') goto LAB_00af8dbb;
  }
  if (3 < iVar2) {
    uVar3 = FUN_00afe430();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 4,&uStack_20);
    if (cVar1 != '\0') goto LAB_00af8e12;
  }
  uStack_20 = FUN_00af1220(param_2,param_3,4,iVar2,iStack_14 + 0x50);
LAB_00af8e12:
  uVar3 = FUN_009d05b0(param_2,param_3,3,iVar2,iStack_14 + 0x4c);
  uVar4 = FUN_009d05b0(param_2,param_3,2,iVar2,iStack_14 + 0x48);
  uVar5 = FUN_009d05b0(param_2,param_3,1,iVar2,iStack_14 + 0x44);
  pcStack_38 = (code *)*(undefined8 *)(iStack_14 + 0x38);
  (*pcStack_38)(uVar5,uVar4,uVar3,uStack_20,uStack_1c,uStack_18);
  return 0;
}



/* FUNCTION 22857 ; VA 0x00af8ea0 ; FUN_00af8ea0 */

undefined4 FUN_00af8ea0(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcStack_30;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  if (iVar2 < 5) {
LAB_00af8efa:
    uStack_18 = FUN_00af1620(param_2,param_3,5,iVar2,iStack_14 + 0x54);
  }
  else {
    uVar3 = FUN_00afe590();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 5,&uStack_1c);
    uStack_18 = uStack_1c;
    if (cVar1 == '\0') goto LAB_00af8efa;
  }
  if (3 < iVar2) {
    uVar3 = FUN_00afe640();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 4,&uStack_1c);
    if (cVar1 != '\0') goto LAB_00af8f51;
  }
  uStack_1c = FUN_00af1820(param_2,param_3,4,iVar2,iStack_14 + 0x50);
LAB_00af8f51:
  uVar3 = FUN_009d05b0(param_2,param_3,3,iVar2,iStack_14 + 0x4c);
  uVar4 = FUN_009d05b0(param_2,param_3,2,iVar2,iStack_14 + 0x48);
  uVar5 = FUN_009d05b0(param_2,param_3,1,iVar2,iStack_14 + 0x44);
  pcStack_30 = (code *)*(undefined8 *)(iStack_14 + 0x38);
  (*pcStack_30)(uVar5,uVar4,uVar3,uStack_1c,uStack_18);
  return 0;
}



/* FUNCTION 22858 ; VA 0x00af8fe0 ; FUN_00af8fe0 */

undefined4 FUN_00af8fe0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_10c [4];
  undefined4 uStack_108;
  uint *puStack_104;
  undefined4 uStack_100;
  int iStack_fc;
  undefined4 uStack_f8;
  int iStack_f4;
  int iStack_f0;
  int *piStack_ec;
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  int iStack_dc;
  int iStack_d8;
  undefined *puStack_d4;
  undefined4 uStack_d0;
  int iStack_cc;
  undefined4 uStack_c8;
  undefined8 uStack_c4;
  undefined4 uStack_bc;
  undefined auStack_ac [60];
  int aiStack_70 [5];
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ecc58;
  pvStack_1c = ExceptionList;
  uStack_bc = param_2;
  uStack_c4 = CONCAT44(0xaf901f,(undefined4)uStack_c4);
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  puStack_d4 = auStack_ac;
  iVar1 = iVar1 - param_3;
  uStack_c4 = CONCAT44(iStack_24 + 0x4c,iVar1);
  uStack_c8 = 3;
  iStack_cc = param_3;
  uStack_d0 = param_2;
  iStack_d8 = 0xaf9040;
  puStack_28 = (undefined4 *)FUN_00a9cec0();
  iStack_d8 = iStack_24 + 0x48;
  uStack_e0 = 2;
  iStack_e4 = param_3;
  uStack_e8 = param_2;
  piStack_ec = aiStack_70;
  iStack_f0 = 0xaf905a;
  iStack_dc = iVar1;
  uStack_2c = FUN_009d09d0();
  puStack_104 = auStack_58;
  iStack_f0 = iStack_24 + 0x44;
  uStack_14 = 0;
  uStack_f8 = 1;
  iStack_fc = param_3;
  uStack_100 = param_2;
  uStack_108 = 0xaf907b;
  iStack_f4 = iVar1;
  uVar2 = FUN_009d09d0();
  uStack_14._0_1_ = 1;
  uStack_40 = *(undefined8 *)(iStack_24 + 0x38);
  iStack_f4 = *puStack_28;
  iStack_f0 = puStack_28[1];
  piStack_ec = (int *)puStack_28[2];
  uStack_e8 = puStack_28[3];
  iStack_e4 = puStack_28[4];
  uStack_e0 = puStack_28[5];
  iStack_dc = puStack_28[6];
  iStack_d8 = puStack_28[7];
  puStack_d4 = (undefined *)puStack_28[8];
  uStack_d0 = puStack_28[9];
  iStack_cc = puStack_28[10];
  uStack_c8 = puStack_28[0xb];
  uStack_c4 = *(undefined8 *)(puStack_28 + 0xc);
  uStack_bc = puStack_28[0xe];
  puStack_28 = (undefined4 *)auStack_10c;
  FUN_0054ef60(uStack_2c);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  (*(code *)uStack_40)();
  if (0xf < uStack_44) {
    uVar3 = uStack_44 + 1;
    uVar4 = auStack_58[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_58[0] - 4);
      uVar3 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    iVar1 = aiStack_70[0];
    if (0xfff < uVar4) {
      iVar1 = *(int *)(aiStack_70[0] + -4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (aiStack_70[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar4);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22859 ; VA 0x00af9190 ; FUN_00af9190 */

undefined4 FUN_00af9190(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [200];
  undefined auStack_48 [4];
  int *piStack_44;
  undefined8 auStack_40 [2];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined2 uStack_22;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ecc83;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  uVar2 = FUN_009d1aa0(param_2,param_3,3,iVar4,iStack_28 + 0x4c);
  uStack_30 = CONCAT31(uStack_30._1_3_,uVar2);
  if (iVar4 < 2) {
LAB_00af92be:
    puVar5 = *(undefined4 **)(iStack_28 + 0x48);
    if (puVar5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_40,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
  }
  else {
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + 2,DAT_01ede6bc);
    if (puVar5 == (undefined4 *)0x0) {
      if (1 < iVar4) {
        uStack_118 = FUN_00888530();
        iStack_114 = 0;
        uStack_14 = 0;
        cVar3 = FUN_009d1bf0(param_2,param_3 + 2,&uStack_118,1);
        if (cVar3 != '\0') {
          puVar5 = (undefined4 *)FUN_0088b990();
          uStack_2c = *puVar5;
          uStack_22 = *(undefined2 *)(puVar5 + 1);
          uStack_14 = 1;
          if (iStack_114 != 0) {
            (**(code **)(iStack_114 + 8))(auStack_110);
          }
          uStack_14 = 0xffffffff;
          goto LAB_00af92d9;
        }
        uStack_14 = 2;
        if (iStack_114 != 0) {
          (**(code **)(iStack_114 + 8))(auStack_110);
        }
        uStack_14 = 0xffffffff;
      }
      goto LAB_00af92be;
    }
  }
  uStack_2c = *puVar5;
  uStack_22 = *(undefined2 *)(puVar5 + 1);
LAB_00af92d9:
  puVar5 = (undefined4 *)FUN_009d1340(auStack_48,param_2,param_3,1,iVar4,iStack_28 + 0x44);
  uStack_14 = 3;
  auStack_40[0] = *(undefined8 *)(iStack_28 + 0x38);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*(code *)auStack_40[0])(*puVar5,puVar5[1],uStack_2c,uStack_22,uStack_30);
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_44[1] + -1;
    piStack_44[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22860 ; VA 0x00af93c0 ; FUN_00af93c0 */

undefined4 FUN_00af93c0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 *puVar2;
  float10 fVar3;
  undefined auStack_60 [48];
  undefined8 uStack_30;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  uStack_18 = FUN_00afbb30(param_2,param_3,4,iVar1,iStack_14 + 0x50);
  fVar3 = (float10)FUN_009d0730(param_2,param_3,3,iVar1,iStack_14 + 0x4c);
  fStack_1c = (float)fVar3;
  fVar3 = (float10)FUN_009d0730(param_2,param_3,2,iVar1,iStack_14 + 0x48);
  fStack_20 = (float)fVar3;
  puVar2 = (undefined4 *)FUN_00a9c980(auStack_60,param_2,param_3,1,iVar1,iStack_14 + 0x44);
  uStack_30 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_30)
            (*puVar2,puVar2[1],puVar2[2],puVar2[3],puVar2[4],puVar2[5],puVar2[6],puVar2[7],puVar2[8]
             ,puVar2[9],puVar2[10],puVar2[0xb],fStack_20,fStack_1c,uStack_18);
  return 0;
}



/* FUNCTION 22861 ; VA 0x00af94c0 ; FUN_00af94c0 */

undefined4 FUN_00af94c0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 *puVar3;
  undefined auStack_64 [48];
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  uStack_18 = FUN_00afbb30(param_2,param_3,3,iVar1,iStack_14 + 0x4c);
  puVar2 = (undefined8 *)FUN_009d16a0(auStack_34,param_2,param_3,2,iVar1,iStack_14 + 0x48);
  puVar3 = (undefined4 *)FUN_00a9c980(auStack_64,param_2,param_3,1,iVar1,iStack_14 + 0x44);
  uStack_28 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_28)
            (*puVar3,puVar3[1],puVar3[2],puVar3[3],puVar3[4],puVar3[5],puVar3[6],puVar3[7],puVar3[8]
             ,puVar3[9],puVar3[10],puVar3[0xb],*puVar2,*(undefined4 *)(puVar2 + 1),uStack_18);
  return 0;
}



/* FUNCTION 22862 ; VA 0x00af95a0 ; FUN_00af95a0 */

undefined4 FUN_00af95a0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  int iVar16;
  undefined4 *puVar17;
  int iVar18;
  float10 fVar19;
  undefined *puVar20;
  undefined4 uVar21;
  int iVar22;
  undefined4 uVar23;
  int iVar24;
  undefined auStack_8c [60];
  undefined8 uStack_50;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  float fStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ecca0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar16 = FUN_01256300(param_2);
  puVar20 = auStack_40;
  iVar18 = iStack_24 + 0x50;
  iVar16 = iVar16 - param_3;
  uVar23 = 4;
  uVar21 = param_2;
  iVar22 = param_3;
  iVar24 = iVar16;
  puStack_28 = (undefined4 *)FUN_009d11e0();
  uStack_14 = 0;
  puStack_2c = (undefined4 *)
               FUN_009d11e0(auStack_38,param_2,param_3,3,iVar16,iStack_24 + 0x4c,puVar20,uVar21,
                            iVar22,uVar23,iVar24,iVar18);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  fVar19 = (float10)FUN_009d0730(param_2,param_3,2,iVar16,iStack_24 + 0x48);
  fStack_30 = (float)fVar19;
  puVar17 = (undefined4 *)FUN_00a9cec0(auStack_8c,param_2,param_3,1,iVar16,iStack_24 + 0x44);
  uVar23 = *puVar17;
  uVar5 = puVar17[1];
  uVar6 = puVar17[2];
  uVar7 = puVar17[3];
  uStack_50 = *(undefined8 *)(iStack_24 + 0x38);
  uVar8 = puVar17[4];
  uVar9 = puVar17[5];
  uVar10 = puVar17[6];
  uVar11 = puVar17[7];
  uVar21 = puVar17[0xe];
  uVar12 = puVar17[8];
  uVar13 = puVar17[9];
  uVar14 = puVar17[10];
  uVar15 = puVar17[0xb];
  uVar2 = *(undefined8 *)(puVar17 + 0xc);
  if (puStack_28[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_28[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *puStack_28;
  uVar4 = puStack_28[1];
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*(code *)uStack_50)
            (uVar23,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,uVar13,uVar14,uVar15,uVar2,
             uVar21,fStack_30,*puStack_2c,puStack_2c[1],uVar3,uVar4);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar22 = piStack_34[1] + -1;
    piStack_34[1] = iVar22;
    UNLOCK();
    if (iVar22 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar22 = piStack_34[2] + -1;
      piStack_34[2] = iVar22;
      UNLOCK();
      if (iVar22 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar22 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar22;
    UNLOCK();
    if (iVar22 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar22 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar22 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22863 ; VA 0x00af9770 ; FUN_00af9770 */

undefined4 FUN_00af9770(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  float10 fVar4;
  undefined auStack_6c [60];
  undefined8 uStack_30;
  float fStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  uStack_18 = FUN_00afbb30(param_2,param_3,4,iVar1,iStack_14 + 0x50);
  uVar2 = FUN_00afbb30(param_2,param_3,3,iVar1,iStack_14 + 0x4c);
  fVar4 = (float10)FUN_009d0730(param_2,param_3,2,iVar1,iStack_14 + 0x48);
  fStack_1c = (float)fVar4;
  puVar3 = (undefined4 *)FUN_00a9cec0(auStack_6c,param_2,param_3,1,iVar1,iStack_14 + 0x44);
  uStack_30 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_30)
            (*puVar3,puVar3[1],puVar3[2],puVar3[3],puVar3[4],puVar3[5],puVar3[6],puVar3[7],puVar3[8]
             ,puVar3[9],puVar3[10],puVar3[0xb],*(undefined8 *)(puVar3 + 0xc),puVar3[0xe],fStack_1c,
             uVar2,uStack_18);
  return 0;
}



/* FUNCTION 22864 ; VA 0x00af9870 ; FUN_00af9870 */

undefined4 FUN_00af9870(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 *puVar2;
  float10 fVar3;
  undefined auStack_6c [60];
  undefined8 uStack_30;
  float fStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  uStack_18 = FUN_00afbb30(param_2,param_3,3,iVar1,iStack_14 + 0x4c);
  fVar3 = (float10)FUN_009d0730(param_2,param_3,2,iVar1,iStack_14 + 0x48);
  fStack_1c = (float)fVar3;
  puVar2 = (undefined4 *)FUN_00a9cec0(auStack_6c,param_2,param_3,1,iVar1,iStack_14 + 0x44);
  uStack_30 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_30)
            (*puVar2,puVar2[1],puVar2[2],puVar2[3],puVar2[4],puVar2[5],puVar2[6],puVar2[7],puVar2[8]
             ,puVar2[9],puVar2[10],puVar2[0xb],*(undefined8 *)(puVar2 + 0xc),puVar2[0xe],fStack_1c,
             uStack_18);
  return 0;
}



/* FUNCTION 22865 ; VA 0x00af9950 ; FUN_00af9950 */

undefined4 __thiscall FUN_00af9950(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined8 *puVar2;
  undefined auStack_2c [12];
  undefined8 uStack_20;
  
  iVar1 = FUN_01256300(param_3);
  puVar2 = (undefined8 *)FUN_00afb9c0(auStack_2c,param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_20 = *(undefined8 *)(param_1 + 0x38);
  (*(code *)uStack_20)(*puVar2,*(undefined4 *)(puVar2 + 1));
  return 0;
}



/* FUNCTION 22866 ; VA 0x00af99d0 ; FUN_00af99d0 */

undefined4 FUN_00af99d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  undefined auStack_3c [12];
  undefined8 uStack_30;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  if (iVar2 < 4) {
LAB_00af9a27:
    uStack_18 = FUN_00af1420();
  }
  else {
    uVar3 = FUN_00afe4e0();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 4,&uStack_20);
    uStack_18 = uStack_20;
    if (cVar1 == '\0') goto LAB_00af9a27;
  }
  if (iVar2 < 3) {
LAB_00af9a68:
    uStack_1c = FUN_00af1020();
  }
  else {
    uVar3 = FUN_00afe380();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 3,&uStack_20);
    uStack_1c = uStack_20;
    if (cVar1 == '\0') goto LAB_00af9a68;
  }
  if (1 < iVar2) {
    uVar3 = FUN_00afe430();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 2,&uStack_20);
    if (cVar1 != '\0') goto LAB_00af9abf;
  }
  uStack_20 = FUN_00af1220();
LAB_00af9abf:
  puVar4 = (undefined8 *)FUN_00afb9c0(auStack_3c,param_2,param_3,1,iVar2,iStack_14 + 0x44);
  uStack_30 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_30)(*puVar4,*(undefined4 *)(puVar4 + 1),uStack_20,uStack_1c,uStack_18);
  return 0;
}



/* FUNCTION 22867 ; VA 0x00af9b30 ; FUN_00af9b30 */

undefined4 FUN_00af9b30(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  float10 fVar3;
  undefined auStack_3c [12];
  undefined8 uStack_30;
  float fStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  uStack_18 = FUN_00afbb30(param_2,param_3,3,iVar1,iStack_14 + 0x4c);
  fVar3 = (float10)FUN_009d0730(param_2,param_3,2,iVar1,iStack_14 + 0x48);
  fStack_1c = (float)fVar3;
  puVar2 = (undefined8 *)FUN_009d16a0(auStack_3c,param_2,param_3,1,iVar1,iStack_14 + 0x44);
  uStack_30 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_30)(*puVar2,*(undefined4 *)(puVar2 + 1),fStack_1c,uStack_18);
  return 0;
}



/* FUNCTION 22868 ; VA 0x00af9c00 ; FUN_00af9c00 */

undefined4 FUN_00af9c00(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [200];
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined8 auStack_38 [2];
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bd5ab;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  if (1 < iVar2) {
    puVar3 = (undefined8 *)FUN_01257810(param_2,param_3 + 2,DAT_01ea8be8);
    if (puVar3 != (undefined8 *)0x0) {
      auStack_38[0] = *puVar3;
      uVar5 = *(undefined4 *)(puVar3 + 1);
      uStack_40 = uVar5;
      goto LAB_00af9d4f;
    }
    if (1 < iVar2) {
      uStack_118 = FUN_00888530();
      iStack_114 = 0;
      uStack_14 = 0;
      cVar1 = FUN_009d1bf0(param_2,param_3 + 2,&uStack_118,1);
      if (cVar1 != '\0') {
        puVar3 = (undefined8 *)FUN_0088a700();
        auStack_38[0] = *puVar3;
        uVar5 = *(undefined4 *)(puVar3 + 1);
        uStack_14 = 1;
        if (iStack_114 != 0) {
          (**(code **)(iStack_114 + 8))(auStack_110);
        }
        uStack_14 = 0xffffffff;
        goto LAB_00af9d4f;
      }
      uStack_14 = 2;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      uStack_14 = 0xffffffff;
    }
  }
  puVar3 = *(undefined8 **)(iStack_24 + 0x48);
  if (puVar3 == (undefined8 *)0x0) {
    FUN_016756b0(auStack_38,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  auStack_38[0] = *puVar3;
  uVar5 = *(undefined4 *)(puVar3 + 1);
LAB_00af9d4f:
  uVar4 = FUN_00afbb30(param_2,param_3,1,iVar2,iStack_24 + 0x44);
  uStack_48 = *(undefined8 *)(iStack_24 + 0x38);
  (*(code *)uStack_48)(uVar4,auStack_38[0],uVar5);
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22869 ; VA 0x00af9dd0 ; FUN_00af9dd0 */

void __thiscall FUN_00af9dd0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uStack_28;
  
  iVar1 = FUN_01256300(param_3);
  iVar1 = iVar1 - param_4;
  uVar2 = FUN_009d05b0(param_3,param_4,3,iVar1,param_1 + 0x4c);
  uVar3 = FUN_009d05b0(param_3,param_4,2,iVar1,param_1 + 0x48);
  uVar4 = FUN_009d05b0(param_3,param_4,1,iVar1,param_1 + 0x44);
  uStack_28 = (code *)*(undefined8 *)(param_1 + 0x38);
  uVar2 = (*uStack_28)(uVar4,uVar3,uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 22870 ; VA 0x00af9e80 ; FUN_00af9e80 */

void FUN_00af9e80(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00af9ec0(param_1,param_2,param_3,param_4,0);
  return;
}



/* FUNCTION 22871 ; VA 0x00af9ec0 ; FUN_00af9ec0 */

/* WARNING: Removing unreachable block (ram,0x00af9f97) */

int FUN_00af9ec0(float param_1,float param_2,float param_3,float param_4,int param_5,char param_6)

{
  int *piVar1;
  byte bVar2;
  float fVar3;
  undefined2 uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  ulonglong uVar13;
  undefined auStack_a0 [12];
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  int aiStack_88 [3];
  int iStack_7c;
  int iStack_78;
  int *piStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  int iStack_64;
  undefined4 uStack_60;
  int iStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  uint uStack_18;
  undefined2 uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eccbb;
  pvStack_10 = ExceptionList;
  fStack_94 = param_1 + param_4;
  fStack_90 = param_2 + param_4;
  fStack_8c = param_3 + param_4;
  fStack_70 = param_1 - param_4;
  fStack_6c = param_2 - param_4;
  fStack_68 = param_3 - param_4;
  ExceptionList = &pvStack_10;
  FUN_00a705d0(&iStack_40,&fStack_70,&fStack_94);
  if (((iStack_40 == iStack_34) || (iStack_3c == iStack_30)) || (iStack_38 == iStack_2c)) {
    FUN_00550130("Extents cannot be empty");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_a0,&DAT_01c17198);
  }
  uVar13 = FUN_00a70d30();
  if ((ulonglong)(longlong)DAT_01d66a04 < uVar13) {
    FUN_00550130("Extents are too large");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&fStack_70,&DAT_01c17198);
  }
  iStack_44 = iStack_34 - iStack_40;
  iVar8 = iStack_2c - iStack_38;
  iVar6 = iStack_30 - iStack_3c;
  iStack_64 = iVar8;
  iStack_58 = iVar6;
  FUN_00a71760(aiStack_88,&iStack_40,0,1);
  uStack_8 = 0;
  uStack_18 = 0;
  do {
    if ((&DAT_0194cd50)[uStack_18] == param_5) {
      if (((char)uStack_18 == '\0') && (iStack_78 == 0)) {
        iVar8 = FUN_00612e90();
        ExceptionList = pvStack_10;
        return iVar8;
      }
      goto LAB_00afa00b;
    }
    uStack_18 = uStack_18 + 1;
  } while (uStack_18 < 0x17);
  uStack_18 = CONCAT31((int3)(uStack_18 >> 8),2);
LAB_00afa00b:
  uStack_60 = 0x40;
  if (param_6 != '\0') {
    uStack_60 = 1;
  }
  param_1 = param_1 * DAT_018e1340;
  param_2 = param_2 * DAT_018e1340;
  iStack_28 = 0;
  param_3 = param_3 * DAT_018e1340;
  param_4 = param_4 * DAT_018e1340;
  iVar7 = iStack_58;
  fVar12 = DAT_018ce2f4;
  fStack_54 = param_3;
  fStack_50 = param_2;
  fStack_4c = param_1;
  if (0 < iVar6) {
    do {
      iStack_48 = 0;
      if (0 < iVar8) {
        do {
          iVar6 = iStack_28;
          iVar8 = iStack_48;
          fStack_1c = ((float)iStack_40 + fVar12) - param_1;
          fStack_20 = ((float)(iStack_3c + iStack_28) + fVar12) - param_2;
          fStack_24 = ((float)(iStack_38 + iStack_48) + fVar12) - param_3;
          if (iStack_78 == 0) {
            FUN_00a6e270();
            fVar12 = DAT_018ce2f4;
          }
          iVar7 = 0;
          iVar6 = iStack_78 + (aiStack_88[0] * iVar8 + iStack_7c * iVar6) * 2;
          if (0 < iStack_44) {
            fStack_20 = fStack_20 * fStack_20;
            fStack_24 = fStack_24 * fStack_24;
            do {
              dVar10 = (double)(fStack_1c * fStack_1c + fStack_20 + fStack_24);
              FUN_017267a0();
              fVar3 = DAT_018ce2f8;
              fVar12 = DAT_018ce2f4;
              bVar2 = *(byte *)(iVar6 + iVar7 * 2);
              fVar11 = (param_4 - (float)dVar10) + DAT_018ce2f4;
              fVar9 = 0.0;
              if (0.0 <= fVar11) {
                fVar9 = fVar11;
              }
              fVar11 = DAT_018ce2f8;
              if (fVar9 <= DAT_018ce2f8) {
                fVar11 = fVar9;
              }
              iVar8 = (int)(fVar11 * DAT_018f9000 + DAT_018ce2f4);
              if (bVar2 != (byte)uStack_60) {
                uVar5 = (uint)*(byte *)(iVar6 + 1 + iVar7 * 2);
                if ((char)uStack_18 == '\0') {
                  if (iVar8 < (int)uVar5) {
                    if ((int)uVar5 <= 0xff - iVar8) goto LAB_00afa21f;
                    uVar4 = CONCAT11((byte)((int)-(uint)bVar2 >> 0x1f) & (byte)(0xff - iVar8),bVar2)
                    ;
                  }
                  else {
                    uVar4 = 0;
                  }
                }
                else {
                  if ((iVar8 < (int)uVar5) || (iVar8 == 0)) goto LAB_00afa21f;
                  uStack_12 = CONCAT11((byte)((int)-(uStack_18 & 0xff) >> 0x1f) & (byte)iVar8,
                                       (char)uStack_18);
                  uVar4 = uStack_12;
                }
                *(undefined2 *)(iVar6 + iVar7 * 2) = uVar4;
              }
LAB_00afa21f:
              iVar7 = iVar7 + 1;
              fStack_1c = fStack_1c + fVar3;
              iVar8 = iStack_48;
            } while (iVar7 < iStack_44);
          }
          iStack_48 = iVar8 + 1;
          iVar7 = iStack_58;
          iVar8 = iStack_64;
          param_1 = fStack_4c;
          param_3 = fStack_54;
          param_2 = fStack_50;
        } while (iStack_48 < iStack_64);
      }
      iStack_28 = iStack_28 + 1;
    } while (iStack_28 < iVar7);
  }
  iVar8 = FUN_00a72960(&iStack_40,aiStack_88,0);
  if (piStack_74 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_74 + 1;
    iVar6 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar8 = (**(code **)*piStack_74)();
      LOCK();
      piVar1 = piStack_74 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar8 = (**(code **)(*piStack_74 + 4))();
        ExceptionList = pvStack_10;
        return iVar8;
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 22872 ; VA 0x00afafd0 ; FUN_00afafd0 */

/* WARNING: Removing unreachable block (ram,0x00afb027) */

int FUN_00afafd0(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  ulonglong uVar8;
  undefined2 uStack00000040;
  undefined2 uStack00000042;
  int in_stack_00000044;
  int aiStack_5c [3];
  int iStack_50;
  int iStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined auStack_2c [16];
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecd18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a70760(&iStack_44,&stack0x00000004,_uStack00000040);
  uVar8 = FUN_00a70d30();
  if ((ulonglong)(longlong)DAT_01d66a04 < uVar8) {
    FUN_00550130("Region is too large");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  iVar6 = iStack_30 - iStack_3c;
  iVar5 = iStack_34 - iStack_40;
  uStack_18 = iStack_38 - iStack_44;
  iStack_1c = iVar6;
  iStack_14 = iVar5;
  FUN_00a6dbd0(uStack_18,iVar5,iVar6);
  uVar2 = 0;
  uStack_8 = 0;
  do {
    if ((&DAT_0194cd50)[uVar2] == in_stack_00000044) {
      if ((char)uVar2 != '\0') goto LAB_00afb078;
      goto LAB_00afb0e8;
    }
    uVar2 = uVar2 + 1;
  } while (uVar2 < 0x17);
  uVar2 = 2;
LAB_00afb078:
  iVar4 = 0;
  uStack00000040 = CONCAT11((char)((int)-(uVar2 & 0xff) >> 0x1f),(char)uVar2);
  iVar3 = iStack_14;
  if (0 < iVar5) {
    do {
      iVar5 = 0;
      if (0 < iVar6) {
        do {
          if (iStack_4c == 0) {
            FUN_00a6e270();
          }
          if (0 < (int)uStack_18) {
            puVar7 = (uint *)(iStack_4c + (aiStack_5c[0] * iVar5 + iStack_50 * iVar4) * 2);
            for (uVar2 = uStack_18 >> 1; uVar2 != 0; uVar2 = uVar2 - 1) {
              *puVar7 = _uStack00000040 & 0xffff | (_uStack00000040 & 0xffff) << 0x10;
              puVar7 = puVar7 + 1;
            }
            for (uVar2 = (uint)((uStack_18 & 1) != 0); uVar2 != 0; uVar2 = uVar2 - 1) {
              *(short *)puVar7 = (short)_uStack00000040;
              puVar7 = (uint *)((int)puVar7 + 2);
            }
          }
          iVar5 = iVar5 + 1;
          iVar3 = iStack_14;
          iVar6 = iStack_1c;
        } while (iVar5 < iStack_1c);
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < iVar3);
  }
LAB_00afb0e8:
  iVar6 = FUN_00a72960(&iStack_44,aiStack_5c,0);
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_48 + 1;
    iVar5 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar6 = (**(code **)*piStack_48)();
      LOCK();
      piVar1 = piStack_48 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar6 = (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 22873 ; VA 0x00afb960 ; FUN_00afb960 */

void FUN_00afb960(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088c960();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0091b810(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22874 ; VA 0x00afb9c0 ; FUN_00afb9c0 */

undefined8 *
FUN_00afb9c0(undefined8 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,
            undefined4 *param_6)

{
  undefined4 uVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    puVar3 = (undefined8 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede6f8);
    if (puVar3 != (undefined8 *)0x0) {
      uVar1 = *(undefined4 *)(puVar3 + 1);
      *param_1 = *puVar3;
      *(undefined4 *)(param_1 + 1) = uVar1;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar2 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
      if (cVar2 != '\0') {
        puVar3 = (undefined8 *)FUN_0088b220();
        uVar1 = *(undefined4 *)(puVar3 + 1);
        *param_1 = *puVar3;
        *(undefined4 *)(param_1 + 1) = uVar1;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar3 = (undefined8 *)*param_6;
  if (puVar3 != (undefined8 *)0x0) {
    uVar1 = *(undefined4 *)(puVar3 + 1);
    *param_1 = *puVar3;
    *(undefined4 *)(param_1 + 1) = uVar1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 22875 ; VA 0x00afbb30 ; FUN_00afbb30 */

int FUN_00afbb30(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_00896e70();
    cVar2 = FUN_009d1e20(uVar3,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00b000c0();
      iVar1 = *piVar4;
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 22876 ; VA 0x00afbc80 ; FUN_00afbc80 */

void __thiscall FUN_00afbc80(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uStack_8;
  
  uStack_8 = *(undefined4 *)(param_1 + 0x14);
  puVar1 = *(undefined4 **)(param_2 + 4);
  if (*(undefined4 **)(param_2 + 8) != puVar1) {
    *puVar1 = uStack_8;
    *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
    return;
  }
  FUN_006030d0(puVar1,&uStack_8);
  return;
}



/* FUNCTION 22877 ; VA 0x00afbcc0 ; FUN_00afbcc0 */

void FUN_00afbcc0(int *param_1,undefined4 *param_2,uint param_3,int param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  byte bVar8;
  undefined4 *puVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecd67;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a70be0(&param_3,param_2,param_3,param_4,1);
  puVar6 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 0;
  param_2 = puVar6;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 1;
    puVar6[2] = 1;
    *puVar6 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(3,(int)&param_4 + 3);
  }
  piVar1 = puVar6 + 3;
  uStack_8 = 1;
  bVar5 = (byte)param_3;
  if (bVar5 == 1) {
    puVar2 = (undefined4 *)*piVar1;
    uVar7 = FUN_00afe430();
    *puVar2 = uVar7;
    param_4 = FUN_00afe760();
    iVar3 = puVar2[1];
    if (iVar3 == param_4) {
      puVar2[2] = 0x11;
    }
    else {
      if (iVar3 != 0) {
        (**(code **)(iVar3 + 8))(puVar2 + 2);
        puVar2[1] = 0;
      }
      puVar2[2] = 0x11;
      puVar2[1] = param_4;
    }
    iVar3 = *piVar1;
    uVar7 = FUN_00afe380();
    *(undefined4 *)(iVar3 + 0xd0) = uVar7;
    param_4 = FUN_00afe6f0();
    iVar4 = *(int *)(iVar3 + 0xd4);
    if (iVar4 == param_4) {
      *(undefined4 *)(iVar3 + 0xd8) = 0;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(iVar3 + 0xd8);
      }
      *(undefined4 *)(iVar3 + 0xd8) = 0;
      *(int *)(iVar3 + 0xd4) = param_4;
    }
    iVar3 = *piVar1;
    uVar7 = FUN_00afe4e0();
    *(undefined4 *)(iVar3 + 0x1a0) = uVar7;
    param_4 = FUN_00afe7d0();
    iVar4 = *(int *)(iVar3 + 0x1a4);
    if (iVar4 == param_4) {
      *(undefined4 *)(iVar3 + 0x1a8) = 0;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(iVar3 + 0x1a8);
      }
      *(undefined4 *)(iVar3 + 0x1a8) = 0;
      *(int *)(iVar3 + 0x1a4) = param_4;
    }
    goto LAB_00afbfc6;
  }
  if ((bVar5 == 0) || (bVar8 = (byte)(param_3 >> 8), bVar8 < 0x2b)) {
    puVar2 = (undefined4 *)*piVar1;
    uVar7 = FUN_00afe430();
    *puVar2 = uVar7;
    param_4 = FUN_00afe760();
    iVar3 = puVar2[1];
    if (iVar3 == param_4) {
      puVar2[2] = 0;
    }
    else {
      if (iVar3 != 0) {
        (**(code **)(iVar3 + 8))(puVar2 + 2);
        puVar2[1] = 0;
      }
      puVar2[2] = 0;
      puVar2[1] = param_4;
    }
    FUN_00aefd60(&DAT_0194ce80);
  }
  else {
    if (bVar8 < 0x55) {
      param_2 = (undefined4 *)0x2;
    }
    else if (bVar8 < 0x80) {
      param_2 = (undefined4 *)0x1;
    }
    else {
      param_2 = (undefined4 *)(-(uint)(bVar8 < 0xd5) & 3);
    }
    if (bVar5 < 0x17) {
      iVar3 = (&DAT_0194cd50)[param_3 & 0xff];
      if (iVar3 < 0x501) {
        if (iVar3 == 0x500) goto LAB_00afbf38;
        if (iVar3 < 0x345) {
          if (iVar3 == 0x344) {
            param_4 = 0xd;
          }
          else if (iVar3 == 0x210) {
            param_4 = 9;
          }
          else if (iVar3 == 800) {
            param_4 = 4;
          }
          else {
            if (iVar3 != 0x330) goto LAB_00afbf38;
            param_4 = 0xe;
          }
        }
        else if (iVar3 == 0x350) {
          param_4 = 3;
        }
        else {
          if (iVar3 != 0x390) goto LAB_00afbf38;
          param_4 = 0xf;
        }
      }
      else if (iVar3 < 0x601) {
        if (iVar3 == 0x600) {
          param_4 = 0x10;
        }
        else if (iVar3 == 0x510) {
          param_4 = 2;
        }
        else {
          if (iVar3 != 0x560) goto LAB_00afbf38;
          param_4 = 5;
        }
      }
      else if (iVar3 == 0x700) {
        param_4 = 0;
      }
      else {
        if (iVar3 != 0x800) goto LAB_00afbf38;
        param_4 = 0x11;
      }
    }
    else {
LAB_00afbf38:
      param_4 = 1;
    }
    FUN_00aefe70(&param_4);
    FUN_00aefd60(&param_2);
  }
  FUN_00aefdc0(&DAT_0194ce84);
LAB_00afbfc6:
  param_1[1] = (int)puVar6;
  *param_1 = (int)piVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22878 ; VA 0x00afbff0 ; FUN_00afbff0 */

void FUN_00afbff0(void)

{
  int iVar1;
  
  if (DAT_01eec9d4 == 0) {
    iVar1 = FUN_00af0010();
    DAT_01eec9d4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22879 ; VA 0x00afc007 ; FUN_00afc007 */

void FUN_00afc007(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 22880 ; VA 0x00afc00f ; FUN_00afc00f */

void FUN_00afc00f(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 22881 ; VA 0x00afc020 ; FUN_00afc020 */

undefined4 * FUN_00afc020(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_00b077e0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return param_1;
}



/* FUNCTION 22882 ; VA 0x00afc050 ; FUN_00afc050 */

undefined4 __thiscall FUN_00afc050(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  char *pcVar2;
  undefined auStack_10 [12];
  
  if ((param_3 == 0x700) || (param_3 == 0x800)) {
    pcVar2 = "Unsupported terrain material";
  }
  else {
    uVar1 = 0;
    do {
      if ((&DAT_0194cd50)[uVar1] == param_3) {
        if ((char)uVar1 == '\x02') goto LAB_00afc087;
        goto LAB_00afc08f;
      }
      uVar1 = uVar1 + 1;
    } while (uVar1 < 0x17);
    uVar1 = 2;
LAB_00afc087:
    if (param_3 == 0x500) {
LAB_00afc08f:
      FUN_0115e8a0((uVar1 & 0xff) * 3 + *(int *)(param_1 + 0x160));
      return param_2;
    }
    pcVar2 = "Invalid terrain material";
  }
  FUN_00550130(pcVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22883 ; VA 0x00afc0d0 ; FUN_00afc0d0 */

undefined4 * __thiscall FUN_00afc0d0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0058a190(0x45);
  uVar2 = 0;
  do {
    FUN_005558a0(*(undefined *)(uVar2 + *(int *)(param_1 + 0x160)));
    FUN_005558a0(*(undefined *)(uVar2 + 1 + *(int *)(param_1 + 0x160)));
    FUN_005558a0(*(undefined *)(uVar2 + 2 + *(int *)(param_1 + 0x160)));
    uVar2 = uVar2 + 3;
  } while (uVar2 < 0x45);
  FUN_0054ef60(auStack_28);
  param_2[4] = 0;
  param_2[5] = 0;
  *param_2 = uStack_40;
  param_2[1] = uStack_3c;
  param_2[2] = uStack_38;
  param_2[3] = uStack_34;
  *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_2c,uStack_30);
  if (0xf < uStack_14) {
    uVar1 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar1) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar1 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar1);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22884 ; VA 0x00afc1f0 ; FUN_00afc1f0 */

undefined4 FUN_00afc1f0(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    return 0x700;
  default:
    return 0x500;
  case 2:
    return 0x510;
  case 3:
    return 0x350;
  case 4:
    return 800;
  case 5:
  case 0xb:
    return 0x560;
  case 6:
  case 7:
  case 8:
  case 0xc:
  case 0xe:
    return 0x330;
  case 9:
  case 10:
    return 0x210;
  case 0xd:
    return 0x344;
  case 0xf:
    return 0x390;
  case 0x10:
    return 0x600;
  case 0x11:
    return 0x800;
  }
}



/* FUNCTION 22885 ; VA 0x00afc2e0 ; FUN_00afc2e0 */

float10 FUN_00afc2e0(void)

{
  return (float10)DAT_018daf54;
}



/* FUNCTION 22886 ; VA 0x00afc2f0 ; FUN_00afc2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afc2f0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec7a8) {
    FUN_016f3809(&DAT_01eec7a8);
    if (DAT_01eec7a8 == -1) {
      _DAT_01eec79c = 0x3f800000;
      _DAT_01eec7a0 = 0x3f800000;
      _DAT_01eec7a4 = 0x3f800000;
      FUN_016f37bf(&DAT_01eec7a8);
    }
  }
  return &DAT_01eec79c;
}



/* FUNCTION 22887 ; VA 0x00afc360 ; FUN_00afc360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afc360(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec7b8) {
    FUN_016f3809(&DAT_01eec7b8);
    if (DAT_01eec7b8 == -1) {
      _DAT_01eec7ac = (float)DAT_01d66b94 / DAT_018ce324;
      _DAT_01eec7b0 = _DAT_01eec7ac;
      _DAT_01eec7b4 = _DAT_01eec7ac;
      FUN_016f37bf(&DAT_01eec7b8);
    }
  }
  return &DAT_01eec7ac;
}



/* FUNCTION 22888 ; VA 0x00afc3e0 ; FUN_00afc3e0 */

undefined * FUN_00afc3e0(undefined *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ecd99;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  FUN_00feff20(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22889 ; VA 0x00afc450 ; FUN_00afc450 */

undefined4 * FUN_00afc450(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a72130(auStack_28);
  FUN_0054ef60(auStack_28);
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = uStack_40;
  param_1[1] = uStack_3c;
  param_1[2] = uStack_38;
  param_1[3] = uStack_34;
  *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_2c,uStack_30);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22890 ; VA 0x00afc520 ; FUN_00afc520 */

int FUN_00afc520(void)

{
  int iVar1;
  
  iVar1 = FUN_008a2610();
  return iVar1 + 0x10;
}



/* FUNCTION 22891 ; VA 0x00afc530 ; FUN_00afc530 */

undefined4 * FUN_00afc530(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_00b077e0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return param_1;
}



/* FUNCTION 22892 ; VA 0x00afc560 ; FUN_00afc560 */

undefined4 FUN_00afc560(undefined4 param_1)

{
  FUN_0054d840(0);
  return param_1;
}



/* FUNCTION 22893 ; VA 0x00afc580 ; FUN_00afc580 */

undefined4 FUN_00afc580(undefined4 param_1)

{
  FUN_0054d840(0x3f);
  return param_1;
}



/* FUNCTION 22894 ; VA 0x00afc5a0 ; FUN_00afc5a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall
FUN_00afc5a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (param_1 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = *(int *)(param_1 + 0xa8);
  }
  uStack_40 = _DAT_018e3fb0;
  uStack_3c = _UNK_018e3fb4;
  uStack_38 = _UNK_018e3fb8;
  uStack_34 = _UNK_018e3fbc;
  uStack_30 = _DAT_018e3fb0;
  uStack_2c = _UNK_018e3fb4;
  uStack_28 = _UNK_018e3fb8;
  uStack_24 = _UNK_018e3fbc;
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  uStack_20 = _DAT_018e3fb0;
  uStack_1c = _UNK_018e3fb4;
  uStack_18 = _UNK_018e3fb8;
  uStack_14 = _UNK_018e3fbc;
  cVar1 = (**(code **)(**(int **)(iVar2 + 0x1ac) + 0x74))(param_3,&uStack_10,param_4,&uStack_40,1);
  if (cVar1 != '\0') {
    FUN_0054fe00(param_1,*param_4);
    return param_2;
  }
  FUN_005502b0();
  return param_2;
}



/* FUNCTION 22895 ; VA 0x00afc640 ; FUN_00afc640 */

void FUN_00afc640(void)

{
  undefined auStack_10 [12];
  
  FUN_016756b0(auStack_10,"GetTouchingParts is not a valid member of Terrain");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22896 ; VA 0x00afc670 ; FUN_00afc670 */

undefined8 * __thiscall FUN_00afc670(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))(auStack_10);
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 22897 ; VA 0x00afc6c0 ; FUN_00afc6c0 */

void __thiscall FUN_00afc6c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_2);
  uVar3 = FUN_00b33940();
  *param_3 = uVar3;
  iVar4 = FUN_006312a0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    *(undefined8 *)(param_3 + 2) = *puVar2;
    param_3[4] = *(undefined4 *)(puVar2 + 1);
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  *(undefined8 *)(param_3 + 2) = *puVar2;
  param_3[4] = *(undefined4 *)(puVar2 + 1);
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 22898 ; VA 0x00afc740 ; FUN_00afc740 */

void FUN_00afc740(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecd67;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a70be0(&param_3,param_2,param_3,param_4,1);
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 0;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(3,(int)&param_4 + 3);
  }
  piVar1 = puVar4 + 3;
  puVar2 = (undefined4 *)*piVar1;
  uStack_8 = 1;
  param_4._3_1_ = (char)param_3 == '\x01';
  uVar5 = FUN_0088daf0();
  *puVar2 = uVar5;
  iVar6 = FUN_005c9ef0();
  iVar3 = puVar2[1];
  if (iVar3 == iVar6) {
    *(undefined *)(puVar2 + 2) = param_4._3_1_;
  }
  else {
    if (iVar3 != 0) {
      (**(code **)(iVar3 + 8))(puVar2 + 2);
      puVar2[1] = 0;
    }
    *(undefined *)(puVar2 + 2) = param_4._3_1_;
    puVar2[1] = iVar6;
  }
  iVar3 = *piVar1;
  uVar5 = FUN_00afe640();
  *(undefined4 *)(iVar3 + 0xd0) = uVar5;
  param_4 = FUN_00afe8b0();
  iVar6 = *(int *)(iVar3 + 0xd4);
  if (iVar6 == param_4) {
    *(undefined4 *)(iVar3 + 0xd8) = 0;
  }
  else {
    if (iVar6 != 0) {
      (**(code **)(iVar6 + 8))(iVar3 + 0xd8);
    }
    *(undefined4 *)(iVar3 + 0xd8) = 0;
    *(int *)(iVar3 + 0xd4) = param_4;
  }
  iVar3 = *piVar1;
  uVar5 = FUN_00afe590();
  *(undefined4 *)(iVar3 + 0x1a0) = uVar5;
  param_4 = FUN_00afe840();
  iVar6 = *(int *)(iVar3 + 0x1a4);
  if (iVar6 == param_4) {
    *(undefined4 *)(iVar3 + 0x1a8) = 0;
  }
  else {
    if (iVar6 != 0) {
      (**(code **)(iVar6 + 8))(iVar3 + 0x1a8);
    }
    *(undefined4 *)(iVar3 + 0x1a8) = 0;
    *(int *)(iVar3 + 0x1a4) = param_4;
  }
  param_1[1] = (int)puVar4;
  *param_1 = (int)piVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22899 ; VA 0x00afc8c0 ; FUN_00afc8c0 */

undefined4 __fastcall FUN_00afc8c0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x134) >> 8),
                  *(int *)(*(int *)(param_1 + 0x134) + 8) != 0);
}



/* FUNCTION 22900 ; VA 0x00afc8d0 ; FUN_00afc8d0 */

uint __fastcall FUN_00afc8d0(int param_1)

{
  uint uVar1;
  undefined2 *puVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  uint uVar6;
  char cStack_8;
  char cStack_7;
  
  uVar6 = 0;
  iVar3 = *(int *)(param_1 + 0x160);
  iVar4 = *(int *)(param_1 + 0x164) - iVar3;
  puVar2 = (undefined2 *)(iVar4 * 0x55555556);
  uVar1 = iVar4 / 3;
  if (uVar1 != 0) {
    pcVar5 = (char *)(iVar3 + 2);
    puVar2 = *(undefined2 **)(param_1 + 0x16c);
    iVar3 = iVar3 - (int)puVar2;
    do {
      cStack_8 = (char)*puVar2;
      if (((cStack_8 != *(char *)(iVar3 + (int)puVar2)) ||
          (cStack_7 = (char)((ushort)*puVar2 >> 8), cStack_7 != pcVar5[-1])) ||
         (*(char *)(puVar2 + 1) != *pcVar5)) {
        return CONCAT31((int3)((uint)puVar2 >> 8),1);
      }
      uVar6 = uVar6 + 1;
      pcVar5 = pcVar5 + 3;
      puVar2 = (undefined2 *)((int)puVar2 + 3);
    } while (uVar6 < uVar1);
  }
  return (uint)puVar2 & 0xffffff00;
}



/* FUNCTION 22901 ; VA 0x00afc950 ; FUN_00afc950 */

undefined4 FUN_00afc950(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  
  iVar1 = FUN_012578b0(param_1,param_2);
  if (iVar1 == 6) {
    iVar1 = FUN_012566d0(param_1,param_2);
    if (iVar1 == param_3) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 22902 ; VA 0x00afc990 ; FUN_00afc990 */

undefined4 FUN_00afc990(float *param_1,undefined4 param_2,float *param_3)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  float10 fVar4;
  float10 fVar5;
  float fVar6;
  float fVar7;
  ushort auStack_c [2];
  ushort auStack_8 [2];
  
  fVar4 = (float10)FUN_01725280((double)*param_1);
  fVar5 = (float10)FUN_01725280((double)param_1[1]);
  iVar1 = (int)fVar5;
  fVar5 = (float10)FUN_01725280((double)param_1[2]);
  FUN_00a70be0(auStack_c,(int)fVar4,iVar1,(int)fVar5,1);
  FUN_00a70be0(auStack_8,(int)fVar4,iVar1 + 1,(int)fVar5,1);
  if ((char)auStack_c[0] == '\x01') {
    if ((char)auStack_8[0] != '\0') {
      *param_3 = (float)(iVar1 * 4 + 4);
      return 1;
    }
    fVar6 = (float)(ushort)((auStack_c[0] >> 8) + 1) * DAT_018fabc4 - DAT_018ce2f4;
    if (fVar6 <= 0.0) {
      fVar6 = 0.0;
    }
    fVar6 = (float)iVar1 + DAT_018ce2f4 + fVar6;
    *param_3 = fVar6 * DAT_018e3f8c;
    bVar3 = fVar6 == param_1[1];
    bVar2 = fVar6 < param_1[1];
  }
  else {
    if ((char)auStack_8[0] != '\x01') {
      return 0;
    }
    if ((char)auStack_c[0] != '\0') {
      *param_3 = (float)(iVar1 * 4 + 8);
      return 1;
    }
    fVar7 = (float)(ushort)((auStack_8[0] >> 8) + 1) * DAT_018fabc4;
    fVar6 = DAT_018ce2f4;
    if (fVar7 <= DAT_018ce2f4) {
      fVar6 = fVar7;
    }
    fVar6 = (float)(iVar1 + 1) - fVar6;
    *param_3 = fVar6 * DAT_018e3f8c;
    bVar3 = param_1[1] == fVar6;
    bVar2 = param_1[1] < fVar6;
  }
  if (!bVar2 && !bVar3) {
    return 1;
  }
  return 0;
}



/* FUNCTION 22903 ; VA 0x00afcb50 ; FUN_00afcb50 */

undefined4 FUN_00afcb50(undefined4 *param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_00aff8c0();
  cVar1 = FUN_00892700(uVar2);
  if (((cVar1 != '\0') && (param_1 != &DAT_01eed290)) && (param_1 != (undefined4 *)&DAT_01eedb38)) {
    return 1;
  }
  uVar2 = FUN_00b09610(param_1);
  return uVar2;
}



/* FUNCTION 22904 ; VA 0x00afcba0 ; FUN_00afcba0 */

uint FUN_00afcba0(void)

{
  int iVar1;
  
  iVar1 = FUN_00af0010();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 22905 ; VA 0x00afcbc0 ; FUN_00afcbc0 */

uint FUN_00afcbc0(void)

{
  int iVar1;
  
  iVar1 = FUN_00af0010();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 22906 ; VA 0x00afcbe0 ; FUN_00afcbe0 */

void FUN_00afcbe0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe380();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22907 ; VA 0x00afcc20 ; FUN_00afcc20 */

void FUN_00afcc20(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe430();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22908 ; VA 0x00afcc60 ; FUN_00afcc60 */

void FUN_00afcc60(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe4e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22909 ; VA 0x00afcca0 ; FUN_00afcca0 */

void FUN_00afcca0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe590();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22910 ; VA 0x00afcce0 ; FUN_00afcce0 */

void FUN_00afcce0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00afe640();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22911 ; VA 0x00afcd20 ; FUN_00afcd20 */

void FUN_00afcd20(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("Cannot Clone() Terrain");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22912 ; VA 0x00afcd50 ; FUN_00afcd50 */

void __thiscall FUN_00afcd50(int param_1,int param_2)

{
  int iVar1;
  char *pcVar2;
  
  FUN_00b09c70(param_2);
  if (DAT_01d6517b != '\0') {
    FUN_016774b0(DAT_01d6517b,"Ancestor change, new parent: %p",*(undefined4 *)(param_2 + 8));
  }
  if (*(int *)(param_2 + 8) == 0) {
    return;
  }
  FUN_005c3ac0(*(int *)(param_2 + 8));
  iVar1 = FUN_00a9d3e0();
  if (iVar1 == 0) {
    if (DAT_01d6517b == '\0') goto LAB_00afcdd6;
    pcVar2 = "No terrain yet - it\'s going go be me!";
  }
  else {
    iVar1 = FUN_00a9d3e0();
    if (iVar1 == param_1) {
      return;
    }
    if (DAT_01d6517b == '\0') goto LAB_00afcdd6;
    pcVar2 = "Terrain already exists - replace the existing one with this one";
  }
  FUN_016774b0(DAT_01d6517b,pcVar2,0);
LAB_00afcdd6:
  FUN_008bb6e0(param_1);
  return;
}



/* FUNCTION 22913 ; VA 0x00afcdf0 ; FUN_00afcdf0 */

void __thiscall FUN_00afcdf0(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  FUN_00b0a250(param_2,param_3);
  if (DAT_01d6517b != '\0') {
    FUN_01677490(DAT_01d6517b,"onServiceProvider, oldProvider: %p, new parent: %p",param_2,param_3,0
                );
  }
  if ((param_3 == 0) && (param_2 != 0)) {
    FUN_005c3ac0(param_2);
    iVar1 = FUN_00a9d3e0();
    if (iVar1 == param_1) {
      if (DAT_01d6517b != '\0') {
        FUN_016774b0(DAT_01d6517b,"onServiceProvider: Clearing terrain instance",0);
      }
      FUN_008bb6e0(0);
    }
  }
  return;
}



/* FUNCTION 22914 ; VA 0x00afce70 ; FUN_00afce70 */

void __thiscall FUN_00afce70(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  
  if (param_3 == 0) {
    iVar1 = FUN_008f7870(param_1 + -0xf8);
    if (iVar1 != 0) {
      (*(code *)**(undefined4 **)(iVar1 + 4))(1);
    }
  }
  return;
}



/* FUNCTION 22915 ; VA 0x00afcea0 ; FUN_00afcea0 */

int __thiscall
FUN_00afcea0(int param_1,int param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar3 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00b629b0();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar3 = FUN_00b63110(*(undefined4 *)(param_1 + 0x134),&param_4,param_6);
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar1 = param_3 + 1;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar3 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar3;
    }
  }
  FUN_00550130("region has to be a TerrainRegion");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 22916 ; VA 0x00afcf60 ; FUN_00afcf60 */

/* WARNING: Removing unreachable block (ram,0x00afd33f) */
/* WARNING: Removing unreachable block (ram,0x00afd04c) */

undefined4 FUN_00afcf60(int param_1)

{
  int *piVar1;
  double dVar2;
  undefined4 uVar3;
  uint uVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  ulonglong uVar9;
  undefined auStack_d0 [60];
  undefined auStack_94 [24];
  byte abStack_7c [40];
  uint uStack_54;
  double dStack_50;
  undefined4 uStack_48;
  byte *pbStack_44;
  int iStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  float fStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecdc3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888530();
  uStack_8 = 0;
  FUN_00a73410();
  cVar5 = FUN_009d29b0(1,auStack_d0);
  if ((cVar5 != '\0') && (cVar5 = FUN_009d1d10(2,&dStack_50), cVar5 != '\0')) {
    FUN_00a70760(auStack_94,auStack_d0,(float)dStack_50);
    uVar9 = FUN_00a70d30();
    if (uVar9 <= (ulonglong)(longlong)DAT_01d669fc) {
      FUN_00a71760(&iStack_38,auStack_94,0,1);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_48 = FUN_00896e70();
      uStack_3c = 0;
      uStack_54 = 0;
      abStack_7c[0] = 0x40;
      abStack_7c[1] = 0x40;
      abStack_7c[2] = 0x40;
      abStack_7c[3] = 0x40;
      abStack_7c[4] = 0x40;
      abStack_7c[5] = 0x40;
      abStack_7c[6] = 0x40;
      abStack_7c[7] = 0x40;
      FUN_01255e10(param_1,0x1c);
      iStack_40 = FUN_01256300(param_1);
      iVar7 = 8;
      do {
        FUN_01256980();
        iVar7 = iVar7 + -1;
      } while (iVar7 != 0);
      FUN_01255f00(param_1,iStack_38,0);
      FUN_01255f00(param_1,iStack_38,0);
      iVar7 = 0;
      iStack_20 = 0;
      if (0 < iStack_38) {
        uStack_18 = 0.0;
        do {
          FUN_01255f00(uVar3,iStack_34,0);
          FUN_01255f00(uVar3,iStack_34,0);
          param_1 = 0;
          if (0 < iStack_34) {
            do {
              FUN_01255f00(uVar3,iStack_30,0);
              FUN_01255f00(uVar3,iStack_30,0);
              iVar7 = 0;
              if (0 < iStack_30) {
                do {
                  uVar4 = uStack_3c;
                  if (iStack_28 == 0) {
                    pbStack_44 = &DAT_01eea940;
                  }
                  else {
                    pbStack_44 = (byte *)((iStack_38 * iVar7 + iStack_2c * param_1 + iStack_20) * 2
                                         + iStack_28);
                  }
                  uVar8 = 0;
                  do {
                    if (abStack_7c[uVar8] == *pbStack_44) goto LAB_00afd1c9;
                    uVar8 = uVar8 + 1;
                  } while (uVar8 < 8);
                  abStack_7c[uStack_3c] = *pbStack_44;
                  uStack_54 = uStack_54 + 1 & 7;
                  uStack_3c = uStack_54;
                  uVar6 = FUN_009cb050();
                  FUN_00880a00(uVar3,uVar6);
                  FUN_01256eb0(uVar3,iStack_40 + uVar4);
                  uVar8 = uVar4;
LAB_00afd1c9:
                  FUN_01256aa0(uVar3,iStack_40 + uVar8);
                  dVar2 = uStack_18;
                  if (*pbStack_44 != 0) {
                    dVar2 = (double)((float)(pbStack_44[1] + 1) * DAT_018fabc4);
                  }
                  FUN_012569a0(uVar3,dVar2);
                  iVar7 = iVar7 + 1;
                  FUN_01256da0(uVar3);
                  FUN_01256da0(uVar3,0xfffffffd,iVar7);
                } while (iVar7 < iStack_30);
              }
              param_1 = param_1 + 1;
              FUN_01256da0(uVar3);
              FUN_01256da0(uVar3,0xfffffffd,param_1);
              iVar7 = iStack_20;
            } while (param_1 < iStack_34);
          }
          iVar7 = iVar7 + 1;
          iStack_20 = iVar7;
          FUN_01256da0(uVar3);
          FUN_01256da0(uVar3,0xfffffffd,iVar7);
        } while (iVar7 < iStack_38);
      }
      FUN_012569c0(uVar3,&DAT_018dbc90);
      fStack_1c = (float)iStack_38;
      uStack_18 = (double)CONCAT44((float)iStack_30,(float)iStack_34);
      FUN_00d987b0(uVar3,&fStack_1c);
      FUN_01256d00(uVar3,0xfffffffc);
      FUN_012569c0(uVar3,&DAT_018dbc90);
      fStack_1c = (float)iStack_38;
      uStack_18 = (double)CONCAT44((float)iStack_30,(float)iStack_34);
      FUN_00d987b0(uVar3,&fStack_1c);
      FUN_01256d00(uVar3,0xfffffffd);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_24[1] + -1;
        piStack_24[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piStack_24 + 2;
          iVar7 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 2;
    }
  }
  FUN_00550130();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(&fStack_1c,&DAT_01c17198);
}



/* FUNCTION 22917 ; VA 0x00afd380 ; FUN_00afd380 */

void __fastcall FUN_00afd380(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  bool bVar5;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece00;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = FUN_01674e20(0x2c);
  uStack_8 = 0;
  bVar5 = iStack_1c == 0;
  if (bVar5) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_008cb670(&iStack_34,&DAT_01d66a44);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_18 = 1;
    uVar1 = FUN_00d58eb0(uVar1,0x40);
  }
  iVar2 = *(int *)(param_1 + 0x13c);
  *(undefined4 *)(param_1 + 0x13c) = uVar1;
  if (iVar2 != 0) {
    FUN_00d59010();
    FUN_01674ea0(iVar2,0x2c);
  }
  uStack_8 = 0xffffffff;
  if ((!bVar5) && (0xf < uStack_20)) {
    uVar3 = uStack_20 + 1;
    iVar2 = iStack_34;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_34 + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (iStack_34 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  iStack_1c = *(undefined4 *)(param_1 + 0xa8);
  uStack_18 = 0;
  FUN_0060e810(0,&uStack_18,&uStack_11);
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 3;
  FUN_00ff0540();
  uVar4 = 0;
  uVar3 = iStack_30 - iStack_34 >> 2;
  if (uVar3 != 0) {
    do {
      if (*(int *)(iStack_34 + uVar4 * 4) != 0) break;
      uVar4 = uVar4 + 1;
    } while (uVar4 < uVar3);
  }
  do {
    if (uVar4 == uVar3) {
      if (iStack_34 != 0) {
        uVar3 = iStack_2c - iStack_34 & 0xfffffffc;
        iVar2 = iStack_34;
        if (0xfff < uVar3) {
          iVar2 = *(int *)(iStack_34 + -4);
          uVar3 = uVar3 + 0x23;
          if (0x1f < (iStack_34 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar2,uVar3);
      }
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00cdfba0(*(undefined4 *)(iStack_34 + uVar4 * 4));
    do {
      uVar4 = uVar4 + 1;
      if (uVar3 <= uVar4) break;
    } while (*(int *)(iStack_34 + uVar4 * 4) == 0);
  } while( true );
}



/* FUNCTION 22918 ; VA 0x00afd530 ; FUN_00afd530 */

/* WARNING: Removing unreachable block (ram,0x00afd587) */

uint FUN_00afd530(void)

{
  uint *puVar1;
  int *piVar2;
  byte bVar3;
  uint uVar4;
  int iVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  ulonglong uVar9;
  undefined2 uStack00000040;
  undefined2 uStack00000042;
  int in_stack_00000044;
  int in_stack_00000048;
  int aiStack_5c [3];
  int iStack_50;
  int iStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined auStack_2c [16];
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecd18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a70760(&iStack_44,&stack0x00000004,_uStack00000040);
  uVar9 = FUN_00a70d30();
  if ((ulonglong)(longlong)DAT_01d66a04 < uVar9) {
    FUN_00550130("Region is too large");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  uStack_14 = 0;
  do {
    if ((&DAT_0194cd50)[uStack_14] == in_stack_00000044) goto LAB_00afd5ae;
    uStack_14 = uStack_14 + 1;
  } while (uStack_14 < 0x17);
  uStack_14 = CONCAT31((int3)(uStack_14 >> 8),2);
LAB_00afd5ae:
  uVar7 = 0;
  do {
    if ((&DAT_0194cd50)[uVar7] == in_stack_00000048) goto LAB_00afd5c4;
    uVar7 = uVar7 + 1;
  } while (uVar7 < 0x17);
  uVar7 = 2;
LAB_00afd5c4:
  cVar6 = (char)uVar7;
  uVar4 = uStack_14;
  if (cVar6 != (char)uStack_14) {
    in_stack_00000044 = iStack_30 - iStack_3c;
    iVar8 = iStack_34 - iStack_40;
    iStack_1c = iVar8;
    FUN_00a71760(aiStack_5c,&iStack_44,0,1);
    uStack_8 = 0;
    in_stack_00000048 = 0;
    iVar5 = in_stack_00000044;
    if (0 < iVar8) {
      do {
        iStack_18 = 0;
        if (0 < iVar5) {
          do {
            iVar5 = iStack_18;
            if (iStack_4c == 0) {
              FUN_00a6e270();
            }
            iVar8 = 0;
            iVar5 = iStack_4c + (aiStack_5c[0] * iVar5 + iStack_50 * in_stack_00000048) * 2;
            if (0 < iStack_38 - iStack_44) {
              do {
                if (*(char *)(iVar5 + iVar8 * 2) == (char)uStack_14) {
                  if (cVar6 == '\0') {
                    bVar3 = 0;
                  }
                  else {
                    bVar3 = *(byte *)(iVar5 + 1 + iVar8 * 2);
                  }
                  if ((char)uStack_14 == '\0') {
                    bVar3 = 0xff;
                  }
                  _uStack00000040 =
                       CONCAT13((byte)((int)-(uVar7 & 0xff) >> 0x1f) & bVar3,
                                CONCAT12(cVar6,uStack00000040));
                  *(undefined2 *)(iVar5 + iVar8 * 2) = uStack00000042;
                }
                iVar8 = iVar8 + 1;
              } while (iVar8 < iStack_38 - iStack_44);
            }
            iStack_18 = iStack_18 + 1;
            iVar5 = in_stack_00000044;
            iVar8 = iStack_1c;
          } while (iStack_18 < in_stack_00000044);
        }
        in_stack_00000048 = in_stack_00000048 + 1;
      } while (in_stack_00000048 < iVar8);
    }
    uVar4 = FUN_00a72960(&iStack_44,aiStack_5c,0);
    if (piStack_48 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piStack_48 + 1);
      uVar7 = *puVar1;
      uVar4 = *puVar1;
      *puVar1 = uVar7 - 1;
      UNLOCK();
      if (uVar7 - 1 == 0) {
        uVar4 = (**(code **)*piStack_48)();
        LOCK();
        piVar2 = piStack_48 + 2;
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uVar4 = (**(code **)(*piStack_48 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 22919 ; VA 0x00afd730 ; FUN_00afd730 */

void FUN_00afd730(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("Cannot Resize() Terrain");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22920 ; VA 0x00afd760 ; FUN_00afd760 */

void FUN_00afd760(void)

{
  FUN_00b0ca50(1);
  return;
}



/* FUNCTION 22921 ; VA 0x00afd770 ; FUN_00afd770 */

void FUN_00afd770(void)

{
  FUN_00b0d450(1);
  return;
}



/* FUNCTION 22922 ; VA 0x00afd780 ; FUN_00afd780 */

void FUN_00afd780(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_00afd7f0(CONCAT26(param_1,CONCAT24(param_3,CONCAT22(param_2,param_1))),
               CONCAT22(param_3,param_2),param_4,param_5,param_6);
  return;
}



/* FUNCTION 22923 ; VA 0x00afd7f0 ; FUN_00afd7f0 */

/* WARNING: Removing unreachable block (ram,0x00afd89a) */

void * FUN_00afd7f0(undefined4 param_1,undefined8 param_2,int param_3,int param_4)

{
  int *piVar1;
  byte bVar2;
  short sVar3;
  void *pvVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  short sVar9;
  uint uVar10;
  short sVar11;
  int iVar12;
  undefined4 *puVar13;
  ulonglong uVar14;
  int aiStack_58 [3];
  int iStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int iStack_3c;
  undefined8 uStack_34;
  int iStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c78;
  pvStack_10 = ExceptionList;
  sVar9 = (short)((ulonglong)param_2 >> 0x10);
  pvVar4 = ExceptionList;
  if ((short)param_1 <= sVar9) {
    pvVar4 = (void *)(param_2._2_4_ >> 0x10);
    sVar3 = (short)((ulonglong)param_2 >> 0x20);
    sVar11 = (short)((uint)param_1 >> 0x10);
    if ((sVar11 <= sVar3) && ((short)param_2 <= param_2._6_2_)) {
      iStack_20 = param_2._6_2_ + 1;
      iStack_3c = sVar3 + 1;
      iStack_40 = sVar9 + 1;
      uStack_28 = CONCAT44((int)sVar11,(int)(short)param_1);
      uStack_34 = uStack_28;
      iStack_2c = (int)(short)param_2;
      ExceptionList = &pvStack_10;
      uStack_28._0_4_ = iStack_40;
      uStack_28._4_4_ = iStack_3c;
      uVar14 = FUN_00a70d30();
      if ((ulonglong)(longlong)DAT_01d66a04 < uVar14) {
        FUN_00550130("Extents are too large");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(&iStack_40,&DAT_01c17198);
      }
      iStack_14 = iStack_20 - iStack_2c;
      iVar12 = uStack_28._4_4_ - uStack_34._4_4_;
      uVar10 = (int)uStack_28 - (int)uStack_34;
      iStack_18 = iVar12;
      FUN_00a6dbd0(uVar10,iVar12,iStack_14);
      uStack_8 = 0;
      if (param_3 == 0x11) {
        param_3._2_2_ = 0xff01;
      }
      else if ((param_3 == 0) || (param_4 == 5)) {
        param_3._2_2_ = 0;
      }
      else {
        switch(param_4) {
        case 0:
          param_3._3_1_ = 0xff;
          break;
        case 1:
        case 4:
          param_3._3_1_ = 0x7f;
          break;
        case 2:
          param_3._3_1_ = 0x55;
          break;
        case 3:
          param_3._3_1_ = 0xaa;
          break;
        default:
          param_3._3_1_ = 0;
        }
        switch(iVar6) {
        case 0:
          uVar5 = 0x700;
          break;
        default:
          uVar5 = 0x500;
          break;
        case 2:
          uVar5 = 0x510;
          break;
        case 3:
          uVar5 = 0x350;
          break;
        case 4:
          uVar5 = 800;
          break;
        case 5:
        case 0xb:
          uVar5 = 0x560;
          break;
        case 6:
        case 7:
        case 8:
        case 0xc:
        case 0xe:
          uVar5 = 0x330;
          break;
        case 9:
        case 10:
          uVar5 = 0x210;
          break;
        case 0xd:
          uVar5 = 0x344;
          break;
        case 0xf:
          uVar5 = 0x390;
          break;
        case 0x10:
          uVar5 = 0x600;
          break;
        case 0x11:
          uVar5 = 0x800;
        }
        bVar2 = FUN_00862c80(uVar5);
        param_3._2_2_ = CONCAT11((byte)((int)-(uint)bVar2 >> 0x1f) & param_3._3_1_,bVar2);
      }
      if (((char)param_3._2_2_ != '\0') &&
         (param_4 = 0, iVar6 = iStack_14, iVar8 = iStack_18, 0 < iVar12)) {
        do {
          iVar12 = 0;
          if (0 < iVar6) {
            do {
              if (iStack_48 == 0) {
                FUN_00a6e270();
              }
              if (0 < (int)uVar10) {
                puVar13 = (undefined4 *)
                          (iStack_48 + (aiStack_58[0] * iVar12 + iStack_4c * param_4) * 2);
                for (uVar7 = uVar10 >> 1; uVar7 != 0; uVar7 = uVar7 - 1) {
                  *puVar13 = CONCAT22(param_3._2_2_,param_3._2_2_);
                  puVar13 = puVar13 + 1;
                }
                for (uVar7 = (uint)((uVar10 & 1) != 0); uVar7 != 0; uVar7 = uVar7 - 1) {
                  *(undefined2 *)puVar13 = param_3._2_2_;
                  puVar13 = (undefined4 *)((int)puVar13 + 2);
                }
              }
              iVar12 = iVar12 + 1;
              iVar6 = iStack_14;
              iVar8 = iStack_18;
            } while (iVar12 < iStack_14);
          }
          param_4 = param_4 + 1;
        } while (param_4 < iVar8);
      }
      pvVar4 = (void *)FUN_00a72960(&uStack_34,aiStack_58,0);
      if (piStack_44 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_44 + 1;
        iVar6 = *piVar1;
        pvVar4 = (void *)*piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          pvVar4 = (void *)(**(code **)*piStack_44)();
          LOCK();
          piVar1 = piStack_44 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            pvVar4 = (void *)(**(code **)(*piStack_44 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 22924 ; VA 0x00afdaf0 ; FUN_00afdaf0 */

void FUN_00afdaf0(void)

{
  FUN_00b0d710(DAT_01d66a18);
  return;
}



/* FUNCTION 22925 ; VA 0x00afdb00 ; FUN_00afdb00 */

void __fastcall FUN_00afdb00(int param_1)

{
  FUN_00b0d750(param_1 + 0x104);
  return;
}



/* FUNCTION 22926 ; VA 0x00afdb10 ; FUN_00afdb10 */

void __fastcall FUN_00afdb10(int param_1)

{
  FUN_00b0d9c0(param_1 + 0x104);
  return;
}



/* FUNCTION 22927 ; VA 0x00afdb20 ; FUN_00afdb20 */

void __thiscall FUN_00afdb20(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x15c) != param_2) {
    *(char *)(param_1 + 0x15c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22928 ; VA 0x00afdb50 ; FUN_00afdb50 */

void FUN_00afdb50(void)

{
  FUN_00b0daf0(0x3e99999a);
  return;
}



/* FUNCTION 22929 ; VA 0x00afdb60 ; FUN_00afdb60 */

void FUN_00afdb60(void)

{
  FUN_00b0db40(0x3f000000);
  return;
}



/* FUNCTION 22930 ; VA 0x00afdb70 ; FUN_00afdb70 */

void FUN_00afdb70(void)

{
  FUN_008a6500(1);
  return;
}



/* FUNCTION 22931 ; VA 0x00afdb80 ; FUN_00afdb80 */

void FUN_00afdb80(void)

{
  FUN_00b0dbe0(&DAT_01eec790);
  return;
}



/* FUNCTION 22932 ; VA 0x00afdb90 ; FUN_00afdb90 */

void __thiscall FUN_00afdb90(int param_1,int param_2,float param_3,float param_4,float param_5)

{
  int iVar1;
  int iVar2;
  char cVar3;
  char cVar4;
  char cVar5;
  float10 fVar6;
  char *pcVar7;
  uint uStack_8;
  
  if ((param_2 == 0x700) || (param_2 == 0x800)) {
    pcVar7 = "Unsupported terrain material";
  }
  else {
    uStack_8 = 0;
    do {
      if ((&DAT_0194cd50)[uStack_8] == param_2) {
        if ((char)uStack_8 == '\x02') goto LAB_00afdbdc;
        goto LAB_00afdbe8;
      }
      uStack_8 = uStack_8 + 1;
    } while (uStack_8 < 0x17);
    uStack_8 = 2;
LAB_00afdbdc:
    if (param_2 == 0x500) {
LAB_00afdbe8:
      fVar6 = (float10)FUN_01725280((double)(param_3 * DAT_018f9980));
      cVar5 = -1;
      if ((int)fVar6 < 0x100) {
        cVar5 = (char)(int)fVar6;
      }
      fVar6 = (float10)FUN_01725280((double)(param_4 * DAT_018f9980));
      cVar4 = -1;
      if ((int)fVar6 < 0x100) {
        cVar4 = (char)(int)fVar6;
      }
      param_2._0_2_ = CONCAT11(cVar4,cVar5);
      fVar6 = (float10)FUN_01725280((double)(param_5 * DAT_018f9980));
      iVar1 = *(int *)(param_1 + 0x160);
      cVar3 = -1;
      if ((int)fVar6 < 0x100) {
        cVar3 = (char)(int)fVar6;
      }
      iVar2 = (uStack_8 & 0xff) * 3;
      if (((cVar5 != *(char *)(iVar2 + iVar1)) || (cVar4 != *(char *)(iVar2 + 1 + iVar1))) ||
         (cVar3 != *(char *)(iVar2 + 2 + iVar1))) {
        *(undefined2 *)(iVar2 + iVar1) = (undefined2)param_2;
        *(char *)(iVar2 + 2 + iVar1) = cVar3;
        FUN_008a4940(&DAT_0212a020);
      }
      return;
    }
    pcVar7 = "Invalid terrain material";
  }
  FUN_00550130(pcVar7);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8();
}



/* FUNCTION 22933 ; VA 0x00afdd10 ; FUN_00afdd10 */

void __thiscall FUN_00afdd10(int param_1,undefined4 *param_2)

{
  ushort uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined2 *puVar5;
  ushort *puVar6;
  undefined2 *puVar7;
  int iVar8;
  int iVar9;
  char *pcVar10;
  bool bVar11;
  ushort *puStack_2c;
  undefined2 *puStack_28;
  undefined2 *puStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  undefined uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  puStack_c = &LAB_017ece18;
  pvStack_10 = ExceptionList;
  if (param_2[4] == 0) {
    return;
  }
  puVar7 = (undefined2 *)0x0;
  uStack_20 = 0;
  iVar8 = 0;
  puStack_2c = (ushort *)0x0;
  puStack_28 = (undefined2 *)0x0;
  puStack_24 = (undefined2 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (2 < (uint)param_2[4]) {
    uStack_1c = 2;
    ExceptionList = &pvStack_10;
    do {
      if (0x16 < uStack_20) goto LAB_00afde2b;
      bVar11 = 0xf < (uint)puVar2[5];
      puVar4 = puVar2;
      if (bVar11) {
        puVar4 = (undefined4 *)*puVar2;
      }
      puVar3 = puVar2;
      if (bVar11) {
        puVar3 = (undefined4 *)*puVar2;
      }
      uStack_14 = CONCAT11(*(undefined *)((int)puVar3 + iVar8 + 1),
                           *(undefined *)((int)puVar4 + iVar8));
      puVar4 = puVar2;
      if (bVar11) {
        puVar4 = (undefined4 *)*puVar2;
      }
      uStack_12 = *(undefined *)((int)puVar4 + iVar8 + 2);
      iVar8 = iVar8 + 3;
      uStack_1c = uStack_1c + 3;
      param_2 = (undefined4 *)CONCAT13(uStack_12,param_2._0_3_);
      if (puVar7 == puStack_28) {
        FUN_00af02a0(puStack_28,&uStack_14);
        puVar7 = puStack_24;
      }
      else {
        *puStack_28 = uStack_14;
        *(undefined *)(puStack_28 + 1) = uStack_12;
        puStack_28 = (undefined2 *)((int)puStack_28 + 3);
      }
      uStack_20 = uStack_20 + 1;
    } while (uStack_1c < (uint)puVar2[4]);
    if (0x16 < uStack_20) goto LAB_00afde2b;
  }
  iVar8 = uStack_20 * 3;
  iVar9 = 0x17 - uStack_20;
  do {
    puVar5 = (undefined2 *)(*(int *)(iStack_18 + 0x16c) + iVar8);
    if (puVar7 == puStack_28) {
      FUN_00af02a0(puStack_28,puVar5);
      puVar7 = puStack_24;
    }
    else {
      *puStack_28 = *puVar5;
      *(undefined *)(puStack_28 + 1) = *(undefined *)(puVar5 + 1);
      puStack_28 = (undefined2 *)((int)puStack_28 + 3);
    }
    iVar8 = iVar8 + 3;
    iVar9 = iVar9 + -1;
  } while (iVar9 != 0);
LAB_00afde2b:
  pcVar10 = *(char **)(iStack_18 + 0x160);
  if ((*(int *)(iStack_18 + 0x164) - (int)pcVar10) / 3 == ((int)puStack_28 - (int)puStack_2c) / 3) {
    puVar6 = puStack_2c;
    for (; pcVar10 != *(char **)(iStack_18 + 0x164); pcVar10 = pcVar10 + 3) {
      uVar1 = *puVar6;
      param_2 = (undefined4 *)(uint)uVar1;
      if ((((char)uVar1 != *pcVar10) ||
          (param_2._1_1_ = (char)(uVar1 >> 8), bVar11 = param_2._1_1_ != pcVar10[1], bVar11)) ||
         (*(char *)(puVar6 + 1) != pcVar10[2])) goto LAB_00afde9b;
      puVar6 = (ushort *)((int)puVar6 + 3);
    }
  }
  else {
LAB_00afde9b:
    if ((ushort **)(iStack_18 + 0x160) != &puStack_2c) {
      FUN_00af0110(puStack_2c,puStack_28,param_2);
    }
    FUN_008a4940(&DAT_0212a020);
  }
  FUN_00af3750();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22934 ; VA 0x00afdee0 ; FUN_00afdee0 */

void FUN_00afdee0(void)

{
  FUN_008a6520(&DAT_01d66a1c);
  return;
}



/* FUNCTION 22935 ; VA 0x00afdef0 ; FUN_00afdef0 */

void __thiscall FUN_00afdef0(int param_1,int param_2)

{
  if (*(int *)(param_2 + 0x10) != 0) {
    FUN_00ff1940(*(undefined4 *)(param_1 + 0x134),param_2);
  }
  return;
}



/* FUNCTION 22936 ; VA 0x00afdf10 ; FUN_00afdf10 */

void __thiscall FUN_00afdf10(int param_1,int param_2)

{
  if (*(int *)(param_2 + 0x10) != 0) {
    FUN_00ff1a10(*(undefined4 *)(param_1 + 0x134),param_2);
  }
  return;
}



/* FUNCTION 22937 ; VA 0x00afdf30 ; FUN_00afdf30 */

void __thiscall FUN_00afdf30(int param_1,int param_2)

{
  if (*(int *)(param_2 + 0x10) != 0) {
    FUN_00ff1ae0(*(undefined4 *)(param_1 + 0x134),param_2);
  }
  return;
}



/* FUNCTION 22938 ; VA 0x00afdf50 ; FUN_00afdf50 */

void FUN_00afdf50(int param_1)

{
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_00fed740();
    return;
  }
  return;
}



/* FUNCTION 22939 ; VA 0x00afdf80 ; FUN_00afdf80 */

void FUN_00afdf80(int param_1)

{
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_00a6f260();
    return;
  }
  return;
}



/* FUNCTION 22940 ; VA 0x00afdfa0 ; FUN_00afdfa0 */

void FUN_00afdfa0(void)

{
  FUN_00b0e790(1);
  return;
}



/* FUNCTION 22941 ; VA 0x00afdfb0 ; FUN_00afdfb0 */

void FUN_00afdfb0(void)

{
  FUN_00b0ea40(0);
  return;
}



/* FUNCTION 22942 ; VA 0x00afdfc0 ; FUN_00afdfc0 */

void FUN_00afdfc0(void)

{
  FUN_00b0ea70(0x100);
  return;
}



/* FUNCTION 22943 ; VA 0x00afdfd0 ; FUN_00afdfd0 */

void FUN_00afdfd0(void)

{
  FUN_00b0ec40(&DAT_01eec784);
  return;
}



/* FUNCTION 22944 ; VA 0x00afdfe0 ; FUN_00afdfe0 */

void FUN_00afdfe0(void)

{
  FUN_00b0ef80(0);
  return;
}



/* FUNCTION 22945 ; VA 0x00afdff0 ; FUN_00afdff0 */

void __thiscall FUN_00afdff0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_3);
  return;
}



/* FUNCTION 22946 ; VA 0x00afe020 ; FUN_00afe020 */

void __thiscall FUN_00afe020(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 8))(param_3);
  return;
}



/* FUNCTION 22947 ; VA 0x00afe050 ; FUN_00afe050 */

void __thiscall FUN_00afe050(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined auStack_e8 [200];
  undefined8 uStack_20;
  int iStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c95ab;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b33940();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_00b33940();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_20 = *(undefined8 *)piVar3;
    iStack_18 = piVar3[2];
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_e8);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined8 *)FUN_0088b220();
    uStack_20 = *puVar5;
    iStack_18 = *(int *)(puVar5 + 1);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&uStack_20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22948 ; VA 0x00afe160 ; FUN_00afe160 */

void FUN_00afe160(undefined2 param_1,undefined2 param_2,undefined2 param_3)

{
  FUN_00afd7f0(CONCAT26(param_1,CONCAT24(param_3,CONCAT22(param_2,param_1))),
               CONCAT22(param_3,param_2),0x11,0,0);
  return;
}



/* FUNCTION 22949 ; VA 0x00afe1d0 ; FUN_00afe1d0 */

void __thiscall FUN_00afe1d0(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = *param_2;
  if ((((NAN(*(float *)(param_1 + 0x140)) || NAN(fVar1)) != (*(float *)(param_1 + 0x140) == fVar1))
      && ((NAN(*(float *)(param_1 + 0x144)) || NAN(param_2[1])) !=
          (*(float *)(param_1 + 0x144) == param_2[1]))) &&
     ((NAN(*(float *)(param_1 + 0x148)) || NAN(param_2[2])) !=
      (*(float *)(param_1 + 0x148) == param_2[2]))) {
    return;
  }
  *(float *)(param_1 + 0x140) = fVar1;
  *(float *)(param_1 + 0x144) = param_2[1];
  *(float *)(param_1 + 0x148) = param_2[2];
  FUN_008a4940();
  return;
}



/* FUNCTION 22950 ; VA 0x00afe240 ; FUN_00afe240 */

void __thiscall FUN_00afe240(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar2 = fVar1;
  }
  if ((NAN(*(float *)(param_1 + 0x158)) || NAN(fVar2)) == (*(float *)(param_1 + 0x158) == fVar2)) {
    *(float *)(param_1 + 0x158) = fVar2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22951 ; VA 0x00afe290 ; FUN_00afe290 */

void __thiscall FUN_00afe290(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar2 = fVar1;
  }
  if ((NAN(*(float *)(param_1 + 0x14c)) || NAN(fVar2)) == (*(float *)(param_1 + 0x14c) == fVar2)) {
    *(float *)(param_1 + 0x14c) = fVar2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22952 ; VA 0x00afe2e0 ; FUN_00afe2e0 */

void __thiscall FUN_00afe2e0(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar2 = fVar1;
  }
  if ((NAN(*(float *)(param_1 + 0x154)) || NAN(fVar2)) == (*(float *)(param_1 + 0x154) == fVar2)) {
    *(float *)(param_1 + 0x154) = fVar2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22953 ; VA 0x00afe330 ; FUN_00afe330 */

void __thiscall FUN_00afe330(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce320;
  if (fVar1 <= DAT_018ce320) {
    fVar2 = fVar1;
  }
  if ((NAN(*(float *)(param_1 + 0x150)) || NAN(fVar2)) == (*(float *)(param_1 + 0x150) == fVar2)) {
    *(float *)(param_1 + 0x150) = fVar2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22954 ; VA 0x00afe380 ; FUN_00afe380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe380(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece46;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecb9c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecb9c);
    if (DAT_01eecb9c == -1) {
      uStack_8 = 0;
      FUN_009ca470("CellBlock");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eecb38 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellBlock>::vftable;
      FUN_009caf20(&DAT_01d66af0,5);
      FUN_016f3654(&LAB_0188c860);
      FUN_016f37bf(&DAT_01eecb9c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eecb38;
}



/* FUNCTION 22955 ; VA 0x00afe430 ; FUN_00afe430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe430(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc04) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecc04);
    if (DAT_01eecc04 == -1) {
      uStack_8 = 0;
      FUN_009ca470("CellMaterial");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eecba0 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellMaterial>::vftable;
      FUN_009caf20(&DAT_01d66a60,0x12);
      FUN_016f3654(&LAB_0188c880);
      FUN_016f37bf(&DAT_01eecc04);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eecba0;
}



/* FUNCTION 22956 ; VA 0x00afe4e0 ; FUN_00afe4e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe4e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecb34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecb34);
    if (DAT_01eecb34 == -1) {
      uStack_8 = 0;
      FUN_009ca470("CellOrientation");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eecad0 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellOrientation>::vftable;
      FUN_009caf20(&DAT_01d66b18,4);
      FUN_016f3654(&LAB_0188c8a0);
      FUN_016f37bf(&DAT_01eecb34);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eecad0;
}



/* FUNCTION 22957 ; VA 0x00afe590 ; FUN_00afe590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe590(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecea6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeca64) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeca64);
    if (DAT_01eeca64 == -1) {
      uStack_8 = 0;
      FUN_009ca470("WaterDirection");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeca00 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::WaterCellDirection>::vftable;
      FUN_009caf20(&DAT_01d66b60,6);
      FUN_016f3654(&LAB_0188c8c0);
      FUN_016f37bf(&DAT_01eeca64);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeca00;
}



/* FUNCTION 22958 ; VA 0x00afe640 ; FUN_00afe640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe640(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecec6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecacc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecacc);
    if (DAT_01eecacc == -1) {
      uStack_8 = 0;
      FUN_009ca470("WaterForce");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeca68 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::WaterCellForce>::vftable;
      FUN_009caf20(&DAT_01d66b38,5);
      FUN_016f3654(&LAB_0188c8e0);
      FUN_016f37bf(&DAT_01eecacc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeca68;
}



/* FUNCTION 22959 ; VA 0x00afe6f0 ; FUN_00afe6f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe6f0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc44) {
    FUN_016f3809(&DAT_01eecc44);
    if (DAT_01eecc44 == -1) {
      _DAT_01eecc38 = FUN_005c65e0;
      _DAT_01eecc3c = FUN_005c65e0;
      _DAT_01eecc40 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eecc44);
    }
  }
  return &DAT_01eecc38;
}



/* FUNCTION 22960 ; VA 0x00afe760 ; FUN_00afe760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe760(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc54) {
    FUN_016f3809(&DAT_01eecc54);
    if (DAT_01eecc54 == -1) {
      _DAT_01eecc48 = FUN_005c65e0;
      _DAT_01eecc4c = FUN_005c65e0;
      _DAT_01eecc50 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eecc54);
    }
  }
  return &DAT_01eecc48;
}



/* FUNCTION 22961 ; VA 0x00afe7d0 ; FUN_00afe7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe7d0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc34) {
    FUN_016f3809(&DAT_01eecc34);
    if (DAT_01eecc34 == -1) {
      _DAT_01eecc28 = FUN_005c65e0;
      _DAT_01eecc2c = FUN_005c65e0;
      _DAT_01eecc30 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eecc34);
    }
  }
  return &DAT_01eecc28;
}



/* FUNCTION 22962 ; VA 0x00afe840 ; FUN_00afe840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe840(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc14) {
    FUN_016f3809(&DAT_01eecc14);
    if (DAT_01eecc14 == -1) {
      _DAT_01eecc08 = FUN_005c65e0;
      _DAT_01eecc0c = FUN_005c65e0;
      _DAT_01eecc10 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eecc14);
    }
  }
  return &DAT_01eecc08;
}



/* FUNCTION 22963 ; VA 0x00afe8b0 ; FUN_00afe8b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00afe8b0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc24) {
    FUN_016f3809(&DAT_01eecc24);
    if (DAT_01eecc24 == -1) {
      _DAT_01eecc18 = FUN_005c65e0;
      _DAT_01eecc1c = FUN_005c65e0;
      _DAT_01eecc20 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eecc24);
    }
  }
  return &DAT_01eecc18;
}



/* FUNCTION 22964 ; VA 0x00afe920 ; FUN_00afe920 */

void FUN_00afe920(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined auStack_10 [12];
  
  if (param_1 == 0) {
    return;
  }
  iVar2 = *(int *)(param_1 + 0xc);
  iVar1 = FUN_008aa870();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da)) {
    iVar3 = param_1;
  }
  if ((iVar3 != 0) && (iVar2 = FUN_00a9d3e0(), iVar2 == 0)) {
    return;
  }
  FUN_016756b0(auStack_10,"Unable to change Terrain\'s parent. Workspace already has Terrain");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 22965 ; VA 0x00afe990 ; FUN_00afe990 */

void FUN_00afe990(float *param_1)

{
  short sStack_c;
  short sStack_a;
  short sStack_8;
  
  FUN_00afeb10(&sStack_c,&stack0x00000008,0);
  *param_1 = (float)(int)sStack_c;
  param_1[1] = (float)(int)sStack_a;
  param_1[2] = (float)(int)sStack_8;
  return;
}



/* FUNCTION 22966 ; VA 0x00afe9e0 ; FUN_00afe9e0 */

void FUN_00afe9e0(float *param_1)

{
  short sStack_c;
  short sStack_a;
  short sStack_8;
  
  FUN_00afeb10(&sStack_c,&stack0x00000008,1);
  *param_1 = (float)(int)sStack_c;
  param_1[1] = (float)(int)sStack_a;
  param_1[2] = (float)(int)sStack_8;
  return;
}



/* FUNCTION 22967 ; VA 0x00afea30 ; FUN_00afea30 */

float * FUN_00afea30(float *param_1,float param_2,undefined8 param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_01725280((double)(param_2 * DAT_018e1340));
  *param_1 = (float)(int)(short)(int)fVar1;
  fVar1 = (float10)FUN_01725280((double)((float)param_3 * DAT_018e1340));
  param_1[1] = (float)(int)(short)(int)fVar1;
  fVar1 = (float10)FUN_01725280((double)(param_3._4_4_ * DAT_018e1340));
  param_1[2] = (float)(int)(short)(int)fVar1;
  return param_1;
}



/* FUNCTION 22968 ; VA 0x00afeb10 ; FUN_00afeb10 */

undefined4 * FUN_00afeb10(undefined4 *param_1,float *param_2,uint param_3)

{
  short *psVar1;
  int iVar2;
  short *psVar3;
  undefined4 uVar4;
  short sVar5;
  char *pcVar6;
  short sVar7;
  uint uVar8;
  int iVar9;
  short *psVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined4 uStack_4c;
  short sStack_48;
  undefined2 uStack_46;
  float fStack_44;
  short *psStack_40;
  short *psStack_3c;
  short *psStack_38;
  short sStack_34;
  short sStack_32;
  short sStack_30;
  undefined4 uStack_2a;
  undefined4 uStack_24;
  short sStack_20;
  uint uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eced8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009c8df0(&uStack_24,param_2);
  sVar5 = sStack_20;
  uVar4 = uStack_24;
  pcVar6 = (char *)FUN_00a70be0((int)&uStack_14 + 2,(int)(short)uStack_24,(int)uStack_24._2_2_,
                                (int)sStack_20,1);
  uStack_1c = param_3 & 0xff;
  if ((*pcVar6 != '\0') == uStack_1c) {
    *param_1 = uVar4;
    *(short *)(param_1 + 1) = sVar5;
    ExceptionList = pvStack_10;
    return param_1;
  }
  psStack_40 = (short *)0x0;
  psStack_3c = (short *)0x0;
  psStack_38 = (short *)0x0;
  uStack_8 = 0;
  FUN_007fdba0(0x1b);
  uStack_14 = -1;
  do {
    param_3 = -1;
    do {
      iVar9 = -1;
      do {
        psVar10 = psStack_3c;
        iVar2 = param_3;
        FUN_009c8df0(&sStack_34,param_2);
        sVar5 = sStack_32 + (short)iVar2;
        sVar7 = (short)uStack_14 + sStack_34;
        sStack_48 = sStack_30 + (short)iVar9;
        uStack_2a = CONCAT22(sVar5,sVar7);
        uStack_4c = uStack_2a;
        fVar13 = *param_2 - ((float)((int)sVar7 << 2) + DAT_018daf58);
        fVar12 = param_2[1] - ((float)((int)sVar5 << 2) + DAT_018daf58);
        fVar11 = param_2[2] - ((float)((int)sStack_48 << 2) + DAT_018daf58);
        fStack_44 = fVar12 * fVar12 + fVar13 * fVar13 + fVar11 * fVar11;
        if (psStack_38 == psVar10) {
          FUN_007fc130(psVar10,&uStack_4c);
        }
        else {
          *(ulonglong *)psVar10 = CONCAT26(uStack_46,CONCAT24(sStack_48,uStack_2a));
          *(float *)(psVar10 + 4) = fStack_44;
          psStack_3c = psVar10 + 6;
        }
        psVar3 = psStack_3c;
        psVar10 = psStack_40;
        iVar9 = iVar9 + 1;
      } while (iVar9 < 2);
      param_3 = param_3 + 1;
    } while ((int)param_3 < 2);
    uStack_14 = uStack_14 + 1;
  } while (uStack_14 < 2);
  FUN_00af09d0(psStack_40,psStack_3c,((int)psStack_3c - (int)psStack_40) / 0xc,param_3);
  psVar1 = psVar10;
  do {
    if (psVar10 == psVar3) {
      *param_1 = uStack_24;
      *(short *)(param_1 + 1) = sStack_20;
      if (psVar1 != (short *)0x0) {
        uVar8 = (((int)psStack_38 - (int)psVar1) / 0xc) * 0xc;
        psVar10 = psVar1;
        if (0xfff < uVar8) {
          psVar10 = *(short **)(psVar1 + -2);
          uVar8 = uVar8 + 0x23;
          if (0x1f < (uint)((int)psVar1 + (-4 - (int)psVar10))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
LAB_00afedd2:
        FUN_01674ea0(psVar10,uVar8);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    pcVar6 = (char *)FUN_00a70be0((int)&param_3 + 2,(int)*psVar10,(int)psVar10[1],(int)psVar10[2],1)
    ;
    if ((*pcVar6 != '\0') == uStack_1c) {
      *param_1 = *(undefined4 *)psVar10;
      *(short *)(param_1 + 1) = psVar10[2];
      if (psStack_40 == (short *)0x0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      uVar8 = (((int)psStack_38 - (int)psStack_40) / 0xc) * 0xc;
      psVar10 = psStack_40;
      if (0xfff < uVar8) {
        psVar10 = *(short **)(psStack_40 + -2);
        uVar8 = uVar8 + 0x23;
        if (0x1f < (uint)((int)psStack_40 + (-4 - (int)psVar10))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00afedd2;
    }
    psVar10 = psVar10 + 6;
    psVar1 = psStack_40;
  } while( true );
}



/* FUNCTION 22969 ; VA 0x00afee00 ; FUN_00afee00 */

/* WARNING: Removing unreachable block (ram,0x00afef16) */

undefined4 FUN_00afee00(undefined4 param_1)

{
  code *pcVar1;
  uint uVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  byte *pbVar10;
  uint uVar11;
  float10 fVar12;
  ulonglong uVar13;
  char *pcVar14;
  undefined auStack_e4 [60];
  int aiStack_a8 [8];
  byte abStack_88 [8];
  uint uStack_80;
  double dStack_7c;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  float fStack_48;
  uint uStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  byte abStack_28 [3];
  byte bStack_25;
  undefined auStack_24 [12];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecf03;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888530();
  uStack_8 = 0;
  FUN_00a73410();
  cVar3 = FUN_009d29b0(1,auStack_e4);
  if (cVar3 == '\0') {
    pcVar14 = "Argument 1 missing or nil";
  }
  else {
    cVar3 = FUN_009d1d10(2,&dStack_7c);
    if (cVar3 == '\0') {
      pcVar14 = "Argument 2 missing or nil";
    }
    else {
      iVar5 = FUN_01256300(param_1);
      if (iVar5 < 4) {
        pcVar14 = "Argument 3 missing or nil";
      }
      else {
        iVar5 = FUN_01256300(param_1);
        if (iVar5 < 5) {
          pcVar14 = "Argument 4 missing or nil";
        }
        else {
          FUN_00a70760(&iStack_74,auStack_e4,(float)dStack_7c);
          uVar13 = FUN_00a70d30();
          if (uVar13 <= (ulonglong)(longlong)DAT_01d669fc) {
            FUN_00a6dbd0(iStack_68 - iStack_74,iStack_64 - iStack_70,iStack_60 - iStack_6c);
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            iStack_54 = FUN_00896e70();
            uStack_44 = 0;
            uStack_80 = 0;
            aiStack_a8[0] = 0;
            aiStack_a8[1] = 0;
            aiStack_a8[2] = 0;
            aiStack_a8[3] = 0;
            aiStack_a8[4] = 0;
            aiStack_a8[5] = 0;
            aiStack_a8[6] = 0;
            aiStack_a8[7] = 0;
            cVar3 = FUN_00afc950(param_1,4,iStack_40);
            if (cVar3 == '\0') {
              uVar6 = FUN_00615960();
              uVar6 = FUN_005f7790(uVar6);
              uVar6 = FUN_0054db20(uVar6);
              FUN_016756b0(auStack_24,
                           "Bad argument materials to \'WriteVoxels\' (%dx%dx%d array expected)",
                           uVar6);
            }
            else {
              cVar3 = FUN_00afc950(param_1,5,iStack_40);
              if (cVar3 != '\0') {
                iStack_14 = 0;
                if (0 < iStack_40) {
                  do {
                    iVar7 = iStack_14;
                    iVar5 = iStack_14 + 1;
                    iStack_50 = iVar5;
                    FUN_01256cb0(param_1,4,iVar5);
                    FUN_01256cb0(param_1,5,iVar5);
                    cVar3 = FUN_00afc950(param_1,0xfffffffe,iStack_3c);
                    if (cVar3 == '\0') {
                      uVar6 = FUN_00615960();
                      uVar6 = FUN_005f7790(uVar6);
                      FUN_016756b0(auStack_24,
                                   "Bad argument materials[%d] to \'WriteVoxels\' (%dx%d array expected)"
                                   ,iVar7 + 1,uVar6);
                      goto LAB_00aff335;
                    }
                    cVar3 = FUN_00afc950(param_1,0xffffffff,iStack_3c);
                    if (cVar3 == '\0') {
                      uVar6 = FUN_00615960();
                      uVar6 = FUN_005f7790(uVar6);
                      FUN_016756b0(auStack_24,
                                   "Bad argument occupancy[%d] to \'WriteVoxels\' (%dx%d array expected)"
                                   ,iVar7 + 1,uVar6);
                      goto LAB_00aff335;
                    }
                    iStack_18 = 0;
                    if (0 < iStack_3c) {
                      do {
                        iVar5 = iStack_18;
                        iStack_4c = iStack_18 + 1;
                        FUN_01256cb0(param_1,0xfffffffe,iStack_4c);
                        FUN_01256cb0(param_1,0xfffffffe,iStack_4c);
                        cVar3 = FUN_00afc950(param_1,0xfffffffe,iStack_38);
                        if (cVar3 == '\0') {
                          uVar6 = FUN_00615960();
                          FUN_016756b0(auStack_24,
                                       "Bad argument materials[%d][%d] to \'WriteVoxels\' (%d-element array expected)"
                                       ,iVar7 + 1,iVar5 + 1,uVar6);
                          goto LAB_00aff335;
                        }
                        cVar3 = FUN_00afc950(param_1,0xffffffff,iStack_38);
                        if (cVar3 == '\0') {
                          uVar6 = FUN_00615960();
                          FUN_016756b0(auStack_24,
                                       "Bad argument occupancy[%d][%d] to \'WriteVoxels\' (%d-element array expected)"
                                       ,iVar7 + 1,iVar5 + 1,uVar6);
                          goto LAB_00aff335;
                        }
                        iVar5 = 0;
                        if (0 < iStack_38) {
                          do {
                            iVar7 = iVar5 + 1;
                            iStack_58 = iVar7;
                            FUN_01256cb0(param_1,0xfffffffe,iVar7);
                            FUN_01256cb0(param_1,0xfffffffe,iVar7);
                            iVar7 = FUN_012577c0(param_1,0xfffffffe);
                            uVar2 = uStack_44;
                            if (iVar7 == 0) {
LAB_00aff365:
                              uVar6 = FUN_012578b0(param_1,0xfffffffe);
                              uVar6 = FUN_012578f0(param_1,uVar6);
                              FUN_01257dd0(param_1,
                                           "Bad argument materials[%d][%d][%d] to \'WriteVoxels\' (Enum.Material expected, got %s)"
                                           ,iStack_14 + 1,iStack_18 + 1,iVar5 + 1,uVar6);
LAB_00aff391:
                              uVar6 = FUN_012578b0(param_1,0xffffffff);
                              uVar6 = FUN_012578f0(param_1,uVar6);
                              FUN_01257dd0(param_1,
                                           "Bad argument occupancy[%d][%d][%d] to \'WriteVoxels\' (number expected, got %s)"
                                           ,iStack_14 + 1,iStack_18 + 1,iVar5 + 1,uVar6);
                              pcVar1 = (code *)swi(3);
                              uVar6 = (*pcVar1)();
                              return uVar6;
                            }
                            uVar11 = 0;
                            do {
                              if (aiStack_a8[uVar11] == iVar7) goto LAB_00aff13a;
                              uVar11 = uVar11 + 1;
                            } while (uVar11 < 8);
                            aiStack_a8[uStack_44] = iVar7;
                            uStack_80 = uStack_80 + 1 & 7;
                            piVar8 = (int *)FUN_01257810(param_1,0xfffffffe,DAT_01e90cd0);
                            if (piVar8 == (int *)0x0) goto LAB_00aff365;
                            if (*(int *)(*piVar8 + 0x18) != iStack_54) {
                              uVar6 = FUN_005543f0();
                              FUN_01257dd0(param_1,
                                           "Bad argument materials[%d][%d][%d] to \'WriteVoxels\' (Enum.Material expected, got %s)"
                                           ,iStack_14 + 1,iStack_18 + 1,iVar5 + 1,uVar6);
                              goto LAB_00aff365;
                            }
                            bVar4 = FUN_00862c80(*(undefined4 *)(*piVar8 + 0x1c));
                            abStack_88[uVar2] = bVar4;
                            uStack_44 = uStack_80;
                            uVar11 = uVar2;
LAB_00aff13a:
                            bVar4 = abStack_88[uVar11];
                            iVar7 = FUN_01256480(param_1,0xffffffff);
                            if (iVar7 == 0) goto LAB_00aff391;
                            fVar12 = (float10)FUN_01257500(param_1,0xffffffff,0);
                            fStack_48 = (float)fVar12;
                            if (((bVar4 == 0) || (cVar3 = FUN_00c94370(fStack_48), cVar3 != '\0'))
                               || (fStack_48 <= 0.0)) {
                              iVar7 = iStack_14;
                              if (DAT_01d66a3c == '\0') {
                                abStack_28[0] = 0;
                                abStack_28[1] = 0;
                                pbVar10 = abStack_28;
                                goto LAB_00aff1f2;
                              }
                            }
                            else {
                              iVar9 = (int)(fStack_48 * DAT_018f9980 - DAT_018ce2f4);
                              iVar7 = 0;
                              if (-1 < iVar9) {
                                iVar7 = iVar9;
                              }
                              bStack_25 = (byte)iVar7;
                              if (0xff < iVar7) {
                                bStack_25 = 0xff;
                              }
                              bStack_25 = (byte)((int)-(uint)bVar4 >> 0x1f) & bStack_25;
                              pbVar10 = abStack_28 + 2;
                              abStack_28[2] = bVar4;
LAB_00aff1f2:
                              iVar7 = iStack_14;
                              FUN_0080b150(iStack_14,iStack_18,iVar5,pbVar10);
                            }
                            FUN_01257280(param_1,0xfffffffd);
                            iVar5 = iStack_58;
                          } while (iStack_58 < iStack_38);
                        }
                        FUN_01257280(param_1,0xfffffffd);
                        iStack_18 = iStack_4c;
                      } while (iStack_4c < iStack_3c);
                    }
                    FUN_01257280(param_1,0xfffffffd);
                    iStack_14 = iStack_50;
                  } while (iStack_50 < iStack_40);
                }
                FUN_00a72960(&iStack_74,&iStack_40,0);
                FUN_00612e90();
                FUN_006133b0();
                ExceptionList = pvStack_10;
                return 0;
              }
              uVar6 = FUN_00615960();
              uVar6 = FUN_005f7790(uVar6);
              uVar6 = FUN_0054db20(uVar6);
              FUN_016756b0(auStack_24,
                           "Bad argument occupancy to \'WriteVoxels\' (%dx%dx%d array expected)",
                           uVar6);
            }
            goto LAB_00aff335;
          }
          pcVar14 = "Region is too large";
        }
      }
    }
  }
  FUN_00550130(pcVar14);
LAB_00aff335:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 22970 ; VA 0x00aff3c0 ; FUN_00aff3c0 */

int * __thiscall
FUN_00aff3c0(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecf2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_RBX::BrickColor)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::BrickColor>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::BrickColor>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22971 ; VA 0x00aff4d0 ; FUN_00aff4d0 */

undefined4 * __thiscall
FUN_00aff4d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_00aff8c0();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_G3D::Vector3_const&)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_00918e80(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Vector3>::vftable;
  return param_1;
}



/* FUNCTION 22972 ; VA 0x00aff560 ; FUN_00aff560 */

undefined4 * __thiscall
FUN_00aff560(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_00aff8c0();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_G3D::Vector3_const&)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_00918e80(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Vector3>::vftable;
  return param_1;
}



/* FUNCTION 22973 ; VA 0x00aff5f0 ; FUN_00aff5f0 */

undefined4 * __thiscall
FUN_00aff5f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_00aff8c0();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const&_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_G3D::Vector3_const&)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_00918e80(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Vector3>::vftable;
  return param_1;
}



/* FUNCTION 22974 ; VA 0x00aff680 ; FUN_00aff680 */

undefined4 * __thiscall
FUN_00aff680(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_00aff8c0();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,float>::
              GetSetImpl<float_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(float)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_006846c0(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,float>::vftable;
  return param_1;
}



/* FUNCTION 22975 ; VA 0x00aff710 ; FUN_00aff710 */

int * __thiscall
FUN_00aff710(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,bool>::
              GetSetImpl<bool_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(bool)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::PartInstance,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::PartInstance,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22976 ; VA 0x00aff820 ; FUN_00aff820 */

int * __thiscall FUN_00aff820(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b0f8e0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22977 ; VA 0x00aff870 ; FUN_00aff870 */

int * __thiscall FUN_00aff870(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b0faa0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22978 ; VA 0x00aff8c0 ; FUN_00aff8c0 */

undefined * FUN_00aff8c0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecf4c;
  pvStack_10 = ExceptionList;
  if (DAT_01eedcc4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeded0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeded0);
      if (DAT_01eeded0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e70350();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BasePart",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188d2e0);
        FUN_016f37bf(&DAT_01eeded0);
      }
    }
    DAT_01eedcc4 = &DAT_01eedcc8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eedcc4;
}



/* FUNCTION 22979 ; VA 0x00aff9a0 ; FUN_00aff9a0 */

void FUN_00aff9a0(void)

{
  int iVar1;
  
  if (DAT_01eeded4 == 0) {
    iVar1 = FUN_00aff8c0();
    DAT_01eeded4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22980 ; VA 0x00aff9c0 ; FUN_00aff9c0 */

undefined4 FUN_00aff9c0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined **appuStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined **ppuStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ecf88;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuStack_40 = (undefined **)0x0;
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  cVar4 = FUN_0055c750(param_2,param_3,&uStack_38);
  ppuStack_40 = &PTR_FUN_0194f9fc;
  if (cVar4 == '\0') {
    ppuStack_40 = (undefined **)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    ppuStack_14 = ppuStack_40;
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_14 = ppuStack_40;
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  appuStack_68[0] = (undefined **)0x0;
  uVar2 = *(undefined4 *)(iStack_18 + 4);
  ppuStack_14 = (undefined **)uVar2;
  if (ppuStack_40 != (undefined **)0x0) {
    appuStack_68[0] = ppuStack_40;
    if (((uint)ppuStack_40 & 1) == 0) {
      (**(code **)((uint)ppuStack_40 & 0xfffffffe))(&uStack_38,&uStack_60,0);
    }
    else {
      uStack_60 = uStack_38;
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
    }
  }
  uStack_8._0_1_ = 2;
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar2);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_48 = *puVar5;
  uStack_44 = puVar5[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if ((DAT_01d69070 != '\0') || (DAT_01d66be0 != '\0')) {
    FUN_00b08fb0();
  }
  uStack_8._0_1_ = 4;
  FUN_00affe60(param_1,appuStack_68);
  FUN_00b01550();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (ppuStack_40 != (undefined **)0x0) {
    if ((((uint)ppuStack_40 & 1) == 0) &&
       (*(code **)((uint)ppuStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)ppuStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
    }
    ppuStack_40 = (undefined **)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22981 ; VA 0x00affc20 ; FUN_00affc20 */

undefined4 FUN_00affc20(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined **appuStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined **ppuStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ecfc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuStack_40 = (undefined **)0x0;
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  cVar4 = FUN_0055c750(param_2,param_3,&uStack_38);
  ppuStack_40 = &PTR_FUN_0194f9f4;
  if (cVar4 == '\0') {
    ppuStack_40 = (undefined **)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    ppuStack_14 = ppuStack_40;
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_14 = ppuStack_40;
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  appuStack_68[0] = (undefined **)0x0;
  uVar2 = *(undefined4 *)(iStack_18 + 4);
  ppuStack_14 = (undefined **)uVar2;
  if (ppuStack_40 != (undefined **)0x0) {
    appuStack_68[0] = ppuStack_40;
    if (((uint)ppuStack_40 & 1) == 0) {
      (**(code **)((uint)ppuStack_40 & 0xfffffffe))(&uStack_38,&uStack_60,0);
    }
    else {
      uStack_60 = uStack_38;
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
    }
  }
  uStack_8._0_1_ = 2;
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar2);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_48 = *puVar5;
  uStack_44 = puVar5[1];
  uStack_8._0_1_ = 3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_00b09010();
  uStack_8._0_1_ = 4;
  FUN_0099e760(param_1,appuStack_68);
  FUN_009a4a10();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (ppuStack_40 != (undefined **)0x0) {
    if ((((uint)ppuStack_40 & 1) == 0) &&
       (*(code **)((uint)ppuStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)ppuStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
    }
    ppuStack_40 = (undefined **)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22982 ; VA 0x00affe60 ; FUN_00affe60 */

undefined4 * FUN_00affe60(undefined4 *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iStack_28;
  int *piStack_24;
  uint *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d25ea;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 0;
  iStack_8._1_3_ = 0;
  uStack_18 = uVar6;
  puVar7 = (undefined4 *)FUN_01674e20(0x40);
  puStack_1c = puVar7;
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puVar7 = 0;
    puVar7[1] = 1;
    puVar7[2] = FUN_00b04fb0;
    puVar7[3] = FUN_00b05080;
    puVar7[4] = 0;
    puVar7[5] = uStack_14;
    puStack_20 = puVar7 + 6;
    *puStack_20 = 0;
    iStack_8._0_1_ = 2;
    uVar2 = *param_2;
    if (uVar2 != 0) {
      *puStack_20 = uVar2;
      if ((uVar2 & 1) == 0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,puVar7 + 8,0);
      }
      else {
        uVar2 = param_2[3];
        uVar4 = param_2[4];
        uVar5 = param_2[5];
        puVar7[8] = param_2[2];
        puVar7[9] = uVar2;
        puVar7[10] = uVar4;
        puVar7[0xb] = uVar5;
        *(undefined8 *)(puVar7 + 0xc) = *(undefined8 *)(param_2 + 6);
      }
    }
    puVar7[0xe] = 0;
    puVar7[0xf] = 0;
    if (param_2[9] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[9] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar7[0xe] = param_2[8];
    puVar7[0xf] = param_2[9];
    if ((DAT_01d69070 != '\0') || (DAT_01d66be0 != '\0')) {
      FUN_00587490(&iStack_28);
      iStack_8._0_1_ = 5;
      if (iStack_28 != 0) {
        FUN_00b08fb0();
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_24[2] + -1;
          piStack_24[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016797d0(puVar7);
  *param_1 = puVar7;
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  iStack_8 = 6;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22983 ; VA 0x00affff0 ; FUN_00affff0 */

int * __fastcall FUN_00affff0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00b0f580();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00b0008b:
    thunk_FUN_00b0f580();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00b0f580();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00b0008b;
    FUN_00aff820(&piStack_8);
    iVar3 = FUN_00b0f580();
    *param_1 = iVar3;
    iVar2 = FUN_00b0f580();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22984 ; VA 0x00b000c0 ; FUN_00b000c0 */

int * __fastcall FUN_00b000c0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = thunk_FUN_00896e70();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00b0015b:
    thunk_FUN_00896e70();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00896e70();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00b0015b;
    FUN_00895430(&piStack_8);
    iVar3 = thunk_FUN_00896e70();
    *param_1 = iVar3;
    iVar2 = thunk_FUN_00896e70();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22985 ; VA 0x00b00190 ; FUN_00b00190 */

int * __fastcall FUN_00b00190(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00b0f830();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00b0022b:
    thunk_FUN_00b0f830();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00b0f830();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00b0022b;
    FUN_00aff870(&piStack_8);
    iVar3 = FUN_00b0f830();
    *param_1 = iVar3;
    iVar2 = FUN_00b0f830();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22986 ; VA 0x00b00260 ; FUN_00b00260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b00260(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecfec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedcc0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eedcc0);
    if (DAT_01eedcc0 == -1) {
      uStack_8 = 0;
      FUN_00888860("CoordinateFrame",0x10,0,0,0);
      _DAT_01eedc9c = RBX::Reflection::TType<class_G3D::CoordinateFrame>::vftable;
      FUN_016f3654(&LAB_0188d2f0);
      FUN_016f37bf(&DAT_01eedcc0);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedc9c;
}



/* FUNCTION 22987 ; VA 0x00b00300 ; thunk_FUN_00b0f580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b0f580(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edca6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee02c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee02c);
    if (DAT_01eee02c == -1) {
      uStack_8 = 0;
      FUN_009ca470("CollisionFidelity");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eedfc8 = RBX::Reflection::EnumDesc<enum_RBX::CollisionFidelity>::vftable;
      FUN_009caf20(&DAT_01d66dc0,4);
      FUN_016f3654(&LAB_0188d180);
      FUN_016f37bf(&DAT_01eee02c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedfc8;
}



/* FUNCTION 22988 ; VA 0x00b00310 ; thunk_FUN_00b0f630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b0f630(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edcc6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee094) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee094);
    if (DAT_01eee094 == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_0194e7f4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee030 = RBX::Reflection::EnumDesc<enum_RBX::PartInstance::FormFactor>::vftable;
      FUN_009caf20(&DAT_01d66c64,4);
      FUN_009cac90("Block",1);
      FUN_016f3654(&LAB_0188d1a0);
      FUN_016f37bf(&DAT_01eee094);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee030;
}



/* FUNCTION 22989 ; VA 0x00b00320 ; thunk_FUN_00b0f6f0 */

undefined * thunk_FUN_00b0f6f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edcdc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedf5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eedf5c);
    if (DAT_01eedf5c == -1) {
      uStack_8 = 0;
      FUN_00ff4f30();
      FUN_016f3654(&LAB_0188d1c0);
      FUN_016f37bf(&DAT_01eedf5c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedef8;
}



/* FUNCTION 22990 ; VA 0x00b00330 ; thunk_FUN_00b0f830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b0f830(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edd26;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedfc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eedfc4);
    if (DAT_01eedfc4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("RenderFidelity");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eedf60 = RBX::Reflection::EnumDesc<enum_RBX::RenderFidelity>::vftable;
      FUN_009caf20(&DAT_01d66de0,3);
      FUN_016f3654(&LAB_0188d200);
      FUN_016f37bf(&DAT_01eedfc4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedf60;
}



/* FUNCTION 22991 ; VA 0x00b00340 ; FUN_00b00340 */

code * FUN_00b00340(code *param_1)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined uVar5;
  undefined4 uVar6;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1c0;
  undefined4 *puStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed02e;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_0088cdc0();
  puStack_ec = (undefined4 *)0x0;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_00000024;
  piStack_e4 = in_stack_00000028;
  puStack_ec = (undefined4 *)FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1c0 = uStack_f0;
  puStack_1bc = (undefined4 *)0x0;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)*puStack_ec)(&uStack_e8,auStack_1b8);
  }
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  puStack_1bc = puStack_ec;
  if (param_1 == (code *)0x0) {
    uStack_8._0_1_ = uVar5;
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  pcVar3 = *(code **)(((uint)param_1 & 0xfffffffe) + 4);
  FUN_005caf00(&uStack_1c0);
  (*pcVar3)(&stack0x0000000c);
  uStack_8._0_1_ = 5;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)puStack_1bc[2])(auStack_1b8);
  }
  uStack_8._0_1_ = 6;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(&uStack_e8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    param_1 = (code *)(*param_1)(&stack0x0000000c,&stack0x0000000c,2);
  }
  piVar4 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22992 ; VA 0x00b004e0 ; FUN_00b004e0 */

int FUN_00b004e0(code *param_1,undefined4 param_2,int *param_3,int param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_4;
  puStack_c = &LAB_017ed048;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    iVar4 = param_5;
    ExceptionList = &pvStack_10;
    if ((param_5 != 1) || (ExceptionList = &pvStack_10, *(int *)(param_4 + 0x1b0) == 0))
    goto LAB_00b00539;
    ExceptionList = &pvStack_10;
    iVar4 = (**(code **)(**(int **)(param_4 + 0x1ac) + 8))();
    if (iVar4 == 10) goto LAB_00b00539;
  }
  iVar4 = (*param_1)(iVar2,&param_2);
LAB_00b00539:
  iVar6 = 0;
  if (0 < *(int *)(iVar2 + 0x14)) {
    do {
      iVar4 = *(int *)(*(int *)(iVar2 + 0x10) + iVar6 * 4);
      uVar5 = -(uint)(iVar4 != 0) & iVar4 - 8U;
      iVar4 = FUN_00ca1a80(uVar5);
      if ((char)iVar4 == '\0') {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        iVar4 = FUN_00b004e0(param_1,param_2,param_3,uVar5,param_5);
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < *(int *)(iVar2 + 0x14));
  }
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22993 ; VA 0x00b005e0 ; FUN_00b005e0 */

undefined4 * __thiscall FUN_00b005e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed073;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22994 ; VA 0x00b006e0 ; FUN_00b006e0 */

undefined4 * __thiscall
FUN_00b006e0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7,undefined4 param_8,undefined8 param_9
            ,undefined4 param_10)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed0d3;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar3 = FUN_00aff8c0();
  FUN_009cb790(uVar3,param_4,param_8,param_9,param_10);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0x10] = param_3;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_7 != (int *)0x0) {
      LOCK();
      param_7[1] = param_7[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_6;
    puVar4[1] = param_7;
  }
  param_1[0x11] = puVar4;
  uStack_8._0_1_ = 2;
  uVar3 = FUN_00888530();
  param_1[9] = uVar3;
  puVar4 = (undefined4 *)param_1[0x11];
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar4 = &uStack_1b8;
    uStack_8 = 4;
    uVar6 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    iStack_e4 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar4;
    uStack_dc = puVar4[1];
    iStack_e4 = FUN_006309e0();
    puVar4 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar5 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar5,uVar3,puVar4);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 5;
    uStack_14 = uVar6;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  uStack_8 = 2;
  if ((uVar6 & 1) != 0) {
    uStack_8 = 6;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22995 ; VA 0x00b008e0 ; FUN_00b008e0 */

undefined4 * __thiscall
FUN_00b008e0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed12b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00aff8c0();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::PartInstance,void___cdecl(class_G3D::Vector3),1>::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined8 *)param_1[0x11];
  if (puVar1 == (undefined8 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088d870();
    iStack_e4 = 0;
    uStack_e0 = *puVar1;
    uStack_d8 = *(undefined4 *)(puVar1 + 1);
    iStack_e4 = FUN_006315b0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22996 ; VA 0x00b00a70 ; FUN_00b00a70 */

undefined4 * __thiscall
FUN_00b00a70(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined8 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed169;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb820(uVar1,param_4,param_10,param_11,param_12);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,enum_RBX::CollisionFidelity,enum_RBX::RenderFidelity),3>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_9;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 2;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_8;
  }
  param_1[0x13] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00b04a30(param_5,param_6,param_7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22997 ; VA 0x00b00b40 ; FUN_00b00b40 */

undefined4 * __fastcall FUN_00b00b40(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("CollisionFidelity");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::CollisionFidelity>::vftable;
  FUN_009caf20(&DAT_01d66dc0,4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22998 ; VA 0x00b00ba0 ; FUN_00b00ba0 */

undefined4 * __fastcall FUN_00b00ba0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470(&DAT_018db7a4);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PartMaterial>::vftable;
  FUN_009caf20(&DAT_01d66c88,0x25);
  FUN_009cad30(&DAT_01d66db0,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22999 ; VA 0x00b00c10 ; FUN_00b00c10 */

undefined4 * __fastcall FUN_00b00c10(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("RenderFidelity");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::RenderFidelity>::vftable;
  FUN_009caf20(&DAT_01d66de0,3);
  ExceptionList = pvStack_10;
  return param_1;
}


