/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 11500 ; VA 0x007a3930 ; FUN_007a3930 */

void FUN_007a3930(int param_1,int param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int iVar11;
  int iVar12;
  
  iVar7 = (int)(param_3 - 1) >> 1;
  iVar11 = param_2;
  if (param_2 < iVar7) {
    do {
      iVar9 = iVar11 * 0x40 + param_1;
      iVar8 = FUN_008361f0(*(undefined4 *)
                            (*(int *)(iVar11 * 0x40 + 0x44 + param_1) * 0x278 + 0x260 +
                            *(int *)(*(int *)(iVar9 + 0x40) + 0x14)));
      iVar9 = FUN_008361f0(*(undefined4 *)
                            (*(int *)(iVar9 + 0x24) * 0x278 + 0x260 +
                            *(int *)(*(int *)(iVar9 + 0x20) + 0x14)));
      iVar12 = iVar11 * 0x20;
      iVar11 = (*(int *)(iVar8 + 8) <= *(int *)(iVar9 + 8)) + 1 + iVar11 * 2;
      puVar1 = (undefined4 *)(iVar11 * 0x20 + param_1);
      uVar4 = puVar1[1];
      uVar5 = puVar1[2];
      uVar6 = puVar1[3];
      puVar2 = (undefined4 *)(iVar12 + param_1);
      *puVar2 = *puVar1;
      puVar2[1] = uVar4;
      puVar2[2] = uVar5;
      puVar2[3] = uVar6;
      puVar1 = (undefined4 *)(iVar11 * 0x20 + 0x10 + param_1);
      uVar4 = puVar1[1];
      uVar5 = puVar1[2];
      uVar6 = puVar1[3];
      puVar2 = (undefined4 *)(iVar12 + 0x10 + param_1);
      *puVar2 = *puVar1;
      puVar2[1] = uVar4;
      puVar2[2] = uVar5;
      puVar2[3] = uVar6;
    } while (iVar11 < iVar7);
  }
  if ((iVar11 == iVar7) && ((param_3 & 1) == 0)) {
    puVar2 = (undefined4 *)(param_3 * 0x20 + -0x20 + param_1);
    uVar4 = puVar2[1];
    uVar5 = puVar2[2];
    uVar6 = puVar2[3];
    puVar1 = (undefined4 *)(iVar11 * 0x20 + param_1);
    *puVar1 = *puVar2;
    puVar1[1] = uVar4;
    puVar1[2] = uVar5;
    puVar1[3] = uVar6;
    puVar1 = (undefined4 *)(param_3 * 0x20 + -0x10 + param_1);
    uVar4 = puVar1[1];
    uVar5 = puVar1[2];
    uVar6 = puVar1[3];
    puVar2 = (undefined4 *)(iVar11 * 0x20 + 0x10 + param_1);
    *puVar2 = *puVar1;
    puVar2[1] = uVar4;
    puVar2[2] = uVar5;
    puVar2[3] = uVar6;
    iVar11 = param_3 - 1;
  }
  while (param_2 < iVar11) {
    iVar8 = iVar11 + -1 >> 1;
    piVar10 = (int *)(iVar8 * 0x20 + param_1);
    iVar7 = FUN_008361f0(*(undefined4 *)(piVar10[1] * 0x278 + 0x260 + *(int *)(*piVar10 + 0x14)));
    iVar9 = FUN_008361f0(*(undefined4 *)(param_4[1] * 0x278 + 0x260 + *(int *)(*param_4 + 0x14)));
    if (*(int *)(iVar7 + 8) <= *(int *)(iVar9 + 8)) break;
    iVar7 = piVar10[1];
    iVar9 = piVar10[2];
    iVar12 = piVar10[3];
    piVar3 = (int *)(iVar11 * 0x20 + param_1);
    *piVar3 = *piVar10;
    piVar3[1] = iVar7;
    piVar3[2] = iVar9;
    piVar3[3] = iVar12;
    iVar7 = piVar10[5];
    iVar9 = piVar10[6];
    iVar12 = piVar10[7];
    piVar3 = (int *)(iVar11 * 0x20 + 0x10 + param_1);
    *piVar3 = piVar10[4];
    piVar3[1] = iVar7;
    piVar3[2] = iVar9;
    piVar3[3] = iVar12;
    iVar11 = iVar8;
  }
  iVar7 = param_4[1];
  iVar9 = param_4[2];
  iVar8 = param_4[3];
  piVar10 = (int *)(iVar11 * 0x20 + param_1);
  *piVar10 = *param_4;
  piVar10[1] = iVar7;
  piVar10[2] = iVar9;
  piVar10[3] = iVar8;
  iVar7 = param_4[5];
  iVar9 = param_4[6];
  iVar8 = param_4[7];
  piVar10 = (int *)(iVar11 * 0x20 + 0x10 + param_1);
  *piVar10 = param_4[4];
  piVar10[1] = iVar7;
  piVar10[2] = iVar9;
  piVar10[3] = iVar8;
  return;
}



/* FUNCTION 11501 ; VA 0x007a3ad0 ; FUN_007a3ad0 */

void FUN_007a3ad0(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  bool bVar10;
  bool bVar11;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  int *piStack_10;
  int *piStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2 - (int)param_1;
  piVar5 = param_2;
  iVar9 = param_3;
  do {
    iVar4 = iVar4 >> 2;
    if (iVar4 < 0x21) {
LAB_007a3b57:
      if (((1 < iVar4) && (param_1 != piVar5)) && (piStack_10 = param_1 + 1, piStack_10 != piVar5))
      {
        piStack_c = (int *)0x4;
        do {
          iVar4 = *piStack_10;
          fVar2 = *(float *)(iVar4 + 0x1cc);
          fVar3 = *(float *)(*param_1 + 0x1cc);
          if ((NAN(fVar2) || NAN(fVar3)) == (fVar2 == fVar3)) {
            bVar11 = fVar3 == fVar2;
            bVar10 = fVar3 < fVar2;
          }
          else {
            bVar11 = *(float *)(iVar4 + 0x224) == *(float *)(*param_1 + 0x224);
            bVar10 = *(float *)(iVar4 + 0x224) < *(float *)(*param_1 + 0x224);
          }
          piVar8 = piStack_10;
          if (bVar10 || bVar11) {
            while( true ) {
              iVar9 = piVar8[-1];
              fVar3 = *(float *)(iVar9 + 0x1cc);
              if ((NAN(fVar2) || NAN(fVar3)) == (fVar2 == fVar3)) {
                bVar11 = fVar3 == fVar2;
                bVar10 = fVar3 < fVar2;
              }
              else {
                bVar11 = *(float *)(iVar4 + 0x224) == *(float *)(iVar9 + 0x224);
                bVar10 = *(float *)(iVar4 + 0x224) < *(float *)(iVar9 + 0x224);
              }
              if (bVar10 || bVar11) break;
              *piVar8 = iVar9;
              piVar8 = piVar8 + -1;
            }
            *piVar8 = iVar4;
            piVar5 = param_2;
          }
          else {
            FUN_0170cc70(param_1 + 1,param_1,piStack_c);
            *param_1 = iVar4;
          }
          piStack_c = (int *)((int)piStack_c + 4);
          piStack_10 = piStack_10 + 1;
        } while (piStack_10 != piVar5);
      }
      return;
    }
    if (iVar9 < 1) {
      if (0x20 < iVar4) {
        iVar4 = (int)piVar5 - (int)param_1;
        uVar6 = iVar4 >> 2;
        piVar5 = (int *)(iVar4 >> 3);
        if (0 < (int)piVar5) {
          piStack_18 = (int *)(uVar6 - 1);
          piStack_c = (int *)((int)piStack_18 >> 1);
          do {
            iStack_8 = param_1[(int)piVar5 + -1];
            piVar5 = (int *)((int)piVar5 + -1);
            piVar8 = piVar5;
            while ((int)piVar8 < (int)piStack_c) {
              iStack_14 = (int)piVar8 * 2;
              fVar2 = *(float *)(param_1[(int)piVar8 * 2 + 1] + 0x1cc);
              fVar3 = *(float *)(param_1[(int)piVar8 * 2 + 2] + 0x1cc);
              if ((NAN(fVar3) || NAN(fVar2)) == (fVar3 == fVar2)) {
                bVar11 = fVar2 == fVar3;
                bVar10 = fVar2 < fVar3;
              }
              else {
                fVar2 = *(float *)(param_1[(int)piVar8 * 2 + 2] + 0x224);
                pfVar1 = (float *)(param_1[(int)piVar8 * 2 + 1] + 0x224);
                bVar11 = fVar2 == *pfVar1;
                bVar10 = fVar2 < *pfVar1;
              }
              piVar7 = (int *)(iStack_14 + 1 + ((!bVar10 && !bVar11) ^ 1));
              param_1[(int)piVar8] = param_1[(int)piVar7];
              piVar8 = piVar7;
            }
            if ((piVar8 == piStack_c) && ((uVar6 & 1) == 0)) {
              param_1[(int)piVar8] = param_1[uVar6 - 1];
              piVar8 = piStack_18;
            }
            if ((int)piVar5 < (int)piVar8) {
              fVar2 = *(float *)(iStack_8 + 0x1cc);
              do {
                piVar7 = (int *)((int)piVar8 + -1 >> 1);
                iVar9 = param_1[(int)piVar7];
                fVar3 = *(float *)(iVar9 + 0x1cc);
                if ((NAN(fVar3) || NAN(fVar2)) == (fVar3 == fVar2)) {
                  bVar11 = fVar2 == fVar3;
                  bVar10 = fVar2 < fVar3;
                }
                else {
                  bVar11 = *(float *)(iVar9 + 0x224) == *(float *)(iStack_8 + 0x224);
                  bVar10 = *(float *)(iVar9 + 0x224) < *(float *)(iStack_8 + 0x224);
                }
              } while ((!bVar10 && !bVar11) &&
                      (param_1[(int)piVar8] = iVar9, piVar8 = piVar7, (int)piVar5 < (int)piVar7));
            }
            param_1[(int)piVar8] = iStack_8;
          } while (0 < (int)piVar5);
        }
        piStack_10 = (int *)uVar6;
        if ((int)uVar6 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar6) {
            param_2 = *(int **)((int)param_1 + iVar4 + -4);
            *(int *)((int)param_1 + iVar4 + -4) = *param_1;
            FUN_007a3770(param_1,0,iVar4 + -4 >> 2,&param_2,param_4);
          }
          iVar4 = iVar4 + -4;
          uVar6 = iVar4 >> 2;
        } while (1 < (int)uVar6);
        return;
      }
      goto LAB_007a3b57;
    }
    FUN_007a2d00(&piStack_1c,param_1,piVar5,param_4);
    iVar9 = (iVar9 >> 1) + (iVar9 >> 2);
    if ((int)((int)piStack_1c - (int)param_1 & 0xfffffffcU) <
        (int)((int)piVar5 - (int)piStack_18 & 0xfffffffcU)) {
      FUN_007a3ad0(param_1,piStack_1c,iVar9,param_4);
      param_1 = piStack_18;
    }
    else {
      FUN_007a3ad0(piStack_18,piVar5,iVar9,param_4);
      param_2 = piStack_1c;
      piVar5 = piStack_1c;
    }
    iVar4 = (int)piVar5 - (int)param_1;
  } while( true );
}



/* FUNCTION 11502 ; VA 0x007a3dd0 ; FUN_007a3dd0 */

void FUN_007a3dd0(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  int *piVar9;
  int *piVar10;
  int iVar11;
  int *piVar12;
  int *piStack_14;
  int *piStack_10;
  int iStack_c;
  uint uStack_8;
  
  iVar5 = (int)param_2 - (int)param_1;
  piVar7 = param_2;
  piVar10 = param_1;
  iVar11 = param_3;
  do {
    iVar5 = iVar5 >> 2;
    if (iVar5 < 0x21) {
LAB_007a3e54:
      if (((1 < iVar5) && (piVar10 != piVar7)) && (piVar6 = piVar10 + 1, piVar6 != piVar7)) {
        param_1 = (int *)0x4;
        do {
          param_2 = (int *)*piVar6;
          fVar2 = *(float *)((int)param_2 + 0x1cc);
          if (*(float *)(*piVar10 + 0x1cc) <= fVar2) {
            iVar5 = *(int *)((int)param_1 + -4 + (int)piVar10);
            fVar3 = *(float *)(iVar5 + 0x1cc);
            piVar9 = (int *)((int)param_1 + -4 + (int)piVar10);
            piVar12 = piVar6;
            while (piVar4 = piVar9, fVar2 < fVar3) {
              *piVar12 = iVar5;
              iVar5 = piVar4[-1];
              piVar9 = piVar4 + -1;
              piVar12 = piVar4;
              fVar3 = *(float *)(iVar5 + 0x1cc);
            }
            *piVar12 = (int)param_2;
          }
          else {
            FUN_0170cc70(piVar10 + 1,piVar10,param_1);
            *piVar10 = (int)param_2;
          }
          piVar6 = piVar6 + 1;
          param_1 = (int *)((int)param_1 + 4);
        } while (piVar6 != piVar7);
      }
      return;
    }
    if (iVar11 < 1) {
      if (0x20 < iVar5) {
        iVar5 = (int)piVar7 - (int)piVar10;
        uVar8 = iVar5 >> 2;
        piVar7 = (int *)(iVar5 >> 3);
        if (0 < (int)piVar7) {
          piVar6 = (int *)((int)(uVar8 - 1) >> 1);
          do {
            iStack_c = piVar10[(int)piVar7 + -1];
            piVar7 = (int *)((int)piVar7 + -1);
            piVar12 = piVar7;
            while ((int)piVar12 < (int)piVar6) {
              piVar9 = (int *)((int)piVar12 * 2 +
                              ((*(float *)(piVar10[(int)piVar12 * 2 + 2] + 0x1cc) <=
                                *(float *)(piVar10[(int)piVar12 * 2 + 1] + 0x1cc) &&
                               *(float *)(piVar10[(int)piVar12 * 2 + 1] + 0x1cc) !=
                               *(float *)(piVar10[(int)piVar12 * 2 + 2] + 0x1cc)) ^ 1) + 1);
              piVar10[(int)piVar12] = piVar10[(int)piVar9];
              piVar12 = piVar9;
            }
            if ((piVar12 == piVar6) && ((uVar8 & 1) == 0)) {
              piVar10[(int)piVar12] = piVar10[uVar8 - 1];
              piVar12 = (int *)(uVar8 - 1);
            }
            if ((int)piVar7 < (int)piVar12) {
              fVar2 = *(float *)(iStack_c + 0x1cc);
              do {
                piVar9 = (int *)((int)piVar12 + -1 >> 1);
                pfVar1 = (float *)(piVar10[(int)piVar9] + 0x1cc);
                if (fVar2 < *pfVar1 || fVar2 == *pfVar1) break;
                piVar10[(int)piVar12] = piVar10[(int)piVar9];
                piVar12 = piVar9;
              } while ((int)piVar7 < (int)piVar9);
            }
            piVar10[(int)piVar12] = iStack_c;
            piStack_10 = piVar7;
          } while (0 < (int)piVar7);
        }
        uStack_8 = uVar8;
        if ((int)uVar8 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar8) {
            param_2 = *(int **)((int)piVar10 + iVar5 + -4);
            *(int *)((int)piVar10 + iVar5 + -4) = *piVar10;
            FUN_007a3870(piVar10,0,iVar5 + -4 >> 2,&param_2,param_4);
          }
          iVar5 = iVar5 + -4;
          uVar8 = iVar5 >> 2;
        } while (1 < (int)uVar8);
        return;
      }
      goto LAB_007a3e54;
    }
    FUN_007a3050(&piStack_14,piVar10,piVar7,param_4);
    iVar11 = (iVar11 >> 1) + (iVar11 >> 2);
    if ((int)((int)piStack_14 - (int)piVar10 & 0xfffffffcU) <
        (int)((int)piVar7 - (int)piStack_10 & 0xfffffffcU)) {
      FUN_007a3dd0(piVar10,piStack_14,iVar11,param_4);
      piVar10 = piStack_10;
    }
    else {
      FUN_007a3dd0(piStack_10,piVar7,iVar11,param_4);
      piVar7 = piStack_14;
    }
    iVar5 = (int)piVar7 - (int)piVar10;
  } while( true );
}



/* FUNCTION 11503 ; VA 0x007a4030 ; FUN_007a4030 */

void FUN_007a4030(int *param_1,int *param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_5;
  
  iVar2 = (int)param_2 - (int)param_1;
  piVar4 = param_2;
  piVar7 = param_1;
  do {
    iVar2 = iVar2 >> 5;
    if (iVar2 < 0x21) {
LAB_007a40ba:
      if (((1 < iVar2) && (piVar7 != piVar4)) && (piStack_20 = piVar7 + 8, piStack_20 != piVar4)) {
        iStack_c = param_4 + 0xd8;
        iStack_10 = 0x20;
        do {
          iStack_38 = *piStack_20;
          iStack_34 = piStack_20[1];
          iStack_30 = piStack_20[2];
          iStack_2c = piStack_20[3];
          iStack_48 = piStack_20[4];
          iStack_44 = piStack_20[5];
          iStack_40 = piStack_20[6];
          iStack_3c = piStack_20[7];
          iStack_1c = iStack_34 * 0x278;
          iStack_18 = iStack_38;
          piStack_14 = piStack_20;
          iVar2 = FUN_008361f0(*(undefined4 *)(*(int *)(iStack_38 + 0x14) + 0x260 + iStack_1c));
          iVar3 = FUN_008361f0(*(undefined4 *)(piVar7[1] * 0x278 + 0x260 + *(int *)(*piVar7 + 0x14))
                              );
          piStack_24 = (int *)(iStack_10 + 0x20 + (int)piVar7);
          if (*(int *)(iVar3 + 8) < *(int *)(iVar2 + 8)) {
            FUN_0055b6b0(&uStack_5,&piStack_24,&piStack_24);
            FUN_0170cc70(piVar7 + 8,piVar7,iStack_10);
            *piVar7 = iStack_38;
            piVar7[1] = iStack_34;
            piVar7[2] = iStack_30;
            piVar7[3] = iStack_2c;
            piVar7[4] = iStack_48;
            piVar7[5] = iStack_44;
            piVar7[6] = iStack_40;
            piVar7[7] = iStack_3c;
          }
          else {
            piVar4 = (int *)(iStack_10 + -0x20 + (int)piVar7);
            iVar2 = FUN_008361f0(*(undefined4 *)(*(int *)(iStack_18 + 0x14) + 0x260 + iStack_1c));
            iVar3 = FUN_008361f0(*(undefined4 *)
                                  (piStack_24[-0xf] * 0x278 + 0x260 + *(int *)(*piVar4 + 0x14)));
            piVar6 = piStack_14;
            piVar5 = piStack_14;
            if (*(int *)(iVar3 + 8) < *(int *)(iVar2 + 8)) {
              do {
                piVar5 = piVar4;
                iVar2 = piVar5[1];
                iVar3 = piVar5[2];
                iVar1 = piVar5[3];
                *piVar6 = *piVar5;
                piVar6[1] = iVar2;
                piVar6[2] = iVar3;
                piVar6[3] = iVar1;
                iVar2 = piVar5[5];
                iVar3 = piVar5[6];
                iVar1 = piVar5[7];
                piVar6[4] = piVar5[4];
                piVar6[5] = iVar2;
                piVar6[6] = iVar3;
                piVar6[7] = iVar1;
                iVar2 = FUN_008361f0(*(undefined4 *)(*(int *)(iStack_18 + 0x14) + 0x260 + iStack_1c)
                                    );
                iVar3 = FUN_008361f0(*(undefined4 *)
                                      (piVar5[-7] * 0x278 + 0x260 + *(int *)(piVar5[-8] + 0x14)));
                piVar4 = piVar5 + -8;
                piVar7 = param_1;
                piVar6 = piVar5;
              } while (*(int *)(iVar3 + 8) < *(int *)(iVar2 + 8));
            }
            piStack_14 = piVar5;
            *piStack_14 = iStack_38;
            piStack_14[1] = iStack_34;
            piStack_14[2] = iStack_30;
            piStack_14[3] = iStack_2c;
            piStack_14[4] = iStack_48;
            piStack_14[5] = iStack_44;
            piStack_14[6] = iStack_40;
            piStack_14[7] = iStack_3c;
            piVar4 = param_2;
          }
          iStack_10 = iStack_10 + 0x20;
          piStack_20 = piStack_20 + 8;
        } while (piStack_20 != piVar4);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar2) {
        FUN_007a2930(piVar7,piVar4,param_4);
        if ((int)piVar4 - (int)piVar7 >> 5 < 2) {
          return;
        }
        piVar4 = piVar4 + -8;
        do {
          iStack_58 = *piVar4;
          iStack_54 = piVar4[1];
          iStack_50 = piVar4[2];
          iStack_4c = piVar4[3];
          iStack_48 = piVar4[4];
          iStack_44 = piVar4[5];
          iStack_40 = piVar4[6];
          iStack_3c = piVar4[7];
          iVar2 = piVar7[1];
          iVar3 = piVar7[2];
          iVar1 = piVar7[3];
          *piVar4 = *piVar7;
          piVar4[1] = iVar2;
          piVar4[2] = iVar3;
          piVar4[3] = iVar1;
          iVar2 = piVar7[5];
          iVar3 = piVar7[6];
          iVar1 = piVar7[7];
          piVar4[4] = piVar7[4];
          piVar4[5] = iVar2;
          piVar4[6] = iVar3;
          piVar4[7] = iVar1;
          FUN_007a3930(piVar7,0,(int)piVar4 - (int)piVar7 >> 5,&iStack_58,param_4);
          piVar4 = piVar4 + -8;
        } while (1 < (int)piVar4 + (0x20 - (int)piVar7) >> 5);
        return;
      }
      goto LAB_007a40ba;
    }
    FUN_007a3220(&piStack_28,piVar7,piVar4,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)piStack_28 - (int)piVar7 & 0xffffffe0U) <
        (int)((int)piVar4 - (int)piStack_24 & 0xffffffe0U)) {
      FUN_007a4030(piVar7,piStack_28,param_3,param_4);
      param_1 = piStack_24;
      piVar7 = piStack_24;
    }
    else {
      FUN_007a4030(piStack_24,piVar4,param_3,param_4);
      param_2 = piStack_28;
      piVar4 = piStack_28;
    }
    iVar2 = (int)piVar4 - (int)piVar7;
  } while( true );
}



/* FUNCTION 11504 ; VA 0x007a42f0 ; FUN_007a42f0 */

void __thiscall FUN_007a42f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    return;
  }
  FUN_0063d9b0(puVar1,param_2);
  return;
}



/* FUNCTION 11505 ; VA 0x007a4320 ; FUN_007a4320 */

void FUN_007a4320(undefined4 *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  byte bVar5;
  bool bVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  int iStack_18;
  int *piStack_c;
  
  piStack_c = param_2;
  if (param_2 != param_3) {
    do {
      iVar1 = *piStack_c;
      bVar6 = true;
      iVar3 = (*(int *)(iVar1 + 0x18) - *(int *)(iVar1 + 0x14)) / 0x278;
      if (iVar3 != 0) {
        iVar7 = 0;
        iVar8 = iVar3;
        do {
          iVar2 = *(int *)(iVar1 + 0x14);
          cVar4 = FUN_008363a0(*(undefined4 *)(iVar2 + 0x260 + iVar7));
          if ((cVar4 != '\0') || (bVar5 = 0, *(int *)(iVar2 + iVar7) == 0)) {
            bVar5 = 1;
          }
          iVar7 = iVar7 + 0x278;
          bVar6 = (bool)(bVar6 & bVar5);
          iVar8 = iVar8 + -1;
        } while (iVar8 != 0);
        if (!bVar6) goto LAB_007a43cd;
      }
      if ((iVar3 == 0) || (piStack_c = piStack_c + 1, piStack_c == param_3)) goto LAB_007a43cd;
    } while( true );
  }
  goto LAB_007a4490;
LAB_007a43cd:
  param_2 = piStack_c;
  if ((piStack_c != param_3) && (piVar9 = piStack_c + 1, piVar9 != param_3)) {
    do {
      iVar1 = *piVar9;
      bVar6 = true;
      iVar3 = (*(int *)(iVar1 + 0x18) - *(int *)(iVar1 + 0x14)) / 0x278;
      if (iVar3 == 0) {
LAB_007a4462:
        if (iVar3 != 0) {
          *piStack_c = *piVar9;
          piStack_c = piStack_c + 1;
        }
      }
      else {
        iVar8 = 0;
        iStack_18 = iVar3;
        do {
          iVar7 = *(int *)(iVar1 + 0x14);
          cVar4 = FUN_008363a0(*(undefined4 *)(iVar7 + 0x260 + iVar8));
          if ((cVar4 != '\0') || (bVar5 = 0, *(int *)(iVar7 + iVar8) == 0)) {
            bVar5 = 1;
          }
          bVar6 = (bool)(bVar6 & bVar5);
          iVar8 = iVar8 + 0x278;
          iStack_18 = iStack_18 + -1;
        } while (iStack_18 != 0);
        if (bVar6) goto LAB_007a4462;
      }
      piVar9 = piVar9 + 1;
      if (piVar9 == param_3) {
        *param_1 = piStack_c;
        return;
      }
    } while( true );
  }
LAB_007a4490:
  *param_1 = param_2;
  return;
}



/* FUNCTION 11506 ; VA 0x007a44a0 ; FUN_007a44a0 */

undefined4 * __fastcall FUN_007a44a0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  return param_1;
}



/* FUNCTION 11507 ; VA 0x007a44d0 ; FUN_007a44d0 */

undefined4 __fastcall FUN_007a44d0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = 6;
  do {
    FUN_01165ab0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return param_1;
}



/* FUNCTION 11508 ; VA 0x007a4500 ; FUN_007a4500 */

undefined4 * __thiscall
FUN_007a4500(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b2576;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::Shadows::ShadowMapSystemImpl::vftable;
  param_1[1] = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_3;
  param_1[3] = param_3[1];
  uStack_8 = 1;
  uStack_7 = 0;
  param_1[4] = 0x42c80000;
  param_1[5] = 0x3dcccccd;
  param_1[6] = 0xffffffff;
  FUN_007f6300();
  uStack_8 = 2;
  FUN_00835540();
  uStack_8 = 3;
  FUN_007a4b30(param_2);
  uStack_8 = 4;
  FUN_00835540();
  param_1[0x80170] = 0;
  param_1[0x80171] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80170] = *param_4;
  param_1[0x80171] = param_4[1];
  param_1[0x80172] = 0;
  param_1[0x80173] = 0;
  if (param_4[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80172] = param_4[2];
  param_1[0x80173] = param_4[3];
  param_1[0x80174] = 0;
  param_1[0x80175] = 0;
  if (param_4[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80174] = param_4[4];
  param_1[0x80175] = param_4[5];
  param_1[0x80176] = 0;
  param_1[0x80177] = 0;
  if (param_4[7] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[7] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80176] = param_4[6];
  param_1[0x80177] = param_4[7];
  param_1[0x80178] = 0;
  param_1[0x80179] = 0;
  if (param_4[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80178] = param_4[8];
  param_1[0x80179] = param_4[9];
  param_1[0x8017a] = 0;
  param_1[0x8017b] = 0;
  if (param_4[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x8017a] = param_4[10];
  param_1[0x8017b] = param_4[0xb];
  param_1[0x8017c] = 0;
  param_1[0x8017d] = 0;
  if (param_4[0xd] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0xd] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x8017c] = param_4[0xc];
  param_1[0x8017d] = param_4[0xd];
  param_1[0x8017e] = 0;
  param_1[0x8017f] = 0;
  if (param_4[0xf] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0xf] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x8017e] = param_4[0xe];
  param_1[0x8017f] = param_4[0xf];
  param_1[0x80180] = 0;
  param_1[0x80181] = 0;
  if (param_4[0x11] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0x11] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80180] = param_4[0x10];
  param_1[0x80181] = param_4[0x11];
  param_1[0x80182] = 0;
  param_1[0x80183] = 0;
  if (param_4[0x13] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0x13] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80182] = param_4[0x12];
  param_1[0x80183] = param_4[0x13];
  param_1[0x80184] = 0;
  param_1[0x80185] = 0;
  if (param_4[0x15] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0x15] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80184] = param_4[0x14];
  param_1[0x80185] = param_4[0x15];
  param_1[0x80186] = 0;
  param_1[0x80187] = 0;
  if (param_4[0x17] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[0x17] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x80186] = param_4[0x16];
  param_1[0x80187] = param_4[0x17];
  param_1[0x80188] = 0;
  *(undefined *)((int)param_1 + 0x200626) = 1;
  param_1[0x8018a] = 0;
  param_1[0x8018b] = 0;
  param_1[0x8018c] = 0;
  param_1[0x8018d] = 0;
  param_1[0x8018e] = 0;
  param_1[0x8018f] = 0;
  param_1[0x80190] = 0;
  param_1[0x80191] = 0;
  param_1[0x80192] = 0;
  param_1[0x80193] = 0;
  param_1[0x80194] = 0;
  param_1[0x80195] = 0;
  param_1[0x80196] = 0;
  param_1[0x80197] = 0;
  param_1[0x80198] = 0;
  param_1[0x80199] = 0;
  param_1[0x8019a] = 0;
  param_1[0x8019b] = 0;
  param_1[0x8019c] = 0;
  param_1[0x8019d] = 0;
  param_1[0x8019e] = 0;
  param_1[0x8019f] = 0;
  param_1[0x801a0] = 0;
  param_1[0x801a1] = 0;
  uStack_8 = 0x1a;
  param_1[0x801a2] = 0;
  param_1[0x801a3] = 0;
  param_1[0x801a4] = 0;
  FUN_007cc9d0();
  param_1[0x80236] = 0;
  param_1[0x80238] = 0;
  param_1[0x8023a] = 0;
  param_1[0x8023b] = 0x1010000;
  *(undefined2 *)(param_1 + 0x8023c) = 0x101;
  param_1[0x8023d] = 0;
  param_1[0x8023e] = 0;
  *(undefined2 *)(param_1 + 0x8023f) = 0;
  *(undefined *)((int)param_1 + 0x2008fe) = 0;
  param_1[0x80240] = 0;
  param_1[0x80241] = 0;
  *(undefined2 *)(param_1 + 0x80242) = 0;
  *(undefined *)((int)param_1 + 0x20090a) = 0;
  param_1[0x80243] = 0;
  param_1[0x80244] = 0x1000000;
  param_1[0x80245] = 0x1010101;
  *(undefined2 *)(param_1 + 0x80246) = 0;
  *(undefined *)((int)param_1 + 0x20091a) = 0;
  param_1[0x80247] = 0;
  *(undefined2 *)(param_1 + 0x80248) = 0;
  param_1[0x80249] = 0x40800000;
  uStack_8 = 0x1c;
  FUN_016f4053(param_1 + 0x8024a,0xc,0x800,FUN_00569440,FUN_0056d320);
  uStack_8 = 0x1d;
  param_1[0x81a62] = 0;
  param_1[0x81a64] = 0;
  param_1[0x81a83] = 0;
  param_1[0x81a85] = 0;
  param_1[0x81aa4] = 0;
  param_1[0x81aa6] = 0;
  param_1[0x81ac5] = 0;
  param_1[0x81ac7] = 0;
  FUN_00836210(*(undefined4 *)(param_1[0x80174] + 0x30),*(undefined4 *)(param_1[0x80174] + 0x34));
  FUN_00836210(*(undefined4 *)(param_1[0x8017a] + 0x28),*(undefined4 *)(param_1[0x8017a] + 0x2c));
  iVar3 = (**(code **)(**(int **)(param_1[1] + 0x3c) + 0x40))();
  *(undefined *)((int)param_1 + 0x200625) = *(undefined *)(iVar3 + 10);
  iVar3 = FUN_01674e20(0x4f3a8);
  _uStack_8 = CONCAT31(uStack_7,0x1e);
  if (iVar3 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0083c350();
  }
  puVar2 = (undefined4 *)param_1[0x80188];
  param_1[0x80188] = uVar4;
  if (puVar2 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  *(undefined *)(param_1 + 0x80189) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11509 ; VA 0x007a4af0 ; FUN_007a4af0 */

undefined8 * __thiscall FUN_007a4af0(undefined8 *param_1,undefined8 *param_2,undefined4 param_3)

{
  *(undefined4 *)param_1 = 0;
  *(undefined4 *)((int)param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
  *(undefined4 *)((int)param_1 + 0xc) = param_3;
  return param_1;
}



/* FUNCTION 11510 ; VA 0x007a4b30 ; FUN_007a4b30 */

int * __thiscall FUN_007a4b30(int *param_1,int param_2)

{
  int *piVar1;
  short sVar2;
  float fVar3;
  int *piVar4;
  int *piVar5;
  undefined8 *puVar6;
  short *psVar7;
  int iVar8;
  int iVar9;
  float fVar10;
  undefined auStack_64 [20];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b25ac;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  piStack_18 = param_1 + 1;
  *piStack_18 = 0;
  param_1[2] = 0;
  piStack_14 = param_1 + 3;
  *piStack_14 = 0;
  param_1[4] = 0;
  piStack_1c = param_1 + 5;
  *piStack_1c = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  iVar8 = 0x41;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  uStack_8 = 3;
  param_1[0xd] = 1;
  piStack_20 = param_1;
  do {
    FUN_0060f2c0();
    iVar8 = iVar8 + -1;
  } while (iVar8 != 0);
  piVar5 = *(int **)(param_2 + 0x3c);
  FUN_0147c5c0(0,0,2,0,0);
  piVar4 = (int *)(**(code **)(*piVar5 + 0x3c))(&uStack_28,0,0xc00,0xc,0);
  iVar8 = *piVar4;
  iVar9 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  param_1[1] = iVar8;
  piVar4 = (int *)param_1[2];
  param_1[2] = iVar9;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar8 = piVar4[1] + -1;
    piVar4[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar8 = piVar4[2] + -1;
      piVar4[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar5 = (int *)(**(code **)(*piVar5 + 0x3c))(&uStack_28,1,0x300,2,0);
  iVar8 = *piVar5;
  iVar9 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[3] = iVar8;
  piVar5 = (int *)param_1[4];
  param_1[4] = iVar9;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = piStack_24[2] + -1;
      piStack_24[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  iVar8 = (**(code **)(*(int *)*piStack_14 + 0x10))();
  puVar6 = (undefined8 *)(**(code **)(*(int *)*piStack_18 + 0x10))();
  fVar3 = DAT_018ce2f8;
  iVar9 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  psVar7 = (short *)(iVar8 + 4);
  uStack_38 = 0x3f800000;
  uStack_34 = 0;
  uStack_44 = 0;
  uStack_40 = 0x3f800000;
  uStack_50 = 0x3f800000;
  uStack_4c = 0x3f800000;
  do {
    sVar2 = (short)iVar9 * 4;
    fVar10 = (float)iVar9;
    iVar9 = iVar9 + 1;
    *puVar6 = 0;
    piStack_48 = (int *)(fVar10 + fVar3);
    *(int **)(puVar6 + 1) = piStack_48;
    *(undefined8 *)((int)puVar6 + 0xc) = 0x3f800000;
    *(int **)((int)puVar6 + 0x14) = piStack_48;
    puVar6[3] = 0x3f80000000000000;
    *(int **)(puVar6 + 4) = piStack_48;
    *(undefined8 *)((int)puVar6 + 0x24) = 0x3f8000003f800000;
    *(int **)((int)puVar6 + 0x2c) = piStack_48;
    *psVar7 = sVar2 + 2;
    puVar6 = puVar6 + 6;
    psVar7[1] = sVar2 + 2;
    psVar7[-2] = sVar2;
    psVar7[-1] = sVar2 + 1;
    psVar7[2] = sVar2 + 1;
    psVar7[3] = sVar2 + 3;
    psVar7 = psVar7 + 6;
  } while (iVar9 < 0x40);
  piStack_3c = piStack_48;
  piStack_30 = piStack_48;
  piStack_24 = piStack_48;
  (**(code **)(*(int *)*piStack_14 + 0x14))();
  (**(code **)(*(int *)*piStack_18 + 0x14))();
  piVar5 = (int *)FUN_0147c1b0(&uStack_28,auStack_64,1,0xc);
  piVar4 = piStack_20;
  iVar8 = *piVar5;
  iVar9 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  *piStack_1c = iVar8;
  piVar5 = (int *)piStack_1c[1];
  piStack_1c[1] = iVar9;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = (int *)FUN_0147c0e0(&uStack_28,piVar4 + 5,piVar4 + 1,piVar4 + 3);
  iVar8 = *piVar5;
  iVar9 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar4[7] = iVar8;
  piVar5 = (int *)piVar4[8];
  piVar4[8] = iVar9;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 11511 ; VA 0x007a4f00 ; FUN_007a4f00 */

void __fastcall FUN_007a4f00(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 4,0xc,0x800,FUN_0056d320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11512 ; VA 0x007a4f50 ; FUN_007a4f50 */

void __fastcall FUN_007a4f50(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11513 ; VA 0x007a4fb0 ; FUN_007a4fb0 */

void __fastcall FUN_007a4fb0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x5c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x54);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x4c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x44);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x3c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x34);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x007a517f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11514 ; VA 0x007a5190 ; FUN_007a5190 */

void __fastcall FUN_007a5190(undefined4 *param_1)

{
  *param_1 = RBX::Graphics::Shadows::ShadowMapSystem::vftable;
  return;
}



/* FUNCTION 11515 ; VA 0x007a51a0 ; FUN_007a51a0 */

int __fastcall FUN_007a51a0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 0x8024a,0xc,0x800,FUN_0056d320);
  iVar4 = param_1[0x8019f];
  uStack_8 = 0xffffffff;
  if (iVar4 != 0) {
    uVar5 = (param_1[0x801a1] - iVar4 >> 2) * 4;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x8019f] = 0;
    param_1[0x801a0] = 0;
    param_1[0x801a1] = 0;
  }
  iVar4 = param_1[0x8019c];
  if (iVar4 != 0) {
    uVar5 = (param_1[0x8019e] - iVar4 >> 2) * 4;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x8019c] = 0;
    param_1[0x8019d] = 0;
    param_1[0x8019e] = 0;
  }
  iVar4 = param_1[0x80199];
  if (iVar4 != 0) {
    uVar5 = (param_1[0x8019b] - iVar4 >> 3) * 8;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x80199] = 0;
    param_1[0x8019a] = 0;
    param_1[0x8019b] = 0;
  }
  iVar4 = param_1[0x80196];
  if (iVar4 != 0) {
    uVar5 = param_1[0x80198] - iVar4 & 0xfffffff0;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x80196] = 0;
    param_1[0x80197] = 0;
    param_1[0x80198] = 0;
  }
  iVar4 = param_1[0x80193];
  if (iVar4 != 0) {
    uVar5 = param_1[0x80195] - iVar4 & 0xffffffe0;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x80193] = 0;
    param_1[0x80194] = 0;
    param_1[0x80195] = 0;
  }
  iVar4 = param_1[0x80190];
  if (iVar4 != 0) {
    uVar5 = (param_1[0x80192] - iVar4 >> 2) * 4;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x80190] = 0;
    param_1[0x80191] = 0;
    param_1[0x80192] = 0;
  }
  iVar4 = param_1[0x8018d];
  if (iVar4 != 0) {
    uVar5 = (param_1[0x8018f] - iVar4 >> 2) * 4;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007a575a;
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x8018d] = 0;
    param_1[0x8018e] = 0;
    param_1[0x8018f] = 0;
  }
  iVar4 = param_1[0x8018a];
  if (iVar4 != 0) {
    uVar5 = (param_1[0x8018c] - iVar4 >> 2) * 4;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) {
LAB_007a575a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
    param_1[0x8018a] = 0;
    param_1[0x8018b] = 0;
    param_1[0x8018c] = 0;
  }
  if ((undefined4 *)param_1[0x80188] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x80188])(1);
  }
  piVar2 = (int *)param_1[0x80187];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80185];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80183];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80181];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x8017f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x8017d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x8017b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80179];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80177];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80175];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80173];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x80171];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00835870();
  FUN_007a5760();
  FUN_00835870();
  uStack_8 = 1;
  iVar4 = FUN_016f32d1(param_1 + 7,0xc,0xf,FUN_00612d60);
  piVar2 = (int *)param_1[3];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Graphics::Shadows::ShadowMapSystem::vftable;
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 11516 ; VA 0x007a5760 ; FUN_007a5760 */

void __fastcall FUN_007a5760(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x007a57ff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11517 ; VA 0x007a5810 ; FUN_007a5810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a5810(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b25cc;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2620;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2630) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2630);
    uVar1 = CONCAT44(_DAT_01eb2624,_DAT_01eb2620);
    if (DAT_01eb2630 == -1) {
      uStack_8 = 0;
      _DAT_01eb2618 = FUN_0152dab0("ShadowMap","Id_OpaqueCasters",0xffffffff);
      _DAT_01eb2620 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueCasters",0xffffffff);
      DAT_01eb2628._0_1_ = 0;
      FUN_016f37bf(&DAT_01eb2630);
      uVar1 = _DAT_01eb2620;
    }
  }
  _DAT_01eb2620 = uVar1;
  *param_1 = _DAT_01eb2618;
  param_1[1] = uVar1;
  param_1[2] = CONCAT71(DAT_01eb2628._1_7_,(undefined)DAT_01eb2628);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11518 ; VA 0x007a58e0 ; FUN_007a58e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a58e0(undefined8 *param_1)

{
  char cVar1;
  undefined8 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b25ec;
  pvStack_10 = ExceptionList;
  uVar2 = _DAT_01eb26a0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb26b0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb26b0);
    cVar1 = DAT_01d7ad48;
    uVar2 = CONCAT44(_DAT_01eb26a4,_DAT_01eb26a0);
    if (DAT_01eb26b0 == -1) {
      uStack_8 = 0;
      uVar2 = FUN_0152dab0("ShadowMap","Id_Transparent",0xffffffff);
      if ((cVar1 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar2);
      }
      _DAT_01eb2698 = uVar2;
      _DAT_01eb26a0 = FUN_0152dab0(&DAT_018fb928,"Id_Transparent",0xffffffff);
      DAT_01eb26a8._0_1_ = DAT_01d7ad48;
      FUN_016f37bf(&DAT_01eb26b0);
      uVar2 = _DAT_01eb26a0;
    }
  }
  _DAT_01eb26a0 = uVar2;
  *param_1 = _DAT_01eb2698;
  param_1[1] = uVar2;
  param_1[2] = CONCAT71(DAT_01eb26a8._1_7_,(char)DAT_01eb26a8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11519 ; VA 0x007a59e0 ; FUN_007a59e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a59e0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b260c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2680;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2690) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2690);
    uVar1 = CONCAT44(_DAT_01eb2684,_DAT_01eb2680);
    if (DAT_01eb2690 == -1) {
      uStack_8 = 0;
      _DAT_01eb2678 = FUN_0152dab0("ShadowMap","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb2680 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      DAT_01eb2688._0_1_ = 0;
      FUN_016f37bf(&DAT_01eb2690);
      uVar1 = _DAT_01eb2680;
    }
  }
  _DAT_01eb2680 = uVar1;
  *param_1 = _DAT_01eb2678;
  param_1[1] = uVar1;
  param_1[2] = CONCAT71(DAT_01eb2688._1_7_,(undefined)DAT_01eb2688);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11520 ; VA 0x007a5ab0 ; FUN_007a5ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a5ab0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b262c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb26c0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb26d0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb26d0);
    uVar1 = CONCAT44(_DAT_01eb26c4,_DAT_01eb26c0);
    if (DAT_01eb26d0 == -1) {
      uStack_8 = 0;
      _DAT_01eb26b8 = FUN_0152dab0("ShadowMap","Id_TransparentCasters",0xffffffff);
      _DAT_01eb26c0 = FUN_0152dab0(&DAT_018fb928,"Id_TransparentCasters",0xffffffff);
      DAT_01eb26c8._0_1_ = 0;
      FUN_016f37bf(&DAT_01eb26d0);
      uVar1 = _DAT_01eb26c0;
    }
  }
  _DAT_01eb26c0 = uVar1;
  *param_1 = _DAT_01eb26b8;
  param_1[1] = uVar1;
  param_1[2] = CONCAT71(DAT_01eb26c8._1_7_,(undefined)DAT_01eb26c8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11521 ; VA 0x007a5b80 ; FUN_007a5b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a5b80(undefined8 *param_1)

{
  char cVar1;
  undefined8 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b264c;
  pvStack_10 = ExceptionList;
  uVar2 = _DAT_01eb2600;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2610) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2610);
    cVar1 = DAT_01d7ad48;
    uVar2 = CONCAT44(_DAT_01eb2604,_DAT_01eb2600);
    if (DAT_01eb2610 == -1) {
      uStack_8 = 0;
      uVar2 = FUN_0152dab0("ShadowMap","Id_Opaque",0xffffffff);
      if ((cVar1 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar2);
      }
      _DAT_01eb25f8 = uVar2;
      _DAT_01eb2600 = FUN_0152dab0(&DAT_018fb928,"Id_Opaque",0xffffffff);
      DAT_01eb2608._0_1_ = DAT_01d7ad48;
      FUN_016f37bf(&DAT_01eb2610);
      uVar2 = _DAT_01eb2600;
    }
  }
  _DAT_01eb2600 = uVar2;
  *param_1 = _DAT_01eb25f8;
  param_1[1] = uVar2;
  param_1[2] = CONCAT71(DAT_01eb2608._1_7_,(char)DAT_01eb2608);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11522 ; VA 0x007a5c80 ; FUN_007a5c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a5c80(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b266c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2640;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2650) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2650);
    uVar1 = CONCAT44(_DAT_01eb2644,_DAT_01eb2640);
    if (DAT_01eb2650 == -1) {
      uStack_8 = 0;
      _DAT_01eb2638 = FUN_0152dab0("ShadowMap","Id_Terrain",0xffffffff);
      _DAT_01eb2640 = FUN_0152dab0(&DAT_018fb928,"Id_Terrain",0xffffffff);
      DAT_01eb2648._0_1_ = 0;
      FUN_016f37bf(&DAT_01eb2650);
      uVar1 = _DAT_01eb2640;
    }
  }
  _DAT_01eb2640 = uVar1;
  *param_1 = _DAT_01eb2638;
  param_1[1] = uVar1;
  param_1[2] = CONCAT71(DAT_01eb2648._1_7_,(undefined)DAT_01eb2648);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11523 ; VA 0x007a5d50 ; FUN_007a5d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007a5d50(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b268c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2660;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2670) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2670);
    uVar1 = CONCAT44(_DAT_01eb2664,_DAT_01eb2660);
    if (DAT_01eb2670 == -1) {
      uStack_8 = 0;
      _DAT_01eb2658 = FUN_0152dab0("ShadowMap","Id_Glass",0xffffffff);
      _DAT_01eb2660 = FUN_0152dab0(&DAT_018fb928,"Id_Glass",0xffffffff);
      DAT_01eb2668._0_1_ = 0;
      FUN_016f37bf(&DAT_01eb2670);
      uVar1 = _DAT_01eb2660;
    }
  }
  _DAT_01eb2660 = uVar1;
  *param_1 = _DAT_01eb2658;
  param_1[1] = uVar1;
  param_1[2] = CONCAT71(DAT_01eb2668._1_7_,(undefined)DAT_01eb2668);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11524 ; VA 0x007a5e20 ; FUN_007a5e20 */

bool FUN_007a5e20(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_008361f0(*(undefined4 *)(param_1[1] * 0x278 + 0x260 + *(int *)(*param_1 + 0x14)));
  iVar2 = FUN_008361f0(*(undefined4 *)(param_2[1] * 0x278 + 0x260 + *(int *)(*param_2 + 0x14)));
  return *(int *)(iVar2 + 8) < *(int *)(iVar1 + 8);
}



/* FUNCTION 11525 ; VA 0x007a5e80 ; FUN_007a5e80 */

undefined4 * __thiscall FUN_007a5e80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::Shadows::ShadowMapSystem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 11526 ; VA 0x007a5eb0 ; FUN_007a5eb0 */

undefined4 __thiscall FUN_007a5eb0(undefined4 param_1,byte param_2)

{
  FUN_007a51a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x206b38);
  }
  return param_1;
}



/* FUNCTION 11527 ; VA 0x007a5ee0 ; FUN_007a5ee0 */

int FUN_007a5ee0(int param_1,int param_2,int param_3)

{
  undefined auStack_c [7];
  undefined uStack_5;
  
  FUN_0055b6b0(&uStack_5,auStack_c,auStack_c);
  FUN_0170cc70(param_3,param_1,param_2 - param_1);
  return (param_2 - param_1) + param_3;
}



/* FUNCTION 11528 ; VA 0x007a5f20 ; FUN_007a5f20 */

void FUN_007a5f20(int param_1,int param_2,undefined4 param_3)

{
  undefined auStack_c [7];
  undefined uStack_5;
  
  FUN_0055b6b0(&uStack_5,auStack_c,auStack_c);
  FUN_0170cc70(param_3,param_1,param_2 - param_1);
  return;
}



/* FUNCTION 11529 ; VA 0x007a5f60 ; FUN_007a5f60 */

void __fastcall FUN_007a5f60(int param_1)

{
  int iVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined4 *puVar5;
  float *pfVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  int *piVar10;
  float fVar11;
  double dVar12;
  undefined8 uVar13;
  undefined auStack_c4 [16];
  undefined auStack_b4 [12];
  float fStack_a8;
  int *piStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [4];
  int *piStack_90;
  int *piStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  int iStack_78;
  int *piStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  int *piStack_64;
  int *piStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  uint uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b26df;
  pvStack_10 = ExceptionList;
  piVar10 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_40 = param_1;
  piStack_30 = piVar10;
  if ((piVar10[0xd] < DAT_01eb2730) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2730), DAT_01eb2730 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("ShadowMap","allocateAndBuildViewports",0xffffffff);
    DAT_01eb272c = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb2728 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2730);
  }
  uStack_54 = DAT_01eb2728;
  uStack_88 = DAT_01eb2728;
  uStack_68 = DAT_01eb272c;
  uStack_84 = DAT_01eb272c;
  uStack_80 = FUN_0152d930(DAT_01eb2728,DAT_01eb272c);
  uStack_8 = 1;
  if (DAT_01d6104c != '\0') {
    if (piVar10[0xd] < DAT_01eb2740) {
      FUN_016f3809(&DAT_01eb2740);
      if (DAT_01eb2740 == -1) {
        uStack_8._0_1_ = 2;
        uVar13 = FUN_0152dab0("Shadows","Priority sort throttling",0xffffffff);
        DAT_01eb273c = (int *)((ulonglong)uVar13 >> 0x20);
        DAT_01eb2738 = (int)uVar13;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb2740);
      }
    }
    piStack_44 = (int *)DAT_01eb2738;
    iStack_78 = DAT_01eb2738;
    piStack_34 = DAT_01eb273c;
    piStack_74 = DAT_01eb273c;
    uStack_70 = FUN_0152d930(DAT_01eb2738,DAT_01eb273c);
    piVar10 = *(int **)(param_1 + 0x200640);
    piStack_48 = *(int **)(param_1 + 0x200644);
    uStack_38 = *(int *)(param_1 + 0x20068c);
    uStack_8._0_1_ = 3;
    piStack_28 = piVar10;
    if (piVar10 != piStack_48) {
      do {
        piStack_20 = (int *)*piStack_28;
        bStack_11 = 1;
        piStack_4c = (int *)(uStack_38 - piStack_20[0x74]);
        piStack_2c = (int *)piStack_20[0x73];
        piStack_18 = (int *)DAT_018ce2f8;
        piStack_1c = (int *)((piStack_20[6] - piStack_20[5]) / 0x278);
        if (piStack_1c != (int *)0x0) {
          piStack_24 = (int *)(param_1 + 0xd8);
          iVar7 = 0;
          do {
            piVar10 = (int *)(piStack_20[5] + iVar7);
            cVar2 = FUN_008363a0(piVar10[0x98]);
            if ((cVar2 == '\0') && (*piVar10 != 0)) {
              piStack_18 = (int *)DAT_018e452c;
            }
            cVar2 = FUN_008363a0(piVar10[0x98]);
            if ((cVar2 == '\0') || (*piVar10 != 2)) {
              bVar3 = 0;
            }
            else {
              bVar3 = 1;
            }
            bStack_11 = bStack_11 & bVar3;
            iVar7 = iVar7 + 0x278;
            piStack_1c = (int *)((int)piStack_1c + -1);
          } while (piStack_1c != (int *)0x0);
          piStack_1c = (int *)0x0;
          param_1 = iStack_40;
        }
        piVar9 = piStack_20;
        piStack_18 = (int *)((float)piStack_18 * (float)piStack_2c);
        dVar12 = (double)ZEXT48(piStack_18);
        FUN_016f4020();
        piVar10 = (int *)((float)piStack_18 / ((float)dVar12 + DAT_018ce2f8));
        if (bStack_11 != 0) {
          piStack_18 = DAT_018fe4b4;
          (**(code **)(*piVar9 + 0x18))(uStack_38);
          piVar10 = piStack_18;
        }
        if (piVar9[0x75] == 3) {
          piVar10 = (int *)0x0;
        }
        piStack_28 = piStack_28 + 1;
        piVar9[0x73] = (int)piVar10;
      } while (piStack_28 != piStack_48);
      piVar10 = *(int **)(param_1 + 0x200640);
    }
    FUN_007a3dd0(piVar10,*(int *)(param_1 + 0x200644),
                 *(int *)(param_1 + 0x200644) - (int)piVar10 >> 2,uStack_54);
    uStack_8._0_1_ = 4;
    FUN_0152dda0(piStack_44,piStack_34,uStack_70);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
  }
  piStack_3c = *(int **)(param_1 + 0x200644);
  piStack_4c = *(int **)(param_1 + 0x200640);
  uStack_38 = 0;
  fVar11 = DAT_018e452c;
  if (DAT_018e452c <= (float)DAT_01d6101c * DAT_018f784c) {
    fVar11 = (float)DAT_01d6101c * DAT_018f784c;
  }
  piStack_2c = (int *)DAT_018ce2f8;
  if (fVar11 <= DAT_018ce2f8) {
    piStack_2c = (int *)fVar11;
  }
  if (piStack_4c != piStack_3c) {
    do {
      piVar10 = (int *)*piStack_4c;
      *(undefined *)(piVar10 + 0x76) = 0;
      piStack_24 = piVar10;
      piStack_18 = piVar10;
      if (piVar10[1] == 0) {
        if (DAT_01d6104c != '\0') {
          FUN_0083b230((float)*(double *)(*(int *)(param_1 + 4) + 0x18),piStack_2c);
        }
        if (uStack_38 < *(uint *)(param_1 + 0x18)) {
          piStack_48 = (int *)piVar10[0x75];
          piStack_50 = (int *)((piVar10[6] - piVar10[5]) / 0x278);
          piStack_34 = (int *)0x0;
          piStack_28 = (int *)0x0;
          piVar10 = piStack_18;
          if (piStack_50 != (int *)0x0) {
            do {
              piVar9 = piStack_28;
              piStack_1c = (int *)((int)piStack_28 * 0x278 + piVar10[5]);
              piStack_44 = (int *)*piStack_1c;
              if (piStack_44 != (int *)0x0) {
                cVar2 = FUN_008363a0(piStack_1c[0x98]);
                if (piStack_44 == (int *)0x2) {
                  piVar10 = piStack_18;
                  if (cVar2 != '\0') {
                    FUN_008363e0(piStack_1c[0x98]);
                    *(int *)(param_1 + 0x206978) = *(int *)(param_1 + 0x206978) + 1;
                    piVar10 = piStack_18;
                  }
                }
                else {
                  piStack_20 = (int *)piStack_1c[1];
                  if (DAT_01d61034 != '\0') {
                    if (piStack_48 == (int *)0x3) {
                      piStack_20 = (int *)(&DAT_018fe050)[(int)piVar9];
                      if (DAT_01eb25c1 != '\0') {
                        piStack_20 = (int *)((uint)piStack_20 >> 1);
                      }
                    }
                    else {
                      piStack_20 = (int *)piStack_18[0x7c];
                    }
                  }
                  *(int *)(param_1 + 0x206978) = *(int *)(param_1 + 0x206978) + 1;
                  if (cVar2 == '\0') {
LAB_007a64bf:
                    piVar10 = *(int **)(param_1 + 0x20065c);
                    piStack_90 = piStack_20;
                    piStack_8c = piStack_20;
                    if (*(int **)(param_1 + 0x200660) == piVar10) {
                      FUN_007a21d0(piVar10,&piStack_24,&piStack_28,&piStack_90);
                      piStack_18 = piStack_24;
                      piVar9 = piStack_28;
                    }
                    else {
                      *piVar10 = (int)piStack_18;
                      piVar10[1] = (int)piVar9;
                      piVar10[2] = (int)piStack_20;
                      piVar10[3] = (int)piStack_20;
                      *(int *)(param_1 + 0x20065c) = *(int *)(param_1 + 0x20065c) + 0x10;
                    }
                    *(int *)(param_1 + 0x20697c) = *(int *)(param_1 + 0x20697c) + 1;
                  }
                  else {
                    cVar2 = FUN_00836350(piStack_1c[0x98],piStack_20);
                    if (cVar2 == '\0') goto LAB_007a64bf;
                    FUN_008363e0(piStack_1c[0x98]);
                  }
                  piVar10 = *(int **)(param_1 + 0x200650);
                  if (*(int **)(param_1 + 0x200654) == piVar10) {
                    FUN_007a2000(piVar10,&piStack_24,&piStack_28);
                    piStack_18 = piStack_24;
                    piStack_34 = (int *)((int)piStack_34 + 1);
                    piVar10 = piStack_24;
                    piVar9 = piStack_28;
                  }
                  else {
                    *piVar10 = (int)piStack_18;
                    piVar10[1] = (int)piVar9;
                    *(undefined *)(piVar10 + 2) = 0;
                    piVar10[3] = -1;
                    piVar10[4] = 1;
                    piVar10[6] = 0;
                    piVar10[7] = 0;
                    *(int *)(param_1 + 0x200650) = *(int *)(param_1 + 0x200650) + 0x20;
                    piStack_34 = (int *)((int)piStack_34 + 1);
                    piVar10 = piStack_18;
                  }
                }
              }
              piStack_28 = (int *)((int)piVar9 + 1);
            } while (piStack_28 < piStack_50);
          }
          if (piStack_48 != (int *)0x3) {
            if (piStack_34 != (int *)0x0) {
              (**(code **)(*piStack_18 + 0x18))(*(undefined4 *)(param_1 + 0x20068c));
            }
            uStack_38 = uStack_38 + (piStack_34 != (int *)0x0);
          }
        }
        else {
          piStack_34 = (int *)((piVar10[6] - piVar10[5]) / 0x278);
          piStack_28 = (int *)0x0;
          if (piStack_34 != (int *)0x0) {
            piStack_24 = (int *)0x0;
            piStack_20 = piStack_34;
            do {
              piStack_1c = (int *)(piVar10[5] + (int)piStack_24);
              cVar2 = FUN_008363a0(piStack_1c[0x98]);
              if (cVar2 == '\0') {
                if ((DAT_01d61054 != '\0') && (*piStack_1c == 0)) {
                  piStack_28 = (int *)((int)piStack_28 + 1);
                }
              }
              else {
                FUN_008363e0(piStack_1c[0x98]);
                *(int *)(param_1 + 0x206978) = *(int *)(param_1 + 0x206978) + 1;
                piStack_28 = (int *)((int)piStack_28 + 1);
              }
              piStack_24 = piStack_24 + 0x9e;
              piStack_20 = (int *)((int)piStack_20 + -1);
            } while (piStack_20 != (int *)0x0);
            piStack_20 = (int *)0x0;
          }
          if ((DAT_01d6104c != '\0') && (piStack_28 != piStack_34)) {
            piVar10[0x79] = (int)piStack_2c;
          }
          (**(code **)(*piVar10 + 0x14))();
        }
      }
      else {
        FUN_0083b200(0);
      }
      piStack_4c = piStack_4c + 1;
    } while (piStack_4c != piStack_3c);
  }
  piStack_3c = *(int **)(param_1 + 0x20065c);
  piStack_2c = *(int **)(param_1 + 0x200658);
  if (piStack_2c != piStack_3c) {
    piVar10 = piStack_2c + 2;
    do {
      piVar9 = *(int **)(param_1 + 0x200668);
      if (*(int **)(param_1 + 0x20066c) == piVar9) {
        FUN_007a2390(piVar9,piVar10);
      }
      else {
        *piVar9 = *piVar10;
        piVar9[1] = piVar10[1];
        *(int *)(param_1 + 0x200668) = *(int *)(param_1 + 0x200668) + 8;
      }
      piVar10 = piVar10 + 4;
      piStack_2c = piStack_2c + 4;
    } while (piStack_2c != piStack_3c);
  }
  if (piStack_30[0xd] < DAT_01eb2750) {
    FUN_016f3809(&DAT_01eb2750);
    if (DAT_01eb2750 == -1) {
      uStack_8._0_1_ = 5;
      uVar13 = FUN_0152dab0("ShadowMap","allocateBatch",0xffffffff);
      DAT_01eb274c = (int *)((ulonglong)uVar13 >> 0x20);
      DAT_01eb2748 = (int *)uVar13;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2750);
    }
  }
  piStack_3c = DAT_01eb2748;
  piStack_64 = DAT_01eb2748;
  piStack_30 = DAT_01eb274c;
  piStack_60 = DAT_01eb274c;
  uVar13 = FUN_0152d930(DAT_01eb2748,DAT_01eb274c);
  uStack_8._0_1_ = 6;
  piStack_2c = (int *)(iStack_40 + 0xd8);
  uStack_5c = uVar13;
  FUN_00835a80(iStack_40 + 0x200664,iStack_40 + 0x200670);
  uStack_8._0_1_ = 7;
  FUN_0152dda0(piStack_3c,piStack_30,uVar13);
  iVar7 = iStack_40;
  uVar8 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*(int *)(iStack_40 + 0x20065c) - *(int *)(iStack_40 + 0x200658) >> 4 != 0) {
    piStack_1c = (int *)0x0;
    do {
      piStack_30 = (int *)(*(int *)(iVar7 + 0x200670) + uVar8 * 4);
      iVar4 = FUN_00556df0();
      if (*piStack_30 == iVar4) {
        *(int *)(iVar7 + 0x206980) = *(int *)(iVar7 + 0x206980) + 1;
      }
      FUN_0083b270(*(undefined4 *)((int)piStack_1c + *(int *)(iVar7 + 0x200658) + 4),piStack_30);
      uVar8 = uVar8 + 1;
      piStack_1c = piStack_1c + 4;
    } while (uVar8 < (uint)(*(int *)(iVar7 + 0x20065c) - *(int *)(iVar7 + 0x200658) >> 4));
  }
  piVar10 = *(int **)(iVar7 + 0x200650);
  piVar9 = *(int **)(iVar7 + 0x20064c);
  piStack_24 = piVar10;
  piStack_20 = piVar9;
  if (piVar9 != piVar10) {
    do {
      cVar2 = FUN_008363a0(*(undefined4 *)(piVar9[1] * 0x278 + *(int *)(*piVar9 + 0x14) + 0x260));
      if (cVar2 == '\0') break;
      piVar9 = piVar9 + 8;
    } while (piVar9 != piVar10);
    iVar7 = iStack_40;
    piStack_20 = piVar9;
    if (piVar9 != piStack_24) {
      piVar10 = piVar9 + 8;
      piStack_30 = piVar10;
      if (piVar10 != piStack_24) {
        do {
          cVar2 = FUN_008363a0(*(undefined4 *)
                                (piVar10[1] * 0x278 + *(int *)(*piVar10 + 0x14) + 0x260));
          if (cVar2 != '\0') {
            iVar7 = piVar10[1];
            iVar4 = piVar10[2];
            iVar1 = piVar10[3];
            *piVar9 = *piVar10;
            piVar9[1] = iVar7;
            piVar9[2] = iVar4;
            piVar9[3] = iVar1;
            iVar7 = piVar10[5];
            iVar4 = piVar10[6];
            iVar1 = piVar10[7];
            piVar9[4] = piVar10[4];
            piVar9[5] = iVar7;
            piVar9[6] = iVar4;
            piVar9[7] = iVar1;
            piVar9 = piVar9 + 8;
          }
          piVar10 = piVar10 + 8;
        } while (piVar10 != piStack_24);
      }
      iVar7 = iStack_40;
      piStack_20 = piVar9;
      if (piVar9 != piStack_24) {
        iVar4 = *(int *)(iStack_40 + 0x200650);
        FUN_0055b6b0(&bStack_11,&piStack_30,&piStack_30);
        iVar4 = iVar4 - (int)piStack_24;
        FUN_0170cc70(piStack_20,piStack_24,iVar4);
        *(int *)(iVar7 + 0x200650) = (int)piStack_20 + iVar4;
      }
    }
  }
  piStack_30 = *(int **)(iVar7 + 0x200644);
  puVar5 = (undefined4 *)
           FUN_007a4320(&piStack_3c,*(undefined4 *)(iVar7 + 0x200640),piStack_30,iVar7);
  piVar10 = (int *)*puVar5;
  if (piVar10 != piStack_30) {
    iVar7 = *(int *)(iVar7 + 0x200644) - (int)piStack_30;
    FUN_0170cc70(piVar10,piStack_30,iVar7);
    *(int *)(iStack_40 + 0x200644) = (int)piVar10 + iVar7;
    iVar7 = iStack_40;
  }
  piStack_44 = *(int **)(iVar7 + 0x200650);
  piStack_2c = *(int **)(iVar7 + 0x20064c);
  if (piStack_2c != piStack_44) {
    do {
      iVar4 = piStack_2c[1] * 0x278 + *(int *)(*piStack_2c + 0x14);
      piStack_1c = (int *)FUN_008361f0(*(undefined4 *)(iVar4 + 0x260));
      piStack_a4 = *(int **)(iVar4 + 0x250);
      dVar12 = (double)(*(float *)(iVar4 + 0xa4) - DAT_018ce2f8);
      if (DAT_018fe498 <=
          (float)(double)CONCAT44((uint)((ulonglong)dVar12 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84(dVar12,0) & (uint)DAT_018c0da0)) {
        fVar11 = *(float *)(iVar4 + 0x94) / *(float *)(iVar4 + 0x90);
      }
      else {
        fVar11 = (float)((uint)(*(float *)(iVar4 + 0x90) / *(float *)(iVar4 + 0x94)) ^ DAT_018c4ea0)
        ;
      }
      piStack_9c = (int *)((uint)fVar11 ^ DAT_018c4ea0);
      uStack_a0 = 0;
      uStack_98 = 0x3f800000;
      piStack_3c = piStack_9c;
      piStack_30 = piStack_a4;
      FUN_01165b90(auStack_b4,&piStack_a4);
      pfVar6 = (float *)FUN_011658d0(auStack_94);
      piStack_64 = (int *)0x0;
      uStack_5c._4_4_ = 0x3f800000;
      piStack_50 = (int *)((DAT_018ce2f8 / fStack_a8) * *pfVar6);
      piStack_60 = piStack_30;
      uStack_5c._0_4_ = piStack_3c;
      FUN_01165b90(auStack_c4,&piStack_64);
      FUN_011658d0(&piStack_74);
      iVar4 = FUN_016f3cd0();
      piVar10 = piStack_2c;
      piStack_2c[4] = iVar4;
      FUN_0083b450(piStack_2c[1],piStack_1c);
      FUN_0083b290(piVar10[1],piStack_1c,*(undefined4 *)(*(int *)(iVar7 + 0x2005d0) + 0x30),
                   *(undefined4 *)(*(int *)(iVar7 + 0x2005d0) + 0x34));
      piStack_2c = piVar10 + 8;
    } while (piStack_2c != piStack_44);
  }
  *(undefined4 *)(iVar7 + 0x200674) = *(undefined4 *)(iVar7 + 0x200670);
  *(undefined4 *)(iVar7 + 0x200668) = *(undefined4 *)(iVar7 + 0x200664);
  *(undefined4 *)(iVar7 + 0x20065c) = *(undefined4 *)(iVar7 + 0x200658);
  uStack_8 = 8;
  FUN_0152dda0(uStack_54,uStack_68,uStack_80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11530 ; VA 0x007a6ad0 ; FUN_007a6ad0 */

void __thiscall FUN_007a6ad0(int param_1,int *param_2,int *param_3,int *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar1 = DAT_018ce2f8 / (float)param_3[1];
  fVar2 = DAT_018ce2f8 / (float)*param_4;
  fVar3 = DAT_018ce2f8 / (float)param_4[1];
  *(float *)(param_1 + 0x24) = DAT_018ce2f8 / (float)*param_3;
  *(float *)(param_1 + 0x28) = fVar1;
  *(float *)(param_1 + 0x2c) = fVar2;
  *(float *)(param_1 + 0x30) = fVar3;
  fVar2 = (float)((double)*param_2 + (double)(&DAT_018c0d90)[-(*param_2 >> 0x1f)]);
  fVar1 = (float)((double)param_2[1] + (double)(&DAT_018c0d90)[-(param_2[1] >> 0x1f)]);
  *(float *)(param_1 + 0x38) = *(float *)(param_1 + 0x24) * fVar2;
  *(float *)(param_1 + 0x3c) = *(float *)(param_1 + 0x28) * fVar1;
  *(float *)(param_1 + 0x40) = *(float *)(param_1 + 0x2c) * fVar2;
  *(float *)(param_1 + 0x44) = *(float *)(param_1 + 0x30) * fVar1;
  *(undefined4 *)(param_1 + 0x34) = 1;
  return;
}



/* FUNCTION 11531 ; VA 0x007a6bc0 ; FUN_007a6bc0 */

void __thiscall FUN_007a6bc0(int param_1,uint *param_2)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  char cVar6;
  uint uVar7;
  int *piVar8;
  float10 fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  int iStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  float fStack_20;
  float *pfStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2718;
  pvStack_10 = ExceptionList;
  iStack_28 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if ((*(int *)(iStack_28 + 0x34) < DAT_01eb2700) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2700), DAT_01eb2700 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("ShadowMap","buildVisibleShadowObjectsList",0xffffffff);
    DAT_01eb26fc = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb26f8 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2700);
  }
  uStack_30 = DAT_01eb26f8;
  uStack_2c = DAT_01eb26fc;
  uVar13 = FUN_0152d930(DAT_01eb26f8,DAT_01eb26fc);
  pfStack_1c = (float *)(param_1 + 0x200694);
  uStack_8 = 1;
  fVar9 = (float10)FUN_01156f90(*(undefined4 *)(*(int *)(param_1 + 4) + 0x5c4));
  uVar7 = 0;
  fStack_20 = (float)fVar9;
  cStack_11 = DAT_01d6103c;
  piVar8 = (int *)*param_2;
  uVar5 = (uint)((int)param_2[1] + (3 - (int)piVar8)) >> 2;
  if ((int *)param_2[1] < piVar8) {
    uVar5 = 0;
  }
  cVar6 = DAT_01d6103c;
  if (uVar5 != 0) {
    do {
      iVar1 = *piVar8;
      if ((*(int *)(iVar1 + 0xd4) != 3) || (cVar6 != '\0')) {
        if (*(int *)(iVar1 + 0x68) != 0) {
          *(undefined4 *)(*(int *)(iVar1 + 0x68) + 0x1f8) = 0xffffffff;
        }
        if ((((*(char *)(iVar1 + 0xf8) != '\0') && (DAT_018fd178 < *(float *)(iVar1 + 0xe4))) &&
            (DAT_018fd178 <
             *(float *)(iVar1 + 0xd8) * *(float *)(iVar1 + 0xd8) +
             *(float *)(iVar1 + 0xdc) * *(float *)(iVar1 + 0xdc) +
             *(float *)(iVar1 + 0xe0) * *(float *)(iVar1 + 0xe0))) &&
           (fVar12 = *(float *)(iVar1 + 0x28) - *(float *)(iVar1 + 0x1c),
           fVar11 = *(float *)(iVar1 + 0x24) - *(float *)(iVar1 + 0x18),
           fVar10 = *(float *)(iVar1 + 0x2c) - *(float *)(iVar1 + 0x20),
           DAT_018fe498 < fVar12 * fVar12 + fVar11 * fVar11 + fVar10 * fVar10)) {
          piVar3 = (int *)FUN_008389f0();
          piStack_24 = piVar3;
          (**(code **)(*piVar3 + 0x1c))(pfStack_1c);
          piVar3[0x7e] = -1;
          fVar10 = (float)piVar3[0x89] + fStack_20;
          param_1 = iStack_18;
          cVar6 = cStack_11;
          if (((float)piVar3[0x87] - pfStack_1c[1]) * ((float)piVar3[0x87] - pfStack_1c[1]) +
              ((float)piVar3[0x86] - *pfStack_1c) * ((float)piVar3[0x86] - *pfStack_1c) +
              ((float)piVar3[0x88] - pfStack_1c[2]) * ((float)piVar3[0x88] - pfStack_1c[2]) <=
              fVar10 * fVar10) {
            iStack_40 = piVar3[0x86];
            iStack_3c = piVar3[0x87];
            uStack_38._0_4_ = piVar3[0x88];
            uStack_38._4_4_ = (float)piVar3[0x89];
            cVar2 = FUN_007ccf30(&iStack_40);
            param_1 = iStack_18;
            cVar6 = cStack_11;
            if (cVar2 != '\0') {
              piVar3[0x73] = piVar3[0x8a];
              FUN_007a42f0(&piStack_24);
              cVar6 = cStack_11;
            }
          }
        }
      }
      uVar7 = uVar7 + 1;
      piVar8 = piVar8 + 1;
    } while (uVar7 != uVar5);
  }
  *(undefined4 *)(param_1 + 0x20062c) = *(undefined4 *)(param_1 + 0x200628);
  if (*(int *)(param_1 + 0x200634) != *(int *)(param_1 + 0x200638)) {
    if ((*(int *)(iStack_28 + 0x34) < DAT_01eb2710) &&
       (FUN_016f3809(&DAT_01eb2710), DAT_01eb2710 == -1)) {
      uStack_8._0_1_ = 3;
      uVar14 = FUN_0152dab0("Shadows","Priority sort",0xffffffff);
      DAT_01eb270c = (int)((ulonglong)uVar14 >> 0x20);
      DAT_01eb2708 = (int)uVar14;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2710);
    }
    iVar1 = DAT_01eb270c;
    iStack_28 = DAT_01eb2708;
    iStack_40 = DAT_01eb2708;
    iStack_3c = DAT_01eb270c;
    uVar14 = FUN_0152d930(DAT_01eb2708,DAT_01eb270c);
    uStack_8._0_1_ = 4;
    uStack_38 = uVar14;
    FUN_007a3ad0(*(int *)(param_1 + 0x200634),*(int *)(iStack_18 + 0x200638),
                 *(int *)(iStack_18 + 0x200638) - *(int *)(param_1 + 0x200634) >> 2,iVar1);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_0152dda0(iStack_28,iVar1,uVar14);
    iVar1 = iStack_18;
    if (DAT_01d6104c == '\0') {
      *(undefined4 *)(iStack_18 + 0x18) = 0xffffffff;
    }
    else {
      uVar4 = FUN_016f3cd0();
      *(undefined4 *)(iVar1 + 0x18) = uVar4;
    }
  }
  uStack_8 = 6;
  FUN_0152dda0(uStack_30,uStack_2c,uVar13);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11532 ; VA 0x007a7040 ; FUN_007a7040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007a7040(int param_1,int *param_2,int *param_3,char param_4)

{
  float *pfVar1;
  undefined *puVar2;
  int iVar3;
  undefined8 uVar4;
  undefined auStack_e0 [64];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b2744;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iStack_24 = param_1;
  puVar2 = &stack0xfffffffc;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2790) {
    ExceptionList = &pvStack_1c;
    FUN_016f3809(&DAT_01eb2790);
    puVar2 = puStack_20;
    if (DAT_01eb2790 == -1) {
      uStack_14 = 0;
      uVar4 = FUN_0152dab0(&DAT_018fb928,"clearChart",0xffffffff);
      DAT_01eb278c = (undefined4)((ulonglong)uVar4 >> 0x20);
      DAT_01eb2788 = (undefined4)uVar4;
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2790);
      puVar2 = puStack_20;
    }
  }
  puStack_20 = puVar2;
  uStack_2c = DAT_01eb2788;
  uStack_60 = DAT_01eb2788;
  uStack_28 = DAT_01eb278c;
  uStack_5c = DAT_01eb278c;
  uStack_58 = FUN_0152d930(DAT_01eb2788,DAT_01eb278c);
  uStack_14 = 1;
  if (param_4 != '\0') {
    *(int *)(param_1 + 0x206998) = *(int *)(param_1 + 0x206998) + 1;
    (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_1 + 0x2005d8),1,1,0,0);
  }
  FUN_00829d10(*(undefined4 *)(param_1 + 0x2005d8));
  uStack_a0 = _DAT_018fe4d0;
  uStack_9c = _UNK_018fe4d4;
  uStack_98 = _UNK_018fe4d8;
  uStack_94 = _UNK_018fe4dc;
  uStack_4c = *(undefined4 *)(*(int *)(param_1 + 0x2005d8) + 0x2c);
  uStack_50 = *(undefined4 *)(*(int *)(param_1 + 0x2005d8) + 0x28);
  fStack_38 = (float)param_3[2];
  fStack_34 = (float)param_3[3];
  uStack_48 = 1;
  uStack_44 = 1;
  FUN_007a6ad0(&fStack_38,&uStack_50,&uStack_48);
  fStack_40 = (float)*param_3 * *(float *)(param_1 + 0x10014c);
  fStack_3c = *(float *)(param_1 + 0x100150) * (float)param_3[1];
  fStack_38 = *(float *)(param_1 + 0x100154) * 0.0;
  fStack_34 = *(float *)(param_1 + 0x100158) * 0.0;
  pfVar1 = (float *)(param_1 + 0x100160 + *(int *)(param_1 + 0x10015c) * 0x10);
  *pfVar1 = fStack_40;
  pfVar1[1] = fStack_3c;
  pfVar1[2] = fStack_38;
  pfVar1[3] = fStack_34;
  *(int *)(param_1 + 0x10015c) = *(int *)(param_1 + 0x10015c) + 1;
  iVar3 = FUN_007a9c60(param_2,"ShadowEvsmClearVS","ShadowEvsmClearFS",auStack_e0,0,1);
  *(int *)(iStack_24 + 0x2069a0) = *(int *)(iStack_24 + 0x2069a0) + iVar3;
  *(int *)(iStack_24 + 0x2069a4) = *(int *)(iStack_24 + 0x2069a4) + 1;
  *(int *)(iStack_24 + 0x20699c) = *(int *)(iStack_24 + 0x20699c) + 1;
  if (param_4 != '\0') {
    (**(code **)(*param_2 + 0x18))();
  }
  uStack_14 = 2;
  FUN_0152dda0(uStack_2c,uStack_28,uStack_58);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 11533 ; VA 0x007a7270 ; FUN_007a7270 */

undefined4 FUN_007a7270(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  int *piStack_cc;
  undefined4 uStack_bc;
  int *piStack_b8;
  undefined4 uStack_b4;
  int *piStack_b0;
  undefined4 uStack_ac;
  int *piStack_a8;
  undefined4 uStack_a4;
  int *piStack_a0;
  undefined4 uStack_9c;
  int *piStack_98;
  undefined4 uStack_94;
  int *piStack_90;
  undefined4 uStack_8c;
  int *piStack_88;
  undefined4 uStack_84;
  int *piStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_74;
  int *piStack_70;
  undefined4 uStack_6c;
  int *piStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  undefined auStack_5c [4];
  int *piStack_58;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined auStack_44 [4];
  int *piStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  char cStack_1a;
  char cStack_19;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b27c6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eb2590);
  uStack_bc = 0;
  piStack_b8 = (int *)0x0;
  uStack_b4 = 0;
  piStack_b0 = (int *)0x0;
  uStack_ac = 0;
  piStack_a8 = (int *)0x0;
  uStack_a4 = 0;
  piStack_a0 = (int *)0x0;
  uStack_9c = 0;
  piStack_98 = (int *)0x0;
  uStack_94 = 0;
  piStack_90 = (int *)0x0;
  uStack_8c = 0;
  piStack_88 = (int *)0x0;
  uStack_84 = 0;
  piStack_80 = (int *)0x0;
  uStack_7c = 0;
  piStack_78 = (int *)0x0;
  uStack_74 = 0;
  piStack_70 = (int *)0x0;
  uStack_6c = 0;
  piStack_68 = (int *)0x0;
  uStack_64 = 0;
  piStack_60 = (int *)0x0;
  piVar1 = *(int **)(param_1 + 0x3c);
  uStack_8 = 1;
  piStack_24 = piVar1;
  puVar4 = (undefined4 *)(**(code **)(*piVar1 + 0x3c))(auStack_18,2,0x1000,0,1);
  uStack_bc = *puVar4;
  piVar2 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  piStack_20 = piStack_b8;
  if (piStack_b8 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_b8[1] + -1;
    piStack_b8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puVar4 = (undefined4 *)*piStack_b8;
      piStack_b8 = piVar2;
      (*(code *)*puVar4)();
      LOCK();
      iVar5 = piStack_20[2] + -1;
      piStack_20[2] = iVar5;
      UNLOCK();
      piVar2 = piStack_b8;
      if (iVar5 == 0) {
        (**(code **)(*piStack_20 + 4))();
        piVar2 = piStack_b8;
      }
    }
  }
  piStack_b8 = piVar2;
  piStack_20 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar5 = piStack_20[2] + -1;
      piStack_20[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  cStack_19 = FUN_0078b7c0();
  if (cStack_19 == '\0') {
    puVar4 = (undefined4 *)(**(code **)(*piVar1 + 0x3c))(auStack_18,2,0x180,0,1);
  }
  else {
    puVar4 = (undefined4 *)(**(code **)(*piVar1 + 0x3c))(auStack_18,2,0xc000);
  }
  piVar2 = piStack_b0;
  uStack_b4 = *puVar4;
  piVar1 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  if (piStack_b0 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_b0[1] + -1;
    piStack_b0[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puVar4 = (undefined4 *)*piStack_b0;
      piStack_b0 = piVar1;
      (*(code *)*puVar4)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      piVar1 = piStack_b0;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        piVar1 = piStack_b0;
      }
    }
  }
  piStack_b0 = piVar1;
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_28 = 0xc00;
  cStack_1a = DAT_01eb25c0;
  if (cStack_19 != '\0') {
    uStack_28 = 0x1000;
  }
  uStack_28 = uStack_28 >> (DAT_01eb25c1 != '\0');
  uVar7 = 0x880;
  if (cStack_19 != '\0') {
    uVar7 = 0x1e00;
  }
  uVar7 = uVar7 >> (DAT_01eb25c1 != '\0');
  iVar5 = (**(code **)(*piStack_24 + 0x40))();
  if (*(uint *)(iVar5 + 0x28) < uStack_28) {
    uStack_28 = *(uint *)(iVar5 + 0x28);
  }
  iVar5 = (**(code **)(*piStack_24 + 0x40))();
  piStack_2c = (int *)*(uint *)(iVar5 + 0x28);
  if (uVar7 <= *(uint *)(iVar5 + 0x28)) {
    piStack_2c = (int *)uVar7;
  }
  uVar7 = DAT_01eb25bc;
  if (DAT_01eb25c1 != '\0') {
    uVar7 = DAT_01eb25bc >> 1;
  }
  uStack_3c = FUN_00835a70(uVar7 + 0x12);
  piStack_20 = (int *)((DAT_01eb25c2 == '\0') + 7);
  puVar4 = (undefined4 *)FUN_0147c180(auStack_18,0,piStack_20,uStack_28,piStack_2c,3);
  piVar2 = piStack_a8;
  uStack_ac = *puVar4;
  piVar1 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  if (piStack_a8 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_a8[1] + -1;
    piStack_a8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puVar4 = (undefined4 *)*piStack_a8;
      piStack_a8 = piVar1;
      (*(code *)*puVar4)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      piVar1 = piStack_a8;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        piVar1 = piStack_a8;
      }
    }
  }
  piStack_a8 = piVar1;
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar6 = FUN_0147d4b0();
  uStack_8._0_1_ = 2;
  FUN_0147d420(&uStack_ac);
  piVar2 = piStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar4 = (undefined4 *)FUN_0147bf30(auStack_18,auStack_4c,uVar6);
  uStack_a4 = *puVar4;
  piVar1 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  piStack_2c = piStack_a0;
  if (piStack_a0 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_a0[1] + -1;
    piStack_a0[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puVar4 = (undefined4 *)*piStack_a0;
      piStack_a0 = piVar1;
      (*(code *)*puVar4)();
      LOCK();
      iVar5 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar5;
      UNLOCK();
      piVar1 = piStack_a0;
      if (iVar5 == 0) {
        (**(code **)(*piStack_2c + 4))();
        piVar1 = piStack_a0;
      }
    }
  }
  piStack_a0 = piVar1;
  piStack_2c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar5 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  piStack_2c = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_48[1] + -1;
    piStack_48[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      iVar5 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_2c = piStack_58;
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_58[1] + -1;
    piStack_58[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      iVar5 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  iVar5 = (**(code **)(*piVar2 + 0x40))();
  piStack_14 = (int *)0x19;
  if (*(char *)(iVar5 + 7) != '\0') {
    piStack_14 = (int *)0x16;
  }
  if (cStack_1a == '\0') {
    puVar4 = (undefined4 *)FUN_0147c180(auStack_44,0,piStack_14,uStack_3c,uStack_3c,3);
    uStack_9c = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_14 = piStack_98;
    if (piStack_98 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_98[1] + -1;
      piStack_98[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_98;
        piStack_98 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        piVar1 = piStack_98;
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
          piVar1 = piStack_98;
        }
      }
    }
    piStack_98 = piVar1;
    piStack_14 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    FUN_0147d420(&uStack_9c);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    puVar4 = (undefined4 *)FUN_0147bff0(auStack_44,0,0,auStack_5c);
    uStack_94 = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_14 = piStack_90;
    if (piStack_90 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_90[1] + -1;
      piStack_90[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_90;
        piStack_90 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        piVar1 = piStack_90;
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
          piVar1 = piStack_90;
        }
      }
    }
    piStack_90 = piVar1;
    piStack_14 = piStack_40;
    piStack_34 = piStack_58;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        piStack_34 = piStack_58;
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
          piStack_34 = piStack_58;
        }
      }
    }
  }
  else {
    iVar5 = (**(code **)(*piVar2 + 0x40))();
    uStack_28 = 4;
    if (*(uint *)(iVar5 + 0x34) < 4) {
      uStack_28 = *(uint *)(iVar5 + 0x34);
    }
    puVar4 = (undefined4 *)FUN_0147c180(auStack_30,0,piStack_20,uStack_3c,uStack_3c,3);
    piVar2 = piStack_70;
    uStack_74 = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_70[1] + -1;
      piStack_70[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_70;
        piStack_70 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        piVar1 = piStack_70;
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
          piVar1 = piStack_70;
        }
      }
    }
    piStack_70 = piVar1;
    piVar1 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar5 = *piVar2 + -1;
        *piVar2 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    uVar6 = FUN_0147d4b0();
    uStack_8._0_1_ = 4;
    FUN_0147d420(&uStack_74);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    puVar4 = (undefined4 *)FUN_0147bf30(auStack_44,auStack_5c,uVar6);
    uStack_94 = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_2c = piStack_90;
    if (piStack_90 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_90[1] + -1;
      piStack_90[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_90;
        piStack_90 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        piVar1 = piStack_90;
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
          piVar1 = piStack_90;
        }
      }
    }
    piStack_90 = piVar1;
    piStack_2c = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    piStack_2c = piStack_58;
    if (piStack_58 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_58[1] + -1;
      piStack_58[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_58)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_2c = piStack_cc;
    if (piStack_cc != (int *)0x0) {
      LOCK();
      iVar5 = piStack_cc[1] + -1;
      piStack_cc[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_cc)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    puVar4 = (undefined4 *)
             FUN_0147c120(auStack_44,0,piStack_20,uStack_3c,uStack_3c,1,1,1,uStack_28,0x42);
    uStack_7c = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_2c = piStack_78;
    if (piStack_78 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_78[1] + -1;
      piStack_78[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_78;
        piStack_78 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        piVar1 = piStack_78;
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
          piVar1 = piStack_78;
        }
      }
    }
    piStack_78 = piVar1;
    piStack_2c = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    puVar4 = (undefined4 *)
             FUN_0147c120(auStack_44,0,piStack_14,uStack_3c,uStack_3c,1,1,1,uStack_28,0x42);
    uStack_6c = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_14 = piStack_68;
    if (piStack_68 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_68[1] + -1;
      piStack_68[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_68;
        piStack_68 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        piVar1 = piStack_68;
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
          piVar1 = piStack_68;
        }
      }
    }
    piStack_68 = piVar1;
    piStack_14 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    FUN_0147d420(&uStack_6c);
    uStack_8._0_1_ = 6;
    FUN_0147d420(&uStack_7c);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puVar4 = (undefined4 *)FUN_0147bf30(auStack_44,auStack_5c,auStack_38);
    uStack_64 = *puVar4;
    piVar1 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_14 = piStack_60;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_60[1] + -1;
      piStack_60[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_60;
        piStack_60 = piVar1;
        (*(code *)*puVar4)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        piVar1 = piStack_60;
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
          piVar1 = piStack_60;
        }
      }
    }
    piStack_60 = piVar1;
    piStack_14 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    piStack_14 = piStack_58;
    if (piStack_58 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_58[1] + -1;
      piStack_58[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_58)();
        LOCK();
        iVar5 = piStack_14[2] + -1;
        piStack_14[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_34[1] + -1;
    piStack_34[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_14 = piStack_34;
      (**(code **)*piStack_34)();
      LOCK();
      iVar5 = piStack_14[2] + -1;
      piStack_14[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  puVar4 = (undefined4 *)FUN_0147c180(auStack_44,0,piStack_20,uStack_3c,uStack_3c,3);
  piVar2 = piStack_88;
  uStack_8c = *puVar4;
  piVar1 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  if (piStack_88 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_88[1] + -1;
    piStack_88[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puVar4 = (undefined4 *)*piStack_88;
      piStack_88 = piVar1;
      (*(code *)*puVar4)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      piVar1 = piStack_88;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        piVar1 = piStack_88;
      }
    }
  }
  piStack_88 = piVar1;
  piVar1 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_40[1] + -1;
    piStack_40[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar6 = FUN_0147d4b0();
  uStack_8._0_1_ = 9;
  FUN_0147d420(&uStack_8c);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puVar4 = (undefined4 *)FUN_0147bf30(auStack_44,auStack_5c,uVar6);
  piVar2 = piStack_80;
  uStack_84 = *puVar4;
  piVar1 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  if (piStack_80 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_80[1] + -1;
    piStack_80[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puVar4 = (undefined4 *)*piStack_80;
      piStack_80 = piVar1;
      (*(code *)*puVar4)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      piVar1 = piStack_80;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        piVar1 = piStack_80;
      }
    }
  }
  piStack_80 = piVar1;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_40[1] + -1;
    piStack_40[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar5 = piStack_40[2] + -1;
      piStack_40[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_58[1] + -1;
    piStack_58[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      iVar5 = piStack_58[2] + -1;
      piStack_58[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (piStack_cc != (int *)0x0) {
    LOCK();
    iVar5 = piStack_cc[1] + -1;
    piStack_cc[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_cc)();
      LOCK();
      piVar1 = piStack_cc + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_cc + 4))();
      }
    }
  }
  piStack_14 = (int *)FUN_01674e20(0x206b38);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (piStack_14 == (int *)0x0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_007a4500(param_1,param_2,&uStack_bc);
  }
  FUN_007a4fb0();
  uStack_8 = 0xc;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 11534 ; VA 0x007a7ce0 ; FUN_007a7ce0 */

void __thiscall FUN_007a7ce0(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  double dVar8;
  undefined8 uVar9;
  undefined4 uStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b280c;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_2c = param_1;
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb2760) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2760), DAT_01eb2760 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("ShadowMap","drawFrustums",0xffffffff);
    DAT_01eb275c = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01eb2758 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2760);
  }
  uStack_40 = DAT_01eb2758;
  uStack_78 = DAT_01eb2758;
  uStack_3c = DAT_01eb275c;
  uStack_74 = DAT_01eb275c;
  uStack_70 = FUN_0152d930(DAT_01eb2758,DAT_01eb275c);
  uStack_8 = 1;
  if (*(int *)(iVar2 + 0x34) < DAT_01eb2770) {
    FUN_016f3809(&DAT_01eb2770);
    if (DAT_01eb2770 == -1) {
      uStack_8._0_1_ = 2;
      uVar9 = FUN_0152dab0(&DAT_018fb928,"Shadows",0xffffffff);
      DAT_01eb276c = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01eb2768 = (undefined4)uVar9;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2770);
    }
  }
  uStack_38 = DAT_01eb2768;
  uStack_68 = DAT_01eb2768;
  uStack_34 = DAT_01eb276c;
  uStack_64 = DAT_01eb276c;
  uStack_60 = FUN_0152d930(DAT_01eb2768,DAT_01eb276c);
  uStack_8._0_1_ = 3;
  if (*(char *)(param_1 + 0x200626) != '\0') {
    if (*(int *)(iVar2 + 0x34) < DAT_01eb2780) {
      FUN_016f3809(&DAT_01eb2780);
      if (DAT_01eb2780 == -1) {
        uStack_8._0_1_ = 4;
        uVar9 = FUN_0152dab0(&DAT_018fb928,"clearShadowAtlas",0xffffffff);
        DAT_01eb277c = (int)((ulonglong)uVar9 >> 0x20);
        DAT_01eb2778 = (int)uVar9;
        uStack_8._0_1_ = 3;
        FUN_016f37bf(&DAT_01eb2780);
      }
    }
    iStack_18 = DAT_01eb2778;
    iStack_50 = DAT_01eb2778;
    iStack_24 = DAT_01eb277c;
    iStack_4c = DAT_01eb277c;
    uVar9 = FUN_0152d930(DAT_01eb2778,DAT_01eb277c);
    uStack_8._0_1_ = 5;
    uStack_48 = uVar9;
    FUN_0147bca0();
    uStack_c4 = 1;
    dVar8 = DAT_018fe4a0;
    FUN_01727e40();
    piStack_14 = (int *)(float)dVar8;
    dVar8 = DAT_018fe4b8;
    FUN_01727e40();
    fStack_b8 = (float)((uint)(float)dVar8 ^ DAT_018c4ea0);
    fStack_c0 = (float)piStack_14;
    fStack_bc = (float)piStack_14 * (float)piStack_14;
    fStack_b4 = fStack_b8 * fStack_b8;
    (**(code **)(*param_2 + 0x14))(*(undefined4 *)(iStack_2c + 0x2005d8),0,1,&uStack_c4,0);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 6;
    FUN_0152dda0(iStack_18,iStack_24,uVar9);
    *(undefined *)(iStack_2c + 0x200626) = 0;
    param_1 = iStack_2c;
  }
  uStack_8._0_1_ = 3;
  FUN_007a5f60();
  FUN_007a4030(*(int *)(param_1 + 0x20064c),*(int *)(param_1 + 0x200650),
               *(int *)(param_1 + 0x200650) - *(int *)(param_1 + 0x20064c) >> 5,param_1);
  if (DAT_01d61044 == '\0') {
    FUN_00835f10();
  }
  else {
    FUN_00836020();
  }
  iVar2 = *(int *)(param_1 + 0x20064c);
  piStack_14 = (int *)0x0;
  iStack_20 = 0;
  uStack_1c = 0;
  if (*(int *)(param_1 + 0x200650) - iVar2 >> 5 != 0) {
    iStack_24 = 0;
    iStack_28 = 0;
    do {
      iStack_18 = iVar2;
      uStack_30 = FUN_008361f0(*(undefined4 *)
                                (*(int *)(iVar2 + 4 + iStack_28) * 0x278 +
                                 *(int *)(*(int *)(iVar2 + iStack_28) + 0x14) + 0x260));
      iStack_58 = *(int *)(uStack_30 + 8) + 0x12;
      iStack_54 = *(int *)(uStack_30 + 0xc) + 0x12;
      iVar2 = FUN_00835ef0(&iStack_58);
      *(int *)(iStack_18 + 0xc + iStack_28) = iVar2;
      if (iVar2 < 0) {
        FUN_007a8210(param_2,param_1 + 0x100570,*(int *)(param_1 + 0x20064c) + iStack_24,iStack_20);
        if (DAT_01d61044 == '\0') {
          FUN_00835f10();
        }
        else {
          FUN_00836020();
        }
        uStack_48._4_4_ = *(int *)(uStack_30 + 0xc) + 0x12;
        uStack_48._0_4_ = *(int *)(uStack_30 + 8) + 0x12;
        uVar3 = FUN_00835ef0(&uStack_48);
        iStack_24 = iStack_28;
        *(undefined4 *)(iStack_18 + 0xc + iStack_28) = uVar3;
        iStack_20 = 0;
        piStack_14 = (int *)uStack_1c;
      }
      iVar2 = *(int *)(param_1 + 0x20064c);
      iStack_20 = iStack_20 + 1;
      uStack_1c = uStack_1c + 1;
      iStack_28 = iStack_28 + 0x20;
      iStack_18 = iVar2;
    } while (uStack_1c < (uint)(*(int *)(param_1 + 0x200650) - iVar2 >> 5));
  }
  FUN_007a8210(param_2,param_1 + 0x100570,(int)piStack_14 * 0x20 + iVar2,iStack_20);
  piVar5 = *(int **)(param_1 + 0x200644);
  piVar7 = *(int **)(param_1 + 0x200640);
  uVar4 = (uint)((int)piVar5 + (3 - (int)piVar7)) >> 2;
  if (piVar5 < piVar7) {
    uVar4 = 0;
  }
  if (uVar4 != 0) {
    uVar6 = 0;
    do {
      if (*(int *)(*piVar7 + 4) == 0) {
        if (*(int *)(*piVar7 + 0x1d4) == 3) {
          FUN_00840fd0();
        }
        else {
          FUN_0083b5a0();
        }
      }
      uVar6 = uVar6 + 1;
      piVar7 = piVar7 + 1;
    } while (uVar6 != uVar4);
    piVar5 = *(int **)(iStack_2c + 0x200644);
    param_1 = iStack_2c;
  }
  piStack_14 = *(int **)(param_1 + 0x200640);
  param_2 = (int *)0x0;
  uVar4 = (uint)((int)piVar5 + (3 - (int)piStack_14)) >> 2;
  if (*(int **)(param_1 + 0x200644) < piStack_14) {
    uVar4 = 0;
  }
  uStack_30 = uVar4;
  if (uVar4 != 0) {
    do {
      iVar2 = *piStack_14;
      iVar1 = *(int *)(iVar2 + 4);
      if (iVar1 != 0) {
        FUN_0083abc0(iVar1);
        FUN_0083b200(0);
        uVar4 = uStack_30;
      }
      uVar6 = (int)param_2 + 1;
      *(int **)(iVar2 + 0x1f8) = param_2;
      piStack_14 = piStack_14 + 1;
      param_2 = (int *)uVar6;
    } while (uVar6 != uVar4);
  }
  *(undefined4 *)(param_1 + 0x200650) = *(undefined4 *)(param_1 + 0x20064c);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0152dda0(uStack_38,uStack_34,uStack_60);
  uStack_8 = 8;
  FUN_0152dda0(uStack_40,uStack_3c,uStack_70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11535 ; VA 0x007a8210 ; FUN_007a8210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007a8210(int param_1,int *param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  undefined8 uVar10;
  undefined4 uVar11;
  undefined auStack_678 [580];
  undefined auStack_434 [744];
  undefined4 uStack_14c;
  undefined4 uStack_148;
  float fStack_140;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined auStack_e4 [16];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  undefined4 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  uint uStack_64;
  int iStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  float fStack_50;
  int *piStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  float fStack_30;
  float fStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2870;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_60 = param_1;
  if (param_5 != 0) {
    iStack_1c = param_5;
    piStack_18 = param_4;
    ExceptionList = &pvStack_10;
    do {
      iVar3 = (**(code **)(*(int *)*piStack_18 + 8))(piStack_18[1]);
      if ((iVar3 != 0) && (*(int *)(*piStack_18 + 0x1d4) == 3)) {
        uVar10 = FUN_007aa6f0(param_2,piStack_18,
                              *(undefined4 *)
                               (piStack_18[1] * 0x13c50 + 0x208 + *(int *)(param_1 + 0x200620)));
        *(undefined8 *)(piStack_18 + 6) = uVar10;
      }
      piStack_18 = piStack_18 + 8;
      iStack_1c = iStack_1c + -1;
    } while (iStack_1c != 0);
  }
  iStack_1c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iStack_1c + 0x34) < DAT_01eb2810) &&
     (FUN_016f3809(&DAT_01eb2810), DAT_01eb2810 == -1)) {
    uStack_8 = 0;
    uVar10 = FUN_0152dab0("ShadowMap","depthPass",0xffffffff);
    DAT_01eb280c = (int *)((ulonglong)uVar10 >> 0x20);
    DAT_01eb2808 = (float)uVar10;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2810);
  }
  fStack_2c = DAT_01eb2808;
  fStack_50 = DAT_01eb2808;
  piStack_28 = DAT_01eb280c;
  piStack_4c = DAT_01eb280c;
  uStack_48 = FUN_0152d930(DAT_01eb2808,DAT_01eb280c);
  uStack_8 = 1;
  if (*(int *)(iStack_1c + 0x34) < DAT_01eb2820) {
    FUN_016f3809(&DAT_01eb2820);
    if (DAT_01eb2820 == -1) {
      uStack_8._0_1_ = 2;
      uVar10 = FUN_0152dab0(&DAT_018fb928,"depthPass",0xffffffff);
      DAT_01eb281c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb2818 = (undefined4)uVar10;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2820);
    }
  }
  uStack_24 = DAT_01eb2818;
  uStack_40 = DAT_01eb2818;
  uStack_58 = DAT_01eb281c;
  uStack_3c = DAT_01eb281c;
  uStack_38 = FUN_0152d930(DAT_01eb2818,DAT_01eb281c);
  uStack_8._0_1_ = 3;
  cStack_11 = '\0';
  if (param_5 != 0) {
    piStack_18 = param_4 + 2;
    iStack_20 = param_5;
    do {
      piStack_5c = piStack_18 + -2;
      cVar2 = FUN_007a8b80(param_2,piStack_5c,piStack_18[4],piStack_18[5]);
      *(bool *)piStack_18 = cVar2 == '\0';
      if (cVar2 != '\0') {
        if (cStack_11 == '\0') {
          FUN_0147bca0();
          uStack_c4 = 0x10;
          uStack_80 = 0x3f800000;
          if (*(int *)(param_1 + 0x200608) == 0) {
            puVar4 = (undefined4 *)0x0;
            uVar11 = 0x10;
            uVar5 = *(undefined4 *)(param_1 + 0x2005e8);
          }
          else {
            dVar7 = DAT_018fe4a0;
            FUN_01727e40();
            fStack_30 = (float)dVar7;
            dVar7 = DAT_018fe4b8;
            FUN_01727e40();
            uStack_c4 = 0x11;
            fStack_b8 = (float)((uint)(float)dVar7 ^ DAT_018c4ea0);
            fStack_c0 = fStack_30;
            fStack_bc = fStack_30 * fStack_30;
            fStack_b4 = fStack_b8 * fStack_b8;
            FUN_005502b0();
            uStack_74 = *(undefined4 *)(param_1 + 0x2005e8);
            puVar4 = &uStack_78;
            uStack_78 = 1;
            uVar11 = 0;
            uVar5 = *(undefined4 *)(param_1 + 0x200618);
          }
          (**(code **)(*param_2 + 0x14))(uVar5,0,uVar11,&uStack_c4,puVar4);
          *(int *)(param_1 + 0x206998) = *(int *)(param_1 + 0x206998) + 1;
          cStack_11 = '\x01';
        }
        fStack_30 = (float)(piStack_18[-1] * 0x278 + *(int *)(*piStack_5c + 0x14));
        iVar3 = FUN_008361f0(*(undefined4 *)((int)fStack_30 + 0x260));
        puStack_54 = (undefined4 *)FUN_008361f0(piStack_18[1]);
        iVar6 = *(int *)(iVar3 + 8) + 0x12;
        iVar3 = *(int *)(iVar3 + 0xc) + 0x12;
        FUN_0083ae90(auStack_678,(int)fStack_30 + 0xc,9,iVar6,iVar3);
        (**(code **)(*param_2 + 0x1c))(*puStack_54,puStack_54[1],iVar6,iVar3);
        iVar3 = *(int *)(*piStack_5c + 0x1d4);
        puStack_54 = (undefined4 *)iVar3;
        FUN_00776530();
        FUN_007ce460(auStack_678);
        fStack_140 = 0.0;
        if (0.0 <= (float)DAT_01d60ff0 * DAT_018fd178) {
          fStack_140 = (float)DAT_01d60ff0 * DAT_018fd178;
        }
        if (DAT_018ce2f8 < fStack_140) {
          fStack_140 = 1.0;
        }
        uStack_14c = 0x40b147ae;
        uStack_148 = 0x40b147ae;
        if (DAT_01eb25c0 == '\0') {
          puVar4 = &uStack_d4;
          uStack_d4 = _DAT_018e0040;
          uStack_d0 = _UNK_018e0044;
          uStack_cc = _UNK_018e0048;
          uStack_c8 = _UNK_018e004c;
        }
        else {
          puVar4 = (undefined4 *)FUN_007a8f30(auStack_e4,(int)fStack_30 + 0x68);
        }
        uStack_134 = *puVar4;
        uStack_130 = puVar4[1];
        uStack_12c = puVar4[2];
        uStack_128 = puVar4[3];
        (**(code **)(*param_2 + 0x30))(0,auStack_434,0x350);
        param_1 = iStack_60;
        if (iVar3 == 3) {
          uStack_64 = CONCAT31(uStack_64._1_3_,1);
          if (*(char *)(iStack_60 + 0x200625) == '\0') goto LAB_007a85bb;
        }
        else {
LAB_007a85bb:
          uStack_64 = uStack_64 & 0xffffff00;
        }
        iStack_70 = 0;
        iStack_6c = 0;
        iStack_68 = 0;
        FUN_007aa160(param_2,iStack_60 + 0x1c,&iStack_70,uStack_64);
        iVar3 = *(int *)(*(int *)(param_1 + 4) + 0x524);
        if (iVar3 != 0) {
          *(int *)(iVar3 + 0x20) = *(int *)(iVar3 + 0x20) + iStack_70;
          *(int *)(iVar3 + 0x24) = *(int *)(iVar3 + 0x24) + iStack_6c;
          *(int *)(iVar3 + 0x2c) = *(int *)(iVar3 + 0x2c) + iStack_68;
        }
        *(int *)(param_1 + 0x20699c) = *(int *)(param_1 + 0x20699c) + iStack_70;
        *(int *)(param_1 + 0x2069a0) = *(int *)(param_1 + 0x2069a0) + iStack_6c;
        *(int *)(param_1 + 0x2069a4) = *(int *)(param_1 + 0x2069a4) + iStack_68;
        if (puStack_54 == (undefined4 *)0x3) {
          iVar3 = 0x2069ac;
        }
        else {
          iVar3 = 0x206a30;
          if (puStack_54 != (undefined4 *)0x1) {
            iVar3 = 0x206ab4;
          }
        }
        piVar1 = (int *)(iVar3 + 0x74 + param_1);
        *piVar1 = *piVar1 + iStack_70;
        piVar1 = (int *)(iVar3 + 0x78 + param_1);
        *piVar1 = *piVar1 + iStack_6c;
        piVar1 = (int *)(iVar3 + 0x7c + param_1);
        *piVar1 = *piVar1 + iStack_68;
      }
      piStack_18 = piStack_18 + 8;
      iStack_20 = iStack_20 + -1;
    } while (iStack_20 != 0);
    if (cStack_11 != '\0') {
      (**(code **)(*param_2 + 0x18))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0152dda0(uStack_24,uStack_58,uStack_38);
  uStack_8 = 5;
  FUN_0152dda0(fStack_2c,piStack_28,uStack_48);
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x34) < DAT_01eb2830) {
    FUN_016f3809(&DAT_01eb2830);
    if (DAT_01eb2830 == -1) {
      uStack_8 = 6;
      uVar10 = FUN_0152dab0("ShadowMap","horizontalBlur",0xffffffff);
      DAT_01eb282c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb2828 = (undefined4)uVar10;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2830);
    }
  }
  uStack_58 = DAT_01eb2828;
  uStack_40 = DAT_01eb2828;
  uStack_24 = DAT_01eb282c;
  uStack_3c = DAT_01eb282c;
  uVar10 = FUN_0152d930(DAT_01eb2828,DAT_01eb282c);
  cVar2 = '\0';
  uStack_8 = 7;
  cStack_11 = '\0';
  uStack_38 = uVar10;
  if (param_5 != 0) {
    piStack_18 = param_4 + 1;
    iStack_20 = param_5;
    do {
      if (*(char *)(piStack_18 + 1) == '\0') {
        uStack_38 = uVar10;
        if (cVar2 == '\0') {
          (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_1 + 0x2005f8),0,1,0,0);
          *(int *)(param_1 + 0x206998) = *(int *)(param_1 + 0x206998) + 1;
          cStack_11 = '\x01';
        }
        piStack_28 = piStack_18 + -1;
        fStack_2c = (float)(*piStack_18 * 0x278 + *(int *)(*piStack_28 + 0x14));
        puVar4 = (undefined4 *)FUN_008361f0(piStack_18[2]);
        dVar7 = (double)(*(float *)((int)fStack_2c + 0xa4) - DAT_018ce2f8);
        if ((float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & DAT_018c0da0._4_4_,
                                    SUB84(dVar7,0) & (uint)DAT_018c0da0) < DAT_018fe498) {
          fStack_50 = _DAT_018fe4e0;
          piStack_4c = _UNK_018fe4e4;
          uStack_48._0_4_ = _UNK_018fe4e8;
          uStack_48._4_4_ = _UNK_018fe4ec;
        }
        else {
          fVar8 = *(float *)((int)fStack_2c + 0x90);
          fVar9 = *(float *)((int)fStack_2c + 0x94) / fVar8;
          uStack_48._0_4_ = 0x3f800000;
          uStack_48._4_4_ = 0;
          fVar8 = (fVar8 * fVar9) / (fVar8 + DAT_018ce2f8);
          fStack_50 = fVar8 / (fVar8 - fVar9);
          piStack_4c = (int *)(fVar9 / (fVar9 - fVar8));
        }
        FUN_007a9050(param_2,piStack_28,&fStack_50,*puVar4,puVar4[1],9,9);
        cVar2 = cStack_11;
        uVar10 = uStack_38;
      }
      piStack_18 = piStack_18 + 8;
      iStack_20 = iStack_20 + -1;
    } while (iStack_20 != 0);
    uStack_38 = uVar10;
    if (cVar2 != '\0') {
      (**(code **)(*param_2 + 0x18))();
    }
  }
  uStack_8 = 8;
  FUN_0152dda0(uStack_58,uStack_24,uStack_38);
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x34) < DAT_01eb2840) {
    FUN_016f3809(&DAT_01eb2840);
    if (DAT_01eb2840 == -1) {
      uStack_8 = 9;
      uVar10 = FUN_0152dab0("ShadowMap","verticalBlur",0xffffffff);
      DAT_01eb283c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb2838 = (undefined4)uVar10;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2840);
    }
  }
  uStack_24 = DAT_01eb2838;
  uStack_40 = DAT_01eb2838;
  piStack_28 = (int *)DAT_01eb283c;
  uStack_3c = DAT_01eb283c;
  uVar10 = FUN_0152d930(DAT_01eb2838,DAT_01eb283c);
  uStack_8 = 10;
  uStack_38 = uVar10;
  (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_1 + 0x2005d8),1,1,0,0);
  *(int *)(param_1 + 0x206998) = *(int *)(param_1 + 0x206998) + 1;
  if (param_5 != 0) {
    param_4 = param_4 + 3;
    do {
      fStack_2c = (float)(param_4[-2] * 0x278 + *(int *)(param_4[-3] + 0x14));
      uVar5 = FUN_008361f0(*(undefined4 *)((int)fStack_2c + 0x260));
      puVar4 = (undefined4 *)FUN_008361f0(*param_4);
      if (*(char *)(param_4 + -1) == '\0') {
        dVar7 = (double)(*(float *)((int)fStack_2c + 0xa4) - DAT_018ce2f8);
        if ((float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & DAT_018c0da0._4_4_,
                                    SUB84(dVar7,0) & (uint)DAT_018c0da0) < DAT_018fe498) {
          fStack_50 = _DAT_018fe4e0;
          piStack_4c = _UNK_018fe4e4;
          uStack_48._0_4_ = _UNK_018fe4e8;
          uStack_48._4_4_ = _UNK_018fe4ec;
        }
        else {
          fVar8 = *(float *)((int)fStack_2c + 0x90);
          fVar9 = *(float *)((int)fStack_2c + 0x94) / fVar8;
          uStack_48._0_4_ = 0x3f800000;
          uStack_48._4_4_ = 0;
          fVar8 = (fVar8 * fVar9) / (fVar8 + DAT_018ce2f8);
          fStack_50 = fVar8 / (fVar8 - fVar9);
          piStack_4c = (int *)(fVar9 / (fVar9 - fVar8));
        }
        FUN_007ab8d0(param_2,param_4 + -3,&fStack_50,*puVar4,puVar4[1],9,9);
      }
      else {
        FUN_007a7040(param_2,uVar5,0);
      }
      param_4 = param_4 + 8;
      param_5 = param_5 + -1;
    } while (param_5 != 0);
  }
  (**(code **)(*param_2 + 0x18))();
  uStack_8 = 0xb;
  FUN_0152dda0(uStack_24,piStack_28,uStack_38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11536 ; VA 0x007a8b80 ; FUN_007a8b80 */

undefined4 __thiscall
FUN_007a8b80(int param_1,undefined4 param_2,int *param_3,int param_4,int param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined8 uVar6;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b28a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_007f63a0();
  if (DAT_01d61034 != '\0') {
    iVar5 = *(int *)(*param_3 + 0x1d4);
    if (iVar5 == 3) {
      uVar4 = param_3[1];
    }
    else {
      uVar4 = 0xffffffff;
      if (((iVar5 == 2) || (iVar5 == 4)) || (iVar5 == 1)) {
        iVar5 = 0x180;
        if (DAT_01eb25c1 != '\0') {
          iVar5 = 0xc0;
        }
        uVar4 = (uint)(iVar5 - *(int *)(*param_3 + 0x1f0)) >> 6;
      }
    }
    *(uint *)(param_1 + 0xd4) = uVar4;
  }
  iStack_14 = 0;
  iVar5 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if (*(int *)(iVar5 + 0x34) < DAT_01eb27f0) {
    FUN_016f3809(&DAT_01eb27f0);
    if (DAT_01eb27f0 == -1) {
      uStack_8 = 0;
      uVar6 = FUN_0152dab0("ShadowMap","updateFrustumRenderQueue",0xffffffff);
      DAT_01eb27ec = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01eb27e8 = (undefined4)uVar6;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb27f0);
    }
  }
  uVar2 = DAT_01eb27ec;
  uVar1 = DAT_01eb27e8;
  uVar6 = FUN_0152d930(DAT_01eb27e8,DAT_01eb27ec);
  uStack_8 = 1;
  cVar3 = (**(code **)(*(int *)*param_3 + 0x10))
                    (param_1 + 0x1c,param_3[1],param_4,param_5,&iStack_14);
  uStack_8 = 2;
  FUN_0152dda0(uVar1,uVar2,uVar6);
  uStack_8 = 0xffffffff;
  *(int *)(param_1 + 0x20698c) = *(int *)(param_1 + 0x20698c) + iStack_14;
  if ((cVar3 == '\0') && (param_4 == 0 && param_5 == 0)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  if (*(int *)(iVar5 + 0x34) < DAT_01eb2800) {
    FUN_016f3809(&DAT_01eb2800);
    if (DAT_01eb2800 == -1) {
      uStack_8 = 3;
      uVar6 = FUN_0152dab0("ShadowMap",&DAT_018fe464,0xffffffff);
      DAT_01eb27fc = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01eb27f8 = (undefined4)uVar6;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2800);
    }
  }
  uVar2 = DAT_01eb27fc;
  uVar1 = DAT_01eb27f8;
  uVar6 = FUN_0152d930(DAT_01eb27f8,DAT_01eb27fc);
  iVar5 = 0xf;
  uStack_8 = 4;
  do {
    FUN_007f6480(1);
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  uStack_8 = 5;
  FUN_0152dda0(uVar1,uVar2,uVar6);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 11537 ; VA 0x007a8e00 ; FUN_007a8e00 */

uint FUN_007a8e00(int param_1)

{
  uint uVar1;
  
  uVar1 = (&DAT_018fe050)[param_1];
  if (DAT_01eb25c1 != '\0') {
    uVar1 = uVar1 >> 1;
  }
  return uVar1;
}



/* FUNCTION 11538 ; VA 0x007a8e30 ; FUN_007a8e30 */

undefined * FUN_007a8e30(uint param_1,int param_2)

{
  undefined *puVar1;
  
  if (param_1 < 2) {
    param_1 = 1;
  }
  else if (0x18 < param_1) {
    param_1 = 0x18;
  }
  *(undefined4 *)(param_2 + 0x30) = *(undefined4 *)(&DAT_01d6145c + param_1 * 0x24);
  *(undefined4 *)(param_2 + 0x34) = *(undefined4 *)(&DAT_01d61460 + param_1 * 0x24);
  *(undefined4 *)(param_2 + 0x38) = *(undefined4 *)(&DAT_01d61464 + param_1 * 0x24);
  *(undefined4 *)(param_2 + 0x3c) = *(undefined4 *)(&DAT_01d61468 + param_1 * 0x24);
  *(undefined4 *)(param_2 + 0x40) = *(undefined4 *)(&DAT_01d6146c + param_1 * 0x24);
  *(undefined4 *)(param_2 + 0x44) = 0;
  *(undefined4 *)(param_2 + 0x48) = 0;
  *(undefined4 *)(param_2 + 0x4c) = 0;
  *(undefined4 *)(param_2 + 0x50) = 0;
  *(undefined4 *)(param_2 + 0x54) = (&DAT_01d617bc)[param_1 * 9];
  *(undefined4 *)(param_2 + 0x58) = (&DAT_01d617c0)[param_1 * 9];
  *(undefined4 *)(param_2 + 0x5c) = (&DAT_01d617c4)[param_1 * 9];
  *(undefined4 *)(param_2 + 0x60) = (&DAT_01d617c8)[param_1 * 9];
  puVar1 = (&PTR_s_DFS_17_01d610bc)[param_1];
  *(undefined4 *)(param_2 + 100) = 0;
  *(undefined4 *)(param_2 + 0x68) = 0;
  *(undefined4 *)(param_2 + 0x6c) = 0;
  return puVar1;
}



/* FUNCTION 11539 ; VA 0x007a8ef0 ; FUN_007a8ef0 */

uint FUN_007a8ef0(void)

{
  uint uVar1;
  
  uVar1 = DAT_01d6105c;
  if (DAT_01eb25c1 != '\0') {
    uVar1 = DAT_01d6105c >> 1;
  }
  return uVar1;
}



/* FUNCTION 11540 ; VA 0x007a8f10 ; FUN_007a8f10 */

uint FUN_007a8f10(void)

{
  uint uVar1;
  
  uVar1 = 0xc0;
  if (DAT_01d61034 != '\0') {
    uVar1 = 0x180;
  }
  if (DAT_01eb25c1 != '\0') {
    uVar1 = uVar1 >> 1;
  }
  return uVar1;
}



/* FUNCTION 11541 ; VA 0x007a8f30 ; FUN_007a8f30 */

void FUN_007a8f30(float *param_1,int param_2)

{
  float fVar1;
  double dVar2;
  float fVar3;
  
  dVar2 = (double)(*(float *)(param_2 + 0x3c) - DAT_018ce2f8);
  if ((float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & DAT_018c0da0._4_4_,
                              SUB84(dVar2,0) & (uint)DAT_018c0da0) < DAT_018fe498) {
    *param_1 = -2.0;
    param_1[1] = 0.0;
    param_1[2] = 0.0;
    param_1[3] = 1.0;
    return;
  }
  fVar1 = *(float *)(param_2 + 0x28);
  fVar3 = *(float *)(param_2 + 0x2c) / fVar1;
  fVar1 = (fVar3 * fVar1) / (fVar1 + DAT_018ce2f8);
  param_1[2] = 1.0;
  param_1[3] = 0.0;
  *param_1 = fVar1 / (fVar1 - fVar3);
  param_1[1] = fVar3 / (fVar3 - fVar1);
  return;
}



/* FUNCTION 11542 ; VA 0x007a9010 ; FUN_007a9010 */

void __thiscall FUN_007a9010(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2005d4);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x2005d4);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x2005d0);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 11543 ; VA 0x007a9050 ; FUN_007a9050 */

void __thiscall
FUN_007a9050(int param_1,int *param_2,int *param_3,undefined4 *param_4,int param_5,
            undefined4 param_6,int param_7)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  char *pcVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined auStack_fc [16];
  float fStack_ec;
  float fStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined *puStack_cc;
  undefined *puStack_c8;
  undefined *puStack_c4;
  undefined *puStack_c0;
  undefined *puStack_bc;
  undefined *puStack_b8;
  undefined *puStack_b4;
  undefined *puStack_b0;
  undefined *puStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  float fStack_8c;
  float fStack_88;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  undefined4 ***pppuStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  uint uStack_48;
  undefined uStack_3c;
  undefined uStack_3b;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b28e4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb27a0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb27a0), DAT_01eb27a0 == -1)) {
    uStack_8 = 0;
    uVar11 = FUN_0152dab0(&DAT_018fb928,"Convert into EVSM and HBlur",0xffffffff);
    DAT_01eb279c = (undefined4)((ulonglong)uVar11 >> 0x20);
    DAT_01eb2798 = (undefined4)uVar11;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb27a0);
  }
  uStack_54 = DAT_01eb2798;
  uStack_7c = DAT_01eb2798;
  uStack_50 = DAT_01eb279c;
  uStack_78 = DAT_01eb279c;
  uStack_74 = FUN_0152d930(DAT_01eb2798,DAT_01eb279c);
  uStack_8 = 1;
  iStack_18 = FUN_008361f0(*(undefined4 *)(param_3[1] * 0x278 + *(int *)(*param_3 + 0x14) + 0x260));
  if (param_3[1] == 0) {
    iStack_30 = 0;
  }
  else {
    iStack_30 = (**(code **)(*(int *)*param_3 + 8))(param_3[1]);
    if (iStack_30 != 0) {
      uStack_28 = *(uint *)(iStack_18 + 8) >> 3;
      uVar6 = *(uint *)(iStack_18 + 0xc) >> 3;
      goto LAB_007a9123;
    }
  }
  uStack_28 = *(uint *)(iStack_18 + 8);
  uVar6 = *(uint *)(iStack_18 + 0xc);
LAB_007a9123:
  iVar3 = *(int *)(param_1 + 0x200608);
  uStack_20 = param_3[4];
  iStack_14 = iVar3;
  if (iVar3 == 0) {
    iStack_14 = *(int *)(param_1 + 0x2005e0);
  }
  iStack_4c = param_5 + param_7;
  uStack_3b = 1;
  uStack_3c = iVar3 != 0;
  uStack_38 = 0;
  uStack_34 = (uint)uStack_34._2_2_ << 0x10;
  (**(code **)(*param_2 + 0x34))(0,iStack_14,&uStack_3c);
  FUN_00829d10(*(undefined4 *)(param_1 + 0x2005f8));
  fStack_ec = DAT_018ce2f8 /
              (float)((double)*(int *)(iStack_14 + 0x30) +
                     (double)(&DAT_018c0d90)[-(*(int *)(iStack_14 + 0x30) >> 0x1f)]);
  uStack_e4 = 0x40b147ae;
  uStack_e0 = 0x40b147ae;
  fStack_e8 = DAT_018ce2f8 /
              (float)((double)*(int *)(iStack_14 + 0x34) +
                     (double)(&DAT_018c0d90)[-(*(int *)(iStack_14 + 0x34) >> 0x1f)]);
  uStack_dc = *param_4;
  uStack_d8 = param_4[1];
  uStack_d4 = param_4[2];
  uStack_d0 = param_4[3];
  fStack_8c = (float)*(int *)(iStack_18 + 8) /
              (float)((double)*(int *)(iStack_14 + 0x30) +
                     (double)(&DAT_018c0d90)[-(*(int *)(iStack_14 + 0x30) >> 0x1f)]);
  iVar3 = *(int *)(iStack_18 + 0xc) + param_7 * 2;
  fStack_88 = (float)((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) /
              (float)((double)*(int *)(iStack_14 + 0x34) +
                     (double)(&DAT_018c0d90)[-(*(int *)(iStack_14 + 0x34) >> 0x1f)]);
  if (*(int *)(param_1 + 0x200608) == 0) {
    if (uStack_20 < 2) {
      uVar7 = 1;
    }
    else {
      uVar7 = uStack_20;
      if (0x18 < uStack_20) {
        uVar7 = 0x18;
      }
    }
    pcVar4 = (char *)(&DAT_01d6105c)[uVar7];
    puStack_cc = (&PTR_s_LFS_7_01d610fc)[uVar7 * 9];
    puStack_c8 = (&PTR_s_LFS_7_01d61100)[uVar7 * 9];
    puStack_c4 = (&PTR_s_LFS_7_01d61104)[uVar7 * 9];
    puStack_c0 = (&PTR_s_LFS_9_01d61108)[uVar7 * 9];
    uStack_a8 = 0;
    uStack_a4 = 0;
    uStack_a0 = 0;
    puStack_bc = (&PTR_s_LFS_9_01d6110c)[uVar7 * 9];
    puStack_b8 = (&PTR_s_LFS_9_01d61110)[uVar7 * 9];
    puStack_b4 = (&PTR_s_LFS_9_01d61114)[uVar7 * 9];
    puStack_b0 = (&PTR_s_LFS_9_01d61118)[uVar7 * 9];
    puStack_ac = (&PTR_s_LFS_9_01d6111c)[uVar7 * 9];
  }
  else {
    pcVar4 = (char *)FUN_007a8e30(uStack_20,auStack_fc);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  pcVar8 = pcVar4;
  do {
    cVar1 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar4,(int)pcVar8 - (int)(pcVar4 + 1));
  uStack_8._0_1_ = 2;
  piVar5 = (int *)FUN_00585d40(0,"ShadowEvsmHBlur",0xf);
  pppuStack_6c = (undefined4 ***)*piVar5;
  iStack_68 = piVar5[1];
  iStack_64 = piVar5[2];
  iStack_60 = piVar5[3];
  uStack_5c = *(undefined8 *)(piVar5 + 4);
  piVar5[4] = 0;
  piVar5[5] = 0xf;
  *(undefined *)piVar5 = 0;
  uStack_8._0_1_ = 4;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_34) {
    uVar10 = uStack_34 + 1;
    uVar7 = uStack_48;
    if (0xfff < uVar10) {
      uVar7 = *(uint *)(uStack_48 - 4);
      uVar10 = uStack_34 + 0x24;
      if (0x1f < (uStack_48 - uVar7) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar10);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_20 = *(undefined4 *)(iStack_14 + 0x34);
  uStack_24 = *(undefined4 *)(iStack_14 + 0x30);
  iStack_18 = *(undefined4 *)(*(int *)(param_1 + 0x2005f8) + 0x2c);
  uStack_1c = *(undefined4 *)(*(int *)(param_1 + 0x2005f8) + 0x28);
  uStack_2c = uStack_28;
  uStack_28 = param_7 * 2 + uVar6;
  FUN_007a6ad0(&uStack_2c,&uStack_1c,&uStack_24);
  FUN_007a97e0(param_3,iStack_30,param_5,param_6,iStack_4c,param_6);
  ppppuVar9 = &pppuStack_6c;
  if (0xf < uStack_5c._4_4_) {
    ppppuVar9 = (undefined4 ****)pppuStack_6c;
  }
  iVar3 = FUN_007a9c60(param_2,"ShadowEvsmPassThroughFlippedVS",ppppuVar9,auStack_fc,0,
                       *(int *)(param_1 + 0x10015c) + -1);
  *(int *)(param_1 + 0x2069a0) = *(int *)(param_1 + 0x2069a0) + iVar3;
  *(int *)(param_1 + 0x2069a4) = *(int *)(param_1 + 0x2069a4) + 1;
  *(int *)(param_1 + 0x20699c) = *(int *)(param_1 + 0x20699c) + 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_5c._4_4_) {
    uVar6 = uStack_5c._4_4_ + 1;
    ppppuVar9 = (undefined4 ****)pppuStack_6c;
    if (0xfff < uVar6) {
      ppppuVar9 = (undefined4 ****)pppuStack_6c[-1];
      uVar6 = uStack_5c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_6c + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar6);
  }
  uStack_5c = 0xf00000000;
  pppuStack_6c = (undefined4 ***)((uint)pppuStack_6c & 0xffffff00);
  uStack_8 = 5;
  FUN_0152dda0(uStack_54,uStack_50,uStack_74);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11544 ; VA 0x007a9540 ; FUN_007a9540 */

void __fastcall FUN_007a9540(int param_1)

{
  float fVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint *puVar7;
  uint uVar8;
  uint *puVar9;
  int *piVar10;
  uint uStack_10;
  int iStack_c;
  int *piStack_8;
  
  iVar5 = 0x800;
  puVar6 = (undefined4 *)(param_1 + 0x200928);
  do {
    puVar6[1] = *puVar6;
    iVar5 = iVar5 + -1;
    puVar6 = puVar6 + 3;
  } while (iVar5 != 0);
  puVar7 = *(uint **)(param_1 + 0x200644);
  piVar10 = (int *)0x0;
  puVar9 = *(uint **)(param_1 + 0x200640);
  piStack_8 = (int *)((uint)((int)puVar7 + (3 - (int)puVar9)) >> 2);
  if (puVar7 < puVar9) {
    piStack_8 = (int *)0x0;
  }
  iStack_c = param_1;
  if (piStack_8 != (int *)0x0) {
    do {
      uStack_10 = *puVar9;
      if ((*(int *)(uStack_10 + 0x1d4) == 2) || (*(int *)(uStack_10 + 0x1d4) == 1)) {
        fVar1 = *(float *)(param_1 + 0x200924);
        iVar5 = param_1 + ((((int)(*(float *)(uStack_10 + 0x220) / fVar1) & 7U) * 0x10 +
                           ((int)(*(float *)(uStack_10 + 0x21c) / fVar1) & 0xfU)) * 0x10 + 0x2ab6e +
                          ((int)(*(float *)(uStack_10 + 0x218) / fVar1) & 0xfU)) * 0xc;
        puVar7 = *(uint **)(iVar5 + 4);
        if (*(uint **)(iVar5 + 8) == puVar7) {
          FUN_0063d9b0(puVar7,&uStack_10);
        }
        else {
          *puVar7 = uStack_10;
          *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 4;
        }
      }
      piVar10 = (int *)((int)piVar10 + 1);
      puVar9 = puVar9 + 1;
    } while (piVar10 != piStack_8);
    puVar7 = *(uint **)(param_1 + 0x200644);
  }
  iVar5 = *(int *)(param_1 + 0x200640);
  uVar8 = (int)puVar7 - iVar5 >> 2;
  uStack_10 = uVar8 - 1;
  if (uStack_10 < uVar8) {
    do {
      iVar5 = *(int *)(iVar5 + uStack_10 * 4);
      if (((*(int *)(iVar5 + 0x1d4) == 2) || (*(int *)(iVar5 + 0x1d4) == 1)) &&
         (*(int *)(iVar5 + 0x1dc) == 0)) {
        *(undefined4 *)(param_1 + 0x200638) = *(undefined4 *)(param_1 + 0x200634);
        FUN_007a9a00(iVar5 + 0x218,0x3dcccccd,(int *)(param_1 + 0x200634));
        piVar10 = *(int **)(param_1 + 0x200634);
        piVar4 = *(int **)(param_1 + 0x200638);
        param_1 = iStack_c;
        piStack_8 = piVar4;
        if (piVar10 != piVar4) {
          do {
            iVar2 = *piVar10;
            if (((iVar2 != iVar5) && (*(int *)(iVar2 + 4) == 0)) &&
               (cVar3 = FUN_00839a50(iVar5,iVar2,0x3dcccccd), piVar4 = piStack_8, cVar3 != '\0')) {
              if (*(char *)(iVar2 + 0x1d8) == '\0') {
                FUN_0083b200(iVar2);
                param_1 = iStack_c;
                break;
              }
              if ((*(int *)(iVar5 + 4) == 0) ||
                 (fVar1 = *(float *)(*(int *)(iVar5 + 4) + 0x1cc),
                 *(float *)(iVar2 + 0x1cc) <= fVar1 && fVar1 != *(float *)(iVar2 + 0x1cc))) {
                FUN_0083b200(iVar2);
                piVar4 = piStack_8;
              }
            }
            piVar10 = piVar10 + 1;
            param_1 = iStack_c;
          } while (piVar10 != piVar4);
        }
      }
      iVar5 = *(int *)(param_1 + 0x200640);
      uStack_10 = uStack_10 - 1;
    } while (uStack_10 < (uint)(*(int *)(param_1 + 0x200644) - iVar5 >> 2));
  }
  *(undefined4 *)(param_1 + 0x200638) = *(undefined4 *)(param_1 + 0x200634);
  return;
}



/* FUNCTION 11545 ; VA 0x007a9750 ; FUN_007a9750 */

void FUN_007a9750(float *param_1,undefined4 param_2,undefined4 *param_3)

{
  float *pfVar1;
  undefined auStack_24 [12];
  float fStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0x3f800000;
  uStack_14 = *param_3;
  uStack_10 = param_3[1];
  uStack_c = param_3[2];
  FUN_01165b90(auStack_24,&uStack_14);
  pfVar1 = (float *)FUN_011658d0(&uStack_10);
  fStack_18 = DAT_018ce2f8 / fStack_18;
  *param_1 = *pfVar1 * fStack_18;
  param_1[1] = pfVar1[1] * fStack_18;
  param_1[2] = pfVar1[2] * fStack_18;
  return;
}



/* FUNCTION 11546 ; VA 0x007a97e0 ; FUN_007a97e0 */

void __thiscall
FUN_007a97e0(int param_1,int *param_2,uint param_3,int param_4,int param_5,int param_6,int param_7)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  
  iVar7 = FUN_008361f0(*(undefined4 *)(param_2[1] * 0x278 + *(int *)(*param_2 + 0x14) + 0x260));
  if (param_3 == 0) {
    fVar2 = *(float *)(param_1 + 0x100150);
    fVar3 = *(float *)(param_1 + 0x100154);
    fVar4 = *(float *)(param_1 + 0x100158);
    pfVar1 = (float *)(param_1 + 0x100160 + *(int *)(param_1 + 0x10015c) * 0x10);
    *pfVar1 = (float)param_4 * *(float *)(param_1 + 0x10014c);
    pfVar1[1] = (float)param_5 * fVar2;
    pfVar1[2] = (float)param_6 * fVar3;
    pfVar1[3] = (float)param_7 * fVar4;
    *(int *)(param_1 + 0x10015c) = *(int *)(param_1 + 0x10015c) + 1;
  }
  else {
    uVar5 = *(uint *)(iVar7 + 8);
    uVar10 = 0;
    uVar6 = *(uint *)(iVar7 + 0xc);
    if (param_3 != 0) {
      do {
        piVar8 = (int *)(**(code **)(*(int *)*param_2 + 0xc))(param_2[1],uVar10);
        if (*piVar8 == 1) {
          iVar7 = (uVar10 & 7) * (uVar5 >> 3);
          iVar9 = (uVar10 >> 3) * (uVar6 >> 3);
          fVar2 = *(float *)(param_1 + 0x100150);
          fVar3 = *(float *)(param_1 + 0x100154);
          fVar4 = *(float *)(param_1 + 0x100158);
          pfVar1 = (float *)(param_1 + 0x100160 + *(int *)(param_1 + 0x10015c) * 0x10);
          *pfVar1 = (float)(param_4 + iVar7) * *(float *)(param_1 + 0x10014c);
          pfVar1[1] = (float)(param_5 + iVar9) * fVar2;
          pfVar1[2] = (float)(param_6 + iVar7) * fVar3;
          pfVar1[3] = (float)(param_7 + iVar9) * fVar4;
          *(int *)(param_1 + 0x10015c) = *(int *)(param_1 + 0x10015c) + 1;
        }
        uVar10 = uVar10 + 1;
      } while (uVar10 < param_3);
      return;
    }
  }
  return;
}



/* FUNCTION 11547 ; VA 0x007a9980 ; FUN_007a9980 */

void __thiscall FUN_007a9980(int param_1,int *param_2,int *param_3)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar5 = param_2[1];
  fVar2 = *(float *)(param_1 + 0x28);
  iVar6 = *param_3;
  fVar3 = *(float *)(param_1 + 0x2c);
  iVar7 = param_3[1];
  fVar4 = *(float *)(param_1 + 0x30);
  pfVar1 = (float *)(param_1 + 0x38 + *(int *)(param_1 + 0x34) * 0x10);
  *pfVar1 = (float)*param_2 * *(float *)(param_1 + 0x24);
  pfVar1[1] = (float)iVar5 * fVar2;
  pfVar1[2] = (float)iVar6 * fVar3;
  pfVar1[3] = (float)iVar7 * fVar4;
  *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x34) + 1;
  return;
}



/* FUNCTION 11548 ; VA 0x007a9a00 ; FUN_007a9a00 */

void __thiscall FUN_007a9a00(float *param_1,float *param_2,float param_3,int param_4)

{
  uint uVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  
  fVar18 = *param_1;
  fVar16 = *param_2;
  fVar2 = param_2[1];
  fVar3 = param_2[2];
  iVar6 = (int)(fVar16 / fVar18);
  iVar7 = (int)(fVar2 / fVar18);
  iVar4 = (int)(fVar3 / fVar18);
  fVar19 = (fVar16 - param_3) / fVar18;
  iVar8 = (int)((param_3 + fVar16) / fVar18);
  fVar17 = (fVar2 - param_3) / fVar18;
  iVar5 = (int)((fVar2 + param_3) / fVar18);
  fVar16 = (fVar3 + param_3) / fVar18;
  fVar18 = (fVar3 - param_3) / fVar18;
  iVar12 = iVar8;
  if (iVar6 + 0x3fffffc0U <= iVar8 + 0x3fffffc0U) {
    iVar12 = iVar6;
  }
  iVar9 = iVar5;
  if (iVar7 + 0x3fffffc0U <= iVar5 + 0x3fffffc0U) {
    iVar9 = iVar7;
  }
  iVar13 = (int)fVar16;
  if (iVar4 + 0x3fffffc0U <= (int)fVar16 + 0x3fffffc0U) {
    iVar13 = iVar4;
  }
  iVar10 = (int)fVar19;
  if (iVar12 + 0x3fffffc0U <= (int)fVar19 + 0x3fffffc0U) {
    iVar10 = iVar12;
  }
  iVar11 = (int)fVar17;
  uVar1 = iVar11 + 0x3fffffc0;
  iVar12 = (int)fVar18;
  if (iVar9 + 0x3fffffc0U <= uVar1) {
    iVar11 = iVar9;
  }
  uVar14 = iVar12 + 0x3fffffc0;
  if (iVar13 + 0x3fffffc0U <= uVar14) {
    iVar12 = iVar13;
  }
  uVar15 = iVar12 + 0x3fffffc0;
  if (iVar8 + 0x3fffffc0U <= iVar6 + 0x3fffffc0U) {
    iVar8 = iVar6;
  }
  if (iVar5 + 0x3fffffc0U <= iVar7 + 0x3fffffc0U) {
    iVar5 = iVar7;
  }
  iVar12 = (int)fVar16;
  if ((int)fVar16 + 0x3fffffc0U <= iVar4 + 0x3fffffc0U) {
    iVar12 = iVar4;
  }
  iVar4 = (int)fVar19;
  if ((int)fVar19 + 0x3fffffc0U <= iVar8 + 0x3fffffc0U) {
    iVar4 = iVar8;
  }
  iVar8 = (int)fVar17;
  if (uVar1 <= iVar5 + 0x3fffffc0U) {
    iVar8 = iVar5;
  }
  iVar5 = (int)fVar18;
  if (uVar14 <= iVar12 + 0x3fffffc0U) {
    iVar5 = iVar12;
  }
  for (; uVar1 = iVar11 + 0x3fffffc0, uVar15 <= iVar5 + 0x3fffffc0U; uVar15 = uVar15 + 1) {
    for (; uVar1 <= iVar8 + 0x3fffffc0U; uVar1 = uVar1 + 1) {
      if (iVar10 + 0x3fffffc0U <= iVar4 + 0x3fffffc0U) {
        uVar14 = iVar10 + 0x3fffffc0U;
        do {
          iVar12 = (uVar14 & 0xf) + ((uVar15 & 7) * 0x10 + (uVar1 & 0xf)) * 0x10;
          FUN_007a2730(*(undefined4 *)(param_4 + 4),param_1[iVar12 * 3 + 1],param_1[iVar12 * 3 + 2],
                       uVar1);
          uVar14 = uVar14 + 1;
        } while (uVar14 <= iVar4 + 0x3fffffc0U);
      }
    }
  }
  return;
}



/* FUNCTION 11549 ; VA 0x007a9c60 ; FUN_007a9c60 */

int __thiscall
FUN_007a9c60(int *param_1,int *param_2,char *param_3,char *param_4,undefined4 param_5,
            undefined4 param_6,int param_7)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint3 uVar4;
  char *pcVar5;
  char *pcStack_30;
  uint uStack_2c;
  char *pcStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined uStack_18;
  int iStack_14;
  int *piStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = *(undefined4 *)(*param_1 + 0x4f4);
  if (param_4 == (char *)0x0) {
    uStack_24 = 0;
  }
  else {
    pcVar5 = param_4;
    do {
      cVar2 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar2 != '\0');
    uStack_24 = (int)pcVar5 - (int)(param_4 + 1);
  }
  if (param_3 == (char *)0x0) {
    uStack_2c = 0;
  }
  else {
    pcVar5 = param_3;
    do {
      cVar2 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar2 != '\0');
    uStack_2c = (int)pcVar5 - (int)(param_3 + 1);
  }
  pcStack_30 = param_3;
  pcStack_28 = param_4;
  piStack_c = param_1;
  FUN_00790e00(&iStack_14,&pcStack_30,2);
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_10[1] + -1;
    piStack_10[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      piVar1 = piStack_10 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
  }
  iVar3 = param_7;
  if ((iStack_14 != 0) && (param_7 != 0)) {
    uVar4 = (uint3)param_4;
    param_4 = (char *)(uint)(uVar4 & 0xff);
    uStack_1c = 0x1000100;
    uStack_20 = 0xf;
    uStack_18 = 0;
    uStack_2c = uStack_2c & 0xffff0000;
    pcStack_28 = (char *)0x0;
    uStack_24 = uStack_24 & 0xffffff00;
    (**(code **)(*param_2 + 0x3c))(&uStack_2c,&uStack_20,(int)&param_4 + 1);
    (**(code **)(*param_2 + 0x24))(iStack_14);
    (**(code **)(*param_2 + 0x30))(1,param_5,0x80);
    piVar1 = piStack_c;
    (**(code **)(*param_2 + 0x30))(3,piStack_c + 0xe,0x410);
    (**(code **)(*param_2 + 0x40))(piVar1[7],0,0,0,iVar3 * 6,0);
    return iVar3 * 6;
  }
  return 0;
}



/* FUNCTION 11550 ; VA 0x007a9dc0 ; FUN_007a9dc0 */

void FUN_007a9dc0(int *param_1,int *param_2,int *param_3,undefined4 *param_4,undefined param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  bool bVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  ushort auStack_60 [2];
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  undefined2 uStack_18;
  undefined uStack_16;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b291b;
  pvStack_10 = ExceptionList;
  iVar6 = param_2[1] - *param_2 >> 0x1f;
  if ((param_2[1] - *param_2) / 0x18 + iVar6 != iVar6) {
    uStack_38 = param_4[1];
    uStack_3c = *param_4;
    cStack_11 = *(char *)(param_4 + 4);
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01532c80(uStack_3c,uStack_38);
    uStack_30 = param_4[3];
    uStack_34 = param_4[2];
    uStack_8 = 0;
    uVar10 = FUN_0152d930(uStack_34,uStack_30);
    uStack_58 = param_5;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_48 = 0;
    uStack_40 = 0;
    iStack_20 = 0;
    iStack_24 = 0;
    param_2._3_1_ = true;
    uStack_18 = 0x102;
    uStack_16 = 0;
    uStack_50 = 0x1000100;
    uStack_54 = 0xf;
    uStack_4c = 0;
    auStack_60[0] = 1;
    uStack_5c = 0;
    (**(code **)(*param_1 + 0x3c))(auStack_60,&uStack_54,&uStack_18);
    iStack_2c = *piVar4;
    uStack_28 = 0;
    uStack_1c = (piVar4[1] - iStack_2c) / 0x18;
    if (uStack_1c != 0) {
      do {
        uVar7 = uStack_28;
        iVar6 = *(int *)(iStack_2c + 4 + uStack_28 * 0x18);
        puVar1 = (undefined4 *)(iStack_2c + uStack_28 * 0x18);
        if (iStack_24 != iVar6) {
          iStack_24 = iVar6;
          if ((DAT_01d6c814 != '\0') &&
             (bVar8 = *(char *)(iVar6 + 8) != '\0', param_2._3_1_ != bVar8)) {
            uStack_58 = param_5;
            uStack_50 = 0x1000100;
            uStack_54 = 0xf;
            uStack_4c = 0;
            auStack_60[0] = (ushort)bVar8;
            uStack_5c = 0;
            (**(code **)(*param_1 + 0x3c))(auStack_60,&uStack_54,&uStack_18);
            iVar6 = puVar1[1];
            param_2._3_1_ = bVar8;
          }
          (**(code **)(*param_1 + 0x24))(*(undefined4 *)(iVar6 + 0x24));
          FUN_0078e140(param_1);
          iStack_20 = iStack_20 + 1;
        }
        uVar7 = uVar7 + 1;
        iVar6 = 1;
        if (uVar7 < uStack_1c) {
          iVar5 = puVar1[1];
          piVar4 = puVar1 + 8;
          do {
            if (((piVar4[-1] != iVar5) || (*piVar4 != puVar1[2])) ||
               (*(int *)piVar4[-2] != *(int *)*puVar1)) break;
            iVar5 = puVar1[1];
            uVar7 = uVar7 + 1;
            iVar6 = iVar6 + 1;
            piVar4 = piVar4 + 6;
          } while (uVar7 < uStack_1c);
        }
        (**(code **)(*(int *)*puVar1 + 4))(param_1,puVar1,iVar6,&uStack_48);
        uStack_28 = uStack_28 + iVar6;
      } while (uStack_28 < uStack_1c);
    }
    iVar6 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if ((*(int *)(iVar6 + 0x34) < DAT_01eb25d0) && (FUN_016f3809(&DAT_01eb25d0), DAT_01eb25d0 == -1)
       ) {
      uStack_8._0_1_ = 2;
      uVar11 = FUN_0152da50("Render");
      DAT_01eb25cc = (undefined4)((ulonglong)uVar11 >> 0x20);
      DAT_01eb25c8 = (undefined4)uVar11;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb25d0);
    }
    iVar5 = iStack_20;
    FUN_0152d760(DAT_01eb25c8,DAT_01eb25cc,"%d batches %d materials %d triangles",(int)uStack_48,
                 iStack_20,uStack_48._4_4_ / 3);
    if ((*(int *)(iVar6 + 0x34) < DAT_01eb25e0) && (FUN_016f3809(&DAT_01eb25e0), DAT_01eb25e0 == -1)
       ) {
      uStack_8._0_1_ = 3;
      uVar11 = FUN_0152da50(&DAT_018fb928);
      DAT_01eb25dc = (undefined4)((ulonglong)uVar11 >> 0x20);
      DAT_01eb25d8 = (undefined4)uVar11;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb25e0);
    }
    FUN_0152d760(DAT_01eb25d8,DAT_01eb25dc,"%d batches %d materials %d triangles",(int)uStack_48,
                 iVar5,uStack_48._4_4_ / 3);
    *param_3 = *param_3 + (int)uStack_48;
    param_3[1] = param_3[1] + uStack_48._4_4_;
    param_3[2] = param_3[2] + iVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0152dda0(uStack_34,uStack_30,uVar10);
    uVar3 = uStack_38;
    uVar2 = uStack_3c;
    uStack_8 = 5;
    FUN_0152dda0(uStack_3c,uStack_38,uVar9);
    if ((cStack_11 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532d10(uVar2,uVar3,uVar9);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11551 ; VA 0x007aa160 ; FUN_007aa160 */

void FUN_007aa160(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined auStack_44 [24];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2944;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb25f0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb25f0);
    if (DAT_01eb25f0 == -1) {
      uStack_8 = 0;
      uVar2 = FUN_0152dab0("ShadowMap","renderShadowQueue",0xffffffff);
      DAT_01eb25ec = (undefined4)((ulonglong)uVar2 >> 0x20);
      DAT_01eb25e8 = (undefined4)uVar2;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb25f0);
    }
  }
  uStack_1c = DAT_01eb25e8;
  uStack_2c = DAT_01eb25e8;
  uStack_18 = DAT_01eb25ec;
  uStack_28 = DAT_01eb25ec;
  uStack_24 = FUN_0152d930(DAT_01eb25e8,DAT_01eb25ec);
  uStack_8 = 1;
  uVar1 = FUN_007a5b80(auStack_44);
  FUN_007a9dc0(param_1,param_2,param_3,uVar1,param_4);
  uVar1 = FUN_007a5810(auStack_44);
  FUN_007a9dc0(param_1,param_2 + 0x24,param_3,uVar1,param_4);
  uVar1 = FUN_007a5c80(auStack_44);
  FUN_007a9dc0(param_1,param_2 + 0xc,param_3,uVar1,param_4);
  uVar1 = FUN_007a5d50(auStack_44);
  FUN_007a9dc0(param_1,param_2 + 0x60,param_3,uVar1,param_4);
  uVar1 = FUN_007a59e0(auStack_44);
  FUN_007a9dc0(param_1,param_2 + 0x3c,param_3,uVar1,param_4);
  uVar1 = FUN_007a58e0(auStack_44);
  FUN_007a9dc0(param_1,param_2 + 0x6c,param_3,uVar1,param_4);
  uVar1 = FUN_007a5ab0(auStack_44);
  FUN_007a9dc0(param_1,param_2 + 0x78,param_3,uVar1,param_4);
  uStack_8 = 2;
  FUN_0152dda0(uStack_1c,uStack_18,uStack_24);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11552 ; VA 0x007aa330 ; FUN_007aa330 */

void __fastcall FUN_007aa330(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[4] = 0;
  param_1[3] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[9] = 0;
  param_1[8] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xe] = 0;
  param_1[0xd] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x13] = 0;
  param_1[0x12] = 0;
  if (param_1[0x17] != 0) {
    param_1[0x18] = param_1[0x17];
  }
  param_1[0x17] = 0;
  if (param_1[0x19] != 0) {
    param_1[0x1a] = param_1[0x19];
  }
  param_1[0x19] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  *(undefined2 *)(param_1 + 0x20) = 0;
  return;
}



/* FUNCTION 11553 ; VA 0x007aa420 ; FUN_007aa420 */

void FUN_007aa420(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  int extraout_ECX;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 *puVar10;
  int unaff_EDI;
  undefined4 *puVar11;
  undefined4 auStack_d014 [12288];
  undefined4 auStack_1014 [1018];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  int iVar12;
  
  FUN_016f40d0();
  iVar5 = (**(code **)(**(int **)(*(int *)(extraout_ECX + 4) + 0x3c) + 0x40))();
  if (*(char *)(iVar5 + 0xd) != '\0') {
    iStack_14 = 7;
    puStack_18 = (undefined4 *)0x7aa457;
    (**(code **)(*param_1 + 0x28))();
    puStack_18 = *(undefined4 **)(extraout_ECX + 0x2005c8);
    uStack_1c = 8;
    iStack_20 = 0x7aa466;
    (**(code **)(*param_1 + 0x28))();
    return;
  }
  if ((*(int *)(extraout_ECX + 0x200644) - *(int *)(extraout_ECX + 0x200640) & 0xfffffffcU) != 0) {
    iStack_14 = 0x7aa48e;
    cVar4 = FUN_0078b7c0();
    if (cVar4 != '\0') {
      iVar5 = 0x80;
      do {
        iStack_14 = 0x7aa4a8;
        FUN_007a44a0();
        iVar5 = iVar5 + -1;
      } while (iVar5 != 0);
      iVar5 = 0x80;
      do {
        iStack_14 = 0x7aa4c7;
        FUN_007a44d0();
        iVar5 = iVar5 + -1;
      } while (iVar5 != 0);
      iStack_14 = *(int *)(extraout_ECX + 0x200644) - *(int *)(extraout_ECX + 0x200640) >> 2;
      iVar5 = extraout_ECX;
      if (iStack_14 != 0) {
        piVar9 = *(int **)(extraout_ECX + 0x200640);
        puVar6 = auStack_1014;
        puVar8 = auStack_d014;
        iVar12 = iStack_14;
        do {
          iVar5 = *piVar9;
          piVar9 = piVar9 + 1;
          uVar1 = *(undefined4 *)(iVar5 + 0x30);
          uVar2 = *(undefined4 *)(iVar5 + 0x34);
          uVar3 = *(undefined4 *)(iVar5 + 0x38);
          *puVar6 = *(undefined4 *)(iVar5 + 0x2c);
          puVar6[1] = uVar1;
          puVar6[2] = uVar2;
          puVar6[3] = uVar3;
          uVar1 = *(undefined4 *)(iVar5 + 0x40);
          uVar2 = *(undefined4 *)(iVar5 + 0x44);
          uVar3 = *(undefined4 *)(iVar5 + 0x48);
          iVar12 = iVar12 + -1;
          puVar6[4] = *(undefined4 *)(iVar5 + 0x3c);
          puVar6[5] = uVar1;
          puVar6[6] = uVar2;
          puVar6[7] = uVar3;
          puVar10 = (undefined4 *)(iVar5 + 0x4c);
          puVar11 = puVar8;
          for (iVar7 = 0x60; iVar7 != 0; iVar7 = iVar7 + -1) {
            *puVar11 = *puVar10;
            puVar10 = puVar10 + 1;
            puVar11 = puVar11 + 1;
          }
          puVar6 = puVar6 + 8;
          puVar8 = puVar8 + 0x60;
          iVar5 = unaff_EDI;
        } while (iVar12 != 0);
      }
      puStack_18 = auStack_1014;
      iStack_14 = iStack_14 << 5;
      uStack_1c = 7;
      iStack_20 = 0x7aa54d;
      (**(code **)(*param_1 + 0x30))();
      iStack_20 = (*(int *)(iVar5 + 0x200644) - *(int *)(iVar5 + 0x200640) >> 2) * 0x180;
      puStack_24 = auStack_d014;
      uStack_28 = 8;
      uStack_2c = 0x7aa573;
      (**(code **)(*param_1 + 0x30))();
      return;
    }
    iStack_14 = 0x20;
    iVar5 = **(int **)(extraout_ECX + 0x200640);
    puStack_18 = (undefined4 *)(iVar5 + 0x2c);
    uStack_1c = 7;
    iStack_20 = 0x7aa596;
    (**(code **)(*param_1 + 0x30))();
    puStack_24 = (undefined4 *)(iVar5 + 0x4c);
    iStack_20 = 0x180;
    uStack_28 = 8;
    uStack_2c = 0x7aa5a8;
    (**(code **)(*param_1 + 0x30))();
  }
  return;
}



/* FUNCTION 11554 ; VA 0x007aa5c0 ; FUN_007aa5c0 */

void FUN_007aa5c0(int *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (DAT_01eb25c3 != '\0') {
    return;
  }
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x30))(aiStack_28);
  uStack_8 = 0;
  iVar2 = (**(code **)(*param_1 + 0x40))();
  if ((*(int *)(iVar2 + 0x34) == 0) ||
     (iVar2 = (**(code **)(*param_1 + 0x40))(), *(char *)(iVar2 + 0xe) == '\0')) {
    uVar4 = 0;
  }
  else {
    uVar4 = 1;
  }
  cVar1 = FUN_00558b60(aiStack_28,"metal_ios");
  if (cVar1 == '\0') {
    cVar1 = FUN_00558b60(aiStack_28,"vulkan_mobile");
    if (cVar1 == '\0') {
      cVar1 = FUN_00558b60(aiStack_28,"glsles3");
      if (cVar1 == '\0') goto LAB_007aa694;
      DAT_01eb25c0 = 0;
      DAT_01eb25c1 = DAT_01d6102c;
    }
    else {
      DAT_01eb25c1 = 1;
      DAT_01eb25c0 = uVar4;
    }
  }
  else {
    DAT_01eb25c1 = 1;
    DAT_01eb25c0 = uVar4;
  }
  DAT_01eb25c2 = 1;
LAB_007aa694:
  DAT_01eb25c3 = 1;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11555 ; VA 0x007aa6f0 ; FUN_007aa6f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 __thiscall FUN_007aa6f0(int param_1,int *param_2,int *param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  undefined uVar3;
  undefined *puVar4;
  char cVar5;
  char *pcVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  float fVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  float10 fVar15;
  float10 fVar16;
  undefined4 uVar17;
  double dVar18;
  undefined4 uVar19;
  float fVar20;
  longlong lVar21;
  undefined8 uVar22;
  uint auStack_368 [128];
  undefined auStack_168 [32];
  float fStack_148;
  float fStack_144;
  float fStack_140;
  float fStack_13c;
  float fStack_138;
  float fStack_134;
  float fStack_130;
  float fStack_12c;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  undefined auStack_98 [4];
  uint uStack_94;
  float fStack_90;
  int iStack_8c;
  uint uStack_88;
  int iStack_84;
  undefined8 uStack_80;
  undefined auStack_74 [4];
  int iStack_70;
  float fStack_6c;
  uint uStack_68;
  int *piStack_64;
  int iStack_60;
  float fStack_5c;
  int iStack_58;
  int *piStack_54;
  uint uStack_50;
  int iStack_4c;
  uint uStack_48;
  uint uStack_44;
  float fStack_40;
  uint *puStack_3c;
  float fStack_38;
  float fStack_34;
  undefined8 uStack_30;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b299a;
  pvStack_1c = ExceptionList;
  iStack_8c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_1c;
  iStack_4c = param_1;
  puVar4 = &stack0xfffffffc;
  if ((*(int *)(iStack_8c + 0x34) < DAT_01eb27c0) &&
     (ExceptionList = &pvStack_1c, FUN_016f3809(&DAT_01eb27c0), puVar4 = puStack_20,
     DAT_01eb27c0 == -1)) {
    uStack_14 = 0;
    uVar22 = FUN_0152dab0("ShadowMap","tiledScrollAtlasChart",0xffffffff);
    DAT_01eb27bc = (undefined4)((ulonglong)uVar22 >> 0x20);
    DAT_01eb27b8 = (undefined4)uVar22;
    uStack_14 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb27c0);
    puVar4 = puStack_20;
  }
  puStack_20 = puVar4;
  uStack_a8 = DAT_01eb27b8;
  uStack_c8 = DAT_01eb27b8;
  uStack_a4 = DAT_01eb27bc;
  uStack_c4 = DAT_01eb27bc;
  uStack_c0 = FUN_0152d930(DAT_01eb27b8,DAT_01eb27bc);
  uStack_14 = 1;
  iVar9 = param_3[1];
  puStack_3c = (uint *)*param_3;
  if (iVar9 == 0) {
    pcVar6 = "Scroll_0";
  }
  else if (iVar9 == 1) {
    pcVar6 = "Scroll_1";
  }
  else if (iVar9 == 2) {
    pcVar6 = "Scroll_2";
  }
  else {
    pcVar6 = "Scroll_3";
    if (iVar9 != 3) {
      pcVar6 = "Scroll";
    }
  }
  uStack_b8 = FUN_0152dab0(&DAT_018fb928,pcVar6,0xffffffff);
  uStack_a0 = uStack_b8;
  uStack_b0 = FUN_0152d930(uStack_b8);
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  piStack_54 = (int *)(*(int *)((int)puStack_3c + 8) + iVar9 * 0x278);
  uStack_50 = *(int *)((int)puStack_3c + 0x14) + iVar9 * 0x278;
  if (*piStack_54 != 0) {
    fStack_24 = (float)(param_1 + 0xd8);
    cVar5 = FUN_008363a0(*(undefined4 *)(uStack_50 + 0x260));
    if (cVar5 != '\0') {
      cVar5 = FUN_008363a0(piStack_54[0x98]);
      uVar14 = uStack_50;
      if (((cVar5 != '\0') && (piStack_54[0x98] == *(int *)(uStack_50 + 0x260))) &&
         (DAT_018fe498 <=
          (float)(double)CONCAT44((uint)((ulonglong)(double)param_4 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)param_4,0) & (uint)DAT_018c0da0))) {
        uStack_d8 = 0;
        uStack_d4 = 0;
        uStack_d0 = 0;
        uStack_cc = 0;
        uStack_88 = _DAT_018fe4f0;
        iStack_84 = _UNK_018fe4f4;
        uStack_80._0_4_ = _UNK_018fe4f8;
        uStack_80._4_4_ = _UNK_018fe4fc;
        cVar5 = FUN_0083a2a0(piStack_54 + 3,uStack_50 + 0xc,&uStack_88,&uStack_d8);
        if (cVar5 != '\0') {
          piVar7 = (int *)FUN_008361f0(*(undefined4 *)(uVar14 + 0x260));
          uStack_48 = (uint)piVar7[2] >> 3;
          fStack_5c = (float)((uint)piVar7[3] >> 3);
          piStack_64 = piVar7;
          FUN_0083a5c0(&uStack_e8,&uStack_d8,*piVar7,piVar7[1],piVar7[2],piVar7[3]);
          fVar15 = (float10)FUN_017268ab(uStack_e8);
          iVar11 = *piVar7;
          fStack_24 = (float)fVar15;
          fVar16 = (float10)FUN_017268ab(uStack_e4);
          fStack_24 = (float)fVar16;
          iStack_60 = (iVar11 - (int)fVar15) / (int)uStack_48;
          if ((iVar11 - (int)fVar15) % (int)uStack_48 == 0) {
            iStack_58 = ((int)fVar16 - piStack_64[1]) / (int)fStack_5c;
            fVar10 = (float)(((int)fVar16 - piStack_64[1]) % (int)fStack_5c);
            if (fVar10 == 0.0) {
              iVar11 = uStack_50 + 0x68;
              uStack_30 = 0;
              fStack_34 = fVar10;
              FUN_007a9750(auStack_98,iVar11,&fStack_34);
              fStack_34 = 0.0;
              uStack_30 = (ulonglong)(uint)param_4 << 0x20;
              FUN_007a9750(auStack_74,iVar11,&fStack_34);
              fStack_24 = fStack_6c - fStack_90;
              if (((iStack_60 != 0) || (iStack_58 != 0)) ||
                 (DAT_018fe498 <=
                  (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_24 >> 0x20) &
                                          DAT_018c0da0._4_4_,
                                          SUB84((double)fStack_24,0) & (uint)DAT_018c0da0))) {
                lVar21 = FUN_0083e3f0(iVar9,iStack_60,iStack_58,fStack_24);
                if (lVar21 != 0) {
                  uVar14 = 0x40;
                  do {
                    uVar13 = uVar14;
                    piStack_54 = (int *)((ulonglong)lVar21 >> 0x20);
                    uStack_50 = (uint)lVar21;
                    FUN_0054eb90();
                    lVar21 = CONCAT44(piStack_54,uStack_50);
                    uVar14 = uVar13 - 1;
                  } while (uVar13 - 1 != 0);
                  puStack_3c = auStack_368;
                  uVar12 = 0;
                  uVar14 = 0;
                  uStack_44 = 0;
                  do {
                    if ((uVar13 & uStack_50) != 0 || (uVar12 & (uint)piStack_54) != 0) {
                      fStack_40 = (float)(uVar14 >> 3);
                      *puStack_3c = uVar14 & 7;
                      puStack_3c[1] = (uint)fStack_40;
                      uStack_44 = uStack_44 + 1;
                      puStack_3c = puStack_3c + 2;
                    }
                    iVar9 = iStack_4c;
                    uVar12 = uVar12 << 1 | uVar13 >> 0x1f;
                    uVar14 = uVar14 + 1;
                    uVar13 = uVar13 * 2;
                  } while (uVar14 < 0x40);
                  *(int *)(iStack_4c + 0x206984) = *(int *)(iStack_4c + 0x206984) + uStack_44;
                  if (*(int *)(iStack_8c + 0x34) < DAT_01eb27d0) {
                    FUN_016f3809(&DAT_01eb27d0);
                    if (DAT_01eb27d0 == -1) {
                      uStack_14._0_1_ = 0x13;
                      uVar22 = FUN_0152dab0(&DAT_018fb928,"EVSM Scroll (Remap)",0xffffffff);
                      DAT_01eb27cc = (int)((ulonglong)uVar22 >> 0x20);
                      DAT_01eb27c8 = (uint)uVar22;
                      uStack_14 = CONCAT31(uStack_14._1_3_,2);
                      FUN_016f37bf(&DAT_01eb27d0);
                    }
                  }
                  uStack_68 = DAT_01eb27c8;
                  uStack_88 = DAT_01eb27c8;
                  puStack_3c = (uint *)DAT_01eb27cc;
                  iStack_84 = DAT_01eb27cc;
                  uStack_80 = FUN_0152d930(DAT_01eb27c8,DAT_01eb27cc);
                  uStack_14 = CONCAT31(uStack_14._1_3_,0x14);
                  dVar18 = (double)(fStack_24 * _DAT_018fe4a8);
                  FUN_01727e40();
                  fStack_40 = (float)dVar18;
                  dVar18 = (double)(fStack_24 * _DAT_018fe4c0);
                  FUN_01727e40();
                  *(int *)(iVar9 + 0x206998) = *(int *)(iVar9 + 0x206998) + 1;
                  fStack_24 = (float)dVar18;
                  (**(code **)(*param_2 + 0x14))(*(undefined4 *)(iVar9 + 0x2005f8),0,1,0,0);
                  iVar11 = *(int *)(iVar9 + 0x2005d0);
                  fStack_34 = (float)CONCAT22(fStack_34._2_2_,0x100);
                  uStack_30 = uStack_30 & 0xffff000000000000;
                  (**(code **)(*param_2 + 0x34))(0,iVar11,&fStack_34);
                  fVar10 = fStack_5c;
                  uStack_94 = *(uint *)(iVar11 + 0x30);
                  fStack_90 = *(float *)(iVar11 + 0x34);
                  fStack_6c = *(float *)(*(int *)(iStack_4c + 0x2005f8) + 0x2c);
                  iStack_70 = *(int *)(*(int *)(iStack_4c + 0x2005f8) + 0x28);
                  uStack_30 = CONCAT44(fStack_5c,uStack_48);
                  FUN_007a6ad0(&uStack_30,&iStack_70,&uStack_94);
                  iStack_60 = iStack_60 * uStack_48 + *piStack_64;
                  uVar14 = 0;
                  iStack_58 = iStack_58 * (int)fVar10 + piStack_64[1];
                  if (uStack_44 != 0) {
                    do {
                      iStack_70 = auStack_368[uVar14 * 2] * uStack_48;
                      fStack_6c = (float)(auStack_368[uVar14 * 2 + 1] * (int)fStack_5c);
                      uStack_30 = CONCAT44(iStack_58 + (int)fStack_6c,iStack_60 + iStack_70);
                      FUN_007a9980(&iStack_70,&uStack_30);
                      uVar14 = uVar14 + 1;
                    } while (uVar14 < uStack_44);
                  }
                  iVar11 = iStack_4c;
                  FUN_00829d10(*(undefined4 *)(iStack_4c + 0x2005f8));
                  fStack_38 = fStack_40;
                  fStack_144 = fStack_40 * fStack_40;
                  fStack_13c = fStack_24 * fStack_24;
                  uStack_30 = CONCAT44(fStack_13c,fStack_24);
                  fStack_148 = fStack_40;
                  fStack_140 = fStack_24;
                  uVar17 = (undefined4)DAT_018fe4a0;
                  uVar19 = (undefined4)((ulonglong)DAT_018fe4a0 >> 0x20);
                  fStack_34 = fStack_144;
                  FUN_01727e40();
                  fStack_40 = (float)(double)CONCAT44(uVar19,uVar17);
                  fStack_24 = fStack_40 * fStack_40;
                  uVar17 = (undefined4)DAT_018fe4b8;
                  uVar19 = (undefined4)((ulonglong)DAT_018fe4b8 >> 0x20);
                  FUN_01727e40();
                  fStack_138 = (float)(double)CONCAT44(uVar19,uVar17);
                  fStack_134 = fStack_138 * fStack_138;
                  uStack_30 = CONCAT44(fStack_24,fStack_40);
                  fStack_130 = fStack_40;
                  fStack_12c = fStack_24;
                  fStack_38 = fStack_138;
                  fStack_34 = fStack_134;
                  iVar8 = FUN_007a9c60(param_2,"ShadowEvsmPassThroughVS","ShadowEvsmRemapFS",
                                       auStack_168,0,*(int *)(iVar11 + 0x10015c) + -1);
                  *(int *)(iVar11 + 0x2069a0) = *(int *)(iVar11 + 0x2069a0) + iVar8;
                  *(int *)(iVar11 + 0x2069a4) = *(int *)(iVar11 + 0x2069a4) + 1;
                  *(int *)(iVar11 + 0x20699c) = *(int *)(iVar11 + 0x20699c) + 1;
                  (**(code **)(*param_2 + 0x18))();
                  uStack_14._0_1_ = 0x15;
                  FUN_0152dda0(uStack_68,puStack_3c,uStack_80);
                  uStack_14._0_1_ = 2;
                  uVar3 = (undefined)uStack_14;
                  uStack_14._0_1_ = 2;
                  if (*(int *)(iStack_8c + 0x34) < DAT_01eb27e0) {
                    uStack_14._0_1_ = uVar3;
                    FUN_016f3809(&DAT_01eb27e0);
                    if (DAT_01eb27e0 == -1) {
                      uStack_14._0_1_ = 0x16;
                      uVar22 = FUN_0152dab0(&DAT_018fb928,"EVSM Scroll (Copy)",0xffffffff);
                      DAT_01eb27dc = (undefined4)((ulonglong)uVar22 >> 0x20);
                      DAT_01eb27d8 = (uint)uVar22;
                      uStack_14._0_1_ = 2;
                      FUN_016f37bf(&DAT_01eb27e0);
                    }
                  }
                  fStack_40 = (float)DAT_01eb27d8;
                  uStack_88 = DAT_01eb27d8;
                  uStack_68 = DAT_01eb27dc;
                  iStack_84 = DAT_01eb27dc;
                  uVar22 = FUN_0152d930(DAT_01eb27d8,DAT_01eb27dc);
                  *(int *)(iVar11 + 0x206998) = *(int *)(iVar11 + 0x206998) + 1;
                  uStack_14._0_1_ = 0x17;
                  uStack_80 = uVar22;
                  (**(code **)(*param_2 + 0x14))(*(undefined4 *)(iStack_4c + 0x2005d8),1,1,0,0);
                  fStack_34 = (float)CONCAT22(fStack_34._2_2_,0x100);
                  iVar11 = *(int *)(iStack_4c + 0x2005f0);
                  uStack_30 = uStack_30 & 0xffff000000000000;
                  (**(code **)(*param_2 + 0x34))(0,iVar11,&fStack_34);
                  (**(code **)(*param_2 + 0x1c))
                            (*piStack_64,piStack_64[1],piStack_64[2],piStack_64[3]);
                  uStack_30 = *(undefined8 *)(iVar11 + 0x30);
                  fStack_6c = (float)piStack_64[3];
                  iStack_70 = piStack_64[2];
                  uStack_94 = uStack_48;
                  fStack_90 = fStack_5c;
                  FUN_007a6ad0(&uStack_94,&iStack_70,&uStack_30);
                  iVar11 = iStack_4c;
                  uVar14 = 0;
                  if (uStack_44 != 0) {
                    do {
                      iVar8 = uVar14 * 2;
                      iVar2 = uVar14 * 2;
                      uVar14 = uVar14 + 1;
                      fStack_38 = *(float *)(iVar9 + 0x10014c) *
                                  (float)(int)(auStack_368[iVar8] * uStack_48);
                      fVar20 = (float)(int)(auStack_368[iVar8] * uStack_48) *
                               *(float *)(iVar9 + 0x100154);
                      fStack_34 = (float)(int)(auStack_368[iVar2 + 1] * (int)fStack_5c) *
                                  *(float *)(iVar9 + 0x100150);
                      fVar10 = *(float *)(iVar9 + 0x100158) *
                               (float)(int)(auStack_368[iVar2 + 1] * (int)fStack_5c);
                      uStack_30 = CONCAT44(fVar10,fVar20);
                      pfVar1 = (float *)(iVar9 + 0x100160 + *(int *)(iVar9 + 0x10015c) * 0x10);
                      *pfVar1 = fStack_38;
                      pfVar1[1] = fStack_34;
                      pfVar1[2] = fVar20;
                      pfVar1[3] = fVar10;
                      *(int *)(iVar9 + 0x10015c) = *(int *)(iVar9 + 0x10015c) + 1;
                    } while (uVar14 < uStack_44);
                  }
                  FUN_00829d10(*(undefined4 *)(iStack_4c + 0x2005d8));
                  iVar9 = FUN_007a9c60(param_2,"ShadowEvsmPassThroughVS","ShadowEvsmCopyFS",
                                       auStack_168,0,*(int *)(iVar11 + 0x10015c) + -1);
                  *(int *)(iVar11 + 0x2069a0) = *(int *)(iVar11 + 0x2069a0) + iVar9;
                  *(int *)(iVar11 + 0x2069a4) = *(int *)(iVar11 + 0x2069a4) + 1;
                  *(int *)(iVar11 + 0x20699c) = *(int *)(iVar11 + 0x20699c) + 1;
                  (**(code **)(*param_2 + 0x18))();
                  uStack_14 = CONCAT31(uStack_14._1_3_,0x18);
                  FUN_0152dda0(fStack_40,uStack_68,uStack_80);
                  goto LAB_007aaef0;
                }
              }
            }
          }
        }
      }
    }
  }
  uStack_30 = 0;
  piStack_54 = (int *)0x0;
  uStack_50 = 0;
LAB_007aaef0:
  uStack_14 = CONCAT31(uStack_14._1_3_,0x19);
  FUN_0152dda0(uStack_a0,uStack_b0);
  uStack_14 = 0x1a;
  FUN_0152dda0(uStack_a8,uStack_a4,uStack_c0);
  ExceptionList = pvStack_1c;
  return CONCAT44(piStack_54,uStack_50);
}



/* FUNCTION 11556 ; VA 0x007ab050 ; FUN_007ab050 */

void __thiscall
FUN_007ab050(int *param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5)

{
  uint *puVar1;
  undefined uVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  char cVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  undefined4 *puVar13;
  int *piVar14;
  uint uVar15;
  int *piVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b29d8;
  pvStack_10 = ExceptionList;
  iVar9 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if ((*(int *)(iVar9 + 0x34) < DAT_01eb26f0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb26f0), DAT_01eb26f0 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0("Shadows","updatePerform",0xffffffff);
    DAT_01eb26ec = (undefined4)((ulonglong)uVar17 >> 0x20);
    DAT_01eb26e8 = (undefined4)uVar17;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb26f0);
  }
  uVar6 = DAT_01eb26ec;
  uVar5 = DAT_01eb26e8;
  uVar17 = FUN_0152d930(DAT_01eb26e8,DAT_01eb26ec);
  uStack_8 = 1;
  if (DAT_018fe498 < *(float *)(param_1[0x80188] + 0x4f360) ||
      DAT_018fe498 == *(float *)(param_1[0x80188] + 0x4f360)) {
    FUN_007aa330();
    FUN_007aa330();
    FUN_007aa330();
    FUN_007aa330();
    FUN_008363d0();
    piVar7 = piStack_14;
    param_1[0x80236] = param_4;
    piVar14 = (int *)(param_1[1] + 0x284);
    piVar16 = param_1 + 0x801a5;
    for (iVar11 = 0x91; iVar11 != 0; iVar11 = iVar11 + -1) {
      *piVar16 = *piVar14;
      piVar14 = piVar14 + 1;
      piVar16 = piVar16 + 1;
    }
    puVar1 = (uint *)(piStack_14 + 0x80190);
    piStack_14[0x80238] = *(int *)(*(int *)(piStack_14[1] + 0x4f8) + 0x18);
    piStack_14[0x80239] = piStack_14[2];
    piStack_14[0x801a4] = *(int *)(*(int *)(piStack_14[1] + 0x4fc) + 0x14);
    piStack_14[0x801a3] = *(int *)(*(int *)(piStack_14[1] + 0x4e4) + 0x24);
    piStack_14[0x80237] = (int)(param_1 + 0x36);
    piStack_14[0x801a2] = *(int *)(piStack_14[0x80188] + 0x4f360);
    piStack_14[0x80191] = *puVar1;
    cVar8 = FUN_0078b7c0();
    piVar14 = piVar7;
    if (cVar8 == '\0') {
      if ((piVar7[0x80188] != 0) && (*(char *)(piVar7 + 0x80189) != '\0')) {
        param_4 = piVar7[0x80188];
        FUN_007a42f0(&param_4);
      }
    }
    else {
      FUN_007a6bc0(param_5);
      param_4 = piVar7[0x80188];
      if ((param_4 != 0) && (*(char *)(piVar7 + 0x80189) != '\0')) {
        FUN_007a42f0(&param_4);
      }
      puVar13 = (undefined4 *)piVar7[0x8018d];
      param_4 = 0;
      uVar12 = (uint)(piVar7[0x8018e] + (3 - (int)puVar13)) >> 2;
      if ((undefined4 *)piVar7[0x8018e] < puVar13) {
        uVar12 = 0;
      }
      if (uVar12 != 0) {
        do {
          param_5 = *puVar13;
          puVar3 = (undefined4 *)piVar7[0x80191];
          uStack_18 = param_5;
          if ((undefined4 *)piVar7[0x80192] == puVar3) {
            FUN_0063d9b0(puVar3,&uStack_18);
          }
          else {
            *puVar3 = param_5;
            piVar7[0x80191] = piVar7[0x80191] + 4;
          }
          param_4 = param_4 + 1;
          puVar13 = puVar13 + 1;
          piVar14 = piStack_14;
        } while (param_4 != uVar12);
      }
      if ((0x80 < (uint)((int)(piVar7[0x80191] - *puVar1) >> 2)) &&
         (iVar11 = *puVar1 + 0x200, iVar11 != piVar7[0x80191])) {
        piVar14[0x80191] = iVar11;
      }
    }
    piVar14[0x8018e] = piVar14[0x8018d];
    puVar13 = (undefined4 *)*puVar1;
    uVar15 = 0;
    uVar12 = (uint)(piVar7[0x80191] + (3 - (int)puVar13)) >> 2;
    if ((undefined4 *)piVar7[0x80191] < puVar13) {
      uVar12 = 0;
    }
    if (uVar12 != 0) {
      do {
        (**(code **)(*(int *)*puVar13 + 4))(param_1 + 0x8019f);
        uVar15 = uVar15 + 1;
        puVar13 = puVar13 + 1;
      } while (uVar15 != uVar12);
    }
    if ((*(int *)(iVar9 + 0x34) < DAT_01eb2720) && (FUN_016f3809(&DAT_01eb2720), DAT_01eb2720 == -1)
       ) {
      uStack_8._0_1_ = 3;
      uVar18 = FUN_0152dab0("Shadows","Merge frustums",0xffffffff);
      DAT_01eb271c = (undefined4)((ulonglong)uVar18 >> 0x20);
      DAT_01eb2718 = (uint)uVar18;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2720);
    }
    uVar10 = DAT_01eb271c;
    param_4 = DAT_01eb2718;
    uVar18 = FUN_0152d930(DAT_01eb2718,DAT_01eb271c);
    uStack_8._0_1_ = 4;
    FUN_007a9540();
    uStack_8._0_1_ = 5;
    FUN_0152dda0(param_4,uVar10,uVar18);
    piVar7 = piStack_14;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_007a7ce0(param_2);
    FUN_007ab790(param_3);
    if (*(int **)(piVar7[1] + 0x578) != (int *)0x0) {
      iVar9 = (**(code **)(**(int **)(piVar7[1] + 0x578) + 0x1c))();
      (**(code **)(*piVar7 + 0x14))(iVar9 + 4);
      uVar2 = *(undefined *)(iVar9 + 3);
      pcVar4 = *(code **)(*piVar7 + 0x10);
      uVar10 = FUN_0078ae30();
      (*pcVar4)(uVar10,uVar2);
    }
  }
  else {
    FUN_007ab790(param_3);
  }
  uStack_8 = 6;
  FUN_0152dda0(uVar5,uVar6,uVar17);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11557 ; VA 0x007ab460 ; FUN_007ab460 */

void FUN_007ab460(int param_1)

{
  int iVar1;
  undefined *puVar2;
  undefined uVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined uVar7;
  int iVar8;
  float10 fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  undefined8 uStack_6c;
  uint uStack_64;
  undefined4 uStack_60;
  float fStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  ulonglong uStack_38;
  uint uStack_30;
  int *piStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b2a04;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  puVar2 = &stack0xfffffffc;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb26e0) &&
     (ExceptionList = &pvStack_1c, FUN_016f3809(&DAT_01eb26e0), puVar2 = puStack_20,
     DAT_01eb26e0 == -1)) {
    uStack_14 = 0;
    uVar13 = FUN_0152dab0("Shadows","updatePrepare",0xffffffff);
    DAT_01eb26dc = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb26d8 = (undefined4)uVar13;
    uStack_14 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb26e0);
    puVar2 = puStack_20;
  }
  puStack_20 = puVar2;
  uStack_40 = DAT_01eb26d8;
  uStack_58 = DAT_01eb26d8;
  uStack_3c = DAT_01eb26dc;
  uStack_54 = DAT_01eb26dc;
  uStack_50 = FUN_0152d930(DAT_01eb26d8,DAT_01eb26dc);
  uStack_14 = 1;
  if ((-(uint)(param_1 != 0) & param_1 + 0xcU) == 0) {
    iVar8 = 0;
  }
  else {
    FUN_005789c0(&DAT_01ea8c74,&LAB_005c2480);
    uVar4 = FUN_005c37d0();
    piVar5 = (int *)FUN_008aa140(uVar4);
    piStack_24 = piVar5;
    if (*piVar5 == 0) {
      uVar4 = FUN_009d6050();
      piVar6 = (int *)FUN_008a9ba0(auStack_48,uVar4);
      iVar8 = *piVar6;
      iVar1 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      *piVar5 = iVar8;
      piVar6 = (int *)piVar5[1];
      piVar5[1] = iVar1;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar8 = piVar6[1] + -1;
        piVar6[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar8 = piVar6[2] + -1;
          piVar6[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_44[1] + -1;
        piStack_44[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar5 = piStack_44 + 2;
          iVar8 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar8 == 1) {
            (**(code **)(*piStack_44 + 4))();
          }
        }
      }
    }
    iVar8 = *piStack_24;
  }
  iVar1 = *(int *)(*(int *)(uStack_30 + 4) + 0x4fc);
  fVar9 = (float10)FUN_01156f90(*(undefined4 *)(*(int *)(uStack_30 + 4) + 0x5c4));
  iVar1 = *(int *)(iVar1 + 0x14);
  fVar12 = *(float *)(&DAT_018fe1c8 + iVar1 * 4);
  fVar11 = DAT_018fe4b0;
  if (fVar12 + *(float *)(&DAT_018fe170 + iVar1 * 4) <= DAT_018fe4b0) {
    fVar11 = fVar12 + *(float *)(&DAT_018fe170 + iVar1 * 4);
  }
  piStack_24 = (int *)(float)fVar9;
  if (fVar11 <= (float)fVar9) {
    piStack_24 = (int *)fVar11;
  }
  fVar11 = fVar12;
  if (fVar12 <= DAT_018f784c) {
    fVar11 = DAT_018f784c;
  }
  *(float *)(uStack_30 + 0x10) = (float)piStack_24 - fVar12;
  *(float *)(uStack_30 + 0x14) = DAT_018ce2f8 / fVar11;
  fVar12 = *(float *)(iVar8 + 0x70);
  uStack_38 = (ulonglong)(uint)fVar12;
  dVar10 = (double)(fVar12 * fVar12 + *(float *)(iVar8 + 0x74) * *(float *)(iVar8 + 0x74) +
                   *(float *)(iVar8 + 0x78) * *(float *)(iVar8 + 0x78));
  FUN_017267a0();
  fVar12 = DAT_018ce2f8 / (float)dVar10;
  uStack_6c = CONCAT44((uint)(*(float *)(iVar8 + 0x74) * fVar12) ^ DAT_018c4ea0,
                       (uint)((float)uStack_38 * fVar12) ^ DAT_018c4ea0);
  uStack_64 = (uint)(*(float *)(iVar8 + 0x78) * fVar12) ^ DAT_018c4ea0;
  if ((*(char *)(iVar8 + 0x11c) == '\0') || (*(float *)(iVar8 + 0x100) <= DAT_018fd178)) {
    uVar3 = 0;
  }
  else {
    uVar3 = 1;
  }
  fStack_5c = (float)piStack_24;
  uVar7 = 0;
  if (DAT_018fe498 <= (float)piStack_24) {
    uVar7 = uVar3;
  }
  piVar5 = (int *)(uStack_30 + 4);
  *(undefined *)(uStack_30 + 0x200624) = uVar7;
  uStack_60 = *(undefined4 *)(iVar8 + 0x120);
  uStack_30 = uStack_64;
  FUN_0083f6a0(&uStack_6c,*(undefined4 *)(*(int *)(*piVar5 + 0x4e4) + 0x24));
  uStack_14 = 2;
  FUN_0152dda0(uStack_40,uStack_3c,uStack_50);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 11558 ; VA 0x007ab790 ; FUN_007ab790 */

void __thiscall FUN_007ab790(int param_1,int param_2)

{
  int iVar1;
  float fVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  float fVar11;
  undefined4 *puStack_8;
  
  fVar11 = 0.0;
  if (0.0 <= (float)DAT_01d60ff0 * DAT_018fd178) {
    fVar11 = (float)DAT_01d60ff0 * DAT_018fd178;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar11 <= DAT_018ce2f8) {
    fVar2 = fVar11;
  }
  *(float *)(param_2 + 0x2f4) = fVar2;
  *(undefined4 *)(param_2 + 0x2e0) = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_2 + 0x2e4) = *(undefined4 *)(param_1 + 0x14);
  FUN_00840f80(param_2);
  *(undefined4 *)(param_2 + 0x2e8) = 0x40b147ae;
  *(undefined4 *)(param_2 + 0x2ec) = 0x40b147ae;
  fVar11 = DAT_018ce2f8;
  if (*(char *)(param_1 + 0x200624) == '\0') {
    fVar11 = 0.0;
  }
  *(float *)(param_2 + 0x2f0) = fVar11;
  puVar6 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x2005c0) + 0x10))();
  puStack_8 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x2005c8) + 0x10))();
  uVar8 = 0;
  if (*(int *)(param_1 + 0x200644) - *(int *)(param_1 + 0x200640) >> 2 != 0) {
    do {
      iVar1 = *(int *)(*(int *)(param_1 + 0x200640) + uVar8 * 4);
      uVar8 = uVar8 + 1;
      uVar3 = *(undefined4 *)(iVar1 + 0x30);
      uVar4 = *(undefined4 *)(iVar1 + 0x34);
      uVar5 = *(undefined4 *)(iVar1 + 0x38);
      *puVar6 = *(undefined4 *)(iVar1 + 0x2c);
      puVar6[1] = uVar3;
      puVar6[2] = uVar4;
      puVar6[3] = uVar5;
      uVar3 = *(undefined4 *)(iVar1 + 0x40);
      uVar4 = *(undefined4 *)(iVar1 + 0x44);
      uVar5 = *(undefined4 *)(iVar1 + 0x48);
      puVar6[4] = *(undefined4 *)(iVar1 + 0x3c);
      puVar6[5] = uVar3;
      puVar6[6] = uVar4;
      puVar6[7] = uVar5;
      puVar9 = (undefined4 *)(iVar1 + 0x4c);
      puVar10 = puStack_8;
      for (iVar7 = 0x60; iVar7 != 0; iVar7 = iVar7 + -1) {
        *puVar10 = *puVar9;
        puVar9 = puVar9 + 1;
        puVar10 = puVar10 + 1;
      }
      puVar6 = puVar6 + 8;
      puStack_8 = puStack_8 + 0x60;
    } while (uVar8 < (uint)(*(int *)(param_1 + 0x200644) - *(int *)(param_1 + 0x200640) >> 2));
  }
  (**(code **)(**(int **)(param_1 + 0x2005c0) + 0x14))();
  (**(code **)(**(int **)(param_1 + 0x2005c8) + 0x14))();
  return;
}



/* FUNCTION 11559 ; VA 0x007ab8c0 ; FUN_007ab8c0 */

undefined FUN_007ab8c0(void)

{
  return DAT_01eb25c0;
}



/* FUNCTION 11560 ; VA 0x007ab8d0 ; FUN_007ab8d0 */

void FUN_007ab8d0(int *param_1,int *param_2,undefined4 *param_3,undefined4 param_4,int param_5,
                 undefined4 param_6,int param_7)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  char *pcVar6;
  int *piVar7;
  int iVar8;
  char *pcVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  uint uVar12;
  undefined8 uVar13;
  undefined auStack_fc [16];
  float fStack_ec;
  float fStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  undefined4 ***pppuStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined2 auStack_3c [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2a34;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb27b0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb27b0);
    if (DAT_01eb27b0 == -1) {
      uStack_8 = 0;
      uVar13 = FUN_0152dab0(&DAT_018fb928,"EVSM VBlur",0xffffffff);
      DAT_01eb27ac = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01eb27a8 = (undefined4)uVar13;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb27b0);
    }
  }
  uStack_54 = DAT_01eb27a8;
  uStack_7c = DAT_01eb27a8;
  uStack_50 = DAT_01eb27ac;
  uStack_78 = DAT_01eb27ac;
  uStack_74 = FUN_0152d930(DAT_01eb27a8,DAT_01eb27ac);
  uStack_8 = 1;
  puVar5 = (undefined4 *)
           FUN_008361f0(*(undefined4 *)(param_2[1] * 0x278 + *(int *)(*param_2 + 0x14) + 0x260));
  if (param_2[1] == 0) {
    iStack_30 = 0;
  }
  else {
    iStack_30 = (**(code **)(*(int *)*param_2 + 8))(param_2[1]);
    if (iStack_30 != 0) {
      uStack_24 = (uint)puVar5[2] >> 3;
      uStack_2c = (uint)puVar5[3] >> 3;
      goto LAB_007ab9a3;
    }
  }
  uStack_24 = puVar5[2];
  uStack_2c = puVar5[3];
LAB_007ab9a3:
  iVar8 = param_2[4];
  auStack_3c[0] = 0x101;
  uStack_38 = 0;
  uStack_34 = (uint)uStack_34._2_2_ << 0x10;
  iStack_1c = *(int *)(iStack_14 + 0x2005f0);
  uStack_4c = *puVar5;
  uVar2 = puVar5[1];
  (**(code **)(*param_1 + 0x34))(0,iStack_1c,auStack_3c);
  iVar3 = iStack_14;
  FUN_00829d10(*(undefined4 *)(iStack_14 + 0x2005d8));
  fStack_ec = DAT_018ce2f8 /
              (float)((double)*(int *)(iStack_1c + 0x30) +
                     (double)(&DAT_018c0d90)[-(*(int *)(iStack_1c + 0x30) >> 0x1f)]);
  uStack_e4 = 0x40b147ae;
  uStack_e0 = 0x40b147ae;
  fStack_e8 = DAT_018ce2f8 /
              (float)((double)*(int *)(iStack_1c + 0x34) +
                     (double)(&DAT_018c0d90)[-(*(int *)(iStack_1c + 0x34) >> 0x1f)]);
  uStack_dc = *param_3;
  uStack_d8 = param_3[1];
  uStack_d4 = param_3[2];
  uStack_d0 = param_3[3];
  pcVar6 = (char *)FUN_007a8e30(iVar8,auStack_fc);
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  pcVar9 = pcVar6;
  do {
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar6,(int)pcVar9 - (int)(pcVar6 + 1));
  uStack_8._0_1_ = 2;
  piVar7 = (int *)FUN_00585d40(0,"ShadowEvsmVBlur",0xf);
  pppuStack_6c = (undefined4 ***)*piVar7;
  iStack_68 = piVar7[1];
  iStack_64 = piVar7[2];
  iStack_60 = piVar7[3];
  uStack_5c = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_8._0_1_ = 4;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_34) {
    uVar11 = uStack_34 + 1;
    uVar12 = uStack_48;
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(uStack_48 - 4);
      uVar11 = uStack_34 + 0x24;
      if (0x1f < (uStack_48 - uVar12) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar11);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_20 = *(undefined4 *)(iStack_1c + 0x30);
  piVar7 = (int *)(iStack_14 + 0x2005d8);
  iStack_14 = *(undefined4 *)(*piVar7 + 0x2c);
  uStack_18 = *(undefined4 *)(*piVar7 + 0x28);
  uStack_28 = uStack_24;
  uStack_24 = uStack_2c;
  iStack_1c = *(undefined4 *)(iStack_1c + 0x34);
  FUN_007a6ad0(&uStack_28,&uStack_18,&uStack_20);
  FUN_007a97e0(param_2,iStack_30,uStack_4c,uVar2,param_4,param_7 + param_5);
  ppppuVar10 = &pppuStack_6c;
  if (0xf < uStack_5c._4_4_) {
    ppppuVar10 = (undefined4 ****)pppuStack_6c;
  }
  iVar8 = FUN_007a9c60(param_1,"ShadowEvsmPassThroughVS",ppppuVar10,auStack_fc,0,
                       *(int *)(iVar3 + 0x10015c) + -1);
  *(int *)(iVar3 + 0x2069a0) = *(int *)(iVar3 + 0x2069a0) + iVar8;
  *(int *)(iVar3 + 0x2069a4) = *(int *)(iVar3 + 0x2069a4) + 1;
  *(int *)(iVar3 + 0x20699c) = *(int *)(iVar3 + 0x20699c) + 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_5c._4_4_) {
    uVar12 = uStack_5c._4_4_ + 1;
    ppppuVar10 = (undefined4 ****)pppuStack_6c;
    if (0xfff < uVar12) {
      ppppuVar10 = (undefined4 ****)pppuStack_6c[-1];
      uVar12 = uStack_5c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_6c + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar10,uVar12);
  }
  uStack_5c = 0xf00000000;
  pppuStack_6c = (undefined4 ***)((uint)pppuStack_6c & 0xffffff00);
  uStack_8 = 5;
  FUN_0152dda0(uStack_54,uStack_50,uStack_74);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11561 ; VA 0x007abcc0 ; FUN_007abcc0 */

void FUN_007abcc0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined auStack_64 [24];
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  float fStack_38;
  float fStack_2c;
  float fStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  uint uStack_14;
  undefined4 *puStack_10;
  int iStack_c;
  undefined4 *puStack_8;
  
  uStack_14 = 0;
  if (param_2 != 0) {
    do {
      iStack_c = *(int *)(param_1 + uStack_14 * 4);
      iStack_18 = *(int *)(iStack_c + 0x20);
      puStack_8 = (undefined4 *)(*(int *)(iStack_18 + 0xac) + *(int *)(iStack_c + 0x24) * 0x70);
      if (*(int *)(iStack_c + 0x28) == -1) {
        puStack_10 = (undefined4 *)0x0;
      }
      else {
        puStack_10 = (undefined4 *)(*(int *)(iStack_c + 0x28) * 0x70 + *(int *)(iStack_18 + 0x88));
      }
      iVar15 = *(int *)(iStack_c + 0x24);
      iVar2 = *(int *)(iStack_18 + 0xb8);
      puStack_1c = (undefined4 *)FUN_00b077e0();
      *puStack_8 = *puStack_1c;
      puStack_8[1] = puStack_1c[1];
      puStack_8[2] = puStack_1c[2];
      puStack_8[3] = puStack_1c[9];
      puStack_8[4] = puStack_1c[3];
      puStack_8[5] = puStack_1c[4];
      puStack_8[6] = puStack_1c[5];
      puStack_8[7] = puStack_1c[10];
      puStack_8[8] = puStack_1c[6];
      puStack_8[9] = puStack_1c[7];
      puStack_8[10] = puStack_1c[8];
      puStack_8[0xb] = puStack_1c[0xb];
      fStack_38 = *(float *)(iStack_c + 0x3c) + 0.0;
      fStack_44 = 0.0 - *(float *)(iStack_c + 0x3c);
      uStack_4c = CONCAT44(0.0 - *(float *)(iStack_c + 0x38),0.0 - *(float *)(iStack_c + 0x34));
      uStack_40 = CONCAT44(*(float *)(iStack_c + 0x38) + 0.0,*(float *)(iStack_c + 0x34) + 0.0);
      fStack_2c = fStack_38;
      fStack_20 = fStack_44;
      puVar14 = (undefined4 *)FUN_00c9f550(auStack_64,puStack_1c);
      uVar3 = puVar14[1];
      uVar4 = puVar14[2];
      uVar5 = puVar14[3];
      puVar1 = (undefined4 *)(iVar2 + iVar15 * 0x18);
      *puVar1 = *puVar14;
      puVar1[1] = uVar3;
      puVar1[2] = uVar4;
      puVar1[3] = uVar5;
      *(undefined8 *)(iVar2 + 0x10 + iVar15 * 0x18) = *(undefined8 *)(puVar14 + 4);
      *(uint *)(iStack_18 + 0xd0) = *(uint *)(iStack_18 + 0xd0) | 1;
      iVar15 = *(int *)(iStack_c + 0x30);
      if (-1 < iVar15) {
        uVar3 = puStack_1c[1];
        uVar4 = puStack_1c[2];
        uVar5 = puStack_1c[3];
        iVar2 = *(int *)(*(int *)(iStack_c + 0x1c) + 0xd0);
        uVar6 = puStack_1c[4];
        uVar7 = puStack_1c[5];
        uVar8 = puStack_1c[6];
        uVar9 = puStack_1c[7];
        uVar10 = puStack_1c[8];
        uVar11 = puStack_1c[9];
        uVar12 = puStack_1c[10];
        uVar13 = puStack_1c[0xb];
        puVar1 = (undefined4 *)(iVar2 + 0xc + iVar15 * 0x3c);
        *puVar1 = *puStack_1c;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        puVar1 = (undefined4 *)(iVar2 + 0x1c + iVar15 * 0x3c);
        *puVar1 = uVar6;
        puVar1[1] = uVar7;
        puVar1[2] = uVar8;
        puVar1[3] = uVar9;
        puVar1 = (undefined4 *)(iVar2 + 0x2c + iVar15 * 0x3c);
        *puVar1 = uVar10;
        puVar1[1] = uVar11;
        puVar1[2] = uVar12;
        puVar1[3] = uVar13;
      }
      if (puStack_10 != (undefined4 *)0x0) {
        for (iVar15 = 0x1c; iVar15 != 0; iVar15 = iVar15 + -1) {
          *puStack_10 = *puStack_8;
          puStack_8 = puStack_8 + 1;
          puStack_10 = puStack_10 + 1;
        }
      }
      uStack_14 = uStack_14 + 1;
    } while (uStack_14 < param_2);
  }
  return;
}



/* FUNCTION 11562 ; VA 0x007abe60 ; FUN_007abe60 */

void FUN_007abe60(int param_1,uint param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined auStack_5c [24];
  undefined8 uStack_44;
  float fStack_3c;
  undefined8 uStack_38;
  float fStack_30;
  float fStack_24;
  float fStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  undefined4 *puStack_8;
  
  uStack_c = 0;
  if (param_2 != 0) {
    do {
      iStack_10 = *(int *)(param_1 + uStack_c * 4);
      iStack_14 = *(int *)(iStack_10 + 0x20);
      puStack_8 = (undefined4 *)(*(int *)(iStack_14 + 0xac) + *(int *)(iStack_10 + 0x24) * 0x70);
      if (*(int *)(iStack_10 + 0x28) == -1) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        puVar8 = (undefined4 *)(*(int *)(iStack_10 + 0x28) * 0x70 + *(int *)(iStack_14 + 0x88));
      }
      iVar7 = *(int *)(iStack_10 + 0x24);
      iVar1 = *(int *)(iStack_14 + 0xb8);
      puVar5 = (undefined4 *)FUN_00b077e0();
      *puStack_8 = *puVar5;
      puStack_8[1] = puVar5[1];
      puStack_8[2] = puVar5[2];
      puStack_8[3] = puVar5[9];
      puStack_8[4] = puVar5[3];
      puStack_8[5] = puVar5[4];
      puStack_8[6] = puVar5[5];
      puStack_8[7] = puVar5[10];
      puStack_8[8] = puVar5[6];
      puStack_8[9] = puVar5[7];
      puStack_8[10] = puVar5[8];
      puStack_8[0xb] = puVar5[0xb];
      fStack_30 = *(float *)(iStack_10 + 0x3c) + 0.0;
      fStack_3c = 0.0 - *(float *)(iStack_10 + 0x3c);
      uStack_44 = CONCAT44(0.0 - *(float *)(iStack_10 + 0x38),0.0 - *(float *)(iStack_10 + 0x34));
      uStack_38 = CONCAT44(*(float *)(iStack_10 + 0x38) + 0.0,*(float *)(iStack_10 + 0x34) + 0.0);
      fStack_24 = fStack_30;
      fStack_18 = fStack_3c;
      puVar6 = (undefined4 *)FUN_00c9f550(auStack_5c,puVar5);
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      puVar5 = (undefined4 *)(iVar1 + iVar7 * 0x18);
      *puVar5 = *puVar6;
      puVar5[1] = uVar2;
      puVar5[2] = uVar3;
      puVar5[3] = uVar4;
      *(undefined8 *)(iVar1 + 0x10 + iVar7 * 0x18) = *(undefined8 *)(puVar6 + 4);
      *(uint *)(iStack_14 + 0xd0) = *(uint *)(iStack_14 + 0xd0) | 1;
      if (puVar8 != (undefined4 *)0x0) {
        for (iVar7 = 0x1c; iVar7 != 0; iVar7 = iVar7 + -1) {
          *puVar8 = *puStack_8;
          puStack_8 = puStack_8 + 1;
          puVar8 = puVar8 + 1;
        }
      }
      uStack_c = uStack_c + 1;
    } while (uStack_c < param_2);
  }
  return;
}



/* FUNCTION 11563 ; VA 0x007ac340 ; FUN_007ac340 */

void FUN_007ac340(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  bool bVar14;
  int iVar15;
  float *pfVar16;
  float *pfVar17;
  undefined8 *puVar18;
  undefined4 *puVar19;
  uint uVar20;
  int iVar21;
  undefined4 *puVar22;
  float10 fVar23;
  float fVar24;
  double dVar25;
  float fStack_ec;
  undefined8 uStack_d8;
  float fStack_d0;
  undefined8 uStack_cc;
  float fStack_c4;
  float fStack_c0;
  undefined4 uStack_bc;
  int iStack_b8;
  float fStack_b4;
  float fStack_b0;
  undefined4 *puStack_ac;
  undefined4 *puStack_a8;
  uint uStack_a4;
  float fStack_a0;
  int iStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined8 uStack_80;
  float fStack_78;
  undefined8 uStack_74;
  float fStack_6c;
  undefined8 auStack_68 [2];
  float fStack_54;
  float fStack_48;
  float fStack_3c;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_a4 = 0;
  if (param_2 != 0) {
    do {
      iVar21 = *(int *)(param_1 + uStack_a4 * 4);
      iVar8 = *(int *)(iVar21 + 0x20);
      iVar9 = *(int *)(iVar21 + 0x24);
      puVar22 = (undefined4 *)(*(int *)(iVar8 + 0xac) + iVar9 * 0x70);
      if (*(int *)(iVar21 + 0x28) == -1) {
        puStack_a8 = (undefined4 *)0x0;
      }
      else {
        puStack_a8 = (undefined4 *)(*(int *)(iVar21 + 0x28) * 0x70 + *(int *)(iVar8 + 0x88));
      }
      uVar10 = *(uint *)(iVar21 + 4);
      iVar11 = *(int *)(iVar8 + 0xb8);
      FUN_00b06fb0(auStack_68);
      puStack_ac = (undefined4 *)FUN_00b077e0();
      pfVar16 = (float *)FUN_00b08320();
      pfVar17 = (float *)FUN_0074adf0(auStack_38);
      fStack_ec = *pfVar16 / *pfVar17;
      fStack_b4 = pfVar16[1] / pfVar17[1];
      uStack_cc = CONCAT44(fStack_b4,fStack_ec);
      fStack_c4 = pfVar16[2] / pfVar17[2];
      fStack_b0 = fStack_c4;
      puVar18 = (undefined8 *)FUN_00b08320();
      uStack_d8 = *puVar18;
      fStack_d0 = *(float *)(puVar18 + 1);
      iStack_b8 = *(int *)(uVar10 + 0x17c);
      iStack_9c = FUN_00b084e0();
      if (fStack_ec < DAT_018c45c4) {
        uStack_98 = uStack_cc;
      }
      else {
        fStack_c4 = fStack_d0;
        fStack_b0 = fStack_d0;
        uStack_cc._4_4_ = (float)((ulonglong)uStack_d8 >> 0x20);
        fStack_b4 = uStack_cc._4_4_;
        uStack_cc._0_4_ = (float)uStack_d8;
        uStack_98 = uStack_d8;
        fStack_ec = (float)uStack_cc;
      }
      if ((iStack_b8 == 0) || (puVar18 = &DAT_01d61bd4, iStack_9c == 0x630)) {
        puVar18 = auStack_68;
      }
      uStack_88 = *puVar18;
      uVar12 = *(undefined4 *)(puVar18 + 1);
      uVar2 = *(undefined4 *)(uVar10 + 0xd0);
      uStack_cc = uStack_98;
      fStack_c0 = fStack_c4;
      fVar23 = (float10)FUN_00b08910();
      iVar15 = iStack_9c;
      *puVar22 = *puStack_ac;
      puVar22[1] = puStack_ac[1];
      puVar22[2] = puStack_ac[2];
      puVar22[3] = puStack_ac[9];
      puVar22[4] = puStack_ac[3];
      puVar22[5] = puStack_ac[4];
      puVar22[6] = puStack_ac[5];
      puVar22[7] = puStack_ac[10];
      puVar22[8] = puStack_ac[6];
      puVar22[9] = puStack_ac[7];
      puVar22[10] = puStack_ac[8];
      puVar22[0xb] = puStack_ac[0xb];
      *(undefined8 *)(puVar22 + 0xc) = uStack_98;
      *(undefined8 *)(puVar22 + 0x10) = uStack_88;
      puVar22[0xe] = fStack_c0;
      puVar22[0x12] = uVar12;
      *(undefined8 *)(puVar22 + 0x18) = 0;
      *(undefined8 *)(puVar22 + 0x14) = DAT_018fe520;
      puVar22[0x16] = DAT_018fe528;
      fStack_a0 = (float)((float10)1 - fVar23);
      puVar22[0x13] = fStack_a0;
      FUN_00764100(&uStack_bc,iStack_9c);
      puVar22[0xf] = 0;
      fVar23 = (float10)FUN_00767900(uStack_bc);
      puVar22[0x1a] = (float)fVar23;
      puVar22[0x1b] = (float)(int)uStack_bc._2_2_ / DAT_018f9000;
      puVar22[0x17] = uVar2;
      if (iStack_b8 == 0) {
        fVar23 = (float10)FUN_00764430(iVar15);
        fVar24 = (float)fVar23;
        FUN_0074b590(&uStack_90,&uStack_d8,(uVar10 >> 3) + uVar10,iVar15);
        puVar22[0x14] = fVar24 * fStack_ec;
        puVar22[0x15] = fStack_b4 * fVar24;
        puVar22[0x16] = fStack_b0 * fVar24;
        puVar22[0x18] = uStack_90;
        puVar22[0x19] = uStack_8c;
      }
      fStack_6c = fStack_d0 * DAT_018ce2f4 + 0.0;
      fStack_78 = 0.0 - fStack_d0 * DAT_018ce2f4;
      uStack_80 = CONCAT44(0.0 - uStack_d8._4_4_ * DAT_018ce2f4,
                           0.0 - (float)uStack_d8 * DAT_018ce2f4);
      uStack_74 = CONCAT44(uStack_d8._4_4_ * DAT_018ce2f4 + 0.0,
                           (float)uStack_d8 * DAT_018ce2f4 + 0.0);
      fStack_54 = fStack_78;
      fStack_48 = fStack_6c;
      puVar19 = (undefined4 *)FUN_00c9f550(auStack_20,puStack_ac);
      fVar24 = DAT_018ce2f4;
      uVar2 = puVar19[1];
      uVar12 = puVar19[2];
      uVar13 = puVar19[3];
      puVar1 = (undefined4 *)(iVar11 + iVar9 * 0x18);
      *puVar1 = *puVar19;
      puVar1[1] = uVar2;
      puVar1[2] = uVar12;
      puVar1[3] = uVar13;
      *(undefined8 *)(iVar11 + 0x10 + iVar9 * 0x18) = *(undefined8 *)(puVar19 + 4);
      fStack_3c = fStack_d0 * fVar24;
      *(ulonglong *)(iVar21 + 0x34) = CONCAT44(uStack_d8._4_4_ * fVar24,(float)uStack_d8 * fVar24);
      *(float *)(iVar21 + 0x3c) = fStack_3c;
      iVar9 = *(int *)(*(int *)(iVar21 + 0x1c) + 0x8c);
      if (((*(float *)(iVar9 + 0x24) <= *(float *)(iVar21 + 0x34)) ||
          (*(float *)(iVar9 + 0x28) <= *(float *)(iVar21 + 0x38))) ||
         (*(float *)(iVar9 + 0x2c) <= *(float *)(iVar21 + 0x3c))) {
        bVar14 = true;
      }
      else {
        bVar14 = false;
      }
      uVar20 = *(uint *)(iVar21 + 0x2c) | 0x200;
      if (!bVar14) {
        uVar20 = *(uint *)(iVar21 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar21 + 0x2c) = uVar20;
      *(uint *)(iVar8 + 0xd0) = *(uint *)(iVar8 + 0xd0) | 1;
      if (-1 < *(int *)(iVar21 + 0x30)) {
        FUN_00d38fb0(*(int *)(iVar21 + 0x30),uVar10,0,iVar21);
      }
      if (*(int *)(uVar10 + 0x150) == 0) {
        pfVar16 = (float *)FUN_00b08320();
        pfVar17 = (float *)FUN_0074adf0(auStack_2c);
        fVar24 = *pfVar16;
        fVar3 = *pfVar17;
        fVar4 = pfVar16[1];
        fVar5 = pfVar17[1];
        fVar6 = pfVar16[2];
        fVar7 = pfVar17[2];
        fVar23 = (float10)FUN_00b4dfe0();
        dVar25 = (double)((fVar4 / fVar5) * (fVar4 / fVar5) + (fVar24 / fVar3) * (fVar24 / fVar3) +
                         (fVar6 / fVar7) * (fVar6 / fVar7));
        FUN_017267a0();
        fVar24 = (float)dVar25 * (float)fVar23;
      }
      else {
        fVar24 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar24 = 0.0;
      }
      puVar22[0xf] = (fVar24 + DAT_018fd178) * DAT_018e1340 * DAT_018f7864;
      if (puStack_a8 != (undefined4 *)0x0) {
        for (iVar21 = 0x1c; iVar21 != 0; iVar21 = iVar21 + -1) {
          *puStack_a8 = *puVar22;
          puVar22 = puVar22 + 1;
          puStack_a8 = puStack_a8 + 1;
        }
      }
      uStack_a4 = uStack_a4 + 1;
    } while (uStack_a4 < param_2);
  }
  return;
}



/* FUNCTION 11564 ; VA 0x007ac8e0 ; FUN_007ac8e0 */

void FUN_007ac8e0(int param_1,uint param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined8 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  bool bVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  float *pfVar15;
  float *pfVar16;
  undefined8 *puVar17;
  undefined4 *puVar18;
  uint uVar19;
  int iVar20;
  float10 fVar21;
  float fVar22;
  float fVar23;
  double dVar24;
  float fVar25;
  undefined4 *puStack_a8;
  uint uStack_a4;
  undefined8 uStack_98;
  float fStack_8c;
  float fStack_88;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined8 uStack_74;
  float fStack_6c;
  undefined8 uStack_68;
  float fStack_60;
  float fStack_54;
  float fStack_48;
  float fStack_3c;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_a4 = 0;
  if (param_2 != 0) {
    do {
      iVar20 = *(int *)(param_1 + uStack_a4 * 4);
      iVar5 = *(int *)(iVar20 + 0x20);
      iVar6 = *(int *)(iVar20 + 0x24);
      puVar13 = (undefined4 *)(*(int *)(iVar5 + 0xac) + iVar6 * 0x70);
      if (*(int *)(iVar20 + 0x28) == -1) {
        puStack_a8 = (undefined4 *)0x0;
      }
      else {
        puStack_a8 = (undefined4 *)(*(int *)(iVar20 + 0x28) * 0x70 + *(int *)(iVar5 + 0x88));
      }
      iVar7 = *(int *)(iVar20 + 4);
      iVar8 = *(int *)(iVar5 + 0xb8);
      FUN_00b06fb0(&uStack_80);
      puVar14 = (undefined4 *)FUN_00b077e0();
      pfVar15 = (float *)FUN_00b08320();
      pfVar16 = (float *)FUN_0074adf0(auStack_38);
      fVar23 = *pfVar15;
      fVar1 = *pfVar16;
      uStack_98 = CONCAT44(pfVar15[1] / pfVar16[1],fVar23 / fVar1);
      fVar22 = pfVar15[2] / pfVar16[2];
      puVar17 = (undefined8 *)FUN_00b08320();
      uVar4 = *puVar17;
      fVar25 = *(float *)(puVar17 + 1);
      if (DAT_018c45c4 <= fVar23 / fVar1) {
        uStack_98 = *puVar17;
        fVar22 = fVar25;
      }
      fVar21 = (float10)FUN_00b08910();
      *puVar13 = *puVar14;
      puVar13[1] = puVar14[1];
      puVar13[2] = puVar14[2];
      puVar13[3] = puVar14[9];
      puVar13[4] = puVar14[3];
      puVar13[5] = puVar14[4];
      puVar13[6] = puVar14[5];
      puVar13[7] = puVar14[10];
      puVar13[8] = puVar14[6];
      puVar13[9] = puVar14[7];
      puVar13[10] = puVar14[8];
      puVar13[0xb] = puVar14[0xb];
      *(undefined8 *)(puVar13 + 0xc) = uStack_98;
      puVar13[0xe] = fVar22;
      *(undefined8 *)(puVar13 + 0x10) = uStack_80;
      puVar13[0x12] = uStack_78;
      *(undefined8 *)(puVar13 + 0x18) = 0;
      *(undefined8 *)(puVar13 + 0x14) = DAT_018fe520;
      puVar13[0x16] = DAT_018fe528;
      puVar13[0x13] = (float)((float10)1 - fVar21);
      puVar13[0xf] = 0;
      fVar21 = (float10)FUN_00767900(0x80);
      fVar23 = DAT_018ce2f4;
      fStack_8c = (float)uVar4;
      fStack_88 = (float)((ulonglong)uVar4 >> 0x20);
      fStack_8c = fStack_8c * DAT_018ce2f4;
      puVar13[0x1b] = 0;
      fVar25 = fVar25 * fVar23;
      puVar13[0x17] = 0;
      fStack_88 = fStack_88 * fVar23;
      fStack_60 = fVar25 + 0.0;
      puVar13[0x1a] = (float)fVar21;
      fStack_6c = 0.0 - fVar25;
      uStack_74 = CONCAT44(0.0 - fStack_88,0.0 - fStack_8c);
      uStack_68 = CONCAT44(fStack_88 + 0.0,fStack_8c + 0.0);
      fStack_54 = fStack_6c;
      fStack_48 = fStack_60;
      puVar18 = (undefined4 *)FUN_00c9f550(auStack_20,puVar14);
      uVar9 = puVar18[1];
      uVar10 = puVar18[2];
      uVar11 = puVar18[3];
      puVar14 = (undefined4 *)(iVar8 + iVar6 * 0x18);
      *puVar14 = *puVar18;
      puVar14[1] = uVar9;
      puVar14[2] = uVar10;
      puVar14[3] = uVar11;
      *(undefined8 *)(iVar8 + 0x10 + iVar6 * 0x18) = *(undefined8 *)(puVar18 + 4);
      *(ulonglong *)(iVar20 + 0x34) = CONCAT44(fStack_88,fStack_8c);
      *(float *)(iVar20 + 0x3c) = fVar25;
      iVar6 = *(int *)(*(int *)(iVar20 + 0x1c) + 0x8c);
      if (((*(float *)(iVar6 + 0x24) <= *(float *)(iVar20 + 0x34)) ||
          (*(float *)(iVar6 + 0x28) <= *(float *)(iVar20 + 0x38))) ||
         (*(float *)(iVar6 + 0x2c) <= *(float *)(iVar20 + 0x3c))) {
        bVar12 = true;
      }
      else {
        bVar12 = false;
      }
      uVar19 = *(uint *)(iVar20 + 0x2c) | 0x200;
      if (!bVar12) {
        uVar19 = *(uint *)(iVar20 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar20 + 0x2c) = uVar19;
      *(uint *)(iVar5 + 0xd0) = *(uint *)(iVar5 + 0xd0) | 1;
      fStack_3c = fVar25;
      if (-1 < *(int *)(iVar20 + 0x30)) {
        FUN_00d38fb0(*(int *)(iVar20 + 0x30),iVar7,0,iVar20);
      }
      if (*(int *)(iVar7 + 0x150) == 0) {
        pfVar15 = (float *)FUN_00b08320();
        pfVar16 = (float *)FUN_0074adf0(auStack_2c);
        fVar23 = *pfVar15;
        fVar1 = *pfVar16;
        fVar25 = pfVar15[1];
        fVar22 = pfVar16[1];
        fVar2 = pfVar15[2];
        fVar3 = pfVar16[2];
        fVar21 = (float10)FUN_00b4dfe0();
        dVar24 = (double)((fVar25 / fVar22) * (fVar25 / fVar22) +
                          (fVar23 / fVar1) * (fVar23 / fVar1) + (fVar2 / fVar3) * (fVar2 / fVar3));
        FUN_017267a0();
        fVar23 = (float)dVar24 * (float)fVar21;
      }
      else {
        fVar23 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar23 = 0.0;
      }
      puVar13[0xf] = (fVar23 + DAT_018fd178) * DAT_018e1340 * DAT_018f7864;
      if (puStack_a8 != (undefined4 *)0x0) {
        for (iVar20 = 0x1c; iVar20 != 0; iVar20 = iVar20 + -1) {
          *puStack_a8 = *puVar13;
          puVar13 = puVar13 + 1;
          puStack_a8 = puStack_a8 + 1;
        }
      }
      uStack_a4 = uStack_a4 + 1;
    } while (uStack_a4 < param_2);
  }
  return;
}



/* FUNCTION 11565 ; VA 0x007acd40 ; FUN_007acd40 */

void FUN_007acd40(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  bool bVar11;
  undefined4 uVar12;
  undefined8 *puVar13;
  float *pfVar14;
  float *pfVar15;
  undefined4 *puVar16;
  uint uVar17;
  int iVar18;
  undefined4 *puVar19;
  float10 fVar20;
  double dVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  undefined4 uStack_bc;
  undefined4 *puStack_b8;
  uint uStack_b4;
  undefined4 *puStack_b0;
  undefined4 *puStack_ac;
  float fStack_a8;
  float fStack_a4;
  ulonglong uStack_a0;
  undefined8 uStack_94;
  float fStack_8c;
  ulonglong uStack_88;
  undefined8 uStack_80;
  float fStack_78;
  undefined8 uStack_74;
  float fStack_6c;
  float fStack_60;
  float fStack_54;
  float fStack_48;
  float fStack_3c;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_b4 = 0;
  if (param_2 != 0) {
    do {
      iVar18 = *(int *)(param_1 + uStack_b4 * 4);
      iVar6 = *(int *)(iVar18 + 0x20);
      iVar7 = *(int *)(iVar18 + 0x24);
      puStack_ac = (undefined4 *)(*(int *)(iVar6 + 0xac) + iVar7 * 0x70);
      if (*(int *)(iVar18 + 0x28) == -1) {
        puStack_b8 = (undefined4 *)0x0;
      }
      else {
        puStack_b8 = (undefined4 *)(*(int *)(iVar18 + 0x28) * 0x70 + *(int *)(iVar6 + 0x88));
      }
      iVar8 = *(int *)(iVar6 + 0xb8);
      iVar9 = *(int *)(*(int *)(iVar18 + 0x48) + 4);
      uStack_a0 = *(undefined8 *)(*(int *)(iVar18 + 0x40) + 0x9c);
      uVar10 = *(undefined4 *)(*(int *)(iVar18 + 0x40) + 0xa4);
      puStack_b0 = (undefined4 *)FUN_00b077e0();
      uVar12 = FUN_00b084e0();
      puVar13 = (undefined8 *)FUN_00b08320();
      fStack_8c = *(float *)(puVar13 + 1);
      uStack_94 = *puVar13;
      pfVar14 = (float *)FUN_00b08320();
      pfVar15 = (float *)FUN_0074adf0(auStack_38);
      uStack_88 = (ulonglong)(uint)(*pfVar14 / *pfVar15);
      fStack_a8 = pfVar14[1] / pfVar15[1];
      fStack_60 = pfVar14[2] / pfVar15[2];
      uVar2 = *(undefined4 *)(iVar9 + 0xd0);
      fVar20 = (float10)FUN_00d00910();
      puVar19 = puStack_ac;
      puVar1 = puStack_b0;
      *puStack_ac = *puStack_b0;
      puStack_ac[1] = puStack_b0[1];
      puStack_ac[2] = puStack_b0[2];
      puStack_ac[3] = puStack_b0[9];
      puStack_ac[4] = puStack_b0[3];
      puStack_ac[5] = puStack_b0[4];
      puStack_ac[6] = puStack_b0[5];
      puStack_ac[7] = puStack_b0[10];
      puStack_ac[8] = puStack_b0[6];
      puStack_ac[9] = puStack_b0[7];
      puStack_ac[10] = puStack_b0[8];
      puStack_ac[0xb] = puStack_b0[0xb];
      *(ulonglong *)(puStack_ac + 0x10) = uStack_a0;
      *(ulonglong *)(puStack_ac + 0xc) = CONCAT44(fStack_a8,(int)uStack_88);
      fStack_a4 = (float)((float10)1 - fVar20);
      puStack_ac[0xe] = fStack_60;
      puStack_ac[0x12] = uVar10;
      *(undefined8 *)(puStack_ac + 0x18) = 0;
      *(undefined8 *)(puStack_ac + 0x14) = DAT_018fe520;
      puStack_ac[0x16] = DAT_018fe528;
      puStack_ac[0x13] = fStack_a4;
      FUN_00764100(&uStack_bc,uVar12);
      puVar19[0xf] = 0x3f800000;
      fVar20 = (float10)FUN_00767900(uStack_bc);
      puVar19[0x1a] = (float)fVar20;
      puVar19[0x1b] = (float)(int)uStack_bc._2_2_ / DAT_018f9000;
      puVar19[0x17] = uVar2;
      fVar22 = (float)uStack_94 * DAT_018ce2f4;
      fVar23 = fStack_8c * DAT_018ce2f4;
      fVar24 = uStack_94._4_4_ * DAT_018ce2f4;
      uStack_a0 = (ulonglong)(uint)fVar22;
      fStack_6c = fVar23 + 0.0;
      fStack_78 = 0.0 - fVar23;
      uStack_80 = CONCAT44(0.0 - fVar24,0.0 - fVar22);
      uStack_74 = CONCAT44(fVar24 + 0.0,fVar22 + 0.0);
      fStack_54 = fStack_78;
      fStack_48 = fStack_6c;
      puVar16 = (undefined4 *)FUN_00c9f550(auStack_20,puVar1);
      uVar2 = puVar16[1];
      uVar10 = puVar16[2];
      uVar12 = puVar16[3];
      puVar1 = (undefined4 *)(iVar8 + iVar7 * 0x18);
      *puVar1 = *puVar16;
      puVar1[1] = uVar2;
      puVar1[2] = uVar10;
      puVar1[3] = uVar12;
      *(undefined8 *)(iVar8 + 0x10 + iVar7 * 0x18) = *(undefined8 *)(puVar16 + 4);
      *(ulonglong *)(iVar18 + 0x34) = CONCAT44(fVar24,(int)uStack_a0);
      *(float *)(iVar18 + 0x3c) = fVar23;
      iVar7 = *(int *)(*(int *)(iVar18 + 0x1c) + 0x8c);
      if (((*(float *)(iVar7 + 0x24) <= *(float *)(iVar18 + 0x34)) ||
          (*(float *)(iVar7 + 0x28) <= *(float *)(iVar18 + 0x38))) ||
         (*(float *)(iVar7 + 0x2c) <= *(float *)(iVar18 + 0x3c))) {
        bVar11 = true;
      }
      else {
        bVar11 = false;
      }
      uVar17 = *(uint *)(iVar18 + 0x2c) | 0x200;
      if (!bVar11) {
        uVar17 = *(uint *)(iVar18 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar18 + 0x2c) = uVar17;
      *(uint *)(iVar6 + 0xd0) = *(uint *)(iVar6 + 0xd0) | 1;
      fStack_3c = fVar23;
      if (*(int *)(iVar9 + 0x150) == 0) {
        pfVar14 = (float *)FUN_00b08320();
        pfVar15 = (float *)FUN_0074adf0(auStack_2c);
        fVar22 = *pfVar14;
        fVar23 = *pfVar15;
        fVar24 = pfVar14[1];
        fVar3 = pfVar15[1];
        fVar4 = pfVar14[2];
        fVar5 = pfVar15[2];
        fVar20 = (float10)FUN_00b4dfe0();
        dVar21 = (double)((fVar24 / fVar3) * (fVar24 / fVar3) +
                          (fVar22 / fVar23) * (fVar22 / fVar23) + (fVar4 / fVar5) * (fVar4 / fVar5))
        ;
        FUN_017267a0();
        fVar22 = (float)dVar21 * (float)fVar20;
      }
      else {
        fVar22 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar22 = 0.0;
      }
      puVar19[0xf] = (fVar22 + DAT_018fd178) * DAT_018e1340;
      if (puStack_b8 != (undefined4 *)0x0) {
        for (iVar18 = 0x1c; iVar18 != 0; iVar18 = iVar18 + -1) {
          *puStack_b8 = *puVar19;
          puVar19 = puVar19 + 1;
          puStack_b8 = puStack_b8 + 1;
        }
      }
      uStack_b4 = uStack_b4 + 1;
    } while (uStack_b4 < param_2);
  }
  return;
}



/* FUNCTION 11566 ; VA 0x007ad1b0 ; FUN_007ad1b0 */

void FUN_007ad1b0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  bool bVar12;
  undefined4 uVar13;
  undefined8 *puVar14;
  float *pfVar15;
  float *pfVar16;
  undefined4 *puVar17;
  uint uVar18;
  int iVar19;
  undefined4 *puVar20;
  float10 fVar21;
  double dVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  undefined4 *puStack_a8;
  uint uStack_a4;
  ulonglong uStack_a0;
  undefined8 uStack_94;
  float fStack_8c;
  ulonglong uStack_88;
  undefined8 uStack_80;
  float fStack_78;
  undefined8 uStack_74;
  float fStack_6c;
  float fStack_60;
  float fStack_54;
  float fStack_48;
  float fStack_3c;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_a4 = 0;
  if (param_2 != 0) {
    do {
      iVar19 = *(int *)(param_1 + uStack_a4 * 4);
      iVar5 = *(int *)(iVar19 + 0x20);
      iVar6 = *(int *)(iVar19 + 0x24);
      puVar20 = (undefined4 *)(*(int *)(iVar5 + 0xac) + iVar6 * 0x70);
      if (*(int *)(iVar19 + 0x28) == -1) {
        puStack_a8 = (undefined4 *)0x0;
      }
      else {
        puStack_a8 = (undefined4 *)(*(int *)(iVar19 + 0x28) * 0x70 + *(int *)(iVar5 + 0x88));
      }
      iVar7 = *(int *)(iVar5 + 0xb8);
      iVar8 = *(int *)(iVar19 + 0x40);
      iVar9 = *(int *)(*(int *)(iVar19 + 0x48) + 4);
      uStack_a0 = *(undefined8 *)(iVar8 + 0x9c);
      uVar10 = *(undefined4 *)(iVar8 + 0xa4);
      puStack_ac = (undefined4 *)FUN_00b077e0();
      uVar13 = FUN_00b084e0();
      puVar14 = (undefined8 *)FUN_00b08320();
      fStack_8c = *(float *)(puVar14 + 1);
      uStack_94 = *puVar14;
      pfVar15 = (float *)FUN_00b08320();
      pfVar16 = (float *)FUN_0074adf0(auStack_38);
      uStack_88 = (ulonglong)(uint)(*pfVar15 / *pfVar16);
      fVar25 = pfVar15[1];
      fVar26 = pfVar16[1];
      fStack_60 = pfVar15[2] / pfVar16[2];
      uVar2 = *(undefined4 *)(iVar9 + 0xd0);
      fVar21 = (float10)FUN_00d00910();
      *puVar20 = *puStack_ac;
      puVar20[1] = puStack_ac[1];
      puVar20[2] = puStack_ac[2];
      puVar20[3] = puStack_ac[9];
      puVar20[4] = puStack_ac[3];
      puVar20[5] = puStack_ac[4];
      puVar20[6] = puStack_ac[5];
      puVar20[7] = puStack_ac[10];
      puVar20[8] = puStack_ac[6];
      puVar20[9] = puStack_ac[7];
      puVar20[10] = puStack_ac[8];
      puVar20[0xb] = puStack_ac[0xb];
      *(ulonglong *)(puVar20 + 0xc) = CONCAT44(fVar25 / fVar26,(int)uStack_88);
      puVar20[0xe] = fStack_60;
      *(ulonglong *)(puVar20 + 0x10) = uStack_a0;
      puVar20[0x12] = uVar10;
      *(undefined8 *)(puVar20 + 0x18) = 0;
      *(undefined8 *)(puVar20 + 0x14) = DAT_018fe520;
      puVar20[0x16] = DAT_018fe528;
      puVar20[0x13] = (float)((float10)1 - fVar21);
      FUN_00764100(&uStack_b0,uVar13);
      puVar20[0xf] = 0x3f800000;
      fVar21 = (float10)FUN_00767900(uStack_b0);
      fVar24 = DAT_018ce2f8;
      puVar20[0x1a] = (float)fVar21;
      puVar20[0x1b] = (float)(int)uStack_b0._2_2_ / DAT_018f9000;
      puVar20[0x17] = uVar2;
      fVar23 = fVar24 / *(float *)(iVar8 + 0xa8);
      iVar11 = *(int *)(iVar8 + 0x70);
      fVar24 = fVar24 / *(float *)(iVar8 + 0xac);
      puVar20[*(int *)(&DAT_018fed5c + iVar11 * 8) + 0x14] = fVar23;
      puVar20[*(int *)(&DAT_018fed60 + iVar11 * 8) + 0x14] = fVar24;
      fVar25 = *(float *)(&DAT_018feddc + iVar11 * 0xc);
      puVar20[0x14] = (float)puVar20[0x14] * (float)uStack_94;
      puVar20[0x15] = (float)puVar20[0x15] * uStack_94._4_4_;
      puVar20[0x16] = (float)puVar20[0x16] * fStack_8c;
      fVar26 = *(float *)(&DAT_018fed90 + iVar11 * 0xc);
      fVar27 = *(float *)(&DAT_018fed94 + iVar11 * 0xc);
      fVar3 = *(float *)(&DAT_018fed98 + iVar11 * 0xc);
      fVar4 = *(float *)(iVar8 + 0xb0);
      puVar20[0x19] =
           (*(float *)(iVar8 + 0xb4) -
           (fVar25 * uStack_94._4_4_ + *(float *)(&DAT_018fedd8 + iVar11 * 0xc) * (float)uStack_94 +
           *(float *)(&DAT_018fede0 + iVar11 * 0xc) * fStack_8c) * DAT_018ce2f4) * fVar24;
      puVar20[0x18] =
           (fVar4 - (fVar27 * uStack_94._4_4_ + fVar26 * (float)uStack_94 + fVar3 * fStack_8c) *
                    DAT_018ce2f4) * fVar23;
      fVar27 = (float)uStack_94 * DAT_018ce2f4;
      fVar26 = uStack_94._4_4_ * DAT_018ce2f4;
      fVar25 = fStack_8c * DAT_018ce2f4;
      uStack_a0 = (ulonglong)(uint)fVar27;
      fStack_6c = fVar25 + 0.0;
      fStack_78 = 0.0 - fVar25;
      uStack_74 = CONCAT44(fVar26 + 0.0,fVar27 + 0.0);
      uStack_80 = CONCAT44(0.0 - fVar26,0.0 - fVar27);
      fStack_54 = fStack_78;
      fStack_48 = fStack_6c;
      puVar17 = (undefined4 *)FUN_00c9f550(auStack_20,puStack_ac);
      uVar2 = puVar17[1];
      uVar10 = puVar17[2];
      uVar13 = puVar17[3];
      puVar1 = (undefined4 *)(iVar7 + iVar6 * 0x18);
      *puVar1 = *puVar17;
      puVar1[1] = uVar2;
      puVar1[2] = uVar10;
      puVar1[3] = uVar13;
      *(undefined8 *)(iVar7 + 0x10 + iVar6 * 0x18) = *(undefined8 *)(puVar17 + 4);
      *(ulonglong *)(iVar19 + 0x34) = CONCAT44(fVar26,(int)uStack_a0);
      *(float *)(iVar19 + 0x3c) = fVar25;
      iVar6 = *(int *)(*(int *)(iVar19 + 0x1c) + 0x8c);
      if (((*(float *)(iVar6 + 0x24) <= *(float *)(iVar19 + 0x34)) ||
          (*(float *)(iVar6 + 0x28) <= *(float *)(iVar19 + 0x38))) ||
         (bVar12 = false, *(float *)(iVar6 + 0x2c) <= *(float *)(iVar19 + 0x3c))) {
        bVar12 = true;
      }
      uVar18 = *(uint *)(iVar19 + 0x2c) | 0x200;
      if (!bVar12) {
        uVar18 = *(uint *)(iVar19 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar19 + 0x2c) = uVar18;
      *(uint *)(iVar5 + 0xd0) = *(uint *)(iVar5 + 0xd0) | 1;
      fStack_3c = fVar25;
      if (*(int *)(iVar9 + 0x150) == 0) {
        pfVar15 = (float *)FUN_00b08320();
        pfVar16 = (float *)FUN_0074adf0(auStack_2c);
        fVar25 = *pfVar15;
        fVar26 = *pfVar16;
        fVar27 = pfVar15[1];
        fVar3 = pfVar16[1];
        fVar4 = pfVar15[2];
        fVar24 = pfVar16[2];
        fVar21 = (float10)FUN_00b4dfe0();
        dVar22 = (double)((fVar27 / fVar3) * (fVar27 / fVar3) +
                          (fVar25 / fVar26) * (fVar25 / fVar26) +
                         (fVar4 / fVar24) * (fVar4 / fVar24));
        FUN_017267a0();
        fVar25 = (float)dVar22 * (float)fVar21;
      }
      else {
        fVar25 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar25 = 0.0;
      }
      puVar20[0xf] = (fVar25 + DAT_018fd178) * DAT_018e1340;
      if (puStack_a8 != (undefined4 *)0x0) {
        for (iVar19 = 0x1c; iVar19 != 0; iVar19 = iVar19 + -1) {
          *puStack_a8 = *puVar20;
          puVar20 = puVar20 + 1;
          puStack_a8 = puStack_a8 + 1;
        }
      }
      uStack_a4 = uStack_a4 + 1;
    } while (uStack_a4 < param_2);
  }
  return;
}



/* FUNCTION 11567 ; VA 0x007ad730 ; FUN_007ad730 */

void FUN_007ad730(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  ushort uVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 uVar12;
  bool bVar13;
  undefined4 *puVar14;
  undefined8 *puVar15;
  undefined4 uVar16;
  int iVar17;
  int iVar18;
  undefined4 *puVar19;
  float *pfVar20;
  uint uVar21;
  int iVar22;
  float10 fVar23;
  double dVar24;
  float fVar25;
  undefined4 uStack_d8;
  undefined4 *puStack_d4;
  undefined4 *puStack_d0;
  uint uStack_cc;
  undefined8 uStack_c8;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  float afStack_a8 [4];
  undefined8 uStack_98;
  float fStack_90;
  undefined8 uStack_8c;
  float fStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined auStack_74 [12];
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  float fStack_48;
  float fStack_3c;
  float fStack_30;
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_cc = 0;
  if (param_2 != 0) {
    do {
      iVar22 = *(int *)(param_1 + uStack_cc * 4);
      iVar8 = *(int *)(iVar22 + 0x20);
      iVar9 = *(int *)(iVar22 + 0x24);
      puVar14 = (undefined4 *)(*(int *)(iVar8 + 0xac) + iVar9 * 0x70);
      if (*(int *)(iVar22 + 0x28) == -1) {
        puStack_d0 = (undefined4 *)0x0;
      }
      else {
        puStack_d0 = (undefined4 *)(*(int *)(iVar22 + 0x28) * 0x70 + *(int *)(iVar8 + 0x88));
      }
      uVar10 = *(uint *)(iVar22 + 4);
      iVar11 = *(int *)(iVar8 + 0xb8);
      puStack_d4 = (undefined4 *)FUN_00b077e0();
      puVar15 = (undefined8 *)FUN_00b08320();
      uStack_c8 = *puVar15;
      fStack_c0 = *(float *)(puVar15 + 1);
      FUN_00b54150(&fStack_bc);
      uStack_78 = DAT_01d61bdc;
      uStack_80 = DAT_01d61bd4;
      FUN_00b06fb0(auStack_74);
      uStack_68 = DAT_01d61bbc;
      uStack_60 = DAT_01d61bc4;
      uStack_5c = DAT_01d61bbc;
      uStack_54 = DAT_01d61bc4;
      fVar23 = (float10)FUN_00b08910();
      afStack_a8[0] = (float)((float10)1 - fVar23);
      fVar23 = (float10)FUN_00b08910();
      afStack_a8[2] = 0.5882353;
      afStack_a8[3] = 0.5882353;
      afStack_a8[1] = (float)((float10)1 - fVar23);
      uVar16 = FUN_00b084e0();
      iVar18 = *(int *)(uVar10 + 0xc);
      iVar17 = FUN_00b50140();
      uVar5 = *(ushort *)(iVar18 + 0x1d8);
      uVar6 = *(ushort *)(iVar17 + 0x1d8);
      uVar7 = *(ushort *)(iVar17 + 0x1da);
      if (*(char *)(uVar10 + 0x198) == '\0') {
        iVar18 = FUN_00b084e0();
        if (iVar18 == 0x630) goto LAB_007ad8a1;
        iVar18 = 0;
      }
      else {
LAB_007ad8a1:
        iVar18 = 1;
      }
      uVar2 = *(undefined4 *)(uVar10 + 0xd0);
      iVar17 = (-(uint)((uint)uVar7 < (uint)uVar5 - (uint)uVar6) & 0xfffffffe) + 2 + iVar18;
      *puVar14 = *puStack_d4;
      puVar14[1] = puStack_d4[1];
      puVar14[2] = puStack_d4[2];
      puVar14[3] = puStack_d4[9];
      puVar14[4] = puStack_d4[3];
      puVar14[5] = puStack_d4[4];
      puVar14[6] = puStack_d4[5];
      puVar14[7] = puStack_d4[10];
      puVar14[8] = puStack_d4[6];
      puVar14[9] = puStack_d4[7];
      puVar14[10] = puStack_d4[8];
      puVar14[0xb] = puStack_d4[0xb];
      *(ulonglong *)(puVar14 + 0xc) = CONCAT44(fStack_b8,fStack_bc);
      puVar14[0xe] = fStack_b4;
      *(undefined8 *)(puVar14 + 0x10) = *(undefined8 *)((int)&uStack_80 + iVar17 * 0xc);
      puVar14[0x12] = *(undefined4 *)(auStack_74 + iVar17 * 0xc + -4);
      *(undefined8 *)(puVar14 + 0x18) = 0;
      *(undefined8 *)(puVar14 + 0x14) = DAT_018fe520;
      puVar14[0x16] = DAT_018fe528;
      puVar14[0x13] = afStack_a8[iVar17];
      FUN_00764100(&uStack_d8,uVar16);
      puVar14[0xf] = (float)((double)iVar18 + DAT_018c0d90);
      fVar23 = (float10)FUN_00767900(uStack_d8);
      puVar14[0x1a] = (float)fVar23;
      puVar14[0x1b] = (float)(int)uStack_d8._2_2_ / DAT_018f9000;
      puVar14[0x17] = uVar2;
      fVar23 = (float10)FUN_00764430(uVar16);
      fVar25 = (float)fVar23;
      FUN_0074b590(&uStack_b0,&uStack_c8,(uVar10 >> 3) + uVar10,uVar16);
      puVar14[0x14] = fStack_bc * fVar25;
      puVar14[0x15] = fStack_b8 * fVar25;
      puVar14[0x16] = fStack_b4 * fVar25;
      fVar25 = DAT_018ce2f4;
      puVar14[0x18] = uStack_b0;
      puVar14[0x19] = uStack_ac;
      fStack_84 = fStack_c0 * fVar25 + 0.0;
      fStack_90 = 0.0 - fStack_c0 * fVar25;
      uStack_98 = CONCAT44(0.0 - uStack_c8._4_4_ * fVar25,0.0 - (float)uStack_c8 * fVar25);
      uStack_8c = CONCAT44(uStack_c8._4_4_ * fVar25 + 0.0,(float)uStack_c8 * fVar25 + 0.0);
      fStack_48 = fStack_90;
      fStack_3c = fStack_84;
      puVar19 = (undefined4 *)FUN_00c9f550(auStack_20,puStack_d4);
      fVar25 = DAT_018ce2f4;
      uVar16 = puVar19[1];
      uVar2 = puVar19[2];
      uVar12 = puVar19[3];
      puVar1 = (undefined4 *)(iVar11 + iVar9 * 0x18);
      *puVar1 = *puVar19;
      puVar1[1] = uVar16;
      puVar1[2] = uVar2;
      puVar1[3] = uVar12;
      *(undefined8 *)(iVar11 + 0x10 + iVar9 * 0x18) = *(undefined8 *)(puVar19 + 4);
      fStack_30 = fStack_c0 * fVar25;
      *(ulonglong *)(iVar22 + 0x34) = CONCAT44(uStack_c8._4_4_ * fVar25,(float)uStack_c8 * fVar25);
      *(float *)(iVar22 + 0x3c) = fStack_30;
      iVar9 = *(int *)(*(int *)(iVar22 + 0x1c) + 0x8c);
      if (((*(float *)(iVar9 + 0x24) <= *(float *)(iVar22 + 0x34)) ||
          (*(float *)(iVar9 + 0x28) <= *(float *)(iVar22 + 0x38))) ||
         (*(float *)(iVar9 + 0x2c) <= *(float *)(iVar22 + 0x3c))) {
        bVar13 = true;
      }
      else {
        bVar13 = false;
      }
      uVar21 = *(uint *)(iVar22 + 0x2c) | 0x200;
      if (!bVar13) {
        uVar21 = *(uint *)(iVar22 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar22 + 0x2c) = uVar21;
      *(uint *)(iVar8 + 0xd0) = *(uint *)(iVar8 + 0xd0) | 1;
      if (*(int *)(uVar10 + 0x188) == 0) {
        pfVar20 = (float *)FUN_00b54150(auStack_2c);
        fVar25 = pfVar20[1];
        fVar3 = *pfVar20;
        fVar4 = pfVar20[2];
        fVar23 = (float10)FUN_00b4dfe0();
        dVar24 = (double)(fVar3 * fVar3 + fVar25 * fVar25 + fVar4 * fVar4);
        FUN_017267a0();
        fVar25 = (float)dVar24 * (float)fVar23;
      }
      else {
        fVar25 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar25 = 0.0;
      }
      puVar14[0xf] = (((float)iVar18 + (float)iVar18) - DAT_018ce2f8) *
                     (fVar25 + DAT_018fd178) * DAT_018e1340;
      if (-1 < *(int *)(iVar22 + 0x30)) {
        FUN_00d38fb0(*(int *)(iVar22 + 0x30),uVar10,0,iVar22);
      }
      if (puStack_d0 != (undefined4 *)0x0) {
        for (iVar22 = 0x1c; iVar22 != 0; iVar22 = iVar22 + -1) {
          *puStack_d0 = *puVar14;
          puVar14 = puVar14 + 1;
          puStack_d0 = puStack_d0 + 1;
        }
      }
      uStack_cc = uStack_cc + 1;
    } while (uStack_cc < param_2);
  }
  return;
}



/* FUNCTION 11568 ; VA 0x007adca0 ; FUN_007adca0 */

void FUN_007adca0(int param_1,uint param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  bool bVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined8 *puVar10;
  undefined4 *puVar11;
  float *pfVar12;
  uint uVar13;
  int iVar14;
  undefined4 *puVar15;
  float10 fVar16;
  double dVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  uint uStack_8c;
  ulonglong uStack_88;
  undefined8 uStack_80;
  float fStack_78;
  undefined8 uStack_74;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  float fStack_48;
  float fStack_3c;
  float fStack_30;
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_8c = 0;
  if (param_2 != 0) {
    do {
      iVar14 = *(int *)(param_1 + uStack_8c * 4);
      iVar2 = *(int *)(iVar14 + 0x20);
      iVar3 = *(int *)(iVar14 + 0x24);
      puVar15 = (undefined4 *)(*(int *)(iVar2 + 0xac) + iVar3 * 0x70);
      if (*(int *)(iVar14 + 0x28) == -1) {
        puStack_90 = (undefined4 *)0x0;
      }
      else {
        puStack_90 = (undefined4 *)(*(int *)(iVar14 + 0x28) * 0x70 + *(int *)(iVar2 + 0x88));
      }
      iVar4 = *(int *)(iVar2 + 0xb8);
      iVar5 = *(int *)(*(int *)(iVar14 + 0x48) + 4);
      puVar8 = (undefined4 *)FUN_00b077e0();
      uVar9 = FUN_00b084e0();
      puVar10 = (undefined8 *)FUN_00b08320();
      fStack_78 = *(float *)(puVar10 + 1);
      uStack_80 = *puVar10;
      FUN_00b54150(&uStack_74);
      uStack_88 = *(undefined8 *)(*(int *)(iVar14 + 0x40) + 0x9c);
      uVar6 = *(undefined4 *)(*(int *)(iVar14 + 0x40) + 0xa4);
      uVar1 = *(undefined4 *)(iVar5 + 0xd0);
      fVar16 = (float10)FUN_00d00910();
      *puVar15 = *puVar8;
      puVar15[1] = puVar8[1];
      puVar15[2] = puVar8[2];
      puVar15[3] = puVar8[9];
      puVar15[4] = puVar8[3];
      puVar15[5] = puVar8[4];
      puVar15[6] = puVar8[5];
      puVar15[7] = puVar8[10];
      puVar15[8] = puVar8[6];
      puVar15[9] = puVar8[7];
      puVar15[10] = puVar8[8];
      puVar15[0xb] = puVar8[0xb];
      *(undefined8 *)(puVar15 + 0xc) = uStack_74;
      *(ulonglong *)(puVar15 + 0x10) = uStack_88;
      puVar15[0xe] = uStack_6c;
      puVar15[0x12] = uVar6;
      *(undefined8 *)(puVar15 + 0x18) = 0;
      *(undefined8 *)(puVar15 + 0x14) = DAT_018fe520;
      puVar15[0x16] = DAT_018fe528;
      puVar15[0x13] = (float)((float10)1 - fVar16);
      FUN_00764100(&uStack_94,uVar9);
      puVar15[0xf] = 0x3f800000;
      fVar16 = (float10)FUN_00767900(uStack_94);
      puVar15[0x1a] = (float)fVar16;
      puVar15[0x1b] = (float)(int)uStack_94._2_2_ / DAT_018f9000;
      puVar15[0x17] = uVar1;
      fVar18 = (float)uStack_80 * DAT_018ce2f4;
      fVar19 = fStack_78 * DAT_018ce2f4;
      fVar20 = uStack_80._4_4_ * DAT_018ce2f4;
      uStack_88 = (ulonglong)(uint)fVar18;
      fStack_54 = fVar19 + 0.0;
      fStack_60 = 0.0 - fVar19;
      uStack_68 = CONCAT44(0.0 - fVar20,0.0 - fVar18);
      uStack_5c = CONCAT44(fVar20 + 0.0,fVar18 + 0.0);
      fStack_48 = fStack_60;
      fStack_3c = fStack_54;
      puVar11 = (undefined4 *)FUN_00c9f550(auStack_20,puVar8);
      uVar1 = puVar11[1];
      uVar6 = puVar11[2];
      uVar9 = puVar11[3];
      puVar8 = (undefined4 *)(iVar4 + iVar3 * 0x18);
      *puVar8 = *puVar11;
      puVar8[1] = uVar1;
      puVar8[2] = uVar6;
      puVar8[3] = uVar9;
      *(undefined8 *)(iVar4 + 0x10 + iVar3 * 0x18) = *(undefined8 *)(puVar11 + 4);
      *(ulonglong *)(iVar14 + 0x34) = CONCAT44(fVar20,(int)uStack_88);
      *(float *)(iVar14 + 0x3c) = fVar19;
      iVar3 = *(int *)(*(int *)(iVar14 + 0x1c) + 0x8c);
      if (((*(float *)(iVar3 + 0x24) <= *(float *)(iVar14 + 0x34)) ||
          (*(float *)(iVar3 + 0x28) <= *(float *)(iVar14 + 0x38))) ||
         (*(float *)(iVar3 + 0x2c) <= *(float *)(iVar14 + 0x3c))) {
        bVar7 = true;
      }
      else {
        bVar7 = false;
      }
      uVar13 = *(uint *)(iVar14 + 0x2c) | 0x200;
      if (!bVar7) {
        uVar13 = *(uint *)(iVar14 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar14 + 0x2c) = uVar13;
      *(uint *)(iVar2 + 0xd0) = *(uint *)(iVar2 + 0xd0) | 1;
      fStack_30 = fVar19;
      if (*(int *)(iVar5 + 0x188) == 0) {
        pfVar12 = (float *)FUN_00b54150(auStack_2c);
        fVar18 = pfVar12[1];
        fVar19 = *pfVar12;
        fVar20 = pfVar12[2];
        fVar16 = (float10)FUN_00b4dfe0();
        dVar17 = (double)(fVar19 * fVar19 + fVar18 * fVar18 + fVar20 * fVar20);
        FUN_017267a0();
        fVar18 = (float)dVar17 * (float)fVar16;
      }
      else {
        fVar18 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar18 = 0.0;
      }
      puVar15[0xf] = (fVar18 + DAT_018fd178) * DAT_018e1340;
      if (puStack_90 != (undefined4 *)0x0) {
        for (iVar14 = 0x1c; iVar14 != 0; iVar14 = iVar14 + -1) {
          *puStack_90 = *puVar15;
          puVar15 = puVar15 + 1;
          puStack_90 = puStack_90 + 1;
        }
      }
      uStack_8c = uStack_8c + 1;
    } while (uStack_8c < param_2);
  }
  return;
}



/* FUNCTION 11569 ; VA 0x007ae0a0 ; FUN_007ae0a0 */

void FUN_007ae0a0(int param_1,uint param_2)

{
  float fVar1;
  float fVar2;
  undefined8 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  bool bVar12;
  undefined4 *puVar13;
  undefined4 uVar14;
  undefined8 *puVar15;
  undefined4 *puVar16;
  float *pfVar17;
  uint uVar18;
  int iVar19;
  undefined4 *puVar20;
  float10 fVar21;
  float fVar22;
  float fVar23;
  double dVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  undefined4 uStack_ac;
  undefined4 *puStack_a8;
  uint uStack_a4;
  float fStack_a0;
  undefined4 uStack_9c;
  ulonglong uStack_98;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  undefined8 uStack_80;
  float fStack_78;
  undefined8 uStack_74;
  float fStack_6c;
  undefined8 uStack_68;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  float fStack_48;
  float fStack_3c;
  float fStack_30;
  undefined auStack_2c [12];
  undefined auStack_20 [28];
  
  uStack_a4 = 0;
  if (param_2 != 0) {
    do {
      iVar19 = *(int *)(param_1 + uStack_a4 * 4);
      iVar4 = *(int *)(iVar19 + 0x20);
      iVar5 = *(int *)(iVar19 + 0x24);
      puVar20 = (undefined4 *)(*(int *)(iVar4 + 0xac) + iVar5 * 0x70);
      if (*(int *)(iVar19 + 0x28) == -1) {
        puStack_a8 = (undefined4 *)0x0;
      }
      else {
        puStack_a8 = (undefined4 *)(*(int *)(iVar19 + 0x28) * 0x70 + *(int *)(iVar4 + 0x88));
      }
      iVar6 = *(int *)(iVar4 + 0xb8);
      iVar7 = *(int *)(*(int *)(iVar19 + 0x48) + 4);
      puVar13 = (undefined4 *)FUN_00b077e0();
      uVar14 = FUN_00b084e0();
      puVar15 = (undefined8 *)FUN_00b08320();
      fStack_6c = *(float *)(puVar15 + 1);
      uStack_74 = *puVar15;
      FUN_00b54150(&fStack_8c);
      iVar8 = *(int *)(iVar19 + 0x40);
      uVar3 = *(undefined8 *)(iVar7 + 0x114);
      fStack_78 = *(float *)(iVar7 + 0x11c);
      uStack_80._0_4_ = (float)uVar3;
      uStack_98 = CONCAT44(uStack_98._4_4_,fStack_8c * (float)uStack_80);
      uStack_80._4_4_ = (float)((ulonglong)uVar3 >> 0x20);
      fVar22 = fStack_88 * uStack_80._4_4_;
      fVar23 = fStack_84 * fStack_78;
      uStack_9c = *(undefined4 *)(iVar7 + 0xd0);
      uStack_80 = uVar3;
      fVar21 = (float10)FUN_00d00910();
      uVar3 = *(undefined8 *)(iVar8 + 0x9c);
      uVar9 = *(undefined4 *)(iVar8 + 0xa4);
      *puVar20 = *puVar13;
      puVar20[1] = puVar13[1];
      puVar20[2] = puVar13[2];
      puVar20[3] = puVar13[9];
      puVar20[4] = puVar13[3];
      puVar20[5] = puVar13[4];
      puVar20[6] = puVar13[5];
      puVar20[7] = puVar13[10];
      puVar20[8] = puVar13[6];
      puVar20[9] = puVar13[7];
      puVar20[10] = puVar13[8];
      puVar20[0xb] = puVar13[0xb];
      *(ulonglong *)(puVar20 + 0xc) = CONCAT44(fStack_88,fStack_8c);
      *(undefined8 *)(puVar20 + 0x10) = uVar3;
      puVar20[0xe] = fStack_84;
      puVar20[0x12] = uVar9;
      *(undefined8 *)(puVar20 + 0x18) = 0;
      *(undefined8 *)(puVar20 + 0x14) = DAT_018fe520;
      fStack_a0 = (float)((float10)1 - fVar21);
      puVar20[0x16] = DAT_018fe528;
      puVar20[0x13] = fStack_a0;
      FUN_00764100(&uStack_ac,uVar14);
      puVar20[0xf] = 0x3f800000;
      fVar21 = (float10)FUN_00767900(uStack_ac);
      fVar26 = DAT_018ce2f8;
      puVar20[0x1a] = (float)fVar21;
      puVar20[0x1b] = (float)(int)uStack_ac._2_2_ / DAT_018f9000;
      puVar20[0x17] = uStack_9c;
      fVar25 = fVar26 / *(float *)(iVar8 + 0xa8);
      iVar10 = *(int *)(iVar8 + 0x70);
      fVar26 = fVar26 / *(float *)(iVar8 + 0xac);
      puVar20[*(int *)(&DAT_018fed5c + iVar10 * 8) + 0x14] = fVar25;
      puVar20[*(int *)(&DAT_018fed60 + iVar10 * 8) + 0x14] = fVar26;
      fVar27 = *(float *)(&DAT_018feddc + iVar10 * 0xc);
      puVar20[0x14] = (float)puVar20[0x14] * (float)uStack_98;
      puVar20[0x15] = fVar22 * (float)puVar20[0x15];
      puVar20[0x16] = (float)puVar20[0x16] * fVar23;
      fVar22 = *(float *)(&DAT_018fed90 + iVar10 * 0xc);
      fVar23 = *(float *)(&DAT_018fed94 + iVar10 * 0xc);
      fVar1 = *(float *)(&DAT_018fed98 + iVar10 * 0xc);
      fVar2 = *(float *)(iVar8 + 0xb0);
      puVar20[0x19] =
           (*(float *)(iVar8 + 0xb4) -
           (fVar27 * uStack_74._4_4_ + *(float *)(&DAT_018fedd8 + iVar10 * 0xc) * (float)uStack_74 +
           *(float *)(&DAT_018fede0 + iVar10 * 0xc) * fStack_6c) * DAT_018ce2f4) * fVar26;
      puVar20[0x18] =
           (fVar2 - (fVar23 * uStack_74._4_4_ + fVar22 * (float)uStack_74 + fVar1 * fStack_6c) *
                    DAT_018ce2f4) * fVar25;
      fVar23 = (float)uStack_74 * DAT_018ce2f4;
      fVar22 = uStack_74._4_4_ * DAT_018ce2f4;
      fVar27 = fStack_6c * DAT_018ce2f4;
      uStack_98 = (ulonglong)(uint)fVar23;
      fStack_54 = fVar27 + 0.0;
      uStack_5c = CONCAT44(fVar22 + 0.0,fVar23 + 0.0);
      fStack_60 = 0.0 - fVar27;
      uStack_68 = CONCAT44(0.0 - fVar22,0.0 - fVar23);
      fStack_48 = fStack_60;
      fStack_3c = fStack_54;
      puVar16 = (undefined4 *)FUN_00c9f550(auStack_20,puVar13);
      uVar9 = puVar16[1];
      uVar14 = puVar16[2];
      uVar11 = puVar16[3];
      puVar13 = (undefined4 *)(iVar6 + iVar5 * 0x18);
      *puVar13 = *puVar16;
      puVar13[1] = uVar9;
      puVar13[2] = uVar14;
      puVar13[3] = uVar11;
      *(undefined8 *)(iVar6 + 0x10 + iVar5 * 0x18) = *(undefined8 *)(puVar16 + 4);
      *(ulonglong *)(iVar19 + 0x34) = CONCAT44(fVar22,(int)uStack_98);
      *(float *)(iVar19 + 0x3c) = fVar27;
      iVar5 = *(int *)(*(int *)(iVar19 + 0x1c) + 0x8c);
      if (((*(float *)(iVar5 + 0x24) <= *(float *)(iVar19 + 0x34)) ||
          (*(float *)(iVar5 + 0x28) <= *(float *)(iVar19 + 0x38))) ||
         (*(float *)(iVar5 + 0x2c) <= *(float *)(iVar19 + 0x3c))) {
        bVar12 = true;
      }
      else {
        bVar12 = false;
      }
      uVar18 = *(uint *)(iVar19 + 0x2c) | 0x200;
      if (!bVar12) {
        uVar18 = *(uint *)(iVar19 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar19 + 0x2c) = uVar18;
      *(uint *)(iVar4 + 0xd0) = *(uint *)(iVar4 + 0xd0) | 1;
      fStack_30 = fVar27;
      if (*(int *)(iVar7 + 0x188) == 0) {
        pfVar17 = (float *)FUN_00b54150(auStack_2c);
        fVar27 = pfVar17[1];
        fVar22 = *pfVar17;
        fVar23 = pfVar17[2];
        fVar21 = (float10)FUN_00b4dfe0();
        dVar24 = (double)(fVar27 * fVar27 + fVar22 * fVar22 + fVar23 * fVar23);
        FUN_017267a0();
        fVar27 = (float)dVar24 * (float)fVar21;
      }
      else {
        fVar27 = 0.0;
      }
      if (DAT_01d60c28 == '\0') {
        fVar27 = 0.0;
      }
      puVar20[0xf] = (fVar27 + DAT_018fd178) * DAT_018e1340;
      if (puStack_a8 != (undefined4 *)0x0) {
        for (iVar19 = 0x1c; iVar19 != 0; iVar19 = iVar19 + -1) {
          *puStack_a8 = *puVar20;
          puVar20 = puVar20 + 1;
          puStack_a8 = puStack_a8 + 1;
        }
      }
      uStack_a4 = uStack_a4 + 1;
    } while (uStack_a4 < param_2);
  }
  return;
}



/* FUNCTION 11570 ; VA 0x007ae5f0 ; FUN_007ae5f0 */

void FUN_007ae5f0(undefined4 param_1,undefined4 param_2)

{
  FUN_007b1670(param_1,param_2);
  return;
}



/* FUNCTION 11571 ; VA 0x007ae610 ; FUN_007ae610 */

void FUN_007ae610(undefined4 param_1,undefined4 param_2)

{
  FUN_007afee0(param_1,param_2);
  return;
}



/* FUNCTION 11572 ; VA 0x007ae630 ; FUN_007ae630 */

void FUN_007ae630(undefined4 param_1,undefined4 param_2)

{
  FUN_007b01d0(param_1,param_2);
  return;
}



/* FUNCTION 11573 ; VA 0x007ae650 ; FUN_007ae650 */

void FUN_007ae650(undefined4 param_1,undefined4 param_2)

{
  FUN_007b0560(param_1,param_2);
  return;
}



/* FUNCTION 11574 ; VA 0x007ae670 ; FUN_007ae670 */

void FUN_007ae670(undefined4 param_1,undefined4 param_2)

{
  FUN_007b08f0(param_1,param_2);
  return;
}



/* FUNCTION 11575 ; VA 0x007ae690 ; FUN_007ae690 */

void FUN_007ae690(undefined4 param_1,undefined4 param_2)

{
  FUN_007b0bf0(param_1,param_2);
  return;
}



/* FUNCTION 11576 ; VA 0x007ae6b0 ; FUN_007ae6b0 */

void FUN_007ae6b0(undefined4 param_1,undefined4 param_2)

{
  FUN_007b0f90(param_1,param_2);
  return;
}



/* FUNCTION 11577 ; VA 0x007ae6d0 ; FUN_007ae6d0 */

void FUN_007ae6d0(undefined4 param_1,undefined4 param_2)

{
  FUN_007b1340(param_1,param_2);
  return;
}



/* FUNCTION 11578 ; VA 0x007ae6f0 ; FUN_007ae6f0 */

void FUN_007ae6f0(undefined4 param_1,undefined4 param_2)

{
  FUN_007b19e0(param_1,param_2);
  return;
}



/* FUNCTION 11579 ; VA 0x007ae710 ; FUN_007ae710 */

void FUN_007ae710(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  bool bVar4;
  uint uVar5;
  float *pfVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  float *pfVar12;
  float10 fVar13;
  float fVar14;
  undefined *puVar15;
  undefined auStack_e0 [12];
  undefined auStack_d4 [32];
  float fStack_b4;
  float fStack_a8;
  undefined8 uStack_a4;
  float fStack_9c;
  undefined8 uStack_98;
  float fStack_90;
  undefined8 uStack_8c;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  float *pfStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined8 uStack_14;
  float *pfStack_c;
  float fStack_8;
  
  uStack_2c = 0;
  if (param_2 != 0) {
    do {
      iVar11 = *(int *)(param_1 + uStack_2c * 4);
      iStack_78 = *(int *)(iVar11 + 0x20);
      pfStack_c = (float *)(*(int *)(iStack_78 + 0xac) + *(int *)(iVar11 + 0x24) * 0x70);
      if (*(int *)(iVar11 + 0x28) == -1) {
        pfVar12 = (float *)0x0;
      }
      else {
        pfVar12 = (float *)(*(int *)(iVar11 + 0x28) * 0x70 + *(int *)(iStack_78 + 0x88));
      }
      iStack_70 = *(int *)(iVar11 + 0x24) * 3;
      uStack_28 = *(uint *)(iVar11 + 4);
      iStack_74 = *(int *)(iStack_78 + 0xb8);
      FUN_00b06fb0();
      pfVar6 = (float *)FUN_00b08320();
      fStack_1c = pfVar6[1] * DAT_018ce2f4;
      fStack_18 = pfVar6[2] * DAT_018ce2f4;
      fStack_20 = *pfVar6 * DAT_018ce2f4;
      pfStack_6c = (float *)FUN_00b077e0();
      fStack_5c = *pfStack_6c;
      fStack_58 = pfStack_6c[1];
      fStack_54 = pfStack_6c[2];
      fStack_50 = pfStack_6c[3];
      fStack_4c = pfStack_6c[4];
      fStack_48 = pfStack_6c[5];
      fStack_44 = pfStack_6c[6];
      fStack_40 = pfStack_6c[7];
      fStack_3c = pfStack_6c[8];
      fStack_38 = pfStack_6c[9];
      fStack_34 = pfStack_6c[10];
      fStack_30 = pfStack_6c[0xb];
      fStack_8 = 0.0;
      iVar7 = FUN_01165580();
      if (iVar7 == 0) {
        fStack_8 = fStack_20;
      }
      else {
        if (iVar7 == 1) {
          puVar15 = &DAT_01eb286c;
          fStack_8 = fStack_1c;
        }
        else {
          if (iVar7 != 2) goto LAB_007ae83d;
          puVar15 = &DAT_01eb2890;
          fStack_8 = fStack_18;
        }
        pfVar6 = (float *)FUN_01160c20(auStack_e0,puVar15);
        fStack_5c = *pfVar6;
        fStack_58 = pfVar6[1];
        fStack_54 = pfVar6[2];
        fStack_50 = pfVar6[3];
        fStack_4c = pfVar6[4];
        fStack_48 = pfVar6[5];
        fStack_44 = pfVar6[6];
        fStack_40 = pfVar6[7];
        fStack_3c = pfVar6[8];
      }
LAB_007ae83d:
      uStack_14 = (double)fStack_8;
      fVar13 = (float10)FUN_01725280(uStack_14);
      uStack_14 = (double)fVar13;
      fVar14 = fStack_8 - (float)fVar13;
      fStack_8 = fStack_38 - (fVar14 * fStack_5c + fStack_58 * 0.0 + fStack_54 * 0.0);
      fStack_60 = fStack_34 - (fVar14 * fStack_50 + fStack_4c * 0.0 + fStack_48 * 0.0);
      fStack_64 = fStack_30 - (fVar14 * fStack_44 + fStack_40 * 0.0 + fStack_3c * 0.0);
      uVar8 = FUN_00b084e0();
      uStack_14._4_4_ = *(float *)(uStack_28 + 0xd0);
      fVar13 = (float10)FUN_00b08910();
      *pfStack_c = fStack_5c;
      pfStack_c[1] = fStack_58;
      pfStack_c[2] = fStack_54;
      pfStack_c[3] = fStack_8;
      pfStack_c[4] = fStack_50;
      pfStack_c[5] = fStack_4c;
      pfStack_c[6] = fStack_48;
      pfStack_c[7] = fStack_60;
      pfStack_c[8] = fStack_44;
      pfStack_c[9] = fStack_40;
      pfStack_c[10] = fStack_3c;
      pfStack_c[0xb] = fStack_64;
      fStack_68 = (float)((float10)1 - fVar13);
      *(ulonglong *)(pfStack_c + 0xc) = CONCAT44(DAT_01d61bcc,DAT_01d61bc8);
      pfStack_c[0xe] = DAT_01d61bd0;
      *(undefined8 *)(pfStack_c + 0x10) = uStack_8c;
      pfStack_c[0x12] = fStack_84;
      pfStack_c[0x18] = 0.0;
      pfStack_c[0x19] = 0.0;
      *(undefined8 *)(pfStack_c + 0x14) = DAT_018fe520;
      pfStack_c[0x16] = DAT_018fe528;
      pfStack_c[0x13] = fStack_68;
      FUN_00764100(&uStack_24);
      pfStack_c[0xf] = 1.0;
      fVar13 = (float10)FUN_00767900(uStack_24);
      pfStack_c[0x1a] = (float)fVar13;
      pfStack_c[0x1b] = (float)(int)uStack_24._2_2_ / DAT_018f9000;
      pfStack_c[0x17] = uStack_14._4_4_;
      fVar13 = (float10)FUN_00764430(uVar8);
      uVar5 = uStack_28;
      uStack_14 = (double)CONCAT44((float)fVar13,(undefined4)uStack_14);
      FUN_0074b590(&fStack_80,&DAT_01d61bc8,(uStack_28 >> 3) + uStack_28,uVar8);
      pfStack_c[0x14] = uStack_14._4_4_ * DAT_01d61bc8;
      pfStack_c[0x15] = uStack_14._4_4_ * DAT_01d61bcc;
      pfStack_c[0x16] = uStack_14._4_4_ * DAT_01d61bd0;
      pfStack_c[0x18] = fStack_80;
      pfStack_c[0x19] = fStack_7c;
      fStack_b4 = fStack_18 + 0.0;
      fStack_a8 = 0.0 - fStack_18;
      uStack_a4 = CONCAT44(0.0 - fStack_1c,0.0 - fStack_20);
      uStack_98 = CONCAT44(fStack_1c + 0.0,fStack_20 + 0.0);
      fStack_9c = fStack_a8;
      fStack_90 = fStack_b4;
      puVar9 = (undefined4 *)FUN_00c9f550(auStack_d4,pfStack_6c);
      uVar8 = puVar9[1];
      uVar2 = puVar9[2];
      uVar3 = puVar9[3];
      puVar1 = (undefined4 *)(iStack_74 + iStack_70 * 8);
      *puVar1 = *puVar9;
      puVar1[1] = uVar8;
      puVar1[2] = uVar2;
      puVar1[3] = uVar3;
      *(undefined8 *)(iStack_74 + 0x10 + iStack_70 * 8) = *(undefined8 *)(puVar9 + 4);
      *(ulonglong *)(iVar11 + 0x34) = CONCAT44(fStack_1c,fStack_20);
      *(float *)(iVar11 + 0x3c) = fStack_18;
      iVar7 = *(int *)(*(int *)(iVar11 + 0x1c) + 0x8c);
      if (((*(float *)(iVar7 + 0x24) <= *(float *)(iVar11 + 0x34)) ||
          (*(float *)(iVar7 + 0x28) <= *(float *)(iVar11 + 0x38))) ||
         (*(float *)(iVar7 + 0x2c) <= *(float *)(iVar11 + 0x3c))) {
        bVar4 = true;
      }
      else {
        bVar4 = false;
      }
      uVar10 = *(uint *)(iVar11 + 0x2c) | 0x200;
      if (!bVar4) {
        uVar10 = *(uint *)(iVar11 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar11 + 0x2c) = uVar10;
      *(uint *)(iStack_78 + 0xd0) = *(uint *)(iStack_78 + 0xd0) | 1;
      pfStack_c[0xf] = 2.5e-05;
      if (-1 < *(int *)(iVar11 + 0x30)) {
        FUN_00d38fb0(*(int *)(iVar11 + 0x30),uVar5,0,iVar11);
      }
      if (pfVar12 != (float *)0x0) {
        for (iVar11 = 0x1c; iVar11 != 0; iVar11 = iVar11 + -1) {
          *pfVar12 = *pfStack_c;
          pfStack_c = pfStack_c + 1;
          pfVar12 = pfVar12 + 1;
        }
      }
      uStack_2c = uStack_2c + 1;
    } while (uStack_2c < param_2);
  }
  return;
}



/* FUNCTION 11580 ; VA 0x007afa10 ; FUN_007afa10 */

void FUN_007afa10(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 0x18);
      uStack_8 = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 8))();
          }
        }
      }
      param_1 = param_1 + 0x28;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11581 ; VA 0x007afa90 ; FUN_007afa90 */

int __thiscall FUN_007afa90(uint *param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  
  iVar7 = param_2 - *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0x70;
  if (iVar1 == 0x2492492) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0x70;
  uVar6 = uVar4;
  if ((uVar2 <= 0x2492492 - (uVar2 >> 1)) && (uVar6 = (uVar2 >> 1) + uVar2, uVar6 < uVar4)) {
    uVar6 = uVar4;
  }
  uVar4 = uVar6 * 0x70;
  if (uVar6 < 0x2492493) {
    uVar6 = uVar4;
    if (0xfff < uVar4) goto LAB_007afb2c;
    if (uVar4 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar6 = 0xffffffff;
LAB_007afb2c:
    uVar2 = uVar6 + 0x23;
    if (uVar2 <= uVar6) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_007afc5b;
    uVar6 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar6 - 4) = iVar3;
  }
  iVar7 = (iVar7 / 0x70) * 0x70;
  puVar8 = param_3;
  puVar10 = (undefined4 *)(uVar6 + iVar7);
  for (iVar3 = 0x1c; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar10 = *puVar8;
    puVar8 = puVar8 + 1;
    puVar10 = puVar10 + 1;
  }
  uVar2 = param_1[1];
  if (param_2 == uVar2) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar6,*param_1,uVar2 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar6,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar7 + 0x70 + uVar6,param_2,param_1[1] - param_2);
  }
  uVar2 = *param_1;
  if (uVar2 != 0) {
    uVar5 = ((int)(param_1[2] - uVar2) / 0x70) * 0x70;
    uVar9 = uVar2;
    if (0xfff < uVar5) {
      uVar9 = *(uint *)(uVar2 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar2 - uVar9) - 4) {
LAB_007afc5b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar5);
  }
  *param_1 = uVar6;
  param_1[1] = (iVar1 + 1) * 0x70 + uVar6;
  param_1[2] = uVar4 + uVar6;
  return *param_1 + iVar7;
}



/* FUNCTION 11582 ; VA 0x007afc70 ; FUN_007afc70 */

void __thiscall FUN_007afc70(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  
  iVar4 = param_1[1];
  iVar10 = *param_1;
  uVar9 = iVar4 - iVar10 >> 4;
  uVar5 = param_1[2] - iVar10 >> 4;
  if (param_2 <= uVar5) {
    if (uVar9 < param_2) {
      iVar4 = FUN_007b3030(iVar4,param_2 - uVar9);
      param_1[1] = iVar4;
      return;
    }
    if (param_2 != uVar9) {
      iVar10 = param_2 * 0x10 + iVar10;
      FUN_00786f80(iVar10,iVar4,param_1);
      param_1[1] = iVar10;
    }
    return;
  }
  if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = param_2;
  if ((uVar5 <= 0xfffffff - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < param_2)) {
    uVar2 = param_2;
  }
  uVar5 = uVar2 * 0x10;
  if (uVar2 < 0x10000000) {
    if (0xfff < uVar5) goto LAB_007afcdd;
    if (uVar5 == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_007afcdd:
    uVar3 = uVar5 + 0x23;
    if (uVar3 <= uVar5) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_007afe23;
    puVar6 = (undefined4 *)(iVar4 + 0x23U & 0xffffffe0);
    puVar6[-1] = iVar4;
  }
  FUN_007b3030(puVar6 + uVar9 * 4,param_2 - uVar9);
  puVar1 = (undefined4 *)param_1[1];
  puVar8 = puVar6;
  for (puVar7 = (undefined4 *)*param_1; puVar7 != puVar1; puVar7 = puVar7 + 4) {
    *puVar8 = 0;
    puVar8[1] = 0;
    *puVar8 = *puVar7;
    puVar8[1] = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    puVar8[2] = puVar7[2];
    puVar8[3] = puVar7[3];
    puVar8 = puVar8 + 4;
  }
  FUN_00786f80(puVar8,puVar8,param_1);
  if (*param_1 != 0) {
    FUN_00786f80(*param_1,param_1[1],param_1);
    iVar4 = *param_1;
    uVar5 = param_1[2] - iVar4 & 0xfffffff0;
    iVar10 = iVar4;
    if (0xfff < uVar5) {
      iVar10 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar10) - 4U) {
LAB_007afe23:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar5);
  }
  *param_1 = (int)puVar6;
  param_1[1] = (int)(puVar6 + param_2 * 4);
  param_1[2] = (int)(puVar6 + uVar2 * 4);
  return;
}



/* FUNCTION 11583 ; VA 0x007afe30 ; FUN_007afe30 */

void __thiscall FUN_007afe30(int param_1,undefined4 *param_2,uint param_3,uint *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if (((((*param_4 & 1) == 0) && ((piVar2[2] & 1U) == 0)) && (piVar2[2] == *param_4)) &&
             (((piVar2[3] == param_4[1] && (piVar2[4] == param_4[2])) && (piVar2[6] == param_4[4])))
             ) break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 11584 ; VA 0x007afee0 ; FUN_007afee0 */

void FUN_007afee0(int param_1,uint param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  bool bVar3;
  float fVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  float10 fVar12;
  undefined auStack_94 [32];
  float fStack_74;
  float fStack_68;
  float fStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  float fStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_1c = 0;
  if (param_2 != 0) {
    do {
      iStack_34 = *(int *)(param_1 + uStack_1c * 4);
      iStack_38 = *(int *)(iStack_34 + 0x20);
      iStack_30 = *(int *)(iStack_34 + 0x24);
      puStack_20 = (undefined4 *)(*(int *)(iStack_38 + 0xac) + iStack_30 * 0x70);
      if (*(int *)(iStack_34 + 0x28) == -1) {
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        puStack_18 = (undefined4 *)(*(int *)(iStack_34 + 0x28) * 0x70 + *(int *)(iStack_38 + 0x88));
      }
      iStack_2c = *(int *)(iStack_38 + 0xb8);
      uStack_40 = *(undefined8 *)(*(int *)(iStack_34 + 0x40) + 0x9c);
      uVar1 = *(undefined4 *)(*(int *)(iStack_34 + 0x40) + 0xa4);
      iVar10 = *(int *)(*(int *)(iStack_34 + 0x48) + 4);
      fVar12 = (float10)FUN_00d00910();
      fStack_24 = (float)((float10)1 - fVar12);
      puVar5 = (undefined4 *)FUN_00b077e0();
      puVar6 = (undefined8 *)FUN_00b08320();
      uStack_10 = *puVar6;
      fStack_8 = *(float *)(puVar6 + 1);
      uVar7 = FUN_00b084e0();
      puVar11 = puStack_20;
      uStack_28 = *(undefined4 *)(iVar10 + 0xd0);
      *puStack_20 = *puVar5;
      puStack_20[1] = puVar5[1];
      puStack_20[2] = puVar5[2];
      puStack_20[3] = puVar5[9];
      puStack_20[4] = puVar5[3];
      puStack_20[5] = puVar5[4];
      puStack_20[6] = puVar5[5];
      puStack_20[7] = puVar5[10];
      puStack_20[8] = puVar5[6];
      puStack_20[9] = puVar5[7];
      puStack_20[10] = puVar5[8];
      puStack_20[0xb] = puVar5[0xb];
      *(undefined8 *)(puStack_20 + 0xc) = uStack_10;
      *(undefined8 *)(puStack_20 + 0x10) = uStack_40;
      puStack_20[0xe] = fStack_8;
      puStack_20[0x12] = uVar1;
      *(undefined8 *)(puStack_20 + 0x18) = 0;
      *(undefined8 *)(puStack_20 + 0x14) = DAT_018fe520;
      puStack_20[0x16] = DAT_018fe528;
      puStack_20[0x13] = fStack_24;
      FUN_00764100(&uStack_14,uVar7);
      puVar11[0xf] = 0x3f800000;
      fVar12 = (float10)FUN_00767900(uStack_14);
      puVar11[0x1a] = (float)fVar12;
      puVar11[0x1b] = (float)(int)uStack_14._2_2_ / DAT_018f9000;
      puVar11[0x17] = uStack_28;
      fStack_68 = fStack_8 * DAT_018ce2f4 + 0.0;
      fStack_5c = 0.0 - fStack_8 * DAT_018ce2f4;
      uStack_58 = CONCAT44(0.0 - uStack_10._4_4_ * DAT_018ce2f4,
                           0.0 - (float)uStack_10 * DAT_018ce2f4);
      uStack_4c = CONCAT44(uStack_10._4_4_ * DAT_018ce2f4 + 0.0,
                           (float)uStack_10 * DAT_018ce2f4 + 0.0);
      fStack_50 = fStack_5c;
      fStack_44 = fStack_68;
      puVar8 = (undefined4 *)FUN_00c9f550(auStack_94,puVar5);
      fVar4 = DAT_018ce2f4;
      uVar1 = puVar8[1];
      uVar7 = puVar8[2];
      uVar2 = puVar8[3];
      puVar5 = (undefined4 *)(iStack_2c + iStack_30 * 0x18);
      *puVar5 = *puVar8;
      puVar5[1] = uVar1;
      puVar5[2] = uVar7;
      puVar5[3] = uVar2;
      *(undefined8 *)(iStack_2c + 0x10 + iStack_30 * 0x18) = *(undefined8 *)(puVar8 + 4);
      fStack_74 = fStack_8 * fVar4;
      *(ulonglong *)(iStack_34 + 0x34) = CONCAT44(uStack_10._4_4_ * fVar4,(float)uStack_10 * fVar4);
      *(float *)(iStack_34 + 0x3c) = fStack_74;
      iVar10 = *(int *)(*(int *)(iStack_34 + 0x1c) + 0x8c);
      if (((*(float *)(iVar10 + 0x24) <= *(float *)(iStack_34 + 0x34)) ||
          (*(float *)(iVar10 + 0x28) <= *(float *)(iStack_34 + 0x38))) ||
         (*(float *)(iVar10 + 0x2c) <= *(float *)(iStack_34 + 0x3c))) {
        bVar3 = true;
      }
      else {
        bVar3 = false;
      }
      uVar9 = *(uint *)(iStack_34 + 0x2c) | 0x200;
      if (!bVar3) {
        uVar9 = *(uint *)(iStack_34 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iStack_34 + 0x2c) = uVar9;
      *(uint *)(iStack_38 + 0xd0) = *(uint *)(iStack_38 + 0xd0) | 1;
      puVar11[0xf] = 0x37d1b717;
      if (puStack_18 != (undefined4 *)0x0) {
        for (iVar10 = 0x1c; iVar10 != 0; iVar10 = iVar10 + -1) {
          *puStack_18 = *puVar11;
          puVar11 = puVar11 + 1;
          puStack_18 = puStack_18 + 1;
        }
      }
      uStack_1c = uStack_1c + 1;
    } while (uStack_1c < param_2);
  }
  return;
}



/* FUNCTION 11585 ; VA 0x007b01d0 ; FUN_007b01d0 */

void FUN_007b01d0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  float fVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  bool bVar6;
  undefined8 *puVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  undefined4 *puVar12;
  float10 fVar13;
  float fVar14;
  float fVar15;
  undefined auStack_98 [32];
  float fStack_78;
  float fStack_6c;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  undefined8 uStack_50;
  float fStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  float fStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_20 = 0;
  if (param_2 != 0) {
    do {
      iStack_38 = *(int *)(param_1 + uStack_20 * 4);
      iStack_3c = *(int *)(iStack_38 + 0x20);
      iStack_34 = *(int *)(iStack_38 + 0x24);
      puStack_14 = (undefined4 *)(*(int *)(iStack_3c + 0xac) + iStack_34 * 0x70);
      if (*(int *)(iStack_38 + 0x28) == -1) {
        puStack_1c = (undefined4 *)0x0;
      }
      else {
        puStack_1c = (undefined4 *)(*(int *)(iStack_38 + 0x28) * 0x70 + *(int *)(iStack_3c + 0x88));
      }
      iStack_30 = *(int *)(iStack_3c + 0xb8);
      iVar11 = *(int *)(iStack_38 + 0x40);
      iVar3 = *(int *)(*(int *)(iStack_38 + 0x48) + 4);
      uStack_44 = *(undefined8 *)(iVar11 + 0x9c);
      uVar4 = *(undefined4 *)(iVar11 + 0xa4);
      fVar13 = (float10)FUN_00d00910();
      fStack_28 = (float)((float10)1 - fVar13);
      puStack_24 = (undefined4 *)FUN_00b077e0();
      puVar7 = (undefined8 *)FUN_00b08320();
      uStack_10 = *puVar7;
      fStack_8 = *(float *)(puVar7 + 1);
      uVar8 = FUN_00b084e0();
      puVar12 = puStack_14;
      puVar1 = puStack_24;
      uStack_2c = *(undefined4 *)(iVar3 + 0xd0);
      *puStack_14 = *puStack_24;
      puStack_14[1] = puStack_24[1];
      puStack_14[2] = puStack_24[2];
      puStack_14[3] = puStack_24[9];
      puStack_14[4] = puStack_24[3];
      puStack_14[5] = puStack_24[4];
      puStack_14[6] = puStack_24[5];
      puStack_14[7] = puStack_24[10];
      puStack_14[8] = puStack_24[6];
      puStack_14[9] = puStack_24[7];
      puStack_14[10] = puStack_24[8];
      puStack_14[0xb] = puStack_24[0xb];
      *(undefined8 *)(puStack_14 + 0xc) = uStack_10;
      *(undefined8 *)(puStack_14 + 0x10) = uStack_44;
      puStack_14[0x12] = uVar4;
      puStack_14[0xe] = fStack_8;
      *(undefined8 *)(puStack_14 + 0x18) = 0;
      *(undefined8 *)(puStack_14 + 0x14) = DAT_018fe520;
      puStack_14[0x16] = DAT_018fe528;
      puStack_14[0x13] = fStack_28;
      FUN_00764100(&uStack_18,uVar8);
      puVar12[0xf] = 0x3f800000;
      fVar13 = (float10)FUN_00767900(uStack_18);
      puVar12[0x1a] = (float)fVar13;
      fVar14 = DAT_018ce2f8;
      puVar12[0x1b] = (float)(int)uStack_18._2_2_ / DAT_018f9000;
      fVar15 = DAT_018ce2f8;
      puVar12[0x17] = uStack_2c;
      fVar14 = fVar14 / *(float *)(iVar11 + 0xa8);
      iVar3 = *(int *)(iVar11 + 0x70);
      fVar15 = fVar15 / *(float *)(iVar11 + 0xac);
      puVar12[*(int *)(&DAT_018fee20 + iVar3 * 8) + 0x14] = fVar14;
      puVar12[*(int *)(&DAT_018fee24 + iVar3 * 8) + 0x14] = fVar15;
      puVar12[0x14] = (float)puVar12[0x14] * (float)uStack_10;
      puVar12[0x15] = (float)puVar12[0x15] * uStack_10._4_4_;
      puVar12[0x16] = (float)puVar12[0x16] * fStack_8;
      fVar2 = *(float *)(iVar11 + 0xb4);
      puVar12[0x18] = *(float *)(iVar11 + 0xb0) * fVar14;
      fVar14 = DAT_018ce2f4;
      puVar12[0x19] = fVar2 * fVar15;
      fStack_6c = fStack_8 * fVar14 + 0.0;
      fStack_60 = 0.0 - fStack_8 * fVar14;
      uStack_5c = CONCAT44(0.0 - uStack_10._4_4_ * fVar14,0.0 - (float)uStack_10 * fVar14);
      uStack_50 = CONCAT44(uStack_10._4_4_ * fVar14 + 0.0,(float)uStack_10 * fVar14 + 0.0);
      fStack_54 = fStack_60;
      fStack_48 = fStack_6c;
      puVar9 = (undefined4 *)FUN_00c9f550(auStack_98,puVar1);
      fVar2 = DAT_018ce2f4;
      uVar4 = puVar9[1];
      uVar8 = puVar9[2];
      uVar5 = puVar9[3];
      puVar1 = (undefined4 *)(iStack_30 + iStack_34 * 0x18);
      *puVar1 = *puVar9;
      puVar1[1] = uVar4;
      puVar1[2] = uVar8;
      puVar1[3] = uVar5;
      *(undefined8 *)(iStack_30 + 0x10 + iStack_34 * 0x18) = *(undefined8 *)(puVar9 + 4);
      fStack_78 = fStack_8 * fVar2;
      *(ulonglong *)(iStack_38 + 0x34) = CONCAT44(uStack_10._4_4_ * fVar2,(float)uStack_10 * fVar2);
      *(float *)(iStack_38 + 0x3c) = fStack_78;
      iVar11 = *(int *)(*(int *)(iStack_38 + 0x1c) + 0x8c);
      if (((*(float *)(iVar11 + 0x24) <= *(float *)(iStack_38 + 0x34)) ||
          (*(float *)(iVar11 + 0x28) <= *(float *)(iStack_38 + 0x38))) ||
         (*(float *)(iVar11 + 0x2c) <= *(float *)(iStack_38 + 0x3c))) {
        bVar6 = true;
      }
      else {
        bVar6 = false;
      }
      uVar10 = *(uint *)(iStack_38 + 0x2c) | 0x200;
      if (!bVar6) {
        uVar10 = *(uint *)(iStack_38 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iStack_38 + 0x2c) = uVar10;
      *(uint *)(iStack_3c + 0xd0) = *(uint *)(iStack_3c + 0xd0) | 1;
      puVar12[0xf] = 0x37d1b717;
      if (puStack_1c != (undefined4 *)0x0) {
        for (iVar11 = 0x1c; iVar11 != 0; iVar11 = iVar11 + -1) {
          *puStack_1c = *puVar12;
          puVar12 = puVar12 + 1;
          puStack_1c = puStack_1c + 1;
        }
      }
      uStack_20 = uStack_20 + 1;
    } while (uStack_20 < param_2);
  }
  return;
}



/* FUNCTION 11586 ; VA 0x007b0560 ; FUN_007b0560 */

void FUN_007b0560(int param_1,uint param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  bool bVar3;
  float fVar4;
  undefined8 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  float10 fVar12;
  undefined auStack_ac [24];
  undefined auStack_94 [20];
  float fStack_80;
  float fStack_74;
  float fStack_68;
  undefined8 uStack_64;
  float fStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  float fStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  float fStack_18;
  uint uStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_28 = 0;
  if (param_2 != 0) {
    do {
      iStack_38 = *(int *)(param_1 + uStack_28 * 4);
      iStack_3c = *(int *)(iStack_38 + 0x20);
      iStack_34 = *(int *)(iStack_38 + 0x24);
      puStack_1c = (undefined4 *)(*(int *)(iStack_3c + 0xac) + iStack_34 * 0x70);
      if (*(int *)(iStack_38 + 0x28) == -1) {
        puStack_24 = (undefined4 *)0x0;
      }
      else {
        puStack_24 = (undefined4 *)(*(int *)(iStack_38 + 0x28) * 0x70 + *(int *)(iStack_3c + 0x88));
      }
      iStack_30 = *(int *)(iStack_3c + 0xb8);
      uStack_14 = *(uint *)(iStack_38 + 4);
      puVar5 = (undefined8 *)FUN_00b06fb0(auStack_94);
      uStack_4c = *puVar5;
      uVar1 = *(undefined4 *)(puVar5 + 1);
      fVar12 = (float10)FUN_00b08910();
      fStack_2c = (float)((float10)1 - fVar12);
      puVar6 = (undefined4 *)FUN_00b077e0();
      puVar5 = (undefined8 *)FUN_00b08320();
      uStack_10 = *puVar5;
      fStack_8 = *(float *)(puVar5 + 1);
      uVar7 = FUN_00b084e0();
      if (uStack_10._4_4_ <= fStack_8) {
        fStack_8 = uStack_10._4_4_;
      }
      uStack_10 = CONCAT44(fStack_8,(float)uStack_10);
      fStack_18 = *(float *)(uStack_14 + 0xd0);
      *puStack_1c = *puVar6;
      puStack_1c[1] = puVar6[1];
      puStack_1c[2] = puVar6[2];
      puStack_1c[3] = puVar6[9];
      puStack_1c[4] = puVar6[3];
      puStack_1c[5] = puVar6[4];
      puStack_1c[6] = puVar6[5];
      puStack_1c[7] = puVar6[10];
      puStack_1c[8] = puVar6[6];
      puStack_1c[9] = puVar6[7];
      puStack_1c[10] = puVar6[8];
      puStack_1c[0xb] = puVar6[0xb];
      *(undefined8 *)(puStack_1c + 0xc) = uStack_10;
      *(undefined8 *)(puStack_1c + 0x10) = uStack_4c;
      puStack_1c[0xe] = fStack_8;
      puStack_1c[0x12] = uVar1;
      *(undefined8 *)(puStack_1c + 0x18) = 0;
      *(undefined8 *)(puStack_1c + 0x14) = DAT_018fe520;
      puStack_1c[0x16] = DAT_018fe528;
      puStack_1c[0x13] = fStack_2c;
      FUN_00764100(&uStack_20,uVar7);
      puVar11 = puStack_1c;
      puStack_1c[0xf] = 0x3f800000;
      fVar12 = (float10)FUN_00767900(uStack_20);
      puVar11[0x1a] = (float)fVar12;
      puVar11[0x1b] = (float)(int)uStack_20._2_2_ / DAT_018f9000;
      puVar11[0x17] = fStack_18;
      fVar12 = (float10)FUN_00764430(uVar7);
      fStack_18 = (float)fVar12;
      FUN_0074b590(&uStack_44,&uStack_10,(uStack_14 >> 3) + uStack_14,uVar7);
      puVar11[0x14] = fStack_18 * (float)uStack_10;
      puVar11[0x15] = fStack_18 * uStack_10._4_4_;
      fVar4 = DAT_018ce2f4;
      puVar11[0x16] = fStack_18 * fStack_8;
      puVar11[0x18] = uStack_44;
      puVar11[0x19] = uStack_40;
      fStack_74 = fStack_8 * fVar4 + 0.0;
      fStack_68 = 0.0 - fStack_8 * fVar4;
      uStack_64 = CONCAT44(0.0 - uStack_10._4_4_ * fVar4,0.0 - (float)uStack_10 * fVar4);
      uStack_58 = CONCAT44(uStack_10._4_4_ * fVar4 + 0.0,(float)uStack_10 * fVar4 + 0.0);
      fStack_5c = fStack_68;
      fStack_50 = fStack_74;
      puVar8 = (undefined4 *)FUN_00c9f550(auStack_ac,puVar6);
      fVar4 = DAT_018ce2f4;
      uVar1 = puVar8[1];
      uVar7 = puVar8[2];
      uVar2 = puVar8[3];
      puVar6 = (undefined4 *)(iStack_30 + iStack_34 * 0x18);
      *puVar6 = *puVar8;
      puVar6[1] = uVar1;
      puVar6[2] = uVar7;
      puVar6[3] = uVar2;
      *(undefined8 *)(iStack_30 + 0x10 + iStack_34 * 0x18) = *(undefined8 *)(puVar8 + 4);
      fStack_80 = fStack_8 * fVar4;
      *(ulonglong *)(iStack_38 + 0x34) = CONCAT44(uStack_10._4_4_ * fVar4,(float)uStack_10 * fVar4);
      *(float *)(iStack_38 + 0x3c) = fStack_80;
      iVar10 = *(int *)(*(int *)(iStack_38 + 0x1c) + 0x8c);
      if (((*(float *)(iVar10 + 0x24) <= *(float *)(iStack_38 + 0x34)) ||
          (*(float *)(iVar10 + 0x28) <= *(float *)(iStack_38 + 0x38))) ||
         (*(float *)(iVar10 + 0x2c) <= *(float *)(iStack_38 + 0x3c))) {
        bVar3 = true;
      }
      else {
        bVar3 = false;
      }
      uVar9 = *(uint *)(iStack_38 + 0x2c) | 0x200;
      if (!bVar3) {
        uVar9 = *(uint *)(iStack_38 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iStack_38 + 0x2c) = uVar9;
      *(uint *)(iStack_3c + 0xd0) = *(uint *)(iStack_3c + 0xd0) | 1;
      puVar11[0xf] = 0x37d1b717;
      if (-1 < *(int *)(iStack_38 + 0x30)) {
        FUN_00d38fb0(*(int *)(iStack_38 + 0x30),uStack_14,0,iStack_38);
      }
      if (puStack_24 != (undefined4 *)0x0) {
        for (iVar10 = 0x1c; iVar10 != 0; iVar10 = iVar10 + -1) {
          *puStack_24 = *puVar11;
          puVar11 = puVar11 + 1;
          puStack_24 = puStack_24 + 1;
        }
      }
      uStack_28 = uStack_28 + 1;
    } while (uStack_28 < param_2);
  }
  return;
}



/* FUNCTION 11587 ; VA 0x007b08f0 ; FUN_007b08f0 */

void FUN_007b08f0(int param_1,uint param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  bool bVar3;
  float fVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  float10 fVar12;
  undefined auStack_94 [32];
  float fStack_74;
  float fStack_68;
  float fStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  float fStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_1c = 0;
  if (param_2 != 0) {
    do {
      iStack_34 = *(int *)(param_1 + uStack_1c * 4);
      iStack_38 = *(int *)(iStack_34 + 0x20);
      iStack_30 = *(int *)(iStack_34 + 0x24);
      puStack_20 = (undefined4 *)(*(int *)(iStack_38 + 0xac) + iStack_30 * 0x70);
      if (*(int *)(iStack_34 + 0x28) == -1) {
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        puStack_18 = (undefined4 *)(*(int *)(iStack_34 + 0x28) * 0x70 + *(int *)(iStack_38 + 0x88));
      }
      iStack_2c = *(int *)(iStack_38 + 0xb8);
      uStack_40 = *(undefined8 *)(*(int *)(iStack_34 + 0x40) + 0x9c);
      uVar1 = *(undefined4 *)(*(int *)(iStack_34 + 0x40) + 0xa4);
      iVar10 = *(int *)(*(int *)(iStack_34 + 0x48) + 4);
      fVar12 = (float10)FUN_00d00910();
      fStack_24 = (float)((float10)1 - fVar12);
      puVar5 = (undefined4 *)FUN_00b077e0();
      puVar6 = (undefined8 *)FUN_00b08320();
      uStack_10 = *puVar6;
      fStack_8 = *(float *)(puVar6 + 1);
      uVar7 = FUN_00b084e0();
      puVar11 = puStack_20;
      if (uStack_10._4_4_ <= fStack_8) {
        fStack_8 = uStack_10._4_4_;
      }
      uStack_10 = CONCAT44(fStack_8,(float)uStack_10);
      uStack_28 = *(undefined4 *)(iVar10 + 0xd0);
      *puStack_20 = *puVar5;
      puStack_20[1] = puVar5[1];
      puStack_20[2] = puVar5[2];
      puStack_20[3] = puVar5[9];
      puStack_20[4] = puVar5[3];
      puStack_20[5] = puVar5[4];
      puStack_20[6] = puVar5[5];
      puStack_20[7] = puVar5[10];
      puStack_20[8] = puVar5[6];
      puStack_20[9] = puVar5[7];
      puStack_20[10] = puVar5[8];
      puStack_20[0xb] = puVar5[0xb];
      *(undefined8 *)(puStack_20 + 0xc) = uStack_10;
      *(undefined8 *)(puStack_20 + 0x10) = uStack_40;
      puStack_20[0xe] = fStack_8;
      puStack_20[0x12] = uVar1;
      *(undefined8 *)(puStack_20 + 0x18) = 0;
      *(undefined8 *)(puStack_20 + 0x14) = DAT_018fe520;
      puStack_20[0x16] = DAT_018fe528;
      puStack_20[0x13] = fStack_24;
      FUN_00764100(&uStack_14,uVar7);
      puVar11[0xf] = 0x3f800000;
      fVar12 = (float10)FUN_00767900(uStack_14);
      puVar11[0x1a] = (float)fVar12;
      puVar11[0x1b] = (float)(int)uStack_14._2_2_ / DAT_018f9000;
      puVar11[0x17] = uStack_28;
      fStack_68 = fStack_8 * DAT_018ce2f4 + 0.0;
      fStack_5c = 0.0 - fStack_8 * DAT_018ce2f4;
      uStack_58 = CONCAT44(0.0 - uStack_10._4_4_ * DAT_018ce2f4,
                           0.0 - (float)uStack_10 * DAT_018ce2f4);
      uStack_4c = CONCAT44(uStack_10._4_4_ * DAT_018ce2f4 + 0.0,
                           (float)uStack_10 * DAT_018ce2f4 + 0.0);
      fStack_50 = fStack_5c;
      fStack_44 = fStack_68;
      puVar8 = (undefined4 *)FUN_00c9f550(auStack_94,puVar5);
      fVar4 = DAT_018ce2f4;
      uVar1 = puVar8[1];
      uVar7 = puVar8[2];
      uVar2 = puVar8[3];
      puVar5 = (undefined4 *)(iStack_2c + iStack_30 * 0x18);
      *puVar5 = *puVar8;
      puVar5[1] = uVar1;
      puVar5[2] = uVar7;
      puVar5[3] = uVar2;
      *(undefined8 *)(iStack_2c + 0x10 + iStack_30 * 0x18) = *(undefined8 *)(puVar8 + 4);
      fStack_74 = fStack_8 * fVar4;
      *(ulonglong *)(iStack_34 + 0x34) = CONCAT44(uStack_10._4_4_ * fVar4,(float)uStack_10 * fVar4);
      *(float *)(iStack_34 + 0x3c) = fStack_74;
      iVar10 = *(int *)(*(int *)(iStack_34 + 0x1c) + 0x8c);
      if (((*(float *)(iVar10 + 0x24) <= *(float *)(iStack_34 + 0x34)) ||
          (*(float *)(iVar10 + 0x28) <= *(float *)(iStack_34 + 0x38))) ||
         (*(float *)(iVar10 + 0x2c) <= *(float *)(iStack_34 + 0x3c))) {
        bVar3 = true;
      }
      else {
        bVar3 = false;
      }
      uVar9 = *(uint *)(iStack_34 + 0x2c) | 0x200;
      if (!bVar3) {
        uVar9 = *(uint *)(iStack_34 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iStack_34 + 0x2c) = uVar9;
      *(uint *)(iStack_38 + 0xd0) = *(uint *)(iStack_38 + 0xd0) | 1;
      puVar11[0xf] = 0x37d1b717;
      if (puStack_18 != (undefined4 *)0x0) {
        for (iVar10 = 0x1c; iVar10 != 0; iVar10 = iVar10 + -1) {
          *puStack_18 = *puVar11;
          puVar11 = puVar11 + 1;
          puStack_18 = puStack_18 + 1;
        }
      }
      uStack_1c = uStack_1c + 1;
    } while (uStack_1c < param_2);
  }
  return;
}



/* FUNCTION 11588 ; VA 0x007b0bf0 ; FUN_007b0bf0 */

void FUN_007b0bf0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  float fVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  bool bVar6;
  undefined8 *puVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  undefined4 *puVar12;
  float10 fVar13;
  float fVar14;
  float fVar15;
  undefined auStack_98 [32];
  float fStack_78;
  float fStack_6c;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  undefined8 uStack_50;
  float fStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  float fStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_20 = 0;
  if (param_2 != 0) {
    do {
      iStack_38 = *(int *)(param_1 + uStack_20 * 4);
      iStack_3c = *(int *)(iStack_38 + 0x20);
      iStack_34 = *(int *)(iStack_38 + 0x24);
      puStack_14 = (undefined4 *)(*(int *)(iStack_3c + 0xac) + iStack_34 * 0x70);
      if (*(int *)(iStack_38 + 0x28) == -1) {
        puStack_1c = (undefined4 *)0x0;
      }
      else {
        puStack_1c = (undefined4 *)(*(int *)(iStack_38 + 0x28) * 0x70 + *(int *)(iStack_3c + 0x88));
      }
      iStack_30 = *(int *)(iStack_3c + 0xb8);
      iVar11 = *(int *)(iStack_38 + 0x40);
      iVar3 = *(int *)(*(int *)(iStack_38 + 0x48) + 4);
      uStack_44 = *(undefined8 *)(iVar11 + 0x9c);
      uVar4 = *(undefined4 *)(iVar11 + 0xa4);
      fVar13 = (float10)FUN_00d00910();
      fStack_28 = (float)((float10)1 - fVar13);
      puStack_24 = (undefined4 *)FUN_00b077e0();
      puVar7 = (undefined8 *)FUN_00b08320();
      uStack_10 = *puVar7;
      fStack_8 = *(float *)(puVar7 + 1);
      uVar8 = FUN_00b084e0();
      puVar1 = puStack_24;
      if (uStack_10._4_4_ <= fStack_8) {
        fStack_8 = uStack_10._4_4_;
      }
      uStack_10 = CONCAT44(fStack_8,(float)uStack_10);
      uStack_2c = *(undefined4 *)(iVar3 + 0xd0);
      *puStack_14 = *puStack_24;
      puStack_14[1] = puStack_24[1];
      puStack_14[2] = puStack_24[2];
      puStack_14[3] = puStack_24[9];
      puStack_14[4] = puStack_24[3];
      puStack_14[5] = puStack_24[4];
      puStack_14[6] = puStack_24[5];
      puStack_14[7] = puStack_24[10];
      puStack_14[8] = puStack_24[6];
      puStack_14[9] = puStack_24[7];
      puStack_14[10] = puStack_24[8];
      puStack_14[0xb] = puStack_24[0xb];
      *(undefined8 *)(puStack_14 + 0xc) = uStack_10;
      *(undefined8 *)(puStack_14 + 0x10) = uStack_44;
      puStack_14[0xe] = fStack_8;
      puStack_14[0x12] = uVar4;
      *(undefined8 *)(puStack_14 + 0x18) = 0;
      *(undefined8 *)(puStack_14 + 0x14) = DAT_018fe520;
      puStack_14[0x16] = DAT_018fe528;
      puStack_14[0x13] = fStack_28;
      FUN_00764100(&uStack_18,uVar8);
      puVar12 = puStack_14;
      puStack_14[0xf] = 0x3f800000;
      fVar13 = (float10)FUN_00767900(uStack_18);
      puVar12[0x1a] = (float)fVar13;
      fVar15 = DAT_018ce2f8;
      puVar12[0x1b] = (float)(int)uStack_18._2_2_ / DAT_018f9000;
      puVar12[0x17] = uStack_2c;
      fVar14 = fVar15 / *(float *)(iVar11 + 0xa8);
      iVar3 = *(int *)(iVar11 + 0x70);
      fVar15 = fVar15 / *(float *)(iVar11 + 0xac);
      puVar12[*(int *)(&DAT_018fee20 + iVar3 * 8) + 0x14] = fVar14;
      puVar12[*(int *)(&DAT_018fee24 + iVar3 * 8) + 0x14] = fVar15;
      puVar12[0x14] = (float)puVar12[0x14] * (float)uStack_10;
      puVar12[0x15] = (float)puVar12[0x15] * uStack_10._4_4_;
      puVar12[0x16] = (float)puVar12[0x16] * fStack_8;
      fVar2 = *(float *)(iVar11 + 0xb4);
      puVar12[0x18] = *(float *)(iVar11 + 0xb0) * fVar14;
      fVar14 = DAT_018ce2f4;
      puVar12[0x19] = fVar2 * fVar15;
      fStack_6c = fStack_8 * fVar14 + 0.0;
      fStack_60 = 0.0 - fStack_8 * fVar14;
      uStack_5c = CONCAT44(0.0 - uStack_10._4_4_ * fVar14,0.0 - (float)uStack_10 * fVar14);
      uStack_50 = CONCAT44(uStack_10._4_4_ * fVar14 + 0.0,(float)uStack_10 * fVar14 + 0.0);
      fStack_54 = fStack_60;
      fStack_48 = fStack_6c;
      puVar9 = (undefined4 *)FUN_00c9f550(auStack_98,puVar1);
      fVar2 = DAT_018ce2f4;
      uVar4 = puVar9[1];
      uVar8 = puVar9[2];
      uVar5 = puVar9[3];
      puVar1 = (undefined4 *)(iStack_30 + iStack_34 * 0x18);
      *puVar1 = *puVar9;
      puVar1[1] = uVar4;
      puVar1[2] = uVar8;
      puVar1[3] = uVar5;
      *(undefined8 *)(iStack_30 + 0x10 + iStack_34 * 0x18) = *(undefined8 *)(puVar9 + 4);
      fStack_78 = fStack_8 * fVar2;
      *(ulonglong *)(iStack_38 + 0x34) = CONCAT44(uStack_10._4_4_ * fVar2,(float)uStack_10 * fVar2);
      *(float *)(iStack_38 + 0x3c) = fStack_78;
      iVar11 = *(int *)(*(int *)(iStack_38 + 0x1c) + 0x8c);
      if (((*(float *)(iVar11 + 0x24) <= *(float *)(iStack_38 + 0x34)) ||
          (*(float *)(iVar11 + 0x28) <= *(float *)(iStack_38 + 0x38))) ||
         (*(float *)(iVar11 + 0x2c) <= *(float *)(iStack_38 + 0x3c))) {
        bVar6 = true;
      }
      else {
        bVar6 = false;
      }
      uVar10 = *(uint *)(iStack_38 + 0x2c) | 0x200;
      if (!bVar6) {
        uVar10 = *(uint *)(iStack_38 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iStack_38 + 0x2c) = uVar10;
      *(uint *)(iStack_3c + 0xd0) = *(uint *)(iStack_3c + 0xd0) | 1;
      puVar12[0xf] = 0x37d1b717;
      if (puStack_1c != (undefined4 *)0x0) {
        for (iVar11 = 0x1c; iVar11 != 0; iVar11 = iVar11 + -1) {
          *puStack_1c = *puVar12;
          puVar12 = puVar12 + 1;
          puStack_1c = puStack_1c + 1;
        }
      }
      uStack_20 = uStack_20 + 1;
    } while (uStack_20 < param_2);
  }
  return;
}



/* FUNCTION 11589 ; VA 0x007b0f90 ; FUN_007b0f90 */

void FUN_007b0f90(int param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  bool bVar7;
  float fVar8;
  undefined8 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  float10 fVar14;
  undefined auStack_b0 [24];
  undefined auStack_98 [20];
  float fStack_84;
  float fStack_78;
  float fStack_6c;
  undefined8 uStack_68;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  float fStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  undefined8 uStack_14;
  float fStack_c;
  undefined4 *puStack_8;
  
  uStack_28 = 0;
  if (param_2 != 0) {
    do {
      iVar12 = *(int *)(param_1 + uStack_28 * 4);
      iStack_40 = *(int *)(iVar12 + 0x20);
      puStack_8 = (undefined4 *)(*(int *)(iStack_40 + 0xac) + *(int *)(iVar12 + 0x24) * 0x70);
      if (*(int *)(iVar12 + 0x28) == -1) {
        puVar13 = (undefined4 *)0x0;
      }
      else {
        puVar13 = (undefined4 *)(*(int *)(iVar12 + 0x28) * 0x70 + *(int *)(iStack_40 + 0x88));
      }
      iStack_38 = *(int *)(iVar12 + 0x24) * 3;
      uVar2 = *(uint *)(iVar12 + 4);
      iStack_3c = *(int *)(iStack_40 + 0xb8);
      puVar9 = (undefined8 *)FUN_00b06fb0(auStack_98);
      uStack_50 = *puVar9;
      uStack_2c = *(undefined4 *)(puVar9 + 1);
      fVar14 = (float10)FUN_00b08910();
      fStack_30 = (float)((float10)1 - fVar14);
      puStack_24 = (undefined4 *)FUN_00b077e0();
      puVar9 = (undefined8 *)FUN_00b08320();
      uStack_14 = *puVar9;
      fStack_c = *(float *)(puVar9 + 1);
      uStack_18 = FUN_00b084e0();
      iStack_34 = (uVar2 >> 3) + uVar2;
      if (uStack_14._4_4_ <= fStack_c) {
        fStack_c = uStack_14._4_4_;
      }
      if (fStack_c <= (float)uStack_14) {
        uStack_14._0_4_ = fStack_c;
      }
      uStack_14 = CONCAT44((float)uStack_14,(float)uStack_14);
      fStack_1c = *(float *)(uVar2 + 0xd0);
      *puStack_8 = *puStack_24;
      puStack_8[1] = puStack_24[1];
      puStack_8[2] = puStack_24[2];
      puStack_8[3] = puStack_24[9];
      puStack_8[4] = puStack_24[3];
      puStack_8[5] = puStack_24[4];
      puStack_8[6] = puStack_24[5];
      puStack_8[7] = puStack_24[10];
      puStack_8[8] = puStack_24[6];
      puStack_8[9] = puStack_24[7];
      puStack_8[10] = puStack_24[8];
      puStack_8[0xb] = puStack_24[0xb];
      *(undefined8 *)(puStack_8 + 0xc) = uStack_14;
      *(undefined8 *)(puStack_8 + 0x10) = uStack_50;
      puStack_8[0xe] = (float)uStack_14;
      puStack_8[0x12] = uStack_2c;
      *(undefined8 *)(puStack_8 + 0x18) = 0;
      *(undefined8 *)(puStack_8 + 0x14) = DAT_018fe520;
      puStack_8[0x16] = DAT_018fe528;
      puStack_8[0x13] = fStack_30;
      fStack_c = (float)uStack_14;
      FUN_00764100(&uStack_20,uStack_18);
      puStack_8[0xf] = 0x3f800000;
      fVar14 = (float10)FUN_00767900(uStack_20);
      puStack_8[0x1a] = (float)fVar14;
      puStack_8[0x1b] = (float)(int)uStack_20._2_2_ / DAT_018f9000;
      puStack_8[0x17] = fStack_1c;
      fVar14 = (float10)FUN_00764430(uStack_18);
      fStack_1c = (float)fVar14;
      FUN_0074b590(&uStack_48,&uStack_14,iStack_34,uStack_18);
      puStack_8[0x14] = fStack_1c * (float)uStack_14;
      puStack_8[0x15] = fStack_1c * uStack_14._4_4_;
      fVar8 = DAT_018ce2f4;
      puStack_8[0x16] = fStack_1c * fStack_c;
      puStack_8[0x18] = uStack_48;
      puStack_8[0x19] = uStack_44;
      fStack_78 = fStack_c * fVar8 + 0.0;
      fStack_6c = 0.0 - fStack_c * fVar8;
      uStack_68 = CONCAT44(0.0 - uStack_14._4_4_ * fVar8,0.0 - (float)uStack_14 * fVar8);
      uStack_5c = CONCAT44(uStack_14._4_4_ * fVar8 + 0.0,(float)uStack_14 * fVar8 + 0.0);
      fStack_60 = fStack_6c;
      fStack_54 = fStack_78;
      puVar10 = (undefined4 *)FUN_00c9f550(auStack_b0,puStack_24);
      fVar8 = DAT_018ce2f4;
      uVar4 = puVar10[1];
      uVar5 = puVar10[2];
      uVar6 = puVar10[3];
      puVar1 = (undefined4 *)(iStack_3c + iStack_38 * 8);
      *puVar1 = *puVar10;
      puVar1[1] = uVar4;
      puVar1[2] = uVar5;
      puVar1[3] = uVar6;
      *(undefined8 *)(iStack_3c + 0x10 + iStack_38 * 8) = *(undefined8 *)(puVar10 + 4);
      fStack_84 = fStack_c * fVar8;
      *(ulonglong *)(iVar12 + 0x34) = CONCAT44(uStack_14._4_4_ * fVar8,(float)uStack_14 * fVar8);
      *(float *)(iVar12 + 0x3c) = fStack_84;
      iVar3 = *(int *)(*(int *)(iVar12 + 0x1c) + 0x8c);
      if (((*(float *)(iVar3 + 0x24) <= *(float *)(iVar12 + 0x34)) ||
          (*(float *)(iVar3 + 0x28) <= *(float *)(iVar12 + 0x38))) ||
         (*(float *)(iVar3 + 0x2c) <= *(float *)(iVar12 + 0x3c))) {
        bVar7 = true;
      }
      else {
        bVar7 = false;
      }
      uVar11 = *(uint *)(iVar12 + 0x2c) | 0x200;
      if (!bVar7) {
        uVar11 = *(uint *)(iVar12 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar12 + 0x2c) = uVar11;
      *(uint *)(iStack_40 + 0xd0) = *(uint *)(iStack_40 + 0xd0) | 1;
      puStack_8[0xf] = 0x37d1b717;
      if (-1 < *(int *)(iVar12 + 0x30)) {
        FUN_00d38fb0(*(int *)(iVar12 + 0x30),uVar2,0,iVar12);
      }
      if (puVar13 != (undefined4 *)0x0) {
        for (iVar12 = 0x1c; iVar12 != 0; iVar12 = iVar12 + -1) {
          *puVar13 = *puStack_8;
          puStack_8 = puStack_8 + 1;
          puVar13 = puVar13 + 1;
        }
      }
      uStack_28 = uStack_28 + 1;
    } while (uStack_28 < param_2);
  }
  return;
}



/* FUNCTION 11590 ; VA 0x007b1340 ; FUN_007b1340 */

void FUN_007b1340(int param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  bool bVar7;
  float fVar8;
  undefined8 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  float10 fVar14;
  undefined auStack_94 [32];
  float fStack_74;
  float fStack_68;
  float fStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  float fStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined8 uStack_14;
  float fStack_c;
  int iStack_8;
  
  uStack_24 = 0;
  if (param_2 != 0) {
    do {
      iVar12 = *(int *)(param_1 + uStack_24 * 4);
      iVar2 = *(int *)(iVar12 + 0x20);
      puStack_18 = (undefined4 *)(*(int *)(iVar2 + 0xac) + *(int *)(iVar12 + 0x24) * 0x70);
      if (*(int *)(iVar12 + 0x28) == -1) {
        puVar13 = (undefined4 *)0x0;
      }
      else {
        puVar13 = (undefined4 *)(*(int *)(iVar12 + 0x28) * 0x70 + *(int *)(iVar2 + 0x88));
      }
      iStack_34 = *(int *)(iVar12 + 0x24) * 3;
      iStack_38 = *(int *)(iVar2 + 0xb8);
      uStack_40 = *(undefined8 *)(*(int *)(iVar12 + 0x40) + 0x9c);
      iStack_8 = *(int *)(*(int *)(iVar12 + 0x48) + 4);
      uStack_28 = *(undefined4 *)(*(int *)(iVar12 + 0x40) + 0xa4);
      fVar14 = (float10)FUN_00d00910();
      fStack_2c = (float)((float10)1 - fVar14);
      puStack_20 = (undefined4 *)FUN_00b077e0();
      puVar9 = (undefined8 *)FUN_00b08320();
      uStack_14 = *puVar9;
      fStack_c = *(float *)(puVar9 + 1);
      uStack_30 = FUN_00b084e0();
      if (uStack_14._4_4_ <= fStack_c) {
        fStack_c = uStack_14._4_4_;
      }
      if (fStack_c <= (float)uStack_14) {
        uStack_14._0_4_ = fStack_c;
      }
      uStack_14 = CONCAT44((float)uStack_14,(float)uStack_14);
      iStack_8 = *(undefined4 *)(iStack_8 + 0xd0);
      *puStack_18 = *puStack_20;
      puStack_18[1] = puStack_20[1];
      puStack_18[2] = puStack_20[2];
      puStack_18[3] = puStack_20[9];
      puStack_18[4] = puStack_20[3];
      puStack_18[5] = puStack_20[4];
      puStack_18[6] = puStack_20[5];
      puStack_18[7] = puStack_20[10];
      puStack_18[8] = puStack_20[6];
      puStack_18[9] = puStack_20[7];
      puStack_18[10] = puStack_20[8];
      puStack_18[0xb] = puStack_20[0xb];
      *(undefined8 *)(puStack_18 + 0xc) = uStack_14;
      *(undefined8 *)(puStack_18 + 0x10) = uStack_40;
      puStack_18[0xe] = (float)uStack_14;
      puStack_18[0x12] = uStack_28;
      *(undefined8 *)(puStack_18 + 0x18) = 0;
      *(undefined8 *)(puStack_18 + 0x14) = DAT_018fe520;
      puStack_18[0x16] = DAT_018fe528;
      puStack_18[0x13] = fStack_2c;
      fStack_c = (float)uStack_14;
      FUN_00764100(&uStack_1c,uStack_30);
      puStack_18[0xf] = 0x3f800000;
      fVar14 = (float10)FUN_00767900(uStack_1c);
      puStack_18[0x1a] = (float)fVar14;
      puStack_18[0x1b] = (float)(int)uStack_1c._2_2_ / DAT_018f9000;
      puStack_18[0x17] = iStack_8;
      fStack_68 = fStack_c * DAT_018ce2f4 + 0.0;
      uStack_4c = CONCAT44(uStack_14._4_4_ * DAT_018ce2f4 + 0.0,
                           (float)uStack_14 * DAT_018ce2f4 + 0.0);
      fStack_5c = 0.0 - fStack_c * DAT_018ce2f4;
      uStack_58 = CONCAT44(0.0 - uStack_14._4_4_ * DAT_018ce2f4,
                           0.0 - (float)uStack_14 * DAT_018ce2f4);
      fStack_50 = fStack_5c;
      fStack_44 = fStack_68;
      puVar10 = (undefined4 *)FUN_00c9f550(auStack_94,puStack_20);
      fVar8 = DAT_018ce2f4;
      uVar4 = puVar10[1];
      uVar5 = puVar10[2];
      uVar6 = puVar10[3];
      puVar1 = (undefined4 *)(iStack_38 + iStack_34 * 8);
      *puVar1 = *puVar10;
      puVar1[1] = uVar4;
      puVar1[2] = uVar5;
      puVar1[3] = uVar6;
      *(undefined8 *)(iStack_38 + 0x10 + iStack_34 * 8) = *(undefined8 *)(puVar10 + 4);
      fStack_74 = fStack_c * fVar8;
      *(ulonglong *)(iVar12 + 0x34) = CONCAT44(uStack_14._4_4_ * fVar8,(float)uStack_14 * fVar8);
      *(float *)(iVar12 + 0x3c) = fStack_74;
      iVar3 = *(int *)(*(int *)(iVar12 + 0x1c) + 0x8c);
      if (((*(float *)(iVar3 + 0x24) <= *(float *)(iVar12 + 0x34)) ||
          (*(float *)(iVar3 + 0x28) <= *(float *)(iVar12 + 0x38))) ||
         (*(float *)(iVar3 + 0x2c) <= *(float *)(iVar12 + 0x3c))) {
        bVar7 = true;
      }
      else {
        bVar7 = false;
      }
      uVar11 = *(uint *)(iVar12 + 0x2c) | 0x200;
      if (!bVar7) {
        uVar11 = *(uint *)(iVar12 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar12 + 0x2c) = uVar11;
      *(uint *)(iVar2 + 0xd0) = *(uint *)(iVar2 + 0xd0) | 1;
      puStack_18[0xf] = 0x37d1b717;
      if (puVar13 != (undefined4 *)0x0) {
        for (iVar12 = 0x1c; iVar12 != 0; iVar12 = iVar12 + -1) {
          *puVar13 = *puStack_18;
          puStack_18 = puStack_18 + 1;
          puVar13 = puVar13 + 1;
        }
      }
      uStack_24 = uStack_24 + 1;
    } while (uStack_24 < param_2);
  }
  return;
}



/* FUNCTION 11591 ; VA 0x007b1670 ; FUN_007b1670 */

void FUN_007b1670(int param_1,uint param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  bool bVar3;
  float fVar4;
  undefined8 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  float10 fVar12;
  undefined auStack_ac [24];
  undefined auStack_94 [20];
  float fStack_80;
  float fStack_74;
  float fStack_68;
  undefined8 uStack_64;
  float fStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  float fStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  float fStack_18;
  uint uStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_28 = 0;
  if (param_2 != 0) {
    do {
      iStack_38 = *(int *)(param_1 + uStack_28 * 4);
      iStack_3c = *(int *)(iStack_38 + 0x20);
      iStack_34 = *(int *)(iStack_38 + 0x24);
      puStack_1c = (undefined4 *)(*(int *)(iStack_3c + 0xac) + iStack_34 * 0x70);
      if (*(int *)(iStack_38 + 0x28) == -1) {
        puStack_24 = (undefined4 *)0x0;
      }
      else {
        puStack_24 = (undefined4 *)(*(int *)(iStack_38 + 0x28) * 0x70 + *(int *)(iStack_3c + 0x88));
      }
      iStack_30 = *(int *)(iStack_3c + 0xb8);
      uStack_14 = *(uint *)(iStack_38 + 4);
      puVar5 = (undefined8 *)FUN_00b06fb0(auStack_94);
      uStack_4c = *puVar5;
      uVar1 = *(undefined4 *)(puVar5 + 1);
      fVar12 = (float10)FUN_00b08910();
      fStack_2c = (float)((float10)1 - fVar12);
      puVar6 = (undefined4 *)FUN_00b077e0();
      puVar5 = (undefined8 *)FUN_00b08320();
      uStack_10 = *puVar5;
      fStack_8 = *(float *)(puVar5 + 1);
      uVar7 = FUN_00b084e0();
      fStack_18 = *(float *)(uStack_14 + 0xd0);
      *puStack_1c = *puVar6;
      puStack_1c[1] = puVar6[1];
      puStack_1c[2] = puVar6[2];
      puStack_1c[3] = puVar6[9];
      puStack_1c[4] = puVar6[3];
      puStack_1c[5] = puVar6[4];
      puStack_1c[6] = puVar6[5];
      puStack_1c[7] = puVar6[10];
      puStack_1c[8] = puVar6[6];
      puStack_1c[9] = puVar6[7];
      puStack_1c[10] = puVar6[8];
      puStack_1c[0xb] = puVar6[0xb];
      *(undefined8 *)(puStack_1c + 0xc) = uStack_10;
      *(undefined8 *)(puStack_1c + 0x10) = uStack_4c;
      puStack_1c[0xe] = fStack_8;
      puStack_1c[0x12] = uVar1;
      *(undefined8 *)(puStack_1c + 0x18) = 0;
      *(undefined8 *)(puStack_1c + 0x14) = DAT_018fe520;
      puStack_1c[0x16] = DAT_018fe528;
      puStack_1c[0x13] = fStack_2c;
      FUN_00764100(&uStack_20,uVar7);
      puVar11 = puStack_1c;
      puStack_1c[0xf] = 0x3f800000;
      fVar12 = (float10)FUN_00767900(uStack_20);
      puVar11[0x1a] = (float)fVar12;
      puVar11[0x1b] = (float)(int)uStack_20._2_2_ / DAT_018f9000;
      puVar11[0x17] = fStack_18;
      fVar12 = (float10)FUN_00764430(uVar7);
      fStack_18 = (float)fVar12;
      FUN_0074b590(&uStack_44,&uStack_10,(uStack_14 >> 3) + uStack_14,uVar7);
      puVar11[0x14] = fStack_18 * (float)uStack_10;
      puVar11[0x15] = fStack_18 * uStack_10._4_4_;
      fVar4 = DAT_018ce2f4;
      puVar11[0x16] = fStack_18 * fStack_8;
      puVar11[0x18] = uStack_44;
      puVar11[0x19] = uStack_40;
      fStack_74 = fStack_8 * fVar4 + 0.0;
      fStack_68 = 0.0 - fStack_8 * fVar4;
      uStack_64 = CONCAT44(0.0 - uStack_10._4_4_ * fVar4,0.0 - (float)uStack_10 * fVar4);
      uStack_58 = CONCAT44(uStack_10._4_4_ * fVar4 + 0.0,(float)uStack_10 * fVar4 + 0.0);
      fStack_5c = fStack_68;
      fStack_50 = fStack_74;
      puVar8 = (undefined4 *)FUN_00c9f550(auStack_ac,puVar6);
      fVar4 = DAT_018ce2f4;
      uVar1 = puVar8[1];
      uVar7 = puVar8[2];
      uVar2 = puVar8[3];
      puVar6 = (undefined4 *)(iStack_30 + iStack_34 * 0x18);
      *puVar6 = *puVar8;
      puVar6[1] = uVar1;
      puVar6[2] = uVar7;
      puVar6[3] = uVar2;
      *(undefined8 *)(iStack_30 + 0x10 + iStack_34 * 0x18) = *(undefined8 *)(puVar8 + 4);
      fStack_80 = fStack_8 * fVar4;
      *(ulonglong *)(iStack_38 + 0x34) = CONCAT44(uStack_10._4_4_ * fVar4,(float)uStack_10 * fVar4);
      *(float *)(iStack_38 + 0x3c) = fStack_80;
      iVar10 = *(int *)(*(int *)(iStack_38 + 0x1c) + 0x8c);
      if (((*(float *)(iVar10 + 0x24) <= *(float *)(iStack_38 + 0x34)) ||
          (*(float *)(iVar10 + 0x28) <= *(float *)(iStack_38 + 0x38))) ||
         (*(float *)(iVar10 + 0x2c) <= *(float *)(iStack_38 + 0x3c))) {
        bVar3 = true;
      }
      else {
        bVar3 = false;
      }
      uVar9 = *(uint *)(iStack_38 + 0x2c) | 0x200;
      if (!bVar3) {
        uVar9 = *(uint *)(iStack_38 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iStack_38 + 0x2c) = uVar9;
      *(uint *)(iStack_3c + 0xd0) = *(uint *)(iStack_3c + 0xd0) | 1;
      puVar11[0xf] = 0x37d1b717;
      if (-1 < *(int *)(iStack_38 + 0x30)) {
        FUN_00d38fb0(*(int *)(iStack_38 + 0x30),uStack_14,0,iStack_38);
      }
      if (puStack_24 != (undefined4 *)0x0) {
        for (iVar10 = 0x1c; iVar10 != 0; iVar10 = iVar10 + -1) {
          *puStack_24 = *puVar11;
          puVar11 = puVar11 + 1;
          puStack_24 = puStack_24 + 1;
        }
      }
      uStack_28 = uStack_28 + 1;
    } while (uStack_28 < param_2);
  }
  return;
}



/* FUNCTION 11592 ; VA 0x007b19e0 ; FUN_007b19e0 */

void FUN_007b19e0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  bool bVar8;
  undefined8 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  float10 fVar14;
  float fVar15;
  float fVar16;
  undefined auStack_98 [32];
  float fStack_78;
  float fStack_6c;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  undefined8 uStack_50;
  float fStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  float fStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined8 uStack_14;
  float fStack_c;
  int iStack_8;
  
  uStack_28 = 0;
  if (param_2 != 0) {
    do {
      iVar12 = *(int *)(param_1 + uStack_28 * 4);
      iVar3 = *(int *)(iVar12 + 0x20);
      puStack_18 = (undefined4 *)(*(int *)(iVar3 + 0xac) + *(int *)(iVar12 + 0x24) * 0x70);
      if (*(int *)(iVar12 + 0x28) == -1) {
        puVar13 = (undefined4 *)0x0;
      }
      else {
        puVar13 = (undefined4 *)(*(int *)(iVar12 + 0x28) * 0x70 + *(int *)(iVar3 + 0x88));
      }
      iStack_38 = *(int *)(iVar12 + 0x24) * 3;
      iStack_3c = *(int *)(iVar3 + 0xb8);
      iStack_8 = *(int *)(*(int *)(iVar12 + 0x48) + 4);
      iStack_20 = *(int *)(iVar12 + 0x40);
      uStack_2c = *(undefined4 *)(iStack_20 + 0xa4);
      uStack_44 = *(undefined8 *)(iStack_20 + 0x9c);
      fVar14 = (float10)FUN_00d00910();
      fStack_30 = (float)((float10)1 - fVar14);
      puStack_24 = (undefined4 *)FUN_00b077e0();
      puVar9 = (undefined8 *)FUN_00b08320();
      uStack_14 = *puVar9;
      fStack_c = *(float *)(puVar9 + 1);
      uStack_34 = FUN_00b084e0();
      if (uStack_14._4_4_ <= fStack_c) {
        fStack_c = uStack_14._4_4_;
      }
      if (fStack_c <= (float)uStack_14) {
        uStack_14._0_4_ = fStack_c;
      }
      uStack_14 = CONCAT44((float)uStack_14,(float)uStack_14);
      iStack_8 = *(undefined4 *)(iStack_8 + 0xd0);
      *puStack_18 = *puStack_24;
      puStack_18[1] = puStack_24[1];
      puStack_18[2] = puStack_24[2];
      puStack_18[3] = puStack_24[9];
      puStack_18[4] = puStack_24[3];
      puStack_18[5] = puStack_24[4];
      puStack_18[6] = puStack_24[5];
      puStack_18[7] = puStack_24[10];
      puStack_18[8] = puStack_24[6];
      puStack_18[9] = puStack_24[7];
      puStack_18[10] = puStack_24[8];
      puStack_18[0xb] = puStack_24[0xb];
      *(undefined8 *)(puStack_18 + 0xc) = uStack_14;
      *(undefined8 *)(puStack_18 + 0x10) = uStack_44;
      puStack_18[0xe] = (float)uStack_14;
      puStack_18[0x12] = uStack_2c;
      *(undefined8 *)(puStack_18 + 0x18) = 0;
      *(undefined8 *)(puStack_18 + 0x14) = DAT_018fe520;
      puStack_18[0x16] = DAT_018fe528;
      puStack_18[0x13] = fStack_30;
      fStack_c = (float)uStack_14;
      FUN_00764100(&uStack_1c,uStack_34);
      puStack_18[0xf] = 0x3f800000;
      fVar14 = (float10)FUN_00767900(uStack_1c);
      fVar16 = DAT_018ce2f8;
      puStack_18[0x1a] = (float)fVar14;
      puStack_18[0x1b] = (float)(int)uStack_1c._2_2_ / DAT_018f9000;
      puStack_18[0x17] = iStack_8;
      fVar15 = fVar16 / *(float *)(iStack_20 + 0xa8);
      iVar4 = *(int *)(iStack_20 + 0x70);
      fVar16 = fVar16 / *(float *)(iStack_20 + 0xac);
      puStack_18[*(int *)(&DAT_018fee20 + iVar4 * 8) + 0x14] = fVar15;
      puStack_18[*(int *)(&DAT_018fee24 + iVar4 * 8) + 0x14] = fVar16;
      puStack_18[0x14] = (float)puStack_18[0x14] * (float)uStack_14;
      puStack_18[0x15] = (float)puStack_18[0x15] * uStack_14._4_4_;
      puStack_18[0x16] = (float)puStack_18[0x16] * fStack_c;
      fVar2 = *(float *)(iStack_20 + 0xb4);
      puStack_18[0x18] = *(float *)(iStack_20 + 0xb0) * fVar15;
      fVar15 = DAT_018ce2f4;
      puStack_18[0x19] = fVar2 * fVar16;
      fStack_6c = fStack_c * fVar15 + 0.0;
      fStack_60 = 0.0 - fStack_c * fVar15;
      uStack_5c = CONCAT44(0.0 - uStack_14._4_4_ * fVar15,0.0 - (float)uStack_14 * fVar15);
      uStack_50 = CONCAT44(uStack_14._4_4_ * fVar15 + 0.0,(float)uStack_14 * fVar15 + 0.0);
      fStack_54 = fStack_60;
      fStack_48 = fStack_6c;
      puVar10 = (undefined4 *)FUN_00c9f550(auStack_98,puStack_24);
      fVar2 = DAT_018ce2f4;
      uVar5 = puVar10[1];
      uVar6 = puVar10[2];
      uVar7 = puVar10[3];
      puVar1 = (undefined4 *)(iStack_3c + iStack_38 * 8);
      *puVar1 = *puVar10;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      *(undefined8 *)(iStack_3c + 0x10 + iStack_38 * 8) = *(undefined8 *)(puVar10 + 4);
      fStack_78 = fStack_c * fVar2;
      *(ulonglong *)(iVar12 + 0x34) = CONCAT44(uStack_14._4_4_ * fVar2,(float)uStack_14 * fVar2);
      *(float *)(iVar12 + 0x3c) = fStack_78;
      iVar4 = *(int *)(*(int *)(iVar12 + 0x1c) + 0x8c);
      if (((*(float *)(iVar4 + 0x24) <= *(float *)(iVar12 + 0x34)) ||
          (*(float *)(iVar4 + 0x28) <= *(float *)(iVar12 + 0x38))) ||
         (*(float *)(iVar4 + 0x2c) <= *(float *)(iVar12 + 0x3c))) {
        bVar8 = true;
      }
      else {
        bVar8 = false;
      }
      uVar11 = *(uint *)(iVar12 + 0x2c) | 0x200;
      if (!bVar8) {
        uVar11 = *(uint *)(iVar12 + 0x2c) & 0xfffffdff;
      }
      *(uint *)(iVar12 + 0x2c) = uVar11;
      *(uint *)(iVar3 + 0xd0) = *(uint *)(iVar3 + 0xd0) | 1;
      puStack_18[0xf] = 0x37d1b717;
      if (puVar13 != (undefined4 *)0x0) {
        for (iVar12 = 0x1c; iVar12 != 0; iVar12 = iVar12 + -1) {
          *puVar13 = *puStack_18;
          puStack_18 = puStack_18 + 1;
          puVar13 = puVar13 + 1;
        }
      }
      uStack_28 = uStack_28 + 1;
    } while (uStack_28 < param_2);
  }
  return;
}



/* FUNCTION 11593 ; VA 0x007b1da0 ; FUN_007b1da0 */

undefined4 * __thiscall FUN_007b1da0(undefined4 *param_1,int param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2a5e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::GfxBinding::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *param_3;
  param_1[2] = param_3[1];
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0xffffffff;
  *param_1 = RBX::Graphics::InstancedBinding2::vftable;
  param_1[7] = param_2;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  param_1[10] = 0xffffffff;
  uStack_8 = 0;
  if (DAT_01eb28ba != '\0') {
    iVar3 = FUN_00b65f00(*param_3);
    if ((iVar3 != 0) && (*(char *)(iVar3 + 0x140) == '\0')) {
      cVar2 = FUN_00b66010();
      if (cVar2 != '\0') {
        uVar4 = 0x100;
        goto LAB_007b1e66;
      }
    }
  }
  uVar4 = 0;
LAB_007b1e66:
  param_1[0xb] = uVar4;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(undefined4 **)(*param_3 + 0xb0) = param_1;
  if (DAT_01d6866c == '\0') {
    bVar5 = *(int *)(*param_3 + 0x70) == 0;
  }
  else {
    bVar5 = *(int *)(*param_3 + 0x6c) == -1;
  }
  if (!bVar5) {
    FUN_007c7840(param_1,3);
  }
  if (DAT_01eb2844 != '\0') {
    FUN_01677490(DAT_01eb2844,"binding 0x%p (0x%p) spawns",param_1,param_1[1],0);
  }
  piVar1 = (int *)(*(int *)(*(int *)(param_2 + 8) + 0x524) + 0x80);
  *piVar1 = *piVar1 + 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11594 ; VA 0x007b1f30 ; FUN_007b1f30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_007b1f30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,short *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2ac9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00841300(param_2,4);
  *param_1 = RBX::Graphics::InstancedCluster2::vftable;
  uStack_8 = 0;
  *(undefined *)(param_1 + 0x1d) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x1e] = uVar2;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = param_3;
  param_1[0x24] = *(undefined4 *)param_4;
  param_1[0x25] = *(undefined4 *)(param_4 + 2);
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  uStack_8._0_1_ = 6;
  iVar3 = FUN_01674e20(0x150);
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    FUN_0170d1f0(iVar3,0,0x150);
    uStack_8._0_1_ = 7;
    FUN_016f4053(iVar3,0xc,0x1c,FUN_00569440,FUN_0056d320);
    uStack_8._0_1_ = 6;
  }
  uStack_20 = _UNK_018c4ebc;
  uStack_24 = _UNK_018c4eb8;
  uStack_28 = _UNK_018c4eb4;
  uStack_2c = _DAT_018c4eb0;
  param_1[0x3a] = iVar3;
  param_1[0x26] = 0;
  param_1[0x33] = 0;
  uStack_1c = 0xff7fffff;
  uStack_18 = 0xff7fffff;
  FUN_008411b0(&uStack_2c,*(undefined4 *)(*(int *)(param_1[2] + 0x4e4) + 0x24));
  if (DAT_01eb2844 != '\0') {
    FUN_016773b0(DAT_01eb2844,"cluster 0x%p spawns at [%d, %d, %d]",param_1,(int)*param_4,
                 (int)param_4[1],(int)param_4[2],0);
  }
  piVar1 = (int *)(*(int *)(param_1[2] + 0x524) + 0x78);
  *piVar1 = *piVar1 + 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11595 ; VA 0x007b2150 ; FUN_007b2150 */

undefined4 * __thiscall FUN_007b2150(undefined4 *param_1,undefined4 param_2,uint *param_3)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char *pcVar6;
  char *pcVar7;
  int *piVar8;
  int *piStack_44;
  int *piStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2b70;
  pvStack_10 = ExceptionList;
  uVar1 = *param_3;
  if ((DAT_01d61b8c == '\0') || ((uVar1 & 8) == 0)) {
    iVar3 = *(int *)(&DAT_018fe500 + (uVar1 & 7) * 4);
  }
  else {
    iVar3 = (uVar1 & 1) * 4 + 5;
  }
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0147c770();
  uStack_8 = 0;
  uVar5 = FUN_0147c770();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00841220(param_2,uVar5,uVar4,param_3 + 4,iVar3,0xff,0);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar3 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_44[1] + -1;
    piStack_44[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar8 = piStack_44 + 2;
      iVar3 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  *param_1 = RBX::Graphics::InstancedEntity2::vftable;
  FUN_007b2440(param_3);
  param_1[0x19] = 0x7f7fffff;
  param_1[0x1a] = 0x7f7fffff;
  param_1[0x1b] = 0x7f7fffff;
  param_1[0x1c] = 0xff7fffff;
  param_1[0x1d] = 0xff7fffff;
  param_1[0x1e] = 0xff7fffff;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  *(undefined8 *)(param_1 + 0x25) = 0;
  param_1[0x27] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  *(undefined8 *)(param_1 + 0x31) = 0;
  param_1[0x33] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (DAT_01eb2844 != '\0') {
    pcVar6 = "decal";
    if ((*param_3 & 2) == 0) {
      pcVar6 = "normal";
    }
    pcVar7 = "transp";
    if ((*param_3 & 1) == 0) {
      pcVar7 = "opaque";
    }
    FUN_01677490(DAT_01eb2844,"entity 0x%p spawns (%s %s)",param_1,pcVar7,pcVar6);
    if (DAT_01eb2844 != '\0') {
      uVar1 = param_3[2];
      piVar8 = (int *)(uVar1 + 0xc);
      if (0xf < *(uint *)(uVar1 + 0x20)) {
        piVar8 = (int *)*piVar8;
      }
      FUN_01677490(DAT_01eb2844,"entity 0x%p key: type %d contentid \'%s\'",param_1,
                   *(undefined4 *)(uVar1 + 8),piVar8);
    }
  }
  piVar8 = (int *)(*(int *)(*(int *)(param_1[1] + 8) + 0x524) + 0x7c);
  *piVar8 = *piVar8 + 1;
  if ((param_3[2] != 0) && (*(int *)(param_3[2] + 4) != 4)) {
    param_1[0x34] = param_1[0x34] | 2;
  }
  if (param_3[4] != 0) {
    cVar2 = FUN_0078e3b0();
    if (cVar2 == '\0') {
      param_1[0x34] = param_1[0x34] | 4;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11596 ; VA 0x007b2440 ; FUN_007b2440 */

undefined4 * __thiscall FUN_007b2440(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 11597 ; VA 0x007b24a0 ; FUN_007b24a0 */

void __fastcall FUN_007b24a0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_007b2d40();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x24);
  }
  return;
}



/* FUNCTION 11598 ; VA 0x007b24d0 ; thunk_FUN_007b2d40 */

void __fastcall thunk_FUN_007b2d40(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x007b2d93. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11599 ; VA 0x007b24e0 ; FUN_007b24e0 */

void __fastcall FUN_007b24e0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_007b2d40();
        FUN_01674ea0(puVar6,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11600 ; VA 0x007b2570 ; FUN_007b2570 */

void __fastcall FUN_007b2570(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_007b2d40();
        FUN_01674ea0(puVar6,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11601 ; VA 0x007b2580 ; FUN_007b2580 */

void __fastcall FUN_007b2580(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_00786f80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11602 ; VA 0x007b25e0 ; FUN_007b25e0 */

void __fastcall FUN_007b25e0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x70) * 0x70;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11603 ; VA 0x007b2650 ; FUN_007b2650 */

void __fastcall FUN_007b2650(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_007b3200(*param_1,param_1[1]);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x28) * 0x28;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11604 ; VA 0x007b26f0 ; FUN_007b26f0 */

void __fastcall FUN_007b26f0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_00786f80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11605 ; VA 0x007b2700 ; thunk_FUN_01158110 */

int __fastcall thunk_FUN_01158110(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  *param_1 = RBX::GfxBinding::vftable;
  iVar4 = FUN_006378f0();
  piVar3 = (int *)param_1[2];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x01158149. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 11606 ; VA 0x007b2710 ; FUN_007b2710 */

void __fastcall FUN_007b2710(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0xb] = param_1[0xb] | 0x2000;
  *param_1 = RBX::Graphics::InstancedBinding2::vftable;
  if (param_1[0x10] == 0) {
    FUN_007c78a0(param_1,3);
  }
  if (DAT_01eb2844 != '\0') {
    FUN_01677490(DAT_01eb2844,"binding 0x%p (0x%p) dies",param_1,param_1[1],0);
  }
  piVar2 = (int *)(*(int *)(*(int *)(param_1[7] + 8) + 0x524) + 0x80);
  *piVar2 = *piVar2 + -1;
  iVar3 = param_1[0x13];
  if (iVar3 != 0) {
    uVar5 = param_1[0x15] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x13] = 0;
    param_1[0x14] = 0;
    param_1[0x15] = 0;
  }
  piVar2 = (int *)param_1[0x11];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01158110();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11607 ; VA 0x007b2820 ; FUN_007b2820 */

void __fastcall FUN_007b2820(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  undefined4 *puVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = param_1[0x1f];
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::InstancedCluster2::vftable;
  if (iVar2 != 0) {
    if (DAT_01eb2844 != '\0') {
      FUN_01677490(DAT_01eb2844,"cluster 0x%p still has %u entities",param_1,iVar2,0);
      iVar2 = param_1[0x1f];
    }
    if (iVar2 == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(param_1[0x22] + param_1[0x1e] * 4);
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      iVar2 = puVar6[8];
      piVar5 = *(int **)(iVar2 + 0xa0);
      uVar4 = (uint)((int)*(int **)(iVar2 + 0xa4) + (3 - (int)piVar5)) >> 2;
      if (*(int **)(iVar2 + 0xa4) < piVar5) {
        uVar4 = 0;
      }
      if (uVar4 != 0) {
        uVar7 = 0;
        do {
          puVar1 = (undefined4 *)*piVar5;
          puVar1[8] = 0;
          puVar1[9] = 0xffffffff;
          puVar1[10] = 0xffffffff;
          puVar1[0xb] = 0;
          FUN_011590c0();
          puVar1[0x14] = puVar1[0x13];
          if (DAT_01eb2844 != '\0') {
            FUN_01677490(DAT_01eb2844,"binding 0x%p purged (fl 0x%x)",puVar1,puVar1[0xb],0);
          }
          (**(code **)*puVar1)(1);
          uVar7 = uVar7 + 1;
          piVar5 = piVar5 + 1;
        } while (uVar7 != uVar4);
      }
      *(undefined4 *)(iVar2 + 0xa4) = *(undefined4 *)(iVar2 + 0xa0);
      *(undefined4 *)(iVar2 + 0xb0) = *(undefined4 *)(iVar2 + 0xac);
      *(undefined4 *)(iVar2 + 0xbc) = *(undefined4 *)(iVar2 + 0xb8);
      if (DAT_01eb2844 != '\0') {
        FUN_016774b0(DAT_01eb2844,"entity 0x%p purged.",iVar2);
      }
      if ((undefined4 *)puVar6[8] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)puVar6[8])(1);
      }
    }
    param_1[0xf] = param_1[0xe];
  }
  iVar2 = param_1[0x3a];
  if (iVar2 != 0) {
    uStack_8 = 0;
    FUN_016f32d1(iVar2,0xc,0x1c,FUN_0056d320);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar2,0x150);
  }
  param_1[0x26] = param_1[0x26] | 0x2000;
  piVar5 = (int *)(*(int *)(param_1[2] + 0x524) + 0x78);
  *piVar5 = *piVar5 + -1;
  if (DAT_01eb2844 != '\0') {
    FUN_016774b0(DAT_01eb2844,"cluster 0x%p dies",param_1);
  }
  FUN_007b2650();
  FUN_0073e270();
  FUN_00641040();
  iVar2 = param_1[0x2d];
  if (iVar2 != 0) {
    uVar4 = param_1[0x2f] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_007b2b39;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x2d] = 0;
    param_1[0x2e] = 0;
    param_1[0x2f] = 0;
  }
  iVar2 = param_1[0x2a];
  if (iVar2 != 0) {
    uVar4 = param_1[0x2c] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_007b2b39;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x2a] = 0;
    param_1[0x2b] = 0;
    param_1[0x2c] = 0;
  }
  iVar2 = param_1[0x27];
  if (iVar2 != 0) {
    uVar4 = param_1[0x29] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_007b2b39:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x27] = 0;
    param_1[0x28] = 0;
    param_1[0x29] = 0;
  }
  FUN_007b24e0();
  FUN_00841420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11608 ; VA 0x007b2b40 ; FUN_007b2b40 */

void __fastcall FUN_007b2b40(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::InstancedEntity2::vftable;
  if ((param_1[0x28] != param_1[0x29]) && (DAT_01eb2844 != '\0')) {
    FUN_016774b0(DAT_01eb2844,"WARN: deleting a non-empty entity with %u bindings, memory leak.",
                 (int)(param_1[0x29] - param_1[0x28]) >> 2);
  }
  if (DAT_01eb28b9 != '\0') {
    FUN_007b4d10(*(undefined4 *)(*(int *)(param_1[1] + 8) + 0x50c));
    FUN_007b4d10(*(undefined4 *)(*(int *)(param_1[1] + 8) + 0x50c));
  }
  if (DAT_01eb2844 != '\0') {
    FUN_016774b0(DAT_01eb2844,"entity 0x%p dies",param_1);
  }
  param_1[0x34] = param_1[0x34] | 0x2000;
  piVar1 = (int *)(*(int *)(*(int *)(param_1[1] + 8) + 0x524) + 0x7c);
  *piVar1 = *piVar1 + -1;
  uStack_8 = 0;
  FUN_01679490();
  iVar2 = param_1[0x35];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  FUN_007b2580();
  FUN_00612d60();
  FUN_007b25e0();
  iVar2 = param_1[0x28];
  if (iVar2 != 0) {
    uVar4 = param_1[0x2a] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_007b2d3a;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x28] = 0;
    param_1[0x29] = 0;
    param_1[0x2a] = 0;
  }
  FUN_007b2580();
  FUN_007b25e0();
  iVar2 = param_1[0x1f];
  if (iVar2 != 0) {
    uVar4 = param_1[0x21] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_007b2d3a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x1f] = 0;
    param_1[0x20] = 0;
    param_1[0x21] = 0;
  }
  FUN_007b2d40();
  FUN_00841390();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11609 ; VA 0x007b2d40 ; FUN_007b2d40 */

void __fastcall FUN_007b2d40(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x007b2d93. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11610 ; VA 0x007b2da0 ; FUN_007b2da0 */

void FUN_007b2da0(void)

{
  FUN_007b2650();
  FUN_0073e270();
  return;
}



/* FUNCTION 11611 ; VA 0x007b2dc0 ; FUN_007b2dc0 */

void * __fastcall FUN_007b2dc0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 11612 ; VA 0x007b2e20 ; FUN_007b2e20 */

int * __thiscall FUN_007b2e20(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined auStack_40 [24];
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar3 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2b90;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_007b4710(param_2);
  FUN_007afe30(&param_2,uStack_18,iVar3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_007b2440(iVar3);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar4 = (int *)FUN_01674e20(0x24);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  *piStack_1c = 0;
  piVar4[3] = 0;
  piVar4[4] = 0;
  piVar4[5] = 0;
  piVar4[6] = 0;
  piVar4[7] = 0;
  piVar4[8] = 0;
  piStack_24 = piVar4;
  FUN_007b2440(auStack_40);
  if (piVar4 + 8 != (int *)0x0) {
    piVar4[8] = 0;
  }
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_007b2d40();
  uVar1 = *(uint *)(param_1 + 8);
  uVar5 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005d6bb0(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_00780ee0(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    param_2 = (uint *)0x1;
    uVar6 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar5) {
      uVar6 = 1;
    }
    uVar5 = FUN_005d6bb0(uVar6 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar5 != *param_2) {
      FUN_00780ee0(uVar5);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar4 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar4 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar4 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar4[1] = uStack_18;
  uVar5 = *(uint *)(param_1 + 4);
  piVar4 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar5) * 4);
  if ((int *)*piVar4 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % uVar5) * 4) = piStack_24;
    }
    *piVar4 = (int)piVar7;
    *piStack_24 = *piVar7;
  }
  else {
    *piStack_24 = *(int *)*piVar4;
    piVar7 = (int *)*piVar4;
  }
  *piVar7 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 11613 ; VA 0x007b3030 ; FUN_007b3030 */

undefined4 * __thiscall FUN_007b3030(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  
  uVar2 = *param_1;
  if (param_3 != 0) {
    puVar3 = (undefined4 *)param_1[1];
    do {
      *param_2 = 0;
      param_2[1] = 0;
      if (puVar3[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_2 = *puVar3;
      param_2[1] = puVar3[1];
      param_2[2] = puVar3[2];
      param_2[3] = puVar3[3];
      param_2 = param_2 + 4;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_00786f80(param_2,param_2,uVar2);
  return param_2;
}



/* FUNCTION 11614 ; VA 0x007b30a0 ; FUN_007b30a0 */

undefined4 __thiscall FUN_007b30a0(undefined4 param_1,byte param_2)

{
  FUN_01158110();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 11615 ; VA 0x007b30d0 ; FUN_007b30d0 */

undefined4 __thiscall FUN_007b30d0(undefined4 param_1,byte param_2)

{
  FUN_01158110();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 11616 ; VA 0x007b3100 ; FUN_007b3100 */

undefined4 __thiscall FUN_007b3100(undefined4 param_1,byte param_2)

{
  FUN_007b2710();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 11617 ; VA 0x007b3130 ; FUN_007b3130 */

undefined4 __thiscall FUN_007b3130(undefined4 param_1,byte param_2)

{
  FUN_007b2820();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xec);
  }
  return param_1;
}



/* FUNCTION 11618 ; VA 0x007b3160 ; FUN_007b3160 */

undefined4 __thiscall FUN_007b3160(undefined4 param_1,byte param_2)

{
  FUN_007b2b40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  return param_1;
}



/* FUNCTION 11619 ; VA 0x007b3190 ; FUN_007b3190 */

uint __thiscall FUN_007b3190(int param_1,double param_2,double param_3)

{
  uint uVar1;
  int *piVar2;
  uint uVar3;
  double dVar4;
  
  if (*(uint *)(param_1 + 4) < 2) {
    return 0;
  }
  uVar1 = 0;
  uVar3 = *(uint *)(param_1 + 4) - 1;
  if (uVar3 != 0) {
    piVar2 = (int *)(param_1 + 8);
    do {
      dVar4 = ((double)*piVar2 + (double)(&DAT_018c0d90)[-(*piVar2 >> 0x1f)]) * param_3;
      if (param_2 < dVar4 * dVar4) {
        return uVar1;
      }
      uVar1 = uVar1 + 1;
      piVar2 = piVar2 + 1;
    } while (uVar1 < uVar3);
  }
  return uVar3;
}



/* FUNCTION 11620 ; VA 0x007b3200 ; FUN_007b3200 */

void FUN_007b3200(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 0x18);
      uStack_8 = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 8))();
          }
        }
      }
      param_1 = param_1 + 0x28;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11621 ; VA 0x007b3290 ; FUN_007b3290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_007b3290(uint param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  undefined auStack_144 [4];
  uint *puStack_140;
  int iStack_124;
  undefined uStack_120;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined uStack_104;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  uint uStack_c0;
  int *piStack_bc;
  uint uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  int *piStack_80;
  int *piStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  int *piStack_70;
  undefined4 uStack_6c;
  int *piStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  uint uStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int *piStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  int *piStack_34;
  uint uStack_30;
  int *piStack_2c;
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_1c;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2c30;
  pvStack_10 = ExceptionList;
  uStack_24 = param_1;
  uStack_1c = 0;
  uStack_14 = 0;
  iStack_28 = *(int *)(param_2 + 4);
  piVar7 = *(int **)(*(int *)(param_2 + 4) + 0x2c);
  if (piVar7 != (int *)0x0) {
    piVar8 = (int *)*piVar7;
    piVar7 = (int *)piVar7[1];
    piStack_34 = piVar8;
    piStack_44 = piVar7;
    ExceptionList = &pvStack_10;
    if (piVar8 != piVar7) {
      do {
        piStack_34 = piVar8;
        if ((*piVar8 == 0) ||
           (iVar5 = *(int *)(*piVar8 + 0xc), iVar2 = FUN_00cffc50(),
           (uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
          uVar6 = uStack_14 | 0x10;
          piStack_68 = (int *)0x0;
          puVar3 = &uStack_6c;
          piStack_20 = (int *)0x0;
        }
        else {
          piStack_70 = (int *)piVar8[1];
          piStack_20 = (int *)*piVar8;
          if (piStack_70 != (int *)0x0) {
            LOCK();
            piStack_70[1] = piStack_70[1] + 1;
            UNLOCK();
            piStack_70 = (int *)piVar8[1];
          }
          uVar6 = uStack_14 | 8;
          puVar3 = &uStack_74;
        }
        piVar8 = (int *)puVar3[1];
        piStack_80 = piStack_20;
        piStack_7c = piVar8;
        *puVar3 = 0;
        puVar3[1] = 0;
        piVar7 = piStack_68;
        uStack_14 = uVar6 | 0x20;
        uStack_1c = uVar6 | 0x20;
        if ((uVar6 & 0x10) != 0) {
          uStack_14 = uVar6 & 0xffffffef | 0x20;
          uStack_1c = uStack_14;
          if (piStack_68 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_68[1] + -1;
            piStack_68[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_68)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
        piVar7 = piStack_70;
        if ((uStack_14 & 8) != 0) {
          uStack_14 = uStack_14 & 0xfffffff7;
          uStack_1c = uStack_14;
          if (piStack_70 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_70[1] + -1;
            piStack_70[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_70)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
        piVar7 = piStack_20;
        if (piStack_20 != (int *)0x0) {
          uStack_110 = 0;
          uStack_10c = 0xf;
          uStack_120 = 0;
          uStack_f4 = 0;
          uStack_f0 = 0xf;
          uStack_104 = 0;
          uStack_8._0_1_ = 1;
          uStack_8._1_3_ = 0;
          FUN_0076f0a0(iStack_28,piStack_20);
          if (iStack_124 != 0) {
            puVar4 = (uint *)FUN_01674e20(0x60);
            puStack_78 = puVar4;
            if (puVar4 == (uint *)0x0) {
              puStack_18 = (uint *)0x0;
            }
            else {
              puVar4[1] = 0;
              puVar4[2] = 0;
              puVar4[3] = 0;
              puVar4[4] = 0;
              puVar4[5] = 0;
              puVar4[6] = 0xffffffff;
              puVar4[7] = uStack_24;
              *puVar4 = (uint)RBX::Graphics::InstancedBinding2::vftable;
              puVar4[8] = 0;
              puVar4[9] = 0xffffffff;
              puVar4[10] = 0xffffffff;
              puVar4[0xb] = *(uint *)(param_2 + 0x2c) & 0x100;
              puVar4[0xd] = 0;
              puVar4[0xe] = 0;
              puVar4[0xf] = 0;
              puVar4[0x10] = 0;
              puVar4[0x11] = 0;
              if (piVar8 != (int *)0x0) {
                LOCK();
                piVar8[1] = piVar8[1] + 1;
                UNLOCK();
              }
              puVar4[0x10] = (uint)piStack_20;
              puVar4[0x11] = (uint)piVar8;
              puVar4[0x12] = param_2;
              puVar4[0x13] = 0;
              puVar4[0x14] = 0;
              puVar4[0x15] = 0;
              puVar4[0x16] = 0;
              uStack_8._0_1_ = 5;
              if (DAT_01eb2844 != '\0') {
                FUN_016774b0(DAT_01eb2844,"binding (decal) 0x%p spawns",puVar4);
              }
              piVar7 = (int *)(*(int *)(*(int *)(uStack_24 + 8) + 0x524) + 0x80);
              *piVar7 = *piVar7 + 1;
              puStack_18 = puVar4;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            puVar3 = *(undefined4 **)(param_2 + 0x50);
            if (*(undefined4 **)(param_2 + 0x54) == puVar3) {
              FUN_006030d0(puVar3,&puStack_18);
            }
            else {
              *puVar3 = puStack_18;
              *(int *)(param_2 + 0x50) = *(int *)(param_2 + 0x50) + 4;
            }
            puVar4 = puStack_18;
            uStack_30 = FUN_007b3ea0(iStack_28,puStack_18[0x10],
                                     *(uint *)(param_2 + 0x2c) >> 8 & 0xffffff01);
            piStack_2c = (int *)0x102;
            piVar7 = (int *)0x102;
            if ((iStack_28 != 0) && (iVar5 = FUN_00b084e0(), piVar7 = piStack_2c, iVar5 == 0x630)) {
              piVar7 = (int *)0x902;
            }
            if ((uStack_30 & 0x10) == 0) {
              puStack_18 = (uint *)FUN_00761230(auStack_144,iStack_28,piStack_20,0,piVar7);
              uStack_14 = uStack_14 | 4;
              uStack_c0 = *puStack_18;
            }
            else {
              uStack_4c = 0;
              piStack_48 = (int *)0x0;
              uStack_a0 = 0;
              piStack_9c = (int *)0x0;
              uStack_98 = 0;
              uStack_94 = 0;
              uStack_90 = _DAT_018fac80;
              uStack_8c = _UNK_018fac84;
              uStack_88 = _UNK_018fac88;
              uStack_84 = _UNK_018fac8c;
              puStack_18 = &uStack_a0;
              uStack_14 = uStack_14 | 3;
              uStack_c0 = 0;
            }
            uStack_1c = uStack_c0;
            piStack_bc = (int *)puStack_18[1];
            *puStack_18 = 0;
            puStack_18[1] = 0;
            uStack_b8 = puStack_18[2];
            uStack_b0 = puStack_18[4];
            uStack_ac = puStack_18[5];
            uStack_a8 = puStack_18[6];
            uStack_a4 = puStack_18[7];
            uStack_b4 = puStack_18[3];
            uStack_8 = 8;
            uStack_40 = uStack_b4;
            piStack_2c = piStack_bc;
            if ((uStack_14 & 4) != 0) {
              uStack_14 = uStack_14 & 0xfffffffb;
              puStack_18 = puStack_140;
              if (puStack_140 != (uint *)0x0) {
                LOCK();
                uVar6 = puStack_140[1] - 1;
                puStack_140[1] = uVar6;
                UNLOCK();
                if (uVar6 == 0) {
                  (**(code **)*puStack_140)();
                  LOCK();
                  uVar6 = puStack_18[2] - 1;
                  puStack_18[2] = uVar6;
                  UNLOCK();
                  if (uVar6 == 0) {
                    (**(code **)(*puStack_18 + 4))();
                  }
                }
              }
            }
            if (((uStack_14 & 2) != 0) &&
               (uStack_14 = uStack_14 & 0xfffffffd, piStack_9c != (int *)0x0)) {
              LOCK();
              iVar5 = piStack_9c[1] + -1;
              piStack_9c[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_9c)();
                LOCK();
                iVar5 = piStack_9c[2] + -1;
                piStack_9c[2] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piStack_9c + 4))();
                }
              }
            }
            uStack_8._0_1_ = 10;
            if (((uStack_14 & 1) != 0) &&
               (uStack_14 = uStack_14 & 0xfffffffe, piStack_48 != (int *)0x0)) {
              LOCK();
              iVar5 = piStack_48[1] + -1;
              piStack_48[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_48)();
                LOCK();
                iVar5 = piStack_48[2] + -1;
                piStack_48[2] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piStack_48 + 4))();
                }
              }
            }
            FUN_0076dfa0(&uStack_3c,&iStack_124,piStack_20);
            uStack_64 = uStack_30;
            uStack_60 = uStack_40;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              piStack_38[1] = piStack_38[1] + 1;
              UNLOCK();
            }
            uStack_5c = uStack_3c;
            piStack_58 = piStack_38;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              piStack_2c[1] = piStack_2c[1] + 1;
              UNLOCK();
            }
            uStack_54 = uStack_1c;
            piStack_50 = piStack_2c;
            uStack_8._0_1_ = 0xc;
            FUN_007b4320(&uStack_64);
            FUN_007b3860(puVar4);
            FUN_007b2d40();
            piVar7 = piStack_38;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              iVar5 = piStack_38[1] + -1;
              piStack_38[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_38)();
                LOCK();
                piVar1 = piVar7 + 2;
                iVar5 = *piVar1 + -1;
                *piVar1 = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piVar7 + 4))();
                }
              }
            }
            piVar7 = piStack_2c;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar5 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_2c)();
                LOCK();
                piVar1 = piVar7 + 2;
                iVar5 = *piVar1 + -1;
                *piVar1 = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piVar7 + 4))();
                }
              }
            }
          }
          piVar7 = (int *)FUN_0076b160();
        }
        uStack_8 = 0xffffffff;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar1 = piVar8 + 1;
          iVar5 = *piVar1;
          piVar7 = (int *)*piVar1;
          *piVar1 = iVar5 + -1;
          UNLOCK();
          if (iVar5 + -1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            piVar1 = piVar8 + 2;
            iVar5 = *piVar1;
            piVar7 = (int *)*piVar1;
            *piVar1 = iVar5 + -1;
            UNLOCK();
            if (iVar5 + -1 == 0) {
              piVar7 = (int *)(**(code **)(*piVar8 + 4))();
            }
          }
        }
        piVar8 = piStack_34 + 2;
        piStack_34 = piVar8;
      } while (piVar8 != piStack_44);
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 11622 ; VA 0x007b3860 ; FUN_007b3860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007b3860(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined4 auStack_124 [28];
  undefined4 auStack_b4 [28];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  piVar10 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2c61;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  param_2[9] = *(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 2;
  param_2[8] = param_1;
  iStack_18 = param_1;
  if (param_2[0x10] == 0) {
    iVar5 = FUN_00d37670(param_2[1],0,param_2);
    piVar10[0xc] = iVar5;
  }
  if (DAT_01eb28b9 != '\0') {
    FUN_007b47a0(*(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 2);
  }
  piVar1 = *(int **)(param_1 + 0xa4);
  if (*(int **)(param_1 + 0xa8) == piVar1) {
    FUN_006030d0(piVar1,&param_2);
  }
  else {
    *piVar1 = (int)piVar10;
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 4;
  }
  FUN_0170d1f0(auStack_b4,0,0x70);
  puVar9 = *(undefined4 **)(param_1 + 0xb0);
  if (*(undefined4 **)(param_1 + 0xb4) == puVar9) {
    FUN_007afa90(puVar9,auStack_b4);
  }
  else {
    puVar8 = auStack_b4;
    for (iVar5 = 0x1c; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar9 = *puVar8;
      puVar8 = puVar8 + 1;
      puVar9 = puVar9 + 1;
    }
    *(int *)(param_1 + 0xb0) = *(int *)(param_1 + 0xb0) + 0x70;
    param_1 = iStack_18;
  }
  uVar3 = _UNK_018c4ebc;
  uVar2 = _UNK_018c4eb8;
  uVar7 = _UNK_018c4eb4;
  puVar9 = *(undefined4 **)(param_1 + 0xbc);
  uStack_44 = _DAT_018c4eb0;
  uStack_40 = _UNK_018c4eb4;
  uStack_3c = _UNK_018c4eb8;
  uStack_38 = _UNK_018c4ebc;
  uStack_34 = 0xff7fffff;
  uStack_30 = 0xff7fffff;
  if (*(undefined4 **)(param_1 + 0xc0) == puVar9) {
    FUN_00603350(puVar9,&uStack_44);
  }
  else {
    *puVar9 = _DAT_018c4eb0;
    puVar9[1] = uVar7;
    puVar9[2] = uVar2;
    puVar9[3] = uVar3;
    *(undefined8 *)(puVar9 + 4) = 0xff7fffffff7fffff;
    *(int *)(param_1 + 0xbc) = *(int *)(param_1 + 0xbc) + 0x18;
  }
  piVar10 = param_2;
  if (param_2[0x10] == 0) {
    iVar5 = param_2[1];
  }
  else {
    iVar5 = *(int *)(param_2[0x12] + 4);
  }
  if ((iVar5 == 0) || (cVar4 = FUN_00b06f40(), cVar4 != '\0')) {
    piVar10[10] = *(int *)(param_1 + 0x80) - *(int *)(param_1 + 0x7c) >> 2;
    if (DAT_01eb28b9 != '\0') {
      FUN_007b47a0(*(int *)(param_1 + 0x80) - *(int *)(param_1 + 0x7c) >> 2);
    }
    piVar1 = *(int **)(param_1 + 0x80);
    if (*(int **)(param_1 + 0x84) == piVar1) {
      FUN_006030d0(piVar1,&param_2);
    }
    else {
      *piVar1 = (int)piVar10;
      *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + 4;
    }
    FUN_0170d1f0(auStack_124,0,0x70);
    puVar9 = *(undefined4 **)(param_1 + 0x8c);
    if (*(undefined4 **)(param_1 + 0x90) == puVar9) {
      FUN_007afa90(puVar9,auStack_124);
    }
    else {
      puVar8 = auStack_124;
      for (iVar5 = 0x1c; iVar5 != 0; iVar5 = iVar5 + -1) {
        *puVar9 = *puVar8;
        puVar8 = puVar8 + 1;
        puVar9 = puVar9 + 1;
      }
      *(int *)(param_1 + 0x8c) = *(int *)(param_1 + 0x8c) + 0x70;
      param_1 = iStack_18;
    }
  }
  piVar10 = param_2;
  *(uint *)(param_1 + 0xd0) = *(uint *)(param_1 + 0xd0) | 1;
  if (param_2[0x10] == 0) {
    piStack_14 = (int *)param_2[1];
    iVar5 = piStack_14[3];
    iVar6 = FUN_00cfb1a0();
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
      iVar5 = piStack_14[3];
      iVar6 = FUN_00b50240();
      piVar1 = piStack_14;
      if ((uint)*(ushort *)(iVar6 + 0x1da) <
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
        iVar5 = FUN_00d012f0(piStack_14);
        if (iVar5 == 0) {
          uVar7 = (**(code **)(*piVar1 + 0xb4))();
          switch(uVar7) {
          case 0:
            iVar5 = 0x11;
            break;
          case 1:
            iVar5 = 0xb;
            break;
          case 2:
            iVar5 = 0xe;
            break;
          case 3:
            iVar5 = 0x17;
            break;
          case 4:
          case 9:
            iVar5 = 0x14;
            break;
          default:
            iVar5 = 0;
          }
        }
        else {
          iVar5 = 0x1b;
        }
      }
      else {
        iVar5 = 8;
      }
    }
    else {
      iVar5 = FUN_00b08820();
      iVar5 = (iVar5 != 0) + 4;
    }
    piVar10[0x16] = iVar5;
    piVar1 = (int *)piVar10[1];
    iVar5 = FUN_00d012f0(piVar1);
    if (iVar5 == 0) {
      iVar5 = (**(code **)(*piVar1 + 0xb4))();
      iVar5 = (uint)(iVar5 == 3) * 2 + 1;
    }
    else {
      iVar5 = FUN_007b4510(piVar1,0);
    }
    piVar10[0x17] = iVar5;
  }
  else {
    iVar5 = FUN_007b4510(*(undefined4 *)(param_2[0x12] + 4),param_2[0x10]);
    piVar10[0x16] = iVar5;
    piStack_14 = (int *)piVar10[0x10];
    piVar1 = *(int **)(piVar10[0x12] + 4);
    iVar5 = FUN_00d012f0(piVar1);
    if (iVar5 == 0) {
      iVar5 = (**(code **)(*piVar1 + 0xb4))();
      if (iVar5 == 3) {
        iVar5 = 3;
        if (piStack_14 != (int *)0x0) {
          iVar5 = 0;
        }
        piVar10[0x17] = iVar5;
      }
      else {
        piVar10[0x17] = (piStack_14 != (int *)0x0) + 1;
      }
    }
    else {
      iVar5 = FUN_007b4510(piVar1,piStack_14);
      piVar10[0x17] = iVar5;
    }
  }
  piStack_14 = piVar10;
  (*(code *)(&PTR_FUN_018fe530)[piVar10[0x16]])(&piStack_14,1);
  iVar6 = iStack_18;
  iVar5 = *(int *)(*(int *)(iStack_18 + 0x54) + 8);
  if ((((iVar5 == 0xf) || (iVar5 == 0x11)) && (piVar10[0x16] == 0x1b)) &&
     ((piVar10[0x10] == 0 && (piVar10 = param_2, *(int *)(*(int *)(iStack_18 + 0x54) + 4) != 4)))) {
    iStack_24 = iStack_18 + 0xd4;
    cVar4 = FUN_016793f0();
    piVar10 = param_2;
    if (cVar4 == '\0') {
      piStack_14 = (int *)(*(int *)(iVar6 + 0x54) + 0x184);
      iStack_8 = 0;
      uVar7 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      uStack_28 = uVar7;
      puStack_2c = (undefined4 *)FUN_01674e20(0x1c);
      if (puStack_2c == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
      }
      else {
        *puStack_2c = 0;
        puStack_2c[1] = 1;
        puStack_2c[2] = FUN_007b41a0;
        puStack_2c[3] = _guard_check_icall;
        puStack_2c[4] = 0;
        puStack_2c[5] = piStack_14;
        puStack_2c[6] = iStack_18;
        puVar9 = puStack_2c;
      }
      FUN_016797d0(puVar9);
      if (puVar9 != (undefined4 *)0x0) {
        LOCK();
        puVar9[1] = puVar9[1] + 1;
        UNLOCK();
      }
      uStack_20 = 1;
      iStack_8._0_1_ = 2;
      puStack_1c = puVar9;
      FUN_01675290(uVar7);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      cVar4 = FUN_01679300(&puStack_1c);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(&puStack_1c);
      }
      iStack_8 = 0xffffffff;
      FUN_0056e750();
      iVar6 = iStack_18;
      piVar10 = param_2;
    }
  }
  if (DAT_01eb2844 != '\0') {
    FUN_01677490(DAT_01eb2844,"entity 0x%p added 0x%p",iVar6,piVar10,0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11623 ; VA 0x007b3d80 ; FUN_007b3d80 */

float10 FUN_007b3d80(void)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_00b08910();
  return (float10)1 - fVar1;
}



/* FUNCTION 11624 ; VA 0x007b3d90 ; FUN_007b3d90 */

void __fastcall FUN_007b3d90(int param_1)

{
  int *piVar1;
  void **ppvVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2c78;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x7c) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5 = *(int **)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x78) * 4);
  }
  ppvVar2 = &pvStack_10;
  if (piVar5 == (int *)0x0) {
    *(uint *)(param_1 + 0x98) = *(uint *)(param_1 + 0x98) | 8;
    return;
  }
  do {
    ExceptionList = ppvVar2;
    FUN_007b2440(piVar5 + 2);
    piVar6 = *(int **)(piVar5[8] + 0xa0);
    piVar1 = *(int **)(piVar5[8] + 0xa4);
    uStack_8 = 0;
    if ((piVar6 != piVar1) && (*(int *)(*piVar6 + 0x40) == 0)) {
      uVar4 = 0;
      uVar3 = (uint)((int)piVar1 + (3 - (int)piVar6)) >> 2;
      if (piVar1 < piVar6) {
        uVar3 = 0;
      }
      if (uVar3 != 0) {
        do {
          FUN_007c8e00(*piVar6 + 4);
          uVar4 = uVar4 + 1;
          piVar6 = piVar6 + 1;
        } while (uVar4 != uVar3);
      }
    }
    uStack_8 = 0xffffffff;
    FUN_007b2d40();
    piVar5 = (int *)*piVar5;
    ppvVar2 = (void **)ExceptionList;
  } while (piVar5 != (int *)0x0);
  *(uint *)(param_1 + 0x98) = *(uint *)(param_1 + 0x98) | 8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11625 ; VA 0x007b3ea0 ; FUN_007b3ea0 */

uint FUN_007b3ea0(int param_1,int param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  float10 fVar9;
  byte bStack_5;
  
  fVar9 = (float10)FUN_00b08910();
  if ((DAT_018daf54 <= (float)fVar9) || (iVar1 = FUN_00b084e0(), iVar1 == 0x630)) {
    bVar5 = 1;
  }
  else {
    bVar5 = 0;
  }
  bStack_5 = 0;
  iVar1 = FUN_00b08820();
  if (iVar1 != 0) {
    if ((DAT_01d61b8c == '\0') || (*(int *)(iVar1 + 0xb4) != 1)) {
      if (*(int *)(iVar1 + 0xb4) == 1) {
        bVar5 = 1;
      }
    }
    else {
      bStack_5 = bVar5 ^ 1;
    }
  }
  iVar2 = FUN_00b084e0();
  iVar1 = *(int *)(param_1 + 0xc);
  uVar8 = 0;
  if (DAT_01d61b94 != '\0') {
    uVar8 = 0x20;
  }
  uVar6 = 0;
  iVar3 = FUN_00b50240();
  iVar4 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar4 = param_1;
  }
  if (iVar4 == 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar3 = FUN_00cfb1a0();
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      iVar4 = param_1;
    }
    iVar1 = 0;
    if (iVar4 != 0) {
      if ((DAT_01d6c814 == '\0') || (*(char *)(iVar4 + 0x192) == '\0')) {
        iVar1 = 0;
      }
      else {
        iVar1 = 1;
      }
      uVar8 = 0;
      if (*(int *)(iVar4 + 0x150) == 1) {
        uVar8 = 0x20;
      }
      uVar6 = 0;
      if (*(int *)(iVar4 + 0x150) == 2) {
        uVar6 = 0x40;
      }
    }
  }
  else {
    uVar8 = 0;
    if (*(int *)(iVar4 + 0x188) == 1) {
      uVar8 = 0x20;
    }
    iVar1 = 0;
  }
  uVar7 = (param_3 & 0xff) << 4;
  if (param_2 == 0) {
    if ((float)fVar9 < DAT_018ce2f8) {
      uVar7 = (uint)(iVar2 == 0x620) << 2 | (uint)bStack_5 << 3 | iVar1 << 7 | (uint)bVar5 | uVar7;
      if (DAT_01d71798 != '\0') {
        uVar7 = uVar7 | uVar6;
      }
      return uVar7 | uVar8;
    }
    return 0x10;
  }
  fVar9 = (float10)FUN_00d00910();
  if (DAT_018ce2f8 <= (float)fVar9) {
    if (DAT_01d71798 == '\0') {
      return uVar8 | 0x12;
    }
    return uVar6 | uVar8 | 0x12;
  }
  if ((bVar5 == 0) && (bStack_5 == 0)) {
    if (DAT_01d71798 != '\0') {
      uVar7 = uVar7 | uVar6;
    }
    return uVar7 | uVar8 | 2;
  }
  if (DAT_01d71798 != '\0') {
    uVar7 = uVar7 | uVar6;
  }
  return uVar7 | uVar8 | 3;
}



/* FUNCTION 11626 ; VA 0x007b40c0 ; FUN_007b40c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007b40c0(int *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  double dVar4;
  uint auStack_18 [5];
  
  auStack_18[0] = 0x7b40ce;
  iVar1 = (**(code **)(*param_1 + 0x40))();
  DAT_01eb28b8 = *(undefined *)(iVar1 + 5);
  DAT_01eb28b9 = *(char *)(iVar1 + 0xd);
  if (DAT_01eb28b9 == '\0') {
    DAT_01eb28b4 = 0x14;
  }
  else {
    DAT_01eb28b4 = *(uint *)(iVar1 + 0x30) / 0x70;
  }
  DAT_01eb28c0 = 5;
  if (DAT_01d71754 < 5) {
    DAT_01eb28c0 = DAT_01d71754;
  }
  auStack_18[2] = DAT_01d6c728;
  auStack_18[3] = DAT_01d6c730;
  auStack_18[1] = DAT_01d6c720;
  auStack_18[4] = DAT_01d6c738;
  _DAT_01eb28c4 = DAT_01d6c720;
  uVar3 = 1;
  if (DAT_01eb28c0 != 1 && DAT_01eb28c0 != 2) {
    do {
      uVar2 = auStack_18[uVar3 + 1];
      if (auStack_18[uVar3 + 1] < auStack_18[uVar3]) {
        uVar2 = auStack_18[uVar3];
      }
      *(uint *)(&DAT_01eb28c4 + uVar3 * 4) = uVar2;
      uVar3 = uVar3 + 1;
    } while (uVar3 < DAT_01eb28c0 - 1U);
  }
  auStack_18[0] = 0x7b4181;
  dVar4 = DAT_018fee58;
  FUN_01728120();
  DAT_01eb28bc = (float)dVar4;
  return;
}



/* FUNCTION 11627 ; VA 0x007b41a0 ; FUN_007b41a0 */

void FUN_007b41a0(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  if (DAT_01eb2844 != '\0') {
    iVar2 = *(int *)(param_1 + 0x18);
    FUN_01677490(DAT_01eb2844,
                 "Cluster 0x%p entity 0x%p: got mesh data, forcing update for all %u bindings",
                 *(undefined4 *)(iVar2 + 4),iVar2,
                 *(int *)(iVar2 + 0xa4) - *(int *)(iVar2 + 0xa0) >> 2);
  }
  iVar2 = *(int *)(param_1 + 0x18);
  uVar4 = 0;
  puVar3 = *(undefined4 **)(iVar2 + 0xa0);
  uVar1 = (uint)((int)*(undefined4 **)(iVar2 + 0xa4) + (3 - (int)puVar3)) >> 2;
  if (*(undefined4 **)(iVar2 + 0xa4) < puVar3) {
    uVar1 = 0;
  }
  if (uVar1 != 0) {
    do {
      FUN_007b50b0(*puVar3);
      uVar4 = uVar4 + 1;
      puVar3 = puVar3 + 1;
    } while (uVar4 != uVar1);
    iVar2 = *(int *)(param_1 + 0x18);
  }
  iVar2 = *(int *)(iVar2 + 4);
  uVar1 = *(uint *)(iVar2 + 0x98);
  if ((uVar1 & 3) == 0) {
    if (*(int *)(iVar2 + 0xcc) < 0) {
      *(uint *)(iVar2 + 0x98) = uVar1 | 2;
      return;
    }
    *(uint *)(iVar2 + 0x98) = uVar1 | 1;
    FUN_007c8c00(iVar2);
  }
  return;
}



/* FUNCTION 11628 ; VA 0x007b4260 ; FUN_007b4260 */

void __thiscall FUN_007b4260(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar3 = param_1[2];
  if (param_2[2] <= param_1[2]) {
    fVar3 = param_2[2];
  }
  fVar2 = param_1[1];
  if (param_2[1] <= param_1[1]) {
    fVar2 = param_2[1];
  }
  fVar1 = *param_1;
  if (*param_2 <= *param_1) {
    fVar1 = *param_2;
  }
  *(ulonglong *)param_1 = CONCAT44(fVar2,fVar1);
  param_1[2] = fVar3;
  fVar3 = param_1[5];
  if (param_1[5] <= param_2[5]) {
    fVar3 = param_2[5];
  }
  fVar2 = param_1[4];
  if (param_1[4] <= param_2[4]) {
    fVar2 = param_2[4];
  }
  fVar1 = param_1[3];
  if (param_1[3] <= param_2[3]) {
    fVar1 = param_2[3];
  }
  *(ulonglong *)(param_1 + 3) = CONCAT44(fVar2,fVar1);
  param_1[5] = fVar3;
  return;
}



/* FUNCTION 11629 ; VA 0x007b4300 ; FUN_007b4300 */

void FUN_007b4300(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 11630 ; VA 0x007b4320 ; FUN_007b4320 */

undefined4 __thiscall FUN_007b4320(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2ca2;
  pvStack_10 = ExceptionList;
  iVar3 = param_1 + 0x75 + (uint)*(byte *)(param_1 + 0x74);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_007b4710(param_2);
  FUN_007afe30(&param_2,uVar1,iVar2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return *(undefined4 *)(param_2 + 0x20);
  }
  param_2 = FUN_01674e20(0xd8);
  uStack_8 = 0;
  if (param_2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_007b2150(param_1,iVar2);
  }
  uStack_8 = 0xffffffff;
  iVar2 = FUN_007b2e20(iVar2);
  *(undefined4 *)(iVar2 + 0x18) = uVar1;
  FUN_00841620(uVar1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 11631 ; VA 0x007b4400 ; FUN_007b4400 */

void __thiscall FUN_007b4400(int param_1,undefined4 *param_2,int param_3,ushort param_4)

{
  int iVar1;
  int iVar2;
  ushort uVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  iVar1 = *(int *)(param_3 + 0xa8);
  iVar2 = FUN_00c157b0();
  fVar6 = *(float *)(param_1 + 0x20) * *(float *)(iVar2 + 0x2c);
  iVar1 = *(int *)(iVar1 + 0x1ac);
  fVar4 = *(float *)(param_1 + 0x18) * *(float *)(iVar2 + 0x24);
  fVar5 = *(float *)(param_1 + 0x1c) * *(float *)(iVar2 + 0x28);
  if (fVar6 < 0.0) {
    fVar6 = fVar6 - DAT_018fee54;
  }
  if (fVar5 < 0.0) {
    fVar5 = fVar5 - DAT_018fee54;
  }
  if (fVar4 < 0.0) {
    fVar4 = fVar4 - DAT_018fee54;
  }
  if (((*(float *)(param_1 + 0x24) <= *(float *)(iVar1 + 4)) ||
      (*(float *)(param_1 + 0x28) <= *(float *)(iVar1 + 8))) ||
     (*(float *)(param_1 + 0x2c) <= *(float *)(iVar1 + 0xc))) {
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  *param_2 = CONCAT22((short)(int)fVar5,(short)(int)fVar4);
  *(short *)(param_2 + 1) = (short)(int)fVar6;
  *(ushort *)((int)param_2 + 6) = uVar3 | param_4;
  return;
}



/* FUNCTION 11632 ; VA 0x007b4510 ; FUN_007b4510 */

char FUN_007b4510(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = param_1[3];
  iVar1 = FUN_00cfb1a0();
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da)) {
    if (param_2 == 0) {
      iVar3 = FUN_00b08820();
      return (iVar3 != 0) + '\x04';
    }
    iVar3 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_00cffd50();
    iVar1 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar1 = param_2;
    }
    return (iVar1 != 0) + '\x06';
  }
  iVar3 = param_1[3];
  iVar1 = FUN_00b50240();
  if ((uint)*(ushort *)(iVar1 + 0x1da) <
      (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) {
    iVar3 = FUN_00d012f0(param_1);
    if (iVar3 != 0) {
      return '\x1b';
    }
    uVar4 = (**(code **)(*param_1 + 0xb4))();
    switch(uVar4) {
    case 0:
      goto switchD_007b461b_caseD_0;
    case 1:
      if (param_2 == 0) {
        return '\v';
      }
      iVar3 = FUN_0073cf00();
      return (iVar3 != 0) + '\f';
    case 2:
      if (param_2 == 0) {
        return '\x0e';
      }
      iVar3 = FUN_0073cf00();
      return (iVar3 != 0) + '\x0f';
    case 3:
      if (param_2 != 0) {
        return '\0';
      }
      return '\x17';
    case 4:
    case 9:
      if (param_2 == 0) {
        return '\x14';
      }
      iVar3 = FUN_0073cf00();
      return (iVar3 != 0) + '\x15';
    default:
      return '\0';
    }
  }
  if (param_2 == 0) {
    return '\b';
  }
  iVar3 = *(int *)(param_2 + 0xc);
  iVar2 = FUN_00cffd50();
  iVar1 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar1 = param_2;
  }
  return (iVar1 != 0) + '\t';
switchD_007b461b_caseD_0:
  if (param_2 == 0) {
    return '\x11';
  }
  iVar3 = FUN_0073cf00();
  return (iVar3 != 0) + '\x12';
}



/* FUNCTION 11633 ; VA 0x007b46f0 ; FUN_007b46f0 */

float10 FUN_007b46f0(void)

{
  return (float10)DAT_018ce2f4;
}



/* FUNCTION 11634 ; VA 0x007b4700 ; FUN_007b4700 */

int __fastcall FUN_007b4700(int param_1)

{
  return param_1 + 0xd0;
}



/* FUNCTION 11635 ; VA 0x007b4710 ; FUN_007b4710 */

uint FUN_007b4710(int *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1 + 0x9e3779b9;
  uVar1 = uVar1 ^ param_1[1] + 0x2c15e7f9 + *param_1 * 0x40 + (uVar1 >> 2);
  uVar1 = uVar1 ^ (uVar1 >> 2) + uVar1 * 0x40 + param_1[2] + ((uint)param_1[2] >> 3) + 0x9e3779b9;
  return (uVar1 >> 2) + 0x9e3779b9 + uVar1 * 0x40 + param_1[4] + ((uint)param_1[4] >> 3) ^ uVar1;
}



/* FUNCTION 11636 ; VA 0x007b4780 ; FUN_007b4780 */

void __fastcall FUN_007b4780(int param_1)

{
  if (*(int *)(param_1 + 0x1c) != 0) {
    if (*(int *)(param_1 + 0x40) != 0) {
      param_1 = *(int *)(param_1 + 0x48);
    }
    FUN_007b4ee0(param_1);
  }
  return;
}



/* FUNCTION 11637 ; VA 0x007b47a0 ; FUN_007b47a0 */

void __thiscall FUN_007b47a0(int *param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2cb8;
  pvStack_10 = ExceptionList;
  param_2 = param_2 / DAT_01eb28b4;
  if ((uint)(param_1[1] - *param_1 >> 4) <= param_2) {
    uStack_24 = 0;
    piStack_20 = (int *)0x0;
    uStack_1c = 0;
    uStack_18 = 2;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    FUN_007afc70(param_2 + 1,param_1,&uStack_24);
    piVar3 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      param_1 = piStack_14;
      if (iVar2 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        param_1 = piStack_14;
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
          param_1 = piStack_14;
        }
      }
    }
  }
  *(undefined4 *)(*param_1 + 0xc + param_2 * 0x10) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11638 ; VA 0x007b4860 ; FUN_007b4860 */

void __thiscall FUN_007b4860(int *param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  
  if (DAT_01eb2844 != '\0') {
    FUN_016773b0(DAT_01eb2844,"binding 0x%p (0x%p) ancestor changed to %p, flags 0x%x",param_1,
                 param_1[1],*param_2,param_1[0xb],0);
  }
  if (param_1[0x10] == 0) {
    cVar2 = FUN_011584d0(param_1[1]);
    if (cVar2 != '\0') {
      iVar1 = param_1[1];
      uVar3 = FUN_00d00f70(iVar1);
      *(undefined4 *)(iVar1 + 0xb4) = uVar3;
      if (DAT_01eb28ba != '\0') {
        (**(code **)(*param_1 + 0x38))();
      }
      return;
    }
  }
  (**(code **)(*param_1 + 4))();
  return;
}



/* FUNCTION 11639 ; VA 0x007b48e0 ; FUN_007b48e0 */

void __fastcall FUN_007b48e0(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x007b48e2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 8))();
  return;
}



/* FUNCTION 11640 ; VA 0x007b48f0 ; FUN_007b48f0 */

void __fastcall FUN_007b48f0(int *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if ((param_1[0x10] == 0) && ((DAT_01d6c85c != '\0' || ((*(byte *)(param_1[1] + 0xb4) & 2) != 0))))
  {
    ExceptionList = &pvStack_10;
    if (DAT_01eb2844 != '\0') {
      ExceptionList = &pvStack_10;
      puVar1 = (undefined4 *)FUN_008a2380(auStack_28);
      uStack_8 = 0;
      if (0xf < (uint)puVar1[5]) {
        puVar1 = (undefined4 *)*puVar1;
      }
      FUN_01677490(DAT_01eb2844,
                   "binding 0x%p (0x%p) clustering condition changed, tossing out. [%s]",param_1,
                   param_1[1],puVar1);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_14) {
        uVar3 = uStack_14 + 1;
        uVar2 = auStack_28[0];
        if (0xfff < uVar3) {
          uVar2 = *(uint *)(auStack_28[0] - 4);
          uVar3 = uStack_14 + 0x24;
          if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar2,uVar3);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
    }
    param_1[0xb] = param_1[0xb] | 0x10;
    (**(code **)(*param_1 + 4))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11641 ; VA 0x007b49e0 ; FUN_007b49e0 */

void __fastcall FUN_007b49e0(int param_1)

{
  int iVar1;
  uint uVar2;
  
  FUN_007b50b0(param_1);
  iVar1 = *(int *)(param_1 + 0x1c);
  uVar2 = *(uint *)(iVar1 + 0x98);
  if ((uVar2 & 3) == 0) {
    if (*(int *)(iVar1 + 0xcc) < 0) {
      *(uint *)(iVar1 + 0x98) = uVar2 | 2;
      return;
    }
    *(uint *)(iVar1 + 0x98) = uVar2 | 1;
    FUN_007c8c00(iVar1);
  }
  return;
}



/* FUNCTION 11642 ; VA 0x007b4a30 ; FUN_007b4a30 */

void __fastcall FUN_007b4a30(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  short *psVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  undefined4 auStack_c [2];
  
  if (DAT_01d61bb4 == '\0') {
    iVar1 = *(int *)(param_1 + 0x1c);
    psVar5 = (short *)FUN_007b4400(auStack_c,*(undefined4 *)(param_1 + 4),0);
    if ((((*psVar5 == *(short *)(iVar1 + 0x90)) && (psVar5[1] == *(short *)(iVar1 + 0x92))) &&
        (psVar5[2] == *(short *)(iVar1 + 0x94))) && (psVar5[3] == *(short *)(iVar1 + 0x96)))
    goto LAB_007b4b46;
  }
  else {
    iVar4 = FUN_00c157b0();
    iVar1 = *(int *)(param_1 + 0x1c);
    iVar2 = *(int *)(iVar1 + 0x8c);
    fVar8 = *(float *)(iVar2 + 0x20) * *(float *)(iVar4 + 0x2c);
    fVar6 = *(float *)(iVar2 + 0x18) * *(float *)(iVar4 + 0x24);
    fVar7 = *(float *)(iVar2 + 0x1c) * *(float *)(iVar4 + 0x28);
    if (fVar8 < 0.0) {
      fVar8 = fVar8 - DAT_018fee54;
    }
    if (fVar7 < 0.0) {
      fVar7 = fVar7 - DAT_018fee54;
    }
    if (fVar6 < 0.0) {
      fVar6 = fVar6 - DAT_018fee54;
    }
    auStack_c[0] = CONCAT22((short)(int)fVar7,(short)(int)fVar6);
    if ((((short)(int)fVar6 == *(short *)(iVar1 + 0x90)) &&
        ((short)(int)fVar7 == *(short *)(iVar1 + 0x92))) &&
       (((short)(int)fVar8 == *(short *)(iVar1 + 0x94) &&
        (((ushort)(*(uint *)(param_1 + 0x2c) >> 9) & 1) == *(ushort *)(iVar1 + 0x96)))))
    goto LAB_007b4b46;
  }
  FUN_007b4e50(param_1);
LAB_007b4b46:
  FUN_007b5170(param_1);
  iVar1 = *(int *)(param_1 + 0x1c);
  uVar3 = *(uint *)(iVar1 + 0x98);
  if ((uVar3 & 3) == 0) {
    if (*(int *)(iVar1 + 0xcc) < 0) {
      *(uint *)(iVar1 + 0x98) = uVar3 | 2;
      return;
    }
    *(uint *)(iVar1 + 0x98) = uVar3 | 1;
    FUN_007c8c00(iVar1);
  }
  return;
}



/* FUNCTION 11643 ; VA 0x007b4ba0 ; FUN_007b4ba0 */

void __fastcall FUN_007b4ba0(int *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  
  if (DAT_01eb28ba != '\0') {
    iVar2 = FUN_00b65f00(param_1[1]);
    if ((iVar2 != 0) && (*(char *)(iVar2 + 0x140) == '\0')) {
      cVar1 = FUN_00b66010();
      if (cVar1 != '\0') {
        uVar3 = 0x100;
        goto LAB_007b4bd8;
      }
    }
  }
  uVar3 = 0;
LAB_007b4bd8:
  if ((param_1[0xb] & 0x100U) != uVar3) {
    param_1[0xb] = param_1[0xb] ^ 0x100;
                    /* WARNING: Could not recover jumptable at 0x007b4bf4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 8))();
    return;
  }
  return;
}



/* FUNCTION 11644 ; VA 0x007b4c00 ; FUN_007b4c00 */

void __fastcall FUN_007b4c00(int param_1)

{
  int iVar1;
  uint uVar2;
  
  FUN_007b4ee0(param_1);
  iVar1 = *(int *)(param_1 + 0x1c);
  uVar2 = *(uint *)(iVar1 + 0x98);
  if ((uVar2 & 3) == 0) {
    if (*(int *)(iVar1 + 0xcc) < 0) {
      *(uint *)(iVar1 + 0x98) = uVar2 | 2;
      return;
    }
    *(uint *)(iVar1 + 0x98) = uVar2 | 1;
    FUN_007c8c00(iVar1);
  }
  return;
}



/* FUNCTION 11645 ; VA 0x007b4c50 ; FUN_007b4c50 */

void __thiscall FUN_007b4c50(undefined4 param_1,char param_2)

{
  char *pcVar1;
  
  if (param_2 == '\0') {
    FUN_007c7840(param_1,3);
  }
  else {
    FUN_007c7a50(param_1,3);
  }
  if (DAT_01eb2844 != '\0') {
    pcVar1 = "sleeping";
    if (param_2 == '\0') {
      pcVar1 = "awake";
    }
    FUN_01677490(DAT_01eb2844,"binding 0x%p is %s",param_1,pcVar1,0);
  }
  return;
}



/* FUNCTION 11646 ; VA 0x007b4cb0 ; FUN_007b4cb0 */

void __fastcall FUN_007b4cb0(int *param_1)

{
  (**(code **)(*param_1 + 8))();
  return;
}



/* FUNCTION 11647 ; VA 0x007b4cc0 ; FUN_007b4cc0 */

void __fastcall FUN_007b4cc0(int param_1)

{
  int iVar1;
  uint uVar2;
  
  FUN_007b50b0(param_1);
  iVar1 = *(int *)(param_1 + 0x1c);
  uVar2 = *(uint *)(iVar1 + 0x98);
  if ((uVar2 & 3) == 0) {
    if (*(int *)(iVar1 + 0xcc) < 0) {
      *(uint *)(iVar1 + 0x98) = uVar2 | 2;
      return;
    }
    *(uint *)(iVar1 + 0x98) = uVar2 | 1;
    FUN_007c8c00(iVar1);
  }
  return;
}



/* FUNCTION 11648 ; VA 0x007b4d10 ; FUN_007b4d10 */

void __fastcall FUN_007b4d10(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)param_1[1];
  if (piVar1 != piVar2) {
    do {
      if (*piVar1 != 0) {
        FUN_007d6460(piVar1);
      }
      piVar1 = piVar1 + 4;
    } while (piVar1 != piVar2);
    piVar2 = (int *)param_1[1];
    piVar1 = (int *)*param_1;
  }
  FUN_00786f80(piVar1,piVar2,param_1);
  param_1[1] = *param_1;
  return;
}



/* FUNCTION 11649 ; VA 0x007b4d60 ; FUN_007b4d60 */

void __thiscall FUN_007b4d60(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 4);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x18;
    return;
  }
  FUN_006c6730(puVar1,param_2);
  return;
}



/* FUNCTION 11650 ; VA 0x007b4da0 ; FUN_007b4da0 */

void __thiscall FUN_007b4da0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  if (DAT_01eb2844 != '\0') {
    FUN_01677490(DAT_01eb2844,"cluster 0x%p new part (0x%p)",param_1,*param_2,0);
  }
  puVar2 = *(undefined4 **)(param_1 + 0xc4);
  if (*(undefined4 **)(param_1 + 200) == puVar2) {
    FUN_005c1970(puVar2,param_2);
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 8;
  }
  uVar3 = *(uint *)(param_1 + 0x98);
  if ((uVar3 & 3) == 0) {
    if (*(int *)(param_1 + 0xcc) < 0) {
      *(uint *)(param_1 + 0x98) = uVar3 | 2;
      return;
    }
    *(uint *)(param_1 + 0x98) = uVar3 | 1;
    FUN_007c8c00(param_1);
  }
  return;
}



/* FUNCTION 11651 ; VA 0x007b4da8 ; FUN_007b4da8 */

void __fastcall FUN_007b4da8(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  char in_AL;
  int unaff_EBP;
  
  puVar2 = *(undefined4 **)(unaff_EBP + 8);
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"cluster 0x%p new part (0x%p)",param_1,*puVar2,0);
  }
  puVar3 = *(undefined4 **)(param_1 + 0xc4);
  if (*(undefined4 **)(param_1 + 200) == puVar3) {
    FUN_005c1970(puVar3,puVar2);
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    if (puVar2[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar3 = *puVar2;
    puVar3[1] = puVar2[1];
    *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 8;
  }
  uVar4 = *(uint *)(param_1 + 0x98);
  if ((uVar4 & 3) == 0) {
    if (*(int *)(param_1 + 0xcc) < 0) {
      *(uint *)(param_1 + 0x98) = uVar4 | 2;
      return;
    }
    *(uint *)(param_1 + 0x98) = uVar4 | 1;
    FUN_007c8c00(param_1);
  }
  return;
}



/* FUNCTION 11652 ; VA 0x007b4e50 ; FUN_007b4e50 */

void __thiscall FUN_007b4e50(int param_1,int param_2)

{
  uint uVar1;
  
  if ((*(uint *)(param_2 + 0x2c) & 0xe) == 0) {
    *(uint *)(param_2 + 0x2c) = *(uint *)(param_2 + 0x2c) | 2;
    FUN_007c8c30((undefined4 *)(param_2 + 4));
    if (DAT_01eb2844 != '\0') {
      FUN_01677490(DAT_01eb2844,"cluster 0x%p evicted 0x%p (0x%p)",param_1,param_2,
                   *(undefined4 *)(param_2 + 4));
    }
    uVar1 = *(uint *)(param_1 + 0x98);
    if ((uVar1 & 3) == 0) {
      if (*(int *)(param_1 + 0xcc) < 0) {
        *(uint *)(param_1 + 0x98) = uVar1 | 2;
        return;
      }
      *(uint *)(param_1 + 0x98) = uVar1 | 1;
      FUN_007c8c00(param_1);
    }
  }
  return;
}



/* FUNCTION 11653 ; VA 0x007b4ee0 ; FUN_007b4ee0 */

void __thiscall FUN_007b4ee0(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  
  if ((*(uint *)(param_2 + 0x2c) & 1) == 0) {
    *(uint *)(param_2 + 0x2c) = *(uint *)(param_2 + 0x2c) | 1;
    piVar1 = *(int **)(param_1 + 0xa0);
    if (*(int **)(param_1 + 0xa4) == piVar1) {
      FUN_006030d0(piVar1,&param_2);
    }
    else {
      *piVar1 = param_2;
      *(int *)(param_1 + 0xa0) = *(int *)(param_1 + 0xa0) + 4;
    }
    iVar3 = param_2;
    uVar2 = *(uint *)(param_1 + 0x98);
    if ((uVar2 & 3) == 0) {
      if (*(int *)(param_1 + 0xcc) < 0) {
        *(uint *)(param_1 + 0x98) = uVar2 | 2;
      }
      else {
        *(uint *)(param_1 + 0x98) = uVar2 | 1;
        FUN_007c8c00(param_1);
      }
    }
    if (DAT_01eb2844 != '\0') {
      FUN_01677490(DAT_01eb2844,"cluster 0x%p binding 0x%p (0x%p) invalidated",param_1,iVar3,
                   *(undefined4 *)(iVar3 + 4));
    }
  }
  return;
}



/* FUNCTION 11654 ; VA 0x007b4f80 ; FUN_007b4f80 */

void __thiscall FUN_007b4f80(int param_1,int param_2)

{
  uint uVar1;
  int *piVar2;
  
  uVar1 = *(uint *)(param_2 + 0x2c);
  if ((uVar1 & 10) != 0) {
    *(uint *)(param_2 + 0x2c) = uVar1 | 0x20;
    return;
  }
  if ((uVar1 & 4) == 0) {
    *(uint *)(param_2 + 0x2c) = uVar1 | 4;
    piVar2 = *(int **)(param_1 + 0xac);
    if (*(int **)(param_1 + 0xb0) == piVar2) {
      FUN_006030d0(piVar2,&param_2);
    }
    else {
      *piVar2 = param_2;
      *(int *)(param_1 + 0xac) = *(int *)(param_1 + 0xac) + 4;
    }
    uVar1 = *(uint *)(param_1 + 0x98);
    if ((uVar1 & 3) == 0) {
      if (*(int *)(param_1 + 0xcc) < 0) {
        *(uint *)(param_1 + 0x98) = uVar1 | 2;
        return;
      }
      *(uint *)(param_1 + 0x98) = uVar1 | 1;
      FUN_007c8c00(param_1);
    }
  }
  return;
}



/* FUNCTION 11655 ; VA 0x007b5010 ; FUN_007b5010 */

void __thiscall FUN_007b5010(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  
  iVar1 = *(int *)(*param_2 + 0xb0);
  param_2 = (int *)iVar1;
  if (DAT_01eb2844 != '\0') {
    FUN_01677490(DAT_01eb2844,"cluster 0x%p incoming transfer 0x%p (0x%p)",param_1,iVar1,
                 *(undefined4 *)(iVar1 + 4));
  }
  *(uint *)(iVar1 + 0x2c) = *(uint *)(iVar1 + 0x2c) & 0xfffffffd | 8;
  piVar2 = *(int **)(param_1 + 0xb8);
  if (*(int **)(param_1 + 0xbc) == piVar2) {
    FUN_006030d0(piVar2,&param_2);
  }
  else {
    *piVar2 = iVar1;
    *(int *)(param_1 + 0xb8) = *(int *)(param_1 + 0xb8) + 4;
  }
  uVar3 = *(uint *)(param_1 + 0x98);
  if ((uVar3 & 3) == 0) {
    if (*(int *)(param_1 + 0xcc) < 0) {
      *(uint *)(param_1 + 0x98) = uVar3 | 2;
      return;
    }
    *(uint *)(param_1 + 0x98) = uVar3 | 1;
    FUN_007c8c00(param_1);
  }
  return;
}



/* FUNCTION 11656 ; VA 0x007b50b0 ; FUN_007b50b0 */

void __thiscall FUN_007b50b0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  
  iVar2 = param_2;
  if ((*(uint *)(param_2 + 0x2c) & 0x40) == 0) {
    *(uint *)(param_2 + 0x2c) = *(uint *)(param_2 + 0x2c) | 0xc0;
    iVar1 = *(int *)(param_1 + 0xe8) + *(int *)(param_2 + 0x58) * 0xc;
    piVar3 = *(int **)(iVar1 + 4);
    if (*(int **)(iVar1 + 8) == piVar3) {
      FUN_006030d0(piVar3,&param_2);
    }
    else {
      *piVar3 = param_2;
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 4;
    }
    piVar3 = *(int **)(iVar2 + 0x50);
    piVar6 = *(int **)(iVar2 + 0x4c);
    uVar5 = 0;
    uVar4 = (uint)((int)piVar3 + (3 - (int)piVar6)) >> 2;
    if (piVar3 < piVar6) {
      uVar4 = 0;
    }
    if (uVar4 != 0) {
      do {
        param_2 = *piVar6;
        iVar2 = *(int *)(param_1 + 0xe8) + *(int *)(param_2 + 0x58) * 0xc;
        piVar3 = *(int **)(iVar2 + 4);
        if (*(int **)(iVar2 + 8) == piVar3) {
          FUN_006030d0(piVar3,&param_2);
        }
        else {
          *piVar3 = param_2;
          *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
        }
        uVar5 = uVar5 + 1;
        piVar6 = piVar6 + 1;
      } while (uVar5 != uVar4);
    }
  }
  return;
}



/* FUNCTION 11657 ; VA 0x007b5170 ; FUN_007b5170 */

void __thiscall FUN_007b5170(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  
  iVar2 = param_2;
  if (-1 < (char)*(uint *)(param_2 + 0x2c)) {
    *(uint *)(param_2 + 0x2c) = *(uint *)(param_2 + 0x2c) | 0x80;
    iVar1 = *(int *)(param_1 + 0xe8) + *(int *)(param_2 + 0x5c) * 0xc;
    piVar3 = *(int **)(iVar1 + 4);
    if (*(int **)(iVar1 + 8) == piVar3) {
      FUN_006030d0(piVar3,&param_2);
    }
    else {
      *piVar3 = param_2;
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 4;
    }
    piVar3 = *(int **)(iVar2 + 0x50);
    piVar6 = *(int **)(iVar2 + 0x4c);
    uVar5 = 0;
    uVar4 = (uint)((int)piVar3 + (3 - (int)piVar6)) >> 2;
    if (piVar3 < piVar6) {
      uVar4 = 0;
    }
    if (uVar4 != 0) {
      do {
        param_2 = *piVar6;
        iVar2 = *(int *)(param_1 + 0xe8) + *(int *)(param_2 + 0x5c) * 0xc;
        piVar3 = *(int **)(iVar2 + 4);
        if (*(int **)(iVar2 + 8) == piVar3) {
          FUN_006030d0(piVar3,&param_2);
        }
        else {
          *piVar3 = param_2;
          *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
        }
        uVar5 = uVar5 + 1;
        piVar6 = piVar6 + 1;
      } while (uVar5 != uVar4);
    }
  }
  return;
}



/* FUNCTION 11658 ; VA 0x007b5230 ; FUN_007b5230 */

void __thiscall FUN_007b5230(int param_1,int param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 auStack_88 [28];
  uint uStack_18;
  int iStack_14;
  
  iStack_14 = param_1;
  uStack_18 = *(uint *)(param_2 + 0x24);
  if (DAT_01eb28b9 != '\0') {
    FUN_007b47a0(*(uint *)(param_2 + 0x24));
  }
  *(undefined4 *)(param_2 + 0x24) = 0xffffffff;
  *(undefined4 *)(param_2 + 0x20) = 0;
  if ((*(int *)(param_2 + 0x40) == 0) && (-1 < *(int *)(param_2 + 0x30))) {
    iVar6 = FUN_00d38e30(*(int *)(param_2 + 0x30));
    if (iVar6 != 0) {
      *(undefined4 *)(iVar6 + 0x30) = *(undefined4 *)(param_2 + 0x30);
    }
  }
  uVar5 = uStack_18;
  if (uStack_18 < (*(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 2) - 1U) {
    iVar6 = *(int *)(param_1 + 0xbc);
    uVar2 = *(undefined4 *)(iVar6 + -0x14);
    uVar3 = *(undefined4 *)(iVar6 + -0x10);
    uVar4 = *(undefined4 *)(iVar6 + -0xc);
    uVar1 = *(undefined8 *)(iVar6 + -8);
    iVar7 = *(int *)(param_1 + 0xb8);
    puVar8 = (undefined4 *)(iVar7 + uStack_18 * 0x18);
    *puVar8 = *(undefined4 *)(iVar6 + -0x18);
    puVar8[1] = uVar2;
    puVar8[2] = uVar3;
    puVar8[3] = uVar4;
    *(undefined8 *)(iVar7 + 0x10 + uStack_18 * 0x18) = uVar1;
    iVar6 = uStack_18 * 0x70;
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0xb0) + -0x70);
    puVar9 = auStack_88;
    for (iVar7 = 0x1c; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar9 = *puVar8;
      puVar8 = puVar8 + 1;
      puVar9 = puVar9 + 1;
    }
    puVar8 = auStack_88;
    puVar9 = (undefined4 *)(*(int *)(iStack_14 + 0xac) + iVar6);
    for (iVar7 = 0x1c; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar9 = *puVar8;
      puVar8 = puVar8 + 1;
      puVar9 = puVar9 + 1;
    }
    *(undefined4 *)(*(int *)(iStack_14 + 0xa0) + uVar5 * 4) =
         *(undefined4 *)(*(int *)(iStack_14 + 0xa4) + -4);
    *(uint *)(*(int *)(*(int *)(iStack_14 + 0xa0) + uVar5 * 4) + 0x24) = uVar5;
    param_1 = iStack_14;
  }
  *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + -4;
  *(int *)(param_1 + 0xb0) = *(int *)(param_1 + 0xb0) + -0x70;
  *(int *)(param_1 + 0xbc) = *(int *)(param_1 + 0xbc) + -0x18;
  if (DAT_01eb28b9 != '\0') {
    FUN_007b47a0(*(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 2);
  }
  uStack_18 = *(uint *)(param_2 + 0x28);
  if (uStack_18 != 0xffffffff) {
    if (DAT_01eb28b9 != '\0') {
      FUN_007b47a0(uStack_18);
    }
    uVar5 = uStack_18;
    *(undefined4 *)(param_2 + 0x28) = 0xffffffff;
    if (uStack_18 < (*(int *)(param_1 + 0x80) - *(int *)(param_1 + 0x7c) >> 2) - 1U) {
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x8c) + -0x70);
      puVar9 = auStack_88;
      for (iVar6 = 0x1c; iVar6 != 0; iVar6 = iVar6 + -1) {
        *puVar9 = *puVar8;
        puVar8 = puVar8 + 1;
        puVar9 = puVar9 + 1;
      }
      puVar8 = auStack_88;
      puVar9 = (undefined4 *)(uVar5 * 0x70 + *(int *)(iStack_14 + 0x88));
      for (iVar6 = 0x1c; iVar6 != 0; iVar6 = iVar6 + -1) {
        *puVar9 = *puVar8;
        puVar8 = puVar8 + 1;
        puVar9 = puVar9 + 1;
      }
      *(undefined4 *)(*(int *)(iStack_14 + 0x7c) + uVar5 * 4) =
           *(undefined4 *)(*(int *)(iStack_14 + 0x80) + -4);
      *(uint *)(*(int *)(*(int *)(iStack_14 + 0x7c) + uVar5 * 4) + 0x28) = uVar5;
      param_1 = iStack_14;
    }
    *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + -4;
    *(int *)(param_1 + 0x8c) = *(int *)(param_1 + 0x8c) + -0x70;
    if (DAT_01eb28b9 != '\0') {
      FUN_007b47a0(*(int *)(param_1 + 0x80) - *(int *)(param_1 + 0x7c) >> 2);
    }
  }
  *(uint *)(param_1 + 0xd0) = *(uint *)(param_1 + 0xd0) | 1;
  if (DAT_01eb2844 != '\0') {
    FUN_01677490(DAT_01eb2844,"entity 0x%p removed 0x%p",param_1,param_2,0);
  }
  return;
}



/* FUNCTION 11659 ; VA 0x007b5450 ; FUN_007b5450 */

void FUN_007b5450(int *param_1,int *param_2,int param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  bool bVar3;
  uint *puVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  uint unaff_ESI;
  uint uVar9;
  int iVar10;
  undefined auStack_1c040 [114688];
  undefined8 uStack_40;
  int *piStack_38;
  undefined8 uStack_34;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  FUN_016f40d0();
  uStack_2c = DAT_01eb28b4;
  if (0x400 < DAT_01eb28b4) {
    uStack_2c = 0x400;
  }
  uVar7 = 0;
  if ((*(int *)(param_2[1] + 4) == 4) || (*(int *)(param_2[1] + 4) == 5)) {
    bVar3 = true;
  }
  else {
    bVar3 = false;
  }
  if (param_3 != 0) {
    piVar1 = param_2 + 2;
    do {
      iVar5 = *param_2;
      iVar10 = 0x94;
      if (!bVar3) {
        iVar10 = 0xc4;
      }
      piStack_38 = (int *)(iVar10 + iVar5);
      if (bVar3) {
        iStack_14 = *(int *)(iVar5 + 0x88);
        iVar5 = *(int *)(iVar5 + 0x8c) - *(int *)(iVar5 + 0x88);
      }
      else {
        iStack_14 = *(int *)(iVar5 + 0xac);
        iVar5 = *(int *)(iVar5 + 0xb0) - *(int *)(iVar5 + 0xac);
      }
      iVar5 = iVar5 / 0x70;
      param_4[1] = param_4[1] + *(int *)(*piVar1 + 0x14) * iVar5;
      if (DAT_01eb28b9 == '\0') {
        uStack_40 = 0;
        puVar4 = (uint *)&uStack_40;
      }
      else {
        piVar6 = (int *)*piStack_38;
        uStack_34 = 0;
        if (piVar6 != (int *)piStack_38[1]) {
          uStack_34._4_4_ = 0;
          uStack_34._0_4_ = 0;
          do {
            iVar10 = *piVar6;
            uStack_34._4_4_ = uStack_34._4_4_ + piVar6[2];
            piVar6 = piVar6 + 4;
            uStack_34._0_4_ = (uint)uStack_34 + (iVar10 != 0);
          } while (piVar6 != (int *)piStack_38[1]);
          uVar7 = unaff_ESI;
        }
        puVar4 = (uint *)&uStack_34;
      }
      uStack_20 = *puVar4;
      puStack_1c = (undefined *)puVar4[1];
      iStack_28 = iVar5;
      iStack_24 = iVar5;
      if (uStack_20 != 0) {
        if (uVar7 != 0) {
          puStack_18 = auStack_1c040;
          puStack_1c = (undefined *)0x1;
          uStack_20 = 0x7b5595;
          iStack_14 = uVar7 * 0x70;
          (**(code **)(*param_1 + 0x30))();
          puVar2 = (undefined4 *)*piVar1;
          iStack_24 = puVar2[5];
          iStack_28 = puVar2[4];
          uStack_2c = puVar2[3];
          uStack_34 = CONCAT44(puVar2[2],*puVar2);
          piStack_38 = (int *)0x7b55b6;
          uStack_20 = uVar7;
          (**(code **)(*param_1 + 0x40))();
          unaff_ESI = 0;
          *param_4 = *param_4 + 1;
          param_4[2] = param_4[2] + uVar7 * 0x70;
        }
        if (uStack_20 != 0) {
          iVar10 = 0;
          do {
            iStack_14 = *(int *)(*piStack_38 + iVar10);
            uVar7 = *(uint *)(*piStack_38 + 8 + iVar10);
            puStack_18 = (undefined *)0x1;
            puStack_1c = (undefined *)0x7b55f5;
            (**(code **)(*param_1 + 0x28))();
            puVar2 = (undefined4 *)*piVar1;
            uStack_20 = puVar2[5];
            iStack_24 = puVar2[4];
            iStack_28 = puVar2[3];
            uStack_2c = puVar2[2];
            uStack_34 = CONCAT44(*puVar2,0x7b5610);
            puStack_1c = (undefined *)uVar7;
            (**(code **)(*param_1 + 0x40))();
            *param_4 = *param_4 + 1;
            iVar10 = (int)puStack_18 + 0x10;
            iStack_24 = iStack_24 - uVar7;
            uStack_20 = uStack_20 - 1;
            iVar5 = iStack_28;
          } while (uStack_20 != 0);
        }
      }
      puStack_18 = (undefined *)((int)puStack_1c * 0x70 + iStack_14);
      uVar7 = unaff_ESI;
      for (uVar9 = iVar5 - (int)puStack_1c; uVar9 != 0; uVar9 = uVar9 - uVar8) {
        uVar8 = uStack_2c - uVar7;
        if (uVar9 <= uStack_2c - uVar7) {
          uVar8 = uVar9;
        }
        iStack_14 = uVar8 * 0x70;
        puStack_1c = auStack_1c040 + uVar7 * 0x70;
        uStack_20 = 0x7b5663;
        FUN_0170c6f0();
        uVar7 = uVar7 + uVar8;
        if (uVar7 == uStack_2c) {
          puStack_18 = auStack_1c040;
          puStack_1c = (undefined *)0x1;
          uStack_20 = 0x7b5685;
          iStack_14 = uVar7 * 0x70;
          (**(code **)(*param_1 + 0x30))();
          puVar2 = (undefined4 *)*piVar1;
          iStack_24 = puVar2[5];
          iStack_28 = puVar2[4];
          uStack_2c = puVar2[3];
          uStack_34 = CONCAT44(puVar2[2],*puVar2);
          piStack_38 = (int *)0x7b56a3;
          uStack_20 = uVar7;
          (**(code **)(*param_1 + 0x40))();
          param_4[2] = param_4[2] + uVar7 * 0x70;
          *param_4 = *param_4 + 1;
          uVar7 = 0;
        }
        puStack_18 = puStack_1c + iStack_14;
      }
      param_2 = param_2 + 6;
      param_3 = param_3 + -1;
      unaff_ESI = uVar7;
    } while (param_3 != 0);
    if (uVar7 != 0) {
      puStack_18 = auStack_1c040;
      puStack_1c = (undefined *)0x1;
      uStack_20 = 0x7b56f9;
      iStack_14 = uVar7 * 0x70;
      (**(code **)(*param_1 + 0x30))();
      puVar2 = (undefined4 *)*piVar1;
      iStack_24 = puVar2[5];
      iStack_28 = puVar2[4];
      uStack_2c = puVar2[3];
      uStack_34 = CONCAT44(puVar2[2],*puVar2);
      piStack_38 = (int *)0x7b5714;
      uStack_20 = uVar7;
      (**(code **)(*param_1 + 0x40))();
      param_4[2] = param_4[2] + uVar7 * 0x70;
      *param_4 = *param_4 + 1;
    }
  }
  return;
}



/* FUNCTION 11660 ; VA 0x007b5730 ; FUN_007b5730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_007b5730(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined auStack_120 [4];
  int *piStack_11c;
  undefined4 uStack_100;
  int *piStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined auStack_e0 [4];
  uint uStack_dc;
  undefined4 uStack_cc;
  uint uStack_c8;
  uint uStack_c0;
  undefined4 uStack_b0;
  uint uStack_ac;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2d28;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  piStack_54 = *(int **)(param_1 + 0xa0);
  uStack_14 = 0;
  piVar2 = *(int **)(param_1 + 0x9c);
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (piVar2 != piStack_54) {
    do {
      uStack_18 = *piVar2;
      piVar1 = *(int **)(uStack_18 + 0x50);
      for (piVar6 = *(int **)(uStack_18 + 0x4c); piStack_24 = piVar2, piVar6 != piVar1;
          piVar6 = piVar6 + 1) {
        piVar2 = (int *)*piVar6;
        if (piVar2[8] != 0) {
          FUN_007b5230(piVar2);
          piVar2 = (int *)*piVar6;
        }
        (**(code **)(*piVar2 + 0x40))();
        if ((undefined4 *)*piVar6 != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)*piVar6)(1);
        }
        piVar2 = piStack_24;
      }
      *(undefined4 *)(uStack_18 + 0x50) = *(undefined4 *)(uStack_18 + 0x4c);
      iVar3 = *piVar2;
      if (*(int *)(iVar3 + 0x20) != 0) {
        FUN_007b5230(iVar3);
        iVar3 = *piVar2;
      }
      uStack_2c = FUN_007b3ea0(*(undefined4 *)(iVar3 + 4),0,
                               *(uint *)(iVar3 + 0x2c) >> 8 & 0xffffff01);
      uVar7 = (uStack_2c & 1) * 2 + 0x100;
      uVar5 = uVar7 | 4;
      if ((uStack_2c & 8) == 0) {
        uVar5 = uVar7;
      }
      uVar7 = uVar5 | 0x2000;
      if ((uStack_2c & 0x80) == 0) {
        uVar7 = uVar5;
      }
      uStack_18 = uVar7;
      iStack_28 = *(int *)(*piVar2 + 4);
      if ((*(int *)(*piVar2 + 4) != 0) && (iVar3 = FUN_00b084e0(), iVar3 == 0x630)) {
        uVar7 = uVar7 | 0x800;
      }
      if ((uStack_2c & 0x10) == 0) {
        puVar4 = (undefined4 *)FUN_00761230(auStack_120,iStack_28,0,0,uVar7);
        uStack_1c = uStack_14 | 4;
        uStack_100 = *puVar4;
      }
      else {
        uStack_5c = 0;
        piStack_58 = (int *)0x0;
        uStack_7c = 0;
        piStack_78 = (int *)0x0;
        uStack_74 = 0;
        uStack_70 = 0;
        uStack_6c = _DAT_018fac80;
        uStack_68 = _UNK_018fac84;
        uStack_64 = _UNK_018fac88;
        uStack_60 = _UNK_018fac8c;
        uStack_1c = uStack_14 | 3;
        puVar4 = &uStack_7c;
        uStack_100 = 0;
      }
      piVar1 = piStack_11c;
      piVar2 = (int *)puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      uStack_f0 = puVar4[4];
      uStack_ec = puVar4[5];
      uStack_e8 = puVar4[6];
      uStack_e4 = puVar4[7];
      uStack_18 = uStack_100;
      uStack_f8 = puVar4[2];
      uStack_f4 = puVar4[3];
      uStack_8 = 2;
      piStack_fc = piVar2;
      uStack_50 = uStack_f4;
      uStack_14 = uStack_1c;
      if (((uStack_1c & 4) != 0) &&
         (uStack_1c = uStack_1c & 0xfffffffb, uStack_14 = uStack_1c, piStack_11c != (int *)0x0)) {
        LOCK();
        iVar3 = piStack_11c[1] + -1;
        piStack_11c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_11c)();
          LOCK();
          piVar6 = piVar1 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piStack_78;
      if (((uStack_14 & 2) != 0) &&
         (uStack_1c = uStack_14 & 0xfffffffd, uStack_14 = uStack_1c, piStack_78 != (int *)0x0)) {
        LOCK();
        iVar3 = piStack_78[1] + -1;
        piStack_78[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_78)();
          LOCK();
          piVar6 = piVar1 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piStack_58;
      if (((uStack_14 & 1) != 0) &&
         (uStack_1c = uStack_14 & 0xfffffffe, uStack_14 = uStack_1c, piStack_58 != (int *)0x0)) {
        LOCK();
        iVar3 = piStack_58[1] + -1;
        piStack_58[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar6 = piVar1 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piStack_24;
      uStack_cc = 0;
      uStack_c8 = 0xf;
      uStack_dc = uStack_dc & 0xffffff00;
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = uStack_c0 & 0xffffff00;
      uStack_8._0_1_ = 5;
      FUN_0076f0a0(*(undefined4 *)(*piStack_24 + 4),0);
      FUN_0076dfa0(&uStack_34,auStack_e0,iStack_28);
      uStack_4c = uStack_2c;
      uStack_48 = uStack_50;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piStack_30[1] = piStack_30[1] + 1;
        UNLOCK();
      }
      uStack_44 = uStack_34;
      piStack_40 = piStack_30;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      uStack_3c = uStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      piStack_38 = piVar2;
      FUN_007b4320(&uStack_4c);
      FUN_007b3860(*piVar1);
      FUN_007b3290(*piVar1);
      piVar6 = piStack_38;
      *(uint *)(*piVar1 + 0x2c) = *(uint *)(*piVar1 + 0x2c) & 0xfffffffe;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_38[1] + -1;
        piStack_38[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar1 = piStack_40;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_40[1] + -1;
        piStack_40[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          piVar6 = piVar1 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piStack_30;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_30[1] + -1;
        piStack_30[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          piVar6 = piVar1 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (0xf < uStack_ac) {
        uVar5 = uStack_ac + 1;
        uVar7 = uStack_c0;
        if (0xfff < uVar5) {
          uVar7 = *(uint *)(uStack_c0 - 4);
          uVar5 = uStack_ac + 0x24;
          if (0x1f < (uStack_c0 - uVar7) - 4) goto LAB_007b5c0e;
        }
        FUN_01674ea0(uVar7,uVar5);
      }
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = uStack_c0 & 0xffffff00;
      if (0xf < uStack_c8) {
        uVar5 = uStack_c8 + 1;
        uVar7 = uStack_dc;
        if (0xfff < uVar5) {
          uVar7 = *(uint *)(uStack_dc - 4);
          uVar5 = uStack_c8 + 0x24;
          if (0x1f < (uStack_dc - uVar7) - 4) {
LAB_007b5c0e:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar5);
      }
      uStack_cc = 0;
      uStack_c8 = 0xf;
      uStack_dc = uStack_dc & 0xffffff00;
      uStack_8 = 0xffffffff;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_24 + 1;
      param_1 = iStack_20;
    } while (piVar2 != piStack_54);
  }
  *(uint *)(param_1 + 0x98) = *(uint *)(param_1 + 0x98) & 0xfffffffe;
  *(undefined4 *)(param_1 + 0xa0) = *(undefined4 *)(param_1 + 0x9c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11661 ; VA 0x007b5c20 ; FUN_007b5c20 */

void FUN_007b5c20(undefined4 param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar3 = 0.0;
  fVar1 = (param_3[5] - param_3[2]) * DAT_018ce2f4;
  fVar6 = param_2[2] - (param_3[2] + param_3[5]) * DAT_018ce2f4;
  fVar5 = (param_3[4] - param_3[1]) * DAT_018ce2f4;
  fVar7 = param_2[1] - (param_3[1] + param_3[4]) * DAT_018ce2f4;
  fVar4 = *param_2 - (*param_3 + param_3[3]) * DAT_018ce2f4;
  fVar2 = (param_3[3] - *param_3) * DAT_018ce2f4;
  if (fVar4 < (float)((uint)fVar2 ^ DAT_018c4ea0)) {
    fVar3 = (fVar2 + fVar4) * (fVar2 + fVar4) + 0.0;
  }
  if (fVar2 < fVar4) {
    fVar3 = fVar3 + (fVar4 - fVar2) * (fVar4 - fVar2);
  }
  if (fVar7 < (float)((uint)fVar5 ^ DAT_018c4ea0)) {
    fVar3 = fVar3 + (fVar5 + fVar7) * (fVar5 + fVar7);
  }
  if (fVar5 < fVar7) {
    fVar3 = fVar3 + (fVar7 - fVar5) * (fVar7 - fVar5);
  }
  if (fVar6 < (float)((uint)fVar1 ^ DAT_018c4ea0)) {
    fVar3 = fVar3 + (fVar1 + fVar6) * (fVar1 + fVar6);
  }
  if (fVar1 < fVar6) {
    fVar3 = fVar3 + (fVar6 - fVar1) * (fVar6 - fVar1);
  }
  FUN_007b3190((double)fVar3,DAT_018c0d60);
  return;
}



/* FUNCTION 11662 ; VA 0x007b5d70 ; FUN_007b5d70 */

void FUN_007b5d70(undefined4 param_1,float *param_2,float *param_3,float param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar3 = 0.0;
  fVar1 = (param_3[5] - param_3[2]) * DAT_018ce2f4;
  fVar6 = param_2[2] - (param_3[2] + param_3[5]) * DAT_018ce2f4;
  fVar5 = (param_3[4] - param_3[1]) * DAT_018ce2f4;
  fVar7 = param_2[1] - (param_3[1] + param_3[4]) * DAT_018ce2f4;
  fVar4 = *param_2 - (*param_3 + param_3[3]) * DAT_018ce2f4;
  fVar2 = (param_3[3] - *param_3) * DAT_018ce2f4;
  if (fVar4 < (float)((uint)fVar2 ^ DAT_018c4ea0)) {
    fVar3 = (fVar2 + fVar4) * (fVar2 + fVar4) + 0.0;
  }
  if (fVar2 < fVar4) {
    fVar3 = fVar3 + (fVar4 - fVar2) * (fVar4 - fVar2);
  }
  if (fVar7 < (float)((uint)fVar5 ^ DAT_018c4ea0)) {
    fVar3 = fVar3 + (fVar5 + fVar7) * (fVar5 + fVar7);
  }
  if (fVar5 < fVar7) {
    fVar3 = fVar3 + (fVar7 - fVar5) * (fVar7 - fVar5);
  }
  if (fVar6 < (float)((uint)fVar1 ^ DAT_018c4ea0)) {
    fVar3 = fVar3 + (fVar1 + fVar6) * (fVar1 + fVar6);
  }
  if (fVar1 < fVar6) {
    fVar3 = fVar3 + (fVar6 - fVar1) * (fVar6 - fVar1);
  }
  FUN_007b3190((double)fVar3,(double)(DAT_01eb28bc * param_4));
  return;
}



/* FUNCTION 11663 ; VA 0x007b5ec0 ; FUN_007b5ec0 */

void FUN_007b5ec0(undefined param_1)

{
  DAT_01eb28ba = param_1;
  return;
}



/* FUNCTION 11664 ; VA 0x007b5ed0 ; FUN_007b5ed0 */

undefined4 FUN_007b5ed0(int *param_1)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (DAT_01eb28b8 != '\0') {
    iVar2 = (**(code **)(*param_1 + 0xb4))();
    if ((iVar2 == 0xc) || (iVar2 == 0xb)) {
      bVar1 = true;
    }
    else {
      bVar1 = false;
    }
    if ((DAT_01eb28b9 != '\0') || (bVar1)) {
      if (iVar2 == 0xc) {
        iVar2 = param_1[3];
        iVar3 = FUN_00cfb1a0();
        piVar4 = (int *)0x0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da)) {
          piVar4 = param_1;
        }
        if (*(char *)((int)piVar4 + 0x191) != '\0') {
          return 0;
        }
        if ((DAT_01d6c85c != '\0') && ((*(byte *)(piVar4 + 0x2d) & 0x40) != 0)) {
          return 0;
        }
      }
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 11665 ; VA 0x007b5f60 ; FUN_007b5f60 */

uint __thiscall FUN_007b5f60(uint *param_1,undefined4 param_2,int param_3,int param_4)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2d48;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_18 = (param_4 + -1 + DAT_01eb28b4) / DAT_01eb28b4;
  piStack_3c = (int *)0x0;
  uVar9 = (int)(param_1[1] - *param_1) >> 4;
  uStack_38 = 0;
  uStack_34 = 1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uStack_18 < uVar9) {
    iVar8 = uStack_18 << 4;
    iVar10 = uVar9 - uStack_18;
    ExceptionList = &pvStack_10;
    do {
      if (*(int *)(*param_1 + iVar8) != 0) {
        FUN_007d6460((int *)(*param_1 + iVar8));
      }
      iVar8 = iVar8 + 0x10;
      iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
  }
  uVar9 = FUN_007afc70(uStack_18,param_1,&uStack_40);
  uStack_14 = 0;
  if (uStack_18 != 0) {
    iVar8 = 0;
    do {
      uVar9 = *param_1;
      if (*(int *)(iVar8 + 0xc + uVar9) != 0) {
        *(undefined4 *)(iVar8 + 0xc + uVar9) = 0;
        if (*(int *)(*param_1 + iVar8) != 0) {
          FUN_007d6460((int *)(*param_1 + iVar8));
          uVar9 = *param_1;
          *(undefined4 *)(uVar9 + iVar8) = 0;
          piVar4 = *(int **)(uVar9 + 4 + iVar8);
          *(undefined4 *)(uVar9 + 4 + iVar8) = 0;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar10 = piVar4[1] + -1;
            piVar4[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar10 = piVar4[2] + -1;
              piVar4[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          *(undefined4 *)(iVar8 + 8 + *param_1) = 0;
        }
        iStack_24 = DAT_01eb28b4 * uStack_14;
        uVar9 = param_4 - iStack_24;
        uStack_28 = DAT_01eb28b4;
        if (uVar9 < DAT_01eb28b4) {
          uStack_28 = uVar9;
        }
        iStack_20 = uStack_28 * 0x70;
        if (0x49 < uStack_28) {
          *(uint *)(iVar8 + 8 + *param_1) = uStack_28;
          puVar6 = (undefined4 *)FUN_007d5f60(auStack_30,iStack_20);
          uVar9 = *param_1;
          uVar7 = *puVar6;
          uVar5 = puVar6[1];
          *puVar6 = 0;
          puVar6[1] = 0;
          *(undefined4 *)(uVar9 + iVar8) = uVar7;
          piVar4 = *(int **)(uVar9 + 4 + iVar8);
          *(undefined4 *)(uVar9 + 4 + iVar8) = uVar5;
          piStack_1c = piVar4;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar10 = piVar4[1] + -1;
            piVar4[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar10 = piVar4[2] + -1;
              piVar4[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          piVar4 = piStack_2c;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar10 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar10 = *piVar1 + -1;
              *piVar1 = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          uVar7 = (**(code **)(**(int **)(iVar8 + *param_1) + 0x10))();
          FUN_0170c6f0(uVar7,iStack_24 * 0x70 + param_3,iStack_20);
          uVar9 = (**(code **)(**(int **)(iVar8 + *param_1) + 0x14))();
        }
        if (DAT_01eb2844 != '\0') {
          uVar9 = FUN_01677490(DAT_01eb2844,"  ... buffer %u 0x%p re-uploaded %u instances",
                               uStack_14,*(undefined4 *)(iVar8 + *param_1),uStack_28);
        }
      }
      uStack_14 = uStack_14 + 1;
      iVar8 = iVar8 + 0x10;
    } while (uStack_14 < uStack_18);
  }
  piVar4 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_3c + 1);
    uVar3 = *puVar2;
    uVar9 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar9 = (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar9;
}



/* FUNCTION 11666 ; VA 0x007b61d0 ; FUN_007b61d0 */

void __fastcall FUN_007b61d0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0xb0);
  uVar1 = *(undefined4 *)(*(int *)(*(int *)(param_1 + 4) + 8) + 0x50c);
  if ((uint)((iVar2 - *(int *)(param_1 + 0xac)) / 0x70) < 0x4a) {
    FUN_007b4d10(uVar1);
  }
  else {
    if (DAT_01eb2844 != '\0') {
      FUN_016774b0(DAT_01eb2844,"entity 0x%p syncing buffers",param_1);
      iVar2 = *(int *)(param_1 + 0xb0);
    }
    FUN_007b5f60(uVar1,*(int *)(param_1 + 0xac),(iVar2 - *(int *)(param_1 + 0xac)) / 0x70);
  }
  iVar2 = *(int *)(param_1 + 0x8c);
  if (0x49 < (uint)((iVar2 - *(int *)(param_1 + 0x88)) / 0x70)) {
    if (DAT_01eb2844 != '\0') {
      FUN_016774b0(DAT_01eb2844,"entity 0x%p syncing shadow buffers",param_1);
      iVar2 = *(int *)(param_1 + 0x8c);
    }
    FUN_007b5f60(uVar1,*(int *)(param_1 + 0x88),(iVar2 - *(int *)(param_1 + 0x88)) / 0x70);
    return;
  }
  FUN_007b4d10(uVar1);
  return;
}



/* FUNCTION 11667 ; VA 0x007b62f0 ; thunk_FUN_011590c0 */

void __fastcall thunk_FUN_011590c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (*(int *)(param_1 + 4) != 0) {
    *(undefined4 *)(*(int *)(param_1 + 4) + 0xb0) = 0;
  }
  iVar3 = *(int *)(param_1 + 0xc);
  piVar1 = (int *)(param_1 + 0xc);
  iVar2 = *(int *)(param_1 + 0x10);
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      FUN_01679490();
      iVar2 = *(int *)(param_1 + 0x10);
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  FUN_00633350(iVar3,iVar2,piVar1);
  *(int *)(param_1 + 0x10) = *piVar1;
  return;
}



/* FUNCTION 11668 ; VA 0x007b6300 ; FUN_007b6300 */

void __fastcall FUN_007b6300(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x98);
  if (DAT_01d61ba4 != '\0') {
    uVar1 = *(uint *)(param_1 + 0x98) | 0x10;
  }
  *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) | 0x80000000;
  *(uint *)(param_1 + 0x98) = uVar1 & 0xfffffffe;
  FUN_007b6e70();
  return;
}



/* FUNCTION 11669 ; VA 0x007b6340 ; FUN_007b6340 */

void __fastcall FUN_007b6340(int param_1)

{
  if (((*(float *)(param_1 + 0x18) < *(float *)(param_1 + 0x24) ||
        *(float *)(param_1 + 0x18) == *(float *)(param_1 + 0x24)) &&
      (*(float *)(param_1 + 0x1c) < *(float *)(param_1 + 0x28) ||
       *(float *)(param_1 + 0x1c) == *(float *)(param_1 + 0x28))) &&
     (*(float *)(param_1 + 0x20) < *(float *)(param_1 + 0x2c) ||
      *(float *)(param_1 + 0x20) == *(float *)(param_1 + 0x2c))) {
    FUN_007c7690(param_1 + 0x18,1);
  }
  FUN_007b5730();
  return;
}



/* FUNCTION 11670 ; VA 0x007b6380 ; FUN_007b6380 */

void __fastcall FUN_007b6380(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  
  *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) | 8;
  piVar1 = *(int **)(param_1 + 0xb8);
  for (piVar9 = *(int **)(param_1 + 0xb4); piVar9 != piVar1; piVar9 = piVar9 + 1) {
    iVar6 = *piVar9;
    piVar2 = *(int **)(iVar6 + 0x50);
    iVar5 = *(int *)(iVar6 + 0x20);
    iVar3 = *(int *)(iVar6 + 0x1c);
    for (piVar8 = *(int **)(iVar6 + 0x4c); piVar8 != piVar2; piVar8 = piVar8 + 1) {
      piVar7 = (int *)*piVar8;
      if (piVar7[8] != 0) {
        FUN_007b5230(piVar7);
        piVar7 = (int *)*piVar8;
      }
      (**(code **)(*piVar7 + 0x40))();
      if ((undefined4 *)*piVar8 != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)*piVar8)(1);
      }
    }
    *(undefined4 *)(iVar6 + 0x50) = *(undefined4 *)(iVar6 + 0x4c);
    iVar5 = FUN_007b4320(iVar5 + 0x4c);
    iVar6 = *piVar9;
    FUN_007b5230(iVar6);
    *(undefined4 *)(iVar6 + 0x1c) = *(undefined4 *)(iVar5 + 4);
    FUN_007b3860(iVar6);
    *(uint *)(*piVar9 + 0x2c) = *(uint *)(*piVar9 + 0x2c) & 0xfffffff5;
    iVar6 = *piVar9;
    if ((*(uint *)(iVar6 + 0x2c) & 0x20) != 0) {
      *(uint *)(iVar6 + 0x2c) = *(uint *)(iVar6 + 0x2c) & 0xffffffdf;
      FUN_007b4f80(*piVar9);
      iVar6 = *piVar9;
    }
    FUN_007b3290(iVar6);
    if ((DAT_01d61ba4 != '\0') && ((*(uint *)(iVar3 + 0x98) & 0x10) == 0)) {
      *(uint *)(iVar3 + 0x98) = *(uint *)(iVar3 + 0x98) | 0x10;
      FUN_007c8bd0(iVar3);
      if (DAT_01eb2844 != '\0') {
        FUN_016774b0(DAT_01eb2844,"cluster 0x%p queued for oob syncbuffers",iVar3);
      }
    }
    uVar4 = *(uint *)(iVar3 + 0x98);
    if ((uVar4 & 3) == 0) {
      if (*(int *)(iVar3 + 0xcc) < 0) {
        *(uint *)(iVar3 + 0x98) = uVar4 | 2;
      }
      else {
        *(uint *)(iVar3 + 0x98) = uVar4 | 1;
        FUN_007c8c00(iVar3);
      }
    }
    if (DAT_01eb2844 != '\0') {
      FUN_016773b0(DAT_01eb2844,"binding 0x%p (0x%p) transfer from 0x%p to 0x%p complete.",*piVar9,
                   *(undefined4 *)(*piVar9 + 4),iVar3,param_1,0);
    }
  }
  *(undefined4 *)(param_1 + 0xb8) = *(undefined4 *)(param_1 + 0xb4);
  *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) & 0xfffffff7;
  return;
}



/* FUNCTION 11671 ; VA 0x007b6530 ; FUN_007b6530 */

void __fastcall FUN_007b6530(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) | 4;
  piVar5 = *(int **)(param_1 + 0xa8);
  piStack_20 = *(int **)(param_1 + 0xac);
  iStack_1c = param_1;
  if (piVar5 != piStack_20) {
    do {
      piVar7 = (int *)*piVar5;
      piStack_14 = piVar5;
      if ((*(byte *)(piVar7 + 0xb) & 0x10) != 0) {
        if (DAT_01eb2844 != '\0') {
          puVar1 = (undefined4 *)FUN_008a2380(auStack_38);
          uStack_8 = 0;
          if (0xf < (uint)puVar1[5]) {
            puVar1 = (undefined4 *)*puVar1;
          }
          FUN_01677490(DAT_01eb2844,"binding 0x%p (0x%p) humanoid re-queue [%s]",*piVar5,
                       *(undefined4 *)(*piVar5 + 4),puVar1);
          uStack_8 = 0xffffffff;
          if (0xf < uStack_24) {
            uVar4 = uStack_24 + 1;
            uVar2 = auStack_38[0];
            if (0xfff < uVar4) {
              uVar2 = *(uint *)(auStack_38[0] - 4);
              uVar4 = uStack_24 + 0x24;
              if (0x1f < (auStack_38[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar2,uVar4);
          }
          piVar7 = (int *)*piVar5;
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = auStack_38[0] & 0xffffff00;
        }
        FUN_007c8e00(piVar7 + 1);
        piVar7 = (int *)*piVar5;
      }
      if (DAT_01eb2844 != '\0') {
        FUN_01677490(DAT_01eb2844,"cluster 0x%p remove 0x%p (0x%p)",param_1,piVar7,piVar7[1]);
      }
      piVar5 = (int *)piVar7[0x14];
      piStack_18 = piVar5;
      for (piVar6 = (int *)piVar7[0x13]; piVar6 != piVar5; piVar6 = piVar6 + 1) {
        piVar3 = (int *)*piVar6;
        if (piVar3[8] != 0) {
          FUN_007b5230(piVar3);
          piVar3 = (int *)*piVar6;
        }
        (**(code **)(*piVar3 + 0x40))();
        if ((undefined4 *)*piVar6 != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)*piVar6)(1);
        }
        param_1 = iStack_1c;
      }
      piVar7[0x14] = piVar7[0x13];
      FUN_007b5230(piVar7);
      (**(code **)(*piVar7 + 0x40))();
      (**(code **)*piVar7)(1);
      uVar2 = *(uint *)(param_1 + 0x98);
      if ((uVar2 & 3) == 0) {
        if (*(int *)(param_1 + 0xcc) < 0) {
          *(uint *)(param_1 + 0x98) = uVar2 | 2;
        }
        else {
          *(uint *)(param_1 + 0x98) = uVar2 | 1;
          FUN_007c8c00(param_1);
        }
      }
      piVar5 = piStack_14 + 1;
    } while (piVar5 != piStack_20);
  }
  *(undefined4 *)(param_1 + 0xac) = *(undefined4 *)(param_1 + 0xa8);
  *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) & 0xfffffffb;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11672 ; VA 0x007b6720 ; FUN_007b6720 */

void __fastcall FUN_007b6720(int param_1)

{
  uint uVar1;
  void **ppvVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2d8d;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_1 + 0xc4);
  piVar7 = *(int **)(param_1 + 0xc0);
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  if (piVar7 != piVar6) {
    do {
      if (*(int *)(*piVar7 + 0xb0) == 0) {
        iVar5 = *(int *)(*piVar7 + 0xc);
        iVar3 = FUN_00d391f0();
        if ((uint)*(ushort *)(iVar3 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
          iVar5 = FUN_00d012f0(*piVar7);
          if (iVar5 == 0) {
            iVar5 = FUN_01674e20(0x60);
            uStack_8 = 2;
            if (iVar5 == 0) goto LAB_007b6819;
            piVar4 = (int *)FUN_007b1da0(param_1,piVar7);
          }
          else {
            piVar4 = (int *)FUN_01674e20(0x60);
            uStack_8 = 1;
            if (piVar4 == (int *)0x0) {
LAB_007b6819:
              piVar4 = (int *)0x0;
            }
            else {
              FUN_007b1da0(param_1,piVar7);
              *piVar4 = (int)RBX::Graphics::InstancedBindingSpecialMesh::vftable;
            }
          }
        }
        else {
          piVar4 = (int *)FUN_01674e20(0x60);
          uStack_8 = 0;
          if (piVar4 == (int *)0x0) goto LAB_007b6819;
          FUN_007b1da0(param_1,piVar7);
          *piVar4 = (int)RBX::Graphics::InstancedBindingTruss::vftable;
        }
        uStack_8 = 0xffffffff;
        FUN_01158150(piVar7);
        (**(code **)(*piVar4 + 8))();
        uVar1 = *(uint *)(param_1 + 0x98);
        if ((uVar1 & 3) == 0) {
          if (*(int *)(param_1 + 0xcc) < 0) {
            *(uint *)(param_1 + 0x98) = uVar1 | 2;
          }
          else {
            *(uint *)(param_1 + 0x98) = uVar1 | 1;
            FUN_007c8c00(param_1);
          }
        }
      }
      piVar7 = piVar7 + 2;
    } while (piVar7 != piVar6);
    piVar6 = *(int **)(param_1 + 0xc4);
    ppvVar2 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar2;
  FUN_005596d0(*(undefined4 *)(param_1 + 0xc0),piVar6,(undefined4 *)(param_1 + 0xc0));
  *(undefined4 *)(param_1 + 0xc4) = *(undefined4 *)(param_1 + 0xc0);
  FUN_007b5730();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11673 ; VA 0x007b68c0 ; FUN_007b68c0 */

undefined4 __fastcall FUN_007b68c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  int *piStack_14;
  uint uStack_10;
  int iStack_c;
  char cStack_5;
  
  cStack_5 = '\0';
  if (*(int *)(param_1 + 0x7c) == 0) {
    piVar8 = (int *)0x0;
  }
  else {
    piVar8 = *(int **)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x78) * 4);
  }
  iVar4 = param_1;
  iStack_c = param_1;
  if (piVar8 != (int *)0x0) {
    do {
      puVar10 = (undefined4 *)piVar8[8];
      if (puVar10[0x28] == puVar10[0x29]) {
        cStack_5 = '\x01';
        if (puVar10 != (undefined4 *)0x0) {
          (**(code **)*puVar10)(1);
          param_1 = iStack_c;
        }
        uStack_10 = (uint)piVar8[1] % *(uint *)(param_1 + 0x78);
        piVar9 = (int *)*piVar8;
        piVar2 = *(int **)(*(int *)(param_1 + 0x88) + uStack_10 * 4);
        for (piVar6 = (int *)*piVar2; piStack_14 = piVar2, piVar6 != piVar8; piVar6 = (int *)*piVar6
            ) {
          piVar2 = piVar6;
        }
        do {
          *piVar2 = *piVar6;
          FUN_007b2d40();
          FUN_01674ea0(piVar6,0x24);
          *(int *)(iStack_c + 0x7c) = *(int *)(iStack_c + 0x7c) + -1;
          uVar5 = uStack_10;
          if (*piVar2 == 0) {
LAB_007b6980:
            if (*(int **)(*(int *)(iStack_c + 0x88) + uStack_10 * 4) == piVar2) {
              *(undefined4 *)(*(int *)(iStack_c + 0x88) + uStack_10 * 4) = 0;
            }
          }
          else {
            uVar5 = *(uint *)(*piVar2 + 4) % *(uint *)(iStack_c + 0x78);
            if (uStack_10 != uVar5) {
              *(int **)(*(int *)(iStack_c + 0x88) + uVar5 * 4) = piVar2;
              goto LAB_007b6980;
            }
          }
          piVar6 = (int *)*piVar2;
          param_1 = iStack_c;
          uStack_10 = uVar5;
        } while (piVar6 != piVar9);
      }
      else {
        piVar9 = (int *)*piVar8;
      }
      piVar8 = piVar9;
    } while (piVar9 != (int *)0x0);
    iVar4 = param_1;
    if (cStack_5 != '\0') {
      iVar7 = 0;
      *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x38);
      if (*(int *)(param_1 + 0x7c) == 0) {
        puVar10 = (undefined4 *)0x0;
      }
      else {
        puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x78) * 4);
      }
      for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
        puVar3 = *(undefined4 **)(param_1 + 0x3c);
        piStack_14 = (int *)puVar10[8];
        if (*(undefined4 **)(param_1 + 0x40) == puVar3) {
          FUN_006030d0(puVar3,&piStack_14);
        }
        else {
          *puVar3 = piStack_14;
          *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 4;
        }
        iVar7 = iVar7 + (*(int *)(puVar10[8] + 0xa4) - *(int *)(puVar10[8] + 0xa0) >> 2);
        iVar4 = iStack_c;
      }
      *(int *)(iVar4 + 0x10) = iVar7;
      if (DAT_01eb2844 != '\0') {
        FUN_01677490(DAT_01eb2844,"cluster 0x%p rebuilt entity list:  %u entries  %u parts",iVar4,
                     *(int *)(param_1 + 0x3c) - *(int *)(param_1 + 0x38) >> 2,iVar7);
        iVar4 = iStack_c;
      }
    }
  }
  if ((DAT_01d61ba4 == '\0') && (DAT_01eb28b9 != '\0')) {
    if (*(int *)(iVar4 + 0x7c) == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = *(undefined4 **)(*(int *)(iVar4 + 0x88) + *(int *)(iVar4 + 0x78) * 4);
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      FUN_007b61d0();
    }
  }
  iVar4 = iStack_c;
  if (*(int *)(iStack_c + 0x7c) == 0) {
    if (DAT_01eb2844 != '\0') {
      FUN_016774b0(DAT_01eb2844,"cluster 0x%p scheduled for termination",iStack_c);
    }
    puVar1 = (uint *)(iVar4 + 0x98);
    *puVar1 = *puVar1 | 4;
    FUN_007c8ba0(iVar4);
    return 0;
  }
  return 1;
}



/* FUNCTION 11674 ; VA 0x007b6ae0 ; FUN_007b6ae0 */

void __fastcall FUN_007b6ae0(int param_1)

{
  undefined4 *puVar1;
  
  if ((DAT_01d61ba4 != '\0') &&
     (*(uint *)(param_1 + 0x98) = *(uint *)(param_1 + 0x98) & 0xffffffef, DAT_01eb28b9 != '\0')) {
    if (*(int *)(param_1 + 0x7c) == 0) {
      puVar1 = (undefined4 *)0x0;
    }
    else {
      puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x78) * 4);
    }
    for (; puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
      FUN_007b61d0();
    }
  }
  return;
}



/* FUNCTION 11675 ; VA 0x007b6b30 ; FUN_007b6b30 */

void __fastcall FUN_007b6b30(int param_1)

{
  float *pfVar1;
  undefined4 *puVar2;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_14;
  float fStack_8;
  
  if ((*(byte *)(param_1 + 0x98) & 4) == 0) {
    fStack_8 = 3.4028235e+38;
    fStack_14 = -3.4028235e+38;
    fStack_2c = 3.4028235e+38;
    fStack_20 = -3.4028235e+38;
    fStack_28 = DAT_018c45d0;
    fStack_34 = DAT_018c45c4;
    fStack_24 = DAT_018c45d0;
    fStack_30 = DAT_018c45c4;
    if (*(int *)(param_1 + 0x7c) == 0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x78) * 4);
    }
    for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
      pfVar1 = (float *)FUN_007b7670();
      fStack_14 = fStack_2c;
      if (pfVar1[2] <= fStack_2c) {
        fStack_14 = pfVar1[2];
      }
      if (pfVar1[1] <= fStack_30) {
        fStack_30 = pfVar1[1];
      }
      if (*pfVar1 <= fStack_34) {
        fStack_34 = *pfVar1;
      }
      fStack_8 = fStack_20;
      if (fStack_20 <= pfVar1[5]) {
        fStack_8 = pfVar1[5];
      }
      if (fStack_24 <= pfVar1[4]) {
        fStack_24 = pfVar1[4];
      }
      if (fStack_28 <= pfVar1[3]) {
        fStack_28 = pfVar1[3];
      }
      fStack_2c = fStack_14;
      fStack_20 = fStack_8;
    }
    FUN_008411b0(&fStack_34,*(undefined4 *)(*(int *)(*(int *)(param_1 + 8) + 0x4e4) + 0x24));
    if (((fStack_34 <= fStack_28) && (fStack_30 <= fStack_24)) && (fStack_2c <= fStack_20)) {
      FUN_007c7690(&fStack_34,1);
    }
    if ((*(uint *)(param_1 + 0x98) & 2) != 0) {
      *(uint *)(param_1 + 0x98) = *(uint *)(param_1 + 0x98) & 0xfffffffd | 1;
      FUN_007c8c00(param_1);
    }
    *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) & 0x7fffffff;
  }
  return;
}



/* FUNCTION 11676 ; VA 0x007b6cd0 ; FUN_007b6cd0 */

void __thiscall FUN_007b6cd0(int param_1,undefined4 param_2)

{
  float *pfVar1;
  undefined4 *puVar2;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_14;
  float fStack_8;
  
  fStack_8 = 3.4028235e+38;
  fStack_14 = -3.4028235e+38;
  fStack_2c = 3.4028235e+38;
  fStack_20 = -3.4028235e+38;
  fStack_28 = DAT_018c45d0;
  fStack_34 = DAT_018c45c4;
  fStack_24 = DAT_018c45d0;
  fStack_30 = DAT_018c45c4;
  if (*(int *)(param_1 + 0x7c) == 0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x88) + *(int *)(param_1 + 0x78) * 4);
  }
  for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
    pfVar1 = (float *)FUN_007b7670();
    fStack_14 = fStack_2c;
    if (pfVar1[2] <= fStack_2c) {
      fStack_14 = pfVar1[2];
    }
    if (pfVar1[1] <= fStack_30) {
      fStack_30 = pfVar1[1];
    }
    if (*pfVar1 <= fStack_34) {
      fStack_34 = *pfVar1;
    }
    fStack_8 = fStack_20;
    if (fStack_20 <= pfVar1[5]) {
      fStack_8 = pfVar1[5];
    }
    if (fStack_24 <= pfVar1[4]) {
      fStack_24 = pfVar1[4];
    }
    if (fStack_28 <= pfVar1[3]) {
      fStack_28 = pfVar1[3];
    }
    fStack_2c = fStack_14;
    fStack_20 = fStack_8;
  }
  FUN_008411b0(&fStack_34,param_2);
  if (((fStack_34 <= fStack_28) && (fStack_30 <= fStack_24)) && (fStack_2c <= fStack_20)) {
    FUN_007c7690(&fStack_34,1);
  }
  return;
}



/* FUNCTION 11677 ; VA 0x007b6e30 ; FUN_007b6e30 */

undefined4 __fastcall FUN_007b6e30(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x98);
  if ((uVar1 & 4) != 0) {
    return 0;
  }
  if ((uVar1 & 2) != 0) {
    *(uint *)(param_1 + 0x98) = uVar1 & 0xfffffffd | 1;
    FUN_007c8c00(param_1);
  }
  *(uint *)(param_1 + 0xcc) = *(uint *)(param_1 + 0xcc) & 0x7fffffff;
  return 1;
}



/* FUNCTION 11678 ; VA 0x007b6e70 ; FUN_007b6e70 */

void __thiscall FUN_007b6e70(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2db0;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  piStack_2c = param_1;
  piStack_20 = param_1;
  do {
    piVar5 = piStack_20;
    iVar3 = *piStack_20;
    uVar4 = piStack_20[1] - iVar3 >> 2;
    if (uVar4 != 0) {
      iStack_28 = iVar3;
      uStack_24 = uVar4;
      (**(code **)((int)&PTR_FUN_018fe530 + uStack_1c))(iVar3,uVar4);
      uStack_18 = 0;
      if (uVar4 != 0) {
        do {
          piStack_14 = (int *)(iVar3 + uStack_18 * 4);
          iVar3 = *(int *)(*piStack_14 + 0x20);
          piVar5 = (int *)(iVar3 + 0xc4);
          uVar4 = *(uint *)(*piStack_14 + 0x24) / DAT_01eb28b4;
          if ((uint)(*(int *)(iVar3 + 200) - *piVar5 >> 4) <= uVar4) {
            uStack_3c = 0;
            piStack_38 = (int *)0x0;
            uStack_34 = 0;
            uStack_30 = 2;
            uStack_8 = 0;
            FUN_007afc70(uVar4 + 1,piVar5,&uStack_3c);
            piVar2 = piStack_38;
            uStack_8 = 0xffffffff;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              iVar3 = piStack_38[1] + -1;
              piStack_38[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piStack_38)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar3 = *piVar1 + -1;
                *piVar1 = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
          }
          *(undefined4 *)(*piVar5 + 0xc + uVar4 * 0x10) = 1;
          iVar3 = *piStack_14;
          if (*(uint *)(iVar3 + 0x28) != 0xffffffff) {
            uVar4 = *(uint *)(iVar3 + 0x28) / DAT_01eb28b4;
            piVar5 = (int *)(*(int *)(iVar3 + 0x20) + 0x94);
            if ((uint)(*(int *)(*(int *)(iVar3 + 0x20) + 0x98) - *piVar5 >> 4) <= uVar4) {
              uStack_4c = 0;
              piStack_48 = (int *)0x0;
              uStack_44 = 0;
              uStack_40 = 2;
              uStack_8 = 1;
              FUN_007afc70(uVar4 + 1,piVar5,&uStack_4c);
              piVar2 = piStack_48;
              uStack_8 = 0xffffffff;
              if (piStack_48 != (int *)0x0) {
                LOCK();
                iVar3 = piStack_48[1] + -1;
                piStack_48[1] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)*piStack_48)();
                  LOCK();
                  piVar1 = piVar2 + 2;
                  iVar3 = *piVar1 + -1;
                  *piVar1 = iVar3;
                  UNLOCK();
                  if (iVar3 == 0) {
                    (**(code **)(*piVar2 + 4))();
                  }
                }
              }
            }
            *(undefined4 *)(*piVar5 + 0xc + uVar4 * 0x10) = 1;
            iVar3 = *piStack_14;
          }
          *(uint *)(iVar3 + 0x2c) = *(uint *)(iVar3 + 0x2c) & 0xffffff3f;
          uStack_18 = uStack_18 + 1;
          uVar4 = uStack_24;
          piVar5 = piStack_20;
          iVar3 = iStack_28;
        } while (uStack_18 < uStack_24);
      }
      *param_2 = *param_2 + uVar4;
      iVar3 = *piVar5;
    }
    uStack_1c = uStack_1c + 4;
    piVar5[1] = iVar3;
    piStack_20 = piVar5 + 3;
  } while (uStack_1c < 0x70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11679 ; VA 0x007b7070 ; FUN_007b7070 */

void __thiscall
FUN_007b7070(int param_1,int param_2,int param_3,undefined4 param_4,int param_5,undefined4 param_6)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  float *pfVar10;
  float10 fVar11;
  float fVar12;
  double dVar13;
  float fVar14;
  float fVar15;
  int iVar16;
  int iVar17;
  uint uStack_b8;
  int iStack_ac;
  int *piStack_a8;
  int iStack_a4;
  float fStack_a0;
  undefined8 uStack_9c;
  uint uStack_94;
  int iStack_90;
  int *piStack_8c;
  int iStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  int iStack_68;
  int *piStack_64;
  int iStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  int *piStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  float fStack_2c;
  ulonglong uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  float fStack_14;
  ulonglong uStack_10;
  
  uVar5 = *(uint *)(param_2 + 0xb8);
  if (*(int *)(param_1 + 0xa0) == *(int *)(param_1 + 0xa4)) {
    return;
  }
  if (*(int *)(*(int *)(param_1 + 0x54) + 4) != 4) {
    return;
  }
  if (*(int *)(param_1 + 0x5c) == 0) {
    return;
  }
  if ((*(uint *)(param_1 + 0xd0) & 2) != 0) {
    *(uint *)(param_1 + 0xd0) = *(uint *)(param_1 + 0xd0) & 0xfffffffd;
    *(int *)(*(int *)(param_1 + 4) + 0x34) =
         *(int *)(*(int *)(*(int *)(*(int *)(param_1 + 4) + 8) + 0x4e4) + 0x24) + 1;
    FUN_007c7690(param_1 + 100,1);
  }
  cVar2 = FUN_0078e3b0();
  if ((cVar2 != '\0') && ((*(byte *)(param_1 + 0xd0) & 4) != 0)) {
    FUN_0078e3b0();
    *(uint *)(param_1 + 0xd0) = *(uint *)(param_1 + 0xd0) & 0xfffffffb;
    *(int *)(*(int *)(param_1 + 4) + 0x34) =
         *(int *)(*(int *)(*(int *)(*(int *)(param_1 + 4) + 8) + 0x4e4) + 0x24) + 1;
    FUN_007c7690(param_1 + 100,1);
  }
  uVar3 = FUN_0078e450(param_6);
  piVar4 = (int *)FUN_0078e270(param_4,param_5,uVar3);
  if (piVar4 == (int *)0x0) {
    return;
  }
  if ((param_5 == 5) || (bVar1 = false, param_5 == 4)) {
    bVar1 = true;
  }
  uVar9 = *(uint *)(param_1 + 0x4c);
  if ((uVar9 & 0x20) == 0) {
    iVar16 = *(int *)(param_1 + 0x54);
    uStack_94 = *(uint *)(iVar16 + 0x15c);
    iVar7 = param_1 + 100;
    if (1 < uStack_94) {
      if ((int)uVar5 < 0) {
        if ((DAT_01d71798 == '\0') || ((uVar9 & 0x40) != 0)) {
          if ((!bVar1) || (DAT_01d60c28 == '\0')) goto LAB_007b720d;
          uStack_b8 = *(int *)(iVar16 + 0x160) - 1;
        }
        else if ((bVar1) && (DAT_01d60c28 != '\0')) {
          uStack_b8 = *(int *)(iVar16 + 0x164) - 1;
        }
        else {
LAB_007b720d:
          uStack_b8 = 0;
        }
      }
      else {
        uStack_b8 = *(int *)(iVar16 + 0x160) - 1;
        if (uVar5 <= *(int *)(iVar16 + 0x160) - 1U) {
          uStack_b8 = uVar5;
        }
      }
      if ((int)uVar5 < 0) {
        if (DAT_01d61b9c == '\0') {
          if (DAT_01d71798 != '\0') {
            if (DAT_01d61bac == '\0') {
              uVar6 = *(undefined4 *)(param_3 + 0x70);
            }
            else {
              uVar6 = *(undefined4 *)(param_3 + 0xc);
            }
            iVar16 = *(int *)(param_1 + 4);
            iVar17 = param_3;
            goto LAB_007b72a7;
          }
          uVar5 = FUN_007b5c20(*(undefined4 *)(param_1 + 4),param_3,iVar7);
        }
        else {
          iVar16 = *(int *)(param_1 + 4);
          if (DAT_01d71798 != '\0') {
            if (DAT_01d61bac == '\0') {
              uVar6 = *(undefined4 *)(param_3 + 0x70);
            }
            else {
              uVar6 = *(undefined4 *)(param_3 + 0xc);
            }
            iVar17 = *(int *)(*(int *)(iVar16 + 8) + 0x4f8) + 4;
LAB_007b72a7:
            uVar5 = FUN_007b5d70(iVar16,iVar17,iVar7,uVar6);
            goto LAB_007b72b5;
          }
          uVar5 = FUN_007b5c20(iVar16,*(int *)(*(int *)(iVar16 + 8) + 0x4f8) + 4,iVar7);
        }
LAB_007b72ea:
        uVar8 = uStack_94 - 1;
        if (uVar5 < uStack_94) {
          uVar8 = uVar5;
        }
      }
      else {
LAB_007b72b5:
        if ((DAT_01d71798 == '\0') || ((*(byte *)(param_1 + 0x4c) & 0x40) != 0)) goto LAB_007b72ea;
        uVar9 = *(uint *)(*(int *)(param_1 + 0x54) + 0x164);
        uVar8 = uVar9 - 1;
        if (uVar5 < uVar9) {
          uVar8 = uVar5;
        }
      }
      if (bVar1) {
        iStack_88 = uStack_b8 * 0x18 + 0xe4;
      }
      else {
        iStack_88 = uVar8 * 0x18 + 0x6c;
      }
      iStack_88 = iStack_88 + *(int *)(param_1 + 0x54);
      uVar9 = *(uint *)(param_1 + 0x4c);
      uStack_5c = 0;
      uStack_58 = 0;
      uStack_54 = 0;
      iStack_68 = param_1;
      piStack_64 = piVar4;
      iStack_60 = iStack_88;
      goto LAB_007b73ae;
    }
  }
  if (bVar1) {
    iStack_88 = *(int *)(param_1 + 0x54) + 0xe4;
  }
  else {
    iStack_88 = *(int *)(param_1 + 0x54) + 0x6c;
  }
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  iStack_50 = param_1;
  piStack_4c = piVar4;
  iStack_48 = iStack_88;
LAB_007b73ae:
  uStack_9c = 0;
  fStack_84 = 0.0;
  fStack_a0 = 0.0;
  pfVar10 = (float *)(param_1 + 100);
  iStack_ac = param_1;
  piStack_a8 = piVar4;
  iStack_a4 = iStack_88;
  iStack_90 = param_1;
  piStack_8c = piVar4;
  if ((uVar9 & 1) == 0) {
    if (param_5 == 3) {
      fStack_74 = (*(float *)(param_1 + 0x70) + *pfVar10) * DAT_018ce2f4;
      fStack_70 = (*(float *)(param_1 + 0x68) + *(float *)(param_1 + 0x74)) * DAT_018ce2f4;
      fStack_6c = (*(float *)(param_1 + 0x6c) + *(float *)(param_1 + 0x78)) * DAT_018ce2f4;
      fVar11 = (float10)FUN_00841650(param_3,&fStack_74,0);
      fStack_a0 = (float)fVar11;
      uVar6 = FUN_008418d0(fStack_a0);
      uStack_9c = CONCAT44(uVar6,(undefined4)uStack_9c);
      iStack_90 = iStack_ac;
      piStack_8c = piStack_a8;
      iStack_88 = iStack_a4;
      fStack_84 = fStack_a0;
    }
  }
  else {
    fStack_80 = (*pfVar10 + *(float *)(param_1 + 0x70)) * DAT_018ce2f4;
    fStack_7c = (*(float *)(param_1 + 0x68) + *(float *)(param_1 + 0x74)) * DAT_018ce2f4;
    fStack_78 = (*(float *)(param_1 + 0x6c) + *(float *)(param_1 + 0x78)) * DAT_018ce2f4;
    fVar11 = (float10)FUN_00841650(param_3,&fStack_80,
                                   *(undefined4 *)(&DAT_018fed54 + (uVar9 >> 1 & 1) * 4));
    fStack_a0 = (float)fVar11;
    if (DAT_01d60f98 == '\0') {
      uStack_9c = uStack_9c & 0xffffffff00000000;
      iStack_90 = iStack_ac;
      piStack_8c = piStack_a8;
      iStack_88 = iStack_a4;
      fStack_84 = fStack_a0;
    }
    else {
      fVar15 = *(float *)(param_1 + 0x74) - *(float *)(param_1 + 0x68);
      fVar14 = *(float *)(param_1 + 0x70) - *pfVar10;
      fVar12 = *(float *)(param_1 + 0x78) - *(float *)(param_1 + 0x6c);
      dVar13 = (double)(fVar15 * fVar15 + fVar14 * fVar14 + fVar12 * fVar12);
      FUN_017267a0();
      iStack_90 = iStack_ac;
      piStack_8c = piStack_a8;
      iStack_88 = iStack_a4;
      fStack_84 = fStack_a0;
      uStack_9c = CONCAT44(uStack_9c._4_4_,
                           (float)dVar13 * DAT_018ce2f4 +
                           (float)(double)CONCAT44((uint)((ulonglong)
                                                          (double)*(float *)(&DAT_018fed54 +
                                                                            (*(uint *)(param_1 +
                                                                                      0x4c) >> 1 & 1
                                                                            ) * 4) >> 0x20) &
                                                   DAT_018c0da0._4_4_,
                                                   SUB84((double)*(float *)(&DAT_018fed54 +
                                                                           (*(uint *)(param_1 + 0x4c
                                                                                     ) >> 1 & 1) * 4
                                                                           ),0) & (uint)DAT_018c0da0
                                                  ));
    }
  }
  iStack_ac = iStack_90;
  piStack_a8 = piStack_8c;
  iStack_a4 = iStack_88;
  fStack_a0 = fStack_84;
  if ((((*(int *)(param_1 + 8) == 8) && (param_5 == 0)) && (*piStack_8c != 0)) &&
     (iVar7 = FUN_0078e270(param_4,1,uVar3), iVar7 != 0)) {
    iStack_20 = iStack_90;
    iStack_18 = iStack_88;
    fStack_14 = fStack_84;
    uStack_10 = uStack_9c;
    iStack_1c = iVar7;
    FUN_007b4d60(&iStack_20);
  }
  if ((((*(byte *)(*(int *)(param_1 + 0x44) + 0x24) & 1) != 0) && (param_5 == 0)) &&
     (iVar7 = FUN_0078e270(param_4,6,uVar3), iVar7 != 0)) {
    iStack_38 = iStack_90;
    iStack_30 = iStack_88;
    uStack_28 = uStack_9c;
    fStack_2c = fStack_84 + DAT_018fd178;
    iStack_34 = iVar7;
    FUN_007b4d60(&iStack_38);
  }
  FUN_007b4d60(&iStack_ac);
  *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | *(uint *)(param_1 + 0x50);
  return;
}



/* FUNCTION 11680 ; VA 0x007b7670 ; FUN_007b7670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall FUN_007b7670(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  float *pfVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  uVar4 = _UNK_018c4ebc;
  uVar3 = _UNK_018c4eb8;
  uVar2 = _UNK_018c4eb4;
  uVar1 = DAT_018c45d0;
  if ((*(uint *)(param_1 + 0xd0) & 1) == 0) {
    return param_1 + 100;
  }
  *(undefined4 *)(param_1 + 100) = _DAT_018c4eb0;
  *(undefined4 *)(param_1 + 0x68) = uVar2;
  *(undefined4 *)(param_1 + 0x6c) = uVar3;
  *(undefined4 *)(param_1 + 0x70) = uVar4;
  *(uint *)(param_1 + 0xd0) = *(uint *)(param_1 + 0xd0) & 0xfffffffe;
  *(ulonglong *)(param_1 + 0x74) = CONCAT44(uVar1,uVar1);
  for (pfVar5 = *(float **)(param_1 + 0xb8); pfVar5 != *(float **)(param_1 + 0xbc);
      pfVar5 = pfVar5 + 6) {
    fVar8 = *(float *)(param_1 + 0x6c);
    if (pfVar5[2] <= *(float *)(param_1 + 0x6c)) {
      fVar8 = pfVar5[2];
    }
    fVar7 = *(float *)(param_1 + 0x68);
    if (pfVar5[1] <= *(float *)(param_1 + 0x68)) {
      fVar7 = pfVar5[1];
    }
    fVar6 = *(float *)(param_1 + 100);
    if (*pfVar5 <= *(float *)(param_1 + 100)) {
      fVar6 = *pfVar5;
    }
    *(ulonglong *)(param_1 + 100) = CONCAT44(fVar7,fVar6);
    *(float *)(param_1 + 0x6c) = fVar8;
    fVar8 = *(float *)(param_1 + 0x78);
    if (*(float *)(param_1 + 0x78) <= pfVar5[5]) {
      fVar8 = pfVar5[5];
    }
    fVar7 = *(float *)(param_1 + 0x74);
    if (*(float *)(param_1 + 0x74) <= pfVar5[4]) {
      fVar7 = pfVar5[4];
    }
    fVar6 = *(float *)(param_1 + 0x70);
    if (*(float *)(param_1 + 0x70) <= pfVar5[3]) {
      fVar6 = pfVar5[3];
    }
    *(ulonglong *)(param_1 + 0x70) = CONCAT44(fVar7,fVar6);
    *(float *)(param_1 + 0x78) = fVar8;
  }
  return param_1 + 100;
}



/* FUNCTION 11681 ; VA 0x007b7770 ; FUN_007b7770 */

void __fastcall FUN_007b7770(int param_1)

{
  if ((*(uint *)(param_1 + 0x2c) & 10) != 0) {
    *(uint *)(param_1 + 0x2c) = *(uint *)(param_1 + 0x2c) | 0x20;
    return;
  }
  FUN_007b4f80(param_1);
  return;
}



/* FUNCTION 11682 ; VA 0x007b77a0 ; FUN_007b77a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007b77a0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined uVar2;
  int iVar3;
  short sVar4;
  float fVar5;
  float fVar6;
  undefined8 *puVar7;
  undefined4 uVar8;
  undefined *puVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 *puStack_30;
  undefined4 uStack_2c;
  undefined8 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined8 *puStack_10;
  undefined8 *puStack_c;
  undefined4 *puStack_8;
  
  puStack_30 = *(undefined8 **)(param_2 + 0x1c);
  puStack_28 = (undefined8 *)(param_2 + 0x5c);
  puStack_10 = (undefined8 *)0x24;
  if (puStack_30 != (undefined8 *)0x6) {
    puStack_10 = (undefined8 *)0x6;
  }
  iVar10 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb2948) && (FUN_016f3809(&DAT_01eb2948), DAT_01eb2948 == -1))
  {
    DAT_01eb293c = -0.5;
    DAT_01eb2940 = -0.5;
    DAT_01eb2944 = -0.5;
    FUN_016f37bf(&DAT_01eb2948);
  }
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb2958) && (FUN_016f3809(&DAT_01eb2958), DAT_01eb2958 == -1))
  {
    _DAT_01eb294c = DAT_01d61bf8;
    DAT_01eb2954 = DAT_01d61c00;
    FUN_016f37bf(&DAT_01eb2958);
  }
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb2968) && (FUN_016f3809(&DAT_01eb2968), DAT_01eb2968 == -1))
  {
    _DAT_01eb295c = CONCAT44(DAT_01d61c04._4_4_,(uint)DAT_01d61c04);
    DAT_01eb2964 = DAT_01d61c0c;
    FUN_016f37bf(&DAT_01eb2968);
  }
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb2978) && (FUN_016f3809(&DAT_01eb2978), DAT_01eb2978 == -1))
  {
    _DAT_01eb296c = DAT_01d61c10;
    DAT_01eb2974 = DAT_01d61c18;
    FUN_016f37bf(&DAT_01eb2978);
  }
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb29e0) && (FUN_016f3809(&DAT_01eb29e0), DAT_01eb29e0 == -1))
  {
    _DAT_01eb2980 = CONCAT44(DAT_01eb2940,DAT_01eb293c);
    _DAT_01eb298c = DAT_01eb296c + DAT_01eb293c;
    _DAT_01eb2990 = DAT_01eb2970 + DAT_01eb2940;
    DAT_01eb29b0._0_4_ = DAT_01eb294c + DAT_01eb293c;
    DAT_01eb29b0._4_4_ = DAT_01eb2950 + DAT_01eb2940;
    _DAT_01eb2994 = DAT_01eb2974 + DAT_01eb2944;
    _DAT_01eb2998 = DAT_01eb295c + DAT_01eb293c;
    _DAT_01eb299c = DAT_01eb2960 + DAT_01eb2940;
    DAT_01eb29b8 = DAT_01eb2954 + DAT_01eb2944;
    _DAT_01eb29a0 = DAT_01eb2964 + DAT_01eb2944;
    _DAT_01eb29a4 = _DAT_01eb2998 + DAT_01eb296c;
    _DAT_01eb29a8 = _DAT_01eb299c + DAT_01eb2970;
    _DAT_01eb29ac = _DAT_01eb29a0 + DAT_01eb2974;
    DAT_01eb29bc._0_4_ = (float)DAT_01eb29b0 + DAT_01eb296c;
    DAT_01eb29bc._4_4_ = DAT_01eb29b0._4_4_ + DAT_01eb2970;
    DAT_01eb29c4 = DAT_01eb29b8 + DAT_01eb2974;
    DAT_01eb29c8._0_4_ = (float)DAT_01eb29b0 + DAT_01eb295c;
    DAT_01eb29c8._4_4_ = DAT_01eb29b0._4_4_ + DAT_01eb2960;
    DAT_01eb29d0 = DAT_01eb29b8 + DAT_01eb2964;
    DAT_01eb29d4._0_4_ = (float)DAT_01eb29c8 + DAT_01eb296c;
    DAT_01eb29d4._4_4_ = DAT_01eb29c8._4_4_ + DAT_01eb2970;
    DAT_01eb29dc = DAT_01eb29d0 + DAT_01eb2974;
    _DAT_01eb2988 = DAT_01eb2944;
    FUN_016f37bf(&DAT_01eb29e0);
  }
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb2a30) && (FUN_016f3809(&DAT_01eb2a30), DAT_01eb2a30 == -1))
  {
    _DAT_01eb2a0c = (uint)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2a10 = DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb29e8 = DAT_01d61bf8;
    _DAT_01eb29f4 = CONCAT44(DAT_01d61c04._4_4_,(uint)DAT_01d61c04);
    _DAT_01eb2a00 = DAT_01d61c10;
    _DAT_01eb2a14 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    _DAT_01eb2a18 = (uint)DAT_01d61c04 ^ DAT_018c4ea0;
    _DAT_01eb2a1c = DAT_01d61c04._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2a20 = (uint)DAT_01d61c0c ^ DAT_018c4ea0;
    _DAT_01eb2a24 = (uint)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01eb2a28 = DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    DAT_01eb29f0 = DAT_01d61c00;
    _DAT_01eb2a2c = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb29fc = DAT_01d61c0c;
    _DAT_01eb2a08 = DAT_01d61c18;
    FUN_016f37bf(&DAT_01eb2a30);
  }
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb2a80) && (FUN_016f3809(&DAT_01eb2a80), DAT_01eb2a80 == -1))
  {
    DAT_01eb2a3c = DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    DAT_01eb2a40 = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    DAT_01eb2a38 = (uint)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01eb2a44 = (uint)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2a48 = DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2a4c = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    _DAT_01eb2a58 = DAT_01d61c00;
    _DAT_01eb2a50 = DAT_01d61bf8;
    _DAT_01eb2a5c = DAT_01d61c10;
    _DAT_01eb2a64 = DAT_01d61c18;
    _DAT_01eb2a68 = _DAT_01eb2a44;
    _DAT_01eb2a6c = _DAT_01eb2a48;
    _DAT_01eb2a70 = _DAT_01eb2a4c;
    _DAT_01eb2a74 = _DAT_01eb2a44;
    _DAT_01eb2a78 = _DAT_01eb2a48;
    _DAT_01eb2a7c = _DAT_01eb2a4c;
    FUN_016f37bf(&DAT_01eb2a80);
  }
  uVar8 = 0x3c0;
  if (puStack_30 != (undefined8 *)0x6) {
    uVar8 = 0xa0;
  }
  FUN_00715060(uVar8,param_1);
  FUN_00727cd0(puStack_10,param_1 + 6);
  puVar7 = puStack_30;
  param_1[9] = 1;
  param_1[10] = 0x28;
  iVar10 = *param_1;
  puStack_18 = (undefined4 *)param_1[6];
  uVar8 = 0x240;
  if (puStack_30 != (undefined8 *)0x6) {
    uVar8 = 0x60;
  }
  FUN_00715060(uVar8,param_1 + 3);
  fVar6 = DAT_018f8ffc;
  fVar5 = DAT_018f8ff8;
  puStack_30 = (undefined8 *)param_1[3];
  if (puVar7 == (undefined8 *)0x6) {
    puVar9 = (undefined *)((int)puStack_30 + 0x24);
    puStack_8 = (undefined4 *)(iVar10 + 0x38);
    iVar10 = 0;
    puStack_c = (undefined8 *)0x0;
    piStack_5c = &DAT_018fee70;
    puStack_10 = (undefined8 *)0x6;
    do {
      uVar8 = DAT_018f993c;
      uVar11 = DAT_018ce2f4;
      switch(*(undefined *)((int)puStack_28 + (int)puStack_c)) {
      case 1:
      case 2:
        param_2._3_1_ = '\x01';
        break;
      case 3:
        param_2._3_1_ = '\0';
        break;
      case 4:
        param_2._3_1_ = '\x02';
        break;
      case 5:
        param_2._3_1_ = '\x03';
        break;
      default:
        param_2._3_1_ = '\0';
        uVar8 = 0;
        uVar11 = 0;
      }
      iVar3 = piStack_5c[-2];
      *(undefined8 *)(puStack_8 + -0xe) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
      puStack_8[-0xc] = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
      uVar2 = (&DAT_018feee0)[(int)puStack_c];
      puStack_8[-0xb] =
           CONCAT13(uVar2,CONCAT12((char)(int)(*(float *)((int)&DAT_01eb29f0 + iVar10) * fVar5 +
                                              fVar6),
                                   CONCAT11((char)(int)(*(float *)((int)&DAT_01eb29ec + iVar10) *
                                                        fVar5 + fVar6),
                                            (char)(int)(*(float *)((int)&DAT_01eb29e8 + iVar10) *
                                                        fVar5 + fVar6))));
      puStack_8[-10] = DAT_01d61c1c;
      puStack_8[-9] = DAT_01d61c20;
      puStack_8[-8] = uVar11;
      puStack_8[-7] = 0;
      puStack_8[-5] = 0xffffffff;
      param_2._3_1_ = param_2._3_1_ + '\x01';
      puStack_8[-6] =
           CONCAT13(param_2._3_1_,
                    CONCAT12((char)(int)(*(float *)((int)&DAT_01eb2a40 + iVar10) * fVar5 + fVar6),
                             CONCAT11((char)(int)(*(float *)((int)&DAT_01eb2a3c + iVar10) * fVar5 +
                                                 fVar6),
                                      (char)(int)(*(float *)((int)&DAT_01eb2a38 + iVar10) * fVar5 +
                                                 fVar6))));
      iVar3 = piStack_5c[-1];
      *(undefined8 *)(puStack_8 + -4) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
      puStack_8[-2] = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
      puStack_8[-1] =
           CONCAT13(uVar2,CONCAT12((char)(int)(*(float *)((int)&DAT_01eb29f0 + iVar10) * fVar5 +
                                              fVar6),
                                   CONCAT11((char)(int)(*(float *)((int)&DAT_01eb29ec + iVar10) *
                                                        fVar5 + fVar6),
                                            (char)(int)(*(float *)((int)&DAT_01eb29e8 + iVar10) *
                                                        fVar5 + fVar6))));
      *puStack_8 = DAT_01d61c24;
      puStack_8[1] = DAT_01d61c28;
      puStack_8[2] = 0;
      puStack_8[3] = 0;
      puStack_8[5] = 0xffffffff;
      puStack_8[4] = CONCAT13(param_2._3_1_,
                              CONCAT12((char)(int)(*(float *)((int)&DAT_01eb2a40 + iVar10) * fVar5 +
                                                  fVar6),
                                       CONCAT11((char)(int)(*(float *)((int)&DAT_01eb2a3c + iVar10)
                                                            * fVar5 + fVar6),
                                                (char)(int)(*(float *)((int)&DAT_01eb2a38 + iVar10)
                                                            * fVar5 + fVar6))));
      iVar3 = *piStack_5c;
      *(undefined8 *)(puStack_8 + 6) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
      puStack_8[8] = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
      puStack_8[9] = CONCAT13(uVar2,CONCAT12((char)(int)(*(float *)((int)&DAT_01eb29f0 + iVar10) *
                                                         fVar5 + fVar6),
                                             CONCAT11((char)(int)(*(float *)((int)&DAT_01eb29ec +
                                                                            iVar10) * fVar5 + fVar6)
                                                      ,(char)(int)(*(float *)((int)&DAT_01eb29e8 +
                                                                             iVar10) * fVar5 + fVar6
                                                                  ))));
      puStack_8[10] = DAT_01d61c2c;
      puStack_8[0xb] = DAT_01d61c30;
      puStack_8[0xc] = uVar11;
      puStack_8[0xd] = uVar8;
      puStack_8[0xf] = 0xffffffff;
      puStack_8[0xe] =
           CONCAT13(param_2._3_1_,
                    CONCAT12((char)(int)(*(float *)((int)&DAT_01eb2a40 + iVar10) * fVar5 + fVar6),
                             CONCAT11((char)(int)(*(float *)((int)&DAT_01eb2a3c + iVar10) * fVar5 +
                                                 fVar6),
                                      (char)(int)(*(float *)((int)&DAT_01eb2a38 + iVar10) * fVar5 +
                                                 fVar6))));
      iVar3 = piStack_5c[1];
      *(undefined8 *)(puStack_8 + 0x10) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
      puStack_8[0x12] = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
      puStack_8[0x13] =
           CONCAT13(uVar2,CONCAT12((char)(int)(*(float *)((int)&DAT_01eb29f0 + iVar10) * fVar5 +
                                              fVar6),
                                   CONCAT11((char)(int)(*(float *)((int)&DAT_01eb29ec + iVar10) *
                                                        fVar5 + fVar6),
                                            (char)(int)(*(float *)((int)&DAT_01eb29e8 + iVar10) *
                                                        fVar5 + fVar6))));
      puStack_8[0x14] = DAT_01d61c34;
      puStack_8[0x15] = DAT_01d61c38;
      puStack_8[0x16] = 0;
      puStack_8[0x17] = uVar8;
      puStack_8[0x19] = 0xffffffff;
      puStack_8[0x18] =
           CONCAT13(param_2._3_1_,
                    CONCAT12((char)(int)(*(float *)((int)&DAT_01eb2a40 + iVar10) * fVar5 + fVar6),
                             CONCAT11((char)(int)(*(float *)((int)&DAT_01eb2a3c + iVar10) * fVar5 +
                                                 fVar6),
                                      (char)(int)(*(float *)((int)&DAT_01eb2a38 + iVar10) * fVar5 +
                                                 fVar6))));
      if (puStack_30 != (undefined8 *)0x0) {
        iVar3 = piStack_5c[-2];
        *(undefined8 *)(puVar9 + -0x24) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + -0x1c) = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + -0x14) = DAT_01d61c1c;
        *(undefined4 *)(puVar9 + -0x10) = DAT_01d61c20;
        puVar9[-0x18] = uVar2;
        *(undefined2 *)(puVar9 + -0x17) = 0;
        puVar9[-0x15] = 0xff;
        iVar3 = piStack_5c[-1];
        *(undefined8 *)(puVar9 + -0xc) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + -4) = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + 4) = DAT_01d61c24;
        *(undefined4 *)(puVar9 + 8) = DAT_01d61c28;
        *puVar9 = uVar2;
        *(undefined2 *)(puVar9 + 1) = 0;
        puVar9[3] = 0xff;
        iVar3 = *piStack_5c;
        *(undefined8 *)(puVar9 + 0xc) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + 0x14) = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + 0x1c) = DAT_01d61c2c;
        *(undefined4 *)(puVar9 + 0x20) = DAT_01d61c30;
        puVar9[0x18] = uVar2;
        *(undefined2 *)(puVar9 + 0x19) = 0;
        puVar9[0x1b] = 0xff;
        iVar3 = piStack_5c[1];
        *(undefined8 *)(puVar9 + 0x24) = *(undefined8 *)(&DAT_01eb2980 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + 0x2c) = *(undefined4 *)(&DAT_01eb2988 + iVar3 * 0xc);
        *(undefined4 *)(puVar9 + 0x34) = DAT_01d61c34;
        *(undefined4 *)(puVar9 + 0x38) = DAT_01d61c38;
        puVar9[0x30] = uVar2;
        *(undefined2 *)(puVar9 + 0x31) = 0;
        puVar9[0x33] = 0xff;
      }
      puVar9 = puVar9 + 0x60;
      sVar4 = (short)((int)puStack_c << 2);
      puStack_8 = puStack_8 + 0x28;
      *(short *)(iVar10 + 2 + (int)puStack_18) = sVar4 + 1;
      *(short *)(iVar10 + (int)puStack_18) = sVar4;
      *(short *)(iVar10 + 4 + (int)puStack_18) = sVar4 + 2;
      *(short *)(iVar10 + 6 + (int)puStack_18) = sVar4 + 2;
      *(short *)(iVar10 + 8 + (int)puStack_18) = sVar4 + 1;
      piStack_5c = piStack_5c + 5;
      *(short *)(iVar10 + 10 + (int)puStack_18) = sVar4 + 3;
      iVar10 = iVar10 + 0xc;
      puStack_c = (undefined8 *)((int)puStack_c + 1);
      puStack_10 = (undefined8 *)((int)puStack_10 + -1);
    } while (puStack_10 != (undefined8 *)0x0);
    return;
  }
  uStack_24 = 0;
  uStack_20 = 0;
  iVar3 = *(int *)(param_2 + 0x1c);
  uStack_1c = 0;
  uStack_60 = 0;
  piStack_5c = (int *)0x0;
  uVar2 = (&DAT_018feee0)[iVar3];
  puStack_c = (undefined8 *)(iVar3 * 0x10);
  puVar1 = &DAT_01eb29e8 + iVar3 * 3;
  uStack_2c = 0x3f800000;
  puStack_28 = (undefined8 *)0x0;
  puStack_10 = (undefined8 *)(&DAT_01eb2980 + *(int *)(&DAT_018feee8 + (int)puStack_c) * 0xc);
  FUN_007be400(iVar10,puStack_10,puVar1,&uStack_2c,&uStack_60,&uStack_24,uVar2,0);
  uStack_58 = 0;
  uStack_54 = 0;
  piStack_5c = (int *)(&DAT_01eb2980 + *(int *)(&DAT_018feeec + (int)puStack_c) * 0xc);
  uStack_50 = 0;
  uStack_2c = 0;
  puStack_28 = (undefined8 *)0x0;
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_007be400(iVar10 + 0x28,piStack_5c,puVar1,&uStack_20,&uStack_2c,&uStack_58,uVar2,0);
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_54 = 0x3f800000;
  puStack_28 = (undefined8 *)(&DAT_01eb2980 + *(int *)(&DAT_018feef0 + (int)puStack_c) * 0xc);
  uStack_50 = 0x3f800000;
  FUN_007be400(iVar10 + 0x50,puStack_28,puVar1,&uStack_54,&uStack_20,&uStack_6c,uVar2,0);
  uStack_6c = 0;
  uStack_68 = 0;
  puStack_c = (undefined8 *)(&DAT_01eb2980 + *(int *)(&DAT_018feef4 + (int)puStack_c) * 0xc);
  uStack_64 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_54 = 0;
  uStack_50 = 0x3f800000;
  FUN_007be400(iVar10 + 0x78,puStack_c,puVar1,&uStack_54,&uStack_20,&uStack_6c,uVar2,0);
  if (puStack_30 != (undefined8 *)0x0) {
    *puStack_30 = *puStack_10;
    *(undefined4 *)(puStack_30 + 1) = *(undefined4 *)(puStack_10 + 1);
    *(undefined4 *)(puStack_30 + 2) = 0x3f800000;
    *(undefined4 *)((int)puStack_30 + 0x14) = 0;
    *(undefined *)((int)puStack_30 + 0xc) = uVar2;
    *(undefined2 *)((int)puStack_30 + 0xd) = 0;
    *(undefined *)((int)puStack_30 + 0xf) = 0xff;
    puStack_30[3] = *(undefined8 *)piStack_5c;
    *(undefined4 *)(puStack_30 + 4) = *(undefined4 *)((int)piStack_5c + 8);
    *(undefined *)((int)puStack_30 + 0x24) = uVar2;
    *(undefined2 *)((int)puStack_30 + 0x25) = 0;
    *(undefined *)((int)puStack_30 + 0x27) = 0xff;
    *(undefined4 *)(puStack_30 + 5) = 0;
    *(undefined4 *)((int)puStack_30 + 0x2c) = 0;
    puStack_30[6] = *puStack_28;
    *(undefined4 *)(puStack_30 + 7) = *(undefined4 *)(puStack_28 + 1);
    *(undefined4 *)(puStack_30 + 8) = 0x3f800000;
    *(undefined4 *)((int)puStack_30 + 0x44) = 0x3f800000;
    *(undefined *)((int)puStack_30 + 0x3c) = uVar2;
    *(undefined2 *)((int)puStack_30 + 0x3d) = 0;
    *(undefined *)((int)puStack_30 + 0x3f) = 0xff;
    puStack_30[9] = *puStack_c;
    *(undefined4 *)(puStack_30 + 10) = *(undefined4 *)(puStack_c + 1);
    *(undefined4 *)(puStack_30 + 0xb) = 0;
    *(undefined4 *)((int)puStack_30 + 0x5c) = 0x3f800000;
    *(undefined *)((int)puStack_30 + 0x54) = uVar2;
    *(undefined2 *)((int)puStack_30 + 0x55) = 0;
    *(undefined *)((int)puStack_30 + 0x57) = 0xff;
  }
  *puStack_18 = 0x10000;
  puStack_18[1] = 0x20002;
  puStack_18[2] = 0x30001;
  return;
}



/* FUNCTION 11683 ; VA 0x007b86c0 ; FUN_007b86c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007b86c0(int *param_1,int *param_2)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined uVar4;
  byte bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  short sVar13;
  short sVar14;
  float *pfVar15;
  int iVar16;
  float *pfVar17;
  float *pfVar18;
  float *pfVar19;
  int iVar20;
  char cVar21;
  short sVar22;
  int iVar23;
  int iVar24;
  undefined *puVar25;
  byte *pbVar26;
  float *pfVar27;
  short sVar28;
  int iVar29;
  short *psVar30;
  uint uVar31;
  short *psVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  double dVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  undefined8 uVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  float fVar47;
  uint uStack_210;
  float *pfStack_20c;
  uint uStack_208;
  int iStack_204;
  float fStack_1fc;
  float fStack_1f8;
  float fStack_1f0;
  byte *pbStack_1e4;
  float *pfStack_1dc;
  int iStack_1d4;
  undefined *puStack_1d0;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  float fStack_1ac;
  float fStack_1a8;
  float fStack_1a4;
  float fStack_1a0;
  int iStack_19c;
  float fStack_18c;
  float fStack_188;
  float fStack_180;
  float fStack_17c;
  undefined8 uStack_178;
  undefined8 uStack_16c;
  float fStack_158;
  float fStack_154;
  float fStack_14c;
  float fStack_f4;
  float fStack_f0;
  float fStack_e8;
  float fStack_e4;
  float fStack_d0;
  float fStack_cc;
  float fStack_b8;
  float fStack_b4;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  uint uStack_90;
  float fStack_8c;
  float fStack_88;
  uint uStack_84;
  float fStack_80;
  float fStack_7c;
  uint uStack_78;
  float fStack_74;
  float fStack_70;
  uint uStack_6c;
  float fStack_68;
  float afStack_64 [3];
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  float fStack_38;
  undefined8 uStack_34;
  float fStack_2c;
  longlong lStack_28;
  float fStack_20;
  float fStack_14;
  undefined auStack_10 [12];
  
  uStack_210 = 0x72;
  iVar6 = param_2[7];
  iVar7 = *param_2;
  iVar23 = 0x18;
  iVar29 = 0x30;
  if (iVar6 == 6) goto LAB_007b8750;
  if (iVar7 == 5) {
    switch(iVar6) {
    case 0:
      iVar29 = 1;
      break;
    case 1:
      iVar29 = 3;
      break;
    default:
      goto switchD_007b86fd_caseD_2;
    case 3:
      iVar29 = 4;
      break;
    case 4:
      iVar29 = 0;
    }
  }
  else {
switchD_007b86fd_caseD_2:
    iVar29 = iVar6;
  }
  if (iVar29 % 3 == 0) {
    uStack_210 = 0x1d;
    iVar29 = 0x18;
    iVar23 = 0;
  }
  else {
    uStack_210 = 0xe;
    iVar23 = 6;
    iVar29 = 0;
  }
LAB_007b8750:
  iVar24 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2a90) && (FUN_016f3809(&DAT_01eb2a90), DAT_01eb2a90 == -1))
  {
    DAT_01eb2a84 = ((float)((uint)(float)DAT_01d61bf8 ^ DAT_018c4ea0) - (float)DAT_01d61c04) -
                   (float)DAT_01d61c10;
    DAT_01eb2a88 = ((float)((uint)DAT_01d61bf8._4_4_ ^ DAT_018c4ea0) - DAT_01d61c04._4_4_) -
                   DAT_01d61c10._4_4_;
    DAT_01eb2a8c = ((float)((uint)DAT_01d61c00 ^ DAT_018c4ea0) - DAT_01d61c0c) - DAT_01d61c18;
    FUN_016f37bf(&DAT_01eb2a90);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2aa0) && (FUN_016f3809(&DAT_01eb2aa0), DAT_01eb2aa0 == -1))
  {
    DAT_01eb2a94 = (float)DAT_01d61bf8 * DAT_018daf58;
    DAT_01eb2a98 = DAT_01d61bf8._4_4_ * DAT_018daf58;
    DAT_01eb2a9c = DAT_01d61c00 * DAT_018daf58;
    FUN_016f37bf(&DAT_01eb2aa0);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2ab0) && (FUN_016f3809(&DAT_01eb2ab0), DAT_01eb2ab0 == -1))
  {
    DAT_01eb2aa4 = (float)DAT_01d61c04 * DAT_018daf58;
    DAT_01eb2aa8 = DAT_01d61c04._4_4_ * DAT_018daf58;
    DAT_01eb2aac = DAT_01d61c0c * DAT_018daf58;
    FUN_016f37bf(&DAT_01eb2ab0);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2ac0) && (FUN_016f3809(&DAT_01eb2ac0), DAT_01eb2ac0 == -1))
  {
    DAT_01eb2ab4 = (float)DAT_01d61c10 * DAT_018daf58;
    DAT_01eb2ab8 = DAT_01d61c10._4_4_ * DAT_018daf58;
    DAT_01eb2abc = DAT_01d61c18 * DAT_018daf58;
    FUN_016f37bf(&DAT_01eb2ac0);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2b28) && (FUN_016f3809(&DAT_01eb2b28), DAT_01eb2b28 == -1))
  {
    DAT_01eb2ac8 = CONCAT44(DAT_01eb2a88,DAT_01eb2a84);
    DAT_01eb2ad4._0_4_ = DAT_01eb2ab4 + DAT_01eb2a84;
    DAT_01eb2ad4._4_4_ = DAT_01eb2ab8 + DAT_01eb2a88;
    DAT_01eb2af8._0_4_ = DAT_01eb2a94 + DAT_01eb2a84;
    DAT_01eb2af8._4_4_ = DAT_01eb2a98 + DAT_01eb2a88;
    DAT_01eb2adc = DAT_01eb2abc + DAT_01eb2a8c;
    DAT_01eb2ae0._0_4_ = DAT_01eb2aa4 + DAT_01eb2a84;
    DAT_01eb2ae0._4_4_ = DAT_01eb2aa8 + DAT_01eb2a88;
    DAT_01eb2b00 = DAT_01eb2a9c + DAT_01eb2a8c;
    DAT_01eb2ae8 = DAT_01eb2aac + DAT_01eb2a8c;
    DAT_01eb2aec._0_4_ = (float)DAT_01eb2ae0 + DAT_01eb2ab4;
    DAT_01eb2aec._4_4_ = DAT_01eb2ae0._4_4_ + DAT_01eb2ab8;
    DAT_01eb2af4 = DAT_01eb2ae8 + DAT_01eb2abc;
    DAT_01eb2b04._0_4_ = (float)DAT_01eb2af8 + DAT_01eb2ab4;
    DAT_01eb2b04._4_4_ = DAT_01eb2af8._4_4_ + DAT_01eb2ab8;
    DAT_01eb2b0c = DAT_01eb2b00 + DAT_01eb2abc;
    DAT_01eb2b10._0_4_ = (float)DAT_01eb2af8 + DAT_01eb2aa4;
    DAT_01eb2b10._4_4_ = DAT_01eb2af8._4_4_ + DAT_01eb2aa8;
    DAT_01eb2b18 = DAT_01eb2b00 + DAT_01eb2aac;
    DAT_01eb2b1c._0_4_ = (float)DAT_01eb2b10 + DAT_01eb2ab4;
    DAT_01eb2b1c._4_4_ = DAT_01eb2b10._4_4_ + DAT_01eb2ab8;
    DAT_01eb2b24 = DAT_01eb2b18 + DAT_01eb2abc;
    DAT_01eb2ad0 = DAT_01eb2a8c;
    FUN_016f37bf(&DAT_01eb2b28);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2b78) && (FUN_016f3809(&DAT_01eb2b78), DAT_01eb2b78 == -1))
  {
    _DAT_01eb2b3c = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    DAT_01eb2b30 = (uint)(float)DAT_01d61c04 ^ DAT_018c4ea0;
    DAT_01eb2b34 = (uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0;
    DAT_01eb2b38 = (uint)DAT_01d61c0c ^ DAT_018c4ea0;
    _DAT_01eb2b40 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2b44 = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb2b60 = DAT_01d61c10;
    _DAT_01eb2b68 = DAT_01d61c18;
    _DAT_01eb2b48 = DAT_01eb2b30;
    _DAT_01eb2b4c = DAT_01eb2b34;
    _DAT_01eb2b50 = DAT_01eb2b38;
    _DAT_01eb2b54 = DAT_01eb2b30;
    _DAT_01eb2b58 = DAT_01eb2b34;
    _DAT_01eb2b5c = DAT_01eb2b38;
    _DAT_01eb2b6c = DAT_01eb2b30;
    _DAT_01eb2b70 = DAT_01eb2b34;
    _DAT_01eb2b74 = DAT_01eb2b38;
    FUN_016f37bf(&DAT_01eb2b78);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2bc8) && (FUN_016f3809(&DAT_01eb2bc8), DAT_01eb2bc8 == -1))
  {
    _DAT_01eb2b98 = (uint)(float)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2b9c = (uint)DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2b80 = DAT_01d61c10;
    _DAT_01eb2ba0 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    _DAT_01eb2ba4 = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01eb2ba8 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    DAT_01eb2b88 = DAT_01d61c18;
    _DAT_01eb2bac = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb2b8c = DAT_01d61bf8;
    _DAT_01eb2b94 = DAT_01d61c00;
    _DAT_01eb2bb0 = DAT_01d61bf8;
    _DAT_01eb2bb8 = DAT_01d61c00;
    _DAT_01eb2bbc = DAT_01d61bf8;
    _DAT_01eb2bc4 = DAT_01d61c00;
    FUN_016f37bf(&DAT_01eb2bc8);
  }
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2c60) && (FUN_016f3809(&DAT_01eb2c60), DAT_01eb2c60 == -1))
  {
    _DAT_01eb2bd4 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2bd8 = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb2bd0 = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01eb2bdc = (uint)(float)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2be0 = (uint)DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2be4 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    _DAT_01eb2be8 = DAT_01d61bf8;
    _DAT_01eb2c18 = DAT_01d61bf8;
    _DAT_01eb2bf4 = DAT_01d61c10;
    _DAT_01eb2bfc = DAT_01d61c18;
    _DAT_01eb2c30 = (uint)(float)DAT_01d61c04 ^ DAT_018c4ea0;
    _DAT_01eb2c34 = (uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2c38 = (uint)DAT_01d61c0c ^ DAT_018c4ea0;
    _DAT_01eb2bf0 = DAT_01d61c00;
    _DAT_01eb2c20 = DAT_01d61c00;
    _DAT_01eb2c24 = DAT_01d61c04;
    _DAT_01eb2c2c = DAT_01d61c0c;
    _DAT_01eb2c48 = DAT_01d61c04;
    _DAT_01eb2c50 = DAT_01d61c0c;
    _DAT_01eb2c54 = DAT_01d61c04;
    _DAT_01eb2c5c = DAT_01d61c0c;
    _DAT_01eb2c00 = _DAT_01eb2bdc;
    _DAT_01eb2c04 = _DAT_01eb2be0;
    _DAT_01eb2c08 = _DAT_01eb2be4;
    _DAT_01eb2c0c = _DAT_01eb2bdc;
    _DAT_01eb2c10 = _DAT_01eb2be0;
    _DAT_01eb2c14 = _DAT_01eb2be4;
    _DAT_01eb2c3c = _DAT_01eb2bdc;
    _DAT_01eb2c40 = _DAT_01eb2be0;
    _DAT_01eb2c44 = _DAT_01eb2be4;
    FUN_016f37bf(&DAT_01eb2c60);
  }
  iStack_204 = 0;
  iStack_19c = 0;
  FUN_00715060(uStack_210 * 0x28,param_1);
  FUN_00727cd0((iVar29 + iVar23 * 2) * 3,param_1 + 6);
  param_1[9] = 1;
  param_1[10] = 0x28;
  iVar29 = *param_1;
  iVar23 = param_1[6];
  FUN_00715060(uStack_210 * 0x18,param_1 + 3);
  iVar8 = param_1[3];
  if ((*(int *)(iVar24 + 0x34) < DAT_01eb2c64) && (FUN_016f3809(&DAT_01eb2c64), DAT_01eb2c64 == -1))
  {
    _DAT_01d61c40 = CONCAT44(DAT_01eb2b10._4_4_,(float)DAT_01eb2b10);
    _DAT_01d61c70 = (uint)(float)DAT_01d61c04 ^ DAT_018c4ea0;
    _DAT_01d61c78 = (uint)DAT_01d61c0c ^ DAT_018c4ea0;
    _DAT_01d61c94 = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01d61c4c = CONCAT44(DAT_01eb2af8._4_4_,(float)DAT_01eb2af8);
    _DAT_01d61c58 = CONCAT44(DAT_01eb2b04._4_4_,(float)DAT_01eb2b04);
    _DAT_01d61c64 = CONCAT44(DAT_01eb2b1c._4_4_,(float)DAT_01eb2b1c);
    _DAT_01d61cb4 = CONCAT44(DAT_01eb2aec._4_4_,(float)DAT_01eb2aec);
    _DAT_01d61c74 = (uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0;
    _DAT_01d61c98 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    _DAT_01d61c48 = DAT_01eb2b18;
    _DAT_01d61c54 = DAT_01eb2b00;
    _DAT_01d61cc0 = CONCAT44(DAT_01eb2ad4._4_4_,(float)DAT_01eb2ad4);
    _DAT_01d61c60 = DAT_01eb2b0c;
    _DAT_01d61c6c = DAT_01eb2b24;
    _DAT_01d61cbc = DAT_01eb2af4;
    _DAT_01d61ccc = DAT_01eb2ac8;
    _DAT_01d61cd8 = CONCAT44(DAT_01eb2ae0._4_4_,(float)DAT_01eb2ae0);
    _DAT_01d61c88 = DAT_01d61c04;
    _DAT_01d61c9c = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01d61cc8 = DAT_01eb2adc;
    _DAT_01d61cd4 = DAT_01eb2ad0;
    _DAT_01d61c7c = DAT_01d61c10;
    _DAT_01d61c84 = DAT_01d61c18;
    _DAT_01d61c90 = DAT_01d61c0c;
    _DAT_01d61ce0 = DAT_01eb2ae8;
    _DAT_01d61cfc = (uint)(float)DAT_01d61c04;
    uRam01d61d00 = (uint)DAT_01d61c04._4_4_;
    _DAT_01d61d04 = DAT_01d61c0c;
    _DAT_01d61d08 = DAT_01d61c10;
    _DAT_01d61d10 = DAT_01d61c18;
    _DAT_01d61ce4 = _DAT_01d61c70;
    _DAT_01d61ce8 = _DAT_01d61c74;
    _DAT_01d61cec = _DAT_01d61c78;
    _DAT_01d61cf0 = _DAT_01d61c94;
    _DAT_01d61cf4 = _DAT_01d61c98;
    _DAT_01d61cf8 = _DAT_01d61c9c;
    FUN_016f37bf(&DAT_01eb2c64);
  }
  iVar24 = 0;
  if (iVar7 == 5) {
    iVar24 = 6;
  }
  uStack_210 = 0;
  fVar38 = DAT_018f8ff8;
  fVar41 = DAT_018f8ffc;
  fVar44 = DAT_018ce2f4;
  fVar40 = DAT_018ce2f8;
  fVar46 = DAT_018f9940;
  do {
    if (iVar6 == 6) {
LAB_007b8903:
      sVar13 = (short)iStack_204;
      if (uStack_210 == (uStack_210 / 3) * 3) {
        uVar31 = -(uint)(uStack_210 != 0) & 0x74;
        uVar2 = *(undefined8 *)((int)&DAT_01d61ca0 + uVar31);
        fVar46 = *(float *)((int)&DAT_01d61ca8 + uVar31);
        fStack_188 = (float)((ulonglong)uVar2 >> 0x20);
        if ((NAN(fStack_188) == (fStack_188 == 0.0)) ||
           (fVar40 = fStack_188, fVar33 = fVar46, NAN(fVar46) == (fVar46 == 0.0))) {
          dVar37 = (double)(fVar46 * fVar46 + fStack_188 * fStack_188);
          FUN_017267a0();
          fVar38 = DAT_018f8ff8;
          fVar41 = DAT_018f8ffc;
          fVar44 = DAT_018ce2f4;
          fVar40 = (DAT_018ce2f8 / (float)dVar37) * fStack_188;
          fVar33 = (DAT_018ce2f8 / (float)dVar37) * fVar46;
        }
        fStack_18c = (float)uVar2;
        fVar33 = fVar33 * fVar44;
        if (iVar7 == 5) {
          fStack_14 = fVar33;
          fStack_94 = fStack_188;
          pfVar15 = &fStack_94;
          uVar43 = CONCAT44((uint)(fStack_18c * fVar44) ^ DAT_018c4ea0,fVar40 * fVar44);
          uStack_90 = (uint)fStack_18c ^ DAT_018c4ea0;
          fStack_8c = fVar46;
        }
        else {
          uVar43 = CONCAT44(fVar40 * fVar44,fStack_18c * fVar44);
          uStack_50 = *(undefined4 *)((int)&DAT_01d61ca8 + uVar31);
          pfVar15 = (float *)&uStack_58;
          uStack_58 = *(undefined8 *)((int)&DAT_01d61ca0 + uVar31);
        }
        uVar3 = *(undefined8 *)pfVar15;
        fVar40 = pfVar15[2];
        iVar16 = 0;
        fStack_f4 = (float)uVar3;
        if (iVar7 == 5) {
          iVar16 = 6;
        }
        iVar16 = iVar16 + uStack_210;
        *(undefined8 *)(iVar29 + iStack_204 * 0x28) = uVar43;
        *(float *)(iVar29 + 8 + iStack_204 * 0x28) = fVar33;
        fStack_f0 = (float)((ulonglong)uVar3 >> 0x20);
        uVar4 = (&DAT_018fef48)[iVar16];
        *(uint *)(iVar29 + 0xc + iStack_204 * 0x28) =
             CONCAT13(uVar4,CONCAT12((char)(int)(fVar40 * fVar38 + fVar41),
                                     CONCAT11((char)(int)(fStack_f0 * fVar38 + fVar41),
                                              (char)(int)(fStack_f4 * fVar38 + fVar41))));
        *(undefined4 *)(iVar29 + 0x10 + iStack_204 * 0x28) = 0x3f000000;
        *(undefined4 *)(iVar29 + 0x14 + iStack_204 * 0x28) = 0x3f000000;
        *(undefined4 *)(iVar29 + 0x18 + iStack_204 * 0x28) = 0;
        *(undefined4 *)(iVar29 + 0x1c + iStack_204 * 0x28) = 0;
        *(undefined4 *)(iVar29 + 0x24 + iStack_204 * 0x28) = 0xffffffff;
        uStack_1c8 = CONCAT13(1,CONCAT12((char)(int)(*(float *)(&DAT_01eb2bd8 + iVar16 * 0xc) *
                                                     fVar38 + fVar41),
                                         CONCAT11((char)(int)(*(float *)(&DAT_01eb2bd4 +
                                                                        iVar16 * 0xc) * fVar38 +
                                                             fVar41),
                                                  (char)(int)(*(float *)(&DAT_01eb2bd0 +
                                                                        iVar16 * 0xc) * fVar38 +
                                                             fVar41))));
        *(undefined4 *)(iVar29 + 0x20 + iStack_204 * 0x28) = uStack_1c8;
        if (iVar8 != 0) {
          *(undefined8 *)(iVar8 + iStack_204 * 0x18) = uVar43;
          *(float *)(iVar8 + 8 + iStack_204 * 0x18) = fVar33;
          *(undefined4 *)(iVar8 + 0x10 + iStack_204 * 0x18) = 0x3f000000;
          *(undefined4 *)(iVar8 + 0x14 + iStack_204 * 0x18) = 0x3f000000;
          *(undefined *)(iVar8 + 0xc + iStack_204 * 0x18) = uVar4;
          *(undefined2 *)(iVar8 + 0xd + iStack_204 * 0x18) = 0;
          *(undefined *)(iVar8 + 0xf + iStack_204 * 0x18) = 0xff;
        }
        pfStack_20c = (float *)0x4;
        pbStack_1e4 = (byte *)(iStack_204 + 1);
        iVar20 = iStack_204 * 0x28;
        iVar1 = iStack_204 * 0x18;
        iStack_204 = iStack_204 + 0x1d;
        pfVar15 = (float *)(&DAT_01d61c78 + uVar31);
        pfStack_1dc = (float *)(iVar29 + iVar20 + 0x38);
        puStack_1d0 = (undefined *)(iVar1 + 0x24 + iVar8);
        do {
          fVar33 = pfVar15[-0xc];
          fStack_e8 = (float)*(undefined8 *)(pfVar15 + -0xe);
          puVar25 = puStack_1d0 + 0xa8;
          fVar39 = (pfVar15[-1] + pfVar15[-1]) * DAT_018f9940;
          pfVar27 = pfStack_1dc + 0x46;
          iStack_1d4 = 7;
          fVar34 = (pfVar15[-2] + pfVar15[-2]) * DAT_018f9940;
          fVar42 = (*pfVar15 + *pfVar15) * DAT_018f9940;
          fStack_e4 = (float)((ulonglong)*(undefined8 *)(pfVar15 + -0xe) >> 0x20);
          do {
            if ((NAN(fStack_e4) == (fStack_e4 == 0.0)) ||
               (fVar40 = fStack_e4, fVar38 = fVar33, NAN(fVar33) == (fVar33 == 0.0))) {
              dVar37 = (double)(fVar33 * fVar33 + fStack_e4 * fStack_e4);
              FUN_017267a0();
              fVar40 = (DAT_018ce2f8 / (float)dVar37) * fStack_e4;
              fVar44 = DAT_018ce2f4;
              fVar38 = (DAT_018ce2f8 / (float)dVar37) * fVar33;
            }
            if (iVar7 == 5) {
              uStack_84 = (uint)(fStack_e8 * fVar44) ^ DAT_018c4ea0;
              pfVar17 = &fStack_88;
              fStack_88 = fVar40 * fVar44;
              fStack_80 = fVar38 * fVar44;
            }
            else {
              uStack_4c = CONCAT44(fVar40 * fVar44,fStack_e8 * fVar44);
              pfVar17 = (float *)&uStack_4c;
              fStack_44 = fVar38 * fVar44;
            }
            fStack_9c = fVar40;
            fStack_98 = fVar38;
            pfVar18 = (float *)FUN_01163210(auStack_10);
            fVar41 = DAT_018f8ffc;
            fVar38 = DAT_018f8ff8;
            fVar40 = DAT_018ce2f8;
            fVar44 = DAT_018ce2f4;
            if (iVar7 != 5) {
              fStack_a4 = *pfVar18;
              fStack_a0 = pfVar18[1];
              pfVar19 = &fStack_a4;
            }
            else {
              pfVar19 = &fStack_ac;
              fStack_ac = (float)((uint)pfVar18[1] ^ DAT_018c4ea0);
              fStack_a8 = *pfVar18;
            }
            fVar35 = (*pfVar19 * *(float *)(&DAT_01d61cac + uVar31) + DAT_018ce2f8) * DAT_018ce2f4;
            fVar36 = (*(float *)(&DAT_01d61cb0 + uVar31) * pfVar19[1] + DAT_018ce2f8) * DAT_018ce2f4
            ;
            if (iVar7 != 5) {
              fStack_38 = fVar46;
              pfVar18 = (float *)&uStack_40;
              uStack_40 = uVar2;
            }
            else {
              pfVar18 = &fStack_7c;
              fStack_7c = fStack_188;
              uStack_78 = (uint)fStack_18c ^ DAT_018c4ea0;
              fStack_74 = fVar46;
            }
            fVar45 = pfVar18[2];
            fStack_158 = (float)*(undefined8 *)pfVar18;
            fStack_154 = (float)((ulonglong)*(undefined8 *)pfVar18 >> 0x20);
            if ((iVar6 == 6) || (iVar7 != 5)) {
              fVar47 = pfVar17[2];
              *(undefined8 *)(pfStack_1dc + -4) = *(undefined8 *)pfVar17;
              pfStack_1dc[-2] = fVar47;
              uVar4 = (&DAT_018fef48)[iVar16];
              pfStack_1dc[-1] =
                   (float)CONCAT13(uVar4,CONCAT12((char)(int)(fVar45 * fVar38 + fVar41),
                                                  CONCAT11((char)(int)(fStack_154 * fVar38 + fVar41)
                                                           ,(char)(int)(fStack_158 * fVar38 + fVar41
                                                                       ))));
              *pfStack_1dc = fVar35;
              pfStack_1dc[1] = fVar36;
              pfStack_1dc[2] = 0.0;
              pfStack_1dc[3] = 0.0;
              pfStack_1dc[5] = -NAN;
              uStack_1bc = (float)CONCAT13(1,CONCAT12((char)(int)(*(float *)(&DAT_01eb2bd8 +
                                                                            iVar16 * 0xc) * fVar38 +
                                                                 fVar41),
                                                      CONCAT11((char)(int)(*(float *)(&DAT_01eb2bd4
                                                                                     + iVar16 * 0xc)
                                                                           * fVar38 + fVar41),
                                                               (char)(int)(*(float *)(&DAT_01eb2bd0
                                                                                     + iVar16 * 0xc)
                                                                           * fVar38 + fVar41))));
              pfStack_1dc[4] = uStack_1bc;
              if (iVar8 != 0) {
                fVar45 = pfVar17[2];
                *(undefined8 *)(puStack_1d0 + -0xc) = *(undefined8 *)pfVar17;
                *(float *)(puStack_1d0 + -4) = fVar45;
                *(float *)(puStack_1d0 + 4) = fVar35;
                *(float *)(puStack_1d0 + 8) = fVar36;
                *puStack_1d0 = uVar4;
                *(undefined2 *)(puStack_1d0 + 1) = 0;
                puStack_1d0[3] = 0xff;
              }
            }
            else {
              *(undefined8 *)(pfStack_1dc + -4) = *(undefined8 *)pfVar17;
              pfStack_1dc[-2] = pfVar17[2];
              uVar4 = (&DAT_018fef48)[uStack_210];
              pfStack_1dc[-1] =
                   (float)CONCAT13(uVar4,CONCAT12((char)(int)(fVar45 * fVar38 + fVar41),
                                                  CONCAT11((char)(int)(fStack_154 * fVar38 + fVar41)
                                                           ,(char)(int)(fStack_158 * fVar38 + fVar41
                                                                       ))));
              *pfStack_1dc = fVar35;
              pfStack_1dc[1] = fVar36;
              pfStack_1dc[2] = 0.0;
              pfStack_1dc[3] = 0.0;
              pfStack_1dc[5] = -NAN;
              uStack_1c4 = (float)CONCAT13(1,CONCAT12((char)(int)(*(float *)(&DAT_01eb2c20 +
                                                                            uStack_210 * 0xc) *
                                                                  fVar38 + fVar41),
                                                      CONCAT11((char)(int)(*(float *)(&DAT_01eb2c1c
                                                                                     + uStack_210 *
                                                                                       0xc) * fVar38
                                                                          + fVar41),
                                                               (char)(int)(*(float *)(&DAT_01eb2c18
                                                                                     + uStack_210 *
                                                                                       0xc) * fVar38
                                                                          + fVar41))));
              pfStack_1dc[4] = uStack_1c4;
              if (iVar8 != 0) {
                fVar45 = pfVar17[2];
                *(undefined8 *)(puStack_1d0 + -0xc) = *(undefined8 *)pfVar17;
                *(float *)(puStack_1d0 + -4) = fVar45;
                *(float *)(puStack_1d0 + 4) = fVar35;
                *(float *)(puStack_1d0 + 8) = fVar36;
                *puStack_1d0 = uVar4;
                *(undefined2 *)(puStack_1d0 + 1) = 0;
                puStack_1d0[3] = 0xff;
              }
            }
            pfStack_1dc = pfStack_1dc + 10;
            puStack_1d0 = puStack_1d0 + 0x18;
            iStack_1d4 = iStack_1d4 + -1;
            fStack_e8 = fVar34 + fStack_e8;
            fStack_e4 = fVar39 + fStack_e4;
            fVar33 = fVar42 + fVar33;
          } while (iStack_1d4 != 0);
          pfVar15 = pfVar15 + 3;
          pfStack_20c = (float *)((int)pfStack_20c + -1);
          pfStack_1dc = pfVar27;
          puStack_1d0 = puVar25;
        } while (pfStack_20c != (float *)0x0);
        pfStack_20c = (float *)0x4;
        iVar16 = iStack_19c + 0x18;
        psVar32 = (short *)(iVar23 + iStack_19c * 6 + 4);
        do {
          uVar31 = 0;
          psVar30 = psVar32;
          do {
            sVar22 = (short)uVar31 + (short)pbStack_1e4;
            psVar30[-2] = sVar13;
            *psVar30 = sVar22;
            uVar31 = uVar31 + 1;
            psVar30[-1] = sVar22 + 1;
            psVar30 = psVar30 + 3;
          } while (uVar31 < 6);
          pbStack_1e4 = (byte *)((int)pbStack_1e4 + 7);
          pfStack_20c = (float *)((int)pfStack_20c + -1);
          psVar32 = psVar32 + 0x12;
          fVar46 = DAT_018f9940;
          iStack_19c = iVar16;
        } while (pfStack_20c != (float *)0x0);
      }
      else {
        fVar33 = (float)(&DAT_01eb2b30)[uStack_210 * 3];
        fVar34 = (float)(&DAT_01eb2b34)[uStack_210 * 3];
        fVar36 = (float)(&DAT_01eb2b38)[uStack_210 * 3] * DAT_018f9940;
        fVar39 = (float)(&DAT_01eb2b80)[uStack_210 * 3];
        fVar42 = (float)(&DAT_01eb2b84)[uStack_210 * 3];
        fVar35 = (&DAT_01eb2b88)[uStack_210 * 3];
        uStack_178 = *(undefined8 *)((int)&DAT_01eb2ac8 + (&DAT_018fef58)[uStack_210 * 5] * 0xc);
        fStack_1f8 = (&DAT_01eb2ad0)[(&DAT_018fef58)[uStack_210 * 5] * 3];
        switch(*(undefined *)(uStack_210 + 0x5c + (int)param_2)) {
        case 1:
        case 2:
          cVar21 = '\x01';
          break;
        case 3:
          cVar21 = '\0';
          break;
        case 4:
          cVar21 = '\x02';
          break;
        case 5:
          cVar21 = '\x03';
          break;
        default:
          cVar21 = '\0';
          fVar44 = 0.0;
        }
        fStack_1fc = 0.0;
        bVar5 = (&DAT_018fef48)[uStack_210 + iVar24];
        iVar20 = iVar24 + uStack_210;
        uStack_16c._4_4_ = (float)((ulonglong)uStack_178 >> 0x20);
        fStack_1a8 = uStack_16c._4_4_;
        uStack_16c._0_4_ = (float)uStack_178;
        fStack_1a0 = 0.0;
        iVar1 = iStack_204 * 0x28;
        uStack_208 = 0;
        iVar16 = iStack_204 * 0x18;
        iStack_204 = iStack_204 + 0xe;
        uStack_1b4 = (float)((uint)(byte)(cVar21 + 1) << 0x18);
        fStack_1ac = (float)uStack_16c;
        pfStack_20c = (float *)(iVar29 + iVar1 + 0x10);
        pbStack_1e4 = (byte *)(iVar16 + 0xc + iVar8);
        fStack_1a4 = fStack_1f8;
        do {
          uStack_1b8 = (float)((uint)bVar5 << 0x18);
          pbVar26 = pbStack_1e4 + 0x30;
          fStack_cc = (float)((ulonglong)uStack_178 >> 0x20);
          pfVar15 = pfStack_20c + 0x14;
          fStack_d0 = (float)uStack_178;
          puStack_1d0 = (undefined *)0x2;
          fStack_1f0 = fStack_d0;
          fVar45 = fStack_1f8;
          fVar47 = fVar40;
          fStack_14c = fVar44;
          do {
            fVar12 = uStack_1b4;
            fVar11 = uStack_1b8;
            if ((NAN(fStack_cc) == (fStack_cc == 0.0)) ||
               (fVar9 = fStack_cc, fVar10 = fVar45, NAN(fVar45) == (fVar45 == 0.0))) {
              dVar37 = (double)(fVar45 * fVar45 + fStack_cc * fStack_cc);
              FUN_017267a0();
              fVar9 = (DAT_018ce2f8 / (float)dVar37) * fStack_cc;
              fVar10 = (DAT_018ce2f8 / (float)dVar37) * fVar45;
            }
            fVar41 = DAT_018f8ffc;
            fVar38 = DAT_018f8ff8;
            fVar40 = DAT_018ce2f8;
            if (iVar7 == 5) {
              pfVar27 = &fStack_70;
              uStack_6c = (uint)(fStack_1f0 * DAT_018ce2f4) ^ DAT_018c4ea0;
              pfVar17 = afStack_64;
              fStack_70 = fVar9 * DAT_018ce2f4;
              fStack_68 = fVar10 * DAT_018ce2f4;
              afStack_64[0] = fVar9;
              afStack_64[1] = -0.0;
              afStack_64[2] = fVar10;
            }
            else {
              pfVar27 = (float *)&uStack_34;
              fStack_2c = fVar10 * DAT_018ce2f4;
              uStack_34 = CONCAT44(fVar9 * DAT_018ce2f4,fStack_1f0 * DAT_018ce2f4);
              fStack_20 = fVar10;
              pfVar17 = (float *)&lStack_28;
              lStack_28 = (ulonglong)(uint)fVar9 << 0x20;
            }
            uVar2 = *(undefined8 *)pfVar17;
            fVar9 = pfVar17[2];
            fStack_17c = fStack_1fc;
            fStack_180 = fVar47;
            if ((iVar6 != 6) && (iVar7 == 5)) {
              fStack_180 = fStack_1fc;
              fStack_17c = DAT_018ce2f8 - fVar47;
            }
            fVar10 = pfVar27[2];
            *(undefined8 *)(pfStack_20c + -4) = *(undefined8 *)pfVar27;
            fStack_b8 = (float)uVar2;
            pfStack_20c[-2] = fVar10;
            fStack_b4 = (float)((ulonglong)uVar2 >> 0x20);
            uStack_1b8._3_1_ = SUB41(fVar11,3);
            uStack_1b8._0_3_ =
                 CONCAT12((char)(int)(fVar9 * fVar38 + fVar41),
                          CONCAT11((char)(int)(fStack_b4 * fVar38 + fVar41),
                                   (char)(int)(fStack_b8 * fVar38 + fVar41)));
            pfStack_20c[-1] = uStack_1b8;
            *pfStack_20c = fStack_180;
            pfStack_20c[1] = fStack_17c;
            pfStack_20c[2] = fStack_14c;
            pfStack_20c[3] = fStack_1a0;
            pfStack_20c[5] = -NAN;
            uStack_1b4._3_1_ = SUB41(fVar12,3);
            uStack_1b4._0_3_ =
                 CONCAT12((char)(int)(*(float *)(&DAT_01eb2bd8 + iVar20 * 0xc) * fVar38 + fVar41),
                          CONCAT11((char)(int)(*(float *)(&DAT_01eb2bd4 + iVar20 * 0xc) * fVar38 +
                                              fVar41),
                                   (char)(int)(*(float *)(&DAT_01eb2bd0 + iVar20 * 0xc) * fVar38 +
                                              fVar41)));
            pfStack_20c[4] = uStack_1b4;
            if (iVar8 != 0) {
              fVar11 = pfVar27[2];
              *(undefined8 *)(pbStack_1e4 + -0xc) = *(undefined8 *)pfVar27;
              *(float *)(pbStack_1e4 + -4) = fVar11;
              *(float *)(pbStack_1e4 + 4) = fStack_180;
              *(float *)(pbStack_1e4 + 8) = fStack_17c;
              *pbStack_1e4 = bVar5;
              pbStack_1e4[1] = 0;
              pbStack_1e4[2] = 0;
              pbStack_1e4[3] = 0xff;
            }
            fVar47 = fVar47 - fVar40;
            pfStack_20c = pfStack_20c + 10;
            fStack_1f0 = fStack_1f0 + fVar39 + fVar39;
            fStack_14c = fStack_14c - fVar44;
            fStack_cc = fStack_cc + fVar42 + fVar42;
            fVar45 = fVar45 + fVar35 + fVar35;
            pbStack_1e4 = pbStack_1e4 + 0x18;
            puStack_1d0 = (undefined *)((int)puStack_1d0 + -1);
          } while (puStack_1d0 != (undefined *)0x0);
          if (uStack_208 < 6) {
            fStack_1ac = fStack_1ac + fVar33 * fVar46 + fVar33 * fVar46;
            fStack_1a8 = fStack_1a8 + fVar34 * fVar46 + fVar34 * fVar46;
            uStack_16c = CONCAT44(fStack_1a8,fStack_1ac);
            fStack_1f8 = fStack_1a4 + fVar36 + fVar36;
            uStack_178 = uStack_16c;
            fStack_1fc = fStack_1fc + DAT_018f9940;
            fStack_1a4 = fStack_1f8;
          }
          uStack_208 = uStack_208 + 1;
          fStack_1a0 = fStack_1a0 + DAT_018ff218;
          pfStack_20c = pfVar15;
          pbStack_1e4 = pbVar26;
        } while (uStack_208 < 7);
        uVar31 = 0;
        iVar16 = iStack_19c + 0xc;
        psVar32 = (short *)(iVar23 + iStack_19c * 6 + 4);
        do {
          sVar22 = (short)uVar31;
          sVar28 = sVar13 + sVar22 * 2;
          psVar32[-2] = sVar28;
          sVar14 = sVar13 + sVar22 * 2 + 2;
          sVar22 = sVar13 + 1 + sVar22 * 2;
          *psVar32 = sVar14;
          uVar31 = uVar31 + 1;
          psVar32[1] = sVar14;
          psVar32[-1] = sVar22;
          psVar32[2] = sVar22;
          psVar32[3] = sVar28 + 3;
          psVar32 = psVar32 + 6;
          fVar44 = DAT_018ce2f4;
          fVar46 = DAT_018f9940;
          iStack_19c = iVar16;
        } while (uVar31 < 6);
      }
    }
    else {
      uVar31 = param_2[7];
      if (iVar7 == 5) {
        switch(uVar31) {
        case 0:
          uVar31 = 1;
          break;
        case 1:
          uVar31 = 3;
          break;
        case 3:
          uVar31 = 4;
          break;
        case 4:
          uVar31 = 0;
        }
      }
      if (uVar31 == uStack_210) goto LAB_007b8903;
    }
    uStack_210 = uStack_210 + 1;
    if (5 < (int)uStack_210) {
      return;
    }
  } while( true );
}



/* FUNCTION 11684 ; VA 0x007ba480 ; FUN_007ba480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007ba480(int *param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  short sVar7;
  short sVar8;
  short sVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined4 uVar13;
  short *psVar14;
  short *psVar15;
  char cVar16;
  short sVar17;
  float *pfVar18;
  float *pfVar19;
  byte *pbVar20;
  short *psVar21;
  short sVar22;
  undefined4 uVar23;
  byte *pbVar24;
  float *pfVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  double dVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  float fVar40;
  undefined8 uVar41;
  float fVar42;
  float fVar43;
  float fVar44;
  float fVar45;
  float fVar46;
  uint uStack_140;
  float fStack_13c;
  uint uStack_138;
  float fStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  short *psStack_128;
  float *pfStack_118;
  int iStack_114;
  int iStack_110;
  undefined8 uStack_104;
  int iStack_ec;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  float fStack_dc;
  int *piStack_d8;
  byte *pbStack_d0;
  float fStack_cc;
  float fStack_c0;
  float fStack_7c;
  float fStack_78;
  undefined8 uStack_70;
  undefined8 uStack_60;
  float fStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  float fStack_c;
  
  iVar2 = *(int *)(param_2 + 0x1c);
  uVar23 = 0x510;
  sVar9 = 0;
  if (iVar2 != 6) {
    uVar23 = 0xd8;
  }
  uVar13 = 0x2df0;
  if (iVar2 != 6) {
    uVar13 = 0x7a8;
  }
  FUN_00715060(uVar13,param_1);
  FUN_00727cd0(uVar23,param_1 + 6);
  param_1[9] = 1;
  param_1[10] = 0x28;
  iVar3 = param_1[6];
  iVar4 = *param_1;
  uVar23 = 0x1b90;
  if (iVar2 != 6) {
    uVar23 = 0x498;
  }
  FUN_00715060(uVar23,param_1 + 3);
  iVar5 = param_1[3];
  iVar6 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2c74) && (FUN_016f3809(&DAT_01eb2c74), DAT_01eb2c74 == -1))
  {
    DAT_01eb2c68 = ((float)((uint)(float)DAT_01d61bf8 ^ DAT_018c4ea0) - (float)DAT_01d61c04) -
                   (float)DAT_01d61c10;
    _DAT_01eb2c6c =
         ((float)((uint)DAT_01d61bf8._4_4_ ^ DAT_018c4ea0) - DAT_01d61c04._4_4_) -
         DAT_01d61c10._4_4_;
    DAT_01eb2c70 = ((float)((uint)DAT_01d61c00 ^ DAT_018c4ea0) - DAT_01d61c0c) - DAT_01d61c18;
    FUN_016f37bf(&DAT_01eb2c74);
  }
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2c84) && (FUN_016f3809(&DAT_01eb2c84), DAT_01eb2c84 == -1))
  {
    DAT_01eb2c78 = (float)DAT_01d61bf8 * DAT_018daf58;
    DAT_01eb2c7c = DAT_01d61bf8._4_4_ * DAT_018daf58;
    DAT_01eb2c80 = DAT_01d61c00 * DAT_018daf58;
    FUN_016f37bf(&DAT_01eb2c84);
  }
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2c94) && (FUN_016f3809(&DAT_01eb2c94), DAT_01eb2c94 == -1))
  {
    DAT_01eb2c88 = (float)DAT_01d61c04 * DAT_018daf58;
    DAT_01eb2c8c = DAT_01d61c04._4_4_ * DAT_018daf58;
    DAT_01eb2c90 = DAT_01d61c0c * DAT_018daf58;
    FUN_016f37bf(&DAT_01eb2c94);
  }
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2ca4) && (FUN_016f3809(&DAT_01eb2ca4), DAT_01eb2ca4 == -1))
  {
    DAT_01eb2c98 = (float)DAT_01d61c10 * DAT_018daf58;
    DAT_01eb2c9c = DAT_01d61c10._4_4_ * DAT_018daf58;
    DAT_01eb2ca0 = DAT_01d61c18 * DAT_018daf58;
    FUN_016f37bf(&DAT_01eb2ca4);
  }
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2d08) && (FUN_016f3809(&DAT_01eb2d08), DAT_01eb2d08 == -1))
  {
    _DAT_01eb2ca8 = CONCAT44(_DAT_01eb2c6c,DAT_01eb2c68);
    _DAT_01eb2cb8 = DAT_01eb2c9c + _DAT_01eb2c6c;
    _DAT_01eb2cb4 = DAT_01eb2c98 + DAT_01eb2c68;
    _DAT_01eb2cc8 = DAT_01eb2c90 + DAT_01eb2c70;
    _DAT_01eb2cbc = DAT_01eb2ca0 + DAT_01eb2c70;
    _DAT_01eb2cc0 = DAT_01eb2c88 + DAT_01eb2c68;
    _DAT_01eb2cc4 = DAT_01eb2c8c + _DAT_01eb2c6c;
    _DAT_01eb2ccc = DAT_01eb2c98 + _DAT_01eb2cc0;
    _DAT_01eb2cb0 = DAT_01eb2c70;
    _DAT_01eb2cd0 = DAT_01eb2c9c + _DAT_01eb2cc4;
    _DAT_01eb2cd4 = DAT_01eb2ca0 + _DAT_01eb2cc8;
    _DAT_01eb2cd8 = DAT_01eb2c78 + DAT_01eb2c68;
    _DAT_01eb2cdc = DAT_01eb2c7c + _DAT_01eb2c6c;
    _DAT_01eb2ce0 = DAT_01eb2c80 + DAT_01eb2c70;
    _DAT_01eb2ce4 = DAT_01eb2c98 + _DAT_01eb2cd8;
    _DAT_01eb2ce8 = DAT_01eb2c9c + _DAT_01eb2cdc;
    _DAT_01eb2cec = DAT_01eb2ca0 + _DAT_01eb2ce0;
    DAT_01eb2cf8 = DAT_01eb2c90 + _DAT_01eb2ce0;
    DAT_01eb2cf0._0_4_ = DAT_01eb2c88 + _DAT_01eb2cd8;
    _DAT_01eb2d04 = DAT_01eb2ca0 + DAT_01eb2cf8;
    DAT_01eb2cf0._4_4_ = DAT_01eb2c8c + _DAT_01eb2cdc;
    _DAT_01eb2cfc = DAT_01eb2c98 + (float)DAT_01eb2cf0;
    _DAT_01eb2d00 = DAT_01eb2c9c + DAT_01eb2cf0._4_4_;
    FUN_016f37bf(&DAT_01eb2d08);
  }
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2d58) && (FUN_016f3809(&DAT_01eb2d58), DAT_01eb2d58 == -1))
  {
    _DAT_01eb2d1c = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    DAT_01eb2d10 = (uint)(float)DAT_01d61c04 ^ DAT_018c4ea0;
    DAT_01eb2d14 = (uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0;
    DAT_01eb2d18 = (uint)DAT_01d61c0c ^ DAT_018c4ea0;
    _DAT_01eb2d20 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2d24 = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb2d40 = DAT_01d61c10;
    _DAT_01eb2d48 = DAT_01d61c18;
    _DAT_01eb2d28 = DAT_01eb2d10;
    _DAT_01eb2d2c = DAT_01eb2d14;
    _DAT_01eb2d30 = DAT_01eb2d18;
    _DAT_01eb2d34 = DAT_01eb2d10;
    _DAT_01eb2d38 = DAT_01eb2d14;
    _DAT_01eb2d3c = DAT_01eb2d18;
    _DAT_01eb2d4c = DAT_01eb2d10;
    _DAT_01eb2d50 = DAT_01eb2d14;
    _DAT_01eb2d54 = DAT_01eb2d18;
    FUN_016f37bf(&DAT_01eb2d58);
  }
  if ((*(int *)(iVar6 + 0x34) < DAT_01eb2da8) && (FUN_016f3809(&DAT_01eb2da8), DAT_01eb2da8 == -1))
  {
    _DAT_01eb2d78 = (uint)(float)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2d7c = (uint)DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2d6c = CONCAT44(DAT_01d61bf8._4_4_,(float)DAT_01d61bf8);
    _DAT_01eb2d60 = DAT_01d61c10;
    _DAT_01eb2d80 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    _DAT_01eb2d84 = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01eb2d88 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    DAT_01eb2d68 = DAT_01d61c18;
    _DAT_01eb2d8c = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb2d74 = DAT_01d61c00;
    _DAT_01eb2d98 = DAT_01d61c00;
    _DAT_01eb2da4 = DAT_01d61c00;
    _DAT_01eb2d90 = _DAT_01eb2d6c;
    _DAT_01eb2d9c = _DAT_01eb2d6c;
    FUN_016f37bf(&DAT_01eb2da8);
  }
  pfStack_118 = (float *)(iVar4 + 0x10);
  uStack_48 = (uint)(float)DAT_01d61bf8 ^ DAT_018c4ea0;
  uStack_54 = CONCAT44(DAT_01d61bf8._4_4_,(float)DAT_01d61bf8);
  uStack_44 = (uint)DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
  fStack_58 = DAT_01d61c18;
  fStack_4c = DAT_01d61c00;
  fStack_28 = DAT_01d61c00;
  fStack_1c = DAT_01d61c00;
  uStack_60 = DAT_01d61c10;
  psStack_128 = (short *)(iVar3 + 4);
  uStack_40 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
  pbStack_d0 = (byte *)(iVar5 + 0xc);
  uStack_3c = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
  uStack_38 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
  uStack_34 = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
  iStack_114 = 0;
  piStack_d8 = &DAT_018fefd0;
  iStack_110 = 0;
  pfVar18 = pfStack_118;
  fVar38 = DAT_018f9940;
  uStack_30 = uStack_54;
  uStack_24 = uStack_54;
  do {
    if ((iVar2 == 6) || (pfVar25 = pfVar18, sVar7 = sVar9, *(int *)(param_2 + 0x1c) == iStack_114))
    {
      fVar26 = *(float *)((int)&DAT_01eb2d10 + iStack_110) * fVar38;
      fVar33 = *(float *)((int)&DAT_01eb2d14 + iStack_110) * fVar38;
      fVar37 = *(float *)((int)&DAT_01eb2d18 + iStack_110) * fVar38;
      fStack_e0 = *(float *)(&DAT_01eb2cb0 + *piStack_d8 * 0xc);
      fVar27 = *(float *)((int)&DAT_01eb2d60 + iStack_110) * fVar38;
      fVar34 = *(float *)((int)&DAT_01eb2d64 + iStack_110) * fVar38;
      fVar38 = *(float *)((int)&DAT_01eb2d68 + iStack_110) * fVar38;
      uStack_70 = *(undefined8 *)(&DAT_01eb2ca8 + *piStack_d8 * 0xc);
      fVar28 = DAT_018ff21c;
      switch(*(undefined *)(iStack_114 + 0x5c + param_2)) {
      case 1:
      case 2:
        cVar16 = '\x01';
        break;
      case 3:
        cVar16 = '\0';
        break;
      case 4:
        cVar16 = '\x02';
        break;
      case 5:
        cVar16 = '\x03';
        break;
      default:
        cVar16 = '\0';
        fVar28 = 0.0;
      }
      fVar43 = fVar28 * DAT_018f9978;
      pfVar25 = pfStack_118 + 0x1ea;
      uStack_104._4_4_ = (float)((ulonglong)uStack_70 >> 0x20);
      uStack_12c = (float)((uint)(byte)(cVar16 + 1) << 0x18);
      bVar1 = (&DAT_018ff048)[iStack_114];
      pbVar24 = pbStack_d0 + 0x498;
      fStack_e4 = uStack_104._4_4_;
      uStack_104._0_4_ = (float)uStack_70;
      fStack_13c = 0.0;
      fStack_134 = 0.0;
      uStack_138 = 0;
      fStack_e8 = (float)uStack_104;
      fStack_dc = fStack_e0;
      do {
        fStack_78 = (float)((ulonglong)uStack_70 >> 0x20);
        pbVar20 = pbStack_d0 + 0xa8;
        fStack_7c = (float)uStack_70;
        pfVar19 = pfVar18 + 0x46;
        fStack_cc = DAT_018ce2f8;
        uStack_130 = (float)((uint)bVar1 << 0x18);
        iStack_ec = 7;
        fVar40 = fStack_dc;
        fStack_c0 = fVar43;
        do {
          fVar12 = uStack_12c;
          fVar11 = uStack_130;
          dVar32 = (double)(fStack_7c * fStack_7c + fStack_78 * fStack_78 + fVar40 * fVar40);
          FUN_017267a0();
          fVar35 = DAT_018ce2f8 / (float)dVar32;
          fVar42 = fStack_7c * fVar35;
          fVar44 = fStack_78 * fVar35;
          fVar35 = fVar40 * fVar35;
          fVar29 = fVar42 * DAT_018ce2f4;
          fVar30 = fVar44 * DAT_018ce2f4;
          fVar31 = *(float *)((int)&uStack_60 + iStack_110 + 4);
          fStack_c = fVar35 * DAT_018ce2f4;
          fVar45 = fVar42 * *(float *)((int)&uStack_60 + iStack_110) + fVar44 * fVar31 +
                   fVar35 * *(float *)((int)&fStack_58 + iStack_110);
          fVar31 = fVar45 * fVar44 - fVar31;
          fVar39 = fVar45 * fVar42 - *(float *)((int)&uStack_60 + iStack_110);
          fVar46 = fVar45 * fVar35 - *(float *)((int)&fStack_58 + iStack_110);
          dVar32 = (double)(fVar31 * fVar31 + fVar39 * fVar39 + fVar46 * fVar46);
          FUN_017267a0();
          fVar10 = DAT_018f8ffc;
          fVar45 = DAT_018f8ff8;
          fVar36 = DAT_018ce2f8 / (float)dVar32;
          uVar41 = CONCAT44(fVar30,fVar29);
          fVar42 = fVar42 * DAT_018f8ff8;
          *(undefined8 *)(pfVar18 + -4) = uVar41;
          pfVar18[-2] = fStack_c;
          *pfVar18 = fStack_cc;
          uStack_130._3_1_ = SUB41(fVar11,3);
          uStack_130._0_3_ =
               CONCAT12((char)(int)(fVar35 * fVar45 + fVar10),
                        CONCAT11((char)(int)(fVar44 * fVar45 + fVar10),(char)(int)(fVar42 + fVar10))
                       );
          pfVar18[-1] = uStack_130;
          pfVar18[1] = fStack_13c;
          pfVar18[2] = fStack_c0;
          pfVar18[3] = fStack_134;
          pfVar18[5] = -NAN;
          uStack_12c._3_1_ = SUB41(fVar12,3);
          uStack_12c._0_3_ =
               CONCAT12((char)(int)(fVar36 * fVar46 * fVar45 + fVar10),
                        CONCAT11((char)(int)(fVar36 * fVar31 * fVar45 + fVar10),
                                 (char)(int)(fVar36 * fVar39 * fVar45 + fVar10)));
          pfVar18[4] = uStack_12c;
          if (iVar5 != 0) {
            *(float *)(pbStack_d0 + 8) = fStack_13c;
            *(undefined8 *)(pbStack_d0 + -0xc) = uVar41;
            *(float *)(pbStack_d0 + -4) = fStack_c;
            *(float *)(pbStack_d0 + 4) = fStack_cc;
            *pbStack_d0 = bVar1;
            pbStack_d0[1] = 0;
            pbStack_d0[2] = 0;
            pbStack_d0[3] = 0xff;
          }
          pfVar18 = pfVar18 + 10;
          fStack_c0 = fStack_c0 - fVar28;
          pbStack_d0 = pbStack_d0 + 0x18;
          iStack_ec = iStack_ec + -1;
          fStack_7c = fStack_7c + fVar27 + fVar27;
          fStack_78 = fStack_78 + fVar34 + fVar34;
          fVar40 = fVar40 + fVar38 + fVar38;
          fStack_cc = fStack_cc - _DAT_01d61d28;
        } while (iStack_ec != 0);
        if (uStack_138 < 6) {
          fStack_e8 = fStack_e8 + fVar26 + fVar26;
          fStack_e4 = fStack_e4 + fVar33 + fVar33;
          fStack_e0 = fStack_e0 + fVar37 + fVar37;
          fStack_13c = fStack_13c + _DAT_01d61d2c;
          uStack_104 = CONCAT44(fStack_e4,fStack_e8);
          uStack_70 = uStack_104;
          fStack_dc = fStack_e0;
        }
        uStack_138 = uStack_138 + 1;
        fStack_134 = fStack_134 + DAT_018ff218;
        pfVar18 = pfVar19;
        pbStack_d0 = pbVar20;
      } while (uStack_138 < 7);
      sVar17 = 0;
      psVar21 = psStack_128 + 0xd8;
      uStack_140 = 0;
      psVar14 = psStack_128;
      do {
        uStack_138 = 0;
        psVar15 = psVar14 + 0x24;
        do {
          sVar22 = sVar17 * 7 + sVar9 + (short)uStack_138;
          sVar8 = (short)uStack_140 + (short)uStack_138;
          psVar14[-2] = sVar22;
          sVar7 = sVar9 + 1 + sVar8;
          psVar14[-1] = sVar7;
          sVar8 = sVar9 + 7 + sVar8;
          psVar14[2] = sVar7;
          *psVar14 = sVar8;
          uStack_138 = uStack_138 + 1;
          psVar14[1] = sVar8;
          psVar14[3] = sVar22 + 8;
          psVar14 = psVar14 + 6;
        } while (uStack_138 < 6);
        uStack_140 = uStack_140 + 7;
        sVar17 = sVar17 + 1;
        psVar14 = psVar15;
        fVar38 = DAT_018f9940;
        psStack_128 = psVar21;
        pfStack_118 = pfVar25;
        pbStack_d0 = pbVar24;
        sVar7 = sVar9 + 0x31;
      } while (uStack_140 < 0x2a);
    }
    sVar9 = sVar7;
    iStack_110 = iStack_110 + 0xc;
    iStack_114 = iStack_114 + 1;
    piStack_d8 = piStack_d8 + 5;
    pfVar18 = pfVar25;
  } while (iStack_110 < 0x48);
  return;
}



/* FUNCTION 11685 ; VA 0x007bb400 ; FUN_007bb400 */

void FUN_007bb400(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  float fVar4;
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  float afStack_34 [5];
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  FUN_00715060(0x271000,param_1);
  puVar1 = param_1 + 6;
  FUN_00727cd0(20000,puVar1);
  piVar2 = param_1 + 3;
  FUN_00715060(0x177000,piVar2);
  iVar3 = *piVar2;
  iStack_3c = 0;
  uStack_48 = *param_1;
  uStack_40 = *puVar1;
  uStack_38 = 0;
  uStack_10 = 0;
  puStack_c = &DAT_bf800000;
  fVar4 = (float)*(byte *)(param_2 + 0x48);
  uStack_8 = 0;
  uStack_1c = 0x3f800000;
  uStack_18 = 0;
  uStack_14 = 0;
  afStack_34[3] = 0.0;
  afStack_34[4] = 0.0;
  afStack_34[0] = (fVar4 + fVar4) * DAT_018f7860;
  puStack_20 = &DAT_bf800000;
  afStack_34[1] = 0.0;
  afStack_34[2] = 0.0;
  iStack_44 = iVar3;
  FUN_007bda40(&uStack_48,afStack_34,afStack_34 + 3,&uStack_1c,&uStack_10,*(byte *)(param_2 + 0x48),
               *(undefined *)(param_2 + 0x49));
  FUN_00715060(iStack_3c * 0x28,param_1);
  if (iVar3 != 0) {
    FUN_00715060(iStack_3c * 0x18,piVar2);
  }
  FUN_00727cd0(uStack_38,puVar1);
  param_1[10] = 0x28;
  param_1[9] = 1;
  return;
}



/* FUNCTION 11686 ; VA 0x007bb540 ; FUN_007bb540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007bb540(int *param_1,int *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined uVar4;
  int iVar5;
  short sVar6;
  undefined4 uVar7;
  float fVar8;
  float *pfVar9;
  undefined4 uVar10;
  int iVar11;
  int *piVar12;
  undefined *puVar13;
  int iVar14;
  bool bVar15;
  double dVar16;
  float fVar17;
  float fVar18;
  undefined4 uVar19;
  undefined auVar20 [12];
  float fVar21;
  undefined auVar22 [16];
  char cStack_1c5;
  float fStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 *puStack_1a4;
  int iStack_1a0;
  float fStack_19c;
  float fStack_198;
  float *pfStack_194;
  float fStack_190;
  float *pfStack_18c;
  ulonglong uStack_188;
  ulonglong uStack_180;
  undefined4 uStack_178;
  float fStack_170;
  float fStack_16c;
  float fStack_168;
  short *psStack_164;
  undefined4 *puStack_160;
  int iStack_15c;
  ulonglong uStack_158;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  ulonglong uStack_140;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined8 *puStack_12c;
  ulonglong uStack_110;
  float fStack_f8;
  float fStack_e8;
  undefined4 uStack_e0;
  float afStack_b0 [43];
  
  iStack_15c = *param_2;
  iVar14 = param_2[7];
  fStack_198 = *(float *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  fStack_19c = (float)iVar14;
  if ((*(int *)((int)fStack_198 + 0x34) < DAT_01eb2dac) &&
     (FUN_016f3809(&DAT_01eb2dac), DAT_01eb2dac == -1)) {
    dVar16 = DAT_018ce308;
    FUN_017267a0();
    _DAT_01d61d44 = (float)dVar16;
    _DAT_01d61d50 = _DAT_01d61d44;
    _DAT_01d61d54 = _DAT_01d61d44;
    FUN_016f37bf(&DAT_01eb2dac);
  }
  uVar10 = 800;
  if (iVar14 != 6) {
    uVar10 = 0xa0;
  }
  FUN_00715060(uVar10,param_1);
  uVar10 = 0x1e;
  if (fStack_19c != 8.40779e-45) {
    uVar10 = 6;
  }
  FUN_00727cd0(uVar10,param_1 + 6);
  param_1[9] = 1;
  param_1[10] = 0x28;
  puStack_1a4 = (undefined4 *)*param_1;
  puStack_160 = (undefined4 *)param_1[6];
  uVar10 = 0x1e0;
  if (fStack_19c != 8.40779e-45) {
    uVar10 = 0x60;
  }
  FUN_00715060(uVar10,param_1 + 3);
  fVar17 = fStack_198;
  puStack_12c = (undefined8 *)param_1[3];
  if ((*(int *)((int)fStack_198 + 0x34) < DAT_01eb2dbc) &&
     (FUN_016f3809(&DAT_01eb2dbc), DAT_01eb2dbc == -1)) {
    DAT_01eb2db0 = -0.5;
    DAT_01eb2db4 = -0.5;
    DAT_01eb2db8 = -0.5;
    FUN_016f37bf(&DAT_01eb2dbc);
  }
  if ((*(int *)((int)fVar17 + 0x34) < DAT_01eb2dcc) &&
     (FUN_016f3809(&DAT_01eb2dcc), DAT_01eb2dcc == -1)) {
    _DAT_01eb2dc0 = CONCAT44(DAT_01d61bf8._4_4_,(uint)DAT_01d61bf8);
    DAT_01eb2dc8 = DAT_01d61c00;
    FUN_016f37bf(&DAT_01eb2dcc);
  }
  if ((*(int *)((int)fVar17 + 0x34) < DAT_01eb2ddc) &&
     (FUN_016f3809(&DAT_01eb2ddc), DAT_01eb2ddc == -1)) {
    _DAT_01eb2dd0 = CONCAT44(DAT_01d61c04._4_4_,(float)DAT_01d61c04);
    DAT_01eb2dd8 = DAT_01d61c0c;
    FUN_016f37bf(&DAT_01eb2ddc);
  }
  if ((*(int *)((int)fVar17 + 0x34) < DAT_01eb2dec) &&
     (FUN_016f3809(&DAT_01eb2dec), DAT_01eb2dec == -1)) {
    _DAT_01eb2de0 = DAT_01d61c10;
    DAT_01eb2de8 = DAT_01d61c18;
    FUN_016f37bf(&DAT_01eb2dec);
  }
  if ((*(int *)((int)fVar17 + 0x34) < DAT_01eb2e50) &&
     (FUN_016f3809(&DAT_01eb2e50), DAT_01eb2e50 == -1)) {
    _DAT_01eb2df0 = CONCAT44(DAT_01eb2db4,DAT_01eb2db0);
    _DAT_01eb2dfc = DAT_01eb2de0 + DAT_01eb2db0;
    _DAT_01eb2e00 = DAT_01eb2de4 + DAT_01eb2db4;
    _DAT_01eb2e20 = DAT_01eb2dc0 + DAT_01eb2db0;
    _DAT_01eb2e24 = DAT_01eb2dc4 + DAT_01eb2db4;
    _DAT_01eb2e04 = DAT_01eb2de8 + DAT_01eb2db8;
    _DAT_01eb2e08 = DAT_01eb2dd0 + DAT_01eb2db0;
    _DAT_01eb2e0c = DAT_01eb2dd4 + DAT_01eb2db4;
    _DAT_01eb2e28 = DAT_01eb2dc8 + DAT_01eb2db8;
    _DAT_01eb2e10 = DAT_01eb2dd8 + DAT_01eb2db8;
    _DAT_01eb2e14 = _DAT_01eb2e08 + DAT_01eb2de0;
    _DAT_01eb2e18 = _DAT_01eb2e0c + DAT_01eb2de4;
    _DAT_01eb2e1c = _DAT_01eb2e10 + DAT_01eb2de8;
    _DAT_01eb2e2c = _DAT_01eb2e20 + DAT_01eb2de0;
    _DAT_01eb2e30 = _DAT_01eb2e24 + DAT_01eb2de4;
    _DAT_01eb2e34 = _DAT_01eb2e28 + DAT_01eb2de8;
    _DAT_01eb2e38 = _DAT_01eb2e20 + DAT_01eb2dd0;
    _DAT_01eb2e3c = _DAT_01eb2e24 + DAT_01eb2dd4;
    _DAT_01eb2e40 = _DAT_01eb2e28 + DAT_01eb2dd8;
    _DAT_01eb2e44 = _DAT_01eb2e38 + DAT_01eb2de0;
    _DAT_01eb2e48 = _DAT_01eb2e3c + DAT_01eb2de4;
    _DAT_01eb2e4c = _DAT_01eb2e40 + DAT_01eb2de8;
    _DAT_01eb2df8 = DAT_01eb2db8;
    FUN_016f37bf(&DAT_01eb2e50);
  }
  if ((*(int *)((int)fVar17 + 0x34) < DAT_01eb2ee8) &&
     (FUN_016f3809(&DAT_01eb2ee8), DAT_01eb2ee8 == -1)) {
    _DAT_01eb2e7c = (uint)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2e88 = (uint)(float)DAT_01d61c04 ^ DAT_018c4ea0;
    _DAT_01eb2e8c = (uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2e80 = DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2e70 = DAT_01d61c10;
    _DAT_01eb2e90 = (uint)DAT_01d61c0c ^ DAT_018c4ea0;
    _DAT_01eb2e84 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    fStack_168 = (float)((uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0);
    fStack_190 = (float)((uint)(float)DAT_01d61c10 ^ DAT_018c4ea0);
    fStack_16c = (float)((uint)DAT_01d61c18 ^ DAT_018c4ea0);
    _DAT_01eb2e98 = (fStack_168 + DAT_01d61c04._4_4_) * DAT_018ce2f4;
    _DAT_01eb2e60 = DAT_01d61c00;
    _DAT_01eb2e9c = (fStack_16c + DAT_01d61c0c) * DAT_018ce2f4;
    _DAT_01eb2e6c = DAT_01d61c0c;
    _DAT_01eb2e94 = (fStack_190 + (float)DAT_01d61c04) * DAT_018ce2f4;
    _DAT_01eb2e78 = DAT_01d61c18;
    _DAT_01eb2e58 = (uint)DAT_01d61bf8;
    _DAT_01eb2e5c = DAT_01d61bf8._4_4_;
    _DAT_01eb2e64 = (float)DAT_01d61c04;
    fRam01eb2e68 = DAT_01d61c04._4_4_;
    _DAT_01eb2ea0 = (uint)DAT_01d61bf8;
    uRam01eb2ea4 = DAT_01d61bf8._4_4_;
    _DAT_01eb2ea8 = DAT_01d61c00;
    _DAT_01eb2eac = (float)DAT_01d61c04;
    fRam01eb2eb0 = DAT_01d61c04._4_4_;
    _DAT_01eb2eb4 = DAT_01d61c0c;
    dVar16 = DAT_018ce308;
    fStack_198 = (float)_DAT_01eb2e88;
    pfStack_18c = (float *)_DAT_01eb2e90;
    psStack_164 = (short *)_DAT_01eb2e8c;
    FUN_017267a0();
    _DAT_01eb2ebc = DAT_018ce2f8 / (float)dVar16;
    _DAT_01eb2ec4 = _DAT_01eb2ebc * DAT_018f7864;
    _DAT_01eb2eb8 = _DAT_01eb2ebc * DAT_018ce2f0;
    _DAT_01eb2ed0 = (uint)fStack_198;
    _DAT_01eb2ed4 = (uint)psStack_164;
    _DAT_01eb2ed8 = (uint)pfStack_18c;
    _DAT_01eb2edc = fStack_190;
    _DAT_01eb2ee0 = fStack_168;
    _DAT_01eb2ee4 = fStack_16c;
    _DAT_01eb2ec0 = _DAT_01eb2ebc;
    _DAT_01eb2ec8 = _DAT_01eb2ebc;
    _DAT_01eb2ecc = _DAT_01eb2eb8;
    FUN_016f37bf(&DAT_01eb2ee8);
  }
  if ((*(int *)((int)fVar17 + 0x34) < DAT_01eb2f38) &&
     (FUN_016f3809(&DAT_01eb2f38), DAT_01eb2f38 == -1)) {
    DAT_01eb2ef0 = (uint)(float)DAT_01d61c10 ^ DAT_018c4ea0;
    _DAT_01eb2efc = (uint)DAT_01d61bf8 ^ DAT_018c4ea0;
    _DAT_01eb2f04 = (uint)DAT_01d61c00 ^ DAT_018c4ea0;
    DAT_01eb2ef4 = (uint)DAT_01d61c10._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2f10 = DAT_01d61c00;
    DAT_01eb2ef8 = (uint)DAT_01d61c18 ^ DAT_018c4ea0;
    _DAT_01eb2f00 = DAT_01d61bf8._4_4_ ^ DAT_018c4ea0;
    _DAT_01eb2f08 = (uint)DAT_01d61bf8;
    uRam01eb2f0c = DAT_01d61bf8._4_4_;
    _DAT_01eb2f14 = (uint)(float)DAT_01d61c10;
    uRam01eb2f18 = (uint)DAT_01d61c10._4_4_;
    _DAT_01eb2f1c = DAT_01d61c18;
    _DAT_01eb2f20 = _DAT_01eb2efc;
    _DAT_01eb2f24 = _DAT_01eb2f00;
    _DAT_01eb2f28 = _DAT_01eb2f04;
    _DAT_01eb2f2c = _DAT_01eb2efc;
    _DAT_01eb2f30 = _DAT_01eb2f00;
    _DAT_01eb2f34 = _DAT_01eb2f04;
    FUN_016f37bf(&DAT_01eb2f38);
  }
  if (fStack_19c == 8.40779e-45) {
    iVar14 = 6;
    do {
      FUN_0060f290();
      iVar11 = iStack_15c;
      iVar14 = iVar14 + -1;
    } while (iVar14 != 0);
    if (iStack_15c == 8) {
      uStack_180 = (ulonglong)((uint)(float)DAT_01d61c04 ^ DAT_018c4ea0);
      fStack_16c = (float)((uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0);
      fStack_168 = (float)((uint)DAT_01d61c0c ^ DAT_018c4ea0);
      uStack_110 = DAT_01d61c10 & 0xffffffff;
      fVar17 = (float)((uint)(float)DAT_01d61c04 ^ DAT_018c4ea0) + (float)DAT_01d61c10;
      fStack_190 = fStack_16c + DAT_01d61c10._4_4_;
      pfStack_18c = (float *)(fStack_168 + DAT_01d61c18);
      uStack_188 = (ulonglong)(uint)fVar17;
      dVar16 = (double)(fStack_190 * fStack_190 + fVar17 * fVar17 +
                       (float)pfStack_18c * (float)pfStack_18c);
      FUN_017267a0();
      fVar17 = DAT_018ce2f8 / (float)dVar16;
      uStack_140 = (ulonglong)(uint)((float)uStack_188 * fVar17);
      fStack_198 = fStack_190 * fVar17;
      psStack_164 = (short *)((float)pfStack_18c * fVar17);
      fStack_170 = (float)((uint)DAT_01d61c00 ^ DAT_018c4ea0) - DAT_01d61c0c;
      uStack_158 = (ulonglong)
                   (uint)((float)((uint)DAT_01d61bf8 ^ DAT_018c4ea0) - (float)DAT_01d61c04);
      fStack_19c = (float)(DAT_01d61bf8._4_4_ ^ DAT_018c4ea0) - DAT_01d61c04._4_4_;
      fStack_f8 = (float)psStack_164;
      FUN_017267a0();
      DAT_01d61c10 = CONCAT44(DAT_01d61c10._4_4_,(int)uStack_110);
    }
    else {
      uStack_180 = (ulonglong)((uint)(float)DAT_01d61c04 ^ DAT_018c4ea0);
      fStack_190 = (float)((uint)DAT_01d61c04._4_4_ ^ DAT_018c4ea0);
      pfStack_18c = (float *)((uint)DAT_01d61c0c ^ DAT_018c4ea0);
      fStack_198 = fStack_190 - DAT_01d61c10._4_4_;
      uStack_158 = DAT_01d61c10 & 0xffffffff;
      psStack_164 = (short *)((float)pfStack_18c - DAT_01d61c18);
      uStack_188 = (ulonglong)
                   (uint)((float)((uint)(float)DAT_01d61c04 ^ DAT_018c4ea0) - (float)DAT_01d61c10);
      FUN_017267a0();
      DAT_01d61c10 = CONCAT44(DAT_01d61c10._4_4_,(int)uStack_158);
    }
    pfStack_18c = afStack_b0;
    psStack_164 = (short *)(puStack_160 + 1);
    piVar12 = (int *)&DAT_018ff1a8;
    fStack_168 = 0.0;
    if (iVar11 != 8) {
      piVar12 = (int *)&DAT_018ff130;
    }
    fStack_190 = 0.0;
    puVar13 = (undefined *)((int)puStack_12c + 0x24);
    puStack_1a4 = (undefined4 *)((int)puStack_1a4 + 0x38);
    pfStack_194 = (float *)&DAT_01eb2ef8;
    fStack_198 = 8.40779e-45;
    do {
      fVar8 = DAT_018f8ffc;
      fVar17 = DAT_018f8ff8;
      uVar7 = _UNK_018e3fbc;
      uVar10 = _UNK_018e3fb4;
      if (fStack_190 != 1.4013e-45) {
        iVar14 = 0;
        if (iStack_15c == 8) {
          iVar14 = 6;
        }
        fVar1 = *(float *)(&DAT_01d61d30 + (iVar14 + (int)fStack_190) * 4);
        fStack_e8 = _DAT_018e3fb0;
        uStack_e0 = _UNK_018e3fb8;
        fStack_16c = DAT_018ce2f8;
        switch(*(undefined *)((int)fStack_190 + 0x5c + (int)param_2)) {
        case 1:
        case 2:
          cStack_1c5 = '\x01';
          break;
        case 3:
          cStack_1c5 = '\0';
          break;
        case 4:
          cStack_1c5 = '\x02';
          break;
        case 5:
          cStack_1c5 = '\x03';
          break;
        default:
          bVar15 = false;
          puStack_160 = (undefined4 *)0x0;
          cStack_1c5 = '\0';
          auVar20 = ZEXT812(0);
          goto LAB_007bc354;
        }
        bVar15 = true;
        auVar20._4_8_ = 0;
        auVar20._0_4_ = DAT_018ce2f4;
        puStack_160 = (undefined4 *)DAT_018e3f8c;
LAB_007bc354:
        auVar22 = ZEXT816(0);
        uVar19 = auVar20._0_4_;
        uStack_1bc = 0;
        fVar2 = pfStack_18c[1];
        fVar18 = 0.0;
        if (NAN(fVar2) == (fVar2 == 0.0)) {
          auVar22._12_4_ = 0;
          auVar22._0_12_ = auVar20;
          uStack_e0 = 0x3f800000;
          fVar18 = DAT_018ce2f8;
          uStack_1bc = uVar19;
        }
        fVar3 = *pfStack_18c;
        if (NAN(fVar3) == (fVar3 == 0.0)) {
          uVar19 = 0;
          auVar20 = ZEXT812(0);
          fStack_16c = fVar18;
          fStack_e8 = fVar18;
        }
        if (bVar15) {
          fVar21 = fVar1 * DAT_018f993c;
        }
        else {
          fVar21 = 0.0;
        }
        if (NAN(fVar2) == (fVar2 == 0.0)) {
          auVar22._0_4_ = auVar22._0_4_ - fVar21 * fVar2 * (float)puStack_160;
          fVar18 = fVar18 - fVar2 * fVar1;
        }
        if (NAN(fVar3) == (fVar3 == 0.0)) {
          auVar20._4_8_ = auVar20._4_8_;
          auVar20._0_4_ = auVar20._0_4_ + fVar3 * fVar21 * (float)puStack_160;
          fStack_16c = fStack_16c + fVar3 * fVar1;
        }
        iVar11 = 0;
        if (iStack_15c == 8) {
          iVar11 = 6;
        }
        iVar11 = iVar11 + (int)fStack_190;
        uVar4 = (&DAT_018ff050)[iVar11];
        iVar5 = piVar12[-2];
        cStack_1c5 = cStack_1c5 + '\x01';
        *(undefined8 *)(puStack_1a4 + -0xe) = *(undefined8 *)(&DAT_01eb2df0 + iVar5 * 0xc);
        puStack_1a4[-0xc] = *(undefined4 *)(&DAT_01eb2df8 + iVar5 * 0xc);
        uStack_14c = CONCAT13(uVar4,CONCAT12((char)(int)(*(float *)(&DAT_01eb2e60 + iVar11 * 0xc) *
                                                         fVar17 + fVar8),
                                             CONCAT11((char)(int)(*(float *)(&DAT_01eb2e5c +
                                                                            iVar11 * 0xc) * fVar17 +
                                                                 fVar8),
                                                      (char)(int)(*(float *)(&DAT_01eb2e58 +
                                                                            iVar11 * 0xc) * fVar17 +
                                                                 fVar8))));
        puStack_1a4[-0xb] = uStack_14c;
        puStack_1a4[-10] = fStack_e8;
        puStack_1a4[-9] = uVar10;
        puStack_1a4[-8] = uVar19;
        puStack_1a4[-7] = 0;
        puStack_1a4[-5] = 0xffffffff;
        uStack_148 = CONCAT13(cStack_1c5,
                              CONCAT12((char)(int)(*pfStack_194 * fVar17 + fVar8),
                                       CONCAT11((char)(int)(pfStack_194[-1] * fVar17 + fVar8),
                                                (char)(int)(pfStack_194[-2] * fVar17 + fVar8))));
        puStack_1a4[-6] = uStack_148;
        iVar5 = piVar12[-1];
        *(undefined8 *)(puStack_1a4 + -4) = *(undefined8 *)(&DAT_01eb2df0 + iVar5 * 0xc);
        puStack_1a4[-2] = *(undefined4 *)(&DAT_01eb2df8 + iVar5 * 0xc);
        uStack_130 = CONCAT13(uVar4,CONCAT12((char)(int)(*(float *)(&DAT_01eb2e60 + iVar11 * 0xc) *
                                                         fVar17 + fVar8),
                                             CONCAT11((char)(int)(*(float *)(&DAT_01eb2e5c +
                                                                            iVar11 * 0xc) * fVar17 +
                                                                 fVar8),
                                                      (char)(int)(*(float *)(&DAT_01eb2e58 +
                                                                            iVar11 * 0xc) * fVar17 +
                                                                 fVar8))));
        puStack_1a4[-1] = uStack_130;
        *puStack_1a4 = uStack_e0;
        puStack_1a4[1] = uVar7;
        puStack_1a4[2] = uStack_1bc;
        puStack_1a4[3] = 0;
        puStack_1a4[5] = 0xffffffff;
        uStack_134 = CONCAT13(cStack_1c5,
                              CONCAT12((char)(int)(*pfStack_194 * fVar17 + fVar8),
                                       CONCAT11((char)(int)(pfStack_194[-1] * fVar17 + fVar8),
                                                (char)(int)(pfStack_194[-2] * fVar17 + fVar8))));
        puStack_1a4[4] = uStack_134;
        iVar5 = *piVar12;
        *(undefined8 *)(puStack_1a4 + 6) = *(undefined8 *)(&DAT_01eb2df0 + iVar5 * 0xc);
        puStack_1a4[8] = *(undefined4 *)(&DAT_01eb2df8 + iVar5 * 0xc);
        uStack_138 = CONCAT13(uVar4,CONCAT12((char)(int)(*(float *)(&DAT_01eb2e60 + iVar11 * 0xc) *
                                                         fVar17 + fVar8),
                                             CONCAT11((char)(int)(*(float *)(&DAT_01eb2e5c +
                                                                            iVar11 * 0xc) * fVar17 +
                                                                 fVar8),
                                                      (char)(int)(*(float *)(&DAT_01eb2e58 +
                                                                            iVar11 * 0xc) * fVar17 +
                                                                 fVar8))));
        puStack_1a4[9] = uStack_138;
        puStack_1a4[10] = fStack_16c;
        puStack_1a4[0xb] = fVar1 + 0.0;
        puStack_1a4[0xc] = auVar20._0_4_;
        puStack_1a4[0xd] = fVar21;
        puStack_1a4[0xf] = 0xffffffff;
        puStack_1a4[0xe] =
             CONCAT13(cStack_1c5,
                      CONCAT12((char)(int)(*pfStack_194 * fVar17 + fVar8),
                               CONCAT11((char)(int)(pfStack_194[-1] * fVar17 + fVar8),
                                        (char)(int)(pfStack_194[-2] * fVar17 + fVar8))));
        iVar5 = piVar12[1];
        *(undefined8 *)(puStack_1a4 + 0x10) = *(undefined8 *)(&DAT_01eb2df0 + iVar5 * 0xc);
        puStack_1a4[0x12] = *(undefined4 *)(&DAT_01eb2df8 + iVar5 * 0xc);
        uVar4 = (&DAT_018ff050)[(int)fStack_190 + iVar14];
        puStack_1a4[0x13] =
             CONCAT13(uVar4,CONCAT12((char)(int)(*(float *)(&DAT_01eb2e60 + iVar11 * 0xc) * fVar17 +
                                                fVar8),
                                     CONCAT11((char)(int)(*(float *)(&DAT_01eb2e5c + iVar11 * 0xc) *
                                                          fVar17 + fVar8),
                                              (char)(int)(*(float *)(&DAT_01eb2e58 + iVar11 * 0xc) *
                                                          fVar17 + fVar8))));
        puStack_1a4[0x14] = fVar18;
        puStack_1a4[0x15] = fVar1 + 0.0;
        puStack_1a4[0x16] = auVar22._0_4_;
        puStack_1a4[0x17] = fVar21;
        puStack_1a4[0x19] = 0xffffffff;
        puStack_1a4[0x18] =
             CONCAT13(cStack_1c5,
                      CONCAT12((char)(int)(*pfStack_194 * fVar17 + fVar8),
                               CONCAT11((char)(int)(pfStack_194[-1] * fVar17 + fVar8),
                                        (char)(int)(pfStack_194[-2] * fVar17 + fVar8))));
        if (puStack_12c != (undefined8 *)0x0) {
          iVar14 = piVar12[-2];
          *(undefined8 *)(puVar13 + -0x24) = *(undefined8 *)(&DAT_01eb2df0 + iVar14 * 0xc);
          *(undefined4 *)(puVar13 + -0x1c) = *(undefined4 *)(&DAT_01eb2df8 + iVar14 * 0xc);
          *(undefined4 *)(puVar13 + -0x14) = uVar19;
          *(undefined4 *)(puVar13 + -0x10) = 0;
          puVar13[-0x18] = uVar4;
          *(undefined2 *)(puVar13 + -0x17) = 0;
          puVar13[-0x15] = 0xff;
          iVar14 = piVar12[-1];
          *(undefined8 *)(puVar13 + -0xc) = *(undefined8 *)(&DAT_01eb2df0 + iVar14 * 0xc);
          *(undefined4 *)(puVar13 + -4) = *(undefined4 *)(&DAT_01eb2df8 + iVar14 * 0xc);
          *(undefined4 *)(puVar13 + 4) = uStack_1bc;
          *(undefined4 *)(puVar13 + 8) = 0;
          *puVar13 = uVar4;
          *(undefined2 *)(puVar13 + 1) = 0;
          puVar13[3] = 0xff;
          iVar14 = *piVar12;
          *(undefined8 *)(puVar13 + 0xc) = *(undefined8 *)(&DAT_01eb2df0 + iVar14 * 0xc);
          *(undefined4 *)(puVar13 + 0x14) = *(undefined4 *)(&DAT_01eb2df8 + iVar14 * 0xc);
          *(int *)(puVar13 + 0x1c) = auVar20._0_4_;
          *(float *)(puVar13 + 0x20) = fVar21;
          puVar13[0x18] = uVar4;
          *(undefined2 *)(puVar13 + 0x19) = 0;
          puVar13[0x1b] = 0xff;
          iVar11 = piVar12[1];
          iVar14 = iVar11 * 0xc;
          uVar10 = *(undefined4 *)(iVar14 + 0x1eb2df4);
          *(undefined4 *)(puVar13 + 0x24) = *(undefined4 *)(&DAT_01eb2df0 + iVar14);
          *(undefined4 *)(puVar13 + 0x28) = uVar10;
          *(undefined4 *)(puVar13 + 0x2c) = *(undefined4 *)(&DAT_01eb2df8 + iVar11 * 0xc);
          *(int *)(puVar13 + 0x34) = auVar22._0_4_;
          *(float *)(puVar13 + 0x38) = fVar21;
          puVar13[0x30] = uVar4;
          *(undefined2 *)(puVar13 + 0x31) = 0;
          puVar13[0x33] = 0xff;
        }
        puVar13 = puVar13 + 0x60;
        puStack_1a4 = puStack_1a4 + 0x28;
        sVar6 = (short)((int)fStack_168 << 2);
        psStack_164[-2] = sVar6;
        *psStack_164 = sVar6 + 2;
        psStack_164[1] = sVar6 + 2;
        psStack_164[-1] = sVar6 + 1;
        psStack_164[2] = sVar6 + 1;
        psStack_164[3] = sVar6 + 3;
        psStack_164 = psStack_164 + 6;
        fStack_168 = (float)((int)fStack_168 + 1);
      }
      pfStack_194 = pfStack_194 + 3;
      fStack_190 = (float)((int)fStack_190 + 1);
      piVar12 = piVar12 + 5;
      pfStack_18c = pfStack_18c + 8;
      fStack_198 = (float)((int)fStack_198 + -1);
      if (fStack_198 == 0.0) {
        return;
      }
    } while( true );
  }
  pfStack_194 = (float *)&DAT_018ff0c8;
  if (iStack_15c != 8) {
    pfStack_194 = (float *)&DAT_018ff068;
  }
  iVar14 = 4;
  iStack_1a0 = param_2[7];
  do {
    FUN_005502b0();
    iVar14 = iVar14 + -1;
  } while (iVar14 != 0);
  if ((iStack_15c == 8) && (iStack_1a0 == 1)) {
    uStack_1ac = 0x3f800000;
    uStack_1a8 = 0x3f800000;
    uStack_1b4 = 0x3f800000;
    uStack_1b8 = 0x3f800000;
    uStack_1bc = 0;
    uStack_1b0 = 0;
    fStack_1c4 = 0.0;
    uStack_1c0 = 0;
    goto LAB_007bb736;
  }
  fStack_1c4 = _DAT_018e3fb0;
  uStack_1c0 = _UNK_018e3fb4;
  uStack_1bc = _UNK_018e3fb8;
  uStack_1b8 = _UNK_018e3fbc;
  uStack_1b4 = _DAT_018ff220;
  uStack_1b0 = _UNK_018ff224;
  uStack_1ac = _UNK_018ff228;
  uStack_1a8 = _UNK_018ff22c;
  if (iStack_15c == 8) {
    if (iStack_1a0 != 0) {
      bVar15 = iStack_1a0 == 2;
      goto LAB_007bb72c;
    }
  }
  else {
    bVar15 = iStack_1a0 == 3;
LAB_007bb72c:
    if (!bVar15) goto LAB_007bb736;
  }
  uStack_1bc = 0x3f800000;
LAB_007bb736:
  uVar4 = (&DAT_018ff05c)[iStack_1a0];
  iVar14 = 0;
  uStack_180 = 0;
  if (iStack_15c == 8) {
    iVar14 = 6;
  }
  uStack_178 = 0;
  iVar14 = iVar14 + iStack_1a0;
  iStack_1a0 = iStack_1a0 * 0x10;
  uStack_188 = 0;
  puVar13 = &DAT_01eb2e58 + iVar14 * 0xc;
  FUN_007be400(puStack_1a4,&DAT_01eb2df0 + *(int *)((int)pfStack_194 + iStack_1a0) * 0xc,puVar13,
               &fStack_1c4,&uStack_188,&uStack_180,uVar4,0);
  uStack_180 = 0;
  uStack_178 = 0;
  uStack_188 = 0;
  FUN_007be400((int)puStack_1a4 + 0x28,
               &DAT_01eb2df0 + *(int *)((int)pfStack_194 + iStack_1a0 + 4) * 0xc,puVar13,&uStack_1bc
               ,&uStack_188,&uStack_180,uVar4,0);
  uStack_180 = 0;
  uStack_178 = 0;
  uStack_188 = 0;
  FUN_007be400((int)puStack_1a4 + 0x50,
               &DAT_01eb2df0 + *(int *)((int)pfStack_194 + iStack_1a0 + 8) * 0xc,puVar13,&uStack_1b4
               ,&uStack_188,&uStack_180,uVar4,0);
  pfVar9 = pfStack_194;
  iVar14 = iStack_1a0;
  uStack_180 = 0;
  uStack_178 = 0;
  uStack_188 = 0;
  FUN_007be400((int)puStack_1a4 + 0x78,
               &DAT_01eb2df0 + *(int *)((int)pfStack_194 + iStack_1a0 + 0xc) * 0xc,puVar13,
               &uStack_1ac,&uStack_188,&uStack_180,uVar4,0);
  if (puStack_12c != (undefined8 *)0x0) {
    iVar11 = *(int *)((int)pfVar9 + iVar14);
    *puStack_12c = *(undefined8 *)(&DAT_01eb2df0 + iVar11 * 0xc);
    *(undefined4 *)(puStack_12c + 1) = *(undefined4 *)(&DAT_01eb2df8 + iVar11 * 0xc);
    *(float *)(puStack_12c + 2) = fStack_1c4;
    *(undefined4 *)((int)puStack_12c + 0x14) = uStack_1c0;
    *(undefined *)((int)puStack_12c + 0xc) = uVar4;
    *(undefined2 *)((int)puStack_12c + 0xd) = 0;
    *(undefined *)((int)puStack_12c + 0xf) = 0xff;
    iVar11 = *(int *)((int)pfVar9 + iVar14 + 4);
    puStack_12c[3] = *(undefined8 *)(&DAT_01eb2df0 + iVar11 * 0xc);
    *(undefined4 *)(puStack_12c + 4) = *(undefined4 *)(&DAT_01eb2df8 + iVar11 * 0xc);
    *(undefined4 *)(puStack_12c + 5) = uStack_1bc;
    *(undefined4 *)((int)puStack_12c + 0x2c) = uStack_1b8;
    *(undefined *)((int)puStack_12c + 0x24) = uVar4;
    *(undefined2 *)((int)puStack_12c + 0x25) = 0;
    *(undefined *)((int)puStack_12c + 0x27) = 0xff;
    iVar11 = *(int *)((int)pfVar9 + iVar14 + 8);
    puStack_12c[6] = *(undefined8 *)(&DAT_01eb2df0 + iVar11 * 0xc);
    *(undefined4 *)(puStack_12c + 7) = *(undefined4 *)(&DAT_01eb2df8 + iVar11 * 0xc);
    *(undefined4 *)(puStack_12c + 8) = uStack_1b4;
    *(undefined4 *)((int)puStack_12c + 0x44) = uStack_1b0;
    *(undefined *)((int)puStack_12c + 0x3c) = uVar4;
    *(undefined2 *)((int)puStack_12c + 0x3d) = 0;
    *(undefined *)((int)puStack_12c + 0x3f) = 0xff;
    iVar14 = *(int *)((int)pfVar9 + iVar14 + 0xc);
    puStack_12c[9] = *(undefined8 *)(&DAT_01eb2df0 + iVar14 * 0xc);
    *(undefined4 *)(puStack_12c + 10) = *(undefined4 *)(&DAT_01eb2df8 + iVar14 * 0xc);
    *(undefined4 *)(puStack_12c + 0xb) = uStack_1ac;
    *(undefined4 *)((int)puStack_12c + 0x5c) = uStack_1a8;
    *(undefined *)((int)puStack_12c + 0x54) = uVar4;
    *(undefined2 *)((int)puStack_12c + 0x55) = 0;
    *(undefined *)((int)puStack_12c + 0x57) = 0xff;
  }
  *puStack_160 = 0x10000;
  puStack_160[1] = 0x20002;
  puStack_160[2] = 0x30001;
  return;
}



/* FUNCTION 11687 ; VA 0x007bd130 ; FUN_007bd130 */

void FUN_007bd130(undefined4 param_1,float *param_2,float *param_3,float *param_4,float *param_5,
                 char param_6,int param_7,int param_8)

{
  undefined8 uVar1;
  int iVar2;
  float *pfVar3;
  float *pfVar4;
  bool bVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  undefined8 uStack_a0;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  pfVar3 = param_3;
  iVar2 = param_7 * 2;
  uStack_1c = CONCAT44((uint)param_3[1] ^ DAT_018c4ea0,(uint)*param_3 ^ DAT_018c4ea0);
  fStack_14 = (float)((uint)param_3[2] ^ DAT_018c4ea0);
  FUN_007bdc90(param_2,&uStack_1c,0xbe800000,param_4,(float)iVar2,2);
  FUN_007bdc90(param_2,param_5,0x3e800000,param_4,(float)iVar2,2);
  uStack_1c = CONCAT44((uint)param_5[1] ^ DAT_018c4ea0,(uint)*param_5 ^ DAT_018c4ea0);
  fStack_14 = (float)((uint)param_5[2] ^ DAT_018c4ea0);
  fStack_40 = *param_3 * DAT_018e1340 + *param_2;
  fStack_3c = param_3[1] * DAT_018e1340 + param_2[1];
  fStack_38 = param_3[2] * DAT_018e1340 + param_2[2];
  FUN_007bdc90(&fStack_40,&uStack_1c,0xbe800000,param_4,(float)iVar2,2);
  uStack_1c = CONCAT44(param_5[1] * DAT_018e1340 + param_2[1],*param_5 * DAT_018e1340 + *param_2);
  fStack_14 = param_5[2] * DAT_018e1340 + param_2[2];
  FUN_007bdc90(&uStack_1c,param_3,0x3e800000,param_4,(float)iVar2,2);
  fStack_28 = 0.0;
  if (-1 < param_7) {
    do {
      if (fStack_28 == 0.0) {
        fVar8 = 0.0;
      }
      else {
        fVar8 = (float)((int)fStack_28 * 2) - DAT_018e1340;
      }
      fStack_8 = *param_4 * fVar8 + *param_2;
      fStack_c = param_4[1] * fVar8 + param_2[1];
      fStack_10 = param_4[2] * fVar8 + param_2[2];
      if ((fStack_28 == 0.0) || (fStack_28 == (float)param_7)) {
        param_3 = (float *)DAT_018e1340;
      }
      else {
        param_3 = (float *)DAT_018ce2f4;
      }
      if (fStack_28 == 0.0) {
        fStack_20 = 0.0;
      }
      else {
        fStack_20 = DAT_018e1340;
      }
      if (fStack_28 == (float)param_7) {
        fStack_24 = 0.0;
      }
      else {
        fStack_24 = DAT_018e1340;
      }
      uStack_1c = CONCAT44((uint)pfVar3[1] ^ DAT_018c4ea0,(uint)*pfVar3 ^ DAT_018c4ea0);
      fStack_14 = (float)((uint)pfVar3[2] ^ DAT_018c4ea0);
      fStack_40 = *pfVar3 * DAT_018e1340 + fStack_8;
      fStack_3c = pfVar3[1] * DAT_018e1340 + fStack_c;
      fStack_38 = pfVar3[2] * DAT_018e1340 + fStack_10;
      FUN_007bdc90(&fStack_40,&uStack_1c,0xbfc00000,param_4,param_3,2);
      fStack_34 = *pfVar3 * DAT_018e1340 + fStack_8 + *param_5 * DAT_018e1340;
      fStack_30 = pfVar3[1] * DAT_018e1340 + fStack_c + param_5[1] * DAT_018e1340;
      fStack_2c = pfVar3[2] * DAT_018e1340 + fStack_10 + param_5[2] * DAT_018e1340;
      FUN_007bdc90(&fStack_34,pfVar3,0x3fc00000,param_4,param_3,2);
      fStack_4c = *pfVar3 * fStack_20 + fStack_8;
      fStack_48 = pfVar3[1] * fStack_20 + fStack_c;
      fStack_44 = pfVar3[2] * fStack_20 + fStack_10;
      FUN_007bdc90(&fStack_4c,pfVar3,DAT_018f9968 - fStack_20,param_5,0x3e800000,2);
      fStack_58 = (float)((uint)*pfVar3 ^ DAT_018c4ea0);
      fStack_54 = (float)((uint)pfVar3[1] ^ DAT_018c4ea0);
      fStack_50 = (float)((uint)pfVar3[2] ^ DAT_018c4ea0);
      fStack_64 = *pfVar3 * fStack_24 + fStack_8 + *param_4 * (float)param_3;
      fStack_60 = pfVar3[1] * fStack_24 + fStack_c + param_4[1] * (float)param_3;
      fStack_5c = pfVar3[2] * fStack_24 + fStack_10 + param_4[2] * (float)param_3;
      FUN_007bdc90(&fStack_64,&fStack_58,(uint)(DAT_018f9968 - fStack_24) ^ DAT_018c4ea0,param_5,
                   0x3e800000,2);
      fStack_28 = (float)((int)fStack_28 + 1);
    } while ((int)fStack_28 <= param_7);
  }
  if (((param_8 != 2) && (1 < param_7)) && (fStack_8 = 0.0, 0 < param_7)) {
    do {
      if (param_8 == 0) {
        bVar5 = (bool)(SUB41(fStack_8,0) & 1);
      }
      else if (param_6 == '\0') {
        bVar5 = (int)fStack_8 < param_7 / 2;
      }
      else {
        bVar5 = param_7 / 2 <= (int)fStack_8;
      }
      fVar8 = param_4[1];
      fVar9 = param_4[2];
      if (bVar5 == false) {
        fVar7 = (float)*(undefined8 *)param_4;
        fStack_98 = param_4[2];
        pfVar4 = (float *)&uStack_a0;
        uStack_a0 = *(undefined8 *)param_4;
      }
      else {
        fVar7 = *param_4;
        pfVar4 = &fStack_64;
        fStack_64 = (float)((uint)fVar7 ^ DAT_018c4ea0);
        fStack_60 = (float)((uint)fVar8 ^ DAT_018c4ea0);
        fStack_5c = (float)((uint)fVar9 ^ DAT_018c4ea0);
      }
      uVar1 = *(undefined8 *)pfVar4;
      fVar8 = fVar8 + fVar8;
      fStack_14 = pfVar4[2];
      fVar7 = fVar7 + fVar7;
      fVar9 = fVar9 + fVar9;
      fVar6 = (float)(int)fStack_8;
      fStack_6c = fVar8 * fVar6 + param_2[1];
      fStack_68 = fVar7 * fVar6 + *param_2;
      fStack_70 = fVar9 * fVar6 + param_2[2];
      if (bVar5 == false) {
        fVar8 = 0.0;
        fVar9 = 0.0;
        fVar7 = 0.0;
      }
      uStack_1c._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
      uStack_1c._0_4_ = (float)uVar1;
      fStack_50 = DAT_018ce2f8;
      if (bVar5 != false) {
        fStack_50 = DAT_018f7864;
      }
      fStack_58 = ((float)uStack_1c - *pfVar3) * DAT_018f9948 * fStack_50;
      fStack_54 = (uStack_1c._4_4_ - pfVar3[1]) * DAT_018f9948 * fStack_50;
      fStack_50 = (fStack_14 - pfVar3[2]) * DAT_018f9948 * fStack_50;
      fStack_10 = (float)uStack_1c + *pfVar3;
      fStack_40 = fStack_10 * DAT_018f9948;
      fStack_c = fStack_14 + pfVar3[2];
      fStack_3c = (uStack_1c._4_4_ + pfVar3[1]) * DAT_018f9948;
      fStack_38 = fStack_c * DAT_018f9948;
      fStack_34 = (fVar7 + fStack_68 + fStack_10 * DAT_018f993c + *param_5 * DAT_018f9938) -
                  fStack_58 * DAT_018f993c;
      fStack_30 = (fVar8 + fStack_6c + (uStack_1c._4_4_ + pfVar3[1]) * DAT_018f993c +
                  param_5[1] * DAT_018f9938) - fStack_54 * DAT_018f993c;
      fStack_2c = (fVar9 + fStack_70 + fStack_c * DAT_018f993c + param_5[2] * DAT_018f9938) -
                  fStack_50 * DAT_018f993c;
      fStack_28 = fStack_58;
      fStack_24 = fStack_54;
      fStack_20 = fStack_50;
      uStack_1c = uVar1;
      FUN_007bdc90(&fStack_34,&fStack_58,0x3e800000,&fStack_40,0x401e6452,2);
      fStack_4c = (float)((uint)fStack_28 ^ DAT_018c4ea0);
      fStack_48 = (float)((uint)fStack_24 ^ DAT_018c4ea0);
      fStack_44 = (float)((uint)fStack_20 ^ DAT_018c4ea0);
      fStack_7c = *param_5 * DAT_018f993c + fStack_34;
      fStack_78 = param_5[1] * DAT_018f993c + fStack_30;
      fStack_74 = param_5[2] * DAT_018f993c + fStack_2c;
      FUN_007bdc90(&fStack_7c,&fStack_4c,0xbe800000,&fStack_40,0x401e6452,2);
      uStack_88 = (uint)*param_5 ^ DAT_018c4ea0;
      uStack_84 = (uint)param_5[1] ^ DAT_018c4ea0;
      uStack_80 = (uint)param_5[2] ^ DAT_018c4ea0;
      FUN_007bdc90(&fStack_34,&uStack_88,0xbe000000,&fStack_40,0x401e6452,2);
      fStack_94 = *param_5 * DAT_018f993c + fStack_34 + fStack_28 * DAT_018e1340;
      fStack_90 = param_5[1] * DAT_018f993c + fStack_30 + fStack_24 * DAT_018e1340;
      fStack_8c = param_5[2] * DAT_018f993c + fStack_2c + fStack_20 * DAT_018e1340;
      FUN_007bdc90(&fStack_94,param_5,0xbe000000,&fStack_40,0x401e6452,2);
      fStack_8 = (float)((int)fStack_8 + 1);
    } while ((int)fStack_8 < param_7);
  }
  return;
}



/* FUNCTION 11688 ; VA 0x007bda40 ; FUN_007bda40 */

void FUN_007bda40(undefined4 param_1,float *param_2,float *param_3,undefined4 param_4,float *param_5
                 ,undefined4 param_6,int param_7)

{
  int iVar1;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar1 = param_7;
  if (param_7 == 1) {
    iVar1 = 2;
  }
  fStack_10 = (*param_2 - *param_3) - *param_5;
  fStack_c = (param_2[1] - param_3[1]) - param_5[1];
  fStack_8 = (param_2[2] - param_3[2]) - param_5[2];
  FUN_007bd130(param_1,&fStack_10,param_3,param_4,param_5,0,param_6,iVar1);
  fStack_10 = (float)((uint)*param_5 ^ DAT_018c4ea0);
  fStack_c = (float)((uint)param_5[1] ^ DAT_018c4ea0);
  fStack_8 = (float)((uint)param_5[2] ^ DAT_018c4ea0);
  fStack_1c = (*param_2 - *param_3) + *param_5;
  fStack_18 = (param_2[1] - param_3[1]) + param_5[1];
  fStack_14 = (param_2[2] - param_3[2]) + param_5[2];
  FUN_007bd130(param_1,&fStack_1c,&fStack_10,param_4,param_3,1,param_6,param_7);
  fStack_1c = (float)((uint)*param_5 ^ DAT_018c4ea0);
  fStack_18 = (float)((uint)param_5[1] ^ DAT_018c4ea0);
  fStack_14 = (float)((uint)param_5[2] ^ DAT_018c4ea0);
  fStack_10 = (float)((uint)*param_3 ^ DAT_018c4ea0);
  fStack_c = (float)((uint)param_3[1] ^ DAT_018c4ea0);
  fStack_8 = (float)((uint)param_3[2] ^ DAT_018c4ea0);
  fStack_24 = param_3[1] + param_2[1] + param_5[1];
  fStack_20 = param_3[2] + param_2[2] + param_5[2];
  fStack_28 = *param_2 + *param_3 + *param_5;
  FUN_007bd130(param_1,&fStack_28,&fStack_10,param_4,&fStack_1c,0,param_6,iVar1);
  fStack_28 = (float)((uint)*param_3 ^ DAT_018c4ea0);
  fStack_24 = (float)((uint)param_3[1] ^ DAT_018c4ea0);
  fStack_20 = (float)((uint)param_3[2] ^ DAT_018c4ea0);
  fStack_18 = (param_3[1] + param_2[1]) - param_5[1];
  fStack_14 = (param_3[2] + param_2[2]) - param_5[2];
  fStack_1c = (*param_2 + *param_3) - *param_5;
  FUN_007bd130(param_1,&fStack_1c,param_5,param_4,&fStack_28,0,param_6,param_7);
  return;
}



/* FUNCTION 11689 ; VA 0x007bdc90 ; FUN_007bdc90 */

void __thiscall
FUN_007bdc90(int *param_1,float *param_2,float *param_3,float param_4,float *param_5,float param_6,
            undefined param_7)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  short sVar5;
  int iVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  undefined8 uStack_38;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar10 = param_4;
  if (*param_1 != 0) {
    fVar14 = param_4;
    if (param_4 <= 0.0) {
      fVar14 = 0.0;
    }
    fVar15 = param_6;
    if (param_6 <= 0.0) {
      fVar15 = 0.0;
    }
    fVar12 = *param_5 * fVar15 + *param_3 * fVar14 + *param_2;
    fVar13 = param_5[1] * fVar15 + param_3[1] * fVar14 + param_2[1];
    fVar14 = param_5[2] * fVar15 + param_3[2] * fVar14 + param_2[2];
    if (0.0 <= param_4) {
      param_4 = 0.0;
    }
    fVar16 = *param_3 * param_4;
    fVar17 = param_3[1] * param_4;
    fVar15 = param_3[2] * param_4;
    if (param_6 <= 0.0) {
      param_4 = 0.0;
    }
    else {
      param_4 = param_6;
    }
    fStack_44 = *param_5 * param_4 + fVar16 + *param_2;
    fVar16 = param_5[2] * param_4 + fVar15 + param_2[2];
    fVar15 = param_5[1] * param_4 + fVar17 + param_2[1];
    param_4 = fVar10;
    if (fVar10 <= 0.0) {
      param_4 = 0.0;
    }
    fVar17 = param_3[1] * param_4;
    fVar18 = *param_3 * param_4;
    fVar8 = param_3[2] * param_4;
    if (0.0 <= param_6) {
      param_4 = 0.0;
    }
    else {
      param_4 = param_6;
    }
    fVar18 = *param_5 * param_4 + fVar18 + *param_2;
    fVar17 = param_5[1] * param_4 + fVar17 + param_2[1];
    fStack_48 = param_5[2] * param_4 + fVar8 + param_2[2];
    if (0.0 <= fVar10) {
      fVar10 = 0.0;
    }
    if (0.0 <= param_6) {
      param_6 = 0.0;
    }
    fStack_30 = param_3[2];
    fVar9 = *param_5 * param_6 + *param_3 * fVar10 + *param_2;
    fVar11 = param_5[2] * param_6 + param_3[2] * fVar10 + param_2[2];
    fVar8 = param_3[1];
    fStack_58 = param_5[1] * param_6 + param_3[1] * fVar10 + param_2[1];
    fStack_18 = 0.0;
    fStack_2c = param_5[2] * fVar8 - param_5[1] * param_3[2];
    fStack_14 = 0.0;
    fStack_28 = *param_5 * param_3[2] - param_5[2] * *param_3;
    fStack_24 = param_5[1] * *param_3 - *param_5 * fVar8;
    uStack_38 = *(undefined8 *)param_3;
    fStack_20 = fVar8 * fVar13 + (float)uStack_38 * fVar12 + param_3[2] * fVar14;
    fStack_1c = param_5[1] * fVar13 + *param_5 * fVar12 + param_5[2] * fVar14;
    fStack_68 = fVar12;
    fStack_64 = fVar13;
    fStack_60 = fVar14;
    fStack_5c = fVar9;
    fStack_54 = fVar11;
    fStack_50 = fVar18;
    fStack_4c = fVar17;
    fStack_40 = fVar15;
    fStack_3c = fVar16;
    fStack_10 = fStack_58;
    fStack_c = fStack_48;
    fStack_8 = fStack_44;
    FUN_007be400(*param_1 + param_1[3] * 0x28,&fStack_68,&fStack_2c,&fStack_20,&fStack_18,&uStack_38
                 ,param_7,0);
    fStack_20 = 0.0;
    fStack_1c = 0.0;
    fStack_18 = fVar15 * param_3[1] + fStack_8 * *param_3 + fVar16 * param_3[2];
    fStack_14 = fVar15 * param_5[1] + fStack_8 * *param_5 + fVar16 * param_5[2];
    FUN_007be400(*param_1 + (param_1[3] + 1) * 0x28,&fStack_44,&fStack_2c,&fStack_18,&fStack_20,
                 &uStack_38,param_7,0);
    fStack_20 = 0.0;
    fStack_1c = 0.0;
    fStack_18 = fVar17 * param_3[1] + fVar18 * *param_3 + fStack_c * param_3[2];
    fStack_14 = fVar17 * param_5[1] + fVar18 * *param_5 + fStack_c * param_5[2];
    FUN_007be400(*param_1 + (param_1[3] + 2) * 0x28,&fStack_50,&fStack_2c,&fStack_18,&fStack_20,
                 &uStack_38,param_7,0);
    fStack_20 = 0.0;
    fStack_1c = 0.0;
    fStack_18 = *param_3 * fVar9 + fStack_10 * param_3[1] + fVar11 * param_3[2];
    fStack_14 = fStack_10 * param_5[1] + fVar9 * *param_5 + fVar11 * param_5[2];
    FUN_007be400(*param_1 + (param_1[3] + 3) * 0x28,&fStack_5c,&fStack_2c,&fStack_18,&fStack_20,
                 &uStack_38,param_7,0);
    iVar6 = param_1[1];
    if (iVar6 != 0) {
      fVar10 = *param_3;
      fVar8 = param_3[1];
      iVar7 = param_1[3];
      fVar1 = param_3[2];
      fVar2 = param_5[2];
      fVar3 = *param_5;
      fVar4 = param_5[1];
      *(undefined2 *)(iVar6 + 0xd + iVar7 * 0x18) = 0;
      *(ulonglong *)(iVar6 + iVar7 * 0x18) = CONCAT44(fVar13,fVar12);
      *(float *)(iVar6 + 8 + iVar7 * 0x18) = fStack_60;
      *(float *)(iVar6 + 0x10 + iVar7 * 0x18) = fVar13 * fVar8 + fVar10 * fVar12 + fVar14 * fVar1;
      *(undefined *)(iVar6 + 0xf + iVar7 * 0x18) = 0xff;
      *(float *)(iVar6 + 0x14 + iVar7 * 0x18) = fVar13 * fVar4 + fVar3 * fVar12 + fVar14 * fVar2;
      *(undefined *)(iVar6 + 0xc + iVar7 * 0x18) = param_7;
      fVar10 = *param_3;
      fVar14 = param_3[1];
      iVar7 = param_1[3] + 1;
      iVar6 = param_1[1];
      fVar12 = param_5[1];
      fVar13 = param_3[2];
      fVar8 = param_5[2];
      fVar1 = *param_5;
      *(undefined2 *)(iVar6 + 0xd + iVar7 * 0x18) = 0;
      *(undefined *)(iVar6 + 0xf + iVar7 * 0x18) = 0xff;
      *(ulonglong *)(iVar6 + iVar7 * 0x18) = CONCAT44(fStack_40,fStack_44);
      *(float *)(iVar6 + 8 + iVar7 * 0x18) = fStack_3c;
      *(float *)(iVar6 + 0x10 + iVar7 * 0x18) =
           fVar10 * fStack_8 + fVar14 * fVar15 + fVar13 * fVar16;
      *(float *)(iVar6 + 0x14 + iVar7 * 0x18) = fVar1 * fStack_8 + fVar15 * fVar12 + fVar16 * fVar8;
      *(undefined *)(iVar6 + 0xc + iVar7 * 0x18) = param_7;
      fVar10 = *param_3;
      fVar14 = param_3[1];
      fVar15 = param_5[1];
      fVar12 = param_3[2];
      fVar13 = param_5[2];
      fVar16 = *param_5;
      iVar6 = param_1[1];
      iVar7 = param_1[3] + 2;
      *(ulonglong *)(iVar6 + iVar7 * 0x18) = CONCAT44(fStack_4c,fStack_50);
      *(float *)(iVar6 + 8 + iVar7 * 0x18) = fStack_48;
      *(float *)(iVar6 + 0x10 + iVar7 * 0x18) =
           fVar14 * fVar17 + fVar10 * fVar18 + fVar12 * fStack_c;
      *(float *)(iVar6 + 0x14 + iVar7 * 0x18) =
           fVar16 * fVar18 + fVar17 * fVar15 + fStack_c * fVar13;
      *(undefined *)(iVar6 + 0xc + iVar7 * 0x18) = param_7;
      *(undefined2 *)(iVar6 + 0xd + iVar7 * 0x18) = 0;
      *(undefined *)(iVar6 + 0xf + iVar7 * 0x18) = 0xff;
      fVar10 = *param_3;
      fVar14 = param_3[1];
      iVar7 = param_1[3] + 3;
      iVar6 = param_1[1];
      fVar15 = param_5[1];
      fVar12 = param_3[2];
      fVar13 = param_5[2];
      fVar16 = *param_5;
      *(undefined2 *)(iVar6 + 0xd + iVar7 * 0x18) = 0;
      *(undefined *)(iVar6 + 0xf + iVar7 * 0x18) = 0xff;
      *(ulonglong *)(iVar6 + iVar7 * 0x18) = CONCAT44(fStack_58,fStack_5c);
      *(float *)(iVar6 + 8 + iVar7 * 0x18) = fStack_54;
      *(float *)(iVar6 + 0x10 + iVar7 * 0x18) =
           fStack_10 * fVar14 + fVar10 * fVar9 + fVar11 * fVar12;
      *(float *)(iVar6 + 0x14 + iVar7 * 0x18) =
           fStack_10 * fVar15 + fVar16 * fVar9 + fVar11 * fVar13;
      *(undefined *)(iVar6 + 0xc + iVar7 * 0x18) = param_7;
    }
    sVar5 = *(short *)(param_1 + 3);
    iVar6 = param_1[4];
    iVar7 = param_1[2];
    *(short *)(iVar7 + 4 + iVar6 * 2) = sVar5 + 2;
    *(short *)(iVar7 + 6 + iVar6 * 2) = sVar5 + 2;
    *(short *)(iVar7 + iVar6 * 2) = sVar5;
    *(short *)(iVar7 + 2 + iVar6 * 2) = sVar5 + 1;
    *(short *)(iVar7 + 8 + iVar6 * 2) = sVar5 + 1;
    *(short *)(iVar7 + 10 + iVar6 * 2) = sVar5 + 3;
  }
  param_1[3] = param_1[3] + 4;
  param_1[4] = param_1[4] + 6;
  return;
}



/* FUNCTION 11690 ; VA 0x007be400 ; FUN_007be400 */

void FUN_007be400(undefined8 *param_1,undefined8 *param_2,float *param_3,undefined4 *param_4,
                 undefined4 *param_5,float *param_6,undefined param_7,char param_8)

{
  float fVar1;
  float fVar2;
  
  fVar2 = DAT_018f8ffc;
  fVar1 = DAT_018f8ff8;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
  *(uint *)((int)param_1 + 0xc) =
       CONCAT13(param_7,CONCAT12((char)(int)(param_3[2] * fVar1 + fVar2),
                                 CONCAT11((char)(int)(param_3[1] * fVar1 + fVar2),
                                          (char)(int)(*param_3 * fVar1 + fVar2))));
  *(undefined4 *)(param_1 + 2) = *param_4;
  *(undefined4 *)((int)param_1 + 0x14) = param_4[1];
  *(undefined4 *)(param_1 + 3) = *param_5;
  *(undefined4 *)((int)param_1 + 0x1c) = param_5[1];
  *(undefined4 *)((int)param_1 + 0x24) = 0xffffffff;
  *(uint *)(param_1 + 4) =
       CONCAT13(param_8 + '\x01',
                CONCAT12((char)(int)(param_6[2] * fVar1 + fVar2),
                         CONCAT11((char)(int)(param_6[1] * fVar1 + fVar2),
                                  (char)(int)(*param_6 * fVar1 + fVar2))));
  return;
}



/* FUNCTION 11691 ; VA 0x007be4f0 ; FUN_007be4f0 */

void FUN_007be4f0(undefined4 *param_1,int param_2)

{
                    /* WARNING: Could not recover jumptable at 0x007be503. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(*(int *)*param_1 + param_2 * 4) + 0x50))();
  return;
}



/* FUNCTION 11692 ; VA 0x007be510 ; FUN_007be510 */

void FUN_007be510(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uStack_8;
  
  uStack_8 = 0;
  uVar1 = ((uint *)*param_1)[1];
  puVar4 = *(undefined4 **)*param_1;
  uVar5 = uVar1 & 0x3fffffff;
  if (puVar4 + uVar1 < puVar4) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      piVar2 = (int *)*puVar4;
      (**(code **)(*piVar2 + 0x54))();
      iVar3 = (**(code **)(*piVar2 + 0x58))();
      puVar4 = puVar4 + 1;
      *(int *)param_1[1] = *(int *)param_1[1] + iVar3;
      uStack_8 = uStack_8 + 1;
    } while (uStack_8 != uVar5);
  }
  return;
}



/* FUNCTION 11693 ; VA 0x007be5e0 ; FUN_007be5e0 */

void FUN_007be5e0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_007c4070(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *param_3;
  return;
}



/* FUNCTION 11694 ; VA 0x007be600 ; FUN_007be600 */

int FUN_007be600(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00575bc0();
  *(undefined2 *)(iVar4 + 0xc) = 0;
  *(undefined4 *)(iVar4 + 0x10) = *param_1;
  *(undefined4 *)(iVar4 + 0x14) = param_1[1];
  *(undefined4 *)(iVar4 + 0x28) = 0;
  *(undefined4 *)(iVar4 + 0x2c) = 0;
  uVar1 = param_1[3];
  uVar2 = param_1[4];
  uVar3 = param_1[5];
  *(undefined4 *)(iVar4 + 0x18) = param_1[2];
  *(undefined4 *)(iVar4 + 0x1c) = uVar1;
  *(undefined4 *)(iVar4 + 0x20) = uVar2;
  *(undefined4 *)(iVar4 + 0x24) = uVar3;
  *(undefined8 *)(iVar4 + 0x28) = *(undefined8 *)(param_1 + 6);
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  return iVar4;
}



/* FUNCTION 11695 ; VA 0x007be660 ; FUN_007be660 */

void FUN_007be660(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 0x44;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 11696 ; VA 0x007be6b0 ; FUN_007be6b0 */

void FUN_007be6b0(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 6;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 7;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 11697 ; VA 0x007be720 ; FUN_007be720 */

int __thiscall FUN_007be720(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined4 *puVar11;
  
  iVar1 = *param_1;
  iVar10 = (int)param_2 - iVar1 >> 3;
  iVar2 = param_1[1] - iVar1 >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar8 = param_1[2] - iVar1 >> 3;
  uVar4 = uVar3;
  if ((uVar8 <= 0x1fffffff - (uVar8 >> 1)) && (uVar4 = (uVar8 >> 1) + uVar8, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  puVar5 = (undefined4 *)FUN_00578020(uVar4);
  puVar6 = puVar5 + iVar10 * 2;
  *puVar6 = *param_3;
  puVar6[1] = param_3[1];
  puVar11 = (undefined4 *)param_1[1];
  puVar7 = (undefined4 *)*param_1;
  puVar9 = puVar5;
  if (param_2 == puVar11) {
    for (; puVar7 != puVar11; puVar7 = puVar7 + 2) {
      *puVar9 = *puVar7;
      puVar9[1] = puVar7[1];
      puVar9 = puVar9 + 2;
    }
  }
  else {
    if (puVar7 != param_2) {
      do {
        *puVar9 = *puVar7;
        puVar11 = puVar7 + 1;
        puVar7 = puVar7 + 2;
        puVar9[1] = *puVar11;
        puVar9 = puVar9 + 2;
      } while (puVar7 != param_2);
      puVar11 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar11) {
      do {
        puVar6[2] = *param_2;
        puVar7 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar6[3] = *puVar7;
        puVar6 = puVar6 + 2;
      } while (param_2 != puVar11);
    }
  }
  FUN_00654980(puVar5,uVar3,uVar4);
  return *param_1 + iVar10 * 8;
}



/* FUNCTION 11698 ; VA 0x007be830 ; FUN_007be830 */

void FUN_007be830(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  float fVar11;
  
  iVar8 = (int)param_3 - (int)param_1 >> 4;
  if (iVar8 < 0x29) {
    fVar11 = (float)param_2[2];
    if (fVar11 < (float)param_1[2]) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      uVar3 = param_2[2];
      uVar4 = param_2[3];
      uVar5 = param_1[1];
      uVar6 = param_1[2];
      uVar7 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = uVar5;
      param_2[2] = uVar6;
      param_2[3] = uVar7;
      *param_1 = uVar1;
      param_1[1] = uVar2;
      param_1[2] = uVar3;
      param_1[3] = uVar4;
      fVar11 = (float)param_2[2];
    }
    if ((float)param_3[2] <= fVar11 && fVar11 != (float)param_3[2]) {
      uVar1 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      uVar4 = *param_3;
      uVar5 = param_3[1];
      uVar6 = param_3[2];
      uVar7 = param_3[3];
      *param_3 = *param_2;
      param_3[1] = uVar1;
      param_3[2] = uVar2;
      param_3[3] = uVar3;
      *param_2 = uVar4;
      param_2[1] = uVar5;
      param_2[2] = uVar6;
      param_2[3] = uVar7;
      if ((float)param_2[2] <= (float)param_1[2] && (float)param_1[2] != (float)param_2[2]) {
        uVar1 = param_1[1];
        uVar2 = param_1[2];
        uVar3 = param_1[3];
        *param_2 = *param_1;
        param_2[1] = uVar1;
        param_2[2] = uVar2;
        param_2[3] = uVar3;
        *param_1 = uVar4;
        param_1[1] = uVar5;
        param_1[2] = uVar6;
        param_1[3] = uVar7;
        return;
      }
    }
  }
  else {
    iVar8 = iVar8 + 1 >> 3;
    fVar11 = (float)param_1[iVar8 * 4 + 2];
    if (fVar11 < (float)param_1[2]) {
      puVar9 = param_1 + iVar8 * 4;
      uVar1 = *puVar9;
      uVar2 = puVar9[1];
      uVar3 = puVar9[2];
      uVar4 = puVar9[3];
      uVar5 = param_1[1];
      uVar6 = param_1[2];
      uVar7 = param_1[3];
      puVar9 = param_1 + iVar8 * 4;
      *puVar9 = *param_1;
      puVar9[1] = uVar5;
      puVar9[2] = uVar6;
      puVar9[3] = uVar7;
      *param_1 = uVar1;
      param_1[1] = uVar2;
      param_1[2] = uVar3;
      param_1[3] = uVar4;
      fVar11 = (float)param_1[iVar8 * 4 + 2];
    }
    if ((float)param_1[iVar8 * 8 + 2] <= fVar11 && fVar11 != (float)param_1[iVar8 * 8 + 2]) {
      puVar9 = param_1 + iVar8 * 4;
      uVar1 = puVar9[1];
      uVar2 = puVar9[2];
      uVar3 = puVar9[3];
      puVar10 = param_1 + iVar8 * 8;
      uVar4 = *puVar10;
      uVar5 = puVar10[1];
      uVar6 = puVar10[2];
      uVar7 = puVar10[3];
      puVar10 = param_1 + iVar8 * 8;
      *puVar10 = *puVar9;
      puVar10[1] = uVar1;
      puVar10[2] = uVar2;
      puVar10[3] = uVar3;
      puVar9 = param_1 + iVar8 * 4;
      *puVar9 = uVar4;
      puVar9[1] = uVar5;
      puVar9[2] = uVar6;
      puVar9[3] = uVar7;
      if ((float)param_1[iVar8 * 4 + 2] <= (float)param_1[2] &&
          (float)param_1[2] != (float)param_1[iVar8 * 4 + 2]) {
        uVar1 = param_1[1];
        uVar2 = param_1[2];
        uVar3 = param_1[3];
        puVar9 = param_1 + iVar8 * 4;
        *puVar9 = *param_1;
        puVar9[1] = uVar1;
        puVar9[2] = uVar2;
        puVar9[3] = uVar3;
        *param_1 = uVar4;
        param_1[1] = uVar5;
        param_1[2] = uVar6;
        param_1[3] = uVar7;
      }
    }
    puVar9 = param_2 + iVar8 * -4;
    fVar11 = (float)param_2[2];
    if (fVar11 < (float)puVar9[2]) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      uVar3 = param_2[2];
      uVar4 = param_2[3];
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      *param_2 = *puVar9;
      param_2[1] = uVar5;
      param_2[2] = uVar6;
      param_2[3] = uVar7;
      *puVar9 = uVar1;
      puVar9[1] = uVar2;
      puVar9[2] = uVar3;
      puVar9[3] = uVar4;
      fVar11 = (float)param_2[2];
    }
    if ((float)param_2[iVar8 * 4 + 2] <= fVar11 && fVar11 != (float)param_2[iVar8 * 4 + 2]) {
      uVar1 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      puVar10 = param_2 + iVar8 * 4;
      uVar4 = *puVar10;
      uVar5 = puVar10[1];
      uVar6 = puVar10[2];
      uVar7 = puVar10[3];
      puVar10 = param_2 + iVar8 * 4;
      *puVar10 = *param_2;
      puVar10[1] = uVar1;
      puVar10[2] = uVar2;
      puVar10[3] = uVar3;
      *param_2 = uVar4;
      param_2[1] = uVar5;
      param_2[2] = uVar6;
      param_2[3] = uVar7;
      if ((float)param_2[2] <= (float)puVar9[2] && (float)puVar9[2] != (float)param_2[2]) {
        uVar1 = puVar9[1];
        uVar2 = puVar9[2];
        uVar3 = puVar9[3];
        *param_2 = *puVar9;
        param_2[1] = uVar1;
        param_2[2] = uVar2;
        param_2[3] = uVar3;
        *puVar9 = uVar4;
        puVar9[1] = uVar5;
        puVar9[2] = uVar6;
        puVar9[3] = uVar7;
      }
    }
    puVar9 = param_3 + iVar8 * -8;
    puVar10 = param_3 + iVar8 * -4;
    fVar11 = (float)puVar10[2];
    if (fVar11 < (float)puVar9[2]) {
      uVar1 = *puVar10;
      uVar2 = puVar10[1];
      uVar3 = puVar10[2];
      uVar4 = puVar10[3];
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      *puVar10 = *puVar9;
      puVar10[1] = uVar5;
      puVar10[2] = uVar6;
      puVar10[3] = uVar7;
      *puVar9 = uVar1;
      puVar9[1] = uVar2;
      puVar9[2] = uVar3;
      puVar9[3] = uVar4;
      fVar11 = (float)puVar10[2];
    }
    if ((float)param_3[2] <= fVar11 && fVar11 != (float)param_3[2]) {
      uVar1 = puVar10[1];
      uVar2 = puVar10[2];
      uVar3 = puVar10[3];
      uVar4 = *param_3;
      uVar5 = param_3[1];
      uVar6 = param_3[2];
      uVar7 = param_3[3];
      *param_3 = *puVar10;
      param_3[1] = uVar1;
      param_3[2] = uVar2;
      param_3[3] = uVar3;
      *puVar10 = uVar4;
      puVar10[1] = uVar5;
      puVar10[2] = uVar6;
      puVar10[3] = uVar7;
      if ((float)puVar10[2] <= (float)puVar9[2] && (float)puVar9[2] != (float)puVar10[2]) {
        uVar1 = puVar9[1];
        uVar2 = puVar9[2];
        uVar3 = puVar9[3];
        *puVar10 = *puVar9;
        puVar10[1] = uVar1;
        puVar10[2] = uVar2;
        puVar10[3] = uVar3;
        *puVar9 = uVar4;
        puVar9[1] = uVar5;
        puVar9[2] = uVar6;
        puVar9[3] = uVar7;
      }
    }
    fVar11 = (float)param_2[2];
    if (fVar11 < (float)param_1[iVar8 * 4 + 2]) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      uVar3 = param_2[2];
      uVar4 = param_2[3];
      puVar9 = param_1 + iVar8 * 4;
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      *param_2 = *puVar9;
      param_2[1] = uVar5;
      param_2[2] = uVar6;
      param_2[3] = uVar7;
      puVar9 = param_1 + iVar8 * 4;
      *puVar9 = uVar1;
      puVar9[1] = uVar2;
      puVar9[2] = uVar3;
      puVar9[3] = uVar4;
      fVar11 = (float)param_2[2];
    }
    if ((float)puVar10[2] <= fVar11 && fVar11 != (float)puVar10[2]) {
      uVar1 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      uVar4 = *puVar10;
      uVar5 = puVar10[1];
      uVar6 = puVar10[2];
      uVar7 = puVar10[3];
      *puVar10 = *param_2;
      puVar10[1] = uVar1;
      puVar10[2] = uVar2;
      puVar10[3] = uVar3;
      *param_2 = uVar4;
      param_2[1] = uVar5;
      param_2[2] = uVar6;
      param_2[3] = uVar7;
      if ((float)param_2[2] <= (float)param_1[iVar8 * 4 + 2] &&
          (float)param_1[iVar8 * 4 + 2] != (float)param_2[2]) {
        puVar9 = param_1 + iVar8 * 4;
        uVar1 = puVar9[1];
        uVar2 = puVar9[2];
        uVar3 = puVar9[3];
        *param_2 = *puVar9;
        param_2[1] = uVar1;
        param_2[2] = uVar2;
        param_2[3] = uVar3;
        param_1 = param_1 + iVar8 * 4;
        *param_1 = uVar4;
        param_1[1] = uVar5;
        param_1[2] = uVar6;
        param_1[3] = uVar7;
      }
    }
  }
  return;
}



/* FUNCTION 11699 ; VA 0x007be9f0 ; FUN_007be9f0 */

void __thiscall FUN_007be9f0(int param_1,int *param_2,byte *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2dc0;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(param_1 + 4);
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193) * 8;
  iVar2 = *(int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (iVar6 != iVar2) {
    iVar6 = **(int **)(*(int *)(param_1 + 0xc) + 4 + iVar1);
    while (iVar6 != iVar2) {
      iVar6 = *(int *)(iVar6 + 4);
      if (*(int *)param_3 == *(int *)(iVar6 + 8)) {
        ExceptionList = &pvStack_10;
        *(int *)param_4[1] = *param_4;
        *(int *)(*param_4 + 4) = param_4[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        uStack_8 = 1;
        FUN_007c7240(param_4);
        *param_2 = iVar6;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  iVar2 = *param_4;
  ExceptionList = &pvStack_10;
  if (iVar6 != iVar2) {
    ExceptionList = &pvStack_10;
    *(int *)param_4[1] = iVar2;
    **(int **)(iVar2 + 4) = iVar6;
    **(undefined4 **)(iVar6 + 4) = param_4;
    iVar3 = *(int *)(iVar6 + 4);
    *(undefined4 *)(iVar6 + 4) = *(undefined4 *)(iVar2 + 4);
    *(int *)(iVar2 + 4) = param_4[1];
    param_4[1] = iVar3;
  }
  piVar5 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (*piVar5 == *(int *)(param_1 + 4)) {
    *piVar5 = (int)param_4;
    *(int **)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = param_4;
  }
  else if (*piVar5 == iVar6) {
    *piVar5 = (int)param_4;
  }
  else {
    piVar4 = *(int **)piVar5[1];
    piVar5[1] = (int)piVar4;
    if (piVar4 != param_4) {
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) =
           *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar1) + 4);
    }
  }
  uStack_8 = 3;
  FUN_007c40d0();
  *param_2 = (int)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11700 ; VA 0x007beb53 ; Catch_All@007beb53 */

void Catch_All_007beb53(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_007c69c0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11701 ; VA 0x007beb80 ; FUN_007beb80 */

void __thiscall FUN_007beb80(int param_1,int *param_2,byte *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2dd0;
  pvStack_10 = ExceptionList;
  piVar7 = *(int **)(param_1 + 4);
  iVar6 = (*(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193) * 8;
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + iVar6);
  piVar9 = piVar7;
  if (piVar1 != piVar7) {
    piVar9 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar6);
  }
  do {
    if (piVar9 == piVar1) {
      iVar2 = *piVar7;
      uStack_8 = 0xffffffff;
      puVar3 = *(undefined4 **)(iVar2 + 4);
      ExceptionList = &pvStack_10;
      uVar5 = FUN_007be5e0(iVar2,puVar3,param_3);
      if (*(int *)(param_1 + 8) == -2) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *(undefined4 *)(iVar2 + 4) = uVar5;
      *puVar3 = uVar5;
      piVar7 = *(int **)(param_1 + 4);
      puVar3 = (undefined4 *)*piVar7;
      piVar1 = (int *)*puVar3;
      if (piVar9 != piVar1) {
        *(int **)puVar3[1] = piVar1;
        *(int **)piVar1[1] = piVar9;
        *(undefined4 **)piVar9[1] = puVar3;
        iVar2 = piVar9[1];
        piVar9[1] = piVar1[1];
        piVar1[1] = puVar3[1];
        puVar3[1] = iVar2;
        piVar7 = *(int **)(param_1 + 4);
      }
      puVar8 = (undefined4 *)(iVar6 + *(int *)(param_1 + 0xc));
      if ((int *)*puVar8 == piVar7) {
        *puVar8 = puVar3;
        *(undefined4 **)(iVar6 + 4 + *(int *)(param_1 + 0xc)) = puVar3;
      }
      else if ((int *)*puVar8 == piVar9) {
        *puVar8 = puVar3;
      }
      else {
        puVar4 = *(undefined4 **)puVar8[1];
        puVar8[1] = puVar4;
        if (puVar4 != puVar3) {
          iVar6 = iVar6 + *(int *)(param_1 + 0xc);
          *(undefined4 *)(iVar6 + 4) = *(undefined4 *)(*(int *)(iVar6 + 4) + 4);
        }
      }
      uStack_8 = 2;
      FUN_007c40d0();
      *param_2 = (int)puVar3;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    piVar9 = (int *)piVar9[1];
  } while (*(int *)param_3 != piVar9[2]);
  *param_2 = (int)piVar9;
  *(undefined *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 11702 ; VA 0x007bed08 ; Catch_All@007bed08 */

void Catch_All_007bed08(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_007c69c0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11703 ; VA 0x007bed40 ; FUN_007bed40 */

void __thiscall
FUN_007bed40(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_007c42b0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_007bedf2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_007bedf2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 11704 ; VA 0x007beea0 ; FUN_007beea0 */

void __thiscall
FUN_007beea0(int *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  bool bVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2de0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar3 = true;
  puVar2 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    puVar1 = (undefined4 *)puVar2[1];
    do {
      puVar2 = puVar1;
      if (param_3 == '\0') {
        bVar3 = *param_4 < (uint)puVar2[4];
      }
      else {
        bVar3 = *param_4 <= (uint)puVar2[4];
      }
      if (bVar3 == false) {
        puVar1 = (undefined4 *)puVar2[2];
      }
      else {
        puVar1 = (undefined4 *)*puVar2;
      }
    } while (*(char *)((int)puVar1 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_007bed40(&param_3,bVar3,puVar2,param_4,param_5);
  *param_2 = *puVar2;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11705 ; VA 0x007bef3f ; Catch_All@007bef3f */

void Catch_All_007bef3f(void)

{
  int unaff_EBP;
  
  FUN_007c42b0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11706 ; VA 0x007bef60 ; FUN_007bef60 */

void __thiscall FUN_007bef60(uint *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  char cStack_5;
  
  uVar6 = 0;
  piVar1 = param_3;
  if (param_3 != param_4) {
    do {
      piVar1 = (int *)*piVar1;
      uVar6 = uVar6 + 1;
    } while (piVar1 != param_4);
  }
  uStack_c = *param_1;
  iStack_14 = (int)((int)param_2 - uStack_c) >> 2;
  if ((uVar6 == 1) && (param_2 == (int *)param_1[1])) {
    cStack_5 = '\x01';
  }
  else {
    cStack_5 = '\0';
    if (uVar6 == 0) {
      return;
    }
  }
  uStack_1c = param_1[1];
  if (uVar6 <= (uint)((int)(param_1[2] - uStack_1c) >> 2)) {
    piStack_18 = (int *)(uVar6 * 4);
    iStack_14 = uStack_1c - (int)param_2;
    if (uVar6 < (uint)(iStack_14 >> 2)) {
      iVar4 = uStack_1c + uVar6 * -4;
      FUN_0055b6b0(&cStack_5,&iStack_14,&iStack_14);
      uVar3 = uStack_1c;
      FUN_0170cc70(uStack_1c,iVar4,uVar6 * 4);
      param_1[1] = (int)piStack_18 + uVar3;
      iVar4 = iVar4 - (int)param_2;
      FUN_0170cc70(uVar3 - iVar4,param_2,iVar4);
      if (param_3 != param_4) {
        do {
          *param_2 = param_3[2];
          param_3 = (int *)*param_3;
          param_2 = param_2 + 1;
        } while (param_3 != param_4);
        return;
      }
    }
    else {
      FUN_0055b6b0(&cStack_5,&uStack_1c,&uStack_1c);
      FUN_0170cc70(param_2 + uVar6,param_2,iStack_14);
      param_1[1] = iStack_14 + (int)(param_2 + uVar6);
      if (param_3 != param_4) {
        do {
          *param_2 = param_3[2];
          param_3 = (int *)*param_3;
          param_2 = param_2 + 1;
        } while (param_3 != param_4);
      }
    }
    return;
  }
  iVar4 = (int)(uStack_1c - *param_1) >> 2;
  if (0x3fffffffU - iVar4 < uVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uStack_10 = uVar6 + iVar4;
  uVar2 = (int)(param_1[2] - uStack_c) >> 2;
  uStack_c = uVar2 >> 1;
  uVar3 = uStack_10;
  if ((uVar2 <= 0x3fffffff - uStack_c) && (uVar3 = uVar2 + uStack_c, uVar2 + uStack_c < uStack_10))
  {
    uVar3 = uStack_10;
  }
  uStack_1c = uVar3 * 4;
  if (uVar3 < 0x40000000) {
    uVar3 = uStack_1c;
    if (0xfff < uStack_1c) goto LAB_007bf025;
    if (uStack_1c == 0) {
      uStack_c = 0;
    }
    else {
      uStack_c = FUN_01674e20(uStack_1c);
    }
  }
  else {
    uVar3 = 0xffffffff;
LAB_007bf025:
    uVar2 = uVar3 + 0x23;
    if (uVar2 <= uVar3) {
      uVar2 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar2);
    if (iVar4 == 0) goto LAB_007bf20d;
    uStack_c = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uStack_c - 4) = iVar4;
  }
  piStack_18 = (int *)(uStack_c + iStack_14 * 4);
  piVar1 = piStack_18;
  if (param_3 != param_4) {
    do {
      *piVar1 = param_3[2];
      param_3 = (int *)*param_3;
      piVar1 = piVar1 + 1;
    } while (param_3 != param_4);
  }
  if (cStack_5 == '\0') {
    FUN_007a5ee0(*param_1,param_2,uStack_c);
    uVar3 = uStack_c;
    FUN_007a5ee0(param_2,param_1[1],uStack_c + (iStack_14 + uVar6) * 4);
  }
  else {
    FUN_0055b6b0(&cStack_5,&piStack_18,&piStack_18);
    uVar3 = uStack_c;
    FUN_0170cc70(uStack_c,*param_1,param_1[1] - *param_1);
  }
  uVar6 = *param_1;
  if (uVar6 != 0) {
    uVar5 = param_1[2] - uVar6 & 0xfffffffc;
    uVar2 = uVar6;
    if (0xfff < uVar5) {
      uVar2 = *(uint *)(uVar6 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar6 - uVar2) - 4) {
LAB_007bf20d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar5);
  }
  *param_1 = uVar3;
  param_1[1] = uVar3 + uStack_10 * 4;
  param_1[2] = uStack_1c + uVar3;
  return;
}



/* FUNCTION 11707 ; VA 0x007bf220 ; FUN_007bf220 */

uint * FUN_007bf220(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  char cVar10;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2df8;
  pvStack_10 = ExceptionList;
  if ((param_1 != param_2) && (puVar1 = param_1 + 7, puVar1 != param_2)) {
    puVar7 = param_1 + 8;
    ExceptionList = &pvStack_10;
    do {
      uStack_30 = *puVar7;
      uStack_2c = puVar7[1];
      uStack_28 = puVar7[2];
      uStack_24 = puVar7[3];
      uVar6 = *puVar1;
      uStack_20 = puVar7[4];
      uStack_1c = puVar7[5];
      puVar7[4] = 0;
      puVar7[5] = 0xf;
      *(undefined *)puVar7 = 0;
      uStack_8 = 0;
      cVar10 = uVar6 < *param_1;
      puStack_18 = puVar7;
      puStack_14 = puVar1;
      if (uVar6 == *param_1) {
        cVar10 = FUN_00558ea0(&uStack_30,param_1 + 1);
      }
      if (cVar10 == '\0') {
        while( true ) {
          puVar8 = puVar7 + -7;
          cVar10 = uVar6 < puVar7[-8];
          if (uVar6 == puVar7[-8]) {
            cVar10 = FUN_00558ea0(&uStack_30,puVar8);
          }
          if (cVar10 == '\0') break;
          *puVar1 = puVar7[-8];
          puVar9 = puVar1 + 1;
          if (puVar9 != puVar8) {
            uVar5 = puVar1[6];
            if (0xf < uVar5) {
              uVar4 = uVar5 + 1;
              uVar3 = *puVar9;
              uVar2 = uVar3;
              if (0xfff < uVar4) {
                uVar2 = *(uint *)(uVar3 - 4);
                uVar4 = uVar5 + 0x24;
                if (0x1f < (uVar3 - uVar2) - 4) goto LAB_007bf547;
              }
              FUN_01674ea0(uVar2,uVar4);
            }
            puVar1[5] = 0;
            puVar1[6] = 0xf;
            *(undefined *)puVar9 = 0;
            uVar5 = puVar7[-6];
            uVar4 = puVar7[-5];
            uVar3 = puVar7[-4];
            *puVar9 = *puVar8;
            puVar1[2] = uVar5;
            puVar1[3] = uVar4;
            puVar1[4] = uVar3;
            uVar5 = puVar7[-2];
            puVar1[5] = puVar7[-3];
            puVar1[6] = uVar5;
            puVar7[-3] = 0;
            puVar7[-2] = 0xf;
            *(undefined *)puVar8 = 0;
          }
          puVar1 = puVar7 + -8;
          puVar7 = puVar8;
        }
        *puVar1 = uVar6;
        puVar7 = puVar1 + 1;
        if (puVar7 != &uStack_30) {
          uVar6 = puVar1[6];
          if (0xf < uVar6) {
            uVar5 = *puVar7;
            uVar3 = uVar6 + 1;
            uVar4 = uVar5;
            if (0xfff < uVar3) {
              uVar4 = *(uint *)(uVar5 - 4);
              uVar3 = uVar6 + 0x24;
              if (0x1f < (uVar5 - uVar4) - 4) goto LAB_007bf547;
            }
            FUN_01674ea0(uVar4,uVar3);
          }
          puVar1[5] = 0;
          puVar1[6] = 0xf;
          *puVar7 = uStack_30;
          puVar1[2] = uStack_2c;
          puVar1[3] = uStack_28;
          puVar1[4] = uStack_24;
          *(ulonglong *)(puVar1 + 5) = CONCAT44(uStack_1c,uStack_20);
          goto LAB_007bf3b2;
        }
      }
      else {
        if (param_1 != puStack_14) {
          puVar1 = puVar7 + 7;
          do {
            puVar7 = puVar1 + -7;
            puVar1[-8] = puVar1[-0xf];
            if (puVar7 != puVar1 + -0xe) {
              uVar5 = puVar1[-2];
              if (0xf < uVar5) {
                uVar4 = *puVar7;
                uVar2 = uVar5 + 1;
                uVar3 = uVar4;
                if (0xfff < uVar2) {
                  uVar3 = *(uint *)(uVar4 - 4);
                  uVar2 = uVar5 + 0x24;
                  if (0x1f < (uVar4 - uVar3) - 4) goto LAB_007bf547;
                }
                FUN_01674ea0(uVar3,uVar2);
              }
              puVar1[-3] = 0;
              puVar1[-2] = 0xf;
              *(undefined *)puVar7 = 0;
              *puVar7 = puVar1[-0xe];
              puVar1[-6] = puVar1[-0xd];
              puVar1[-5] = puVar1[-0xc];
              puVar1[-4] = puVar1[-0xb];
              puVar1[-3] = puVar1[-10];
              puVar1[-2] = puVar1[-9];
              puVar1[-10] = 0;
              puVar1[-9] = 0xf;
              *(undefined *)(puVar1 + -0xe) = 0;
            }
            puVar8 = puVar1 + -0xf;
            puVar1 = puVar7;
          } while (param_1 != puVar8);
        }
        puVar1 = param_1 + 1;
        *param_1 = uVar6;
        if (puVar1 != &uStack_30) {
          uVar6 = param_1[6];
          if (0xf < uVar6) {
            uVar5 = *puVar1;
            uVar3 = uVar6 + 1;
            uVar4 = uVar5;
            if (0xfff < uVar3) {
              uVar4 = *(uint *)(uVar5 - 4);
              uVar3 = uVar6 + 0x24;
              if (0x1f < (uVar5 - uVar4) - 4) goto LAB_007bf547;
            }
            FUN_01674ea0(uVar4,uVar3);
          }
          param_1[5] = 0;
          param_1[6] = 0xf;
          *puVar1 = uStack_30;
          param_1[2] = uStack_2c;
          param_1[3] = uStack_28;
          param_1[4] = uStack_24;
          *(ulonglong *)(param_1 + 5) = CONCAT44(uStack_1c,uStack_20);
LAB_007bf3b2:
          uStack_20 = 0;
          uStack_1c = 0xf;
          uStack_30 = uStack_30 & 0xffffff00;
        }
      }
      uStack_8 = 0xffffffff;
      if (0xf < uStack_1c) {
        uVar6 = uStack_1c + 1;
        uVar5 = uStack_30;
        if (0xfff < uVar6) {
          uVar5 = *(uint *)(uStack_30 - 4);
          uVar6 = uStack_1c + 0x24;
          if (0x1f < (uStack_30 - uVar5) - 4) {
LAB_007bf547:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar6);
      }
      puVar1 = puStack_14 + 7;
      puVar7 = puStack_18 + 7;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11708 ; VA 0x007bf550 ; FUN_007bf550 */

void FUN_007bf550(uint *param_1,uint *param_2,uint *param_3)

{
  char cVar1;
  
  cVar1 = *param_2 < *param_1;
  if (*param_2 == *param_1) {
    cVar1 = FUN_00558ea0(param_2 + 1,param_1 + 1);
  }
  if (cVar1 != '\0') {
    FUN_007c0d20(param_2,param_1);
  }
  cVar1 = *param_3 < *param_2;
  if (*param_3 == *param_2) {
    cVar1 = FUN_00558ea0(param_3 + 1,param_2 + 1);
  }
  if (cVar1 != '\0') {
    FUN_007c0d20(param_3,param_2);
    cVar1 = *param_2 < *param_1;
    if (*param_2 == *param_1) {
      cVar1 = FUN_00558ea0(param_2 + 1,param_1 + 1);
    }
    if (cVar1 != '\0') {
      FUN_007c0d20(param_2,param_1);
    }
  }
  return;
}



/* FUNCTION 11709 ; VA 0x007bf5e0 ; FUN_007bf5e0 */

void FUN_007bf5e0(undefined4 *param_1,uint *param_2,uint *param_3,uint *param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  uint *puVar10;
  char cVar11;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  undefined8 uStack_74;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  uint uStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puVar7 = param_2 + (((int)param_3 - (int)param_2) / 0x1c >> 1) * 7;
  iVar1 = ((int)(param_3 + -7) - (int)param_2) / 0x1c;
  puStack_8 = puVar7;
  if (iVar1 < 0x29) {
    FUN_007bf550(param_2,puVar7,param_3 + -7,param_4);
  }
  else {
    iVar1 = iVar1 + 1 >> 3;
    puStack_c = (uint *)(iVar1 * 0x38);
    FUN_007bf550(param_2,param_2 + iVar1 * 7,param_2 + iVar1 * 0xe,param_4);
    FUN_007bf550(puStack_8 + iVar1 * -7,puStack_8,puStack_8 + iVar1 * 7,param_4);
    puVar10 = param_3 + -7;
    FUN_007bf550((int)puVar10 - (int)puStack_c,puVar10 + iVar1 * -7,puVar10,param_4);
    puVar7 = puStack_8;
    FUN_007bf550(param_2 + iVar1 * 7,puStack_8,puVar10 + iVar1 * -7,param_4);
  }
  param_4 = puVar7 + 7;
  puVar10 = puVar7;
  puStack_c = puVar7;
  puVar9 = puStack_8;
  if (param_2 < puVar7) {
    while( true ) {
      cVar11 = puVar10[-7] < *puVar10;
      if (puVar10[-7] == *puVar10) {
        puStack_c = puVar10;
        cVar11 = FUN_00558ea0(puVar10 + -6,puVar10 + 1);
      }
      puStack_c = puVar10;
      puVar9 = puVar10;
      if (cVar11 != '\0') break;
      cVar11 = *puVar10 < puVar10[-7];
      if (*puVar10 == puVar10[-7]) {
        cVar11 = FUN_00558ea0(puVar10 + 1,puVar10 + -6);
      }
      puStack_c = puVar10;
      if ((cVar11 != '\0') ||
         (puStack_c = puVar10 + -7, puVar10 = puStack_c, puVar9 = puStack_c, puStack_c <= param_2))
      break;
    }
  }
  puStack_8 = puVar9;
  puVar10 = puStack_c;
  puVar9 = puStack_c;
  puVar8 = param_4;
  if (param_4 < param_3) {
    puVar7 = puVar7 + 8;
    do {
      cVar11 = *param_4 < *puVar10;
      if (*param_4 == *puVar10) {
        cVar11 = FUN_00558ea0(puVar7,puVar10 + 1);
      }
      puVar9 = puStack_8;
      puVar8 = param_4;
      if (cVar11 != '\0') break;
      cVar11 = *puVar10 < *param_4;
      if (*puVar10 == *param_4) {
        cVar11 = FUN_00558ea0(puVar10 + 1,puVar7);
      }
      puVar9 = puStack_8;
      puVar8 = param_4;
      if (cVar11 != '\0') break;
      param_4 = param_4 + 7;
      puVar7 = puVar7 + 7;
      puVar8 = param_4;
    } while (param_4 < param_3);
  }
LAB_007bf7a0:
  do {
    puStack_8 = puVar8;
    puVar7 = puVar10;
    if (puStack_8 < param_3) {
      puVar10 = puStack_8 + 1;
      puVar8 = param_4 + 1;
      do {
        cVar11 = *puVar9 < *puStack_8;
        if (*puVar9 == *puStack_8) {
          cVar11 = FUN_00558ea0(puVar9 + 1,puVar10);
        }
        if (cVar11 == '\0') {
          cVar11 = *puStack_8 < *puVar9;
          if (*puStack_8 == *puVar9) {
            cVar11 = FUN_00558ea0(puVar10,puVar9 + 1);
          }
          puVar7 = puStack_c;
          if (cVar11 != '\0') break;
          if (param_4 != puStack_8) {
            uStack_10 = *param_4;
            uStack_4c = *puVar8;
            uStack_48 = puVar8[1];
            uStack_44 = puVar8[2];
            uStack_40 = puVar8[3];
            uStack_18 = *(undefined8 *)(puVar8 + 2);
            uStack_3c = puVar8[4];
            uStack_38 = puVar8[5];
            uStack_34 = *(undefined8 *)(puVar8 + 4);
            puVar8[4] = 0;
            puVar8[5] = 0xf;
            *(undefined *)puVar8 = 0;
            *param_4 = *puStack_8;
            uStack_20 = uStack_4c;
            uStack_1c = uStack_48;
            if (puVar8 != puVar10) {
              uVar5 = puVar8[5];
              if (0xf < uVar5) {
                uVar3 = uVar5 + 1;
                uVar2 = *puVar8;
                uVar4 = uVar2;
                if (0xfff < uVar3) {
                  uVar4 = *(uint *)(uVar2 - 4);
                  uVar3 = uVar5 + 0x24;
                  if (0x1f < (uVar2 - uVar4) - 4) goto LAB_007bfdc4;
                }
                FUN_01674ea0(uVar4,uVar3);
              }
              puVar8[4] = 0;
              puVar8[5] = 0xf;
              *(undefined *)puVar8 = 0;
              uVar5 = puVar10[1];
              uVar3 = puVar10[2];
              uVar2 = puVar10[3];
              *puVar8 = *puVar10;
              puVar8[1] = uVar5;
              puVar8[2] = uVar3;
              puVar8[3] = uVar2;
              uVar5 = puVar10[5];
              puVar8[4] = puVar10[4];
              puVar8[5] = uVar5;
              puVar10[4] = 0;
              puVar10[5] = 0xf;
              *(undefined *)puVar10 = 0;
            }
            *puStack_8 = uStack_10;
            if (puVar10 == &uStack_4c) {
              if (0xf < uStack_38) {
                uVar5 = uStack_38 + 1;
                uVar3 = uStack_4c;
                if (0xfff < uVar5) {
                  uVar3 = *(uint *)(uStack_4c - 4);
                  uVar5 = uStack_38 + 0x24;
                  if (0x1f < (uStack_4c - uVar3) - 4) goto LAB_007bfdc4;
                }
                FUN_01674ea0(uVar3,uVar5);
              }
            }
            else {
              uVar5 = puVar10[5];
              if (0xf < uVar5) {
                uVar3 = *puVar10;
                uVar4 = uVar5 + 1;
                uVar2 = uVar3;
                if (0xfff < uVar4) {
                  uVar2 = *(uint *)(uVar3 - 4);
                  uVar4 = uVar5 + 0x24;
                  if (0x1f < (uVar3 - uVar2) - 4) goto LAB_007bfdc4;
                }
                FUN_01674ea0(uVar2,uVar4);
              }
              puVar10[4] = 0;
              *puVar10 = uStack_20;
              puVar10[1] = uStack_1c;
              puVar10[2] = (uint)uStack_18;
              puVar10[3] = uStack_18._4_4_;
              puVar10[4] = (uint)uStack_34;
              puVar10[5] = uStack_34._4_4_;
            }
          }
          param_4 = param_4 + 7;
          puVar8 = puVar8 + 7;
        }
        puStack_8 = puStack_8 + 7;
        puVar10 = puVar10 + 7;
        puVar7 = puStack_c;
      } while (puStack_8 < param_3);
    }
    if (param_2 < puVar7) {
      puVar10 = puVar7 + -6;
      puVar8 = puVar9;
      do {
        cVar11 = puVar10[-1] < *puVar8;
        if (puVar10[-1] == *puVar8) {
          cVar11 = FUN_00558ea0(puVar10,puVar8 + 1);
        }
        puVar9 = puVar8;
        if (cVar11 == '\0') {
          cVar11 = *puVar8 < puVar10[-1];
          if (*puVar8 == puVar10[-1]) {
            cVar11 = FUN_00558ea0(puVar8 + 1,puVar10);
          }
          if (cVar11 != '\0') break;
          puVar9 = puVar8 + -7;
          if (puVar9 != puVar10 + -1) {
            uStack_68 = puVar8[-6];
            uStack_64 = puVar8[-5];
            uStack_60 = puVar8[-4];
            uStack_5c = puVar8[-3];
            uStack_18 = *(undefined8 *)(puVar8 + -4);
            uStack_10 = *puVar9;
            puVar7 = puVar8 + -6;
            uStack_58 = puVar8[-2];
            uStack_54 = puVar8[-1];
            uStack_34 = *(undefined8 *)(puVar8 + -2);
            puVar8[-2] = 0;
            puVar8[-1] = 0xf;
            *(undefined *)puVar7 = 0;
            *puVar9 = puVar10[-1];
            uStack_20 = uStack_68;
            uStack_1c = uStack_64;
            if (puVar7 != puVar10) {
              uVar5 = puVar8[-1];
              if (0xf < uVar5) {
                uVar3 = *puVar7;
                uVar4 = uVar5 + 1;
                uVar2 = uVar3;
                if (0xfff < uVar4) {
                  uVar2 = *(uint *)(uVar3 - 4);
                  uVar4 = uVar5 + 0x24;
                  if (0x1f < (uVar3 - uVar2) - 4) goto LAB_007bfdc4;
                }
                FUN_01674ea0(uVar2,uVar4);
              }
              puVar8[-2] = 0;
              puVar8[-1] = 0xf;
              *(undefined *)puVar7 = 0;
              uVar5 = puVar10[1];
              uVar3 = puVar10[2];
              uVar2 = puVar10[3];
              *puVar7 = *puVar10;
              puVar8[-5] = uVar5;
              puVar8[-4] = uVar3;
              puVar8[-3] = uVar2;
              uVar5 = puVar10[5];
              puVar8[-2] = puVar10[4];
              puVar8[-1] = uVar5;
              puVar10[4] = 0;
              puVar10[5] = 0xf;
              *(undefined *)puVar10 = 0;
            }
            puVar10[-1] = uStack_10;
            if (puVar10 == &uStack_68) {
              puVar7 = puStack_c;
              if (0xf < uStack_54) {
                uVar3 = uStack_54 + 1;
                uVar5 = uStack_68;
                if (0xfff < uVar3) {
                  uVar5 = *(uint *)(uStack_68 - 4);
                  uVar3 = uStack_54 + 0x24;
                  if (0x1f < (uStack_68 - uVar5) - 4) goto LAB_007bfdc4;
                }
                FUN_01674ea0(uVar5,uVar3);
                puVar7 = puStack_c;
              }
            }
            else {
              uVar5 = puVar10[5];
              if (0xf < uVar5) {
                uVar3 = *puVar10;
                uVar4 = uVar5 + 1;
                uVar2 = uVar3;
                if (0xfff < uVar4) {
                  uVar2 = *(uint *)(uVar3 - 4);
                  uVar4 = uVar5 + 0x24;
                  if (0x1f < (uVar3 - uVar2) - 4) goto LAB_007bfdc4;
                }
                FUN_01674ea0(uVar2,uVar4);
              }
              puVar10[4] = 0;
              *puVar10 = uStack_20;
              puVar10[1] = uStack_1c;
              puVar10[2] = (uint)uStack_18;
              puVar10[3] = uStack_18._4_4_;
              puVar10[4] = (uint)uStack_34;
              puVar10[5] = uStack_34._4_4_;
              puVar7 = puStack_c;
            }
          }
        }
        puVar7 = puVar7 + -7;
        puVar10 = puVar10 + -7;
        puVar8 = puVar9;
        puStack_c = puVar7;
      } while (param_2 < puVar7);
    }
    puVar10 = puStack_8;
    if (puVar7 != param_2) {
      puVar10 = puVar7 + -7;
      puStack_c = puVar10;
      if (puStack_8 == param_3) {
        puVar8 = puVar9 + -7;
        if (puVar10 != puVar8) {
          uStack_28 = puVar7[-6];
          uStack_24 = puVar7[-5];
          uStack_20 = puVar7[-4];
          uStack_1c = puVar7[-3];
          uStack_2c = *puVar10;
          uStack_18 = *(undefined8 *)(puVar7 + -2);
          puVar7[-2] = 0;
          puVar7[-1] = 0xf;
          *(undefined *)(puVar7 + -6) = 0;
          FUN_007c31d0(puVar8);
          FUN_007c31d0(&uStack_2c);
          FUN_0056c780();
        }
        uStack_28 = puVar9[-6];
        uStack_24 = puVar9[-5];
        uStack_20 = puVar9[-4];
        uStack_1c = puVar9[-3];
        uStack_2c = *puVar8;
        param_4 = param_4 + -7;
        uStack_18 = *(undefined8 *)(puVar9 + -2);
        puVar9[-2] = 0;
        puVar9[-1] = 0xf;
        *(undefined *)(puVar9 + -6) = 0;
        FUN_007c31d0(param_4);
        FUN_007c31d0(&uStack_2c);
        FUN_0056c780();
        puVar9 = puVar8;
        puVar10 = puStack_c;
        puVar8 = puStack_8;
      }
      else {
        FUN_007c12f0(puStack_8);
        FUN_007c31d0(puVar10);
        FUN_007c31d0(&uStack_2c);
        FUN_0056c780();
        puVar8 = puStack_8 + 7;
      }
      goto LAB_007bf7a0;
    }
    if (puStack_8 == param_3) {
      param_1[1] = param_4;
      *param_1 = puVar9;
      return;
    }
    if (param_4 != puStack_8) {
      uStack_84 = puVar9[1];
      uStack_80 = puVar9[2];
      uStack_7c = puVar9[3];
      uStack_78 = puVar9[4];
      uStack_18 = *(undefined8 *)(puVar9 + 3);
      uVar5 = *puVar9;
      puVar7 = puVar9 + 1;
      uStack_74 = *(undefined8 *)(puVar9 + 5);
      puVar9[5] = 0;
      puVar9[6] = 0xf;
      *(undefined *)puVar7 = 0;
      *puVar9 = *param_4;
      uStack_34 = uStack_74;
      uStack_20 = uStack_84;
      uStack_1c = uStack_80;
      if (puVar7 != param_4 + 1) {
        uVar3 = puVar9[6];
        if (0xf < uVar3) {
          uVar2 = *puVar7;
          uVar6 = uVar3 + 1;
          uVar4 = uVar2;
          if (0xfff < uVar6) {
            uVar4 = *(uint *)(uVar2 - 4);
            uVar6 = uVar3 + 0x24;
            if (0x1f < (uVar2 - uVar4) - 4) goto LAB_007bfdc4;
          }
          FUN_01674ea0(uVar4,uVar6);
        }
        puVar9[5] = 0;
        puVar9[6] = 0xf;
        *(undefined *)(puVar9 + 1) = 0;
        uVar3 = param_4[2];
        uVar2 = param_4[3];
        uVar4 = param_4[4];
        puVar9[1] = param_4[1];
        puVar9[2] = uVar3;
        puVar9[3] = uVar2;
        puVar9[4] = uVar4;
        *(undefined8 *)(puVar9 + 5) = *(undefined8 *)(param_4 + 5);
        param_4[5] = 0;
        param_4[6] = 0xf;
        *(undefined *)(param_4 + 1) = 0;
      }
      *param_4 = uVar5;
      if (param_4 + 1 == &uStack_84) {
        if (0xf < uStack_74._4_4_) {
          uVar3 = uStack_74._4_4_ + 1;
          uVar5 = uStack_84;
          if (0xfff < uVar3) {
            uVar5 = *(uint *)(uStack_84 - 4);
            uVar3 = uStack_74._4_4_ + 0x24;
            if (0x1f < (uStack_84 - uVar5) - 4) goto LAB_007bfdc4;
          }
          FUN_01674ea0(uVar5,uVar3);
        }
      }
      else {
        uVar5 = param_4[6];
        if (0xf < uVar5) {
          uVar3 = param_4[1];
          uVar4 = uVar5 + 1;
          uVar2 = uVar3;
          if (0xfff < uVar4) {
            uVar2 = *(uint *)(uVar3 - 4);
            uVar4 = uVar5 + 0x24;
            if (0x1f < (uVar3 - uVar2) - 4) {
LAB_007bfdc4:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar2,uVar4);
        }
        param_4[5] = 0;
        param_4[6] = 0xf;
        *(undefined *)(param_4 + 1) = 0;
        param_4[1] = uStack_20;
        param_4[2] = uStack_1c;
        param_4[3] = (uint)uStack_18;
        param_4[4] = uStack_18._4_4_;
        *(undefined8 *)(param_4 + 5) = uStack_34;
      }
    }
    uStack_28 = puVar9[1];
    uStack_24 = puVar9[2];
    uStack_20 = puVar9[3];
    uStack_1c = puVar9[4];
    uStack_2c = *puVar9;
    param_4 = param_4 + 7;
    uStack_18 = *(undefined8 *)(puVar9 + 5);
    puVar9[5] = 0;
    puVar9[6] = 0xf;
    *(undefined *)(puVar9 + 1) = 0;
    FUN_007c31d0(puVar10);
    FUN_007c31d0(&uStack_2c);
    FUN_0056c780();
    puVar9 = puVar9 + 7;
    puVar10 = puStack_c;
    puVar8 = puStack_8 + 7;
  } while( true );
}



/* FUNCTION 11710 ; VA 0x007bfdd0 ; FUN_007bfdd0 */

void FUN_007bfdd0(int param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  int *piVar14;
  
  iVar1 = param_3 - 1;
  iVar8 = iVar1 >> 1;
  iVar13 = param_2;
  iVar12 = param_2;
  if (param_2 < iVar8) {
    do {
      iVar13 = param_1 + iVar12 * 0x38;
      if (*(uint *)(iVar13 + 0x38) == *(uint *)(iVar13 + 0x1c)) {
        uVar9 = FUN_00558ea0(iVar13 + 0x3c,iVar13 + 0x20);
      }
      else {
        uVar9 = (uint)(*(uint *)(iVar13 + 0x38) < *(uint *)(iVar13 + 0x1c));
      }
      iVar13 = iVar12 * 2 + (uVar9 & 0xff ^ 1) + 1;
      puVar3 = (undefined4 *)(param_1 + iVar13 * 0x1c);
      puVar4 = (undefined4 *)(param_1 + iVar12 * 0x1c);
      *puVar4 = *puVar3;
      piVar2 = puVar3 + 1;
      piVar14 = puVar4 + 1;
      if (piVar14 != piVar2) {
        uVar9 = puVar4[6];
        if (0xf < uVar9) {
          iVar12 = *piVar14;
          uVar11 = uVar9 + 1;
          iVar10 = iVar12;
          if (0xfff < uVar11) {
            iVar10 = *(int *)(iVar12 + -4);
            uVar11 = uVar9 + 0x24;
            if (0x1f < (iVar12 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar10,uVar11);
        }
        puVar4[5] = 0;
        puVar4[6] = 0xf;
        *(undefined *)piVar14 = 0;
        uVar5 = puVar3[2];
        uVar6 = puVar3[3];
        uVar7 = puVar3[4];
        *piVar14 = *piVar2;
        puVar4[2] = uVar5;
        puVar4[3] = uVar6;
        puVar4[4] = uVar7;
        uVar5 = puVar3[6];
        puVar4[5] = puVar3[5];
        puVar4[6] = uVar5;
        puVar3[5] = 0;
        puVar3[6] = 0xf;
        *(undefined *)piVar2 = 0;
      }
      iVar12 = iVar13;
    } while (iVar13 < iVar8);
  }
  if ((iVar13 == iVar8) && ((param_3 & 1) == 0)) {
    iVar12 = param_1 + param_3 * 0x1c;
    puVar3 = (undefined4 *)(iVar12 + -0x18);
    puVar4 = (undefined4 *)(param_1 + iVar13 * 0x1c);
    *puVar4 = *(undefined4 *)(iVar12 + -0x1c);
    iVar13 = iVar1;
    if (puVar4 + 1 != puVar3) {
      FUN_005507b0();
      uVar5 = *(undefined4 *)(iVar12 + -0x14);
      uVar6 = *(undefined4 *)(iVar12 + -0x10);
      uVar7 = *(undefined4 *)(iVar12 + -0xc);
      puVar4[1] = *puVar3;
      puVar4[2] = uVar5;
      puVar4[3] = uVar6;
      puVar4[4] = uVar7;
      *(undefined8 *)(puVar4 + 5) = *(undefined8 *)(iVar12 + -8);
      *(undefined4 *)(iVar12 + -8) = 0;
      *(undefined4 *)(iVar12 + -4) = 0xf;
      *(undefined *)puVar3 = 0;
    }
  }
  FUN_007c0010(param_1,iVar13,param_2,param_4,param_5);
  return;
}



/* FUNCTION 11711 ; VA 0x007bff50 ; FUN_007bff50 */

void FUN_007bff50(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  float *pfVar3;
  float fVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  
  iVar10 = (int)(param_3 - 1) >> 1;
  iVar8 = param_2;
  iVar9 = param_2;
  if (param_2 < iVar10) {
    do {
      fVar4 = *(float *)(param_1 + 0x18 + iVar8 * 0x20);
      pfVar3 = (float *)(param_1 + 0x28 + iVar8 * 0x20);
      iVar9 = ((*pfVar3 <= fVar4 && fVar4 != *pfVar3) ^ 1) + 1 + iVar8 * 2;
      puVar1 = (undefined4 *)(param_1 + iVar9 * 0x10);
      uVar5 = puVar1[1];
      uVar6 = puVar1[2];
      uVar7 = puVar1[3];
      puVar2 = (undefined4 *)(param_1 + iVar8 * 0x10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar5;
      puVar2[2] = uVar6;
      puVar2[3] = uVar7;
      iVar8 = iVar9;
    } while (iVar9 < iVar10);
  }
  if ((iVar9 == iVar10) && ((param_3 & 1) == 0)) {
    puVar2 = (undefined4 *)(param_1 + -0x10 + param_3 * 0x10);
    uVar5 = puVar2[1];
    uVar6 = puVar2[2];
    uVar7 = puVar2[3];
    puVar1 = (undefined4 *)(param_1 + iVar9 * 0x10);
    *puVar1 = *puVar2;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    iVar9 = param_3 - 1;
  }
  while ((param_2 < iVar9 &&
         (iVar8 = iVar9 + -1 >> 1, pfVar3 = (float *)(param_1 + 8 + iVar8 * 0x10),
         *pfVar3 <= (float)param_4[2] && (float)param_4[2] != *pfVar3))) {
    puVar1 = (undefined4 *)(param_1 + iVar8 * 0x10);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + iVar9 * 0x10);
    *puVar2 = *puVar1;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    iVar9 = iVar8;
  }
  uVar5 = param_4[1];
  uVar6 = param_4[2];
  uVar7 = param_4[3];
  puVar1 = (undefined4 *)(param_1 + iVar9 * 0x10);
  *puVar1 = *param_4;
  puVar1[1] = uVar5;
  puVar1[2] = uVar6;
  puVar1[3] = uVar7;
  return;
}



/* FUNCTION 11712 ; VA 0x007c0010 ; FUN_007c0010 */

void FUN_007c0010(int param_1,int param_2,int param_3,uint *param_4)

{
  uint *puVar1;
  uint *puVar2;
  uint *puVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  char cVar10;
  
  if (param_3 < param_2) {
    do {
      iVar9 = param_2 + -1 >> 1;
      puVar2 = (uint *)(param_1 + iVar9 * 0x1c);
      puVar1 = puVar2 + 1;
      cVar10 = *puVar2 < *param_4;
      if (*puVar2 == *param_4) {
        cVar10 = FUN_00558ea0(puVar1,param_4 + 1);
      }
      if (cVar10 == '\0') break;
      puVar3 = (uint *)(param_1 + param_2 * 0x1c);
      puVar4 = puVar3 + 1;
      *puVar3 = *puVar2;
      if (puVar4 != puVar1) {
        uVar5 = puVar3[6];
        if (0xf < uVar5) {
          uVar6 = *puVar4;
          uVar8 = uVar5 + 1;
          uVar7 = uVar6;
          if (0xfff < uVar8) {
            uVar7 = *(uint *)(uVar6 - 4);
            uVar8 = uVar5 + 0x24;
            if (0x1f < (uVar6 - uVar7) - 4) goto LAB_007c0177;
          }
          FUN_01674ea0(uVar7,uVar8);
        }
        puVar3[5] = 0;
        puVar3[6] = 0xf;
        *(undefined *)puVar4 = 0;
        uVar5 = puVar2[2];
        uVar6 = puVar2[3];
        uVar7 = puVar2[4];
        *puVar4 = *puVar1;
        puVar3[2] = uVar5;
        puVar3[3] = uVar6;
        puVar3[4] = uVar7;
        uVar5 = puVar2[6];
        puVar3[5] = puVar2[5];
        puVar3[6] = uVar5;
        puVar2[5] = 0;
        puVar2[6] = 0xf;
        *(undefined *)puVar1 = 0;
      }
      param_2 = iVar9;
    } while (param_3 < iVar9);
  }
  puVar4 = (uint *)(param_1 + param_2 * 0x1c);
  puVar1 = puVar4 + 1;
  puVar2 = param_4 + 1;
  *puVar4 = *param_4;
  if (puVar1 != puVar2) {
    uVar5 = puVar4[6];
    if (0xf < uVar5) {
      uVar6 = *puVar1;
      uVar8 = uVar5 + 1;
      uVar7 = uVar6;
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(uVar6 - 4);
        uVar8 = uVar5 + 0x24;
        if (0x1f < (uVar6 - uVar7) - 4) {
LAB_007c0177:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    puVar4[5] = 0;
    puVar4[6] = 0xf;
    *(undefined *)puVar1 = 0;
    uVar5 = param_4[2];
    uVar6 = param_4[3];
    uVar7 = param_4[4];
    *puVar1 = *puVar2;
    puVar4[2] = uVar5;
    puVar4[3] = uVar6;
    puVar4[4] = uVar7;
    *(undefined8 *)(puVar4 + 5) = *(undefined8 *)(param_4 + 5);
    param_4[5] = 0;
    param_4[6] = 0xf;
    *(undefined *)puVar2 = 0;
  }
  return;
}



/* FUNCTION 11713 ; VA 0x007c0180 ; FUN_007c0180 */

void __thiscall FUN_007c0180(int *param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  
  uVar3 = param_2;
  puVar5 = (undefined4 *)param_1[1];
  iVar7 = *param_1;
  uVar8 = (int)puVar5 - iVar7 >> 3;
  uVar6 = param_1[2] - iVar7 >> 3;
  if (uVar6 < param_2) {
    if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2;
    if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar1 = (uVar6 >> 1) + uVar6, uVar1 < param_2)) {
      uVar1 = param_2;
    }
    param_2 = uVar1;
    iVar4 = FUN_00578020(param_2);
    puVar5 = (undefined4 *)(iVar4 + uVar8 * 8);
    for (iVar7 = uVar3 - uVar8; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5 = puVar5 + 2;
    }
    puVar5 = (undefined4 *)*param_1;
    puVar2 = (undefined4 *)param_1[1];
    if (puVar5 != puVar2) {
      iVar7 = iVar4 - (int)puVar5;
      do {
        *(undefined4 *)(iVar7 + (int)puVar5) = *puVar5;
        *(undefined4 *)(iVar7 + 4 + (int)puVar5) = puVar5[1];
        puVar5 = puVar5 + 2;
      } while (puVar5 != puVar2);
    }
    FUN_00654980(iVar4,uVar3,param_2);
    return;
  }
  if (uVar8 < param_2) {
    iVar7 = param_2 - uVar8;
    if (iVar7 != 0) {
      do {
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5 = puVar5 + 2;
        iVar7 = iVar7 + -1;
      } while (iVar7 != 0);
      param_1[1] = (int)puVar5;
      return;
    }
  }
  else {
    if (param_2 == uVar8) {
      return;
    }
    puVar5 = (undefined4 *)(iVar7 + param_2 * 8);
  }
  param_1[1] = (int)puVar5;
  return;
}



/* FUNCTION 11714 ; VA 0x007c0280 ; FUN_007c0280 */

void __thiscall FUN_007c0280(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2e10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Graphics::GuiCluster>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11715 ; VA 0x007c02ee ; Catch_All@007c02ee */

void Catch_All_007c02ee(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11716 ; VA 0x007c0310 ; FUN_007c0310 */

void FUN_007c0310(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2e28;
  pvStack_10 = ExceptionList;
  iVar2 = (param_2 - (int)param_1) / 0x1c;
  if (1 < iVar2) {
    piVar6 = (int *)(param_2 + -0x18);
    iStack_14 = 0x18 - (int)param_1;
    ExceptionList = &pvStack_10;
    do {
      if (1 < iVar2) {
        iStack_2c = *piVar6;
        iStack_28 = piVar6[1];
        iStack_24 = piVar6[2];
        iStack_20 = piVar6[3];
        iStack_30 = piVar6[-1];
        iStack_1c = piVar6[4];
        uStack_18 = piVar6[5];
        piVar6[4] = 0;
        piVar6[5] = 0xf;
        *(undefined *)piVar6 = 0;
        piVar7 = param_1 + 1;
        uStack_8 = 0;
        piVar6[-1] = *param_1;
        if (piVar6 != piVar7) {
          uVar5 = piVar6[5];
          if (0xf < uVar5) {
            iVar2 = *piVar6;
            uVar4 = uVar5 + 1;
            iVar3 = iVar2;
            if (0xfff < uVar4) {
              iVar3 = *(int *)(iVar2 + -4);
              uVar4 = uVar5 + 0x24;
              if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_007c04b7;
            }
            FUN_01674ea0(iVar3,uVar4);
          }
          piVar6[4] = 0;
          piVar6[5] = 0xf;
          *(undefined *)piVar6 = 0;
          iVar2 = param_1[2];
          iVar3 = param_1[3];
          iVar1 = param_1[4];
          *piVar6 = *piVar7;
          piVar6[1] = iVar2;
          piVar6[2] = iVar3;
          piVar6[3] = iVar1;
          iVar2 = param_1[6];
          piVar6[4] = param_1[5];
          piVar6[5] = iVar2;
          param_1[5] = 0;
          param_1[6] = 0xf;
          *(undefined *)piVar7 = 0;
        }
        FUN_007bfdd0(param_1,0,(int)((-4 - (int)param_1) + (int)piVar6) / 0x1c,&iStack_30,param_3);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_18) {
          uVar5 = uStack_18 + 1;
          iVar2 = iStack_2c;
          if (0xfff < uVar5) {
            iVar2 = *(int *)(iStack_2c + -4);
            uVar5 = uStack_18 + 0x24;
            if (0x1f < (iStack_2c - iVar2) - 4U) {
LAB_007c04b7:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar2,uVar5);
        }
      }
      piVar6 = piVar6 + -7;
      iVar2 = (int)(iStack_14 + (int)piVar6) / 0x1c;
    } while (1 < iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11717 ; VA 0x007c04c0 ; FUN_007c04c0 */

void FUN_007c04c0(int param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined *puVar4;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2df8;
  iVar1 = param_2 - param_1;
  pvStack_10 = ExceptionList;
  iVar2 = iStack_14;
  ExceptionList = &pvStack_10;
  do {
    iVar1 = iVar1 / 0x1c;
    if (iVar1 < 0x21) {
LAB_007c05bf:
      if (1 < iVar1) {
        FUN_007bf220(param_1,param_2,param_4);
      }
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar1) {
        iVar1 = (param_2 - param_1) / 0x1c;
        iStack_14 = iVar1 >> 1;
        if (0 < iStack_14) {
          puVar4 = (undefined *)(param_1 + (iStack_14 * 7 + 1) * 4);
          do {
            iStack_30 = *(int *)(puVar4 + -0x1c);
            uStack_2c = *(undefined4 *)(puVar4 + -0x18);
            uStack_28 = *(undefined4 *)(puVar4 + -0x14);
            uStack_24 = *(undefined4 *)(puVar4 + -0x10);
            uStack_34 = *(undefined4 *)(puVar4 + -0x20);
            iStack_14 = iStack_14 + -1;
            uStack_20 = *(undefined8 *)(puVar4 + -0xc);
            *(undefined4 *)(puVar4 + -0xc) = 0;
            *(undefined4 *)(puVar4 + -8) = 0xf;
            puVar4[-0x1c] = 0;
            uStack_8 = 0;
            FUN_007bfdd0(param_1,iStack_14,iVar1,&uStack_34,param_4);
            uStack_8 = 0xffffffff;
            if (0xf < uStack_20._4_4_) {
              uVar3 = uStack_20._4_4_ + 1;
              iVar2 = iStack_30;
              if (0xfff < uVar3) {
                iVar2 = *(int *)(iStack_30 + -4);
                uVar3 = uStack_20._4_4_ + 0x24;
                if (0x1f < (iStack_30 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(iVar2,uVar3);
            }
            puVar4 = puVar4 + -0x1c;
            iVar2 = iStack_14;
          } while (0 < iStack_14);
        }
        iStack_14 = iVar2;
        FUN_007c0310(param_1,param_2,param_4);
        ExceptionList = pvStack_10;
        return;
      }
      goto LAB_007c05bf;
    }
    iStack_14 = iVar2;
    FUN_007bf5e0(&iStack_18,param_1,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((iStack_18 - param_1) / 0x1c < (param_2 - iStack_14) / 0x1c) {
      FUN_007c04c0(param_1,iStack_18,param_3,param_4);
      param_1 = iStack_14;
    }
    else {
      FUN_007c04c0(iStack_14,param_2,param_3,param_4);
      param_2 = iStack_18;
    }
    iVar1 = param_2 - param_1;
    iVar2 = iStack_14;
  } while( true );
}



/* FUNCTION 11718 ; VA 0x007c06e0 ; FUN_007c06e0 */

void FUN_007c06e0(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  float fVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  int iVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  int iVar16;
  undefined4 *puVar17;
  undefined4 *puVar18;
  undefined4 *puVar19;
  undefined4 *puVar20;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  float fStack_18;
  undefined4 uStack_14;
  undefined4 *puStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar16 = (int)param_2 - (int)param_1;
  puVar15 = param_1;
  puVar20 = param_2;
  do {
    iVar9 = iVar16 >> 4;
    param_2 = puVar20;
    if (iVar9 < 0x21) {
LAB_007c08d1:
      if (((1 < iVar9) && (puVar15 != puVar20)) && (puVar18 = puVar15 + 4, puVar18 != puVar20)) {
        param_1 = (undefined4 *)0x10;
        do {
          uStack_20 = *puVar18;
          uStack_1c = puVar18[1];
          fStack_18 = (float)puVar18[2];
          uStack_14 = puVar18[3];
          if ((float)puVar15[2] <= fStack_18) {
            fVar1 = *(float *)((int)puVar15 + (int)param_1 + -8);
            puVar13 = (undefined4 *)((int)param_1 + -0x10 + (int)puVar15);
            puVar19 = puVar18;
            while (puVar14 = puVar13, fStack_18 < fVar1) {
              uVar2 = puVar14[1];
              uVar3 = puVar14[2];
              uVar4 = puVar14[3];
              *puVar19 = *puVar14;
              puVar19[1] = uVar2;
              puVar19[2] = uVar3;
              puVar19[3] = uVar4;
              puVar13 = puVar14 + -4;
              puVar19 = puVar14;
              fVar1 = (float)puVar14[-2];
            }
            *puVar19 = uStack_20;
            puVar19[1] = uStack_1c;
            puVar19[2] = fStack_18;
            puVar19[3] = uStack_14;
          }
          else {
            FUN_0055b6b0((int)&param_2 + 3,&puStack_10,&puStack_10);
            FUN_0170cc70(puVar15 + 4,puVar15,param_1);
            *puVar15 = uStack_20;
            puVar15[1] = uStack_1c;
            puVar15[2] = fStack_18;
            puVar15[3] = uStack_14;
          }
          puVar18 = puVar18 + 4;
          param_1 = (undefined4 *)((int)param_1 + 0x10);
        } while (puVar18 != puVar20);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar9) {
        uVar10 = (int)puVar20 - (int)puVar15 >> 4;
        iVar16 = (int)puVar20 - (int)puVar15 >> 5;
        if (0 < iVar16) {
          iStack_c = uVar10 - 1;
          puStack_10 = puVar15 + iVar16 * 4;
          do {
            uVar2 = puStack_10[-4];
            uVar3 = puStack_10[-3];
            fVar1 = (float)puStack_10[-2];
            uVar4 = puStack_10[-1];
            puStack_10 = puStack_10 + -4;
            iVar16 = iVar16 + -1;
            iVar9 = iVar16;
            while (iVar9 < iStack_c >> 1) {
              iVar12 = (((float)puVar15[iVar9 * 8 + 10] <= (float)puVar15[iVar9 * 8 + 6] &&
                        (float)puVar15[iVar9 * 8 + 6] != (float)puVar15[iVar9 * 8 + 10]) ^ 1) + 1 +
                       iVar9 * 2;
              puVar18 = puVar15 + iVar12 * 4;
              uVar5 = puVar18[1];
              uVar6 = puVar18[2];
              uVar7 = puVar18[3];
              puVar19 = puVar15 + iVar9 * 4;
              *puVar19 = *puVar18;
              puVar19[1] = uVar5;
              puVar19[2] = uVar6;
              puVar19[3] = uVar7;
              iVar9 = iVar12;
            }
            if ((iVar9 == iStack_c >> 1) && ((uVar10 & 1) == 0)) {
              puVar19 = puVar15 + uVar10 * 4 + -4;
              uVar5 = puVar19[1];
              uVar6 = puVar19[2];
              uVar7 = puVar19[3];
              puVar18 = puVar15 + iVar9 * 4;
              *puVar18 = *puVar19;
              puVar18[1] = uVar5;
              puVar18[2] = uVar6;
              puVar18[3] = uVar7;
              iVar9 = iStack_c;
            }
            while ((iVar16 < iVar9 &&
                   (iVar12 = iVar9 + -1 >> 1,
                   (float)puVar15[iVar12 * 4 + 2] <= fVar1 &&
                   fVar1 != (float)puVar15[iVar12 * 4 + 2]))) {
              puVar18 = puVar15 + iVar12 * 4;
              uVar5 = puVar18[1];
              uVar6 = puVar18[2];
              uVar7 = puVar18[3];
              puVar19 = puVar15 + iVar9 * 4;
              *puVar19 = *puVar18;
              puVar19[1] = uVar5;
              puVar19[2] = uVar6;
              puVar19[3] = uVar7;
              iVar9 = iVar12;
            }
            puVar18 = puVar15 + iVar9 * 4;
            *puVar18 = uVar2;
            puVar18[1] = uVar3;
            puVar18[2] = fVar1;
            puVar18[3] = uVar4;
            iStack_8 = iVar16;
          } while (0 < iVar16);
        }
        if ((int)uVar10 < 2) {
          return;
        }
        puVar20 = puVar20 + -4;
        do {
          if (1 < (int)uVar10) {
            uStack_20 = *puVar20;
            uStack_1c = puVar20[1];
            fStack_18 = (float)puVar20[2];
            uStack_14 = puVar20[3];
            uVar2 = puVar15[1];
            uVar3 = puVar15[2];
            uVar4 = puVar15[3];
            *puVar20 = *puVar15;
            puVar20[1] = uVar2;
            puVar20[2] = uVar3;
            puVar20[3] = uVar4;
            FUN_007bff50(puVar15,0,(int)puVar20 - (int)puVar15 >> 4,&uStack_20,param_4);
          }
          puVar20 = puVar20 + -4;
          uVar10 = (int)puVar20 + (0x10 - (int)puVar15) >> 4;
        } while (1 < (int)uVar10);
        return;
      }
      goto LAB_007c08d1;
    }
    puVar18 = puVar15 + (iVar16 >> 5) * 4;
    FUN_007be830(puVar15,puVar18,puVar20 + -4,param_4);
    puVar20 = puVar18 + 4;
    for (; puVar15 < puVar18; puVar18 = puVar18 + -4) {
      if (((float)puVar18[-2] < (float)puVar18[2]) || ((float)puVar18[2] < (float)puVar18[-2]))
      break;
    }
    puVar19 = puVar20;
    puVar13 = puVar18;
    if (puVar20 < param_2) {
      do {
        puVar19 = puVar20;
        if (((float)puVar20[2] < (float)puVar18[2]) || ((float)puVar18[2] < (float)puVar20[2]))
        break;
        puVar20 = puVar20 + 4;
        puVar19 = puVar20;
      } while (puVar20 < param_2);
    }
joined_r0x007c0782:
    puVar14 = puVar13;
    if (puVar20 < param_2) {
      if ((float)puVar20[2] <= (float)puVar18[2]) {
        if ((float)puVar20[2] < (float)puVar18[2]) goto joined_r0x007c07c0;
        if (puVar19 != puVar20) {
          uVar2 = puVar20[1];
          uVar3 = puVar20[2];
          uVar4 = puVar20[3];
          uVar5 = *puVar19;
          uVar6 = puVar19[1];
          uVar7 = puVar19[2];
          uVar8 = puVar19[3];
          *puVar19 = *puVar20;
          puVar19[1] = uVar2;
          puVar19[2] = uVar3;
          puVar19[3] = uVar4;
          *puVar20 = uVar5;
          puVar20[1] = uVar6;
          puVar20[2] = uVar7;
          puVar20[3] = uVar8;
        }
        puVar19 = puVar19 + 4;
      }
      puVar20 = puVar20 + 4;
      goto joined_r0x007c0782;
    }
joined_r0x007c07c0:
    for (; puVar15 < puVar13; puVar13 = puVar13 + -4) {
      puVar11 = puVar14 + -4;
      puVar17 = puVar18;
      if ((float)puVar18[2] <= (float)puVar14[-2]) {
        if ((float)puVar18[2] < (float)puVar14[-2]) break;
        puVar17 = puVar18 + -4;
        if (puVar17 != puVar11) {
          uVar2 = puVar14[-3];
          uVar3 = puVar14[-2];
          uVar4 = puVar14[-1];
          uVar5 = *puVar17;
          uVar6 = puVar18[-3];
          uVar7 = puVar18[-2];
          uVar8 = puVar18[-1];
          *puVar17 = *puVar11;
          puVar18[-3] = uVar2;
          puVar18[-2] = uVar3;
          puVar18[-1] = uVar4;
          *puVar11 = uVar5;
          puVar14[-3] = uVar6;
          puVar14[-2] = uVar7;
          puVar14[-1] = uVar8;
        }
      }
      puVar14 = puVar11;
      puVar18 = puVar17;
    }
    if (puVar13 != puVar15) {
      puVar14 = puVar13 + -4;
      if (puVar20 == param_2) {
        puVar17 = puVar18 + -4;
        if (puVar14 != puVar17) {
          uVar2 = puVar18[-3];
          uVar3 = puVar18[-2];
          uVar4 = puVar18[-1];
          uVar5 = *puVar14;
          uVar6 = puVar13[-3];
          uVar7 = puVar13[-2];
          uVar8 = puVar13[-1];
          *puVar14 = *puVar17;
          puVar13[-3] = uVar2;
          puVar13[-2] = uVar3;
          puVar13[-1] = uVar4;
          *puVar17 = uVar5;
          puVar18[-3] = uVar6;
          puVar18[-2] = uVar7;
          puVar18[-1] = uVar8;
        }
        uVar2 = puVar19[-3];
        uVar3 = puVar19[-2];
        uVar4 = puVar19[-1];
        uVar5 = *puVar17;
        uVar6 = puVar18[-3];
        uVar7 = puVar18[-2];
        uVar8 = puVar18[-1];
        *puVar17 = puVar19[-4];
        puVar18[-3] = uVar2;
        puVar18[-2] = uVar3;
        puVar18[-1] = uVar4;
        puVar19[-4] = uVar5;
        puVar19[-3] = uVar6;
        puVar19[-2] = uVar7;
        puVar19[-1] = uVar8;
        puVar19 = puVar19 + -4;
        puVar18 = puVar17;
        puVar13 = puVar14;
      }
      else {
        uVar2 = *puVar20;
        uVar3 = puVar20[1];
        uVar4 = puVar20[2];
        uVar5 = puVar20[3];
        uVar6 = puVar13[-3];
        uVar7 = puVar13[-2];
        uVar8 = puVar13[-1];
        *puVar20 = *puVar14;
        puVar20[1] = uVar6;
        puVar20[2] = uVar7;
        puVar20[3] = uVar8;
        puVar20 = puVar20 + 4;
        *puVar14 = uVar2;
        puVar13[-3] = uVar3;
        puVar13[-2] = uVar4;
        puVar13[-1] = uVar5;
        puVar13 = puVar14;
      }
      goto joined_r0x007c0782;
    }
    if (puVar20 != param_2) {
      if (puVar19 != puVar20) {
        uVar2 = puVar19[1];
        uVar3 = puVar19[2];
        uVar4 = puVar19[3];
        uVar5 = *puVar18;
        uVar6 = puVar18[1];
        uVar7 = puVar18[2];
        uVar8 = puVar18[3];
        *puVar18 = *puVar19;
        puVar18[1] = uVar2;
        puVar18[2] = uVar3;
        puVar18[3] = uVar4;
        *puVar19 = uVar5;
        puVar19[1] = uVar6;
        puVar19[2] = uVar7;
        puVar19[3] = uVar8;
      }
      uVar2 = puVar20[1];
      uVar3 = puVar20[2];
      uVar4 = puVar20[3];
      uVar5 = *puVar18;
      uVar6 = puVar18[1];
      uVar7 = puVar18[2];
      uVar8 = puVar18[3];
      *puVar18 = *puVar20;
      puVar18[1] = uVar2;
      puVar18[2] = uVar3;
      puVar18[3] = uVar4;
      *puVar20 = uVar5;
      puVar20[1] = uVar6;
      puVar20[2] = uVar7;
      puVar20[3] = uVar8;
      puVar20 = puVar20 + 4;
      puVar19 = puVar19 + 4;
      puVar18 = puVar18 + 4;
      goto joined_r0x007c0782;
    }
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puVar18 - (int)puVar15 & 0xfffffff0U) <
        (int)((int)param_2 - (int)puVar19 & 0xfffffff0U)) {
      FUN_007c06e0(puVar15,puVar18,param_3,param_4);
      puVar15 = puVar19;
    }
    else {
      FUN_007c06e0(puVar19,param_2,param_3,param_4);
      param_2 = puVar18;
    }
    iVar16 = (int)param_2 - (int)puVar15;
    puVar20 = param_2;
  } while( true );
}



/* FUNCTION 11719 ; VA 0x007c0ac0 ; FUN_007c0ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007c0ac0(int param_1,undefined4 *param_2,uint *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b2e48;
  pvStack_10 = ExceptionList;
  uVar2 = *param_3;
  uVar7 = (uVar2 >> 3) + uVar2;
  uVar6 = uVar7 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar8;
    }
    if (piVar4 == (int *)0x0) goto LAB_007c0b5e;
    do {
      if (uVar7 == piVar4[1]) {
        if (uVar2 == piVar4[2]) break;
      }
      else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar6) goto LAB_007c0b5e;
      piVar4 = (int *)*piVar4;
    } while (piVar4 != (int *)0x0);
  }
  if (piVar4 != (int *)0x0) {
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_007c0b5e:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_007c5ce0();
  _DAT_00000008 = *param_4;
  uVar6 = *(uint *)(param_1 + 8);
  uVar2 = uVar6 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar2 = FUN_005d6bb0(uVar2);
    if (uVar2 <= *(uint *)(param_1 + 4)) {
      uVar2 = *(uint *)(param_1 + 4);
    }
    FUN_007c5f90(uVar2);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar2) {
    uVar5 = uVar6 >> 1;
    if ((uVar6 >> 1) + uVar6 <= uVar2) {
      uVar5 = 1;
    }
    iVar3 = FUN_005d6bb0(uVar5 + uVar6);
    if (iVar3 != *(int *)(param_1 + 4)) {
      FUN_007c5f90(iVar3);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar8;
      while (puVar1 != (undefined4 *)0x0) {
        uVar2 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar4 = (int *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar2 * 4) == 0) {
          *piVar4 = (int)puVar8;
          puVar8 = puVar1;
        }
        else {
          *puVar8 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar8;
      }
    }
  }
  uVar2 = uVar7 % *(uint *)(param_1 + 4);
  piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  _DAT_00000004 = uVar7;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar4 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar8 = piVar4;
    _DAT_00000000 = *piVar4;
    *piVar4 = 0;
  }
  else {
    _DAT_00000000 = *piVar4;
    *(undefined4 *)*puVar8 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11720 ; VA 0x007c0ca0 ; FUN_007c0ca0 */

int __fastcall FUN_007c0ca0(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b63e30();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 11721 ; VA 0x007c0ce0 ; FUN_007c0ce0 */

int __fastcall FUN_007c0ce0(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d400b0();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 11722 ; VA 0x007c0d20 ; FUN_007c0d20 */

void FUN_007c0d20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int iStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined8 uStack_c;
  
  iStack_34 = param_1[1];
  uStack_30 = param_1[2];
  uStack_2c = param_1[3];
  uStack_28 = param_1[4];
  uVar3 = *param_1;
  piVar1 = param_1 + 1;
  piVar2 = param_2 + 1;
  uStack_24 = *(undefined8 *)(param_1 + 5);
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)piVar1 = 0;
  *param_1 = *param_2;
  iStack_1c = iStack_34;
  uStack_18 = uStack_30;
  uStack_14 = uStack_2c;
  uStack_10 = uStack_28;
  uStack_c = uStack_24;
  if (piVar1 != piVar2) {
    FUN_005507b0();
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    uVar6 = param_2[4];
    *piVar1 = *piVar2;
    param_1[2] = uVar4;
    param_1[3] = uVar5;
    param_1[4] = uVar6;
    *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 5);
    param_2[5] = 0;
    param_2[6] = 0xf;
    *(undefined *)piVar2 = 0;
  }
  *param_2 = uVar3;
  if (piVar2 != &iStack_34) {
    FUN_005507b0();
    *piVar2 = iStack_1c;
    param_2[2] = uStack_18;
    param_2[3] = uStack_14;
    param_2[4] = uStack_10;
    *(undefined8 *)(param_2 + 5) = uStack_c;
    return;
  }
  if (0xf < uStack_24._4_4_) {
    uVar8 = uStack_24._4_4_ + 1;
    iVar7 = iStack_34;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iStack_34 + -4);
      uVar8 = uStack_24._4_4_ + 0x24;
      if (0x1f < (iStack_34 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  return;
}



/* FUNCTION 11723 ; VA 0x007c0e00 ; FUN_007c0e00 */

int __thiscall FUN_007c0e00(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_007c0280(param_2,param_2);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 11724 ; VA 0x007c0e70 ; FUN_007c0e70 */

void * __thiscall FUN_007c0e70(int param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  piVar4 = *(int **)(param_1 + 0x2c);
  pvVar2 = ExceptionList;
  if (piVar4 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(param_1 + 0x30);
      piVar4 = *(int **)(param_1 + 0x2c);
    }
    iVar1 = piVar4[1];
    iVar5 = *piVar4;
    uStack_8 = 0;
    pvVar2 = pvStack_10;
    for (; iVar5 != iVar1; iVar5 = iVar5 + 8) {
      (*(code *)*param_2)(iVar5);
      pvVar2 = (void *)FUN_007c0e70(param_2);
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      pvVar2 = (void *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar2 = (void *)(**(code **)*piVar3)();
        LOCK();
        piVar4 = piVar3 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar2 = (void *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 11725 ; VA 0x007c0f20 ; FUN_007c0f20 */

undefined4 * __fastcall FUN_007c0f20(undefined4 *param_1)

{
  param_1[1] = 0;
  param_1[2] = 0;
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 11726 ; VA 0x007c0f50 ; FUN_007c0f50 */

undefined * __thiscall FUN_007c0f50(undefined *param_1,float *param_2,float param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  
  FUN_007c1010();
  FUN_007c74b0(0);
  *param_1 = 0;
  FUN_00621160(0);
  uVar4 = FUN_00588320(0xb);
  fVar3 = DAT_018ce2f8;
  *(undefined4 *)(param_1 + 4) = uVar4;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  fVar1 = param_2[2];
  fVar2 = *param_2;
  *(float *)(param_1 + 0x1c) = fVar3 / param_2[1];
  *(float *)(param_1 + 0x18) = fVar3 / fVar2;
  *(float *)(param_1 + 0x20) = fVar3 / fVar1;
  fVar1 = param_2[2];
  fVar2 = *param_2;
  *(float *)(param_1 + 0x28) = param_3 * param_2[1];
  *(float *)(param_1 + 0x2c) = fVar1 * param_3;
  *(float *)(param_1 + 0x24) = fVar2 * param_3;
  return param_1;
}



/* FUNCTION 11727 ; VA 0x007c1010 ; FUN_007c1010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __fastcall FUN_007c1010(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb31ca == '\0') {
    DAT_01eb31ca = '\x01';
    DAT_01eb31a4 = 0;
    uRam01eb31a8 = 0;
    uRam01eb31ac = 0;
    DAT_01eb31b0 = 0;
    _DAT_01eb31c4 = 0;
    DAT_01eb31b4 = _DAT_018ffab0;
    uRam01eb31b8 = _UNK_018ffab4;
    uRam01eb31bc = _UNK_018ffab8;
    uRam01eb31c0 = _UNK_018ffabc;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  iVar2 = DAT_01eb31b4;
  for (iVar1 = DAT_01eb31b0; iVar1 != 0; iVar1 = *(int *)(iVar1 + -8)) {
    iVar1 = iVar2 + iVar1;
    iVar2 = *(int *)(iVar1 + -4);
  }
  uStack_8 = 0;
  LOCK();
  uVar3 = DAT_01eb31a4 + 0x80000000;
  UNLOCK();
  uVar4 = uVar3;
  if (((DAT_01eb31a4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31a4)) {
    LOCK();
    DAT_01eb31a4 = uVar3 | 0x40000000;
    UNLOCK();
    uVar4 = DAT_01eb31a4;
    if ((uVar3 >> 0x1e & 1) == 0) {
      uVar5 = FUN_00554e40();
      SetEvent(uVar5);
      uVar4 = DAT_01eb31a4;
    }
  }
  DAT_01eb31a4 = uVar4;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11728 ; VA 0x007c10d0 ; FUN_007c10d0 */

undefined4 * __fastcall FUN_007c10d0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2e76;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00621160(0);
  *param_1 = 0;
  FUN_007c7590(0);
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_007c4070(0,0);
  param_1[1] = uVar1;
  uStack_8 = 0;
  FUN_00621160(0);
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0x3f800000;
  FUN_007c44a0(0x10);
  uStack_14 = param_1[1];
  FUN_007c53e0(0x10,&uStack_14);
  param_1[6] = 7;
  param_1[7] = 8;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11729 ; VA 0x007c11a0 ; FUN_007c11a0 */

uint * __thiscall FUN_007c11a0(uint *param_1,int *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2e88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar4 = (param_2[1] - *param_2) / 0x1c;
  if (uVar4 != 0) {
    if (0x9249249 < uVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar4 = uVar4 * 0x1c;
    if (uVar4 < 0x1000) {
      if (uVar4 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar4);
      }
    }
    else {
      uVar2 = uVar4 + 0x23;
      if (uVar2 <= uVar4) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar4;
    puVar5 = (undefined4 *)*param_1;
    puVar1 = (undefined4 *)param_2[1];
    puVar6 = (undefined4 *)*param_2;
    uStack_8 = 1;
    for (; puVar6 != puVar1; puVar6 = puVar6 + 7) {
      *puVar5 = *puVar6;
      FUN_0054ef60(puVar6 + 1);
      puVar5 = puVar5 + 7;
    }
    FUN_007be6b0(puVar5,puVar5,param_1);
    param_1[1] = (uint)puVar5;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11730 ; VA 0x007c12cf ; Catch_All@007c12cf */

void Catch_All_007c12cf(void)

{
  FUN_007c4590();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11731 ; VA 0x007c12f0 ; FUN_007c12f0 */

undefined4 * __thiscall FUN_007c12f0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = *param_2;
  param_1[5] = 0;
  param_1[6] = 0;
  uVar1 = param_2[2];
  uVar2 = param_2[3];
  uVar3 = param_2[4];
  param_1[1] = param_2[1];
  param_1[2] = uVar1;
  param_1[3] = uVar2;
  param_1[4] = uVar3;
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 5);
  param_2[5] = 0;
  param_2[6] = 0xf;
  *(undefined *)(param_2 + 1) = 0;
  return param_1;
}



/* FUNCTION 11732 ; VA 0x007c1340 ; FUN_007c1340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_007c1340(undefined4 *param_1,int param_2,int *param_3,int *param_4)

{
  int *piVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  char cVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  undefined *puVar11;
  undefined4 *puVar12;
  int *piVar13;
  float fVar14;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined2 uStack_38;
  undefined4 uStack_30;
  code *pcStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  iVar9 = (int)param_4;
  puStack_c = &LAB_017b3156;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::SceneUpdater::vftable;
  param_1[1] = *(undefined4 *)((int)param_4 + 0x510);
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  param_1[5] = param_2;
  param_1[6] = param_3;
  param_1[7] = *(undefined4 *)((int)param_4 + 0x524);
  param_1[8] = *(undefined4 *)((int)param_4 + 0x520);
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  uStack_8 = 6;
  uStack_7 = 0;
  puStack_1c = param_1;
  FUN_007c10d0();
  uStack_8 = 7;
  FUN_007c10d0();
  uStack_8 = 8;
  FUN_007c10d0();
  puVar2 = (undefined8 *)(param_1 + 0x25);
  *puVar2 = 0;
  *(undefined8 **)puVar2 = puVar2;
  param_1[0x26] = puVar2;
  uStack_8 = 10;
  if (DAT_01eb31c9 == '\0') {
    DAT_01eb317c = 0;
    uRam01eb3180 = 0;
    uRam01eb3184 = 0;
    DAT_01eb3188 = 0;
    DAT_01eb31c9 = '\x01';
    DAT_01eb318c = _DAT_018ffad0;
    uRam01eb3190 = _UNK_018ffad4;
    uRam01eb3194 = _UNK_018ffad8;
    uRam01eb3198 = _UNK_018ffadc;
    _DAT_01eb319c = 0;
  }
  FUN_005874f0();
  iVar3 = DAT_01eb318c;
  for (iVar10 = DAT_01eb3188; iVar10 != 0; iVar10 = *(int *)(iVar10 + -8)) {
    iVar10 = iVar3 + iVar10;
    iVar3 = *(int *)(iVar10 + -4);
  }
  uStack_8 = 0xb;
  LOCK();
  uVar5 = DAT_01eb317c + 0x80000000;
  UNLOCK();
  uVar6 = uVar5;
  if (((DAT_01eb317c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb317c)) {
    LOCK();
    DAT_01eb317c = uVar5 | 0x40000000;
    UNLOCK();
    uVar6 = DAT_01eb317c;
    if ((uVar5 >> 0x1e & 1) == 0) {
      uVar8 = FUN_00554e40();
      SetEvent(uVar8);
      uVar6 = DAT_01eb317c;
    }
  }
  DAT_01eb317c = uVar6;
  uStack_8 = 10;
  if (DAT_01ead1f1 == '\0') {
    DAT_01ead1f1 = '\x01';
    DAT_01ead1cc = 0;
    uRam01ead1d0 = 0;
    DAT_01ead1d4 = 0;
    DAT_01ead1d8 = 0;
    _DAT_01ead1ec = 0;
    DAT_01ead1dc = _DAT_018ce350;
    _DAT_01ead1e0 = _UNK_018ce354;
    _DAT_01ead1e4 = _UNK_018ce358;
    _DAT_01ead1e8 = _UNK_018ce35c;
  }
  FUN_005874f0();
  iVar3 = DAT_01ead1dc;
  for (iVar10 = DAT_01ead1d8; iVar10 != 0; iVar10 = *(int *)(iVar10 + -8)) {
    iVar10 = iVar3 + iVar10;
    iVar3 = *(int *)(iVar10 + -4);
  }
  uStack_8 = 0xc;
  LOCK();
  uVar5 = DAT_01ead1cc + 0x80000000;
  UNLOCK();
  uVar6 = uVar5;
  if (((DAT_01ead1cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1cc)) {
    LOCK();
    DAT_01ead1cc = uVar5 | 0x40000000;
    UNLOCK();
    uVar6 = DAT_01ead1cc;
    if ((uVar5 >> 0x1e & 1) == 0) {
      uVar8 = FUN_00554e40();
      SetEvent(uVar8);
      uVar6 = DAT_01ead1cc;
    }
  }
  DAT_01ead1cc = uVar6;
  uStack_8 = 10;
  *(undefined *)(param_1 + 0x27) = 0;
  FUN_00621160(0);
  uVar8 = FUN_00588320(0xb);
  param_1[0x28] = uVar8;
  param_1[0x29] = 0;
  param_1[0x2a] = 0x3f800000;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  uStack_8 = 0xd;
  FUN_007c10d0();
  *(undefined *)(param_1 + 0x35) = 0;
  uVar8 = FUN_00588320(0xb);
  param_1[0x36] = uVar8;
  param_1[0x37] = 0;
  param_1[0x38] = 0x3f800000;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  *(undefined *)(param_1 + 0x3b) = 0;
  uVar8 = FUN_00588320(0xb);
  param_1[0x3c] = uVar8;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0x3f800000;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  uStack_8 = 0x10;
  FUN_007c10d0();
  *(undefined *)(param_1 + 0x49) = 0;
  uVar8 = FUN_00588320(0xb);
  param_1[0x4a] = uVar8;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0x3f800000;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  puVar12 = param_1 + 0x4f;
  uStack_8 = 0x12;
  *puVar12 = 0;
  param_1[0x50] = 0;
  puStack_18 = puVar12;
  uVar8 = FUN_00575b10();
  *puVar12 = uVar8;
  uStack_8 = 0x13;
  FUN_00621160(0);
  FUN_007c7590(0);
  *(undefined *)(param_1 + 0x51) = 0;
  FUN_00621160(0);
  uVar8 = FUN_00588320(0xb);
  param_1[0x52] = uVar8;
  param_1[0x53] = 0;
  param_1[0x54] = 0x3f800000;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  uStack_8 = 0x14;
  FUN_00621160(0);
  FUN_007c7590(0);
  *(undefined *)(param_1 + 0x57) = 0;
  FUN_00621160(0);
  uVar8 = FUN_00588320(0xb);
  param_1[0x58] = uVar8;
  param_1[0x59] = 0;
  param_1[0x5a] = 0x3f800000;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  *(undefined *)(param_1 + 0x5d) = 0;
  uVar8 = FUN_00588320(0xb);
  param_1[0x5e] = uVar8;
  param_1[0x5f] = 0;
  param_1[0x60] = 0x3f800000;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = iVar9;
  puVar12 = param_1 + 100;
  *puVar12 = 0;
  uStack_8 = 0x16;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  puStack_18 = puVar12;
  uVar8 = FUN_005e9aa0(0,0);
  param_1[0x65] = uVar8;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  uStack_8 = 0x18;
  *puVar12 = 0x3f800000;
  FUN_005cb500(8);
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  uStack_8 = 0x1c;
  *(undefined *)(param_1 + 0x70) = 0;
  FUN_007c10d0();
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  uStack_8 = 0x1e;
  param_1[0x80] = 0;
  iVar9 = FUN_01674e20(0x78);
  param_1[0x7c] = iVar9;
  param_1[0x7f] = iVar9;
  param_1[0x7e] = iVar9;
  param_1[0x7d] = iVar9 + 0x78;
  param_1[0x83] = 0;
  *(undefined2 *)(param_1 + 0x84) = 1;
  param_1[0x85] = 0;
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  param_1[0x92] = 0;
  param_1[0x93] = 0;
  *(undefined *)(param_1 + 0x94) = 0;
  uVar8 = FUN_00588320(0xb);
  param_1[0x95] = uVar8;
  param_1[0x96] = 0;
  param_1[0x97] = 0x3f800000;
  param_1[0x98] = 0;
  param_1[0x99] = 0;
  param_1[0x9a] = 0;
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  param_1[0x9d] = 0;
  param_1[0x9e] = 0;
  param_1[0x9f] = 0;
  uStack_8 = 0x27;
  param_1[0xa0] = 0;
  param_1[0xa1] = 0;
  param_1[0xa2] = 0;
  FUN_016f4053(param_1 + 0xa3,0xc,6,FUN_007c0f20,FUN_007c2040);
  param_1[0xb5] = 0;
  param_1[0xb6] = 0;
  param_1[0xb7] = 0;
  param_1[0xb8] = 0;
  param_1[0xb9] = 0;
  param_1[0xba] = 0;
  param_1[0xbb] = 0;
  param_1[0xbc] = 0;
  _uStack_8 = CONCAT31(uStack_7,0x2b);
  if ((uint)((int)(param_1[0x7b] - param_1[0x79]) >> 3) < 4) {
    FUN_007c4400(4);
  }
  if (DAT_01d65107 != '\0') {
    FUN_016774b0(DAT_01d65107,"SceneUpdater bind - start",0);
  }
  iVar9 = (int)param_4;
  iVar10 = (**(code **)(**(int **)((int)param_4 + 0x3c) + 0x40))();
  if ((*(char *)(iVar10 + 5) != '\0') && (*(int *)(param_2 + 0x4a0) == 1)) {
    *(undefined *)(param_1 + 0x70) = 1;
    puVar11 = (undefined *)FUN_01674e20(0x30);
    uStack_8 = 0x2c;
    piStack_20 = (int *)puVar11;
    if (puVar11 == (undefined *)0x0) {
      puVar11 = (undefined *)0x0;
    }
    else {
      puStack_18 = (undefined4 *)(float)DAT_01d61d6c;
      FUN_007c1010();
      FUN_007c74b0(0);
      *puVar11 = 0;
      FUN_00621160(0);
      uVar8 = FUN_00588320(0xb);
      fVar14 = DAT_018ce2f8 / (float)puStack_18;
      *(undefined4 *)(puVar11 + 4) = uVar8;
      *(undefined4 *)(puVar11 + 8) = 0;
      *(undefined4 *)(puVar11 + 0xc) = 0x3f800000;
      *(undefined4 *)(puVar11 + 0x10) = 0;
      *(undefined4 *)(puVar11 + 0x14) = 0;
      *(float *)(puVar11 + 0x18) = fVar14;
      *(float *)(puVar11 + 0x1c) = fVar14;
      *(float *)(puVar11 + 0x20) = fVar14;
      fVar14 = (float)puStack_18 * 0.0;
      *(float *)(puVar11 + 0x24) = fVar14;
      *(float *)(puVar11 + 0x28) = fVar14;
      *(float *)(puVar11 + 0x2c) = fVar14;
    }
    iVar10 = param_1[0x6f];
    _uStack_8 = CONCAT31(uStack_7,0x2b);
    param_1[0x6f] = puVar11;
    if (iVar10 != 0) {
      FUN_007c3ff0(iVar10);
    }
    FUN_0085a180(*(undefined4 *)(iVar9 + 0x3c));
  }
  FUN_007b5ec0(*(undefined *)(param_1 + 0x70));
  pcStack_2c = FUN_007c7f00;
  piStack_28 = param_1;
  FUN_007c0e70(&pcStack_2c);
  iVar9 = FUN_008a4100();
  puStack_18 = (undefined4 *)(iVar9 + 0x10);
  uStack_8 = 0x2d;
  uVar8 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x2e;
  piStack_20 = (int *)uVar8;
  piStack_28 = (int *)FUN_01674e20(0x20);
  if (piStack_28 == (undefined4 *)0x0) {
    puVar12 = (undefined4 *)0x0;
  }
  else {
    *piStack_28 = 0;
    piStack_28[1] = 1;
    piStack_28[2] = (int)FUN_007c6780;
    piStack_28[3] = (int)_guard_check_icall;
    piStack_28[4] = 0;
    piStack_28[5] = (int)puStack_18;
    piStack_28[6] = (int)FUN_007c7f00;
    piStack_28[7] = (int)param_1;
    puVar12 = piStack_28;
  }
  FUN_016797d0(puVar12);
  if (puVar12 != (undefined4 *)0x0) {
    LOCK();
    puVar12[1] = puVar12[1] + 1;
    UNLOCK();
  }
  uStack_14 = 1;
  uStack_8 = 0x2f;
  param_4 = puVar12;
  FUN_01675290(uVar8);
  _uStack_8 = CONCAT31(uStack_7,0x2d);
  cVar7 = FUN_01679300(&param_4);
  if (cVar7 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_4);
  }
  uStack_14 = 0;
  if (param_4 != (undefined4 *)0x0) {
    piVar13 = param_4 + 1;
    LOCK();
    iVar9 = *piVar13;
    *piVar13 = *piVar13 + -1;
    UNLOCK();
    if (iVar9 == 1) {
      FUN_01674ea0(param_4);
    }
  }
  uStack_8 = 0x30;
  uVar8 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x31;
  piStack_28 = (int *)uVar8;
  piStack_20 = (int *)FUN_01674e20(0x1c);
  if (piStack_20 == (int *)0x0) {
    piVar13 = (int *)0x0;
  }
  else {
    *piStack_20 = 0;
    piStack_20[1] = 1;
    piStack_20[2] = (int)FUN_007c6690;
    piStack_20[3] = (int)_guard_check_icall;
    piStack_20[4] = 0;
    piStack_20[5] = (int)&DAT_01edfb94;
    piStack_20[6] = (int)param_1;
    piVar13 = piStack_20;
  }
  FUN_016797d0(piVar13);
  if (piVar13 != (int *)0x0) {
    LOCK();
    piVar13[1] = piVar13[1] + 1;
    UNLOCK();
  }
  uStack_14 = 2;
  uStack_8 = 0x32;
  param_4 = piVar13;
  FUN_01675290(uVar8);
  _uStack_8 = CONCAT31(uStack_7,0x30);
  cVar7 = FUN_01679300(&param_4);
  if (cVar7 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_4);
  }
  uStack_14 = 0;
  uStack_8 = 0x2b;
  if (param_4 != (int *)0x0) {
    piVar13 = param_4 + 1;
    LOCK();
    iVar9 = *piVar13;
    *piVar13 = *piVar13 + -1;
    UNLOCK();
    if (iVar9 == 1) {
      FUN_01674ea0(param_4);
    }
  }
  if (DAT_01d60c40 != '\0') {
    puStack_18 = (undefined4 *)(*(int *)(param_1[99] + 0x514) + 0xcc);
    uStack_8 = 0x33;
    uVar8 = FUN_01675290(DAT_02110da8);
    uStack_8 = 0x34;
    piStack_28 = (int *)uVar8;
    piStack_20 = (int *)FUN_01674e20(0x1c);
    if (piStack_20 == (int *)0x0) {
      piVar13 = (int *)0x0;
    }
    else {
      *piStack_20 = 0;
      piStack_20[1] = 1;
      piStack_20[2] = (int)FUN_007c66b0;
      piStack_20[3] = (int)_guard_check_icall;
      piStack_20[4] = 0;
      piStack_20[5] = (int)puStack_18;
      piStack_20[6] = (int)param_1;
      piVar13 = piStack_20;
    }
    FUN_016797d0(piVar13);
    if (piVar13 != (int *)0x0) {
      LOCK();
      piVar13[1] = piVar13[1] + 1;
      UNLOCK();
    }
    uStack_14 = 4;
    uStack_8 = 0x35;
    param_4 = piVar13;
    FUN_01675290(uVar8);
    _uStack_8 = CONCAT31(uStack_7,0x33);
    cVar7 = FUN_01679300(&param_4);
    if (cVar7 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_4);
    }
    uStack_8 = 0x2b;
    if (param_4 != (int *)0x0) {
      piVar13 = param_4 + 1;
      LOCK();
      iVar9 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        FUN_01674ea0(param_4);
      }
    }
  }
  if (DAT_01d6517a != '\0') {
    FUN_016774b0(DAT_01d6517a,"After initial bind, added parts: %u",param_1[0x37]);
  }
  uStack_44 = 0;
  uStack_40 = DAT_018c45c8;
  uStack_38 = 1;
  uStack_48 = 0;
  pcStack_2c = (code *)0x0;
  piStack_28 = (int *)0x0;
  _uStack_8 = CONCAT31(uStack_7,0x36);
  puVar12 = (undefined4 *)FUN_0151d9e0(auStack_24,&pcStack_2c,0,&uStack_48);
  uVar8 = *puVar12;
  uVar4 = puVar12[1];
  *puVar12 = 0;
  puVar12[1] = 0;
  param_1[0xb5] = uVar8;
  piVar13 = (int *)param_1[0xb6];
  param_1[0xb6] = uVar4;
  if (piVar13 != (int *)0x0) {
    LOCK();
    iVar9 = piVar13[1] + -1;
    piVar13[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar13)();
      LOCK();
      iVar9 = piVar13[2] + -1;
      piVar13[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_20[1] + -1;
    piStack_20[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar13 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = piStack_28;
  uStack_8 = 0x2b;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_28[1] + -1;
    piStack_28[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar13 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar13 + 4))();
      }
    }
  }
  uStack_30 = 0x43000000;
  pcStack_2c = (code *)0x42800000;
  piStack_28 = (int *)0x43000000;
  param_4 = (int *)FUN_01674e20(0x30);
  uStack_8 = 0x37;
  if (param_4 == (int *)0x0) {
    uVar8 = 0;
  }
  else {
    uVar8 = FUN_007c0f50(&uStack_30,0x3fc00000);
  }
  iVar9 = param_1[0x6d];
  uStack_8 = 0x2b;
  param_1[0x6d] = uVar8;
  if (iVar9 != 0) {
    FUN_007c3ff0(iVar9);
  }
  param_4 = (int *)FUN_01674e20(0x30);
  uStack_8 = 0x38;
  if (param_4 == (int *)0x0) {
    uVar8 = 0;
  }
  else {
    uVar8 = FUN_007c0f50(&uStack_30,0x3fc00000);
  }
  iVar9 = param_1[0x6e];
  _uStack_8 = CONCAT31(uStack_7,0x2b);
  param_1[0x6e] = uVar8;
  if (iVar9 != 0) {
    FUN_007c3ff0(iVar9);
  }
  if (DAT_01d65107 != '\0') {
    FUN_016774b0(DAT_01d65107,"SceneUpdater bind - end",0);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar9 = param_3[1] + -1;
    param_3[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar13 = param_3 + 2;
      iVar9 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11733 ; VA 0x007c2040 ; FUN_007c2040 */

void __fastcall FUN_007c2040(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01674ea0(*param_1);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11734 ; VA 0x007c2090 ; FUN_007c2090 */

void __fastcall FUN_007c2090(undefined4 *param_1)

{
  FUN_007be6b0(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 11735 ; VA 0x007c20b0 ; FUN_007c20b0 */

void __fastcall FUN_007c20b0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)*param_1;
  piVar2 = (int *)*piVar3;
  ExceptionList = &pvStack_10;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar2 != piVar3) {
    do {
      piVar1 = (int *)*piVar2;
      uStack_8 = 0;
      FUN_007c7240(piVar2);
      piVar3 = (int *)*param_1;
      piVar2 = piVar1;
    } while (piVar1 != piVar3);
  }
  uStack_8 = 1;
  FUN_007c7240(piVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11736 ; VA 0x007c2120 ; FUN_007c2120 */

void __fastcall FUN_007c2120(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)*param_1;
  while (puVar2 != param_1) {
    puVar1 = (undefined4 *)*puVar2;
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2 = puVar1;
  }
  param_1[1] = 0;
  *param_1 = 0;
  return;
}



/* FUNCTION 11737 ; VA 0x007c2150 ; FUN_007c2150 */

void __fastcall FUN_007c2150(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_007c6cb0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11738 ; VA 0x007c21a0 ; FUN_007c21a0 */

void __fastcall FUN_007c21a0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 4) != 0) {
    if ((*(char *)(param_1 + 9) != '\0') &&
       (piVar1 = *(int **)(*(int *)(param_1 + 4) + 0x10), piVar1 != (int *)0x0)) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x14);
  }
  return;
}



/* FUNCTION 11739 ; VA 0x007c21e0 ; FUN_007c21e0 */

void __fastcall FUN_007c21e0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) != 0) {
    ExceptionList = &pvStack_10;
    FUN_007c7240(*(int *)(param_1 + 4));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11740 ; VA 0x007c2220 ; FUN_007c2220 */

void __fastcall FUN_007c2220(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) != 0) {
    ExceptionList = &pvStack_10;
    FUN_007c7190(*(int *)(param_1 + 4));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11741 ; VA 0x007c2260 ; FUN_007c2260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_007c2260(int param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_1 + 4);
  uVar4 = DAT_01ead1cc;
  if (piVar6 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    if ((*(char *)(param_1 + 9) != '\0') &&
       (iVar1 = piVar6[3], ExceptionList = &pvStack_10, iVar1 != 0)) {
      piVar2 = (int *)piVar6[4];
      ExceptionList = &pvStack_10;
      *piVar2 = iVar1;
      *(int **)(iVar1 + 4) = piVar2;
      piVar6[3] = 0;
      piVar6[4] = 0;
      piVar6 = *(int **)(param_1 + 4);
    }
    if (DAT_01ead1f1 == '\0') {
      DAT_01ead1f1 = '\x01';
      DAT_01ead1cc = 0;
      uRam01ead1d0 = 0;
      DAT_01ead1d4 = (int *)0x0;
      DAT_01ead1d8 = 0;
      _DAT_01ead1ec = 0;
      DAT_01ead1dc = _DAT_018ce350;
      _DAT_01ead1e0 = _UNK_018ce354;
      _DAT_01ead1e4 = _UNK_018ce358;
      _DAT_01ead1e8 = _UNK_018ce35c;
    }
    FUN_005874f0();
    *piVar6 = (int)DAT_01ead1d4;
    uStack_8 = 0;
    LOCK();
    uVar3 = DAT_01ead1cc + 0x80000000;
    UNLOCK();
    uVar4 = uVar3;
    DAT_01ead1d4 = piVar6;
    if (((DAT_01ead1cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1cc)) {
      LOCK();
      DAT_01ead1cc = uVar3 | 0x40000000;
      UNLOCK();
      uVar4 = DAT_01ead1cc;
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
        uVar4 = DAT_01ead1cc;
      }
    }
  }
  DAT_01ead1cc = uVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11742 ; VA 0x007c2340 ; thunk_FUN_007c6140 */

void __fastcall thunk_FUN_007c6140(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[4];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(puVar7,0x14);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11743 ; VA 0x007c2350 ; FUN_007c2350 */

void __fastcall FUN_007c2350(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_007c62b0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11744 ; VA 0x007c23d0 ; FUN_007c23d0 */

void __fastcall FUN_007c23d0(int param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_007c6320(iVar2 + *(int *)(param_1 + 4) * 4,0);
      iVar2 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) + 1;
    if (iVar1 == 1) {
      FUN_0061e220(iVar2);
    }
    else {
      FUN_0061e2d0(iVar2,iVar1);
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11745 ; VA 0x007c2460 ; FUN_007c2460 */

void __fastcall FUN_007c2460(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar2 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar2;
        FUN_007c7190(puVar2);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar2 = (undefined4 *)*puVar1;
      } while (puVar2 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar3 = *(int *)(param_1 + 4) + 1;
    if (iVar3 == 1) {
      FUN_0061e220(iVar4);
    }
    else {
      FUN_0061e2d0(iVar4,iVar3);
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11746 ; VA 0x007c2500 ; FUN_007c2500 */

void __fastcall FUN_007c2500(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar2 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar2;
        FUN_007c7240(puVar2);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar2 = (undefined4 *)*puVar1;
      } while (puVar2 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar3 = *(int *)(param_1 + 4) + 1;
    if (iVar3 == 1) {
      FUN_0061e220(iVar4);
    }
    else {
      FUN_0061e2d0(iVar4,iVar3);
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11747 ; VA 0x007c25a0 ; FUN_007c25a0 */

void __fastcall FUN_007c25a0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_007c3ff0(*param_1);
  }
  return;
}



/* FUNCTION 11748 ; VA 0x007c25b0 ; FUN_007c25b0 */

void __fastcall FUN_007c25b0(int param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_007c6320(iVar2 + *(int *)(param_1 + 4) * 4,0);
      iVar2 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) + 1;
    if (iVar1 == 1) {
      FUN_0061e220(iVar2);
    }
    else {
      FUN_0061e2d0(iVar2,iVar1);
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11749 ; VA 0x007c25c0 ; thunk_FUN_007c61e0 */

void __fastcall thunk_FUN_007c61e0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_007c6260(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}


