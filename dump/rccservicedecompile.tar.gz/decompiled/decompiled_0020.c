/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 5000 ; VA 0x005b73b0 ; FUN_005b73b0 */

double * FUN_005b73b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                     undefined4 param_5)

{
  int iVar1;
  double *pdVar2;
  char *pcVar3;
  float10 fVar4;
  double dVar5;
  char *pcStack_8;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     ((*(char *)(param_1 + 0x144b4) == '\0' || (iVar1 = FUN_005b7d20(param_1,param_4), iVar1 == 0)))
     ) {
    pdVar2 = (double *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,param_5,8,0,0,0,0);
    if (*(char *)(param_1 + 0x140b4) == '\0') {
      if (pdVar2 != (double *)0x0) {
        pcVar3 = (char *)FUN_005bde00(param_1);
        if (pcVar3 != (char *)0x0) {
          if (*pcVar3 == '\0') {
            *(undefined4 *)(param_1 + 0x1615c) = 4;
            return (double *)0x0;
          }
          iVar1 = FUN_005bdc80(pcVar3,&DAT_018c37a8);
          dVar5 = DAT_018c45c8;
          if ((((iVar1 == 0) ||
               (iVar1 = FUN_005bdc80(pcVar3,&DAT_018c37b4), dVar5 = DAT_018c45c8, iVar1 == 0)) ||
              (iVar1 = FUN_005bdc80(pcVar3,&DAT_018c37ac), dVar5 = DAT_018c45d8, iVar1 == 0)) ||
             (iVar1 = FUN_005bdc80(pcVar3,&DAT_018c37a4), dVar5 = DAT_018c2920, iVar1 == 0)) {
            *pdVar2 = dVar5;
          }
          else {
            fVar4 = (float10)FUN_0172167a(pcVar3,&pcStack_8);
            *pdVar2 = (double)fVar4;
            if ((*pcStack_8 != '\0') &&
               (iVar1 = FUN_005bded0(pcVar3,&DAT_018c381c,pdVar2), iVar1 != 1)) {
              *(undefined4 *)(param_1 + 0x1615c) = 4;
            }
          }
        }
        if (*(int *)(param_1 + 0x1615c) != 0) {
          return (double *)0x0;
        }
      }
    }
    else {
      pdVar2 = (double *)FUN_005b6f90(param_1,param_1 + 0x140b4,pdVar2,0,param_5,0,8,0,0);
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 == 0))
    {
      return pdVar2;
    }
  }
  return (double *)0x0;
}



/* FUNCTION 5001 ; VA 0x005b7550 ; FUN_005b7550 */

undefined4 *
FUN_005b7550(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  char *pcVar4;
  undefined4 uVar5;
  char *pcStack_8;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    iVar1 = param_1 + 0x144b4;
    if ((((*(char *)(param_1 + 0x144b4) == '\0') ||
         (iVar2 = FUN_005b8220(param_1,iVar1,param_4), iVar2 == 0)) ||
        (iVar2 = FUN_005b8220(param_1,iVar1,&DAT_018c3724), iVar2 == 0)) ||
       ((iVar2 = FUN_005b8220(param_1,iVar1,":short"), iVar2 == 0 ||
        (iVar1 = FUN_005b8220(param_1,iVar1,":byte"), iVar1 == 0)))) {
      puVar3 = (undefined4 *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,param_5,4,0,0,0,0);
      if (*(char *)(param_1 + 0x140b4) == '\0') {
        if (puVar3 != (undefined4 *)0x0) {
          pcVar4 = (char *)FUN_005bde00(param_1);
          if (pcVar4 != (char *)0x0) {
            SetLastError(0);
            uVar5 = FUN_0171d785(pcVar4,&pcStack_8,10);
            *puVar3 = uVar5;
            if (((pcVar4 == pcStack_8) && ((*(uint *)(param_1 + 8) & 0x1000) != 0)) ||
               ((*pcStack_8 != '\0' || (iVar1 = GetLastError(), iVar1 == 0x22)))) {
              *(undefined4 *)(param_1 + 0x1615c) = 4;
            }
          }
          if (*(int *)(param_1 + 0x1615c) != 0) {
            return (undefined4 *)0x0;
          }
        }
      }
      else {
        puVar3 = (undefined4 *)FUN_005b6f90(param_1,param_1 + 0x140b4,puVar3,0,param_5,0,4,0,0);
      }
      if ((*(short *)(param_1 + 0x309a) == 0) || (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 == 0)
         ) {
        return puVar3;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x1615c) = 4;
      FUN_005bb7f0(param_1);
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 5002 ; VA 0x005b76c0 ; FUN_005b76c0 */

void FUN_005b76c0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  *(undefined4 *)(param_1 + 4) = 1;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x2fbc) = 0;
  *(undefined4 *)(param_1 + 0x2fb8) = 0;
  *(undefined4 *)(param_1 + 0x2fc0) = 0;
  *(undefined4 *)(param_1 + 0x2fc4) = 0;
  *(code **)(param_1 + 0x2fc8) = FUN_005b0930;
  *(code **)(param_1 + 0x2fcc) = FUN_005acb60;
  *(code **)(param_1 + 0x2fd0) = FUN_005acb30;
  *(code **)(param_1 + 0x2fd4) = FUN_005acb40;
  *(code **)(param_1 + 0x2fd8) = FUN_005acb10;
  *(undefined4 *)(param_1 + 0x2fdc) = 0;
  *(code **)(param_1 + 0x2fe0) = FUN_005b0cb0;
  *(code **)(param_1 + 0x2fe4) = FUN_005b0d20;
  *(code **)(param_1 + 0x2fe8) = FUN_005aff50;
  *(code **)(param_1 + 0x2fec) = FUN_005b0490;
  *(undefined4 *)(param_1 + 0x2ff0) = 0;
  *(undefined4 *)(param_1 + 0x2ff8) = 0;
  *(undefined4 *)(param_1 + 0x2ffc) = 0;
  *(code **)(param_1 + 0x2ff4) = FUN_005be7e0;
  *(code **)(param_1 + 0x300c) = FUN_005bdf00;
  *(code **)(param_1 + 0x3008) = FUN_005bdf30;
  *(code **)(param_1 + 0x3010) = FUN_005be710;
  *(code **)(param_1 + 0x3000) = FUN_005bdf20;
  *(code **)(param_1 + 0x3004) = FUN_005be840;
  *(code **)(param_1 + 0x3014) = FUN_005afc00;
  *(code **)(param_1 + 0x3018) = FUN_005af980;
  *(code **)(param_1 + 0x301c) = FUN_005b9850;
  *(undefined4 *)(param_1 + 0x3020) = 0;
  *(undefined4 *)(param_1 + 0x3024) = 0;
  *(undefined4 *)(param_1 + 0x3028) = 0;
  *(code **)(param_1 + 0x302c) = FUN_005af8f0;
  *(undefined4 *)(param_1 + 0x3030) = 0;
  *(undefined4 *)(param_1 + 0x3034) = 0;
  *(undefined4 *)(param_1 + 0x3038) = 0;
  *(undefined4 *)(param_1 + 0x303c) = 0;
  *(undefined4 *)(param_1 + 0x3040) = 0;
  *(undefined4 *)(param_1 + 0x3044) = 0;
  *(undefined4 *)(param_1 + 0x3048) = 0;
  *(undefined4 *)(param_1 + 0x304c) = 0;
  *(undefined4 *)(param_1 + 0x3050) = 0;
  *(undefined4 *)(param_1 + 0x3054) = 0;
  *(undefined4 *)(param_1 + 0x3058) = 0;
  *(undefined4 *)(param_1 + 0x305c) = 0;
  *(undefined4 *)(param_1 + 0x3060) = 0;
  *(undefined4 *)(param_1 + 0x3064) = 0;
  *(undefined4 *)(param_1 + 0x3068) = 0;
  *(undefined4 *)(param_1 + 0x306c) = 0;
  *(undefined4 *)(param_1 + 0x3070) = 0;
  *(undefined **)(param_1 + 0x14) = &DAT_018c34b4;
  *(char **)(param_1 + 0x18) = "%.17lG";
  *(char **)(param_1 + 0x1c) = "cid:id%d";
  *(undefined **)(param_1 + 0x20) = &DAT_018c34d0;
  *(undefined **)(param_1 + 0x16140) = &DAT_018c34d4;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x1612c) = 0;
  *(undefined4 *)(param_1 + 0x16130) = 0;
  *(undefined4 *)(param_1 + 0x16134) = 0;
  *(undefined4 *)(param_1 + 0x16138) = 0;
  *(undefined4 *)(param_1 + 0x1613c) = 100;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x16124) = 0;
  *(undefined4 *)(param_1 + 0x30a8) = 0;
  *(undefined4 *)(param_1 + 0x30ac) = 0;
  *(undefined4 *)(param_1 + 0x30b0) = 0;
  *(undefined1 **)(param_1 + 0x28) = &DAT_018c2414;
  *(undefined ***)(param_1 + 0x50) = &PTR_s_SOAP_ENV_01d59038;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x154fc) = 0;
  *(undefined4 *)(param_1 + 0x2fac) = 0;
  *(undefined4 *)(param_1 + 0x2fb0) = 0;
  *(undefined4 *)(param_1 + 0x3074) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x3078) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x307c) = 0;
  *(undefined4 *)(param_1 + 0x3080) = 0;
  *(undefined4 *)(param_1 + 0x16168) = 0;
  *(undefined4 *)(param_1 + 0x16190) = 0;
  *(undefined4 *)(param_1 + 0x16194) = 0;
  *(undefined4 *)(param_1 + 0x16198) = 0;
  *(undefined4 *)(param_1 + 0x161a4) = 0;
  *(undefined4 *)(param_1 + 0x161a8) = 0;
  *(undefined4 *)(param_1 + 0x161ac) = 0;
  *(undefined4 *)(param_1 + 0x1619c) = 0;
  *(undefined4 *)(param_1 + 0x161a0) = 0;
  *(undefined4 *)(param_1 + 0x161b0) = 0;
  *(undefined4 *)(param_1 + 0x3088) = 0;
  *(undefined4 *)(param_1 + 0x3084) = 1;
  *(undefined *)(param_1 + 0x15d18) = 0;
  *(undefined4 *)(param_1 + 0x16128) = 0;
  *(undefined4 *)(param_1 + 0x16118) = 0;
  *(undefined4 *)(param_1 + 0x16144) = 0;
  *(undefined4 *)(param_1 + 0x16148) = 0x1f90;
  *(undefined4 *)(param_1 + 0x1614c) = 0;
  *(undefined4 *)(param_1 + 0x16150) = 0;
  *(undefined4 *)(param_1 + 0x1611c) = 0;
  *(undefined4 *)(param_1 + 0x16120) = 0;
  *(undefined4 *)(param_1 + 0x171cc) = 0;
  *(undefined4 *)(param_1 + 0x171d0) = 0;
  *(undefined4 *)(param_1 + 0x171d4) = 0;
  *(undefined4 *)(param_1 + 0x171d8) = 0;
  *(undefined4 *)(param_1 + 0x171dc) = 0;
  *(undefined4 *)(param_1 + 0x171e0) = 0x20;
  puVar2 = (undefined4 *)(param_1 + 0x68);
  for (iVar1 = 1999; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  *(undefined4 *)(param_1 + 0x2fa4) = 0;
  *(undefined2 *)(param_1 + 0x2fa8) = 0;
  puVar2 = (undefined4 *)(param_1 + 0x1fa4);
  for (iVar1 = 0x400; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  if (*(short *)(param_1 + 0x1612c) == 0) {
    *(undefined4 *)(param_1 + 0x3090) = 0;
    *(undefined4 *)(param_1 + 0x308c) = 0;
  }
  *(ushort *)(param_1 + 0x1612c) =
       ((ushort)(*(uint *)(param_1 + 0x10) >> 4) | (ushort)(*(uint *)(param_1 + 0xc) >> 4)) & 1;
  *(undefined4 *)(param_1 + 0x15502) = 0;
  *(undefined2 *)(param_1 + 0x154b6) = 0;
  *(undefined2 *)(param_1 + 0x15500) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x15506) = 0x90000;
  *(undefined4 *)(param_1 + 0x1550a) = 0;
  *(undefined4 *)(param_1 + 0x30a0) = 0;
  *(undefined4 *)(param_1 + 0x30a4) = 0;
  *(undefined2 *)(param_1 + 0x3098) = 0;
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  *(undefined4 *)(param_1 + 0x3094) = 0;
  *(undefined4 *)(param_1 + 0x2fb4) = 0;
  *(undefined4 *)(param_1 + 0x309c) = 0;
  *(undefined *)(param_1 + 0x15518) = 0;
  *(undefined4 *)(param_1 + 0x16174) = 0;
  *(undefined4 *)(param_1 + 0x16178) = 0;
  FUN_005b52e0();
  return;
}



/* FUNCTION 5003 ; VA 0x005b7b00 ; FUN_005b7b00 */

int * FUN_005b7b00(int param_1,char *param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                  undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  
  iVar2 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar2 != 0) {
    if (param_2 == (char *)0x0) {
      return (int *)0x0;
    }
    if (*param_2 != '-') {
      return (int *)0x0;
    }
    if (*(int *)(param_1 + 0x1615c) != 6) {
      return (int *)0x0;
    }
    *(undefined4 *)(param_1 + 0x1615c) = 0;
  }
  if ((param_3 != (int *)0x0) || (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 != (int *)0x0))
  {
    if (*(short *)(param_1 + 0x309a) == 0) {
      if ((param_2 != (char *)0x0) && (*param_2 == '-')) {
        *(undefined4 *)(param_1 + 0x1615c) = 6;
        return (int *)0x0;
      }
      if (*(short *)(param_1 + 0x15504) == 0) {
        iVar2 = FUN_005b7fc0(param_1,1);
        if (iVar2 != 0) {
          pcVar3 = "";
          do {
            cVar1 = *pcVar3;
            pcVar3 = pcVar3 + 1;
            pcVar3[iVar2 + -0x18c2415] = cVar1;
          } while (cVar1 != '\0');
        }
        *param_3 = iVar2;
      }
      else {
        *param_3 = 0;
      }
    }
    else {
      iVar2 = FUN_005bd410(param_1,param_6,param_7,param_8);
      *param_3 = iVar2;
      if (iVar2 == 0) {
        return (int *)0x0;
      }
      iVar2 = FUN_005b6e40(param_1,param_1 + 0x13cb4,iVar2,param_5,4,0,0,0,0);
      if (iVar2 == 0) {
        return (int *)0x0;
      }
      if (((*(char *)*param_3 == '\0') && (param_2 != (char *)0x0)) && (*param_2 == '-')) {
        *(undefined4 *)(param_1 + 0x1615c) = 6;
        return (int *)0x0;
      }
    }
    if (*(char *)(param_1 + 0x140b4) != '\0') {
      param_3 = (int *)FUN_005b70d0(param_1,param_1 + 0x140b4,param_3,param_5,4,0);
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0))
    {
      return param_3;
    }
  }
  return (int *)0x0;
}



/* FUNCTION 5004 ; VA 0x005b7c70 ; FUN_005b7c70 */

bool FUN_005b7c70(int param_1,int param_2)

{
  if (param_2 == 0) {
    return false;
  }
  if ((((*(short *)(param_1 + 6) == 1) && (*(int *)(param_1 + 0x28) != 0)) &&
      ((*(uint *)(param_1 + 8) & 0x10000) == 0)) && (*(short *)(param_1 + 0x15508) != 3)) {
    if ((*(uint *)(param_1 + 8) & 8) != 0) {
      return *(char *)(param_2 + 0x14) != '\0';
    }
    return *(char *)(param_2 + 0x15) != '\0';
  }
  if ((*(byte *)(param_1 + 8) & 8) != 0) {
    return *(char *)(param_2 + 0x14) == '\x01';
  }
  return *(char *)(param_2 + 0x15) == '\x01';
}



/* FUNCTION 5005 ; VA 0x005b7ce0 ; FUN_005b7ce0 */

bool FUN_005b7ce0(int param_1,int param_2)

{
  if (*(short *)(param_1 + 0x15508) == 3) {
    return true;
  }
  if (param_2 == 0) {
    return false;
  }
  if ((*(byte *)(param_1 + 8) & 8) != 0) {
    return *(char *)(param_2 + 0x14) == '\0';
  }
  return *(char *)(param_2 + 0x15) == '\0';
}



/* FUNCTION 5006 ; VA 0x005b7d20 ; FUN_005b7d20 */

undefined4 FUN_005b7d20(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = param_1 + 0x144b4;
  iVar1 = FUN_005b8220(param_1,iVar2,param_2);
  if (iVar1 != 0) {
    iVar1 = FUN_005b8220(param_1,iVar2,":float");
    if (iVar1 != 0) {
      iVar1 = FUN_005b8220(param_1,iVar2,":double");
      if (iVar1 != 0) {
        iVar1 = FUN_005b8220(param_1,iVar2,":decimal");
        if (iVar1 != 0) {
          iVar1 = FUN_005b8220(param_1,iVar2,":integer");
          if (iVar1 != 0) {
            iVar1 = FUN_005b8220(param_1,iVar2,":positiveInteger");
            if (iVar1 != 0) {
              iVar1 = FUN_005b8220(param_1,iVar2,":negativeInteger");
              if (iVar1 != 0) {
                iVar1 = FUN_005b8220(param_1,iVar2,":nonPositiveInteger");
                if (iVar1 != 0) {
                  iVar1 = FUN_005b8220(param_1,iVar2,":nonNegativeInteger");
                  if (iVar1 != 0) {
                    iVar1 = FUN_005b8220(param_1,iVar2,":long");
                    if (iVar1 != 0) {
                      iVar1 = FUN_005b8220(param_1,iVar2,&DAT_018c3724);
                      if (iVar1 != 0) {
                        iVar1 = FUN_005b8220(param_1,iVar2,":short");
                        if (iVar1 != 0) {
                          iVar1 = FUN_005b8220(param_1,iVar2,":byte");
                          if (iVar1 != 0) {
                            iVar1 = FUN_005b8220(param_1,iVar2,":unsignedLong");
                            if (iVar1 != 0) {
                              iVar1 = FUN_005b8220(param_1,iVar2,":unsignedInt");
                              if (iVar1 != 0) {
                                iVar1 = FUN_005b8220(param_1,iVar2,":unsignedShort");
                                if (iVar1 != 0) {
                                  iVar2 = FUN_005b8220(param_1,iVar2,":unsignedByte");
                                  if (iVar2 != 0) {
                                    *(undefined4 *)(param_1 + 0x1615c) = 4;
                                    FUN_005bb7f0(param_1);
                                    return 0xffffffff;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 5007 ; VA 0x005b7ec0 ; FUN_005b7ec0 */

undefined4 *
FUN_005b7ec0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_0171e1f2(0x14);
  if (puVar2 != (undefined4 *)0x0) {
    uVar1 = *(undefined4 *)(param_1 + 0x60);
    puVar2[3] = param_4;
    puVar2[1] = param_2;
    *puVar2 = uVar1;
    puVar2[4] = param_5;
    puVar2[2] = param_3;
    *(undefined4 **)(param_1 + 0x60) = puVar2;
  }
  return puVar2;
}



/* FUNCTION 5008 ; VA 0x005b7f00 ; FUN_005b7f00 */

int FUN_005b7f00(int param_1,undefined4 param_2)

{
  FUN_005bde90(param_1 + 0x134b4,&DAT_018c373c,param_2);
  return param_1 + 0x134b4;
}



/* FUNCTION 5009 ; VA 0x005b7f30 ; FUN_005b7f30 */

undefined4 * FUN_005b7f30(int param_1,byte *param_2)

{
  byte bVar1;
  undefined4 *puVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  bool bVar7;
  
  iVar3 = FUN_005b6df0(param_2);
  puVar2 = *(undefined4 **)(param_1 + 0x68 + iVar3 * 4);
  do {
    if (puVar2 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
    pbVar6 = (byte *)(puVar2 + 8);
    pbVar4 = param_2;
    do {
      bVar1 = *pbVar6;
      bVar7 = bVar1 < *pbVar4;
      if (bVar1 != *pbVar4) {
LAB_005b7f75:
        uVar5 = -(uint)bVar7 | 1;
        goto LAB_005b7f7a;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar6[1];
      bVar7 = bVar1 < pbVar4[1];
      if (bVar1 != pbVar4[1]) goto LAB_005b7f75;
      pbVar6 = pbVar6 + 2;
      pbVar4 = pbVar4 + 2;
    } while (bVar1 != 0);
    uVar5 = 0;
LAB_005b7f7a:
    if (uVar5 == 0) {
      return puVar2;
    }
    puVar2 = (undefined4 *)*puVar2;
  } while( true );
}



/* FUNCTION 5010 ; VA 0x005b7f90 ; FUN_005b7f90 */

undefined4 FUN_005b7f90(undefined4 param_1,char *param_2)

{
  int iVar1;
  
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    iVar1 = FUN_005b7f30(param_1,param_2);
    if (iVar1 != 0) {
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  return 0;
}



/* FUNCTION 5011 ; VA 0x005b7fc0 ; FUN_005b7fc0 */

undefined1 * FUN_005b7fc0(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined1 *puVar2;
  int iVar3;
  
  if (param_2 == 0) {
    return &DAT_018c2414;
  }
  if (param_1 == 0) {
    puVar2 = (undefined1 *)FUN_0171e1f2(param_2);
    return puVar2;
  }
  if (*(code **)(param_1 + 0x3030) != (code *)0x0) {
    puVar2 = (undefined1 *)(**(code **)(param_1 + 0x3030))(param_1,param_2);
    *(undefined2 *)(param_1 + 0x1550a) = 1;
    return puVar2;
  }
  iVar3 = param_2 + 2 + (-(param_2 + 2) & 3U);
  puVar2 = (undefined1 *)FUN_0171e1f2(iVar3 + 8);
  if (puVar2 == (undefined1 *)0x0) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    return (undefined1 *)0x0;
  }
  puVar1 = (undefined4 *)(puVar2 + iVar3);
  *(undefined2 *)((int)puVar1 + -2) = 0xc0de;
  *puVar1 = *(undefined4 *)(param_1 + 100);
  puVar1[1] = iVar3;
  *(undefined2 *)(param_1 + 0x1550a) = 1;
  *(undefined4 **)(param_1 + 100) = puVar1;
  return puVar2;
}



/* FUNCTION 5012 ; VA 0x005b8070 ; FUN_005b8070 */

undefined4 FUN_005b8070(int param_1,byte *param_2,byte *param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  byte *pbVar5;
  byte *pbVar6;
  bool bVar7;
  
  pbVar6 = param_2;
  pbVar5 = param_3;
  if (param_2 == (byte *)0x0) {
    return 1;
  }
  do {
    bVar1 = *pbVar6;
    bVar7 = bVar1 < *pbVar5;
    if (bVar1 != *pbVar5) {
LAB_005b80a8:
      uVar2 = -(uint)bVar7 | 1;
      goto LAB_005b80ad;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar6[1];
    bVar7 = bVar1 < pbVar5[1];
    if (bVar1 != pbVar5[1]) goto LAB_005b80a8;
    pbVar6 = pbVar6 + 2;
    pbVar5 = pbVar5 + 2;
  } while (bVar1 != 0);
  uVar2 = 0;
LAB_005b80ad:
  if (uVar2 != 0) {
    iVar3 = FUN_01723e00(param_2,&DAT_018c3498,4);
    if (iVar3 == 0) {
      param_2 = param_2 + 4;
    }
    pbVar6 = param_3;
    do {
      bVar1 = *pbVar6;
      pbVar6 = pbVar6 + 1;
    } while (bVar1 != 0);
    pbVar5 = param_3 + 1;
    if (*param_3 != 0x3c) {
      pbVar5 = param_3;
    }
    iVar3 = ((int)pbVar6 - (int)(param_3 + 1)) + -2;
    if (*param_3 != 0x3c) {
      iVar3 = (int)pbVar6 - (int)(param_3 + 1);
    }
    iVar4 = FUN_01723e00(param_2,pbVar5,iVar3);
    if ((iVar4 != 0) || (param_2[iVar3] != 0)) {
      FUN_005b3420(param_1 + 0x134b4,0x400,param_2,&DAT_018c2414);
      iVar4 = FUN_01723e00(param_1 + 0x134b4,pbVar5,iVar3);
      if (iVar4 != 0) {
        return 1;
      }
      if (*(char *)(iVar3 + 0x134b4 + param_1) != '\0') {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 5013 ; VA 0x005b8150 ; FUN_005b8150 */

undefined4 FUN_005b8150(int param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 0x58);
  do {
    if (puVar1 == (undefined4 *)0x0) {
LAB_005b8184:
      if ((((param_4 == 3) && (param_5 == 3)) &&
          (iVar2 = FUN_01723e00(param_2,&DAT_018c2f90,3), iVar2 == 0)) &&
         (iVar2 = FUN_01723e00(param_2,param_3,3), iVar2 == 0)) {
        return 0;
      }
      *(undefined4 *)(param_1 + 0x1615c) = 5;
      return 5;
    }
    iVar2 = FUN_01723e00(puVar1 + 4,param_2,param_4);
    if ((iVar2 == 0) && (*(char *)((int)puVar1 + param_4 + 0x10) == '\0')) {
      if (puVar1 != (undefined4 *)0x0) {
        if (-1 < *(short *)(puVar1 + 2)) {
          iVar2 = *(int *)(*(int *)(param_1 + 0x54) + *(short *)(puVar1 + 2) * 0x10);
          if (iVar2 == 0) {
            return 0;
          }
          iVar2 = FUN_01723e00(iVar2,param_3,param_5);
          if ((iVar2 == 0) &&
             (*(char *)(param_5 + *(int *)(*(int *)(param_1 + 0x54) + *(short *)(puVar1 + 2) * 0x10)
                       ) == '\0')) {
            return 0;
          }
        }
        return 9;
      }
      goto LAB_005b8184;
    }
    puVar1 = (undefined4 *)*puVar1;
  } while( true );
}



/* FUNCTION 5014 ; VA 0x005b8220 ; FUN_005b8220 */

int FUN_005b8220(undefined4 param_1,byte *param_2,byte *param_3)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  bool bVar7;
  
  if (param_2 == (byte *)0x0) {
    return 0;
  }
  if (param_3 == (byte *)0x0) {
    return 0;
  }
  if (*param_3 == 0) {
    return 0;
  }
  iVar2 = FUN_0170dbd0(param_2,0x3a);
  pbVar3 = (byte *)FUN_0170dbd0(param_3,0x3a);
  if (pbVar3 != (byte *)0x0) {
    pbVar6 = pbVar3 + 1;
    pbVar4 = param_2;
    if (iVar2 == 0) {
      do {
        bVar1 = *pbVar4;
        bVar7 = bVar1 < *pbVar6;
        if (bVar1 != *pbVar6) {
LAB_005b82f8:
          uVar5 = -(uint)bVar7 | 1;
          goto LAB_005b82fd;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar4[1];
        bVar7 = bVar1 < pbVar6[1];
        if (bVar1 != pbVar6[1]) goto LAB_005b82f8;
        pbVar6 = pbVar6 + 2;
        pbVar4 = pbVar4 + 2;
      } while (bVar1 != 0);
      uVar5 = 0;
LAB_005b82fd:
      if (uVar5 != 0) {
        return 3;
      }
      if (pbVar3 == param_3) {
        return 0;
      }
      iVar2 = 0;
    }
    else {
      if (*pbVar6 != 0) {
        pbVar4 = (byte *)(iVar2 + 1);
        do {
          bVar1 = *pbVar4;
          bVar7 = bVar1 < *pbVar6;
          if (bVar1 != *pbVar6) {
LAB_005b8295:
            uVar5 = -(uint)bVar7 | 1;
            goto LAB_005b829a;
          }
          if (bVar1 == 0) break;
          bVar1 = pbVar4[1];
          bVar7 = bVar1 < pbVar6[1];
          if (bVar1 != pbVar6[1]) goto LAB_005b8295;
          pbVar4 = pbVar4 + 2;
          pbVar6 = pbVar6 + 2;
        } while (bVar1 != 0);
        uVar5 = 0;
LAB_005b829a:
        if (uVar5 != 0) {
          return 3;
        }
      }
      if (pbVar3 == param_3) {
        return 0;
      }
      iVar2 = iVar2 - (int)param_2;
    }
    iVar2 = FUN_005b8150(param_1,param_2,param_3,iVar2,(int)pbVar3 - (int)param_3);
    if (iVar2 == 0) {
      return 0;
    }
    if (iVar2 == 9) {
      return 3;
    }
    return iVar2;
  }
  if (iVar2 == 0) {
    do {
      bVar1 = *param_2;
      bVar7 = bVar1 < *param_3;
      if (bVar1 != *param_3) goto LAB_005b8350;
      if (bVar1 == 0) break;
      bVar1 = param_2[1];
      bVar7 = bVar1 < param_3[1];
      if (bVar1 != param_3[1]) goto LAB_005b8350;
      param_2 = param_2 + 2;
      param_3 = param_3 + 2;
    } while (bVar1 != 0);
LAB_005b834c:
    uVar5 = 0;
  }
  else {
    pbVar3 = (byte *)(iVar2 + 1);
    do {
      bVar1 = *pbVar3;
      bVar7 = bVar1 < *param_3;
      if (bVar1 != *param_3) goto LAB_005b8350;
      if (bVar1 == 0) goto LAB_005b834c;
      bVar1 = pbVar3[1];
      bVar7 = bVar1 < param_3[1];
      if (bVar1 != param_3[1]) goto LAB_005b8350;
      pbVar3 = pbVar3 + 2;
      param_3 = param_3 + 2;
    } while (bVar1 != 0);
    uVar5 = 0;
  }
LAB_005b8355:
  if (uVar5 == 0) {
    return 0;
  }
  return 3;
LAB_005b8350:
  uVar5 = -(uint)bVar7 | 1;
  goto LAB_005b8355;
}



/* FUNCTION 5015 ; VA 0x005b8370 ; FUN_005b8370 */

undefined4 FUN_005b8370(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (0 < param_2) {
    do {
      uVar2 = *(uint *)(param_1 + 0x3094);
      if (uVar2 == 0) {
        if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
           (iVar1 = FUN_005bac80(param_1), iVar1 != 0)) {
          return 0xffffffff;
        }
        uVar2 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
        *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
      }
      else {
        if (uVar2 == 0xffffffff) {
          return 0xffffffff;
        }
        *(undefined4 *)(param_1 + 0x3094) = 0;
      }
      if (uVar2 == 0xffffffff) {
        return 0xffffffff;
      }
      param_2 = param_2 + -1;
    } while (0 < param_2);
  }
  return 0;
}



/* FUNCTION 5016 ; VA 0x005b83f0 ; FUN_005b83f0 */

void FUN_005b83f0(undefined4 param_1,int *param_2,undefined4 *param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_005b7fc0(param_1,0x24);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = param_4;
    puVar1[2] = param_5;
    *puVar1 = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    if (*param_2 == 0) {
      *param_2 = (int)puVar1;
    }
    if ((undefined4 *)*param_3 != (undefined4 *)0x0) {
      *(undefined4 *)*param_3 = puVar1;
    }
    *param_3 = puVar1;
  }
  return;
}



/* FUNCTION 5017 ; VA 0x005b8460 ; FUN_005b8460 */

int FUN_005b8460(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x5c) + 4);
  if (puVar1 != (undefined4 *)0x0) {
    *(undefined4 *)(*(int *)(param_1 + 0x5c) + 4) = *puVar1;
    FUN_017168b0(puVar1);
    iVar2 = *(int *)(*(int *)(param_1 + 0x5c) + 4);
    if (iVar2 != 0) {
      return iVar2 + 8;
    }
  }
  return 0;
}



/* FUNCTION 5018 ; VA 0x005b84a0 ; FUN_005b84a0 */

undefined4
FUN_005b84a0(int param_1,char *param_2,undefined4 param_3,char *param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_1,param_3,param_4,param_6);
  if (*param_2 != '-') {
    iVar2 = FUN_005b37c0(param_1,param_2,uVar1,param_5);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4210(param_1,0);
    }
    else {
      iVar2 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar2 != 0) goto LAB_005b8523;
  }
  FUN_005bde90(param_1 + 0x134b4,&DAT_018c373c,(int)*param_4);
  iVar2 = FUN_005bd9a0(param_1,param_1 + 0x134b4,0);
  if (iVar2 == 0) {
    uVar1 = FUN_005b3e10(param_1,param_2);
    return uVar1;
  }
LAB_005b8523:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5019 ; VA 0x005b8530 ; FUN_005b8530 */

undefined4
FUN_005b8530(int param_1,char *param_2,undefined4 param_3,double *param_4,undefined4 param_5,
            undefined4 param_6)

{
  double dVar1;
  undefined4 uVar2;
  int iVar3;
  undefined *puVar4;
  undefined *puVar5;
  
  uVar2 = FUN_005b44d0(param_1,param_3,param_4,param_6);
  if (*param_2 != '-') {
    iVar3 = FUN_005b37c0(param_1,param_2,uVar2,param_5);
    if (iVar3 == 0) {
      iVar3 = FUN_005b4210(param_1,0);
    }
    else {
      iVar3 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar3 != 0) goto LAB_005b861d;
  }
  dVar1 = *param_4;
  iVar3 = FUN_01723f60(dVar1);
  if (iVar3 == 0) {
    if (dVar1 < DAT_018c45c8) {
      if (DAT_018c45d8 < dVar1) {
        puVar5 = (undefined *)(param_1 + 0x134b4);
        FUN_005bde90(puVar5,*(undefined4 *)(param_1 + 0x18),dVar1);
        puVar4 = (undefined *)FUN_0170dbd0(puVar5,0x2c);
        if (puVar4 != (undefined *)0x0) {
          *puVar4 = 0x2e;
        }
      }
      else {
        puVar5 = &DAT_018c37ac;
      }
    }
    else {
      puVar5 = &DAT_018c37a8;
    }
  }
  else {
    puVar5 = &DAT_018c37a4;
  }
  iVar3 = FUN_005bd9a0(param_1,puVar5,0);
  if (iVar3 == 0) {
    uVar2 = FUN_005b3e10(param_1,param_2);
    return uVar2;
  }
LAB_005b861d:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5020 ; VA 0x005b8630 ; FUN_005b8630 */

undefined4
FUN_005b8630(int param_1,char *param_2,undefined4 param_3,undefined4 *param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_1,param_3,param_4,param_6);
  if (*param_2 != '-') {
    iVar2 = FUN_005b37c0(param_1,param_2,uVar1,param_5);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4210(param_1,0);
    }
    else {
      iVar2 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar2 != 0) goto LAB_005b86b1;
  }
  FUN_005bde90(param_1 + 0x134b4,&DAT_018c373c,*param_4);
  iVar2 = FUN_005bd9a0(param_1,param_1 + 0x134b4,0);
  if (iVar2 == 0) {
    uVar1 = FUN_005b3e10(param_1,param_2);
    return uVar1;
  }
LAB_005b86b1:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5021 ; VA 0x005b86c0 ; FUN_005b86c0 */

undefined4 FUN_005b86c0(int param_1,char *param_2,undefined4 *param_3,undefined4 param_4)

{
  byte bVar1;
  char cVar2;
  int *piVar3;
  undefined1 *puVar4;
  char *pcVar5;
  int iVar6;
  int iVar7;
  byte *pbVar8;
  uint uVar9;
  undefined4 uVar10;
  byte *pbVar11;
  undefined1 *puVar12;
  char *pcVar13;
  int iVar14;
  bool bVar15;
  
  if ((param_2 == (char *)0x0) || (*param_2 == '-')) {
    param_2 = (char *)0x0;
  }
  else {
    if ((*(int *)(param_1 + 0x54) == 0) || (iVar6 = FUN_0170dbd0(param_2,0x3a), iVar6 == 0)) {
      if (*param_2 == '-') goto LAB_005b87e8;
      iVar6 = FUN_005b37c0(param_1,param_2,0,param_4);
      if (iVar6 == 0) goto LAB_005b87aa;
      iVar6 = *(int *)(param_1 + 0x1615c);
    }
    else {
      FUN_0171dd10((byte *)(param_1 + 0x134b4),param_2,iVar6 - (int)param_2);
      *(undefined *)((iVar6 - (int)param_2) + 0x134b4 + param_1) = 0;
      piVar3 = *(int **)(param_1 + 0x54);
      iVar14 = 0;
      if (*piVar3 != 0) {
        iVar7 = 0;
        do {
          pbVar11 = *(byte **)(iVar7 + (int)piVar3);
          pbVar8 = (byte *)(param_1 + 0x134b4);
          do {
            bVar1 = *pbVar8;
            bVar15 = bVar1 < *pbVar11;
            if (bVar1 != *pbVar11) {
LAB_005b8755:
              uVar9 = -(uint)bVar15 | 1;
              goto LAB_005b875a;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar8[1];
            bVar15 = bVar1 < pbVar11[1];
            if (bVar1 != pbVar11[1]) goto LAB_005b8755;
            pbVar8 = pbVar8 + 2;
            pbVar11 = pbVar11 + 2;
          } while (bVar1 != 0);
          uVar9 = 0;
LAB_005b875a:
          if (uVar9 == 0) break;
          iVar14 = iVar14 + 1;
          iVar7 = iVar14 * 0x10;
        } while (piVar3[iVar14 * 4] != 0);
      }
      param_2 = (char *)(iVar6 + 1);
      iVar6 = FUN_005b37c0(param_1,param_2,0,param_4);
      if (iVar6 != 0) goto LAB_005b87b9;
      puVar4 = *(undefined1 **)(*(int *)(param_1 + 0x54) + 4 + iVar14 * 0x10);
      puVar12 = &DAT_018c2414;
      if (puVar4 != (undefined1 *)0x0) {
        puVar12 = puVar4;
      }
      iVar6 = FUN_005b1b60(param_1,"xmlns",puVar12);
      if (iVar6 != 0) goto LAB_005b87b9;
LAB_005b87aa:
      iVar6 = FUN_005b4210(param_1,0);
    }
    if (iVar6 != 0) goto LAB_005b87b9;
  }
LAB_005b87e8:
  if ((param_3 != (undefined4 *)0x0) && (pcVar5 = (char *)*param_3, pcVar5 != (char *)0x0)) {
    pcVar13 = pcVar5;
    do {
      cVar2 = *pcVar13;
      pcVar13 = pcVar13 + 1;
    } while (cVar2 != '\0');
    iVar6 = FUN_005bc2c0(param_1,pcVar5,(int)pcVar13 - (int)(pcVar5 + 1));
    if (iVar6 != 0) {
LAB_005b87b9:
      return *(undefined4 *)(param_1 + 0x1615c);
    }
  }
  if (param_2 == (char *)0x0) {
    return 0;
  }
  uVar10 = FUN_005b3e10(param_1,param_2);
  return uVar10;
}



/* FUNCTION 5022 ; VA 0x005b8840 ; FUN_005b8840 */

undefined4
FUN_005b8840(int param_1,char *param_2,undefined4 param_3,undefined4 *param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,param_6);
  if (-1 < iVar1) {
    if ((*(char *)*param_4 == '\0') && ((*(uint *)(param_1 + 8) & 0x800000) != 0)) {
      uVar2 = FUN_005b4030(param_1,param_2,iVar1,param_5);
      return uVar2;
    }
    if (*param_2 != '-') {
      iVar1 = FUN_005b37c0(param_1,param_2,iVar1,param_5);
      if (iVar1 == 0) {
        iVar1 = FUN_005b4210(param_1,0);
      }
      else {
        iVar1 = *(int *)(param_1 + 0x1615c);
      }
      if (iVar1 != 0) goto LAB_005b88e6;
    }
    iVar1 = FUN_005bd9a0(param_1,*param_4,0);
    if (iVar1 == 0) {
      iVar1 = FUN_005b3e10(param_1,param_2);
      if (iVar1 == 0) {
        return 0;
      }
    }
  }
LAB_005b88e6:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5023 ; VA 0x005b8900 ; FUN_005b8900 */

int FUN_005b8900(int param_1)

{
  char cVar1;
  byte bVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined2 uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  byte *pbVar12;
  char *pcVar13;
  byte *pbVar14;
  byte *pbVar15;
  char *pcVar16;
  undefined *puVar17;
  bool bVar18;
  undefined4 uVar19;
  undefined4 *puStack_14;
  undefined1 *puStack_10;
  uint uStack_c;
  
  if (*(short *)(param_1 + 0x1550c) != 0) {
    if (*(char *)(param_1 + 0x138b4) == '\0') {
      *(undefined4 *)(param_1 + 0x1615c) = 6;
      return 6;
    }
    return 0;
  }
  *(undefined2 *)(param_1 + 0x1550c) = 1;
  *(undefined *)(param_1 + 0x13cb4) = 0;
  *(undefined *)(param_1 + 0x140b4) = 0;
  *(undefined *)(param_1 + 0x144b4) = 0;
  *(undefined *)(param_1 + 0x148b4) = 0;
  *(undefined *)(param_1 + 0x14cb4) = 0;
  *(undefined *)(param_1 + 0x150b4) = 0;
  *(undefined4 *)(param_1 + 0x154b4) = 0;
  *(undefined2 *)(param_1 + 0x154f8) = 0xffff;
  *(undefined4 *)(param_1 + 0x15502) = 0;
  iVar7 = FUN_005b6b90(param_1);
  while ((-1 < iVar7 && (iVar7 < 0x21))) {
    iVar7 = FUN_005b6b90(param_1);
  }
  puVar17 = (undefined *)(param_1 + 0x138b4);
  if (iVar7 != -2) {
    *puVar17 = 0;
    if (iVar7 == -1) {
      *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
      return -1;
    }
    *(int *)(param_1 + 0x3094) = iVar7;
    *(undefined4 *)(param_1 + 0x1615c) = 6;
    return 6;
  }
  uVar8 = *(uint *)(param_1 + 0x308c);
  do {
    if ((*(uint *)(param_1 + 0x3090) <= uVar8) && (iVar7 = FUN_005bac80(param_1), iVar7 != 0)) {
      uStack_c = 0xffffffff;
      goto LAB_005b8a27;
    }
    uStack_c = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
    uVar8 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar8;
  } while (uStack_c < 0x21);
  if (uStack_c != 0x3e) {
LAB_005b8a27:
    iVar7 = 0x400;
    do {
      while( true ) {
        if (((uStack_c == 0x2f) || ((int)uStack_c < 0x21)) || (uStack_c == 0xffffffff))
        goto LAB_005b8a8c;
        iVar7 = iVar7 + -1;
        if (0 < iVar7) {
          *puVar17 = (char)uStack_c;
          puVar17 = puVar17 + 1;
        }
        if ((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090)) ||
           (iVar9 = FUN_005bac80(param_1), iVar9 == 0)) break;
        uStack_c = 0xffffffff;
      }
      uStack_c = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
    } while (uStack_c != 0x3e);
  }
LAB_005b8a8c:
  if (-1 < (int)uStack_c) {
    while ((int)uStack_c < 0x21) {
      if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
         (iVar7 = FUN_005bac80(param_1), iVar7 != 0)) {
        uStack_c = 0xffffffff;
        break;
      }
      bVar2 = *(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
      uStack_c = (uint)bVar2;
    }
  }
  *puVar17 = 0;
  FUN_005b9a10(param_1);
  for (puVar3 = *(undefined4 **)(param_1 + 0x154fc); puVar3 != (undefined4 *)0x0;
      puVar3 = (undefined4 *)*puVar3) {
    *(undefined2 *)(puVar3 + 4) = 0;
  }
  do {
    if (uStack_c == 0xffffffff) {
LAB_005b8d31:
      *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
      return -1;
    }
    if ((uStack_c == 0x3e) || (uStack_c == 0x2f)) {
      if (uStack_c == 0xffffffff) goto LAB_005b8d31;
      *(ushort *)(param_1 + 0x309a) = (ushort)(uStack_c != 0x2f);
      if (uStack_c != 0x2f) goto LAB_005b8fa4;
      uVar8 = *(uint *)(param_1 + 0x308c);
      goto LAB_005b8f76;
    }
    puVar17 = (undefined *)(param_1 + 0x134b4);
    iVar7 = 0x400;
    while (uStack_c != 0x3d) {
      while( true ) {
        if ((((uStack_c == 0x3e) || (uStack_c == 0x2f)) || ((int)uStack_c < 0x21)) ||
           (uStack_c == 0xffffffff)) goto LAB_005b8b83;
        iVar7 = iVar7 + -1;
        if (0 < iVar7) {
          *puVar17 = (char)uStack_c;
          puVar17 = puVar17 + 1;
        }
        if ((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090)) ||
           (iVar9 = FUN_005bac80(param_1), iVar9 == 0)) break;
        uStack_c = 0xffffffff;
      }
      bVar2 = *(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
      uStack_c = (uint)bVar2;
    }
LAB_005b8b83:
    *puVar17 = 0;
    if (iVar7 == 0x400) {
      *(undefined4 *)(param_1 + 0x1615c) = 5;
      return 5;
    }
    iVar7 = FUN_01723e00(param_1 + 0x134b4,"xmlns",5);
    if (iVar7 == 0) {
      if (*(char *)(param_1 + 0x134b9) == ':') {
        puStack_10 = (undefined1 *)(param_1 + 0x134ba);
      }
      else {
        puStack_10 = &DAT_018c2414;
        if (*(char *)(param_1 + 0x134b9) != '\0') {
          puStack_10 = (undefined1 *)0x0;
        }
      }
    }
    else {
      puStack_10 = (undefined1 *)0x0;
    }
    puVar5 = *(undefined4 **)(param_1 + 0x154fc);
    puVar3 = (undefined4 *)0x0;
    while (puVar11 = puVar5, puVar11 != (undefined4 *)0x0) {
      pbVar12 = (byte *)(param_1 + 0x134b4);
      pbVar10 = (byte *)((int)puVar11 + 0x12);
      do {
        bVar2 = *pbVar10;
        bVar18 = bVar2 < *pbVar12;
        if (bVar2 != *pbVar12) {
LAB_005b8c10:
          uVar8 = -(uint)bVar18 | 1;
          goto LAB_005b8c15;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar10[1];
        bVar18 = bVar2 < pbVar12[1];
        if (bVar2 != pbVar12[1]) goto LAB_005b8c10;
        pbVar10 = pbVar10 + 2;
        pbVar12 = pbVar12 + 2;
      } while (bVar2 != 0);
      uVar8 = 0;
LAB_005b8c15:
      if (uVar8 == 0) {
        if (puVar11 != (undefined4 *)0x0) goto LAB_005b8cac;
        break;
      }
      puVar3 = puVar11;
      puVar5 = (undefined4 *)*puVar11;
    }
    pcVar13 = (char *)(param_1 + 0x134b4);
    do {
      cVar1 = *pcVar13;
      pcVar13 = pcVar13 + 1;
    } while (cVar1 != '\0');
    puVar11 = (undefined4 *)FUN_0171e1f2(pcVar13 + (0x14 - (param_1 + 0x134b5)));
    if (puVar11 == (undefined4 *)0x0) {
LAB_005b8f2a:
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0x14;
    }
    pcVar13 = (char *)(param_1 + 0x134b4);
    do {
      cVar1 = *pcVar13;
      pcVar13 = pcVar13 + 1;
      pcVar13[(int)puVar11 + (0x11 - (param_1 + 0x134b4))] = cVar1;
    } while (cVar1 != '\0');
    puVar11[1] = 0;
    puVar11[2] = 0;
    if ((puVar3 == (undefined4 *)0x0) || (iVar7 = FUN_0170dbd0(param_1 + 0x134b4,0x3a), iVar7 == 0))
    {
      *puVar11 = *(undefined4 *)(param_1 + 0x154fc);
      *(undefined4 **)(param_1 + 0x154fc) = puVar11;
    }
    else {
      *puVar3 = puVar11;
      *puVar11 = 0;
    }
LAB_005b8cac:
    if (-1 < (int)uStack_c) {
      while ((int)uStack_c < 0x21) {
        if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
           (iVar7 = FUN_005bac80(param_1), iVar7 != 0)) {
          uStack_c = 0xffffffff;
          goto LAB_005b8cfb;
        }
        bVar2 = *(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
        *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        uStack_c = (uint)bVar2;
      }
    }
    if (uStack_c == 0x3d) {
      do {
        iVar7 = FUN_005b6b90(param_1);
        if (iVar7 < 0) break;
      } while (iVar7 < 0x21);
      if ((iVar7 != -5) && (iVar7 != -6)) {
        *(int *)(param_1 + 0x3094) = iVar7;
        iVar7 = 0x20;
      }
      iVar9 = FUN_005b5ec0(param_1,puVar11[1],puVar11[2],iVar7);
      if (iVar9 != 0) {
        if (*(int *)(param_1 + 0x1615c) != 0x14) {
          return *(int *)(param_1 + 0x1615c);
        }
        *(undefined4 *)(param_1 + 0x1615c) = 0;
        uVar19 = puVar11[2];
        uVar4 = puVar11[1];
        *(undefined4 *)(param_1 + 0x30b0) = 0;
        iVar9 = FUN_005b19f0(param_1,uVar4,uVar19);
        if (iVar9 != 0) break;
        if (puVar11[1] != 0) {
          FUN_017168b0(puVar11[1]);
        }
        iVar9 = FUN_005b5ec0(param_1,*(int *)(param_1 + 0x30a8) + *(int *)(param_1 + 0x30b0),
                             *(int *)(param_1 + 0x30ac) - *(int *)(param_1 + 0x30b0),iVar7);
        while (iVar9 != 0) {
          if (*(int *)(param_1 + 0x1615c) != 0x14) {
            return *(int *)(param_1 + 0x1615c);
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0;
          *(undefined4 *)(param_1 + 0x30b0) = *(undefined4 *)(param_1 + 0x30ac);
          iVar9 = FUN_005b19f0(param_1,0,0);
          if (iVar9 != 0) goto LAB_005b8f1d;
          iVar9 = FUN_005b5ec0(param_1,*(int *)(param_1 + 0x30a8) + *(int *)(param_1 + 0x30b0),
                               *(int *)(param_1 + 0x30ac) - *(int *)(param_1 + 0x30b0),iVar7);
        }
        if (*(int *)(param_1 + 0x30b0) == 0) {
          pcVar16 = *(char **)(param_1 + 0x30a8);
          pcVar13 = pcVar16 + 1;
          do {
            cVar1 = *pcVar16;
            pcVar16 = pcVar16 + 1;
          } while (cVar1 != '\0');
          pcVar16 = pcVar16 + (1 - (int)pcVar13);
          puVar11[2] = pcVar16;
          if (pcVar16 < (char *)0x100) {
            puVar11[2] = 0x100;
            pcVar16 = (char *)0x100;
          }
        }
        else {
          pcVar16 = *(char **)(param_1 + 0x30ac);
          puVar11[2] = pcVar16;
        }
        pcVar13 = (char *)FUN_0171e1f2(pcVar16);
        puVar11[1] = pcVar13;
        if (pcVar13 == (char *)0x0) goto LAB_005b8f2a;
        pcVar16 = *(char **)(param_1 + 0x30a8);
        do {
          cVar1 = *pcVar16;
          pcVar16 = pcVar16 + 1;
          *pcVar13 = cVar1;
          pcVar13 = pcVar13 + 1;
        } while (cVar1 != '\0');
      }
      uVar8 = *(uint *)(param_1 + 0x308c);
      do {
        if ((*(uint *)(param_1 + 0x3090) <= uVar8) && (iVar7 = FUN_005bac80(param_1), iVar7 != 0)) {
          uStack_c = 0xffffffff;
          uVar6 = 2;
          goto LAB_005b8d00;
        }
        uStack_c = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
        uVar8 = *(int *)(param_1 + 0x308c) + 1;
        *(uint *)(param_1 + 0x308c) = uVar8;
      } while (uStack_c < 0x21);
      uVar6 = 2;
    }
    else {
LAB_005b8cfb:
      uVar6 = 1;
    }
LAB_005b8d00:
    *(undefined2 *)(puVar11 + 4) = uVar6;
  } while (((puStack_10 == (undefined1 *)0x0) || (puVar11[1] == 0)) ||
          (iVar7 = FUN_005b9b50(param_1,puStack_10,puVar11[1]), iVar7 == 0));
LAB_005b8f1d:
  return *(int *)(param_1 + 0x1615c);
  while( true ) {
    bVar2 = *(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
    uVar8 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar8;
    if (0x20 < bVar2) break;
LAB_005b8f76:
    if ((*(uint *)(param_1 + 0x3090) <= uVar8) && (iVar7 = FUN_005bac80(param_1), iVar7 != 0))
    break;
  }
LAB_005b8fa4:
  puVar3 = *(undefined4 **)(param_1 + 0x154fc);
joined_r0x005b8faf:
  if (puVar3 == (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return 0;
  }
  if ((*(short *)(puVar3 + 4) != 0) && (iVar7 = puVar3[1], iVar7 != 0)) {
    pbVar10 = (byte *)((int)puVar3 + 0x12);
    pbVar14 = &DAT_018c1fd8;
    pbVar12 = pbVar10;
    do {
      bVar2 = *pbVar12;
      bVar18 = bVar2 < *pbVar14;
      if (bVar2 != *pbVar14) {
LAB_005b8ff5:
        uVar8 = -(uint)bVar18 | 1;
        goto LAB_005b8ffa;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar12[1];
      bVar18 = bVar2 < pbVar14[1];
      if (bVar2 != pbVar14[1]) goto LAB_005b8ff5;
      pbVar12 = pbVar12 + 2;
      pbVar14 = pbVar14 + 2;
    } while (bVar2 != 0);
    uVar8 = 0;
LAB_005b8ffa:
    if (uVar8 == 0) {
      if (((0 < *(short *)(param_1 + 6)) && ((*(uint *)(param_1 + 8) & 0x8000) == 0)) ||
         ((*(uint *)(param_1 + 8) & 0x10000) != 0)) {
        *(undefined *)(param_1 + 0x13cb4) = 0x23;
        FUN_0171dd10(param_1 + 0x13cb5,puVar3[1],0x3fe);
        *(undefined *)(param_1 + 0x140b3) = 0;
      }
      goto LAB_005b970b;
    }
    pbVar14 = &DAT_018c3490;
    pbVar12 = pbVar10;
    do {
      bVar2 = *pbVar12;
      bVar18 = bVar2 < *pbVar14;
      if (bVar2 != *pbVar14) {
LAB_005b9070:
        uVar8 = -(uint)bVar18 | 1;
        goto LAB_005b9075;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar12[1];
      bVar18 = bVar2 < pbVar14[1];
      if (bVar2 != pbVar14[1]) goto LAB_005b9070;
      pbVar12 = pbVar12 + 2;
      pbVar14 = pbVar14 + 2;
    } while (bVar2 != 0);
    uVar8 = 0;
LAB_005b9075:
    if (uVar8 == 0) {
      if ((*(short *)(param_1 + 6) == 1) || ((*(uint *)(param_1 + 8) & 0x10200) != 0)) {
        uVar19 = 0x3ff;
        iVar9 = param_1 + 0x140b4;
LAB_005b9099:
        FUN_0171dd10(iVar9,iVar7,uVar19);
        *(undefined *)(param_1 + 0x144b3) = 0;
      }
      goto LAB_005b970b;
    }
    iVar7 = FUN_005b8220(param_1,pbVar10,"xsi:type");
    if (iVar7 == 0) {
      FUN_0171dd10(param_1 + 0x144b4,puVar3[1],0x3ff);
      *(undefined *)(param_1 + 0x148b3) = 0;
      goto LAB_005b970b;
    }
    iVar7 = FUN_005b8220(param_1,pbVar10,"xsi:null");
    if ((iVar7 == 0) || (iVar7 = FUN_005b8220(param_1,pbVar10,&DAT_018c35fc), iVar7 == 0)) {
      pbVar15 = &DAT_018c3554;
      pbVar12 = (byte *)puVar3[1];
      pbVar14 = pbVar12;
      do {
        bVar2 = *pbVar14;
        bVar18 = bVar2 < *pbVar15;
        if (bVar2 != *pbVar15) {
LAB_005b9150:
          uVar8 = -(uint)bVar18 | 1;
          goto LAB_005b9155;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar14[1];
        bVar18 = bVar2 < pbVar15[1];
        if (bVar2 != pbVar15[1]) goto LAB_005b9150;
        pbVar14 = pbVar14 + 2;
        pbVar15 = pbVar15 + 2;
      } while (bVar2 != 0);
      uVar8 = 0;
LAB_005b9155:
      if (uVar8 != 0) {
        pbVar14 = &DAT_018bdf50;
        do {
          bVar2 = *pbVar12;
          bVar18 = bVar2 < *pbVar14;
          if (bVar2 != *pbVar14) {
LAB_005b9182:
            uVar8 = -(uint)bVar18 | 1;
            goto LAB_005b9187;
          }
          if (bVar2 == 0) break;
          bVar2 = pbVar12[1];
          bVar18 = bVar2 < pbVar14[1];
          if (bVar2 != pbVar14[1]) goto LAB_005b9182;
          pbVar12 = pbVar12 + 2;
          pbVar14 = pbVar14 + 2;
        } while (bVar2 != 0);
        uVar8 = 0;
LAB_005b9187:
        if (uVar8 != 0) goto LAB_005b918f;
      }
      *(undefined2 *)(param_1 + 0x15504) = 1;
      goto LAB_005b970b;
    }
LAB_005b918f:
    if (*(short *)(param_1 + 6) == 1) {
      iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:arrayType");
      if (iVar7 != 0) {
        iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:offset");
        if (iVar7 == 0) {
          FUN_0171dd10(param_1 + 0x150b4,puVar3[1],0x400);
        }
        else {
          iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:position");
          if (iVar7 == 0) {
            pcVar13 = (char *)puVar3[1];
            if (*pcVar13 == '\0') {
              *(undefined2 *)(param_1 + 0x154b6) = 0xffff;
            }
            else {
              puStack_14 = (undefined4 *)(param_1 + 0x154b8);
              puStack_10 = (undefined1 *)0x0;
              iVar7 = 1;
              do {
                uVar19 = FUN_01717832(pcVar13 + iVar7);
                puStack_10 = (undefined1 *)((int)puStack_10 + 1);
                *puStack_14 = uVar19;
                puStack_14 = puStack_14 + 1;
                cVar1 = pcVar13[iVar7];
                iVar9 = iVar7;
                while (((cVar1 != '\0' && (cVar1 != ',')) && (cVar1 != ']'))) {
                  iVar7 = iVar9 + 1;
                  iVar9 = iVar9 + 1;
                  cVar1 = pcVar13[iVar7];
                }
                iVar7 = iVar9 + 1;
                if (pcVar13[iVar9] != ',') {
                  iVar7 = iVar9;
                }
              } while ((((int)puStack_10 < 0x10) && (pcVar13[iVar7] != '\0')) &&
                      (pcVar13[iVar7] != ']'));
              *(short *)(param_1 + 0x154b6) = (short)puStack_10;
            }
          }
          else {
            iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:root");
            if (iVar7 == 0) {
              pbVar14 = &DAT_018c3554;
              pbVar10 = (byte *)puVar3[1];
              pbVar12 = pbVar10;
              do {
                bVar2 = *pbVar12;
                bVar18 = bVar2 < *pbVar14;
                if (bVar2 != *pbVar14) {
LAB_005b9364:
                  uVar8 = -(uint)bVar18 | 1;
                  goto LAB_005b9369;
                }
                if (bVar2 == 0) break;
                bVar2 = pbVar12[1];
                bVar18 = bVar2 < pbVar14[1];
                if (bVar2 != pbVar14[1]) goto LAB_005b9364;
                pbVar12 = pbVar12 + 2;
                pbVar14 = pbVar14 + 2;
              } while (bVar2 != 0);
              uVar8 = 0;
LAB_005b9369:
              if (uVar8 != 0) {
                pbVar12 = &DAT_018bdf50;
                do {
                  bVar2 = *pbVar10;
                  bVar18 = bVar2 < *pbVar12;
                  if (bVar2 != *pbVar12) {
LAB_005b9392:
                    uVar8 = -(uint)bVar18 | 1;
                    goto LAB_005b9397;
                  }
                  if (bVar2 == 0) break;
                  bVar2 = pbVar10[1];
                  bVar18 = bVar2 < pbVar12[1];
                  if (bVar2 != pbVar12[1]) goto LAB_005b9392;
                  pbVar10 = pbVar10 + 2;
                  pbVar12 = pbVar12 + 2;
                } while (bVar2 != 0);
                uVar8 = 0;
LAB_005b9397:
                if (uVar8 != 0) {
                  *(undefined2 *)(param_1 + 0x154f8) = 0;
                  goto LAB_005b970b;
                }
              }
              *(undefined2 *)(param_1 + 0x154f8) = 1;
            }
            else {
              iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENV:mustUnderstand");
              if (iVar7 == 0) {
                pbVar15 = &DAT_018c3554;
                pbVar12 = (byte *)puVar3[1];
                pbVar14 = pbVar12;
                do {
                  bVar2 = *pbVar14;
                  bVar18 = bVar2 < *pbVar15;
                  if (bVar2 != *pbVar15) {
LAB_005b9410:
                    uVar8 = -(uint)bVar18 | 1;
                    goto LAB_005b9415;
                  }
                  if (bVar2 == 0) break;
                  bVar2 = pbVar14[1];
                  bVar18 = bVar2 < pbVar15[1];
                  if (bVar2 != pbVar15[1]) goto LAB_005b9410;
                  pbVar14 = pbVar14 + 2;
                  pbVar15 = pbVar15 + 2;
                } while (bVar2 != 0);
                uVar8 = 0;
LAB_005b9415:
                if (uVar8 != 0) {
                  pbVar14 = &DAT_018bdf50;
                  do {
                    bVar2 = *pbVar12;
                    bVar18 = bVar2 < *pbVar14;
                    if (bVar2 != *pbVar14) {
LAB_005b9440:
                      uVar8 = -(uint)bVar18 | 1;
                      goto LAB_005b9445;
                    }
                    if (bVar2 == 0) break;
                    bVar2 = pbVar12[1];
                    bVar18 = bVar2 < pbVar14[1];
                    if (bVar2 != pbVar14[1]) goto LAB_005b9440;
                    pbVar12 = pbVar12 + 2;
                    pbVar14 = pbVar14 + 2;
                  } while (bVar2 != 0);
                  uVar8 = 0;
LAB_005b9445:
                  if (uVar8 != 0) goto LAB_005b945a;
                }
LAB_005b9449:
                *(undefined2 *)(param_1 + 0x15502) = 1;
              }
              else {
LAB_005b945a:
                iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENV:actor");
                if (iVar7 == 0) {
                  pbVar10 = *(byte **)(param_1 + 0x2c);
                  if (pbVar10 != (byte *)0x0) {
                    pbVar12 = (byte *)puVar3[1];
                    do {
                      bVar2 = *pbVar10;
                      bVar18 = bVar2 < *pbVar12;
                      if (bVar2 != *pbVar12) {
LAB_005b94a0:
                        uVar8 = -(uint)bVar18 | 1;
                        goto LAB_005b94a5;
                      }
                      if (bVar2 == 0) break;
                      bVar2 = pbVar10[1];
                      bVar18 = bVar2 < pbVar12[1];
                      if (bVar2 != pbVar12[1]) goto LAB_005b94a0;
                      pbVar10 = pbVar10 + 2;
                      pbVar12 = pbVar12 + 2;
                    } while (bVar2 != 0);
                    uVar8 = 0;
LAB_005b94a5:
                    if (uVar8 == 0) goto LAB_005b970b;
                  }
                  pbVar12 = &DAT_018c3660;
                  pbVar10 = (byte *)puVar3[1];
                  do {
                    bVar2 = *pbVar10;
                    bVar18 = bVar2 < *pbVar12;
                    if (bVar2 != *pbVar12) goto LAB_005b94d8;
                    if (bVar2 == 0) break;
                    bVar2 = pbVar10[1];
                    bVar18 = bVar2 < pbVar12[1];
                    if (bVar2 != pbVar12[1]) goto LAB_005b94d8;
                    pbVar10 = pbVar10 + 2;
                    pbVar12 = pbVar12 + 2;
                  } while (bVar2 != 0);
LAB_005b94d4:
                  uVar8 = 0;
                  goto LAB_005b94dd;
                }
              }
            }
          }
        }
        goto LAB_005b970b;
      }
      iVar7 = FUN_0170dd00(puVar3[1],0x5b);
      if (iVar7 == 0) {
LAB_005b9203:
        iVar7 = puVar3[1];
        iVar9 = 0x148b4;
      }
      else {
        uVar8 = iVar7 - puVar3[1];
        if (0x3ff < uVar8) goto LAB_005b9203;
        FUN_0171dd10(param_1 + 0x148b4,puVar3[1],uVar8);
        *(undefined *)((iVar7 - puVar3[1]) + 0x148b4 + param_1) = 0;
        iVar9 = 0x14cb4;
      }
      FUN_0171dd10(iVar9 + param_1,iVar7,0x3ff);
      *(undefined *)(param_1 + 0x150b3) = 0;
      *(undefined *)(param_1 + 0x14cb3) = 0;
      goto LAB_005b970b;
    }
    if (*(short *)(param_1 + 6) != 2) goto LAB_005b970b;
    pbVar14 = &DAT_018c368c;
    pbVar12 = pbVar10;
    do {
      bVar2 = *pbVar12;
      bVar18 = bVar2 < *pbVar14;
      if (bVar2 != *pbVar14) {
LAB_005b9527:
        uVar8 = -(uint)bVar18 | 1;
        goto LAB_005b952c;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar12[1];
      bVar18 = bVar2 < pbVar14[1];
      if (bVar2 != pbVar14[1]) goto LAB_005b9527;
      pbVar12 = pbVar12 + 2;
      pbVar14 = pbVar14 + 2;
    } while (bVar2 != 0);
    uVar8 = 0;
LAB_005b952c:
    if ((uVar8 == 0) || (iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:ref"), iVar7 == 0)) {
      uVar19 = 0x3fe;
      *(undefined *)(param_1 + 0x140b4) = 0x23;
      iVar7 = puVar3[1];
      iVar9 = param_1 + 0x140b5;
      goto LAB_005b9099;
    }
    iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:itemType");
    if (iVar7 == 0) {
      FUN_0171dd10(param_1 + 0x148b4,puVar3[1],0x3ff);
      goto LAB_005b970b;
    }
    iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENC:arraySize");
    if (iVar7 == 0) {
      FUN_0171dd10(param_1 + 0x14cb4,puVar3[1],0x3ff);
      goto LAB_005b970b;
    }
    iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENV:mustUnderstand");
    if (iVar7 == 0) {
      pbVar15 = &DAT_018c3554;
      pbVar12 = (byte *)puVar3[1];
      pbVar14 = pbVar12;
      do {
        bVar2 = *pbVar14;
        bVar18 = bVar2 < *pbVar15;
        if (bVar2 != *pbVar15) {
LAB_005b9603:
          uVar8 = -(uint)bVar18 | 1;
          goto LAB_005b9608;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar14[1];
        bVar18 = bVar2 < pbVar15[1];
        if (bVar2 != pbVar15[1]) goto LAB_005b9603;
        pbVar14 = pbVar14 + 2;
        pbVar15 = pbVar15 + 2;
      } while (bVar2 != 0);
      uVar8 = 0;
LAB_005b9608:
      if (uVar8 == 0) goto LAB_005b9449;
      pbVar14 = &DAT_018bdf50;
      do {
        bVar2 = *pbVar12;
        bVar18 = bVar2 < *pbVar14;
        if (bVar2 != *pbVar14) {
LAB_005b9635:
          uVar8 = -(uint)bVar18 | 1;
          goto LAB_005b963a;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar12[1];
        bVar18 = bVar2 < pbVar14[1];
        if (bVar2 != pbVar14[1]) goto LAB_005b9635;
        pbVar12 = pbVar12 + 2;
        pbVar14 = pbVar14 + 2;
      } while (bVar2 != 0);
      uVar8 = 0;
LAB_005b963a:
      if (uVar8 == 0) {
        *(undefined2 *)(param_1 + 0x15502) = 1;
        goto LAB_005b970b;
      }
    }
    iVar7 = FUN_005b8220(param_1,pbVar10,"SOAP-ENV:role");
    if (iVar7 != 0) goto LAB_005b970b;
    pbVar10 = *(byte **)(param_1 + 0x2c);
    if (pbVar10 != (byte *)0x0) {
      pbVar12 = (byte *)puVar3[1];
      do {
        bVar2 = *pbVar10;
        bVar18 = bVar2 < *pbVar12;
        if (bVar2 != *pbVar12) {
LAB_005b9693:
          uVar8 = -(uint)bVar18 | 1;
          goto LAB_005b9698;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar10[1];
        bVar18 = bVar2 < pbVar12[1];
        if (bVar2 != pbVar12[1]) goto LAB_005b9693;
        pbVar10 = pbVar10 + 2;
        pbVar12 = pbVar12 + 2;
      } while (bVar2 != 0);
      uVar8 = 0;
LAB_005b9698:
      if (uVar8 == 0) goto LAB_005b970b;
    }
    pbVar12 = &DAT_018c3690;
    pbVar10 = (byte *)puVar3[1];
    do {
      bVar2 = *pbVar10;
      bVar18 = bVar2 < *pbVar12;
      if (bVar2 != *pbVar12) goto LAB_005b94d8;
      if (bVar2 == 0) goto LAB_005b94d4;
      bVar2 = pbVar10[1];
      bVar18 = bVar2 < pbVar12[1];
      if (bVar2 != pbVar12[1]) goto LAB_005b94d8;
      pbVar10 = pbVar10 + 2;
      pbVar12 = pbVar12 + 2;
    } while (bVar2 != 0);
    uVar8 = 0;
    goto LAB_005b94dd;
  }
  goto LAB_005b970b;
LAB_005b94d8:
  uVar8 = -(uint)bVar18 | 1;
LAB_005b94dd:
  if (uVar8 != 0) {
    *(undefined2 *)(param_1 + 0x154b4) = 1;
  }
LAB_005b970b:
  puVar3 = (undefined4 *)*puVar3;
  goto joined_r0x005b8faf;
}



/* FUNCTION 5024 ; VA 0x005b9730 ; FUN_005b9730 */

void FUN_005b9730(int param_1,uint param_2,uint *param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 *param_6)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  short sVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2fa4);
  if ((puVar1 == (undefined4 *)0x0) || (sVar4 = *(short *)(param_1 + 0x2fa8), 0x1f < sVar4)) {
    puVar1 = (undefined4 *)FUN_0171e1f2(0x304);
    if (puVar1 == (undefined4 *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return;
    }
    *puVar1 = *(undefined4 *)(param_1 + 0x2fa4);
    *(undefined4 **)(param_1 + 0x2fa4) = puVar1;
    sVar4 = 0;
    *(undefined2 *)(param_1 + 0x2fa8) = 0;
  }
  puVar1 = puVar1 + sVar4 * 6 + 1;
  *(short *)(param_1 + 0x2fa8) = sVar4 + 1;
  *param_6 = puVar1;
  uVar3 = param_2;
  if (param_3 != (uint *)0x0) {
    uVar3 = *param_3;
  }
  uVar3 = uVar3 >> 3 & 0x3ff;
  *puVar1 = *(undefined4 *)(param_1 + 0x1fa4 + uVar3 * 4);
  puVar1[3] = param_5;
  puVar1[1] = param_2;
  puVar1[2] = param_3;
  *(undefined2 *)(puVar1 + 5) = 0;
  *(undefined4 **)(param_1 + 0x1fa4 + uVar3 * 4) = puVar1;
  iVar2 = *(int *)(param_1 + 0x2fb4) + 1;
  *(int *)(param_1 + 0x2fb4) = iVar2;
  puVar1[4] = iVar2;
  return;
}



/* FUNCTION 5025 ; VA 0x005b9800 ; FUN_005b9800 */

undefined4 FUN_005b9800(int param_1,uint param_2,int param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  
  *param_4 = 0;
  if (param_2 != 0) {
    for (puVar1 = *(undefined4 **)(param_1 + 0x1fa4 + (param_2 >> 3 & 0x3ff) * 4);
        puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
      if ((puVar1[1] == param_2) && (puVar1[3] == param_3)) {
        *param_4 = puVar1;
        return puVar1[4];
      }
    }
  }
  return 0;
}



/* FUNCTION 5026 ; VA 0x005b9850 ; FUN_005b9850 */

undefined4 FUN_005b9850(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  bool bVar4;
  undefined4 uStack_318;
  int iStack_314;
  undefined4 uStack_214;
  int iStack_210;
  undefined4 uStack_110;
  int iStack_10c;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0;
  iStack_10c = *(int *)(param_1 + 0x3078);
  uStack_318 = 0;
  uStack_214 = 0;
  if (iStack_10c == -1) {
    iStack_10c = *(int *)(param_1 + 0x3074);
    if (iStack_10c == -1) {
      return 0;
    }
    uStack_110 = 1;
    iVar1 = Ordinal_18(iStack_10c + 1,0,&uStack_110,0,&uStack_c);
  }
  else {
    uStack_318 = 1;
    uStack_110 = 1;
    uStack_214 = 1;
    iStack_314 = iStack_10c;
    iStack_210 = iStack_10c;
    iVar1 = Ordinal_18(iStack_10c + 1,&uStack_318,&uStack_110,&uStack_214,&uStack_c);
    bVar4 = iVar1 < 0;
    if (iVar1 < 1) goto LAB_005b9904;
    iVar2 = Ordinal_151(*(undefined4 *)(param_1 + 0x3078),&uStack_214);
    if (iVar2 != 0) {
      bVar4 = true;
      goto LAB_005b9904;
    }
  }
  bVar4 = iVar1 < 0;
  if (0 < iVar1) {
    if (*(int *)(param_1 + 0x3078) == -1) {
      return 0xffffffff;
    }
    iVar1 = Ordinal_151(*(int *)(param_1 + 0x3078),&uStack_110);
    if (iVar1 == 0) {
      return 0xffffffff;
    }
    iVar1 = Ordinal_151(*(undefined4 *)(param_1 + 0x3078),&uStack_318);
    if ((iVar1 != 0) &&
       (iVar1 = Ordinal_16(*(undefined4 *)(param_1 + 0x3078),param_1 + 0x134b4,1,2), iVar1 < 1)) {
      return 0xffffffff;
    }
    return 0;
  }
LAB_005b9904:
  if (bVar4) {
    uVar3 = Ordinal_111();
    *(undefined4 *)(param_1 + 0x16164) = uVar3;
    if (((*(int *)(param_1 + 0x3074) != -1) || (*(int *)(param_1 + 0x3078) != -1)) &&
       (iVar1 = Ordinal_111(), iVar1 != 0x2714)) {
      uVar3 = FUN_005be760(param_1,"select failed in soap_poll()",0x1c);
      FUN_005bcf60(param_1,uVar3);
      *(undefined4 *)(param_1 + 0x1615c) = 0x1c;
      return 0x1c;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x16164) = 0;
  }
  return 0xffffffff;
}



/* FUNCTION 5027 ; VA 0x005b9a10 ; FUN_005b9a10 */

void FUN_005b9a10(int param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = *(int **)(param_1 + 0x58);
  if (piVar1 == (int *)0x0) {
    *(undefined4 *)(param_1 + 0x58) = 0;
    return;
  }
  do {
    piVar2 = piVar1;
    if ((uint)piVar1[1] < *(uint *)(param_1 + 0x309c)) break;
    piVar2 = (int *)*piVar1;
    FUN_017168b0(piVar1);
    piVar1 = piVar2;
  } while (piVar2 != (int *)0x0);
  *(int **)(param_1 + 0x58) = piVar2;
  return;
}



/* FUNCTION 5028 ; VA 0x005b9a50 ; FUN_005b9a50 */

void FUN_005b9a50(int param_1,undefined4 param_2)

{
  short sVar1;
  int *piVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  int iVar8;
  int iVar9;
  
  if ((param_1 == 0) || ((*(short *)(param_1 + 4) != 1 && (*(short *)(param_1 + 4) != 2)))) {
    FUN_005af950(param_2,"Error: soap struct state not initialized\n");
  }
  else if (*(int *)(param_1 + 0x1615c) != 0) {
    piVar2 = (int *)FUN_005acd30(param_1);
    iVar9 = *piVar2;
    if (iVar9 == 0) {
      FUN_005bc8a0(param_1);
      iVar9 = *piVar2;
    }
    if (*(short *)(param_1 + 6) == 2) {
      puVar3 = (undefined4 *)FUN_005ace60(param_1);
      pcVar5 = (char *)*puVar3;
    }
    else {
      pcVar5 = (char *)0x0;
    }
    piVar2 = (int *)FUN_005ace30(param_1);
    pcVar7 = (char *)*piVar2;
    piVar2 = (int *)FUN_005acd60(param_1);
    if ((piVar2 == (int *)0x0) || (pcVar4 = (char *)*piVar2, pcVar4 == (char *)0x0)) {
      pcVar4 = "[no detail]";
    }
    pcVar6 = "[no reason]";
    if (pcVar7 != (char *)0x0) {
      pcVar6 = pcVar7;
    }
    sVar1 = *(short *)(param_1 + 6);
    pcVar7 = "no subcode";
    if (pcVar5 != (char *)0x0) {
      pcVar7 = pcVar5;
    }
    iVar8 = (int)sVar1;
    if (sVar1 == 0) {
      iVar8 = *(int *)(param_1 + 0x1615c);
    }
    pcVar5 = "SOAP 1.";
    if (sVar1 == 0) {
      pcVar5 = "Error ";
    }
    FUN_005af950(param_2,"%s%d fault: %s [%s]\n\"%s\"\nDetail: %s\n",pcVar5,iVar8,iVar9,pcVar7,
                 pcVar6,pcVar4);
    return;
  }
  return;
}



/* FUNCTION 5029 ; VA 0x005b9b50 ; FUN_005b9b50 */

undefined4 FUN_005b9b50(int param_1,char *param_2,byte *param_3)

{
  char cVar1;
  byte bVar2;
  byte *pbVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  byte *pbVar7;
  byte *pbVar8;
  char *pcVar9;
  char *pcVar10;
  int *piVar11;
  bool bVar12;
  short sStack_8;
  
  sStack_8 = -1;
  pcVar9 = param_2;
  do {
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  pbVar7 = param_3;
  do {
    bVar2 = *pbVar7;
    pbVar7 = pbVar7 + 1;
  } while (bVar2 != 0);
  piVar11 = *(int **)(param_1 + 0x54);
  if (piVar11 != (int *)0x0) {
    sStack_8 = 0;
    if (*piVar11 != 0) {
      do {
        pbVar3 = (byte *)piVar11[1];
        pbVar8 = param_3;
        if (pbVar3 != (byte *)0x0) {
          do {
            bVar2 = *pbVar8;
            bVar12 = bVar2 < *pbVar3;
            if (bVar2 != *pbVar3) {
LAB_005b9be0:
              uVar4 = -(uint)bVar12 | 1;
              goto LAB_005b9be5;
            }
            if (bVar2 == 0) break;
            bVar2 = pbVar8[1];
            bVar12 = bVar2 < pbVar3[1];
            if (bVar2 != pbVar3[1]) goto LAB_005b9be0;
            pbVar3 = pbVar3 + 2;
            pbVar8 = pbVar8 + 2;
          } while (bVar2 != 0);
          uVar4 = 0;
LAB_005b9be5:
          if (uVar4 == 0) {
            if (piVar11[3] != 0) {
              FUN_017168b0(piVar11[3]);
              piVar11[3] = 0;
            }
            break;
          }
        }
        pbVar3 = (byte *)piVar11[3];
        pbVar8 = param_3;
        if (pbVar3 == (byte *)0x0) {
          if ((piVar11[2] != 0) && (iVar5 = FUN_005bdc80(param_3,piVar11[2]), iVar5 == 0)) {
            pbVar3 = (byte *)FUN_0171e1f2(pbVar7 + (1 - (int)(param_3 + 1)));
            piVar11[3] = (int)pbVar3;
            if (pbVar3 != (byte *)0x0) {
              do {
                bVar2 = *pbVar8;
                *pbVar3 = bVar2;
                pbVar3 = pbVar3 + 1;
                pbVar8 = pbVar8 + 1;
              } while (bVar2 != 0);
            }
            break;
          }
        }
        else {
          do {
            bVar2 = *pbVar8;
            bVar12 = bVar2 < *pbVar3;
            if (bVar2 != *pbVar3) {
LAB_005b9c15:
              uVar4 = -(uint)bVar12 | 1;
              goto LAB_005b9c1a;
            }
            if (bVar2 == 0) break;
            bVar2 = pbVar8[1];
            bVar12 = bVar2 < pbVar3[1];
            if (bVar2 != pbVar3[1]) goto LAB_005b9c15;
            pbVar3 = pbVar3 + 2;
            pbVar8 = pbVar8 + 2;
          } while (bVar2 != 0);
          uVar4 = 0;
LAB_005b9c1a:
          if (uVar4 == 0) break;
        }
        piVar11 = piVar11 + 4;
        sStack_8 = sStack_8 + 1;
      } while (*piVar11 != 0);
      if (*piVar11 != 0) goto LAB_005b9c9a;
    }
    sStack_8 = -1;
  }
LAB_005b9c9a:
  pbVar3 = (byte *)0x0;
  if (sStack_8 < 0) {
    pbVar3 = pbVar7 + (1 - (int)(param_3 + 1));
  }
  puVar6 = (undefined4 *)FUN_0171e1f2(pcVar9 + (int)(pbVar3 + (0x14 - (int)(param_2 + 1))));
  if (puVar6 == (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    return 0x14;
  }
  *puVar6 = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 **)(param_1 + 0x58) = puVar6;
  puVar6[1] = *(undefined4 *)(param_1 + 0x309c);
  *(short *)(puVar6 + 2) = sStack_8;
  pcVar10 = param_2;
  do {
    cVar1 = *pcVar10;
    pcVar10 = pcVar10 + 1;
    pcVar10[(int)puVar6 + (0xf - (int)param_2)] = cVar1;
  } while (cVar1 != '\0');
  if (-1 < sStack_8) {
    puVar6[3] = 0;
    return 0;
  }
  puVar6[3] = pcVar9 + (0x11 - (int)(param_2 + 1)) + (int)puVar6;
  pbVar7 = param_3;
  do {
    bVar2 = *pbVar7;
    pbVar7 = pbVar7 + 1;
    pbVar7[(int)(pcVar9 + (0x11 - (int)(param_2 + 1)) + (int)puVar6 + (-1 - (int)param_3))] = bVar2;
  } while (bVar2 != 0);
  return 0;
}



/* FUNCTION 5030 ; VA 0x005b9d40 ; FUN_005b9d40 */

undefined4 * FUN_005b9d40(int param_1,byte *param_2,byte *param_3,short param_4)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  byte *pbVar7;
  byte *pbVar8;
  byte *pbVar9;
  bool bVar10;
  
  pbVar9 = param_2;
  do {
    bVar1 = *pbVar9;
    pbVar9 = pbVar9 + 1;
  } while (bVar1 != 0);
  iVar4 = *(int *)(param_1 + 0x171d0);
  if (iVar4 != 0) {
    while ((iVar3 = FUN_01723e00(iVar4,param_2,(int)pbVar9 - (int)(param_2 + 1)), iVar3 != 0 ||
           ((cVar2 = *(char *)(iVar4 + ((int)pbVar9 - (int)(param_2 + 1))), cVar2 != '\0' &&
            (cVar2 != ' '))))) {
      iVar4 = FUN_0170dbd0(iVar4,0x20);
      if ((iVar4 == 0) || (iVar4 = iVar4 + 1, iVar4 == 0)) goto LAB_005b9da9;
    }
    if (iVar4 != 0) {
      return (undefined4 *)0x0;
    }
  }
LAB_005b9da9:
  if (param_4 == 0) {
    for (puVar6 = *(undefined4 **)(param_1 + 0x58); puVar6 != (undefined4 *)0x0;
        puVar6 = (undefined4 *)*puVar6) {
      pbVar9 = (byte *)(puVar6 + 4);
      pbVar7 = param_2;
      do {
        bVar1 = *pbVar9;
        bVar10 = bVar1 < *pbVar7;
        if (bVar1 != *pbVar7) {
LAB_005b9de7:
          uVar5 = -(uint)bVar10 | 1;
          goto LAB_005b9dec;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar9[1];
        bVar10 = bVar1 < pbVar7[1];
        if (bVar1 != pbVar7[1]) goto LAB_005b9de7;
        pbVar9 = pbVar9 + 2;
        pbVar7 = pbVar7 + 2;
      } while (bVar1 != 0);
      uVar5 = 0;
LAB_005b9dec:
      if (uVar5 == 0) {
        pbVar9 = (byte *)puVar6[3];
        pbVar7 = pbVar9;
        pbVar8 = param_3;
        if (pbVar9 != (byte *)0x0) {
          do {
            bVar1 = *pbVar7;
            bVar10 = bVar1 < *pbVar8;
            if (bVar1 != *pbVar8) {
LAB_005b9e20:
              uVar5 = -(uint)bVar10 | 1;
              goto LAB_005b9e25;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar7[1];
            bVar10 = bVar1 < pbVar8[1];
            if (bVar1 != pbVar8[1]) goto LAB_005b9e20;
            pbVar7 = pbVar7 + 2;
            pbVar8 = pbVar8 + 2;
          } while (bVar1 != 0);
          uVar5 = 0;
LAB_005b9e25:
          if (uVar5 != 0) goto LAB_005b9e29;
        }
        if ((*(uint *)(param_1 + 0x309c) <= (uint)puVar6[1]) && (pbVar9 != (byte *)0x0)) {
          return (undefined4 *)0x0;
        }
        if (*(short *)(puVar6 + 2) != 1) {
          return (undefined4 *)0x0;
        }
        param_4 = 1;
        break;
      }
LAB_005b9e29:
    }
  }
  pbVar9 = param_2;
  do {
    bVar1 = *pbVar9;
    pbVar9 = pbVar9 + 1;
  } while (bVar1 != 0);
  if (param_3 == (byte *)0x0) {
    iVar4 = 0;
  }
  else {
    pbVar7 = param_3;
    do {
      bVar1 = *pbVar7;
      pbVar7 = pbVar7 + 1;
    } while (bVar1 != 0);
    iVar4 = (int)pbVar7 - (int)(param_3 + 1);
  }
  puVar6 = (undefined4 *)FUN_0171e1f2(pbVar9 + ((iVar4 + 0x15) - (int)(param_2 + 1)));
  if (puVar6 == (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    return (undefined4 *)0x0;
  }
  *puVar6 = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 **)(param_1 + 0x58) = puVar6;
  pbVar7 = param_2;
  do {
    bVar1 = *pbVar7;
    pbVar7 = pbVar7 + 1;
    pbVar7[(int)puVar6 + (0xf - (int)param_2)] = bVar1;
  } while (bVar1 != 0);
  if (param_3 == (byte *)0x0) {
    puVar6[3] = 0;
  }
  else {
    puVar6[3] = pbVar9 + (int)puVar6 + (0x11 - (int)(param_2 + 1));
    pbVar7 = param_3;
    do {
      bVar1 = *pbVar7;
      pbVar7 = pbVar7 + 1;
      pbVar7[(int)(pbVar9 + (int)puVar6 + (0x11 - (int)(param_2 + 1)) + (-1 - (int)param_3))] =
           bVar1;
    } while (bVar1 != 0);
  }
  puVar6[1] = *(undefined4 *)(param_1 + 0x309c);
  *(short *)(puVar6 + 2) = param_4;
  return puVar6;
}



/* FUNCTION 5031 ; VA 0x005b9f10 ; FUN_005b9f10 */

int FUN_005b9f10(int param_1)

{
  int *piVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  
  if ((*(byte *)(param_1 + 8) & 0x80) != 0) {
    for (piVar1 = *(int **)(param_1 + 0x16194); piVar1 != (int *)0x0; piVar1 = (int *)*piVar1) {
      *(int *)(param_1 + 0x16170) = piVar1[2];
      *(int *)(param_1 + 0x16184) = piVar1[3];
      *(int *)(param_1 + 0x16188) = piVar1[4];
      *(int *)(param_1 + 0x1618c) = piVar1[5];
      *(undefined *)(param_1 + 0x1617c) = 0x18;
      if (*(code **)(param_1 + 0x3044) == (code *)0x0) {
LAB_005b9f9c:
        if (*piVar1 == 0) {
          *(byte *)(param_1 + 0x1617c) = *(byte *)(param_1 + 0x1617c) | 2;
        }
        iVar3 = FUN_005ba200(param_1);
        if (iVar3 != 0) {
LAB_005ba1aa:
          return *(int *)(param_1 + 0x1615c);
        }
        iVar3 = piVar1[2];
        iVar4 = FUN_005bc2c0(param_1,piVar1[1],iVar3);
        if (iVar4 == 0) {
          iVar3 = FUN_005bc2c0(param_1,&DAT_018c2414,-iVar3 & 3);
        }
        else {
          iVar3 = *(int *)(param_1 + 0x1615c);
        }
        if (iVar3 != 0) goto LAB_005ba1aa;
      }
      else {
        iVar3 = (**(code **)(param_1 + 0x3044))(param_1,piVar1[1],piVar1[3],piVar1[4],piVar1[5]);
        if (iVar3 == 0) {
          if (*(int *)(param_1 + 0x1615c) != 0) {
            return *(int *)(param_1 + 0x1615c);
          }
          goto LAB_005b9f9c;
        }
        uVar5 = piVar1[2];
        if ((uVar5 == 0) &&
           ((uVar7 = *(uint *)(param_1 + 8) & 3, (*(uint *)(param_1 + 8) & 0x40) != 0 || uVar7 == 3
            || (uVar7 == 2)))) {
          do {
            uVar5 = (**(code **)(param_1 + 0x3054))(param_1,iVar3,param_1 + 0x134b4,0x400);
            if (uVar5 < 0x400) {
              bVar2 = *(byte *)(param_1 + 0x1617c) & 0xfe;
              *(byte *)(param_1 + 0x1617c) = bVar2;
              if (*piVar1 == 0) {
                *(byte *)(param_1 + 0x1617c) = bVar2 | 2;
              }
            }
            else {
              *(byte *)(param_1 + 0x1617c) = *(byte *)(param_1 + 0x1617c) | 1;
            }
            *(uint *)(param_1 + 0x16170) = uVar5;
            iVar4 = FUN_005ba200(param_1);
            if (iVar4 != 0) break;
            iVar4 = FUN_005bc2c0(param_1,param_1 + 0x134b4,uVar5);
            if (iVar4 == 0) {
              iVar4 = FUN_005bc2c0(param_1,&DAT_018c2414,-uVar5 & 3);
            }
            else {
              iVar4 = *(int *)(param_1 + 0x1615c);
            }
            if (iVar4 != 0) break;
            if (*(int *)(param_1 + 0x16184) != 0) {
              *(byte *)(param_1 + 0x1617c) = *(byte *)(param_1 + 0x1617c) & 0xeb;
              *(undefined4 *)(param_1 + 0x16184) = 0;
              *(undefined4 *)(param_1 + 0x16188) = 0;
              *(undefined4 *)(param_1 + 0x1618c) = 0;
            }
          } while (0x3ff < uVar5);
        }
        else {
          if (*piVar1 == 0) {
            *(byte *)(param_1 + 0x1617c) = *(byte *)(param_1 + 0x1617c) | 2;
          }
          iVar4 = FUN_005ba200(param_1);
          if (iVar4 != 0) goto LAB_005ba1aa;
          while( true ) {
            uVar7 = 0x400;
            if (uVar5 < 0x400) {
              uVar7 = uVar5;
            }
            iVar4 = (**(code **)(param_1 + 0x3054))(param_1,iVar3,param_1 + 0x134b4,uVar7);
            if (iVar4 == 0) break;
            iVar6 = FUN_005bc2c0(param_1,param_1 + 0x134b4,iVar4);
            if ((iVar6 != 0) || (uVar5 = uVar5 - iVar4, uVar5 == 0)) goto LAB_005ba14a;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
LAB_005ba14a:
          FUN_005bc2c0(param_1,&DAT_018c2414,-*(int *)(param_1 + 0x16170) & 3);
        }
        if (*(code **)(param_1 + 0x304c) != (code *)0x0) {
          (**(code **)(param_1 + 0x304c))(param_1,iVar3);
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 5032 ; VA 0x005ba1c0 ; FUN_005ba1c0 */

undefined4 FUN_005ba1c0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005bc2c0(param_1,param_2,param_3);
  if (iVar1 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = FUN_005bc2c0(param_1,&DAT_018c2414,-param_3 & 3);
  return uVar2;
}



/* FUNCTION 5033 ; VA 0x005ba200 ; FUN_005ba200 */

undefined4 FUN_005ba200(int param_1)

{
  char *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  byte bStack_18;
  byte bStack_17;
  undefined uStack_16;
  undefined uStack_15;
  undefined uStack_14;
  undefined uStack_13;
  undefined uStack_12;
  undefined uStack_11;
  undefined uStack_10;
  undefined uStack_f;
  undefined uStack_e;
  undefined uStack_d;
  uint uStack_c;
  int iStack_8;
  
  uVar5 = 0;
  iStack_8 = 0;
  uStack_c = 0;
  iVar4 = *(int *)(param_1 + 0x1618c);
  if (iVar4 != 0) {
    iStack_8 = CONCAT11(*(undefined *)(iVar4 + 2),*(undefined *)(iVar4 + 3)) + 4;
  }
  pcVar6 = *(char **)(param_1 + 0x16184);
  if (pcVar6 != (char *)0x0) {
    pcVar1 = pcVar6 + 1;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    uVar5 = (int)pcVar6 - (int)pcVar1;
    if (0xffff < uVar5) {
      uVar5 = 0xffff;
    }
  }
  pcVar6 = *(char **)(param_1 + 0x16188);
  if (pcVar6 != (char *)0x0) {
    pcVar1 = pcVar6 + 1;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    uStack_c = (int)pcVar6 - (int)pcVar1;
    if (0xffff < uStack_c) {
      uStack_c = 0xffff;
    }
  }
  uStack_13 = (undefined)uVar5;
  uStack_11 = (undefined)uStack_c;
  bStack_18 = *(byte *)(param_1 + 0x1617c) & 7 | 8;
  bStack_17 = *(byte *)(param_1 + 0x1617c) & 0xf0;
  uStack_16 = (undefined)((uint)iStack_8 >> 8);
  uStack_14 = (undefined)(uVar5 >> 8);
  uStack_12 = (undefined)(uStack_c >> 8);
  uStack_15 = (undefined)iStack_8;
  uVar3 = *(undefined4 *)(param_1 + 0x16170);
  uStack_10 = (undefined)((uint)uVar3 >> 0x18);
  uStack_f = (undefined)((uint)uVar3 >> 0x10);
  uStack_e = (undefined)((uint)uVar3 >> 8);
  uStack_d = (undefined)uVar3;
  iVar4 = FUN_005bc2c0(param_1,&bStack_18,0xc);
  if (iVar4 == 0) {
    iVar4 = FUN_005bc2c0(param_1,*(undefined4 *)(param_1 + 0x1618c),iStack_8);
    if (iVar4 == 0) {
      iVar4 = FUN_005bc2c0(param_1,&DAT_018c2414,-iStack_8 & 3);
    }
    else {
      iVar4 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar4 == 0) {
      iVar4 = FUN_005bc2c0(param_1,*(undefined4 *)(param_1 + 0x16184),uVar5);
      if (iVar4 == 0) {
        iVar4 = FUN_005bc2c0(param_1,&DAT_018c2414,-uVar5 & 3);
      }
      else {
        iVar4 = *(int *)(param_1 + 0x1615c);
      }
      if ((iVar4 == 0) &&
         (iVar4 = FUN_005ba1c0(param_1,*(undefined4 *)(param_1 + 0x16188),uStack_c), iVar4 == 0)) {
        return 0;
      }
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5034 ; VA 0x005ba390 ; FUN_005ba390 */

int FUN_005ba390(int param_1,int param_2,int param_3)

{
  char cVar1;
  undefined4 *puVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  char *pcVar8;
  char *pcVar9;
  char *pcVar10;
  char *pcVar11;
  undefined2 *puVar12;
  char *pcStack_c;
  
  if (*(int *)(param_1 + 0x16158) == 0x7d1) goto LAB_005ba65f;
  pcStack_c = (char *)0x0;
  if (param_2 == 0x3eb) {
    pcVar3 = *(char **)(param_1 + 0x24);
    if (pcVar3 == (char *)0x0) {
LAB_005ba3c9:
      if (((param_3 != 0) ||
          (pcVar3 = "text/xml; charset=utf-8", ((byte)*(undefined4 *)(param_1 + 0x10) & 3) == 3)) &&
         (pcVar3 = "application/soap+xml; charset=utf-8", *(short *)(param_1 + 6) != 2)) {
        pcVar3 = "text/xml; charset=utf-8";
      }
    }
  }
  else {
    if (param_2 != 0x3ea) goto LAB_005ba3c9;
    pcVar3 = "text/html; charset=utf-8";
  }
  uVar6 = *(uint *)(param_1 + 8);
  pcVar10 = pcVar3;
  if ((uVar6 & 0x280) != 0) {
    if ((uVar6 & 0x200) == 0) {
      pcVar10 = "application/dime";
    }
    else {
      pcVar10 = "application/xop+xml; charset=utf-8";
      pcStack_c = pcVar3;
    }
  }
  if (((uVar6 & 0x100) != 0) && (pcVar3 = *(char **)(param_1 + 0x1619c), pcVar3 != (char *)0x0)) {
    pcVar9 = pcVar3 + 1;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    pcVar8 = "";
    if (*(char **)(param_1 + 0x161a0) != (char *)0x0) {
      pcVar8 = *(char **)(param_1 + 0x161a0);
    }
    pcVar11 = pcVar8 + 1;
    do {
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    if (pcVar3 + (int)(pcVar8 + (-(int)pcVar11 - (int)pcVar9)) < (char *)0x3b0) {
      iVar4 = FUN_0170dbd0(pcVar10,0x3b);
      FUN_005bde90(param_1 + 0x134b4,"multipart/related; boundary=\"%s\"; type=\"",
                   *(undefined4 *)(param_1 + 0x1619c));
      pcVar3 = pcVar10;
      if (iVar4 == 0) {
        do {
          cVar1 = *pcVar3;
          pcVar3 = pcVar3 + 1;
        } while (cVar1 != '\0');
        uVar6 = (int)pcVar3 - (int)pcVar10;
        pcVar3 = (char *)(param_1 + 0x134b3);
        do {
          pcVar9 = pcVar3 + 1;
          pcVar3 = pcVar3 + 1;
        } while (*pcVar9 != '\0');
        for (uVar5 = uVar6 >> 2; uVar5 != 0; uVar5 = uVar5 - 1) {
          *(undefined4 *)pcVar3 = *(undefined4 *)pcVar10;
          pcVar10 = pcVar10 + 4;
          pcVar3 = pcVar3 + 4;
        }
        for (uVar6 = uVar6 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
          *pcVar3 = *pcVar10;
          pcVar10 = pcVar10 + 1;
          pcVar3 = pcVar3 + 1;
        }
      }
      else {
        FUN_01723cc0(param_1 + 0x134b4,pcVar10,iVar4 - (int)pcVar10);
      }
      pcVar10 = (char *)(param_1 + 0x134b4);
      if (*(int *)(param_1 + 0x161a0) != 0) {
        puVar2 = (undefined4 *)(param_1 + 0x134b3);
        do {
          puVar7 = puVar2;
          puVar2 = (undefined4 *)((int)puVar7 + 1);
        } while (*(char *)((int)puVar7 + 1) != '\0');
        *(undefined4 *)((int)puVar7 + 1) = DAT_018c3c78;
        *(undefined4 *)((int)puVar7 + 5) = DAT_018c3c7c;
        *(undefined2 *)((int)puVar7 + 9) = DAT_018c3c80;
        *(undefined *)((int)puVar7 + 0xb) = DAT_018c3c82;
        pcVar3 = *(char **)(param_1 + 0x161a0);
        pcVar9 = pcVar3;
        do {
          cVar1 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar1 != '\0');
        pcVar8 = (char *)(param_1 + 0x134b3);
        do {
          pcVar11 = pcVar8 + 1;
          pcVar8 = pcVar8 + 1;
        } while (*pcVar11 != '\0');
        pcVar11 = pcVar3;
        for (uVar6 = (uint)((int)pcVar9 - (int)pcVar3) >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
          *(undefined4 *)pcVar8 = *(undefined4 *)pcVar11;
          pcVar11 = pcVar11 + 4;
          pcVar8 = pcVar8 + 4;
        }
        for (uVar6 = (int)pcVar9 - (int)pcVar3 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
          *pcVar8 = *pcVar11;
          pcVar11 = pcVar11 + 1;
          pcVar8 = pcVar8 + 1;
        }
      }
      puVar12 = (undefined2 *)(param_1 + 0x134b3);
      do {
        pcVar3 = (char *)((int)puVar12 + 1);
        puVar12 = (undefined2 *)((int)puVar12 + 1);
      } while (*pcVar3 != '\0');
      *puVar12 = DAT_018c35d8;
      if (pcStack_c != (char *)0x0) {
        puVar2 = (undefined4 *)(param_1 + 0x134b3);
        do {
          puVar7 = puVar2;
          puVar2 = (undefined4 *)((int)puVar7 + 1);
        } while (*(char *)((int)puVar7 + 1) != '\0');
        *(undefined4 *)((int)puVar7 + 1) = DAT_018c3c84;
        *(undefined4 *)((int)puVar7 + 5) = DAT_018c3c88;
        *(undefined4 *)((int)puVar7 + 9) = DAT_018c3c8c;
        *(undefined2 *)((int)puVar7 + 0xd) = DAT_018c3c90;
        *(undefined *)((int)puVar7 + 0xf) = DAT_018c3c92;
        pcVar3 = pcStack_c;
        do {
          cVar1 = *pcVar3;
          pcVar3 = pcVar3 + 1;
        } while (cVar1 != '\0');
        pcVar9 = (char *)(param_1 + 0x134b3);
        do {
          pcVar8 = pcVar9 + 1;
          pcVar9 = pcVar9 + 1;
        } while (*pcVar8 != '\0');
        pcVar8 = pcStack_c;
        for (uVar6 = (uint)((int)pcVar3 - (int)pcStack_c) >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
          *(undefined4 *)pcVar9 = *(undefined4 *)pcVar8;
          pcVar8 = pcVar8 + 4;
          pcVar9 = pcVar9 + 4;
        }
        for (uVar6 = (int)pcVar3 - (int)pcStack_c & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
          *pcVar9 = *pcVar8;
          pcVar8 = pcVar8 + 1;
          pcVar9 = pcVar9 + 1;
        }
        puVar12 = (undefined2 *)(param_1 + 0x134b3);
        do {
          pcVar3 = (char *)((int)puVar12 + 1);
          puVar12 = (undefined2 *)((int)puVar12 + 1);
        } while (*pcVar3 != '\0');
        *puVar12 = DAT_018c35d8;
      }
    }
  }
  iVar4 = 0;
  if ((pcVar10 == (char *)0x0) ||
     (iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,"Content-Type",pcVar10), iVar4 == 0)) {
    if (((byte)*(undefined4 *)(param_1 + 0x10) & 3) == 3) {
      iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,"Transfer-Encoding","chunked");
    }
    else if (pcVar10 != (char *)0x0) {
      FUN_005bde90(param_1 + 0x134b4,&DAT_018c3820,param_3);
      iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,"Content-Length",param_1 + 0x134b4);
    }
    if (iVar4 == 0) {
LAB_005ba65f:
      pcVar3 = "keep-alive";
      if (*(short *)(param_1 + 0x1612c) == 0) {
        pcVar3 = "close";
      }
      iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,"Connection",pcVar3);
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 5035 ; VA 0x005ba690 ; FUN_005ba690 */

undefined4 FUN_005ba690(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  char *pcVar7;
  uint uVar8;
  int *piVar9;
  char *pcVar10;
  
  if (((*(uint *)(param_1 + 8) & 0x100) == 0) ||
     (pcVar10 = *(char **)(param_1 + 0x1619c), pcVar10 == (char *)0x0)) {
    return 0;
  }
  piVar9 = *(int **)(param_1 + 0x161a8);
  if (piVar9 != (int *)0x0) {
    do {
      if ((*(code **)(param_1 + 0x305c) == (code *)0x0) ||
         ((iVar2 = (**(code **)(param_1 + 0x305c))(param_1,piVar9[1],piVar9[3],piVar9[4],piVar9[8]),
          iVar2 == 0 && (*(int *)(param_1 + 0x1615c) == 0)))) {
        iVar2 = FUN_005ba890(param_1,piVar9);
        if ((iVar2 != 0) || (iVar2 = FUN_005bc2c0(param_1,piVar9[1],piVar9[2]), iVar2 != 0))
        goto LAB_005ba86f;
      }
      else {
        uVar8 = piVar9[2];
        if ((iVar2 == 0) || (iVar3 = FUN_005ba890(param_1,piVar9), iVar3 != 0)) goto LAB_005ba86f;
        if (uVar8 == 0) {
          uVar8 = *(uint *)(param_1 + 8) & 3;
          if (((*(uint *)(param_1 + 8) & 0x40) != 0 || uVar8 == 3) || (uVar8 == 2)) {
            do {
              iVar3 = (**(code **)(param_1 + 0x306c))(param_1,iVar2,param_1 + 0x134b4,0x400);
              iVar4 = FUN_005bc2c0(param_1,param_1 + 0x134b4,iVar3);
              if (iVar4 != 0) break;
            } while (iVar3 != 0);
          }
        }
        else {
          while( true ) {
            uVar5 = 0x400;
            if (uVar8 < 0x400) {
              uVar5 = uVar8;
            }
            iVar3 = (**(code **)(param_1 + 0x306c))(param_1,iVar2,param_1 + 0x134b4,uVar5);
            if (iVar3 == 0) break;
            iVar4 = FUN_005bc2c0(param_1,param_1 + 0x134b4,iVar3);
            if ((iVar4 != 0) || (uVar8 = uVar8 - iVar3, uVar8 == 0)) goto LAB_005ba7d4;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
        }
LAB_005ba7d4:
        if (*(code **)(param_1 + 0x3064) != (code *)0x0) {
          (**(code **)(param_1 + 0x3064))(param_1,iVar2);
        }
      }
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)0x0);
    pcVar10 = *(char **)(param_1 + 0x1619c);
  }
  iVar2 = FUN_005bc2c0(param_1,&DAT_018c38c8,4);
  if (iVar2 != 0) {
LAB_005ba86f:
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  if (pcVar10 != (char *)0x0) {
    pcVar7 = pcVar10;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    iVar2 = FUN_005bc2c0(param_1,pcVar10,(int)pcVar7 - (int)(pcVar10 + 1));
    if (iVar2 != 0) goto LAB_005ba86f;
  }
  uVar6 = FUN_005bc2c0(param_1,&DAT_018c3938,2);
  return uVar6;
}



/* FUNCTION 5036 ; VA 0x005ba890 ; FUN_005ba890 */

undefined4 FUN_005ba890(int param_1,int param_2)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  char *pcVar6;
  
  pcVar2 = *(char **)(param_1 + 0x1619c);
  iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c8,4);
  if (iVar3 == 0) {
    if (pcVar2 != (char *)0x0) {
      pcVar6 = pcVar2;
      do {
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar1 != '\0');
      iVar3 = FUN_005bc2c0(param_1,pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
      if (iVar3 != 0) goto LAB_005ba8ea;
    }
    iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
  }
  else {
LAB_005ba8ea:
    iVar3 = *(int *)(param_1 + 0x1615c);
  }
  if (iVar3 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  pcVar2 = *(char **)(param_2 + 0x10);
  if (pcVar2 != (char *)0x0) {
    iVar3 = FUN_005bc2c0(param_1,"Content-Type: ",0xe);
    if (iVar3 == 0) {
      if (pcVar2 != (char *)0x0) {
        pcVar6 = pcVar2;
        do {
          cVar1 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar1 != '\0');
        iVar3 = FUN_005bc2c0(param_1,pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
        if (iVar3 != 0) goto LAB_005ba950;
      }
      iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
    }
    else {
LAB_005ba950:
      iVar3 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar3 != 0) goto LAB_005baaec;
  }
  piVar4 = (int *)&DAT_018c28e0;
  if (*(int *)(param_2 + 0x18) != 1) {
    do {
      if (piVar4[1] == 0) break;
      piVar4 = piVar4 + 2;
    } while (*piVar4 != *(int *)(param_2 + 0x18));
  }
  pcVar2 = (char *)piVar4[1];
  if (pcVar2 != (char *)0x0) {
    iVar3 = FUN_005bc2c0(param_1,"Content-Transfer-Encoding: ",0x1b);
    if (iVar3 == 0) {
      pcVar6 = pcVar2;
      do {
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar1 != '\0');
      iVar3 = FUN_005bc2c0(param_1,pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
      if (iVar3 != 0) goto LAB_005ba9ca;
      iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
    }
    else {
LAB_005ba9ca:
      iVar3 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar3 != 0) goto LAB_005baaec;
  }
  pcVar2 = *(char **)(param_2 + 0xc);
  if (pcVar2 != (char *)0x0) {
    iVar3 = FUN_005bc2c0(param_1,"Content-ID: ",0xc);
    if (iVar3 == 0) {
      if (pcVar2 != (char *)0x0) {
        pcVar6 = pcVar2;
        do {
          cVar1 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar1 != '\0');
        iVar3 = FUN_005bc2c0(param_1,pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
        if (iVar3 != 0) goto LAB_005baa2a;
      }
      iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
    }
    else {
LAB_005baa2a:
      iVar3 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar3 != 0) goto LAB_005baaec;
  }
  pcVar2 = *(char **)(param_2 + 0x1c);
  if (pcVar2 != (char *)0x0) {
    iVar3 = FUN_005bc2c0(param_1,"Content-Location: ",0x12);
    if (iVar3 == 0) {
      if (pcVar2 != (char *)0x0) {
        pcVar6 = pcVar2;
        do {
          cVar1 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar1 != '\0');
        iVar3 = FUN_005bc2c0(param_1,pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
        if (iVar3 != 0) goto LAB_005baa8a;
      }
      iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
    }
    else {
LAB_005baa8a:
      iVar3 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar3 != 0) goto LAB_005baaec;
  }
  pcVar2 = *(char **)(param_2 + 0x20);
  if (pcVar2 == (char *)0x0) goto LAB_005baaf7;
  iVar3 = FUN_005bc2c0(param_1,"Content-Description: ",0x15);
  if (iVar3 == 0) {
    if (pcVar2 != (char *)0x0) {
      pcVar6 = pcVar2;
      do {
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar1 != '\0');
      iVar3 = FUN_005bc2c0(param_1,pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
      if (iVar3 != 0) goto LAB_005baae2;
    }
    iVar3 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
  }
  else {
LAB_005baae2:
    iVar3 = *(int *)(param_1 + 0x1615c);
  }
  if (iVar3 != 0) {
LAB_005baaec:
    return *(undefined4 *)(param_1 + 0x1615c);
  }
LAB_005baaf7:
  uVar5 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
  return uVar5;
}



/* FUNCTION 5037 ; VA 0x005bab10 ; FUN_005bab10 */

void FUN_005bab10(undefined4 param_1,uint param_2)

{
  byte *pbVar1;
  byte bVar2;
  byte abStack_14 [16];
  
  if (param_2 < 0x80) {
    if (param_2 != 0) {
      abStack_14[0] = (byte)param_2;
      FUN_005bc2c0(param_1,abStack_14,1);
      return;
    }
  }
  else {
    if (param_2 < 0x800) {
      pbVar1 = abStack_14;
      abStack_14[0] = (byte)(param_2 >> 6) & 0x1f | 0xc0;
    }
    else {
      if (param_2 < 0x10000) {
        pbVar1 = abStack_14;
        abStack_14[0] = (byte)(param_2 >> 0xc) & 0xf | 0xe0;
      }
      else {
        if (param_2 < 0x200000) {
          pbVar1 = abStack_14;
          abStack_14[0] = (byte)(param_2 >> 0x12) & 7 | 0xf0;
        }
        else {
          bVar2 = (byte)(param_2 >> 0x18);
          if (param_2 < 0x4000000) {
            abStack_14[0] = bVar2 & 3 | 0xf8;
            pbVar1 = abStack_14 + 1;
          }
          else {
            abStack_14[1] = bVar2 & 0x3f | 0x80;
            pbVar1 = abStack_14 + 2;
            abStack_14[0] = bVar2 >> 6 & 1 | 0xfc;
          }
          *pbVar1 = (byte)(param_2 >> 0x12) & 0x3f | 0x80;
        }
        pbVar1 = pbVar1 + 1;
        *pbVar1 = (byte)(param_2 >> 0xc) & 0x3f | 0x80;
      }
      pbVar1 = pbVar1 + 1;
      *pbVar1 = (byte)(param_2 >> 6) & 0x3f | 0x80;
    }
    pbVar1[1] = (byte)param_2 & 0x3f | 0x80;
    (pbVar1 + 1)[1] = 0;
  }
  pbVar1 = abStack_14;
  do {
    bVar2 = *pbVar1;
    pbVar1 = pbVar1 + 1;
  } while (bVar2 != 0);
  FUN_005bc2c0(param_1,abStack_14,(int)pbVar1 - (int)(abStack_14 + 1));
  return;
}



/* FUNCTION 5038 ; VA 0x005bac20 ; FUN_005bac20 */

void FUN_005bac20(int param_1,undefined4 param_2,undefined4 param_3)

{
  char *pcVar1;
  
  pcVar1 = "SOAP-ENV:Receiver";
  if (*(short *)(param_1 + 6) != 2) {
    pcVar1 = "SOAP-ENV:Server";
  }
  FUN_005b31e0(param_1,pcVar1,0,param_2,param_3);
  return;
}



/* FUNCTION 5039 ; VA 0x005bac50 ; FUN_005bac50 */

void FUN_005bac50(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  
  pcVar1 = "SOAP-ENV:Receiver";
  if (*(short *)(param_1 + 6) != 2) {
    pcVar1 = "SOAP-ENV:Server";
  }
  FUN_005b31e0(param_1,pcVar1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 5040 ; VA 0x005bac80 ; FUN_005bac80 */

undefined4 FUN_005bac80(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  byte *pbVar4;
  uint uVar5;
  byte abStack_10 [8];
  undefined uStack_8;
  undefined uStack_7;
  undefined uStack_6;
  undefined uStack_5;
  
  if ((*(byte *)(param_1 + 8) & 0x80) != 0) {
    iVar1 = *(int *)(param_1 + 0x16178);
    if (iVar1 == 0) {
      if (*(int *)(param_1 + 0x16174) == 0) goto LAB_005bae69;
      iVar1 = FUN_005baed0(param_1);
      if (iVar1 == 0) {
        iVar1 = *(int *)(param_1 + 0x3090);
        iVar2 = *(int *)(param_1 + 0x308c);
        uVar5 = *(uint *)(param_1 + 0x16174);
        if (uVar5 <= (uint)(iVar1 - iVar2)) {
          *(int *)(param_1 + 0x16178) = iVar1;
          *(int *)(param_1 + 0x30a0) = *(int *)(param_1 + 0x30a0) + (uVar5 - iVar1) + iVar2;
          *(uint *)(param_1 + 0x3090) = uVar5 + iVar2;
          return 0;
        }
        *(uint *)(param_1 + 0x16174) = (uVar5 - iVar1) + iVar2;
        return 0;
      }
    }
    else {
      *(int *)(param_1 + 0x30a0) = *(int *)(param_1 + 0x30a0) + (iVar1 - *(int *)(param_1 + 0x3090))
      ;
      *(int *)(param_1 + 0x3090) = iVar1;
      uVar5 = -*(int *)(param_1 + 0x16170) & 3;
      if (uVar5 != 0) {
        do {
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
          if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
             (iVar1 = FUN_005baed0(param_1), iVar1 != 0)) {
            return 0xffffffff;
          }
          uVar5 = uVar5 - 1;
        } while (0 < (int)uVar5);
      }
      iVar1 = 0xc;
      pbVar4 = abStack_10;
      while( true ) {
        uVar5 = *(int *)(param_1 + 0x308c) + 1;
        *pbVar4 = *(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
        *(uint *)(param_1 + 0x308c) = uVar5;
        if ((*(uint *)(param_1 + 0x3090) <= uVar5) && (iVar2 = FUN_005baed0(param_1), iVar2 != 0))
        break;
        iVar1 = iVar1 + -1;
        pbVar4 = pbVar4 + 1;
        if (iVar1 < 1) {
          iVar1 = *(int *)(param_1 + 0x3090);
          iVar2 = *(int *)(param_1 + 0x308c);
          *(byte *)(param_1 + 0x1617c) = abStack_10[0] & 7;
          uVar5 = CONCAT31(CONCAT21(CONCAT11(uStack_8,uStack_7),uStack_6),uStack_5);
          *(uint *)(param_1 + 0x16170) = uVar5;
          if ((abStack_10[0] & 1) == 0) {
            *(undefined4 *)(param_1 + 0x16178) = 0;
            *(int *)(param_1 + 0x30a0) = iVar1 - iVar2;
            *(undefined4 *)(param_1 + 0x16174) = 0;
            return 0;
          }
          *(uint *)(param_1 + 0x16174) = uVar5;
          if (uVar5 <= (uint)(iVar1 - iVar2)) {
            *(int *)(param_1 + 0x16178) = iVar1;
            *(uint *)(param_1 + 0x3090) = uVar5 + iVar2;
            *(uint *)(param_1 + 0x30a0) = (uVar5 + iVar2) - iVar2;
            return 0;
          }
          *(int *)(param_1 + 0x30a0) = iVar1 - iVar2;
          *(uint *)(param_1 + 0x16174) = (uVar5 - iVar1) + iVar2;
          return 0;
        }
      }
    }
    return 0xffffffff;
  }
LAB_005bae69:
  uVar3 = FUN_005baed0(param_1);
  return uVar3;
}



/* FUNCTION 5041 ; VA 0x005bae80 ; FUN_005bae80 */

int FUN_005bae80(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_005ade00(param_1);
  if ((iVar1 == 0) || (*(int *)(param_1 + 0x1615c) != 3)) {
    if (*(int *)(param_1 + 0x1615c) != 0) {
      return *(int *)(param_1 + 0x1615c);
    }
    if (*(code **)(param_1 + 0x2ff0) != (code *)0x0) {
      iVar1 = (**(code **)(param_1 + 0x2ff0))(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      return iVar1;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
  }
  return 0;
}



/* FUNCTION 5042 ; VA 0x005baed0 ; FUN_005baed0 */

uint FUN_005baed0(undefined *param_1)

{
  undefined *puVar1;
  uint uVar2;
  undefined *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  char cVar7;
  uint uVar8;
  undefined auStack_c [8];
  
  puVar3 = param_1;
  if (((byte)*(undefined4 *)(param_1 + 8) & 3) == 3) {
    uVar6 = *(uint *)(param_1 + 0x15510);
    if (uVar6 == 0) {
      uVar4 = *(uint *)(param_1 + 0x15514);
LAB_005baf00:
      param_1 = auStack_c;
      puVar1 = puVar3 + 0x30b4;
      if (uVar4 != 0) {
        *(undefined4 *)(puVar3 + 0x308c) = *(undefined4 *)(puVar3 + 0x3090);
LAB_005baf58:
        *(uint *)(puVar3 + 0x3090) = uVar4;
        do {
          uVar6 = *(uint *)(puVar3 + 0x308c);
          if (uVar6 < *(uint *)(puVar3 + 0x3090)) {
LAB_005bafa4:
            cVar7 = puVar1[uVar6];
            *(uint *)(puVar3 + 0x308c) = uVar6 + 1;
            iVar5 = (int)cVar7;
            if (((0x2f < iVar5) && (iVar5 < 0x3a)) || ((0x40 < iVar5 && (iVar5 < 0x47))))
            goto LAB_005bafd0;
          }
          else {
            *(undefined4 *)(puVar3 + 0x308c) = 0;
            iVar5 = (**(code **)(puVar3 + 0x3018))(puVar3,puVar1,0x10000);
            *(int *)(puVar3 + 0x15514) = iVar5;
            *(int *)(puVar3 + 0x3090) = iVar5;
            if (iVar5 != 0) {
              uVar6 = *(uint *)(puVar3 + 0x308c);
              goto LAB_005bafa4;
            }
            iVar5 = -1;
          }
          if (iVar5 - 0x61U < 6) goto LAB_005bafd0;
          if (iVar5 == -1) {
            *(undefined4 *)(puVar3 + 0x3094) = 0xffffffff;
            return 0xffffffff;
          }
        } while( true );
      }
      uVar4 = (**(code **)(puVar3 + 0x3018))(puVar3,puVar1,0x10000);
      *(undefined4 *)(puVar3 + 0x308c) = 0;
      *(uint *)(puVar3 + 0x15514) = uVar4;
      if (uVar4 != 0) goto LAB_005baf58;
      goto LAB_005baf38;
    }
LAB_005bb17b:
    if (0x10000 < uVar6) {
      uVar6 = 0x10000;
    }
    iVar5 = (**(code **)(puVar3 + 0x3018))(puVar3,puVar3 + 0x30b4,uVar6);
    *(undefined4 *)(puVar3 + 0x308c) = 0;
    *(int *)(puVar3 + 0x3090) = iVar5;
    *(int *)(puVar3 + 0x15510) = *(int *)(puVar3 + 0x15510) - iVar5;
  }
  else {
    *(undefined4 *)(param_1 + 0x308c) = 0;
    iVar5 = (**(code **)(param_1 + 0x3018))(param_1,param_1 + 0x30b4,0x10000);
    *(int *)(puVar3 + 0x3090) = iVar5;
  }
  goto LAB_005bb265;
LAB_005bafd0:
  do {
    *param_1 = (char)iVar5;
    param_1 = param_1 + 1;
    uVar6 = *(uint *)(puVar3 + 0x308c);
    if (uVar6 < *(uint *)(puVar3 + 0x3090)) {
LAB_005bb018:
      cVar7 = puVar1[uVar6];
      *(uint *)(puVar3 + 0x308c) = uVar6 + 1;
      iVar5 = (int)cVar7;
      if (((iVar5 < 0x30) || (0x39 < iVar5)) && ((iVar5 < 0x41 || (0x46 < iVar5))))
      goto LAB_005bb065;
    }
    else {
      *(undefined4 *)(puVar3 + 0x308c) = 0;
      iVar5 = (**(code **)(puVar3 + 0x3018))(puVar3,puVar1,0x10000);
      *(int *)(puVar3 + 0x15514) = iVar5;
      *(int *)(puVar3 + 0x3090) = iVar5;
      if (iVar5 != 0) {
        uVar6 = *(uint *)(puVar3 + 0x308c);
        goto LAB_005bb018;
      }
      iVar5 = -1;
LAB_005bb065:
      if (5 < iVar5 - 0x61U) break;
    }
  } while ((int)param_1 - (int)auStack_c < 7);
  if (iVar5 == -1) {
LAB_005baf38:
    *(undefined4 *)(puVar3 + 0x3094) = 0xffffffff;
    return 0xffffffff;
  }
  while (iVar5 != 10) {
    uVar6 = *(uint *)(puVar3 + 0x308c);
    if (*(uint *)(puVar3 + 0x3090) <= uVar6) {
      *(undefined4 *)(puVar3 + 0x308c) = 0;
      iVar5 = (**(code **)(puVar3 + 0x3018))(puVar3,puVar1,0x10000);
      *(int *)(puVar3 + 0x15514) = iVar5;
      *(int *)(puVar3 + 0x3090) = iVar5;
      if (iVar5 == 0) goto LAB_005baf38;
      uVar6 = *(uint *)(puVar3 + 0x308c);
    }
    iVar5 = (int)(char)puVar1[uVar6];
    *(uint *)(puVar3 + 0x308c) = uVar6 + 1;
    if (iVar5 == -1) {
      *(undefined4 *)(puVar3 + 0x3094) = 0xffffffff;
      return 0xffffffff;
    }
  }
  *param_1 = 0;
  uVar6 = FUN_0171d7dd(auStack_c,&param_1,0x10);
  *(uint *)(puVar3 + 0x15510) = uVar6;
  if (uVar6 == 0) {
    *(undefined4 *)(puVar3 + 0x15514) = 0;
    cVar7 = '\n';
    goto LAB_005bb1d0;
  }
  iVar5 = *(int *)(puVar3 + 0x308c);
  uVar2 = *(uint *)(puVar3 + 0x15514);
  uVar8 = iVar5 + uVar6;
  *(uint *)(puVar3 + 0x3090) = uVar8;
  if (uVar2 < uVar8) {
    *(uint *)(puVar3 + 0x3090) = uVar2;
    *(undefined4 *)(puVar3 + 0x15514) = 0;
    uVar6 = uVar6 + (iVar5 - uVar2);
    *(uint *)(puVar3 + 0x15510) = uVar6;
    uVar4 = 0;
    uVar8 = uVar2;
  }
  else {
    uVar4 = uVar2;
    if (uVar2 != 0) {
      *(undefined4 *)(puVar3 + 0x15510) = 0;
      uVar6 = 0;
    }
  }
  iVar5 = uVar8 - iVar5;
  if (iVar5 != 0) goto LAB_005bb265;
  if (uVar6 != 0) goto LAB_005bb17b;
  goto LAB_005baf00;
  while( true ) {
    uVar6 = *(uint *)(puVar3 + 0x308c);
    if (*(uint *)(puVar3 + 0x3090) <= uVar6) {
      *(undefined4 *)(puVar3 + 0x308c) = 0;
      iVar5 = (**(code **)(puVar3 + 0x3018))(puVar3,puVar3 + 0x30b4,0x10000);
      *(int *)(puVar3 + 0x15514) = iVar5;
      *(int *)(puVar3 + 0x3090) = iVar5;
      if (iVar5 == 0) break;
      uVar6 = *(uint *)(puVar3 + 0x308c);
    }
    cVar7 = (puVar3 + 0x30b4)[uVar6];
    *(uint *)(puVar3 + 0x308c) = uVar6 + 1;
    if (cVar7 == -1) break;
LAB_005bb1d0:
    if (cVar7 == '\n') break;
  }
  iVar5 = 0;
  *(undefined4 *)(puVar3 + 0x3094) = 0xffffffff;
LAB_005bb265:
  if (*(code **)(puVar3 + 0x303c) != (code *)0x0) {
    uVar6 = (**(code **)(puVar3 + 0x303c))(puVar3,puVar3 + 0x30b4,iVar5);
    *(uint *)(puVar3 + 0x1615c) = uVar6;
    if (uVar6 != 0) {
      return uVar6;
    }
  }
  *(int *)(puVar3 + 0x30a0) = *(int *)(puVar3 + 0x30a0) + iVar5;
  return (uint)(iVar5 == 0);
}



/* FUNCTION 5043 ; VA 0x005bb2a0 ; FUN_005bb2a0 */

int FUN_005bb2a0(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  char *pcVar3;
  
  iVar2 = param_2;
  if ((param_2 != 0) && ((*(uint *)(param_1 + 8) & 0x8000) == 0)) {
    iVar1 = FUN_005b9800(param_1,param_2,param_3,&param_2);
    if (iVar1 == 0) {
      iVar2 = FUN_005b9730(param_1,iVar2,0,0,param_3,&param_2);
      if (iVar2 == 0) {
        return 1;
      }
      pcVar3 = (char *)(param_2 + 0x14);
      *pcVar3 = '\0';
      *(undefined *)(param_2 + 0x15) = 0;
    }
    else {
      pcVar3 = (char *)(param_2 + 0x14);
      if (*(char *)(param_2 + 0x14) == '\0') {
        *pcVar3 = '\x02';
        *(undefined *)(param_2 + 0x15) = 2;
        return (int)*pcVar3;
      }
    }
    return (int)*pcVar3;
  }
  return 1;
}



/* FUNCTION 5044 ; VA 0x005bb320 ; FUN_005bb320 */

undefined4 FUN_005bb320(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  bool bVar7;
  bool bVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int *piVar11;
  char *pcVar12;
  int iVar13;
  int *piVar14;
  uint uVar15;
  int iStack_18;
  int iStack_10;
  
  iVar13 = 0;
  puVar9 = (undefined4 *)(param_1 + 0x68);
  do {
    for (puVar2 = (undefined4 *)*puVar9; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2
        ) {
      iVar3 = puVar2[6];
      if (iVar3 == 0) {
        if (*(char *)(puVar2 + 8) == '#') {
          pcVar12 = (char *)((int)puVar2 + 0x21);
          iVar13 = param_1 - (int)pcVar12;
          do {
            cVar1 = *pcVar12;
            pcVar12 = pcVar12 + 1;
            pcVar12[iVar13 + 0x13cb3] = cVar1;
          } while (cVar1 != '\0');
          *(undefined4 *)(param_1 + 0x1615c) = 0x19;
          return 0x19;
        }
      }
      else {
        piVar11 = (int *)puVar2[3];
        puVar2[3] = 0;
        while (piVar11 != (int *)0x0) {
          piVar14 = (int *)*piVar11;
          *piVar11 = iVar3;
          piVar11 = piVar14;
        }
      }
    }
    iVar13 = iVar13 + 1;
    puVar9 = puVar9 + 1;
  } while (iVar13 < 1999);
  do {
    bVar7 = false;
    puVar9 = (undefined4 *)(param_1 + 0x68);
    bVar8 = false;
    iStack_18 = 0;
    do {
      for (puVar2 = (undefined4 *)*puVar9; puVar2 != (undefined4 *)0x0;
          puVar2 = (undefined4 *)*puVar2) {
        puVar4 = (undefined4 *)puVar2[6];
        if (puVar4 != (undefined4 *)0x0) {
          puVar10 = (undefined4 *)(param_1 + 0x68);
          iStack_10 = 0;
          do {
            for (puVar5 = (undefined4 *)*puVar10; puVar5 != (undefined4 *)0x0;
                puVar5 = (undefined4 *)*puVar5) {
              for (puVar6 = (undefined4 *)puVar5[4]; bVar7 = bVar8, puVar6 != (undefined4 *)0x0;
                  puVar6 = (undefined4 *)*puVar6) {
                if ((puVar4 <= puVar6) && (puVar6 < (undefined4 *)(puVar2[2] + (int)puVar4)))
                goto LAB_005bb57a;
              }
              for (puVar6 = (undefined4 *)puVar5[5]; puVar6 != (undefined4 *)0x0;
                  puVar6 = (undefined4 *)*puVar6) {
                if ((puVar4 <= (undefined4 *)puVar6[2]) &&
                   ((undefined4 *)puVar6[2] < (undefined4 *)(puVar2[2] + (int)puVar4)))
                goto LAB_005bb57a;
              }
            }
            iStack_10 = iStack_10 + 1;
            puVar10 = puVar10 + 1;
          } while (iStack_10 < 1999);
          piVar11 = (int *)puVar2[4];
          if (piVar11 != (int *)0x0) {
            puVar2[4] = 0;
            do {
              piVar14 = (int *)*piVar11;
              FUN_0170c6f0(piVar11,puVar2[6],puVar2[2]);
              piVar11 = piVar14;
            } while (piVar14 != (int *)0x0);
            bVar8 = true;
          }
          puVar4 = (undefined4 *)puVar2[5];
          while (bVar7 = bVar8, puVar4 != (undefined4 *)0x0) {
            uVar15 = puVar4[3];
            piVar11 = (int *)puVar2[6];
            piVar14 = piVar11;
            if ((uint)puVar2[7] < uVar15) {
              do {
                if (param_1 == 0) {
                  piVar11 = (int *)FUN_0171e1f2(4);
                }
                else {
                  if (*(code **)(param_1 + 0x3030) == (code *)0x0) {
                    piVar11 = (int *)FUN_0171e1f2(0x10);
                    if (piVar11 == (int *)0x0) {
                      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
                      goto LAB_005bb5bf;
                    }
                    *(undefined2 *)((int)piVar11 + 6) = 0xc0de;
                    piVar11[2] = *(int *)(param_1 + 100);
                    piVar11[3] = 8;
                    *(int **)(param_1 + 100) = piVar11 + 2;
                  }
                  else {
                    piVar11 = (int *)(**(code **)(param_1 + 0x3030))(param_1,4);
                  }
                  *(undefined2 *)(param_1 + 0x1550a) = 1;
                }
                if (piVar11 == (int *)0x0) {
LAB_005bb5bf:
                  return *(undefined4 *)(param_1 + 0x1615c);
                }
                uVar15 = uVar15 - 1;
                *piVar11 = (int)piVar14;
                piVar14 = piVar11;
              } while ((uint)puVar2[7] < uVar15);
            }
            if ((code *)puVar4[5] == (code *)0x0) {
              FUN_0170c6f0(puVar4[2],piVar11,puVar2[2]);
            }
            else {
              (*(code *)puVar4[5])(param_1,puVar2[1],puVar4[1],puVar4[2],puVar4[4]);
            }
            puVar2[5] = *puVar4;
            FUN_017168b0(puVar4);
            bVar8 = true;
            puVar4 = (undefined4 *)puVar2[5];
          }
        }
LAB_005bb57a:
      }
      iStack_18 = iStack_18 + 1;
      puVar9 = puVar9 + 1;
    } while (iStack_18 < 1999);
    if (!bVar7) {
      return 0;
    }
  } while( true );
}



/* FUNCTION 5045 ; VA 0x005bb5d0 ; FUN_005bb5d0 */

void FUN_005bb5d0(int param_1,int param_2)

{
  byte bVar1;
  undefined4 *puVar2;
  byte *pbVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  byte *pbVar7;
  byte *pbVar8;
  byte *pbVar9;
  bool bVar10;
  undefined4 *puStack_8;
  
  if (*(int *)(param_2 + 0xc) != 0) {
    puStack_8 = (undefined4 *)(param_1 + 0x161b0);
    puVar2 = (undefined4 *)*puStack_8;
    while (puVar2 != (undefined4 *)0x0) {
      pbVar3 = *(byte **)(param_2 + 0xc);
      pbVar9 = (byte *)puVar2[3];
      pbVar8 = pbVar3;
      pbVar7 = pbVar9;
      if (pbVar9 == (byte *)0x0) {
LAB_005bb707:
        puStack_8 = (undefined4 *)*puStack_8;
      }
      else {
        do {
          bVar1 = *pbVar7;
          bVar10 = bVar1 < *pbVar8;
          if (bVar1 != *pbVar8) {
LAB_005bb635:
            uVar4 = -(uint)bVar10 | 1;
            goto LAB_005bb63a;
          }
          if (bVar1 == 0) break;
          bVar1 = pbVar7[1];
          bVar10 = bVar1 < pbVar8[1];
          if (bVar1 != pbVar8[1]) goto LAB_005bb635;
          pbVar8 = pbVar8 + 2;
          pbVar7 = pbVar7 + 2;
        } while (bVar1 != 0);
        uVar4 = 0;
LAB_005bb63a:
        if (uVar4 != 0) {
          iVar5 = FUN_01723e00(pbVar9,&DAT_018c3498,4);
          if (iVar5 == 0) {
            pbVar9 = pbVar9 + 4;
          }
          pbVar8 = pbVar3;
          do {
            bVar1 = *pbVar8;
            pbVar8 = pbVar8 + 1;
          } while (bVar1 != 0);
          iVar5 = ((int)pbVar8 - (int)(pbVar3 + 1)) + -2;
          if (*pbVar3 != 0x3c) {
            iVar5 = (int)pbVar8 - (int)(pbVar3 + 1);
          }
          pbVar8 = pbVar3 + 1;
          if (*pbVar3 != 0x3c) {
            pbVar8 = pbVar3;
          }
          iVar6 = FUN_01723e00(pbVar9,pbVar8,iVar5);
          if ((iVar6 != 0) || (pbVar9[iVar5] != 0)) {
            FUN_005b3420(param_1 + 0x134b4,0x400,pbVar9,&DAT_018c2414);
            iVar6 = FUN_01723e00(param_1 + 0x134b4,pbVar8,iVar5);
            if ((iVar6 != 0) || (*(char *)(param_1 + 0x134b4 + iVar5) != '\0')) goto LAB_005bb707;
          }
        }
        *puStack_8 = *puVar2;
        *(undefined4 *)puVar2[1] = *(undefined4 *)(param_2 + 4);
        *(undefined4 *)puVar2[2] = *(undefined4 *)(param_2 + 8);
        *(undefined4 *)puVar2[4] = *(undefined4 *)(param_2 + 0x10);
        iVar5 = *(int *)(param_2 + 0x14);
        if (iVar5 == 0) {
          iVar5 = *(int *)(param_2 + 0x20);
        }
        *(int *)puVar2[5] = iVar5;
        FUN_017168b0(puVar2);
      }
      puVar2 = (undefined4 *)*puStack_8;
    }
  }
  return;
}



/* FUNCTION 5046 ; VA 0x005bb730 ; FUN_005bb730 */

int FUN_005bb730(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  
  if (((*(uint *)(param_1 + 0x10) & 0x42) == 0) && ((param_2 == 0x3ea || (param_2 == 0x3eb)))) {
    *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffffe | 2;
  }
  *(int *)(param_1 + 0x16158) = param_2;
  uVar2 = FUN_005b3280(param_1);
  iVar3 = FUN_005b2450(param_1);
  if (iVar3 == 0) {
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 & 3;
    if ((uVar4 != 2) && ((uVar1 & 0x40) == 0)) {
      *(uint *)(param_1 + 8) = uVar1 & 0xfffffbfc;
      if (uVar4 != 0) {
        *(uint *)(param_1 + 8) = uVar1 & 0xfffffbfc | 1;
      }
      iVar3 = (**(code **)(param_1 + 0x2fe4))(param_1,param_2,uVar2);
      *(int *)(param_1 + 0x1615c) = iVar3;
      if (iVar3 != 0) {
        return iVar3;
      }
      if ((uVar4 == 3) && (iVar3 = FUN_005b5120(param_1), iVar3 != 0)) {
        return *(int *)(param_1 + 0x1615c);
      }
      *(uint *)(param_1 + 8) = uVar1;
    }
    return 0;
  }
  return *(int *)(param_1 + 0x1615c);
}



/* FUNCTION 5047 ; VA 0x005bb7f0 ; FUN_005bb7f0 */

void FUN_005bb7f0(int param_1)

{
  if ((*(short *)(param_1 + 0x1550c) == 0) &&
     (*(undefined2 *)(param_1 + 0x1550c) = 1, *(short *)(param_1 + 0x309a) != 0)) {
    *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + -1;
  }
  return;
}



/* FUNCTION 5048 ; VA 0x005bb820 ; FUN_005bb820 */

undefined4 FUN_005bb820(int param_1,char *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  char *pcVar3;
  char cVar4;
  char *pcVar5;
  char *pcVar6;
  int *piVar7;
  char *pcVar8;
  
  if (param_2 == (char *)0x0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  *(undefined4 *)(param_1 + 0x30b0) = 0;
  while (cVar4 = *param_2, cVar4 != '\0') {
    do {
      pcVar8 = param_2;
      if ((cVar4 < '\0') || (' ' < cVar4)) break;
      cVar4 = param_2[1];
      param_2 = param_2 + 1;
      pcVar8 = param_2;
    } while (cVar4 != '\0');
    if (cVar4 == '\0') break;
    pcVar6 = (char *)0x1;
    cVar4 = pcVar8[1];
    while ((cVar4 != '\0' && ((cVar4 < '\0' || (' ' < cVar4))))) {
      pcVar3 = pcVar6 + 1;
      pcVar6 = pcVar6 + 1;
      cVar4 = pcVar3[(int)pcVar8];
    }
    piVar7 = *(int **)(param_1 + 0x58);
    pcVar3 = pcVar6;
    param_2 = pcVar8;
    if ((piVar7 != (int *)0x0) && (iVar1 = FUN_01723e00(pcVar8,&DAT_018c382c,4), iVar1 != 0)) {
      iVar1 = FUN_0170dbd0(pcVar8,0x3a);
      if (iVar1 == 0) {
        do {
          if (*(char *)(piVar7 + 4) == '\0') break;
          piVar7 = (int *)*piVar7;
        } while (piVar7 != (int *)0x0);
      }
      else {
        do {
          iVar2 = FUN_01723e00(piVar7 + 4,pcVar8,iVar1 - (int)pcVar8);
          if ((iVar2 == 0) && (*(char *)((iVar1 - (int)pcVar8) + 0x10 + (int)piVar7) == '\0'))
          break;
          piVar7 = (int *)*piVar7;
        } while (piVar7 != (int *)0x0);
        param_2 = (char *)(iVar1 + 1);
      }
      if (piVar7 == (int *)0x0) {
        FUN_005b19f0(param_1,&DAT_018c3834,2);
      }
      else if ((*(short *)(piVar7 + 2) < 0) || (*(int *)(param_1 + 0x54) == 0)) {
        if (piVar7[3] == 0) {
          *(undefined4 *)(param_1 + 0x1615c) = 9;
          return 9;
        }
        FUN_005b19f0(param_1,&DAT_018c35d8,1);
        pcVar3 = (char *)piVar7[3];
        pcVar5 = pcVar3;
        do {
          cVar4 = *pcVar5;
          pcVar5 = pcVar5 + 1;
        } while (cVar4 != '\0');
        FUN_005b19f0(param_1,pcVar3,(int)pcVar5 - (int)(pcVar3 + 1));
        FUN_005b19f0(param_1,&DAT_018c35d8,1);
      }
      else {
        pcVar3 = *(char **)(*(int *)(param_1 + 0x54) + *(short *)(piVar7 + 2) * 0x10);
        if (pcVar3 != (char *)0x0) {
          pcVar5 = pcVar3;
          do {
            cVar4 = *pcVar5;
            pcVar5 = pcVar5 + 1;
          } while (cVar4 != '\0');
          FUN_005b19f0(param_1,pcVar3,(int)pcVar5 - (int)(pcVar3 + 1));
        }
      }
      FUN_005b19f0(param_1,&DAT_018c3838,1);
      pcVar3 = pcVar8 + ((int)pcVar6 - (int)param_2);
    }
    FUN_005b19f0(param_1,param_2,pcVar3);
    param_2 = pcVar8 + (int)pcVar6;
    if (*param_2 != '\0') {
      FUN_005b19f0(param_1,&DAT_018c0cc8,1);
    }
  }
  FUN_005b19f0(param_1,&DAT_018c2414,1);
  pcVar8 = *(char **)(param_1 + 0x30a8);
  iVar1 = 0;
  if (pcVar8 != (char *)0x0) {
    pcVar6 = pcVar8;
    do {
      cVar4 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar4 != '\0');
    iVar1 = FUN_005b7fc0(param_1,pcVar6 + (1 - (int)(pcVar8 + 1)));
    if (iVar1 != 0) {
      iVar2 = iVar1 - (int)pcVar8;
      do {
        cVar4 = *pcVar8;
        pcVar8 = pcVar8 + 1;
        pcVar8[iVar2 + -1] = cVar4;
      } while (cVar4 != '\0');
      *param_3 = iVar1;
      return *(undefined4 *)(param_1 + 0x1615c);
    }
  }
  *param_3 = iVar1;
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5049 ; VA 0x005bbaa0 ; FUN_005bbaa0 */

undefined * FUN_005bbaa0(int param_1,byte *param_2,undefined *param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined *puVar6;
  
  if ((param_3 == (undefined *)0x0) &&
     (param_3 = (undefined *)FUN_005b7fc0(param_1,((param_4 + 2) / 3) * 4 + 1),
     param_3 == (undefined *)0x0)) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    return (undefined *)0x0;
  }
  *param_3 = 0;
  if (param_2 == (byte *)0x0) {
    return param_3;
  }
  puVar6 = param_3;
  if (2 < param_4) {
    iVar5 = (param_4 - 3U) / 3 + 1;
    param_4 = param_4 + iVar5 * -3;
    do {
      iVar4 = 4;
      uVar2 = (uint)CONCAT21(CONCAT11(*param_2,param_2[1]),param_2[2]);
      do {
        iVar4 = iVar4 + -1;
        uVar3 = uVar2 & 0x3f;
        uVar2 = uVar2 >> 6;
        puVar6[iVar4] = (&DAT_018c23d0)[uVar3];
      } while (0 < iVar4);
      puVar6 = puVar6 + 4;
      param_2 = param_2 + 3;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
  }
  *puVar6 = 0;
  if (0 < param_4) {
    uVar2 = 0;
    iVar5 = param_4;
    do {
      bVar1 = *param_2;
      param_2 = param_2 + 1;
      uVar2 = uVar2 << 8 | (uint)bVar1;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
    iVar5 = param_4;
    if (param_4 < 3) {
      iVar4 = 3 - param_4;
      iVar5 = 3;
      do {
        uVar2 = uVar2 << 8;
        iVar4 = iVar4 + -1;
      } while (iVar4 != 0);
    }
    iVar5 = iVar5 + 1;
    while (0 < iVar5) {
      iVar5 = iVar5 + -1;
      uVar3 = uVar2 & 0x3f;
      uVar2 = uVar2 >> 6;
      puVar6[iVar5] = (&DAT_018c23d0)[uVar3];
    }
    iVar5 = 3;
    if (param_4 < 3) {
      do {
        puVar6[iVar5] = 0x3d;
        iVar5 = iVar5 + -1;
      } while (param_4 < iVar5);
    }
    puVar6[4] = 0;
  }
  return param_3;
}



/* FUNCTION 5050 ; VA 0x005bbbf0 ; FUN_005bbbf0 */

undefined4 FUN_005bbbf0(int param_1,char *param_2,undefined4 *param_3)

{
  char *pcVar1;
  undefined4 uVar2;
  int iVar3;
  
  pcVar1 = param_2;
  if (param_2 == (char *)0x0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  SetLastError(0);
  uVar2 = FUN_0171d785(pcVar1,&param_2,10);
  *param_3 = uVar2;
  if (((pcVar1 != param_2) || ((*(uint *)(param_1 + 8) & 0x1000) == 0)) && (*param_2 == '\0')) {
    iVar3 = GetLastError();
    if (iVar3 != 0x22) goto LAB_005bbc44;
  }
  *(undefined4 *)(param_1 + 0x1615c) = 4;
LAB_005bbc44:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 5051 ; VA 0x005bbc60 ; FUN_005bbc60 */

int FUN_005bbc60(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  int iStack_10;
  
  iVar6 = *(int *)(param_1 + 0x5c);
  if (*(int *)(iVar6 + 8) != 0) {
    if (param_2 == 0) {
      param_2 = FUN_005b7fc0(param_1,*(int *)(iVar6 + 8));
      iVar6 = *(int *)(param_1 + 0x5c);
      if (param_2 == 0) {
        *(undefined4 *)(param_1 + 0x1615c) = 0x14;
        goto LAB_005bbe35;
      }
    }
    if (*(int **)(iVar6 + 4) != (int *)0x0) {
      piVar10 = *(int **)(iVar6 + 4);
      piVar7 = (int *)0x0;
      do {
        piVar8 = piVar10;
        piVar10 = (int *)*piVar8;
        *piVar8 = (int)piVar7;
        piVar7 = piVar8;
      } while (piVar10 != (int *)0x0);
      *(int **)(*(int *)(param_1 + 0x5c) + 4) = piVar8;
      piVar8 = piVar8 + 2;
      if (piVar8 != (int *)0x0) {
        iVar6 = *(int *)(param_1 + 0x5c);
        iVar9 = param_2;
        do {
          iVar1 = *(int *)(*(int *)(iVar6 + 4) + 4);
          if (param_3 != 0) {
            puVar5 = (undefined4 *)(param_1 + 0x68);
            piVar10 = (int *)(iVar1 + (int)piVar8);
            iStack_10 = 1999;
            do {
              for (puVar2 = (undefined4 *)*puVar5; puVar2 != (undefined4 *)0x0;
                  puVar2 = (undefined4 *)*puVar2) {
                piVar7 = (int *)puVar2[6];
                if (((piVar7 != (int *)0x0) && (piVar8 <= piVar7)) && (piVar7 < piVar10)) {
                  puVar2[6] = (int)piVar7 + (iVar9 - (int)piVar8);
                }
                piVar7 = puVar2 + 3;
                while (piVar4 = piVar7, piVar4 != (int *)0x0) {
                  piVar7 = (int *)*piVar4;
                  if (((piVar7 != (int *)0x0) && (piVar8 <= piVar7)) && (piVar7 < piVar10)) {
                    *piVar4 = (int)piVar7 + (iVar9 - (int)piVar8);
                  }
                }
                piVar7 = puVar2 + 4;
                while (piVar4 = piVar7, piVar4 != (int *)0x0) {
                  piVar7 = (int *)*piVar4;
                  if (((piVar7 != (int *)0x0) && (piVar8 <= piVar7)) && (piVar7 < piVar10)) {
                    *piVar4 = (int)piVar7 + (iVar9 - (int)piVar8);
                  }
                }
                for (puVar3 = (undefined4 *)puVar2[5]; puVar3 != (undefined4 *)0x0;
                    puVar3 = (undefined4 *)*puVar3) {
                  piVar7 = (int *)puVar3[2];
                  if ((piVar8 <= piVar7) && (piVar7 < piVar10)) {
                    puVar3[2] = (int)piVar7 + (iVar9 - (int)piVar8);
                  }
                }
              }
              puVar5 = puVar5 + 1;
              iStack_10 = iStack_10 + -1;
            } while (iStack_10 != 0);
            for (puVar5 = *(undefined4 **)(param_1 + 0x161b0); puVar5 != (undefined4 *)0x0;
                puVar5 = (undefined4 *)*puVar5) {
              piVar7 = (int *)puVar5[1];
              if (((piVar7 != (int *)0x0) && (piVar8 <= piVar7)) && (piVar7 < piVar10)) {
                puVar5[1] = (int)piVar7 + (iVar9 - (int)piVar8);
                puVar5[2] = puVar5[2] + (iVar9 - (int)piVar8);
                puVar5[4] = puVar5[4] + (iVar9 - (int)piVar8);
                puVar5[5] = puVar5[5] + (iVar9 - (int)piVar8);
              }
            }
          }
          FUN_0170c6f0(iVar9,piVar8,iVar1);
          iVar6 = *(int *)(param_1 + 0x5c);
          iVar9 = iVar9 + iVar1;
          puVar5 = *(undefined4 **)(iVar6 + 4);
          if (puVar5 == (undefined4 *)0x0) {
LAB_005bbe28:
            piVar8 = (int *)0x0;
          }
          else {
            *(undefined4 *)(iVar6 + 4) = *puVar5;
            FUN_017168b0(puVar5);
            iVar6 = *(int *)(param_1 + 0x5c);
            if (*(int *)(iVar6 + 4) == 0) goto LAB_005bbe28;
            piVar8 = (int *)(*(int *)(iVar6 + 4) + 8);
          }
        } while (piVar8 != (int *)0x0);
      }
    }
  }
LAB_005bbe35:
  puVar5 = *(undefined4 **)(param_1 + 0x5c);
  if (puVar5 != (undefined4 *)0x0) {
    puVar2 = (undefined4 *)puVar5[1];
    while (puVar2 != (undefined4 *)0x0) {
      puVar3 = (undefined4 *)*puVar2;
      FUN_017168b0(puVar2);
      puVar2 = puVar3;
    }
    *(undefined4 *)(param_1 + 0x5c) = *puVar5;
    FUN_017168b0(puVar5);
  }
  return param_2;
}



/* FUNCTION 5052 ; VA 0x005bbe70 ; FUN_005bbe70 */

void FUN_005bbe70(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  char *pcVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  
  do {
    pcVar5 = *(char **)(param_1 + 0x1619c);
    if (pcVar5 != (char *)0x0) {
      if (*(int *)(param_1 + 0x306c) == 0) {
        pcVar7 = pcVar5 + 1;
        do {
          cVar1 = *pcVar5;
          pcVar5 = pcVar5 + 1;
        } while (cVar1 != '\0');
        uVar6 = (int)pcVar5 - (int)pcVar7;
        for (puVar2 = *(undefined4 **)(param_1 + 0x161a8); puVar2 != (undefined4 *)0x0;
            puVar2 = (undefined4 *)*puVar2) {
          iVar8 = puVar2[1];
          if (((iVar8 != 0) && (uVar6 <= (uint)puVar2[2])) && (uVar4 = 0, puVar2[2] != uVar6)) {
            do {
              iVar3 = FUN_01723e00(iVar8,*(undefined4 *)(param_1 + 0x1619c),uVar6);
              if (iVar3 == 0) goto LAB_005bbf1b;
              uVar4 = uVar4 + 1;
              iVar8 = iVar8 + 1;
            } while (uVar4 < puVar2[2] - uVar6);
          }
        }
      }
      if (*(int *)(param_1 + 0x161a0) == 0) {
        *(char **)(param_1 + 0x161a0) = "<SOAP-ENV:Envelope>";
      }
      return;
    }
LAB_005bbf1b:
    pcVar5 = *(char **)(param_1 + 0x1619c);
    if (pcVar5 == (char *)0x0) {
LAB_005bbf3e:
      uVar6 = 0x40;
      pcVar5 = (char *)FUN_005b7fc0(param_1,0x41);
      *(char **)(param_1 + 0x1619c) = pcVar5;
      if (pcVar5 == (char *)0x0) {
        return;
      }
    }
    else {
      pcVar7 = pcVar5;
      do {
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      uVar6 = (int)pcVar7 - (int)(pcVar5 + 1);
      if (uVar6 < 0x10) goto LAB_005bbf3e;
    }
    *(undefined2 *)pcVar5 = DAT_018c393c;
    pcVar5[2] = DAT_018c393e;
    pcVar5 = pcVar5 + 2;
    for (iVar8 = uVar6 - 4; iVar8 != 0; iVar8 = iVar8 + -1) {
      uVar6 = FUN_0171d737();
      *pcVar5 = (&DAT_018c23d0)[uVar6 & 0x3f];
      pcVar5 = pcVar5 + 1;
    }
    *(undefined2 *)pcVar5 = DAT_018c393c;
    pcVar5[2] = DAT_018c393e;
  } while( true );
}



/* FUNCTION 5053 ; VA 0x005bbfb0 ; FUN_005bbfb0 */

undefined4 FUN_005bbfb0(undefined4 param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  
  if (param_2 != (char *)0x0) {
    pcVar2 = param_2;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    uVar3 = FUN_005bc2c0(param_1,param_2,(int)pcVar2 - (int)(param_2 + 1));
    return uVar3;
  }
  return 0;
}



/* FUNCTION 5054 ; VA 0x005bbfe0 ; FUN_005bbfe0 */

undefined4 FUN_005bbfe0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined4 uStack_214;
  int iStack_210;
  undefined4 uStack_110;
  int iStack_10c;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar5 = 1;
  iVar1 = *(int *)(param_1 + 0x1615c);
  if (iVar1 == 1000) {
    return 1000;
  }
  *(undefined2 *)(param_1 + 0x1612c) = 0;
  FUN_005bc8a0(param_1);
  iVar2 = *(int *)(param_1 + 0x3078);
  if (iVar2 != -1) {
    uStack_c = 0;
    uStack_8 = 0;
    uStack_214 = 1;
    uStack_110 = 1;
    iStack_210 = iVar2;
    iStack_10c = iVar2;
    iVar5 = Ordinal_18(iVar2 + 1,&uStack_214,&uStack_110,0,&uStack_c);
    if (0 < iVar5) {
      iVar2 = Ordinal_151(*(undefined4 *)(param_1 + 0x3078),&uStack_110);
      if (iVar2 == 0) {
LAB_005bc0b9:
        iVar5 = 0;
      }
      else {
        iVar2 = Ordinal_151(*(undefined4 *)(param_1 + 0x3078),&uStack_214);
        if (iVar2 != 0) {
          iVar2 = Ordinal_16(*(undefined4 *)(param_1 + 0x3078),param_1 + 0x134b4,1,2);
          if (iVar2 < 0) goto LAB_005bc0b9;
        }
      }
    }
  }
  if (((iVar1 != -1) || ((*(int *)(param_1 + 0x30) == 0 && (*(int *)(param_1 + 0x34) == 0)))) &&
     (0 < iVar5)) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    _guard_check_icall(param_1);
    FUN_005af020(param_1);
    if (((*(byte *)(param_1 + 8) & 0x80) == 0) &&
       (uVar4 = *(uint *)(param_1 + 0x10), -1 < (char)uVar4)) {
      *(uint *)(param_1 + 8) = uVar4;
      if (((uVar4 & 3) == 2) ||
         (((uVar4 & 0x40) != 0 || (uVar4 & 3) == 3 && (*(int *)(param_1 + 0x3038) == 0)))) {
        uVar4 = uVar4 & 0xfffffff7;
      }
      else {
        uVar4 = uVar4 | 8;
      }
    }
    else {
      uVar4 = *(uint *)(param_1 + 0x10) | 0x88;
    }
    if ((*(int *)(param_1 + 0x28) == 0) && ((uVar4 & 0x10000) == 0)) {
      uVar4 = uVar4 | 0x8000;
    }
    uVar6 = uVar4 | 0x100;
    if ((uVar4 & 0x280) != 0x280) {
      uVar6 = uVar4 & 0xfffffdff;
    }
    *(uint *)(param_1 + 8) = uVar6;
    if ((uVar6 & 0x100) != 0) {
      FUN_005bbe70(param_1);
    }
    *(undefined4 *)(param_1 + 0x16190) = *(undefined4 *)(param_1 + 0x16198);
    *(undefined4 *)(param_1 + 0x30a0) = 0;
    *(undefined4 *)(param_1 + 0x15504) = 0;
    *(undefined2 *)(param_1 + 0x154b6) = 0;
    *(undefined4 *)(param_1 + 0x15500) = 0;
    *(undefined2 *)(param_1 + 0x15508) = 0;
    *(undefined4 *)(param_1 + 0x2fb4) = 0;
    FUN_005b2e60(param_1);
    FUN_005bcec0(param_1);
    *(undefined4 *)(param_1 + 0x1616c) = 0;
    *(undefined4 *)(param_1 + 0x16170) = 0;
    if ((*(code **)(param_1 + 0x3034) != (code *)0x0) &&
       (((byte)*(undefined4 *)(param_1 + 8) & 3) != 2)) {
      uVar3 = (**(code **)(param_1 + 0x3034))(param_1);
      *(undefined4 *)(param_1 + 0x1615c) = uVar3;
    }
    if ((*(byte *)(param_1 + 8) & 8) != 0) {
      FUN_005b4e30(param_1);
      FUN_005aefa0(param_1);
      FUN_005b2a20(param_1);
      FUN_005aef40(param_1);
      FUN_005b2ad0(param_1);
      FUN_005b4fa0(param_1);
    }
    if (*(code **)(param_1 + 0x3040) != (code *)0x0) {
      uVar3 = (**(code **)(param_1 + 0x3040))(param_1);
      *(undefined4 *)(param_1 + 0x1615c) = uVar3;
    }
    iVar5 = FUN_005bb730(param_1,iVar1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    iVar5 = FUN_005b4e30(param_1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    iVar5 = FUN_005aefa0(param_1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    iVar5 = FUN_005b2a20(param_1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    iVar5 = FUN_005aef40(param_1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    iVar5 = FUN_005b2ad0(param_1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    iVar5 = FUN_005b4fa0(param_1);
    if (iVar5 != 0) goto LAB_005bc2ab;
    FUN_005b4900(param_1);
  }
  *(int *)(param_1 + 0x1615c) = iVar1;
LAB_005bc2ab:
  uVar3 = FUN_005b2e00(param_1);
  return uVar3;
}



/* FUNCTION 5055 ; VA 0x005bc2c0 ; FUN_005bc2c0 */

undefined4 FUN_005bc2c0(int param_1,int param_2,uint param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = param_3;
  if (param_3 != 0) {
    uVar3 = *(uint *)(param_1 + 8);
    if ((uVar3 & 8) == 0) {
      if ((uVar3 & 3) == 0) {
        uVar1 = FUN_005b5160(param_1,param_2,param_3);
        return uVar1;
      }
      iVar2 = *(int *)(param_1 + 0x308c);
      uVar3 = 0x10000 - iVar2;
      if (uVar3 <= param_3) {
        param_3 = param_2;
        do {
          FUN_0170c6f0(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1,param_3,uVar3);
          *(undefined4 *)(param_1 + 0x308c) = 0;
          iVar2 = FUN_005b5160(param_1,param_1 + 0x30b4,0x10000);
          if (iVar2 != 0) {
            return *(undefined4 *)(param_1 + 0x1615c);
          }
          uVar4 = uVar4 - uVar3;
          param_2 = param_3 + uVar3;
          uVar3 = 0x10000;
          param_3 = param_2;
        } while (0xffff < uVar4);
        iVar2 = *(int *)(param_1 + 0x308c);
      }
      FUN_0170c6f0(param_1 + 0x30b4 + iVar2,param_2,uVar4);
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + uVar4;
      return 0;
    }
    *(int *)(param_1 + 0x30a0) = *(int *)(param_1 + 0x30a0) + param_3;
    if ((*(code **)(param_1 + 0x3038) != (code *)0x0) && (((byte)uVar3 & 3) != 2)) {
      uVar1 = (**(code **)(param_1 + 0x3038))(param_1,param_2,param_3);
      *(undefined4 *)(param_1 + 0x1615c) = uVar1;
      return uVar1;
    }
  }
  return 0;
}



/* FUNCTION 5056 ; VA 0x005bc3d0 ; FUN_005bc3d0 */

void FUN_005bc3d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char *pcVar1;
  
  pcVar1 = "SOAP-ENV:Sender";
  if (*(short *)(param_1 + 6) != 2) {
    pcVar1 = "SOAP-ENV:Client";
  }
  FUN_005b31e0(param_1,pcVar1,0,param_2,param_3);
  return;
}



/* FUNCTION 5057 ; VA 0x005bc400 ; FUN_005bc400 */

void FUN_005bc400(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  
  pcVar1 = "SOAP-ENV:Sender";
  if (*(short *)(param_1 + 6) != 2) {
    pcVar1 = "SOAP-ENV:Client";
  }
  FUN_005b31e0(param_1,pcVar1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 5058 ; VA 0x005bc430 ; FUN_005bc430 */

undefined4 FUN_005bc430(int param_1,byte *param_2,char *param_3)

{
  byte bVar1;
  char cVar2;
  int *piVar3;
  byte *pbVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  byte *pbVar10;
  char *pcVar11;
  int *piVar12;
  bool bVar13;
  
  if (*param_2 == 0x2d) {
    return 0;
  }
  piVar12 = (int *)(param_1 + 0x154fc);
  for (piVar6 = (int *)*piVar12; piVar6 != (int *)0x0; piVar6 = (int *)*piVar6) {
    pbVar4 = (byte *)((int)piVar6 + 0x12);
    pbVar10 = param_2;
    do {
      bVar1 = *pbVar4;
      bVar13 = bVar1 < *pbVar10;
      if (bVar1 != *pbVar10) {
LAB_005bc480:
        uVar5 = -(uint)bVar13 | 1;
        goto LAB_005bc485;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar4[1];
      bVar13 = bVar1 < pbVar10[1];
      if (bVar1 != pbVar10[1]) goto LAB_005bc480;
      pbVar4 = pbVar4 + 2;
      pbVar10 = pbVar10 + 2;
    } while (bVar1 != 0);
    uVar5 = 0;
LAB_005bc485:
    if (uVar5 == 0) {
      if (piVar6 != (int *)0x0) {
        if (*(short *)(piVar6 + 4) != 0) {
          return 0;
        }
        if (param_3 == (char *)0x0) goto LAB_005bc849;
        if (piVar6[1] != 0) {
          pcVar11 = param_3;
          do {
            cVar2 = *pcVar11;
            pcVar11 = pcVar11 + 1;
          } while (cVar2 != '\0');
          if ((uint)piVar6[2] <= (uint)((int)pcVar11 - (int)(param_3 + 1))) {
            FUN_017168b0(piVar6[1]);
            piVar6[1] = 0;
            piVar6[3] = 0;
          }
        }
        goto LAB_005bc5a0;
      }
      break;
    }
  }
  pbVar4 = param_2;
  do {
    bVar1 = *pbVar4;
    pbVar4 = pbVar4 + 1;
  } while (bVar1 != 0);
  piVar6 = (int *)FUN_0171e1f2(pbVar4 + (0x14 - (int)(param_2 + 1)));
  if (piVar6 == (int *)0x0) goto LAB_005bc85b;
  piVar6[3] = 0;
  if ((*(uint *)(param_1 + 8) & 0x4000) == 0) {
    *piVar6 = *piVar12;
  }
  else {
    iVar7 = FUN_0170dbd0(param_2,0x3a);
    iVar8 = FUN_01723e00(param_2,"xmlns",5);
    iVar9 = *piVar12;
    if (iVar8 == 0) {
      if (iVar9 != 0) {
        while (iVar9 = FUN_01723e00(iVar9 + 0x12,"xmlns",5), iVar9 == 0) {
          piVar3 = (int *)*piVar12;
          pbVar4 = param_2 + 5;
          pbVar10 = (byte *)((int)piVar3 + 0x17);
          do {
            bVar1 = *pbVar10;
            bVar13 = bVar1 < *pbVar4;
            if (bVar1 != *pbVar4) {
LAB_005bc640:
              uVar5 = -(uint)bVar13 | 1;
              goto LAB_005bc645;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar10[1];
            bVar13 = bVar1 < pbVar4[1];
            if (bVar1 != pbVar4[1]) goto LAB_005bc640;
            pbVar10 = pbVar10 + 2;
            pbVar4 = pbVar4 + 2;
          } while (bVar1 != 0);
          uVar5 = 0;
LAB_005bc645:
          if ((0 < (int)uVar5) || (iVar9 = *piVar3, piVar12 = piVar3, iVar9 == 0)) break;
        }
      }
      *piVar6 = *piVar12;
    }
    else {
      if (iVar7 == 0) {
        if (iVar9 != 0) {
          do {
            iVar9 = FUN_01723e00(iVar9 + 0x12,"xmlns",5);
            if (iVar9 != 0) {
              iVar9 = *piVar12;
              if (*(int *)(iVar9 + 0xc) != 0) break;
              pbVar4 = (byte *)(iVar9 + 0x12);
              pbVar10 = param_2;
              do {
                bVar1 = *pbVar4;
                bVar13 = bVar1 < *pbVar10;
                if (bVar1 != *pbVar10) {
LAB_005bc6c4:
                  uVar5 = -(uint)bVar13 | 1;
                  goto LAB_005bc6c9;
                }
                if (bVar1 == 0) break;
                bVar1 = pbVar4[1];
                bVar13 = bVar1 < pbVar10[1];
                if (bVar1 != pbVar10[1]) goto LAB_005bc6c4;
                pbVar4 = pbVar4 + 2;
                pbVar10 = pbVar10 + 2;
              } while (bVar1 != 0);
              uVar5 = 0;
LAB_005bc6c9:
              if (0 < (int)uVar5) break;
            }
            piVar12 = (int *)*piVar12;
            iVar9 = *piVar12;
          } while (iVar9 != 0);
          *piVar6 = iVar9;
          goto LAB_005bc7e4;
        }
      }
      else {
        while (iVar9 != 0) {
          iVar9 = FUN_01723e00(iVar9 + 0x12,"xmlns:",6);
          if (((iVar9 == 0) &&
              (iVar9 = FUN_01723e00(*piVar12 + 0x18,param_2,iVar7 - (int)param_2), iVar9 == 0)) &&
             (*(char *)((*piVar12 - (int)param_2) + 0x18 + iVar7) == '\0')) {
            if (piVar6[3] == 0) {
              piVar6[3] = *(int *)(*piVar12 + 0xc);
            }
          }
          else {
            iVar9 = FUN_01723e00(*piVar12 + 0x12,"xmlns",5);
            if (iVar9 != 0) {
              iVar9 = *piVar12;
              pbVar4 = *(byte **)(iVar9 + 0xc);
              if ((pbVar4 != (byte *)0x0) && (pbVar10 = (byte *)piVar6[3], pbVar10 != (byte *)0x0))
              {
                do {
                  bVar1 = *pbVar4;
                  bVar13 = bVar1 < *pbVar10;
                  if (bVar1 != *pbVar10) {
LAB_005bc791:
                    uVar5 = -(uint)bVar13 | 1;
                    goto LAB_005bc796;
                  }
                  if (bVar1 == 0) break;
                  bVar1 = pbVar4[1];
                  bVar13 = bVar1 < pbVar10[1];
                  if (bVar1 != pbVar10[1]) goto LAB_005bc791;
                  pbVar4 = pbVar4 + 2;
                  pbVar10 = pbVar10 + 2;
                } while (bVar1 != 0);
                uVar5 = 0;
LAB_005bc796:
                if (0 < (int)uVar5) break;
                if (uVar5 == 0) {
                  pbVar4 = (byte *)(iVar9 + 0x12);
                  pbVar10 = param_2;
                  do {
                    bVar1 = *pbVar4;
                    bVar13 = bVar1 < *pbVar10;
                    if (bVar1 != *pbVar10) {
LAB_005bc7c2:
                      uVar5 = -(uint)bVar13 | 1;
                      goto LAB_005bc7c7;
                    }
                    if (bVar1 == 0) break;
                    bVar1 = pbVar4[1];
                    bVar13 = bVar1 < pbVar10[1];
                    if (bVar1 != pbVar10[1]) goto LAB_005bc7c2;
                    pbVar4 = pbVar4 + 2;
                    pbVar10 = pbVar10 + 2;
                  } while (bVar1 != 0);
                  uVar5 = 0;
LAB_005bc7c7:
                  if (0 < (int)uVar5) break;
                }
              }
            }
          }
          piVar12 = (int *)*piVar12;
          iVar9 = *piVar12;
        }
      }
      *piVar6 = iVar9;
    }
  }
LAB_005bc7e4:
  *piVar12 = (int)piVar6;
  pbVar4 = param_2;
  do {
    bVar1 = *pbVar4;
    pbVar4 = pbVar4 + 1;
    pbVar4[(int)piVar6 + (0x11 - (int)param_2)] = bVar1;
  } while (bVar1 != 0);
  piVar6[1] = 0;
LAB_005bc5a0:
  if (param_3 == (char *)0x0) {
LAB_005bc849:
    *(undefined2 *)(piVar6 + 4) = 1;
    return 0;
  }
  iVar9 = piVar6[1];
  if (iVar9 == 0) {
    pcVar11 = param_3;
    do {
      cVar2 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar2 != '\0');
    piVar6[2] = (int)(pcVar11 + (1 - (int)(param_3 + 1)));
    iVar9 = FUN_0171e1f2(pcVar11 + (1 - (int)(param_3 + 1)));
    piVar6[1] = iVar9;
    if (iVar9 == 0) {
LAB_005bc85b:
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0x14;
    }
  }
  pcVar11 = param_3;
  do {
    cVar2 = *pcVar11;
    pcVar11[iVar9 - (int)param_3] = cVar2;
    pcVar11 = pcVar11 + 1;
  } while (cVar2 != '\0');
  iVar9 = FUN_01723e00((int)piVar6 + 0x12,"xmlns:",6);
  if (iVar9 == 0) {
    piVar6[3] = piVar6[1];
  }
  *(undefined2 *)(piVar6 + 4) = 2;
  pbVar4 = &DAT_018c363c;
  do {
    bVar1 = *param_2;
    bVar13 = bVar1 < *pbVar4;
    if (bVar1 != *pbVar4) {
LAB_005bc80c:
      uVar5 = -(uint)bVar13 | 1;
      goto LAB_005bc811;
    }
    if (bVar1 == 0) break;
    bVar1 = param_2[1];
    bVar13 = bVar1 < pbVar4[1];
    if (bVar1 != pbVar4[1]) goto LAB_005bc80c;
    param_2 = param_2 + 2;
    pbVar4 = pbVar4 + 2;
  } while (bVar1 != 0);
  uVar5 = 0;
LAB_005bc811:
  if (uVar5 == 0) {
    *(undefined2 *)(param_1 + 0x15508) = 10;
    FUN_0171dd10(param_1 + 0x13cb4,param_3,0x400);
    *(undefined *)(param_1 + 0x140b3) = 0;
  }
  return 0;
}



/* FUNCTION 5059 ; VA 0x005bc880 ; FUN_005bc880 */

void FUN_005bc880(int param_1,int param_2)

{
  if (param_2 != 0) {
    if ((*(byte *)(param_1 + 8) & 8) != 0) {
      *(undefined *)(param_2 + 0x14) = 1;
      return;
    }
    *(undefined *)(param_2 + 0x15) = 1;
  }
  return;
}



/* FUNCTION 5060 ; VA 0x005bc8a0 ; FUN_005bc8a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005bc8a0(int param_1)

{
  char *pcVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  char *pcVar8;
  undefined4 *puVar9;
  int iVar10;
  char *pcVar11;
  undefined8 uVar12;
  
  piVar6 = (int *)FUN_005acd30(param_1);
  piVar7 = (int *)FUN_005ace30(param_1);
  if (*(code **)(param_1 + 0x3020) != (code *)0x0) {
    (**(code **)(param_1 + 0x3020))(param_1,piVar6,piVar7);
  }
  if (*piVar6 == 0) {
    pcVar8 = "SOAP-ENV:Sender";
    if (*(short *)(param_1 + 6) != 2) {
      pcVar8 = "SOAP-ENV:Client";
    }
    *piVar6 = (int)pcVar8;
  }
  if (*piVar7 != 0) {
    return;
  }
  iVar10 = *(int *)(param_1 + 0x1615c);
  if (1000 < iVar10) {
switchD_005bc913_caseD_0:
    if ((200 < iVar10) && (iVar10 < 600)) {
      uVar12 = FUN_005aff20(param_1,iVar10);
      FUN_005bde90(param_1 + 0x130b4,"HTTP Error: %d %s",(int)((ulonglong)uVar12 >> 0x20),
                   (int)uVar12);
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "Error %d";
    goto LAB_005bcde8;
  }
  if (iVar10 == 1000) {
    *piVar7 = (int)"Stopped: no response sent";
    return;
  }
  switch(iVar10) {
  default:
    goto switchD_005bc913_caseD_0;
  case 1:
    *piVar7 = (int)"Client fault";
    return;
  case 2:
    *piVar7 = (int)"Server fault";
    return;
  case 3:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "tag name or namespace mismatch",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "tag name or namespace mismatch";
    break;
  case 4:
    iVar10 = FUN_005bd020(param_1,"data type mismatch ",param_1 + 0x144b4);
    *piVar7 = iVar10;
    return;
  case 5:
    *piVar7 = (int)"Well-formedness violation";
    return;
  case 6:
    *piVar7 = (int)"No XML element tag";
    return;
  case 7:
    *piVar7 = (int)"Array index out of bounds";
    return;
  case 8:
    iVar10 = param_1 + 0x138b4;
    *piVar6 = (int)"SOAP-ENV:MustUnderstand";
    pcVar8 = "The data in element \'%s\' must be understood but cannot be handled";
    goto LAB_005bcde8;
  case 9:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "namespace error",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "namespace error";
    break;
  case 10:
    *piVar7 = (int)"User error";
    return;
  case 0xb:
    *piVar7 = (int)"Fatal error";
    return;
  case 0xc:
    return;
  case 0xd:
    iVar10 = param_1 + 0x138b4;
    pcVar8 = "Method \'%s\' not implemented: method name or namespace not recognized";
LAB_005bcde8:
    FUN_005bde90(param_1 + 0x130b4,pcVar8,iVar10);
    *piVar7 = param_1 + 0x130b4;
    return;
  case 0xe:
    *piVar7 = (int)"Data required for operation";
    return;
  case 0xf:
    *piVar7 = (int)"HTTP GET method not implemented";
    return;
  case 0x10:
    *piVar7 = (int)"HTTP PUT method not implemented";
    return;
  case 0x12:
    *piVar7 = (int)"HTTP HEAD method not implemented";
    return;
  case 0x13:
    *piVar7 = (int)"HTTP method not implemented";
    return;
  case 0x14:
    *piVar7 = (int)"Out of memory";
    return;
  case 0x15:
    *piVar7 = (int)"Memory overflow or memory corruption error";
    return;
  case 0x16:
    *piVar7 = (int)"Header line too long";
    return;
  case 0x17:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "nil not allowed",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "nil not allowed";
    break;
  case 0x18:
    iVar10 = FUN_005bd020(param_1,"multiple definitions of id ",param_1 + 0x13cb4);
    *piVar7 = iVar10;
    if (*(short *)(param_1 + 6) == 2) {
      puVar9 = (undefined4 *)FUN_005ace60(param_1);
      *puVar9 = "SOAP-ENC:DuplicateID";
      return;
    }
    return;
  case 0x19:
    iVar10 = FUN_005bd020(param_1,"missing id for ref ",param_1 + 0x13cb4);
    *piVar7 = iVar10;
    if (*(short *)(param_1 + 6) != 2) {
      return;
    }
    puVar9 = (undefined4 *)FUN_005ace60(param_1);
    *puVar9 = "SOAP-ENC:MissingID";
    return;
  case 0x1a:
    iVar10 = FUN_005bd020(param_1,"incompatible object type ref/id pair ",param_1 + 0x13cb4);
    *piVar7 = iVar10;
    return;
  case 0x1b:
    *piVar7 = (int)"Message too large for UDP packet";
    return;
  case 0x1c:
    iVar10 = FUN_005be760(param_1);
    *piVar7 = iVar10;
    return;
  case 0x1d:
    *piVar7 = (int)"An HTTP processing error occurred";
    return;
  case 0x1e:
    *piVar7 = (int)"OpenSSL not installed: recompile with -DWITH_OPENSSL";
    return;
  case 0x1f:
    *piVar7 = (int)"Zlib/gzip not installed for (de)compression: recompile with -DWITH_GZIP";
    return;
  case 0x20:
    *piVar7 = (int)"DIME format error";
    return;
  case 0x21:
    *piVar7 = (int)"DIME href to missing attachment";
    return;
  case 0x22:
    *piVar7 = (int)"DIME version/transmission error";
    return;
  case 0x23:
    *piVar7 = (int)"End of DIME error";
    return;
  case 0x24:
    *piVar7 = (int)"MIME format error";
    return;
  case 0x25:
    *piVar7 = (int)"MIME href to missing attachment";
    return;
  case 0x26:
    *piVar7 = (int)"End of MIME error";
    return;
  case 0x27:
    *piVar6 = (int)"SOAP-ENV:VersionMismatch";
    *piVar7 = (int)"Invalid SOAP message or SOAP version mismatch";
    return;
  case 0x28:
    *piVar7 = (int)"Plugin registry error";
    return;
  case 0x29:
    *piVar6 = (int)"SOAP-ENV:DataEncodingUnknown";
    *piVar7 = (int)"Unsupported SOAP data encoding";
    return;
  case 0x2a:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "missing required attribute",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "missing required attribute";
    break;
  case 0x2b:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "prohibited attribute present",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "prohibited attribute present";
    break;
  case 0x2c:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "occurrence violation",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "occurrence violation";
    break;
  case 0x2d:
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s in element <%s>",
                   "content length violation",&DAT_018c2414,(char *)(param_1 + 0x138b4));
      *piVar7 = param_1 + 0x130b4;
      return;
    }
    pcVar8 = "content length violation";
    break;
  case 0x2e:
    *piVar7 = (int)"Maximum number of open connections was reached";
    return;
  case -1:
    pcVar11 = (char *)FUN_005bd390(param_1);
    pcVar1 = (char *)(param_1 + 0x130b4);
    pcVar8 = pcVar11;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
      pcVar8[(int)(pcVar1 + (-1 - (int)pcVar11))] = cVar2;
    } while (cVar2 != '\0');
    pcVar8 = pcVar1;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    if (pcVar8 + (0x19 - (param_1 + 0x130b5)) < (char *)0x400) {
      pcVar8 = pcVar1;
      do {
        cVar2 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar2 != '\0');
      FUN_0170cc70(param_1 + 0x130cd,pcVar1,pcVar8 + (1 - (param_1 + 0x130b5)));
      uVar5 = _UNK_018c4400;
      uVar4 = _UNK_018c43fc;
      uVar3 = _UNK_018c43f8;
      *(undefined4 *)pcVar1 = _DAT_018c43f4;
      *(undefined4 *)(param_1 + 0x130b8) = uVar3;
      *(undefined4 *)(param_1 + 0x130bc) = uVar4;
      *(undefined4 *)(param_1 + 0x130c0) = uVar5;
      *(undefined8 *)(param_1 + 0x130c4) = DAT_018c4404;
      *(undefined *)(param_1 + 0x130cc) = DAT_018c440c;
    }
    *piVar7 = (int)pcVar1;
    return;
  }
  FUN_005bde90(param_1 + 0x130b4,"Validation constraint violation: %s%s",pcVar8,&DAT_018c2414);
  *piVar7 = param_1 + 0x130b4;
  return;
}



/* FUNCTION 5061 ; VA 0x005bcec0 ; FUN_005bcec0 */

void FUN_005bcec0(int param_1)

{
  byte bVar1;
  int *piVar2;
  undefined2 uVar3;
  int iVar4;
  byte *pbVar5;
  uint uVar6;
  byte *pbVar7;
  int iVar8;
  bool bVar9;
  
  piVar2 = *(int **)(param_1 + 0x50);
  if ((piVar2 != (int *)0x0) && (*(int *)(param_1 + 0x54) == 0)) {
    iVar8 = 1;
    iVar4 = *piVar2;
    while (iVar4 != 0) {
      piVar2 = piVar2 + 4;
      iVar8 = iVar8 + 1;
      iVar4 = *piVar2;
    }
    iVar4 = FUN_0171e1f2(iVar8 << 4);
    if (iVar4 != 0) {
      FUN_0170c6f0(iVar4,*(undefined4 *)(param_1 + 0x50),iVar8 << 4);
      pbVar5 = *(byte **)(iVar4 + 4);
      if (pbVar5 != (byte *)0x0) {
        pbVar7 = &DAT_018c22f8;
        do {
          bVar1 = *pbVar5;
          bVar9 = bVar1 < *pbVar7;
          if (bVar1 != *pbVar7) {
LAB_005bcf38:
            uVar6 = -(uint)bVar9 | 1;
            goto LAB_005bcf3d;
          }
          if (bVar1 == 0) break;
          bVar1 = pbVar5[1];
          bVar9 = bVar1 < pbVar7[1];
          if (bVar1 != pbVar7[1]) goto LAB_005bcf38;
          pbVar5 = pbVar5 + 2;
          pbVar7 = pbVar7 + 2;
        } while (bVar1 != 0);
        uVar6 = 0;
LAB_005bcf3d:
        uVar3 = 1;
        if (uVar6 != 0) {
          uVar3 = 2;
        }
        *(undefined2 *)(param_1 + 6) = uVar3;
      }
      *(int *)(param_1 + 0x54) = iVar4;
    }
  }
  return;
}



/* FUNCTION 5062 ; VA 0x005bcf60 ; FUN_005bcf60 */

void FUN_005bcf60(int param_1,undefined4 param_2,char *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  char *pcVar2;
  
  pcVar2 = "SOAP-ENV:Receiver";
  if (*(short *)(param_1 + 6) != 2) {
    pcVar2 = "SOAP-ENV:Server";
  }
  puVar1 = (undefined4 *)FUN_005acd30(param_1);
  *puVar1 = pcVar2;
  puVar1 = (undefined4 *)FUN_005ace30(param_1);
  *puVar1 = param_2;
  if ((param_3 != (char *)0x0) && (*param_3 != '\0')) {
    puVar1 = (undefined4 *)FUN_005acd60(param_1);
    if (puVar1 != (undefined4 *)0x0) {
      *puVar1 = param_3;
    }
  }
  *(undefined4 *)(param_1 + 0x1615c) = param_4;
  return;
}



/* FUNCTION 5063 ; VA 0x005bcfc0 ; FUN_005bcfc0 */

void FUN_005bcfc0(int param_1,undefined4 param_2,char *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  char *pcVar2;
  
  pcVar2 = "SOAP-ENV:Sender";
  if (*(short *)(param_1 + 6) != 2) {
    pcVar2 = "SOAP-ENV:Client";
  }
  puVar1 = (undefined4 *)FUN_005acd30(param_1);
  *puVar1 = pcVar2;
  puVar1 = (undefined4 *)FUN_005ace30(param_1);
  *puVar1 = param_2;
  if ((param_3 != (char *)0x0) && (*param_3 != '\0')) {
    puVar1 = (undefined4 *)FUN_005acd60(param_1);
    if (puVar1 != (undefined4 *)0x0) {
      *puVar1 = param_3;
    }
  }
  *(undefined4 *)(param_1 + 0x1615c) = param_4;
  return;
}



/* FUNCTION 5064 ; VA 0x005bd020 ; FUN_005bd020 */

int FUN_005bd020(int param_1,undefined4 param_2,undefined1 *param_3)

{
  int iVar1;
  undefined1 *puVar2;
  
  iVar1 = param_1 + 0x130b4;
  if (*(char *)(param_1 + 0x138b4) != '\0') {
    puVar2 = &DAT_018c2414;
    if (param_3 != (undefined1 *)0x0) {
      puVar2 = param_3;
    }
    FUN_005bde90(iVar1,"Validation constraint violation: %s%s in element <%s>",param_2,puVar2,
                 param_1 + 0x138b4);
    return iVar1;
  }
  puVar2 = &DAT_018c2414;
  if (param_3 != (undefined1 *)0x0) {
    puVar2 = param_3;
  }
  FUN_005bde90(iVar1,"Validation constraint violation: %s%s",param_2,puVar2);
  return iVar1;
}



/* FUNCTION 5065 ; VA 0x005bd090 ; FUN_005bd090 */

undefined4 FUN_005bd090(int param_1,undefined4 param_2,undefined4 param_3)

{
  short sVar1;
  int *piVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  int iVar8;
  int iVar9;
  
  if ((param_1 != 0) && ((*(short *)(param_1 + 4) == 1 || (*(short *)(param_1 + 4) == 2)))) {
    if (*(int *)(param_1 + 0x1615c) != 0) {
      piVar2 = (int *)FUN_005acd30(param_1);
      iVar9 = *piVar2;
      if (iVar9 == 0) {
        FUN_005bc8a0(param_1);
        iVar9 = *piVar2;
      }
      if (*(short *)(param_1 + 6) == 2) {
        puVar3 = (undefined4 *)FUN_005ace60(param_1);
        pcVar5 = (char *)*puVar3;
      }
      else {
        pcVar5 = (char *)0x0;
      }
      piVar2 = (int *)FUN_005ace30(param_1);
      pcVar7 = (char *)*piVar2;
      piVar2 = (int *)FUN_005acd60(param_1);
      if ((piVar2 == (int *)0x0) || (pcVar4 = (char *)*piVar2, pcVar4 == (char *)0x0)) {
        pcVar4 = "[no detail]";
      }
      pcVar6 = "[no reason]";
      if (pcVar7 != (char *)0x0) {
        pcVar6 = pcVar7;
      }
      sVar1 = *(short *)(param_1 + 6);
      pcVar7 = "no subcode";
      if (pcVar5 != (char *)0x0) {
        pcVar7 = pcVar5;
      }
      iVar8 = (int)sVar1;
      if (sVar1 == 0) {
        iVar8 = *(int *)(param_1 + 0x1615c);
      }
      pcVar5 = "SOAP 1.";
      if (sVar1 == 0) {
        pcVar5 = "Error ";
      }
      FUN_005af8b0(param_2,param_3,"%s%d fault: %s [%s]\n\"%s\"\nDetail: %s\n",pcVar5,iVar8,iVar9,
                   pcVar7,pcVar6,pcVar4);
      return param_2;
    }
    return param_2;
  }
  FUN_0171dd10(param_2,"Error: soap struct not initialized",param_3);
  return param_2;
}



/* FUNCTION 5066 ; VA 0x005bd1b0 ; FUN_005bd1b0 */

int FUN_005bd1b0(undefined4 param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  
  if (param_2 != (char *)0x0) {
    pcVar3 = param_2;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    iVar2 = FUN_005b7fc0(param_1,pcVar3 + (1 - (int)(param_2 + 1)));
    if (iVar2 != 0) {
      iVar4 = iVar2 - (int)param_2;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        param_2[iVar4 + -1] = cVar1;
      } while (cVar1 != '\0');
    }
    return iVar2;
  }
  return 0;
}



/* FUNCTION 5067 ; VA 0x005bd200 ; FUN_005bd200 */

void FUN_005bd200(int param_1,undefined4 param_2)

{
  char *pcVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  char *pcVar5;
  int iVar6;
  char *pcVar7;
  int iVar8;
  
  if ((param_1 == 0) || ((*(short *)(param_1 + 4) != 1 && (*(short *)(param_1 + 4) != 2)))) {
    FUN_00558890(param_2,"Error: soap struct state not initialized\n");
  }
  else if (*(int *)(param_1 + 0x1615c) != 0) {
    piVar2 = (int *)FUN_005acd30(param_1);
    iVar8 = *piVar2;
    if (iVar8 == 0) {
      FUN_005bc8a0(param_1);
      iVar8 = *piVar2;
    }
    if (*(short *)(param_1 + 6) == 2) {
      puVar3 = (undefined4 *)FUN_005ace60(param_1);
      pcVar7 = (char *)*puVar3;
    }
    else {
      pcVar7 = (char *)0x0;
    }
    piVar2 = (int *)FUN_005ace30(param_1);
    pcVar1 = (char *)*piVar2;
    piVar2 = (int *)FUN_005acd60(param_1);
    pcVar5 = "SOAP 1.";
    if (*(short *)(param_1 + 6) == 0) {
      pcVar5 = "Error ";
    }
    FUN_00558890(param_2,pcVar5);
    iVar6 = (int)*(short *)(param_1 + 6);
    if (*(short *)(param_1 + 6) == 0) {
      iVar6 = *(int *)(param_1 + 0x1615c);
    }
    pcVar5 = "no subcode";
    if (pcVar7 != (char *)0x0) {
      pcVar5 = pcVar7;
    }
    uVar4 = FUN_005af260(iVar6," fault: ",iVar8,&DAT_018bfd90,pcVar5,&DAT_018bfd94);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00562ba0(uVar4);
    pcVar7 = "[no reason]";
    if (pcVar1 != (char *)0x0) {
      pcVar7 = pcVar1;
    }
    uVar4 = FUN_00558890(uVar4,&DAT_018c35d8,pcVar7,&DAT_018c35d8);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00558890(uVar4);
    uVar4 = FUN_00562ba0(uVar4);
    uVar4 = FUN_00558890(uVar4,"Detail: ");
    if ((piVar2 == (int *)0x0) || (pcVar7 = (char *)*piVar2, pcVar7 == (char *)0x0)) {
      pcVar7 = "[no detail]";
    }
    uVar4 = FUN_00558890(uVar4,pcVar7);
    FUN_00562ba0(uVar4);
    return;
  }
  return;
}



/* FUNCTION 5068 ; VA 0x005bd390 ; FUN_005bd390 */

char * FUN_005bd390(int param_1)

{
  char *pcVar1;
  
  if (*(int *)(param_1 + 0x16164) != 0) {
    pcVar1 = (char *)(param_1 + 0x130b4);
    *pcVar1 = '\0';
    FormatMessageA(0x1200,0,*(int *)(param_1 + 0x16164),0x400,pcVar1,0x400,0);
    return pcVar1;
  }
  if (0 < *(int *)(param_1 + 0x30)) {
    pcVar1 = (char *)(param_1 + 0x130b4);
    if (0 < *(int *)(param_1 + 0x34)) {
      FUN_005bde90(pcVar1,"Operation interrupted or timed out after %ds send or %ds receive delay",
                   *(int *)(param_1 + 0x34));
      return pcVar1;
    }
    FUN_005bde90(pcVar1,"Operation interrupted or timed out after %ds receive delay",
                 *(int *)(param_1 + 0x30));
    return pcVar1;
  }
  return "Operation interrupted or timed out";
}



/* FUNCTION 5069 ; VA 0x005bd410 ; FUN_005bd410 */

int FUN_005bd410(int param_1,int param_2,int param_3,int param_4)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  byte *pbVar6;
  byte *pbVar7;
  byte *pbVar8;
  char *pcVar9;
  byte bVar10;
  char *pcVar11;
  int iVar12;
  byte *pbVar13;
  byte bStack_1c;
  byte abStack_1b [7];
  byte *pbStack_14;
  int iStack_10;
  uint uStack_c;
  int iStack_8;
  
  iVar5 = param_1;
  pcVar11 = (char *)0x0;
  iStack_10 = 0;
  iVar12 = 0;
  iStack_8 = 0;
  if (*(short *)(param_1 + 0x1550c) != 0) {
    if (*(short *)(param_1 + 0x309a) == 0) {
      return 0;
    }
    if (*(char *)(param_1 + 0x138b4) != '\0') {
      pcVar11 = (char *)(param_1 + 0x134b4);
      *pcVar11 = 0x3c;
      *(undefined *)(param_1 + 0x138b3) = 0;
      pbStack_14 = (byte *)pcVar11;
      FUN_0171dd10(param_1 + 0x134b5,param_1 + 0x138b4,0x3fe);
      pbVar6 = (byte *)pcVar11;
      do {
        bVar10 = *pbVar6;
        pbVar6 = pbVar6 + 1;
      } while (bVar10 != 0);
      pbVar6 = (byte *)pcVar11 + ((int)pbVar6 - (iVar5 + 0x134b5));
      for (puVar2 = *(undefined4 **)(iVar5 + 0x154fc); puVar2 != (undefined4 *)0x0;
          puVar2 = (undefined4 *)*puVar2) {
        pcVar11 = (char *)pbStack_14;
        if (*(short *)(puVar2 + 4) != 0) {
          if ((byte *)(param_1 + 0x138b2) <= pbVar6) break;
          *pbVar6 = 0x20;
          pbVar7 = (byte *)((int)puVar2 + 0x12);
          pbVar13 = pbVar6 + 1;
          pbVar8 = pbVar13;
          do {
            bVar10 = *pbVar7;
            pbVar7 = pbVar7 + 1;
            *pbVar8 = bVar10;
            pbVar8 = pbVar8 + 1;
          } while (bVar10 != 0);
          pbVar7 = pbVar13;
          do {
            bVar10 = *pbVar7;
            pbVar7 = pbVar7 + 1;
          } while (bVar10 != 0);
          pbVar6 = pbVar13 + ((int)pbVar7 - (int)(pbVar6 + 2));
          if ((byte *)(param_1 + 0x138b2) <= pbVar6) break;
          if (puVar2[1] != 0) {
            pbVar6[0] = 0x3d;
            pbVar6[1] = 0x22;
            pbVar7 = pbVar6 + 2;
            pbVar8 = (byte *)puVar2[1];
            do {
              bVar10 = *pbVar8;
              pbVar8 = pbVar8 + 1;
              *pbVar7 = bVar10;
              pbVar7 = pbVar7 + 1;
            } while (bVar10 != 0);
            pbVar7 = pbVar6 + 2;
            do {
              bVar10 = *pbVar7;
              pbVar7 = pbVar7 + 1;
            } while (bVar10 != 0);
            pbVar6[(int)(pbVar7 + (2 - (int)(pbVar6 + 3)))] = 0x22;
            pbVar6 = pbVar6 + (int)(pbVar7 + (3 - (int)(pbVar6 + 3)));
          }
        }
      }
      pbVar6[0] = 0x3e;
      pbVar6[1] = 0;
      pbVar6 = (byte *)pcVar11;
      do {
        bVar10 = *pbVar6;
        pbVar6 = pbVar6 + 1;
      } while (bVar10 != 0);
      iVar12 = (int)pbVar6 - (int)((byte *)pcVar11 + 1);
      iStack_8 = 1;
      *(undefined2 *)(param_1 + 0x1550c) = 0;
    }
  }
  iVar5 = param_1;
  *(undefined4 *)(param_1 + 0x30b0) = 0;
  iVar3 = FUN_005b19f0(param_1,0,0);
  do {
    if (iVar3 != 0) {
      return 0;
    }
    pbVar6 = (byte *)(*(int *)(iVar5 + 0x30a8) + *(int *)(iVar5 + 0x30b0));
    pbStack_14 = (byte *)0x0;
    uVar4 = *(int *)(param_1 + 0x30ac) - *(int *)(iVar5 + 0x30b0);
    uStack_c = uVar4;
    *(int *)(param_1 + 0x30b0) = *(int *)(param_1 + 0x30ac);
    if (uVar4 != 0) {
      do {
        if (iVar12 < 1) {
          if ((*(uint *)(param_1 + 8) & 0x200000) == 0) {
            uVar4 = FUN_005b6b90(param_1);
          }
          else {
            uVar4 = FUN_005b5480();
            if ((uVar4 + 0x7fffff80 < 0x7fffff80) && ((int)uVar4 < -6)) {
              uVar4 = uVar4 & 0x7fffffff;
              if (uVar4 < 0x800) {
                pbVar7 = abStack_1b;
                bStack_1c = (byte)(uVar4 >> 6) & 0x1f | 0xc0;
              }
              else {
                if (uVar4 < 0x10000) {
                  pbVar7 = abStack_1b;
                  bStack_1c = (byte)(uVar4 >> 0xc) & 0xf | 0xe0;
                }
                else {
                  if (uVar4 < 0x200000) {
                    pbVar7 = abStack_1b;
                    bStack_1c = (byte)(uVar4 >> 0x12) & 7 | 0xf0;
                  }
                  else {
                    bVar10 = (byte)(uVar4 >> 0x18);
                    if (uVar4 < 0x4000000) {
                      pbVar7 = abStack_1b;
                      bStack_1c = bVar10 & 3 | 0xf8;
                    }
                    else {
                      pbVar7 = abStack_1b + 1;
                      bStack_1c = bVar10 >> 6 | 0xfc;
                      abStack_1b[0] = bVar10 & 0x3f | 0x80;
                    }
                    *pbVar7 = (byte)(uVar4 >> 0x12) & 0x3f | 0x80;
                    pbVar7 = pbVar7 + 1;
                  }
                  *pbVar7 = (byte)(uVar4 >> 0xc) & 0x3f | 0x80;
                  pbVar7 = pbVar7 + 1;
                }
                *pbVar7 = (byte)(uVar4 >> 6) & 0x3f | 0x80;
                pbVar7 = pbVar7 + 1;
              }
              pcVar11 = (char *)abStack_1b;
              *pbVar7 = (byte)uVar4 & 0x3f | 0x80;
              iVar12 = (int)pbVar7 - (int)&bStack_1c;
              *pbVar6 = bStack_1c;
              uVar4 = uStack_c;
              goto LAB_005bd83d;
            }
          }
          iVar5 = param_1;
          if ((int)uVar4 < -5) {
            if (uVar4 == 0xfffffffa) {
LAB_005bd75c:
              uVar4 = 0x27;
            }
            else {
              switch(uVar4) {
              case 0x80000022:
                if (param_2 != 0) goto switchD_005bd783_caseD_fffffffb;
                pcVar11 = "quot;";
                iVar12 = 5;
                uVar4 = 0x26;
                break;
              default:
                goto switchD_005bd6de_caseD_80000023;
              case 0x80000026:
                if (param_2 == 0) {
                  pcVar11 = &DAT_018c3708;
                  iVar12 = 4;
                }
                uVar4 = 0x26;
                break;
              case 0x80000027:
                if (param_2 != 0) goto LAB_005bd75c;
                pcVar11 = "apos;";
                iVar12 = 5;
                uVar4 = 0x26;
                break;
              case 0x8000003c:
                if (param_2 == 0) {
                  pcVar11 = &DAT_018c3700;
                  iVar12 = 3;
                  uVar4 = 0x26;
                }
                else {
                  uVar4 = 0x3c;
                }
                break;
              case 0x8000003e:
                if (param_2 != 0) goto switchD_005bd783_caseD_fffffffc;
                pcVar11 = &DAT_018c3704;
                iVar12 = 3;
                uVar4 = 0x26;
              }
            }
          }
          else {
            switch(uVar4) {
            case 0x2f:
              if (0 < iStack_8) {
                iVar5 = FUN_005b5480(param_1);
                if (iVar5 == -4) {
                  iStack_8 = iStack_8 + -1;
                }
                *(int *)(param_1 + 0x3094) = iVar5;
              }
              uVar4 = 0x2f;
              break;
            case 0xfffffffb:
switchD_005bd783_caseD_fffffffb:
              uVar4 = 0x22;
              break;
            case 0xfffffffc:
switchD_005bd783_caseD_fffffffc:
              uVar4 = 0x3e;
              break;
            case 0xfffffffd:
              if (iStack_8 == 0) goto LAB_005bd86d;
              pcVar11 = (char *)&DAT_018c36fc;
              iStack_8 = iStack_8 + -1;
              iVar12 = 1;
              uVar4 = 0x3c;
              break;
            case 0xfffffffe:
              iStack_8 = iStack_8 + 1;
              uVar4 = 0x3c;
              break;
            default:
switchD_005bd6de_caseD_80000023:
              if (uVar4 == 0xffffffff) {
LAB_005bd86d:
                *(uint *)(param_1 + 0x3094) = uVar4;
                *pbVar6 = 0;
                pcVar11 = *(char **)(param_1 + 0x30a8);
                iVar12 = 0;
                if (pcVar11 != (char *)0x0) {
                  pcVar9 = pcVar11;
                  do {
                    cVar1 = *pcVar9;
                    pcVar9 = pcVar9 + 1;
                  } while (cVar1 != '\0');
                  iVar12 = FUN_005b7fc0(param_1,pcVar9 + (1 - (int)(pcVar11 + 1)));
                  if (iVar12 != 0) {
                    iVar3 = iVar12 - (int)pcVar11;
                    do {
                      cVar1 = *pcVar11;
                      pcVar11 = pcVar11 + 1;
                      pcVar11[iVar3 + -1] = cVar1;
                    } while (cVar1 != '\0');
                  }
                }
                param_1 = iVar12;
                if (((*(uint *)(iVar5 + 8) & 0x1000) == 0) || (param_3 <= iStack_10)) {
                  if ((param_2 == 2) && (iVar12 = FUN_005bb820(iVar5,param_1,&param_1), iVar12 != 0)
                     ) {
                    return 0;
                  }
                  return param_1;
                }
LAB_005bd8fc:
                *(undefined4 *)(iVar5 + 0x1615c) = 0x2d;
                return 0;
              }
              if ((*(uint *)(param_1 + 8) & 0x400000) != 0) {
                iVar12 = FUN_01721e3e(&bStack_1c,uVar4);
                if ((iVar12 < 1) || (iVar5 = FUN_0172171f(), iVar5 < iVar12)) {
                  iVar12 = 0;
                  uVar4 = 0x7f;
                }
                else {
                  uVar4 = (uint)bStack_1c;
                  pcVar11 = (char *)abStack_1b;
                  iVar12 = iVar12 + -1;
                }
              }
            }
          }
          *pbVar6 = (byte)uVar4;
          iStack_10 = iStack_10 + 1;
          uVar4 = uStack_c;
          if ((((*(uint *)(param_1 + 8) & 0x1000) != 0) && (-1 < param_4)) &&
             (iVar5 = param_1, param_4 < iStack_10)) goto LAB_005bd8fc;
        }
        else {
          bVar10 = *pcVar11;
          pcVar11 = (char *)((byte *)pcVar11 + 1);
          *pbVar6 = bVar10;
          iVar12 = iVar12 + -1;
        }
LAB_005bd83d:
        pbVar6 = pbVar6 + 1;
        pbStack_14 = (byte *)((int)pbStack_14 + 1);
      } while (pbStack_14 < uVar4);
    }
    iVar5 = param_1;
    iVar3 = FUN_005b19f0(param_1,0,0);
  } while( true );
}



/* FUNCTION 5070 ; VA 0x005bd9a0 ; FUN_005bd9a0 */

undefined4 FUN_005bd9a0(uint param_1,char *param_2,int param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  char *pcVar8;
  
  uVar3 = param_1;
  uVar2 = *(uint *)(param_1 + 8);
  pcVar7 = param_2 + 1;
  cVar1 = *param_2;
  pcVar8 = param_2;
  do {
    param_2 = (char *)(int)cVar1;
    if (param_2 == (char *)0x0) {
      uVar4 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      return uVar4;
    }
    switch(param_2) {
    case (char *)0x9:
      if (param_3 != 0) {
        iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
        if (iVar5 != 0) goto LAB_005bdc1b;
        iVar5 = FUN_005bc2c0(uVar3,"&#x9;",5);
        break;
      }
      goto LAB_005bdbf4;
    case (char *)0xa:
      if ((param_3 == 0) && ((*(uint *)(uVar3 + 8) & 0x4000) != 0)) goto LAB_005bdbf4;
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bc2c0(uVar3,"&#xA;",5);
      break;
    default:
      if ((*(uint *)(uVar3 + 8) & 0x400000) != 0) {
        uVar4 = FUN_0172171f();
        iVar5 = FUN_01721cc7(&param_1,pcVar7 + -1,uVar4);
        if ((0 < iVar5) && ((char *)(param_1 & 0xffff) != param_2)) {
          iVar6 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
          if ((iVar6 != 0) || (iVar6 = FUN_005bab10(uVar3,param_1 & 0xffff), iVar6 != 0))
          goto LAB_005bdc1b;
          pcVar7 = pcVar7 + iVar5 + -1;
          pcVar8 = pcVar7;
          goto LAB_005bdbf4;
        }
      }
      if ((((-(uint)((uVar2 & 0x200000) != 0) & 0x80) - 0x80 & (uint)param_2) == 0) &&
         (((uint)param_2 & 0xffffffe0) != 0)) goto LAB_005bdbf4;
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bab10(uVar3,(uint)param_2 & 0xff);
      break;
    case (char *)0xd:
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bc2c0(uVar3,"&#xD;",5);
      break;
    case (char *)0x22:
      if (param_3 == 0) goto LAB_005bdbf4;
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bc2c0(uVar3,"&quot;",6);
      break;
    case (char *)0x26:
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bc2c0(uVar3,"&amp;",5);
      break;
    case (char *)0x3c:
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bc2c0(uVar3,&DAT_018c36e4,4);
      break;
    case (char *)0x3e:
      if (param_3 != 0) goto LAB_005bdbf4;
      iVar5 = FUN_005bc2c0(uVar3,pcVar8,pcVar7 + (-1 - (int)pcVar8));
      if (iVar5 != 0) goto LAB_005bdc1b;
      iVar5 = FUN_005bc2c0(uVar3,&DAT_018c36ec,4);
    }
    pcVar8 = pcVar7;
    if (iVar5 != 0) {
LAB_005bdc1b:
      return *(undefined4 *)(uVar3 + 0x1615c);
    }
LAB_005bdbf4:
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while( true );
}



/* FUNCTION 5071 ; VA 0x005bdc80 ; FUN_005bdc80 */

int FUN_005bdc80(char *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  
  cVar1 = *param_1;
  while (iVar3 = (int)cVar1, pcVar5 = param_2, iVar3 != 0) {
    iVar2 = (int)*param_2;
    if (iVar3 == 0x22) break;
    if ((*param_2 != '-') && (iVar3 != iVar2)) {
      iVar4 = iVar2 + 0x20;
      if (0x19 < iVar2 - 0x41U) {
        iVar4 = iVar2;
      }
      iVar2 = iVar3 + 0x20;
      if (0x19 < iVar3 - 0x41U) {
        iVar2 = iVar3;
      }
      if (iVar2 != iVar4) {
        if (iVar4 != 0x2a) {
          return 1;
        }
        pcVar5 = param_2 + 1;
        iVar3 = (int)param_2[1];
        if (param_2[1] == '\0') {
          return 0;
        }
        iVar4 = (int)*param_1;
        iVar2 = iVar3 + 0x20;
        if (0x19 < iVar3 - 0x41U) {
          iVar2 = iVar3;
        }
        if (iVar4 != 0) goto LAB_005bdd05;
        break;
      }
    }
    pcVar5 = param_1 + 1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
    cVar1 = *pcVar5;
  }
  goto LAB_005bdd3a;
  while( true ) {
    iVar3 = iVar4 + 0x20;
    if (0x19 < iVar4 - 0x41U) {
      iVar3 = iVar4;
    }
    if ((iVar3 == iVar2) && (iVar3 = FUN_005bdc80(param_1 + 1,param_2 + 2), iVar3 == 0)) {
      return 0;
    }
    iVar4 = (int)param_1[1];
    param_1 = param_1 + 1;
    if (iVar4 == 0) break;
LAB_005bdd05:
    if (iVar4 == 0x22) break;
  }
LAB_005bdd3a:
  if ((*pcVar5 == '*') && (pcVar5[1] == '\0')) {
    return 0;
  }
  return (int)*pcVar5;
}



/* FUNCTION 5072 ; VA 0x005bdd60 ; FUN_005bdd60 */

void FUN_005bdd60(int param_1,undefined4 param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 0x58);
  do {
    if (puVar1 == (undefined4 *)0x0) {
LAB_005bdd94:
      iVar2 = FUN_01723e00(param_2,&DAT_018c2f90,3);
      if (iVar2 != 0) {
        FUN_0171dd10(param_1 + 0x134b4,param_2,param_3);
        *(undefined *)(param_1 + 0x134b4 + param_3) = 0;
        FUN_005b9d40(param_1,param_1 + 0x134b4,0,1);
      }
      return;
    }
    iVar2 = FUN_01723e00(puVar1 + 4,param_2,param_3);
    if ((iVar2 == 0) && (*(char *)((int)puVar1 + param_3 + 0x10) == '\0')) {
      if (puVar1 != (undefined4 *)0x0) {
        if (*(short *)(puVar1 + 2) != 0) {
          return;
        }
        FUN_005b9d40(param_1,puVar1 + 4,puVar1[3],1);
        return;
      }
      goto LAB_005bdd94;
    }
    puVar1 = (undefined4 *)*puVar1;
  } while( true );
}



/* FUNCTION 5073 ; VA 0x005bde00 ; FUN_005bde00 */

undefined1 * FUN_005bde00(int param_1)

{
  int iVar1;
  byte *pbVar2;
  uint uVar3;
  
  pbVar2 = (byte *)(param_1 + 0x134b4);
  if (*(short *)(param_1 + 0x309a) == 0) {
    return &DAT_018c2414;
  }
  do {
    iVar1 = FUN_005b5480(param_1);
    if (iVar1 < 0) break;
  } while (iVar1 < 0x21);
  uVar3 = 0;
  do {
    if ((iVar1 == -3) || (iVar1 == -1)) break;
    *pbVar2 = (byte)iVar1;
    pbVar2 = pbVar2 + 1;
    iVar1 = FUN_005b5480(param_1);
    uVar3 = uVar3 + 1;
  } while (uVar3 < 0x3ff);
  while ((pbVar2 = pbVar2 + -1, uVar3 != 0 && (*pbVar2 < 0x21))) {
    uVar3 = uVar3 - 1;
  }
  pbVar2[1] = 0;
  if ((iVar1 == -1) || (iVar1 == -3)) {
    *(int *)(param_1 + 0x3094) = iVar1;
  }
  return (undefined1 *)(param_1 + 0x134b4);
}



/* FUNCTION 5074 ; VA 0x005bde90 ; FUN_005bde90 */

int FUN_005bde90(undefined4 param_1,undefined4 param_2)

{
  uint *puVar1;
  int iVar2;
  
  puVar1 = (uint *)FUN_005574c0(param_1,0xffffffff,param_2,0,&stack0x0000000c);
  iVar2 = FUN_0171d0ba(*puVar1 | 1,puVar1[1]);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  return iVar2;
}



/* FUNCTION 5075 ; VA 0x005bded0 ; FUN_005bded0 */

void FUN_005bded0(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_005af8a0(param_1,0xffffffff,param_2,0,&stack0x0000000c);
  FUN_01723c8d(*puVar1,puVar1[1]);
  return;
}



/* FUNCTION 5076 ; VA 0x005bdf00 ; FUN_005bdf00 */

void FUN_005bdf00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  Ordinal_1(param_2,param_3,param_4);
  return;
}



/* FUNCTION 5077 ; VA 0x005bdf20 ; FUN_005bdf20 */

void FUN_005bdf20(undefined4 param_1,undefined4 param_2)

{
  Ordinal_3(param_2);
  return;
}



/* FUNCTION 5078 ; VA 0x005bdf30 ; FUN_005bdf30 */

/* WARNING: Type propagation algorithm not settling */

int FUN_005bdf30(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined2 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  char *pcVar9;
  int iVar10;
  bool bVar11;
  undefined auStack_1b0 [140];
  undefined4 uStack_124;
  int iStack_120;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint auStack_14 [3];
  uint uStack_8;
  
  iVar2 = param_1;
  iStack_20 = 10;
  uStack_1c = 0x10000;
  auStack_14[1] = 1;
  if (*(int *)(param_1 + 0x3078) != -1) {
    (**(code **)(param_1 + 0x3000))(param_1,*(int *)(param_1 + 0x3078));
  }
  bVar11 = DAT_01ea8b8c == 0;
  *(undefined4 *)(iVar2 + 0x3078) = 0xffffffff;
  *(undefined4 *)(iVar2 + 0x16160) = 1;
  if (bVar11) {
    iVar4 = Ordinal_115(0x101,auStack_1b0);
    if (iVar4 != 0) {
      *(undefined4 *)(iVar2 + 0x16164) = 0;
      uVar6 = FUN_005be760(iVar2);
      pcVar9 = "SOAP-ENV:Sender";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = uVar6;
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "TCP init failed in tcp_connect()";
        *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
        return -1;
      }
LAB_005be6ed:
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      return -1;
    }
    DAT_01ea8b8c = 1;
  }
  *(undefined4 *)(iVar2 + 0x16160) = 0;
  auStack_14[0] = param_4;
  do {
    uVar8 = auStack_14[0];
    iVar4 = Ordinal_23(2,((*(byte *)(iVar2 + 0x10) & 4) != 0) + '\x01',0);
    param_1 = iVar4;
    if (iVar4 == -1) {
      uVar6 = Ordinal_111();
      *(undefined4 *)(iVar2 + 0x16164) = uVar6;
      uVar6 = FUN_005be760(iVar2);
      pcVar9 = "SOAP-ENV:Sender";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = uVar6;
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "socket failed in tcp_connect()";
      }
      goto LAB_005be6ed;
    }
    iVar5 = *(int *)(iVar2 + 0x44);
    if (iVar5 == 0x80) {
      uStack_18 = 1;
      iVar5 = Ordinal_21(iVar4,0xffff,0x80,&uStack_18,4);
      if (iVar5 != 0) {
        uVar6 = Ordinal_111();
        *(undefined4 *)(iVar2 + 0x16164) = uVar6;
        uVar6 = FUN_005be760(iVar2);
        pcVar9 = "SOAP-ENV:Sender";
        if (*(short *)(iVar2 + 6) != 2) {
          pcVar9 = "SOAP-ENV:Client";
        }
        puVar7 = (undefined4 *)FUN_005acd30(iVar2);
        *puVar7 = pcVar9;
        puVar7 = (undefined4 *)FUN_005ace30(iVar2);
        *puVar7 = uVar6;
        puVar7 = (undefined4 *)FUN_005acd60(iVar2);
        if (puVar7 != (undefined4 *)0x0) {
          *puVar7 = "setsockopt SO_LINGER failed in tcp_connect()";
        }
        *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
        (**(code **)(iVar2 + 0x3000))(iVar2,param_1);
        return -1;
      }
    }
    else if ((iVar5 != 0) && (iVar5 = Ordinal_21(iVar4,0xffff,iVar5,auStack_14 + 1,4), iVar5 != 0))
    {
      uVar6 = Ordinal_111();
      *(undefined4 *)(iVar2 + 0x16164) = uVar6;
      uVar6 = FUN_005be760(iVar2);
      pcVar9 = "SOAP-ENV:Sender";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = uVar6;
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "setsockopt failed in tcp_connect()";
      }
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      (**(code **)(iVar2 + 0x3000))(iVar2,param_1);
      return -1;
    }
    if (((*(short *)(iVar2 + 0x1612c) != 0) || (*(short *)(iVar2 + 0x1612e) != 0)) &&
       (iVar5 = Ordinal_21(iVar4,0xffff,8,auStack_14 + 1,4), iVar5 != 0)) {
      uVar6 = Ordinal_111();
      *(undefined4 *)(iVar2 + 0x16164) = uVar6;
      uVar6 = FUN_005be760(iVar2);
      pcVar9 = "SOAP-ENV:Sender";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = uVar6;
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "setsockopt SO_KEEPALIVE failed in tcp_connect()";
      }
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      (**(code **)(iVar2 + 0x3000))(iVar2,param_1);
      return -1;
    }
    iVar5 = Ordinal_21(iVar4,0xffff,0x1001,&uStack_1c,4);
    if (iVar5 != 0) {
      uVar6 = Ordinal_111();
      *(undefined4 *)(iVar2 + 0x16164) = uVar6;
      uVar6 = FUN_005be760(iVar2);
      pcVar9 = "SOAP-ENV:Sender";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = uVar6;
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "setsockopt SO_SNDBUF failed in tcp_connect()";
      }
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      (**(code **)(iVar2 + 0x3000))(iVar2,param_1);
      return -1;
    }
    iVar5 = Ordinal_21(iVar4,0xffff,0x1002,&uStack_1c,4);
    if (iVar5 != 0) {
      uVar6 = Ordinal_111();
      *(undefined4 *)(iVar2 + 0x16164) = uVar6;
      uVar6 = FUN_005be760(iVar2);
      pcVar9 = "SOAP-ENV:Sender";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = uVar6;
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "setsockopt SO_RCVBUF failed in tcp_connect()";
      }
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      (**(code **)(iVar2 + 0x3000))(iVar2,param_1);
      return -1;
    }
    if (((*(byte *)(iVar2 + 0x10) & 4) == 0) &&
       (iVar5 = Ordinal_21(iVar4,6,1,auStack_14 + 1,4), iVar5 != 0)) {
      iVar5 = Ordinal_111();
      pcVar9 = "setsockopt TCP_NODELAY failed in tcp_connect()";
      goto LAB_005be331;
    }
    *(undefined4 *)(iVar2 + 0x171f4) = 0x10;
    *(undefined4 *)(iVar2 + 0x171e4) = 0;
    *(undefined4 *)(iVar2 + 0x171e8) = 0;
    *(undefined4 *)(iVar2 + 0x171ec) = 0;
    *(undefined4 *)(iVar2 + 0x171f0) = 0;
    *(undefined2 *)(iVar2 + 0x171e4) = 2;
    *(undefined4 *)(iVar2 + 0x16160) = 2;
    if (*(int *)(iVar2 + 0x16144) == 0) {
      iVar5 = (**(code **)(iVar2 + 0x2ff4))(iVar2,param_3,iVar2 + 0x171e8);
      if (iVar5 != 0) {
        pcVar9 = "get host by name failed in tcp_connect()";
        goto LAB_005be337;
      }
      uVar8 = uVar8 & 0xffff;
    }
    else {
      iVar5 = (**(code **)(iVar2 + 0x2ff4))(iVar2,*(int *)(iVar2 + 0x16144),iVar2 + 0x171e8);
      if (iVar5 != 0) {
        pcVar9 = "get proxy host by name failed in tcp_connect()";
        goto LAB_005be337;
      }
      uVar8 = (uint)*(ushort *)(iVar2 + 0x16148);
    }
    uVar3 = Ordinal_9(uVar8);
    *(undefined2 *)(iVar2 + 0x171e6) = uVar3;
    *(undefined4 *)(iVar2 + 0x16160) = 0;
    if ((*(byte *)(iVar2 + 0x10) & 4) != 0) {
      return iVar4;
    }
    uStack_8 = (uint)(*(int *)(iVar2 + 0x38) != 0);
    Ordinal_10(iVar4,0x8004667e,&uStack_8);
    while( true ) {
      iVar5 = Ordinal_4(iVar4,iVar2 + 0x171e4,0x10);
      if (iVar5 == 0) goto LAB_005be4dd;
      iVar5 = Ordinal_111();
      if (iVar5 == 0x2740) break;
      if ((*(int *)(iVar2 + 0x38) != 0) && ((iVar5 == 0x2734 || (iVar5 == 0x2733))))
      goto LAB_005be367;
      if ((iVar5 != 0) && (iVar5 != 0x2714)) goto LAB_005be286;
    }
    (**(code **)(iVar2 + 0x3000))(iVar2,iVar4);
    iVar10 = iStack_20 + -1;
    bVar11 = 0 < iStack_20;
    iStack_20 = iVar10;
  } while (bVar11);
LAB_005be286:
  *(int *)(iVar2 + 0x16164) = iVar5;
  pcVar9 = "connect failed in tcp_connect()";
LAB_005be337:
  uVar6 = FUN_005be760(iVar2,pcVar9,0x1c);
  FUN_005bcfc0(iVar2,uVar6);
  (**(code **)(iVar2 + 0x3000))(iVar2,iVar4);
  return -1;
  while( true ) {
    if (iVar5 == 0) {
      pcVar9 = "SOAP-ENV:Sender";
      *(undefined4 *)(iVar2 + 0x16164) = 0;
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar9 = "SOAP-ENV:Client";
      }
      puVar7 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar7 = pcVar9;
      puVar7 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar7 = "Timeout";
      puVar7 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar7 != (undefined4 *)0x0) {
        *puVar7 = "connect failed in tcp_connect()";
      }
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      (**(code **)(iVar2 + 0x3000))(iVar2,iVar4);
      return -1;
    }
    iVar5 = Ordinal_111();
    if (iVar5 != 0x2714) break;
LAB_005be367:
    auStack_14[2] = *(int *)(iVar2 + 0x38);
    if ((int)auStack_14[2] < 1) {
      iVar5 = (int)((ulonglong)((longlong)(int)auStack_14[2] * -0x431bde83) >> 0x20);
      iVar10 = -auStack_14[2];
      auStack_14[2] = (iVar5 >> 0x12) - (iVar5 >> 0x1f);
      uStack_8 = iVar10 % 1000000;
    }
    else {
      uStack_8 = 0;
    }
    uStack_124 = 1;
    iStack_120 = iVar4;
    iVar5 = Ordinal_18(iVar4 + 1,0,&uStack_124,0,auStack_14 + 2);
    if (0 < iVar5) {
      auStack_14[0] = 4;
      piVar1 = (int *)(iVar2 + 0x16164);
      iVar5 = Ordinal_7(iVar4,0xffff,0x1007,piVar1,auStack_14);
      if ((iVar5 != 0) || (*piVar1 != 0)) {
        if (*piVar1 == 0) {
          iVar4 = Ordinal_111();
          *piVar1 = iVar4;
        }
        uVar6 = FUN_005be760(iVar2);
        pcVar9 = "SOAP-ENV:Sender";
        if (*(short *)(iVar2 + 6) != 2) {
          pcVar9 = "SOAP-ENV:Client";
        }
        puVar7 = (undefined4 *)FUN_005acd30(iVar2);
        *puVar7 = pcVar9;
        puVar7 = (undefined4 *)FUN_005ace30(iVar2);
        *puVar7 = uVar6;
        puVar7 = (undefined4 *)FUN_005acd60(iVar2);
        if (puVar7 != (undefined4 *)0x0) {
          *puVar7 = "connect failed in tcp_connect()";
        }
        *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
        (**(code **)(iVar2 + 0x3000))(iVar2,param_1);
        return -1;
      }
LAB_005be4dd:
      if ((*(int *)(iVar2 + 0x30) != 0) || (param_1 = 0, *(int *)(iVar2 + 0x34) != 0)) {
        param_1 = 1;
      }
      Ordinal_10(iVar4,0x8004667e,&param_1);
      *(uint *)(iVar2 + 0xc) = *(uint *)(iVar2 + 0xc) & 0xfffff7ff;
      *(uint *)(iVar2 + 0x10) = *(uint *)(iVar2 + 0x10) & 0xfffff7ff;
      *(int *)(iVar2 + 0x3078) = iVar4;
      iVar5 = FUN_005bdc80(param_2,"https:*");
      if (iVar5 != 0) {
        return iVar4;
      }
      (**(code **)(iVar2 + 0x3000))(iVar2,iVar4);
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1e;
      return -1;
    }
  }
  pcVar9 = "connect failed in tcp_connect()";
LAB_005be331:
  *(int *)(iVar2 + 0x16164) = iVar5;
  goto LAB_005be337;
}



/* FUNCTION 5079 ; VA 0x005be710 ; FUN_005be710 */

undefined4 FUN_005be710(int param_1)

{
  if ((*(int *)(param_1 + 0x3078) != -1) && ((*(byte *)(param_1 + 0x10) & 4) == 0)) {
    (**(code **)(param_1 + 0x3004))(param_1,*(int *)(param_1 + 0x3078),2);
    (**(code **)(param_1 + 0x3000))(param_1,*(undefined4 *)(param_1 + 0x3078));
    *(undefined4 *)(param_1 + 0x3078) = 0xffffffff;
  }
  return 0;
}



/* FUNCTION 5080 ; VA 0x005be760 ; FUN_005be760 */

char * FUN_005be760(int param_1)

{
  int iVar1;
  int *piVar2;
  char *pcVar3;
  
  iVar1 = *(int *)(param_1 + 0x16160);
  if (iVar1 == 0) {
    pcVar3 = (char *)FUN_005bd390();
    return pcVar3;
  }
  if (iVar1 == 1) {
    return "WSAStartup failed";
  }
  if (iVar1 != 2) {
    return (char *)0x0;
  }
  iVar1 = *(int *)(param_1 + 0x16164);
  piVar2 = (int *)&DAT_018c246c;
  if (iVar1 != 0x2af9) {
    do {
      if (piVar2[1] == 0) break;
      piVar2 = piVar2 + 2;
    } while (*piVar2 != iVar1);
  }
  pcVar3 = (char *)piVar2[1];
  if (pcVar3 == (char *)0x0) {
    pcVar3 = (char *)(param_1 + 0x130b4);
    FUN_005bde90(pcVar3,"TCP/UDP IP error %d",iVar1);
  }
  return pcVar3;
}



/* FUNCTION 5081 ; VA 0x005be7e0 ; FUN_005be7e0 */

undefined4 FUN_005be7e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = Ordinal_11(param_2);
  if (iVar1 != -1) {
    *param_3 = iVar1;
    return 0;
  }
  iVar1 = Ordinal_52(param_2);
  if (iVar1 == 0) {
    uVar2 = Ordinal_111();
    *(undefined4 *)(param_1 + 0x16164) = uVar2;
    return 0xffffffff;
  }
  FUN_0170c6f0(param_3,**(undefined4 **)(iVar1 + 0xc),(int)*(short *)(iVar1 + 10));
  return 0;
}



/* FUNCTION 5082 ; VA 0x005be840 ; FUN_005be840 */

void FUN_005be840(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  Ordinal_22(param_2,param_3);
  return;
}



/* FUNCTION 5083 ; VA 0x005be850 ; FUN_005be850 */

undefined4 * __fastcall FUN_005be850(undefined4 *param_1)

{
  FUN_005af100();
  *param_1 = RCCServiceSoapService::vftable;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[2] = 0;
  if (param_1[0x14] == 0) {
    param_1[0x14] = &PTR_s_SOAP_ENV_018c4670;
  }
  return param_1;
}



/* FUNCTION 5084 ; VA 0x005be890 ; FUN_005be890 */

void __fastcall FUN_005be890(undefined4 *param_1)

{
  *param_1 = RCCServiceSoapService::vftable;
  FUN_005af130();
  return;
}



/* FUNCTION 5085 ; VA 0x005be8a0 ; FUN_005be8a0 */

undefined4 * __thiscall FUN_005be8a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RCCServiceSoapService::vftable;
  FUN_005af130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x17658);
  }
  return param_1;
}



/* FUNCTION 5086 ; VA 0x005be8d0 ; FUN_005be8d0 */

void __thiscall FUN_005be8d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0xc) = param_2;
  *(undefined4 *)(param_1 + 0x10) = param_3;
  *(undefined4 *)(param_1 + 8) = param_3;
  if (*(int *)(param_1 + 0x50) == 0) {
    *(undefined ***)(param_1 + 0x50) = &PTR_s_SOAP_ENV_018c4670;
  }
  return;
}



/* FUNCTION 5087 ; VA 0x005be900 ; FUN_005be900 */

void __fastcall FUN_005be900(undefined4 param_1)

{
  FUN_005b1350(param_1);
  return;
}



/* FUNCTION 5088 ; VA 0x005be910 ; FUN_005be910 */

void __thiscall
FUN_005be910(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005b25e0(param_1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 5089 ; VA 0x005be930 ; FUN_005be930 */

undefined4 * __fastcall FUN_005be930(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017959c2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x17658);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_005af100();
    *puVar1 = RCCServiceSoapService::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[2] = 0;
    if (puVar1[0x14] == 0) {
      puVar1[0x14] = &PTR_s_SOAP_ENV_018c4670;
    }
  }
  FUN_005b3080(puVar1,param_1);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 5090 ; VA 0x005be9c0 ; FUN_005be9c0 */

undefined4 __fastcall FUN_005be9c0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = FUN_005b8900(param_1);
  if (iVar1 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  iVar1 = param_1 + 0x138b4;
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:HelloWorld");
  if (iVar2 == 0) {
    uVar3 = FUN_005c0a60(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetVersion");
  if (iVar2 == 0) {
    uVar3 = FUN_005c0810(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetStatus");
  if (iVar2 == 0) {
    uVar3 = FUN_005c0600(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:OpenJob");
  if (iVar2 == 0) {
    uVar3 = FUN_005c0c70(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:OpenJobEx");
  if (iVar2 == 0) {
    uVar3 = FUN_005c0e80(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:RenewLease");
  if (iVar2 == 0) {
    uVar3 = FUN_005c1090(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:Execute");
  if (iVar2 == 0) {
    uVar3 = FUN_005bfbb0(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ExecuteEx");
  if (iVar2 == 0) {
    uVar3 = FUN_005bfdc0(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseJob");
  if (iVar2 == 0) {
    uVar3 = FUN_005bf580(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:BatchJob");
  if (iVar2 == 0) {
    uVar3 = FUN_005bed40(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:BatchJobEx");
  if (iVar2 == 0) {
    uVar3 = FUN_005bef50(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetExpiration");
  if (iVar2 == 0) {
    uVar3 = FUN_005c03f0(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetAllJobs");
  if (iVar2 == 0) {
    uVar3 = FUN_005bffd0(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetAllJobsEx");
  if (iVar2 == 0) {
    uVar3 = FUN_005c01e0(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseExpiredJobs");
  if (iVar2 == 0) {
    uVar3 = FUN_005bf370(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseAllJobs");
  if (iVar2 == 0) {
    uVar3 = FUN_005bf160(param_1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:Diag");
  if (iVar2 == 0) {
    uVar3 = FUN_005bf790(param_1);
    return uVar3;
  }
  iVar1 = FUN_005b8220(param_1,iVar1,"ns1:DiagEx");
  if (iVar1 == 0) {
    uVar3 = FUN_005bf9a0(param_1);
    return uVar3;
  }
  *(undefined4 *)(param_1 + 0x1615c) = 0xd;
  return 0xd;
}



/* FUNCTION 5091 ; VA 0x005bec20 ; FUN_005bec20 */

int __thiscall FUN_005bec20(int *param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x34))(0,param_2,100);
  if (iVar1 != -1) {
    iVar1 = (**(code **)(*param_1 + 0x38))();
    while (iVar1 != -1) {
      (**(code **)(*param_1 + 0x3c))();
      FUN_005b3540(param_1,0);
      FUN_005b45c0(param_1);
      iVar1 = (**(code **)(*param_1 + 0x38))();
    }
  }
  return param_1[0x5857];
}



/* FUNCTION 5092 ; VA 0x005bec80 ; FUN_005bec80 */

undefined4 __fastcall FUN_005bec80(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = param_1[0x584f];
  do {
    FUN_005b1df0(param_1);
    FUN_005b1df0(param_1);
    if ((param_1[0x584f] != 0) && (iVar3 = iVar3 + -1, iVar3 == 0)) {
      *(undefined2 *)(param_1 + 0x584b) = 0;
    }
    iVar1 = FUN_005b1fc0(param_1);
    if (iVar1 == 0) {
      iVar1 = FUN_005b4b50(param_1);
      if ((((iVar1 != 0) || (iVar1 = FUN_005bae80(param_1), iVar1 != 0)) ||
          (iVar1 = FUN_005b2950(param_1), iVar1 != 0)) ||
         ((iVar1 = (**(code **)(*param_1 + 0x40))(), iVar1 != 0 ||
          (((code *)param_1[0xc0a] != (code *)0x0 &&
           (iVar1 = (*(code *)param_1[0xc0a])(param_1), iVar1 != 0)))))) {
LAB_005bed33:
        uVar2 = FUN_005bbfe0(param_1);
        return uVar2;
      }
    }
    else {
      if (param_1[0x5857] < 1000) goto LAB_005bed33;
      FUN_005b2e00();
    }
    if (*(short *)(param_1 + 0x584b) == 0) {
      return 0;
    }
  } while( true );
}



/* FUNCTION 5093 ; VA 0x005bed40 ; FUN_005bed40 */

int FUN_005bed40(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01797f58;
  pvStack_10 = ExceptionList;
  ppuStack_24 = _ns1__BatchJobResponse::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598620(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005995f0(piVar1,&param_1,"-ns2:BatchJob",0);
  if (iVar2 != 0) {
    iVar2 = FUN_005b2aa0(piVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4f70(piVar1);
      if (iVar2 == 0) {
        iVar2 = FUN_005b4750(piVar1);
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar1 + 0x68))(param_1,&ppuStack_24);
          piVar1[0x5857] = iVar2;
          if (iVar2 != 0) goto LAB_005bef2c;
          _guard_check_icall(piVar1);
          FUN_005ac270(piVar1);
          iVar2 = FUN_005b1ea0(piVar1);
          if (iVar2 == 0) {
            if ((*(byte *)(piVar1 + 2) & 8) == 0) {
LAB_005bee95:
              iVar2 = FUN_005b4720(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005bb730(piVar1,0);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b4e30(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005aefa0(piVar1);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2a20(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005ab530(piVar1,"ns1:BatchJobResponse",&DAT_018bc9b8);
                        if (iVar2 == 0) {
                          iVar2 = FUN_005b2ad0(piVar1);
                          if (iVar2 == 0) {
                            iVar2 = FUN_005b4fa0(piVar1);
                            if (iVar2 == 0) {
                              iVar2 = FUN_005b4900(piVar1);
                              if (iVar2 == 0) {
                                iVar2 = FUN_005b2e00(piVar1);
                                goto LAB_005bef2c;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            else {
              iVar2 = FUN_005b4e30(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005aefa0(piVar1);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b2a20(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005ab530(piVar1,"ns1:BatchJobResponse",&DAT_018bc9b8);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2ad0(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005b4fa0(piVar1);
                        if (iVar2 == 0) goto LAB_005bee95;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = piVar1[0x5857];
LAB_005bef2c:
  FUN_0056e640();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 5094 ; VA 0x005bef50 ; FUN_005bef50 */

int FUN_005bef50(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01797f78;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__BatchJobExResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599630(piVar1,&param_1,"-ns2:BatchJobEx",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x6c))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac240(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005ab4e0(piVar1,"ns1:BatchJobExResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005ab4e0(piVar1,"ns1:BatchJobExResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5095 ; VA 0x005bf160 ; FUN_005bf160 */

int FUN_005bf160(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01797f98;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__CloseAllJobsResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599670(piVar1,&param_1,"-ns2:CloseAllJobs",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x80))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_00553510(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005ab5d0(piVar1,"ns1:CloseAllJobsResponse",&DAT_018bc9b8), iVar2 == 0
                && (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005ab5d0(piVar1,"ns1:CloseAllJobsResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5096 ; VA 0x005bf370 ; FUN_005bf370 */

int FUN_005bf370(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01797fb8;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__CloseExpiredJobsResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005996b0(piVar1,&param_1,"-ns2:CloseExpiredJobs",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x7c))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_00553510(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005ab670(piVar1,"ns1:CloseExpiredJobsResponse",&DAT_018bc9b8),
                iVar2 == 0 && (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005ab670(piVar1,"ns1:CloseExpiredJobsResponse",&DAT_018bc9b8), iVar2 == 0
             && ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
                 (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5097 ; VA 0x005bf580 ; FUN_005bf580 */

int FUN_005bf580(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01797fd8;
  pvStack_10 = ExceptionList;
  ppuStack_18 = _ns1__CloseJobResponse::vftable;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598640(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005996f0(piVar1,&param_1,"-ns2:CloseJob",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 100))(param_1,&ppuStack_18);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_00553510(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005ab710(piVar1,"ns1:CloseJobResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005ab710(piVar1,"ns1:CloseJobResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5098 ; VA 0x005bf790 ; FUN_005bf790 */

int FUN_005bf790(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01797ff8;
  pvStack_10 = ExceptionList;
  ppuStack_24 = _ns1__DiagResponse::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598620(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005997b0(piVar1,&param_1,"-ns2:Diag",0);
  if (iVar2 != 0) {
    iVar2 = FUN_005b2aa0(piVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4f70(piVar1);
      if (iVar2 == 0) {
        iVar2 = FUN_005b4750(piVar1);
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar1 + 0x84))(param_1,&ppuStack_24);
          piVar1[0x5857] = iVar2;
          if (iVar2 != 0) goto LAB_005bf97f;
          _guard_check_icall(piVar1);
          FUN_005ac270(piVar1);
          iVar2 = FUN_005b1ea0(piVar1);
          if (iVar2 == 0) {
            if ((*(byte *)(piVar1 + 2) & 8) == 0) {
LAB_005bf8e8:
              iVar2 = FUN_005b4720(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005bb730(piVar1,0);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b4e30(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005aefa0(piVar1);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2a20(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005ab850(piVar1,"ns1:DiagResponse",&DAT_018bc9b8);
                        if (iVar2 == 0) {
                          iVar2 = FUN_005b2ad0(piVar1);
                          if (iVar2 == 0) {
                            iVar2 = FUN_005b4fa0(piVar1);
                            if (iVar2 == 0) {
                              iVar2 = FUN_005b4900(piVar1);
                              if (iVar2 == 0) {
                                iVar2 = FUN_005b2e00(piVar1);
                                goto LAB_005bf97f;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            else {
              iVar2 = FUN_005b4e30(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005aefa0(piVar1);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b2a20(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005ab850(piVar1,"ns1:DiagResponse",&DAT_018bc9b8);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2ad0(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005b4fa0(piVar1);
                        if (iVar2 == 0) goto LAB_005bf8e8;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = piVar1[0x5857];
LAB_005bf97f:
  FUN_00596470();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 5099 ; VA 0x005bf9a0 ; FUN_005bf9a0 */

int FUN_005bf9a0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798018;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__DiagExResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005997f0(piVar1,&param_1,"-ns2:DiagEx",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x88))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac240(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005ab800(piVar1,"ns1:DiagExResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005ab800(piVar1,"ns1:DiagExResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5100 ; VA 0x005bfbb0 ; FUN_005bfbb0 */

int FUN_005bfbb0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798038;
  pvStack_10 = ExceptionList;
  ppuStack_24 = _ns1__ExecuteResponse::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598620(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599830(piVar1,&param_1,"-ns2:Execute",0);
  if (iVar2 != 0) {
    iVar2 = FUN_005b2aa0(piVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4f70(piVar1);
      if (iVar2 == 0) {
        iVar2 = FUN_005b4750(piVar1);
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar1 + 0x5c))(param_1,&ppuStack_24);
          piVar1[0x5857] = iVar2;
          if (iVar2 != 0) goto LAB_005bfd9c;
          _guard_check_icall(piVar1);
          FUN_005ac270(piVar1);
          iVar2 = FUN_005b1ea0(piVar1);
          if (iVar2 == 0) {
            if ((*(byte *)(piVar1 + 2) & 8) == 0) {
LAB_005bfd05:
              iVar2 = FUN_005b4720(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005bb730(piVar1,0);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b4e30(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005aefa0(piVar1);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2a20(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005ab990(piVar1,"ns1:ExecuteResponse",&DAT_018bc9b8);
                        if (iVar2 == 0) {
                          iVar2 = FUN_005b2ad0(piVar1);
                          if (iVar2 == 0) {
                            iVar2 = FUN_005b4fa0(piVar1);
                            if (iVar2 == 0) {
                              iVar2 = FUN_005b4900(piVar1);
                              if (iVar2 == 0) {
                                iVar2 = FUN_005b2e00(piVar1);
                                goto LAB_005bfd9c;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            else {
              iVar2 = FUN_005b4e30(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005aefa0(piVar1);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b2a20(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005ab990(piVar1,"ns1:ExecuteResponse",&DAT_018bc9b8);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2ad0(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005b4fa0(piVar1);
                        if (iVar2 == 0) goto LAB_005bfd05;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = piVar1[0x5857];
LAB_005bfd9c:
  FUN_005965a0();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 5101 ; VA 0x005bfdc0 ; FUN_005bfdc0 */

int FUN_005bfdc0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798058;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__ExecuteExResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005998f0(piVar1,&param_1,"-ns2:ExecuteEx",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x60))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac240(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005ab940(piVar1,"ns1:ExecuteExResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005ab940(piVar1,"ns1:ExecuteExResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5102 ; VA 0x005bffd0 ; FUN_005bffd0 */

int FUN_005bffd0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798078;
  pvStack_10 = ExceptionList;
  ppuStack_24 = _ns1__GetAllJobsResponse::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598620(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005999b0(piVar1,&param_1,"-ns2:GetAllJobs",0);
  if (iVar2 != 0) {
    iVar2 = FUN_005b2aa0(piVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4f70(piVar1);
      if (iVar2 == 0) {
        iVar2 = FUN_005b4750(piVar1);
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar1 + 0x74))(param_1,&ppuStack_24);
          piVar1[0x5857] = iVar2;
          if (iVar2 != 0) goto LAB_005c01bc;
          _guard_check_icall(piVar1);
          FUN_005ac340(piVar1);
          iVar2 = FUN_005b1ea0(piVar1);
          if (iVar2 == 0) {
            if ((*(byte *)(piVar1 + 2) & 8) == 0) {
LAB_005c0125:
              iVar2 = FUN_005b4720(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005bb730(piVar1,0);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b4e30(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005aefa0(piVar1);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2a20(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005abad0(piVar1,"ns1:GetAllJobsResponse",&DAT_018bc9b8);
                        if (iVar2 == 0) {
                          iVar2 = FUN_005b2ad0(piVar1);
                          if (iVar2 == 0) {
                            iVar2 = FUN_005b4fa0(piVar1);
                            if (iVar2 == 0) {
                              iVar2 = FUN_005b4900(piVar1);
                              if (iVar2 == 0) {
                                iVar2 = FUN_005b2e00(piVar1);
                                goto LAB_005c01bc;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            else {
              iVar2 = FUN_005b4e30(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005aefa0(piVar1);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b2a20(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005abad0(piVar1,"ns1:GetAllJobsResponse",&DAT_018bc9b8);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2ad0(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005b4fa0(piVar1);
                        if (iVar2 == 0) goto LAB_005c0125;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = piVar1[0x5857];
LAB_005c01bc:
  FUN_00596630();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 5103 ; VA 0x005c01e0 ; FUN_005c01e0 */

int FUN_005c01e0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798098;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__GetAllJobsExResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_005999f0(piVar1,&param_1,"-ns2:GetAllJobsEx",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x78))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac310(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005aba80(piVar1,"ns1:GetAllJobsExResponse",&DAT_018bc9b8), iVar2 == 0
                && (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005aba80(piVar1,"ns1:GetAllJobsExResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5104 ; VA 0x005c03f0 ; FUN_005c03f0 */

int FUN_005c03f0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **appuStack_28 [2];
  undefined8 uStack_20;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_017980b8;
  pvStack_10 = ExceptionList;
  appuStack_28[0] = _ns1__GetExpirationResponse::vftable;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005986b0(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599a30(piVar1,&param_1,"-ns2:GetExpiration",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x70))(param_1,appuStack_28);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_00553510(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005abb70(piVar1,"ns1:GetExpirationResponse",&DAT_018bc9b8), iVar2 == 0
                && (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005abb70(piVar1,"ns1:GetExpirationResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5105 ; VA 0x005c0600 ; FUN_005c0600 */

int FUN_005c0600(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_017980d8;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__GetStatusResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599af0(piVar1,&param_1,"-ns2:GetStatus",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x4c))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac360(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005abc10(piVar1,"ns1:GetStatusResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005abc10(piVar1,"ns1:GetStatusResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5106 ; VA 0x005c0810 ; FUN_005c0810 */

int FUN_005c0810(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined **ppuStack_30;
  uint uStack_2c;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_017980f8;
  pvStack_10 = ExceptionList;
  ppuStack_30 = _ns1__GetVersionResponse::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598650(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599b30(piVar1,&param_1,"-ns2:GetVersion",0);
  if (iVar2 != 0) {
    iVar2 = FUN_005b2aa0(piVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4f70(piVar1);
      if (iVar2 == 0) {
        iVar2 = FUN_005b4750(piVar1);
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar1 + 0x48))(param_1,&ppuStack_30);
          piVar1[0x5857] = iVar2;
          if (iVar2 != 0) goto LAB_005c0a0e;
          _guard_check_icall(piVar1);
          FUN_005ac290(piVar1);
          iVar2 = FUN_005b1ea0(piVar1);
          if (iVar2 == 0) {
            if ((*(byte *)(piVar1 + 2) & 8) == 0) {
LAB_005c0977:
              iVar2 = FUN_005b4720(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005bb730(piVar1,0);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b4e30(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005aefa0(piVar1);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2a20(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005abcb0(piVar1,"ns1:GetVersionResponse",&DAT_018bc9b8);
                        if (iVar2 == 0) {
                          iVar2 = FUN_005b2ad0(piVar1);
                          if (iVar2 == 0) {
                            iVar2 = FUN_005b4fa0(piVar1);
                            if (iVar2 == 0) {
                              iVar2 = FUN_005b4900(piVar1);
                              if (iVar2 == 0) {
                                iVar2 = FUN_005b2e00(piVar1);
                                goto LAB_005c0a0e;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            else {
              iVar2 = FUN_005b4e30(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005aefa0(piVar1);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b2a20(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005abcb0(piVar1,"ns1:GetVersionResponse",&DAT_018bc9b8);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2ad0(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005b4fa0(piVar1);
                        if (iVar2 == 0) goto LAB_005c0977;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = piVar1[0x5857];
LAB_005c0a0e:
  ppuStack_30 = _ns1__GetVersionResponse::vftable;
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar3 = uStack_2c;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(uStack_2c - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 5107 ; VA 0x005c0a60 ; FUN_005c0a60 */

int FUN_005c0a60(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798118;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__HelloWorldResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599b70(piVar1,&param_1,"-ns2:HelloWorld",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x44))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac390(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005abd50(piVar1,"ns1:HelloWorldResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005abd50(piVar1,"ns1:HelloWorldResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5108 ; VA 0x005c0c70 ; FUN_005c0c70 */

int FUN_005c0c70(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798138;
  pvStack_10 = ExceptionList;
  ppuStack_24 = _ns1__OpenJobResponse::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598620(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599bb0(piVar1,&param_1,"-ns2:OpenJob",0);
  if (iVar2 != 0) {
    iVar2 = FUN_005b2aa0(piVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4f70(piVar1);
      if (iVar2 == 0) {
        iVar2 = FUN_005b4750(piVar1);
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar1 + 0x50))(param_1,&ppuStack_24);
          piVar1[0x5857] = iVar2;
          if (iVar2 != 0) goto LAB_005c0e5c;
          _guard_check_icall(piVar1);
          FUN_005ac270(piVar1);
          iVar2 = FUN_005b1ea0(piVar1);
          if (iVar2 == 0) {
            if ((*(byte *)(piVar1 + 2) & 8) == 0) {
LAB_005c0dc5:
              iVar2 = FUN_005b4720(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005bb730(piVar1,0);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b4e30(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005aefa0(piVar1);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2a20(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005abe90(piVar1,"ns1:OpenJobResponse",&DAT_018bc9b8);
                        if (iVar2 == 0) {
                          iVar2 = FUN_005b2ad0(piVar1);
                          if (iVar2 == 0) {
                            iVar2 = FUN_005b4fa0(piVar1);
                            if (iVar2 == 0) {
                              iVar2 = FUN_005b4900(piVar1);
                              if (iVar2 == 0) {
                                iVar2 = FUN_005b2e00(piVar1);
                                goto LAB_005c0e5c;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            else {
              iVar2 = FUN_005b4e30(piVar1);
              if (iVar2 == 0) {
                iVar2 = FUN_005aefa0(piVar1);
                if (iVar2 == 0) {
                  iVar2 = FUN_005b2a20(piVar1);
                  if (iVar2 == 0) {
                    iVar2 = FUN_005abe90(piVar1,"ns1:OpenJobResponse",&DAT_018bc9b8);
                    if (iVar2 == 0) {
                      iVar2 = FUN_005b2ad0(piVar1);
                      if (iVar2 == 0) {
                        iVar2 = FUN_005b4fa0(piVar1);
                        if (iVar2 == 0) goto LAB_005c0dc5;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = piVar1[0x5857];
LAB_005c0e5c:
  FUN_0056e6b0();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 5109 ; VA 0x005c0e80 ; FUN_005c0e80 */

int FUN_005c0e80(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **ppuStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798158;
  pvStack_10 = ExceptionList;
  ppuStack_1c = _ns1__OpenJobExResponse::vftable;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00598600(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599bf0(piVar1,&param_1,"-ns2:OpenJobEx",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x54))(param_1,&ppuStack_1c);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_005ac240(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005abe40(piVar1,"ns1:OpenJobExResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005abe40(piVar1,"ns1:OpenJobExResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5110 ; VA 0x005c1090 ; FUN_005c1090 */

int FUN_005c1090(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined **appuStack_28 [2];
  undefined8 uStack_20;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  puStack_c = &LAB_01798178;
  pvStack_10 = ExceptionList;
  appuStack_28[0] = _ns1__RenewLeaseResponse::vftable;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005986b0(param_1);
  FUN_00598770(piVar1,&param_1);
  piVar1[10] = 0;
  iVar2 = FUN_00599c30(piVar1,&param_1,"-ns2:RenewLease",0);
  if ((((iVar2 != 0) && (iVar2 = FUN_005b2aa0(piVar1), iVar2 == 0)) &&
      (iVar2 = FUN_005b4f70(piVar1), iVar2 == 0)) && (iVar2 = FUN_005b4750(piVar1), iVar2 == 0)) {
    iVar2 = (**(code **)(*piVar1 + 0x58))(param_1,appuStack_28);
    piVar1[0x5857] = iVar2;
    if (iVar2 != 0) {
      ExceptionList = pvStack_10;
      return iVar2;
    }
    _guard_check_icall(piVar1);
    FUN_00553510(piVar1);
    iVar2 = FUN_005b1ea0(piVar1);
    if (((iVar2 == 0) &&
        (((*(byte *)(piVar1 + 2) & 8) == 0 ||
         ((((iVar2 = FUN_005b4e30(piVar1), iVar2 == 0 && (iVar2 = FUN_005aefa0(piVar1), iVar2 == 0))
           && ((iVar2 = FUN_005b2a20(piVar1), iVar2 == 0 &&
               ((iVar2 = FUN_005abf30(piVar1,"ns1:RenewLeaseResponse",&DAT_018bc9b8), iVar2 == 0 &&
                (iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0)))))) &&
          (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))))) &&
       (((((iVar2 = FUN_005b4720(piVar1), iVar2 == 0 && (iVar2 = FUN_005bb730(piVar1,0), iVar2 == 0)
           ) && (iVar2 = FUN_005b4e30(piVar1), iVar2 == 0)) &&
         ((iVar2 = FUN_005aefa0(piVar1), iVar2 == 0 && (iVar2 = FUN_005b2a20(piVar1), iVar2 == 0))))
        && (((iVar2 = FUN_005abf30(piVar1,"ns1:RenewLeaseResponse",&DAT_018bc9b8), iVar2 == 0 &&
             ((iVar2 = FUN_005b2ad0(piVar1), iVar2 == 0 &&
              (iVar2 = FUN_005b4fa0(piVar1), iVar2 == 0)))) &&
            (iVar2 = FUN_005b4900(piVar1), iVar2 == 0)))))) {
      iVar2 = FUN_005b2e00(piVar1);
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  ExceptionList = pvStack_10;
  return piVar1[0x5857];
}



/* FUNCTION 5111 ; VA 0x005c12a0 ; FUN_005c12a0 */

void __fastcall FUN_005c12a0(undefined4 param_1)

{
  FUN_005b2e00(param_1);
  return;
}



/* FUNCTION 5112 ; VA 0x005c12b0 ; FUN_005c12b0 */

void __fastcall FUN_005c12b0(int param_1)

{
  *(undefined4 *)(param_1 + 0x2fac) = 0;
  return;
}



/* FUNCTION 5113 ; VA 0x005c12c0 ; FUN_005c12c0 */

void __thiscall FUN_005c12c0(undefined4 param_1,undefined4 param_2)

{
  FUN_005b9a50(param_1,param_2);
  return;
}



/* FUNCTION 5114 ; VA 0x005c12e0 ; FUN_005c12e0 */

void __thiscall
FUN_005c12e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005bac50(param_1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 5115 ; VA 0x005c1300 ; FUN_005c1300 */

void __thiscall FUN_005c1300(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005bac20(param_1,param_2,param_3);
  return;
}



/* FUNCTION 5116 ; VA 0x005c1320 ; FUN_005c1320 */

void __thiscall
FUN_005c1320(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005bc400(param_1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 5117 ; VA 0x005c1340 ; FUN_005c1340 */

void __thiscall FUN_005c1340(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005bc3d0(param_1,param_2,param_3);
  return;
}



/* FUNCTION 5118 ; VA 0x005c1360 ; FUN_005c1360 */

void __thiscall FUN_005c1360(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005bd090(param_1,param_2,param_3);
  return;
}



/* FUNCTION 5119 ; VA 0x005c1380 ; FUN_005c1380 */

void __thiscall FUN_005c1380(undefined4 param_1,undefined4 param_2)

{
  FUN_005bd200(param_1,param_2);
  return;
}



/* FUNCTION 5120 ; VA 0x005c13a0 ; FUN_005c13a0 */

undefined4 * __thiscall FUN_005c13a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088c8c0();
  *param_1 = uVar1;
  param_1[1] = 0;
  param_1[2] = *param_2;
  uVar1 = FUN_005c9cc0();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 5121 ; VA 0x005c13e0 ; FUN_005c13e0 */

undefined4 * __thiscall FUN_005c13e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088cb40();
  *param_1 = uVar1;
  param_1[1] = 0;
  FUN_0054ef60(param_2);
  uVar1 = FUN_005c9d30();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 5122 ; VA 0x005c1420 ; FUN_005c1420 */

undefined4 * __thiscall FUN_005c1420(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_008882f0();
  *param_1 = uVar2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  uVar2 = FUN_005c9da0();
  param_1[1] = uVar2;
  return param_1;
}



/* FUNCTION 5123 ; VA 0x005c1470 ; FUN_005c1470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005c1470(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_0088da50();
  iVar1 = _tls_index;
  *param_1 = uVar2;
  param_1[1] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ea8c28) {
    FUN_016f3809(&DAT_01ea8c28);
    if (DAT_01ea8c28 == -1) {
      DAT_01ea8c1c = FUN_005c6620;
      _DAT_01ea8c20 = FUN_005c6620;
      DAT_01ea8c24 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c28);
    }
  }
  param_1[1] = &DAT_01ea8c1c;
  return param_1;
}



/* FUNCTION 5124 ; VA 0x005c1510 ; FUN_005c1510 */

undefined4 * __thiscall FUN_005c1510(undefined4 *param_1,undefined *param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_0088daf0();
  iVar1 = _tls_index;
  *param_1 = uVar2;
  param_1[1] = 0;
  *(undefined *)(param_1 + 2) = *param_2;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ea8bf8) {
    FUN_016f3809(&DAT_01ea8bf8);
    if (DAT_01ea8bf8 == -1) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
  }
  param_1[1] = &DAT_01ea8bec;
  return param_1;
}



/* FUNCTION 5125 ; VA 0x005c15a0 ; FUN_005c15a0 */

undefined4 * __thiscall FUN_005c15a0(undefined4 *param_1,undefined4 *param_2)

{
  void *pvVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_008881d0();
  *param_1 = uVar2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  pvVar1 = ThreadLocalStoragePointer;
  *param_2 = 0;
  param_2[1] = 0;
  if (*(int *)(*(int *)((int)pvVar1 + _tls_index * 4) + 0x34) < DAT_01ea8a9c) {
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
  }
  param_1[1] = &DAT_01ea8a90;
  return param_1;
}



/* FUNCTION 5126 ; VA 0x005c1650 ; FUN_005c1650 */

undefined4 * __thiscall FUN_005c1650(undefined4 *param_1,undefined *param_2)

{
  int iVar1;
  
  iVar1 = _tls_index;
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = *param_2;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ea8bf8) {
    FUN_016f3809(&DAT_01ea8bf8);
    if (DAT_01ea8bf8 == -1) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
  }
  *param_1 = &DAT_01ea8bec;
  return param_1;
}



/* FUNCTION 5127 ; VA 0x005c16d0 ; FUN_005c16d0 */

undefined4 * __thiscall FUN_005c16d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar3 = FUN_0088cb40();
  *param_1 = uVar3;
  iVar4 = FUN_005c9d30();
  iVar2 = param_1[1];
  if (iVar2 == iVar4) {
    if (param_1 + 2 != param_2) {
      puVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_005542c0(param_2,*puVar1);
      return param_1;
    }
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(param_1 + 2);
      param_1[1] = 0;
    }
    FUN_0054ef60(param_2);
    param_1[1] = iVar4;
  }
  return param_1;
}



/* FUNCTION 5128 ; VA 0x005c1740 ; FUN_005c1740 */

undefined4 * __thiscall FUN_005c1740(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_0088c8c0();
  *param_1 = uVar2;
  iVar3 = FUN_005c9cc0();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 5129 ; VA 0x005c17a0 ; FUN_005c17a0 */

int * __thiscall FUN_005c17a0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = FUN_005c9d30();
  iVar2 = *param_1;
  if (iVar2 == iVar3) {
    if (param_1 + 1 != param_2) {
      piVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,*piVar1);
      return param_1;
    }
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(param_1 + 1);
      *param_1 = 0;
    }
    FUN_0054ef60(param_2);
    *param_1 = iVar3;
  }
  return param_1;
}



/* FUNCTION 5130 ; VA 0x005c1810 ; FUN_005c1810 */

undefined4 * __thiscall FUN_005c1810(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  
  uVar5 = FUN_008882f0();
  *param_1 = uVar5;
  iVar6 = FUN_005c9da0();
  iVar2 = param_1[1];
  if (iVar2 == iVar6) {
    uVar5 = *param_2;
    uVar3 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[2] = uVar5;
    piVar4 = (int *)param_1[3];
    param_1[3] = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[1] + -1;
      piVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      return param_1;
    }
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(param_1 + 2);
      param_1[1] = 0;
    }
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[2] = *param_2;
    param_1[3] = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[1] = iVar6;
  }
  return param_1;
}



/* FUNCTION 5131 ; VA 0x005c1970 ; FUN_005c1970 */

int __thiscall FUN_005c1970(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar6 = *param_1;
  iVar3 = (int)(param_1[1] - uVar6) >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - uVar6) >> 3;
  uVar8 = uVar1;
  if ((uVar5 <= 0x1fffffff - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar5 = uVar8 * 8;
  if (uVar8 < 0x20000000) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_005c19df;
    if (uVar5 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_005c19df:
    uVar4 = uVar8 + 0x23;
    if (uVar4 <= uVar8) {
      uVar4 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar4);
    if (iVar3 == 0) goto LAB_005c1ae5;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar6) >> 3) * 8;
  *(undefined4 *)(iVar3 + uVar8) = 0;
  *(undefined4 *)(iVar3 + 4 + uVar8) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + uVar8) = *param_3;
  *(undefined4 *)(iVar3 + 4 + uVar8) = param_3[1];
  uVar4 = param_1[1];
  uVar6 = *param_1;
  uVar7 = uVar8;
  if (param_2 != uVar4) {
    FUN_005c23f0(uVar6,param_2,uVar8,param_1);
    uVar4 = param_1[1];
    uVar7 = iVar3 + 8 + uVar8;
    uVar6 = param_2;
  }
  FUN_005c23f0(uVar6,uVar4,uVar7,param_1);
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    uVar6 = *param_1;
    uVar7 = param_1[2] - uVar6 & 0xfffffff8;
    uVar4 = uVar6;
    if (0xfff < uVar7) {
      uVar4 = *(uint *)(uVar6 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar6 - uVar4) - 4) {
LAB_005c1ae5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar7);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + uVar1 * 8;
  param_1[2] = uVar5 + uVar8;
  return *param_1 + iVar3;
}



/* FUNCTION 5132 ; VA 0x005c1af0 ; FUN_005c1af0 */

void __thiscall FUN_005c1af0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798190;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5133 ; VA 0x005c1b5e ; Catch_All@005c1b5e */

void Catch_All_005c1b5e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00573060(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5134 ; VA 0x005c1b80 ; FUN_005c1b80 */

int __thiscall FUN_005c1b80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017981a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::BloomEffect>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5135 ; VA 0x005c1c54 ; Catch_All@005c1c54 */

void Catch_All_005c1c54(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5136 ; VA 0x005c1c70 ; FUN_005c1c70 */

int __thiscall FUN_005c1c70(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017981b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ColorCorrectionEffect*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5137 ; VA 0x005c1d42 ; Catch_All@005c1d42 */

void Catch_All_005c1d42(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5138 ; VA 0x005c1d60 ; FUN_005c1d60 */

int __thiscall FUN_005c1d60(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017981c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ContentProvider*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5139 ; VA 0x005c1e32 ; Catch_All@005c1e32 */

void Catch_All_005c1e32(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5140 ; VA 0x005c1e50 ; FUN_005c1e50 */

int __thiscall FUN_005c1e50(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017981d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::HttpService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5141 ; VA 0x005c1f22 ; Catch_All@005c1f22 */

void Catch_All_005c1f22(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5142 ; VA 0x005c1f40 ; FUN_005c1f40 */

int __thiscall FUN_005c1f40(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017981e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Lighting*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5143 ; VA 0x005c2012 ; Catch_All@005c2012 */

void Catch_All_005c2012(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5144 ; VA 0x005c2030 ; FUN_005c2030 */

int __thiscall FUN_005c2030(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017981f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::MeshContentProvider*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5145 ; VA 0x005c2102 ; Catch_All@005c2102 */

void Catch_All_005c2102(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5146 ; VA 0x005c2120 ; FUN_005c2120 */

int __thiscall FUN_005c2120(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798200;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ModuleScript*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5147 ; VA 0x005c21f2 ; Catch_All@005c21f2 */

void Catch_All_005c21f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5148 ; VA 0x005c2210 ; FUN_005c2210 */

int __thiscall FUN_005c2210(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798210;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Selection*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5149 ; VA 0x005c22e2 ; Catch_All@005c22e2 */

void Catch_All_005c22e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5150 ; VA 0x005c2300 ; FUN_005c2300 */

int __thiscall FUN_005c2300(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798220;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::SolidModelContentProvider*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5151 ; VA 0x005c23d2 ; Catch_All@005c23d2 */

void Catch_All_005c23d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5152 ; VA 0x005c23f0 ; FUN_005c23f0 */

undefined4 *
FUN_005c23f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_1;
  puVar2 = param_3;
  if (param_1 != param_2) {
    do {
      *puVar2 = 0;
      puVar2[1] = 0;
      *puVar2 = *puVar1;
      puVar2[1] = *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar2);
      *puVar1 = 0;
      puVar1 = puVar1 + 2;
      *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar2) = 0;
      puVar2 = puVar2 + 2;
    } while (puVar1 != param_2);
  }
  FUN_005596d0(puVar2,puVar2,param_4);
  return puVar2;
}



/* FUNCTION 5153 ; VA 0x005c24c0 ; FUN_005c24c0 */

void __thiscall FUN_005c24c0(int param_1,undefined4 *param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_3 * 4;
  *(uint *)(param_1 + 0xc) = param_3;
  if (param_3 < 0x40000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = FUN_01674e20(uVar3);
      }
      goto LAB_005c251d;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  uVar3 = iVar2 + 0x23U & 0xffffffe0;
  *(int *)(uVar3 - 4) = iVar2;
LAB_005c251d:
  *(uint *)(param_1 + 4) = uVar3;
  *(uint *)(param_1 + 8) = uVar3;
  uVar1 = uVar3 + *(int *)(param_1 + 0xc) * 4;
  while (uVar3 != uVar1) {
    **(undefined4 **)(param_1 + 8) = *param_2;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 4;
    uVar3 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 5154 ; VA 0x005c2550 ; FUN_005c2550 */

void __thiscall FUN_005c2550(int param_1,int param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005c6580();
  iVar1 = *(int *)(param_1 + 4);
  FUN_0054ef60(param_2);
  *(undefined4 *)(iVar1 + 0x20) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(iVar1 + 0x24) = 0;
  uStack_8 = 0;
  if (*(undefined4 **)(param_2 + 0x1c) == (undefined4 *)0x0) {
    *(undefined4 *)(iVar1 + 0x24) = 0;
  }
  else {
    (*(code *)**(undefined4 **)(param_2 + 0x1c))(param_2 + 0x20,iVar1 + 0x28);
    *(undefined4 *)(iVar1 + 0x24) = *(undefined4 *)(param_2 + 0x1c);
  }
  *(undefined *)(param_1 + 9) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5155 ; VA 0x005c25e0 ; FUN_005c25e0 */

undefined4 * FUN_005c25e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798260;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009d9830();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009d9930();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c1c70(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5156 ; VA 0x005c26a0 ; FUN_005c26a0 */

undefined4 * FUN_005c26a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017982a3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008bd840();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x150);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_008c27c0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c1d60(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5157 ; VA 0x005c2760 ; FUN_005c2760 */

int FUN_005c2760(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017982b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8c5c,&LAB_005c2460);
  uVar2 = FUN_005c36d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_008bd920();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005c26a0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8c5c,&LAB_005c2460);
      uVar2 = FUN_005c36d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5158 ; VA 0x005c28f0 ; FUN_005c28f0 */

undefined4 FUN_005c28f0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005c2760();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 5159 ; VA 0x005c2950 ; FUN_005c2950 */

undefined4 * FUN_005c2950(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798303;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009e1b40();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x158);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009e28d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c1e50(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5160 ; VA 0x005c2a10 ; FUN_005c2a10 */

int FUN_005c2a10(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798318;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8c64,&LAB_005c2470);
  uVar2 = FUN_005c3750();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009e1c40();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005c2950(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8c64,&LAB_005c2470);
      uVar2 = FUN_005c3750();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5161 ; VA 0x005c2ba0 ; FUN_005c2ba0 */

undefined4 * FUN_005c2ba0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798363;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009d5f50();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x150);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009d6b40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c1f40(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5162 ; VA 0x005c2c60 ; FUN_005c2c60 */

int FUN_005c2c60(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798378;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8c74,&LAB_005c2480);
  uVar2 = FUN_005c37d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009d6050();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005c2ba0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8c74,&LAB_005c2480);
      uVar2 = FUN_005c37d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5163 ; VA 0x005c2df0 ; FUN_005c2df0 */

undefined4 FUN_005c2df0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005c2c60();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 5164 ; VA 0x005c2e50 ; FUN_005c2e50 */

undefined4 * FUN_005c2e50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017983c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009de430();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xd0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009de530();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c2030(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5165 ; VA 0x005c2f20 ; FUN_005c2f20 */

int FUN_005c2f20(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017983d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8c4c,&LAB_005c2490);
  uVar2 = FUN_005c3850();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009de510();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005c2e50(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8c4c,&LAB_005c2490);
      uVar2 = FUN_005c3850();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5166 ; VA 0x005c30b0 ; FUN_005c30b0 */

undefined4 * FUN_005c30b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798423;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009ec190();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x108);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009ec440();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c2120(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5167 ; VA 0x005c3170 ; FUN_005c3170 */

undefined4 * FUN_005c3170(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798463;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009df5a0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009dfad0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c2210(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5168 ; VA 0x005c3230 ; FUN_005c3230 */

int FUN_005c3230(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798478;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8c6c,&LAB_005c24a0);
  uVar2 = FUN_005c38d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009df680();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005c3170(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8c6c,&LAB_005c24a0);
      uVar2 = FUN_005c38d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5169 ; VA 0x005c33c0 ; FUN_005c33c0 */

undefined4 FUN_005c33c0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005c3230();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 5170 ; VA 0x005c3420 ; FUN_005c3420 */

undefined4 * FUN_005c3420(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017984c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009decf0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xcc);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009dedf0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c2300(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5171 ; VA 0x005c34e0 ; FUN_005c34e0 */

int FUN_005c34e0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017984d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8c54,&LAB_005c24b0);
  uVar2 = FUN_005c3950();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009dedd0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005c3420(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8c54,&LAB_005c24b0);
      uVar2 = FUN_005c3950();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5172 ; VA 0x005c3670 ; FUN_005c3670 */

undefined4 FUN_005c3670(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005c34e0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 5173 ; VA 0x005c36d0 ; FUN_005c36d0 */

undefined4 FUN_005c36d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017984fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c90) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8c90);
    if (DAT_01ea8c90 == -1) {
      uStack_8 = 0;
      DAT_01ea8c8c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8c90);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8c8c;
}



/* FUNCTION 5174 ; VA 0x005c3750 ; FUN_005c3750 */

undefined4 FUN_005c3750(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179851c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c98) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8c98);
    if (DAT_01ea8c98 == -1) {
      uStack_8 = 0;
      DAT_01ea8c94 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8c98);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8c94;
}



/* FUNCTION 5175 ; VA 0x005c37d0 ; FUN_005c37d0 */

undefined4 FUN_005c37d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179853c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8ca8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8ca8);
    if (DAT_01ea8ca8 == -1) {
      uStack_8 = 0;
      DAT_01ea8ca4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8ca8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8ca4;
}



/* FUNCTION 5176 ; VA 0x005c3850 ; FUN_005c3850 */

undefined4 FUN_005c3850(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179855c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c80) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8c80);
    if (DAT_01ea8c80 == -1) {
      uStack_8 = 0;
      DAT_01ea8c7c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8c80);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8c7c;
}



/* FUNCTION 5177 ; VA 0x005c38d0 ; FUN_005c38d0 */

undefined4 FUN_005c38d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179857c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8ca0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8ca0);
    if (DAT_01ea8ca0 == -1) {
      uStack_8 = 0;
      DAT_01ea8c9c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8ca0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8c9c;
}



/* FUNCTION 5178 ; VA 0x005c3950 ; FUN_005c3950 */

undefined4 FUN_005c3950(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179859c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c88) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8c88);
    if (DAT_01ea8c88 == -1) {
      uStack_8 = 0;
      DAT_01ea8c84 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8c88);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8c84;
}



/* FUNCTION 5179 ; VA 0x005c39d0 ; FUN_005c39d0 */

void FUN_005c39d0(int param_1,int param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  int iStack_d4;
  undefined4 auStack_9c [26];
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017985bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_1c = uStack_1c & 0xffffff00;
  uStack_8 = 0;
  FUN_005c3e00(param_1,param_2 + param_1,uStack_1c,
               *(undefined4 *)((int)auStack_9c + *(int *)(iStack_d4 + 4)),auStack_14,param_4);
  FUN_0058c420(&iStack_34);
  if (param_3 == &iStack_34) {
    if (0xf < uStack_20) {
      uVar2 = uStack_20 + 1;
      iVar1 = iStack_34;
      if (0xfff < uVar2) {
        iVar1 = *(int *)(iStack_34 + -4);
        uVar2 = uStack_20 + 0x24;
        if (0x1f < (iStack_34 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar2);
    }
  }
  else {
    FUN_005507b0();
    *param_3 = iStack_34;
    param_3[1] = iStack_30;
    param_3[2] = iStack_2c;
    param_3[3] = iStack_28;
    *(ulonglong *)(param_3 + 4) = CONCAT44(uStack_20,uStack_24);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5180 ; VA 0x005c3ac0 ; FUN_005c3ac0 */

int FUN_005c3ac0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
      uVar3 = FUN_00560f40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_008aa950();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 5181 ; VA 0x005c3bd0 ; FUN_005c3bd0 */

undefined8 * __thiscall FUN_005c3bd0(int *param_1,undefined8 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  int *piVar6;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088d870();
  if (iVar1 != iVar3) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined8 *)FUN_0088b880();
    uVar2 = *(undefined4 *)(puVar5 + 1);
    *param_2 = *puVar5;
    *(undefined4 *)(param_2 + 1) = uVar2;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar3 = FUN_0088d870();
  if (iVar1 == iVar3) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    iVar1 = piVar6[2];
    *param_2 = *(undefined8 *)piVar6;
    *(int *)(param_2 + 1) = iVar1;
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5182 ; VA 0x005c3cd0 ; FUN_005c3cd0 */

undefined4 * FUN_005c3cd0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179860c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = GetProcessHeap(0,0x40);
  puVar2 = (undefined4 *)HeapAlloc(uVar1);
  if (puVar2 == (undefined4 *)0x0) {
    uVar1 = FUN_0054fbc0();
    uStack_8 = 0;
    FUN_005648a0(uVar1);
  }
  else {
    *puVar2 = boost::detail::thread_data_base::vftable;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    uVar1 = FUN_00575ab0();
    puVar2[4] = uVar1;
    puVar2[6] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
    puVar2[9] = 0;
    puVar2[10] = 0;
    puVar2[0xb] = 0;
    puVar2[0xc] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar3 = CreateEventA(0,1,0,0);
    if (iVar3 != 0) {
      puVar2[0xd] = iVar3;
      *(undefined *)(puVar2 + 0xe) = 1;
      *puVar2 = boost::detail::thread_data<void_(__cdecl*)(void)>::vftable;
      puVar2[0xf] = *param_1;
      ExceptionList = pvStack_10;
      return puVar2;
    }
  }
  uVar1 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar1);
}



/* FUNCTION 5183 ; VA 0x005c3dc3 ; Catch_All@005c3dc3 */

void Catch_All_005c3dc3(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5184 ; VA 0x005c3e00 ; FUN_005c3e00 */

byte * FUN_005c3e00(byte *param_1,byte *param_2,undefined4 param_3,int *param_4)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  undefined *puVar5;
  byte *pbVar6;
  bool bVar7;
  undefined uVar8;
  int iStack_c;
  
  iStack_c = 0;
  pbVar6 = param_1;
  if (param_1 != param_2) {
    while( true ) {
      bVar1 = *param_1;
      pbVar6 = param_1 + 1;
      if (pbVar6 == param_2) break;
      bVar2 = *pbVar6;
      pbVar6 = param_1 + 2;
      if (pbVar6 == param_2) {
        FUN_0056ec80((&DAT_01d594a0)[(uint)(bVar1 >> 2) * 4]);
        FUN_0056ec80((&DAT_01d594a0)[((uint)(bVar2 >> 4) + (bVar1 & 3) * 0x10) * 4]);
        uVar8 = (&DAT_01d594a0)[(bVar2 & 0xf) * 0x10];
        goto LAB_005c4053;
      }
      bVar3 = *pbVar6;
      param_1 = param_1 + 3;
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d594a0)[(uint)(bVar1 >> 2) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_005c3e99;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_005c3e99:
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d594a0)[((bVar1 & 3) * 0x10 + (uint)(bVar2 >> 4)) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_005c3efc;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_005c3efc:
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d594a0)[((uint)(bVar3 >> 6) + (bVar2 & 0xf) * 4) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_005c3f5d;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_005c3f5d:
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d594a0)[(bVar3 & 0x3f) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_005c3fb3;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_005c3fb3:
      bVar7 = iStack_c != 0x11;
      iVar4 = iStack_c + 1;
      iStack_c = 0;
      if (bVar7) {
        iStack_c = iVar4;
      }
      if (param_1 == param_2) {
        return param_1;
      }
    }
    FUN_0056ec80((&DAT_01d594a0)[(uint)(bVar1 >> 2) * 4]);
    FUN_0056ec80((&DAT_01d594a0)[(bVar1 & 3) * 0x40]);
    uVar8 = 0x3d;
LAB_005c4053:
    FUN_0056ec80(uVar8);
    FUN_0056ec80(0x3d);
  }
  return pbVar6;
}



/* FUNCTION 5185 ; VA 0x005c4070 ; FUN_005c4070 */

int * FUN_005c4070(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8c5c,&LAB_005c2460);
  uVar3 = FUN_005c36d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_008bd920();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5186 ; VA 0x005c4120 ; FUN_005c4120 */

int * FUN_005c4120(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8c74,&LAB_005c2480);
  uVar3 = FUN_005c37d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009d6050();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5187 ; VA 0x005c41d0 ; FUN_005c41d0 */

int * FUN_005c41d0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8c4c,&LAB_005c2490);
  uVar3 = FUN_005c3850();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009de510();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5188 ; VA 0x005c4280 ; FUN_005c4280 */

int * FUN_005c4280(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8c6c,&LAB_005c24a0);
  uVar3 = FUN_005c38d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009df680();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5189 ; VA 0x005c4330 ; FUN_005c4330 */

uint * FUN_005c4330(uint *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    piStack_c = (int *)0x0;
    puVar7 = &uStack_10;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
    uVar8 = 0;
  }
  else {
    piVar6 = (int *)FUN_005c9c10(auStack_20);
    uVar8 = -(uint)(*piVar6 != 0) & *piVar6 - 0xcU;
    piStack_14 = (int *)piVar6[1];
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)piVar6[1];
    }
    bVar5 = true;
    bVar4 = true;
    bVar3 = false;
    puVar7 = &uStack_18;
  }
  uVar1 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *param_1 = uVar8;
  param_1[1] = uVar1;
  if (bVar3) {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar2 = piStack_c[2] + -1;
        piStack_c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
  }
  if (bVar4) {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if ((bVar5) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar6 = piStack_1c + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 5190 ; VA 0x005c4440 ; thunk_FUN_0088c8c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088c8c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba50c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede8dc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede8dc);
    if (DAT_01ede8dc == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cd9c,2,1,0,0);
      _DAT_01ede8b8 = RBX::Reflection::TType<int>::vftable;
      FUN_016f3654(&LAB_01880920);
      FUN_016f37bf(&DAT_01ede8dc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede8b8;
}



/* FUNCTION 5191 ; VA 0x005c4490 ; thunk_FUN_0088d050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d050(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba68c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edebfc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edebfc);
    if (DAT_01edebfc == -1) {
      uStack_8 = 0;
      FUN_00888860("Color3",0x11,0,0,0);
      _DAT_01edebd8 = RBX::Reflection::TType<class_G3D::Color3>::vftable;
      FUN_016f3654(&LAB_018809e0);
      FUN_016f37bf(&DAT_01edebfc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edebd8;
}



/* FUNCTION 5192 ; VA 0x005c44a0 ; thunk_FUN_0088da50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088da50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba88c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede904) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede904);
    if (DAT_01ede904 == -1) {
      uStack_8 = 0;
      FUN_00888860("int64",3,1,0,0);
      _DAT_01ede8e0 = RBX::Reflection::TType<__int64>::vftable;
      FUN_016f3654(&LAB_01880ae0);
      FUN_016f37bf(&DAT_01ede904);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede8e0;
}



/* FUNCTION 5193 ; VA 0x005c44b0 ; thunk_FUN_0088daf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088daf0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba8ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede92c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede92c);
    if (DAT_01ede92c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cdb8,1,1,0,0);
      _DAT_01ede908 = RBX::Reflection::TType<bool>::vftable;
      FUN_016f3654(&LAB_01880af0);
      FUN_016f37bf(&DAT_01ede92c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede908;
}



/* FUNCTION 5194 ; VA 0x005c44c0 ; FUN_005c44c0 */

/* WARNING: Removing unreachable block (ram,0x005c4553) */

int * __thiscall
FUN_005c44c0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179863b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088c8c0();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5195 ; VA 0x005c4570 ; FUN_005c4570 */

undefined * __thiscall FUN_005c4570(undefined *param_1,undefined param_2)

{
  *param_1 = param_2;
  return param_1;
}



/* FUNCTION 5196 ; VA 0x005c4580 ; FUN_005c4580 */

undefined * __thiscall FUN_005c4580(undefined *param_1,int param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = FUN_005c9310(*(undefined4 *)(param_2 + 8));
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  FUN_005c9140(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5197 ; VA 0x005c4600 ; FUN_005c4600 */

undefined4 __thiscall FUN_005c4600(undefined4 param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_009cbbb0(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5198 ; VA 0x005c4650 ; FUN_005c4650 */

undefined4 * __fastcall FUN_005c4650(undefined4 *param_1)

{
  *param_1 = 0x7f7fffff;
  param_1[1] = 0x7f7fffff;
  param_1[2] = 0x7f7fffff;
  param_1[3] = 0xff7fffff;
  param_1[4] = 0xff7fffff;
  param_1[5] = 0xff7fffff;
  return param_1;
}



/* FUNCTION 5199 ; VA 0x005c4680 ; FUN_005c4680 */

undefined4 * __fastcall FUN_005c4680(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798678;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_ThumbnailGenerator,class_RBX::Instance>::vftable;
  uVar1 = FUN_00559080();
  param_1[3] = uVar1;
  *(undefined *)(param_1 + 0x15) = 1;
  *param_1 = ThumbnailGenerator::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5200 ; VA 0x005c46f0 ; FUN_005c46f0 */

int __thiscall FUN_005c46f0(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined *)(param_1 + 0x20) = *(undefined *)(param_2 + 0x20);
  *(undefined *)(param_1 + 0x21) = *(undefined *)(param_2 + 0x21);
  uVar1 = *(undefined4 *)(param_2 + 0x28);
  uVar2 = *(undefined4 *)(param_2 + 0x2c);
  uVar3 = *(undefined4 *)(param_2 + 0x30);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_2 + 0x24);
  *(undefined4 *)(param_1 + 0x28) = uVar1;
  *(undefined4 *)(param_1 + 0x2c) = uVar2;
  *(undefined4 *)(param_1 + 0x30) = uVar3;
  *(undefined8 *)(param_1 + 0x34) = *(undefined8 *)(param_2 + 0x34);
  *(undefined *)(param_1 + 0x3c) = 0;
  if (*(char *)(param_2 + 0x3c) != '\0') {
    *(undefined8 *)(param_1 + 0x40) = *(undefined8 *)(param_2 + 0x40);
    *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_2 + 0x48);
    *(undefined *)(param_1 + 0x3c) = 1;
  }
  return param_1;
}



/* FUNCTION 5201 ; VA 0x005c4760 ; FUN_005c4760 */

undefined4 * __thiscall
FUN_005c4760(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  return param_1;
}



/* FUNCTION 5202 ; VA 0x005c4790 ; FUN_005c4790 */

undefined4 * __thiscall FUN_005c4790(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_weak_ptr::vftable;
  return param_1;
}



/* FUNCTION 5203 ; VA 0x005c47d0 ; FUN_005c47d0 */

undefined4 * __fastcall FUN_005c47d0(undefined4 *param_1)

{
  *(undefined8 *)(param_1 + 1) = 0;
  *param_1 = std::bad_weak_ptr::vftable;
  return param_1;
}



/* FUNCTION 5204 ; VA 0x005c47f0 ; FUN_005c47f0 */

void __fastcall FUN_005c47f0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x54);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),1);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),1);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x40));
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 5205 ; VA 0x005c48a0 ; thunk_FUN_009cb8b0 */

void __fastcall thunk_FUN_009cb8b0(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::FunctionDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 5206 ; VA 0x005c48b0 ; FUN_005c48b0 */

void __fastcall FUN_005c48b0(int param_1)

{
  if (*(undefined4 **)(param_1 + 0x34) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x34))(1);
  }
  FUN_009ca940();
  return;
}



/* FUNCTION 5207 ; VA 0x005c48d0 ; FUN_005c48d0 */

void __fastcall FUN_005c48d0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return;
}



/* FUNCTION 5208 ; VA 0x005c4910 ; FUN_005c4910 */

void __fastcall FUN_005c4910(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  uStack_8 = 0;
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_00560ab0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0xf0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5209 ; VA 0x005c4970 ; FUN_005c4970 */

void __fastcall FUN_005c4970(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_005c4b70();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x5c);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 5210 ; VA 0x005c4a30 ; FUN_005c4a30 */

void __fastcall FUN_005c4a30(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_00560ab0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0xf0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5211 ; VA 0x005c4a90 ; FUN_005c4a90 */

void __fastcall FUN_005c4a90(char *param_1)

{
  if (*param_1 != '\0') {
    *param_1 = '\0';
  }
  return;
}



/* FUNCTION 5212 ; VA 0x005c4aa0 ; FUN_005c4aa0 */

void __fastcall FUN_005c4aa0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,4);
  }
  return;
}



/* FUNCTION 5213 ; VA 0x005c4ac0 ; FUN_005c4ac0 */

void __fastcall FUN_005c4ac0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_005c4ed0(*param_1);
  }
  return;
}



/* FUNCTION 5214 ; VA 0x005c4ad0 ; FUN_005c4ad0 */

void __fastcall FUN_005c4ad0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  return;
}



/* FUNCTION 5215 ; VA 0x005c4b10 ; FUN_005c4b10 */

void __fastcall FUN_005c4b10(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0xc);
  }
  return;
}



/* FUNCTION 5216 ; VA 0x005c4b30 ; FUN_005c4b30 */

void __fastcall FUN_005c4b30(int *param_1)

{
  if ((int *)*param_1 != (int *)0x0) {
    (**(code **)(*(int *)*param_1 + 0x90))(1);
  }
  return;
}



/* FUNCTION 5217 ; VA 0x005c4b50 ; FUN_005c4b50 */

void __fastcall FUN_005c4b50(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,1);
  }
  return;
}



/* FUNCTION 5218 ; VA 0x005c4b70 ; FUN_005c4b70 */

void __fastcall FUN_005c4b70(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (*(char *)(param_1 + 0xf) != '\0') {
    *(undefined *)(param_1 + 0xf) = 0;
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 5219 ; VA 0x005c4bd0 ; FUN_005c4bd0 */

void FUN_005c4bd0(void)

{
  FUN_005c4b70();
  return;
}



/* FUNCTION 5220 ; VA 0x005c4be0 ; FUN_005c4be0 */

void __fastcall FUN_005c4be0(undefined4 *param_1)

{
  *(undefined4 *)*param_1 = 0;
  return;
}



/* FUNCTION 5221 ; VA 0x005c4bf0 ; FUN_005c4bf0 */

void __thiscall FUN_005c4bf0(undefined *param_1,undefined param_2)

{
  LOCK();
  *param_1 = param_2;
  UNLOCK();
  return;
}



/* FUNCTION 5222 ; VA 0x005c4c00 ; FUN_005c4c00 */

int * __thiscall FUN_005c4c00(int param_1,char *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  void **ppvVar4;
  char cVar5;
  char *pcVar6;
  char *pcVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  undefined4 *puVar14;
  int iVar15;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017986a0;
  pvStack_10 = ExceptionList;
  pcVar6 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pcVar6 = *(char **)param_2;
  }
  pcVar7 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pcVar7 = *(char **)param_2;
  }
  iVar11 = (int)(pcVar6 + *(int *)(param_2 + 0x10)) - (int)pcVar7;
  uVar13 = 0;
  if (pcVar6 + *(int *)(param_2 + 0x10) < pcVar7) {
    iVar11 = 0;
  }
  if (iVar11 != 0) {
    iVar15 = 0;
    do {
      cVar5 = *pcVar7;
      pcVar7 = pcVar7 + 1;
      iVar15 = iVar15 + 1;
      uVar13 = uVar13 ^ (uVar13 >> 2) + 0x9e3779b9 + uVar13 * 0x40 + (int)cVar5;
    } while (iVar15 != iVar11);
  }
  piStack_14 = (int *)(uVar13 % *(uint *)(param_1 + 4));
  ppvVar4 = &pvStack_10;
  iStack_18 = param_1;
  if (*(int *)(param_1 + 8) != 0) {
    puVar14 = *(undefined4 **)(*(int *)(param_1 + 0x14) + (int)piStack_14 * 4);
    piVar8 = piStack_14;
    if (puVar14 == (undefined4 *)0x0) {
      puVar14 = (undefined4 *)0x0;
      ppvVar4 = &pvStack_10;
    }
    else {
      puVar14 = (undefined4 *)*puVar14;
      ppvVar4 = &pvStack_10;
    }
    for (; ExceptionList = ppvVar4, ppvVar4 = (void **)ExceptionList, puVar14 != (undefined4 *)0x0;
        puVar14 = (undefined4 *)*puVar14) {
      if (uVar13 == puVar14[1]) {
        piVar8 = puVar14 + 2;
        iStack_18 = puVar14[6];
        if (0xf < (uint)puVar14[7]) {
          piVar8 = (int *)*piVar8;
        }
        pcVar6 = param_2;
        if (0xf < *(uint *)(param_2 + 0x14)) {
          pcVar6 = *(char **)param_2;
        }
        cVar5 = FUN_0055c360(pcVar6,*(undefined4 *)(param_2 + 0x10),piVar8,iStack_18);
        piVar8 = piStack_14;
        if (cVar5 != '\0') {
          ppvVar4 = (void **)ExceptionList;
          if (puVar14 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar14 + 2;
          }
          break;
        }
      }
      else if ((int *)((uint)puVar14[1] % *(uint *)(param_1 + 4)) != piVar8) break;
      ppvVar4 = (void **)ExceptionList;
    }
  }
  ExceptionList = ppvVar4;
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  FUN_005c6580();
  piVar8 = piStack_20;
  piStack_14 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  iVar11 = FUN_00888530();
  piVar8[8] = iVar11;
  piVar8[9] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar12 = uStack_28 + 1;
    iVar11 = aiStack_3c[0];
    if (0xfff < uVar12) {
      iVar11 = *(int *)(aiStack_3c[0] + -4);
      uVar12 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar11) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar11,uVar12);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar12 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar12 = FUN_005c9310(uVar12);
    if (uVar12 <= *(uint *)(param_1 + 4)) {
      uVar12 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar12);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar12) {
    iStack_18 = 1;
    uVar9 = uVar2 >> 1;
    if ((uVar2 >> 1) + uVar2 <= uVar12) {
      uVar9 = 1;
    }
    iVar11 = FUN_005c9310(uVar9 + uVar2);
    if (iVar11 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar11);
      puVar14 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar14;
      while (piVar8 = piStack_20, puVar3 != (undefined4 *)0x0) {
        uVar12 = (uint)puVar3[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar12 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar12 * 4) == 0) {
          *piVar8 = (int)puVar14;
          puVar14 = puVar3;
        }
        else {
          *puVar14 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar14;
      }
    }
  }
  piVar8[1] = uVar13;
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar13 % *(uint *)(param_1 + 4)) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar8;
    }
    *piVar1 = (int)piVar10;
    *piVar8 = *piVar10;
  }
  else {
    *piVar8 = *(int *)*piVar1;
    piVar10 = (int *)*piVar1;
  }
  *piVar10 = (int)piVar8;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_14;
}



/* FUNCTION 5223 ; VA 0x005c4eb0 ; FUN_005c4eb0 */

int FUN_005c4eb0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_005c4c00(param_1);
  return iVar1 + 0x18;
}



/* FUNCTION 5224 ; VA 0x005c4ed0 ; FUN_005c4ed0 */

void FUN_005c4ed0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != (int *)0x0) {
    uVar1 = param_1[5];
    if (0xf < uVar1) {
      iVar2 = *param_1;
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    FUN_01674ea0(param_1,0x18);
  }
  return;
}



/* FUNCTION 5225 ; VA 0x005c4f40 ; FUN_005c4f40 */

int __thiscall FUN_005c4f40(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 5226 ; VA 0x005c4fa0 ; FUN_005c4fa0 */

int __thiscall FUN_005c4fa0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x44));
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x40));
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 5227 ; VA 0x005c5010 ; FUN_005c5010 */

undefined4 __thiscall FUN_005c5010(undefined4 param_1,byte param_2)

{
  FUN_005c47f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 5228 ; VA 0x005c5040 ; FUN_005c5040 */

int __thiscall FUN_005c5040(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x40));
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 5229 ; VA 0x005c5080 ; FUN_005c5080 */

int __thiscall FUN_005c5080(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x40));
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 5230 ; VA 0x005c50d0 ; FUN_005c50d0 */

int __thiscall FUN_005c50d0(int param_1,byte param_2)

{
  if (*(undefined4 **)(param_1 + 0x34) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x34))(1);
  }
  FUN_009ca940();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 5231 ; VA 0x005c5110 ; FUN_005c5110 */

undefined4 * __thiscall FUN_005c5110(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<int>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 5232 ; VA 0x005c5140 ; FUN_005c5140 */

undefined4 __thiscall FUN_005c5140(undefined4 param_1,byte param_2)

{
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x54);
  }
  return param_1;
}



/* FUNCTION 5233 ; VA 0x005c5170 ; FUN_005c5170 */

undefined4 __thiscall FUN_005c5170(undefined4 param_1,byte param_2)

{
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 5234 ; VA 0x005c51a0 ; FUN_005c51a0 */

undefined4 * __thiscall FUN_005c51a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<int>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 5235 ; VA 0x005c51d0 ; FUN_005c51d0 */

undefined4 * __thiscall FUN_005c51d0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = ThumbnailGenerator::vftable;
  piVar2 = (int *)param_1[0x18];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5236 ; VA 0x005c5230 ; FUN_005c5230 */

void __thiscall FUN_005c5230(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 8;
  param_1[2] = param_2 + param_4 * 8;
  return;
}



/* FUNCTION 5237 ; VA 0x005c52a0 ; FUN_005c52a0 */

void __fastcall FUN_005c52a0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0056d080();
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 5238 ; VA 0x005c52c0 ; FUN_005c52c0 */

void __thiscall FUN_005c52c0(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x2c8590b - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_005c549c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_005c5324;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_005c5324:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_005c549c;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_005c549c;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 5239 ; VA 0x005c54b0 ; FUN_005c54b0 */

void __thiscall FUN_005c54b0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((DAT_01d59328 != '\0') && (ExceptionList = &pvStack_10, *(int *)(param_1 + 0x5c) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(&param_2);
    FUN_005db7a0();
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5240 ; VA 0x005c5550 ; FUN_005c5550 */

void __thiscall FUN_005c5550(int param_1,undefined4 *param_2,int param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  piVar3 = *(int **)(param_3 + 4);
  *(undefined4 *)(param_3 + 4) = 0;
  piVar3[1] = param_4;
  param_4 = param_4 % *(uint *)(param_1 + 4);
  puVar4 = *(undefined4 **)(*(int *)(param_1 + 0x14) + param_4 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + param_4 * 4);
  if (puVar4 == (undefined4 *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *piVar1 = (int)piVar2;
    *piVar3 = *piVar2;
    *piVar2 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = piVar3;
    return;
  }
  *piVar3 = *puVar4;
  *(int **)*piVar1 = piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar3;
  return;
}



/* FUNCTION 5241 ; VA 0x005c55d0 ; FUN_005c55d0 */

undefined4 __fastcall FUN_005c55d0(int param_1)

{
  undefined4 uVar1;
  
  if (*(int **)(param_1 + 0x34) == (int *)0x0) {
    return 1;
  }
                    /* WARNING: Could not recover jumptable at 0x005c55df. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0x44))();
  return uVar1;
}



/* FUNCTION 5242 ; VA 0x005c55f0 ; FUN_005c55f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005c55f0(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  char cStack00000028;
  undefined in_stack_0000002c;
  int *in_stack_00000030;
  int *in_stack_00000034;
  undefined auStack_e8 [24];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  char *pcStack_c4;
  undefined4 uStack_c0;
  uint uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 *puStack_ac;
  undefined8 uStack_a8;
  undefined4 *puStack_a0;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined uStack_64;
  undefined uStack_63;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  char cStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017988a1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  puStack_a0 = (undefined4 *)0x0;
  uStack_8 = 2;
  uStack_c0 = 0x17;
  puStack_ac = (undefined4 *)0x0;
  uStack_a8 = 0xf;
  pcStack_c4 = "ThumbnailGeneratorClick";
  uStack_bc = uStack_bc & 0xffffff00;
  uStack_c8 = 0x5c5646;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_c0 = 0x5c564d;
  FUN_005c54b0();
  puStack_a0 = (undefined4 *)&DAT_018bdf50;
  puStack_ac = &param_2;
  if (0xf < in_stack_0000001c) {
    puStack_ac = param_2;
  }
  if (cStack00000028 == '\0') {
    puStack_a0 = (undefined4 *)&DAT_018bdf48;
  }
  uStack_a8 = CONCAT44(in_stack_00000024,in_stack_00000020);
  uStack_b4 = 0x18c4bb800000001;
  uStack_b8 = 0x5c567d;
  FUN_0086f2f0();
  uStack_28 = 0xff7fffff;
  uStack_24 = 0xff7fffff;
  uStack_94 = _DAT_018c4eb0;
  uStack_90 = _UNK_018c4eb4;
  uStack_8c = _UNK_018c4eb8;
  uStack_88 = _UNK_018c4ebc;
  if (in_stack_00000030 != (int *)0x0) {
    if ((in_stack_00000030[1] - *in_stack_00000030) / 0xd0 == 2) {
      iVar3 = *(int *)*in_stack_00000030;
      puStack_a0 = (undefined4 *)0x5c56cb;
      iVar5 = FUN_0088d870();
      if (iVar3 == iVar5) {
        iVar3 = *(int *)(*in_stack_00000030 + 0xd0);
        puStack_a0 = (undefined4 *)0x5c56df;
        iVar5 = FUN_0088d870();
        if (iVar3 == iVar5) {
          puStack_a0 = (undefined4 *)auStack_20;
          uStack_a8 = CONCAT44(0x5c56f7,(undefined4)uStack_a8);
          puVar6 = (undefined8 *)FUN_005c3bd0();
          puStack_a0 = &uStack_90;
          uStack_a8 = CONCAT44(0x5c570a,(undefined4)uStack_a8);
          puVar7 = (undefined8 *)FUN_005c3bd0();
          uVar2 = *puVar7;
          uStack_8c = *(undefined4 *)(puVar7 + 1);
          uStack_24 = *(undefined4 *)(puVar6 + 1);
          uStack_2c = (undefined4)*puVar6;
          uStack_28 = (undefined4)((ulonglong)*puVar6 >> 0x20);
          uStack_38._0_4_ = (undefined4)uVar2;
          uStack_38._4_4_ = (undefined4)((ulonglong)uVar2 >> 0x20);
          uStack_94 = (undefined4)uStack_38;
          uStack_90 = uStack_38._4_4_;
          uStack_88 = uStack_2c;
          uStack_38 = uVar2;
          uStack_30 = uStack_8c;
        }
      }
    }
  }
  uStack_1c = CONCAT44(uStack_24,uStack_28);
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = auStack_84[0] & 0xffffff00;
  uStack_60 = _DAT_018c4eb0;
  uStack_5c = _UNK_018c4eb4;
  uStack_58 = _UNK_018c4eb8;
  uStack_54 = _UNK_018c4ebc;
  uStack_50 = 0xff7fffffff7fffff;
  cStack_48 = 0;
  puStack_a0 = (undefined4 *)in_stack_00000018;
  puVar8 = &param_2;
  if (0xf < in_stack_0000001c) {
    puVar8 = param_2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_a8 = CONCAT44(puVar8,0x5c5787);
  FUN_005542c0();
  uStack_6c = in_stack_00000020;
  uStack_68 = in_stack_00000024;
  uStack_64 = cStack00000028;
  uStack_63 = in_stack_0000002c;
  uStack_60 = uStack_94;
  uStack_5c = uStack_90;
  uStack_58 = uStack_8c;
  uStack_54 = uStack_88;
  uStack_50 = uStack_1c;
  cStack_48 = '\0';
  _cStack00000028 = auStack_e8;
  FUN_0054ef60(auStack_84);
  puVar8 = puStack_ac;
  uStack_d0 = uStack_6c;
  uStack_cc = uStack_68;
  pcStack_c4 = (char *)uStack_60;
  uStack_c0 = uStack_5c;
  uStack_bc = uStack_58;
  uStack_b8 = uStack_54;
  uStack_c8._0_2_ = CONCAT11(uStack_63,uStack_64);
  uStack_b4 = uStack_50;
  puStack_ac = (undefined4 *)((uint)puStack_ac & 0xffffff00);
  if (cStack_48 != '\0') {
    uStack_a8 = uStack_44;
    puStack_a0 = (undefined4 *)uStack_3c;
    puStack_ac = (undefined4 *)CONCAT31(SUB43(puVar8,1),1);
  }
  FUN_005c5900(param_1);
  puStack_a0 = (undefined4 *)0x6;
  uStack_a8 = 0x18c4be400000001;
  uStack_14 = 1;
  puStack_ac = (undefined4 *)0x5c5834;
  FUN_0086edd0();
  if (0xf < uStack_70) {
    puStack_a0 = (undefined4 *)(uStack_70 + 1);
    uVar9 = auStack_84[0];
    if (0xfff < puStack_a0) {
      uVar9 = *(uint *)(auStack_84[0] - 4);
      puStack_a0 = (undefined4 *)(uStack_70 + 0x24);
      if (0x1f < (auStack_84[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_a0 = (undefined4 *)0x5c58ef;
        FUN_017167a3();
      }
    }
    uStack_a8 = CONCAT44(uVar9,0x5c5868);
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000001c) {
    puStack_a0 = (undefined4 *)(in_stack_0000001c + 1);
    puVar8 = param_2;
    if (0xfff < puStack_a0) {
      puVar8 = (undefined4 *)param_2[-1];
      puStack_a0 = (undefined4 *)(in_stack_0000001c + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar8))) {
                    /* WARNING: Subroutine does not return */
        puStack_a0 = (undefined4 *)&UNK_005c58f4;
        FUN_017167a3();
      }
    }
    uStack_a8 = CONCAT44(puVar8,0x5c5898);
    FUN_01674ea0();
  }
  piVar4 = in_stack_00000034;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_a0 = (undefined4 *)0x5c58c6;
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_a0 = (undefined4 *)0x5c58d5;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5243 ; VA 0x005c5900 ; FUN_005c5900 */

undefined4 * __thiscall FUN_005c5900(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined uVar2;
  undefined *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined uStack00000028;
  undefined uStack00000029;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  char in_stack_00000044;
  undefined8 in_stack_00000048;
  undefined4 in_stack_00000050;
  undefined auStack_d0 [12];
  int iStack_c4;
  undefined auStack_c0 [24];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined uStack_9f;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  uint *puStack_74;
  uint *puStack_70;
  undefined *puStack_6c;
  undefined auStack_68 [4];
  int *piStack_64;
  uint auStack_5c [4];
  int iStack_4c;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined auStack_20 [7];
  undefined uStack_19;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798902;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff24;
  LOCK();
  DAT_01ea8b9c = DAT_01ea8b9c + 1;
  UNLOCK();
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  puVar3 = &stack0xffffff24;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    ExceptionList = &pvStack_10;
    puVar3 = &stack0xffffff24;
    if ((iVar5 != 0) &&
       (iVar4 = iVar5, ExceptionList = &pvStack_10, puVar3 = &stack0xffffff24,
       *(int *)(iVar5 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_005c8ac0();
      puVar3 = puStack_14;
    }
    puStack_14 = puVar3;
    puVar3 = puStack_14;
    if (iVar4 != 0) {
      iStack_18 = *(int *)(iVar4 + 0xc);
      iVar5 = FUN_008a8c30();
      puVar3 = puStack_14;
      if ((uint)*(ushort *)(iStack_18 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        iStack_18 = FUN_005c2760();
        goto LAB_005c59ae;
      }
    }
  }
  puStack_14 = puVar3;
  iStack_18 = 0;
LAB_005c59ae:
  FUN_005c64c0();
  iStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  uStack_8._0_1_ = 3;
  FUN_0151f360(1);
  uStack_8._0_1_ = 4;
  iStack_c4 = param_1;
  FUN_0054ef60(&stack0x00000008);
  uStack_84 = in_stack_00000044 != '\0';
  uStack_a8 = in_stack_00000020;
  uStack_a4 = in_stack_00000024;
  uStack_a0 = uStack00000028;
  uStack_9c = in_stack_0000002c;
  uStack_98 = in_stack_00000030;
  uStack_94 = in_stack_00000034;
  uStack_90 = in_stack_00000038;
  uStack_9f = uStack00000029;
  uStack_8c = in_stack_0000003c;
  if ((bool)uStack_84) {
    uStack_80 = in_stack_00000048;
    uStack_78 = in_stack_00000050;
  }
  puStack_74 = auStack_44;
  puStack_70 = auStack_5c;
  puStack_6c = auStack_20;
  uStack_8._0_1_ = 5;
  FUN_005789c0(&DAT_01ea8bdc,FUN_005c9f60);
  puStack_2c = &DAT_01ea8bb8;
  do {
    LOCK();
    uVar7 = DAT_01ea8bb8 & 1;
    DAT_01ea8bb8 = DAT_01ea8bb8 | 1;
    UNLOCK();
  } while (uVar7 != 0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (DAT_01ea8bac <= DAT_01ea8bb4 + 1U) {
    FUN_005c52c0(1);
  }
  DAT_01ea8bb0 = DAT_01ea8bb0 & DAT_01ea8bac - 1;
  iStack_24 = (DAT_01ea8bac - 1 & DAT_01ea8bb0 + DAT_01ea8bb4) * 4;
  if (*(int *)(iStack_24 + DAT_01ea8ba8) == 0) {
    uVar6 = FUN_01674e20(0x5c);
    *(undefined4 *)(iStack_24 + DAT_01ea8ba8) = uVar6;
  }
  piVar1 = *(int **)(iStack_24 + DAT_01ea8ba8);
  *piVar1 = iStack_c4;
  FUN_005c46f0(auStack_c0);
  piVar1[0x14] = (int)puStack_74;
  piVar1[0x15] = (int)puStack_70;
  piVar1[0x16] = (int)puStack_6c;
  DAT_01ea8bb4 = DAT_01ea8bb4 + 1;
  uStack_8._0_1_ = 5;
  DAT_01ea8bb8 = 0;
  FUN_0151f3f0();
  FUN_0151f430();
  if (iStack_4c != 0) {
    FUN_005500e0(auStack_5c);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_d0,&DAT_01c17198);
  }
  FUN_005c4b70();
  FUN_0151f390();
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_48) {
    uVar8 = uStack_48 + 1;
    uVar7 = auStack_5c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_5c[0] - 4);
      uVar8 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  iVar5 = FUN_01674e20(0xc);
  uStack_8._0_1_ = 7;
  puStack_2c = (undefined4 *)iVar5;
  if (iVar5 == 0) {
    iVar5 = 0;
  }
  else {
    FUN_00569550(2,&uStack_19);
  }
  uStack_8._0_1_ = 2;
  uStack_28 = 0;
  iStack_24 = 0;
  FUN_0055ba30(iVar5,param_2);
  uStack_8._0_1_ = 8;
  FUN_005c16d0(auStack_44);
  uVar6 = FUN_008cebe0(auStack_68);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_005c1810(uVar6);
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_64[1] + -1;
    piStack_64[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_64)();
      LOCK();
      piVar1 = piStack_64 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_64 + 4))();
      }
    }
  }
  *param_2 = uStack_28;
  param_2[1] = iStack_24;
  if (0xf < uStack_30) {
    uVar8 = uStack_30 + 1;
    uVar7 = auStack_44[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_44[0] - 4);
      uVar8 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005c4b70();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5244 ; VA 0x005c5cb1 ; Catch@005c5cb1 */

void Catch_005c5cb1(void)

{
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0x5c),6);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5245 ; VA 0x005c5d00 ; FUN_005c5d00 */

/* WARNING: Removing unreachable block (ram,0x005c5f35) */
/* WARNING: Removing unreachable block (ram,0x005c5e09) */
/* WARNING: Removing unreachable block (ram,0x005c5f43) */
/* WARNING: Removing unreachable block (ram,0x005c5fac) */
/* WARNING: Removing unreachable block (ram,0x005c5f53) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4
FUN_005c5d00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  int iStack_9c;
  uint uStack_88;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined2 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  char cStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798944;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  FUN_005c54b0();
  FUN_0115ee20();
  uStack_8 = 1;
  FUN_0086f2f0();
  FUN_005542c0();
  uVar1 = DAT_018c45d0;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  uStack_40 = _DAT_018c4eb0;
  uStack_3c = _UNK_018c4eb4;
  uStack_38 = _UNK_018c4eb8;
  uStack_34 = _UNK_018c4ebc;
  uStack_30 = 0xff7fffffff7fffff;
  cStack_28 = '\0';
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_005542c0();
  uStack_40 = _DAT_018c4eb0;
  uStack_3c = _UNK_018c4eb4;
  uStack_38 = _UNK_018c4eb8;
  uStack_34 = _UNK_018c4ebc;
  uStack_4c = param_2;
  uStack_30 = CONCAT44(uVar1,uVar1);
  uStack_48 = param_3;
  uStack_44 = 0x101;
  if (cStack_28 == '\0') {
    cStack_28 = '\x01';
  }
  _uStack_24 = CONCAT44(param_5,param_4);
  uStack_1c = param_6;
  FUN_0054ef60(auStack_64);
  FUN_005c5900(param_1);
  uStack_18 = 1;
  FUN_0086edd0();
  if (0xf < uStack_50) {
    if ((0xfff < uStack_50 + 1) && (0x1f < (auStack_64[0] - *(int *)(auStack_64[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < uStack_88) {
    if ((0xfff < uStack_88 + 1) && (0x1f < (iStack_9c - *(int *)(iStack_9c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5246 ; VA 0x005c5fc0 ; FUN_005c5fc0 */

undefined4 * __thiscall FUN_005c5fc0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 *in_stack_00000020;
  uint in_stack_00000034;
  int in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined uVar8;
  undefined4 in_stack_fffffeb8;
  undefined4 in_stack_fffffebc;
  undefined4 in_stack_fffffec0;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined auStack_120 [56];
  int iStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_d0;
  undefined auStack_b8 [48];
  undefined4 uStack_88;
  int iStack_84;
  int iStack_74;
  undefined auStack_60 [4];
  int *piStack_5c;
  char *apcStack_50 [4];
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  undefined auStack_34 [12];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017989cd;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed4;
  uVar12 = 0;
  uVar11 = 0;
  uStack_8 = 1;
  uVar9 = 0;
  uVar10 = 0xf;
  uVar8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("ThumbnailGeneratorClickTexture",0x1e);
  FUN_005c54b0(uVar8,in_stack_fffffeb8,in_stack_fffffebc,in_stack_fffffec0,uVar9,uVar10,uVar11,
               uVar12);
  LOCK();
  DAT_01ea8b9c = DAT_01ea8b9c + 1;
  UNLOCK();
  puVar5 = &stack0x00000020;
  if (0xf < in_stack_00000034) {
    puVar5 = in_stack_00000020;
  }
  puVar2 = &param_3;
  if (0xf < in_stack_0000001c) {
    puVar2 = param_3;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0086f2f0(1,"ThumbnailGenerator::clickTexture(%s, %s, %d, %d)",puVar2,puVar5,in_stack_00000038,
               in_stack_0000003c);
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      uStack_18 = FUN_005c2760();
      goto LAB_005c60b0;
    }
  }
  uStack_18 = 0;
LAB_005c60b0:
  FUN_005c64c0();
  FUN_0115f210();
  uStack_8._0_1_ = 3;
  FUN_0115f530(1);
  iVar4 = FUN_011603d0(&stack0x00000020);
  FUN_0115f610(0,0,3);
  uStack_8._0_1_ = 4;
  uVar9 = FUN_008ccda0();
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 5;
  FUN_009cbbb0(&uStack_38);
  uStack_8._0_1_ = 6;
  FUN_008cdc80(&puStack_20,&uStack_38,uVar9,1);
  uStack_8._0_1_ = 8;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar7 = uStack_38;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_38 - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (uStack_38 - uVar7) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  puVar5 = puStack_20 + 4;
  if (0xf < (uint)puStack_20[5]) {
    puStack_20 = (undefined4 *)*puStack_20;
  }
  FUN_0115eea0(puStack_20,*puVar5,0,1,0,0);
  uStack_8._0_1_ = 9;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if ((-1 < iStack_e4) && ((0 < iStack_e4 || (iStack_e8 != 0)))) {
    apcStack_50[0] = "Cannot getCArray for a huge file";
    uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(apcStack_50,&DAT_01c21d2c);
  }
  uVar9 = FUN_011602a0(uStack_d0,uStack_e0,5);
  FUN_0115ffa0(auStack_120,uVar9);
  FUN_0115f010();
  uStack_8._0_1_ = 4;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (iVar4 != 2) {
    uVar9 = FUN_011604f0(auStack_34);
    uStack_8._0_1_ = 10;
    FUN_0115f870(uVar9);
    uStack_8._0_1_ = 4;
    FUN_0115f820();
  }
  if ((iStack_40 < 1) || (iStack_3c < 1)) {
    FUN_01160230(1,1,3,1);
  }
  else {
    uVar9 = FUN_0115f960(auStack_34,in_stack_00000038,in_stack_0000003c);
    uStack_8._0_1_ = 0xb;
    FUN_0115f870(uVar9);
    uStack_8._0_1_ = 4;
    FUN_0115f820();
  }
  FUN_01160090(iVar4,auStack_b8);
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_8._0_1_ = 0xc;
  FUN_005c39d0(uStack_88,iStack_84 + iStack_74,&uStack_38,in_stack_0000003c);
  FUN_0086edd0(1,"ThumbnailGenerator::clickTexture() success",6);
  iVar4 = FUN_01674e20(0xc);
  uStack_8._0_1_ = 0xd;
  in_stack_00000038 = iVar4;
  if (iVar4 == 0) {
    iVar4 = 0;
  }
  else {
    FUN_00569550(2,(int)&stack0x0000003c + 3);
  }
  uStack_8._0_1_ = 0xc;
  puStack_20 = (undefined4 *)0x0;
  piStack_1c = (int *)0x0;
  FUN_0055ba30(iVar4,in_stack_0000003c);
  puVar5 = puStack_20;
  uStack_8._0_1_ = 0xe;
  FUN_005c16d0(&uStack_38);
  uVar9 = FUN_008cebe0(auStack_60);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  FUN_005c1810(uVar9);
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar1 = piStack_5c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  *param_2 = puVar5;
  param_2[1] = piStack_1c;
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar7 = uStack_38;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_38 - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (uStack_38 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  FUN_0115f820();
  FUN_0115f2b0();
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    puVar5 = param_3;
    if (0xfff < uVar7) {
      puVar5 = (undefined4 *)param_3[-1];
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar7);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = (undefined4 *)((uint)param_3 & 0xffffff00);
  if (0xf < in_stack_00000034) {
    uVar7 = in_stack_00000034 + 1;
    puVar5 = in_stack_00000020;
    if (0xfff < uVar7) {
      puVar5 = (undefined4 *)in_stack_00000020[-1];
      uVar7 = in_stack_00000034 + 0x24;
      if (0x1f < (uint)((int)in_stack_00000020 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5247 ; VA 0x005c6456 ; Catch@005c6456 */

void Catch_005c6456(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = *(undefined4 *)(unaff_EBP + -0x54);
  FUN_0086ed30(3,uVar1,6);
  FUN_005500e0(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x68,&DAT_01c17198);
}



/* FUNCTION 5248 ; VA 0x005c64a6 ; Catch@005c64a6 */

void Catch_005c64a6(void)

{
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0x50),6);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5249 ; VA 0x005c64c0 ; FUN_005c64c0 */

void __fastcall FUN_005c64c0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iVar2 != 0) && (iVar1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      iVar1 = FUN_005c8ac0();
    }
    if (((iVar1 != 0) &&
        (iVar2 = *(int *)(iVar1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005c2f20(), iVar2 != 0)) {
      FUN_009ddcc0(0x7fffffff);
    }
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005c34e0(), iVar2 != 0)) {
      FUN_009ddcc0(0x7fffffff);
    }
  }
  return;
}


