/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 19500 ; VA 0x009ee570 ; FUN_009ee570 */

undefined * FUN_009ee570(undefined *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar3 = "true";
  if (*param_2 == '\0') {
    pcVar3 = "false";
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  return param_1;
}



/* FUNCTION 19501 ; VA 0x009ee5c0 ; FUN_009ee5c0 */

undefined4 FUN_009ee5c0(undefined4 *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (param_1[4] != 0) {
    cVar1 = FUN_009eea80(param_1);
    if (cVar1 != '\0') {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      uVar2 = FUN_01717832(param_1);
      *param_2 = uVar2;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19502 ; VA 0x009ee600 ; FUN_009ee600 */

undefined4 FUN_009ee600(char *param_1,undefined4 *param_2)

{
  char cVar1;
  code *pcVar2;
  char cVar3;
  char *pcVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8410;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x10) == 0) {
    return 0;
  }
  uStack_8 = 0;
  pcVar4 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar4 = *(char **)param_1;
  }
  ExceptionList = &pvStack_10;
  if (pcVar4 != pcVar4 + *(int *)(param_1 + 0x10)) {
    cVar1 = *pcVar4;
    ExceptionList = &pvStack_10;
    cVar3 = FUN_009d7520();
    if (cVar1 == '-') {
      param_1 = (char *)-(int)param_1;
    }
    if (cVar3 != '\0') {
      *param_2 = param_1;
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  FUN_009ee230();
  pcVar2 = (code *)swi(3);
  uVar5 = (*pcVar2)();
  return uVar5;
}



/* FUNCTION 19503 ; VA 0x009ee695 ; Catch@009ee695 */

undefined4 Catch_009ee695(void)

{
  return 0x9ee69b;
}



/* FUNCTION 19504 ; VA 0x009ee6c0 ; FUN_009ee6c0 */

undefined4 FUN_009ee6c0(undefined4 *param_1,float *param_2)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  float10 fVar6;
  
  puVar5 = param_1;
  iVar1 = param_1[4];
  if (iVar1 == 0) {
    return 0;
  }
  uVar2 = param_1[5];
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  cVar3 = FUN_0055c360(puVar4,iVar1,&DAT_018c37a8,3);
  if (cVar3 != '\0') {
    *param_2 = DAT_018e0028;
    return 1;
  }
  puVar4 = puVar5;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*puVar5;
  }
  cVar3 = FUN_0055c360(puVar4,iVar1,&DAT_018c37ac,4);
  if (cVar3 != '\0') {
    *param_2 = DAT_0193ce08;
    return 1;
  }
  puVar4 = puVar5;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*puVar5;
  }
  cVar3 = FUN_0055c360(puVar4,iVar1,&DAT_0193cde4,3);
  if (cVar3 != '\0') {
    *param_2 = DAT_0193279c;
    return 1;
  }
  if (0xf < uVar2) {
    puVar5 = (undefined4 *)*puVar5;
  }
  fVar6 = (float10)FUN_0172167a(puVar5,&param_1);
  *param_2 = (float)fVar6;
  return 1;
}



/* FUNCTION 19505 ; VA 0x009ee7a0 ; FUN_009ee7a0 */

undefined4 FUN_009ee7a0(undefined4 *param_1,double *param_2)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  undefined4 *puVar4;
  float10 fVar5;
  
  iVar1 = param_1[4];
  if (iVar1 == 0) {
    return 0;
  }
  uVar2 = param_1[5];
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  cVar3 = FUN_0055c360(puVar4,iVar1,&DAT_018c37a8,3);
  if (cVar3 != '\0') {
    *param_2 = DAT_0193cdf8;
    return 1;
  }
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  cVar3 = FUN_0055c360(puVar4,iVar1,&DAT_018c37ac,4);
  if (cVar3 != '\0') {
    *param_2 = DAT_0193ce10;
    return 1;
  }
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  cVar3 = FUN_0055c360(puVar4,iVar1,&DAT_0193cde4,3);
  if (cVar3 != '\0') {
    *param_2 = DAT_0193ce00;
    return 1;
  }
  if (0xf < uVar2) {
    param_1 = (undefined4 *)*param_1;
  }
  fVar5 = (float10)FUN_01728c1a(param_1);
  *param_2 = (double)fVar5;
  return 1;
}



/* FUNCTION 19506 ; VA 0x009ee890 ; FUN_009ee890 */

undefined4 FUN_009ee890(undefined4 *param_1,undefined8 *param_2)

{
  char cVar1;
  undefined8 uVar2;
  
  if (param_1[4] != 0) {
    cVar1 = FUN_009eea80(param_1);
    if (cVar1 != '\0') {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      uVar2 = FUN_0171d7b1(param_1,0,10);
      *param_2 = uVar2;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19507 ; VA 0x009ee8e0 ; FUN_009ee8e0 */

undefined FUN_009ee8e0(undefined4 *param_1,undefined *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  
  uVar1 = param_1[5];
  uVar2 = param_1[4];
  puVar4 = param_1;
  if (0xf < uVar1) {
    puVar4 = (undefined4 *)*param_1;
  }
  cVar3 = FUN_0055c360(puVar4,uVar2,&DAT_018bdf50,4);
  if (cVar3 == '\0') {
    puVar4 = param_1;
    if (0xf < uVar1) {
      puVar4 = (undefined4 *)*param_1;
    }
    cVar3 = FUN_0055c360(puVar4,uVar2,&DAT_018c6230,4);
    if (cVar3 == '\0') {
      puVar4 = param_1;
      if (0xf < uVar1) {
        puVar4 = (undefined4 *)*param_1;
      }
      cVar3 = FUN_0055c360(puVar4,uVar2,&DAT_018bf8dc,4);
      if (cVar3 == '\0') {
        puVar4 = param_1;
        if (0xf < uVar1) {
          puVar4 = (undefined4 *)*param_1;
        }
        cVar3 = FUN_0055c360(puVar4,uVar2,&DAT_018bdf48,5);
        if (cVar3 == '\0') {
          puVar4 = param_1;
          if (0xf < uVar1) {
            puVar4 = (undefined4 *)*param_1;
          }
          cVar3 = FUN_0055c360(puVar4,uVar2,"False",5);
          if (cVar3 == '\0') {
            if (0xf < uVar1) {
              param_1 = (undefined4 *)*param_1;
            }
            cVar3 = FUN_0055c360(param_1,uVar2,&DAT_018c7824,5);
            if (cVar3 == '\0') {
              return 0;
            }
          }
        }
        *param_2 = 0;
        return 1;
      }
    }
  }
  *param_2 = 1;
  return 1;
}



/* FUNCTION 19508 ; VA 0x009ee9d0 ; FUN_009ee9d0 */

uint FUN_009ee9d0(uint param_1,uint param_2)

{
  return param_1 ^ param_2;
}



/* FUNCTION 19509 ; VA 0x009ee9e0 ; FUN_009ee9e0 */

uint FUN_009ee9e0(uint param_1,int param_2,uint param_3,uint param_4)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  char *pcVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uStack_8;
  
  uVar2 = 0;
  uVar5 = 0;
  uVar7 = 0;
  uStack_8 = 0;
  if (param_1 < param_1 + param_2) {
    pcVar4 = (char *)(param_1 + 2);
    iVar6 = (((param_1 + param_2) - param_1) - 1 >> 4) + 1;
    do {
      uVar7 = (int)pcVar4[-2] + (uVar7 << 10 | uVar7 >> 0x16) + param_3;
      uVar5 = (param_3 - (int)pcVar4[-1]) - (uVar5 << 0xf | uVar5 >> 0x11);
      uVar7 = (uVar7 * 0x8000 | uVar7 >> 0x11) ^ uVar2;
      uVar5 = uStack_8 - (uVar5 * 0x20 | uVar5 >> 0x1b);
      uVar3 = (int)*pcVar4 ^ ~uStack_8 ^ param_3;
      uStack_8 = (uVar3 << 5 | uVar3 >> 0x1b) + uVar5;
      pcVar1 = pcVar4 + 1;
      pcVar4 = pcVar4 + 0x10;
      uVar2 = ~uVar2 ^ (int)*pcVar1 - param_3;
      uVar2 = (uVar2 << 10 | uVar2 >> 0x16) + uVar7;
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
  }
  return ((uVar2 - uStack_8) - uVar5) + uVar7 ^ param_4;
}



/* FUNCTION 19510 ; VA 0x009eea80 ; FUN_009eea80 */

uint FUN_009eea80(undefined4 *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      puVar3 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar3 = (undefined4 *)*param_1;
      }
      cVar1 = *(char *)((int)puVar3 + uVar2);
      if (((uVar2 != 0) || (cVar1 != '-')) && (('9' < cVar1 || (cVar1 < '0')))) {
        return uVar2 & 0xffffff00;
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < (uint)param_1[4]);
  }
  return CONCAT31((int3)(uVar2 >> 8),1);
}



/* FUNCTION 19511 ; VA 0x009eead0 ; FUN_009eead0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009eead0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8440;
  pvStack_10 = ExceptionList;
  if (DAT_01ee5a10 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee5c28) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee5c28);
      if (DAT_01ee5c28 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TimerService",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ee5c20 = RBX::Creator<class_RBX::TimerService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee5a18,&DAT_01ee5c20);
        FUN_016f3654(FUN_018883e0);
        FUN_016f37bf(&DAT_01ee5c28);
      }
    }
    DAT_01ee5a10 = &DAT_01ee5a18;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee5a10;
}



/* FUNCTION 19512 ; VA 0x009eebd0 ; FUN_009eebd0 */

void FUN_009eebd0(void)

{
  int iVar1;
  
  if (DAT_01ee5c2c == 0) {
    iVar1 = FUN_009eead0();
    DAT_01ee5c2c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19513 ; VA 0x009eebf0 ; FUN_009eebf0 */

int FUN_009eebf0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8450;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00970740(param_1,param_2);
  uStack_8 = 0;
  *(undefined4 *)(iVar5 + 8) = *param_3;
  *(undefined4 *)(iVar5 + 0xc) = param_3[1];
  *(undefined4 *)(iVar5 + 0x10) = 0;
  uVar1 = param_3[2];
  if (uVar1 != 0) {
    *(uint *)(iVar5 + 0x10) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_3 + 4,iVar5 + 0x18,0);
    }
    else {
      uVar2 = param_3[5];
      uVar3 = param_3[6];
      uVar4 = param_3[7];
      *(undefined4 *)(iVar5 + 0x18) = param_3[4];
      *(undefined4 *)(iVar5 + 0x1c) = uVar2;
      *(undefined4 *)(iVar5 + 0x20) = uVar3;
      *(undefined4 *)(iVar5 + 0x24) = uVar4;
      *(undefined8 *)(iVar5 + 0x28) = *(undefined8 *)(param_3 + 8);
    }
  }
  *(undefined4 *)(iVar5 + 0x30) = param_3[10];
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19514 ; VA 0x009eec92 ; Catch_All@009eec92 */

void Catch_All_009eec92(void)

{
  int unaff_EBP;
  
  FUN_00875970(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19515 ; VA 0x009eecb0 ; FUN_009eecb0 */

undefined4 * __fastcall FUN_009eecb0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d847b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::TimerService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_009eead0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  FUN_00f45140();
  *param_1 = RBX::TimerService::vftable;
  param_1[0x16] = RBX::TimerService::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  uVar1 = FUN_00970740(0,0);
  param_1[0x19] = uVar1;
  param_1[0x18] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19516 ; VA 0x009eed50 ; FUN_009eed50 */

void __fastcall FUN_009eed50(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::TimerService>::vftable;
  uVar1 = FUN_009eead0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19517 ; VA 0x009eed90 ; FUN_009eed90 */

void __fastcall FUN_009eed90(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  ExceptionList = &pvStack_10;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar1 = (int *)*piVar4;
      uVar2 = piVar4[4];
      uStack_8 = 0;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(piVar4 + 6,piVar4 + 6,2);
          }
        }
        piVar4[4] = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(piVar4,0x38);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19518 ; VA 0x009eee36 ; FUN_009eee36 */

void FUN_009eee36(void)

{
  FUN_009eee40();
  return;
}



/* FUNCTION 19519 ; VA 0x009eee40 ; FUN_009eee40 */

undefined4 __thiscall FUN_009eee40(undefined4 param_1,byte param_2)

{
  FUN_009eed90();
  FUN_00f45160();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x6c);
  }
  return param_1;
}



/* FUNCTION 19520 ; VA 0x009eee80 ; FUN_009eee80 */

void __thiscall FUN_009eee80(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = *(int **)(param_1 + 100);
  piVar2 = (int *)*piVar1;
  if (piVar2 != piVar1) {
    while (piVar2[0xc] != param_2) {
      piVar2 = (int *)*piVar2;
      if (piVar2 == piVar1) {
        return;
      }
    }
    FUN_009ef170(&param_2,piVar2);
  }
  return;
}



/* FUNCTION 19521 ; VA 0x009eeec0 ; FUN_009eeec0 */

undefined4 * FUN_009eeec0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005cf1e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19522 ; VA 0x009eef30 ; FUN_009eef30 */

undefined4 __thiscall
FUN_009eef30(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8,undefined4 param_9,
            undefined4 *param_10)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  double *pdVar3;
  undefined4 uVar4;
  double dStack_8c;
  uint auStack_84 [2];
  undefined auStack_7c [24];
  undefined4 uStack_64;
  uint auStack_5c [2];
  undefined auStack_54 [24];
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined auStack_1c [8];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d84b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x60) = *(int *)(param_1 + 0x60) + 1;
  dStack_8c = 0.0;
  auStack_84[0] = 0;
  uStack_8 = 1;
  iStack_14 = param_1;
  pdVar3 = (double *)FUN_01682800(auStack_1c);
  auStack_3c[0] = 0;
  dStack_8c = *pdVar3 + (double)CONCAT44(param_10,param_9);
  if (param_2 != 0) {
    auStack_3c[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_34,0);
    }
    else {
      uStack_34 = param_4;
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
    }
  }
  auStack_5c[0] = 0;
  uStack_8._0_1_ = 3;
  FUN_005880d0(auStack_3c);
  FUN_005880d0(auStack_84);
  FUN_005880d0(auStack_5c);
  uStack_8._0_1_ = 4;
  if (((auStack_5c[0] != 0) && ((auStack_5c[0] & 1) == 0)) &&
     (*(code **)(auStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_5c[0] & 0xfffffffe))(auStack_54,auStack_54,2);
  }
  uStack_8._0_1_ = 5;
  if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
     (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  uStack_64 = *(undefined4 *)(param_1 + 0x60);
  puVar1 = *(undefined4 **)(param_1 + 100);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar2 = (undefined4 *)*puVar1;
  do {
    if (puVar2 == puVar1) {
      param_10 = (undefined4 *)puVar1[1];
      uVar4 = FUN_009eebf0(puVar1,param_10,&dStack_8c);
      if (*(int *)(iStack_14 + 0x68) == 0x4924923) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(iStack_14 + 0x68) = *(int *)(iStack_14 + 0x68) + 1;
      puVar1[1] = uVar4;
      *param_10 = uVar4;
LAB_009ef0e9:
      uVar4 = uStack_64;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (auStack_84[0] != 0) {
        if (((auStack_84[0] & 1) == 0) && (*(code **)(auStack_84[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_84[0] & 0xfffffffe))(auStack_7c,auStack_7c,2);
        }
        auStack_84[0] = 0;
      }
      uStack_8 = 7;
      if (((param_2 != 0) && ((param_2 & 1) == 0)) &&
         (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
      }
      ExceptionList = pvStack_10;
      return uVar4;
    }
    if (dStack_8c < *(double *)(puVar2 + 2)) {
      param_10 = (undefined4 *)puVar2[1];
      uVar4 = FUN_009eebf0(puVar2,param_10,&dStack_8c);
      if (*(int *)(iStack_14 + 0x68) == 0x4924923) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(iStack_14 + 0x68) = *(int *)(iStack_14 + 0x68) + 1;
      puVar2[1] = uVar4;
      *param_10 = uVar4;
      goto LAB_009ef0e9;
    }
    puVar2 = (undefined4 *)*puVar2;
  } while( true );
}



/* FUNCTION 19523 ; VA 0x009ef170 ; FUN_009ef170 */

void __thiscall FUN_009ef170(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  *(int *)param_3[1] = *param_3;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  uVar2 = param_3[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_3 + 6,param_3 + 6,2);
      }
    }
    param_3[4] = 0;
  }
  FUN_01674ea0(param_3,0x38);
  *param_2 = iVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19524 ; VA 0x009ef200 ; FUN_009ef200 */

uint FUN_009ef200(void)

{
  int iVar1;
  
  iVar1 = FUN_009eead0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19525 ; VA 0x009ef220 ; FUN_009ef220 */

uint FUN_009ef220(void)

{
  int iVar1;
  
  iVar1 = FUN_009eead0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19526 ; VA 0x009ef240 ; FUN_009ef240 */

void __fastcall FUN_009ef240(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  double adStack_2c [2];
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d84c8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_01682800(adStack_2c);
  if ((*(int *)(param_1 + 0x10) != 0) &&
     (iVar1 = **(int **)(param_1 + 0xc), *(double *)(iVar1 + 8) <= adStack_2c[0])) {
    uStack_8 = 0;
    if (*(uint *)(iVar1 + 0x10) != 0) {
      (**(code **)((*(uint *)(iVar1 + 0x10) & 0xfffffffe) + 4))(iVar1 + 0x18);
      FUN_009ef2cf();
      return;
    }
    uVar2 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19527 ; VA 0x009ef2aa ; Catch@009ef2aa */

undefined * Catch_009ef2aa(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = FUN_008ed2c0(*(int *)(unaff_EBP + -0x14) + -0x58);
  FUN_0086eff0(2,*(undefined4 *)(unaff_EBP + -0x1c),uVar1);
  return &DAT_009ef2ca;
}



/* FUNCTION 19528 ; VA 0x009ef2cf ; FUN_009ef2cf */

void FUN_009ef2cf(void)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  
  puVar3 = *(undefined4 **)(unaff_ESI + 0xc);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_009ef170(unaff_EBP + -0x20,*puVar3);
  if ((*(int *)(unaff_EDI + 0x10) != 0) &&
     (iVar1 = **(int **)(unaff_ESI + 0xc), *(double *)(iVar1 + 8) <= *(double *)(unaff_EBP + -0x28))
     ) {
    uVar2 = *(uint *)(iVar1 + 0x10);
    *(undefined4 *)(unaff_EBP + -4) = 0;
    if (uVar2 != 0) {
      (**(code **)((uVar2 & 0xfffffffe) + 4))(iVar1 + 0x18);
      FUN_009ef2cf();
      return;
    }
    uVar4 = FUN_0054fda0();
    *(undefined *)(unaff_EBP + -4) = 1;
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar4);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 19529 ; VA 0x009ef310 ; FUN_009ef310 */

void FUN_009ef310(undefined4 param_1,undefined4 param_2)

{
  FUN_008a4210(param_1,param_2);
  FUN_00f45260(param_1,param_2);
  return;
}



/* FUNCTION 19530 ; VA 0x009ef340 ; FUN_009ef340 */

int * __thiscall
FUN_009ef340(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009ef640();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::VersionControlService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::VersionControlService::*)(void)const_,void_(__thiscall_RBX::VersionControlService::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::VersionControlService,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::VersionControlService,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19531 ; VA 0x009ef440 ; FUN_009ef440 */

void __thiscall
FUN_009ef440(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uStack_364;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  int iStack_358;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d852a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  iStack_8 = 0;
  pcStack_14 = *(code **)(*(int *)*param_1 + 4);
  uStack_24 = uVar1;
  uStack_364 = FUN_0088cbe0();
  uStack_360 = 0;
  iStack_358 = param_2[1];
  if (iStack_358 != 0) {
    LOCK();
    *(int *)(iStack_358 + 4) = *(int *)(iStack_358 + 4) + 1;
    UNLOCK();
    iStack_358 = param_2[1];
  }
  uStack_35c = *param_2;
  uStack_360 = FUN_00630900();
  iStack_8._0_1_ = 1;
  uStack_294 = FUN_0088cbe0();
  uStack_290 = 0;
  iStack_288 = param_3[1];
  if (iStack_288 != 0) {
    LOCK();
    *(int *)(iStack_288 + 4) = *(int *)(iStack_288 + 4) + 1;
    UNLOCK();
    iStack_288 = param_3[1];
  }
  uStack_28c = *param_3;
  uStack_290 = FUN_00630900();
  iStack_8._0_1_ = 2;
  uStack_1c4 = FUN_0088cbe0();
  uStack_1c0 = 0;
  iStack_1b8 = param_4[1];
  if (iStack_1b8 != 0) {
    LOCK();
    *(int *)(iStack_1b8 + 4) = *(int *)(iStack_1b8 + 4) + 1;
    UNLOCK();
    iStack_1b8 = param_4[1];
  }
  uStack_1bc = *param_4;
  uStack_1c0 = FUN_00630900();
  iStack_8._0_1_ = 3;
  uStack_f4 = FUN_0088cb40();
  uStack_f0 = 0;
  FUN_0054ef60(param_5);
  uStack_f0 = FUN_005c9d30();
  iStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_364,&uStack_24,param_2);
  iStack_8._0_1_ = 5;
  (*pcStack_14)(&uStack_20);
  iStack_8._0_1_ = 6;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_364,0xd0,4,FUN_0056e5b0);
  iStack_8 = 7;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19532 ; VA 0x009ef640 ; FUN_009ef640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009ef640(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8560;
  pvStack_10 = ExceptionList;
  if (DAT_01ee5c84 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee5e98) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee5e98);
      if (DAT_01ee5e98 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"VersionControlService",1,uStack_20,0,0,3,3,0);
        _DAT_01ee5e90 = RBX::Creator<class_RBX::VersionControlService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee5c88,&DAT_01ee5e90);
        FUN_016f3654(FUN_01888540);
        FUN_016f37bf(&DAT_01ee5e98);
      }
    }
    DAT_01ee5c84 = &DAT_01ee5c88;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee5c84;
}



/* FUNCTION 19533 ; VA 0x009ef740 ; FUN_009ef740 */

void FUN_009ef740(void)

{
  int iVar1;
  
  if (DAT_01ee5e9c == 0) {
    iVar1 = FUN_009ef640();
    DAT_01ee5e9c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19534 ; VA 0x009ef760 ; FUN_009ef760 */

int FUN_009ef760(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = FUN_005e9aa0(param_1,param_2);
  *(undefined4 *)(iVar2 + 8) = 0;
  *(undefined4 *)(iVar2 + 0xc) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 8) = *param_3;
  *(undefined4 *)(iVar2 + 0xc) = param_3[1];
  return iVar2;
}



/* FUNCTION 19535 ; VA 0x009ef7a0 ; FUN_009ef7a0 */

void FUN_009ef7a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_005e9aa0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = 0;
  *(undefined4 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  return;
}



/* FUNCTION 19536 ; VA 0x009ef7e0 ; FUN_009ef7e0 */

void __thiscall FUN_009ef7e0(int param_1,int *param_2,uint *param_3,int *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8570;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_3;
  iVar7 = *(int *)(param_1 + 4);
  iVar5 = (*(uint *)(param_1 + 0x18) &
          (((uVar1 >> 8 & 0xff ^ (uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193) * 0x1000193 ^
           uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193) * 8;
  iVar2 = *(int *)(*(int *)(param_1 + 0xc) + iVar5);
  if (iVar7 != iVar2) {
    iVar7 = **(int **)(*(int *)(param_1 + 0xc) + 4 + iVar5);
    while (iVar7 != iVar2) {
      iVar7 = *(int *)(iVar7 + 4);
      if (uVar1 == *(uint *)(iVar7 + 8)) {
        ExceptionList = &pvStack_10;
        FUN_009f33c0(param_4);
        *param_2 = iVar7;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  iVar2 = *param_4;
  ExceptionList = &pvStack_10;
  if (iVar7 != iVar2) {
    ExceptionList = &pvStack_10;
    *(int *)param_4[1] = iVar2;
    **(int **)(iVar2 + 4) = iVar7;
    **(undefined4 **)(iVar7 + 4) = param_4;
    iVar3 = *(int *)(iVar7 + 4);
    *(undefined4 *)(iVar7 + 4) = *(undefined4 *)(iVar2 + 4);
    *(int *)(iVar2 + 4) = param_4[1];
    param_4[1] = iVar3;
  }
  piVar6 = (int *)(iVar5 + *(int *)(param_1 + 0xc));
  if (*piVar6 == *(int *)(param_1 + 4)) {
    *piVar6 = (int)param_4;
    *(int **)(iVar5 + 4 + *(int *)(param_1 + 0xc)) = param_4;
  }
  else if (*piVar6 == iVar7) {
    *piVar6 = (int)param_4;
  }
  else {
    piVar4 = *(int **)piVar6[1];
    piVar6[1] = (int)piVar4;
    if (piVar4 != param_4) {
      iVar5 = iVar5 + *(int *)(param_1 + 0xc);
      *(undefined4 *)(iVar5 + 4) = *(undefined4 *)(*(int *)(iVar5 + 4) + 4);
    }
  }
  uStack_8 = 2;
  FUN_009f3310();
  *param_2 = (int)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19537 ; VA 0x009ef938 ; Catch_All@009ef938 */

void Catch_All_009ef938(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_009f55a0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19538 ; VA 0x009ef960 ; FUN_009ef960 */

void __thiscall FUN_009ef960(int param_1,int *param_2,uint *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8580;
  pvStack_10 = ExceptionList;
  uVar1 = *param_3;
  iVar7 = (*(uint *)(param_1 + 0x18) &
          (((*param_3 >> 8 & 0xff ^ (*param_3 & 0xff ^ 0x811c9dc5) * 0x1000193) * 0x1000193 ^
           uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193) * 8;
  piVar10 = (int *)(*(int *)(param_1 + 0xc) + iVar7);
  piVar8 = *(int **)(param_1 + 4);
  piVar2 = (int *)*piVar10;
  piVar11 = piVar8;
  if (piVar2 != piVar8) {
    piVar11 = *(int **)piVar10[1];
  }
  do {
    if (piVar11 == piVar2) {
      iVar3 = *piVar8;
      uStack_8 = 0xffffffff;
      puVar4 = *(undefined4 **)(iVar3 + 4);
      ExceptionList = &pvStack_10;
      uVar6 = FUN_009ef7a0(iVar3,puVar4,param_3);
      if (*(int *)(param_1 + 8) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *(undefined4 *)(iVar3 + 4) = uVar6;
      *puVar4 = uVar6;
      piVar8 = *(int **)(param_1 + 4);
      puVar4 = (undefined4 *)*piVar8;
      piVar2 = (int *)*puVar4;
      if (piVar11 != piVar2) {
        *(int **)puVar4[1] = piVar2;
        *(int **)piVar2[1] = piVar11;
        *(undefined4 **)piVar11[1] = puVar4;
        iVar3 = piVar11[1];
        piVar11[1] = piVar2[1];
        piVar2[1] = puVar4[1];
        puVar4[1] = iVar3;
        piVar8 = *(int **)(param_1 + 4);
      }
      puVar9 = (undefined4 *)(iVar7 + *(int *)(param_1 + 0xc));
      if ((int *)*puVar9 == piVar8) {
        *puVar9 = puVar4;
        *(undefined4 **)(iVar7 + 4 + *(int *)(param_1 + 0xc)) = puVar4;
      }
      else if ((int *)*puVar9 == piVar11) {
        *puVar9 = puVar4;
      }
      else {
        puVar5 = *(undefined4 **)puVar9[1];
        puVar9[1] = puVar5;
        if (puVar5 != puVar4) {
          iVar7 = iVar7 + *(int *)(param_1 + 0xc);
          *(undefined4 *)(iVar7 + 4) = *(undefined4 *)(*(int *)(iVar7 + 4) + 4);
        }
      }
      uStack_8 = 2;
      FUN_009f3310();
      *param_2 = (int)puVar4;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    piVar11 = (int *)piVar11[1];
  } while (uVar1 != piVar11[2]);
  *param_2 = (int)piVar11;
  *(undefined *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19539 ; VA 0x009efaf5 ; Catch_All@009efaf5 */

void Catch_All_009efaf5(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + 0xc));
  FUN_009f55a0(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19540 ; VA 0x009efb30 ; FUN_009efb30 */

int __thiscall FUN_009efb30(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  *param_1 = param_2;
  param_1[1] = (int)param_3;
  if ((param_2 != 0) && ((*(int *)(param_2 + 4) == 0 || (*(int *)(*(int *)(param_2 + 4) + 4) == 0)))
     ) {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
      param_3 = (int *)param_1[1];
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
    }
    *(int *)param_2 = param_2;
    piVar3 = *(int **)(param_2 + 4);
    *(int **)(param_2 + 4) = param_3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar3 = param_3 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*param_3)();
        LOCK();
        piVar3 = param_3 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  return param_2;
}



/* FUNCTION 19541 ; VA 0x009efbb0 ; FUN_009efbb0 */

undefined4 * __thiscall FUN_009efbb0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009f54d0;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19542 ; VA 0x009efc70 ; FUN_009efc70 */

void FUN_009efc70(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_008ae410();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 19543 ; VA 0x009efcd0 ; FUN_009efcd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009efcd0(int param_1,undefined4 *param_2,uint *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8598;
  pvStack_10 = ExceptionList;
  uVar2 = *param_3;
  uVar7 = (uVar2 >> 3) + uVar2;
  uVar6 = uVar7 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar8;
    }
    if (piVar4 == (int *)0x0) goto LAB_009efd6e;
    do {
      if (uVar7 == piVar4[1]) {
        if (uVar2 == piVar4[2]) break;
      }
      else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar6) goto LAB_009efd6e;
      piVar4 = (int *)*piVar4;
    } while (piVar4 != (int *)0x0);
  }
  if (piVar4 != (int *)0x0) {
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_009efd6e:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008b0490();
  if (param_4[1] != 0) {
    LOCK();
    piVar4 = (int *)(param_4[1] + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  _DAT_00000008 = *param_4;
  _DAT_0000000c = param_4[1];
  uVar6 = *(uint *)(param_1 + 8);
  uVar2 = uVar6 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar2 = FUN_005c9310(uVar2);
    if (uVar2 <= *(uint *)(param_1 + 4)) {
      uVar2 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar2);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar2) {
    uVar5 = uVar6 >> 1;
    if (uVar6 + (uVar6 >> 1) <= uVar2) {
      uVar5 = 1;
    }
    iVar3 = FUN_005c9310(uVar5 + uVar6);
    if (iVar3 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar3);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar8;
      while (puVar1 != (undefined4 *)0x0) {
        uVar2 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar4 = (int *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar2 * 4) == 0) {
          *piVar4 = (int)puVar8;
          puVar8 = puVar1;
        }
        else {
          *puVar8 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar8;
      }
    }
  }
  uVar2 = uVar7 % *(uint *)(param_1 + 4);
  piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  _DAT_00000004 = uVar7;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar4 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar8 = piVar4;
    _DAT_00000000 = *piVar4;
    *piVar4 = 0;
  }
  else {
    _DAT_00000000 = *piVar4;
    *(undefined4 *)*puVar8 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19544 ; VA 0x009efed0 ; FUN_009efed0 */

int * FUN_009efed0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00b73ae0(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 19545 ; VA 0x009effc0 ; FUN_009effc0 */

int FUN_009effc0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01eadddc,&LAB_00670d50);
  uVar3 = FUN_00676330();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00c2d700();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 19546 ; VA 0x009f0080 ; FUN_009f0080 */

undefined4 *
FUN_009f0080(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d85c2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x108);
  uStack_8 = 0;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 1;
    puVar6[2] = 1;
    *puVar6 = std::_Ref_count_obj<class_RBX::VersionHistoryCommitCoordinator>::vftable;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar2 = *param_3;
    uVar3 = param_3[1];
    uVar4 = *param_2;
    uVar5 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    FUN_00a044a0(uVar4,uVar5,uVar2,uVar3,param_4,param_5,param_6);
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009efb30(puVar6 + 4,puVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19547 ; VA 0x009f0170 ; FUN_009f0170 */

void FUN_009f0170(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d85e8;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x270);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar2 = *param_2;
  uStack_8 = 0;
  iVar3 = *(int *)(iVar2 + 0x1a0);
  iVar4 = FUN_0088cbe0();
  if (iVar3 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar3 = iVar2 + 0x1a8;
  if (*(int *)(iVar2 + 0x1a4) == 0) {
    iVar3 = 0;
  }
  if (*(int *)(iVar3 + 4) != 0) {
    LOCK();
    piVar5 = (int *)(*(int *)(iVar3 + 4) + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  iVar2 = *param_2;
  uStack_8._0_1_ = 1;
  iVar3 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088cbe0();
  if (iVar3 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar3 = iVar2 + 0xd8;
  if (*(int *)(iVar2 + 0xd4) == 0) {
    iVar3 = 0;
  }
  if (*(int *)(iVar3 + 4) != 0) {
    LOCK();
    piVar5 = (int *)(*(int *)(iVar3 + 4) + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  param_2 = (int *)*param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar2 = *param_2;
  iVar3 = FUN_0088cbe0();
  if (iVar2 == iVar3) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0xffffffff;
    FUN_009f5990(param_1,*piVar5,piVar5[1]);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19548 ; VA 0x009f02f0 ; FUN_009f02f0 */

void FUN_009f02f0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8610;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar2 = *param_2;
  uStack_8 = 0;
  iVar3 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088cbe0();
  if (iVar3 == iVar4) {
    iVar3 = iVar2 + 0xd8;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      iVar3 = 0;
    }
    if (*(int *)(iVar3 + 4) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(iVar3 + 4) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar2 = *param_2;
    iVar3 = FUN_0088cbe0();
    if (iVar2 == iVar3) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      if (piVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_009f5b40(param_1,*piVar5,piVar5[1]);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 19549 ; VA 0x009f0420 ; FUN_009f0420 */

undefined4 * __thiscall
FUN_009f0420(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d8641;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 19550 ; VA 0x009f0580 ; FUN_009f0580 */

undefined4 * __thiscall
FUN_009f0580(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d867c;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::VersionControlService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::VersionControlService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 19551 ; VA 0x009f0700 ; FUN_009f0700 */

undefined4 * __fastcall FUN_009f0700(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d86a6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_005e9aa0(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19552 ; VA 0x009f0790 ; FUN_009f0790 */

undefined4 * __fastcall FUN_009f0790(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d87cc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::VersionControlService,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_009ef640();
  param_1[3] = uVar1;
  param_1[0x16] = RBX::IVersionControlService::vftable;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uStack_8 = 1;
  param_1[0x1e] = 0;
  *param_1 = RBX::VersionControlService::vftable;
  param_1[0x16] = RBX::VersionControlService::vftable;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  *(undefined *)(param_1 + 0x2e) = 0;
  *(undefined *)(param_1 + 0x2f) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x30] = *ppuVar3;
  param_1[0x31] = 0;
  param_1[0x32] = 0x3f800000;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  *(undefined *)(param_1 + 0x35) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x36] = *ppuVar3;
  param_1[0x37] = 0;
  param_1[0x38] = 0x3f800000;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  *(undefined2 *)(param_1 + 0x3b) = 0;
  *(undefined *)((int)param_1 + 0xee) = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  uStack_8._0_1_ = 0xe;
  FUN_009f0700();
  uStack_8._0_1_ = 0xf;
  FUN_009f0700();
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  uStack_8._0_1_ = 0x14;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("VersionControlService",0x15);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19553 ; VA 0x009f0a60 ; FUN_009f0a60 */

void __fastcall FUN_009f0a60(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::VersionControlService>::vftable;
  uVar1 = FUN_009ef640(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19554 ; VA 0x009f0aa0 ; FUN_009f0aa0 */

void __fastcall FUN_009f0aa0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009f3680();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x10);
  return;
}



/* FUNCTION 19555 ; VA 0x009f0b10 ; FUN_009f0b10 */

void __fastcall FUN_009f0b10(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_009f0c20();
      FUN_01674ea0(piVar3,0x80);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x80);
  return;
}



/* FUNCTION 19556 ; VA 0x009f0b70 ; FUN_009f0b70 */

void __fastcall FUN_009f0b70(undefined4 *param_1)

{
  FUN_009f3680();
  FUN_01674ea0(*param_1,0x10);
  return;
}



/* FUNCTION 19557 ; VA 0x009f0b90 ; FUN_009f0b90 */

void __fastcall FUN_009f0b90(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_009efc70(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x38);
  }
  return;
}



/* FUNCTION 19558 ; VA 0x009f0bc0 ; FUN_009f0bc0 */

void __fastcall FUN_009f0bc0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00612580();
      piVar3 = *(int **)(iVar2 + 0xc);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x28);
  }
  return;
}



/* FUNCTION 19559 ; VA 0x009f0c20 ; FUN_009f0c20 */

void __fastcall FUN_009f0c20(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = param_1[0x1c];
  if (0xf < uVar2) {
    iVar3 = param_1[0x17];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009f0d63;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  *(undefined *)(param_1 + 0x17) = 0;
  uVar2 = param_1[0x13];
  if (0xf < uVar2) {
    iVar3 = param_1[0xe];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009f0d63;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  *(undefined *)(param_1 + 0xe) = 0;
  uVar2 = param_1[0xd];
  if (0xf < uVar2) {
    iVar3 = param_1[8];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009f0d63;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = (int *)param_1[7];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar2 = param_1[5];
  if (0xf < uVar2) {
    iVar3 = *param_1;
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_009f0d63:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 19560 ; VA 0x009f0d70 ; FUN_009f0d70 */

void __fastcall FUN_009f0d70(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_009efc70(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 19561 ; VA 0x009f0e20 ; FUN_009f0e20 */

void __fastcall FUN_009f0e20(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        FUN_00612580();
        piVar3 = (int *)puVar7[3];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 19562 ; VA 0x009f0ee0 ; FUN_009f0ee0 */

void __fastcall FUN_009f0ee0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar5 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar3 = iVar1;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  piVar4 = *(int **)(param_1 + 4);
  piVar6 = (int *)*piVar4;
  *piVar4 = (int)piVar4;
  *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
  *(undefined4 *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar6 != piVar4) {
    do {
      piVar2 = (int *)*piVar6;
      FUN_009f0c20();
      FUN_01674ea0(piVar6,0x80);
      piVar4 = *(int **)(param_1 + 4);
      piVar6 = piVar2;
    } while (piVar2 != piVar4);
  }
  FUN_01674ea0(piVar4,0x80);
  return;
}



/* FUNCTION 19563 ; VA 0x009f0f90 ; FUN_009f0f90 */

void __fastcall FUN_009f0f90(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_009efc70(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 19564 ; VA 0x009f0fa0 ; FUN_009f0fa0 */

void __fastcall FUN_009f0fa0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        FUN_00612580();
        piVar3 = (int *)puVar7[3];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 19565 ; VA 0x009f0fb0 ; FUN_009f0fb0 */

void __fastcall FUN_009f0fb0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009f3680();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x10);
  return;
}



/* FUNCTION 19566 ; VA 0x009f0fc0 ; FUN_009f0fc0 */

void FUN_009f0fc0(void)

{
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  return;
}



/* FUNCTION 19567 ; VA 0x009f1010 ; FUN_009f1010 */

void __fastcall FUN_009f1010(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x58);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x44);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009f110f;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0xf;
  *(undefined *)(param_1 + 0x44) = 0;
  uVar2 = *(uint *)(param_1 + 0x34);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x20);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009f110f;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_009f110f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009f1109. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 19568 ; VA 0x009f1120 ; FUN_009f1120 */

void __fastcall FUN_009f1120(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5f60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x144);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x140);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x13c);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x138);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_009f0aa0();
  FUN_009f0aa0();
  piVar1 = *(int **)(param_1 + 0xf4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_009f0e20();
  FUN_009f0d70();
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xb4);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xb0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 6;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xac);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19569 ; VA 0x009f13e0 ; FUN_009f13e0 */

void __fastcall FUN_009f13e0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  
  FUN_016dedfb(param_1 + 200);
  uVar6 = *(uint *)(param_1 + 0x84);
  if (0xf < uVar6) {
    iVar1 = *(int *)(param_1 + 0x70);
    uVar5 = uVar6 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) goto LAB_009f15b1;
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0xf;
  *(undefined *)(param_1 + 0x70) = 0;
  uVar6 = *(uint *)(param_1 + 0x6c);
  if (0xf < uVar6) {
    iVar1 = *(int *)(param_1 + 0x58);
    uVar5 = uVar6 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) goto LAB_009f15b1;
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    uVar6 = *(int *)(param_1 + 0x4c) - iVar1 & 0xfffffffc;
    iVar3 = iVar1;
    if (0xfff < uVar6) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
LAB_009f15b1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar6);
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
    *(undefined4 *)(param_1 + 0x4c) = 0;
  }
  piVar4 = *(int **)(param_1 + 0x3c);
  piVar7 = (int *)*piVar4;
  *piVar4 = (int)piVar4;
  *(int *)(*(int *)(param_1 + 0x3c) + 4) = *(int *)(param_1 + 0x3c);
  *(undefined4 *)(param_1 + 0x40) = 0;
  piVar4 = *(int **)(param_1 + 0x3c);
  if (piVar7 != piVar4) {
    do {
      piVar2 = (int *)*piVar7;
      FUN_009f0c20();
      FUN_01674ea0(piVar7,0x80);
      piVar4 = *(int **)(param_1 + 0x3c);
      piVar7 = piVar2;
    } while (piVar2 != piVar4);
  }
  FUN_01674ea0(piVar4,0x80);
  piVar4 = *(int **)(param_1 + 0x28);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar1 = piVar4[1] + -1;
    piVar4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar1 = piVar4[2] + -1;
      piVar4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x20);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar1 = piVar4[1] + -1;
    piVar4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar1 = piVar4[2] + -1;
      piVar4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar7 = piVar4 + 2;
    iVar1 = *piVar7;
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (iVar1 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009f15aa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar4 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 19570 ; VA 0x009f15c0 ; FUN_009f15c0 */

int * __thiscall FUN_009f15c0(byte *param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  undefined **ppuVar6;
  int iVar7;
  undefined **ppuVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  undefined4 *puVar12;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d87f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0055c740(param_1 + *param_1 + 1,param_2);
  uStack_14 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar12 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    uVar11 = uStack_14;
    if (puVar12 == (undefined4 *)0x0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      puVar12 = (undefined4 *)*puVar12;
    }
    for (; puVar12 != (undefined4 *)0x0; puVar12 = (undefined4 *)*puVar12) {
      if (uVar4 == puVar12[1]) {
        cVar3 = FUN_00558b30(param_2,puVar12 + 2);
        uVar11 = uStack_14;
        if (cVar3 != '\0') {
          if (puVar12 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar12 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar12[1] % *(uint *)(param_1 + 4) != uVar11) break;
    }
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar5 = (int *)FUN_01674e20(0x38);
  piStack_18 = piVar5 + 2;
  *piVar5 = 0;
  piVar5[1] = 0;
  piStack_20 = piVar5;
  FUN_0170d1f0(piStack_18,0,0x30);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  *(undefined *)(piVar5 + 8) = 0;
  uStack_14 = 0xb;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  piVar5[9] = (int)*ppuVar8;
  piVar5[10] = 0;
  piVar5[0xb] = 0x3f800000;
  piVar5[0xc] = 0;
  piVar5[0xd] = 0;
  if (0xf < uStack_28) {
    uVar11 = uStack_28 + 1;
    iVar7 = aiStack_3c[0];
    if (0xfff < uVar11) {
      iVar7 = *(int *)(aiStack_3c[0] + -4);
      uVar11 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar11);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar11 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar11 = FUN_005c9310(uVar11);
    if (uVar11 <= *(uint *)(param_1 + 4)) {
      uVar11 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar11);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar11) {
    uStack_14 = 1;
    uVar9 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar11) {
      uVar9 = 1;
    }
    iVar7 = FUN_005c9310(uVar9 + uVar1);
    if (iVar7 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar7);
      puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar12;
      while (puVar2 != (undefined4 *)0x0) {
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4)
        ;
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar10 = (int)puVar12;
          puVar12 = puVar2;
        }
        else {
          *puVar12 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar12;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar12 = piVar10;
    *piVar5 = *piVar10;
  }
  else {
    *piVar5 = *piVar10;
    piVar10 = (int *)*puVar12;
  }
  *piVar10 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 19571 ; VA 0x009f1870 ; FUN_009f1870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009f1870(int param_1,uint *param_2)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d8810;
  pvStack_10 = ExceptionList;
  uVar3 = *param_2;
  uVar9 = (uVar3 >> 3) + uVar3;
  uVar8 = uVar9 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      if (uVar9 == puVar5[1]) {
        if (uVar3 == puVar5[2]) {
          if (puVar5 != (undefined4 *)0x0) {
            return puVar5 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar5[1] % *(uint *)(param_1 + 4) != uVar8) break;
    }
  }
  piVar10 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
    piVar10 = (int *)param_2[1];
  }
  param_2 = (uint *)*param_2;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  FUN_009f3f60();
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
  }
  _DAT_00000008 = (uint)param_2;
  DAT_00000010 = 0;
  param_2 = (uint *)0xb;
  _DAT_0000000c = piVar10;
  ppuVar2 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  ppuVar6 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar2;
  }
  _DAT_00000014 = *ppuVar6;
  _DAT_00000018 = 0;
  _DAT_0000001c = 0x3f800000;
  _DAT_00000020 = 0;
  uRam00000024 = 0;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar4 = piVar10[1] + -1;
    piVar10[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar4 = piVar10[2] + -1;
      piVar10[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  uVar8 = *(uint *)(param_1 + 8);
  uVar3 = uVar8 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005c9310(uVar3);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar3) {
    param_2 = (uint *)0x1;
    uVar7 = uVar8 >> 1;
    if (uVar8 + (uVar8 >> 1) <= uVar3) {
      uVar7 = 1;
    }
    iVar4 = FUN_005c9310(uVar7 + uVar8);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar5;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar10 = (int)puVar5;
          puVar5 = puVar1;
        }
        else {
          *puVar5 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar5;
      }
    }
  }
  uVar3 = uVar9 % *(uint *)(param_1 + 4);
  piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  _DAT_00000004 = uVar9;
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar5 = piVar10;
    _DAT_00000000 = *piVar10;
    *piVar10 = 0;
  }
  else {
    _DAT_00000000 = *piVar10;
    *(undefined4 *)*puVar5 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  FUN_009f0bc0();
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 19572 ; VA 0x009f1af0 ; FUN_009f1af0 */

int FUN_009f1af0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_005cf8d0(-(uint)(param_1 != 0) & param_1 + 0xcU);
  if (iVar4 != 0) {
    *(undefined4 *)(iVar4 + 0xf0) = 0;
    piVar3 = *(int **)(iVar4 + 0xf4);
    *(undefined4 *)(iVar4 + 0xf4) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  return iVar4;
}



/* FUNCTION 19573 ; VA 0x009f1b60 ; FUN_009f1b60 */

/* WARNING: Removing unreachable block (ram,0x009f1bfe) */
/* WARNING: Removing unreachable block (ram,0x009f1c0e) */
/* WARNING: Removing unreachable block (ram,0x009f1c14) */

void __thiscall FUN_009f1b60(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8838;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19574 ; VA 0x009f1c62 ; Catch@009f1c62 */

undefined * Catch_009f1c62(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_009f1c73;
}



/* FUNCTION 19575 ; VA 0x009f1c90 ; FUN_009f1c90 */

/* WARNING: Removing unreachable block (ram,0x009f1da1) */
/* WARNING: Removing unreachable block (ram,0x009f1db1) */
/* WARNING: Removing unreachable block (ram,0x009f1db7) */

void * __thiscall
FUN_009f1c90(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,int param_8)

{
  int *piVar1;
  void *pvVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8880;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 6;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar4 = param_3[2] + -1;
        param_3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar4 = param_5[1] + -1;
      param_5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar4 = param_5[2] + -1;
        param_5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    if (param_7 != (int *)0x0) {
      LOCK();
      iVar4 = param_7[1] + -1;
      param_7[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_7)();
        LOCK();
        piVar1 = param_7 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_7 + 4))();
        }
      }
    }
    pvVar2 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar2;
  }
  pvVar2 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      pvVar2 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar2 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar4 = *piVar1;
      pvVar2 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar2 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pvVar2 = (void *)(**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pvVar2 = (void *)(**(code **)(*param_7 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000030) {
    uVar5 = in_stack_00000030 + 1;
    iVar4 = param_8;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_8 + -4);
      uVar5 = in_stack_00000030 + 0x24;
      if (0x1f < (param_8 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pvVar2 = (void *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 19576 ; VA 0x009f1ea0 ; Catch@009f1ea0 */

undefined * Catch_009f1ea0(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_009f1eb1;
}



/* FUNCTION 19577 ; VA 0x009f1ed0 ; FUN_009f1ed0 */

/* WARNING: Removing unreachable block (ram,0x009f1fbe) */
/* WARNING: Removing unreachable block (ram,0x009f1fce) */
/* WARNING: Removing unreachable block (ram,0x009f1fd4) */

void * __thiscall
FUN_009f1ed0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            int param_6)

{
  int *piVar1;
  void *pvVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d88b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 5;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar4 = param_3[2] + -1;
        param_3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar4 = param_5[1] + -1;
      param_5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    pvVar2 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar2;
  }
  pvVar2 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      pvVar2 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar2 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pvVar2 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pvVar2 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    uVar5 = in_stack_00000028 + 1;
    iVar4 = param_6;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_6 + -4);
      uVar5 = in_stack_00000028 + 0x24;
      if (0x1f < (param_6 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pvVar2 = (void *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 19578 ; VA 0x009f2089 ; Catch@009f2089 */

undefined * Catch_009f2089(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_009f209a;
}



/* FUNCTION 19579 ; VA 0x009f20c0 ; FUN_009f20c0 */

undefined4 __thiscall FUN_009f20c0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x108);
  }
  return param_1;
}



/* FUNCTION 19580 ; VA 0x009f20f0 ; FUN_009f20f0 */

undefined4 __thiscall FUN_009f20f0(undefined4 param_1,byte param_2)

{
  FUN_009f1120();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 19581 ; VA 0x009f2120 ; FUN_009f2120 */

void __fastcall FUN_009f2120(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  uint uStack_58;
  undefined4 uStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  uint uStack_40;
  undefined4 uStack_3c;
  code *pcStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8a62;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iVar6 = FUN_008f7870(param_1);
  if (iVar6 == 0) {
    iVar7 = 0;
  }
  else {
    iVar7 = iVar6 + 0xc;
  }
  iVar7 = FUN_009effc0(iVar7);
  if (iVar7 != 0) {
    uStack_48 = 0xf00000000;
    uStack_58 = uStack_58 & 0xffffff00;
    uStack_8 = 0;
    if ((DAT_01ee5c34 < 1) || (DAT_01d658cc < 1)) {
      FUN_0054ef60(iVar7 + 0x70);
      FUN_005507b0();
      uStack_58 = uStack_40;
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_54 = uStack_3c;
      pcStack_50 = pcStack_38;
      uStack_4c = uStack_34;
      uStack_48 = CONCAT44(piStack_2c,iStack_30);
      iStack_30 = 0;
      piStack_2c = (int *)&DAT_0000000f;
      FUN_005507b0();
    }
    else {
      FUN_005542c0("testGuid",8);
    }
    if ((int)uStack_48 != 0) {
      iStack_14 = *(int *)(iVar7 + 0x88);
      if (iStack_14 == 0) {
        iStack_14 = *(int *)(iVar6 + 0x450);
      }
      iStack_20 = *(undefined4 *)(iVar7 + 0x90);
      iStack_1c = *(int *)(iVar7 + 0x94);
      puVar8 = (undefined4 *)FUN_005c4330(&iStack_30,iVar6);
      uStack_8._0_1_ = 1;
      puVar9 = (undefined4 *)FUN_01674e20(0x108);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (puVar9 == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
      }
      else {
        puVar9[1] = 1;
        puVar9[2] = 1;
        *puVar9 = std::_Ref_count_obj<class_RBX::VersionHistoryCommitCoordinator>::vftable;
        uVar3 = *puVar8;
        uVar4 = puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        piStack_24 = puVar9;
        FUN_00a04340(uVar3,uVar4,&uStack_58,iStack_14,iStack_20,iStack_1c);
      }
      uStack_28 = 0;
      piStack_24 = (int *)0x0;
      FUN_009efb30(puVar9 + 4,puVar9);
      iStack_20 = iStack_18 + 0xf0;
      FUN_005587e0(&uStack_28);
      piVar2 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_24[1] + -1;
        piStack_24[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_2c;
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      iVar6 = iStack_18;
      pcStack_38 = FUN_009f61b0;
      uStack_34 = 0;
      iStack_30 = iStack_18;
      iStack_20 = FUN_00915d30(&iStack_1c,&pcStack_38);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      cVar5 = FUN_01679300(iStack_20);
      if (cVar5 != '\0') {
        FUN_01679490();
        FUN_016791c0(iStack_20);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (iStack_1c != 0) {
        piVar2 = (int *)(iStack_1c + 4);
        LOCK();
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          FUN_01674ea0(iStack_1c);
        }
      }
      pcStack_38 = FUN_009f2470;
      uStack_34 = 0;
      iStack_30 = iVar6;
      iStack_20 = FUN_00915d30(&iStack_1c,&pcStack_38);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      cVar5 = FUN_01679300(iStack_20);
      if (cVar5 != '\0') {
        FUN_01679490();
        FUN_016791c0(iStack_20);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (iStack_1c != 0) {
        piVar2 = (int *)(iStack_1c + 4);
        LOCK();
        iVar6 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(iStack_1c);
        }
      }
      FUN_00a06a80();
    }
    if (0xf < uStack_48._4_4_) {
      uVar11 = uStack_48._4_4_ + 1;
      uVar10 = uStack_58;
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(uStack_58 - 4);
        uVar11 = uStack_48._4_4_ + 0x24;
        if (0x1f < (uStack_58 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19582 ; VA 0x009f2470 ; FUN_009f2470 */

void __fastcall FUN_009f2470(undefined4 param_1)

{
  char cVar1;
  undefined auStack_8 [4];
  
  FUN_008f7870(param_1);
  auStack_8[0] = 0;
  cVar1 = FUN_00585a40(auStack_8);
  if (cVar1 == '\0') {
    FUN_0090ca30(&DAT_0193d811);
    return;
  }
  FUN_0090ca30(0);
  return;
}



/* FUNCTION 19583 ; VA 0x009f24d0 ; FUN_009f24d0 */

uint ***** __thiscall
FUN_009f24d0(int *param_1,int *param_2,int *param_3,int *param_4,int *param_5,int *param_6,
            int *param_7,undefined4 param_8,undefined4 param_9)

{
  int *piVar1;
  uint uVar2;
  code *pcVar3;
  undefined uVar4;
  char cVar5;
  int iVar6;
  uint ****ppppuVar7;
  uint *****pppppuVar8;
  int iVar9;
  undefined4 uVar10;
  int **ppiVar11;
  int *piVar12;
  uint uVar13;
  uint ***pppuVar14;
  uint uVar15;
  uint *****pppppuVar16;
  uint *****pppppuVar17;
  uint ****ppppuVar18;
  undefined4 *puVar19;
  uint ****ppppuVar20;
  uint *puVar21;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  uint ***pppuStack_288;
  uint ***pppuStack_284;
  uint ***pppuStack_280;
  uint ***pppuStack_27c;
  undefined8 uStack_278;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined uStack_1b8;
  int aiStack_f0 [2];
  uint ***pppuStack_e8;
  uint ***pppuStack_e4;
  uint ***pppuStack_e0;
  uint ***pppuStack_dc;
  uint ****ppppuStack_d8;
  int *piStack_d4;
  uint ****ppppuStack_d0;
  uint ****ppppuStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  int iStack_c0;
  int *piStack_bc;
  undefined auStack_b8 [8];
  undefined auStack_b0 [8];
  undefined4 uStack_a8;
  uint ****ppppuStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  uint ***pppuStack_8c;
  uint ***pppuStack_88;
  uint ***pppuStack_84;
  uint ***pppuStack_80;
  uint ****ppppuStack_7c;
  uint ****ppppuStack_78;
  int iStack_74;
  uint ****ppppuStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  uint ****ppppuStack_60;
  uint ****ppppuStack_5c;
  int *piStack_58;
  int *piStack_54;
  int *piStack_50;
  uint ****ppppuStack_4c;
  uint ***pppuStack_48;
  uint ***pppuStack_44;
  uint ***pppuStack_40;
  uint ***pppuStack_3c;
  uint ****ppppuStack_38;
  uint ****ppppuStack_34;
  int *piStack_30;
  uint ****ppppuStack_2c;
  uint ****ppppuStack_28;
  uint ****ppppuStack_24;
  uint ****ppppuStack_20;
  uint ****ppppuStack_1c;
  uint uStack_18;
  uint ****ppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d8b47;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 2;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  iStack_74 = FUN_008f7870(param_1);
  ppppuStack_2c = (uint ****)0x0;
  iVar9 = param_2[1] - *param_2 >> 0x1f;
  if ((param_2[1] - *param_2) / 0xd0 + iVar9 != iVar9) {
    ppppuStack_4c = (uint ****)0x0;
    do {
      iVar9 = *(int *)(*param_2 + (int)ppppuStack_4c);
      ppppuStack_14 = (uint ****)(*param_2 + (int)ppppuStack_4c);
      iVar6 = FUN_0088cb40();
      if (iVar9 != iVar6) goto LAB_009f3302;
      ppppuStack_60 = (uint ****)0x0;
      ppppuStack_5c = (uint ****)0x0;
      puVar19 = (undefined4 *)
                (-(uint)((uint ****)ppppuStack_14[1] != (uint ****)0x0) & (uint)(ppppuStack_14 + 2))
      ;
      ppppuStack_20 = (uint ****)puVar19[4];
      if (0xf < (uint)puVar19[5]) {
        puVar19 = (undefined4 *)*puVar19;
      }
      if (&DAT_0000000f < ppppuStack_20) {
        ppppuStack_14 = (uint ****)((uint)ppppuStack_20 | 0xf);
        if ((uint *****)0x7fffffff < ppppuStack_14) {
          ppppuStack_14 = (uint ****)0x7fffffff;
        }
        pppppuVar17 = (uint *****)((int)ppppuStack_14 + 1);
        if (pppppuVar17 < &DAT_00001000) {
          if (pppppuVar17 == (uint *****)0x0) {
            ppppuStack_70 = (uint ****)0x0;
          }
          else {
            ppppuStack_70 = (uint ****)FUN_01674e20(pppppuVar17);
          }
        }
        else {
          pppppuVar16 = (uint *****)ppppuStack_14 + 9;
          if (pppppuVar16 <= pppppuVar17) {
            pppppuVar16 = (uint *****)0xffffffff;
          }
          ppppuVar18 = (uint ****)FUN_01674e20(pppppuVar16);
          if (ppppuVar18 == (uint ****)0x0) goto LAB_009f32f3;
          ppppuStack_70 = (uint ****)((int)ppppuVar18 + 0x23U & 0xffffffe0);
          ((uint *****)ppppuStack_70)[-1] = ppppuVar18;
        }
        FUN_0170c6f0(ppppuStack_70,puVar19,(undefined *)((int)ppppuStack_20 + 1));
        ppppuStack_5c = ppppuStack_14;
      }
      else {
        ppppuStack_70 = (uint ****)*puVar19;
        uStack_6c = puVar19[1];
        uStack_68 = puVar19[2];
        uStack_64 = puVar19[3];
        ppppuStack_5c = (uint ****)&DAT_0000000f;
      }
      uStack_8 = 3;
      ppppuStack_60 = ppppuStack_20;
      FUN_008fbc70(&piStack_58,&ppppuStack_70);
      uStack_8 = 4;
      uVar4 = uStack_8;
      uStack_8 = 4;
      if (piStack_58 == (int *)0x0) {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        uStack_8 = uVar4;
        pppppuVar17 = (uint *****)FUN_009f9770(param_2,param_3,param_9,1);
LAB_009f29a5:
        piVar12 = piStack_54;
        if (piStack_54 != (int *)0x0) {
          LOCK();
          piVar1 = piStack_54 + 1;
          iVar9 = *piVar1;
          pppppuVar17 = (uint *****)*piVar1;
          *piVar1 = iVar9 + -1;
          UNLOCK();
          if (iVar9 + -1 == 0) {
            (**(code **)*piStack_54)();
            LOCK();
            piVar1 = piVar12 + 2;
            iVar9 = *piVar1;
            pppppuVar17 = (uint *****)*piVar1;
            *piVar1 = iVar9 + -1;
            UNLOCK();
            if (iVar9 + -1 == 0) {
              pppppuVar17 = (uint *****)(**(code **)(*piVar12 + 4))();
            }
          }
        }
        if (&DAT_0000000f < ppppuStack_5c) {
          pppppuVar16 = (uint *****)((int)ppppuStack_5c + 1);
          pppppuVar17 = (uint *****)ppppuStack_70;
          if ((uint *****)0xfff < pppppuVar16) {
            pppppuVar17 = (uint *****)ppppuStack_70[-1];
            pppppuVar16 = (uint *****)(ppppuStack_5c + 9);
            if ((undefined *)0x1f < (undefined *)((int)ppppuStack_70 + (-4 - (int)pppppuVar17))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          pppppuVar17 = (uint *****)FUN_01674ea0(pppppuVar17,pppppuVar16);
        }
        goto LAB_009f3270;
      }
      ppppuStack_14 = (uint ****)(*param_4 + (int)ppppuStack_4c);
      ppppuVar18 = (uint ****)*ppppuStack_14;
      ppppuVar7 = (uint ****)FUN_0088cb40();
      if (ppppuVar18 != ppppuVar7) goto LAB_009f3302;
      ppppuStack_7c = (uint ****)0x0;
      ppppuStack_78 = (uint ****)0x0;
      ppppuStack_24 = ppppuStack_14 + 2;
      if ((uint ****)ppppuStack_14[1] == (uint ****)0x0) {
        ppppuStack_24 = (uint ****)0x0;
      }
      ppppuStack_1c = ((uint *****)ppppuStack_24)[4];
      if ((uint ****)0xf < ((uint *****)ppppuStack_24)[5]) {
        ppppuStack_24 = (uint ****)*ppppuStack_24;
      }
      if (&DAT_0000000f < ppppuStack_1c) {
        pppppuVar17 = (uint *****)((uint)ppppuStack_1c | 0xf);
        if ((uint *****)0x7fffffff < pppppuVar17) {
          pppppuVar17 = (uint *****)0x7fffffff;
        }
        pppppuVar16 = (uint *****)((int)pppppuVar17 + 1);
        ppppuStack_20 = (uint ****)pppppuVar17;
        if (pppppuVar16 < &DAT_00001000) {
          if (pppppuVar16 == (uint *****)0x0) {
            ppppuVar18 = (uint ****)0x0;
          }
          else {
            ppppuVar18 = (uint ****)FUN_01674e20(pppppuVar16);
          }
        }
        else {
          pppppuVar8 = pppppuVar17 + 9;
          if (pppppuVar8 <= pppppuVar16) {
            pppppuVar8 = (uint *****)0xffffffff;
          }
          pppuVar14 = (uint ***)FUN_01674e20(pppppuVar8);
          if (pppuVar14 == (uint ***)0x0) goto LAB_009f32f3;
          ppppuVar18 = (uint ****)((int)pppuVar14 + 0x23U & 0xffffffe0);
          ppppuVar18[-1] = pppuVar14;
        }
        pppuStack_8c = (uint ***)ppppuVar18;
        FUN_0170c6f0(ppppuVar18,ppppuStack_24,(undefined *)((int)ppppuStack_1c + 1));
        ppppuStack_78 = (uint ****)pppppuVar17;
      }
      else {
        ppppuVar18 = (uint ****)*ppppuStack_24;
        pppuStack_88 = (uint ***)((uint *****)ppppuStack_24)[1];
        pppuStack_84 = (uint ***)((uint *****)ppppuStack_24)[2];
        pppuStack_80 = (uint ***)((uint *****)ppppuStack_24)[3];
        ppppuStack_20 = (uint ****)&DAT_0000000f;
        ppppuStack_78 = (uint ****)&DAT_0000000f;
        pppuStack_8c = (uint ***)ppppuVar18;
      }
      uStack_8 = 5;
      ppppuStack_7c = ppppuStack_1c;
      ppppuStack_1c = (uint ****)(**(code **)(*piStack_58 + 0xac))();
      ppppuStack_38 = (uint ****)0x0;
      ppppuStack_34 = (uint ****)0x0;
      ppppuStack_14 = ((uint *****)ppppuStack_1c)[4];
      if ((uint ****)0xf < ((uint *****)ppppuStack_1c)[5]) {
        ppppuStack_1c = (uint ****)*ppppuStack_1c;
      }
      if (&DAT_0000000f < ppppuStack_14) {
        ppppuStack_24 = (uint ****)((uint)ppppuStack_14 | 0xf);
        if ((uint *****)0x7fffffff < ppppuStack_24) {
          ppppuStack_24 = (uint ****)0x7fffffff;
        }
        pppppuVar17 = (uint *****)((int)ppppuStack_24 + 1);
        if (pppppuVar17 < &DAT_00001000) {
          if (pppppuVar17 == (uint *****)0x0) {
            ppppuVar7 = (uint ****)0x0;
          }
          else {
            ppppuVar7 = (uint ****)FUN_01674e20(pppppuVar17);
          }
        }
        else {
          pppppuVar16 = (uint *****)ppppuStack_24 + 9;
          if (pppppuVar16 <= pppppuVar17) {
            pppppuVar16 = (uint *****)0xffffffff;
          }
          pppuVar14 = (uint ***)FUN_01674e20(pppppuVar16);
          if (pppuVar14 == (uint ***)0x0) goto LAB_009f32f3;
          ppppuVar7 = (uint ****)((int)pppuVar14 + 0x23U & 0xffffffe0);
          ppppuVar7[-1] = pppuVar14;
        }
        pppuStack_48 = (uint ***)ppppuVar7;
        FUN_0170c6f0(ppppuVar7,ppppuStack_1c,(undefined *)((int)ppppuStack_14 + 1));
      }
      else {
        ppppuVar7 = (uint ****)*ppppuStack_1c;
        pppuStack_44 = (uint ***)((uint *****)ppppuStack_1c)[1];
        pppuStack_40 = (uint ***)((uint *****)ppppuStack_1c)[2];
        pppuStack_3c = (uint ***)((uint *****)ppppuStack_1c)[3];
        ppppuStack_24 = (uint ****)&DAT_0000000f;
        pppuStack_48 = (uint ***)ppppuVar7;
      }
      uStack_8 = 6;
      ppppuStack_38 = ppppuStack_14;
      ppppuStack_34 = ppppuStack_24;
      cVar5 = FUN_00558b30(&pppuStack_48,&pppuStack_8c);
      if (cVar5 == '\0') {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        FUN_009f9770(param_2,param_3,param_9,1);
        if (&DAT_0000000f < ppppuStack_24) {
          pppppuVar17 = (uint *****)((int)ppppuStack_24 + 1);
          ppppuVar20 = ppppuVar7;
          if ((uint *****)0xfff < pppppuVar17) {
            ppppuVar20 = (uint ****)ppppuVar7[-1];
            pppppuVar17 = (uint *****)(ppppuStack_24 + 9);
            if (0x1f < (uint)((int)ppppuVar7 + (-4 - (int)ppppuVar20))) goto LAB_009f32f3;
          }
          FUN_01674ea0(ppppuVar20,pppppuVar17);
        }
        pppppuVar17 = (uint *****)ppppuStack_20;
        if (&DAT_0000000f < ppppuStack_20) {
          pppppuVar17 = (uint *****)((int)ppppuStack_20 + 1);
          ppppuVar7 = ppppuVar18;
          if ((uint *****)0xfff < pppppuVar17) {
            ppppuVar7 = (uint ****)ppppuVar18[-1];
            pppppuVar17 = (uint *****)(ppppuStack_20 + 9);
            if (0x1f < (uint)((int)ppppuVar18 + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          pppppuVar17 = (uint *****)FUN_01674ea0(ppppuVar7,pppppuVar17);
        }
        goto LAB_009f29a5;
      }
      uStack_8 = 5;
      if (&DAT_0000000f < ppppuStack_24) {
        pppppuVar17 = (uint *****)((int)ppppuStack_24 + 1);
        ppppuVar20 = ppppuVar7;
        if ((uint *****)0xfff < pppppuVar17) {
          ppppuVar20 = (uint ****)ppppuVar7[-1];
          pppppuVar17 = (uint *****)(ppppuStack_24 + 9);
          if (0x1f < (uint)((int)ppppuVar7 + (-4 - (int)ppppuVar20))) goto LAB_009f32f3;
        }
        FUN_01674ea0(ppppuVar20,pppppuVar17);
      }
      uStack_8 = 4;
      if (&DAT_0000000f < ppppuStack_20) {
        pppppuVar17 = (uint *****)((int)ppppuStack_20 + 1);
        ppppuVar7 = ppppuVar18;
        if ((uint *****)0xfff < pppppuVar17) {
          ppppuVar7 = (uint ****)ppppuVar18[-1];
          pppppuVar17 = (uint *****)(ppppuStack_20 + 9);
          if (0x1f < (uint)((int)ppppuVar18 + (-4 - (int)ppppuVar7))) goto LAB_009f32f3;
        }
        FUN_01674ea0(ppppuVar7,pppppuVar17);
      }
      piVar12 = piStack_54;
      if (piStack_54 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_54[1] + -1;
        piStack_54[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_54)();
          LOCK();
          piVar1 = piVar12 + 2;
          iVar9 = *piVar1 + -1;
          *piVar1 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar12 + 4))();
          }
        }
      }
      uStack_8 = 2;
      if (&DAT_0000000f < ppppuStack_5c) {
        pppppuVar16 = (uint *****)((int)ppppuStack_5c + 1);
        pppppuVar17 = (uint *****)ppppuStack_70;
        if ((uint *****)0xfff < pppppuVar16) {
          pppppuVar17 = (uint *****)ppppuStack_70[-1];
          pppppuVar16 = (uint *****)(ppppuStack_5c + 9);
          if ((undefined *)0x1f < (undefined *)((int)ppppuStack_70 + (-4 - (int)pppppuVar17)))
          goto LAB_009f32f3;
        }
        FUN_01674ea0(pppppuVar17,pppppuVar16);
      }
      ppppuStack_2c = (uint ****)((int)ppppuStack_2c + 1);
      ppppuStack_4c = ppppuStack_4c + 0x34;
    } while (ppppuStack_2c < (uint *****)((param_2[1] - *param_2) / 0xd0));
  }
  ppppuStack_2c = (uint ****)0x0;
  pppppuVar17 = (uint *****)((param_2[1] - *param_2) / 0xd0);
  if (pppppuVar17 != (uint *****)0x0) {
    do {
      ppppuStack_20 = (uint ****)((int)ppppuStack_2c * 0xd0);
      ppppuStack_14 = (uint ****)(*param_2 + (int)ppppuStack_20);
      ppppuVar18 = (uint ****)*ppppuStack_14;
      ppppuVar7 = (uint ****)FUN_0088cb40();
      if (ppppuVar18 != ppppuVar7) {
LAB_009f3302:
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      ppppuStack_60 = (uint ****)0x0;
      ppppuStack_5c = (uint ****)0x0;
      puVar19 = (undefined4 *)
                (-(uint)((uint ****)ppppuStack_14[1] != (uint ****)0x0) & (uint)(ppppuStack_14 + 2))
      ;
      ppppuStack_14 = (uint ****)puVar19[4];
      if (0xf < (uint)puVar19[5]) {
        puVar19 = (undefined4 *)*puVar19;
      }
      if (&DAT_0000000f < ppppuStack_14) {
        ppppuStack_1c = (uint ****)((uint)ppppuStack_14 | 0xf);
        if ((uint *****)0x7fffffff < ppppuStack_1c) {
          ppppuStack_1c = (uint ****)0x7fffffff;
        }
        pppppuVar17 = (uint *****)((int)ppppuStack_1c + 1);
        if (pppppuVar17 < &DAT_00001000) {
          if (pppppuVar17 == (uint *****)0x0) {
            ppppuStack_70 = (uint ****)0x0;
          }
          else {
            ppppuStack_70 = (uint ****)FUN_01674e20(pppppuVar17);
          }
        }
        else {
          pppppuVar16 = (uint *****)ppppuStack_1c + 9;
          if (pppppuVar16 <= pppppuVar17) {
            pppppuVar16 = (uint *****)0xffffffff;
          }
          ppppuVar18 = (uint ****)FUN_01674e20(pppppuVar16);
          if (ppppuVar18 == (uint ****)0x0) {
LAB_009f32f3:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          ppppuStack_70 = (uint ****)((int)ppppuVar18 + 0x23U & 0xffffffe0);
          ((uint *****)ppppuStack_70)[-1] = ppppuVar18;
        }
        FUN_0170c6f0(ppppuStack_70,puVar19,(undefined *)((int)ppppuStack_14 + 1));
        ppppuStack_60 = ppppuStack_14;
        ppppuStack_5c = ppppuStack_1c;
      }
      else {
        ppppuStack_70 = (uint ****)*puVar19;
        uStack_6c = puVar19[1];
        uStack_68 = puVar19[2];
        uStack_64 = puVar19[3];
        ppppuStack_5c = (uint ****)&DAT_0000000f;
        ppppuStack_60 = ppppuStack_14;
      }
      uStack_8 = 7;
      ppppuStack_14 = (uint ****)(*param_6 + (int)ppppuStack_20);
      ppppuVar18 = (uint ****)*ppppuStack_14;
      ppppuVar7 = (uint ****)FUN_0088cb40();
      if (ppppuVar18 != ppppuVar7) goto LAB_009f3302;
      ppppuStack_7c = (uint ****)0x0;
      ppppuStack_78 = (uint ****)0x0;
      puVar21 = (uint *)(-(uint)((uint ****)ppppuStack_14[1] != (uint ****)0x0) &
                        (uint)(ppppuStack_14 + 2));
      ppppuStack_14 = (uint ****)puVar21[4];
      if (0xf < puVar21[5]) {
        puVar21 = (uint *)*puVar21;
      }
      if (&DAT_0000000f < ppppuStack_14) {
        ppppuStack_1c = (uint ****)((uint)ppppuStack_14 | 0xf);
        if ((uint *****)0x7fffffff < ppppuStack_1c) {
          ppppuStack_1c = (uint ****)0x7fffffff;
        }
        pppppuVar17 = (uint *****)((int)ppppuStack_1c + 1);
        if (pppppuVar17 < &DAT_00001000) {
          if (pppppuVar17 == (uint *****)0x0) {
            pppuStack_8c = (uint ***)0x0;
          }
          else {
            pppuStack_8c = (uint ***)FUN_01674e20(pppppuVar17);
          }
        }
        else {
          pppppuVar16 = (uint *****)ppppuStack_1c + 9;
          if (pppppuVar16 <= pppppuVar17) {
            pppppuVar16 = (uint *****)0xffffffff;
          }
          pppuVar14 = (uint ***)FUN_01674e20(pppppuVar16);
          if (pppuVar14 == (uint ***)0x0) goto LAB_009f32f3;
          pppuStack_8c = (uint ***)((int)pppuVar14 + 0x23U & 0xffffffe0);
          ((uint ****)pppuStack_8c)[-1] = pppuVar14;
        }
        FUN_0170c6f0(pppuStack_8c,puVar21,(undefined *)((int)ppppuStack_14 + 1));
        ppppuStack_78 = ppppuStack_1c;
      }
      else {
        pppuStack_8c = (uint ***)*puVar21;
        pppuStack_88 = (uint ***)puVar21[1];
        pppuStack_84 = (uint ***)puVar21[2];
        pppuStack_80 = (uint ***)puVar21[3];
        ppppuStack_78 = (uint ****)&DAT_0000000f;
      }
      uStack_8 = 8;
      ppppuStack_7c = ppppuStack_14;
      FUN_008fbc70(&ppppuStack_28,&ppppuStack_70);
      _uStack_8 = CONCAT31(uStack_7,9);
      if (((uint *****)ppppuStack_28 == (uint *****)0x0) ||
         (ppppuVar18 = (uint ****)ppppuStack_28[3], iVar9 = FUN_00b73ae0(),
         (uint)*(ushort *)(iVar9 + 0x1da) <
         (uint)*(ushort *)(ppppuVar18 + 0x76) - (uint)*(ushort *)(iVar9 + 0x1d8))) {
        puVar19 = &uStack_a0;
        uVar15 = uStack_18 | 2;
        piStack_9c = (int *)0x0;
        ppppuStack_14 = (uint ****)0x0;
      }
      else {
        ppppuStack_14 = ppppuStack_28;
        if ((uint *****)ppppuStack_24 != (uint *****)0x0) {
          LOCK();
          ppppuStack_24[1] = (uint ***)((int)ppppuStack_24[1] + 1);
          UNLOCK();
        }
        puVar19 = &uStack_a8;
        ppppuStack_a4 = ppppuStack_24;
        uVar15 = uStack_18 | 1;
      }
      ppppuStack_cc = (uint ****)puVar19[1];
      ppppuStack_1c = ppppuStack_cc;
      *puVar19 = 0;
      puVar19[1] = 0;
      piVar12 = piStack_9c;
      uStack_18 = uVar15 | 4;
      ppppuStack_d0 = ppppuStack_14;
      if (((uVar15 & 2) != 0) && (uStack_18 = uVar15 & 0xfffffffd | 4, piStack_9c != (int *)0x0)) {
        LOCK();
        iVar9 = piStack_9c[1] + -1;
        piStack_9c[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_9c)();
          LOCK();
          piVar1 = piVar12 + 2;
          iVar9 = *piVar1 + -1;
          *piVar1 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar12 + 4))();
          }
        }
      }
      ppppuVar18 = ppppuStack_a4;
      if (((uStack_18 & 1) != 0) &&
         (uStack_18 = uStack_18 & 0xfffffffe, (uint *****)ppppuStack_a4 != (uint *****)0x0)) {
        LOCK();
        ppppuVar7 = (uint ****)((int)ppppuStack_a4[1] - 1);
        ppppuStack_a4[1] = (uint ***)ppppuVar7;
        UNLOCK();
        if (ppppuVar7 == (uint ****)0x0) {
          (*(code *)**ppppuStack_a4)();
          LOCK();
          pppppuVar17 = (uint *****)(ppppuVar18 + 2);
          ppppuVar7 = (uint ****)((int)*pppppuVar17 - 1);
          *pppppuVar17 = ppppuVar7;
          UNLOCK();
          if (ppppuVar7 == (uint ****)0x0) {
            (*(code *)(*ppppuVar18)[1])();
          }
        }
      }
      uStack_8 = 10;
      if ((uint *****)ppppuStack_14 == (uint *****)0x0) {
        if (((uint *****)ppppuStack_28 == (uint *****)0x0) ||
           (ppppuVar18 = (uint ****)ppppuStack_28[3], iVar9 = FUN_009ec190(),
           (uint)*(ushort *)(iVar9 + 0x1da) <
           (uint)*(ushort *)(ppppuVar18 + 0x76) - (uint)*(ushort *)(iVar9 + 0x1d8))) {
          piStack_54 = (int *)0x0;
          ppiVar11 = &piStack_58;
          ppppuStack_14 = (uint ****)0x30;
          ppppuStack_20 = (uint ****)0x0;
        }
        else {
          ppppuStack_20 = ppppuStack_28;
          if ((uint *****)ppppuStack_24 != (uint *****)0x0) {
            LOCK();
            ppppuStack_24[1] = (uint ***)((int)ppppuStack_24[1] + 1);
            UNLOCK();
          }
          ppppuStack_4c = ppppuStack_24;
          ppiVar11 = &piStack_50;
          ppppuStack_14 = (uint ****)0x28;
        }
        uStack_18 = uStack_18 | (uint)ppppuStack_14;
        piVar12 = ppiVar11[1];
        *ppiVar11 = (int *)0x0;
        ppiVar11[1] = (int *)0x0;
        ppppuStack_d8 = ppppuStack_20;
        piStack_d4 = piVar12;
        if (((uStack_18 & 0x10) != 0) &&
           (uStack_18 = uStack_18 & 0xffffffef, piStack_54 != (int *)0x0)) {
          LOCK();
          iVar9 = piStack_54[1] + -1;
          piStack_54[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_54)();
            LOCK();
            iVar9 = piStack_54[2] + -1;
            piStack_54[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piStack_54 + 4))();
            }
          }
        }
        if (((uStack_18 & 8) != 0) &&
           (uStack_18 = uStack_18 & 0xfffffff7, (uint *****)ppppuStack_4c != (uint *****)0x0)) {
          LOCK();
          ppppuVar18 = (uint ****)((int)ppppuStack_4c[1] - 1);
          ppppuStack_4c[1] = (uint ***)ppppuVar18;
          UNLOCK();
          if (ppppuVar18 == (uint ****)0x0) {
            (*(code *)**ppppuStack_4c)();
            LOCK();
            ppppuVar18 = (uint ****)((int)ppppuStack_4c[2] - 1);
            ppppuStack_4c[2] = (uint ***)ppppuVar18;
            UNLOCK();
            if (ppppuVar18 == (uint ****)0x0) {
              (*(code *)(*ppppuStack_4c)[1])();
            }
          }
        }
        uStack_8 = 0xc;
        uVar4 = uStack_8;
        uStack_8 = 0xc;
        if ((uint *****)ppppuStack_20 != (uint *****)0x0) {
          uVar10 = FUN_00886c00(auStack_b8,&pppuStack_8c);
          uStack_8 = 0xd;
          FUN_009ed830(uVar10);
          FUN_0056e380();
          FUN_0056e380();
          uVar4 = uStack_8;
        }
        uStack_8 = uVar4;
        if (piVar12 != (int *)0x0) {
          LOCK();
          iVar9 = piVar12[1] + -1;
          piVar12[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar12)();
            LOCK();
            iVar9 = piVar12[2] + -1;
            piVar12[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar12 + 4))();
            }
          }
        }
      }
      else {
        uVar10 = FUN_00886c00(auStack_b0,&pppuStack_8c);
        uStack_8 = 0xb;
        FUN_00b75530(uVar10);
        FUN_0056e380();
        FUN_0056e380();
      }
      ppppuVar18 = ppppuStack_1c;
      uStack_8 = 9;
      if ((uint *****)ppppuStack_1c != (uint *****)0x0) {
        LOCK();
        ppppuVar7 = (uint ****)((int)ppppuStack_1c[1] - 1);
        ppppuStack_1c[1] = (uint ***)ppppuVar7;
        UNLOCK();
        if (ppppuVar7 == (uint ****)0x0) {
          (*(code *)**ppppuStack_1c)();
          LOCK();
          pppppuVar17 = (uint *****)(ppppuVar18 + 2);
          ppppuVar7 = (uint ****)((int)*pppppuVar17 - 1);
          *pppppuVar17 = ppppuVar7;
          UNLOCK();
          if (ppppuVar7 == (uint ****)0x0) {
            (*(code *)(*ppppuVar18)[1])();
          }
        }
      }
      if (((iStack_74 != 0) && (iStack_74 != -0xc)) && (iVar9 = FUN_005cf750(), iVar9 != 0)) {
        FUN_0097c020(&iStack_c0,param_9,piStack_30);
        uStack_8 = 0xe;
        puVar19 = (undefined4 *)FUN_008a2380(aiStack_f0);
        uStack_8 = 0xf;
        if (0xf < (uint)puVar19[5]) {
          puVar19 = (undefined4 *)*puVar19;
        }
        piVar12 = *(int **)(iStack_c0 + 0x28);
        if (0xf < (uint)piVar12[5]) {
          piVar12 = (int *)*piVar12;
        }
        uVar10 = FUN_01675640(&pppuStack_48,"%s committed a new version of script %s",piVar12,
                              puVar19);
        uStack_8 = 0x10;
        FUN_0098c2c0(1,uVar10);
        uStack_8 = 0xf;
        if (&DAT_0000000f < ppppuStack_34) {
          pppppuVar17 = (uint *****)((int)ppppuStack_34 + 1);
          ppppuVar18 = (uint ****)pppuStack_48;
          if ((uint *****)0xfff < pppppuVar17) {
            ppppuVar18 = (uint ****)pppuStack_48[-1];
            pppppuVar17 = (uint *****)(ppppuStack_34 + 9);
            if (0x1f < (uint)((int)pppuStack_48 + (-4 - (int)ppppuVar18))) goto LAB_009f32f3;
          }
          FUN_01674ea0(ppppuVar18,pppppuVar17);
        }
        ppppuStack_38 = (uint ****)0x0;
        ppppuStack_34 = (uint ****)&DAT_0000000f;
        pppuStack_48 = (uint ***)((uint)pppuStack_48 & 0xffffff00);
        uStack_8 = 0xe;
        if ((uint ****)0xf < pppuStack_dc) {
          ppppuVar18 = (uint ****)((int)pppuStack_dc + 1);
          iVar9 = aiStack_f0[0];
          if ((uint ****)0xfff < ppppuVar18) {
            iVar9 = *(int *)(aiStack_f0[0] + -4);
            ppppuVar18 = (uint ****)(pppuStack_dc + 9);
            if (0x1f < (aiStack_f0[0] - iVar9) - 4U) goto LAB_009f32f3;
          }
          FUN_01674ea0(iVar9,ppppuVar18);
        }
        piVar12 = piStack_bc;
        uStack_8 = 9;
        if (piStack_bc != (int *)0x0) {
          LOCK();
          iVar9 = piStack_bc[1] + -1;
          piStack_bc[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_bc)();
            LOCK();
            piVar1 = piVar12 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar12 + 4))();
            }
          }
        }
      }
      uStack_c8 = param_9;
      ppppuStack_1c = (uint ****)&ppppuStack_70;
      if (&DAT_0000000f < ppppuStack_5c) {
        ppppuStack_1c = ppppuStack_70;
      }
      uStack_c4 = 0;
      ppppuStack_38 = (uint ****)0x0;
      ppppuStack_34 = (uint ****)0x0;
      ppppuStack_14 = ppppuStack_60;
      if (&DAT_0000000f < ppppuStack_60) {
        uVar15 = (uint)ppppuStack_60 | 0xf;
        if (0x7fffffff < uVar15) {
          uVar15 = 0x7fffffff;
        }
        uVar2 = uVar15 + 1;
        if (uVar2 < 0x1000) {
          if (uVar2 == 0) {
            pppuStack_48 = (uint ***)0x0;
          }
          else {
            pppuStack_48 = (uint ***)FUN_01674e20(uVar2);
          }
        }
        else {
          uVar13 = uVar15 + 0x24;
          if (uVar13 <= uVar2) {
            uVar13 = 0xffffffff;
          }
          pppuVar14 = (uint ***)FUN_01674e20(uVar13);
          if (pppuVar14 == (uint ***)0x0) goto LAB_009f32f3;
          pppuStack_48 = (uint ***)((int)pppuVar14 + 0x23U & 0xffffffe0);
          ((uint ****)pppuStack_48)[-1] = pppuVar14;
        }
        FUN_0170c6f0(pppuStack_48,ppppuStack_1c,(undefined *)((int)ppppuStack_14 + 1));
        ppppuStack_34 = (uint ****)uVar15;
      }
      else {
        pppuStack_48 = *ppppuStack_1c;
        pppuStack_44 = (uint ***)((uint *****)ppppuStack_1c)[1];
        pppuStack_40 = (uint ***)((uint *****)ppppuStack_1c)[2];
        pppuStack_3c = (uint ***)((uint *****)ppppuStack_1c)[3];
        ppppuStack_34 = (uint ****)0xf;
      }
      uStack_8 = 0x11;
      pcVar3 = *(code **)(*piStack_30 + 8);
      pppuStack_e8 = pppuStack_48;
      pppuStack_e4 = pppuStack_44;
      pppuStack_e0 = pppuStack_40;
      pppuStack_dc = pppuStack_3c;
      ppppuStack_38 = ppppuStack_14;
      uStack_290 = FUN_0088cb40();
      uStack_28c = 0;
      pppuStack_288 = pppuStack_e8;
      pppuStack_284 = pppuStack_e4;
      pppuStack_280 = pppuStack_e0;
      pppuStack_27c = pppuStack_dc;
      pppuStack_48 = (uint ***)((uint)pppuStack_48 & 0xffffff00);
      uStack_278 = CONCAT44(ppppuStack_34,ppppuStack_38);
      ppppuStack_38 = (uint ****)0x0;
      ppppuStack_34 = (uint ****)&DAT_0000000f;
      uStack_28c = FUN_005c9d30();
      uStack_8 = 0x12;
      uStack_1c0 = FUN_0088daf0();
      uStack_1bc = 0;
      uStack_1b8 = 1;
      uStack_1bc = FUN_005c9ef0();
      uStack_8 = 0x13;
      uStack_98 = 0;
      uStack_94 = 0;
      uStack_90 = 0;
      FUN_00687980(&uStack_290,aiStack_f0,param_9);
      uStack_8 = 0x14;
      (*pcVar3)(&DAT_021254b0,&uStack_98,&uStack_c8);
      uStack_8 = 0x15;
      FUN_00577b20();
      _uStack_8 = CONCAT31(uStack_7,0x11);
      FUN_016f32d1(&uStack_290,0xd0,2,FUN_0056e5b0);
      ppppuVar18 = ppppuStack_24;
      if ((uint *****)ppppuStack_24 != (uint *****)0x0) {
        LOCK();
        ppppuVar7 = (uint ****)((int)ppppuStack_24[1] - 1);
        ppppuStack_24[1] = (uint ***)ppppuVar7;
        UNLOCK();
        if (ppppuVar7 == (uint ****)0x0) {
          (*(code *)**ppppuStack_24)();
          LOCK();
          pppppuVar17 = (uint *****)(ppppuVar18 + 2);
          ppppuVar7 = (uint ****)((int)*pppppuVar17 - 1);
          *pppppuVar17 = ppppuVar7;
          UNLOCK();
          if (ppppuVar7 == (uint ****)0x0) {
            (*(code *)(*ppppuVar18)[1])();
          }
        }
      }
      FUN_005507b0();
      uStack_8 = 2;
      FUN_005507b0();
      ppppuStack_2c = (uint ****)((int)ppppuStack_2c + 1);
      pppppuVar17 = (uint *****)((param_2[1] - *param_2) / 0xd0);
    } while (ppppuStack_2c < pppppuVar17);
  }
LAB_009f3270:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar12 = param_3 + 1;
    iVar9 = *piVar12;
    pppppuVar17 = (uint *****)*piVar12;
    *piVar12 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar12 = param_3 + 2;
      iVar9 = *piVar12;
      pppppuVar17 = (uint *****)*piVar12;
      *piVar12 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        pppppuVar17 = (uint *****)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar12 = param_5 + 1;
    iVar9 = *piVar12;
    pppppuVar17 = (uint *****)*piVar12;
    *piVar12 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar12 = param_5 + 2;
      iVar9 = *piVar12;
      pppppuVar17 = (uint *****)*piVar12;
      *piVar12 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        pppppuVar17 = (uint *****)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar12 = param_7 + 1;
    iVar9 = *piVar12;
    pppppuVar17 = (uint *****)*piVar12;
    *piVar12 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      pppppuVar17 = (uint *****)(**(code **)*param_7)();
      LOCK();
      piVar12 = param_7 + 2;
      iVar9 = *piVar12;
      *piVar12 = *piVar12 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        pppppuVar17 = (uint *****)(**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pppppuVar17;
}



/* FUNCTION 19584 ; VA 0x009f3310 ; FUN_009f3310 */

void __fastcall FUN_009f3310(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_005cb500(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_009ef7e0(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 19585 ; VA 0x009f33b0 ; FUN_009f33b0 */

void FUN_009f33b0(void)

{
  FUN_009f13e0();
  return;
}



/* FUNCTION 19586 ; VA 0x009f33c0 ; FUN_009f33c0 */

void __thiscall FUN_009f33c0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  piVar2 = (int *)param_2[3];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_2,0x10);
  return;
}



/* FUNCTION 19587 ; VA 0x009f3420 ; FUN_009f3420 */

void FUN_009f3420(undefined4 param_1)

{
  FUN_009f0c20();
  FUN_01674ea0(param_1,0x80);
  return;
}



/* FUNCTION 19588 ; VA 0x009f3450 ; FUN_009f3450 */

int __thiscall
FUN_009f3450(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8b70;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_6);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_009fa890(param_1 + -0x58,param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19589 ; VA 0x009f3540 ; FUN_009f3540 */

int __thiscall
FUN_009f3540(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8b98;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_8);
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_009fa460(param_1 + -0x58,param_2,param_3,param_4,param_5,param_6,param_7);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19590 ; VA 0x009f3680 ; FUN_009f3680 */

void __fastcall FUN_009f3680(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = (int *)*param_1;
  piVar4 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar4 != (int *)*param_1) {
    do {
      piVar1 = (int *)piVar4[3];
      piVar2 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x10);
      piVar4 = piVar2;
    } while (piVar2 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 19591 ; VA 0x009f36f0 ; FUN_009f36f0 */

undefined4 * __thiscall
FUN_009f36f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8be1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009f4bd0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19592 ; VA 0x009f38a0 ; FUN_009f38a0 */

undefined4 * __thiscall
FUN_009f38a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8c21;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009f4cd0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19593 ; VA 0x009f3a50 ; FUN_009f3a50 */

undefined4 * __thiscall
FUN_009f3a50(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8c61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009f4ea0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19594 ; VA 0x009f3c00 ; FUN_009f3c00 */

undefined4 * __thiscall
FUN_009f3c00(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8ca1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009f5000;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19595 ; VA 0x009f3db0 ; FUN_009f3db0 */

undefined4 * __thiscall
FUN_009f3db0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8ce1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009f5100;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19596 ; VA 0x009f3f60 ; FUN_009f3f60 */

void __fastcall FUN_009f3f60(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00612580();
      piVar3 = *(int **)(iVar2 + 0xc);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  puVar4[2] = 0;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  puVar4[6] = 0;
  puVar4[7] = 0;
  puVar4[8] = 0;
  puVar4[9] = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 19597 ; VA 0x009f3fe0 ; FUN_009f3fe0 */

undefined4 * FUN_009f3fe0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00675340(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19598 ; VA 0x009f4050 ; FUN_009f4050 */

uint **** FUN_009f4050(uint ****param_1,uint ****param_2)

{
  int *piVar1;
  uint ****ppppuVar2;
  int *piVar3;
  uint ****ppppuVar4;
  uint ***pppuVar5;
  int iVar6;
  code *pcVar7;
  uint **ppuVar8;
  code *pcVar9;
  uint ****ppppuVar10;
  code *pcVar11;
  uint ***pppuVar12;
  uint ***pppuVar13;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  uint **ppuStack_258;
  uint **ppuStack_254;
  uint **ppuStack_250;
  uint **ppuStack_24c;
  uint ***pppuStack_248;
  code *pcStack_244;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  uint ***pppuStack_188;
  uint ***pppuStack_184;
  uint *puStack_c0;
  uint ***pppuStack_bc;
  uint **ppuStack_b8;
  uint **ppuStack_b4;
  uint **ppuStack_b0;
  uint **ppuStack_ac;
  undefined *puStack_a8;
  undefined4 uStack_a4;
  undefined *puStack_a0;
  undefined4 uStack_9c;
  int iStack_98;
  int *piStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  uint ***pppuStack_78;
  uint ***pppuStack_74;
  uint ***pppuStack_70;
  uint ***pppuStack_6c;
  uint ***pppuStack_68;
  uint ***pppuStack_64;
  undefined auStack_60 [4];
  undefined auStack_5c [4];
  uint ***pppuStack_58;
  uint *puStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  uint ***pppuStack_48;
  uint ***pppuStack_44;
  code *pcStack_40;
  uint **ppuStack_3c;
  uint **ppuStack_38;
  uint **ppuStack_34;
  uint **ppuStack_30;
  uint ***pppuStack_2c;
  code *pcStack_28;
  uint ***pppuStack_24;
  uint ***pppuStack_20;
  uint ***pppuStack_1c;
  int *piStack_18;
  uint ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d8da1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  ppppuVar4 = (uint ****)FUN_009f1870(&param_1);
  pppuVar12 = ppppuVar4[4];
  pppuStack_68 = (uint ***)(ppppuVar4 + 2);
  if (pppuVar12 == (uint ***)0x0) {
    pppuVar13 = (uint ***)0x0;
  }
  else {
    ppppuVar10 = ppppuVar4 + 3;
    ppppuVar4 = (uint ****)ppppuVar4[7];
    pppuVar13 = ppppuVar4[(int)*ppppuVar10];
  }
  if (pppuVar13 != (uint ***)0x0) {
    do {
      pppuVar12 = pppuVar13 + 2;
      pppuStack_14 = (uint ***)pppuVar13[6];
      pppuStack_48 = (uint ***)0x0;
      pppuStack_44 = (uint ***)0x0;
      if ((uint **)0xf < pppuVar13[7]) {
        pppuVar12 = (uint ***)*pppuVar12;
      }
      if (&DAT_0000000f < pppuStack_14) {
        pppuStack_1c = (uint ***)((uint)pppuStack_14 | 0xf);
        if ((uint ****)0x7fffffff < pppuStack_1c) {
          pppuStack_1c = (uint ***)0x7fffffff;
        }
        ppppuVar4 = (uint ****)((int)pppuStack_1c + 1);
        if (ppppuVar4 < &DAT_00001000) {
          if (ppppuVar4 == (uint ****)0x0) {
            pppuStack_58 = (uint ***)0x0;
          }
          else {
            pppuStack_58 = (uint ***)FUN_01674e20(ppppuVar4);
          }
        }
        else {
          ppppuVar10 = (uint ****)pppuStack_1c + 9;
          if (ppppuVar10 <= ppppuVar4) {
            ppppuVar10 = (uint ****)0xffffffff;
          }
          pppuVar5 = (uint ***)FUN_01674e20(ppppuVar10);
          if (pppuVar5 == (uint ***)0x0) goto LAB_009f4767;
          pppuStack_58 = (uint ***)((int)pppuVar5 + 0x23U & 0xffffffe0);
          ((uint ****)pppuStack_58)[-1] = pppuVar5;
        }
        FUN_0170c6f0(pppuStack_58,pppuVar12,(int)pppuStack_14 + 1);
        pppuStack_44 = pppuStack_1c;
      }
      else {
        pppuStack_58 = (uint ***)*pppuVar12;
        puStack_54 = (uint *)pppuVar12[1];
        puStack_50 = (uint *)pppuVar12[2];
        puStack_4c = (uint *)pppuVar12[3];
        pppuStack_44 = (uint ***)&DAT_0000000f;
      }
      uStack_8 = 1;
      pppuStack_48 = pppuStack_14;
      iVar6 = FUN_009f15c0(&pppuStack_58);
      pppuStack_24 = (uint ***)(iVar6 + 0x18);
      FUN_009f58b0(&param_1);
      FUN_008f7870(piStack_18);
      FUN_008fbc70(&iStack_98,&pppuStack_58);
      uStack_8 = 2;
      if (iStack_98 != 0) {
        FUN_00ae65e0(*(int *)(iVar6 + 0x20) != 0);
      }
      piVar3 = piStack_94;
      uStack_8 = 1;
      if (piStack_94 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_94[1] + -1;
        piStack_94[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_94)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (DAT_01d656d8 == '\0') {
        if ((uint ***)pppuStack_24[2] == (uint ***)0x0) {
          pppuVar12 = (uint ***)0x0;
          ppppuVar4 = (uint ****)pppuStack_24;
        }
        else {
          pppuVar12 = (uint ***)pppuStack_24[5][(int)pppuStack_24[1]];
          ppppuVar4 = (uint ****)pppuStack_24[5];
        }
        for (; pppuVar12 != (uint ***)0x0; pppuVar12 = (uint ***)*pppuVar12) {
          pppuStack_bc = (uint ***)pppuVar12[3];
          if ((uint ****)pppuStack_bc != (uint ****)0x0) {
            LOCK();
            ((uint ****)pppuStack_bc)[1] = (uint ***)((int)((uint ****)pppuStack_bc)[1] + 1);
            UNLOCK();
            pppuStack_bc = (uint ***)pppuVar12[3];
          }
          puStack_c0 = (uint *)pppuVar12[2];
          uStack_8 = 10;
          pppuStack_14 = pppuStack_bc;
          FUN_00927d30(auStack_60);
          puStack_a8 = auStack_60;
          uStack_a4 = 0;
          pppuStack_1c = (uint ***)param_2;
          if (param_2 != (uint ****)0x0) {
            LOCK();
            param_2[1] = (uint ***)((int)param_2[1] + 1);
            UNLOCK();
          }
          pppuStack_64 = (uint ***)param_1;
          pppuStack_78 = (uint ***)param_1;
          pppuStack_74 = (uint ***)param_2;
          pppuStack_24 = (uint ***)&pppuStack_58;
          if (&DAT_0000000f < pppuStack_44) {
            pppuStack_24 = pppuStack_58;
          }
          uStack_8 = 0xb;
          pppuStack_2c = (uint ***)0x0;
          pcStack_28 = (code *)0x0;
          pppuStack_20 = pppuStack_48;
          if (&DAT_0000000f < pppuStack_48) {
            pcStack_40 = (code *)((uint)pppuStack_48 | 0xf);
            if ((code *)0x7fffffff < pcStack_40) {
              pcStack_40 = (code *)0x7fffffff;
            }
            pcVar11 = pcStack_40 + 1;
            if (pcVar11 < &DAT_00001000) {
              if (pcVar11 == (code *)0x0) {
                ppuStack_3c = (uint **)0x0;
              }
              else {
                ppuStack_3c = (uint **)FUN_01674e20(pcVar11);
              }
            }
            else {
              pcVar9 = pcStack_40 + 0x24;
              if (pcVar9 <= pcVar11) {
                pcVar9 = (code *)0xffffffff;
              }
              ppuVar8 = (uint **)FUN_01674e20(pcVar9);
              if (ppuVar8 == (uint **)0x0) goto LAB_009f4767;
              ppuStack_3c = (uint **)((int)ppuVar8 + 0x23U & 0xffffffe0);
              ((uint ***)ppuStack_3c)[-1] = ppuVar8;
            }
            FUN_0170c6f0(ppuStack_3c,pppuStack_24,(int)pppuStack_20 + 1);
            pcStack_28 = pcStack_40;
          }
          else {
            ppuStack_3c = *pppuStack_24;
            ppuStack_38 = (uint **)((uint ****)pppuStack_24)[1];
            ppuStack_34 = (uint **)((uint ****)pppuStack_24)[2];
            ppuStack_30 = (uint **)((uint ****)pppuStack_24)[3];
            pcStack_28 = (code *)&DAT_0000000f;
          }
          uStack_8 = 0xd;
          pcStack_40 = *(code **)(*piStack_18 + 8);
          ppuStack_b8 = ppuStack_3c;
          ppuStack_b4 = ppuStack_38;
          ppuStack_b0 = ppuStack_34;
          ppuStack_ac = ppuStack_30;
          pppuStack_2c = pppuStack_20;
          uStack_260 = FUN_0088cb40();
          uStack_25c = 0;
          ppuStack_258 = ppuStack_b8;
          ppuStack_254 = ppuStack_b4;
          ppuStack_250 = ppuStack_b0;
          ppuStack_24c = ppuStack_ac;
          ppuStack_3c = (uint **)((uint)ppuStack_3c & 0xffffff00);
          pppuStack_248 = pppuStack_2c;
          pcStack_244 = pcStack_28;
          pppuStack_2c = (uint ***)0x0;
          pcStack_28 = (code *)0xf;
          uStack_25c = FUN_005c9d30();
          uStack_8 = 0xe;
          uStack_190 = FUN_0088cdc0();
          pppuStack_188 = pppuStack_64;
          uStack_18c = 0;
          pppuStack_184 = pppuStack_1c;
          pppuStack_78 = (uint ***)0x0;
          pppuStack_74 = (uint ***)0x0;
          uStack_18c = FUN_006309e0();
          uStack_8 = 0xf;
          uStack_90 = 0;
          uStack_8c = 0;
          uStack_88 = 0;
          FUN_00687980(&uStack_260,&puStack_c0,param_2);
          uStack_8 = 0x10;
          (*pcStack_40)(&DAT_02125570,&uStack_90,&puStack_a8);
          uStack_8 = 0x11;
          FUN_00577b20();
          uStack_8 = 0xd;
          FUN_016f32d1(&uStack_260,0xd0,2,FUN_0056e5b0);
          ppppuVar4 = (uint ****)pppuStack_14;
          if ((uint ****)pppuStack_14 != (uint ****)0x0) {
            LOCK();
            pppuVar5 = (uint ***)((int)pppuStack_14[1] - 1);
            pppuStack_14[1] = (uint **)pppuVar5;
            UNLOCK();
            if (pppuVar5 == (uint ***)0x0) {
              (*(code *)**pppuStack_14)();
              LOCK();
              ppppuVar10 = (uint ****)(pppuStack_14 + 2);
              pppuVar5 = *ppppuVar10;
              ppppuVar4 = (uint ****)*ppppuVar10;
              *ppppuVar10 = (uint ***)((int)pppuVar5 - 1U);
              UNLOCK();
              if ((uint ***)((int)pppuVar5 - 1U) == (uint ***)0x0) {
                ppppuVar4 = (uint ****)(*(code *)(*pppuStack_14)[1])();
              }
            }
          }
        }
      }
      else {
        FUN_00927d30(auStack_5c);
        puStack_a0 = auStack_5c;
        uStack_9c = 1;
        pppuStack_20 = (uint ***)param_2;
        if (param_2 != (uint ****)0x0) {
          LOCK();
          param_2[1] = (uint ***)((int)param_2[1] + 1);
          UNLOCK();
        }
        pppuStack_24 = (uint ***)param_1;
        pppuStack_70 = (uint ***)param_1;
        pppuStack_6c = (uint ***)param_2;
        pppuStack_1c = (uint ***)&pppuStack_58;
        if (&DAT_0000000f < pppuStack_44) {
          pppuStack_1c = pppuStack_58;
        }
        uStack_8 = 3;
        pppuStack_2c = (uint ***)0x0;
        pcStack_28 = (code *)0x0;
        pppuStack_14 = pppuStack_48;
        if (&DAT_0000000f < pppuStack_48) {
          pcVar11 = (code *)((uint)pppuStack_48 | 0xf);
          if ((code *)0x7fffffff < pcVar11) {
            pcVar11 = (code *)0x7fffffff;
          }
          pcVar9 = pcVar11 + 1;
          if (pcVar9 < &DAT_00001000) {
            if (pcVar9 == (code *)0x0) {
              ppuStack_3c = (uint **)0x0;
            }
            else {
              ppuStack_3c = (uint **)FUN_01674e20(pcVar9);
            }
          }
          else {
            pcVar7 = pcVar11 + 0x24;
            if (pcVar7 <= pcVar9) {
              pcVar7 = (code *)0xffffffff;
            }
            ppuVar8 = (uint **)FUN_01674e20(pcVar7);
            if (ppuVar8 == (uint **)0x0) goto LAB_009f4767;
            ppuStack_3c = (uint **)((int)ppuVar8 + 0x23U & 0xffffffe0);
            ((uint ***)ppuStack_3c)[-1] = ppuVar8;
          }
          FUN_0170c6f0(ppuStack_3c,pppuStack_1c,(int)pppuStack_14 + 1);
          pcStack_28 = pcVar11;
        }
        else {
          ppuStack_3c = *pppuStack_1c;
          ppuStack_38 = (uint **)((uint ****)pppuStack_1c)[1];
          ppuStack_34 = (uint **)((uint ****)pppuStack_1c)[2];
          ppuStack_30 = (uint **)((uint ****)pppuStack_1c)[3];
          pcStack_28 = (code *)&DAT_0000000f;
        }
        uStack_8 = 5;
        pcVar11 = *(code **)(*piStack_18 + 8);
        ppuStack_b8 = ppuStack_3c;
        ppuStack_b4 = ppuStack_38;
        ppuStack_b0 = ppuStack_34;
        ppuStack_ac = ppuStack_30;
        pppuStack_2c = pppuStack_14;
        uStack_260 = FUN_0088cb40();
        uStack_25c = 0;
        ppuStack_258 = ppuStack_b8;
        ppuStack_254 = ppuStack_b4;
        ppuStack_250 = ppuStack_b0;
        ppuStack_24c = ppuStack_ac;
        ppuStack_3c = (uint **)((uint)ppuStack_3c & 0xffffff00);
        pppuStack_248 = pppuStack_2c;
        pcStack_244 = pcStack_28;
        pppuStack_2c = (uint ***)0x0;
        pcStack_28 = (code *)0xf;
        uStack_25c = FUN_005c9d30();
        uStack_8 = 6;
        uStack_190 = FUN_0088cdc0();
        pppuStack_188 = pppuStack_24;
        uStack_18c = 0;
        pppuStack_184 = pppuStack_20;
        pppuStack_70 = (uint ***)0x0;
        pppuStack_6c = (uint ***)0x0;
        uStack_18c = FUN_006309e0();
        uStack_8 = 7;
        uStack_84 = 0;
        uStack_80 = 0;
        uStack_7c = 0;
        FUN_00687980(&uStack_260,&puStack_c0,param_2);
        uStack_8 = 8;
        (*pcVar11)(&DAT_02125570,&uStack_84,&puStack_a0);
        uStack_8 = 9;
        FUN_00577b20();
        uStack_8 = 5;
        ppppuVar4 = (uint ****)FUN_016f32d1(&uStack_260,0xd0,2,FUN_0056e5b0);
      }
      uStack_8 = 0;
      if (&DAT_0000000f < pppuStack_44) {
        ppppuVar10 = (uint ****)((int)pppuStack_44 + 1);
        ppppuVar4 = (uint ****)pppuStack_58;
        if ((uint ****)0xfff < ppppuVar10) {
          ppppuVar4 = (uint ****)pppuStack_58[-1];
          ppppuVar10 = (uint ****)(pppuStack_44 + 9);
          if (0x1f < (uint)((int)pppuStack_58 + (-4 - (int)ppppuVar4))) {
LAB_009f4767:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        ppppuVar4 = (uint ****)FUN_01674ea0(ppppuVar4,ppppuVar10);
      }
      pppuVar13 = (uint ***)*pppuVar13;
    } while (pppuVar13 != (uint ***)0x0);
    pppuVar12 = (uint ***)pppuStack_68[2];
  }
  pppuVar13 = pppuStack_68;
  if (pppuVar12 != (uint ***)0x0) {
    FUN_0061adc0(pppuStack_68[5] + (int)pppuStack_68[1],0);
    ppppuVar10 = (uint ****)pppuVar13[5];
    ppppuVar4 = ppppuVar10 + (int)pppuVar13[1];
    for (; ppppuVar10 != ppppuVar4; ppppuVar10 = ppppuVar10 + 1) {
      *ppppuVar10 = (uint ***)0x0;
    }
  }
  ppppuVar10 = param_2;
  if (param_2 != (uint ****)0x0) {
    LOCK();
    ppppuVar2 = param_2 + 1;
    pppuVar12 = *ppppuVar2;
    ppppuVar4 = (uint ****)*ppppuVar2;
    *ppppuVar2 = (uint ***)((int)pppuVar12 - 1U);
    UNLOCK();
    if ((uint ***)((int)pppuVar12 - 1U) == (uint ***)0x0) {
      ppppuVar4 = (uint ****)(*(code *)**param_2)();
      LOCK();
      ppppuVar2 = ppppuVar10 + 2;
      pppuVar12 = *ppppuVar2;
      *ppppuVar2 = (uint ***)((int)*ppppuVar2 - 1);
      UNLOCK();
      if (pppuVar12 == (uint ***)0x1) {
        ppppuVar4 = (uint ****)(*(code *)(*ppppuVar10)[1])();
      }
    }
  }
  ExceptionList = pvStack_10;
  return ppppuVar4;
}



/* FUNCTION 19599 ; VA 0x009f4770 ; FUN_009f4770 */

int FUN_009f4770(byte *param_1,uint *param_2,byte *param_3)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  byte *pbVar6;
  uint uVar7;
  byte *pbVar8;
  int *piVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint *puStack_22c;
  uint **ppuStack_228;
  undefined ***pppuStack_224;
  uint uStack_218;
  undefined4 uStack_214;
  uint *puStack_210;
  int iStack_20c;
  int iStack_208;
  int iStack_204;
  undefined8 uStack_200;
  undefined4 uStack_148;
  undefined4 uStack_144;
  uint *puStack_140;
  byte *pbStack_13c;
  uint *puStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  undefined **ppuStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint *puStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  uint uStack_38;
  uint *puStack_34;
  byte *pbStack_30;
  undefined *puStack_2c;
  uint *puStack_28;
  int *piStack_24;
  byte *pbStack_20;
  int *piStack_1c;
  int *piStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d8e0c;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pppuStack_224 = (undefined ***)&param_2;
  ppuStack_228 = (uint **)0x9f47ab;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009f1870();
  pbVar6 = param_1;
  pbStack_14 = (byte *)(iVar4 + 8);
  if (*(int *)(iVar4 + 0x10) != 0) {
    ppuStack_228 = (uint **)(pbStack_14 + *pbStack_14 + 1);
    pppuStack_224 = (undefined ***)param_1;
    puStack_22c = (uint *)0x9f47cb;
    pbStack_30 = (byte *)FUN_0055c740();
    puStack_28 = (uint *)(iVar4 + 0xc);
    piStack_24 = (int *)*puStack_28;
    pbStack_20 = (byte *)((uint)pbStack_30 % (uint)piStack_24);
    puStack_2c = (undefined *)((int)pbStack_20 * 4);
    piStack_1c = *(int **)(puStack_2c + *(int *)(iVar4 + 0x1c));
    if ((piStack_1c != (int *)0x0) &&
       (piVar2 = (int *)*piStack_1c, (int *)*piStack_1c != (int *)0x0)) {
      while (piVar9 = piVar2, (byte *)((uint)piVar9[1] % (uint)piStack_24) == pbStack_20) {
        if ((byte *)piVar9[1] == pbStack_30) {
          pppuStack_224 = (undefined ***)(piVar9 + 2);
          ppuStack_228 = (uint **)pbVar6;
          puStack_22c = (uint *)0x9f4820;
          cVar3 = FUN_00558b30();
          piVar2 = piStack_1c;
          if (cVar3 != '\0') {
            pppuStack_224 = (undefined ***)*piVar9;
            ppuStack_228 = (uint **)piStack_1c;
            puStack_22c = (uint *)0x9f4842;
            FUN_0061adc0();
            if (*piVar2 != 0) {
              pbVar8 = (byte *)(*(uint *)(*piVar2 + 4) % *puStack_28);
              if (pbStack_20 == pbVar8) break;
              *(int **)(*(int *)(pbStack_14 + 0x14) + (int)pbVar8 * 4) = piVar2;
            }
            if (*(int **)(puStack_2c + *(int *)(pbStack_14 + 0x14)) == piVar2) {
              *(undefined4 *)(puStack_2c + *(int *)(pbStack_14 + 0x14)) = 0;
            }
            break;
          }
        }
        piVar2 = (int *)*piVar9;
        piStack_1c = piVar9;
        if ((int *)*piVar9 == (int *)0x0) break;
      }
    }
  }
  pppuStack_224 = (undefined ***)pbVar6;
  ppuStack_228 = (uint **)0x9f4882;
  iVar5 = FUN_009f15c0();
  pppuStack_224 = (undefined ***)&param_2;
  ppuStack_228 = (uint **)0x9f4890;
  FUN_009f58b0();
  ppuStack_228 = (uint **)pbVar6;
  puStack_22c = (uint *)0x9f489a;
  pppuStack_224 = (undefined ***)(iVar5 + 0x18);
  iVar4 = FUN_009faf20();
  if (DAT_01d656d8 == '\0') {
    if (*(int *)(iVar5 + 0x20) == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      iVar4 = *(int *)(iVar5 + 0x2c);
      puVar10 = *(undefined4 **)(iVar4 + *(int *)(iVar5 + 0x1c) * 4);
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      piStack_64 = (int *)puVar10[3];
      if (piStack_64 != (int *)0x0) {
        LOCK();
        piStack_64[1] = piStack_64[1] + 1;
        UNLOCK();
        piStack_64 = (int *)puVar10[3];
      }
      uStack_68 = puVar10[2];
      pppuStack_224 = (undefined ***)&puStack_2c;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 2;
      ppuStack_228 = (uint **)0x9f498a;
      piStack_24 = piStack_64;
      FUN_00927d30();
      ppuStack_60 = &puStack_2c;
      uStack_5c = 0;
      if (param_3 != (byte *)0x0) {
        LOCK();
        *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
        UNLOCK();
      }
      pbStack_14 = param_3;
      puStack_28 = param_2;
      puStack_34 = param_2;
      pbStack_30 = param_3;
      piStack_1c = *(int **)(pbVar6 + 0x10);
      iStack_8._0_1_ = 3;
      piStack_3c = (int *)0x0;
      uStack_38 = 0;
      if (0xf < *(uint *)(pbVar6 + 0x14)) {
        pbVar6 = *(byte **)pbVar6;
      }
      pbStack_20 = pbVar6;
      if (&DAT_0000000f < piStack_1c) {
        uVar11 = (uint)piStack_1c | 0xf;
        if (0x7fffffff < uVar11) {
          uVar11 = 0x7fffffff;
        }
        pppuStack_224 = (undefined ***)(uVar11 + 1);
        if (pppuStack_224 < 0x1000) {
          if (pppuStack_224 == (undefined ***)0x0) {
            puStack_22c = (uint *)0x0;
          }
          else {
            ppuStack_228 = (uint **)0x9f4a48;
            puStack_22c = (uint *)FUN_01674e20();
          }
        }
        else {
          uVar7 = uVar11 + 0x24;
          if (uVar7 <= pppuStack_224) {
            uVar7 = 0xffffffff;
          }
          ppuStack_228 = (uint **)0x9f4a28;
          pppuStack_224 = (undefined ***)uVar7;
          uVar7 = FUN_01674e20();
          if (uVar7 == 0) {
                    /* WARNING: Subroutine does not return */
            pppuStack_224 = (undefined ***)&UNK_009f4bc0;
            FUN_017167a3();
          }
          puStack_22c = (uint *)(uVar7 + 0x23 & 0xffffffe0);
          puStack_22c[-1] = uVar7;
        }
        pppuStack_224 = (undefined ***)((int)piStack_1c + 1);
        ppuStack_228 = (uint **)pbStack_20;
        puStack_4c = puStack_22c;
        FUN_0170c6f0();
        uStack_38 = uVar11;
      }
      else {
        puStack_4c = *(uint **)pbVar6;
        iStack_48 = *(int *)(pbVar6 + 4);
        iStack_44 = *(int *)(pbVar6 + 8);
        iStack_40 = *(int *)(pbVar6 + 0xc);
        uStack_38 = 0xf;
      }
      iStack_8._0_1_ = 5;
      pcVar1 = *(code **)(*piStack_18 + 8);
      pppuStack_224 = (undefined ***)0x9f4a87;
      puStack_78 = puStack_4c;
      iStack_74 = iStack_48;
      iStack_70 = iStack_44;
      iStack_6c = iStack_40;
      piStack_3c = piStack_1c;
      uStack_218 = FUN_0088cb40();
      uStack_214 = 0;
      puStack_210 = puStack_78;
      iStack_20c = iStack_74;
      iStack_208 = iStack_70;
      iStack_204 = iStack_6c;
      puStack_4c = (uint *)((uint)puStack_4c & 0xffffff00);
      uStack_200 = CONCAT44(uStack_38,piStack_3c);
      piStack_3c = (int *)0x0;
      uStack_38 = 0xf;
      pppuStack_224 = (undefined ***)0x9f4ac6;
      uStack_214 = FUN_005c9d30();
      iStack_8._0_1_ = 6;
      pppuStack_224 = (undefined ***)0x9f4ad5;
      uStack_148 = FUN_0088cdc0();
      puStack_140 = puStack_28;
      uStack_144 = 0;
      pbStack_13c = pbStack_14;
      puStack_34 = (uint *)0x0;
      pbStack_30 = (byte *)0x0;
      pppuStack_224 = (undefined ***)0x9f4b0a;
      uStack_144 = FUN_006309e0();
      pppuStack_224 = (undefined ***)param_1;
      ppuStack_228 = &puStack_78;
      iStack_8._0_1_ = 7;
      puStack_22c = &uStack_218;
      uStack_58 = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      FUN_00687980();
      pppuStack_224 = &ppuStack_60;
      ppuStack_228 = (uint **)&uStack_58;
      iStack_8._0_1_ = 8;
      puStack_22c = (uint *)&DAT_02125570;
      (*pcVar1)();
      iStack_8._0_1_ = 9;
      pppuStack_224 = (undefined ***)0x9f4b61;
      FUN_00577b20();
      pppuStack_224 = (undefined ***)FUN_0056e5b0;
      ppuStack_228 = (uint **)0x2;
      puStack_22c = (uint *)0xd0;
      iStack_8._0_1_ = 5;
      iVar4 = FUN_016f32d1(&uStack_218);
      piVar2 = piStack_24;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piVar9 = piStack_24 + 1;
        iVar5 = *piVar9;
        iVar4 = *piVar9;
        *piVar9 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          pppuStack_224 = (undefined ***)0x9f4b98;
          (**(code **)*piStack_24)();
          LOCK();
          piVar9 = piVar2 + 2;
          iVar5 = *piVar9;
          iVar4 = *piVar9;
          *piVar9 = iVar5 + -1;
          UNLOCK();
          if (iVar5 + -1 == 0) {
            pppuStack_224 = (undefined ***)0x9f4ba9;
            iVar4 = (**(code **)(*piVar2 + 4))();
          }
        }
      }
      pbVar6 = param_1;
    }
  }
  else {
    pppuStack_224 = (undefined ***)&param_1;
    ppuStack_228 = (uint **)0x9f48b3;
    FUN_00927d30();
    puStack_34 = (uint *)&param_1;
    pbStack_30 = (byte *)0x1;
    pppuStack_224 = (undefined ***)&puStack_34;
    puStack_2c = (undefined *)&puStack_22c;
    if (param_3 != (byte *)0x0) {
      LOCK();
      *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
      UNLOCK();
    }
    puStack_22c = param_2;
    ppuStack_228 = (uint **)param_3;
    iStack_8._0_1_ = 1;
    FUN_0054ef60(pbVar6);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    iVar4 = FUN_009fa150(piStack_18);
  }
  pbVar6 = param_3;
  if (param_3 != (byte *)0x0) {
    LOCK();
    pbVar8 = param_3 + 4;
    iVar5 = *(int *)pbVar8;
    iVar4 = *(int *)pbVar8;
    *(int *)pbVar8 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      pppuStack_224 = (undefined ***)0x9f4928;
      iVar4 = (*(code *)**(undefined4 **)param_3)();
      LOCK();
      pbVar8 = pbVar6 + 8;
      iVar5 = *(int *)pbVar8;
      *(int *)pbVar8 = *(int *)pbVar8 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pppuStack_224 = (undefined ***)0x9f4937;
        iVar4 = (**(code **)(*(int *)pbVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19600 ; VA 0x009f4bd0 ; FUN_009f4bd0 */

void FUN_009f4bd0(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_005c9cc0();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19601 ; VA 0x009f4cd0 ; FUN_009f4cd0 */

int FUN_009f4cd0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a58a4;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_2);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_00000020;
  piStack_e4 = in_stack_00000024;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_01675290(uVar5);
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    uVar7 = param_2;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_2 - 4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 19602 ; VA 0x009f4ea0 ; FUN_009f4ea0 */

void FUN_009f4ea0(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c83dc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_2);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000020;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19603 ; VA 0x009f5000 ; FUN_009f5000 */

int FUN_009f5000(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
                undefined4 param_6,int *param_7,int param_8)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8e40;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009ef440(&param_2,&param_4,&param_6,&param_8);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_7)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    uVar5 = in_stack_00000034 + 1;
    iVar4 = param_8;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_8 + -4);
      uVar5 = in_stack_00000034 + 0x24;
      if (0x1f < (param_8 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19604 ; VA 0x009f5100 ; FUN_009f5100 */

int FUN_009f5100(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
                int param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_0000002c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8ea7;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cbe0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_00630900();
  uStack_8._0_1_ = 4;
  uStack_1c0 = FUN_0088cbe0();
  uStack_1bc = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_4;
  piStack_1b4 = param_5;
  uStack_1bc = FUN_00630900();
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_6);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 7;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 3;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    uVar6 = in_stack_0000002c + 1;
    iVar5 = param_6;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_6 + -4);
      uVar6 = in_stack_0000002c + 0x24;
      if (0x1f < (param_6 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19605 ; VA 0x009f5330 ; FUN_009f5330 */

void FUN_009f5330(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  void **ppvVar6;
  int *piVar7;
  undefined auStack_2c [8];
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x18);
  if (*(int *)(iVar1 + 0x100) != 0) {
    puVar2 = *(undefined4 **)(iVar1 + 0xfc);
    ppvVar6 = &pvStack_10;
    for (puVar3 = (undefined4 *)*puVar2; ExceptionList = ppvVar6, puVar3 != puVar2;
        puVar3 = (undefined4 *)*puVar3) {
      FUN_00a11ca0(param_2,param_3);
      ppvVar6 = (void **)ExceptionList;
    }
    iStack_24 = iVar1 + 0xf8;
    iStack_1c = iVar1 + 0x118;
    piStack_20 = (int *)(iVar1 + 0xfc);
    piVar4 = (int *)*piStack_20;
    piVar7 = (int *)*piVar4;
    if (piVar7 != piVar4) {
      do {
        iVar5 = **(int **)(iVar1 + 0x11c);
        puStack_14 = *(undefined4 **)(iVar5 + 4);
        uStack_18 = FUN_009ef760(iVar5,puStack_14,piVar7 + 2);
        if (*(int *)(iVar1 + 0x120) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddcd9("list<T> too long");
        }
        *(int *)(iVar1 + 0x120) = *(int *)(iVar1 + 0x120) + 1;
        *(undefined4 *)(iVar5 + 4) = uStack_18;
        *puStack_14 = uStack_18;
        iVar5 = **(int **)(iVar1 + 0x11c);
        FUN_009ef7e0(auStack_2c,iVar5 + 8,iVar5);
        piVar7 = (int *)*piVar7;
      } while (piVar7 != piVar4);
    }
    uStack_8 = 0;
    FUN_009f3680();
    FUN_005cb500(8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19606 ; VA 0x009f5440 ; FUN_009f5440 */

int FUN_009f5440(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_009f6890(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19607 ; VA 0x009f54d0 ; FUN_009f54d0 */

int FUN_009f54d0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8ed0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar3 = *(code **)(param_1 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19608 ; VA 0x009f55a0 ; FUN_009f55a0 */

void __thiscall FUN_009f55a0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  
  uVar2 = param_3[2];
  iVar1 = (*(uint *)(param_1 + 0x18) &
          (((uVar2 >> 8 & 0xff ^ (uVar2 & 0xff ^ 0x811c9dc5) * 0x1000193) * 0x1000193 ^
           uVar2 >> 0x10 & 0xff) * 0x1000193 ^ uVar2 >> 0x18) * 0x1000193) * 8;
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar4[1] == param_3) {
    if ((int *)*piVar4 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if ((int *)*piVar4 == param_3) {
    *piVar4 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  piVar4 = (int *)param_3[3];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_01674ea0(param_3,0x10);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 19609 ; VA 0x009f5680 ; FUN_009f5680 */

int __thiscall FUN_009f5680(int param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  undefined4 *puVar9;
  int iVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar1 = *param_2;
  piVar2 = *(int **)(param_1 + 4);
  uVar7 = *(uint *)(param_1 + 0x18) &
          ((((uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar1 >> 8 & 0xff) * 0x1000193 ^
           uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193;
  iVar3 = *(int *)(param_1 + 0xc);
  piVar4 = *(int **)(iVar3 + uVar7 * 8);
  iVar10 = uVar7 * 8 + 4;
  piVar8 = piVar4;
  while( true ) {
    piVar5 = piVar2;
    if (piVar4 != piVar2) {
      piVar5 = (int *)**(undefined4 **)(iVar3 + iVar10);
    }
    if (piVar8 == piVar5) goto LAB_009f576a;
    piVar5 = piVar8;
    if (piVar8[2] == uVar1) break;
    piVar8 = (int *)*piVar8;
  }
  while( true ) {
    piVar6 = piVar2;
    if (piVar4 != piVar2) {
      piVar6 = (int *)**(undefined4 **)(iVar3 + iVar10);
    }
    if ((piVar5 == piVar6) || (uVar1 != piVar5[2])) break;
    piVar5 = (int *)*piVar5;
  }
  if (piVar8 == piVar5) {
LAB_009f576a:
    piVar8 = piVar2;
    piVar5 = piVar2;
  }
  iVar10 = 0;
  for (piVar4 = piVar8; piVar4 != piVar5; piVar4 = (int *)*piVar4) {
    iVar10 = iVar10 + 1;
  }
  if ((piVar8 == (int *)*piVar2) && (piVar5 == piVar2)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_009f3680();
    FUN_005cb500(8);
  }
  else {
    ExceptionList = &pvStack_10;
    if (piVar8 != piVar5) {
      do {
        piVar2 = (int *)*piVar8;
        uVar1 = piVar8[2];
        iVar3 = (((((uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar1 >> 8 & 0xff) * 0x1000193 ^
                  uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193 &
                *(uint *)(param_1 + 0x18)) * 8;
        puVar9 = (undefined4 *)(iVar3 + *(int *)(param_1 + 0xc));
        if ((int *)puVar9[1] == piVar8) {
          if ((int *)*puVar9 == piVar8) {
            *puVar9 = *(undefined4 *)(param_1 + 4);
            *(undefined4 *)(iVar3 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
          }
          else {
            puVar9[1] = piVar8[1];
          }
        }
        else if ((int *)*puVar9 == piVar8) {
          *puVar9 = piVar2;
        }
        *(int *)piVar8[1] = *piVar8;
        *(int *)(*piVar8 + 4) = piVar8[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        piVar4 = (int *)piVar8[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar3 = piVar4[1] + -1;
          piVar4[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar3 = piVar4[2] + -1;
            piVar4[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        FUN_01674ea0(piVar8,0x10);
        piVar8 = piVar2;
      } while (piVar2 != piVar5);
      ExceptionList = pvStack_10;
      return iVar10;
    }
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 19610 ; VA 0x009f58b0 ; FUN_009f58b0 */

undefined4 __thiscall FUN_009f58b0(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_008b20f0(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 19611 ; VA 0x009f5990 ; FUN_009f5990 */

/* WARNING: Removing unreachable block (ram,0x009f5af1) */
/* WARNING: Removing unreachable block (ram,0x009f5aa5) */
/* WARNING: Removing unreachable block (ram,0x009f5aae) */
/* WARNING: Removing unreachable block (ram,0x009f5abd) */
/* WARNING: Removing unreachable block (ram,0x009f5a7f) */
/* WARNING: Removing unreachable block (ram,0x009f5a88) */
/* WARNING: Removing unreachable block (ram,0x009f5a97) */
/* WARNING: Removing unreachable block (ram,0x009f5acb) */
/* WARNING: Removing unreachable block (ram,0x009f5ad4) */
/* WARNING: Removing unreachable block (ram,0x009f5ae2) */
/* WARNING: Removing unreachable block (ram,0x009f5aff) */
/* WARNING: Removing unreachable block (ram,0x009f5b2b) */
/* WARNING: Removing unreachable block (ram,0x009f5b0f) */

undefined4
FUN_009f5990(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8e40;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009f1c90(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
                       param_11,CONCAT44(param_13,param_12));
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19612 ; VA 0x009f5b40 ; FUN_009f5b40 */

/* WARNING: Removing unreachable block (ram,0x009f5c50) */
/* WARNING: Removing unreachable block (ram,0x009f5c04) */
/* WARNING: Removing unreachable block (ram,0x009f5c0d) */
/* WARNING: Removing unreachable block (ram,0x009f5c1c) */
/* WARNING: Removing unreachable block (ram,0x009f5c2a) */
/* WARNING: Removing unreachable block (ram,0x009f5c33) */
/* WARNING: Removing unreachable block (ram,0x009f5c41) */
/* WARNING: Removing unreachable block (ram,0x009f5c5e) */
/* WARNING: Removing unreachable block (ram,0x009f5c8a) */
/* WARNING: Removing unreachable block (ram,0x009f5c6e) */

undefined4
FUN_009f5b40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8ef8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009f1ed0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                       CONCAT44(param_11,param_10));
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19613 ; VA 0x009f5c90 ; FUN_009f5c90 */

void FUN_009f5c90(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088c8c0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19614 ; VA 0x009f5ce0 ; FUN_009f5ce0 */

/* WARNING: Removing unreachable block (ram,0x009f5dac) */
/* WARNING: Removing unreachable block (ram,0x009f5dba) */
/* WARNING: Removing unreachable block (ram,0x009f5dfa) */
/* WARNING: Removing unreachable block (ram,0x009f5dca) */

void FUN_009f5ce0(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined *)(iVar2 + 0xd8);
  if (*(int *)(iVar2 + 0xd4) == 0) {
    puVar4 = (undefined *)0x0;
  }
  uVar1 = *puVar4;
  param_2 = (int *)*param_2;
  iVar2 = *param_2;
  iVar5 = FUN_0088cb40();
  if (iVar2 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar6 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar6 = (int *)0x0;
  }
  FUN_0054ef60(piVar6);
  uStack_8 = 0;
  FUN_009f1b60(uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20),
               CONCAT31((int3)((uint)puVar4 >> 8),uVar1));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19615 ; VA 0x009f5e00 ; FUN_009f5e00 */

void FUN_009f5e00(undefined4 param_1,undefined4 param_2)

{
  FUN_009f0170(param_1,param_2,param_2);
  return;
}



/* FUNCTION 19616 ; VA 0x009f5e20 ; FUN_009f5e20 */

void FUN_009f5e20(undefined4 param_1,undefined4 param_2)

{
  FUN_009f02f0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 19617 ; VA 0x009f5e50 ; FUN_009f5e50 */

undefined4 __thiscall FUN_009f5e50(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x70);
  return param_2;
}



/* FUNCTION 19618 ; VA 0x009f5ea0 ; FUN_009f5ea0 */

void FUN_009f5ea0(undefined4 param_1,undefined4 param_2)

{
  FUN_009f1af0(param_2);
  return;
}



/* FUNCTION 19619 ; VA 0x009f5eb0 ; FUN_009f5eb0 */

void FUN_009f5eb0(undefined4 param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_005cf8d0(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar1 != 0) {
    FUN_009f5680(param_1);
  }
  return;
}



/* FUNCTION 19620 ; VA 0x009f5ee0 ; FUN_009f5ee0 */

uint FUN_009f5ee0(void)

{
  int iVar1;
  
  iVar1 = FUN_009ef640();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19621 ; VA 0x009f5f00 ; FUN_009f5f00 */

uint FUN_009f5f00(void)

{
  int iVar1;
  
  iVar1 = FUN_009ef640();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19622 ; VA 0x009f5f20 ; FUN_009f5f20 */

void FUN_009f5f20(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dc556c);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_7e9327b028e2ba7cbe461c03f6dbb2a0>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19623 ; VA 0x009f5f80 ; FUN_009f5f80 */

int * FUN_009f5f80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009f6057. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009f5fd6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc55a4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_ca9c3e406aa27643dd6b3b143b1fde12>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19624 ; VA 0x009f6070 ; FUN_009f6070 */

int __thiscall FUN_009f6070(int param_1,uint param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined *puVar6;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8f20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a0a460(&uStack_1c);
  iVar4 = *(int *)(param_1 + 0xf0);
  piVar5 = *(int **)(iVar4 + 0x28);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(iVar4 + 0x28);
  }
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uVar3 = FUN_00927d30(auStack_14);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  FUN_009f9770(uStack_1c,piStack_18,uVar3,param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[1] + -1;
    piVar5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar4 = piVar5[2] + -1;
      piVar5[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_008f7870(param_1);
  param_2 = param_2 & 0xffffff00;
  cVar2 = FUN_00585a40(&param_2);
  if (cVar2 == '\0') {
    puVar6 = &DAT_0193d811;
  }
  else {
    puVar6 = (undefined *)0x0;
  }
  iVar4 = FUN_0090ca30(puVar6);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_18 + 1;
    iVar1 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piStack_18)();
      LOCK();
      piVar5 = piStack_18 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19625 ; VA 0x009f61b0 ; FUN_009f61b0 */

void __fastcall FUN_009f61b0(int param_1)

{
  undefined auStack_c [4];
  undefined4 uStack_8;
  
  if (DAT_01d65a50 != '\0') {
    FUN_009ef960(auStack_c,param_1 + 0xf0,uStack_8);
    return;
  }
  FUN_009f2470();
  return;
}



/* FUNCTION 19626 ; VA 0x009f61f0 ; FUN_009f61f0 */

int FUN_009f61f0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_44 [20];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8f38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_30 = 0x9f621b;
  ExceptionList = &pvStack_10;
  FUN_008f7870();
  uStack_2c = 1;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piVar1 = param_2 + 1;
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0055c750(param_1,param_2,auStack_44);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar3 = param_2[2] + -1;
      param_2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar3 = param_2[2] + -1;
      param_2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar3 = param_2[2] + -1;
      param_2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  iVar3 = FUN_0090ca30();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_2c = 0x9f631a;
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = 0x9f6329;
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19627 ; VA 0x009f6340 ; FUN_009f6340 */

uint __fastcall FUN_009f6340(int *param_1)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  uint ****ppppuVar9;
  int iVar10;
  uint ******ppppppuVar11;
  uint uVar12;
  uint *****pppppuVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined4 uStack_248;
  undefined4 uStack_244;
  uint ****ppppuStack_240;
  uint ****ppppuStack_23c;
  uint ****ppppuStack_238;
  uint ****ppppuStack_234;
  undefined8 uStack_230;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined uStack_170;
  int aiStack_a8 [2];
  uint ****ppppuStack_a0;
  uint ****ppppuStack_9c;
  uint ****ppppuStack_98;
  uint ****ppppuStack_94;
  int iStack_90;
  int *piStack_8c;
  int iStack_88;
  int *piStack_84;
  undefined *puStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  int *piStack_68;
  undefined auStack_64 [4];
  int iStack_60;
  int iStack_5c;
  uint *****pppppuStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint *****pppppuStack_48;
  uint uStack_44;
  int *piStack_40;
  int *piStack_3c;
  int iStack_38;
  uint ****ppppuStack_34;
  uint ****ppppuStack_30;
  uint ****ppppuStack_2c;
  uint ****ppppuStack_28;
  uint *****pppppuStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint *****pppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8fbd;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_40 = param_1;
  iVar5 = FUN_008f7870(param_1);
  iStack_5c = iVar5;
  FUN_00a0a460(&piStack_6c);
  iVar10 = param_1[0x3c];
  piStack_8c = *(int **)(iVar10 + 0x28);
  if (piStack_8c != (int *)0x0) {
    LOCK();
    piStack_8c[1] = piStack_8c[1] + 1;
    UNLOCK();
    piStack_8c = *(int **)(iVar10 + 0x28);
  }
  iStack_90 = *(int *)(iVar10 + 0x24);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_60 = iStack_90;
  piStack_3c = piStack_8c;
  FUN_00927d30(auStack_64);
  if ((iVar5 == 0) || (iVar5 == -0xc)) {
    iStack_38 = 0;
  }
  else {
    iStack_38 = FUN_005cf750();
  }
  uStack_18 = 0;
  uVar12 = (piStack_6c[1] - *piStack_6c) / 0xd0;
  if (uVar12 != 0) {
    iStack_1c = 0;
    do {
      iVar10 = *(int *)(*piStack_6c + iStack_1c);
      iVar15 = *piStack_6c + iStack_1c;
      iVar5 = FUN_0088cb40();
      if (iVar10 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      pppppuStack_48 = (uint *****)0x0;
      uStack_44 = 0;
      puVar14 = (undefined4 *)(-(uint)(*(int *)(iVar15 + 4) != 0) & iVar15 + 8U);
      pppppuStack_14 = (uint *****)puVar14[4];
      if (0xf < (uint)puVar14[5]) {
        puVar14 = (undefined4 *)*puVar14;
      }
      if (&DAT_0000000f < pppppuStack_14) {
        uVar12 = (uint)pppppuStack_14 | 0xf;
        if (0x7fffffff < uVar12) {
          uVar12 = 0x7fffffff;
        }
        uVar3 = uVar12 + 1;
        if (uVar3 < 0x1000) {
          if (uVar3 == 0) {
            pppppuStack_58 = (uint *****)0x0;
          }
          else {
            pppppuStack_58 = (uint *****)FUN_01674e20(uVar3);
          }
        }
        else {
          uVar8 = uVar12 + 0x24;
          if (uVar8 <= uVar3) {
            uVar8 = 0xffffffff;
          }
          pppppuVar13 = (uint *****)FUN_01674e20(uVar8);
          if (pppppuVar13 == (uint *****)0x0) goto LAB_009f6873;
          pppppuStack_58 = (uint *****)((int)pppppuVar13 + 0x23U & 0xffffffe0);
          ((uint ******)pppppuStack_58)[-1] = pppppuVar13;
        }
        FUN_0170c6f0(pppppuStack_58,puVar14,(undefined *)((int)pppppuStack_14 + 1));
        uStack_44 = uVar12;
      }
      else {
        pppppuStack_58 = (uint *****)*puVar14;
        uStack_54 = puVar14[1];
        uStack_50 = puVar14[2];
        uStack_4c = puVar14[3];
        uStack_44 = 0xf;
      }
      uStack_8._0_1_ = 2;
      pppppuStack_48 = pppppuStack_14;
      FUN_008fbc70(&iStack_88,&pppppuStack_58);
      uStack_8._0_1_ = 3;
      if ((iStack_38 != 0) && (iStack_88 != 0)) {
        puVar14 = (undefined4 *)FUN_008a2380(aiStack_a8);
        uStack_8._0_1_ = 4;
        if (0xf < (uint)puVar14[5]) {
          puVar14 = (undefined4 *)*puVar14;
        }
        piVar6 = *(int **)(iStack_60 + 0x28);
        if (0xf < (uint)piVar6[5]) {
          piVar6 = (int *)*piVar6;
        }
        uVar7 = FUN_01675640(&ppppuStack_34,"%s committed a new version of script %s",piVar6,puVar14
                            );
        uStack_8._0_1_ = 5;
        FUN_0098c2c0(1,uVar7);
        uStack_8._0_1_ = 4;
        if (0xf < uStack_20) {
          uVar12 = uStack_20 + 1;
          ppppuVar9 = ppppuStack_34;
          if (0xfff < uVar12) {
            ppppuVar9 = (uint ****)ppppuStack_34[-1];
            uVar12 = uStack_20 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_34 + (-4 - (int)ppppuVar9))) goto LAB_009f6873;
          }
          FUN_01674ea0(ppppuVar9,uVar12);
        }
        pppppuStack_24 = (uint *****)0x0;
        uStack_20 = 0xf;
        ppppuStack_34 = (uint ****)((uint)ppppuStack_34 & 0xffffff00);
        uStack_8._0_1_ = 3;
        if ((uint *****)0xf < ppppuStack_94) {
          pppppuVar13 = (uint *****)((int)ppppuStack_94 + 1);
          iVar10 = aiStack_a8[0];
          if ((uint *****)0xfff < pppppuVar13) {
            iVar10 = *(int *)(aiStack_a8[0] + -4);
            pppppuVar13 = (uint *****)(ppppuStack_94 + 9);
            if (0x1f < (aiStack_a8[0] - iVar10) - 4U) goto LAB_009f6873;
          }
          FUN_01674ea0(iVar10,pppppuVar13);
        }
      }
      pppppuVar13 = pppppuStack_48;
      puStack_80 = auStack_64;
      pppppuStack_14 = (uint *****)&pppppuStack_58;
      if (0xf < uStack_44) {
        pppppuStack_14 = pppppuStack_58;
      }
      uStack_7c = 0;
      pppppuStack_24 = (uint *****)0x0;
      uStack_20 = 0;
      if (&DAT_0000000f < pppppuStack_48) {
        uVar12 = (uint)pppppuStack_48 | 0xf;
        if (0x7fffffff < uVar12) {
          uVar12 = 0x7fffffff;
        }
        uVar3 = uVar12 + 1;
        if (uVar3 < 0x1000) {
          if (uVar3 == 0) {
            ppppuStack_34 = (uint ****)0x0;
          }
          else {
            ppppuStack_34 = (uint ****)FUN_01674e20(uVar3);
          }
        }
        else {
          uVar8 = uVar12 + 0x24;
          if (uVar8 <= uVar3) {
            uVar8 = 0xffffffff;
          }
          ppppuVar9 = (uint ****)FUN_01674e20(uVar8);
          if (ppppuVar9 == (uint ****)0x0) goto LAB_009f6873;
          ppppuStack_34 = (uint ****)((int)ppppuVar9 + 0x23U & 0xffffffe0);
          ((uint *****)ppppuStack_34)[-1] = ppppuVar9;
        }
        FUN_0170c6f0(ppppuStack_34,pppppuStack_14,(undefined *)((int)pppppuVar13 + 1));
        uStack_20 = uVar12;
      }
      else {
        ppppuStack_34 = *pppppuStack_14;
        ppppuStack_30 = (uint ****)((uint ******)pppppuStack_14)[1];
        ppppuStack_2c = (uint ****)((uint ******)pppppuStack_14)[2];
        ppppuStack_28 = (uint ****)((uint ******)pppppuStack_14)[3];
        uStack_20 = 0xf;
      }
      pppppuStack_24 = pppppuVar13;
      uStack_8._0_1_ = 6;
      pcVar4 = *(code **)(*piStack_40 + 8);
      ppppuStack_a0 = ppppuStack_34;
      ppppuStack_9c = ppppuStack_30;
      ppppuStack_98 = ppppuStack_2c;
      ppppuStack_94 = ppppuStack_28;
      uStack_248 = FUN_0088cb40();
      uStack_244 = 0;
      ppppuStack_240 = ppppuStack_a0;
      ppppuStack_23c = ppppuStack_9c;
      ppppuStack_238 = ppppuStack_98;
      ppppuStack_234 = ppppuStack_94;
      ppppuStack_34 = (uint ****)((uint)ppppuStack_34 & 0xffffff00);
      uStack_230 = CONCAT44(uStack_20,pppppuStack_24);
      pppppuStack_24 = (uint *****)0x0;
      uStack_20 = 0xf;
      uStack_244 = FUN_005c9d30();
      uStack_8._0_1_ = 7;
      uStack_178 = FUN_0088daf0();
      uStack_174 = 0;
      uStack_170 = 1;
      uStack_174 = FUN_005c9ef0();
      uStack_8._0_1_ = 8;
      uStack_78 = 0;
      uStack_74 = 0;
      uStack_70 = 0;
      FUN_00687980(&uStack_248,aiStack_a8,piStack_40);
      uStack_8._0_1_ = 9;
      (*pcVar4)(&DAT_021254b0,&uStack_78,&puStack_80);
      uStack_8._0_1_ = 10;
      FUN_00577b20();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      FUN_016f32d1(&uStack_248,0xd0,2,FUN_0056e5b0);
      piVar6 = piStack_84;
      if (piStack_84 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_84[1] + -1;
        piStack_84[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_84)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar10 = *piVar1 + -1;
          *piVar1 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uStack_8._0_1_ = 1;
      if (0xf < uStack_44) {
        uVar12 = uStack_44 + 1;
        ppppppuVar11 = (uint ******)pppppuStack_58;
        if (0xfff < uVar12) {
          ppppppuVar11 = (uint ******)pppppuStack_58[-1];
          uVar12 = uStack_44 + 0x24;
          if ((undefined *)0x1f < (undefined *)((int)pppppuStack_58 + (-4 - (int)ppppppuVar11))) {
LAB_009f6873:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppppuVar11,uVar12);
      }
      uStack_18 = uStack_18 + 1;
      iStack_1c = iStack_1c + 0xd0;
      uVar12 = (piStack_6c[1] - *piStack_6c) / 0xd0;
    } while (uStack_18 < uVar12);
  }
  piVar6 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_3c + 1);
    uVar3 = *puVar2;
    uVar12 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      puVar2 = (uint *)(piVar6 + 2);
      uVar3 = *puVar2;
      uVar12 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar12 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (piStack_68 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_68 + 1);
    uVar3 = *puVar2;
    uVar12 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar12 = (**(code **)*piStack_68)();
      LOCK();
      piVar6 = piStack_68 + 2;
      iVar10 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        uVar12 = (**(code **)(*piStack_68 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar12;
}



/* FUNCTION 19628 ; VA 0x009f6890 ; FUN_009f6890 */

undefined4 * __thiscall FUN_009f6890(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  bool bVar5;
  bool bVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8fe0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_1;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar3 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar7 = FUN_00913630();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
        (uint)*(ushort *)(iVar7 + 0x1da)) {
      iStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      bVar6 = true;
      bVar5 = false;
      piStack_24 = param_3;
      puVar8 = &uStack_28;
      goto LAB_009f691e;
    }
  }
  piStack_1c = (int *)0x0;
  puVar8 = &uStack_20;
  iStack_14 = 0;
  bVar6 = false;
  bVar5 = true;
LAB_009f691e:
  piVar4 = (int *)puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  if (bVar5) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar3 = *piVar1;
      puVar8 = (undefined4 *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar3 = *piVar1;
        puVar8 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          puVar8 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar1 = piStack_24;
  if ((bVar6) && (piStack_24 != (int *)0x0)) {
    LOCK();
    piVar2 = piStack_24 + 1;
    iVar3 = *piVar2;
    puVar8 = (undefined4 *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      puVar8 = (undefined4 *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar8 = (undefined4 *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_14 != 0) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    puVar8 = (undefined4 *)FUN_009f4050(iStack_14,piVar4);
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    puVar8 = (undefined4 *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      puVar8 = (undefined4 *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar8 = (undefined4 *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar3 = *piVar4;
    puVar8 = (undefined4 *)*piVar4;
    *piVar4 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar8 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar8 = (undefined4 *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar8;
}



/* FUNCTION 19629 ; VA 0x009f6a20 ; FUN_009f6a20 */

uint __thiscall FUN_009f6a20(int *param_1,uint param_2,int *param_3)

{
  uint *puVar1;
  code *pcVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint ****ppppuVar7;
  code *pcVar8;
  uint ***pppuVar9;
  uint *****pppppuVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 uStack_238;
  undefined4 uStack_234;
  uint ***pppuStack_230;
  uint ***pppuStack_22c;
  uint ***pppuStack_228;
  uint ***pppuStack_224;
  uint uStack_220;
  code *pcStack_21c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  uint uStack_160;
  int *piStack_15c;
  uint ***pppuStack_98;
  uint ***pppuStack_94;
  uint ***pppuStack_90;
  uint ***pppuStack_8c;
  uint uStack_88;
  int *piStack_84;
  undefined *puStack_80;
  undefined4 uStack_7c;
  uint ****ppppuStack_78;
  uint ***pppuStack_74;
  uint ***pppuStack_70;
  uint ***pppuStack_6c;
  uint uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  int *piStack_50;
  undefined auStack_4c [4];
  uint ***pppuStack_48;
  uint ***pppuStack_44;
  uint ***pppuStack_40;
  uint ***pppuStack_3c;
  uint uStack_38;
  code *pcStack_34;
  int *piStack_30;
  uint uStack_2c;
  code *pcStack_28;
  uint uStack_24;
  uint ****ppppuStack_20;
  uint ****ppppuStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d904f;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  uVar5 = FUN_00927d30(auStack_4c);
  if (param_1[0x37] == 0) {
    puVar12 = (undefined4 *)0x0;
  }
  else {
    uVar5 = param_1[0x3a];
    puVar12 = *(undefined4 **)(uVar5 + param_1[0x36] * 4);
  }
  do {
    if (puVar12 == (undefined4 *)0x0) {
      if (param_3 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(param_3 + 1);
        uVar6 = *puVar1;
        uVar5 = *puVar1;
        *puVar1 = uVar6 - 1;
        UNLOCK();
        if (uVar6 - 1 == 0) {
          uVar5 = (**(code **)*param_3)();
          LOCK();
          piVar3 = param_3 + 2;
          iVar4 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            uVar5 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar5;
    }
    piStack_84 = (int *)puVar12[3];
    if (piStack_84 != (int *)0x0) {
      LOCK();
      piStack_84[1] = piStack_84[1] + 1;
      UNLOCK();
      piStack_84 = (int *)puVar12[3];
    }
    uVar5 = puVar12[2];
    iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
    iStack_8._0_1_ = 1;
    uStack_88 = uVar5;
    uStack_2c = uVar5;
    piStack_18 = piStack_84;
    if (uVar5 == param_2) {
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_84 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_84 + 1);
        uVar6 = *puVar1 - 1;
        uVar5 = *puVar1;
        *puVar1 = uVar6;
        UNLOCK();
joined_r0x009f6e17:
        if (uVar6 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          puVar1 = (uint *)(piStack_18 + 2);
          uVar6 = *puVar1;
          uVar5 = *puVar1;
          *puVar1 = uVar6 - 1;
          UNLOCK();
          if (uVar6 - 1 == 0) {
            uVar5 = (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    else {
      if (puVar12[6] == 0) {
        puVar11 = (undefined4 *)0x0;
      }
      else {
        puVar11 = *(undefined4 **)(puVar12[9] + puVar12[5] * 4);
        uVar5 = puVar12[9];
      }
      for (; puVar11 != (undefined4 *)0x0; puVar11 = (undefined4 *)*puVar11) {
        ppppuStack_20 = (uint ****)(puVar11 + 2);
        uStack_14 = puVar11[6];
        uStack_68 = 0;
        uStack_64 = 0;
        if (0xf < (uint)puVar11[7]) {
          ppppuStack_20 = (uint ****)*ppppuStack_20;
        }
        if (uStack_14 < 0x10) {
          ppppuStack_78 = (uint ****)*ppppuStack_20;
          pppuStack_74 = (uint ***)((uint *****)ppppuStack_20)[1];
          pppuStack_70 = (uint ***)((uint *****)ppppuStack_20)[2];
          pppuStack_6c = (uint ***)((uint *****)ppppuStack_20)[3];
          uStack_24 = 0xf;
          ppppuStack_1c = ppppuStack_78;
        }
        else {
          uStack_24 = uStack_14 | 0xf;
          if (0x7fffffff < uStack_24) {
            uStack_24 = 0x7fffffff;
          }
          uVar5 = uStack_24 + 1;
          if (uVar5 < 0x1000) {
            if (uVar5 == 0) {
              ppppuStack_78 = (uint ****)0x0;
            }
            else {
              ppppuStack_78 = (uint ****)FUN_01674e20(uVar5);
            }
          }
          else {
            uVar6 = uStack_24 + 0x24;
            if (uVar6 <= uVar5) {
              uVar6 = 0xffffffff;
            }
            ppppuVar7 = (uint ****)FUN_01674e20(uVar6);
            if (ppppuVar7 == (uint ****)0x0) goto LAB_009f6e79;
            ppppuStack_78 = (uint ****)((int)ppppuVar7 + 0x23U & 0xffffffe0);
            ((uint *****)ppppuStack_78)[-1] = ppppuVar7;
          }
          ppppuStack_1c = ppppuStack_78;
          FUN_0170c6f0(ppppuStack_78,ppppuStack_20,uStack_14 + 1);
        }
        puStack_80 = auStack_4c;
        uStack_7c = 0;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          piStack_18[1] = piStack_18[1] + 1;
          UNLOCK();
        }
        uStack_54 = uStack_2c;
        piStack_50 = piStack_18;
        iStack_8._0_1_ = 3;
        uStack_38 = 0;
        ppppuStack_20 = (uint ****)&ppppuStack_78;
        if (0xf < uStack_24) {
          ppppuStack_20 = ppppuStack_1c;
        }
        pcStack_34 = (code *)0x0;
        uStack_68 = uStack_14;
        uStack_64 = uStack_24;
        if (uStack_14 < 0x10) {
          pcStack_34 = (code *)&DAT_0000000f;
          pppuStack_48 = *ppppuStack_20;
          pppuStack_44 = (uint ***)((uint *****)ppppuStack_20)[1];
          pppuStack_40 = (uint ***)((uint *****)ppppuStack_20)[2];
          pppuStack_3c = (uint ***)((uint *****)ppppuStack_20)[3];
        }
        else {
          pcStack_28 = (code *)(uStack_14 | 0xf);
          if ((code *)0x7fffffff < pcStack_28) {
            pcStack_28 = (code *)0x7fffffff;
          }
          pcVar2 = pcStack_28 + 1;
          if (pcVar2 < &DAT_00001000) {
            if (pcVar2 == (code *)0x0) {
              pppuStack_48 = (uint ***)0x0;
            }
            else {
              pppuStack_48 = (uint ***)FUN_01674e20(pcVar2);
            }
          }
          else {
            pcVar8 = pcStack_28 + 0x24;
            if (pcVar8 <= pcVar2) {
              pcVar8 = (code *)0xffffffff;
            }
            pppuVar9 = (uint ***)FUN_01674e20(pcVar8);
            if (pppuVar9 == (uint ***)0x0) goto LAB_009f6e79;
            pppuStack_48 = (uint ***)((int)pppuVar9 + 0x23U & 0xffffffe0);
            ((uint ****)pppuStack_48)[-1] = pppuVar9;
          }
          FUN_0170c6f0(pppuStack_48,ppppuStack_20,uStack_14 + 1);
          pcStack_34 = pcStack_28;
        }
        iStack_8._0_1_ = 5;
        pcStack_28 = *(code **)(*piStack_30 + 8);
        pppuStack_98 = pppuStack_48;
        pppuStack_94 = pppuStack_44;
        pppuStack_90 = pppuStack_40;
        pppuStack_8c = pppuStack_3c;
        uStack_38 = uStack_14;
        uStack_238 = FUN_0088cb40();
        uStack_234 = 0;
        pppuStack_230 = pppuStack_98;
        pppuStack_22c = pppuStack_94;
        pppuStack_228 = pppuStack_90;
        pppuStack_224 = pppuStack_8c;
        pppuStack_48 = (uint ***)((uint)pppuStack_48 & 0xffffff00);
        uStack_220 = uStack_38;
        pcStack_21c = pcStack_34;
        uStack_38 = 0;
        pcStack_34 = (code *)0xf;
        uStack_234 = FUN_005c9d30();
        iStack_8._0_1_ = 6;
        uStack_168 = FUN_0088cdc0();
        uStack_160 = uStack_2c;
        uStack_164 = 0;
        piStack_15c = piStack_18;
        uStack_54 = 0;
        piStack_50 = (int *)0x0;
        uStack_164 = FUN_006309e0();
        iStack_8._0_1_ = 7;
        uStack_60 = 0;
        uStack_5c = 0;
        uStack_58 = 0;
        FUN_00687980(&uStack_238,&pppuStack_98,param_3);
        iStack_8._0_1_ = 8;
        (*pcStack_28)(&DAT_02125530,&uStack_60,&puStack_80);
        iStack_8._0_1_ = 9;
        FUN_00577b20();
        iStack_8._0_1_ = 5;
        FUN_016f32d1(&uStack_238,0xd0,2,FUN_0056e5b0);
        iStack_8._0_1_ = 1;
        uVar5 = uStack_24;
        if (0xf < uStack_24) {
          uVar5 = uStack_24 + 1;
          pppppuVar10 = (uint *****)ppppuStack_1c;
          if (0xfff < uVar5) {
            pppppuVar10 = (uint *****)ppppuStack_1c[-1];
            uVar5 = uStack_24 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_1c + (-4 - (int)pppppuVar10))) {
LAB_009f6e79:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          uVar5 = FUN_01674ea0(pppppuVar10,uVar5);
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_18 + 1);
        uVar6 = *puVar1 - 1;
        uVar5 = *puVar1;
        *puVar1 = uVar6;
        UNLOCK();
        goto joined_r0x009f6e17;
      }
    }
    puVar12 = (undefined4 *)*puVar12;
  } while( true );
}



/* FUNCTION 19630 ; VA 0x009f6e80 ; FUN_009f6e80 */

void __thiscall FUN_009f6e80(int param_1,undefined4 *param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  char *pcVar10;
  undefined8 uVar11;
  undefined auStack_84 [24];
  undefined auStack_6c [24];
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar7 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d90c2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_016793f0();
    if (cVar2 != '\0') {
      FUN_01679490();
    }
    if ((DAT_01d65a50 != '\0') && (cVar2 = FUN_016793f0(), cVar2 != '\0')) {
      FUN_01679490();
    }
  }
  uVar9 = param_3;
  FUN_008a4210(puVar7,param_3);
  if (uVar9 != 0) {
    uVar3 = FUN_00983210(param_1);
    *(undefined *)(param_1 + 0xb8) = uVar3;
    cVar2 = FUN_00971ce0(param_1,1);
    if (cVar2 != '\0') {
      iVar5 = *(int *)(param_1 + 0x34);
      iVar4 = param_1;
      if ((iVar5 != 0) && (iVar4 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
        iVar4 = FUN_005c8ac0();
      }
      if (((iVar4 != 0) &&
          (iVar5 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(), uVar9 = param_3,
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da))) &&
         (iVar5 = FUN_005cf750(), uVar9 = param_3, iVar5 != 0)) {
        puStack_18 = (undefined4 *)(iVar5 + 0x2a8);
        iStack_8 = 0;
        iVar5 = FUN_01675290(DAT_02110da8);
        iStack_8._0_1_ = 1;
        iStack_1c = iVar5;
        puStack_20 = (undefined4 *)FUN_01674e20(0x1c);
        if (puStack_20 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)0x0;
        }
        else {
          *puStack_20 = 0;
          puStack_20[1] = 1;
          puStack_20[2] = FUN_009f5440;
          puStack_20[3] = _guard_check_icall;
          puStack_20[4] = 0;
          puStack_20[5] = puStack_18;
          puStack_20[6] = param_1;
          puVar7 = puStack_20;
        }
        FUN_016797d0(puVar7);
        if (puVar7 != (undefined4 *)0x0) {
          LOCK();
          puVar7[1] = puVar7[1] + 1;
          UNLOCK();
        }
        uStack_14 = 1;
        iStack_8._0_1_ = 2;
        param_2 = puVar7;
        FUN_01675290(iVar5);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        cVar2 = FUN_01679300(&param_2);
        if (cVar2 != '\0') {
          FUN_01679490();
          FUN_016791c0(&param_2);
        }
        iStack_8 = 0xffffffff;
        uStack_14 = 0;
        uVar9 = param_3;
        if (param_2 != (undefined4 *)0x0) {
          piVar1 = param_2 + 1;
          LOCK();
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          uStack_14 = 0;
          if (iVar5 == 1) {
            FUN_01674ea0(param_2);
            uStack_14 = 0;
            uVar9 = param_3;
          }
        }
      }
      if ((DAT_01d656f0 != '\0') && (iVar5 = FUN_009effc0(uVar9), iVar5 != 0)) {
        if (DAT_01d656f8 == '\0') {
          param_3 = CONCAT31(param_3._1_3_,*(undefined *)(iVar5 + 0x68));
          FUN_009facc0(param_3);
        }
        else {
          cVar2 = *(char *)(iVar5 + 0x69);
          param_2 = (undefined4 *)CONCAT31(param_2._1_3_,cVar2);
          uStack_2c = 0;
          uStack_28 = 0xf;
          auStack_3c[0] = 0;
          FUN_005542c0("Studio.TeamCreate.CollabEdit.",0x1d);
          iStack_8 = 3;
          pcVar10 = "Enabled";
          if (cVar2 == '\0') {
            pcVar10 = "Disabled";
          }
          uVar6 = FUN_00558c80(auStack_6c,auStack_3c,pcVar10);
          iStack_8 = CONCAT31(iStack_8._1_3_,4);
          FUN_008783f0(uVar6,1,0);
          FUN_005507b0();
          iStack_8 = 0xffffffff;
          FUN_005507b0();
          FUN_0087c450("Studio","CollabEdit",pcVar10,1,0,0);
          FUN_009facc0(param_2);
          uVar9 = param_3;
        }
        if ((DAT_01d65710 != '\0') && (DAT_01d65708 != '\0')) {
          if ((DAT_01d65720 != '\0') || (param_3 = param_3 & 0xffffff00, DAT_01d65728 != '\0')) {
            param_3 = CONCAT31(param_3._1_3_,1);
          }
          if ((DAT_01d65a50 != '\0') && (iStack_1c = FUN_008f7870(uVar9), iStack_1c != 0)) {
            param_2 = (undefined4 *)(iStack_1c + 0xd4);
            iStack_8 = 5;
            puVar7 = (undefined4 *)FUN_01675290(DAT_02110da8);
            iStack_8._0_1_ = 6;
            puStack_20 = puVar7;
            puStack_24 = (undefined4 *)FUN_01674e20(0x1c);
            if (puStack_24 == (undefined4 *)0x0) {
              puVar8 = (undefined4 *)0x0;
            }
            else {
              *puStack_24 = 0;
              puStack_24[1] = 1;
              puStack_24[2] = FUN_009f5330;
              puStack_24[3] = _guard_check_icall;
              puStack_24[4] = 0;
              puStack_24[5] = param_2;
              puStack_24[6] = param_1;
              puVar8 = puStack_24;
            }
            FUN_016797d0(puVar8);
            if (puVar8 != (undefined4 *)0x0) {
              LOCK();
              puVar8[1] = puVar8[1] + 1;
              UNLOCK();
            }
            uStack_14 = 2;
            iStack_8._0_1_ = 7;
            puStack_18 = puVar8;
            FUN_01675290(puVar7);
            iStack_8 = CONCAT31(iStack_8._1_3_,5);
            FUN_00614020(&puStack_18);
            iStack_8 = 0xffffffff;
            FUN_0056e750();
            piVar1 = *(int **)(iStack_1c + 0x43c);
            iVar5 = piVar1[1];
            uVar9 = *piVar1 - (int)piVar1;
            uVar11 = FUN_016f3900(uVar9,iVar5 - (int)piVar1,10000,0);
            uVar11 = FUN_016f39b0(uVar11,10000,0);
            iVar5 = ((iVar5 - (int)piVar1) - (int)((ulonglong)uVar11 >> 0x20)) -
                    (uint)(uVar9 < (uint)uVar11);
            if ((iVar5 <= (int)DAT_01ee5c3c >> 0x1f) &&
               ((iVar5 < (int)DAT_01ee5c3c >> 0x1f || (uVar9 - (uint)uVar11 < DAT_01ee5c3c)))) {
              param_3 = CONCAT31(param_3._1_3_,1);
            }
          }
          uStack_44 = 0;
          uStack_40 = 0xf;
          auStack_54[0] = 0;
          FUN_005542c0("Studio.TeamCreate.CollabEditVersionHistory.",0x2b);
          cVar2 = (char)param_3;
          iStack_8 = 8;
          pcVar10 = "Enabled";
          if ((char)param_3 == '\0') {
            pcVar10 = "Disabled";
          }
          uVar6 = FUN_00558c80(auStack_84,auStack_54,pcVar10);
          iStack_8 = CONCAT31(iStack_8._1_3_,9);
          FUN_008783f0(uVar6,1,0);
          FUN_005507b0();
          iStack_8 = 0xffffffff;
          FUN_005507b0();
          FUN_0087c450("Studio","CollabEditVersionHistory",pcVar10,1,0,0);
          FUN_009facf0(param_3);
          if ((DAT_01d65a50 == '\0') && (cVar2 != '\0')) {
            FUN_009f2120();
          }
        }
      }
      if ((DAT_01d656e0 != '\0') && (*(char *)(param_1 + 0xec) != DAT_01d656e8)) {
        *(char *)(param_1 + 0xec) = DAT_01d656e8;
        FUN_008a4940(&DAT_021252c8);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19631 ; VA 0x009f7380 ; FUN_009f7380 */

int __thiscall
FUN_009f7380(int param_1,int *param_2,int *param_3,int *param_4,int *param_5,int param_6,int param_7
            )

{
  int *piVar1;
  undefined4 uVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  uint auStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  int *piStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  int iStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  int *piStack_48;
  code *pcStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  uint *puStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d914b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uStack_24 = FUN_008f7870(param_1);
  if (*(int *)(param_1 + 0xf0) != 0) {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar5 = FUN_009f9770(param_2,param_3,param_7,2);
    goto LAB_009f7c07;
  }
  uStack_50 = 0;
  piStack_4c = (int *)0x0;
  piStack_48 = (int *)0x0;
  uStack_5c = 0;
  iStack_58 = 0;
  iStack_54 = 0;
  uStack_8 = 3;
  FUN_0097c020(&piStack_34,param_7,param_1);
  uStack_8 = 4;
  uVar3 = uStack_8;
  uStack_8 = 4;
  if (piStack_34 == (int *)0x0) {
    if ((((DAT_01ee5c38 != 0) && (iVar5 = FUN_008f7870(param_1), uVar3 = uStack_8, iVar5 != 0)) &&
        (iVar5 != -0xc)) && (param_6 = FUN_005cf750(), uVar3 = uStack_8, param_6 != 0)) {
      piStack_64 = (int *)0x0;
      uStack_60 = 0xf;
      uStack_74 = uStack_74 & 0xffffff00;
      FUN_005542c0("apply edits failed with internal error: cannot initiate commit",0x3e);
      uStack_8 = 5;
      FUN_0098c2c0(1,&uStack_74);
      uStack_8 = 4;
      FUN_005507b0();
      uVar3 = uStack_8;
    }
    uStack_8 = uVar3;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_009f9770(param_2,param_3,param_7,0);
  }
  else {
    uStack_14 = 0;
    iVar5 = param_2[1] - *param_2 >> 0x1f;
    uStack_8 = uVar3;
    if ((param_2[1] - *param_2) / 0xd0 + iVar5 != iVar5) {
      param_7 = 0;
      do {
        iVar5 = *(int *)(*param_2 + param_7);
        piStack_20 = (int *)(*param_2 + param_7);
        iVar6 = FUN_0088cb40();
        if (iVar5 != iVar6) {
LAB_009f7c64:
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piStack_64 = (int *)0x0;
        uStack_60 = 0;
        puStack_1c = (uint *)(-(uint)(piStack_20[1] != 0) & (uint)(piStack_20 + 2));
        piStack_20 = (int *)puStack_1c[4];
        if (0xf < puStack_1c[5]) {
          puStack_1c = (uint *)*puStack_1c;
        }
        if (&DAT_0000000f < piStack_20) {
          uVar11 = (uint)piStack_20 | 0xf;
          if (0x7fffffff < uVar11) {
            uVar11 = 0x7fffffff;
          }
          uStack_74 = FUN_00554060(uVar11 + 1);
          FUN_0170c6f0(uStack_74,puStack_1c,(undefined *)((int)piStack_20 + 1));
          uStack_60 = uVar11;
        }
        else {
          uStack_74 = *puStack_1c;
          uStack_70 = puStack_1c[1];
          uStack_6c = puStack_1c[2];
          uStack_68 = puStack_1c[3];
          uStack_60 = 0xf;
        }
        uStack_8 = 6;
        piStack_64 = piStack_20;
        FUN_008fbc70(&iStack_2c,&uStack_74);
        piVar10 = piStack_28;
        uStack_8 = 7;
        if (iStack_2c == 0) {
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_28[1] + -1;
            piStack_28[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_28)();
              LOCK();
              piVar1 = piVar10 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
          uStack_8 = 4;
          if (0xf < uStack_60) {
            uVar9 = uStack_60 + 1;
            uVar11 = uStack_74;
            if (0xfff < uVar9) {
              uVar11 = *(uint *)(uStack_74 - 4);
              uVar9 = uStack_60 + 0x24;
              if (0x1f < (uStack_74 - uVar11) - 4) goto LAB_009f7c6e;
            }
            FUN_01674ea0(uVar11,uVar9);
          }
        }
        else {
          piStack_20 = (int *)FUN_00ae43a0();
          if ((piStack_20 == (int *)0x0) ||
             (iVar5 = piStack_20[3], iVar6 = FUN_00913630(), piVar10 = piStack_20,
             (uint)*(ushort *)(iVar6 + 0x1da) <
             (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
            piVar10 = (int *)0x0;
          }
          if (piVar10 == piStack_34) {
            if (piStack_28 != (int *)0x0) {
              LOCK();
              piStack_28[1] = piStack_28[1] + 1;
              UNLOCK();
            }
            iStack_3c = iStack_2c;
            piStack_38 = piStack_28;
            uStack_8 = 8;
            if (piStack_48 == piStack_4c) {
              FUN_00603a30(piStack_4c,&iStack_3c);
              piVar10 = piStack_38;
            }
            else {
              *piStack_4c = 0;
              *piStack_4c = iStack_2c;
              piStack_4c[1] = (int)piStack_28;
              piStack_4c = piStack_4c + 2;
              iStack_3c = 0;
              piVar10 = (int *)0x0;
            }
            uStack_8 = 7;
            if (piVar10 != (int *)0x0) {
              LOCK();
              iVar5 = piVar10[1] + -1;
              piVar10[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piVar10)();
                LOCK();
                iVar5 = piVar10[2] + -1;
                piVar10[2] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piVar10 + 4))();
                }
              }
            }
            piStack_20 = (int *)(*param_4 + param_7);
            iVar5 = *piStack_20;
            iVar6 = FUN_0088cb40();
            if (iVar5 != iVar6) goto LAB_009f7c64;
            piVar10 = piStack_20 + 2;
            if (piStack_20[1] == 0) {
              piVar10 = (int *)0x0;
            }
            if (iStack_54 == iStack_58) {
              FUN_00559960(iStack_58,piVar10);
            }
            else {
              FUN_0054ef60(piVar10);
              iStack_58 = iStack_58 + 0x18;
            }
          }
          piVar10 = piStack_28;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_28[1] + -1;
            piStack_28[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_28)();
              LOCK();
              piVar1 = piVar10 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
          uStack_8 = 4;
          FUN_005507b0();
        }
        uStack_14 = uStack_14 + 1;
        param_7 = param_7 + 0xd0;
      } while (uStack_14 < (uint)((param_2[1] - *param_2) / 0xd0));
    }
    iVar5 = iStack_18;
    FUN_009fae00(auStack_8c,param_6,&uStack_50);
    uStack_8 = 9;
    uVar7 = FUN_005c4330(&iStack_2c,uStack_24);
    _uStack_8 = CONCAT31(uStack_7,10);
    puVar8 = (undefined4 *)
             FUN_009f0080(&iStack_3c,uVar7,&piStack_34,&uStack_50,&uStack_5c,auStack_8c);
    uVar7 = *puVar8;
    uVar2 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined4 *)(iVar5 + 0xf0) = uVar7;
    piVar10 = *(int **)(iVar5 + 0xf4);
    *(undefined4 *)(iVar5 + 0xf4) = uVar2;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar5 = piVar10[1] + -1;
      piVar10[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar5 = piVar10[2] + -1;
        piVar10[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    piVar10 = piStack_38;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_38[1] + -1;
      piStack_38[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    uStack_8 = 9;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_28[1] + -1;
      piStack_28[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar5 = piStack_28[2] + -1;
        piStack_28[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    pcStack_44 = FUN_009f6340;
    uStack_40 = 0;
    iStack_3c = iStack_18;
    if (DAT_01d65a50 == '\0') {
      param_7 = FUN_00915d30(&param_6,&pcStack_44);
      _uStack_8 = CONCAT31(uStack_7,0xb);
      cVar4 = FUN_01679300(param_7);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_7);
      }
      uStack_8 = 9;
      if (param_6 != 0) {
        piVar10 = (int *)(param_6 + 4);
        LOCK();
        iVar6 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_6);
        }
      }
      pcStack_44 = FUN_009f61b0;
      uStack_40 = 0;
      iStack_3c = iVar5;
      param_7 = FUN_00915d30(&param_6,&pcStack_44);
      _uStack_8 = CONCAT31(uStack_7,0xc);
      cVar4 = FUN_01679300(param_7);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_7);
      }
      uStack_8 = 9;
      if (param_6 != 0) {
        piVar10 = (int *)(param_6 + 4);
        LOCK();
        iVar6 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_6);
        }
      }
      pcStack_44 = FUN_009f6070;
      uStack_40 = 0;
      iStack_3c = iVar5;
      param_7 = FUN_00836450(&param_6,&pcStack_44);
      _uStack_8 = CONCAT31(uStack_7,0xd);
      cVar4 = FUN_01679300(param_7);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_7);
      }
      uStack_8 = 9;
      if (param_6 != 0) {
        piVar10 = (int *)(param_6 + 4);
        LOCK();
        iVar6 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_6);
        }
      }
      pcStack_44 = FUN_009f2470;
      uStack_40 = 0;
      iStack_3c = iVar5;
      param_7 = FUN_00915d30(&param_6,&pcStack_44);
      _uStack_8 = CONCAT31(uStack_7,0xe);
      cVar4 = FUN_01679300(param_7);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_7);
      }
      uStack_8 = 9;
      if (param_6 != 0) {
        piVar10 = (int *)(param_6 + 4);
        LOCK();
        iVar5 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        iVar6 = param_6;
        goto joined_r0x009f7b6f;
      }
    }
    else {
      FUN_00915d30(&param_7,&pcStack_44);
      if (param_7 != 0) {
        piVar10 = (int *)(param_7 + 4);
        LOCK();
        iVar6 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_7);
        }
      }
      pcStack_44 = FUN_009f61b0;
      uStack_40 = 0;
      iStack_3c = iVar5;
      FUN_00915d30(&param_7,&pcStack_44);
      if (param_7 != 0) {
        piVar10 = (int *)(param_7 + 4);
        LOCK();
        iVar6 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_7);
        }
      }
      pcStack_44 = FUN_009f6070;
      uStack_40 = 0;
      iStack_3c = iVar5;
      FUN_00836450(&param_7,&pcStack_44);
      if (param_7 != 0) {
        piVar10 = (int *)(param_7 + 4);
        LOCK();
        iVar6 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_7);
        }
      }
      pcStack_44 = FUN_009f61f0;
      uStack_40 = 0;
      iStack_3c = iVar5;
      FUN_009efbb0(&param_7,&pcStack_44);
      if (param_7 != 0) {
        piVar10 = (int *)(param_7 + 4);
        LOCK();
        iVar5 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        iVar6 = param_7;
joined_r0x009f7b6f:
        if (iVar5 == 1) {
          FUN_01674ea0(iVar6);
        }
      }
    }
    FUN_00a0b400();
    if (0xf < uStack_78) {
      uVar9 = uStack_78 + 1;
      uVar11 = auStack_8c[0];
      if (0xfff < uVar9) {
        uVar11 = *(uint *)(auStack_8c[0] - 4);
        uVar9 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar11) - 4) {
LAB_009f7c6e:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar9);
    }
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = auStack_8c[0] & 0xffffff00;
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_30[2] + -1;
      piStack_30[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  thunk_FUN_00577a40();
  iVar5 = thunk_FUN_00577ac0();
LAB_009f7c07:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar10 = param_3 + 1;
    iVar6 = *piVar10;
    iVar5 = *piVar10;
    *piVar10 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar10 = param_3 + 2;
      iVar6 = *piVar10;
      iVar5 = *piVar10;
      *piVar10 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar10 = param_5 + 1;
    iVar6 = *piVar10;
    iVar5 = *piVar10;
    *piVar10 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar10 = param_5 + 2;
      iVar6 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19632 ; VA 0x009f7c80 ; FUN_009f7c80 */

void * __thiscall FUN_009f7c80(int param_1,undefined *param_2,int *param_3,int *param_4)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  void *pvVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 in_stack_ffffff14;
  undefined4 in_stack_ffffff18;
  int **ppiVar9;
  undefined4 in_stack_ffffff1c;
  undefined4 in_stack_ffffff20;
  int **ppiVar10;
  undefined *in_stack_ffffff24;
  undefined4 in_stack_ffffff28;
  undefined4 uVar11;
  undefined *puVar12;
  undefined auStack_c0 [24];
  undefined auStack_a8 [24];
  undefined auStack_90 [24];
  undefined auStack_78 [24];
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  int *apiStack_30 [2];
  int *apiStack_28 [2];
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d924f;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0xb8) == '\0') {
    return ExceptionList;
  }
  if (param_2 == &DAT_02125370) {
    ExceptionList = &pvStack_10;
    FUN_0097c020(&piStack_18,param_4,param_1);
    uStack_8 = 0;
    param_3 = (int *)*param_3;
    iVar6 = *param_3;
    iVar3 = FUN_0088cb40();
    if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    FUN_0054ef60(piVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    FUN_009f9160(auStack_48,piStack_18,piStack_14);
    pvVar5 = (void *)FUN_005507b0();
    if (piStack_14 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return pvVar5;
    }
    LOCK();
    piVar4 = piStack_14 + 1;
    iVar6 = *piVar4;
    pvVar5 = (void *)*piVar4;
    *piVar4 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 != 0) {
      ExceptionList = pvStack_10;
      return pvVar5;
    }
    pvVar5 = (void *)(**(code **)*piStack_14)();
    LOCK();
    piVar4 = piStack_14 + 2;
    iVar6 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar6 != 1) {
      ExceptionList = pvStack_10;
      return pvVar5;
    }
    pvVar5 = (void *)(**(code **)(*piStack_14 + 4))();
    ExceptionList = pvStack_10;
    return pvVar5;
  }
  if (param_2 == &DAT_021253b0) {
    ExceptionList = &pvStack_10;
    FUN_0097c020(&piStack_18,param_4,param_1);
    uStack_8 = 2;
    param_3 = (int *)*param_3;
    iVar6 = *param_3;
    iVar3 = FUN_0088cb40();
    if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    FUN_0054ef60(piVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    FUN_009f4770(auStack_48,piStack_18,piStack_14);
    FUN_005507b0();
    pvVar5 = (void *)FUN_00550b30();
    ExceptionList = pvStack_10;
    return pvVar5;
  }
  if (param_2 == &DAT_021253f0) {
    ExceptionList = &pvStack_10;
    iVar6 = FUN_008f7870(param_1);
    uVar7 = FUN_0055d610();
    FUN_0054ef60(uVar7);
    uStack_8 = 4;
    uVar7 = 0x9f7e66;
    FUN_008fbc70(apiStack_28,auStack_78);
    uStack_8._0_1_ = 5;
    if (apiStack_28[0] == (int *)0x0) {
      piStack_18 = param_4;
      ppiVar10 = &piStack_18;
      uVar11 = 0;
      piStack_14 = (int *)0x0;
      FUN_0054ef60(auStack_78);
      FUN_009fa300(param_1,in_stack_ffffff14,in_stack_ffffff18,in_stack_ffffff1c,in_stack_ffffff20,
                   in_stack_ffffff24,uVar7,uVar11,ppiVar10);
    }
    else {
      uVar7 = FUN_0055d610();
      FUN_0054ef60(uVar7);
      uStack_8._0_1_ = 6;
      uVar7 = FUN_0055d610();
      FUN_0054ef60(uVar7);
      uStack_8._0_1_ = 7;
      uVar7 = (**(code **)(*apiStack_28[0] + 0xac))();
      FUN_0054ef60(uVar7);
      uStack_8._0_1_ = 8;
      uVar7 = 0x9f7f00;
      cVar2 = FUN_00558b30(auStack_a8,auStack_48);
      if (cVar2 != '\0') {
        FUN_009efed0(&piStack_20,apiStack_28);
        uStack_8._0_1_ = 9;
        uVar1 = (undefined)uStack_8;
        uStack_8._0_1_ = 9;
        if (piStack_20 == (int *)0x0) {
          uVar7 = 0x9f7f61;
          uStack_8._0_1_ = uVar1;
          FUN_009431c0(apiStack_30,apiStack_28);
          uStack_8._0_1_ = 0xb;
          uVar1 = (undefined)uStack_8;
          uStack_8._0_1_ = 0xb;
          if (apiStack_30[0] != (int *)0x0) {
            uVar7 = 0x9f7f7c;
            uVar11 = FUN_00886c00(&piStack_18,auStack_60);
            uStack_8._0_1_ = 0xc;
            FUN_009ed830(uVar11);
            FUN_0056e380();
            FUN_0056e380();
            uVar1 = (undefined)uStack_8;
          }
          uStack_8._0_1_ = uVar1;
          FUN_00550b30();
        }
        else {
          uVar7 = 0x9f7f33;
          uVar11 = FUN_00886c00(&piStack_18,auStack_60);
          uStack_8._0_1_ = 10;
          FUN_00b75530(uVar11);
          FUN_0056e380();
          FUN_0056e380();
        }
        uStack_8._0_1_ = 8;
        FUN_00550b30();
        if (((iVar6 != 0) && (iVar6 != -0xc)) && (iVar6 = FUN_005cf750(), iVar6 != 0)) {
          FUN_0097c020(&piStack_20,param_4,param_1);
          uStack_8._0_1_ = 0xd;
          puVar8 = (undefined4 *)FUN_008a2380(auStack_90);
          uStack_8._0_1_ = 0xe;
          if (0xf < (uint)puVar8[5]) {
            puVar8 = (undefined4 *)*puVar8;
          }
          piVar4 = (int *)piStack_20[10];
          if (0xf < (uint)piVar4[5]) {
            piVar4 = (int *)*piVar4;
          }
          in_stack_ffffff24 = auStack_c0;
          in_stack_ffffff20 = 0x9f8024;
          uVar11 = FUN_01675640(in_stack_ffffff24,"%s committed a new version of script %s",piVar4,
                                puVar8);
          uStack_8._0_1_ = 0xf;
          uVar7 = 0x9f8035;
          FUN_0098c2c0(1,uVar11);
          FUN_005507b0();
          FUN_005507b0();
          uStack_8._0_1_ = 8;
          FUN_00550b30();
        }
        ppiVar10 = &piStack_20;
        piStack_20 = param_4;
        uVar11 = 1;
        uStack_1c = 0;
        FUN_0054ef60(auStack_78);
        FUN_009fa300(param_1,in_stack_ffffff14,in_stack_ffffff18,in_stack_ffffff1c,in_stack_ffffff20
                     ,in_stack_ffffff24,uVar7,uVar11,ppiVar10);
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_00550b30();
        pvVar5 = (void *)FUN_005507b0();
        ExceptionList = pvStack_10;
        return pvVar5;
      }
      piStack_20 = param_4;
      ppiVar10 = &piStack_20;
      uVar11 = 0;
      uStack_1c = 0;
      FUN_0054ef60(auStack_78);
      FUN_009fa300(param_1,in_stack_ffffff14,in_stack_ffffff18,in_stack_ffffff1c,in_stack_ffffff20,
                   in_stack_ffffff24,uVar7,uVar11,ppiVar10);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
    }
    FUN_00550b30();
    pvVar5 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar5;
  }
  if (param_2 == &DAT_02125430) {
    ExceptionList = &pvStack_10;
    uVar7 = FUN_00605bd0();
    FUN_00557fc0(uVar7);
    uStack_8 = 0x10;
    uVar7 = FUN_00605bd0();
    FUN_00557fc0(uVar7);
    uStack_8._0_1_ = 0x11;
    uVar7 = FUN_00605bd0();
    FUN_00557fc0(uVar7);
    uStack_8._0_1_ = 0x12;
    uVar7 = FUN_0055d610();
    FUN_0054ef60(uVar7);
    uStack_8._0_1_ = 0x13;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x13;
    if ((((apiStack_28[0] == (int *)0x0) || (piStack_18 == (int *)0x0)) ||
        (apiStack_30[0] == (int *)0x0)) ||
       ((iVar6 = (apiStack_28[0][1] - *apiStack_28[0]) / 0xd0,
        iVar6 != (piStack_18[1] - *piStack_18) / 0xd0 ||
        (iVar6 != (apiStack_30[0][1] - *apiStack_30[0]) / 0xd0)))) {
      if ((((DAT_01ee5c38 != 0) &&
           (iVar6 = FUN_008f7870(param_1), uVar1 = (undefined)uStack_8, iVar6 != 0)) &&
          (iVar6 != -0xc)) && (iVar6 = FUN_005cf750(), uVar1 = (undefined)uStack_8, iVar6 != 0)) {
        FUN_0097c020(&piStack_20,param_4,param_1);
        uStack_8._0_1_ = 0x14;
        piVar4 = (int *)piStack_20[10];
        if (0xf < (uint)piVar4[5]) {
          piVar4 = (int *)*piVar4;
        }
        in_stack_ffffff24 = (undefined *)0x9f8331;
        uVar7 = FUN_01675640(auStack_90,"%s\'s commit failed with internal error: bad commit input",
                             piVar4);
        uStack_8._0_1_ = 0x15;
        in_stack_ffffff28 = 0x9f8342;
        FUN_0098c2c0(1,uVar7);
        FUN_005507b0();
        uStack_8._0_1_ = 0x13;
        FUN_00550b30();
        uVar1 = (undefined)uStack_8;
      }
      uStack_8._0_1_ = uVar1;
      uVar7 = 0;
      FUN_00557fc0(apiStack_28);
      FUN_009f9770(in_stack_ffffff24,in_stack_ffffff28,param_4,uVar7);
    }
    else if ((DAT_01d65710 == '\0') ||
            ((DAT_01d65708 == '\0' || (*(char *)(param_1 + 0xee) == '\0')))) {
      puVar12 = auStack_60;
      ppiVar10 = apiStack_30;
      uVar11 = 0x9f827e;
      FUN_00557fc0(ppiVar10);
      ppiVar9 = &piStack_18;
      uVar7 = 0x9f828c;
      FUN_00557fc0(ppiVar9);
      FUN_00557fc0(apiStack_28);
      FUN_009f24d0(uVar7,ppiVar9,uVar11,ppiVar10,in_stack_ffffff24,in_stack_ffffff28,puVar12,param_4
                  );
    }
    else {
      puVar12 = auStack_60;
      ppiVar10 = apiStack_30;
      uVar11 = 0x9f8244;
      FUN_00557fc0(ppiVar10);
      ppiVar9 = &piStack_18;
      uVar7 = 0x9f8252;
      FUN_00557fc0(ppiVar9);
      FUN_00557fc0(apiStack_28);
      FUN_009f8590(uVar7,ppiVar9,uVar11,ppiVar10,in_stack_ffffff24,in_stack_ffffff28,puVar12,param_4
                  );
    }
    FUN_005507b0();
    FUN_00550b30();
    FUN_00550b30();
    pvVar5 = (void *)FUN_00550b30();
    ExceptionList = pvStack_10;
    return pvVar5;
  }
  if (param_2 == &DAT_02125470) {
    ExceptionList = &pvStack_10;
    uVar7 = FUN_00605bd0();
    FUN_00557fc0(uVar7);
    uStack_8 = 0x16;
    uVar7 = FUN_00605bd0();
    FUN_00557fc0(uVar7);
    uStack_8._0_1_ = 0x17;
    uVar7 = FUN_0055d610();
    FUN_0054ef60(uVar7);
    uStack_8._0_1_ = 0x18;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x18;
    if (((piStack_18 == (int *)0x0) || (apiStack_30[0] == (int *)0x0)) ||
       ((piStack_18[1] - *piStack_18) / 0xd0 != (apiStack_30[0][1] - *apiStack_30[0]) / 0xd0)) {
      if (((DAT_01ee5c38 != 0) &&
          (iVar6 = FUN_008f7870(param_1), uVar1 = (undefined)uStack_8, iVar6 != 0)) &&
         ((iVar6 != -0xc && (iVar6 = FUN_005cf750(), uVar1 = (undefined)uStack_8, iVar6 != 0)))) {
        FUN_0097c020(&piStack_20,param_4,param_1);
        uStack_8._0_1_ = 0x19;
        piVar4 = (int *)piStack_20[10];
        if (0xf < (uint)piVar4[5]) {
          piVar4 = (int *)*piVar4;
        }
        in_stack_ffffff24 = (undefined *)0x9f84c7;
        uVar7 = FUN_01675640(auStack_90,"%s\'s apply edits failed with internal error: bad input",
                             piVar4);
        uStack_8._0_1_ = 0x1a;
        in_stack_ffffff28 = 0x9f84d8;
        FUN_0098c2c0(1,uVar7);
        FUN_005507b0();
        uStack_8._0_1_ = 0x18;
        FUN_00550b30();
        uVar1 = (undefined)uStack_8;
      }
      uStack_8._0_1_ = uVar1;
      uVar7 = 0;
      FUN_00557fc0(&piStack_18);
      FUN_009f9770(in_stack_ffffff24,in_stack_ffffff28,param_4,uVar7);
    }
    else {
      puVar12 = auStack_48;
      ppiVar10 = apiStack_30;
      uVar7 = 0x9f842a;
      FUN_00557fc0(ppiVar10);
      FUN_00557fc0(&piStack_18);
      FUN_009f7380(uVar7,ppiVar10,in_stack_ffffff24,in_stack_ffffff28,puVar12,param_4);
    }
    FUN_005507b0();
    FUN_00550b30();
    pvVar5 = (void *)FUN_00550b30();
    ExceptionList = pvStack_10;
    return pvVar5;
  }
  if (param_2 != &DAT_021255b0) {
    ExceptionList = &pvStack_10;
    pvVar5 = (void *)FUN_009cba80(param_2,param_3,param_4);
    ExceptionList = pvStack_10;
    return pvVar5;
  }
  ExceptionList = &pvStack_10;
  FUN_0097c020(&piStack_20,param_4,param_1);
  uStack_8 = 0x1b;
  FUN_00557fc0(&piStack_20);
  FUN_009f6a20(param_4,param_1);
  pvVar5 = (void *)FUN_00550b30();
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 19633 ; VA 0x009f8590 ; FUN_009f8590 */

int __thiscall
FUN_009f8590(int *param_1,int *param_2,int *param_3,int *param_4,int *param_5,int *param_6,
            int *param_7,int param_8,int param_9)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  uint *puVar8;
  int *piVar9;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  int *piStack_9c;
  undefined auStack_98 [4];
  int *piStack_94;
  uint uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  int *piStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  int *piStack_68;
  uint uStack_64;
  uint *puStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  int iStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  uint uStack_44;
  int *piStack_40;
  int *piStack_3c;
  uint uStack_38;
  int iStack_34;
  uint uStack_30;
  uint uStack_2c;
  int *piStack_28;
  code *pcStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d92f9;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  piStack_94 = (int *)FUN_008f7870(param_1);
  if (param_1[0x3c] != 0) {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar2 = FUN_009f9770(param_2,param_3,param_9,2);
    goto LAB_009f90b7;
  }
  uStack_50 = 0;
  puStack_4c = (undefined4 *)0x0;
  puStack_48 = (undefined4 *)0x0;
  uStack_5c = 0;
  iStack_58 = 0;
  iStack_54 = 0;
  uStack_44 = 0;
  uStack_8 = 4;
  iVar2 = param_2[1] - *param_2 >> 0x1f;
  if ((param_2[1] - *param_2) / 0xd0 + iVar2 != iVar2) {
    iStack_34 = 0;
    do {
      iVar2 = *(int *)(*param_2 + iStack_34);
      piStack_14 = (int *)(*param_2 + iStack_34);
      iVar3 = FUN_0088cb40();
      if (iVar2 != iVar3) goto LAB_009f9144;
      uStack_80 = 0;
      piStack_7c = (int *)0x0;
      puVar8 = (uint *)(-(uint)(piStack_14[1] != 0) & (uint)(piStack_14 + 2));
      uStack_30 = puVar8[4];
      if (0xf < puVar8[5]) {
        puVar8 = (uint *)*puVar8;
      }
      if (uStack_30 < 0x10) {
        uStack_90 = *puVar8;
        uStack_8c = puVar8[1];
        uStack_88 = puVar8[2];
        uStack_84 = puVar8[3];
        piStack_7c = (int *)&DAT_0000000f;
      }
      else {
        piStack_14 = (int *)(uStack_30 | 0xf);
        if ((int *)0x7fffffff < piStack_14) {
          piStack_14 = (int *)0x7fffffff;
        }
        piVar6 = (int *)((int)piStack_14 + 1);
        if (piVar6 < &DAT_00001000) {
          if (piVar6 == (int *)0x0) {
            uStack_90 = 0;
          }
          else {
            uStack_90 = FUN_01674e20(piVar6);
          }
        }
        else {
          piVar9 = piStack_14 + 9;
          if (piVar9 <= piVar6) {
            piVar9 = (int *)0xffffffff;
          }
          iVar2 = FUN_01674e20(piVar9);
          if (iVar2 == 0) goto LAB_009f913a;
          uStack_90 = iVar2 + 0x23U & 0xffffffe0;
          *(int *)(uStack_90 - 4) = iVar2;
        }
        FUN_0170c6f0(uStack_90,puVar8,uStack_30 + 1);
        piStack_7c = piStack_14;
      }
      uStack_8 = 5;
      uStack_80 = uStack_30;
      FUN_008fbc70(&piStack_1c,&uStack_90);
      uStack_8 = 6;
      if (piStack_1c == (int *)0x0) {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        FUN_009f9770(param_2,param_3,param_9,1);
LAB_009f8b45:
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_18[1] + -1;
          piStack_18[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            iVar2 = piStack_18[2] + -1;
            piStack_18[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_18 + 4))();
            }
          }
        }
        if (&DAT_0000000f < piStack_7c) {
          piVar6 = (int *)((int)piStack_7c + 1);
          uVar7 = uStack_90;
          if ((int *)0xfff < piVar6) {
            uVar7 = *(uint *)(uStack_90 - 4);
            piVar6 = piStack_7c + 9;
            if (0x1f < (uStack_90 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,piVar6);
        }
        uStack_80 = 0;
        piStack_7c = (int *)&DAT_0000000f;
        uStack_90 = uStack_90 & 0xffffff00;
        goto LAB_009f90a7;
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      piStack_40 = piStack_1c;
      piStack_3c = piStack_18;
      uStack_8 = 7;
      if (puStack_48 == puStack_4c) {
        FUN_00603a30(puStack_4c,&piStack_40);
        piVar6 = piStack_3c;
      }
      else {
        *puStack_4c = 0;
        *puStack_4c = piStack_1c;
        puStack_4c[1] = piStack_18;
        puStack_4c = puStack_4c + 2;
        piStack_40 = (int *)0x0;
        piVar6 = (int *)0x0;
      }
      uStack_8 = 6;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar2 = piVar6[2] + -1;
          piVar6[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piStack_14 = (int *)(*param_6 + iStack_34);
      iVar2 = *piStack_14;
      iVar3 = FUN_0088cb40();
      if (iVar2 != iVar3) {
LAB_009f9144:
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar6 = piStack_14 + 2;
      if (piStack_14[1] == 0) {
        piVar6 = (int *)0x0;
      }
      if (iStack_54 == iStack_58) {
        FUN_00559960(iStack_58,piVar6);
      }
      else {
        FUN_0054ef60(piVar6);
        iStack_58 = iStack_58 + 0x18;
      }
      piStack_14 = (int *)(*param_4 + iStack_34);
      iVar2 = *piStack_14;
      iVar3 = FUN_0088cb40();
      if (iVar2 != iVar3) goto LAB_009f9144;
      puVar8 = (uint *)(piStack_14 + 2);
      if (piStack_14[1] == 0) {
        puVar8 = (uint *)0x0;
      }
      uStack_2c = puVar8[4];
      if (0xf < puVar8[5]) {
        puVar8 = (uint *)*puVar8;
      }
      if (uStack_2c < 0x10) {
        uStack_b0 = *puVar8;
        uStack_ac = puVar8[1];
        uStack_a8 = puVar8[2];
        uStack_a4 = puVar8[3];
        piVar6 = (int *)&DAT_0000000f;
        uStack_30 = uStack_b0;
      }
      else {
        piStack_14 = (int *)(uStack_2c | 0xf);
        if ((int *)0x7fffffff < piStack_14) {
          piStack_14 = (int *)0x7fffffff;
        }
        uStack_b0 = FUN_00554060((undefined *)((int)piStack_14 + 1));
        uStack_30 = uStack_b0;
        FUN_0170c6f0(uStack_b0,puVar8,uStack_2c + 1);
        piVar6 = piStack_14;
      }
      _uStack_8 = CONCAT31(uStack_7,8);
      uStack_a0 = uStack_2c;
      piStack_9c = piVar6;
      puStack_60 = (uint *)(**(code **)(*piStack_1c + 0xac))();
      piStack_14 = (int *)puStack_60[4];
      if (0xf < puStack_60[5]) {
        puStack_60 = (uint *)*puStack_60;
      }
      if (&DAT_0000000f < piStack_14) {
        uStack_38 = (uint)piStack_14 | 0xf;
        if (0x7fffffff < uStack_38) {
          uStack_38 = 0x7fffffff;
        }
        uStack_78 = FUN_00554060(uStack_38 + 1);
        uStack_2c = uStack_78;
        FUN_0170c6f0(uStack_78,puStack_60,(undefined *)((int)piStack_14 + 1));
      }
      else {
        uStack_78 = *puStack_60;
        uStack_74 = puStack_60[1];
        uStack_70 = puStack_60[2];
        uStack_6c = puStack_60[3];
        uStack_38 = 0xf;
        uStack_2c = uStack_78;
      }
      uStack_8 = 9;
      piStack_68 = piStack_14;
      uStack_64 = uStack_38;
      cVar1 = FUN_00558b30(&uStack_78,&uStack_b0);
      if (cVar1 == '\0') {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        FUN_009f9770(param_2,param_3,param_9,1);
        if (0xf < uStack_38) {
          uVar7 = uStack_38 + 1;
          uVar5 = uStack_2c;
          if (0xfff < uVar7) {
            uVar5 = *(uint *)(uStack_2c - 4);
            uVar7 = uStack_38 + 0x24;
            if (0x1f < (uStack_2c - uVar5) - 4) goto LAB_009f913a;
          }
          FUN_01674ea0(uVar5,uVar7);
        }
        if (&DAT_0000000f < piVar6) {
          piVar9 = (int *)((int)piVar6 + 1);
          uVar7 = uStack_30;
          if ((int *)0xfff < piVar9) {
            uVar7 = *(uint *)(uStack_30 - 4);
            piVar9 = piVar6 + 9;
            if (0x1f < (uStack_30 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,piVar9);
        }
        goto LAB_009f8b45;
      }
      uStack_8 = 8;
      if (0xf < uStack_38) {
        uVar7 = uStack_38 + 1;
        uVar5 = uStack_2c;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uStack_2c - 4);
          uVar7 = uStack_38 + 0x24;
          if (0x1f < (uStack_2c - uVar5) - 4) goto LAB_009f913a;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      uStack_8 = 6;
      if (&DAT_0000000f < piVar6) {
        piVar9 = (int *)((int)piVar6 + 1);
        uVar7 = uStack_30;
        if ((int *)0xfff < piVar9) {
          uVar7 = *(uint *)(uStack_30 - 4);
          piVar9 = piVar6 + 9;
          if (0x1f < (uStack_30 - uVar7) - 4) goto LAB_009f913a;
        }
        FUN_01674ea0(uVar7,piVar9);
      }
      piVar6 = piStack_18;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_18[1] + -1;
        piStack_18[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar9 = piVar6 + 2;
          iVar2 = *piVar9 + -1;
          *piVar9 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uStack_8 = 4;
      if (&DAT_0000000f < piStack_7c) {
        piVar6 = (int *)((int)piStack_7c + 1);
        uVar7 = uStack_90;
        if ((int *)0xfff < piVar6) {
          uVar7 = *(uint *)(uStack_90 - 4);
          piVar6 = piStack_7c + 9;
          if (0x1f < (uStack_90 - uVar7) - 4) {
LAB_009f913a:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,piVar6);
      }
      uStack_44 = uStack_44 + 1;
      iStack_34 = iStack_34 + 0xd0;
    } while (uStack_44 < (uint)((param_2[1] - *param_2) / 0xd0));
  }
  piVar6 = piStack_28;
  FUN_0097c020(&piStack_40,param_9,piStack_28);
  uStack_8 = 10;
  if (piStack_40 == (int *)0x0) {
    if ((((DAT_01ee5c38 != 0) && (iVar2 = FUN_008f7870(piVar6), iVar2 != 0)) && (iVar2 != -0xc)) &&
       (param_8 = FUN_005cf750(), param_8 != 0)) {
      piStack_68 = (int *)0x0;
      uStack_64 = 0xf;
      uStack_78 = uStack_78 & 0xffffff00;
      FUN_005542c0("commit failed with internal error: cannot initiate commit",0x39);
      uStack_8 = 0x11;
      FUN_0098c2c0(1,&uStack_78);
      uStack_8 = 10;
      FUN_005507b0();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_009f9770(param_2,param_3,param_9,0);
  }
  else {
    FUN_009fae00(&uStack_78,param_8,&uStack_50);
    uStack_8 = 0xb;
    uVar4 = FUN_005c4330(auStack_98,piStack_94);
    _uStack_8 = CONCAT31(uStack_7,0xc);
    piVar9 = (int *)FUN_009f0080(&piStack_1c,uVar4,&piStack_40,&uStack_50,&uStack_5c,&uStack_78);
    iVar2 = *piVar9;
    iVar3 = piVar9[1];
    *piVar9 = 0;
    piVar9[1] = 0;
    piVar6[0x3c] = iVar2;
    piVar6 = (int *)piVar6[0x3d];
    piStack_28[0x3d] = iVar3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piVar6 = piStack_94;
    uStack_8 = 0xb;
    if (piStack_94 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_94[1] + -1;
      piStack_94[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_94)();
        LOCK();
        piVar9 = piVar6 + 2;
        iVar2 = *piVar9 + -1;
        *piVar9 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piVar6 = piStack_28;
    pcStack_24 = FUN_009f6340;
    uStack_20 = 0;
    piStack_1c = piStack_28;
    if (DAT_01d65a50 == '\0') {
      param_9 = FUN_00915d30(&param_8,&pcStack_24);
      _uStack_8 = CONCAT31(uStack_7,0xd);
      cVar1 = FUN_01679300(param_9);
      if (cVar1 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_9);
      }
      uStack_8 = 0xb;
      if (param_8 != 0) {
        piVar9 = (int *)(param_8 + 4);
        LOCK();
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_8);
        }
      }
      pcStack_24 = FUN_009f61b0;
      uStack_20 = 0;
      piStack_1c = piVar6;
      param_9 = FUN_00915d30(&param_8,&pcStack_24);
      _uStack_8 = CONCAT31(uStack_7,0xe);
      cVar1 = FUN_01679300(param_9);
      if (cVar1 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_9);
      }
      uStack_8 = 0xb;
      if (param_8 != 0) {
        piVar9 = (int *)(param_8 + 4);
        LOCK();
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_8);
        }
      }
      pcStack_24 = FUN_009f6070;
      uStack_20 = 0;
      piStack_1c = piVar6;
      param_9 = FUN_00836450(&param_8,&pcStack_24);
      _uStack_8 = CONCAT31(uStack_7,0xf);
      cVar1 = FUN_01679300(param_9);
      if (cVar1 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_9);
      }
      uStack_8 = 0xb;
      if (param_8 != 0) {
        piVar9 = (int *)(param_8 + 4);
        LOCK();
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_8);
        }
      }
      pcStack_24 = FUN_009f2470;
      uStack_20 = 0;
      piStack_1c = piVar6;
      param_9 = FUN_00915d30(&param_8,&pcStack_24);
      _uStack_8 = CONCAT31(uStack_7,0x10);
      cVar1 = FUN_01679300(param_9);
      if (cVar1 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_9);
      }
      uStack_8 = 0xb;
      if (param_8 != 0) {
        piVar6 = (int *)(param_8 + 4);
        LOCK();
        iVar2 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        iVar3 = param_8;
        goto joined_r0x009f8fc2;
      }
    }
    else {
      FUN_00915d30(&param_9,&pcStack_24);
      if (param_9 != 0) {
        piVar9 = (int *)(param_9 + 4);
        LOCK();
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_9);
        }
      }
      pcStack_24 = FUN_009f61b0;
      uStack_20 = 0;
      piStack_1c = piVar6;
      FUN_00915d30(&param_9,&pcStack_24);
      if (param_9 != 0) {
        piVar9 = (int *)(param_9 + 4);
        LOCK();
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_9);
        }
      }
      pcStack_24 = FUN_009f6070;
      uStack_20 = 0;
      piStack_1c = piVar6;
      FUN_00836450(&param_9,&pcStack_24);
      if (param_9 != 0) {
        piVar9 = (int *)(param_9 + 4);
        LOCK();
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_9);
        }
      }
      pcStack_24 = FUN_009f61f0;
      uStack_20 = 0;
      piStack_1c = piVar6;
      FUN_009efbb0(&param_9,&pcStack_24);
      if (param_9 != 0) {
        piVar6 = (int *)(param_9 + 4);
        LOCK();
        iVar2 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        iVar3 = param_9;
joined_r0x009f8fc2:
        if (iVar2 == 1) {
          FUN_01674ea0(iVar3);
        }
      }
    }
    FUN_00a0b400();
    FUN_005507b0();
  }
  piVar6 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar9 = piVar6 + 2;
      iVar2 = *piVar9 + -1;
      *piVar9 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
LAB_009f90a7:
  thunk_FUN_00577a40();
  iVar2 = thunk_FUN_00577ac0();
LAB_009f90b7:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar6 = param_3 + 1;
    iVar3 = *piVar6;
    iVar2 = *piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar3 = *piVar6;
      iVar2 = *piVar6;
      *piVar6 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar6 = param_5 + 1;
    iVar3 = *piVar6;
    iVar2 = *piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar6 = param_5 + 2;
      iVar3 = *piVar6;
      iVar2 = *piVar6;
      *piVar6 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar2 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar6 = param_7 + 1;
    iVar3 = *piVar6;
    iVar2 = *piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*param_7)();
      LOCK();
      piVar6 = param_7 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 19634 ; VA 0x009f9160 ; FUN_009f9160 */

uint __thiscall FUN_009f9160(int *param_1,uint *param_2,undefined *param_3,uint *param_4)

{
  uint *puVar1;
  uint *puVar2;
  uint uVar3;
  code *pcVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  uint uStack_238;
  uint uStack_234;
  uint uStack_230;
  uint uStack_22c;
  undefined8 uStack_228;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined *puStack_168;
  uint *puStack_164;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint uStack_94;
  undefined *puStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined *puStack_70;
  uint *puStack_6c;
  undefined *puStack_68;
  uint *puStack_64;
  undefined auStack_60 [4];
  undefined *puStack_5c;
  int *piStack_58;
  undefined *puStack_54;
  undefined *puStack_50;
  undefined auStack_4c [4];
  uint *puStack_48;
  undefined *puStack_44;
  uint *puStack_40;
  int iStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d93bb;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_009f1870();
  FUN_00676530();
  iStack_3c = FUN_009f15c0();
  iStack_3c = iStack_3c + 0x18;
  FUN_00927d30();
  if (DAT_01d656d8 == '\0') {
    if (*(int *)(iStack_3c + 8) == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = *(undefined4 **)(*(int *)(iStack_3c + 0x14) + *(int *)(iStack_3c + 4) * 4);
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      puStack_6c = (uint *)puVar8[3];
      if (puStack_6c != (uint *)0x0) {
        LOCK();
        puStack_6c[1] = puStack_6c[1] + 1;
        UNLOCK();
        puStack_6c = (uint *)puVar8[3];
      }
      puStack_70 = (undefined *)puVar8[2];
      iStack_8._0_1_ = 2;
      puStack_50 = puStack_70;
      puStack_20 = puStack_6c;
      FUN_00927d30();
      puStack_90 = auStack_60;
      uStack_8c = 0;
      if (param_4 != (uint *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      puStack_1c = param_4;
      puStack_54 = param_3;
      puStack_68 = param_3;
      puStack_64 = param_4;
      uStack_18 = param_2[4];
      iStack_8._0_1_ = 3;
      uStack_28 = 0;
      uStack_24 = 0;
      puStack_48 = param_2;
      if (0xf < param_2[5]) {
        puStack_48 = (uint *)*param_2;
      }
      if (uStack_18 < 0x10) {
        uStack_38 = *puStack_48;
        uStack_34 = puStack_48[1];
        uStack_30 = puStack_48[2];
        uStack_2c = puStack_48[3];
        uStack_24 = 0xf;
      }
      else {
        uVar7 = uStack_18 | 0xf;
        if (0x7fffffff < uVar7) {
          uVar7 = 0x7fffffff;
        }
        if (uVar7 + 1 < 0x1000) {
          if (uVar7 == 0xffffffff) {
            uStack_38 = 0;
          }
          else {
            uStack_38 = FUN_01674e20();
          }
        }
        else {
          iVar6 = FUN_01674e20();
          if (iVar6 == 0) goto LAB_009f975e;
          uStack_38 = iVar6 + 0x23U & 0xffffffe0;
          *(int *)(uStack_38 - 4) = iVar6;
        }
        FUN_0170c6f0();
        uStack_24 = uVar7;
      }
      iStack_8._0_1_ = 5;
      pcVar4 = *(code **)(*piStack_14 + 8);
      uStack_a0 = uStack_38;
      uStack_9c = uStack_34;
      uStack_98 = uStack_30;
      uStack_94 = uStack_2c;
      uStack_28 = uStack_18;
      uStack_240 = FUN_0088cb40();
      uStack_23c = 0;
      uStack_238 = uStack_a0;
      uStack_234 = uStack_9c;
      uStack_230 = uStack_98;
      uStack_22c = uStack_94;
      uStack_38 = uStack_38 & 0xffffff00;
      uStack_228 = CONCAT44(uStack_24,uStack_28);
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_23c = FUN_005c9d30();
      iStack_8._0_1_ = 6;
      uStack_170 = FUN_0088cdc0();
      puStack_168 = puStack_54;
      uStack_16c = 0;
      puStack_164 = puStack_1c;
      puStack_68 = (undefined *)0x0;
      puStack_64 = (uint *)0x0;
      uStack_16c = FUN_006309e0();
      iStack_8._0_1_ = 7;
      uStack_7c = 0;
      uStack_78 = 0;
      uStack_74 = 0;
      FUN_00687980();
      iStack_8._0_1_ = 8;
      (*pcVar4)();
      iStack_8._0_1_ = 9;
      FUN_00577b20();
      iStack_8._0_1_ = 5;
      FUN_016f32d1(&uStack_240);
      puStack_5c = auStack_4c;
      piStack_58 = (int *)0x0;
      if (puStack_20 != (uint *)0x0) {
        LOCK();
        puStack_20[1] = puStack_20[1] + 1;
        UNLOCK();
      }
      puStack_44 = puStack_50;
      puStack_40 = puStack_20;
      iStack_8._0_1_ = 10;
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_18 = param_2[4];
      puStack_1c = param_2;
      if (0xf < param_2[5]) {
        puStack_1c = (uint *)*param_2;
      }
      if (uStack_18 < 0x10) {
        uStack_38 = *puStack_1c;
        uStack_34 = puStack_1c[1];
        uStack_30 = puStack_1c[2];
        uStack_2c = puStack_1c[3];
        uStack_24 = 0xf;
      }
      else {
        uVar7 = uStack_18 | 0xf;
        if (0x7fffffff < uVar7) {
          uVar7 = 0x7fffffff;
        }
        if (uVar7 + 1 < 0x1000) {
          if (uVar7 == 0xffffffff) {
            uStack_38 = 0;
          }
          else {
            uStack_38 = FUN_01674e20();
          }
        }
        else {
          iVar6 = FUN_01674e20();
          if (iVar6 == 0) {
LAB_009f975e:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          uStack_38 = iVar6 + 0x23U & 0xffffffe0;
          *(int *)(uStack_38 - 4) = iVar6;
        }
        FUN_0170c6f0();
        uStack_24 = uVar7;
      }
      iStack_8._0_1_ = 0xc;
      pcVar4 = *(code **)(*piStack_14 + 8);
      uStack_a0 = uStack_38;
      uStack_9c = uStack_34;
      uStack_98 = uStack_30;
      uStack_94 = uStack_2c;
      uStack_28 = uStack_18;
      uStack_240 = FUN_0088cb40();
      uStack_23c = 0;
      uStack_238 = uStack_a0;
      uStack_234 = uStack_9c;
      uStack_230 = uStack_98;
      uStack_22c = uStack_94;
      uStack_38 = uStack_38 & 0xffffff00;
      uStack_228 = CONCAT44(uStack_24,uStack_28);
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_23c = FUN_005c9d30();
      iStack_8._0_1_ = 0xd;
      uStack_170 = FUN_0088cdc0();
      puStack_168 = puStack_50;
      uStack_16c = 0;
      puStack_164 = puStack_20;
      puStack_44 = (undefined *)0x0;
      puStack_40 = (uint *)0x0;
      uStack_16c = FUN_006309e0();
      iStack_8._0_1_ = 0xe;
      uStack_88 = 0;
      uStack_84 = 0;
      uStack_80 = 0;
      FUN_00687980();
      iStack_8._0_1_ = 0xf;
      (*pcVar4)();
      iStack_8._0_1_ = 0x10;
      FUN_00577b20();
      iStack_8._0_1_ = 0xc;
      FUN_016f32d1(&uStack_240);
      puVar2 = puStack_20;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (puStack_20 != (uint *)0x0) {
        LOCK();
        uVar7 = puStack_20[1] - 1;
        puStack_20[1] = uVar7;
        UNLOCK();
        if (uVar7 == 0) {
          (**(code **)*puStack_20)();
          LOCK();
          puVar1 = puVar2 + 2;
          uVar7 = *puVar1 - 1;
          *puVar1 = uVar7;
          UNLOCK();
          if (uVar7 == 0) {
            (**(code **)(*puVar2 + 4))();
          }
        }
      }
    }
  }
  else {
    puStack_44 = auStack_4c;
    puStack_40 = (uint *)0x1;
    if (param_4 != (uint *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iStack_8._0_1_ = 1;
    FUN_0054ef60(param_2);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_009fa150(param_1);
  }
  FUN_009efcd0();
  FUN_008f7870();
  uVar7 = FUN_008fbc70();
  iStack_8 = CONCAT31(iStack_8._1_3_,0x11);
  if (puStack_5c != (undefined *)0x0) {
    uVar7 = FUN_00ae65e0();
  }
  piVar5 = piStack_58;
  if (piStack_58 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_58 + 1);
    uVar3 = *puVar2;
    uVar7 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      puVar2 = (uint *)(piVar5 + 2);
      uVar3 = *puVar2;
      uVar7 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar7 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_4 != (uint *)0x0) {
    LOCK();
    puVar2 = param_4 + 1;
    uVar3 = *puVar2;
    uVar7 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar7 = (**(code **)*param_4)();
      LOCK();
      puVar2 = param_4 + 2;
      uVar3 = *puVar2;
      *puVar2 = *puVar2 - 1;
      UNLOCK();
      if (uVar3 == 1) {
        uVar7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 19635 ; VA 0x009f9770 ; FUN_009f9770 */

uint __thiscall FUN_009f9770(int *param_1,int *param_2,int *param_3,undefined4 param_4,uint param_5)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  code *pcVar4;
  int iVar5;
  uint ***pppuVar6;
  uint uVar7;
  int iVar8;
  uint ***pppuVar9;
  uint uVar10;
  uint **ppuVar11;
  uint ****ppppuVar12;
  uint ****ppppuVar13;
  int iVar14;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  uint **ppuStack_218;
  uint **ppuStack_214;
  uint **ppuStack_210;
  uint **ppuStack_20c;
  undefined8 uStack_208;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  uint uStack_148;
  uint **ppuStack_80;
  uint **ppuStack_7c;
  uint **ppuStack_78;
  uint **ppuStack_74;
  uint ***pppuStack_70;
  uint **ppuStack_6c;
  uint **ppuStack_68;
  uint **ppuStack_64;
  uint **ppuStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint **ppuStack_4c;
  uint **ppuStack_48;
  uint **ppuStack_44;
  uint **ppuStack_40;
  uint **ppuStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9435;
  pvStack_10 = ExceptionList;
  uStack_28 = param_4;
  uStack_8 = 0;
  uStack_24 = 0;
  pcVar4 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  uStack_150 = FUN_0088c8c0();
  uStack_14c = 0;
  uStack_148 = param_5;
  uStack_14c = FUN_005c9cc0();
  uStack_8._0_1_ = 1;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  FUN_00687980(&uStack_150,&ppuStack_80,param_4);
  uStack_8._0_1_ = 2;
  (*pcVar4)(&DAT_021254f0,&uStack_34,&uStack_28);
  uStack_8._0_1_ = 3;
  FUN_00577b20();
  uStack_8._0_1_ = 0;
  uVar7 = FUN_016f32d1(&uStack_150,0xd0,1,FUN_0056e5b0);
  if (param_2 != (int *)0x0) {
    uStack_24 = 0;
    uVar7 = (param_2[1] - *param_2) / 0xd0;
    if (uVar7 != 0) {
      iStack_18 = 0;
      do {
        iVar5 = *(int *)(*param_2 + iStack_18);
        iVar14 = *param_2 + iStack_18;
        iVar8 = FUN_0088cb40();
        if (iVar5 != iVar8) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        ppuStack_60 = (uint **)0x0;
        pppuStack_14 = (uint ***)(iVar14 + 8);
        uStack_5c = 0;
        if (*(int *)(iVar14 + 4) == 0) {
          pppuStack_14 = (uint ***)0x0;
        }
        pppuVar6 = ((uint ****)pppuStack_14)[4];
        if ((uint ***)0xf < ((uint ****)pppuStack_14)[5]) {
          pppuStack_14 = (uint ***)*pppuStack_14;
        }
        if (pppuVar6 < (uint ***)0x10) {
          ppppuVar12 = (uint ****)*pppuStack_14;
          uVar7 = 0xf;
          uStack_20 = 0xf;
          pppuStack_70 = (uint ***)ppppuVar12;
          ppuStack_6c = (uint **)((uint ****)pppuStack_14)[1];
          ppuStack_68 = (uint **)((uint ****)pppuStack_14)[2];
          ppuStack_64 = (uint **)((uint ****)pppuStack_14)[3];
        }
        else {
          uVar7 = (uint)pppuVar6 | 0xf;
          if (0x7fffffff < uVar7) {
            uVar7 = 0x7fffffff;
          }
          uVar3 = uVar7 + 1;
          uStack_20 = uVar7;
          if (uVar3 < 0x1000) {
            if (uVar3 == 0) {
              ppppuVar12 = (uint ****)0x0;
            }
            else {
              ppppuVar12 = (uint ****)FUN_01674e20(uVar3);
            }
          }
          else {
            uVar10 = uVar7 + 0x24;
            if (uVar10 <= uVar3) {
              uVar10 = 0xffffffff;
            }
            pppuVar9 = (uint ***)FUN_01674e20(uVar10);
            if (pppuVar9 == (uint ***)0x0) goto LAB_009f9bb5;
            ppppuVar12 = (uint ****)((int)pppuVar9 + 0x23U & 0xffffffe0);
            ppppuVar12[-1] = pppuVar9;
          }
          pppuStack_70 = (uint ***)ppppuVar12;
          FUN_0170c6f0(ppppuVar12,pppuStack_14,(int)pppuVar6 + 1);
        }
        uStack_5c = uVar7;
        ppuStack_60 = (uint **)pppuVar6;
        uStack_30 = param_4;
        pppuStack_14 = (uint ***)&pppuStack_70;
        if (0xf < uVar7) {
          pppuStack_14 = (uint ***)ppppuVar12;
        }
        uStack_8._0_1_ = 4;
        uStack_2c = 0;
        ppuStack_3c = (uint **)0x0;
        uStack_38 = 0;
        if (pppuVar6 < (uint ***)0x10) {
          ppuStack_4c = *pppuStack_14;
          ppuStack_48 = (uint **)((uint ****)pppuStack_14)[1];
          ppuStack_44 = (uint **)((uint ****)pppuStack_14)[2];
          ppuStack_40 = (uint **)((uint ****)pppuStack_14)[3];
          uStack_38 = 0xf;
        }
        else {
          uVar7 = (uint)pppuVar6 | 0xf;
          if (0x7fffffff < uVar7) {
            uVar7 = 0x7fffffff;
          }
          uVar3 = uVar7 + 1;
          if (uVar3 < 0x1000) {
            if (uVar3 == 0) {
              ppuStack_4c = (uint **)0x0;
            }
            else {
              ppuStack_4c = (uint **)FUN_01674e20(uVar3);
            }
          }
          else {
            uVar10 = uVar7 + 0x24;
            if (uVar10 <= uVar3) {
              uVar10 = 0xffffffff;
            }
            ppuVar11 = (uint **)FUN_01674e20(uVar10);
            if (ppuVar11 == (uint **)0x0) goto LAB_009f9bb5;
            ppuStack_4c = (uint **)((int)ppuVar11 + 0x23U & 0xffffffe0);
            ((uint ***)ppuStack_4c)[-1] = ppuVar11;
          }
          FUN_0170c6f0(ppuStack_4c,pppuStack_14,(int)pppuVar6 + 1);
          uStack_38 = uVar7;
        }
        uStack_8._0_1_ = 5;
        pcVar4 = *(code **)(*piStack_1c + 8);
        ppuStack_80 = ppuStack_4c;
        ppuStack_7c = ppuStack_48;
        ppuStack_78 = ppuStack_44;
        ppuStack_74 = ppuStack_40;
        ppuStack_3c = (uint **)pppuVar6;
        uStack_220 = FUN_0088cb40();
        uStack_21c = 0;
        ppuStack_218 = ppuStack_80;
        ppuStack_214 = ppuStack_7c;
        ppuStack_210 = ppuStack_78;
        ppuStack_20c = ppuStack_74;
        ppuStack_4c = (uint **)((uint)ppuStack_4c & 0xffffff00);
        uStack_208 = CONCAT44(uStack_38,ppuStack_3c);
        ppuStack_3c = (uint **)0x0;
        uStack_38 = 0xf;
        uStack_21c = FUN_005c9d30();
        uStack_8._0_1_ = 6;
        uStack_150 = FUN_0088daf0();
        uStack_14c = 0;
        uStack_148 = uStack_148 & 0xffffff00;
        uStack_14c = FUN_005c9ef0();
        uStack_8._0_1_ = 7;
        uStack_58 = 0;
        uStack_54 = 0;
        uStack_50 = 0;
        FUN_00687980(&uStack_220,&ppuStack_80,param_4);
        uStack_8._0_1_ = 8;
        (*pcVar4)(&DAT_021254b0,&uStack_58,&uStack_30);
        uStack_8._0_1_ = 9;
        FUN_00577b20();
        uStack_8._0_1_ = 5;
        FUN_016f32d1(&uStack_220,0xd0,2,FUN_0056e5b0);
        uStack_8._0_1_ = 0;
        if (0xf < uStack_20) {
          uVar7 = uStack_20 + 1;
          ppppuVar13 = ppppuVar12;
          if (0xfff < uVar7) {
            ppppuVar13 = (uint ****)ppppuVar12[-1];
            uVar7 = uStack_20 + 0x24;
            if (0x1f < (uint)((int)ppppuVar12 + (-4 - (int)ppppuVar13))) {
LAB_009f9bb5:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar13,uVar7);
        }
        iStack_18 = iStack_18 + 0xd0;
        uStack_24 = uStack_24 + 1;
        uVar7 = (param_2[1] - *param_2) / 0xd0;
      } while (uStack_24 < uVar7);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar7 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 19636 ; VA 0x009f9bc0 ; FUN_009f9bc0 */

/* WARNING: Removing unreachable block (ram,0x009f9d2e) */
/* WARNING: Removing unreachable block (ram,0x009f9cec) */
/* WARNING: Removing unreachable block (ram,0x009f9ca6) */
/* WARNING: Removing unreachable block (ram,0x009f9cb4) */
/* WARNING: Removing unreachable block (ram,0x009f9d66) */
/* WARNING: Removing unreachable block (ram,0x009f9cc8) */
/* WARNING: Removing unreachable block (ram,0x009f9cfa) */
/* WARNING: Removing unreachable block (ram,0x009f9d6b) */
/* WARNING: Removing unreachable block (ram,0x009f9d0a) */
/* WARNING: Removing unreachable block (ram,0x009f9d3c) */
/* WARNING: Removing unreachable block (ram,0x009f9d70) */
/* WARNING: Removing unreachable block (ram,0x009f9d4c) */

void FUN_009f9bc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19)

{
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8888;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_009f9d80(param_1,param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,
               param_10,param_11,CONCAT44(param_13,param_12),param_14,param_15,param_16,param_17,
               CONCAT44(param_19,param_18),&uStack_1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19637 ; VA 0x009f9d80 ; FUN_009f9d80 */

/* WARNING: Removing unreachable block (ram,0x009f9f93) */
/* WARNING: Removing unreachable block (ram,0x009f9f51) */
/* WARNING: Removing unreachable block (ram,0x009f9f0b) */
/* WARNING: Removing unreachable block (ram,0x009f9f19) */
/* WARNING: Removing unreachable block (ram,0x009f9fcb) */
/* WARNING: Removing unreachable block (ram,0x009f9f2d) */
/* WARNING: Removing unreachable block (ram,0x009f9f5f) */
/* WARNING: Removing unreachable block (ram,0x009f9fd0) */
/* WARNING: Removing unreachable block (ram,0x009f9f6f) */
/* WARNING: Removing unreachable block (ram,0x009f9fa1) */
/* WARNING: Removing unreachable block (ram,0x009f9fd5) */
/* WARNING: Removing unreachable block (ram,0x009f9fb1) */

void FUN_009f9d80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20)

{
  code *pcVar1;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 uStack_278;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d948f;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_284 = param_3;
  uStack_280 = param_4;
  uStack_27c = param_5;
  uStack_278 = CONCAT44(param_7,param_6);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  uStack_1b8 = param_8;
  uStack_1b4 = param_9;
  uStack_1b0 = param_10;
  uStack_1ac = param_11;
  uStack_1a8 = CONCAT44(param_13,param_12);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_14;
  uStack_e4 = param_15;
  uStack_e0 = param_16;
  uStack_dc = param_17;
  uStack_d8 = CONCAT44(param_19,param_18);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 6;
  (*pcVar1)(uStack_14,&uStack_20,param_20);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19638 ; VA 0x009f9fe0 ; FUN_009f9fe0 */

/* WARNING: Removing unreachable block (ram,0x009fa10d) */
/* WARNING: Removing unreachable block (ram,0x009fa11b) */
/* WARNING: Removing unreachable block (ram,0x009fa147) */
/* WARNING: Removing unreachable block (ram,0x009fa12b) */

void FUN_009f9fe0(int *param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7)

{
  code *pcVar1;
  undefined4 uStack_128;
  undefined4 uStack_124;
  uint uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined8 uStack_110;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d94d1;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_58 = param_2;
  uStack_54 = param_3;
  uStack_50 = param_4;
  uStack_4c = param_5;
  uStack_24 = 0;
  uStack_48 = param_2;
  uStack_44 = param_3;
  uStack_40 = param_4;
  uStack_3c = param_5;
  uStack_38 = CONCAT44(param_7,param_6);
  uStack_8 = 1;
  uStack_7 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_30 = uStack_38;
  uStack_128 = FUN_0088cb40();
  uStack_124 = 0;
  uStack_120 = uStack_58;
  uStack_11c = uStack_54;
  uStack_118 = uStack_50;
  uStack_114 = uStack_4c;
  uStack_110 = uStack_30;
  uStack_38 = 0xf00000000;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_124 = FUN_005c9d30();
  uStack_8 = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_128,&uStack_58,param_1);
  uStack_8 = 3;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_28);
  uStack_8 = 4;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_016f32d1(&uStack_128,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19639 ; VA 0x009fa150 ; FUN_009fa150 */

/* WARNING: Removing unreachable block (ram,0x009fa28f) */
/* WARNING: Removing unreachable block (ram,0x009fa2f5) */
/* WARNING: Removing unreachable block (ram,0x009fa281) */
/* WARNING: Removing unreachable block (ram,0x009fa29f) */
/* WARNING: Removing unreachable block (ram,0x009fa2c2) */
/* WARNING: Removing unreachable block (ram,0x009fa2ce) */
/* WARNING: Removing unreachable block (ram,0x009fa2dc) */

undefined4
FUN_009fa150(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d951c;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1b4 = param_3;
  uStack_1b0 = param_4;
  uStack_1ac = param_5;
  uStack_1a8 = CONCAT44(param_7,param_6);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088cdc0();
  uStack_e8 = param_8;
  uStack_ec = 0;
  uStack_e4 = param_9;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,param_1);
  uStack_8._0_1_ = 4;
  (*pcVar1)(uStack_14,&uStack_20,param_10);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 19640 ; VA 0x009fa300 ; FUN_009fa300 */

/* WARNING: Removing unreachable block (ram,0x009fa41c) */
/* WARNING: Removing unreachable block (ram,0x009fa42a) */
/* WARNING: Removing unreachable block (ram,0x009fa454) */
/* WARNING: Removing unreachable block (ram,0x009fa43a) */

void FUN_009fa300(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9)

{
  code *pcVar1;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d9564;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1b4 = param_3;
  uStack_1b0 = param_4;
  uStack_1ac = param_5;
  uStack_1a8 = CONCAT44(param_7,param_6);
  uStack_1bc = FUN_005c9d30();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = (undefined)param_8;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,param_8);
  iStack_8._0_1_ = 3;
  (*pcVar1)(uStack_14,&uStack_20,param_9);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19641 ; VA 0x009fa460 ; FUN_009fa460 */

/* WARNING: Removing unreachable block (ram,0x009fa5d5) */
/* WARNING: Removing unreachable block (ram,0x009fa589) */
/* WARNING: Removing unreachable block (ram,0x009fa592) */
/* WARNING: Removing unreachable block (ram,0x009fa5a1) */
/* WARNING: Removing unreachable block (ram,0x009fa563) */
/* WARNING: Removing unreachable block (ram,0x009fa56c) */
/* WARNING: Removing unreachable block (ram,0x009fa57b) */
/* WARNING: Removing unreachable block (ram,0x009fa5af) */
/* WARNING: Removing unreachable block (ram,0x009fa5b8) */
/* WARNING: Removing unreachable block (ram,0x009fa5c6) */
/* WARNING: Removing unreachable block (ram,0x009fa5e3) */
/* WARNING: Removing unreachable block (ram,0x009fa60f) */
/* WARNING: Removing unreachable block (ram,0x009fa5f3) */

undefined4
FUN_009fa460(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8e40;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fa620(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                       param_10,param_11,CONCAT44(param_13,param_12),&uStack_1c);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19642 ; VA 0x009fa620 ; FUN_009fa620 */

/* WARNING: Removing unreachable block (ram,0x009fa84f) */
/* WARNING: Removing unreachable block (ram,0x009fa801) */
/* WARNING: Removing unreachable block (ram,0x009fa80a) */
/* WARNING: Removing unreachable block (ram,0x009fa819) */
/* WARNING: Removing unreachable block (ram,0x009fa7db) */
/* WARNING: Removing unreachable block (ram,0x009fa7e4) */
/* WARNING: Removing unreachable block (ram,0x009fa7f3) */
/* WARNING: Removing unreachable block (ram,0x009fa827) */
/* WARNING: Removing unreachable block (ram,0x009fa830) */
/* WARNING: Removing unreachable block (ram,0x009fa83e) */
/* WARNING: Removing unreachable block (ram,0x009fa85d) */
/* WARNING: Removing unreachable block (ram,0x009fa887) */
/* WARNING: Removing unreachable block (ram,0x009fa86d) */

undefined4
FUN_009fa620(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d95d2;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_360 = FUN_0088cbe0();
  uStack_358 = param_2;
  uStack_35c = 0;
  uStack_354 = param_3;
  uStack_35c = FUN_00630900();
  uStack_8._0_1_ = 4;
  uStack_290 = FUN_0088cbe0();
  uStack_288 = param_4;
  uStack_28c = 0;
  uStack_284 = param_5;
  uStack_28c = FUN_00630900();
  uStack_8._0_1_ = 5;
  uStack_1c0 = FUN_0088cbe0();
  uStack_1b8 = param_6;
  uStack_1bc = 0;
  uStack_1b4 = param_7;
  uStack_1bc = FUN_00630900();
  uStack_8._0_1_ = 6;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_8;
  uStack_e4 = param_9;
  uStack_e0 = param_10;
  uStack_dc = param_11;
  uStack_d8 = CONCAT44(param_13,param_12);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 7;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_360,&uStack_20,param_1);
  uStack_8._0_1_ = 8;
  (*pcVar1)(uStack_14,&uStack_20,param_14);
  uStack_8._0_1_ = 9;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar2 = FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 19643 ; VA 0x009fa890 ; FUN_009fa890 */

/* WARNING: Removing unreachable block (ram,0x009fa9b4) */
/* WARNING: Removing unreachable block (ram,0x009fa968) */
/* WARNING: Removing unreachable block (ram,0x009fa971) */
/* WARNING: Removing unreachable block (ram,0x009fa980) */
/* WARNING: Removing unreachable block (ram,0x009fa98e) */
/* WARNING: Removing unreachable block (ram,0x009fa997) */
/* WARNING: Removing unreachable block (ram,0x009fa9a5) */
/* WARNING: Removing unreachable block (ram,0x009fa9c2) */
/* WARNING: Removing unreachable block (ram,0x009fa9ee) */
/* WARNING: Removing unreachable block (ram,0x009fa9d2) */

undefined4
FUN_009fa890(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8ef8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009faa00(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                       CONCAT44(param_11,param_10),&uStack_1c);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19644 ; VA 0x009faa00 ; FUN_009faa00 */

/* WARNING: Removing unreachable block (ram,0x009fabc5) */
/* WARNING: Removing unreachable block (ram,0x009fab77) */
/* WARNING: Removing unreachable block (ram,0x009fab80) */
/* WARNING: Removing unreachable block (ram,0x009fab8f) */
/* WARNING: Removing unreachable block (ram,0x009fab9d) */
/* WARNING: Removing unreachable block (ram,0x009faba6) */
/* WARNING: Removing unreachable block (ram,0x009fabb4) */
/* WARNING: Removing unreachable block (ram,0x009fabd3) */
/* WARNING: Removing unreachable block (ram,0x009fabfd) */
/* WARNING: Removing unreachable block (ram,0x009fabe3) */

undefined4
FUN_009faa00(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d962f;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088cbe0();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_00630900();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cbe0();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_00630900();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_e4 = param_7;
  uStack_e0 = param_8;
  uStack_dc = param_9;
  uStack_d8 = CONCAT44(param_11,param_10);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 6;
  (*pcVar1)(uStack_14,&uStack_20,param_12);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar2 = FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 19645 ; VA 0x009fac10 ; FUN_009fac10 */

void __fastcall FUN_009fac10(int param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*(int *)(param_1 + -0x58) + 8))(&DAT_021255b0,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19646 ; VA 0x009fac90 ; FUN_009fac90 */

void __thiscall FUN_009fac90(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xec) != param_2) {
    *(char *)(param_1 + 0xec) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19647 ; VA 0x009facc0 ; FUN_009facc0 */

void __thiscall FUN_009facc0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xed) != param_2) {
    *(char *)(param_1 + 0xed) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19648 ; VA 0x009facf0 ; FUN_009facf0 */

void __thiscall FUN_009facf0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xee) != param_2) {
    *(char *)(param_1 + 0xee) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19649 ; VA 0x009fad20 ; FUN_009fad20 */

void __thiscall FUN_009fad20(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_2);
  FUN_009f9fe0(param_1 + -0x58);
  return;
}



/* FUNCTION 19650 ; VA 0x009fad50 ; FUN_009fad50 */

void __thiscall FUN_009fad50(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_2);
  FUN_009f9fe0(param_1 + -0x58);
  return;
}



/* FUNCTION 19651 ; VA 0x009fad80 ; FUN_009fad80 */

void __thiscall FUN_009fad80(int param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9670;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2);
  uStack_8 = 0xffffffff;
  FUN_009f9bc0(param_1 + -0x58);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19652 ; VA 0x009fae00 ; FUN_009fae00 */

undefined * FUN_009fae00(undefined *param_1,undefined4 *param_2,int *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = DAT_01d6568c;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (param_2[4] == 0) {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)
             FUN_01675640(aiStack_28,PTR_s__d_script_s__committed_01d65730,
                          param_3[1] - *param_3 >> 3);
    uStack_8 = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    if ((uint)puVar1[4] < uVar3) {
      uVar3 = puVar1[4];
    }
    if (0xf < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    FUN_005542c0(puVar1,uVar3);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar2 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    if ((uint)param_2[4] < uVar3) {
      uVar3 = param_2[4];
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19653 ; VA 0x009faf20 ; FUN_009faf20 */

int __thiscall FUN_009faf20(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9688;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008f7870(param_1);
  iVar3 = FUN_008fbc70(&iStack_18,param_2);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00ae65e0(*(int *)(param_3 + 8) != 0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19654 ; VA 0x009fafb0 ; FUN_009fafb0 */

int * __thiscall
FUN_009fafb0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009fb580();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Stats::StatsService,int>::
              GetImpl<int_(__thiscall_RBX::Stats::StatsService::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Stats::StatsService,int>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Stats::StatsService,int>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19655 ; VA 0x009fb0b0 ; FUN_009fb0b0 */

int * __thiscall
FUN_009fb0b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009fb580();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Stats::StatsService,float>::
              GetImpl<float_(__thiscall_RBX::Stats::StatsService::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Stats::StatsService,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Stats::StatsService,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19656 ; VA 0x009fb1b0 ; FUN_009fb1b0 */

int * __thiscall FUN_009fb1b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00a01260();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 19657 ; VA 0x009fb200 ; FUN_009fb200 */

undefined * FUN_009fb200(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d96ac;
  pvStack_10 = ExceptionList;
  if (DAT_01ee5ebc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee60c8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee60c8);
      if (DAT_01ee60c8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StatsItem",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01888820);
        FUN_016f37bf(&DAT_01ee60c8);
      }
    }
    DAT_01ee5ebc = &DAT_01ee5ec0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee5ebc;
}



/* FUNCTION 19658 ; VA 0x009fb2e0 ; FUN_009fb2e0 */

undefined * FUN_009fb2e0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d96cc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee62e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee64f8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee64f8);
      if (DAT_01ee64f8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_009fb200();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RunningAverageItemDouble",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01888830);
        FUN_016f37bf(&DAT_01ee64f8);
      }
    }
    DAT_01ee62e8 = &DAT_01ee62f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee62e8;
}



/* FUNCTION 19659 ; VA 0x009fb3c0 ; FUN_009fb3c0 */

undefined * FUN_009fb3c0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d96ec;
  pvStack_10 = ExceptionList;
  if (DAT_01ee60d0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee62e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee62e0);
      if (DAT_01ee62e0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_009fb200();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RunningAverageItemInt",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01888840);
        FUN_016f37bf(&DAT_01ee62e0);
      }
    }
    DAT_01ee60d0 = &DAT_01ee60d8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee60d0;
}



/* FUNCTION 19660 ; VA 0x009fb4a0 ; FUN_009fb4a0 */

undefined * FUN_009fb4a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d970c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee6930 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6b40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee6b40);
      if (DAT_01ee6b40 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_009fb200();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RunningAverageTimeIntervalItem",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01888850);
        FUN_016f37bf(&DAT_01ee6b40);
      }
    }
    DAT_01ee6930 = &DAT_01ee6938;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee6930;
}



/* FUNCTION 19661 ; VA 0x009fb580 ; FUN_009fb580 */

undefined * FUN_009fb580(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d972c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee6500 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6710) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee6710);
      if (DAT_01ee6710 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Stats",1,uStack_20,0,0,0x13,0,0);
        FUN_016f3654(&LAB_01888860);
        FUN_016f37bf(&DAT_01ee6710);
      }
    }
    DAT_01ee6500 = &DAT_01ee6508;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee6500;
}



/* FUNCTION 19662 ; VA 0x009fb660 ; FUN_009fb660 */

undefined * FUN_009fb660(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d974c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee6718 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6928) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee6928);
      if (DAT_01ee6928 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_009fb200();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TotalCountTimeIntervalItem",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01888870);
        FUN_016f37bf(&DAT_01ee6928);
      }
    }
    DAT_01ee6718 = &DAT_01ee6720;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee6718;
}



/* FUNCTION 19663 ; VA 0x009fb740 ; FUN_009fb740 */

void FUN_009fb740(void)

{
  int iVar1;
  
  if (DAT_01ee60cc == 0) {
    iVar1 = FUN_009fb200();
    DAT_01ee60cc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19664 ; VA 0x009fb760 ; FUN_009fb760 */

void FUN_009fb760(void)

{
  int iVar1;
  
  if (DAT_01ee6714 == 0) {
    iVar1 = FUN_009fb580();
    DAT_01ee6714 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19665 ; VA 0x009fb780 ; FUN_009fb780 */

int __thiscall FUN_009fb780(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9768;
  pvStack_10 = ExceptionList;
  uVar7 = *param_1;
  iVar4 = (int)(param_1[1] - uVar7) / 0x48;
  if (iVar4 == 0x38e38e3) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar5 = (int)(param_1[2] - uVar7) / 0x48;
  uVar2 = uVar1;
  if ((uVar5 <= 0x38e38e3 - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < uVar1)) {
    uVar2 = uVar1;
  }
  uVar5 = uVar2 * 0x48;
  if (uVar2 < 0x38e38e4) {
    if (0xfff < uVar5) goto LAB_009fb83c;
    if (uVar5 == 0) {
      uVar5 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_009fb83c:
    uVar3 = uVar5 + 0x23;
    if (uVar3 <= uVar5) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_009fb9bf;
    uVar5 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar4;
  }
  uStack_8 = 0;
  iVar4 = ((int)(param_2 - uVar7) / 0x48) * 0x48;
  FUN_009fe430(param_3);
  uVar7 = param_1[1];
  if (param_2 == uVar7) {
    uVar3 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    for (; uVar3 != uVar7; uVar3 = uVar3 + 0x48) {
      FUN_009fe430(uVar3);
    }
  }
  else {
    FUN_009feab0(*param_1,param_2,uVar5);
    FUN_009feab0(param_2,param_1[1],iVar4 + uVar5 + 0x48);
  }
  uVar7 = *param_1;
  if (uVar7 != 0) {
    uVar3 = param_1[1];
    if (uVar7 != uVar3) {
      do {
        FUN_0096ca80();
        uVar7 = uVar7 + 0x48;
      } while (uVar7 != uVar3);
      uVar7 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar7) / 0x48) * 0x48;
    uVar3 = uVar7;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar7 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar7 - uVar3) - 4) {
LAB_009fb9bf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + uVar1 * 0x48;
  param_1[2] = uVar5 + uVar2 * 0x48;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 19666 ; VA 0x009fb995 ; Catch_All@009fb995 */

void Catch_All_009fb995(void)

{
  int unaff_EBP;
  
  FUN_00970980(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_008f20b0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19667 ; VA 0x009fb9d0 ; FUN_009fb9d0 */

int __thiscall FUN_009fb9d0(uint *param_1,uint param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9780;
  pvStack_10 = ExceptionList;
  uVar7 = *param_1;
  iVar2 = (int)(param_1[1] - uVar7) >> 5;
  if (iVar2 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar5 = (int)(param_1[2] - uVar7) >> 5;
  uVar8 = uVar1;
  if ((uVar5 <= 0x7ffffff - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar5 = uVar8 * 0x20;
  if (uVar8 < 0x8000000) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_009fba5b;
    if (uVar5 == 0) {
      uVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_009fba5b:
    uVar3 = uVar8 + 0x23;
    if (uVar3 <= uVar8) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(uVar3);
    if (iVar2 == 0) goto LAB_009fbb92;
    uVar8 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar2;
  }
  uVar7 = param_2 - uVar7 & 0xffffffe0;
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined4 *)(uVar7 + 0x18 + uVar8) = *(undefined4 *)(param_3 + 0x18);
  *(undefined *)(uVar7 + 0x1c + uVar8) = *(undefined *)(param_3 + 0x1c);
  if (param_2 == param_1[1]) {
    FUN_00775e00(*param_1,param_1[1],uVar8,param_1);
  }
  else {
    FUN_00775e00(*param_1,param_2,uVar8,param_1);
    FUN_00775e00(param_2,param_1[1],uVar7 + uVar8 + 0x20,param_1);
  }
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    uVar3 = *param_1;
    uVar6 = param_1[2] - uVar3 & 0xffffffe0;
    uVar4 = uVar3;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uVar3 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar3 - uVar4) - 4) {
LAB_009fbb92:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar1 * 0x20 + uVar8;
  param_1[2] = uVar5 + uVar8;
  ExceptionList = pvStack_10;
  return *param_1 + uVar7;
}



/* FUNCTION 19668 ; VA 0x009fbb69 ; Catch_All@009fbb69 */

void Catch_All_009fbb69(void)

{
  int unaff_EBP;
  
  FUN_00576230(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19669 ; VA 0x009fbba0 ; FUN_009fbba0 */

void FUN_009fbba0(int param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar1 = param_3 - param_1 >> 5;
  if (iVar1 < 0x29) {
    uVar2 = *(uint *)(param_2 + 0x18);
    if (*(uint *)(param_1 + 0x18) < uVar2) {
      FUN_009fdf30(param_2,param_1);
      uVar2 = *(uint *)(param_2 + 0x18);
    }
    if (uVar2 < *(uint *)(param_3 + 0x18)) {
      FUN_009fdf30(param_3,param_2);
      if (*(uint *)(param_1 + 0x18) < *(uint *)(param_2 + 0x18)) {
        FUN_009fdf30(param_2,param_1);
      }
    }
  }
  else {
    iVar4 = iVar1 + 1 >> 3;
    iVar1 = iVar4 * 0x20 + param_1;
    iVar3 = iVar4 * 0x40 + param_1;
    uVar2 = *(uint *)(iVar1 + 0x18);
    if (*(uint *)(param_1 + 0x18) < uVar2) {
      FUN_009fdf30(iVar1,param_1);
      uVar2 = *(uint *)(iVar1 + 0x18);
    }
    if (uVar2 < *(uint *)(iVar3 + 0x18)) {
      FUN_009fdf30(iVar3,iVar1);
      if (*(uint *)(param_1 + 0x18) < *(uint *)(iVar1 + 0x18)) {
        FUN_009fdf30(iVar1,param_1);
      }
    }
    uVar2 = *(uint *)(param_2 + 0x18);
    iVar3 = iVar4 * 0x20 + param_2;
    iVar5 = param_2 + iVar4 * -0x20;
    if (*(uint *)(iVar5 + 0x18) < uVar2) {
      FUN_009fdf30(param_2,iVar5);
      uVar2 = *(uint *)(param_2 + 0x18);
    }
    if (uVar2 < *(uint *)(iVar3 + 0x18)) {
      FUN_009fdf30(iVar3,param_2);
      if (*(uint *)(iVar5 + 0x18) < *(uint *)(param_2 + 0x18)) {
        FUN_009fdf30(param_2,iVar5);
      }
    }
    iVar5 = param_3 + iVar4 * -0x20;
    iVar3 = param_3 + iVar4 * -0x40;
    uVar2 = *(uint *)(iVar5 + 0x18);
    if (*(uint *)(iVar3 + 0x18) < uVar2) {
      FUN_009fdf30(iVar5,iVar3);
      uVar2 = *(uint *)(iVar5 + 0x18);
    }
    if (uVar2 < *(uint *)(param_3 + 0x18)) {
      FUN_009fdf30(param_3,iVar5);
      if (*(uint *)(iVar3 + 0x18) < *(uint *)(iVar5 + 0x18)) {
        FUN_009fdf30(iVar5,iVar3);
      }
    }
    uVar2 = *(uint *)(param_2 + 0x18);
    if (*(uint *)(iVar1 + 0x18) < uVar2) {
      FUN_009fdf30(param_2,iVar1);
      uVar2 = *(uint *)(param_2 + 0x18);
    }
    if (uVar2 < *(uint *)(iVar5 + 0x18)) {
      FUN_009fdf30(iVar5,param_2);
      if (*(uint *)(iVar1 + 0x18) < *(uint *)(param_2 + 0x18)) {
        FUN_009fdf30(param_2,iVar1);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 19670 ; VA 0x009fbd30 ; FUN_009fbd30 */

void FUN_009fbd30(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint *puStack_14;
  uint *puStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  if ((param_1 != param_2) && (puVar6 = param_1 + 8, puVar6 != param_2)) {
    puStack_14 = param_1 + 6;
    do {
      uStack_4c = *puVar6;
      uStack_48 = puVar6[1];
      uStack_44 = puVar6[2];
      uStack_40 = puVar6[3];
      uStack_3c = puVar6[4];
      uStack_38 = puVar6[5];
      puStack_14[6] = 0;
      puStack_14[7] = 0xf;
      *(undefined *)puVar6 = 0;
      uStack_5 = *(undefined *)(puStack_14 + 9);
      uVar5 = puStack_14[8];
      uStack_2c = uStack_4c;
      uStack_28 = uStack_48;
      uStack_24 = uStack_44;
      uStack_20 = uStack_40;
      uStack_1c = uStack_3c;
      uStack_18 = uStack_38;
      uStack_c = uVar5;
      if (param_1[6] < uVar5) {
        puVar7 = puStack_14 + 7;
        puVar8 = puStack_14 + 10;
        uVar2 = uStack_38;
        puVar1 = puVar6;
        while (uStack_38 = uVar2, puStack_10 = puVar6, param_1 != puVar1) {
          puVar6 = puVar8 + -8;
          puVar1 = puVar7 + -0xd;
          if (puVar6 != puVar1) {
            uVar5 = *puVar7;
            if (0xf < uVar5) {
              uVar2 = *puVar6;
              uVar4 = uVar5 + 1;
              uVar3 = uVar2;
              if (0xfff < uVar4) {
                uVar3 = *(uint *)(uVar2 - 4);
                uVar4 = uVar5 + 0x24;
                if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc00b;
              }
              FUN_01674ea0(uVar3,uVar4);
            }
            puVar7[-1] = 0;
            *puVar7 = 0xf;
            *(undefined *)puVar6 = 0;
            uVar5 = puVar7[-0xc];
            uVar2 = puVar7[-0xb];
            uVar3 = puVar7[-10];
            *puVar6 = puVar7[-0xd];
            puVar8[-7] = uVar5;
            puVar8[-6] = uVar2;
            puVar8[-5] = uVar3;
            uVar5 = puVar7[-8];
            puVar8[-4] = puVar7[-9];
            puVar8[-3] = uVar5;
            puVar7[-9] = 0;
            puVar7[-8] = 0xf;
            *(undefined *)(puVar7 + -0xd) = 0;
          }
          puVar7[1] = puVar7[-7];
          *(undefined *)(puVar7 + 2) = *(undefined *)(puVar7 + -6);
          puVar7 = puVar7 + -8;
          puVar8 = puVar6;
          puVar6 = puStack_10;
          uVar2 = uStack_38;
        }
        if (param_1 == &uStack_4c) {
          param_1[6] = uStack_c;
          *(undefined *)(param_1 + 7) = uStack_5;
        }
        else {
          uVar5 = param_1[5];
          if (0xf < uVar5) {
            uVar2 = *param_1;
            uVar4 = uVar5 + 1;
            uVar3 = uVar2;
            if (0xfff < uVar4) {
              uVar3 = *(uint *)(uVar2 - 4);
              uVar4 = uVar5 + 0x24;
              if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc00b;
            }
            FUN_01674ea0(uVar3,uVar4);
          }
          uVar2 = 0xf;
          uStack_4c = uStack_4c & 0xffffff00;
          *param_1 = uStack_2c;
          param_1[1] = uStack_28;
          param_1[2] = uStack_24;
          param_1[3] = uStack_20;
          *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_18,uStack_1c);
          param_1[6] = uStack_c;
          *(undefined *)(param_1 + 7) = uStack_5;
        }
      }
      else {
        puVar1 = puStack_14 + -6;
        puVar7 = puVar6;
        puVar8 = puVar6;
        puStack_10 = puVar6;
        if (*puStack_14 < uVar5) {
          do {
            puVar8 = puVar1;
            if (puVar7 != puVar8) {
              uVar2 = puVar7[5];
              if (0xf < uVar2) {
                uVar5 = *puVar7;
                uVar4 = uVar2 + 1;
                uVar3 = uVar5;
                if (0xfff < uVar4) {
                  uVar3 = *(uint *)(uVar5 - 4);
                  uVar4 = uVar2 + 0x24;
                  if (0x1f < (uVar5 - uVar3) - 4) goto LAB_009fc00b;
                }
                FUN_01674ea0(uVar3,uVar4);
                uVar5 = uStack_c;
              }
              puVar7[4] = 0;
              puVar7[5] = 0xf;
              *(undefined *)puVar7 = 0;
              uVar2 = puVar8[1];
              uVar3 = puVar8[2];
              uVar4 = puVar8[3];
              *puVar7 = *puVar8;
              puVar7[1] = uVar2;
              puVar7[2] = uVar3;
              puVar7[3] = uVar4;
              uVar2 = puVar8[5];
              puVar7[4] = puVar8[4];
              puVar7[5] = uVar2;
              puVar8[4] = 0;
              puVar8[5] = 0xf;
              *(undefined *)puVar8 = 0;
            }
            puVar7[6] = puVar8[6];
            *(undefined *)(puVar7 + 7) = *(undefined *)(puVar8 + 7);
            puVar1 = puVar8 + -8;
            puVar7 = puVar8;
          } while (puVar8[-2] < uVar5);
        }
        uVar2 = uStack_38;
        if (puVar8 != &uStack_4c) {
          uVar2 = puVar8[5];
          if (0xf < uVar2) {
            uVar5 = *puVar8;
            uVar4 = uVar2 + 1;
            uVar3 = uVar5;
            if (0xfff < uVar4) {
              uVar3 = *(uint *)(uVar5 - 4);
              uVar4 = uVar2 + 0x24;
              if (0x1f < (uVar5 - uVar3) - 4) goto LAB_009fc00b;
            }
            FUN_01674ea0(uVar3,uVar4);
            uVar5 = uStack_c;
          }
          uStack_4c = uStack_4c & 0xffffff00;
          *puVar8 = uStack_2c;
          puVar8[1] = uStack_28;
          puVar8[2] = uStack_24;
          puVar8[3] = uStack_20;
          *(ulonglong *)(puVar8 + 4) = CONCAT44(uStack_18,uStack_1c);
          uVar2 = 0xf;
        }
        puVar8[6] = uVar5;
        *(undefined *)(puVar8 + 7) = uStack_5;
      }
      if (0xf < uVar2) {
        uVar5 = uVar2 + 1;
        uVar3 = uStack_4c;
        if (0xfff < uVar5) {
          uVar3 = *(uint *)(uStack_4c - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uStack_4c - uVar3) - 4) {
LAB_009fc00b:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar3,uVar5);
      }
      puVar6 = puVar6 + 8;
      puStack_14 = puStack_14 + 8;
    } while (puVar6 != param_2);
  }
  return;
}



/* FUNCTION 19671 ; VA 0x009fc020 ; FUN_009fc020 */

void FUN_009fc020(undefined4 *param_1,uint *param_2,uint *param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  uint *puStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  puVar6 = param_2 + ((int)param_3 - (int)param_2 >> 6) * 8;
  FUN_009fbba0(param_2,puVar6,param_3 + -8,param_4);
  puVar7 = puVar6 + 8;
  for (; ((param_2 < puVar6 &&
          (uVar2 = puVar6[-2], uVar4 = puVar6[6], uVar4 > uVar2 || uVar2 == uVar4)) &&
         (uVar4 <= uVar2)); puVar6 = puVar6 + -8) {
  }
  puVar8 = puVar7;
  puStack_c = puVar6;
  if (puVar7 < param_3) {
    uVar4 = puVar6[6];
    do {
      uVar2 = puVar7[6];
      puVar8 = puVar7;
      if ((uVar2 >= uVar4 && uVar2 != uVar4) || (uVar2 < uVar4)) break;
      puVar7 = puVar7 + 8;
      puVar8 = puVar7;
    } while (puVar7 < param_3);
  }
joined_r0x009fc093:
  do {
    if (param_3 <= puVar7) {
LAB_009fc20a:
      if (param_2 < puStack_c) {
        puStack_10 = puStack_c + -3;
        puVar5 = puVar6;
        do {
          puVar6 = puVar5;
          if (puStack_10[1] <= puVar5[6]) {
            if (puStack_10[1] < puVar5[6]) break;
            puVar6 = puVar5 + -8;
            if (puVar6 != puStack_10 + -5) {
              uStack_88 = *puVar6;
              uStack_84 = puVar5[-7];
              uStack_80 = puVar5[-6];
              uStack_7c = puVar5[-5];
              uStack_78 = *(undefined8 *)(puVar5 + -4);
              puVar5[-4] = 0;
              puVar5[-3] = 0xf;
              *(undefined *)puVar6 = 0;
              uStack_18 = CONCAT44(puVar5[-2],(uint)uStack_18);
              uStack_5 = *(undefined *)(puVar5 + -1);
              uVar4 = puVar5[-3];
              uStack_40 = uStack_78;
              uStack_28 = uStack_88;
              uStack_24 = uStack_84;
              uStack_20 = uStack_80;
              uStack_1c = uStack_7c;
              if (0xf < uVar4) {
                uVar2 = uVar4 + 1;
                uVar3 = *puVar6;
                uVar1 = uVar3;
                if (0xfff < uVar2) {
                  uVar1 = *(uint *)(uVar3 - 4);
                  uVar2 = uVar4 + 0x24;
                  if (0x1f < (uVar3 - uVar1) - 4) goto LAB_009fc6ab;
                }
                FUN_01674ea0(uVar1,uVar2);
              }
              puVar5[-4] = 0;
              puVar5[-3] = 0xf;
              *(undefined *)puVar6 = 0;
              uVar4 = puStack_10[-4];
              uVar2 = puStack_10[-3];
              uVar3 = puStack_10[-2];
              *puVar6 = puStack_10[-5];
              puVar5[-7] = uVar4;
              puVar5[-6] = uVar2;
              puVar5[-5] = uVar3;
              uVar4 = *puStack_10;
              puVar5[-4] = puStack_10[-1];
              puVar5[-3] = uVar4;
              puStack_10[-1] = 0;
              *puStack_10 = 0xf;
              *(undefined *)(puStack_10 + -5) = 0;
              puVar5[-2] = puStack_10[1];
              *(undefined *)(puVar5 + -1) = *(undefined *)(puStack_10 + 2);
              if (puStack_10 + -5 == &uStack_88) {
                uVar4 = uStack_78._4_4_;
              }
              else {
                uVar4 = *puStack_10;
                if (0xf < uVar4) {
                  uVar2 = puStack_10[-5];
                  uVar1 = uVar4 + 1;
                  uVar3 = uVar2;
                  if (0xfff < uVar1) {
                    uVar3 = *(uint *)(uVar2 - 4);
                    uVar1 = uVar4 + 0x24;
                    if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc6ab;
                  }
                  FUN_01674ea0(uVar3,uVar1);
                }
                uStack_88 = uStack_88 & 0xffffff00;
                puStack_10[-5] = uStack_28;
                puStack_10[-4] = uStack_24;
                puStack_10[-3] = uStack_20;
                puStack_10[-2] = uStack_1c;
                puStack_10[-1] = (uint)uStack_40;
                *puStack_10 = uStack_40._4_4_;
                uVar4 = 0xf;
              }
              puStack_10[1] = uStack_18._4_4_;
              *(undefined *)(puStack_10 + 2) = uStack_5;
              if (0xf < uVar4) {
                uVar3 = uVar4 + 1;
                uVar2 = uStack_88;
                if (0xfff < uVar3) {
                  uVar2 = *(uint *)(uStack_88 - 4);
                  uVar3 = uVar4 + 0x24;
                  if (0x1f < (uStack_88 - uVar2) - 4) goto LAB_009fc6ab;
                }
                FUN_01674ea0(uVar2,uVar3);
              }
            }
          }
          puStack_10 = puStack_10 + -8;
          puStack_c = puStack_c + -8;
          puVar5 = puVar6;
        } while (param_2 < puStack_c);
      }
      if (puStack_c == param_2) {
        if (puVar7 == param_3) {
          param_1[1] = puVar8;
          *param_1 = puVar6;
          return;
        }
        if (puVar8 != puVar7) {
          uStack_a8 = *puVar6;
          uStack_a4 = puVar6[1];
          uStack_a0 = puVar6[2];
          uStack_9c = puVar6[3];
          uStack_98 = *(undefined8 *)(puVar6 + 4);
          puVar6[4] = 0;
          puVar6[5] = 0xf;
          *(undefined *)puVar6 = 0;
          uStack_18 = CONCAT44(puVar6[6],(uint)uStack_18);
          uStack_5 = *(undefined *)(puVar6 + 7);
          uStack_40 = uStack_98;
          uStack_28 = uStack_a8;
          uStack_24 = uStack_a4;
          uStack_20 = uStack_a0;
          uStack_1c = uStack_9c;
          if (puVar6 != puVar8) {
            uVar4 = puVar6[5];
            if (0xf < uVar4) {
              uVar2 = *puVar6;
              uVar1 = uVar4 + 1;
              uVar3 = uVar2;
              if (0xfff < uVar1) {
                uVar3 = *(uint *)(uVar2 - 4);
                uVar1 = uVar4 + 0x24;
                if (0x1f < (uVar2 - uVar3) - 4) {
LAB_009fc6ab:
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(uVar3,uVar1);
            }
            puVar6[4] = 0;
            puVar6[5] = 0xf;
            *(undefined *)puVar6 = 0;
            uVar4 = puVar8[1];
            uVar2 = puVar8[2];
            uVar3 = puVar8[3];
            *puVar6 = *puVar8;
            puVar6[1] = uVar4;
            puVar6[2] = uVar2;
            puVar6[3] = uVar3;
            *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar8 + 4);
            puVar8[4] = 0;
            puVar8[5] = 0xf;
            *(undefined *)puVar8 = 0;
          }
          puVar6[6] = puVar8[6];
          *(undefined *)(puVar6 + 7) = *(undefined *)(puVar8 + 7);
          if (puVar8 == &uStack_a8) {
            uVar4 = uStack_98._4_4_;
          }
          else {
            uVar4 = puVar8[5];
            if (0xf < uVar4) {
              uVar2 = *puVar8;
              uVar1 = uVar4 + 1;
              uVar3 = uVar2;
              if (0xfff < uVar1) {
                uVar3 = *(uint *)(uVar2 - 4);
                uVar1 = uVar4 + 0x24;
                if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc6ab;
              }
              FUN_01674ea0(uVar3,uVar1);
            }
            puVar8[4] = 0;
            puVar8[5] = 0xf;
            *(undefined *)puVar8 = 0;
            *puVar8 = uStack_28;
            puVar8[1] = uStack_24;
            puVar8[2] = uStack_20;
            puVar8[3] = uStack_1c;
            uStack_a8 = uStack_a8 & 0xffffff00;
            *(undefined8 *)(puVar8 + 4) = uStack_40;
            uVar4 = 0xf;
          }
          puVar8[6] = uStack_18._4_4_;
          *(undefined *)(puVar8 + 7) = uStack_5;
          if (0xf < uVar4) {
            uVar3 = uVar4 + 1;
            uVar2 = uStack_a8;
            if (0xfff < uVar3) {
              uVar2 = *(uint *)(uStack_a8 - 4);
              uVar3 = uVar4 + 0x24;
              if (0x1f < (uStack_a8 - uVar2) - 4) goto LAB_009fc6ab;
            }
            FUN_01674ea0(uVar2,uVar3);
          }
        }
        uStack_38 = *puVar6;
        uStack_34 = puVar6[1];
        uStack_30 = puVar6[2];
        uStack_2c = puVar6[3];
        uStack_28 = puVar6[4];
        uStack_24 = puVar6[5];
        puVar6[4] = 0;
        puVar6[5] = 0xf;
        *(undefined *)puVar6 = 0;
        uStack_20 = puVar6[6];
        uStack_1c = CONCAT31(uStack_1c._1_3_,*(undefined *)(puVar6 + 7));
        if (puVar6 != puVar7) {
          uVar4 = puVar6[5];
          if (0xf < uVar4) {
            uVar2 = *puVar6;
            uVar1 = uVar4 + 1;
            uVar3 = uVar2;
            if (0xfff < uVar1) {
              uVar3 = *(uint *)(uVar2 - 4);
              uVar1 = uVar4 + 0x24;
              if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc6ab;
            }
            FUN_01674ea0(uVar3,uVar1);
          }
          puVar6[4] = 0;
          puVar6[5] = 0xf;
          *(undefined *)puVar6 = 0;
          uVar4 = puVar7[1];
          uVar2 = puVar7[2];
          uVar3 = puVar7[3];
          *puVar6 = *puVar7;
          puVar6[1] = uVar4;
          puVar6[2] = uVar2;
          puVar6[3] = uVar3;
          uVar4 = puVar7[5];
          puVar6[4] = puVar7[4];
          puVar6[5] = uVar4;
          puVar7[4] = 0;
          puVar7[5] = 0xf;
          *(undefined *)puVar7 = 0;
        }
        puVar6[6] = puVar7[6];
        *(undefined *)(puVar6 + 7) = *(undefined *)(puVar7 + 7);
        FUN_009fe6d0(&uStack_38);
        FUN_005507b0();
        puVar6 = puVar6 + 8;
        puVar7 = puVar7 + 8;
        puVar8 = puVar8 + 8;
      }
      else {
        puStack_c = puStack_c + -8;
        if (puVar7 == param_3) {
          puVar6 = puVar6 + -8;
          if (puStack_c != puVar6) {
            FUN_00776fd0(puStack_c);
            FUN_009fe6d0(puVar6);
            FUN_009fe6d0(&uStack_38);
            FUN_005507b0();
          }
          FUN_00776fd0(puVar6);
          FUN_009fe6d0(puVar8 + -8);
          FUN_009fe6d0(&uStack_38);
          FUN_005507b0();
          puVar8 = puVar8 + -8;
        }
        else {
          FUN_00776fd0(puVar7);
          FUN_009fe6d0(puStack_c);
          FUN_009fe6d0(&uStack_38);
          FUN_005507b0();
          puVar7 = puVar7 + 8;
        }
      }
      goto joined_r0x009fc093;
    }
    if (puVar6[6] <= puVar7[6]) {
      if (puVar6[6] < puVar7[6]) goto LAB_009fc20a;
      if (puVar8 != puVar7) {
        uStack_68 = *puVar8;
        uStack_64 = puVar8[1];
        uStack_60 = puVar8[2];
        uStack_5c = puVar8[3];
        uStack_40 = *(undefined8 *)(puVar8 + 2);
        uStack_58 = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
        puStack_10 = (uint *)puVar8[6];
        uVar4 = puVar8[5];
        uStack_5 = *(undefined *)(puVar8 + 7);
        uStack_48 = uStack_68;
        uStack_44 = uStack_64;
        uStack_18 = uStack_58;
        if (0xf < uVar4) {
          uVar2 = *puVar8;
          uVar1 = uVar4 + 1;
          uVar3 = uVar2;
          if (0xfff < uVar1) {
            uVar3 = *(uint *)(uVar2 - 4);
            uVar1 = uVar4 + 0x24;
            if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc6ab;
          }
          FUN_01674ea0(uVar3,uVar1);
        }
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
        uVar4 = puVar7[1];
        uVar2 = puVar7[2];
        uVar3 = puVar7[3];
        *puVar8 = *puVar7;
        puVar8[1] = uVar4;
        puVar8[2] = uVar2;
        puVar8[3] = uVar3;
        uVar4 = puVar7[5];
        puVar8[4] = puVar7[4];
        puVar8[5] = uVar4;
        puVar7[4] = 0;
        puVar7[5] = 0xf;
        *(undefined *)puVar7 = 0;
        puVar8[6] = puVar7[6];
        *(undefined *)(puVar8 + 7) = *(undefined *)(puVar7 + 7);
        if (puVar7 == &uStack_68) {
          uVar4 = uStack_58._4_4_;
        }
        else {
          uVar4 = puVar7[5];
          if (0xf < uVar4) {
            uVar2 = *puVar7;
            uVar1 = uVar4 + 1;
            uVar3 = uVar2;
            if (0xfff < uVar1) {
              uVar3 = *(uint *)(uVar2 - 4);
              uVar1 = uVar4 + 0x24;
              if (0x1f < (uVar2 - uVar3) - 4) goto LAB_009fc6ab;
            }
            FUN_01674ea0(uVar3,uVar1);
          }
          uStack_68 = uStack_68 & 0xffffff00;
          *puVar7 = uStack_48;
          puVar7[1] = uStack_44;
          puVar7[2] = (uint)uStack_40;
          puVar7[3] = uStack_40._4_4_;
          puVar7[4] = (uint)uStack_18;
          puVar7[5] = uStack_18._4_4_;
          uVar4 = 0xf;
        }
        puVar7[6] = (uint)puStack_10;
        *(undefined *)(puVar7 + 7) = uStack_5;
        if (0xf < uVar4) {
          uVar3 = uVar4 + 1;
          uVar2 = uStack_68;
          if (0xfff < uVar3) {
            uVar2 = *(uint *)(uStack_68 - 4);
            uVar3 = uVar4 + 0x24;
            if (0x1f < (uStack_68 - uVar2) - 4) goto LAB_009fc6ab;
          }
          FUN_01674ea0(uVar2,uVar3);
        }
      }
      puVar8 = puVar8 + 8;
    }
    puVar7 = puVar7 + 8;
  } while( true );
}



/* FUNCTION 19672 ; VA 0x009fc6c0 ; FUN_009fc6c0 */

void FUN_009fc6c0(int param_1,int param_2,uint param_3,int *param_4)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  int *piVar11;
  undefined4 *puVar12;
  int *piVar13;
  undefined4 *puVar14;
  
  iVar6 = (int)(param_3 - 1) >> 1;
  iVar10 = param_2;
  if (param_2 < iVar6) {
    do {
      iVar8 = param_1 + iVar10 * 0x40;
      piVar11 = (int *)(iVar10 * 0x20 + param_1);
      iVar10 = (2 - (uint)(*(uint *)(iVar8 + 0x38) < *(uint *)(iVar8 + 0x58))) + iVar10 * 2;
      piVar13 = (int *)(iVar10 * 0x20 + param_1);
      if (piVar11 != piVar13) {
        uVar1 = piVar11[5];
        if (0xf < uVar1) {
          iVar8 = *piVar11;
          uVar9 = uVar1 + 1;
          iVar7 = iVar8;
          if (0xfff < uVar9) {
            iVar7 = *(int *)(iVar8 + -4);
            uVar9 = uVar1 + 0x24;
            if (0x1f < (iVar8 - iVar7) - 4U) goto LAB_009fc929;
          }
          FUN_01674ea0(iVar7,uVar9);
        }
        piVar11[4] = 0;
        piVar11[5] = 0xf;
        *(undefined *)piVar11 = 0;
        iVar8 = piVar13[1];
        iVar7 = piVar13[2];
        iVar2 = piVar13[3];
        *piVar11 = *piVar13;
        piVar11[1] = iVar8;
        piVar11[2] = iVar7;
        piVar11[3] = iVar2;
        iVar8 = piVar13[5];
        piVar11[4] = piVar13[4];
        piVar11[5] = iVar8;
        piVar13[4] = 0;
        piVar13[5] = 0xf;
        *(undefined *)piVar13 = 0;
      }
      piVar11[6] = piVar13[6];
      *(undefined *)(piVar11 + 7) = *(undefined *)(piVar13 + 7);
    } while (iVar10 < iVar6);
  }
  if ((iVar10 == iVar6) && ((param_3 & 1) == 0)) {
    puVar14 = (undefined4 *)(param_1 + -0x20 + param_3 * 0x20);
    puVar12 = (undefined4 *)(iVar10 * 0x20 + param_1);
    if (puVar12 != puVar14) {
      FUN_005507b0();
      uVar3 = puVar14[1];
      uVar4 = puVar14[2];
      uVar5 = puVar14[3];
      *puVar12 = *puVar14;
      puVar12[1] = uVar3;
      puVar12[2] = uVar4;
      puVar12[3] = uVar5;
      uVar3 = puVar14[5];
      puVar12[4] = puVar14[4];
      puVar12[5] = uVar3;
      puVar14[4] = 0;
      puVar14[5] = 0xf;
      *(undefined *)puVar14 = 0;
    }
    puVar12[6] = puVar14[6];
    *(undefined *)(puVar12 + 7) = *(undefined *)(puVar14 + 7);
    iVar10 = param_3 - 1;
  }
  while (param_2 < iVar10) {
    iVar6 = iVar10 + -1 >> 1;
    piVar11 = (int *)(iVar6 * 0x20 + param_1);
    if ((uint)piVar11[6] <= (uint)param_4[6]) break;
    piVar13 = (int *)(iVar10 * 0x20 + param_1);
    if (piVar13 != piVar11) {
      uVar1 = piVar13[5];
      if (0xf < uVar1) {
        uVar9 = uVar1 + 1;
        iVar10 = *piVar13;
        iVar8 = iVar10;
        if (0xfff < uVar9) {
          iVar8 = *(int *)(iVar10 + -4);
          uVar9 = uVar1 + 0x24;
          if (0x1f < (iVar10 - iVar8) - 4U) goto LAB_009fc929;
        }
        FUN_01674ea0(iVar8,uVar9);
      }
      piVar13[4] = 0;
      piVar13[5] = 0xf;
      *(undefined *)piVar13 = 0;
      iVar10 = piVar11[1];
      iVar8 = piVar11[2];
      iVar7 = piVar11[3];
      *piVar13 = *piVar11;
      piVar13[1] = iVar10;
      piVar13[2] = iVar8;
      piVar13[3] = iVar7;
      iVar10 = piVar11[5];
      piVar13[4] = piVar11[4];
      piVar13[5] = iVar10;
      piVar11[4] = 0;
      piVar11[5] = 0xf;
      *(undefined *)piVar11 = 0;
    }
    piVar13[6] = piVar11[6];
    *(undefined *)(piVar13 + 7) = *(undefined *)(piVar11 + 7);
    iVar10 = iVar6;
  }
  piVar11 = (int *)(iVar10 * 0x20 + param_1);
  if (piVar11 != param_4) {
    uVar1 = piVar11[5];
    if (0xf < uVar1) {
      iVar10 = *piVar11;
      uVar9 = uVar1 + 1;
      iVar6 = iVar10;
      if (0xfff < uVar9) {
        iVar6 = *(int *)(iVar10 + -4);
        uVar9 = uVar1 + 0x24;
        if (0x1f < (iVar10 - iVar6) - 4U) {
LAB_009fc929:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar9);
    }
    piVar11[4] = 0;
    piVar11[5] = 0xf;
    *(undefined *)piVar11 = 0;
    iVar10 = param_4[1];
    iVar6 = param_4[2];
    iVar8 = param_4[3];
    *piVar11 = *param_4;
    piVar11[1] = iVar10;
    piVar11[2] = iVar6;
    piVar11[3] = iVar8;
    *(undefined8 *)(piVar11 + 4) = *(undefined8 *)(param_4 + 4);
    param_4[4] = 0;
    param_4[5] = 0xf;
    *(undefined *)param_4 = 0;
  }
  piVar11[6] = param_4[6];
  *(undefined *)(piVar11 + 7) = *(undefined *)(param_4 + 7);
  return;
}



/* FUNCTION 19673 ; VA 0x009fc930 ; FUN_009fc930 */

int __thiscall FUN_009fc930(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9790;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::Item*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19674 ; VA 0x009fca02 ; Catch_All@009fca02 */

void Catch_All_009fca02(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19675 ; VA 0x009fca20 ; FUN_009fca20 */

int __thiscall FUN_009fca20(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d97a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::PerformanceStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19676 ; VA 0x009fcaf2 ; Catch_All@009fcaf2 */

void Catch_All_009fcaf2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19677 ; VA 0x009fcb10 ; FUN_009fcb10 */

int __thiscall FUN_009fcb10(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d97b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RunningAverageItemDouble*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19678 ; VA 0x009fcbe2 ; Catch_All@009fcbe2 */

void Catch_All_009fcbe2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19679 ; VA 0x009fcc00 ; FUN_009fcc00 */

int __thiscall FUN_009fcc00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d97c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RunningAverageItemInt*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19680 ; VA 0x009fccd2 ; Catch_All@009fccd2 */

void Catch_All_009fccd2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19681 ; VA 0x009fccf0 ; FUN_009fccf0 */

int __thiscall FUN_009fccf0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d97d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_TotalCountTimeIntervalItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19682 ; VA 0x009fcdc2 ; Catch_All@009fcdc2 */

void Catch_All_009fcdc2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19683 ; VA 0x009fcde0 ; FUN_009fcde0 */

int __thiscall FUN_009fcde0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d97e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedMemItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19684 ; VA 0x009fceb2 ; Catch_All@009fceb2 */

void Catch_All_009fceb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19685 ; VA 0x009fced0 ; FUN_009fced0 */

int __thiscall FUN_009fced0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d97f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedPercentItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19686 ; VA 0x009fcfa2 ; Catch_All@009fcfa2 */

void Catch_All_009fcfa2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19687 ; VA 0x009fcfc0 ; FUN_009fcfc0 */

void FUN_009fcfc0(uint *param_1,int param_2,int param_3,undefined4 param_4)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint *puVar8;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  undefined uStack_10;
  int iStack_c;
  uint *puStack_8;
  
  iVar2 = param_2 - (int)param_1;
  do {
    iVar2 = iVar2 >> 5;
    if (iVar2 < 0x21) {
LAB_009fd040:
      if (iVar2 < 2) {
        return;
      }
      FUN_009fbd30(param_1,param_2,param_4);
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar2) {
        iVar2 = param_2 - (int)param_1 >> 5;
        iVar6 = param_2 - (int)param_1 >> 6;
        if (iVar6 < 1) goto LAB_009fd10a;
        puVar8 = param_1 + iVar6 * 8 + 5;
        break;
      }
      goto LAB_009fd040;
    }
    FUN_009fc020(&iStack_c,param_1,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)(iStack_c - (int)param_1 & 0xffffffe0U) < (int)(param_2 - (int)puStack_8 & 0xffffffe0U)
       ) {
      FUN_009fcfc0(param_1,iStack_c,param_3,param_4);
      param_1 = puStack_8;
    }
    else {
      FUN_009fcfc0(puStack_8,param_2,param_3,param_4);
      param_2 = iStack_c;
    }
    iVar2 = param_2 - (int)param_1;
  } while( true );
  do {
    uStack_2c = puVar8[-0xd];
    uStack_28 = puVar8[-0xc];
    uStack_24 = puVar8[-0xb];
    uStack_20 = puVar8[-10];
    iVar6 = iVar6 + -1;
    uStack_1c = puVar8[-9];
    uStack_18 = puVar8[-8];
    puVar8[-9] = 0;
    puVar8[-8] = 0xf;
    *(undefined *)(puVar8 + -0xd) = 0;
    uStack_14 = puVar8[-7];
    uStack_10 = *(undefined *)(puVar8 + -6);
    FUN_009fc6c0(param_1,iVar6,iVar2,&uStack_2c,param_4);
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar5 = uStack_2c;
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(uStack_2c - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (uStack_2c - uVar5) - 4) goto LAB_009fd22d;
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    puVar8 = puVar8 + -8;
  } while (0 < iVar6);
LAB_009fd10a:
  if (iVar2 < 2) {
    return;
  }
  puVar8 = (uint *)(param_2 + -0xc);
  do {
    if (1 < iVar2) {
      uStack_2c = puVar8[-5];
      uStack_28 = puVar8[-4];
      uStack_24 = puVar8[-3];
      uStack_20 = puVar8[-2];
      puVar1 = puVar8 + -5;
      uStack_1c = puVar8[-1];
      uStack_18 = *puVar8;
      puVar8[-1] = 0;
      *puVar8 = 0xf;
      *(undefined *)puVar1 = 0;
      uStack_14 = puVar8[1];
      uStack_10 = *(undefined *)(puVar8 + 2);
      if (puVar8 + -5 != param_1) {
        uVar5 = *puVar8;
        if (0xf < uVar5) {
          uVar7 = *puVar1;
          uVar4 = uVar5 + 1;
          uVar3 = uVar7;
          if (0xfff < uVar4) {
            uVar3 = *(uint *)(uVar7 - 4);
            uVar4 = uVar5 + 0x24;
            if (0x1f < (uVar7 - uVar3) - 4) {
LAB_009fd22d:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar3,uVar4);
        }
        puVar8[-1] = 0;
        *puVar8 = 0xf;
        *(undefined *)puVar1 = 0;
        uVar5 = param_1[1];
        uVar7 = param_1[2];
        uVar3 = param_1[3];
        *puVar1 = *param_1;
        puVar8[-4] = uVar5;
        puVar8[-3] = uVar7;
        puVar8[-2] = uVar3;
        uVar5 = param_1[5];
        puVar8[-1] = param_1[4];
        *puVar8 = uVar5;
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      puVar8[1] = param_1[6];
      *(undefined *)(puVar8 + 2) = *(undefined *)(param_1 + 7);
      FUN_009fc6c0(param_1,0,(int)puVar1 - (int)param_1 >> 5,&uStack_2c,param_4);
      if (0xf < uStack_18) {
        uVar7 = uStack_18 + 1;
        uVar5 = uStack_2c;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uStack_2c - 4);
          uVar7 = uStack_18 + 0x24;
          if (0x1f < (uStack_2c - uVar5) - 4) goto LAB_009fd22d;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
    }
    puVar8 = puVar8 + -8;
    iVar2 = (int)puVar8 + (0xc - (int)param_1) >> 5;
    if (iVar2 < 2) {
      return;
    }
  } while( true );
}



/* FUNCTION 19688 ; VA 0x009fd240 ; FUN_009fd240 */

undefined4 * FUN_009fd240(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9838;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x78);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *puVar3 = RBX::Stats::Item::vftable;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fc930(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19689 ; VA 0x009fd340 ; FUN_009fd340 */

undefined4 * FUN_009fd340(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9883;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xd8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ca7c10();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fca20(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19690 ; VA 0x009fd400 ; FUN_009fd400 */

undefined4 * FUN_009fd400(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d98d3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb2e0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    uVar5 = *param_2;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    puVar3[0x1e] = uVar5;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::Described<class_RunningAverageItemDouble,class_RunningAverageItem<double>_>::
              vftable;
    uVar5 = FUN_009fb2e0();
    puVar3[3] = uVar5;
    *puVar3 = RunningAverageItemDouble::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fcb10(puVar3,param_1);
  uStack_8 = 8;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19691 ; VA 0x009fd510 ; FUN_009fd510 */

undefined4 * FUN_009fd510(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9923;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb3c0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    uVar5 = *param_2;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    puVar3[0x1e] = uVar5;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::Described<class_RunningAverageItemInt,class_RunningAverageItem<int>_>::vftable;
    uVar5 = FUN_009fb3c0();
    puVar3[3] = uVar5;
    *puVar3 = RunningAverageItemInt::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fcc00(puVar3,param_1);
  uStack_8 = 8;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19692 ; VA 0x009fd620 ; FUN_009fd620 */

undefined4 * FUN_009fd620(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9973;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb660();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  puVar4 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Described<class_TotalCountTimeIntervalItem,class_RBX::Stats::Item>::vftable;
    uVar5 = FUN_009fb660();
    puVar4[3] = uVar5;
    *puVar4 = TotalCountTimeIntervalItem::vftable;
    puVar4[0x1e] = uVar1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fccf0(puVar4,param_1);
  uStack_8 = 8;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19693 ; VA 0x009fd730 ; FUN_009fd730 */

undefined4 * FUN_009fd730(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d99bb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<unsigned_int>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018d6241;
      *puVar5 = RBX::Stats::TypedMemItem::vftable;
    }
    else {
      puVar5[0x1e] = 0;
      *puVar5 = RBX::Stats::TypedMemItem::vftable;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fcde0(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19694 ; VA 0x009fd890 ; FUN_009fd890 */

undefined4 * FUN_009fd890(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9a0b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<float>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018e2e61;
      *puVar5 = RBX::Stats::TypedPercentItem::vftable;
    }
    else {
      puVar5[0x1e] = 0;
      *puVar5 = RBX::Stats::TypedPercentItem::vftable;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009fced0(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19695 ; VA 0x009fd9f0 ; FUN_009fd9f0 */

undefined4 * FUN_009fd9f0(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_009fd620(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19696 ; VA 0x009fdb40 ; FUN_009fdb40 */

undefined4 * FUN_009fdb40(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_009fd510(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19697 ; VA 0x009fdc90 ; FUN_009fdc90 */

undefined4 * FUN_009fdc90(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_009fd400(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19698 ; VA 0x009fdde0 ; FUN_009fdde0 */

void __thiscall FUN_009fdde0(undefined4 param_1,int *param_2)

{
  FUN_009ffd50(param_1,(double)*param_2,&DAT_018bed68,*param_2);
  return;
}



/* FUNCTION 19699 ; VA 0x009fde10 ; FUN_009fde10 */

void __thiscall FUN_009fde10(undefined4 param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *param_2;
  FUN_009ffd50(param_1,(double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)],&DAT_0193cde0,iVar1
              );
  return;
}



/* FUNCTION 19700 ; VA 0x009fde50 ; FUN_009fde50 */

void __thiscall FUN_009fde50(undefined4 param_1,float *param_2)

{
  FUN_009ffd50(param_1,(double)*param_2,&DAT_0192c008,(double)*param_2);
  return;
}



/* FUNCTION 19701 ; VA 0x009fde80 ; FUN_009fde80 */

void __thiscall FUN_009fde80(undefined4 param_1,undefined8 *param_2)

{
  FUN_009ffd50(param_1,*param_2,&DAT_0192c008,*param_2);
  return;
}



/* FUNCTION 19702 ; VA 0x009fdeb0 ; FUN_009fdeb0 */

void __thiscall FUN_009fdeb0(undefined4 param_1,undefined4 *param_2)

{
  undefined8 in_XMM0_Qa;
  
  FUN_016f3fe0(&DAT_018c6c58,*param_2,param_2[1]);
  FUN_009ffd50(param_1,in_XMM0_Qa);
  return;
}



/* FUNCTION 19703 ; VA 0x009fdee0 ; FUN_009fdee0 */

void __thiscall FUN_009fdee0(int param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar3 = "true";
  if (*param_2 == '\0') {
    pcVar3 = "false";
  }
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  *(double *)(param_1 + 0x58) = (double)(*param_2 != '\0');
  return;
}



/* FUNCTION 19704 ; VA 0x009fdf30 ; FUN_009fdf30 */

void FUN_009fdf30(uint *param_1,uint *param_2)

{
  undefined uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined8 uStack_2c;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  undefined8 uStack_c;
  
  uStack_3c = *param_1;
  uStack_38 = param_1[1];
  uStack_34 = param_1[2];
  uStack_30 = param_1[3];
  uStack_2c = *(undefined8 *)(param_1 + 4);
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uVar1 = *(undefined *)(param_1 + 7);
  uVar3 = param_1[6];
  uStack_1c = uStack_3c;
  uStack_18 = uStack_38;
  uStack_14 = uStack_34;
  uStack_10 = uStack_30;
  uStack_c = uStack_2c;
  if (param_1 != param_2) {
    FUN_005507b0();
    uVar4 = param_2[1];
    uVar5 = param_2[2];
    uVar2 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar4;
    param_1[2] = uVar5;
    param_1[3] = uVar2;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
  }
  param_1[6] = param_2[6];
  *(undefined *)(param_1 + 7) = *(undefined *)(param_2 + 7);
  if (param_2 == &uStack_3c) {
    uVar4 = uStack_2c._4_4_;
  }
  else {
    FUN_005507b0();
    uStack_3c = uStack_3c & 0xffffff00;
    *param_2 = uStack_1c;
    param_2[1] = uStack_18;
    param_2[2] = uStack_14;
    param_2[3] = uStack_10;
    *(undefined8 *)(param_2 + 4) = uStack_c;
    uVar4 = 0xf;
  }
  param_2[6] = uVar3;
  *(undefined *)(param_2 + 7) = uVar1;
  if (0xf < uVar4) {
    uVar5 = uVar4 + 1;
    uVar3 = uStack_3c;
    if (0xfff < uVar5) {
      uVar3 = *(uint *)(uStack_3c - 4);
      uVar5 = uVar4 + 0x24;
      if (0x1f < (uStack_3c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar5);
  }
  return;
}



/* FUNCTION 19705 ; VA 0x009fe020 ; FUN_009fe020 */

code * FUN_009fe020(code *param_1)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined uVar5;
  undefined4 uVar6;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1c0;
  undefined4 *puStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9a4e;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_008881d0();
  puStack_ec = (undefined4 *)0x0;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_00000024;
  piStack_e4 = in_stack_00000028;
  puStack_ec = (undefined4 *)FUN_0058c000();
  uStack_8._0_1_ = 2;
  uStack_1c0 = uStack_f0;
  puStack_1bc = (undefined4 *)0x0;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)*puStack_ec)(&uStack_e8,auStack_1b8);
  }
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  puStack_1bc = puStack_ec;
  if (param_1 == (code *)0x0) {
    uStack_8._0_1_ = uVar5;
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  pcVar3 = *(code **)(((uint)param_1 & 0xfffffffe) + 4);
  FUN_005caf00(&uStack_1c0);
  (*pcVar3)(&stack0x0000000c);
  uStack_8._0_1_ = 5;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)puStack_1bc[2])(auStack_1b8);
  }
  uStack_8._0_1_ = 6;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(&uStack_e8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    param_1 = (code *)(*param_1)(&stack0x0000000c,&stack0x0000000c,2);
  }
  piVar4 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19706 ; VA 0x009fe1c0 ; thunk_FUN_00a011b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a011b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9dd6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6bb4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee6bb4);
    if (DAT_01ee6bb4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TextureQueryType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee6b50 = RBX::Reflection::EnumDesc<enum_RBX::Stats::TextureQueryType>::vftable;
      FUN_009caf20(&DAT_01d658a8,4);
      FUN_016f3654(&LAB_01888800);
      FUN_016f37bf(&DAT_01ee6bb4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee6b50;
}



/* FUNCTION 19707 ; VA 0x009fe1d0 ; FUN_009fe1d0 */

undefined4 FUN_009fe1d0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_009fe34d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_009fe34d;
  }
  iVar2 = thunk_FUN_005f31b0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_009fe2f8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_005f31b0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_005ed680(&param_3);
      iVar4 = thunk_FUN_005f31b0();
      iStack_ec = iVar4;
      iVar5 = thunk_FUN_005f31b0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_009fe2f8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_005f31b0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 19708 ; VA 0x009fe3d0 ; FUN_009fe3d0 */

undefined4 * __fastcall FUN_009fe3d0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("DeveloperMemoryTag");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Memory::DeveloperTag>::vftable;
  FUN_009caf20(&DAT_01d657f8,0x16);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19709 ; VA 0x009fe430 ; FUN_009fe430 */

undefined4 * __thiscall FUN_009fe430(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9a6b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19710 ; VA 0x009fe510 ; FUN_009fe510 */

undefined4 * __fastcall FUN_009fe510(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9aa6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650("Stats");
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Stats::StatsService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_009fb580();
  param_1[3] = uVar1;
  *param_1 = RBX::Stats::StatsService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  uStack_8 = 3;
  FUN_016f4053(param_1 + 0x1a,0x28,4,FUN_009fe5f0,FUN_009fe6b0);
  param_1[0x1f] = 0;
  *(undefined *)(param_1 + 0x23) = 0;
  param_1[0x29] = 1;
  *(undefined *)(param_1 + 0x2d) = 1;
  param_1[0x33] = 2;
  *(undefined *)(param_1 + 0x37) = 0;
  param_1[0x3d] = 3;
  *(undefined *)(param_1 + 0x41) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19711 ; VA 0x009fe5f0 ; FUN_009fe5f0 */

undefined8 * __fastcall FUN_009fe5f0(undefined8 *param_1)

{
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((int)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  return param_1;
}



/* FUNCTION 19712 ; VA 0x009fe630 ; FUN_009fe630 */

void __fastcall FUN_009fe630(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0096ca80();
        iVar2 = iVar2 + 0x48;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x48) * 0x48;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 19713 ; VA 0x009fe6b0 ; FUN_009fe6b0 */

void FUN_009fe6b0(void)

{
  FUN_009fe630();
  FUN_0056d3e0();
  return;
}



/* FUNCTION 19714 ; VA 0x009fe6d0 ; FUN_009fe6d0 */

undefined4 * __thiscall FUN_009fe6d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 != param_2) {
    FUN_005507b0();
    uVar1 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
  }
  param_1[6] = param_2[6];
  *(undefined *)(param_1 + 7) = *(undefined *)(param_2 + 7);
  return param_1;
}



/* FUNCTION 19715 ; VA 0x009fe720 ; FUN_009fe720 */

int __thiscall FUN_009fe720(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 19716 ; VA 0x009fe780 ; FUN_009fe780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009fe780(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Stats::TextureQueryType>::vftable;
  _DAT_01ee6b44 = _DAT_01ee6b44 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 19717 ; VA 0x009fe7b0 ; FUN_009fe7b0 */

int __thiscall FUN_009fe7b0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 0x68,0x28,4,FUN_009fe6b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x60);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = *(int **)(param_1 + 0x5c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x108);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19718 ; VA 0x009fe870 ; FUN_009fe870 */

int * FUN_009fe870(int param_1,int param_2)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint in_stack_0000001c;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined8 uStack_20;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d9bf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  piVar4 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_018c5904,7);
    uStack_8 = 1;
    iVar3 = FUN_008a1240(auStack_38);
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = iVar3 + 4;
    }
    FUN_0060ddd0(&piStack_18,iVar3);
    uStack_8 = 3;
    uVar2 = uStack_8;
    uStack_8 = 3;
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      uVar6 = auStack_38[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
          uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    piVar4 = piStack_18;
    if ((piStack_18 != (int *)0x0) && (piVar4 = (int *)piStack_18[0xb], piVar4 != (int *)0x0)) {
      iVar3 = *piVar4;
      piVar4 = (int *)(piVar4[1] - iVar3 >> 3);
      if (((int *)0x1 < piVar4) &&
         ((*(int *)(iVar3 + 8) != 0 &&
          (piVar4 = (int *)FUN_008a1240(&param_2), piVar4 != (int *)0x0)))) {
        piVar4 = (int *)FUN_005cf720();
        if (piVar4 != (int *)0x0) {
          (**(code **)(*piVar4 + 0xa4))();
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = 0;
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8 = 4;
          FUN_008a1240(auStack_50);
          piVar4 = (int *)FUN_005cf720();
          (**(code **)(*piVar4 + 0xa4))();
          uStack_20 = *(undefined8 *)(piVar4 + 0x16);
          FUN_005507b0();
        }
        piVar4 = (int *)FUN_00550b30();
        goto LAB_009fea57;
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar3 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar4 = (int *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar4 = (int *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
LAB_009fea57:
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar6) {
      iVar3 = *(int *)(param_2 + -4);
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar4 = (int *)FUN_01674ea0(iVar3,uVar6);
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 19719 ; VA 0x009feab0 ; FUN_009feab0 */

undefined4 * FUN_009feab0(int param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d9c13;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    iVar2 = param_1 + 8;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      *param_3 = *(undefined4 *)(iVar2 + -8);
      param_3[1] = *(undefined4 *)(iVar2 + -4);
      param_3[2] = 0;
      FUN_005880d0(iVar2);
      uStack_8 = 1;
      param_3[10] = 0;
      FUN_005880d0(iVar2 + 0x20);
      param_3 = param_3 + 0x12;
      iVar1 = iVar2 + 0x40;
      iVar2 = iVar2 + 0x48;
    } while (iVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 19720 ; VA 0x009feb50 ; FUN_009feb50 */

void FUN_009feb50(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7930;
  pvStack_10 = ExceptionList;
  pcStack_14 = param_2;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee5eae);
  uVar1 = *param_6;
  uVar2 = *param_5;
  uVar3 = *param_4;
  auStack_6c[0] = 0;
  uVar4 = *param_8;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_6c;
  puVar6 = auStack_6c;
  if (uVar4 != 0) {
    auStack_6c[0] = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_8 + 2;
      uStack_7c = 0x9febdf;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
      puVar5 = (uint *)puStack_1c;
      puVar6 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_8[2];
      uStack_60 = param_8[3];
      uStack_5c = param_8[4];
      uStack_58 = param_8[5];
      uStack_54 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
      puVar5 = auStack_6c;
      puVar6 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar6;
  puStack_1c = (undefined *)puVar5;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar4 = *param_7;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_7 + 2);
    }
    else {
      uStack_a8 = param_7[2];
      uStack_a4 = param_7[3];
      uStack_a0 = param_7[4];
      uStack_9c = param_7[5];
      uStack_98 = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_009602e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x9fecc1;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(uVar2,uVar3);
  uStack_9c = 0x9fece4;
  uStack_90 = uVar1;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19721 ; VA 0x009fed00 ; FUN_009fed00 */

void FUN_009fed00(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00a011b0();
    *param_2 = uVar3;
    iVar4 = FUN_00a01260();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 19722 ; VA 0x009fed60 ; FUN_009fed60 */

void FUN_009fed60(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a011b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19723 ; VA 0x009feda0 ; FUN_009feda0 */

undefined4 * FUN_009feda0(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_009fd730(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19724 ; VA 0x009feef0 ; FUN_009feef0 */

undefined4 * FUN_009feef0(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_009fd890(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19725 ; VA 0x009ff040 ; FUN_009ff040 */

undefined4 * __thiscall FUN_009ff040(undefined4 param_1,undefined4 *param_2,char *param_3)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d9c41;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009fd240(param_2);
  uStack_8 = 0;
  uStack_14 = 1;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  pcStack_18 = *(code **)(*(int *)*param_2 + 0x38);
  pcVar3 = param_3;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar3 - (int)(param_3 + 1));
  uStack_8 = 1;
  (*pcStack_18)(auStack_30);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  FUN_008a65e0(param_1,0);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19726 ; VA 0x009ff130 ; FUN_009ff130 */

void __thiscall FUN_009ff130(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_008881d0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_00a011b0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00a01260();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_00a011b0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_005c9cc0();
    puVar3 = &uStack_28c;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19727 ; VA 0x009ff440 ; FUN_009ff440 */

int FUN_009ff440(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9c58;
  pvStack_10 = ExceptionList;
  iVar3 = 0;
  piVar4 = (int *)0x0;
  iVar2 = *(int *)(param_1 + 0x1c);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar4 = (int *)(iVar2 + 4);
    iVar3 = *(int *)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    while (iVar3 != 0) {
      LOCK();
      iVar2 = *piVar4;
      if (iVar3 == iVar2) {
        *piVar4 = iVar3 + 1;
        iVar2 = iVar3;
      }
      UNLOCK();
      if (iVar2 == iVar3) {
        iVar3 = *(int *)(param_1 + 0x18);
        piVar4 = *(int **)(param_1 + 0x1c);
        goto LAB_009ff499;
      }
      iVar3 = *piVar4;
    }
    iVar3 = 0;
    piVar4 = (int *)0x0;
  }
LAB_009ff499:
  uStack_8 = 0;
  if (iVar3 != 0) {
    iVar2 = FUN_00a012d0(param_2,param_3);
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 19728 ; VA 0x009ff500 ; FUN_009ff500 */

void __thiscall FUN_009ff500(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint in_stack_0000002c;
  undefined4 uVar5;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [12];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_3;
  puStack_c = &LAB_017d9c96;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_3)();
  if (uVar3 < 3) {
LAB_009ff5c3:
    if (*(undefined4 **)(param_1 + 0x48) == (undefined4 *)0x0) {
      uVar5 = 3;
      goto LAB_009ff716;
    }
    piStack_14 = (int *)**(undefined4 **)(param_1 + 0x48);
  }
  else {
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 2;
    cVar2 = (**(code **)(*piVar1 + 4))(3,&uStack_f4);
    if (cVar2 == '\0') {
      uStack_8._0_1_ = 4;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009ff5c3;
    }
    puVar4 = (undefined4 *)FUN_00889220();
    param_3 = (int *)*puVar4;
    uStack_8._0_1_ = 3;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8._0_1_ = 1;
    piStack_14 = param_3;
  }
  uVar3 = (**(code **)*piVar1)();
  if (1 < uVar3) {
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 5;
    cVar2 = (**(code **)(*piVar1 + 4))(2,&uStack_f4);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00889220();
      param_3 = (int *)*puVar4;
      uStack_8._0_1_ = 6;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009ff677;
    }
    uStack_8._0_1_ = 7;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(param_1 + 0x44) == (undefined4 *)0x0) {
    uVar5 = 2;
LAB_009ff716:
    FUN_016756b0(auStack_24,"Argument %d missing or nil",uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  param_3 = (int *)**(undefined4 **)(param_1 + 0x44);
LAB_009ff677:
  uStack_18 = FUN_009fff00(piVar1,param_1 + 0x40);
  FUN_009feb50(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_3,&piStack_14,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19729 ; VA 0x009ff740 ; FUN_009ff740 */

void FUN_009ff740(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  float10 fVar4;
  float afStack_1c [2];
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  if (0 < iVar2 - param_3) {
    uVar3 = FUN_005f31b0();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 1,afStack_1c);
    if (cVar1 != '\0') goto LAB_009ff7ab;
  }
  afStack_1c[0] = (float)FUN_009fe1d0(param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
LAB_009ff7ab:
  fVar4 = (float10)(**(code **)(iStack_14 + 0x38))(afStack_1c[0]);
  afStack_1c[0] = (float)fVar4;
  FUN_009d5680(param_2,afStack_1c[0]);
  return;
}



/* FUNCTION 19730 ; VA 0x009ff7e0 ; FUN_009ff7e0 */

void __thiscall FUN_009ff7e0(int param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  char *pcVar4;
  uint uVar5;
  double dVar6;
  char acStack_70 [64];
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  iVar2 = (int)param_2 >> 0x1f;
  if (param_2 < 1000) {
    ExceptionList = &pvStack_10;
    FUN_005e4ba0(acStack_70,0x40,&DAT_0193e0a8,param_2);
    dStack_18 = (double)(int)param_2 + (double)(&DAT_018c0d90)[-iVar2];
  }
  else {
    dStack_18 = (double)(int)param_2;
    if (param_2 < 100000) {
      dStack_18 = dStack_18 + (double)(&DAT_018c0d90)[-iVar2];
      dVar6 = dStack_18 / DAT_018c0d70;
      pcVar4 = "%.1fKB";
    }
    else if (param_2 < 1000000) {
      dStack_18 = dStack_18 + (double)(&DAT_018c0d90)[-iVar2];
      dVar6 = dStack_18 / DAT_018c0d70;
      pcVar4 = "%.0fKB";
    }
    else if (param_2 < 100000000) {
      dStack_18 = dStack_18 + (double)(&DAT_018c0d90)[-iVar2];
      dVar6 = dStack_18 / DAT_0193e468;
      pcVar4 = "%.1fMB";
    }
    else if (param_2 < 1000000000) {
      dStack_18 = dStack_18 + (double)(&DAT_018c0d90)[-iVar2];
      dVar6 = dStack_18 / DAT_0193e468;
      pcVar4 = "%.0fMB";
    }
    else {
      dStack_18 = dStack_18 + (double)(&DAT_018c0d90)[-iVar2];
      dVar6 = dStack_18 / DAT_0193e470;
      pcVar4 = "%.1fGB";
    }
    ExceptionList = &pvStack_10;
    FUN_005e4ba0(acStack_70,0x40,pcVar4,dVar6);
  }
  pcVar4 = acStack_70;
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(acStack_70,(int)pcVar4 - (int)(acStack_70 + 1));
  *(double *)(param_1 + 0x58) = dStack_18;
  uStack_8 = 0;
  if ((undefined4 ****)(param_1 + 0x60) != apppuStack_30) {
    ppppuVar3 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    }
    FUN_005542c0(ppppuVar3,uStack_20);
  }
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19731 ; VA 0x009ff9e0 ; FUN_009ff9e0 */

undefined * FUN_009ff9e0(undefined *param_1,uint param_2)

{
  char cVar1;
  char *pcVar2;
  double dVar3;
  char acStack_44 [64];
  
  if (param_2 < 1000) {
    FUN_005e4ba0(acStack_44,0x40,&DAT_0193e0a8,param_2);
  }
  else {
    dVar3 = (double)(int)param_2 + (double)(&DAT_018c0d90)[-((int)param_2 >> 0x1f)];
    if (param_2 < 100000) {
      dVar3 = dVar3 / DAT_018c0d70;
      pcVar2 = "%.1fKB";
    }
    else if (param_2 < 1000000) {
      dVar3 = dVar3 / DAT_018c0d70;
      pcVar2 = "%.0fKB";
    }
    else if (param_2 < 100000000) {
      dVar3 = dVar3 / DAT_0193e468;
      pcVar2 = "%.1fMB";
    }
    else if (param_2 < 1000000000) {
      dVar3 = dVar3 / DAT_0193e468;
      pcVar2 = "%.0fMB";
    }
    else {
      dVar3 = dVar3 / DAT_0193e470;
      pcVar2 = "%.1fGB";
    }
    FUN_005e4ba0(acStack_44,0x40,pcVar2,dVar3);
  }
  pcVar2 = acStack_44;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(acStack_44,(int)pcVar2 - (int)(acStack_44 + 1));
  return param_1;
}



/* FUNCTION 19732 ; VA 0x009ffaf0 ; FUN_009ffaf0 */

void __thiscall FUN_009ffaf0(int param_1,double param_2)

{
  char cVar1;
  double dVar2;
  char *pcVar3;
  char acStack_68 [64];
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (DAT_018c0d70 <= param_2) {
    dVar2 = param_2 / DAT_018c0d70;
    if (DAT_0193e468 <= param_2) {
      pcVar3 = "%.0fGB";
    }
    else {
      pcVar3 = "%.1fGB";
    }
  }
  else {
    pcVar3 = "%.0fMB";
    dVar2 = param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_005e4ba0(acStack_68,0x40,pcVar3,dVar2);
  pcVar3 = acStack_68;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(acStack_68,(int)pcVar3 - (int)(acStack_68 + 1));
  *(double *)(param_1 + 0x58) = param_2;
  uStack_8 = 0;
  if ((uint *)(param_1 + 0x60) != auStack_28) {
    FUN_005542c0();
  }
  if (0xf < uStack_14) {
    if ((0xfff < uStack_14 + 1) && (0x1f < (auStack_28[0] - *(int *)(auStack_28[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19733 ; VA 0x009ffc10 ; FUN_009ffc10 */

void __thiscall FUN_009ffc10(undefined4 param_1,double *param_2)

{
  double *pdVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  double dStack_50;
  
  dVar2 = param_2[5];
  FUN_017267a0();
  dVar2 = (dVar2 / param_2[4]) * DAT_018ce318;
  pdVar1 = (double *)FUN_016827a0();
  dStack_50 = param_2[4];
  if (((*(char **)(param_2 + 7) == (char *)0x0) || (**(char **)(param_2 + 7) == '\0')) &&
     (dStack_50 + dStack_50 < *pdVar1 - *param_2)) {
    dStack_50 = *pdVar1 - *param_2;
  }
  if (dStack_50 <= 0.0) {
    dStack_50 = 0.0;
  }
  else {
    dStack_50 = DAT_018c0d60 / dStack_50;
  }
  pdVar1 = (double *)FUN_016827a0();
  dVar4 = param_2[4];
  if (((*(char **)(param_2 + 7) == (char *)0x0) || (**(char **)(param_2 + 7) == '\0')) &&
     (dVar4 + dVar4 < *pdVar1 - *param_2)) {
    dVar4 = *pdVar1 - *param_2;
  }
  dVar3 = 0.0;
  if (0.0 < dVar4) {
    dVar3 = DAT_018c0d60 / dVar4;
  }
  FUN_009ffd50(param_1,dVar3,"%.1f/s (%.0f%%CV)",dStack_50,dVar2);
  return;
}



/* FUNCTION 19734 ; VA 0x009ffd50 ; FUN_009ffd50 */

void FUN_009ffd50(int param_1,undefined8 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01675830(aiStack_28,param_3,&stack0x00000014);
  uStack_8 = 0;
  *(undefined8 *)(param_1 + 0x58) = param_2;
  if ((undefined4 *)(param_1 + 0x60) != puVar2) {
    puVar1 = puVar2 + 4;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_005542c0(puVar2,*puVar1);
  }
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19735 ; VA 0x009ffdf0 ; FUN_009ffdf0 */

undefined4 FUN_009ffdf0(int *param_1,int *param_2)

{
  undefined4 uVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_1)();
  if (1 < uVar3) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = (**(code **)(*param_1 + 4))(2,&uStack_ec);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00889220();
      uVar1 = *puVar4;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_2;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19736 ; VA 0x009fff00 ; FUN_009fff00 */

int * FUN_009fff00(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uVar9;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)*param_1)();
  if (iVar4 == 0) {
LAB_00a000a7:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_00a011b0();
  cVar3 = (*pcVar1)(1,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(1,&iStack_ec);
  iVar4 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_00a000a7;
  }
  iVar6 = FUN_00a011b0();
  iVar8 = iStack_ec;
  if (iVar4 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_00a00052;
  }
  iVar6 = FUN_0088cb40();
  iVar4 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_00a011b0();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_009fb1b0(&param_1);
      iVar4 = FUN_00a011b0();
      iStack_ec = iVar4;
      iVar8 = FUN_00a011b0();
      if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_00a00052:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_00a011b0();
  uVar5 = FUN_005543f0();
  uVar9 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar9,uVar5);
}



/* FUNCTION 19737 ; VA 0x00a00130 ; FUN_00a00130 */

undefined4 FUN_00a00130(undefined4 param_1)

{
  FUN_0054ef60(&DAT_01d6577c);
  return param_1;
}



/* FUNCTION 19738 ; VA 0x00a00150 ; FUN_00a00150 */

void FUN_00a00150(void)

{
  int iVar1;
  
  if (DAT_01ee64fc == 0) {
    iVar1 = FUN_009fb2e0();
    DAT_01ee64fc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19739 ; VA 0x00a00170 ; FUN_00a00170 */

void FUN_00a00170(void)

{
  int iVar1;
  
  if (DAT_01ee62e4 == 0) {
    iVar1 = FUN_009fb3c0();
    DAT_01ee62e4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19740 ; VA 0x00a00190 ; FUN_00a00190 */

void FUN_00a00190(void)

{
  int iVar1;
  
  if (DAT_01ee692c == 0) {
    iVar1 = FUN_009fb660();
    DAT_01ee692c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19741 ; VA 0x00a001d0 ; FUN_00a001d0 */

float10 __fastcall FUN_00a001d0(undefined4 param_1)

{
  float10 fVar1;
  undefined uVar2;
  
  uVar2 = 0;
  FUN_005542c0("Received Data Packets",0x15);
  fVar1 = (float10)FUN_009fe870(param_1,uVar2);
  return (float10)(float)fVar1;
}



/* FUNCTION 19742 ; VA 0x00a00210 ; FUN_00a00210 */

float10 __fastcall FUN_00a00210(undefined4 param_1)

{
  float10 fVar1;
  undefined uVar2;
  
  uVar2 = 0;
  FUN_005542c0("Sent Data Packets",0x11);
  fVar1 = (float10)FUN_009fe870(param_1,uVar2);
  return (float10)(float)fVar1;
}



/* FUNCTION 19743 ; VA 0x00a00250 ; FUN_00a00250 */

float10 __fastcall FUN_00a00250(undefined4 param_1)

{
  float10 fVar1;
  
  FUN_00606cd0(param_1,param_1);
  fVar1 = (float10)FUN_009994b0();
  return (float10)(float)(fVar1 * (float10)DAT_018c0d70);
}



/* FUNCTION 19744 ; VA 0x00a00280 ; FUN_00a00280 */

float10 FUN_00a00280(int param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = 0;
  uVar3 = 0;
  iVar1 = FUN_01675020();
  if (iVar1 != 0) {
    do {
      iVar1 = FUN_01675030(uVar3);
      if (param_1 == iVar1) {
        iVar1 = FUN_016750a0(uVar3);
        iVar4 = iVar4 + iVar1;
      }
      uVar3 = uVar3 + 1;
      uVar2 = FUN_01675020();
    } while (uVar3 < uVar2);
  }
  return (float10)((float)((double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)]) * DAT_018d6c1c
                  * DAT_018d6c1c);
}



/* FUNCTION 19745 ; VA 0x00a00310 ; FUN_00a00310 */

void __thiscall
FUN_00a00310(int param_1,int param_2,undefined4 param_3,undefined4 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  double *pdVar1;
  undefined auStack_e8 [72];
  undefined auStack_a0 [8];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 auStack_90 [8];
  undefined4 auStack_70 [8];
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9ce6;
  pvStack_10 = ExceptionList;
  auStack_90[0] = 0;
  auStack_70[0] = 0;
  uStack_98 = param_3;
  uStack_94 = param_4;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    auStack_30[0] = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_28,0);
    }
    else {
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      uStack_1c = param_10;
      uStack_18 = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  auStack_50[0] = 0;
  uStack_8._0_1_ = 4;
  FUN_005880d0(auStack_30);
  FUN_005880d0(auStack_90);
  FUN_005880d0(auStack_50);
  uStack_8._0_1_ = 5;
  if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
     (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
  }
  uStack_8._0_1_ = 6;
  if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
     (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  uStack_8._0_1_ = 2;
  auStack_30[0] = 0;
  if (param_12 != 0) {
    auStack_30[0] = param_12;
    if ((param_12 & 1) == 0) {
      (**(code **)(param_12 & 0xfffffffe))(&param_14,&uStack_28,0);
    }
    else {
      uStack_28 = param_14;
      uStack_24 = param_15;
      uStack_20 = param_16;
      uStack_1c = param_17;
      uStack_18 = param_18;
    }
  }
  auStack_50[0] = 0;
  uStack_8._0_1_ = 8;
  FUN_005880d0(auStack_30);
  FUN_005880d0(auStack_70);
  FUN_005880d0(auStack_50);
  uStack_8._0_1_ = 9;
  if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
     (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
  }
  uStack_8._0_1_ = 10;
  if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
     (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  uStack_8._0_1_ = 2;
  param_1 = param_1 + param_2 * 0x28;
  FUN_009fe430(&uStack_98);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  pdVar1 = (double *)FUN_016830f0(auStack_a0);
  if ((double)DAT_01d65734 <= (*pdVar1 - *(double *)(param_1 + 0x68)) * DAT_018c0d70) {
    if (*(int *)(param_1 + 0x88) == *(int *)(param_1 + 0x84)) {
      FUN_009fb780(*(int *)(param_1 + 0x84),auStack_e8);
    }
    else {
      FUN_009fe430(auStack_e8);
      *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + 0x48;
    }
  }
  else {
    FUN_00a00b00(auStack_e8);
  }
  FUN_0096ca80();
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
  }
  uStack_8 = 0xd;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_12 & 0xfffffffe))(&param_14,&param_14,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19746 ; VA 0x00a005f0 ; FUN_00a005f0 */

float10 __fastcall FUN_00a005f0(undefined4 param_1)

{
  float10 fVar1;
  undefined uVar2;
  
  uVar2 = 0;
  FUN_005542c0("Received Physics Packets",0x18);
  fVar1 = (float10)FUN_009fe870(param_1,uVar2);
  return (float10)(float)fVar1;
}



/* FUNCTION 19747 ; VA 0x00a00630 ; FUN_00a00630 */

float10 __fastcall FUN_00a00630(undefined4 param_1)

{
  float10 fVar1;
  undefined uVar2;
  
  uVar2 = 0;
  FUN_005542c0("Sent Physics Packets",0x14);
  fVar1 = (float10)FUN_009fe870(param_1,uVar2);
  return (float10)(float)fVar1;
}



/* FUNCTION 19748 ; VA 0x00a00670 ; FUN_00a00670 */

float10 __fastcall FUN_00a00670(undefined4 param_1)

{
  float10 fVar1;
  
  FUN_00606cd0(param_1,param_1);
  fVar1 = (float10)FUN_009997b0();
  return (float10)(float)(fVar1 * (float10)DAT_018c0d70);
}



/* FUNCTION 19749 ; VA 0x00a006c0 ; FUN_00a006c0 */

undefined4 __thiscall FUN_00a006c0(int *param_1,undefined4 param_2)

{
  (**(code **)(*param_1 + 0xa4))();
  FUN_0054ef60(param_1 + 0x18);
  return param_2;
}


