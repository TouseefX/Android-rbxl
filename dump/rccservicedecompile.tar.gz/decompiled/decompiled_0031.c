/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 7750 ; VA 0x0066f342 ; Catch_All@0066f342 */

void Catch_All_0066f342(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7751 ; VA 0x0066f360 ; FUN_0066f360 */

int __thiscall FUN_0066f360(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3410;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ReplicatedStorage*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7752 ; VA 0x0066f432 ; Catch_All@0066f432 */

void Catch_All_0066f432(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7753 ; VA 0x0066f450 ; FUN_0066f450 */

int __thiscall FUN_0066f450(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3420;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RobloxReplicatedStorage*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7754 ; VA 0x0066f522 ; Catch_All@0066f522 */

void Catch_All_0066f522(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7755 ; VA 0x0066f540 ; FUN_0066f540 */

int __thiscall FUN_0066f540(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ServerScriptService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7756 ; VA 0x0066f612 ; Catch_All@0066f612 */

void Catch_All_0066f612(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7757 ; VA 0x0066f630 ; FUN_0066f630 */

int __thiscall FUN_0066f630(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3440;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::ServerReplicator::ServerStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7758 ; VA 0x0066f702 ; Catch_All@0066f702 */

void Catch_All_0066f702(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7759 ; VA 0x0066f720 ; FUN_0066f720 */

int __thiscall FUN_0066f720(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3450;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ServerStorage*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7760 ; VA 0x0066f7f2 ; Catch_All@0066f7f2 */

void Catch_All_0066f7f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7761 ; VA 0x0066f810 ; FUN_0066f810 */

int __thiscall FUN_0066f810(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3460;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::SocialService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7762 ; VA 0x0066f8e2 ; Catch_All@0066f8e2 */

void Catch_All_0066f8e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7763 ; VA 0x0066f900 ; FUN_0066f900 */

int __thiscall FUN_0066f900(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3470;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Soundscape::SoundService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7764 ; VA 0x0066f9d2 ; Catch_All@0066f9d2 */

void Catch_All_0066f9d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7765 ; VA 0x0066f9f0 ; FUN_0066f9f0 */

int __thiscall FUN_0066f9f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3480;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StarterGuiService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7766 ; VA 0x0066fac2 ; Catch_All@0066fac2 */

void Catch_All_0066fac2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7767 ; VA 0x0066fae0 ; FUN_0066fae0 */

int __thiscall FUN_0066fae0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3490;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StarterPackService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7768 ; VA 0x0066fbb2 ; Catch_All@0066fbb2 */

void Catch_All_0066fbb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7769 ; VA 0x0066fbd0 ; FUN_0066fbd0 */

int __thiscall FUN_0066fbd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a34a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StudioData*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7770 ; VA 0x0066fca2 ; Catch_All@0066fca2 */

void Catch_All_0066fca2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7771 ; VA 0x0066fcc0 ; FUN_0066fcc0 */

int __thiscall FUN_0066fcc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a34b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Teams*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7772 ; VA 0x0066fd92 ; Catch_All@0066fd92 */

void Catch_All_0066fd92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7773 ; VA 0x0066fdb0 ; FUN_0066fdb0 */

int __thiscall FUN_0066fdb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a34c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TeleportService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7774 ; VA 0x0066fe82 ; Catch_All@0066fe82 */

void Catch_All_0066fe82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7775 ; VA 0x0066fea0 ; FUN_0066fea0 */

int __thiscall FUN_0066fea0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a34d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TestService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7776 ; VA 0x0066ff72 ; Catch_All@0066ff72 */

void Catch_All_0066ff72(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7777 ; VA 0x0066ff90 ; FUN_0066ff90 */

int __thiscall FUN_0066ff90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a34e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::UnvalidatedAssetService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7778 ; VA 0x00670062 ; Catch_All@00670062 */

void Catch_All_00670062(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7779 ; VA 0x00670080 ; FUN_00670080 */

int __thiscall FUN_00670080(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a34f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::VersionControlService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7780 ; VA 0x00670152 ; Catch_All@00670152 */

void Catch_All_00670152(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7781 ; VA 0x00670170 ; FUN_00670170 */

undefined FUN_00670170(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_1;
  piStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_10 = param_3;
  piStack_c = param_4;
  uStack_8 = param_5;
  cVar4 = FUN_00585a40(&uStack_18);
  piVar2 = piStack_c;
  if (cVar4 == '\0') {
    FUN_006775b0(&uStack_18);
    *param_6 = 0;
    param_6[1] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    *param_6 = uStack_2c;
    param_6[1] = piStack_28;
    param_6[2] = 0;
    param_6[3] = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    param_6[2] = uStack_24;
    param_6[3] = piStack_20;
    param_6[4] = uStack_1c;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar3 = piStack_20[2] + -1;
        piStack_20[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    piVar2 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar5 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar3 = param_4[2] + -1;
      param_4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  return uVar5;
}



/* FUNCTION 7782 ; VA 0x00670320 ; FUN_00670320 */

void __thiscall
FUN_00670320(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_018d6264;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 7783 ; VA 0x00670440 ; FUN_00670440 */

undefined FUN_00670440(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      int *param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 auStack_40 [2];
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a3518;
  pvStack_10 = ExceptionList;
  auStack_40[0] = param_1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_38 = param_3;
  uStack_30 = param_5;
  uStack_2c = param_6;
  uStack_28 = param_7;
  piStack_34 = param_4;
  uStack_24 = param_8;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar5 = FUN_00585a40(auStack_40);
  piVar1 = piStack_34;
  uVar4 = uStack_38;
  uVar3 = auStack_40[0];
  if (cVar5 == '\0') {
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[2] = piStack_34[2] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_30;
    uStack_18 = uStack_2c;
    uStack_1c = uStack_28;
    uStack_20 = uStack_24;
    uStack_8 = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar3;
      puVar6[2] = 0;
      puVar6[3] = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[2] = piVar1[2] + 1;
        UNLOCK();
      }
      puVar6[2] = uVar4;
      puVar6[3] = piVar1;
      puVar6[4] = uStack_14;
      puVar6[5] = uStack_18;
      puVar6[6] = uStack_1c;
      puVar6[7] = uStack_20;
    }
    *param_9 = (int)puVar6;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    uVar7 = 1;
  }
  else {
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    uVar7 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 7784 ; VA 0x006705d0 ; FUN_006705d0 */

void __thiscall FUN_006705d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_c = param_4;
  uStack_10 = param_3;
  puStack_8 = param_1;
  cVar4 = FUN_00585a40(&uStack_14);
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_10;
    param_1[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = false;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar5 = &PTR_FUN_018d62c8;
  if (!bVar3) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_8 = ppuVar5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 7785 ; VA 0x006706e0 ; FUN_006706e0 */

void __thiscall FUN_006706e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a357f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_3;
  iStack_7c = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000010);
  uStack_3c = param_2;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_3c);
  if (cVar2 == '\0') {
    uStack_60 = uStack_3c;
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_60;
      puStack_18 = puVar3 + 1;
      *puStack_18 = 0;
      puVar3[2] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_5c;
      puVar3[2] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_018d62a8;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7786 ; VA 0x006708a0 ; FUN_006708a0 */

void __thiscall
FUN_006708a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  char cStack_5;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  cStack_5 = param_5;
  uStack_20 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_4;
  uStack_14 = param_5;
  uStack_1c = param_3;
  uStack_10 = param_6;
  cVar3 = FUN_00585a40(&uStack_20);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_20;
    cStack_5 = uStack_14;
    param_1[3] = 0;
    param_1[4] = 0;
    piStack_c = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[4] = piStack_18;
    param_1[3] = uStack_1c;
    *(undefined *)(param_1 + 5) = uStack_14;
    param_1[6] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_018d62c0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 7787 ; VA 0x006709d0 ; FUN_006709d0 */

undefined4 *
FUN_006709d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_20;
  int *piStack_18;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_006778b0(param_3,param_4,param_5,param_6,param_7);
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *puVar3;
  param_1[2] = puVar3[1];
  param_1[3] = 0;
  param_1[4] = 0;
  if (puVar3[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = puVar3[2];
  param_1[4] = puVar3[3];
  param_1[5] = puVar3[4];
  param_1[6] = puVar3[5];
  param_1[7] = puVar3[6];
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[2] + -1;
    piStack_20[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_6 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7788 ; VA 0x00670b10 ; FUN_00670b10 */

undefined4 *
FUN_00670b10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
    piVar1 = param_4 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  piVar1 = param_4 + 2;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  *(undefined *)(param_1 + 3) = param_5;
  param_1[4] = param_6;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7789 ; VA 0x00670d90 ; FUN_00670d90 */

undefined4 * FUN_00670d90(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a35cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<int>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018d630d;
    }
    else {
      puVar5[0x1e] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e460(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7790 ; VA 0x00670ee0 ; FUN_00670ee0 */

undefined4 * FUN_00670ee0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a361b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<unsigned_int>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018d6241;
    }
    else {
      puVar5[0x1e] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e550(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7791 ; VA 0x00671030 ; FUN_00671030 */

undefined4 * FUN_00671030(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3660;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bdf550();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bdf670();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e640(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7792 ; VA 0x006710f0 ; FUN_006710f0 */

int FUN_006710f0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3678;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd9c,&LAB_00670bf0);
  uVar2 = FUN_00675830();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bdf650();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671030(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd9c,&LAB_00670bf0);
      uVar2 = FUN_00675830();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7793 ; VA 0x00671280 ; FUN_00671280 */

undefined4 * FUN_00671280(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a36c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b67d80();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x118);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b69a30();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e730(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7794 ; VA 0x00671340 ; FUN_00671340 */

int FUN_00671340(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a36d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddd4,&LAB_00670c00);
  uVar2 = FUN_006758b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b67e80();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671280(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddd4,&LAB_00670c00);
      uVar2 = FUN_006758b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7795 ; VA 0x006714d0 ; FUN_006714d0 */

undefined4 FUN_006714d0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_0055e000();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7796 ; VA 0x00671530 ; FUN_00671530 */

undefined4 * FUN_00671530(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3723;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a75310();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x130);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a7bd20();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e820(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7797 ; VA 0x006715f0 ; FUN_006715f0 */

int FUN_006715f0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3738;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd64,&LAB_00670c10);
  uVar2 = FUN_00675930();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00a75410();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671530(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd64,&LAB_00670c10);
      uVar2 = FUN_00675930();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7798 ; VA 0x00671780 ; FUN_00671780 */

undefined4 * FUN_00671780(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3783;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bea180();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x154);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bedc90();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e910(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7799 ; VA 0x00671840 ; FUN_00671840 */

int FUN_00671840(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3798;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd6c,&LAB_00670c20);
  uVar2 = FUN_006759b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bea280();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671780(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd6c,&LAB_00670c20);
      uVar2 = FUN_006759b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7800 ; VA 0x006719d0 ; FUN_006719d0 */

undefined4 FUN_006719d0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00671840();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7801 ; VA 0x00671a30 ; FUN_00671a30 */

undefined4 FUN_00671a30(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00634b40();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7802 ; VA 0x00671a90 ; FUN_00671a90 */

undefined4 * FUN_00671a90(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a37e3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00be8480();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xe0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00be8790();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066ea00(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7803 ; VA 0x00671b50 ; FUN_00671b50 */

int FUN_00671b50(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a37f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
  uVar2 = FUN_00675a30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00be8560();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671a90(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
      uVar2 = FUN_00675a30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7804 ; VA 0x00671ce0 ; FUN_00671ce0 */

undefined4 FUN_00671ce0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005f4cd0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7805 ; VA 0x00671d40 ; FUN_00671d40 */

undefined4 * FUN_00671d40(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3843;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bd5c00();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x130);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bd79b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066eaf0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7806 ; VA 0x00671e00 ; FUN_00671e00 */

int FUN_00671e00(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3858;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd24,&LAB_00670c40);
  uVar2 = FUN_00675ab0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bd5d00();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671d40(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd24,&LAB_00670c40);
      uVar2 = FUN_00675ab0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7807 ; VA 0x00671f90 ; FUN_00671f90 */

undefined4 * FUN_00671f90(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a38a3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b12040();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x218);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b18df0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066ebe0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7808 ; VA 0x00672050 ; FUN_00672050 */

int FUN_00672050(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a38b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd74,&LAB_00670c50);
  uVar2 = FUN_00675b30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b12140();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00671f90(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd74,&LAB_00670c50);
      uVar2 = FUN_00675b30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7809 ; VA 0x006721e0 ; FUN_006721e0 */

undefined4 FUN_006721e0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_0055e310();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7810 ; VA 0x00672240 ; FUN_00672240 */

undefined4 * FUN_00672240(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3900;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bfb120();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bfc0b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066ecd0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7811 ; VA 0x00672300 ; FUN_00672300 */

int FUN_00672300(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddf4,&LAB_00670c60);
  uVar2 = FUN_00675bb0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bfb200();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00672240(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddf4,&LAB_00670c60);
      uVar2 = FUN_00675bb0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7812 ; VA 0x00672490 ; FUN_00672490 */

undefined4 FUN_00672490(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00672300();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7813 ; VA 0x006724f0 ; FUN_006724f0 */

undefined4 * FUN_006724f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3963;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00abe1a0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xac);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00abe4d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066edc0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7814 ; VA 0x006725b0 ; FUN_006725b0 */

int FUN_006725b0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3978;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddec,&LAB_00670c70);
  uVar2 = FUN_00675c30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00abe2a0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006724f0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddec,&LAB_00670c70);
      uVar2 = FUN_00675c30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7815 ; VA 0x00672740 ; FUN_00672740 */

undefined4 FUN_00672740(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_0055e560();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7816 ; VA 0x006727a0 ; FUN_006727a0 */

undefined4 * FUN_006727a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a39c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00be0bd0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xa0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00be2f80();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066eeb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7817 ; VA 0x00672860 ; FUN_00672860 */

int FUN_00672860(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a39d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd94,&LAB_00670c80);
  uVar2 = FUN_00675cb0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00be0cd0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006727a0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd94,&LAB_00670c80);
      uVar2 = FUN_00675cb0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7818 ; VA 0x006729f0 ; FUN_006729f0 */

undefined4 * FUN_006729f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3a23;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c096f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c09e80();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066efa0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7819 ; VA 0x00672ab0 ; FUN_00672ab0 */

int FUN_00672ab0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddb4,&LAB_00670c90);
  uVar2 = FUN_00675d30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c097f0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006729f0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddb4,&LAB_00670c90);
      uVar2 = FUN_00675d30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7820 ; VA 0x00672c40 ; FUN_00672c40 */

undefined4 * FUN_00672c40(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3a83;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c0ecd0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x90);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c0ffe0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f090(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7821 ; VA 0x00672d00 ; FUN_00672d00 */

int FUN_00672d00(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3a98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddbc,&LAB_00670ca0);
  uVar2 = FUN_00675db0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c0edd0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00672c40(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddbc,&LAB_00670ca0);
      uVar2 = FUN_00675db0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7822 ; VA 0x00672e90 ; FUN_00672e90 */

undefined4 FUN_00672e90(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00672d00();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7823 ; VA 0x00672ef0 ; FUN_00672ef0 */

undefined4 * FUN_00672ef0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3ae0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00be79a0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x6c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00be7ce0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f180(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7824 ; VA 0x00672fb0 ; FUN_00672fb0 */

int FUN_00672fb0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3af8;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (param_1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar5 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00677290();
      iVar5 = *piVar3;
      if (iVar5 == 0) {
        FUN_00672ef0(&iStack_18);
        iStack_8 = iVar5;
        FUN_008a5700(param_1);
        FUN_005789c0(&DAT_01eadd34,&LAB_00670cb0);
        uVar4 = FUN_00675e30();
        piVar3 = (int *)FUN_008aa140(uVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar3 = iStack_18;
        piVar1 = (int *)piVar3[1];
        piVar3[1] = (int)piStack_14;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar5 = piVar1[1] + -1;
          piVar1[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar3 = piStack_14 + 2;
            iVar2 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 7825 ; VA 0x00673100 ; FUN_00673100 */

undefined4 * FUN_00673100(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3b40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bff1c0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bff310();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f270(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7826 ; VA 0x006731c0 ; FUN_006731c0 */

int FUN_006731c0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3b58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddac,&LAB_00670cc0);
  uVar2 = FUN_00675eb0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bff2c0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00673100(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddac,&LAB_00670cc0);
      uVar2 = FUN_00675eb0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7827 ; VA 0x00673350 ; FUN_00673350 */

undefined4 * FUN_00673350(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bfef00();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bff020();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f360(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7828 ; VA 0x00673410 ; FUN_00673410 */

int FUN_00673410(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3bb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd7c,&LAB_00670cd0);
  uVar2 = FUN_00675f30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bff000();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00673350(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd7c,&LAB_00670cd0);
      uVar2 = FUN_00675f30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7829 ; VA 0x006735a0 ; FUN_006735a0 */

undefined4 * FUN_006735a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3c00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bff5b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bff6d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f450(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7830 ; VA 0x00673660 ; FUN_00673660 */

int FUN_00673660(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3c18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd84,&LAB_00670ce0);
  uVar2 = FUN_00675fb0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bff6b0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006735a0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd84,&LAB_00670ce0);
      uVar2 = FUN_00675fb0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7831 ; VA 0x006737f0 ; FUN_006737f0 */

undefined4 * FUN_006737f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3c60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b623e0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x60);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b62500();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f540(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7832 ; VA 0x006738b0 ; FUN_006738b0 */

int FUN_006738b0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3c78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddc4,&LAB_00670cf0);
  uVar2 = FUN_00676030();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b624e0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006737f0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddc4,&LAB_00670cf0);
      uVar2 = FUN_00676030();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7833 ; VA 0x00673a40 ; FUN_00673a40 */

undefined4 * FUN_00673a40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3ce4;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_20 = uVar3;
  puStack_1c = (undefined4 *)FUN_01674e20(0x218);
  if (puStack_1c == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uStack_28 = *param_2;
    piStack_2c = (int *)param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    uVar5 = 1;
    uStack_14 = 1;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
    }
    uStack_8 = 4;
    piStack_24 = piStack_2c;
    FUN_006fe020(&uStack_28);
    piStack_18 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    *puStack_1c = RBX::Network::ServerReplicator::ServerStatsItem::vftable;
    puStack_1c[0x7c] = 0;
    puStack_1c[0x7d] = 0;
    puStack_1c[0x7e] = 0;
    puStack_1c[0x7f] = 0;
    puStack_1c[0x80] = 0;
    puStack_1c[0x81] = 0;
    puStack_1c[0x82] = 0;
    puStack_1c[0x83] = 0;
    puStack_1c[0x84] = 0;
    puStack_1c[0x85] = 0;
    puVar4 = puStack_1c;
  }
  uStack_8 = 5;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f630(puVar4,param_1);
  uStack_14 = uVar5 | 2;
  if ((uVar5 != 0) && (uStack_14 = 2, piStack_2c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  uStack_8 = 9;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7834 ; VA 0x00673c20 ; FUN_00673c20 */

undefined4 * FUN_00673c20(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3d20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c08f50();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c09070();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f720(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7835 ; VA 0x00673ce0 ; FUN_00673ce0 */

int FUN_00673ce0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaddcc,&LAB_00670d00);
  uVar2 = FUN_006760b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c09050();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00673c20(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaddcc,&LAB_00670d00);
      uVar2 = FUN_006760b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7836 ; VA 0x00673e70 ; FUN_00673e70 */

undefined4 * FUN_00673e70(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c2a7d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x68);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c2ad60();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f810(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7837 ; VA 0x00673f30 ; FUN_00673f30 */

int FUN_00673f30(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3d98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadda4,&LAB_00670d10);
  uVar2 = FUN_00676130();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c2a8d0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00673e70(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadda4,&LAB_00670d10);
      uVar2 = FUN_00676130();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7838 ; VA 0x006740c0 ; FUN_006740c0 */

undefined4 * FUN_006740c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3de3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c1b320();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x298);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c1c690();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f900(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7839 ; VA 0x00674180 ; FUN_00674180 */

int FUN_00674180(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3df8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd3c,&LAB_00670d20);
  uVar2 = FUN_006761b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c1b420();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006740c0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd3c,&LAB_00670d20);
      uVar2 = FUN_006761b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7840 ; VA 0x00674310 ; FUN_00674310 */

undefined4 * FUN_00674310(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3e43;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b56f90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xe4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b5a440();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066f9f0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7841 ; VA 0x006743d0 ; FUN_006743d0 */

int FUN_006743d0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3e58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd4c,&LAB_00670d30);
  uVar2 = FUN_00676230();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b57090();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00674310(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd4c,&LAB_00670d30);
      uVar2 = FUN_00676230();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7842 ; VA 0x00674560 ; FUN_00674560 */

undefined4 * FUN_00674560(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3ea0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bd3ab0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bd41c0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066fae0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7843 ; VA 0x00674620 ; FUN_00674620 */

int FUN_00674620(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3eb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd44,&LAB_00670d40);
  uVar2 = FUN_006762b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bd3b90();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00674560(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd44,&LAB_00670d40);
      uVar2 = FUN_006762b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7844 ; VA 0x006747b0 ; FUN_006747b0 */

undefined4 * FUN_006747b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3f03;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c2d600();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c2d720();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066fbd0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7845 ; VA 0x00674870 ; FUN_00674870 */

int FUN_00674870(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3f18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadddc,&LAB_00670d50);
  uVar2 = FUN_00676330();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c2d700();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006747b0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadddc,&LAB_00670d50);
      uVar2 = FUN_00676330();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7846 ; VA 0x00674a00 ; FUN_00674a00 */

undefined4 * FUN_00674a00(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3f60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bdf840();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bdf960();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066fcc0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7847 ; VA 0x00674ac0 ; FUN_00674ac0 */

int FUN_00674ac0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3f78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd5c,&LAB_00670d60);
  uVar2 = FUN_006763b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bdf940();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00674a00(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd5c,&LAB_00670d60);
      uVar2 = FUN_006763b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7848 ; VA 0x00674c50 ; FUN_00674c50 */

undefined4 * FUN_00674c50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3fc3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ac0f70();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x10c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ac7770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066fdb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7849 ; VA 0x00674d10 ; FUN_00674d10 */

int FUN_00674d10(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3fd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead2e4,&LAB_00605b60);
  uVar2 = FUN_00606020();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00ac1050();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00674c50(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead2e4,&LAB_00605b60);
      uVar2 = FUN_00606020();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7850 ; VA 0x00674ea0 ; FUN_00674ea0 */

undefined4 * FUN_00674ea0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4023;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c00340();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x1d8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c01b00();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066fea0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7851 ; VA 0x00674f60 ; FUN_00674f60 */

int FUN_00674f60(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd8c,&LAB_00670d70);
  uVar2 = FUN_00676430();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c00440();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00674ea0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadd8c,&LAB_00670d70);
      uVar2 = FUN_00676430();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7852 ; VA 0x006750f0 ; FUN_006750f0 */

undefined4 * FUN_006750f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4083;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c2dc10();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c2ea90();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066ff90(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7853 ; VA 0x006751b0 ; FUN_006751b0 */

int FUN_006751b0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4098;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadde4,&LAB_00670d80);
  uVar2 = FUN_006764b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c2dd10();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006750f0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eadde4,&LAB_00670d80);
      uVar2 = FUN_006764b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7854 ; VA 0x00675340 ; FUN_00675340 */

undefined4 * FUN_00675340(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a40e3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009ef640();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x148);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009f0790();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00670080(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7855 ; VA 0x00675400 ; FUN_00675400 */

int FUN_00675400(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a40f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8dfc,&LAB_005cf1d0);
  uVar2 = FUN_005cf580();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009ef740();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00675340(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8dfc,&LAB_005cf1d0);
      uVar2 = FUN_005cf580();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7856 ; VA 0x00675590 ; FUN_00675590 */

undefined4 * FUN_00675590(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00670d90(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7857 ; VA 0x006756e0 ; FUN_006756e0 */

undefined4 * FUN_006756e0(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00670ee0(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7858 ; VA 0x00675830 ; FUN_00675830 */

undefined4 FUN_00675830(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a414c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade68) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade68);
    if (DAT_01eade68 == -1) {
      uStack_8 = 0;
      DAT_01eade64 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade68);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade64;
}



/* FUNCTION 7859 ; VA 0x006758b0 ; FUN_006758b0 */

undefined4 FUN_006758b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a416c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadea0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadea0);
    if (DAT_01eadea0 == -1) {
      uStack_8 = 0;
      DAT_01eade9c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadea0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade9c;
}



/* FUNCTION 7860 ; VA 0x00675930 ; FUN_00675930 */

undefined4 FUN_00675930(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a418c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade30) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade30);
    if (DAT_01eade30 == -1) {
      uStack_8 = 0;
      DAT_01eade2c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade30);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade2c;
}



/* FUNCTION 7861 ; VA 0x006759b0 ; FUN_006759b0 */

undefined4 FUN_006759b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a41ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade38) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade38);
    if (DAT_01eade38 == -1) {
      uStack_8 = 0;
      DAT_01eade34 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade38);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade34;
}



/* FUNCTION 7862 ; VA 0x00675a30 ; FUN_00675a30 */

undefined4 FUN_00675a30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a41cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade20) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade20);
    if (DAT_01eade20 == -1) {
      uStack_8 = 0;
      DAT_01eade1c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade20);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade1c;
}



/* FUNCTION 7863 ; VA 0x00675ab0 ; FUN_00675ab0 */

undefined4 FUN_00675ab0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a41ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadd30) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadd30);
    if (DAT_01eadd30 == -1) {
      uStack_8 = 0;
      DAT_01eadd2c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadd30);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eadd2c;
}



/* FUNCTION 7864 ; VA 0x00675b30 ; FUN_00675b30 */

undefined4 FUN_00675b30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a420c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade40) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade40);
    if (DAT_01eade40 == -1) {
      uStack_8 = 0;
      DAT_01eade3c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade40);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade3c;
}



/* FUNCTION 7865 ; VA 0x00675bb0 ; FUN_00675bb0 */

undefined4 FUN_00675bb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a422c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadec0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadec0);
    if (DAT_01eadec0 == -1) {
      uStack_8 = 0;
      DAT_01eadebc = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadec0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eadebc;
}



/* FUNCTION 7866 ; VA 0x00675c30 ; FUN_00675c30 */

undefined4 FUN_00675c30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a424c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadeb8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadeb8);
    if (DAT_01eadeb8 == -1) {
      uStack_8 = 0;
      DAT_01eadeb4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadeb8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eadeb4;
}



/* FUNCTION 7867 ; VA 0x00675cb0 ; FUN_00675cb0 */

undefined4 FUN_00675cb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a426c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade60) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade60);
    if (DAT_01eade60 == -1) {
      uStack_8 = 0;
      DAT_01eade5c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade60);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade5c;
}



/* FUNCTION 7868 ; VA 0x00675d30 ; FUN_00675d30 */

undefined4 FUN_00675d30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a428c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade80) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade80);
    if (DAT_01eade80 == -1) {
      uStack_8 = 0;
      DAT_01eade7c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade80);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade7c;
}



/* FUNCTION 7869 ; VA 0x00675db0 ; FUN_00675db0 */

undefined4 FUN_00675db0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a42ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade88) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade88);
    if (DAT_01eade88 == -1) {
      uStack_8 = 0;
      DAT_01eade84 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade88);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade84;
}



/* FUNCTION 7870 ; VA 0x00675e30 ; FUN_00675e30 */

undefined4 FUN_00675e30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a42cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade00) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade00);
    if (DAT_01eade00 == -1) {
      uStack_8 = 0;
      DAT_01eaddfc = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade00);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaddfc;
}



/* FUNCTION 7871 ; VA 0x00675eb0 ; FUN_00675eb0 */

undefined4 FUN_00675eb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a42ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade78) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade78);
    if (DAT_01eade78 == -1) {
      uStack_8 = 0;
      DAT_01eade74 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade78);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade74;
}



/* FUNCTION 7872 ; VA 0x00675f30 ; FUN_00675f30 */

undefined4 FUN_00675f30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a430c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade48) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade48);
    if (DAT_01eade48 == -1) {
      uStack_8 = 0;
      DAT_01eade44 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade48);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade44;
}



/* FUNCTION 7873 ; VA 0x00675fb0 ; FUN_00675fb0 */

undefined4 FUN_00675fb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a432c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade50) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade50);
    if (DAT_01eade50 == -1) {
      uStack_8 = 0;
      DAT_01eade4c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade50);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade4c;
}



/* FUNCTION 7874 ; VA 0x00676030 ; FUN_00676030 */

undefined4 FUN_00676030(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a434c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade90) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade90);
    if (DAT_01eade90 == -1) {
      uStack_8 = 0;
      DAT_01eade8c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade90);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade8c;
}



/* FUNCTION 7875 ; VA 0x006760b0 ; FUN_006760b0 */

undefined4 FUN_006760b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a436c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade98) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade98);
    if (DAT_01eade98 == -1) {
      uStack_8 = 0;
      DAT_01eade94 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade98);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade94;
}



/* FUNCTION 7876 ; VA 0x00676130 ; FUN_00676130 */

undefined4 FUN_00676130(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a438c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade70) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade70);
    if (DAT_01eade70 == -1) {
      uStack_8 = 0;
      DAT_01eade6c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade70);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade6c;
}



/* FUNCTION 7877 ; VA 0x006761b0 ; FUN_006761b0 */

undefined4 FUN_006761b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a43ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade08) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade08);
    if (DAT_01eade08 == -1) {
      uStack_8 = 0;
      DAT_01eade04 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade08);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade04;
}



/* FUNCTION 7878 ; VA 0x00676230 ; FUN_00676230 */

undefined4 FUN_00676230(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a43cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade18) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade18);
    if (DAT_01eade18 == -1) {
      uStack_8 = 0;
      DAT_01eade14 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade18);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade14;
}



/* FUNCTION 7879 ; VA 0x006762b0 ; FUN_006762b0 */

undefined4 FUN_006762b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a43ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade10) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade10);
    if (DAT_01eade10 == -1) {
      uStack_8 = 0;
      DAT_01eade0c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade10);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade0c;
}



/* FUNCTION 7880 ; VA 0x00676330 ; FUN_00676330 */

undefined4 FUN_00676330(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a440c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadea8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadea8);
    if (DAT_01eadea8 == -1) {
      uStack_8 = 0;
      DAT_01eadea4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadea8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eadea4;
}



/* FUNCTION 7881 ; VA 0x006763b0 ; FUN_006763b0 */

undefined4 FUN_006763b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a442c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade28) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade28);
    if (DAT_01eade28 == -1) {
      uStack_8 = 0;
      DAT_01eade24 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade28);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade24;
}



/* FUNCTION 7882 ; VA 0x00676430 ; FUN_00676430 */

undefined4 FUN_00676430(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a444c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eade58) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eade58);
    if (DAT_01eade58 == -1) {
      uStack_8 = 0;
      DAT_01eade54 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eade58);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eade54;
}



/* FUNCTION 7883 ; VA 0x006764b0 ; FUN_006764b0 */

undefined4 FUN_006764b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a446c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadeb0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadeb0);
    if (DAT_01eadeb0 == -1) {
      uStack_8 = 0;
      DAT_01eadeac = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadeb0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eadeac;
}



/* FUNCTION 7884 ; VA 0x00676530 ; FUN_00676530 */

void __thiscall FUN_00676530(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  uint *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005702d0(param_3);
  uVar7 = *(uint *)(param_1 + 4);
  puVar1 = (uint *)(param_1 + 4);
  uVar9 = uVar5 % uVar7;
  if (*(int *)(param_1 + 8) == 0) {
    piVar11 = (int *)0x0;
  }
  else {
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar10 == (undefined4 *)0x0) {
      piVar11 = (int *)0x0;
    }
    else {
      piVar11 = (int *)*puVar10;
    }
    if (piVar11 == (int *)0x0) goto LAB_0067660d;
    do {
      if (uVar5 == piVar11[1]) {
        piVar6 = piVar11 + 2;
        if (0xf < (uint)piVar11[7]) {
          piVar6 = (int *)*piVar6;
        }
        puVar10 = param_3;
        if (0xf < (uint)param_3[5]) {
          puVar10 = (undefined4 *)*param_3;
        }
        cVar4 = FUN_0055c360(puVar10,param_3[4],piVar6,piVar11[6]);
        if (cVar4 != '\0') break;
      }
      else if ((uint)piVar11[1] % uVar7 != uVar9) goto LAB_0067660d;
      piVar11 = (int *)*piVar11;
    } while (piVar11 != (int *)0x0);
  }
  if (piVar11 != (int *)0x0) {
    *param_2 = piVar11;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_0067660d:
  uStack_8 = 0;
  piVar11 = (int *)FUN_01674e20(0x20);
  *piVar11 = 0;
  piVar11[1] = 0;
  piVar11[2] = 0;
  piVar11[3] = 0;
  piVar11[4] = 0;
  piVar11[5] = 0;
  piVar11[6] = 0;
  piVar11[7] = 0;
  FUN_0054ef60(param_4);
  uVar9 = *(uint *)(param_1 + 8);
  uVar7 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *puVar1) {
      uVar7 = *puVar1;
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar8 = uVar9 >> 1;
    if (uVar9 + (uVar9 >> 1) <= uVar7) {
      uVar8 = 1;
    }
    uVar7 = FUN_005c9310(uVar8 + *(int *)(param_1 + 8));
    if (uVar7 != *puVar1) {
      FUN_005d2b00(uVar7);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar3 = (undefined4 *)*puVar10;
      while (puVar3 != (undefined4 *)0x0) {
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *puVar1) * 4) == 0) {
          *piVar6 = (int)puVar10;
          puVar10 = puVar3;
        }
        else {
          *puVar10 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar11[1] = uVar5;
  uVar7 = *puVar1;
  piVar6 = (int *)(*(int *)(param_1 + 0x14) + (uVar5 % uVar7) * 4);
  if ((int *)*piVar6 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar7) * 4) = piVar11;
    }
    *piVar6 = (int)piVar2;
    *piVar11 = *piVar2;
    *piVar2 = (int)piVar11;
  }
  else {
    *piVar11 = *(int *)*piVar6;
    *(int **)*piVar6 = piVar11;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar11;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7885 ; VA 0x00676780 ; FUN_00676780 */

int * __thiscall FUN_00676780(byte *param_1,int *param_2,int param_3,int param_4,int *param_5)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  undefined4 *puVar12;
  byte *pbVar13;
  int iStack_1c;
  byte *pbStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a44a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_18 = param_1;
  uStack_14 = FUN_005702d0(param_3);
  FUN_009c91c0(&uStack_14,param_3 + 0x18);
  uVar8 = (uStack_14 >> 2) + 0x9e3779b9 + uStack_14 * 0x40 + *(int *)(param_3 + 0x1c) ^ uStack_14;
  uStack_14 = uVar8;
  FUN_00676e80(&iStack_1c,uVar8,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_1c == 0) {
    uStack_8 = 0;
    piVar9 = (int *)FUN_01674e20(0x40);
    *piVar9 = 0;
    piVar9[1] = 0;
    FUN_0170d1f0(piVar9 + 2,0,0x38);
    FUN_0054ef60(param_4);
    pbVar13 = pbStack_18;
    piVar9[8] = *(int *)(param_4 + 0x18);
    piVar9[9] = *(int *)(param_4 + 0x1c);
    iVar5 = param_5[1];
    iVar6 = param_5[2];
    iVar7 = param_5[3];
    piVar9[10] = *param_5;
    piVar9[0xb] = iVar5;
    piVar9[0xc] = iVar6;
    piVar9[0xd] = iVar7;
    *(undefined8 *)(piVar9 + 0xe) = *(undefined8 *)(param_5 + 4);
    uVar3 = *(uint *)(pbStack_18 + 8);
    uVar10 = uVar3 + 1;
    if (*(int *)(pbStack_18 + 0x14) == 0) {
      uVar10 = FUN_005c9310(uVar10);
      if (uVar10 <= *(uint *)(pbVar13 + 4)) {
        uVar10 = *(uint *)(pbVar13 + 4);
      }
      FUN_005d2b00(uVar10);
    }
    else if (*(uint *)(pbStack_18 + 0x10) < uVar10) {
      uVar11 = uVar3 >> 1;
      if (uVar3 + (uVar3 >> 1) <= uVar10) {
        uVar11 = 1;
      }
      uVar10 = FUN_005c9310(uVar11 + uVar3);
      puVar1 = (uint *)(pbVar13 + 4);
      if (uVar10 != *puVar1) {
        FUN_005d2b00(uVar10);
        puVar12 = (undefined4 *)(*(int *)(pbVar13 + 0x14) + *puVar1 * 4);
        puVar4 = (undefined4 *)*puVar12;
        while (puVar4 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(pbStack_18 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4);
          if (*(int *)(*(int *)(pbStack_18 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4) == 0) {
            *piVar2 = (int)puVar12;
            puVar12 = puVar4;
          }
          else {
            *puVar12 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar4;
          }
          pbVar13 = pbStack_18;
          puVar4 = (undefined4 *)*puVar12;
        }
      }
    }
    piVar9[1] = uVar8;
    uVar10 = *(uint *)(pbVar13 + 4);
    iVar5 = *(int *)(pbVar13 + 0x14);
    puVar12 = (undefined4 *)(iVar5 + (uVar8 % uVar10) * 4);
    if (*(int *)(iVar5 + (uVar8 % uVar10) * 4) == 0) {
      piVar2 = (int *)(iVar5 + uVar10 * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(pbVar13 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar10) * 4) = piVar9;
      }
      *puVar12 = piVar2;
      *piVar9 = *piVar2;
      *piVar2 = (int)piVar9;
    }
    else {
      *piVar9 = *(int *)*puVar12;
      *(int **)*puVar12 = piVar9;
    }
    *(int *)(pbVar13 + 8) = *(int *)(pbVar13 + 8) + 1;
    *param_2 = (int)piVar9;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = iStack_1c;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7886 ; VA 0x006769c0 ; FUN_006769c0 */

int * __thiscall FUN_006769c0(byte *param_1,int *param_2,uint *param_3,uint *param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint *puVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar9 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a44c8;
  pvStack_10 = ExceptionList;
  puVar1 = param_3 + 1;
  ExceptionList = &pvStack_10;
  param_3 = (uint *)*param_3;
  FUN_009c91c0(&param_3,puVar1);
  param_3 = (uint *)(((uint)param_3 >> 2) + 0x9e3779b9 + (int)param_3 * 0x40 + puVar9[2] ^
                    (uint)param_3);
  uStack_14 = (uint)param_3;
  FUN_00676f40(&iStack_18,param_3,puVar9,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_18 != 0) {
    *param_2 = iStack_18;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_8 = 0;
  piVar10 = (int *)FUN_01674e20(0x30);
  *piVar10 = 0;
  piVar10[1] = 0;
  piVar10[2] = 0;
  piVar10[3] = 0;
  piVar10[4] = 0;
  piVar10[5] = 0;
  piVar10[6] = 0;
  piVar10[7] = 0;
  piVar10[8] = 0;
  piVar10[9] = 0;
  piVar10[10] = 0;
  piVar10[0xb] = 0;
  iVar6 = ((int *)param_4)[1];
  iVar7 = ((int *)param_4)[2];
  iVar8 = ((int *)param_4)[3];
  piVar10[2] = *param_4;
  piVar10[3] = iVar6;
  piVar10[4] = iVar7;
  piVar10[5] = iVar8;
  iVar6 = ((int *)param_4)[5];
  iVar7 = ((int *)param_4)[6];
  iVar8 = ((int *)param_4)[7];
  piVar10[6] = ((int *)param_4)[4];
  piVar10[7] = iVar6;
  piVar10[8] = iVar7;
  piVar10[9] = iVar8;
  *(undefined8 *)(piVar10 + 10) = *(undefined8 *)((int *)param_4 + 8);
  uVar4 = *(uint *)(param_1 + 8);
  uVar11 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar11 = FUN_005c9310(uVar11);
    if (uVar11 <= *(uint *)(param_1 + 4)) {
      uVar11 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar11);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar11) {
    param_4 = (uint *)0x1;
    uVar12 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar11) {
      uVar12 = 1;
    }
    uVar11 = FUN_005c9310(uVar12 + *(int *)(param_1 + 8));
    param_4 = (uint *)(param_1 + 4);
    if (uVar11 != *param_4) {
      FUN_005d2b00(uVar11);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_4 * 4);
      puVar5 = (undefined4 *)*puVar13;
      while (puVar5 != (undefined4 *)0x0) {
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_4) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_4) * 4) == 0) {
          *piVar2 = (int)puVar13;
          puVar13 = puVar5;
        }
        else {
          *puVar13 = *puVar5;
          *puVar5 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar5;
        }
        puVar5 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar10[1] = uStack_14;
  uVar11 = *(uint *)(param_1 + 4);
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uStack_14 % uVar11) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % uVar11) * 4) = piVar10;
    }
    *piVar2 = (int)piVar3;
    *piVar10 = *piVar3;
    *piVar3 = (int)piVar10;
  }
  else {
    *piVar10 = *(int *)*piVar2;
    *(int **)*piVar2 = piVar10;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = (int)piVar10;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7887 ; VA 0x00676bf0 ; FUN_00676bf0 */

int FUN_00676bf0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00913630();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 7888 ; VA 0x00676c30 ; FUN_00676c30 */

int __fastcall FUN_00676c30(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00c39bb0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 7889 ; VA 0x00676c60 ; FUN_00676c60 */

int * FUN_00676c60(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_005ee350(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 7890 ; VA 0x00676d50 ; FUN_00676d50 */

undefined4 FUN_00676d50(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      puVar3 = (undefined4 *)FUN_00677290();
      return *puVar3;
    }
  }
  return 0;
}



/* FUNCTION 7891 ; VA 0x00676db0 ; FUN_00676db0 */

int __fastcall FUN_00676db0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00b56e90(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 7892 ; VA 0x00676e20 ; FUN_00676e20 */

int __fastcall FUN_00676e20(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00b56e90(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 7893 ; VA 0x00676e80 ; FUN_00676e80 */

void __thiscall FUN_00676e80(int param_1,undefined4 *param_2,uint param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 *puVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar2 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar2;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          piVar5 = piVar4 + 2;
          cVar1 = FUN_009c8f50(piVar4 + 8);
          if (cVar1 != '\0') {
            if (0xf < (uint)piVar4[7]) {
              piVar5 = (int *)*piVar5;
            }
            puVar2 = param_4;
            if (0xf < (uint)param_4[5]) {
              puVar2 = (undefined4 *)*param_4;
            }
            cVar1 = FUN_0055c360(puVar2,param_4[4],piVar5,piVar4[6]);
            if (cVar1 != '\0') break;
          }
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 7894 ; VA 0x00676f40 ; FUN_00676f40 */

void __thiscall FUN_00676f40(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          if ((*param_4 == piVar4[2]) && (cVar2 = FUN_009c8f50(piVar4 + 3), cVar2 != '\0')) break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 7895 ; VA 0x00676fe0 ; FUN_00676fe0 */

undefined4 * FUN_00676fe0(undefined4 param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a44e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x5c);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::weak_ptr<class_RBX::Network::ServerReplicator>,int,enum_PacketPriority,int),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::Network::ServerReplicator>_>,class_boost::_bi::value<int>,class_boost::_bi::value<enum_PacketPriority>,class_boost::_bi::value<int>_>_>_>
              ::vftable;
    FUN_00677660(param_1);
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 7896 ; VA 0x0067704d ; Catch_All@0067704d */

void Catch_All_0067704d(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7897 ; VA 0x00677080 ; FUN_00677080 */

int * FUN_00677080(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd64,&LAB_00670c10);
  uVar3 = FUN_00675930();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00a75410();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7898 ; VA 0x00677130 ; FUN_00677130 */

int * FUN_00677130(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd6c,&LAB_00670c20);
  uVar3 = FUN_006759b0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00bea280();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7899 ; VA 0x006771e0 ; FUN_006771e0 */

int * FUN_006771e0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
  uVar3 = FUN_00675a30();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00be8560();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7900 ; VA 0x00677290 ; FUN_00677290 */

int * FUN_00677290(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd34,&LAB_00670cb0);
  uVar3 = FUN_00675e30();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00be7aa0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7901 ; VA 0x00677340 ; FUN_00677340 */

int * FUN_00677340(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd8c,&LAB_00670d70);
  uVar3 = FUN_00676430();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00c00440();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7902 ; VA 0x006773f0 ; FUN_006773f0 */

void FUN_006773f0(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(*param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Player::RTTI_Type_Descriptor,0);
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar2 != 0) {
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_1 = iVar2;
    param_1[1] = param_2[1];
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7903 ; VA 0x00677470 ; FUN_00677470 */

void * __thiscall FUN_00677470(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  code *pcVar3;
  int iVar4;
  void *pvVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a4510;
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar8 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar8 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar1 = (undefined4 *)puVar8[1];
    puVar8 = (undefined4 *)*puVar8;
    iStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; puVar8 != puVar1; puVar8 = puVar8 + 2) {
      piVar7 = (int *)puVar8[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)puVar8[1];
      }
      uVar2 = *puVar8;
      pcVar3 = (code *)*param_2;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      (*pcVar3)(uVar2,piVar7);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar4 = piVar7[1] + -1;
        piVar7[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar4 = piVar7[2] + -1;
          piVar7[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      pvVar5 = (void *)FUN_00677470(param_2);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar7 = piVar6 + 1;
      iVar4 = *piVar7;
      pvVar5 = (void *)*piVar7;
      *piVar7 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar7 = piVar6 + 2;
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 7904 ; VA 0x006775b0 ; FUN_006775b0 */

undefined4 * __thiscall FUN_006775b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 7905 ; VA 0x00677610 ; FUN_00677610 */

undefined4 * __thiscall FUN_00677610(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  return param_1;
}



/* FUNCTION 7906 ; VA 0x00677660 ; FUN_00677660 */

undefined4 * __thiscall FUN_00677660(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_2[3] = 0;
  param_2[4] = 0;
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  return param_1;
}



/* FUNCTION 7907 ; VA 0x006776e0 ; FUN_006776e0 */

undefined4 * __thiscall FUN_006776e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4528;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7908 ; VA 0x00677760 ; FUN_00677760 */

undefined4 * __thiscall
FUN_00677760(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4568;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7909 ; VA 0x006778b0 ; FUN_006778b0 */

int __thiscall
FUN_006778b0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_006779a0(param_2,param_3,param_4,param_5,param_6,param_7);
  *(undefined4 *)(param_1 + 0x18) = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7910 ; VA 0x006779a0 ; FUN_006779a0 */

undefined4 * __thiscall
FUN_006779a0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = 0;
  piVar2 = param_5 + 2;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[2] + -1;
    param_5[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  param_1[4] = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  param_1[5] = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[2] + -1;
    param_3[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7911 ; VA 0x00677af0 ; FUN_00677af0 */

undefined4 * __thiscall FUN_00677af0(undefined4 *param_1,undefined4 *param_2)

{
  FUN_005f70a0();
  FUN_005f7140();
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined2 *)(param_1 + 2) = *(undefined2 *)(param_2 + 2);
  FUN_005f7170(param_2 + 4);
  return param_1;
}



/* FUNCTION 7912 ; VA 0x00677b30 ; FUN_00677b30 */

undefined4 * __thiscall
FUN_00677b30(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = param_3;
  param_1[1] = param_4;
  param_1[2] = param_5;
  param_1[3] = param_6;
  *(ulonglong *)(param_1 + 4) = CONCAT44(param_8,param_7);
  if (param_2 == 0) {
    param_7 = 0xffffffff;
    param_8 = 0;
  }
  else {
    param_7 = *(undefined4 *)(param_2 + 0x18);
    param_8 = *(undefined4 *)(param_2 + 0x1c);
  }
  param_1[6] = param_7;
  param_1[7] = param_8;
  return param_1;
}



/* FUNCTION 7913 ; VA 0x00677b90 ; FUN_00677b90 */

undefined4 * __thiscall
FUN_00677b90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,int *param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,int param_16,
            undefined4 *param_17)

{
  int iVar1;
  undefined8 uVar2;
  undefined4 *puVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined **ppuVar10;
  uint uVar11;
  undefined4 in_stack_ffffffb0;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined8 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a46a5;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar5 = FUN_00644880();
  if ((DAT_01d5a4d0 == '\0') ||
     (puStack_14 = (undefined8 *)CONCAT31(puStack_14._1_3_,1), *(int *)(param_16 + 0x124) != 2)) {
    puStack_14 = (undefined8 *)((uint)puStack_14 & 0xffffff00);
  }
  if (param_12 != (int *)0x0) {
    LOCK();
    param_12[1] = param_12[1] + 1;
    UNLOCK();
  }
  FUN_0060f2e0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,in_stack_ffffffb0,param_14,param_15,param_17,puStack_14,uVar5);
  uStack_8._0_1_ = 1;
  *param_1 = RBX::Described<class_RBX::Network::ServerReplicator,class_RBX::Network::Replicator>::
             vftable;
  param_1[0x17] =
       RBX::Described<class_RBX::Network::ServerReplicator,class_RBX::Network::Replicator>::vftable;
  param_1[0x19] =
       RBX::Described<class_RBX::Network::ServerReplicator,class_RBX::Network::Replicator>::vftable;
  param_1[0x1a] =
       RBX::Described<class_RBX::Network::ServerReplicator,class_RBX::Network::Replicator>::vftable;
  uVar5 = FUN_005ee350();
  param_1[3] = uVar5;
  param_1[0xec0] = param_2;
  *param_1 = RBX::Network::ServerReplicator::vftable;
  param_1[0x17] = RBX::Network::ServerReplicator::vftable;
  param_1[0x19] = RBX::Network::ServerReplicator::vftable;
  param_1[0x1a] = RBX::Network::ServerReplicator::vftable;
  puStack_14 = (undefined8 *)(param_1 + 0xec2);
  *puStack_14 = DAT_018ce308;
  *(undefined *)(param_1 + 0xec4) = 0;
  param_17 = (undefined4 *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_17)
  ;
  ppuVar10 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar10 = ppuVar6;
  }
  param_1[0xec5] = *ppuVar10;
  param_1[0xec6] = 0;
  param_1[0xec7] = 0x3f800000;
  param_1[0xec8] = 0;
  param_1[0xec9] = 0;
  puVar8 = param_1 + 0xeca;
  uStack_8._0_1_ = 3;
  *puVar8 = 0;
  param_1[0xecb] = 0;
  param_1[0xecc] = 0;
  param_1[0xecd] = 0;
  param_1[0xece] = 0;
  param_17 = puVar8;
  puVar7 = (undefined4 *)FUN_01674e20(8);
  puVar3 = puStack_18;
  *puVar8 = puVar7;
  *puVar7 = 0;
  puVar7[1] = 0;
  *(undefined4 **)*puVar8 = puVar8;
  param_1[0xecf] = 0;
  param_1[0xed2] = 0;
  puStack_14 = (undefined8 *)(puStack_18 + 0xed4);
  *puStack_14 = DAT_018ce308;
  *(undefined *)(puStack_18 + 0xed6) = 0;
  param_17 = (undefined4 *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_17)
  ;
  ppuVar10 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar10 = ppuVar6;
  }
  puVar3[0xed7] = *ppuVar10;
  puVar3[0xed8] = 0;
  puVar3[0xed9] = 0x3f800000;
  puVar3[0xeda] = 0;
  puVar3[0xedb] = 0;
  puVar7 = puVar3 + 0xedc;
  uStack_8._0_1_ = 5;
  *puVar7 = 0;
  puVar3[0xedd] = 0;
  puVar3[0xede] = 0;
  puVar3[0xedf] = 0;
  puVar3[0xee0] = 0;
  param_17 = puVar7;
  puVar8 = (undefined4 *)FUN_01674e20(8);
  *puVar7 = puVar8;
  *puVar8 = 0;
  puVar8[1] = 0;
  *(undefined4 **)*puVar7 = puVar7;
  puVar3[0xee1] = 0;
  puVar3[0xee4] = 0;
  puVar3[0xee5] = 0;
  puVar3[0xee6] = 0;
  puVar3[0xee7] = 0;
  *(undefined8 *)(puVar3 + 0xee8) = 0;
  *(undefined *)(puVar3 + 0xeea) = DAT_01d5af40;
  puVar3[0xeeb] = 0;
  puVar3[0xeec] = 0;
  uStack_8._0_1_ = 9;
  puVar3[0xeed] = 0;
  puVar3[0xeee] = 0x24;
  FUN_016830f0(puVar3 + 0xef0);
  FUN_016830f0(puVar3 + 0xef2);
  FUN_0151f6f0(0xffffffff,0,0);
  *(undefined *)(puVar3 + 0xf02) = 0;
  puVar3[0xf03] = 0;
  puVar3[0xf04] = 0;
  puVar3[0xf05] = 0;
  puVar3[0xf06] = 0;
  puVar3[0xf07] = param_16;
  puVar3[0xf08] = 0;
  puVar3[0xf09] = 0;
  puVar3[0xf0a] = 1;
  puVar3[0xf0b] = 0;
  puVar3[0xf0c] = 0x10000;
  puVar3[0xf0d] = 0;
  puVar3[0xf0e] = 0;
  *(undefined *)(puVar3 + 0xf0f) = 0;
  puVar3[0xf14] = 0;
  puVar3[0xf15] = 0xf;
  *(undefined *)(puVar3 + 0xf10) = 0;
  puVar3[0xf16] = 0;
  puVar3[0xf17] = 0;
  puVar3[0xf1c] = 0;
  puVar3[0xf1d] = 0xf;
  *(undefined *)(puVar3 + 0xf18) = 0;
  uVar2 = DAT_018ce300;
  uStack_8._0_1_ = 0x11;
  *(undefined8 *)(puVar3 + 0xf1e) = 0;
  *(undefined8 *)(puVar3 + 0xf20) = uVar2;
  puVar3[0xf22] = 0;
  puVar3[0xf24] = 0;
  puVar3[0xf25] = 0;
  puVar3[0xf26] = 0;
  puVar3[0xf27] = 0;
  *(undefined *)(puVar3 + 0xf28) = 1;
  *(undefined8 *)(puVar3 + 0xf2a) = uVar2;
  puVar3[0xf2c] = 0;
  puVar3[0xf2e] = 0;
  puVar3[0xf2f] = 0;
  puVar3[0xf30] = 0;
  puVar3[0xf31] = 0;
  *(undefined *)(puVar3 + 0xf32) = 1;
  *(undefined8 *)(puVar3 + 0xf34) = uVar2;
  puVar3[0xf36] = 0;
  puVar3[0xf38] = 0;
  puVar3[0xf39] = 0;
  puVar3[0xf3a] = 0;
  puVar3[0xf3b] = 0;
  *(undefined *)(puVar3 + 0xf3c) = 1;
  puVar3[0xf3e] = 0;
  puStack_14 = (undefined8 *)0xffffffff;
  FUN_0060e810(0,&puStack_14,(int)&param_17 + 3);
  puVar3[0xf42] = 0;
  puVar3[0xf43] = 0xffffffff;
  puVar3[0xf45] = 0;
  puVar3[0xf46] = 0;
  puVar3[0xf47] = 0;
  puVar3[0xf48] = 0;
  puVar3[0xf50] = 0;
  puVar3[0xf51] = 0;
  puVar3[0xf52] = 0;
  *(undefined *)(puVar3 + 0xf53) = 0;
  puStack_14 = (undefined8 *)(float)DAT_01eadc60;
  uStack_8._0_1_ = 0x14;
  param_17 = (undefined4 *)(float)DAT_01d5ae54;
  FUN_016830f0(puVar3 + 0xf54);
  puVar3[0xf57] = param_17;
  puVar3[0xf56] = 0;
  puVar3[0xf58] = puStack_14;
  puVar3[0xf5a] = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("ServerReplicator",0x10);
  uStack_8._0_1_ = 0x15;
  FUN_008a6520(auStack_30);
  uStack_8._0_1_ = 0x14;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x14;
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    uVar9 = auStack_30[0];
    if (0xfff < uVar11) {
      uVar9 = *(uint *)(auStack_30[0] - 4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar11);
  }
  puVar3[0xe10] = param_2;
  param_17 = (undefined4 *)FUN_01674e20(4);
  uStack_8._0_1_ = 0x16;
  if (param_17 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0054d840(puVar3);
  }
  iVar1 = puVar3[0xee4];
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  puVar3[0xee4] = uVar5;
  if (iVar1 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar1,4);
  }
  puVar3[0x424] = puVar3[0xef0];
  *(undefined *)(puVar3 + 0xe00) = 0;
  puVar3[0x425] = puVar3[0xef1];
  uVar9 = FUN_01679ce0();
  if (((int)(uVar9 % 100000) < DAT_01eace40) && (*(int *)(param_16 + 0x124) != 2)) {
    *(undefined *)(puVar3 + 0xe18) = 1;
  }
  if (param_12 != (int *)0x0) {
    LOCK();
    iVar1 = param_12[1] + -1;
    param_12[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_12)();
      LOCK();
      iVar1 = param_12[2] + -1;
      param_12[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 7914 ; VA 0x006781e0 ; thunk_FUN_006133f0 */

void __fastcall thunk_FUN_006133f0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0x17] = RBX::Network::Replicator::vftable;
  *param_1 = RBX::Network::Replicator::vftable;
  param_1[0x19] = RBX::Network::Replicator::vftable;
  param_1[0x1a] = RBX::Network::Replicator::vftable;
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Replicator destroyed: %p",param_1);
  }
  FUN_00612c70();
  piVar2 = (int *)param_1[0xe3e];
  if (piVar2 != (int *)0x0) {
    uStack_8 = 0;
    FUN_016899e0();
    puVar3 = (undefined4 *)*piVar2;
    if (puVar3 != (undefined4 *)0x0) {
      LOCK();
      iVar6 = puVar3[1] + -1;
      puVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*puVar3)(0);
        uVar4 = GetProcessHeap(0,puVar3);
        HeapFree(uVar4);
      }
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0xe3d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006113b0();
  FUN_0056c7e0();
  FUN_0056c7e0();
  LOCK();
  iVar6 = param_1[0xe2d];
  param_1[0xe2d] = 0;
  UNLOCK();
  if (iVar6 != 0) {
    CloseHandle(iVar6);
  }
  FUN_0151f390();
  uStack_8 = 1;
  FUN_01679490();
  iVar6 = param_1[0xe2a];
  if (iVar6 != 0) {
    piVar2 = (int *)(iVar6 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar6);
    }
  }
  piVar2 = (int *)param_1[0xe27];
  uStack_8 = 0xffffffff;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = param_1[0xe22];
  if (iVar6 != 0) {
    uVar7 = (param_1[0xe24] - iVar6 >> 2) * 4;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) goto LAB_00613bf5;
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0xe22] = 0;
    param_1[0xe23] = 0;
    param_1[0xe24] = 0;
  }
  iVar6 = param_1[0xe1f];
  if (iVar6 != 0) {
    uVar7 = (param_1[0xe21] - iVar6 >> 2) * 4;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) goto LAB_00613bf5;
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0xe1f] = 0;
    param_1[0xe20] = 0;
    param_1[0xe21] = 0;
  }
  iVar6 = param_1[0xe1c];
  if (iVar6 != 0) {
    uVar7 = (param_1[0xe1e] - iVar6 >> 2) * 4;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) goto LAB_00613bf5;
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0xe1c] = 0;
    param_1[0xe1d] = 0;
    param_1[0xe1e] = 0;
  }
  piVar2 = (int *)param_1[0xe17];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xe15];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xe13];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00612170();
  FUN_006120e0();
  FUN_00611f60();
  FUN_00611f60();
  FUN_00612650();
  FUN_00610df0();
  FUN_00611470();
  FUN_00611300();
  LOCK();
  iVar6 = param_1[0x7c2];
  param_1[0x7c2] = 0;
  UNLOCK();
  if (iVar6 != 0) {
    CloseHandle(iVar6);
  }
  FUN_006123a0();
  FUN_0061a9e0();
  FUN_006122a0();
  FUN_0061ab40();
  FUN_00612320();
  FUN_016dedfb(param_1 + 0x794);
  FUN_006126f0();
  FUN_00612460();
  FUN_006b1b80();
  FUN_006b1b80();
  piVar2 = (int *)param_1[0x77a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x778];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x776];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x774];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x772];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006baa90();
  FUN_0061ac80();
  FUN_00610ff0();
  iVar6 = param_1[0x689];
  uStack_8 = 2;
  if (iVar6 != 0) {
    uVar7 = param_1[0x688];
    do {
      uVar7 = (uVar7 + 1) % (uint)param_1[0x687];
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
    param_1[0x689] = 0;
    param_1[0x688] = uVar7;
  }
  FUN_01674ea0(param_1[0x68a]);
  if (param_1[0x685] != 0) {
    FUN_006157e0(1);
  }
  FUN_00612580();
  piVar2 = (int *)param_1[0x65b];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x65a];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x659];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x658];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x657];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x656];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x655];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x654];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x653];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x652];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00612a40();
  iVar6 = param_1[0x647];
  if (iVar6 != 0) {
    uVar7 = param_1[0x649] - iVar6 & 0xfffffff0;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) {
LAB_00613bf5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0x647] = 0;
    param_1[0x648] = 0;
    param_1[0x649] = 0;
  }
  piVar2 = (int *)param_1[0x642];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x63d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00613260();
  FUN_00613260();
  FUN_00613140();
  piVar2 = (int *)param_1[0x1c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x1a] = RBX::Voxel2::GridListener::vftable;
  param_1[0x19] = RBX::IMetric::vftable;
  FUN_006bcd30();
  FUN_00611620();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7915 ; VA 0x006781f0 ; FUN_006781f0 */

void FUN_006781f0(void)

{
  FUN_00611300();
  FUN_006784e0();
  return;
}



/* FUNCTION 7916 ; VA 0x00678210 ; FUN_00678210 */

void __fastcall FUN_00678210(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x78);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x80,param_1 + 0x80,2);
      }
    }
    *(undefined4 *)(param_1 + 0x78) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7917 ; VA 0x006782c0 ; FUN_006782c0 */

void __fastcall FUN_006782c0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x006782d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 7918 ; VA 0x006782e0 ; FUN_006782e0 */

void __fastcall FUN_006782e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0067830f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 7919 ; VA 0x00678320 ; FUN_00678320 */

void FUN_00678320(void)

{
  FUN_005d11a0();
  return;
}



/* FUNCTION 7920 ; VA 0x00678330 ; FUN_00678330 */

void __fastcall FUN_00678330(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[4];
  if (iVar1 != 0) {
    do {
      iVar1 = iVar1 + -1;
      param_1[4] = iVar1;
    } while (iVar1 != 0);
    param_1[3] = 0;
  }
  iVar1 = param_1[2];
  while (iVar1 != 0) {
    iVar1 = iVar1 + -1;
    iVar2 = *(int *)(param_1[1] + iVar1 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x18);
    }
  }
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 7921 ; VA 0x006783e0 ; thunk_FUN_005d11a0 */

void __fastcall thunk_FUN_005d11a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x005d11f9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 7922 ; VA 0x006783f0 ; FUN_006783f0 */

void __fastcall FUN_006783f0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar3 = (int *)piVar4[5];
      piVar1 = (int *)*piVar4;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = (int *)piVar4[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x20);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x20);
  return;
}



/* FUNCTION 7923 ; VA 0x00678490 ; FUN_00678490 */

void __fastcall FUN_00678490(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_005cf430(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x40);
  }
  return;
}



/* FUNCTION 7924 ; VA 0x006784c0 ; FUN_006784c0 */

void __fastcall FUN_006784c0(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x30);
  }
  return;
}



/* FUNCTION 7925 ; VA 0x006784e0 ; FUN_006784e0 */

void __fastcall FUN_006784e0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0067859d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x40);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0067859d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7926 ; VA 0x006785b0 ; FUN_006785b0 */

void __fastcall FUN_006785b0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7927 ; VA 0x00678630 ; FUN_00678630 */

void __fastcall FUN_00678630(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar1,4);
  }
  return;
}



/* FUNCTION 7928 ; VA 0x00678650 ; FUN_00678650 */

void __fastcall FUN_00678650(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0067859d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x40);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0067859d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7929 ; VA 0x00678660 ; FUN_00678660 */

void __fastcall FUN_00678660(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7930 ; VA 0x00678670 ; FUN_00678670 */

void __fastcall FUN_00678670(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x34) * 0x34;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7931 ; VA 0x006786e0 ; FUN_006786e0 */

void __fastcall FUN_006786e0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 7932 ; VA 0x00678740 ; FUN_00678740 */

void FUN_00678740(void)

{
  FUN_00678330();
  FUN_006785b0();
  return;
}



/* FUNCTION 7933 ; VA 0x00678760 ; FUN_00678760 */

void __fastcall FUN_00678760(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::ServerReplicator::vftable;
  param_1[0x17] = RBX::Network::ServerReplicator::vftable;
  param_1[0x19] = RBX::Network::ServerReplicator::vftable;
  param_1[0x1a] = RBX::Network::ServerReplicator::vftable;
  if (*(char *)(param_1 + 0xe18) != '\0') {
    FUN_0062eb80();
  }
  iVar2 = param_1[0xf50];
  if (iVar2 != 0) {
    uVar8 = (param_1[0xf52] - iVar2 >> 2) * 4;
    iVar5 = iVar2;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00678b27;
    }
    FUN_01674ea0(iVar5,uVar8);
    param_1[0xf50] = 0;
    param_1[0xf51] = 0;
    param_1[0xf52] = 0;
  }
  iVar2 = param_1[0xf46];
  if (iVar2 != 0) {
    uVar8 = (param_1[0xf48] - iVar2 >> 2) * 4;
    iVar5 = iVar2;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00678b27;
    }
    FUN_01674ea0(iVar5,uVar8);
    param_1[0xf46] = 0;
    param_1[0xf47] = 0;
    param_1[0xf48] = 0;
  }
  iVar2 = param_1[0xf3f];
  if (iVar2 != 0) {
    uVar8 = (param_1[0xf41] - iVar2 >> 2) * 4;
    iVar5 = iVar2;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00678b27;
    }
    FUN_01674ea0(iVar5,uVar8);
    param_1[0xf3f] = 0;
    param_1[0xf40] = 0;
    param_1[0xf41] = 0;
  }
  uVar8 = param_1[0xf1d];
  if (0xf < uVar8) {
    iVar2 = param_1[0xf18];
    uVar7 = uVar8 + 1;
    iVar5 = iVar2;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00678b27;
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  param_1[0xf1c] = 0;
  param_1[0xf1d] = 0xf;
  *(undefined *)(param_1 + 0xf18) = 0;
  piVar3 = (int *)param_1[0xf17];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar8 = param_1[0xf15];
  if (0xf < uVar8) {
    iVar2 = param_1[0xf10];
    uVar7 = uVar8 + 1;
    iVar5 = iVar2;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar2 - iVar5) - 4U) {
LAB_00678b27:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  param_1[0xf14] = 0;
  param_1[0xf15] = 0xf;
  *(undefined *)(param_1 + 0xf10) = 0;
  piVar3 = (int *)param_1[0xf0e];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0xf08];
  if (piVar3 != (int *)0x0) {
    uStack_8 = 0;
    FUN_016899e0();
    puVar4 = (undefined4 *)*piVar3;
    if (puVar4 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = puVar4[1] + -1;
      puVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*puVar4)(0);
        uVar6 = GetProcessHeap(0,puVar4);
        HeapFree(uVar6);
      }
    }
    FUN_01674ea0(piVar3,4);
  }
  piVar3 = (int *)param_1[0xf06];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0xf04];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0151f7f0();
  piVar3 = (int *)param_1[0xeec];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0xee6];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar2 = param_1[0xee4];
  if (iVar2 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar2,4);
  }
  FUN_00611300();
  FUN_006784e0();
  FUN_00678330();
  FUN_006785b0();
  FUN_006133f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7934 ; VA 0x00678b30 ; FUN_00678b30 */

void __fastcall FUN_00678b30(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x214);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x20c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x204);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1fc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 500);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00678c10();
  return;
}



/* FUNCTION 7935 ; VA 0x00678c10 ; FUN_00678c10 */

void __fastcall FUN_00678c10(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x1e4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0x1dc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1d4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1cc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1c4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1bc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1b4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1ac);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1a4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x19c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x194);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x18c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x184);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x17c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x174);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x16c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x164);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x15c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x154);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x14c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x144);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x13c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x134);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x124);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x11c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x114);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x10c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x104);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xfc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xf4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xec);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xe4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xdc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xd4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xcc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xbc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xb4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xac);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xa4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x9c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x94);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x8c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x84);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x7c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x60);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 7936 ; VA 0x006793c0 ; FUN_006793c0 */

int __thiscall FUN_006793c0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a46b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_24);
  uStack_8 = 0;
  if (iStack_24 != 0) {
    if (param_2 == 1) {
      *(undefined4 *)(iStack_24 + 0x3d68) = 2;
      iVar4 = FUN_0067fc40(param_1[2],param_1[3]);
    }
    else {
      iVar4 = param_2 + -2;
      if ((iVar4 == 0) && (*(undefined4 *)(iStack_24 + 0x3d68) = 1, DAT_01d5af10 != '\0')) {
        FUN_008f7870(iStack_24);
        uStack_18 = FUN_00671e00();
        piVar5 = (int *)param_1[1];
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
          piVar5 = (int *)param_1[1];
        }
        uVar6 = param_1[2];
        uVar3 = *param_1;
        uVar7 = param_1[3];
        piVar1 = piVar5 + 2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uVar8 = 0;
        if (piVar5 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uStack_14 = uVar7;
        FUN_00670320(uVar3,piVar5,uVar6,uVar7);
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar4 = *piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            uVar7 = 0x6794b2;
            (**(code **)(*piVar5 + 4))(uVar8);
          }
          LOCK();
          iVar4 = *piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            uVar7 = 0x6794c1;
            (**(code **)(*piVar5 + 4))();
          }
        }
        FUN_00557fc0(iStack_24 + 0x3c0c);
        iVar4 = FUN_00bdee80(uVar6,uVar7,uVar8);
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_20 + 1;
    iVar2 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_20)();
      LOCK();
      piVar5 = piStack_20 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7937 ; VA 0x0067952b ; FUN_0067952b */

void FUN_0067952b(void)

{
  FUN_00679a80();
  return;
}



/* FUNCTION 7938 ; VA 0x00679533 ; FUN_00679533 */

void FUN_00679533(void)

{
  FUN_00679a80();
  return;
}



/* FUNCTION 7939 ; VA 0x0067953b ; FUN_0067953b */

void FUN_0067953b(void)

{
  FUN_00679a80();
  return;
}



/* FUNCTION 7940 ; VA 0x00679550 ; FUN_00679550 */

int __thiscall FUN_00679550(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 7941 ; VA 0x006795b0 ; FUN_006795b0 */

int __thiscall FUN_006795b0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x78);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x80,param_1 + 0x80,2);
      }
    }
    *(undefined4 *)(param_1 + 0x78) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7942 ; VA 0x00679680 ; FUN_00679680 */

undefined4 __thiscall FUN_00679680(undefined4 param_1,byte param_2)

{
  FUN_00678210();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  return param_1;
}



/* FUNCTION 7943 ; VA 0x006796b0 ; FUN_006796b0 */

int __thiscall FUN_006796b0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x4c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0x44);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 7944 ; VA 0x00679710 ; FUN_00679710 */

int __thiscall FUN_00679710(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7945 ; VA 0x00679780 ; FUN_00679780 */

int __thiscall FUN_00679780(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  iVar2 = *(int *)(param_1 + 0x18);
  if (iVar2 != 0) {
    uVar5 = ((*(int *)(param_1 + 0x20) - iVar2) / 0x34) * 0x34;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 7946 ; VA 0x00679830 ; FUN_00679830 */

int * __thiscall FUN_00679830(int *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0x1d];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01674ea0(param_1[3]);
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar4 = ((param_1[2] - iVar3) / 0xc) * 0xc;
    iVar5 = iVar3;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7947 ; VA 0x00679930 ; FUN_00679930 */

int __thiscall FUN_00679930(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = *(int **)(param_1 + 0x1c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 8);
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*(int *)(param_1 + 8) + 4) = *(int *)(param_1 + 8);
  *(undefined4 *)(param_1 + 0xc) = 0;
  piVar3 = *(int **)(param_1 + 8);
  if (piVar4 != piVar3) {
    do {
      piVar3 = (int *)piVar4[5];
      piVar1 = (int *)*piVar4;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = (int *)piVar4[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x20);
      piVar3 = *(int **)(param_1 + 8);
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x20);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 7948 ; VA 0x00679a20 ; FUN_00679a20 */

int __thiscall FUN_00679a20(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 7949 ; VA 0x00679a80 ; FUN_00679a80 */

undefined4 __thiscall FUN_00679a80(undefined4 param_1,byte param_2)

{
  FUN_00678760();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3d70);
  }
  return param_1;
}



/* FUNCTION 7950 ; VA 0x00679ab0 ; FUN_00679ab0 */

undefined4 __thiscall FUN_00679ab0(undefined4 param_1,byte param_2)

{
  FUN_00678b30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x218);
  }
  return param_1;
}



/* FUNCTION 7951 ; VA 0x00679ae0 ; FUN_00679ae0 */

undefined4 * __thiscall FUN_00679ae0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 7952 ; VA 0x00679b10 ; FUN_00679b10 */

void __thiscall
FUN_00679b10(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  undefined4 *puVar1;
  undefined auStack_c [8];
  
  puVar1 = (undefined4 *)FUN_016830f0(auStack_c);
  *(undefined4 *)(param_1 + 0x3c1c) = *puVar1;
  *(undefined4 *)(param_1 + 0x3c20) = puVar1[1];
  FUN_006159a0(param_2,param_3,param_4,param_5,param_6,param_7);
  return;
}



/* FUNCTION 7953 ; VA 0x00679b60 ; FUN_00679b60 */

undefined4 __thiscall FUN_00679b60(int param_1,int param_2)

{
  int ****ppppiVar1;
  int **ppiVar2;
  int *****pppppiVar3;
  int ****ppppiVar4;
  undefined4 uVar5;
  ulonglong uVar6;
  char cVar7;
  undefined uVar8;
  undefined4 uVar9;
  double *pdVar10;
  undefined4 *puVar11;
  undefined *puVar12;
  int ***pppiVar13;
  int iVar14;
  undefined4 uVar15;
  uint uVar16;
  int *piVar17;
  float10 fVar18;
  undefined4 uStack_1c4;
  undefined *puStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined4 uStack_1b0;
  undefined *puStack_1ac;
  undefined4 uStack_1a8;
  undefined auStack_1a4 [4];
  undefined4 uStack_1a0;
  int ***pppiStack_19c;
  code *pcStack_198;
  int ***pppiStack_194;
  int *piStack_190;
  int **ppiStack_18c;
  char *pcStack_188;
  int ****ppppiStack_184;
  undefined8 uStack_180;
  undefined auStack_16c [52];
  undefined **appuStack_138 [2];
  undefined auStack_130 [24];
  int ***apppiStack_118 [2];
  int ***pppiStack_110;
  int *piStack_10c;
  int **ppiStack_108;
  undefined4 uStack_104;
  int *piStack_100;
  uint uStack_fc;
  int ***pppiStack_ec;
  int ***pppiStack_e4;
  int *piStack_e0;
  int **ppiStack_dc;
  undefined4 uStack_d8;
  int *piStack_d4;
  undefined4 uStack_d0;
  int ***pppiStack_cc;
  int ***pppiStack_c4;
  int *piStack_c0;
  int **ppiStack_bc;
  undefined4 uStack_b8;
  int *piStack_b4;
  uint uStack_b0;
  undefined4 uStack_ac;
  int iStack_a8;
  int *piStack_a4;
  int ****ppppiStack_a0;
  undefined4 uStack_9c;
  code *apcStack_98 [2];
  int *piStack_90;
  int *piStack_8c;
  int ****ppppiStack_88;
  undefined4 uStack_84;
  undefined *puStack_80;
  int iStack_7c;
  int ****ppppiStack_78;
  uint uStack_74;
  undefined auStack_70 [8];
  int ***pppiStack_68;
  int iStack_64;
  int iStack_5c;
  uint uStack_58;
  uint uStack_50;
  uint uStack_48;
  int *piStack_44;
  char acStack_40 [4];
  undefined4 uStack_3c;
  int *piStack_38;
  float fStack_34;
  int **ppiStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  char acStack_18 [4];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4835;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe88;
  uStack_28 = 0;
  uStack_180._4_4_ = (char *)DAT_01eadc98;
  uStack_24 = 0;
  uStack_180._0_4_ = (char *)0x679b9f;
  ExceptionList = &pvStack_10;
  iStack_a8 = param_1;
  uVar9 = FUN_01675290();
  uStack_180._4_4_ = (char *)(param_1 + 0x18);
  uStack_8 = 0;
  uStack_180._0_4_ = (undefined *)0x679bbf;
  uStack_ac = uVar9;
  cVar7 = FUN_005f7260();
  if (cVar7 != '\0') {
    uStack_8 = 1;
    uStack_180._0_4_ = (char *)0x679bd0;
    uStack_180._4_4_ = (char *)uVar9;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 1;
  }
  puVar12 = *(undefined **)(param_2 + 0x38);
  uStack_8._0_1_ = 2;
  switch(*puVar12) {
  case 0xe:
    if ((DAT_01d5aed0 != '\0') && (*(char *)(param_1 + 0x3cf0) == '\0')) {
      uStack_180._4_4_ = (char *)0x0;
      uStack_180._0_4_ = (undefined *)0x679c2d;
      FUN_00680f20();
    }
    uStack_8 = 3;
    uStack_180._4_4_ = (char *)uVar9;
    uVar9 = FUN_0067abb3();
    return uVar9;
  default:
    uStack_180._4_4_ = (char *)param_2;
    uStack_180._0_4_ = (char *)0x67ab1a;
    uVar15 = FUN_00615a90();
    uStack_8 = 0x34;
    uStack_180._0_4_ = (char *)0x67ab29;
    uStack_180._4_4_ = (char *)uVar9;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar15;
  case 0x13:
    uStack_180._4_4_ = (char *)0x679c45;
    FUN_006ab530();
    uStack_180._4_4_ = (char *)0x1;
    uStack_180._0_4_ = acStack_18;
    uStack_8._0_1_ = 4;
    acStack_18[0] = -0x6d;
    ppppiStack_184 = (int ****)0x679c5b;
    FUN_006ad5e0();
    uStack_180._4_4_ = (char *)0x1;
    uStack_180._0_4_ = acStack_18;
    acStack_18[0] = '\0';
    ppppiStack_184 = (int ****)0x679c6d;
    FUN_006ad5e0();
    uStack_180._4_4_ = auStack_70;
    uStack_180._0_4_ = "j";
    (**(code **)(*(int *)(param_1 + -0x5c) + 0x1b0))();
    uStack_180._0_4_ = (char *)0x0;
    iStack_1b4 = 0x679c89;
    FUN_005f70a0();
    iStack_1b4 = 0x679c91;
    FUN_005f7140();
    uStack_1b0 = DAT_01d5ae88;
    puStack_1ac = (undefined *)DAT_01d5ae8c;
    uStack_1a8 = CONCAT22(uStack_1a8._2_2_,DAT_01d5ae90);
    iStack_1b4 = param_1 + 0x18;
    uStack_1b8 = 0x679cb6;
    FUN_005f7170();
    iStack_1b4 = 0;
    uStack_1b8 = 3;
    uStack_1bc = 2;
    puStack_1c0 = auStack_70;
    uStack_1c4 = 0x679cc7;
    FUN_00681340();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (iStack_64 != 0) {
      uStack_180._0_4_ = (char *)(iStack_5c - iStack_64);
      iVar14 = iStack_64;
      if (0xfff < (char *)uStack_180) {
        iVar14 = *(int *)(iStack_64 + -4);
        uStack_180._0_4_ = (char *)((int)(char *)uStack_180 + 0x23);
        if (0x1f < (iStack_64 - iVar14) - 4U) {
                    /* WARNING: Subroutine does not return */
          uStack_180._0_4_ = (char *)0x67abd5;
          FUN_017167a3();
        }
      }
      pcStack_188 = (char *)0x679cfc;
      ppppiStack_184 = (int ****)iVar14;
      FUN_01674ea0();
    }
    uStack_8 = 5;
    ppppiStack_184 = (int ****)0x679d0c;
    uStack_180._0_4_ = (char *)uVar9;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 1;
  case 0x15:
  case 0x16:
    if ((DAT_01d5aed0 != '\0') && (*(char *)(param_1 + 0x3cf0) == '\0')) {
      uStack_180._4_4_ = (char *)0x1;
      uStack_180._0_4_ = (undefined *)0x67aa21;
      FUN_00680f20();
    }
  case 0x87:
  case 0x88:
  case 0x8b:
  case 0x8c:
    puStack_20 = (undefined *)(float)DAT_01d5ae54;
    fStack_34 = (float)DAT_01eadc60;
    if (((NAN((float)puStack_20) || NAN(*(float *)(param_1 + 0x3d00))) ==
         ((float)puStack_20 == *(float *)(param_1 + 0x3d00))) ||
       ((NAN(fStack_34) || NAN(*(float *)(param_1 + 0x3d04))) ==
        (fStack_34 == *(float *)(param_1 + 0x3d04)))) {
      uStack_180._4_4_ = (char *)0x67aa60;
      fVar18 = (float10)FUN_0061f160();
      piStack_1c = (int *)(float)fVar18;
      if (*(float *)(param_1 + 0x3d00) < (float)piStack_1c) {
        *(float *)(param_1 + 0x3cfc) = *(float *)(param_1 + 0x3d00);
      }
      *(undefined **)(param_1 + 0x3d00) = puStack_20;
      *(float *)(param_1 + 0x3d04) = fStack_34;
    }
    uStack_180._4_4_ = (char *)0x3f800000;
    uStack_180._0_4_ = (char *)0x67aaa1;
    cVar7 = FUN_00618e60();
    if (cVar7 == '\0') {
      uStack_8 = 0x32;
      uStack_180._4_4_ = (char *)uVar9;
      uVar9 = FUN_0067abb3();
      return uVar9;
    }
    uStack_180._4_4_ = (char *)param_2;
    uStack_180._0_4_ = (char *)0x67aaad;
    uVar15 = FUN_00615a90();
    uStack_8 = 0x31;
    uStack_180._0_4_ = (char *)0x67aabc;
    uStack_180._4_4_ = (char *)uVar9;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar15;
  case 0x8f:
    uStack_180._4_4_ = (char *)0x0;
    uStack_180._0_4_ = *(char **)(param_2 + 0x30);
    pcStack_188 = (char *)0x679d35;
    ppppiStack_184 = (int ****)puVar12;
    FUN_006ab380();
    uStack_180._4_4_ = (char *)0x1;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uStack_180._0_4_ = (char *)0x679d43;
    FUN_006ab660();
    uStack_180._4_4_ = auStack_70;
    ppppiStack_184 = (int ****)0x679d53;
    uStack_180._0_4_ = (char *)(param_1 + 0x3c04);
    FUN_006ab8e0();
    if (DAT_01ee4213 != 0) {
      ppppiStack_184 = (int ****)(uint)DAT_01ee4213;
      uStack_180._0_4_ = "initialSpawnName: %s";
      pcStack_188 = (char *)0x679d6e;
      uStack_180._4_4_ = (char *)(param_1 + 0x3c04);
      FUN_01677760();
    }
    uStack_180._4_4_ = (char *)0x679d79;
    FUN_00613200();
    uStack_8 = 7;
    uStack_180._4_4_ = (char *)uVar9;
    uVar9 = FUN_0067abb3();
    return uVar9;
  case 0x90:
    if (*(char *)(param_1 + 0x3bd1) != '\0') {
      if (((DAT_01eadc5c & 0x44) != 0) && (*(char *)(param_1 + 0x3bd3) == '\0')) {
        uStack_180._4_4_ = (char *)0x0;
        uStack_180._0_4_ = (undefined *)0x0;
        ppppiStack_184 = (int ****)0x0;
        pcStack_188 = "protocol";
        ppiStack_18c = (int **)0x18d2004;
        piStack_190 = (int *)&DAT_018c5f98;
        pppiStack_194 = (int ***)0x67a2d6;
        FUN_0087c450();
        *(undefined *)(param_1 + 0x3bd3) = 1;
      }
      if ((DAT_01eadc5c & 4) != 0) {
        uStack_8 = 0x1b;
        uStack_180._4_4_ = (char *)uVar9;
        uVar9 = FUN_0067abb3();
        return uVar9;
      }
    }
    uStack_180._4_4_ = (char *)0x0;
    *(undefined *)(param_1 + 0x3bd1) = 1;
    uStack_180._0_4_ = *(char **)(param_2 + 0x30);
    ppppiStack_184 = *(int *****)(param_2 + 0x38);
    pcStack_188 = (char *)0x67a30d;
    FUN_006ab380();
    uStack_180._4_4_ = (char *)0x1;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
    uStack_180._0_4_ = (char *)0x67a31b;
    FUN_006ab660();
    if (*(char *)(param_1 + 0x3804) != '\0') {
      uStack_180._4_4_ = acStack_40;
      uStack_180._0_4_ = (char *)0x67a32d;
      pdVar10 = (double *)FUN_016830f0();
      *(double *)(param_1 + 0x380c) = (*pdVar10 - *(double *)(param_1 + 0x3c1c)) * DAT_018c0d70;
    }
    uStack_180._4_4_ = auStack_70;
    uStack_180._0_4_ = (char *)0x67a355;
    FUN_006c4970();
    uStack_180._4_4_ = (char *)0x67a360;
    uVar8 = FUN_006abe40();
    puStack_20 = (undefined *)CONCAT31(puStack_20._1_3_,uVar8);
    uStack_180._4_4_ = (char *)0x67a36b;
    uVar15 = FUN_006ac4d0();
    *(undefined4 *)(param_1 + 0x3b5c) = uVar15;
    if ((*(uint *)(param_1 + 0x37ac) & 0x800) != 0) {
      uStack_180._4_4_ = (char *)0x67a389;
      uVar8 = FUN_006abe40();
      *(undefined *)(param_1 + 0x3be0) = uVar8;
    }
    if (*(byte *)(param_1 + 0x3be0) != 1) {
      if (DAT_01ee4213 != 0) {
        uStack_180._4_4_ = (char *)(uint)*(byte *)(param_1 + 0x3be0);
        ppppiStack_184 = (int ****)(uint)DAT_01ee4213;
        uStack_180._0_4_ = "Unsupported Luau version requested: %d";
        pcStack_188 = (char *)0x67a3b5;
        FUN_016774b0();
      }
      uStack_180._4_4_ = (char *)0x106;
      uStack_180._0_4_ = (char *)0x67a3c5;
      FUN_0062b590();
      uStack_180._4_4_ = (char *)0x67a3cd;
      FUN_00613200();
      uStack_8 = 0x1d;
      uStack_180._4_4_ = (char *)uVar9;
      uVar9 = FUN_0067abb3();
      return uVar9;
    }
    if (uStack_50 < uStack_58) {
      uStack_180._4_4_ = (char *)0x67a3ea;
      uVar16 = FUN_006acdc0();
      piStack_1c = (int *)(uVar16 & 0xffff);
      for (iVar14 = 0; iVar14 < (int)((uint)piStack_1c & 0xffff); iVar14 = iVar14 + 1) {
        puStack_80 = (undefined *)0x0;
        iStack_7c = 0xf;
        piStack_90 = (int *)((uint)piStack_90 & 0xffffff00);
        uStack_180._4_4_ = auStack_70;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
        uStack_180._0_4_ = (char *)&piStack_90;
        ppppiStack_184 = (int ****)0x67a422;
        FUN_006ab8e0();
        uStack_180._0_4_ = (char *)&piStack_90;
        ppppiStack_184 = (int ****)acStack_40;
        pcStack_188 = (char *)0x67a43c;
        uStack_180._4_4_ = (char *)uStack_180;
        FUN_00676530();
        uStack_180._4_4_ = (char *)0x67a447;
        FUN_005507b0();
      }
    }
    *(undefined *)(param_1 + 0x199c) = 1;
    *(undefined *)(param_1 + 0x3bac) = 1;
    piStack_d4 = (int *)0x0;
    uStack_d0 = 0xf;
    pppiStack_e4 = (int ***)((uint)pppiStack_e4 & 0xffffff00);
    uStack_180._4_4_ = auStack_70;
    uStack_8._0_1_ = 0x1f;
    uStack_180._0_4_ = (char *)&pppiStack_e4;
    ppppiStack_184 = (int ****)0x67a48a;
    FUN_006ab8e0();
    if (DAT_01d5af20 == '\0') {
      uStack_180._0_4_ = (char *)&uStack_48;
      ppppiStack_184 = (int ****)0x67a4d8;
      uStack_180._4_4_ = (char *)&pppiStack_e4;
      uStack_180._4_4_ = (char *)FUN_00977a10();
      uStack_8._0_1_ = 0x21;
    }
    else {
      uStack_180._4_4_ = (char *)0x0;
      pcStack_188 = (char *)0x67a4ab;
      ppppiStack_184 = &pppiStack_e4;
      uStack_180._0_4_ = (char *)(param_1 + 0x3bd8);
      cVar7 = FUN_0098f070();
      if (cVar7 == '\0') goto LAB_0067a509;
      uStack_180._0_4_ = (char *)&uStack_48;
      ppppiStack_184 = (int ****)0x67a4c2;
      uStack_180._4_4_ = (char *)(param_1 + 0x3bd8);
      uStack_180._4_4_ = (char *)FUN_00977710();
      uStack_8._0_1_ = 0x20;
    }
    uStack_180._0_4_ = acStack_40;
    ppppiStack_184 = (int ****)0x67a4e6;
    uStack_180._4_4_ = (char *)FUN_006773f0();
    uStack_180._0_4_ = (char *)0x67a4f5;
    FUN_005587e0();
    uStack_180._4_4_ = (char *)0x67a4fd;
    FUN_00550b30();
    uStack_8._0_1_ = 0x1f;
    uStack_180._4_4_ = (char *)0x67a509;
    FUN_00550b30();
LAB_0067a509:
    uStack_180._4_4_ = *(char **)(param_1 + 0x3bfc);
    if (uStack_180._4_4_ != (char *)0x0) {
      uStack_180._4_4_ = (char *)0x67a560;
      uStack_180._4_4_ = (char *)thunk_FUN_00676db0();
      uStack_180._0_4_ = acStack_40;
      ppppiStack_184 = (int ****)0x67a56a;
      puVar11 = (undefined4 *)FUN_0060dcd0();
      uVar15 = *puVar11;
      uVar5 = puVar11[1];
      *puVar11 = 0;
      puVar11[1] = 0;
      *(undefined4 *)(param_1 + 0x3bb8) = uVar15;
      piStack_1c = *(int **)(param_1 + 0x3bbc);
      *(undefined4 *)(param_1 + 0x3bbc) = uVar5;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar14 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          uStack_180._4_4_ = (char *)0x67a5a8;
          (**(code **)*piStack_1c)();
          LOCK();
          piVar17 = piStack_1c + 2;
          iVar14 = *piVar17;
          *piVar17 = *piVar17 + -1;
          UNLOCK();
          if (iVar14 == 1) {
            uStack_180._4_4_ = (char *)0x67a5b8;
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      uStack_180._4_4_ = (char *)0x67a5c0;
      FUN_00550b30();
      uStack_180._4_4_ = auStack_70;
      uStack_180._0_4_ = puStack_20;
      ppppiStack_184 = (int ****)0x67a5d3;
      (**(code **)(*(int *)(param_1 + -0x5c) + 0x298))();
      ppppiStack_184 = (int ****)0x67a5de;
      FUN_005507b0();
      ppppiStack_184 = (int ****)0x67a5e6;
      FUN_00613200();
      uStack_8 = 0x23;
      ppppiStack_184 = (int ****)uVar9;
      uVar9 = FUN_0067abb3();
      return uVar9;
    }
    if (DAT_01ee4213 != 0) {
      ppppiStack_184 = (int ****)(uint)DAT_01ee4213;
      uStack_180._0_4_ = "Player Creation Error";
      pcStack_188 = (char *)0x67a52b;
      FUN_016774b0();
    }
    uStack_180._4_4_ = (char *)0x106;
    uStack_180._0_4_ = (char *)0x67a53b;
    FUN_0062b590();
    uStack_180._4_4_ = (char *)0x67a546;
    FUN_005507b0();
    uStack_180._4_4_ = (char *)0x67a54e;
    FUN_00613200();
    uStack_8 = 0x22;
    uStack_180._4_4_ = (char *)uVar9;
    uVar9 = FUN_0067abb3();
    return uVar9;
  case 0x92:
    if (*(char *)(param_1 + 0x3bd2) != '\0') {
      if (((DAT_01eadc5c & 0x22) != 0) && (*(char *)(param_1 + 0x3bd4) == '\0')) {
        uStack_180._4_4_ = (char *)0x0;
        uStack_180._0_4_ = (undefined *)0x0;
        ppppiStack_184 = (int ****)0x0;
        pcStack_188 = "PlaceId";
        ppiStack_18c = (int **)0x18d2004;
        piStack_190 = (int *)&DAT_018c5f98;
        pppiStack_194 = (int ***)0x679dbb;
        FUN_0087c450();
        *(undefined *)(param_1 + 0x3bd4) = 1;
      }
      if ((DAT_01eadc5c & 2) != 0) {
        uStack_8 = 8;
        uStack_180._4_4_ = (char *)uVar9;
        uVar9 = FUN_0067abb3();
        return uVar9;
      }
    }
    uStack_180._4_4_ = (char *)0x0;
    *(undefined *)(param_1 + 0x3bd2) = 1;
    uStack_180._0_4_ = *(char **)(param_2 + 0x30);
    ppppiStack_184 = *(int *****)(param_2 + 0x38);
    pcStack_188 = (char *)0x679df5;
    FUN_006ab380();
    uStack_180._4_4_ = (char *)0x1;
    uStack_8._0_1_ = 9;
    uStack_180._0_4_ = (char *)0x679e06;
    FUN_006ab660();
    uStack_180._4_4_ = auStack_16c;
    uStack_180._0_4_ = (char *)&ppppiStack_a0;
    ppppiStack_184 = (int ****)0x679e19;
    FUN_006ab860();
    uStack_180._4_4_ = (char *)0x679e2c;
    cVar7 = (**(code **)(*(int *)(param_1 + -0x5c) + 0x124))();
    if (cVar7 == '\0') {
      uStack_180._4_4_ = (char *)uStack_9c;
      ppppiStack_184 = (int ****)acStack_40;
      uStack_180._0_4_ = (char *)ppppiStack_a0;
      pcStack_188 = (char *)0x679e5a;
      FUN_00644a60();
      uStack_8._0_1_ = 10;
      if (acStack_40[0] == '\0') {
        uStack_180._0_4_ = (char *)0x679e78;
        uStack_180._4_4_ = (char *)(param_1 + -0x5c);
        iVar14 = FUN_008f7870();
        piStack_1c = *(int **)(iVar14 + 0x43c);
        puStack_20 = (undefined *)(*piStack_1c - (int)piStack_1c);
        piStack_1c = (int *)(piStack_1c[1] - (int)piStack_1c);
        ppppiStack_78 = ppppiStack_a0;
        fStack_34 = (float)uStack_9c;
        uStack_180._0_4_ = (char *)&uStack_48;
        ppppiStack_184 = (int ****)0x679eac;
        uStack_180._4_4_ = (char *)(param_1 + -0x5c);
        FUN_0060e0c0();
        if (piStack_44 != (int *)0x0) {
          LOCK();
          piStack_44[2] = piStack_44[2] + 1;
          UNLOCK();
        }
        uStack_74 = uStack_48;
        piStack_a4 = piStack_44;
        piStack_8c = piStack_44;
        if (piStack_44 != (int *)0x0) {
          piStack_38 = piStack_44 + 2;
          piStack_2c = piStack_44;
          LOCK();
          *piStack_38 = *piStack_38 + 1;
          UNLOCK();
          ppiStack_30 = (int **)(piStack_44 + 2);
          LOCK();
          *ppiStack_30 = (int *)((int)*ppiStack_30 + 1);
          UNLOCK();
          LOCK();
          *ppiStack_30 = (int *)((int)*ppiStack_30 + 1);
          UNLOCK();
          LOCK();
          *ppiStack_30 = (int *)((int)*ppiStack_30 + 1);
          UNLOCK();
          LOCK();
          ppiVar2 = (int **)*ppiStack_30;
          *ppiStack_30 = (int *)((int)ppiVar2 + -1);
          UNLOCK();
          if ((int **)((int)ppiVar2 + -1) == (int **)0x0) {
            uStack_180._4_4_ = (char *)0x679efa;
            (**(code **)(*piStack_44 + 4))();
          }
          LOCK();
          ppiVar2 = (int **)*ppiStack_30;
          *ppiStack_30 = (int *)((int)ppiVar2 + -1);
          UNLOCK();
          if ((int **)((int)ppiVar2 + -1) == (int **)0x0) {
            uStack_180._4_4_ = (char *)0x679f0d;
            (**(code **)(*piStack_2c + 4))();
          }
          LOCK();
          ppiVar2 = (int **)*ppiStack_30;
          *ppiStack_30 = (int *)((int)ppiVar2 + -1);
          UNLOCK();
          if ((int **)((int)ppiVar2 + -1) == (int **)0x0) {
            uStack_180._4_4_ = (char *)0x679f20;
            (**(code **)(*piStack_2c + 4))();
          }
          LOCK();
          iVar14 = *piStack_38;
          *piStack_38 = iVar14 + -1;
          UNLOCK();
          piStack_8c = piStack_2c;
          if (iVar14 + -1 == 0) {
            uStack_180._4_4_ = (char *)0x679f36;
            (**(code **)(*piStack_a4 + 4))();
            piStack_8c = piStack_2c;
          }
        }
        apcStack_98[0] = FUN_0067acc0;
        piVar17 = piStack_8c + 2;
        if (piStack_8c != (int *)0x0) {
          LOCK();
          *piVar17 = *piVar17 + 1;
          UNLOCK();
        }
        piStack_90 = (int *)uStack_74;
        ppppiStack_88 = ppppiStack_78;
        uStack_84 = fStack_34;
        puStack_80 = puStack_20;
        iStack_7c = (int)piStack_1c;
        if (piStack_8c != (int *)0x0) {
          LOCK();
          iVar14 = *piVar17;
          *piVar17 = iVar14 + -1;
          UNLOCK();
          if (iVar14 + -1 == 0) {
            uStack_180._4_4_ = (char *)0x679f8d;
            (**(code **)(*piStack_8c + 4))();
          }
        }
        if (piStack_44 != (int *)0x0) {
          LOCK();
          iVar14 = piStack_44[2] + -1;
          piStack_44[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            uStack_180._4_4_ = (char *)0x679fa2;
            (**(code **)(*piStack_44 + 4))();
          }
        }
        uStack_180._4_4_ = (char *)0x4;
        uStack_8._0_1_ = 0xb;
        uStack_180._0_4_ = (char *)0x679fad;
        piStack_2c = (int *)FUN_01674e20();
        piStack_1c = piStack_2c;
        if (piStack_2c == (int *)0x0) {
          piVar17 = (int *)0x0;
          uVar16 = uStack_24;
        }
        else {
          uStack_180._4_4_ = (char *)apcStack_98;
          uStack_180._0_4_ = (char *)0x679fd0;
          FUN_00677610();
          piVar17 = piStack_c0;
          pppiStack_ec = pppiStack_cc;
          if (piStack_c0 != (int *)0x0) {
            LOCK();
            piStack_c0[2] = piStack_c0[2] + 1;
            UNLOCK();
          }
          ppiStack_30 = ppiStack_bc;
          ppiStack_dc = ppiStack_bc;
          uStack_28 = uStack_b8;
          uStack_d8 = uStack_b8;
          piStack_38 = piStack_b4;
          piStack_d4 = piStack_b4;
          pppiStack_e4 = pppiStack_c4;
          piStack_e0 = piStack_c0;
          uStack_24 = uStack_b0;
          uStack_d0 = uStack_b0;
          appuStack_138[0] = (undefined **)0x0;
          apppiStack_118[0] = pppiStack_cc;
          if (piStack_c0 != (int *)0x0) {
            LOCK();
            piStack_c0[2] = piStack_c0[2] + 1;
            UNLOCK();
          }
          ppiStack_108 = ppiStack_bc;
          uStack_104 = uStack_b8;
          piStack_100 = piStack_b4;
          pppiStack_110 = pppiStack_c4;
          piStack_10c = piStack_c0;
          uStack_fc = uStack_b0;
          uStack_180._4_4_ = auStack_130;
          uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
          pppiStack_19c = pppiStack_cc;
          if (piStack_c0 != (int *)0x0) {
            LOCK();
            piStack_c0[2] = piStack_c0[2] + 1;
            UNLOCK();
          }
          pppiStack_194 = pppiStack_c4;
          piStack_190 = piStack_c0;
          ppiStack_18c = ppiStack_bc;
          pcStack_188 = (char *)uStack_b8;
          ppppiStack_184 = (int ****)piStack_b4;
          uStack_180._0_4_ = (char *)uStack_b0;
          uStack_1a0 = 0x67a0d8;
          cVar7 = FUN_00670440();
          appuStack_138[0] = &PTR_FUN_018d62b8;
          if (cVar7 == '\0') {
            appuStack_138[0] = (undefined **)0x0;
          }
          if (piVar17 != (int *)0x0) {
            LOCK();
            iVar14 = piVar17[2] + -1;
            piVar17[2] = iVar14;
            UNLOCK();
            if (iVar14 == 0) {
              uStack_180._4_4_ = (char *)0x67a107;
              (**(code **)(*piVar17 + 4))();
            }
            if (piVar17 != (int *)0x0) {
              LOCK();
              iVar14 = piVar17[2] + -1;
              piVar17[2] = iVar14;
              UNLOCK();
              if (iVar14 == 0) {
                uStack_180._4_4_ = (char *)0x67a11c;
                (**(code **)(*piVar17 + 4))();
              }
            }
          }
          if (piStack_c0 != (int *)0x0) {
            LOCK();
            iVar14 = piStack_c0[2] + -1;
            piStack_c0[2] = iVar14;
            UNLOCK();
            if (iVar14 == 0) {
              uStack_180._4_4_ = (char *)0x67a135;
              (**(code **)(*piStack_c0 + 4))();
            }
          }
          uStack_180._4_4_ = "PlaceAuthenticationThread";
          uStack_180._0_4_ = (char *)appuStack_138;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
          ppppiStack_184 = &pppiStack_68;
          uStack_28 = 1;
          pcStack_188 = (char *)0x67a155;
          uStack_180._4_4_ = (char *)FUN_0151a450();
          uStack_8 = 0x11;
          uStack_28 = 3;
          apppiStack_118[0] = (int ***)0x0;
          uStack_180._0_4_ = (char *)0x67a17c;
          FUN_005880d0();
          uStack_28 = 0x13;
          uStack_180._4_4_ = (char *)apppiStack_118;
          uStack_8 = 0x12;
          uStack_180._0_4_ = (char *)0x67a196;
          iVar14 = FUN_00563bf0();
          *piStack_2c = iVar14;
          if (iVar14 != 0) {
            LOCK();
            *(int *)(iVar14 + 4) = *(int *)(iVar14 + 4) + 1;
            UNLOCK();
          }
          uVar16 = 0x33;
          uStack_28 = 0x33;
          uStack_8._0_1_ = 0x15;
          if (apppiStack_118[0] != (int ***)0x0) {
            if ((((uint)apppiStack_118[0] & 1) == 0) &&
               (*(code **)((uint)apppiStack_118[0] & 0xfffffffe) != (code *)0x0)) {
              ppppiStack_184 = &pppiStack_110;
              uStack_180._4_4_ = (char *)0x2;
              pcStack_188 = (char *)0x67a1d8;
              uStack_180._0_4_ = (char *)ppppiStack_184;
              (**(code **)((uint)apppiStack_118[0] & 0xfffffffe))();
            }
            apppiStack_118[0] = (int ***)0x0;
          }
          uStack_8._0_1_ = 0x14;
          uStack_180._4_4_ = (char *)0x67a1f3;
          cVar7 = FUN_0168a8f0();
          piVar17 = piStack_2c;
          if (cVar7 == '\0') {
            uStack_180._4_4_ = (char *)0x67abe0;
            uStack_180._4_4_ = (char *)FUN_005503c0();
            uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
                    /* WARNING: Subroutine does not return */
            uStack_180._0_4_ = &UNK_0067abea;
            FUN_0054e630();
          }
        }
        pppppiVar3 = *(int ******)(param_1 + 0x3bc4);
        *(int **)(param_1 + 0x3bc4) = piVar17;
        if (pppppiVar3 != (int *****)0x0) {
          uStack_8._0_1_ = 0x19;
          uStack_8._1_3_ = 0;
          uStack_180._4_4_ = (char *)0x67a224;
          FUN_016899e0();
          ppppiVar4 = *pppppiVar3;
          if (ppppiVar4 != (int ****)0x0) {
            LOCK();
            ppppiVar1 = ppppiVar4 + 1;
            pppiVar13 = *ppppiVar1;
            *ppppiVar1 = (int ***)((int)*ppppiVar1 + -1);
            UNLOCK();
            if (pppiVar13 == (int ***)0x1) {
              uStack_180._4_4_ = (char *)0x0;
              uStack_180._0_4_ = "Wj";
              (*(code *)**ppppiVar4)();
              ppppiStack_184 = (int ****)0x0;
              pcStack_188 = (char *)0x67a249;
              uStack_180._0_4_ = (char *)ppppiVar4;
              pcStack_188 = (char *)GetProcessHeap();
              ppiStack_18c = (int **)0x67a250;
              HeapFree();
            }
          }
          uStack_180._4_4_ = (char *)0x4;
          ppppiStack_184 = (int ****)0x67a25b;
          uStack_180._0_4_ = (char *)pppppiVar3;
          FUN_01674ea0();
        }
        if ((uVar16 & 2) != 0) {
          uVar16 = uVar16 & 0xfffffffd;
          uStack_180._4_4_ = (char *)0x67a26e;
          FUN_00550990();
        }
        if ((uVar16 & 1) != 0) {
          uStack_180._4_4_ = (char *)0x67a27e;
          FUN_00550990();
        }
        uStack_180._4_4_ = (char *)0x67a289;
        FUN_006782c0();
      }
      else {
        *(undefined4 *)(param_1 + 0x3bc8) = uStack_3c;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x3bc8) = 2;
    }
    uStack_180._4_4_ = (char *)0x67a294;
    FUN_00613200();
    uStack_8 = 0x1a;
    uStack_180._4_4_ = (char *)uVar9;
    uVar9 = FUN_0067abb3();
    return uVar9;
  case 0x96:
    uStack_180._4_4_ = (char *)0x0;
    uStack_180._0_4_ = *(char **)(param_2 + 0x30);
    pcStack_188 = (char *)0x67a601;
    ppppiStack_184 = (int ****)puVar12;
    FUN_006ab380();
    uStack_180._4_4_ = (char *)0x1;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
    uStack_180._0_4_ = (char *)0x67a60f;
    FUN_006ab660();
    uStack_180._4_4_ = (char *)0x67a617;
    cVar7 = FUN_006abd90();
    uStack_24 = CONCAT31(uStack_24._1_3_,cVar7);
    if (cVar7 == '\0') {
      uStack_1b8 = 0;
    }
    else {
      uStack_180._4_4_ = (char *)0x67a626;
      uStack_1b8 = FUN_006ac4d0();
    }
    piVar17 = (int *)(param_1 + -0x5c);
    uStack_180._4_4_ = (char *)piVar17;
    if (DAT_01d67ecc == '\0') {
      uStack_180._0_4_ = (char *)0x67a6c1;
      FUN_008f7870();
      uStack_180._4_4_ = (char *)0x67a6cc;
      fStack_34 = (float)FUN_00671e00();
      uStack_180._4_4_ = (char *)0x1;
      ppppiStack_78 = &pppiStack_19c;
      puStack_20 = (undefined *)&pppiStack_19c;
      uStack_1a0 = 0;
      piStack_1c = &iStack_1b4;
      uStack_1bc = uStack_24;
      FUN_0060e0c0(&uStack_1c4,piVar17);
      FUN_00670b10(piStack_1c,FUN_006839b0);
      uStack_1b8 = 0x67a70d;
      FUN_0066dd30();
      uStack_8._0_1_ = 0x26;
      uStack_1a0 = 0x67a71b;
      uStack_1a8 = (**(code **)(*piVar17 + 0xb8))();
      puStack_1ac = auStack_1a4;
      uStack_1b0 = 0x67a727;
      FUN_0060dcd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
      uStack_1a8 = 0x67a736;
      FUN_00bdf0f0();
    }
    else {
      uStack_180._0_4_ = (char *)0x67a642;
      FUN_008f7870();
      uStack_180._4_4_ = (char *)0x67a64d;
      fStack_34 = (float)FUN_00671e00();
      uStack_180._4_4_ = (char *)0x1;
      ppppiStack_78 = &pppiStack_19c;
      puStack_20 = (undefined *)&pppiStack_19c;
      uStack_1a0 = 0;
      piStack_1c = &iStack_1b4;
      uStack_1bc = uStack_24;
      FUN_0060e0c0(&uStack_1c4,piVar17);
      FUN_00670b10(piStack_1c,FUN_006839b0);
      uStack_1b8 = 0x67a68e;
      FUN_0066dd30();
      uStack_8._0_1_ = 0x25;
      uStack_1a0 = 0x67a69c;
      uStack_1a8 = (**(code **)(*piVar17 + 0xb8))();
      puStack_1ac = auStack_1a4;
      uStack_1b0 = 0x67a6a8;
      FUN_0060dcd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
      uStack_1a8 = 0x67a6b7;
      FUN_00bdee80();
    }
    uStack_180._4_4_ = (char *)0x67a73e;
    FUN_00613200();
    uStack_8 = 0x27;
    uStack_180._4_4_ = (char *)uVar9;
    uVar9 = FUN_0067abb3();
    return uVar9;
  case 0x99:
    break;
  case 0x9c:
    uStack_180._4_4_ = (char *)param_2;
    uStack_180._0_4_ = (char *)0x67aaea;
    FUN_0067fad0();
    uStack_8 = 0x33;
    uStack_180._0_4_ = (char *)0x67aaf7;
    uStack_180._4_4_ = (char *)uVar9;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 1;
  }
  if (DAT_01d5af08 == '\0') {
    if (((DAT_01d80e64 == '\0') || (*(char *)(param_1 + 0x37e8) != '\0')) ||
       (*(int *)(param_1 + 0x3bb0) == 0)) goto LAB_0067a9f8;
    uStack_180._4_4_ = (char *)(param_1 + -0x5c);
    uStack_180._0_4_ = (undefined *)0x67a7cc;
    piStack_1c = (int *)FUN_008f7870();
    if (piStack_1c == (int *)0x0) goto LAB_0067a9f8;
    uStack_180._4_4_ = (char *)0x0;
    uStack_180._0_4_ = *(char **)(param_2 + 0x30);
    ppppiStack_184 = *(int *****)(param_2 + 0x38);
    pcStack_188 = (char *)0x67a7ed;
    FUN_006ab380();
    uStack_180._4_4_ = (char *)0x1;
    uStack_8._0_1_ = 0x29;
    uStack_180._0_4_ = (undefined *)0x67a7fe;
    FUN_006ab660();
    uStack_180._4_4_ = (char *)0x67a809;
    FUN_006ac4d0();
    uStack_180._4_4_ = (char *)0x67a814;
    pppiVar13 = (int ***)FUN_006ac4d0();
    uStack_180._4_4_ = (char *)0x67a824;
    ppiStack_30 = (int **)pppiVar13;
    piStack_38 = (int *)FUN_006ac4d0();
    if (((int)DAT_01d5ae38 < (int)pppiVar13) || ((int)pppiVar13 < 1)) {
      ppiStack_30 = (int **)DAT_01d5ae38;
    }
    if (((int)DAT_01d5ae40 < (int)piStack_38) || ((int)piStack_38 < 1)) {
      piStack_38 = DAT_01d5ae40;
    }
    uVar16 = uStack_24;
    if (DAT_01d5af00 == 0) {
LAB_0067a939:
      acStack_18[0] = '\0';
    }
    else {
      uStack_180._4_4_ = (char *)0x1;
      uStack_180._0_4_ = &DAT_018bf378;
      piStack_b4 = (int *)0x0;
      uStack_b0 = 0xf;
      pppiStack_c4 = (int ***)((uint)pppiStack_c4 & 0xffffff00);
      ppppiStack_184 = (int ****)0x67a883;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2a);
      uStack_28 = 4;
      uStack_180._4_4_ = (char *)0x67a899;
      uStack_180 = FUN_00928340();
      uVar6 = (ulonglong)uStack_180 >> 0x20;
      iVar14 = (int)uStack_180;
      if ((uStack_180 < 0x100000000) && (uStack_180 < 0)) {
        uStack_180._0_4_ = (char *)-iVar14;
        uStack_180._4_4_ = (char *)-((int)uVar6 + (uint)(iVar14 != 0));
        ppppiStack_184 = (int ****)((int)&uStack_d0 + 1);
        pcStack_188 = (char *)0x67a8b8;
        iVar14 = FUN_0055c3d0();
        *(undefined *)(iVar14 + -1) = 0x2d;
        iVar14 = iVar14 + -1;
      }
      else {
        ppppiStack_184 = (int ****)((int)&uStack_d0 + 1);
        pcStack_188 = (char *)0x67a8cf;
        iVar14 = FUN_0055c3d0();
      }
      puStack_80 = (undefined *)0x0;
      iStack_7c = 0xf;
      piStack_90 = (int *)((uint)piStack_90 & 0xffffff00);
      if (iVar14 != (int)&uStack_d0 + 1) {
        uStack_180._4_4_ = (char *)(((int)&uStack_d0 + 1) - iVar14);
        ppppiStack_184 = (int ****)0x67a902;
        uStack_180._0_4_ = (char *)iVar14;
        FUN_005542c0();
      }
      uStack_180._4_4_ = (char *)&pppiStack_c4;
      uStack_8._0_1_ = 0x2b;
      uStack_8._1_3_ = 0;
      ppppiStack_184 = (int ****)&piStack_90;
      uVar16 = 0xcc;
      uStack_180._0_4_ = &DAT_01d5aef0;
      uStack_28 = 0xcc;
      pcStack_188 = (char *)0x67a929;
      cVar7 = FUN_0067d600();
      if (cVar7 == '\0') goto LAB_0067a939;
      acStack_18[0] = '\x01';
    }
    if ((uVar16 & 8) != 0) {
      uVar16 = uVar16 & 0xfffffff7;
      uStack_180._4_4_ = (char *)0x67a950;
      FUN_005507b0();
    }
    uStack_8 = 0x29;
    if ((uVar16 & 4) != 0) {
      uStack_180._4_4_ = (char *)0x67a967;
      FUN_005507b0();
    }
    if (acStack_18[0] != '\0') {
      *(undefined *)(param_1 + 0x37e8) = 1;
      uStack_180._4_4_ = (char *)0x67a97d;
      FUN_0152de00();
      uStack_180._4_4_ = (char *)piStack_38;
      piStack_190 = (int *)(param_1 + -0x5c);
      uStack_180._0_4_ = (char *)0x2;
      ppppiStack_184 = (int ****)ppiStack_30;
      puStack_20 = (undefined *)&ppiStack_18c;
      pppiStack_194 = &ppiStack_18c;
      pcStack_198 = (code *)0x67a997;
      FUN_0060e0c0();
      pppiStack_19c = (int ***)&pppiStack_194;
      uStack_8._0_1_ = 0x2c;
      pcStack_198 = (code *)piStack_1c;
      uStack_1a0 = 0x67a9ac;
      FUN_005e5de0();
      uStack_8._0_1_ = 0x29;
      pppiStack_19c = (int ***)&pppiStack_68;
      pcStack_198 = FUN_0067feb0;
      uStack_1a0 = 0x67a9c1;
      uStack_180._4_4_ = (char *)FUN_006709d0();
      uStack_8._0_1_ = 0x2d;
      uStack_180._0_4_ = (undefined *)0x67a9d1;
      FUN_0066dc80();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2f);
      uStack_180._4_4_ = (char *)0x67a9dd;
      FUN_006782e0();
      uStack_180._4_4_ = (char *)0x67a9e5;
      FUN_016899e0();
      uStack_180._4_4_ = (char *)0x67a9ed;
      FUN_0056ebb0();
    }
  }
  else {
    uStack_180._4_4_ = (char *)0x0;
    uStack_180._0_4_ = *(char **)(param_2 + 0x30);
    pcStack_188 = (char *)0x67a762;
    ppppiStack_184 = (int ****)puVar12;
    FUN_006ab380();
    uStack_180._4_4_ = (char *)0x1;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x28);
    uStack_180._0_4_ = (char *)0x67a770;
    FUN_006ab660();
    uStack_180._4_4_ = (char *)0x67a778;
    FUN_006ac4d0();
    uStack_180._4_4_ = (char *)0x67a780;
    puVar12 = (undefined *)FUN_006ac4d0();
    uStack_180._4_4_ = (char *)0x67a78a;
    uStack_180._4_4_ = (char *)FUN_006ac4d0();
    ppppiStack_184 = (int ****)0x67a794;
    uStack_180._0_4_ = puVar12;
    FUN_0067fc40();
  }
  uStack_180._4_4_ = (char *)0x67a9f8;
  FUN_00613200();
LAB_0067a9f8:
  uStack_8 = 0x30;
  uStack_180._4_4_ = (char *)uVar9;
  uVar9 = FUN_0067abb3();
  return uVar9;
}



/* FUNCTION 7954 ; VA 0x0067ab41 ; Catch@0067ab41 */

undefined * Catch_0067ab41(void)

{
  char *pcVar1;
  char *pcVar2;
  int unaff_EBP;
  
  pcVar1 = (char *)(**(code **)(**(int **)(unaff_EBP + -0x140) + 4))();
  pcVar2 = "empty error string";
  if (pcVar1 != (char *)0x0) {
    pcVar2 = pcVar1;
  }
  FUN_0086f2f0(3,"ServerReplicator::OnReceive packet %d: %s",
               **(undefined **)(*(int *)(unaff_EBP + 8) + 0x38),pcVar2);
  if (DAT_01ee420a != '\0') {
    FUN_01677650(DAT_01ee420a,"Error on ServerReplicator::OnReceive: %s",pcVar1);
  }
  FUN_0062b590(0x104);
  return &DAT_0067aba6;
}



/* FUNCTION 7955 ; VA 0x0067abb3 ; FUN_0067abb3 */

undefined4 FUN_0067abb3(void)

{
  int unaff_EBP;
  
  FUN_01675290();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 0;
}



/* FUNCTION 7956 ; VA 0x0067acb0 ; FUN_0067acb0 */

void __fastcall FUN_0067acb0(int param_1)

{
  *(undefined4 *)(param_1 + 0x3c24) = 2;
  return;
}



/* FUNCTION 7957 ; VA 0x0067acc0 ; FUN_0067acc0 */

int FUN_0067acc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&piStack_18);
  uStack_8 = 0;
  if (piStack_18 != (int *)0x0) {
    iVar3 = (**(code **)(*piStack_18 + 0x238))(param_2,param_3,param_4,param_5);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 7958 ; VA 0x0067ad50 ; FUN_0067ad50 */

void FUN_0067ad50(undefined4 *param_1)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadcf4) {
    FUN_016f3809(&DAT_01eadcf4);
    if (DAT_01eadcf4 == -1) {
      DAT_01eadcf0 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadcf4);
    }
  }
  *param_1 = DAT_01eadcf0;
  return;
}



/* FUNCTION 7959 ; VA 0x0067adb0 ; FUN_0067adb0 */

void __thiscall FUN_0067adb0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_8efa8613e04d74ea603fc25b2f37ee41>,void,enum_RBX::Player::CanManageStatus>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  return;
}



/* FUNCTION 7960 ; VA 0x0067ae00 ; FUN_0067ae00 */

void __thiscall FUN_0067ae00(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 8);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x14);
  }
  return;
}



/* FUNCTION 7961 ; VA 0x0067ae40 ; FUN_0067ae40 */

void __fastcall FUN_0067ae40(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00679780(1);
  }
  return;
}



/* FUNCTION 7962 ; VA 0x0067ae50 ; FUN_0067ae50 */

void __fastcall FUN_0067ae50(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00679830(1);
  }
  return;
}



/* FUNCTION 7963 ; VA 0x0067ae60 ; FUN_0067ae60 */

void __fastcall FUN_0067ae60(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00679930(1);
  }
  return;
}



/* FUNCTION 7964 ; VA 0x0067ae70 ; FUN_0067ae70 */

void FUN_0067ae70(undefined4 *param_1)

{
  FUN_006793c0(*param_1);
  return;
}



/* FUNCTION 7965 ; VA 0x0067ae90 ; FUN_0067ae90 */

void FUN_0067ae90(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_1,0x20);
  return;
}



/* FUNCTION 7966 ; VA 0x0067af00 ; FUN_0067af00 */

undefined4 * __thiscall FUN_0067af00(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_8efa8613e04d74ea603fc25b2f37ee41>,void,enum_RBX::Player::CanManageStatus>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  return param_2;
}



/* FUNCTION 7967 ; VA 0x0067af50 ; FUN_0067af50 */

TypeDescriptor * FUN_0067af50(void)

{
  return &<lambda_8efa8613e04d74ea603fc25b2f37ee41>::RTTI_Type_Descriptor;
}



/* FUNCTION 7968 ; VA 0x0067af60 ; FUN_0067af60 */

int __fastcall FUN_0067af60(int *param_1)

{
  uint3 uVar2;
  int iVar1;
  
  if (DAT_01d5a4d8 == '\0') {
                    /* WARNING: Could not recover jumptable at 0x0067af8d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar1 = (**(code **)(*param_1 + 0x11c))();
    return iVar1;
  }
  iVar1 = *(int *)(param_1[0xf07] + 0x124);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if ((iVar1 != 1) && (iVar1 != 2)) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31(uVar2,1);
}



/* FUNCTION 7969 ; VA 0x0067af90 ; FUN_0067af90 */

void FUN_0067af90(int param_1,char *param_2,undefined8 param_3,undefined4 param_4,undefined4 param_5
                 ,char param_6)

{
  char cVar1;
  undefined uVar2;
  uint *puVar3;
  int *piVar4;
  char *pcVar5;
  char *pcVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  undefined8 uStack_70;
  undefined8 uStack_68;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined8 uStack_48;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4880;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar5 = param_2;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_2,(int)pcVar5 - (int)(param_2 + 1));
  uStack_18 = 0xf00000000;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (DAT_01d5aed8 != '\0') {
    puVar3 = (uint *)FUN_01675640(&uStack_58,"_PlaceId_%lld",param_4,param_5);
    if (&uStack_28 != puVar3) {
      FUN_005507b0();
      uStack_28 = *puVar3;
      uStack_24 = puVar3[1];
      uStack_20 = puVar3[2];
      uStack_1c = puVar3[3];
      uStack_18 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
    }
    if (0xf < uStack_48._4_4_) {
      uVar8 = uStack_48._4_4_ + 1;
      uVar10 = uStack_58;
      if (0xfff < uVar8) {
        uVar10 = *(uint *)(uStack_58 - 4);
        uVar8 = uStack_48._4_4_ + 0x24;
        if (0x1f < (uStack_58 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar8);
    }
  }
  FUN_0054ef60(auStack_40);
  uVar10 = uStack_60;
  uStack_48 = param_3;
  uStack_8._0_1_ = 2;
  puVar3 = *(uint **)(param_1 + 4);
  if (*(uint **)(param_1 + 8) == puVar3) {
    FUN_00603540(puVar3,&uStack_60);
    uVar10 = uStack_4c;
  }
  else {
    uStack_60 = uStack_60 & 0xffffff00;
    *puVar3 = uVar10;
    puVar3[1] = uStack_5c;
    puVar3[2] = uStack_58;
    puVar3[3] = uStack_54;
    *(ulonglong *)(puVar3 + 4) = CONCAT44(uStack_4c,uStack_50);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    *(undefined8 *)(puVar3 + 6) = param_3;
    uVar10 = 0xf;
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uVar10) {
    uVar9 = uVar10 + 1;
    uVar8 = uStack_60;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(uStack_60 - 4);
      uVar9 = uVar10 + 0x24;
      if (0x1f < (uStack_60 - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  if ((int)uStack_18 != 0) {
    piVar4 = (int *)FUN_005f3cd0(&uStack_58,auStack_40,&uStack_28);
    iStack_80 = *piVar4;
    iStack_7c = piVar4[1];
    iStack_78 = piVar4[2];
    iStack_74 = piVar4[3];
    uStack_70 = *(undefined8 *)(piVar4 + 4);
    piVar4[4] = 0;
    piVar4[5] = 0xf;
    *(undefined *)piVar4 = 0;
    uStack_68 = param_3;
    uStack_8._0_1_ = 4;
    FUN_00625cd0(&iStack_80);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_70._4_4_) {
      uVar10 = uStack_70._4_4_ + 1;
      iVar7 = iStack_80;
      if (0xfff < uVar10) {
        iVar7 = *(int *)(iStack_80 + -4);
        uVar10 = uStack_70._4_4_ + 0x24;
        if (0x1f < (iStack_80 - iVar7) - 4U) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar10);
    }
    uStack_8._0_1_ = 1;
    if (0xf < uStack_48._4_4_) {
      uVar8 = uStack_48._4_4_ + 1;
      uVar10 = uStack_58;
      if (0xfff < uVar8) {
        uVar10 = *(uint *)(uStack_58 - 4);
        uVar8 = uStack_48._4_4_ + 0x24;
        if (0x1f < (uStack_58 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar8);
    }
  }
  pcVar5 = "_Fail";
  if (param_6 == '\0') {
    pcVar5 = "_Success";
  }
  pcVar6 = pcVar5;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_00554150(pcVar5,(int)pcVar6 - (int)(pcVar5 + 1));
  FUN_0054ef60(auStack_40);
  uVar10 = uStack_60;
  uStack_48 = param_3;
  puVar3 = *(uint **)(param_1 + 4);
  uStack_8._0_1_ = 5;
  if (*(uint **)(param_1 + 8) == puVar3) {
    FUN_00603540(puVar3,&uStack_60);
  }
  else {
    uStack_60 = uStack_60 & 0xffffff00;
    *puVar3 = uVar10;
    puVar3[1] = uStack_5c;
    puVar3[2] = uStack_58;
    puVar3[3] = uStack_54;
    *(ulonglong *)(puVar3 + 4) = CONCAT44(uStack_4c,uStack_50);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    *(undefined8 *)(puVar3 + 6) = param_3;
    uStack_4c = 0xf;
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_4c) {
    uVar8 = uStack_4c + 1;
    uVar10 = uStack_60;
    if (0xfff < uVar8) {
      uVar10 = *(uint *)(uStack_60 - 4);
      uVar8 = uStack_4c + 0x24;
      if (0x1f < (uStack_60 - uVar10) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar8);
  }
  if ((int)uStack_18 != 0) {
    piVar4 = (int *)FUN_005f3cd0(&uStack_58,auStack_40,&uStack_28);
    iStack_80 = *piVar4;
    iStack_7c = piVar4[1];
    iStack_78 = piVar4[2];
    iStack_74 = piVar4[3];
    uStack_70 = *(undefined8 *)(piVar4 + 4);
    piVar4[4] = 0;
    piVar4[5] = 0xf;
    *(undefined *)piVar4 = 0;
    uStack_68 = param_3;
    uStack_8._0_1_ = 7;
    FUN_00625cd0(&iStack_80);
    if (0xf < uStack_70._4_4_) {
      uVar10 = uStack_70._4_4_ + 1;
      iVar7 = iStack_80;
      if (0xfff < uVar10) {
        iVar7 = *(int *)(iStack_80 + -4);
        uVar10 = uStack_70._4_4_ + 0x24;
        if (0x1f < (iStack_80 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar10);
    }
    if (0xf < uStack_48._4_4_) {
      uVar8 = uStack_48._4_4_ + 1;
      uVar10 = uStack_58;
      if (0xfff < uVar8) {
        uVar10 = *(uint *)(uStack_58 - 4);
        uVar8 = uStack_48._4_4_ + 0x24;
        if (0x1f < (uStack_58 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar8);
    }
  }
  if (0xf < uStack_18._4_4_) {
    uVar8 = uStack_18._4_4_ + 1;
    uVar10 = uStack_28;
    if (0xfff < uVar8) {
      uVar10 = *(uint *)(uStack_28 - 4);
      uVar8 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uStack_28 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar8);
  }
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    uVar10 = auStack_40[0];
    if (0xfff < uVar8) {
      uVar10 = *(uint *)(auStack_40[0] - 4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7970 ; VA 0x0067b3f0 ; FUN_0067b3f0 */

ushort * __thiscall FUN_0067b3f0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  ushort *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a48b1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iStack_14 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  puVar4 = (ushort *)FUN_0061dc20(&iStack_14);
  if (puVar4 != (ushort *)0x0) {
    iStack_14 = *(int *)(*(int *)(param_1 + 0x19f4) + 0x58);
    if ((uint)*puVar4 < (uint)((*(int *)(*(int *)(param_1 + 0x19f4) + 0x5c) - iStack_14) / 0x3c)) {
      iStack_14 = iStack_14 + (uint)*puVar4 * 0x3c;
    }
    else {
      iStack_14 = 0;
    }
    uStack_2c = 0;
    piStack_28 = (int *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(char *)(param_1 + 0x1db8) == '\0') {
      puVar5 = (undefined4 *)FUN_006d89e0(auStack_24,param_2);
      piVar1 = piStack_28;
      uStack_2c = *puVar5;
      piVar2 = (int *)puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_28[1] + -1;
        piStack_28[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puVar5 = (undefined4 *)*piStack_28;
          piStack_28 = piVar2;
          (*(code *)*puVar5)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          piVar2 = piStack_28;
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
            piVar2 = piStack_28;
          }
        }
      }
      piStack_28 = piVar2;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar3 = piStack_20[2] + -1;
          piStack_20[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    puVar5 = *(undefined4 **)(param_1 + 0x1948);
    puStack_1c = *(undefined4 **)*puVar5;
    puStack_18 = puVar5;
    if (puStack_1c == (undefined4 *)0x0) {
      puStack_1c = (undefined4 *)FUN_00621d50();
    }
    else {
      *(undefined4 *)*puVar5 = *puStack_1c;
    }
    *puStack_1c = puVar5;
    puStack_1c = puStack_1c + 1;
    uStack_8._0_1_ = 2;
    if (puStack_1c == (undefined4 *)0x0) {
      uVar6 = 0;
    }
    else {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      uVar6 = FUN_006bf3f0(param_1,iStack_14,param_2,param_3,&uStack_2c,0);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar4 = (ushort *)FUN_006b1f50(uVar6);
    piVar2 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar3 = *piVar1;
      puVar4 = (ushort *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        puVar4 = (ushort *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          puVar4 = (ushort *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    puVar4 = (ushort *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar4 = (ushort *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar4 = (ushort *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 7971 ; VA 0x0067b5f0 ; FUN_0067b5f0 */

bool FUN_0067b5f0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_009fb200();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_0067b622;
  }
  param_1 = 0;
LAB_0067b622:
  return param_1 != 0;
}



/* FUNCTION 7972 ; VA 0x0067b630 ; FUN_0067b630 */

undefined __fastcall FUN_0067b630(int param_1)

{
  return *(undefined *)(param_1 + 0x3c2c);
}



/* FUNCTION 7973 ; VA 0x0067b640 ; FUN_0067b640 */

int __thiscall FUN_0067b640(int param_1,int param_2)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x3bb8);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if ((iVar1 != 0) && (iVar1 < param_2)) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31(uVar2,1);
}



/* FUNCTION 7974 ; VA 0x0067b660 ; FUN_0067b660 */

undefined4 __thiscall FUN_0067b660(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar1 = param_2;
  uVar3 = FUN_00c1a100(*(undefined4 *)(param_2 + 0xa8));
  iVar4 = FUN_00b06640(uVar3);
  FUN_00b07ca0(&param_2);
  cVar2 = FUN_00a33d60(param_1 + 0x94);
  if (DAT_01d5aec0 != '\0') {
    *(undefined4 *)(param_1 + 0x3d00) = *(undefined4 *)(param_1 + 0x3cfc);
    *(undefined4 *)(param_1 + 0x3d08) = 0;
    if (iVar4 != iVar1) {
      return 0;
    }
    if (cVar2 != '\0') {
      param_2 = FUN_00c155c0();
      if ((uint)((*(int *)(param_1 + 0x3d00) - *(int *)(param_1 + 0x3cfc) >> 2) * 3) >> 2 <=
          *(uint *)(param_1 + 0x3d08)) {
        FUN_006286d0();
      }
      FUN_00620c30(&param_2);
    }
  }
  if ((iVar4 == iVar1) && (cVar2 != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 7975 ; VA 0x0067b720 ; FUN_0067b720 */

bool __thiscall FUN_0067b720(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar1 = param_2;
  uVar3 = FUN_00c1a030(*(undefined4 *)(param_2 + 0xa8));
  iVar4 = FUN_00b06640(uVar3);
  if (iVar4 == iVar1) {
    FUN_00b07ca0(&param_2);
    cVar2 = FUN_00a33d60(param_1 + 0x94);
    return cVar2 == '\0';
  }
  return false;
}



/* FUNCTION 7976 ; VA 0x0067b770 ; FUN_0067b770 */

void __fastcall FUN_0067b770(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = (int *)*param_1;
  piVar4 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar4 != (int *)*param_1) {
    do {
      piVar1 = (int *)piVar4[5];
      piVar2 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = (int *)piVar4[3];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x20);
      piVar4 = piVar2;
    } while (piVar2 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 7977 ; VA 0x0067b800 ; FUN_0067b800 */

bool __thiscall FUN_0067b800(int *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  
  iVar1 = *param_1;
  if (iVar1 == param_1[1]) {
    return false;
  }
  uVar2 = *param_2;
  if (uVar2 != param_1[4]) {
    uVar3 = (uVar2 >> 3) + uVar2;
    uVar6 = (param_1[1] - iVar1 >> 2) - 1;
    uVar5 = 0;
    do {
      uVar3 = uVar3 & uVar6;
      puVar4 = (uint *)(iVar1 + uVar3 * 4);
      if (*puVar4 == uVar2) goto LAB_0067b85f;
      if (*puVar4 == param_1[4]) break;
      uVar3 = uVar3 + 1 + uVar5;
      uVar5 = uVar5 + 1;
    } while (uVar5 <= uVar6);
  }
  puVar4 = (uint *)0x0;
LAB_0067b85f:
  return puVar4 != (uint *)0x0;
}



/* FUNCTION 7978 ; VA 0x0067b870 ; FUN_0067b870 */

undefined4 * __thiscall FUN_0067b870(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a48c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0060dcd0(auStack_20,param_1);
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_00673a40(auStack_18,uVar3);
  *param_2 = *puVar4;
  uVar3 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar3;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7979 ; VA 0x0067b930 ; FUN_0067b930 */

undefined4 __thiscall FUN_0067b930(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined2 uVar5;
  undefined auStack_48 [44];
  undefined4 uStack_1c;
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a48f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  uVar2 = FUN_01675290(DAT_01eadc98);
  iStack_8 = 0;
  uStack_1c = uVar2;
  if (param_1[0xf09] == 3) {
    param_1[0xf09] = 4;
    FUN_006ab530();
    iStack_8._0_1_ = 1;
    auStack_14[0] = 0x92;
    FUN_006ad5e0(auStack_14,1);
    auStack_14[0] = 0;
    FUN_006ad5e0(auStack_14,1);
    FUN_005f70a0();
    FUN_005f7140();
    piVar1 = piStack_18;
    uVar3 = DAT_01d5ae88;
    uVar4 = DAT_01d5ae8c;
    uVar5 = DAT_01d5ae90;
    FUN_005f7170(piStack_18 + 0x1d);
    FUN_00681340(auStack_48,0,3,0,uVar3,uVar4,uVar5);
    (**(code **)(*piVar1 + 0x23c))(0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00613200();
  }
  FUN_0067bd30();
  FUN_0067bac0();
  uVar3 = FUN_0061a360(param_2);
  iStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 7980 ; VA 0x0067ba70 ; FUN_0067ba70 */

void FUN_0067ba70(undefined4 param_1,int param_2)

{
  char cVar1;
  
  cVar1 = FUN_006abd90();
  *(char *)(param_2 + 1) = cVar1;
  if (cVar1 != '\0') {
    FUN_006ab8a0(param_2 + 4,param_1);
  }
  return;
}



/* FUNCTION 7981 ; VA 0x0067baa0 ; FUN_0067baa0 */

void FUN_0067baa0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0067bab0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x18))();
  return;
}



/* FUNCTION 7982 ; VA 0x0067bac0 ; FUN_0067bac0 */

void __fastcall FUN_0067bac0(undefined4 *param_1)

{
  uint *puVar1;
  int *piVar2;
  byte bVar3;
  undefined4 *puVar4;
  double *pdVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  int *piVar13;
  double dVar14;
  undefined8 uVar15;
  undefined auStack_44 [8];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  uint *puStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4908;
  pvStack_10 = ExceptionList;
  piStack_2c = param_1 + 8;
  puVar1 = param_1 + 0xd;
  ExceptionList = &pvStack_10;
  puStack_30 = puVar1;
  puStack_20 = param_1;
  while( true ) {
    puVar4 = puStack_20;
    piVar13 = piStack_2c;
    uStack_3c = *puStack_20;
    uStack_38 = puStack_20[1];
    do {
      LOCK();
      uVar10 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
      uStack_8 = (uint)((uVar10 & 1) != 0);
    } while (uStack_8 != 0);
    if (piStack_2c[4] == 0) break;
    pdVar5 = (double *)FUN_01682800(auStack_44);
    if ((piVar13 == (int *)0x0) || ((int *)*piVar13 == (int *)0x0)) {
      iVar6 = 0;
    }
    else {
      iVar6 = *(int *)*piVar13;
    }
    dVar14 = *(double *)
              (*(int *)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & piVar13[3]) * 4) + 8) +
             (double)CONCAT44(uStack_38,uStack_3c);
    if (*pdVar5 <= dVar14 && dVar14 != *pdVar5) break;
    if ((piVar13 == (int *)0x0) || ((int *)*piVar13 == (int *)0x0)) {
      iVar6 = 0;
    }
    else {
      iVar6 = *(int *)*piVar13;
    }
    piStack_18 = (int *)**(int **)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & piVar13[3]) * 4
                                  );
    piVar2 = piVar13 + 4;
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      piVar13[3] = 0;
      uVar10 = 0;
    }
    else {
      piVar13[3] = piVar13[3] + 1;
      uVar10 = piVar13[3];
    }
    if (piVar13[4] == 0) {
      uVar15 = 0;
    }
    else {
      puVar7 = (undefined4 *)*piVar13;
      if (puVar7 != (undefined4 *)0x0) {
        puVar7 = (undefined4 *)*puVar7;
      }
      uVar15 = *(undefined8 *)(*(int *)(puVar7[1] + (puVar7[2] - 1 & uVar10) * 4) + 8);
    }
    *(undefined8 *)(piVar13 + 6) = uVar15;
    uStack_8 = 0xffffffff;
    pbVar12 = (byte *)(puVar4 + 2);
    *puVar1 = 0;
    bVar3 = *pbVar12;
    uStack_1c = FUN_005702d0(piStack_18);
    FUN_009c91c0(&uStack_1c,(int)piStack_18 + 0x18);
    uStack_1c = uStack_1c ^
                *(int *)((int)piStack_18 + 0x1c) + -0x61c88647 + uStack_1c * 0x40 + (uStack_1c >> 2)
    ;
    FUN_00676e80(&piStack_24,uStack_1c,piStack_18,
                 -(uint)(pbVar12 + bVar3 + 1 != (byte *)0x0) & (uint)(pbVar12 + bVar3 + 1 + 1));
    piStack_34 = piStack_24;
    piStack_28 = (int *)*piStack_24;
    uVar10 = (uint)piStack_24[1] % (uint)puStack_20[3];
    piStack_18 = *(int **)(puStack_20[7] + uVar10 * 4);
    for (piVar13 = (int *)*piStack_18; piVar13 != piStack_24; piVar13 = (int *)*piVar13) {
      piStack_18 = piVar13;
    }
    do {
      *piStack_18 = *piVar13;
      uVar11 = piVar13[7];
      if (0xf < uVar11) {
        iVar6 = piVar13[2];
        uVar9 = uVar11 + 1;
        iVar8 = iVar6;
        if (0xfff < uVar9) {
          iVar8 = *(int *)(iVar6 + -4);
          uVar9 = uVar11 + 0x24;
          if (0x1f < (iVar6 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar8,uVar9);
      }
      piVar13[6] = 0;
      piVar13[7] = 0xf;
      *(undefined *)(piVar13 + 2) = 0;
      FUN_01674ea0(piVar13,0x40);
      puStack_20[4] = puStack_20[4] + -1;
      uVar11 = uVar10;
      if (*piStack_18 == 0) {
LAB_0067bce8:
        if (*(int **)(puStack_20[7] + uVar10 * 4) == piStack_18) {
          *(undefined4 *)(puStack_20[7] + uVar10 * 4) = 0;
        }
      }
      else {
        uVar11 = *(uint *)(*piStack_18 + 4) % (uint)puStack_20[3];
        if (uVar10 != uVar11) {
          *(int **)(puStack_20[7] + uVar11 * 4) = piStack_18;
          goto LAB_0067bce8;
        }
      }
      piVar13 = (int *)*piStack_18;
      uVar10 = uVar11;
    } while (piVar13 != piStack_28);
  }
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7983 ; VA 0x0067bd30 ; FUN_0067bd30 */

void __fastcall FUN_0067bd30(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  double *pdVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  int *piVar10;
  int iVar11;
  int *piVar12;
  double dVar13;
  undefined8 uVar14;
  uint uStack_6c;
  undefined8 uStack_68;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined auStack_54 [8];
  undefined auStack_4c [8];
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint *puStack_3c;
  int *piStack_38;
  uint *puStack_34;
  int *piStack_2c;
  int *piStack_28;
  uint *puStack_24;
  double *pdStack_20;
  uint uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4930;
  pvStack_10 = ExceptionList;
  piStack_28 = param_1 + 8;
  puStack_24 = param_1 + 0xd;
  uStack_60 = 0;
  uStack_5c = 0xffffffff;
  uStack_58 = 0;
  puVar9 = puStack_24;
  piVar10 = piStack_28;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  while( true ) {
    uStack_44 = *puStack_14;
    uStack_40 = puStack_14[1];
    do {
      LOCK();
      uVar7 = *puVar9;
      *puVar9 = *puVar9 | 1;
      UNLOCK();
      uStack_8 = (uint)((uVar7 & 1) != 0);
    } while (uStack_8 != 0);
    if (piVar10[4] == 0) break;
    puStack_34 = puVar9;
    pdStack_20 = (double *)FUN_01682800(auStack_4c);
    if ((piVar10 == (int *)0x0) || ((int *)*piVar10 == (int *)0x0)) {
      iVar11 = 0;
    }
    else {
      iVar11 = *(int *)*piVar10;
    }
    dVar13 = *(double *)
              (*(int *)(*(int *)(iVar11 + 4) + (*(int *)(iVar11 + 8) - 1U & piVar10[3]) * 4) + 0x10)
             + (double)CONCAT44(uStack_40,uStack_44);
    if (*pdStack_20 <= dVar13 && dVar13 != *pdStack_20) break;
    if ((piVar10 == (int *)0x0) || ((int *)*piVar10 == (int *)0x0)) {
      iVar11 = 0;
    }
    else {
      iVar11 = *(int *)*piVar10;
    }
    puVar1 = *(uint **)(*(int *)(iVar11 + 4) + (*(int *)(iVar11 + 8) - 1U & piVar10[3]) * 4);
    uStack_60 = *puVar1;
    uStack_5c = puVar1[1];
    uStack_58 = puVar1[2];
    piVar12 = piVar10 + 4;
    *piVar12 = *piVar12 + -1;
    if (*piVar12 == 0) {
      piVar10[3] = 0;
      uVar7 = 0;
    }
    else {
      piVar10[3] = piVar10[3] + 1;
      uVar7 = piVar10[3];
    }
    if (piVar10[4] == 0) {
      uVar14 = 0;
    }
    else {
      puVar3 = (undefined4 *)*piVar10;
      if (puVar3 != (undefined4 *)0x0) {
        puVar3 = (undefined4 *)*puVar3;
      }
      uVar14 = *(undefined8 *)(*(int *)(puVar3[1] + (puVar3[2] - 1 & uVar7) * 4) + 0x10);
    }
    *(undefined8 *)(piVar10 + 6) = uVar14;
    uStack_8 = 0xffffffff;
    *puVar9 = 0;
    iVar11 = (int)puStack_14 + *(byte *)(puStack_14 + 2) + 9;
    uStack_1c = uStack_60;
    FUN_009c91c0(&uStack_1c,&uStack_5c);
    puVar3 = puStack_14;
    uStack_1c = uStack_1c ^ (uStack_1c >> 2) + 0x9e3779b9 + uStack_1c * 0x40 + uStack_58;
    FUN_00676f40(&piStack_2c,uStack_1c,&uStack_60,-(uint)(iVar11 != 0) & iVar11 + 1U);
    pdVar4 = (double *)FUN_01682800(auStack_54);
    uVar2 = uStack_58;
    uVar8 = uStack_5c;
    uVar7 = uStack_60;
    if (*pdVar4 < *(double *)(piStack_2c + 8) || *pdVar4 == *(double *)(piStack_2c + 8)) {
      FUN_01682800(&uStack_68);
      piVar10 = piStack_28;
      do {
        LOCK();
        uVar6 = *puVar9;
        *puVar9 = *puVar9 | 1;
        UNLOCK();
      } while ((uVar6 & 1) != 0);
      uStack_8 = 1;
      if (piStack_28[4] == 0) {
        *(undefined8 *)(piStack_28 + 6) = uStack_68;
      }
      uVar6 = piStack_28[2];
      puStack_3c = puVar9;
      if (uVar6 <= piStack_28[4] + 1U) {
        FUN_006174f0(1);
        uVar6 = piVar10[2];
      }
      piVar10[3] = piVar10[3] & uVar6 - 1;
      pdStack_20 = (double *)(piVar10[4] + piVar10[3] & piVar10[2] - 1U);
      iVar11 = piVar10[1];
      if (*(int *)(iVar11 + (int)pdStack_20 * 4) == 0) {
        uVar5 = FUN_01674e20(0x18);
        *(undefined4 *)(piVar10[1] + (int)pdStack_20 * 4) = uVar5;
        iVar11 = puStack_14[9];
      }
      puVar1 = *(uint **)(iVar11 + (int)pdStack_20 * 4);
      *puVar1 = uVar7;
      puVar1[1] = uVar8;
      puVar1[2] = uVar2;
      puVar1[3] = uStack_6c;
      *(undefined8 *)(puVar1 + 4) = uStack_68;
      piVar10[4] = piVar10[4] + 1;
      *puVar9 = 0;
    }
    else {
      puStack_34 = (uint *)*piStack_2c;
      pdStack_20 = (double *)(puVar3 + 3);
      piStack_38 = piStack_2c;
      uVar7 = (uint)piStack_2c[1] % *(uint *)pdStack_20;
      piStack_18 = *(int **)(puVar3[7] + uVar7 * 4);
      for (piVar12 = (int *)*piStack_18; piVar12 != piStack_2c; piVar12 = (int *)*piVar12) {
        piStack_18 = piVar12;
      }
      do {
        *piStack_18 = *piVar12;
        FUN_01674ea0(piVar12,0x30);
        puStack_14[4] = puStack_14[4] + -1;
        uVar8 = uVar7;
        if (*piStack_18 == 0) {
LAB_0067bf47:
          if (*(int **)(puStack_14[7] + uVar7 * 4) == piStack_18) {
            *(undefined4 *)(puStack_14[7] + uVar7 * 4) = 0;
          }
        }
        else {
          uVar8 = *(uint *)(*piStack_18 + 4) % *(uint *)pdStack_20;
          if (uVar7 != uVar8) {
            *(int **)(puStack_14[7] + uVar8 * 4) = piStack_18;
            goto LAB_0067bf47;
          }
        }
        piVar12 = (int *)*piStack_18;
        puVar9 = puStack_24;
        uVar7 = uVar8;
        piVar10 = piStack_28;
      } while ((uint *)piVar12 != puStack_34);
    }
  }
  *puVar9 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7984 ; VA 0x0067c050 ; FUN_0067c050 */

void FUN_0067c050(undefined4 param_1,int param_2,int param_3,undefined param_4,undefined param_5)

{
  int iVar1;
  undefined2 *puVar2;
  int iVar3;
  undefined2 *puVar4;
  int *piVar5;
  int iStack_8;
  
  iVar3 = param_3;
  iVar1 = *(int *)(param_3 + 0xc);
  iStack_8 = iVar1;
  puVar4 = (undefined2 *)FUN_0061dc20(&iStack_8);
  if (puVar4 == (undefined2 *)0x0) {
    if (DAT_01ee420a != '\0') {
      piVar5 = *(int **)(iVar1 + 4);
      if (0xf < (uint)piVar5[5]) {
        piVar5 = (int *)*piVar5;
      }
      FUN_01677520(DAT_01ee420a,
                   "WARNING: Skipping top replication container \'%s\' because it is not in the network schema"
                   ,piVar5);
    }
    return;
  }
  puVar2 = *(undefined2 **)(param_2 + 4);
  if (*(undefined2 **)(param_2 + 8) != puVar2) {
    *puVar2 = *puVar4;
    *(undefined *)(puVar2 + 4) = param_4;
    *(int *)(puVar2 + 2) = iVar3;
    *(undefined *)((int)puVar2 + 9) = param_5;
    *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 0xc;
    return;
  }
  FUN_0066dfb0(puVar2,puVar4,&param_3,&param_4,&param_5);
  return;
}



/* FUNCTION 7985 ; VA 0x0067c0f0 ; FUN_0067c0f0 */

undefined4 __thiscall FUN_0067c0f0(int *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined2 *puVar4;
  undefined4 uVar5;
  char acStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00554e30(param_2);
  if ((iVar3 == 1) ||
     ((param_1[0xf03] == 0 && (iVar3 = (**(code **)(*param_1 + 0x274))(iVar1), iVar3 == 1)))) {
    ExceptionList = pvStack_10;
    return 1;
  }
  if (DAT_01d5aec0 == '\0') {
    iVar3 = FUN_00c15700();
    if ((iVar3 == 0) || (*(int *)(iVar1 + 0xa8) == iVar3)) {
      iVar3 = *(int *)(iVar1 + 0xa8);
    }
    param_2 = *(undefined4 *)(iVar3 + 0x1dc);
    if (param_1[0xf03] != 0) {
      FUN_00927d30(&iStack_14);
      cVar2 = FUN_005e0cd0(&param_2);
      if (cVar2 != '\0') {
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  else {
    iStack_14 = FUN_00c155c0();
    if (*(int *)(iStack_14 + 0xc) == 0) {
      param_2 = 0;
    }
    else {
      param_2 = *(int *)(iStack_14 + 0xc) + -8;
    }
    cVar2 = FUN_0067b800(&param_2);
    if (cVar2 == '\0') {
      acStack_2c[0] = FUN_0067b800(&iStack_14);
      if (acStack_2c[0] == '\0') {
        if (DAT_01d5aec8 != '\0') {
          uStack_1c = 0;
          uStack_18 = 0xf;
          FUN_005542c0("PhysicsReceivedChildBeforeParent",0x20);
          uStack_8 = 0;
          FUN_008783f0(acStack_2c,1,0);
          FUN_005507b0();
        }
        ExceptionList = pvStack_10;
        return 1;
      }
    }
    else {
      if ((uint)((param_1[0xf40] - param_1[0xf3f] >> 2) * 3) >> 2 <= (uint)param_1[0xf42]) {
        FUN_006286d0();
      }
      FUN_00620c30(&iStack_14);
    }
  }
  param_2 = *(undefined4 *)(iVar1 + 0xc);
  puVar4 = (undefined2 *)FUN_0061dc20(&param_2);
  if (puVar4 == (undefined2 *)0x0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar5 = FUN_0067e4f0(iVar1,*puVar4);
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 7986 ; VA 0x0067c2e0 ; FUN_0067c2e0 */

uint FUN_0067c2e0(int param_1,uint param_2,int param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4948;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_50 = uStack_30;
  uStack_4c = uStack_2c;
  uStack_48 = uStack_28;
  uStack_44 = uStack_24;
  uStack_3c = uStack_1c;
  if (param_1 == 0) {
    uStack_18 = 0xffffffff;
    uStack_14 = 0;
  }
  else {
    uStack_18 = *(undefined4 *)(param_1 + 0x18);
    uStack_14 = *(undefined4 *)(param_1 + 0x1c);
  }
  uStack_20 = 0;
  uStack_38 = uStack_18;
  uStack_34 = uStack_14;
  uStack_1c = 0xf;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_8 = 0;
  if (*(char *)(param_3 + 1) != '\0') {
    uVar1 = *(undefined4 *)(param_3 + 4);
    FUN_0067c5c0(&param_2,&uStack_50);
    if (param_2 != 0) {
      *(undefined4 *)(param_2 + 0x3c) = uVar1;
    }
  }
  FUN_0067c5c0(&param_2,&uStack_50);
  if (param_2 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = (uint)(*(int *)(param_2 + 0x3c) != *(int *)(param_2 + 0x28));
    param_2 = uVar4;
  }
  if (0xf < uStack_3c) {
    uVar3 = uStack_3c + 1;
    uVar2 = uStack_50;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(uStack_50 - 4);
      uVar3 = uStack_3c + 0x24;
      if (0x1f < (uStack_50 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 7987 ; VA 0x0067c410 ; FUN_0067c410 */

undefined4 * __thiscall
FUN_0067c410(int *param_1,undefined4 param_2,undefined4 *param_3,uint param_4,int param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar3 = param_3;
  if ((param_3 == (undefined4 *)&DAT_02122620) || (param_3 == (undefined4 *)&DAT_02122658)) {
    iVar2 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                         &RBX::Humanoid::RTTI_Type_Descriptor,0);
    if ((iVar2 != 0) &&
       ((param_1[0xf03] != 0 &&
        (iVar2 = FUN_009b48a0(iVar2), iVar2 != *(int *)(param_1[0xf03] + 100))))) {
      return (undefined4 *)0x1;
    }
  }
  else {
    if (param_3 == (undefined4 *)&DAT_01eedac8) {
      return (undefined4 *)0x1;
    }
    if ((param_3 != &DAT_0211a3d8) && (cVar1 = FUN_00618ab0(param_3), cVar1 == '\0')) {
      return (undefined4 *)0x1;
    }
  }
  param_4 = param_4 & 0xffff;
  if (*(char *)(param_5 + 1) != '\0') {
    FUN_0067e440(param_2,param_4,*(undefined4 *)(param_5 + 4));
  }
  iVar2 = FUN_0067e4f0(param_2,param_4);
  if (iVar2 == 1) {
    return (undefined4 *)0x1;
  }
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 == '\0') {
    if (puVar3 == (undefined4 *)&DAT_0212f508) {
      return (undefined4 *)0x1;
    }
    if (puVar3 == &DAT_01ee5798) {
      return (undefined4 *)0x1;
    }
    if (param_1[0x685] != 0) {
      puVar3 = (undefined4 *)FUN_00690040(param_2,puVar3);
      return puVar3;
    }
    if ((param_1[0xee4] != 0) && (cVar1 = FUN_0068ff40(param_2,puVar3,&param_3), cVar1 != '\0')) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 7988 ; VA 0x0067c530 ; FUN_0067c530 */

int * __thiscall FUN_0067c530(int *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int *piVar2;
  int *piStack_8;
  
  piStack_8 = param_1;
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 == '\0') {
    cVar1 = FUN_006452c0(param_2);
    if (cVar1 == '\0') {
      return (int *)0x1;
    }
    if (param_1[0x685] != 0) {
      piVar2 = (int *)FUN_00690ff0(param_2,param_3);
      return piVar2;
    }
    if (param_1[0xee4] != 0) {
      cVar1 = FUN_00690e10(param_2,param_3,&piStack_8);
      if (cVar1 != '\0') {
        return piStack_8;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 7989 ; VA 0x0067c5c0 ; FUN_0067c5c0 */

undefined4 __thiscall FUN_0067c5c0(byte *param_1,undefined4 param_2,int param_3)

{
  byte bVar1;
  byte *pbStack_8;
  
  bVar1 = *param_1;
  pbStack_8 = param_1;
  pbStack_8 = (byte *)FUN_005702d0(param_3);
  FUN_009c91c0(&pbStack_8,param_3 + 0x18);
  FUN_00676e80(param_2,*(int *)(param_3 + 0x1c) + -0x61c88647 +
                       (int)pbStack_8 * 0x40 + ((uint)pbStack_8 >> 2) ^ (uint)pbStack_8,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  return param_2;
}



/* FUNCTION 7990 ; VA 0x0067c640 ; thunk_FUN_009fb740 */

void thunk_FUN_009fb740(void)

{
  int iVar1;
  
  if (DAT_01ee60cc == 0) {
    iVar1 = FUN_009fb200();
    DAT_01ee60cc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 7991 ; VA 0x0067c650 ; FUN_0067c650 */

void __thiscall FUN_0067c650(int param_1,float *param_2,float *param_3,float *param_4)

{
  *param_2 = (float)*(double *)(param_1 + 0x3c90);
  *param_3 = (float)*(double *)(param_1 + 0x3cb8);
  *param_4 = (float)*(double *)(param_1 + 0x3ce0);
  return;
}



/* FUNCTION 7992 ; VA 0x0067c6a0 ; FUN_0067c6a0 */

void FUN_0067c6a0(void)

{
  FUN_009edf10(1,0);
  return;
}



/* FUNCTION 7993 ; VA 0x0067c6c0 ; FUN_0067c6c0 */

void __thiscall FUN_0067c6c0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  double *pdVar2;
  uint uVar3;
  uint uVar4;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 auStack_50 [2];
  undefined8 uStack_48;
  undefined uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  char cStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0061f780(param_2,param_3,param_4);
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 != '\0') {
    FUN_0054ef60(param_3);
    uStack_70 = uStack_38;
    uStack_6c = uStack_34;
    uStack_68 = uStack_30;
    uStack_64 = uStack_2c;
    uStack_5c = uStack_24;
    if (param_2 == 0) {
      uStack_18._0_4_ = 0xffffffff;
      uStack_18._4_4_ = 0;
    }
    else {
      uStack_18._0_4_ = *(undefined4 *)(param_2 + 0x18);
      uStack_18._4_4_ = *(undefined4 *)(param_2 + 0x1c);
    }
    uStack_58 = (undefined4)uStack_18;
    uStack_54 = uStack_18._4_4_;
    uStack_28 = 0;
    uStack_24 = 0xf;
    uStack_38 = uStack_38 & 0xffffff00;
    uStack_8 = 0;
    auStack_50[0] = 0;
    uStack_40 = 0;
    uStack_3c = 0xffffffff;
    uStack_48 = 0;
    FUN_00676780(&iStack_20,&uStack_70,&uStack_70,auStack_50);
    pdVar2 = (double *)FUN_01682800(&uStack_18);
    uStack_18 = *(double *)(param_1 + 0xed4) + *pdVar2;
    *(double *)(iStack_20 + 0x30) = uStack_18;
    if (cStack_1c == '\0') {
      if (*(char *)(iStack_20 + 0x38) != '\0') {
        *(int *)(iStack_20 + 0x28) = *(int *)(iStack_20 + 0x28) + 1;
        *(undefined *)(iStack_20 + 0x38) = 0;
      }
    }
    else {
      FUN_00680510(iStack_20 + 8);
    }
    if (0xf < uStack_5c) {
      uVar4 = uStack_5c + 1;
      uVar3 = uStack_70;
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(uStack_70 - 4);
        uVar4 = uStack_5c + 0x24;
        if (0x1f < (uStack_70 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7994 ; VA 0x0067c830 ; FUN_0067c830 */

void __thiscall
FUN_0067c830(int param_1,int param_2,undefined4 param_3,uint param_4,undefined4 param_5)

{
  int iVar1;
  char cVar2;
  double *pdVar3;
  ulonglong uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined8 uStack_c;
  
  FUN_00620180(param_2,param_3,param_4,param_5);
  cVar2 = FUN_00683840(param_2,param_4,param_3);
  if (cVar2 != '\0') {
    uStack_30 = 0;
    uStack_28 = 0;
    uStack_20 = uStack_20 & 0xffffff00;
    uStack_1c = 0xffffffff;
    if (param_2 == 0) {
      uStack_c = 0xffffffff;
    }
    else {
      uStack_c = *(undefined8 *)(param_2 + 0x18);
    }
    uStack_14 = (int)uStack_c;
    uStack_58 = CONCAT44((int)uStack_c,param_4) & 0xffffffff0000ffff;
    uStack_50 = uStack_c._4_4_;
    uStack_48 = 0;
    uStack_44 = uStack_2c;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_38 = CONCAT44(0xffffffff,uStack_20);
    uStack_18 = param_4 & 0xffff;
    FUN_006769c0(&uStack_c,&uStack_58,&uStack_58);
    iVar1 = (int)uStack_c;
    if (uStack_c._4_1_ != '\0') {
      pdVar3 = (double *)FUN_01682800(&uStack_c);
      *(double *)(iVar1 + 0x20) = *pdVar3 + *(double *)(param_1 + 0x3b08);
      if (param_2 == 0) {
        uStack_c._0_4_ = 0xffffffff;
        uStack_c._4_4_ = 0;
      }
      else {
        uStack_c._0_4_ = *(undefined4 *)(param_2 + 0x18);
        uStack_c._4_4_ = *(undefined4 *)(param_2 + 0x1c);
      }
      uStack_14 = (int)uStack_c;
      uStack_10 = uStack_c._4_4_;
      uStack_18 = param_4 & 0xffff;
      FUN_006805f0(&uStack_18);
      return;
    }
    if (*(char *)((int)uStack_c + 0x28) != '\0') {
      *(int *)((int)uStack_c + 0x18) = *(int *)((int)uStack_c + 0x18) + 1;
      *(undefined *)((int)uStack_c + 0x28) = 0;
      pdVar3 = (double *)FUN_01682800(&uStack_c);
      *(double *)(iVar1 + 0x20) = *pdVar3 + *(double *)(param_1 + 0x3b08);
    }
  }
  return;
}



/* FUNCTION 7995 ; VA 0x0067c9b0 ; FUN_0067c9b0 */

void __fastcall FUN_0067c9b0(int param_1)

{
  undefined4 uVar1;
  char cVar2;
  double *pdVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x3c2a) != '\0') {
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1 + 0x3c40);
  FUN_00933940();
  if (DAT_01d5b208 != '\0') {
    *(bool *)(*(int *)(param_1 + 0x3c0c) + 0x4c7) = (*(uint *)(param_1 + 0x3808) & 0x40) != 0;
  }
  FUN_008a65e0(*(undefined4 *)(param_1 + 0x1dc0),0);
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"ServerReplicator:InstallRemotePlayer - LoadCharacter",0);
  }
  *(undefined *)(param_1 + 0x3c2a) = 1;
  pdVar3 = (double *)FUN_016830f0();
  FUN_0151fb00("PlayerInstalled",*pdVar3 - *(double *)(param_1 + 0x3bc0));
  if (*(int *)(param_1 + 0x1a18) != 0) {
    cVar2 = FUN_00afc8c0();
    uStack_14 = CONCAT31(uStack_14._1_3_,1);
    if (cVar2 != '\0') goto LAB_0067caa0;
  }
  uStack_14 = uStack_14 & 0xffffff00;
LAB_0067caa0:
  FUN_0151fcf0("HasTerrain",uStack_14);
  iVar4 = FUN_0061f4a0();
  FUN_0151fc50("BytesSent",*(undefined4 *)(iVar4 + 0x60),*(undefined4 *)(iVar4 + 100));
  uVar1 = DAT_01ead4a0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("ServerJoin",10);
  uStack_8 = 0;
  FUN_01520d20(auStack_30,uVar1,0);
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7996 ; VA 0x0067cb60 ; FUN_0067cb60 */

int FUN_0067cb60(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint in_stack_00000020;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4998;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&piStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (piStack_1c == (int *)0x0) {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) goto LAB_0067cbdc;
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar3 = (**(code **)(*piStack_1c + 0x284))(&param_3);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) goto LAB_0067cbdc;
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
  }
  if (iVar2 == 1) {
    iVar3 = (**(code **)(*param_2 + 4))();
  }
LAB_0067cbdc:
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if ((param_3 - *(int *)(param_3 + -4)) - 4U < 0x20) {
        iVar3 = FUN_0067cc65();
        return iVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    iVar3 = FUN_01674ea0(param_3,in_stack_00000020 + 1);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 7997 ; VA 0x0067cc52 ; Catch@0067cc52 */

undefined4 Catch_0067cc52(void)

{
  FUN_0062b370(0x106);
  return 0x67cc18;
}



/* FUNCTION 7998 ; VA 0x0067cc65 ; FUN_0067cc65 */

void __fastcall FUN_0067cc65(undefined4 param_1,undefined4 param_2)

{
  int unaff_EBP;
  
  FUN_01674ea0(param_1,param_2);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 7999 ; VA 0x0067cc90 ; FUN_0067cc90 */

undefined4 FUN_0067cc90(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(*(code *)*param_1)(param_1[1]);
  return *puVar1;
}


