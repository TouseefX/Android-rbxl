/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 17000 ; VA 0x00943620 ; FUN_00943620 */

int * __thiscall FUN_00943620(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00da6440();
  if (iVar2 != iVar3) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar5 = (int *)thunk_FUN_00da6130();
    *param_2 = 0;
    param_2[1] = 0;
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *piVar5;
    param_2[1] = piVar5[1];
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *param_1;
  iVar3 = FUN_00da6440();
  if (iVar2 == iVar3) {
    piVar5 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar5 = (int *)0x0;
    }
    *param_2 = 0;
    param_2[1] = 0;
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *piVar5;
    param_2[1] = piVar5[1];
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17001 ; VA 0x00943750 ; FUN_00943750 */

void FUN_00943750(void)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3258;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,4);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    *puVar3 = boost::thread_specific_ptr<int>::delete_data::vftable;
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 17002 ; VA 0x009437b0 ; FUN_009437b0 */

undefined4 * FUN_009437b0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca7bc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = GetProcessHeap(0,0x50);
  puVar4 = (undefined4 *)HeapAlloc(uVar3);
  if (puVar4 == (undefined4 *)0x0) {
    uVar3 = FUN_0054fbc0();
    uStack_8 = 0;
    FUN_005648a0(uVar3);
  }
  else {
    *puVar4 = boost::detail::thread_data_base::vftable;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    puVar4[4] = 0;
    puVar4[5] = 0;
    uVar3 = FUN_00575ab0();
    puVar4[4] = uVar3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    puVar4[8] = 0;
    puVar4[9] = 0;
    puVar4[10] = 0;
    puVar4[0xb] = 0;
    puVar4[0xc] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar5 = CreateEventA(0,1,0,0);
    if (iVar5 != 0) {
      puVar4[0xd] = iVar5;
      *(undefined *)(puVar4 + 0xe) = 1;
      *puVar4 = boost::detail::
                thread_data<class_boost::_bi::bind_t<void,class_boost::_mfi::mf0<void,class_RBX::ScriptContext>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::ScriptContext*>_>_>_>
                ::vftable;
      uVar3 = param_1[1];
      uVar1 = param_1[2];
      uVar2 = param_1[3];
      puVar4[0x10] = *param_1;
      puVar4[0x11] = uVar3;
      puVar4[0x12] = uVar1;
      puVar4[0x13] = uVar2;
      ExceptionList = pvStack_10;
      return puVar4;
    }
  }
  uVar3 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar3);
}



/* FUNCTION 17003 ; VA 0x009438a5 ; Catch_All@009438a5 */

void Catch_All_009438a5(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17004 ; VA 0x009438f0 ; FUN_009438f0 */

void __thiscall FUN_009438f0(undefined4 *param_1,int *param_2,int *param_3)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_c [4];
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  if (param_2 != param_3) {
    do {
      uVar2 = *puStack_8;
      iVar5 = FUN_0093f460(param_2 + 4);
      FUN_009408f0(auStack_c,uVar2,iVar5 + 0x10,iVar5);
      piVar3 = (int *)param_2[2];
      if (*(char *)((int)piVar3 + 0xd) == '\0') {
        cVar1 = *(char *)(*piVar3 + 0xd);
        param_2 = piVar3;
        piVar3 = (int *)*piVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar3 + 0xd);
          param_2 = piVar3;
          piVar3 = (int *)*piVar3;
        }
      }
      else {
        cVar1 = *(char *)(param_2[1] + 0xd);
        piVar4 = (int *)param_2[1];
        piVar3 = param_2;
        while ((param_2 = piVar4, cVar1 == '\0' && (piVar3 == (int *)param_2[2]))) {
          cVar1 = *(char *)(param_2[1] + 0xd);
          piVar4 = (int *)param_2[1];
          piVar3 = param_2;
        }
      }
    } while (param_2 != param_3);
  }
  return;
}



/* FUNCTION 17005 ; VA 0x00943970 ; FUN_00943970 */

void __thiscall FUN_00943970(undefined4 param_1,int *param_2)

{
  undefined8 uVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_01674e20(0x50,param_1);
  uVar1 = DAT_018ce300;
  if (puVar2 != (undefined4 *)0x0) {
    puVar2[1] = 1;
    puVar2[2] = 1;
    *puVar2 = std::_Ref_count_obj<struct_RBX::ScriptContext::GlobalState>::vftable;
    *(undefined8 *)(puVar2 + 4) = uVar1;
    puVar2[6] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
    puVar2[9] = 0;
    *(undefined *)(puVar2 + 0xc) = 1;
    *(undefined8 *)(puVar2 + 10) = 0;
    puVar2[0xe] = 0;
    *(undefined8 *)(puVar2 + 0x10) = 0;
    puVar2[0x12] = 0;
    puVar2[0x13] = puVar2 + 0x13;
    *param_2 = (int)(puVar2 + 4);
    param_2[1] = (int)puVar2;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0x10;
  return;
}



/* FUNCTION 17006 ; VA 0x009439f0 ; FUN_009439f0 */

int * FUN_009439f0(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_3c [4];
  undefined4 uStack_38;
  undefined4 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca7ea;
  pvStack_10 = ExceptionList;
  uStack_34 = 0x140;
  uStack_38 = 0x943a18;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20();
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::ClearUnusedLuaRefsJob>::vftable;
    iVar1 = *param_2;
    piVar2 = (int *)param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    iVar3 = *(int *)(iVar1 + 0x34);
    uStack_34 = 0xb;
    uStack_8 = 1;
    FUN_00944080(auStack_3c,-(uint)(iVar3 != 0) & iVar3 + 4U);
    FUN_00a360a0("ClearUnusedLuaRefsJob",1,0);
    piVar4[4] = (int)RBX::ClearUnusedLuaRefsJob::vftable;
    piVar4[0x4e] = 0;
    piVar4[0x4f] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[2] = piVar2[2] + 1;
      UNLOCK();
    }
    piVar4[0x4e] = iVar1;
    piVar4[0x4f] = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943add;
        (**(code **)*piVar2)();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_34 = 0x943aef;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piVar4 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar4;
  if ((piVar2 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))) {
    piVar5 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar4[6] = (int)piVar2;
    piVar2 = (int *)piVar4[7];
    piVar4[7] = (int)piVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943b3d;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943b50;
        (**(code **)*piVar5)();
        LOCK();
        piVar4 = piVar5 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          uStack_34 = 0x943b5f;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17007 ; VA 0x00943b80 ; FUN_00943b80 */

int * FUN_00943b80(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_3c [4];
  undefined4 uStack_38;
  undefined4 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca7ea;
  pvStack_10 = ExceptionList;
  uStack_34 = 0x140;
  uStack_38 = 0x943ba8;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20();
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::GcJob>::vftable;
    iVar1 = *param_2;
    piVar2 = (int *)param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    iVar3 = *(int *)(iVar1 + 0x34);
    uStack_34 = 4;
    uStack_8 = 1;
    FUN_00944080(auStack_3c,-(uint)(iVar3 != 0) & iVar3 + 4U);
    FUN_00a360a0("LuaGc",1,0);
    piVar4[4] = (int)RBX::GcJob::vftable;
    piVar4[0x4e] = 0;
    piVar4[0x4f] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[2] = piVar2[2] + 1;
      UNLOCK();
    }
    piVar4[0x4e] = iVar1;
    piVar4[0x4f] = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943c6d;
        (**(code **)*piVar2)();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_34 = 0x943c7f;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piVar4 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar4;
  if ((piVar2 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))) {
    piVar5 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar4[6] = (int)piVar2;
    piVar2 = (int *)piVar4[7];
    piVar4[7] = (int)piVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943ccd;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943ce0;
        (**(code **)*piVar5)();
        LOCK();
        piVar4 = piVar5 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          uStack_34 = 0x943cef;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17008 ; VA 0x00943d10 ; FUN_00943d10 */

int * FUN_00943d10(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_3c [4];
  undefined4 uStack_38;
  undefined4 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca7ea;
  pvStack_10 = ExceptionList;
  uStack_34 = 0x140;
  uStack_38 = 0x943d38;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20();
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::WaitingParallelScriptsJob>::vftable;
    iVar1 = *param_2;
    piVar2 = (int *)param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    iVar3 = *(int *)(iVar1 + 0x34);
    uStack_34 = 4;
    uStack_8 = 1;
    FUN_00944080(auStack_3c,-(uint)(iVar3 != 0) & iVar3 + 4U);
    FUN_00a360a0("WaitingParallelScriptsJob",1,0);
    piVar4[4] = (int)RBX::WaitingParallelScriptsJob::vftable;
    piVar4[0x4e] = 0;
    piVar4[0x4f] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[2] = piVar2[2] + 1;
      UNLOCK();
    }
    piVar4[0x4e] = iVar1;
    piVar4[0x4f] = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943dfd;
        (**(code **)*piVar2)();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_34 = 0x943e0f;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piVar4 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar4;
  if ((piVar2 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))) {
    piVar5 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar4[6] = (int)piVar2;
    piVar2 = (int *)piVar4[7];
    piVar4[7] = (int)piVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943e5d;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_34 = 0x943e70;
        (**(code **)*piVar5)();
        LOCK();
        piVar4 = piVar5 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          uStack_34 = 0x943e7f;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17009 ; VA 0x00943ea0 ; FUN_00943ea0 */

int * FUN_00943ea0(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  double dVar6;
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca830;
  pvStack_10 = ExceptionList;
  uStack_38 = 0x148;
  uStack_3c = 0x943ec8;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20();
  uStack_8 = 0;
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::WaitingScriptsJob>::vftable;
    iVar1 = *param_2;
    piVar2 = (int *)param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    iVar4 = *(int *)(iVar1 + 0x34);
    uStack_38 = 4;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_00944080(auStack_40,-(uint)(iVar4 != 0) & iVar4 + 4U);
    FUN_00a360a0("WaitingScriptJob",1,0);
    uStack_8._0_1_ = 2;
    piVar3[4] = (int)RBX::WaitingScriptsJob::vftable;
    if ((DAT_01d64508 == '\0') || (DAT_01ee29f4 < 1)) {
      uStack_38 = 0x943f83;
      iVar4 = FUN_0095c9f0();
      dVar6 = (double)*(float *)(iVar4 + 0x6c) / DAT_018cf108;
    }
    else {
      dVar6 = (double)DAT_01ee29f4 / DAT_018c0d70;
    }
    *(double *)(piVar3 + 0x4e) = dVar6;
    piVar3[0x50] = 0;
    piVar3[0x51] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[2] = piVar2[2] + 1;
      UNLOCK();
    }
    piVar3[0x50] = iVar1;
    piVar3[0x51] = (int)piVar2;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_38 = 0x943fd4;
    FUN_00a361f0();
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_38 = 0x943fe7;
        (**(code **)*piVar2)();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_38 = 0x943ff7;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piVar3 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar3;
  if ((piVar2 != (int *)0x0) && ((piVar3[7] == 0 || (*(int *)(piVar3[7] + 4) == 0)))) {
    piVar5 = piVar3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar3[6] = (int)piVar2;
    piVar2 = (int *)piVar3[7];
    piVar3[7] = (int)piVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_38 = 0x944045;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_38 = 0x944058;
        (**(code **)*piVar5)();
        LOCK();
        piVar3 = piVar5 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          uStack_38 = 0x944067;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17010 ; VA 0x00944080 ; FUN_00944080 */

int * FUN_00944080(int *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_2 == 0) {
    piStack_20 = (int *)0x0;
    puVar6 = &uStack_24;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
    iVar7 = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined4 *)FUN_005c9c10(auStack_2c);
    uStack_8 = 0;
    iVar7 = FUN_0170d75d(*puVar6,0,&RBX::Reflection::DescribedBase::RTTI_Type_Descriptor,
                         &RBX::DataModel::RTTI_Type_Descriptor,0);
    if (iVar7 == 0) {
      iVar7 = 0;
      piStack_18 = (int *)0x0;
      puVar6 = &uStack_1c;
      bVar5 = true;
      bVar4 = true;
      bVar3 = false;
    }
    else {
      piStack_18 = (int *)puVar6[1];
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
        piStack_18 = (int *)puVar6[1];
      }
      bVar5 = true;
      bVar4 = true;
      bVar3 = false;
      puVar6 = &uStack_1c;
    }
  }
  *puVar6 = 0;
  *param_1 = iVar7;
  param_1[1] = puVar6[1];
  puVar6[1] = 0;
  piVar2 = piStack_20;
  if ((bVar3) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_20[1] + -1;
    piStack_20[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_18;
  if ((bVar4) && (piStack_18 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((bVar5) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_28[1] + -1;
    piStack_28[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar2 = piStack_28 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17011 ; VA 0x009441d0 ; FUN_009441d0 */

void FUN_009441d0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca858;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*param_2 + 0x340);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088c8c0();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar1 = *(int *)(*param_2 + 0x270);
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar1 = *param_2;
  uStack_8 = 0;
  iVar2 = *(int *)(iVar1 + 0x1a0);
  iVar3 = FUN_0088cdc0();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar2 = iVar1 + 0x1a8;
  if (*(int *)(iVar1 + 0x1a4) == 0) {
    iVar2 = 0;
  }
  if (*(int *)(iVar2 + 4) != 0) {
    LOCK();
    piVar4 = (int *)(*(int *)(iVar2 + 4) + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  iVar1 = *param_2;
  uStack_8._0_1_ = 1;
  iVar2 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_0088cb40();
  if (iVar2 == iVar3) {
    iVar2 = iVar1 + 0xd8;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      iVar2 = 0;
    }
    FUN_0054ef60(iVar2);
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar1 = *param_2;
    iVar2 = FUN_0088cb40();
    if (iVar1 == iVar2) {
      piVar4 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar4 = (int *)0x0;
      }
      FUN_0054ef60(piVar4);
      uStack_8 = 0xffffffff;
      FUN_0094f740(param_1);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 17012 ; VA 0x00944360 ; FUN_00944360 */

void * __thiscall FUN_00944360(int param_1,undefined4 param_2)

{
  int iVar1;
  void *pvVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017bbe08;
  piVar4 = *(int **)(param_1 + 0x2c);
  pvVar2 = ExceptionList;
  if (piVar4 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(param_1 + 0x2c);
      piVar3 = *(int **)(param_1 + 0x30);
    }
    iVar1 = piVar4[1];
    iVar5 = *piVar4;
    uStack_8 = 0;
    pvVar2 = pvStack_10;
    for (; iVar5 != iVar1; iVar5 = iVar5 + 8) {
      FUN_00948b50(iVar5);
      pvVar2 = (void *)FUN_00944360(param_2);
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      pvVar2 = (void *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar2 = (void *)(**(code **)*piVar3)();
        LOCK();
        piVar4 = piVar3 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar2 = (void *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 17013 ; VA 0x00944410 ; FUN_00944410 */

undefined4 * __thiscall
FUN_00944410(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined auStack_458 [1080];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca8bd;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_0093f0f0();
  FUN_009cb970(uVar1,param_3,param_9,param_10,param_11);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ScriptContext,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>_RBX::ScriptContext::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(param_7);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  FUN_0086e3d0(param_8);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_458,&puStack_20,param_9);
  iStack_8._0_1_ = 6;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 7;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_458,0xd8,5,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17014 ; VA 0x009445c0 ; FUN_009445c0 */

uint * __thiscall
FUN_009445c0(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,uint param_6,
            uint param_7,undefined8 param_8)

{
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca8e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  if (uStack_54 != 0) {
    *param_1 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_4c;
      param_1[3] = uStack_48;
      param_1[4] = uStack_44;
      param_1[5] = uStack_40;
      *(undefined8 *)(param_1 + 6) = uStack_3c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17015 ; VA 0x00944760 ; FUN_00944760 */

uint * __thiscall
FUN_00944760(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,uint param_6,
            uint param_7,undefined8 param_8)

{
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca918;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  if (uStack_54 != 0) {
    *param_1 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_4c;
      param_1[3] = uStack_48;
      param_1[4] = uStack_44;
      param_1[5] = uStack_40;
      *(undefined8 *)(param_1 + 6) = uStack_3c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17016 ; VA 0x00944900 ; FUN_00944900 */

undefined4 * __thiscall FUN_00944900(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017ca938;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  ExceptionList = &pvStack_10;
  *param_1 = piVar1;
  if (piVar1 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17017 ; VA 0x009449a0 ; FUN_009449a0 */

undefined4 * __thiscall
FUN_009449a0(undefined4 *param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9)

{
  int iVar1;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca978;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_3 != 0) {
    uStack_38 = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_30,0);
    }
    else {
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      ExceptionList = &pvStack_10;
    }
  }
  piStack_18 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_2 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = 6;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17018 ; VA 0x00944b60 ; FUN_00944b60 */

undefined4 * __thiscall FUN_00944b60(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca9a0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  ExceptionList = &pvStack_10;
  *param_1 = piVar1;
  if (piVar1 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17019 ; VA 0x00944c50 ; FUN_00944c50 */

undefined4 __thiscall
FUN_00944c50(undefined4 param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
            uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca9d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != 0) {
    uStack_40 = param_10;
    if ((param_10 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_12;
      uStack_50 = 0x944cbd;
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_12;
      uStack_34 = param_13;
      uStack_30 = param_14;
      puStack_2c = (undefined4 *)param_15;
      uStack_28 = param_16;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_58,0);
    }
    else {
      uStack_58 = param_5;
      uStack_54 = param_6;
      uStack_50 = param_7;
      puStack_4c = param_8;
      uStack_48 = param_9;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00945040(param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_2 != (int *)0x0)) {
      uStack_28 = CONCAT44(0x944d46,(undefined4)uStack_28);
      FUN_00d88950();
      uStack_28 = CONCAT44(0x10,param_2);
      puStack_2c = (undefined4 *)0x944d4e;
      FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_5;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x944d79;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_12;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x944da7;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17020 ; VA 0x00944dc0 ; FUN_00944dc0 */

undefined4 * __thiscall FUN_00944dc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  uVar2 = param_2[7];
  uVar3 = param_2[8];
  uVar4 = param_2[9];
  param_1[6] = param_2[6];
  param_1[7] = uVar2;
  param_1[8] = uVar3;
  param_1[9] = uVar4;
  *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
  param_1[0xc] = param_2[0xc];
  param_1[0xe] = param_2[0xe];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  return param_1;
}



/* FUNCTION 17021 ; VA 0x00944e50 ; FUN_00944e50 */

undefined4 * __thiscall FUN_00944e50(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17022 ; VA 0x00944ef0 ; FUN_00944ef0 */

undefined4 * __thiscall
FUN_00944ef0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  param_1[4] = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17023 ; VA 0x00945040 ; FUN_00945040 */

undefined4 * __thiscall
FUN_00945040(undefined4 *param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
            uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017caa18;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_3 != 0) {
    uStack_38 = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_30,0);
    }
    else {
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      ExceptionList = &pvStack_10;
    }
  }
  piStack_18 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8._0_1_ = 6;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  param_1[10] = 0;
  if (param_10 != 0) {
    param_1[10] = param_10;
    if ((param_10 & 1) == 0) {
      (**(code **)(param_10 & 0xfffffffe))(&param_12,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_12;
      param_1[0xd] = param_13;
      param_1[0xe] = param_14;
      param_1[0xf] = param_15;
      *(undefined8 *)(param_1 + 0x10) = param_16;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_2 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  uStack_8 = 9;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17024 ; VA 0x00945270 ; FUN_00945270 */

int __thiscall
FUN_00945270(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11,undefined4 param_12)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00944ef0(param_2,param_3,param_4,param_5,param_6);
  *(undefined4 *)(param_1 + 0x18) = param_7;
  *(undefined4 *)(param_1 + 0x1c) = param_8;
  *(undefined4 *)(param_1 + 0x20) = param_9;
  *(undefined4 *)(param_1 + 0x24) = param_10;
  *(undefined8 *)(param_1 + 0x28) = param_11;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x30) = param_12;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17025 ; VA 0x009453b0 ; FUN_009453b0 */

int __thiscall
FUN_009453b0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00945270(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12);
  *(undefined4 *)(param_1 + 0x38) = param_13;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x40) = param_14;
  *(undefined4 *)(param_1 + 0x44) = param_15;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17026 ; VA 0x00945500 ; FUN_00945500 */

uint * __thiscall FUN_00945500(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017caa38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = param_2 * 0x10;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    puVar4 = (undefined4 *)*param_1;
    uStack_8 = 1;
    for (; param_2 != 0; param_2 = param_2 - 1) {
      *puVar4 = *param_3;
      FUN_00945610(param_3 + 1);
      puVar4 = puVar4 + 4;
    }
    param_1[1] = (uint)puVar4;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17027 ; VA 0x009455f8 ; Catch_All@009455f8 */

void Catch_All_009455f8(void)

{
  FUN_0094a060();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17028 ; VA 0x00945610 ; FUN_00945610 */

int * __thiscall FUN_00945610(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = (param_2[1] - *param_2) / 0xc;
  if (uVar1 != 0) {
    if (0x15555555 < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00618050(uVar1);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = *param_1 + uVar1 * 0xc;
    iVar2 = FUN_009414e0(*param_2,param_2[1],*param_1,param_1);
    param_1[1] = iVar2;
  }
  return param_1;
}



/* FUNCTION 17029 ; VA 0x00945690 ; FUN_00945690 */

undefined4 * __thiscall FUN_00945690(undefined4 *param_1,int param_2)

{
  char cVar1;
  undefined *puVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar1 = FUN_00616b10(param_2);
  if (cVar1 != '\0') {
    puVar2 = (undefined *)*param_1;
    if (param_2 != 0) {
      do {
        *(undefined4 *)(puVar2 + 0x10) = 0;
        *(undefined4 *)(puVar2 + 0x14) = 0xf;
        *puVar2 = 0;
        puVar2 = puVar2 + 0x18;
        param_2 = param_2 + -1;
      } while (param_2 != 0);
    }
    FUN_00559570(puVar2,puVar2,param_1);
    param_1[1] = puVar2;
  }
  return param_1;
}



/* FUNCTION 17030 ; VA 0x009456f0 ; FUN_009456f0 */

undefined4 * __thiscall FUN_009456f0(undefined4 *param_1,uint *param_2)

{
  uint uVar1;
  undefined uVar2;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  undefined auStack_4c [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017caa63;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[8] = 0;
  uVar2 = DAT_01ee2ab1;
  uStack_8 = 1;
  if (*param_2 != 0) {
    uVar1 = *param_2;
    if (uVar1 != 0) {
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_64,0);
      }
      else {
        uStack_64 = param_2[2];
        uStack_60 = param_2[3];
        uStack_5c = param_2[4];
        uStack_58 = param_2[5];
        uStack_54 = *(undefined8 *)(param_2 + 6);
      }
    }
    FUN_00942360(auStack_4c,FUN_00954450,uVar2);
    uStack_54 = CONCAT44(0x94579d,(undefined4)uStack_54);
    FUN_0093eaf0();
  }
  uVar2 = DAT_01ee2ab1;
  if (param_2[8] != 0) {
    uVar1 = param_2[8];
    if (uVar1 != 0) {
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,&uStack_64,0);
      }
      else {
        uStack_64 = param_2[10];
        uStack_60 = param_2[0xb];
        uStack_5c = param_2[0xc];
        uStack_58 = param_2[0xd];
        uStack_54 = *(undefined8 *)(param_2 + 0xe);
      }
    }
    FUN_00942150(auStack_4c,FUN_00953840,uVar2);
    uStack_54 = CONCAT44(0x945810,(undefined4)uStack_54);
    FUN_0093e980();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17031 ; VA 0x00945830 ; FUN_00945830 */

uint * __thiscall FUN_00945830(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017caa78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[0xb];
      uVar2 = param_2[0xc];
      uVar3 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17032 ; VA 0x00945900 ; FUN_00945900 */

undefined4 * __fastcall FUN_00945900(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0xf;
  *(undefined *)(param_1 + 9) = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0xf;
  *(undefined *)(param_1 + 0xf) = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0xf;
  *(undefined *)(param_1 + 0x15) = 0;
  return param_1;
}



/* FUNCTION 17033 ; VA 0x00945960 ; FUN_00945960 */

undefined8 * __fastcall FUN_00945960(undefined8 *param_1)

{
  *param_1 = DAT_018ce300;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((int)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  *(undefined *)(param_1 + 4) = 1;
  param_1[3] = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  param_1[6] = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(int *)((int)param_1 + 0x3c) = (int)param_1 + 0x3c;
  return param_1;
}



/* FUNCTION 17034 ; VA 0x009459a0 ; FUN_009459a0 */

undefined4 * __fastcall FUN_009459a0(undefined4 *param_1)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  undefined8 uVar10;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cacad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ScriptContext,class_RBX::ServiceInstance>::vftable;
  uVar2 = FUN_0093f0f0();
  param_1[3] = uVar2;
  param_1[0x16] = RBX::IScriptFilter::vftable;
  *param_1 = RBX::ScriptContext::vftable;
  param_1[0x16] = RBX::ScriptContext::vftable;
  param_1[0x18] = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  param_1[0x17] = RBX::Lua::WeakThreadRef::vftable;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  iVar9 = 2;
  do {
    FUN_00945960();
    iVar9 = iVar9 + -1;
  } while (iVar9 != 0);
  puVar5 = param_1 + 0x3e;
  *puVar5 = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  puStack_14 = puVar5;
  uVar2 = FUN_0068a6a0(0,0);
  param_1[0x3f] = uVar2;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  uStack_8._0_1_ = 4;
  *puVar5 = 0x3f800000;
  FUN_005cb500(8);
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  puVar5 = param_1 + 0x4f;
  param_1[0x4d] = 0xabf77f4e;
  param_1[0x4e] = 0x8a5180d;
  uStack_8._0_1_ = 7;
  *puVar5 = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  puStack_14 = puVar5;
  puVar3 = (undefined4 *)FUN_01674e20(8);
  *puVar5 = puVar3;
  *puVar3 = 0;
  puVar3[1] = 0;
  *(undefined4 **)*puVar5 = puVar5;
  param_1[0x54] = 0;
  puVar5 = param_1 + 0x55;
  uStack_8._0_1_ = 8;
  *puVar5 = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  puStack_14 = puVar5;
  puVar3 = (undefined4 *)FUN_01674e20(8);
  *puVar5 = puVar3;
  *puVar3 = 0;
  puVar3[1] = 0;
  *(undefined4 **)*puVar5 = puVar5;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  *(undefined *)((int)param_1 + 0x181) = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  *(undefined *)(param_1 + 99) = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  puVar5 = param_1 + 0x66;
  uStack_8._0_1_ = 0xe;
  *puVar5 = 0;
  param_1[0x67] = 0;
  puStack_14 = puVar5;
  uVar2 = FUN_00601dc0();
  *puVar5 = uVar2;
  param_1[0x68] = 0;
  puStack_14 = (undefined4 *)0xb;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  uVar10 = DAT_018c45c8;
  *(undefined *)(param_1 + 0x6e) = 0;
  *(undefined8 *)(param_1 + 0x70) = uVar10;
  *(undefined *)(param_1 + 0x72) = 0;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar6 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar4;
  }
  param_1[0x73] = *ppuVar6;
  param_1[0x74] = 0;
  param_1[0x75] = 0x3f800000;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  uVar10 = DAT_018ce300;
  uStack_8._0_1_ = 0x10;
  *(undefined8 *)(param_1 + 0x78) = 0;
  *(undefined8 *)(param_1 + 0x7a) = uVar10;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0;
  param_1[0x7f] = 0;
  *(undefined *)(param_1 + 0x82) = 1;
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined8 *)(param_1 + 0x84) = uVar10;
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  *(undefined *)(param_1 + 0x8c) = 1;
  *(undefined8 *)(param_1 + 0x8a) = 0;
  *(undefined8 *)(param_1 + 0x8e) = uVar10;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  param_1[0x92] = 0;
  param_1[0x93] = 0;
  *(undefined *)(param_1 + 0x96) = 1;
  *(undefined8 *)(param_1 + 0x94) = 0;
  FUN_016827e0(param_1 + 0x98);
  FUN_016827e0(param_1 + 0x9a);
  param_1[0x9c] = 0;
  param_1[0x9d] = 0;
  param_1[0x9e] = 0;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0;
  param_1[0xa1] = 0;
  param_1[0xa2] = 0;
  *(undefined *)(param_1 + 0xa4) = 0;
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0;
  param_1[0xa8] = 0;
  param_1[0xa9] = 0;
  param_1[0xaa] = 0;
  param_1[0xab] = 0;
  param_1[0xac] = 0;
  param_1[0xad] = 0;
  param_1[0xae] = 0;
  param_1[0xaf] = 0;
  param_1[0xb0] = 0;
  param_1[0xb1] = 0;
  param_1[0xb2] = 0;
  param_1[0xb3] = 0;
  param_1[0xb4] = 0;
  FUN_016dee4c(param_1 + 0xb5,2);
  *(undefined *)(param_1 + 0xc1) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar6 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar4;
  }
  param_1[0xc2] = *ppuVar6;
  param_1[0xc3] = 0;
  param_1[0xc4] = 0x3f800000;
  param_1[0xc5] = 0;
  param_1[0xc6] = 0;
  *(undefined *)(param_1 + 199) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar6 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar4;
  }
  param_1[200] = *ppuVar6;
  param_1[0xc9] = 0;
  param_1[0xca] = 0x3f800000;
  param_1[0xcb] = 0;
  param_1[0xcc] = 0;
  param_1[0xd0] = 0;
  param_1[0xd1] = 0;
  param_1[0xd2] = 0;
  param_1[0xd3] = 0;
  param_1[0xd4] = 0;
  param_1[0xd5] = 0;
  param_1[0xd6] = 0;
  param_1[0xd7] = 0;
  uStack_8._0_1_ = 0x20;
  FUN_00610ca0();
  param_1[0xd9] = 0;
  param_1[0xda] = 0;
  param_1[0xdb] = 0;
  param_1[0xdc] = 0;
  param_1[0xdd] = 0;
  param_1[0xde] = 0;
  param_1[0xdf] = 0;
  param_1[0xe0] = 0;
  param_1[0xe1] = 0;
  param_1[0xe2] = 0;
  *(undefined *)(param_1 + 0xe3) = 0;
  *(undefined8 *)(param_1 + 0xe4) = 0;
  param_1[0xe6] = 0;
  param_1[0xe7] = 0;
  param_1[0xe8] = 0;
  puVar5 = param_1 + 0xe9;
  uStack_8._0_1_ = 0x24;
  *puVar5 = 0;
  param_1[0xea] = 0;
  puStack_14 = puVar5;
  uVar2 = FUN_00949c30();
  *puVar5 = uVar2;
  puStack_14 = param_1 + 0xeb;
  uStack_8._0_1_ = 0x25;
  FUN_016f4053(puStack_14,0x1c,2,FUN_0089ab00,FUN_00d88aa0);
  uStack_8._0_1_ = 0x26;
  param_1[0xf9] = 1;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Script Context",0xe);
  uStack_8._0_1_ = 0x27;
  FUN_008a6520(auStack_38);
  uVar10 = CONCAT44(uStack_20._4_4_,(undefined4)uStack_20);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar8 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar8) - 4) {
LAB_009461b8:
        uStack_20 = uVar10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uVar10 = FUN_0152dab0("Script","$OverflowToken",0xffffffff);
  *(undefined8 *)(param_1 + 0xce) = uVar10;
  puStack_14 = (undefined4 *)0x0;
  do {
    puVar3 = puStack_14;
    puVar5 = (undefined4 *)FUN_01675640(auStack_38,"$UserToken_%d",puStack_14);
    uStack_8._0_1_ = 0x28;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    uVar10 = FUN_0152dab0("Script",puVar5,0xffffffff);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
    uStack_20 = uVar10;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      uVar7 = auStack_38[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_38[0] - 4);
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar7) - 4) goto LAB_009461b8;
      }
      FUN_01674ea0(uVar7,uVar8);
      puVar3 = puStack_14;
    }
    puVar1 = (undefined8 *)param_1[0xaf];
    if ((undefined8 *)param_1[0xb0] == puVar1) {
      FUN_00805800(puVar1,&uStack_20);
    }
    else {
      *puVar1 = uStack_20;
      param_1[0xaf] = param_1[0xaf] + 8;
    }
    puStack_14 = (undefined4 *)((int)puVar3 + 1);
    if (99 < (int)puStack_14) {
      if (DAT_01d62bf0 != '\0') {
        if ((uint)((int)(param_1[0xa2] - param_1[0xa0]) >> 3) < 0x400) {
          FUN_00777ed0(0x400);
        }
        param_1[0xa3] = (int)(param_1[0xa2] - param_1[0xa0]) >> 3;
        ExceptionList = pvStack_10;
        return param_1;
      }
      param_1[0xa3] = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 17035 ; VA 0x009461c0 ; FUN_009461c0 */

undefined4 * __thiscall FUN_009461c0(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cacd3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  FUN_0054f510(param_2 + 6);
  uStack_8 = 0;
  FUN_0054f510(param_2 + 0xe);
  uStack_8 = 1;
  FUN_0054f510(param_2 + 0x16);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17036 ; VA 0x00946290 ; FUN_00946290 */

int __fastcall FUN_00946290(int param_1)

{
  FUN_01255470(2,0,0,0);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  return param_1;
}



/* FUNCTION 17037 ; VA 0x009462d0 ; FUN_009462d0 */

undefined4 * __thiscall FUN_009462d0(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cacf7;
  pvStack_10 = ExceptionList;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x10);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar1 == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    piVar2 = (int *)FUN_00d88510(param_2);
  }
  *param_1 = piVar2;
  if (piVar2 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17038 ; VA 0x00946350 ; FUN_00946350 */

void FUN_00946350(void)

{
  FUN_0094a0d0();
  return;
}



/* FUNCTION 17039 ; VA 0x00946360 ; FUN_00946360 */

void __fastcall FUN_00946360(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ScriptContext>::vftable;
  uVar1 = FUN_0093f0f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17040 ; VA 0x009463a0 ; thunk_FUN_0094a060 */

void __fastcall thunk_FUN_0094a060(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0094a0d0();
        iVar2 = iVar2 + 0x10;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffff0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17041 ; VA 0x009463b0 ; FUN_009463b0 */

void __fastcall FUN_009463b0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  while (puVar2 = puVar1, puVar2 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar2;
    if ((puVar2[1] == param_1) && (puVar2[1] != 0)) {
      puVar3 = puVar1;
      if ((undefined4 *)puVar2[2] != (undefined4 *)0x0) {
        *(undefined4 *)puVar2[2] = puVar1;
        puVar3 = (undefined4 *)*puVar2;
      }
      if (puVar3 != (undefined4 *)0x0) {
        puVar3[2] = puVar2[2];
      }
      *(int *)puVar2[1] = *(int *)puVar2[1] + -1;
      *puVar2 = 0;
      puVar2[2] = 0;
      puVar2[1] = 0;
    }
  }
  return;
}



/* FUNCTION 17042 ; VA 0x00946410 ; FUN_00946410 */

void __fastcall FUN_00946410(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009466b0();
  return;
}



/* FUNCTION 17043 ; VA 0x00946470 ; FUN_00946470 */

void __fastcall FUN_00946470(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x10) {
    FUN_0094a0d0();
  }
  return;
}



/* FUNCTION 17044 ; VA 0x009464a0 ; FUN_009464a0 */

void __fastcall FUN_009464a0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x40) {
    FUN_00947650();
  }
  return;
}



/* FUNCTION 17045 ; VA 0x009464d0 ; FUN_009464d0 */

void __fastcall FUN_009464d0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)param_1[1];
  for (piVar2 = (int *)*param_1; piVar2 != piVar1; piVar2 = piVar2 + 7) {
    (**(code **)(*piVar2 + 4))(0);
  }
  return;
}



/* FUNCTION 17046 ; VA 0x00946500 ; FUN_00946500 */

void __fastcall FUN_00946500(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1,0x1c,2,FUN_00d88aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17047 ; VA 0x00946540 ; FUN_00946540 */

void FUN_00946540(void)

{
  FUN_00946a50();
  return;
}



/* FUNCTION 17048 ; VA 0x00946550 ; FUN_00946550 */

void __fastcall FUN_00946550(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00946a50();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17049 ; VA 0x009465b0 ; FUN_009465b0 */

void FUN_009465b0(void)

{
  FUN_0056b650();
  return;
}



/* FUNCTION 17050 ; VA 0x009465c0 ; FUN_009465c0 */

void __fastcall FUN_009465c0(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  LOCK();
  iVar1 = *(int *)(*param_1 + 8) + -1;
  ExceptionList = &pvStack_10;
  *(int *)(*param_1 + 8) = iVar1;
  UNLOCK();
  if (iVar1 == 0) {
    FUN_005f1f00();
    uVar2 = DAT_01ea94d0;
    EnterCriticalSection(DAT_01ea94d0);
    cVar3 = FUN_0094b920(param_1);
    if (cVar3 != '\0') {
      FUN_0094e520(*param_1);
    }
    LeaveCriticalSection(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17051 ; VA 0x00946640 ; thunk_FUN_00946a50 */

void __fastcall thunk_FUN_00946a50(undefined4 *param_1)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = param_1[2];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 4,param_1 + 4,2);
      }
    }
    param_1[2] = 0;
  }
  piVar3 = (int *)*param_1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar3 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(piVar3,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17052 ; VA 0x00946650 ; FUN_00946650 */

void __fastcall FUN_00946650(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00946a50();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17053 ; VA 0x009466b0 ; FUN_009466b0 */

void __fastcall FUN_009466b0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar3 = (int *)piVar4[4];
      piVar1 = (int *)*piVar4;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x14);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x14);
  return;
}



/* FUNCTION 17054 ; VA 0x00946730 ; FUN_00946730 */

void __fastcall FUN_00946730(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0094e1b0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x4c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17055 ; VA 0x00946780 ; FUN_00946780 */

void __fastcall FUN_00946780(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00949e50(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17056 ; VA 0x009467e0 ; FUN_009467e0 */

void __fastcall FUN_009467e0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_005cf430(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 17057 ; VA 0x00946810 ; FUN_00946810 */

void __fastcall FUN_00946810(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00942f90(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 17058 ; VA 0x00946840 ; FUN_00946840 */

void __fastcall FUN_00946840(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00577ac0();
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_009468cf;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_009468cf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 17059 ; VA 0x009468e0 ; FUN_009468e0 */

void __fastcall FUN_009468e0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 17060 ; VA 0x00946980 ; FUN_00946980 */

void __fastcall FUN_00946980(undefined4 *param_1)

{
  FUN_00949fb0();
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 17061 ; VA 0x009469a0 ; FUN_009469a0 */

void __fastcall FUN_009469a0(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0094e3b0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17062 ; VA 0x009469f0 ; FUN_009469f0 */

void __fastcall FUN_009469f0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00949f40(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17063 ; VA 0x00946a50 ; FUN_00946a50 */

void __fastcall FUN_00946a50(undefined4 *param_1)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = param_1[2];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 4,param_1 + 4,2);
      }
    }
    param_1[2] = 0;
  }
  piVar3 = (int *)*param_1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar3 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(piVar3,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17064 ; VA 0x00946ae0 ; FUN_00946ae0 */

void __fastcall FUN_00946ae0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00946b9d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00946b9d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17065 ; VA 0x00946bb0 ; FUN_00946bb0 */

void __fastcall FUN_00946bb0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00942f90(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17066 ; VA 0x00946c60 ; FUN_00946c60 */

void __fastcall FUN_00946c60(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0094d130(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17067 ; VA 0x00946ce0 ; FUN_00946ce0 */

void __fastcall FUN_00946ce0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_008c3510();
    FUN_01674ea0(iVar1,0x40);
  }
  return;
}



/* FUNCTION 17068 ; VA 0x00946d00 ; FUN_00946d00 */

void __fastcall FUN_00946d00(int *param_1)

{
  if (*param_1 != 0) {
    FUN_00948ed0(*param_1);
  }
  return;
}



/* FUNCTION 17069 ; VA 0x00946d10 ; FUN_00946d10 */

void __fastcall FUN_00946d10(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0094d130(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17070 ; VA 0x00946d20 ; FUN_00946d20 */

void __fastcall FUN_00946d20(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009466b0();
  return;
}



/* FUNCTION 17071 ; VA 0x00946d30 ; FUN_00946d30 */

void __fastcall FUN_00946d30(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00946b9d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00946b9d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17072 ; VA 0x00946d40 ; FUN_00946d40 */

void __fastcall FUN_00946d40(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00942f90(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17073 ; VA 0x00946d50 ; FUN_00946d50 */

void __fastcall FUN_00946d50(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00946f60();
        iVar2 = iVar2 + 0x70;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x70) * 0x70;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17074 ; VA 0x00946dd0 ; FUN_00946dd0 */

void __fastcall FUN_00946dd0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00947650();
        iVar2 = iVar2 + 0x40;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xffffffc0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17075 ; VA 0x00946e40 ; FUN_00946e40 */

void __fastcall FUN_00946e40(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  if (piVar2 != (int *)0x0) {
    piVar3 = (int *)param_1[1];
    if (piVar2 != piVar3) {
      do {
        (**(code **)(*piVar2 + 4))(0);
        piVar2 = piVar2 + 7;
      } while (piVar2 != piVar3);
      piVar2 = (int *)*param_1;
    }
    uVar1 = ((param_1[2] - (int)piVar2) / 0x1c) * 0x1c;
    piVar3 = piVar2;
    if (0xfff < uVar1) {
      piVar3 = (int *)piVar2[-1];
      uVar1 = uVar1 + 0x23;
      if (0x1f < (uint)((int)piVar2 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17076 ; VA 0x00946ed0 ; FUN_00946ed0 */

void __fastcall FUN_00946ed0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0056e380();
  FUN_0056e380();
  piVar4 = (int *)(param_1 + 4);
  uStack_8 = 0;
  LOCK();
  iVar1 = *(int *)(*piVar4 + 8) + -1;
  *(int *)(*piVar4 + 8) = iVar1;
  UNLOCK();
  if (iVar1 == 0) {
    FUN_005f1f00();
    uVar2 = DAT_01ea94d0;
    EnterCriticalSection(DAT_01ea94d0);
    cVar3 = FUN_0094b920(piVar4);
    if (cVar3 != '\0') {
      FUN_0094e520(*piVar4);
    }
    LeaveCriticalSection(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17077 ; VA 0x00946f60 ; FUN_00946f60 */

void __fastcall FUN_00946f60(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x68);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x54);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009470a5;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0xf;
  *(undefined *)(param_1 + 0x54) = 0;
  uVar2 = *(uint *)(param_1 + 0x50);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x3c);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009470a5;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0xf;
  *(undefined *)(param_1 + 0x3c) = 0;
  uVar2 = *(uint *)(param_1 + 0x38);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x24);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009470a5;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_009470a5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0094709f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 17078 ; VA 0x009470b0 ; FUN_009470b0 */

void __fastcall FUN_009470b0(int *param_1)

{
  if (param_1[1] != 0) {
    if ((int *)param_1[2] != (int *)0x0) {
      *(int *)param_1[2] = *param_1;
    }
    if (*param_1 != 0) {
      *(int *)(*param_1 + 8) = param_1[2];
    }
    *(int *)param_1[1] = *(int *)param_1[1] + -1;
    *param_1 = 0;
    param_1[2] = 0;
    param_1[1] = 0;
  }
  return;
}



/* FUNCTION 17079 ; VA 0x009470f0 ; FUN_009470f0 */

void __fastcall FUN_009470f0(uint *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01257280(param_1[1],~*param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17080 ; VA 0x00947130 ; FUN_00947130 */

void __fastcall FUN_00947130(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ScriptContext::vftable;
  param_1[0x16] = RBX::ScriptContext::vftable;
  uStack_8 = 0;
  puStack_14 = param_1;
  FUN_016f32d1(param_1 + 0xeb,0x1c,2,FUN_00d88aa0);
  uStack_8 = 1;
  FUN_0094e1b0(&puStack_14,*(undefined4 *)param_1[0xe9],(undefined4 *)param_1[0xe9]);
  FUN_01674ea0(param_1[0xe9],0x4c);
  FUN_00946dd0();
  iVar2 = param_1[0xe2];
  if ((iVar2 != 0) && (iVar2 != -1)) {
    CloseHandle(iVar2);
  }
  FUN_0056d500();
  LOCK();
  iVar2 = param_1[0xdc];
  param_1[0xdc] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  LOCK();
  iVar2 = param_1[0xda];
  param_1[0xda] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  uStack_8 = 2;
  FUN_016899e0();
  puVar3 = (undefined4 *)param_1[0xd8];
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    iVar2 = puVar3[1] + -1;
    puVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*puVar3)(0);
      uVar5 = GetProcessHeap(0,puVar3);
      HeapFree(uVar5);
    }
  }
  piVar4 = (int *)param_1[0xd7];
  uStack_8 = 0xffffffff;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0xd5];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0xd3];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0xd1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00946ae0();
  FUN_00946c60();
  FUN_016dedfb(param_1 + 0xb5);
  LOCK();
  iVar2 = param_1[0xb4];
  param_1[0xb4] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  piVar4 = (int *)param_1[0xb2];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  iVar2 = param_1[0xae];
  if (iVar2 != 0) {
    uVar7 = (param_1[0xb0] - iVar2 >> 3) * 8;
    iVar6 = iVar2;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) goto LAB_0094763d;
    }
    FUN_01674ea0(iVar6,uVar7);
    param_1[0xae] = 0;
    param_1[0xaf] = 0;
    param_1[0xb0] = 0;
  }
  iVar2 = param_1[0xab];
  if (iVar2 != 0) {
    uVar7 = param_1[0xad] - iVar2 & 0xfffffff0;
    iVar6 = iVar2;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) goto LAB_0094763d;
    }
    FUN_01674ea0(iVar6,uVar7);
    param_1[0xab] = 0;
    param_1[0xac] = 0;
    param_1[0xad] = 0;
  }
  iVar2 = param_1[0xa8];
  if (iVar2 != 0) {
    uVar7 = (param_1[0xaa] - iVar2 >> 2) * 4;
    iVar6 = iVar2;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_0094763d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
    param_1[0xa8] = 0;
    param_1[0xa9] = 0;
    param_1[0xaa] = 0;
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00577ac0();
  FUN_00946bb0();
  iVar2 = param_1[0x66];
  piVar4 = param_1 + 0x66;
  uStack_8 = 3;
  FUN_00949f40(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar4 + 4) = iVar2;
  *(int *)*piVar4 = iVar2;
  *(int *)(*piVar4 + 8) = iVar2;
  param_1[0x67] = 0;
  FUN_01674ea0(*piVar4,0x18);
  piVar4 = (int *)param_1[0x65];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x62];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_1[0x5f] != 0) {
    FUN_00948ed0(param_1[0x5f]);
  }
  piVar4 = (int *)param_1[0x5e];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x5c];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00949fb0();
  FUN_01674ea0(param_1[0x55],8);
  param_1[0x55] = 0;
  FUN_00949fb0();
  FUN_01674ea0(param_1[0x4f],8);
  param_1[0x4f] = 0;
  piVar4 = (int *)param_1[0x4b];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00577ac0();
  FUN_00946410();
  FUN_00d88aa0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17081 ; VA 0x00947650 ; FUN_00947650 */

int __fastcall FUN_00947650(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00d88a30();
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x009476b1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 17082 ; VA 0x009476c0 ; thunk_FUN_01255500 */

void __fastcall thunk_FUN_01255500(undefined4 *param_1)

{
  undefined8 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  uVar3 = param_1[1];
  uVar4 = param_1[2];
  uVar5 = param_1[3];
  uVar1 = *(undefined8 *)(param_1 + 4);
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *(undefined4 *)(iVar2 + 8) = *param_1;
  *(undefined4 *)(iVar2 + 0xc) = uVar3;
  *(undefined4 *)(iVar2 + 0x10) = uVar4;
  *(undefined4 *)(iVar2 + 0x14) = uVar5;
  *(undefined8 *)(iVar2 + 0x18) = uVar1;
  return;
}



/* FUNCTION 17083 ; VA 0x009476d0 ; FUN_009476d0 */

int __fastcall FUN_009476d0(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x60);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x68,param_1 + 0x68,2);
      }
    }
    *(undefined4 *)(param_1 + 0x60) = 0;
  }
  iVar5 = FUN_008c3510();
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17084 ; VA 0x00947760 ; FUN_00947760 */

void __fastcall FUN_00947760(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x58);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x60,param_1 + 0x60,2);
      }
    }
    *(undefined4 *)(param_1 + 0x58) = 0;
  }
  FUN_008c3510();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17085 ; VA 0x009477c0 ; FUN_009477c0 */

void __fastcall FUN_009477c0(int *param_1)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  iVar6 = param_1[6];
  ppvVar2 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar2, iVar6 != 0) {
    piVar1 = *(int **)(param_1[3] + (param_1[4] - 1U & param_1[5] + -1 + iVar6) * 4);
    uVar5 = piVar1[5];
    if (0xf < uVar5) {
      iVar6 = *piVar1;
      uVar4 = uVar5 + 1;
      iVar3 = iVar6;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar6 + -4);
        uVar4 = uVar5 + 0x24;
        if (0x1f < (iVar6 - iVar3) - 4U) goto LAB_00947909;
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    piVar1[4] = 0;
    piVar1[5] = 0xf;
    *(undefined *)piVar1 = 0;
    piVar1 = param_1 + 6;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[5] = 0;
    }
    ppvVar2 = (void **)ExceptionList;
    iVar6 = param_1[6];
  }
  iVar6 = param_1[4];
  while (iVar6 != 0) {
    iVar6 = iVar6 + -1;
    iVar3 = *(int *)(param_1[3] + iVar6 * 4);
    if (iVar3 != 0) {
      FUN_01674ea0(iVar3,0x18);
    }
  }
  iVar6 = param_1[3];
  if (iVar6 != 0) {
    uVar5 = param_1[4] * 4;
    iVar3 = iVar6;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar6 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar6 - iVar3) - 4U) {
LAB_00947909:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  param_1[4] = 0;
  param_1[3] = 0;
  FUN_01674ea0(param_1[2],8);
  param_1[2] = 0;
  iVar6 = *param_1;
  uStack_8 = 0;
  FUN_00949e50(*(undefined4 *)(iVar6 + 4));
  *(int *)(*param_1 + 4) = iVar6;
  *(int *)*param_1 = iVar6;
  *(int *)(*param_1 + 8) = iVar6;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17086 ; VA 0x00947910 ; FUN_00947910 */

void __fastcall FUN_00947910(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = (int *)param_1[2];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)*param_1;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if ((iVar2 == 1) && (piVar1 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(piVar1,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 17087 ; VA 0x00947970 ; FUN_00947970 */

undefined4 * __thiscall FUN_00947970(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  
  uVar2 = *param_2;
  *param_2 = 0;
  piVar3 = (int *)*param_1;
  *param_1 = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d889a0();
      FUN_01674ea0(piVar3,8);
    }
  }
  return param_1;
}



/* FUNCTION 17088 ; VA 0x009479b0 ; FUN_009479b0 */

undefined4 * __thiscall FUN_009479b0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_2;
  if (piVar2 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  piVar3 = (int *)*param_1;
  *param_1 = piVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d889a0();
      FUN_01674ea0(piVar3,8);
    }
  }
  return param_1;
}



/* FUNCTION 17089 ; VA 0x00947a00 ; FUN_00947a00 */

undefined4 * __thiscall FUN_00947a00(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  
  uVar2 = *param_2;
  *param_2 = 0;
  piVar3 = (int *)*param_1;
  *param_1 = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piVar3,0x10);
    }
  }
  return param_1;
}



/* FUNCTION 17090 ; VA 0x00947a40 ; FUN_00947a40 */

undefined4 * __thiscall FUN_00947a40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  
  piVar1 = param_2 + 1;
  piVar2 = param_1 + 1;
  *param_1 = *param_2;
  if (piVar1 != piVar2) {
    if (*piVar2 != 0) {
      (**(code **)(*piVar2 + 8))(param_1 + 2);
      *piVar2 = 0;
    }
    if (*piVar1 != 0) {
      (**(code **)(*piVar1 + 4))(param_2 + 2,param_1 + 2);
      *piVar2 = *piVar1;
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(param_2 + 2);
        *piVar1 = 0;
      }
    }
  }
  uVar3 = FUN_00888530();
  *param_2 = uVar3;
  if (*piVar1 != 0) {
    (**(code **)(*piVar1 + 8))(param_2 + 2);
    *piVar1 = 0;
  }
  return param_1;
}



/* FUNCTION 17091 ; VA 0x00947ad0 ; FUN_00947ad0 */

undefined4 * __thiscall FUN_00947ad0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar1 = (int *)*param_2;
  if (piVar1 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar2 = (int *)*param_1;
  *param_1 = piVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piVar2,0x10);
    }
  }
  iVar3 = param_2[2];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[2];
  }
  param_1[1] = param_2[1];
  piVar1 = (int *)param_1[2];
  param_1[2] = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17092 ; VA 0x00947b60 ; FUN_00947b60 */

int * __thiscall FUN_00947b60(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piStack_8;
  
  piVar1 = param_2;
  piStack_8 = param_1;
  FUN_005875d0(&param_2,param_2);
  piVar2 = param_2;
  if (param_2 != (int *)*param_1) {
    piVar3 = param_2 + 4;
    if (0xf < (uint)param_2[9]) {
      piVar3 = (int *)*piVar3;
    }
    piVar5 = piVar1;
    if (0xf < (uint)piVar1[5]) {
      piVar5 = (int *)*piVar1;
    }
    iVar4 = FUN_0055c2d0(piVar5,piVar1[4],piVar3,param_2[8]);
    if (-1 < iVar4) {
      return piVar2 + 10;
    }
  }
  piStack_8 = piVar1;
  iVar4 = FUN_0093f3c0(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_00940690(&param_2,piVar2,iVar4 + 0x10,iVar4);
  return param_2 + 10;
}



/* FUNCTION 17093 ; VA 0x00947bf0 ; FUN_00947bf0 */

int * __thiscall FUN_00947bf0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  byte bVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  int aiStack_48 [5];
  uint uStack_34;
  uint uStack_30;
  int *piStack_2c;
  undefined2 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cad20;
  pvStack_10 = ExceptionList;
  bVar3 = *param_1;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_005702d0(param_2);
  iVar7 = (int)param_2;
  FUN_00562fc0(&param_2,uStack_18,param_2,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_2c = (int *)0x0;
  uStack_28 = 0;
  uStack_30 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar7);
  iStack_8._0_1_ = 1;
  FUN_0094c530();
  piVar2 = piStack_2c;
  piStack_24 = piStack_2c + 2;
  FUN_0054ef60(aiStack_48);
  uStack_20 = 0xfffffffe;
  uStack_1c = 0x7fffffff;
  piVar2[8] = 0;
  piVar2[9] = 0;
  piVar2[10] = 0;
  piVar2[0xb] = 0;
  uVar6 = FUN_0056a9c0(0);
  FUN_005672c0(uVar6,&uStack_20);
  uStack_28 = CONCAT11(1,(undefined)uStack_28);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_34) {
    uVar10 = uStack_34 + 1;
    iVar7 = aiStack_48[0];
    if (0xfff < uVar10) {
      iVar7 = *(int *)(aiStack_48[0] + -4);
      uVar10 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar10);
  }
  uVar4 = *(uint *)(param_1 + 8);
  uVar10 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar10 = FUN_005c9310(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    param_2 = (uint *)0x1;
    uVar8 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar10) {
      uVar8 = 1;
    }
    uVar10 = FUN_005c9310(uVar8 + uVar4);
    puVar1 = (uint *)(param_1 + 4);
    if (uVar10 != *puVar1) {
      param_2 = puVar1;
      FUN_005d2b00(uVar10);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar5 = (undefined4 *)*puVar11;
      while (puVar5 != (undefined4 *)0x0) {
        piVar2 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar5[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar5[1] % *param_2) * 4) == 0) {
          *piVar2 = (int)puVar11;
          puVar11 = puVar5;
        }
        else {
          *puVar11 = *puVar5;
          *puVar5 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar5;
        }
        param_1 = pbStack_14;
        puVar5 = (undefined4 *)*puVar11;
      }
    }
  }
  piStack_2c[1] = uStack_18;
  iVar7 = *(int *)(param_1 + 0x14);
  uVar10 = *(uint *)(param_1 + 4);
  piVar2 = (int *)(iVar7 + (uStack_18 % uVar10) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar9 = (int *)(iVar7 + uVar10 * 4);
    if (*piVar9 != 0) {
      *(int **)(iVar7 + (*(uint *)(*piVar9 + 4) % uVar10) * 4) = piStack_2c;
    }
    *piVar2 = (int)piVar9;
    *piStack_2c = *piVar9;
  }
  else {
    *piStack_2c = *(int *)*piVar2;
    piVar9 = (int *)*piVar2;
  }
  *piVar9 = (int)piStack_2c;
  *(int *)(pbStack_14 + 8) = *(int *)(pbStack_14 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_24;
}



/* FUNCTION 17094 ; VA 0x00947e30 ; FUN_00947e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00947e30(int param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cad38;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar9 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar9 = ~uVar4;
  }
  uVar9 = (uVar9 >> 2) + uVar9 * 0x40 + iVar5 ^ uVar9;
  uVar8 = uVar9 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar9 == puVar6[1]) {
        if ((iVar5 == puVar6[2]) && (uVar4 == puVar6[3])) {
          return puVar6 + 2;
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar8) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0094c590();
  _DAT_00000010 = 0;
  _DAT_00000014 = 0;
  _DAT_00000018 = 0;
  _DAT_0000001c = 0;
  _DAT_00000020 = 0;
  uRam00000024 = 0;
  uRam00000028 = 0;
  uRam0000002c = 0;
  uVar2 = *(uint *)(param_1 + 8);
  uVar8 = uVar2 + 1;
  _DAT_00000008 = iVar5;
  _DAT_0000000c = uVar4;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar4 = FUN_005c9310(uVar8);
    if (uVar4 <= *(uint *)(param_1 + 4)) {
      uVar4 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar4);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar4 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar8) {
      uVar4 = 1;
    }
    iVar5 = FUN_005c9310(uVar4 + uVar2);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar6;
      while (puVar3 != (undefined4 *)0x0) {
        uVar4 = (uint)puVar3[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar4 * 4) == 0) {
          *piVar1 = (int)puVar6;
          puVar6 = puVar3;
        }
        else {
          *puVar6 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar9 % *(uint *)(param_1 + 4)) * 4);
  _DAT_00000004 = uVar9;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *piVar1 = (int)piVar7;
    _DAT_00000000 = *piVar7;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    piVar7 = (int *)*piVar1;
  }
  *piVar7 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 17095 ; VA 0x00948040 ; FUN_00948040 */

uint * __thiscall FUN_00948040(byte *param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cad58;
  pvStack_10 = ExceptionList;
  uVar6 = *param_2;
  uVar9 = (uVar6 >> 3) + uVar6;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0x18);
  puVar1 = (uint *)(piVar5 + 2);
  *piVar5 = 0;
  piVar5[1] = 0;
  *puVar1 = 0;
  piVar5[3] = 0;
  piVar5[4] = 0;
  piVar5[5] = 0;
  *puVar1 = uVar6;
  piVar5[3] = 0;
  piVar5[4] = 0;
  piVar5[5] = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar6 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005c9310(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    param_2 = (uint *)0x1;
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar6) {
      uVar7 = 1;
    }
    uVar6 = FUN_005c9310(uVar7 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar6 != *param_2) {
      FUN_005d2b00(uVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar4 = (undefined4 *)*puVar10;
      while (puVar4 != (undefined4 *)0x0) {
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_2) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_2) * 4) == 0) {
          *piVar2 = (int)puVar10;
          puVar10 = puVar4;
        }
        else {
          *puVar10 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar5[1] = uVar9;
  uVar6 = *(uint *)(param_1 + 4);
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar9 % uVar6) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % uVar6) * 4) = piVar5;
    }
    *piVar2 = (int)piVar8;
    *piVar5 = *piVar8;
  }
  else {
    *piVar5 = *(int *)*piVar2;
    piVar8 = (int *)*piVar2;
  }
  *piVar8 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 17096 ; VA 0x00948230 ; FUN_00948230 */

int * __thiscall FUN_00948230(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piStack_10;
  undefined4 *puStack_c;
  int *piStack_8;
  
  piVar2 = param_2;
  FUN_0094f6a0(&param_2,param_2);
  if (param_2 == *(int **)(param_1 + 4)) {
    piStack_8 = piVar2;
    iVar1 = **(int **)(param_1 + 4);
    puStack_c = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_0093f390(iVar1,puStack_c,&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0xccccccb) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puStack_c = uVar3;
    FUN_00940070(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    param_2 = piStack_10;
  }
  return param_2 + 3;
}



/* FUNCTION 17097 ; VA 0x009482c0 ; FUN_009482c0 */

int FUN_009482c0(int *param_1)

{
  code *pcVar1;
  void *pvVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined **ppuVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined **ppuVar10;
  int *piVar11;
  undefined4 **ppuVar12;
  undefined4 uStack_304;
  undefined4 *puStack_300;
  int *piStack_2fc;
  int *piStack_2f8;
  undefined4 uStack_234;
  int iStack_230;
  int *piStack_22c;
  int *piStack_228;
  undefined4 uStack_164;
  undefined4 *puStack_160;
  undefined4 auStack_15c [50];
  undefined auStack_94 [8];
  undefined auStack_8c [8];
  undefined auStack_84 [8];
  undefined auStack_7c [8];
  int *piStack_74;
  int *piStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  int *piStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 *puStack_40;
  undefined2 uStack_3c;
  uint uStack_38;
  undefined4 *puStack_34;
  undefined2 uStack_30;
  uint uStack_2c;
  int iStack_28;
  undefined2 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar6 = param_1;
  puStack_c = &LAB_017cae00;
  pvStack_10 = ExceptionList;
  piStack_20 = (int *)0x0;
  piStack_1c = (int *)0x0;
  iVar5 = param_1[1];
  ExceptionList = &pvStack_10;
  if (iVar5 != 0) {
    piVar11 = (int *)(iVar5 + 4);
    iVar5 = *(int *)(iVar5 + 4);
    ExceptionList = &pvStack_10;
    while (iVar5 != 0) {
      LOCK();
      iVar4 = *piVar11;
      if (iVar5 == iVar4) {
        *piVar11 = iVar5 + 1;
        iVar4 = iVar5;
      }
      UNLOCK();
      if (iVar4 == iVar5) {
        piStack_20 = (int *)*param_1;
        piStack_1c = (int *)param_1[1];
        break;
      }
      iVar5 = *piVar11;
    }
  }
  piVar11 = piStack_1c;
  uStack_8 = 0;
  if (piStack_20 == (int *)0x0) {
    piVar6 = param_1 + 2;
    if (0xf < (uint)param_1[7]) {
      piVar6 = (int *)*piVar6;
    }
    iVar5 = FUN_0086f2f0(2,"Skip coverage stats because script is missing (name: %s)",piVar6);
  }
  else {
    iVar5 = FUN_00d893d0();
    if (iVar5 == 0) {
      piVar11 = piVar6 + 2;
      if (0xf < (uint)piVar6[7]) {
        piVar11 = (int *)*piVar11;
      }
      iVar5 = FUN_0086f2f0(2,"Skip coverage stats because script code is missing (name: %s)",piVar11
                          );
    }
    else {
      iStack_50 = 0;
      iStack_4c = 0;
      uStack_48 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0094f5f0(&iStack_50,iVar5);
      piVar6 = (int *)FUN_01674e20(0x24);
      if (piVar6 == (int *)0x0) {
        piVar6 = (int *)0x0;
        uStack_18 = 0;
      }
      else {
        piVar6[1] = 1;
        piVar6[2] = 1;
        *piVar6 = (int)std::
                       _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                       ::vftable;
        *(undefined *)(piVar6 + 3) = 0;
        uStack_18 = 0xb;
        ppuVar7 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_18);
        ppuVar10 = ppuVar7 + -1;
        if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar10 = ppuVar7;
        }
        piVar6[4] = (int)*ppuVar10;
        piVar6[5] = 0;
        piVar6[6] = 0x3f800000;
        piVar6[7] = 0;
        piVar6[8] = 0;
      }
      piStack_6c = piVar6 + 3;
      uStack_8._0_1_ = 2;
      piStack_68 = piVar6;
      uStack_234 = FUN_0088cdc0();
      iStack_230 = 0;
      if (piVar11 != (int *)0x0) {
        LOCK();
        piVar11[1] = piVar11[1] + 1;
        UNLOCK();
      }
      piStack_22c = piStack_20;
      piStack_228 = piVar11;
      iStack_230 = FUN_006309e0();
      iStack_28 = 0;
      uStack_24 = 0;
      uStack_2c = -(uint)(piVar6 != (int *)0xfffffff1) & (uint)(piVar6 + 4);
      uStack_8._0_1_ = 4;
      uStack_18 = uStack_2c;
      FUN_005c6580();
      piStack_14 = (int *)(iStack_28 + 8);
      *(undefined4 *)(iStack_28 + 0x18) = 0;
      *(undefined4 *)(iStack_28 + 0x1c) = 0xf;
      *(undefined *)piStack_14 = 0;
      FUN_005542c0("Script",6);
      uStack_8._0_1_ = 5;
      FUN_005caf00(&uStack_234);
      uStack_8._0_1_ = 4;
      uStack_24 = CONCAT11(1,(undefined)uStack_24);
      FUN_0094df20(auStack_7c,&uStack_2c);
      iVar5 = iStack_28;
      uStack_8._0_1_ = 6;
      if (iStack_28 != 0) {
        if (uStack_24._1_1_ != '\0') {
          FUN_00560ab0(uStack_2c,iStack_28 + 8);
        }
        FUN_01674ea0(iVar5,0xf0);
      }
      uStack_8._0_1_ = 7;
      if (iStack_230 != 0) {
        (**(code **)(iStack_230 + 8))(&piStack_22c);
      }
      iVar5 = iStack_4c - iStack_50;
      uStack_8._0_1_ = 2;
      piVar11 = (int *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 8;
      piStack_14 = piVar11;
      if (piVar11 == (int *)0x0) {
        piVar11 = (int *)0x0;
      }
      else {
        piVar11[1] = 1;
        piVar11[2] = 1;
        *piVar11 = (int)std::
                        _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                        ::vftable;
        FUN_00569550(iVar5 >> 2,(int)&param_1 + 3);
      }
      piStack_74 = piVar11 + 3;
      param_1 = (int *)0x0;
      piStack_70 = piVar11;
      if (iStack_4c - iStack_50 >> 2 != 0) {
        piStack_14 = (int *)0x0;
        do {
          iVar5 = iStack_50;
          uStack_8._0_1_ = 9;
          uStack_164 = FUN_0088c8c0();
          puStack_160 = (undefined4 *)0x0;
          auStack_15c[0] = *(undefined4 *)(iVar5 + (int)param_1 * 4);
          if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
               DAT_01ea8c18) && (FUN_016f3809(&DAT_01ea8c18), DAT_01ea8c18 == -1)) {
            DAT_01ea8c0c = FUN_005c65e0;
            DAT_01ea8c10 = FUN_005c65e0;
            DAT_01ea8c14 = _guard_check_icall;
            FUN_016f37bf(&DAT_01ea8c18);
          }
          puStack_160 = &DAT_01ea8c0c;
          iVar5 = piVar11[3];
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          if ((uint)((piVar11[4] - iVar5) / 0xd0) <= param_1) {
            FUN_00577c40();
            pcVar1 = (code *)swi(3);
            iVar5 = (*pcVar1)();
            return iVar5;
          }
          *(undefined4 *)((int)piStack_14 + iVar5) = uStack_164;
          ppuVar12 = (undefined4 **)(iVar5 + 4 + (int)piStack_14);
          if (&puStack_160 != ppuVar12) {
            if (*ppuVar12 != (undefined4 *)0x0) {
              (*(code *)(*ppuVar12)[2])(ppuVar12 + 1);
              *ppuVar12 = (undefined4 *)0x0;
            }
            if (puStack_160 != (undefined4 *)0x0) {
              (*(code *)puStack_160[1])(auStack_15c,ppuVar12 + 1);
              *ppuVar12 = puStack_160;
              if (puStack_160 != (undefined4 *)0x0) {
                (*(code *)puStack_160[2])(auStack_15c);
                puStack_160 = (undefined4 *)0x0;
              }
            }
          }
          uStack_164 = FUN_00888530();
          if (puStack_160 != (undefined4 *)0x0) {
            (*(code *)puStack_160[2])(auStack_15c);
            puStack_160 = (undefined4 *)0x0;
          }
          uStack_8._0_1_ = 0xb;
          if (puStack_160 != (undefined4 *)0x0) {
            (*(code *)puStack_160[2])(auStack_15c);
          }
          param_1 = (int *)((int)param_1 + 1);
          piStack_14 = piStack_14 + 0x34;
        } while (param_1 < (uint)(iStack_4c - iStack_50 >> 2));
      }
      piStack_5c = piVar11 + 3;
      if (piVar11 != (int *)0x0) {
        LOCK();
        piVar11[1] = piVar11[1] + 1;
        UNLOCK();
      }
      uStack_38 = uStack_18;
      puStack_34 = (undefined4 *)0x0;
      uStack_8._0_1_ = 0xd;
      uStack_30 = 0;
      piStack_58 = piVar11;
      puVar8 = (undefined4 *)FUN_01674e20(0xf0);
      *puVar8 = 0;
      puVar8[1] = 0;
      puStack_34 = puVar8;
      FUN_0170d1f0((int)puVar8 + 9,0,0xe7);
      puVar8[6] = 0;
      puVar8[7] = 0xf;
      uStack_30 = CONCAT11(uStack_30._1_1_,1);
      *(undefined *)(puVar8 + 2) = 0;
      param_1 = puVar8 + 2;
      FUN_005542c0(&DAT_018dd1f4,4);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      uVar9 = FUN_008882f0();
      pvVar2 = ThreadLocalStoragePointer;
      puVar8[8] = uVar9;
      puVar8[9] = 0;
      puVar8[10] = piVar11 + 3;
      iVar5 = _tls_index;
      puVar8[0xb] = piVar11;
      piStack_5c = (int *)0x0;
      piStack_58 = (int *)0x0;
      if ((*(int *)(*(int *)((int)pvVar2 + iVar5 * 4) + 0x34) < DAT_01ea8c38) &&
         (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
        DAT_01ea8c2c = FUN_0057bbb0;
        DAT_01ea8c30 = FUN_005880a0;
        DAT_01ea8c34 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ea8c38);
      }
      puVar8[9] = &DAT_01ea8c2c;
      uStack_8._0_1_ = 0xd;
      uStack_30 = CONCAT11(1,(undefined)uStack_30);
      FUN_0094df20(auStack_84,&uStack_38);
      puVar8 = puStack_34;
      uStack_8._0_1_ = 0xf;
      if (puStack_34 != (undefined4 *)0x0) {
        if (uStack_30._1_1_ != '\0') {
          FUN_00560ab0(uStack_38,puStack_34 + 2);
        }
        FUN_01674ea0(puVar8,0xf0);
      }
      uStack_44 = uStack_18;
      puStack_40 = (undefined4 *)0x0;
      uStack_8._0_1_ = 0x10;
      uStack_3c = 0;
      puVar8 = (undefined4 *)FUN_01674e20(0xf0);
      *puVar8 = 0;
      puVar8[1] = 0;
      puStack_40 = puVar8;
      FUN_0170d1f0((int)puVar8 + 9,0,0xe7);
      puVar8[6] = 0;
      puVar8[7] = 0xf;
      uStack_3c = CONCAT11(uStack_3c._1_1_,1);
      *(undefined *)(puVar8 + 2) = 0;
      param_1 = puVar8 + 2;
      FUN_005542c0("HitsPrecise",0xb);
      uStack_8._0_1_ = 0x11;
      uVar9 = FUN_0088daf0();
      puVar8[8] = uVar9;
      puVar8[9] = 0;
      *(undefined *)(puVar8 + 10) = 1;
      uVar9 = FUN_005c9ef0();
      puVar8[9] = uVar9;
      uStack_8._0_1_ = 0x10;
      uStack_3c = CONCAT11(1,(undefined)uStack_3c);
      FUN_0094df20(auStack_8c,&uStack_44);
      puVar8 = puStack_40;
      uStack_8._0_1_ = 0x12;
      if (puStack_40 != (undefined4 *)0x0) {
        if (uStack_3c._1_1_ != '\0') {
          FUN_00560ab0(uStack_44,puStack_40 + 2);
        }
        FUN_01674ea0(puVar8,0xf0);
      }
      param_1 = (int *)**(undefined4 **)(iStack_54 + 4);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      piStack_64 = piVar6 + 3;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
      piStack_60 = piVar6;
      uStack_304 = FUN_008881d0();
      piVar3 = param_1;
      piStack_2fc = piVar6 + 3;
      puStack_300 = (undefined4 *)0x0;
      piStack_64 = (int *)0x0;
      piStack_60 = (int *)0x0;
      piStack_2f8 = piVar6;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c
          ) && (FUN_016f3809(&DAT_01ea8a9c), DAT_01ea8a9c == -1)) {
        DAT_01ea8a90 = FUN_0057bbb0;
        DAT_01ea8a94 = FUN_005880a0;
        DAT_01ea8a98 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ea8a9c);
      }
      puStack_300 = &DAT_01ea8a90;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      if (piVar3[2] == piVar3[1]) {
        FUN_005ca4f0(piVar3[1],&uStack_304);
      }
      else {
        FUN_005caf00(&uStack_304);
        piVar3[1] = piVar3[1] + 0xd0;
      }
      uStack_8._0_1_ = 0x15;
      if (puStack_300 != (undefined4 *)0x0) {
        (*(code *)puStack_300[2])(&piStack_2fc);
      }
      piStack_14 = piStack_20;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      FUN_00708ea0(auStack_94,&piStack_14,param_1);
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar5 = piVar11[1] + -1;
        piVar11[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar5 = piVar11[2] + -1;
          piVar11[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar5 = piVar6[2] + -1;
          piVar6[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      iVar5 = FUN_0056d320();
    }
  }
  piVar6 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar11 = piStack_1c + 1;
    iVar4 = *piVar11;
    iVar5 = *piVar11;
    *piVar11 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar11 = piVar6 + 2;
      iVar4 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17098 ; VA 0x00948b50 ; FUN_00948b50 */

void __thiscall FUN_00948b50(int *param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 *******pppppppuVar9;
  uint uVar10;
  undefined4 *puVar11;
  int iVar12;
  undefined auStack_c4 [8];
  undefined auStack_bc [56];
  undefined auStack_84 [24];
  undefined4 ******appppppuStack_6c [5];
  uint uStack_58;
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  undefined auStack_2c [4];
  undefined4 *puStack_28;
  int iStack_24;
  int iStack_20;
  char cStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cae61;
  pvStack_10 = ExceptionList;
  uVar1 = *param_2;
  if (uVar1 == 0) {
    return;
  }
  iVar12 = *param_1;
  iStack_20 = *(int *)(iVar12 + 0xc);
  puVar8 = *(undefined4 **)(iVar12 + 4);
  uVar10 = *(uint *)(iVar12 + 0x18) &
           ((((uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar1 >> 8 & 0xff) * 0x1000193 ^
            uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193;
  puStack_30 = *(undefined4 **)(iStack_20 + uVar10 * 8);
  iStack_24 = uVar10 * 8 + 4;
  puVar4 = puStack_30;
  while( true ) {
    puVar5 = puVar8;
    if (puStack_30 != puVar8) {
      puVar5 = (undefined4 *)**(undefined4 **)(iStack_24 + iStack_20);
    }
    if (puVar4 == puVar5) goto LAB_00948c35;
    puVar5 = puVar4;
    if (puVar4[2] == uVar1) break;
    puVar4 = (undefined4 *)*puVar4;
  }
  while( true ) {
    puVar11 = puVar8;
    if (puStack_30 != puVar8) {
      puVar11 = (undefined4 *)**(undefined4 **)(iStack_24 + iStack_20);
    }
    if ((puVar5 == puVar11) || (uVar1 != puVar5[2])) break;
    puVar5 = (undefined4 *)*puVar5;
  }
  puStack_34 = puVar4;
  puStack_28 = puVar4;
  if (puVar4 == puVar5) {
LAB_00948c35:
    puVar5 = puVar8;
    puVar4 = puVar8;
  }
  iVar12 = 0;
  if (puVar4 != puVar5) {
    do {
      puVar4 = (undefined4 *)*puVar4;
      iVar12 = iVar12 + 1;
    } while (puVar4 != puVar5);
    if (iVar12 != 0) {
      return;
    }
  }
  ExceptionList = &pvStack_10;
  piStack_38 = param_1;
  if (uVar1 == 0) {
LAB_00948d44:
    cStack_1c = '\0';
  }
  else {
    iVar12 = *(int *)(uVar1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
      iVar12 = *(int *)(uVar1 + 0xc);
      iVar6 = FUN_009ec190();
      if ((uint)*(ushort *)(iVar6 + 0x1da) <
          (uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) goto LAB_00948d44;
      iVar12 = FUN_00ae4430();
      if (*(int *)(iVar12 + 0x10) == 0) {
        uVar7 = FUN_009ed300(auStack_2c);
        uStack_8 = 0;
        cStack_1c = 0;
        FUN_008866a0(uVar7);
        cStack_1c = '\x01';
        FUN_0056e380();
        FUN_0056e380();
        goto LAB_00948d49;
      }
    }
    else {
      iVar12 = FUN_00ae4430();
      if (*(int *)(iVar12 + 0x10) == 0) {
        if (DAT_01d67698 == '\0') {
          puVar8 = (undefined4 *)FUN_00b74db0();
          cStack_1c = 0;
          FUN_008866a0(*puVar8);
          cStack_1c = '\x01';
        }
        else {
          uVar7 = FUN_00b74d90();
          cStack_1c = 0;
          FUN_008866a0(uVar7);
          cStack_1c = '\x01';
        }
        goto LAB_00948d49;
      }
    }
    uVar7 = FUN_00ae4370();
    cStack_1c = 0;
    FUN_008866a0(uVar7);
    cStack_1c = '\x01';
  }
LAB_00948d49:
  uStack_8 = 1;
  if (cStack_1c != '\0') {
    iVar12 = FUN_00a33fa0();
    if (*(int *)(iVar12 + 0x10) != 0) {
      uVar7 = FUN_008a2380(auStack_84);
      uStack_8._0_1_ = 2;
      uStack_44 = 0;
      uStack_40 = 0xf;
      auStack_54[0] = 0;
      FUN_005542c0(&DAT_0191bf9c,1);
      uStack_8._0_1_ = 3;
      FUN_00558ba0(appppppuStack_6c,auStack_54,uVar7);
      FUN_005507b0();
      FUN_005507b0();
      piVar3 = piStack_38;
      uStack_3c = 1;
      piVar2 = *(int **)piStack_38[2];
      uStack_8._0_1_ = 7;
      pppppppuVar9 = appppppuStack_6c;
      if (0xf < uStack_58) {
        pppppppuVar9 = (undefined4 *******)appppppuStack_6c[0];
      }
      piStack_38 = piVar2;
      iVar12 = FUN_009edf40(piVar2,auStack_18,pppppppuVar9);
      if (iVar12 == 0) {
        FUN_005587b0(param_2);
        uStack_8._0_1_ = 8;
        FUN_008a2380(auStack_bc);
        uStack_8._0_1_ = 9;
        FUN_00d886a0(*(undefined4 *)piVar3[2],0xffffffff);
        uStack_8._0_1_ = 10;
        FUN_009482c0(auStack_c4);
        FUN_00947650();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      FUN_01257280(piVar2,0xfffffffe);
      FUN_005507b0();
    }
    if (cStack_1c != '\0') {
      FUN_0056e380();
      FUN_0056e380();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17099 ; VA 0x00948e90 ; FUN_00948e90 */

int FUN_00948e90(byte *param_1)

{
  return ((((*param_1 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_1[1]) * 0x1000193 ^ (uint)param_1[2])
          * 0x1000193 ^ (uint)param_1[3]) * 0x1000193;
}



/* FUNCTION 17100 ; VA 0x00948ed0 ; FUN_00948ed0 */

void FUN_00948ed0(int param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  
  if (param_1 != 0) {
    puVar4 = *(uint **)(param_1 + 4);
    if (puVar4 != (uint *)0x0) {
      puVar5 = *(uint **)(param_1 + 8);
      if (puVar4 != puVar5) {
        do {
          uVar3 = *puVar4;
          if (uVar3 != 0) {
            piVar2 = (int *)(uVar3 + 4);
            LOCK();
            iVar1 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if ((iVar1 == 1) &&
               (piVar2 = (int *)(-(uint)(piVar2 != (int *)0x0) & uVar3), piVar2 != (int *)0x0)) {
              (**(code **)(*piVar2 + 4))(1);
            }
          }
          puVar4 = puVar4 + 6;
        } while (puVar4 != puVar5);
        puVar4 = *(uint **)(param_1 + 4);
      }
      uVar3 = ((*(int *)(param_1 + 0xc) - (int)puVar4) / 0x18) * 0x18;
      puVar5 = puVar4;
      if (0xfff < uVar3) {
        puVar5 = (uint *)puVar4[-1];
        uVar3 = uVar3 + 0x23;
        if (0x1f < (uint)((int)puVar4 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(puVar5,uVar3);
      *(undefined4 *)(param_1 + 4) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    FUN_01674ea0(param_1,0x14);
  }
  return;
}



/* FUNCTION 17101 ; VA 0x00948fa0 ; FUN_00948fa0 */

/* WARNING: Removing unreachable block (ram,0x0094900d) */
/* WARNING: Removing unreachable block (ram,0x00949019) */
/* WARNING: Removing unreachable block (ram,0x00949027) */

undefined4 __thiscall FUN_00948fa0(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cae80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 17102 ; VA 0x00949060 ; FUN_00949060 */

void __thiscall FUN_00949060(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 17103 ; VA 0x009490c0 ; FUN_009490c0 */

/* WARNING: Removing unreachable block (ram,0x00949211) */
/* WARNING: Removing unreachable block (ram,0x00949221) */
/* WARNING: Removing unreachable block (ram,0x00949227) */

void * __thiscall FUN_009490c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  int *in_stack_00000038;
  int in_stack_0000003c;
  uint in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017caed8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 6;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_01675290();
    FUN_005507b0();
    FUN_005507b0();
    if (in_stack_00000038 != (int *)0x0) {
      LOCK();
      iVar2 = in_stack_00000038[1] + -1;
      in_stack_00000038[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*in_stack_00000038)();
        LOCK();
        piVar1 = in_stack_00000038 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*in_stack_00000038 + 4))();
        }
      }
    }
    pvVar3 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar3;
  }
  pvVar3 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    pvVar3 = (void *)FUN_01674ea0();
  }
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) &&
       (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    pvVar3 = (void *)FUN_01674ea0();
  }
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000038 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = in_stack_00000038 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_00000038 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000050) {
    if ((0xfff < in_stack_00000050 + 1) &&
       (0x1f < (in_stack_0000003c - *(int *)(in_stack_0000003c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    pvVar3 = (void *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 17104 ; VA 0x009492ec ; Catch@009492ec */

undefined * Catch_009492ec(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x30));
  return &DAT_009492fd;
}



/* FUNCTION 17105 ; VA 0x00949320 ; FUN_00949320 */

/* WARNING: Removing unreachable block (ram,0x0094940e) */
/* WARNING: Removing unreachable block (ram,0x0094941e) */
/* WARNING: Removing unreachable block (ram,0x00949424) */

void * __thiscall FUN_00949320(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  int *in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017caf28;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (0xf < in_stack_00000018) {
      if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      ExceptionList = &pvStack_10;
      pvVar3 = (void *)FUN_01674ea0();
    }
    if (0xf < in_stack_00000030) {
      if ((0xfff < in_stack_00000030 + 1) &&
         (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      pvVar3 = (void *)FUN_01674ea0();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 5;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_01675290();
    FUN_005507b0();
    pvVar3 = (void *)FUN_005507b0();
  }
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000038 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = in_stack_00000038 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_00000038 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 17106 ; VA 0x009494cd ; Catch@009494cd */

undefined * Catch_009494cd(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x2c));
  return &DAT_009494de;
}



/* FUNCTION 17107 ; VA 0x00949500 ; FUN_00949500 */

int __thiscall FUN_00949500(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 17108 ; VA 0x00949540 ; FUN_00949540 */

undefined4 __thiscall FUN_00949540(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xec);
  }
  return param_1;
}



/* FUNCTION 17109 ; VA 0x00949570 ; FUN_00949570 */

undefined4 __thiscall FUN_00949570(undefined4 param_1,byte param_2)

{
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 17110 ; VA 0x009495a0 ; FUN_009495a0 */

int __thiscall FUN_009495a0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 300);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x130);
  }
  return param_1;
}



/* FUNCTION 17111 ; VA 0x009495f0 ; FUN_009495f0 */

int * __thiscall FUN_009495f0(int *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if ((param_1[1] == param_1[3] + 8) && (param_1[1] != 0)) {
    if ((int *)param_1[2] != (int *)0x0) {
      *(int *)param_1[2] = *param_1;
    }
    if (*param_1 != 0) {
      *(int *)(*param_1 + 8) = param_1[2];
    }
    *(int *)param_1[1] = *(int *)param_1[1] + -1;
    *param_1 = 0;
    param_1[2] = 0;
    param_1[1] = 0;
  }
  *(int *)param_1[3] = *(int *)param_1[3] + -1;
  iVar2 = param_1[0xf];
  if (iVar2 != 0) {
    FUN_008c3510();
    FUN_01674ea0(iVar2,0x40);
  }
  piVar3 = (int *)param_1[0xe];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = (int *)param_1[5];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if ((iVar2 == 1) && (piVar3 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piVar3,8);
    }
  }
  piVar3 = (int *)param_1[4];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_1[1] != 0) {
    if ((int *)param_1[2] != (int *)0x0) {
      *(int *)param_1[2] = *param_1;
    }
    if (*param_1 != 0) {
      *(int *)(*param_1 + 8) = param_1[2];
    }
    *(int *)param_1[1] = *(int *)param_1[1] + -1;
    *param_1 = 0;
    param_1[2] = 0;
    param_1[1] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 17112 ; VA 0x00949710 ; FUN_00949710 */

undefined4 __thiscall FUN_00949710(undefined4 param_1,byte param_2)

{
  FUN_00947130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,1000);
  }
  return param_1;
}



/* FUNCTION 17113 ; VA 0x00949740 ; FUN_00949740 */

undefined4 __thiscall FUN_00949740(undefined4 param_1,byte param_2)

{
  FUN_009477c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 17114 ; VA 0x00949770 ; FUN_00949770 */

undefined4 __thiscall FUN_00949770(undefined4 param_1,byte param_2)

{
  FUN_009463b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 17115 ; VA 0x009497a0 ; FUN_009497a0 */

int __thiscall FUN_009497a0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x134);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 17116 ; VA 0x009497f0 ; FUN_009497f0 */

void FUN_009497f0(int param_1)

{
  uint *puVar1;
  uint *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  uint in_stack_00000018;
  int in_stack_0000001c;
  undefined4 *in_stack_00000020;
  undefined auStack_e8 [24];
  int iStack_d0;
  int *piStack_cc;
  uint uStack_c8;
  uint auStack_c4 [6];
  uint auStack_ac [6];
  uint auStack_94 [6];
  uint auStack_7c [6];
  int *piStack_64;
  int aiStack_60 [5];
  uint uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  int *piStack_2c;
  int *piStack_28;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = in_stack_0000001c;
  puStack_c = &LAB_017cb12e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00eced00(&piStack_2c,in_stack_0000001c,0);
  uStack_8._0_1_ = 1;
  if (piStack_2c != piStack_28) {
    FUN_00945900();
    uStack_8._0_1_ = 2;
    if (piStack_2c != piStack_28) {
      puVar2 = (uint *)(piStack_2c + 8);
      piVar9 = piStack_2c;
      do {
        piVar6 = (int *)puVar2[-7];
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
          piVar6 = (int *)puVar2[-7];
        }
        iStack_d0 = *piVar9;
        piStack_14 = piStack_cc;
        if (piStack_cc != (int *)0x0) {
          LOCK();
          iVar3 = piStack_cc[1] + -1;
          piStack_cc[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            puVar4 = (undefined4 *)*piStack_cc;
            piStack_cc = piVar6;
            (*(code *)*puVar4)();
            LOCK();
            iVar3 = piStack_14[2] + -1;
            piStack_14[2] = iVar3;
            UNLOCK();
            piVar6 = piStack_cc;
            if (iVar3 == 0) {
              (**(code **)(*piStack_14 + 4))();
              piVar6 = piStack_cc;
            }
          }
        }
        piStack_cc = piVar6;
        uStack_c8 = puVar2[-6];
        if (auStack_c4 != puVar2 + -5) {
          puVar1 = puVar2 + -5;
          if (0xf < *puVar2) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar2[-1]);
        }
        puVar1 = puVar2 + 1;
        if (auStack_ac != puVar1) {
          if (0xf < puVar2[6]) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar2[5]);
        }
        puVar1 = puVar2 + 7;
        if (auStack_94 != puVar1) {
          if (0xf < puVar2[0xc]) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar2[0xb]);
        }
        puVar1 = puVar2 + 0xd;
        if (auStack_7c != puVar1) {
          if (0xf < puVar2[0x12]) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar2[0x11]);
        }
        piStack_64 = (int *)puVar2[0x13];
        iVar3 = in_stack_0000001c;
        piStack_14 = piStack_64;
        if (0 < (int)piStack_64) {
          if ((piVar9 != piStack_28) && (iStack_d0 != 0)) {
            uStack_34 = 0xf00000000;
            uStack_44 = uStack_44 & 0xffffff00;
            FUN_005542c0(&DAT_018bc9b8,0);
            uStack_8._0_1_ = 3;
            FUN_009430d0(&iStack_20,&iStack_d0);
            uStack_8._0_1_ = 4;
            uStack_48 = FUN_008ed2c0(iStack_20);
            piVar9 = piStack_14;
            if (iStack_20 != 0) {
              uVar5 = FUN_00ae6180(piStack_14,uStack_48);
              puVar2 = (uint *)FUN_00d10cd0(aiStack_60,uVar5);
              if (&uStack_44 != puVar2) {
                FUN_005507b0();
                uStack_44 = *puVar2;
                uStack_40 = puVar2[1];
                uStack_3c = puVar2[2];
                uStack_38 = puVar2[3];
                uStack_34 = *(undefined8 *)(puVar2 + 4);
                puVar2[4] = 0;
                puVar2[5] = 0xf;
                *(undefined *)puVar2 = 0;
              }
              if (0xf < uStack_4c) {
                uVar7 = uStack_4c + 1;
                iVar3 = aiStack_60[0];
                if (0xfff < uVar7) {
                  iVar3 = *(int *)(aiStack_60[0] + -4);
                  uVar7 = uStack_4c + 0x24;
                  if (0x1f < (aiStack_60[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(iVar3,uVar7);
              }
            }
            if (((DAT_01d644c0 != '\0') && (iVar3 = FUN_008f7870(iStack_20), iVar3 != 0)) &&
               (iVar3 = FUN_00635890(), iVar3 != 0)) {
              if (piStack_1c != (int *)0x0) {
                LOCK();
                piStack_1c[1] = piStack_1c[1] + 1;
                UNLOCK();
              }
              iStack_18 = iStack_20;
              piStack_14 = piStack_1c;
              uStack_8._0_1_ = 5;
              puVar4 = (undefined4 *)FUN_00b76e60(auStack_e8,&iStack_18);
              uStack_8._0_1_ = 6;
              if (0xf < (uint)puVar4[5]) {
                puVar4 = (undefined4 *)*puVar4;
              }
              uVar5 = FUN_01675640(aiStack_60,"%s:%i",puVar4,piVar9);
              FUN_005511f0(uVar5);
              FUN_005507b0();
              FUN_005507b0();
              uStack_8._0_1_ = 4;
              FUN_00550b30();
            }
            FUN_0086f010(*in_stack_00000020,&param_1,&uStack_44,uStack_48);
            if (piStack_1c != (int *)0x0) {
              LOCK();
              iVar3 = piStack_1c[1] + -1;
              piStack_1c[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piStack_1c)();
                LOCK();
                piVar9 = piStack_1c + 2;
                iVar3 = *piVar9;
                *piVar9 = *piVar9 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                  (**(code **)(*piStack_1c + 4))();
                }
              }
            }
            if (0xf < uStack_34._4_4_) {
              uVar8 = uStack_34._4_4_ + 1;
              uVar7 = uStack_44;
              if (0xfff < uVar8) {
                uVar7 = *(uint *)(uStack_44 - 4);
                uVar8 = uStack_34._4_4_ + 0x24;
                if (0x1f < (uStack_44 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(uVar7,uVar8);
            }
            uStack_34 = 0xf00000000;
            uStack_44 = uStack_44 & 0xffffff00;
            FUN_00946f60();
            goto LAB_00949999;
          }
          break;
        }
        piVar9 = piVar9 + 0x1c;
        puVar2 = puVar2 + 0x1c;
      } while (piVar9 != piStack_28);
    }
    uStack_8._0_1_ = 1;
    FUN_00946f60();
  }
  uVar5 = 6;
  if ((iVar3 != 0) && (*(int *)(iVar3 + 0x6c) != 0)) {
    uVar5 = FUN_008ed2c0(*(undefined4 *)(*(int *)(*(int *)(iVar3 + 0x6c) + 0xc) + 4));
  }
  FUN_0086ed30(*in_stack_00000020,&param_1,uVar5);
LAB_00949999:
  FUN_00946d50();
  if (0xf < in_stack_00000018) {
    uVar7 = in_stack_00000018 + 1;
    iVar3 = param_1;
    if (0xfff < uVar7) {
      iVar3 = *(int *)(param_1 + -4);
      uVar7 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17117 ; VA 0x00949c30 ; FUN_00949c30 */

void FUN_00949c30(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x4c);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 17118 ; VA 0x00949c50 ; FUN_00949c50 */

void __fastcall FUN_00949c50(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x4c);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 17119 ; VA 0x00949c70 ; FUN_00949c70 */

void __fastcall FUN_00949c70(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_009463b0();
    FUN_01674ea0(iVar1,0x10);
  }
  return;
}



/* FUNCTION 17120 ; VA 0x00949c90 ; FUN_00949c90 */

void __fastcall FUN_00949c90(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_009477c0();
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 17121 ; VA 0x00949cb0 ; FUN_00949cb0 */

void FUN_00949cb0(void)

{
  FUN_009477c0();
  return;
}



/* FUNCTION 17122 ; VA 0x00949cc0 ; FUN_00949cc0 */

void FUN_00949cc0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_00946f60();
      param_1 = param_1 + 0x70;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 17123 ; VA 0x00949cf0 ; FUN_00949cf0 */

void FUN_00949cf0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_00947650();
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 17124 ; VA 0x00949d20 ; FUN_00949d20 */

void FUN_00949d20(int *param_1,int *param_2)

{
  if (param_1 != param_2) {
    do {
      (**(code **)(*param_1 + 4))(0);
      param_1 = param_1 + 7;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 17125 ; VA 0x00949d50 ; FUN_00949d50 */

void __thiscall FUN_00949d50(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  piVar2 = (int *)param_2[4];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_2,0x14);
  return;
}



/* FUNCTION 17126 ; VA 0x00949db0 ; FUN_00949db0 */

void FUN_00949db0(undefined4 param_1)

{
  FUN_00946840();
  FUN_01674ea0(param_1,0x4c);
  return;
}



/* FUNCTION 17127 ; VA 0x00949dd0 ; FUN_00949dd0 */

void FUN_00949dd0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x14);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01674ea0(param_1,0x18);
  return;
}



/* FUNCTION 17128 ; VA 0x00949e00 ; FUN_00949e00 */

void FUN_00949e00(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00949e00(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00946840();
    FUN_01674ea0(param_1,0x4c);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 17129 ; VA 0x00949e50 ; FUN_00949e50 */

void FUN_00949e50(int *param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00949e50(param_1[2]);
    piVar2 = (int *)param_1[0xd];
    piVar3 = (int *)*param_1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = (int *)param_1[0xb];
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar4 = param_1[9];
    if (0xf < uVar4) {
      iVar5 = param_1[4];
      uVar7 = uVar4 + 1;
      iVar6 = iVar5;
      if (0xfff < uVar7) {
        iVar6 = *(int *)(iVar5 + -4);
        uVar7 = uVar4 + 0x24;
        if (0x1f < (iVar5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x38);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 17130 ; VA 0x00949f40 ; FUN_00949f40 */

void FUN_00949f40(int *param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00949f40(param_1[2]);
    piVar2 = (int *)param_1[5];
    piVar3 = (int *)*param_1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    FUN_01674ea0(param_1,0x18);
    param_1 = piVar3;
    cVar1 = *(char *)((int)piVar3 + 0xd);
  }
  return;
}



/* FUNCTION 17131 ; VA 0x00949f90 ; FUN_00949f90 */

void FUN_00949f90(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x4c);
  return;
}



/* FUNCTION 17132 ; VA 0x00949fb0 ; FUN_00949fb0 */

void __fastcall FUN_00949fb0(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x10);
  while (iVar4 != 0) {
    FUN_00947910();
    piVar1 = (int *)(param_1 + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    iVar4 = *(int *)(param_1 + 0x10);
  }
  iVar4 = *(int *)(param_1 + 8);
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(*(int *)(param_1 + 4) + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0xc);
    }
  }
  iVar4 = *(int *)(param_1 + 4);
  if (iVar4 != 0) {
    uVar3 = *(int *)(param_1 + 8) * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 17133 ; VA 0x0094a060 ; FUN_0094a060 */

void __fastcall FUN_0094a060(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0094a0d0();
        iVar2 = iVar2 + 0x10;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffff0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17134 ; VA 0x0094a0d0 ; FUN_0094a0d0 */

void __fastcall FUN_0094a0d0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00947910();
        iVar2 = iVar2 + 0xc;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0xc) * 0xc;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17135 ; VA 0x0094a150 ; FUN_0094a150 */

int __thiscall FUN_0094a150(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb148;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    do {
      FUN_00942ca0(param_1,param_4,param_2);
      param_4 = param_4 + 0x40;
      param_2 = param_2 + 0x40;
    } while (param_2 != param_3);
  }
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 17136 ; VA 0x0094a1c0 ; FUN_0094a1c0 */

undefined4 * FUN_0094a1c0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar4 = param_3;
  if (param_1 != param_2) {
    puVar3 = param_1 + 1;
    puVar5 = param_3 + 2;
    do {
      puVar1 = puVar3 + 3;
      *puVar4 = puVar3[-1];
      puVar3[-1] = 0;
      puVar4 = puVar4 + 3;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = 0;
      *puVar5 = 0;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = *puVar3;
      puVar2 = puVar3 + 2;
      *puVar5 = puVar3[1];
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3 = puVar1;
      puVar5 = puVar5 + 3;
    } while (puVar2 != param_2);
  }
  return puVar4;
}



/* FUNCTION 17137 ; VA 0x0094a240 ; FUN_0094a240 */

int FUN_0094a240(int param_1,int param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb168;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      FUN_00d88710(param_1);
      param_3 = param_3 + 0x1c;
      param_1 = param_1 + 0x1c;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 17138 ; VA 0x0094a2b0 ; FUN_0094a2b0 */

int FUN_0094a2b0(uint param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cb198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&param_1);
  _uStack_8 = CONCAT31(uStack_7,1);
  iVar4 = FUN_0094a4b0();
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_1 - *(int *)(param_1 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17139 ; VA 0x0094a3b0 ; FUN_0094a3b0 */

int FUN_0094a3b0(uint param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cb198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&param_1);
  _uStack_8 = CONCAT31(uStack_7,1);
  iVar4 = FUN_0094a4b0();
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_1 - *(int *)(param_1 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17140 ; VA 0x0094a4b0 ; FUN_0094a4b0 */

/* WARNING: Removing unreachable block (ram,0x0094a544) */

void FUN_0094a4b0(void)

{
  char cVar1;
  int iVar2;
  char in_stack_00000024;
  undefined4 uStack_190;
  undefined *puStack_18c;
  undefined auStack_188 [104];
  undefined4 uStack_120;
  undefined *puStack_11c;
  undefined *puStack_118;
  undefined *puStack_114;
  undefined auStack_110 [120];
  undefined auStack_98 [32];
  undefined auStack_78 [24];
  undefined auStack_60 [8];
  undefined *puStack_58;
  undefined *puStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  code *pcStack_44;
  undefined4 uStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined auStack_20 [8];
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cb1ee;
  pvStack_10 = ExceptionList;
  uStack_50 = 0;
  iStack_8 = 1;
  puStack_114 = (undefined *)0x94a4e7;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0056f530();
  if (cVar1 == '\0') {
    puStack_114 = (undefined *)iStack_18;
    puStack_118 = auStack_60;
    puStack_11c = (undefined *)0x94a4fb;
    puStack_114 = (undefined *)FUN_0060dcd0();
    puStack_118 = (undefined *)0x94a50d;
    uStack_34 = puStack_114;
    FUN_005587e0();
    puStack_114 = (undefined *)0x94a515;
    FUN_00550b30();
  }
  puStack_114 = auStack_20;
  puStack_118 = (undefined *)0x94a51e;
  FUN_00942d40();
  iStack_8._0_1_ = 2;
  if (in_stack_00000024 != '\0') {
    puStack_114 = (undefined *)0x94a535;
    FUN_0054db20();
    puStack_114 = (undefined *)0x94a53c;
    FUN_0095c5f0();
  }
  cStack_11 = '\0';
  puStack_114 = (undefined *)0x0;
  puStack_118 = &stack0x00000004;
  puStack_11c = auStack_78;
  uStack_120 = 0x94a5d1;
  FUN_00a35300();
  iStack_8._0_1_ = 4;
  puStack_114 = (undefined *)0x94a5e0;
  cVar1 = FUN_00554d00();
  if (cVar1 == '\0') {
    puStack_114 = (undefined *)iStack_18;
    puStack_118 = (undefined *)0x94a5f0;
    FUN_008f7870();
    puStack_114 = (undefined *)0x94a5fd;
    iStack_2c = FUN_00635890();
    if (iStack_2c != 0) {
      puStack_114 = (undefined *)0x0;
      puStack_118 = auStack_78;
      puStack_11c = (undefined *)0x94a617;
      FUN_00558140();
      iStack_8._0_1_ = 5;
      puStack_114 = auStack_98;
      puStack_118 = (undefined *)0x94a62a;
      puStack_118 = (undefined *)FUN_0054db20();
      puStack_11c = (undefined *)0x94a633;
      FUN_00b76b00();
      iStack_8._0_1_ = 4;
      puStack_114 = (undefined *)0x94a642;
      FUN_00550800();
    }
  }
  puStack_114 = (undefined *)0x94a64a;
  piStack_30 = (int *)FUN_0054db20();
  pcStack_44 = *(code **)(*piStack_30 + 0x38);
  puStack_114 = &stack0x00000004;
  puStack_118 = (undefined *)0x94a662;
  (*pcStack_44)();
  puStack_114 = (undefined *)0x94a66a;
  uStack_4c = FUN_0054db20();
  puStack_114 = (undefined *)0x94a675;
  puStack_114 = (undefined *)FUN_0054db20();
  puStack_118 = (undefined *)0x94a684;
  uStack_48 = puStack_114;
  FUN_0058bb00();
  iStack_8._0_1_ = 2;
  puStack_114 = (undefined *)0x94a690;
  FUN_005507b0();
  if (cStack_11 == '\0') {
    puStack_114 = (undefined *)0x94a6a0;
    FUN_0054db20();
    puStack_114 = (undefined *)0x94a6a7;
    iVar2 = FUN_005c8ab0();
    if (iVar2 != iStack_18) {
      puStack_114 = (undefined *)0x94a6b7;
      FUN_00946290();
      iStack_8._0_1_ = 6;
      puStack_54 = auStack_188;
      puStack_18c = auStack_110;
      uStack_190 = 0x94a6cf;
      FUN_009461c0();
      puStack_58 = (undefined *)&uStack_190;
      FUN_005587b0(auStack_20);
      FUN_0094a730();
      iStack_8._0_1_ = 2;
      puStack_114 = (undefined *)0x94a6f7;
      FUN_00947760();
    }
  }
  iStack_8._0_1_ = 1;
  puStack_114 = (undefined *)0x94a703;
  FUN_00550b30();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  puStack_114 = (undefined *)0x94a70f;
  FUN_005507b0();
  iStack_8 = 0xffffffff;
  puStack_114 = (undefined *)0x94a71e;
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17141 ; VA 0x0094a730 ; FUN_0094a730 */

void FUN_0094a730(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000064;
  int iStack_128;
  int *piStack_124;
  undefined4 uStack_b8;
  undefined *puStack_b4;
  char *pcStack_b0;
  int *piStack_ac;
  undefined auStack_94 [120];
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb236;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_ac = &iStack_1c;
  pcStack_b0 = (undefined *)0x94a766;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  if (iStack_1c != 0) {
    if (DAT_01ee4206 != 0) {
      piStack_ac = *(int **)(iStack_1c + 0x28);
      if (0xf < (uint)piStack_ac[5]) {
        piStack_ac = (int *)*piStack_ac;
      }
      puStack_b4 = (undefined *)(uint)DAT_01ee4206;
      pcStack_b0 = "ScriptContext::addScript -- %s";
      uStack_b8 = 0x94a79c;
      FUN_01677650();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    piStack_ac = (int *)&stack0x0000000c;
    uStack_8._0_1_ = 3;
    pcStack_b0 = (undefined *)0x94a7da;
    FUN_009461c0();
    puStack_14 = (undefined *)&iStack_128;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    iStack_128 = iStack_1c;
    piStack_124 = piStack_18;
    uStack_8._0_1_ = 5;
    FUN_009461c0(auStack_94);
    uStack_8._0_1_ = 4;
    FUN_0095d510();
    piStack_ac = (int *)0x94a83a;
    FUN_009476d0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_ac = (int *)0x94a850;
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_ac = (int *)0x94a860;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      piStack_ac = (int *)0x94a874;
      (**(code **)(*param_2 + 4))();
    }
  }
  uStack_8 = 6;
  if (in_stack_00000064 != 0) {
    if (((in_stack_00000064 & 1) == 0) &&
       (*(code **)(in_stack_00000064 & 0xfffffffe) != (code *)0x0)) {
      puStack_b4 = &stack0x0000006c;
      piStack_ac = (int *)0x2;
      uStack_b8 = 0x94a898;
      pcStack_b0 = puStack_b4;
      (**(code **)(in_stack_00000064 & 0xfffffffe))();
    }
    in_stack_00000064 = 0;
  }
  piStack_ac = (int *)0x94a8aa;
  FUN_008c3510();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17142 ; VA 0x0094a8c0 ; FUN_0094a8c0 */

bool __fastcall FUN_0094a8c0(int param_1)

{
  return *(int *)(param_1 + 0x3e4) != 1;
}



/* FUNCTION 17143 ; VA 0x0094a8d0 ; FUN_0094a8d0 */

void FUN_0094a8d0(void)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *in_stack_00000018;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  uint in_stack_0000002c;
  uint in_stack_0000004c;
  int *in_stack_0000006c;
  undefined4 *apuStack_c0 [6];
  undefined4 uStack_a8;
  undefined *puStack_a4;
  int *piStack_a0;
  undefined4 *puStack_9c;
  int *piStack_98;
  int *piStack_94;
  char *pcStack_90;
  undefined4 auStack_80 [8];
  undefined4 uStack_60;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = in_stack_00000018;
  puStack_c = &LAB_017cb297;
  pvStack_10 = ExceptionList;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  piStack_20 = in_stack_00000018;
  ExceptionList = &pvStack_10;
  if (in_stack_00000018 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *in_stack_00000018 = *in_stack_00000018 + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  if ((in_stack_00000018 != (int *)0x0) && (in_stack_00000018[2] != 0)) {
    piVar5 = (int *)in_stack_0000006c[5];
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    if (piVar5 != (int *)0x0) {
      LOCK();
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    uStack_8 = 6;
    piStack_1c = piVar5;
    if ((piVar5 == (int *)0x0) || (piVar5[2] == 0)) {
      pcStack_90 = (char *)0x1;
      piStack_94 = (int *)in_stack_00000018[2];
      piStack_98 = (int *)0x94a964;
      FUN_01255e10();
      piStack_98 = (int *)piVar1[2];
      puStack_9c = (undefined4 *)0x94a96c;
      pcStack_90 = (char *)FUN_012565c0();
      piStack_94 = (int *)0x94a978;
      puVar2 = (undefined4 *)FUN_009462d0();
      piVar4 = (int *)*puVar2;
      *puVar2 = 0;
      piStack_1c = piVar4;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pcStack_90 = (char *)0x94a99a;
          FUN_00d88950();
          pcStack_90 = (char *)0x10;
          piStack_98 = (int *)0x94a9a2;
          piStack_94 = piVar5;
          FUN_01674ea0();
        }
      }
      piVar5 = piStack_18;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar3 = *piStack_18;
        *piStack_18 = *piStack_18 + -1;
        UNLOCK();
        if ((iVar3 == 1) && (piStack_18 != (int *)0x0)) {
          pcStack_90 = (char *)0x94a9c3;
          FUN_00d88950();
          pcStack_90 = (char *)0x10;
          piStack_94 = piVar5;
          piStack_98 = (int *)0x94a9cb;
          FUN_01674ea0();
        }
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      pcStack_90 = (char *)0xfffffffe;
      piStack_94 = (int *)piVar1[2];
      piStack_98 = (int *)0x94a9df;
      FUN_01257280();
      cStack_11 = '\x01';
    }
    else {
      cStack_11 = '\0';
      piVar4 = piVar5;
    }
    if (piVar4 == (int *)0x0) {
      piStack_94 = (int *)0x0;
    }
    else {
      piStack_94 = (int *)piVar4[2];
    }
    pcStack_90 = &stack0x00000004;
    piStack_98 = (int *)0x94a9fb;
    FUN_00d892f0();
    if (piVar4 == (int *)0x0) {
      pcStack_90 = (char *)0x0;
    }
    else {
      pcStack_90 = (char *)piVar4[2];
    }
    piStack_94 = (int *)in_stack_00000024;
    piStack_98 = (int *)0x94aa12;
    piStack_94 = (int *)FUN_009d5c60();
    pcStack_90 = (char *)0x0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      *piVar4 = *piVar4 + 1;
      UNLOCK();
    }
    puStack_9c = (undefined4 *)0x94aa49;
    piStack_98 = piVar4;
    iVar3 = FUN_0095aba0();
    if (iVar3 == 0) {
      if (piVar4 == (int *)0x0) {
        puStack_9c = (undefined4 *)0x0;
      }
      else {
        puStack_9c = (undefined4 *)piVar4[2];
      }
      apuStack_c0[0] = &stack0x0000002c;
      FUN_0054f510();
      apuStack_c0[0] = (undefined4 *)0x94ab8e;
      FUN_0094b190();
      if (piVar4 == (int *)0x0) {
        piStack_a0 = (int *)0x0;
      }
      else {
        piStack_a0 = (int *)piVar4[2];
      }
      puStack_9c = (undefined4 *)0x0;
      puStack_a4 = (undefined *)0x94aba4;
      FUN_01257280();
      if (cStack_11 != '\0') {
        if (piVar4 == (int *)0x0) {
          puStack_9c = (undefined4 *)0x0;
        }
        else {
          puStack_9c = (undefined4 *)piVar4[2];
        }
        piStack_a0 = (int *)0x94abc1;
        puStack_9c = (undefined4 *)FUN_00d887b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        piStack_a0 = (int *)0x94abce;
        FUN_00d88cd0();
        puStack_9c = (undefined4 *)0x94abd6;
        FUN_00d88aa0();
      }
    }
    else if (iVar3 == 1) {
      puStack_9c = (undefined4 *)0x94aa97;
      FUN_00d89650();
      auStack_80[0] = 0;
      uStack_60 = 0;
      uStack_8._0_1_ = 8;
      FUN_0054f510(&stack0x0000002c);
      FUN_00942690(apuStack_c0,FUN_0094b190);
      FUN_0093edd0();
      FUN_0054f510(&stack0x0000004c);
      FUN_00942570(apuStack_c0,FUN_0094acf0);
      FUN_0093ec60();
      if ((piVar4 == (int *)0x0) || (piVar4[2] == 0)) {
        piVar5 = (int *)0x0;
      }
      else {
        piVar5 = *(int **)(piVar4[2] + 0x6c);
      }
      puStack_9c = (undefined4 *)0x40;
      piStack_a0 = (int *)0x94ab27;
      piStack_18 = piVar5;
      iStack_24 = FUN_01674e20();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (iStack_24 == 0) {
        iVar3 = 0;
      }
      else {
        puStack_9c = auStack_80;
        piStack_a0 = (int *)0x94ab40;
        iVar3 = FUN_00945830();
      }
      piVar5 = (int *)piVar5[0xf];
      piStack_18[0xf] = iVar3;
      if (piVar5 != (int *)0x0) {
        puStack_9c = (undefined4 *)0x94ab5a;
        FUN_008c3510();
        puStack_9c = (undefined4 *)0x40;
        puStack_a4 = (undefined *)0x94ab62;
        piStack_a0 = piVar5;
        FUN_01674ea0();
      }
      puStack_9c = (undefined4 *)0x94ab6d;
      FUN_008c3510();
    }
    else if (iVar3 == 2) {
      puStack_9c = (undefined4 *)0x94aa68;
      FUN_00d89650();
      if (piVar4 == (int *)0x0) {
        puStack_9c = (undefined4 *)0x0;
      }
      else {
        puStack_9c = (undefined4 *)piVar4[2];
      }
      apuStack_c0[0] = &stack0x0000004c;
      FUN_0054f510();
      apuStack_c0[0] = (undefined4 *)0x94aa87;
      FUN_0094acf0();
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_9c = (undefined4 *)0x94abee;
        FUN_00d88950();
        puStack_9c = (undefined4 *)0x10;
        puStack_a4 = (undefined *)0x94abf6;
        piStack_a0 = piVar4;
        FUN_01674ea0();
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      puStack_9c = (undefined4 *)0x94ac12;
      FUN_00d88950();
      puStack_9c = (undefined4 *)0x10;
      piStack_a0 = piVar1;
      puStack_a4 = (undefined *)0x94ac1a;
      FUN_01674ea0();
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    puStack_9c = (undefined4 *)0x94ac2c;
    FUN_00d88a30();
    piVar1 = in_stack_00000028;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      iVar3 = in_stack_00000028[1] + -1;
      in_stack_00000028[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_9c = (undefined4 *)0x94ac42;
        (**(code **)*in_stack_00000028)();
        LOCK();
        piVar5 = piVar1 + 2;
        iVar3 = *piVar5 + -1;
        *piVar5 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puStack_9c = (undefined4 *)0x94ac52;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 10;
    if (in_stack_0000002c != 0) {
      if (((in_stack_0000002c & 1) == 0) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        puStack_a4 = &stack0x00000034;
        puStack_9c = (undefined4 *)0x2;
        uStack_a8 = 0x94ac73;
        piStack_a0 = (int *)puStack_a4;
        (**(code **)(in_stack_0000002c & 0xfffffffe))();
      }
      in_stack_0000002c = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    if (in_stack_0000004c != 0) {
      if (((in_stack_0000004c & 1) == 0) &&
         (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
        puStack_a4 = &stack0x00000054;
        puStack_9c = (undefined4 *)0x2;
        uStack_a8 = 0x94ac9e;
        piStack_a0 = (int *)puStack_a4;
        (**(code **)(in_stack_0000004c & 0xfffffffe))();
      }
      in_stack_0000004c = 0;
    }
    if (in_stack_0000006c != (int *)0x0) {
      piVar1 = in_stack_0000006c + 1;
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (((iVar3 == 1) && (piVar1 != (int *)0x0)) && (in_stack_0000006c != (int *)0x0)) {
        puStack_9c = (undefined4 *)0x1;
        piStack_a0 = (int *)0x94accd;
        (**(code **)(*in_stack_0000006c + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  pcStack_90 = "Script that implemented this callback has been destroyed";
                    /* WARNING: Subroutine does not return */
  piStack_94 = (int *)&UNK_0094ace8;
  FUN_016757c0();
}



/* FUNCTION 17144 ; VA 0x0094acf0 ; FUN_0094acf0 */

void FUN_0094acf0(uint param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000024;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cb2c0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  pcVar2 = (char *)FUN_00881a60(in_stack_00000024,0xffffffff);
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  iStack_8._0_1_ = 1;
  FUN_0054ef60(auStack_2c);
  FUN_005e65e0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  iStack_8 = 2;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17145 ; VA 0x0094ade0 ; FUN_0094ade0 */

void FUN_0094ade0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5
                 )

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint in_stack_00000034;
  undefined auStack_14c [8];
  undefined4 uStack_144;
  undefined4 *puStack_140;
  undefined4 uStack_12c;
  int *piStack_128;
  int *piStack_124;
  uint *puStack_120;
  int *piStack_11c;
  undefined4 uStack_118;
  undefined4 *puStack_114;
  undefined auStack_fc [40];
  uint uStack_d4;
  int aiStack_cc [6];
  int aiStack_b4 [5];
  int *piStack_a0;
  undefined4 auStack_98 [8];
  undefined4 uStack_78;
  uint uStack_58;
  int aiStack_50 [6];
  uint auStack_38 [2];
  int aiStack_30 [6];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb340;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  puStack_114 = &uStack_18;
  uStack_8 = 2;
  uStack_118 = param_3;
  piStack_124 = aiStack_b4;
  piStack_11c = (int *)param_2;
  puStack_120 = (uint *)param_1;
  piStack_128 = (int *)0x94ae35;
  ExceptionList = &pvStack_10;
  FUN_0094c800();
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  param_3 = piStack_a0;
  if (piStack_a0 != (int *)0x0) {
    LOCK();
    *piStack_a0 = *piStack_a0 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  if (piStack_a0 == (int *)0x0) {
    puStack_114 = (undefined4 *)0x0;
  }
  else {
    puStack_114 = (undefined4 *)piStack_a0[2];
  }
  uStack_118 = param_4;
  piStack_11c = (int *)0x94ae6c;
  uStack_118 = FUN_009d5c60();
  puStack_114 = (undefined4 *)0x0;
  piStack_11c = piStack_a0;
  if (piStack_a0 != (int *)0x0) {
    LOCK();
    *piStack_a0 = *piStack_a0 + 1;
    UNLOCK();
  }
  puStack_120 = (uint *)0x94ae88;
  iVar2 = FUN_0095aba0();
  if (iVar2 == 0) {
    puStack_140 = &stack0x00000034;
    uStack_144 = 0x94b0c9;
    FUN_0054f510();
    uStack_8._0_1_ = 6;
    FUN_0054f510();
    uStack_8._0_1_ = 5;
    FUN_00954610();
  }
  else if (iVar2 == 1) {
    auStack_98[0] = 0;
    uStack_78 = 0;
    uStack_8._0_1_ = 7;
    puStack_140 = &stack0x00000034;
    uStack_144 = 0x94aeea;
    FUN_0054f510();
    uStack_8._0_1_ = 8;
    FUN_0054f510();
    if (piStack_a0 != (int *)0x0) {
      LOCK();
      *piStack_a0 = *piStack_a0 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 7;
    FUN_00941fa0();
    puStack_120 = (uint *)0x0;
    uStack_8._0_1_ = 9;
    FUN_00944b60(auStack_fc);
    puStack_120 = (uint *)FUN_0093dd20();
    if (auStack_98 != puStack_120) {
      auStack_38[0] = 0;
      uStack_8._0_1_ = 0xb;
      piStack_124 = (int *)0x94af6a;
      FUN_005880d0();
      puStack_120 = auStack_98;
      piStack_124 = (int *)0x94af78;
      FUN_005880d0();
      puStack_120 = auStack_38;
      piStack_124 = (int *)0x94af87;
      FUN_005880d0();
      uStack_8._0_1_ = 0xc;
      if (auStack_38[0] != 0) {
        if (((auStack_38[0] & 1) == 0) && (*(code **)(auStack_38[0] & 0xfffffffe) != (code *)0x0)) {
          piStack_128 = aiStack_30;
          puStack_120 = (uint *)0x2;
          uStack_12c = 0x94afa8;
          piStack_124 = piStack_128;
          (**(code **)(auStack_38[0] & 0xfffffffe))();
        }
        auStack_38[0] = 0;
      }
    }
    uStack_8._0_1_ = 0xd;
    if (uStack_58 != 0) {
      if (((uStack_58 & 1) == 0) && (*(code **)(uStack_58 & 0xfffffffe) != (code *)0x0)) {
        piStack_128 = aiStack_50;
        puStack_120 = (uint *)0x2;
        uStack_12c = 0x94afd3;
        piStack_124 = piStack_128;
        (**(code **)(uStack_58 & 0xfffffffe))();
      }
      uStack_58 = 0;
    }
    uStack_8._0_1_ = 0xe;
    if (uStack_d4 != 0) {
      if (((uStack_d4 & 1) == 0) && (*(code **)(uStack_d4 & 0xfffffffe) != (code *)0x0)) {
        piStack_128 = aiStack_cc;
        puStack_120 = (uint *)0x2;
        uStack_12c = 0x94b004;
        piStack_124 = piStack_128;
        (**(code **)(uStack_d4 & 0xfffffffe))();
      }
      uStack_d4 = 0;
    }
    uStack_8._0_1_ = 7;
    puStack_120 = (uint *)0x94b020;
    FUN_00946a50();
    FUN_0054f510();
    if (piStack_a0 != (int *)0x0) {
      LOCK();
      *piStack_a0 = *piStack_a0 + 1;
      UNLOCK();
    }
    FUN_00941e90(auStack_14c,FUN_00954510);
    FUN_0093e7a0();
    if ((piStack_a0 == (int *)0x0) || (piStack_a0[2] == 0)) {
      iVar2 = 0;
    }
    else {
      iVar2 = *(int *)(piStack_a0[2] + 0x6c);
    }
    puStack_120 = (uint *)0x40;
    piStack_124 = (int *)0x94b06f;
    iVar3 = FUN_01674e20();
    uStack_8._0_1_ = 0xf;
    if (iVar3 == 0) {
      uVar4 = 0;
    }
    else {
      puStack_120 = auStack_98;
      piStack_124 = (int *)0x94b08b;
      uVar4 = FUN_00945830();
    }
    piVar1 = *(int **)(iVar2 + 0x3c);
    *(undefined4 *)(iVar2 + 0x3c) = uVar4;
    if (piVar1 != (int *)0x0) {
      puStack_120 = (uint *)0x94b0a0;
      FUN_008c3510();
      puStack_120 = (uint *)0x40;
      piStack_128 = (int *)0x94b0a8;
      piStack_124 = piVar1;
      FUN_01674ea0();
    }
    puStack_120 = (uint *)0x94b0b6;
    FUN_008c3510();
  }
  else if (iVar2 == 2) {
    puStack_140 = &stack0x00000034;
    uStack_144 = 0x94aead;
    FUN_0054f510();
    puStack_140 = &param_3;
    uStack_144 = 0x94aeb6;
    FUN_00954510();
  }
  if (piStack_a0 != (int *)0x0) {
    LOCK();
    iVar2 = *piStack_a0;
    *piStack_a0 = *piStack_a0 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_120 = (uint *)0x94b102;
      FUN_00d88950();
      puStack_120 = (uint *)0x10;
      piStack_124 = piStack_a0;
      piStack_128 = (int *)0x94b10a;
      FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  puStack_120 = (uint *)0x94b11f;
  FUN_00d88aa0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      piStack_128 = (int *)&stack0x0000001c;
      puStack_120 = (uint *)0x2;
      uStack_12c = 0x94b140;
      piStack_124 = piStack_128;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 0x11;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    piStack_128 = (int *)&stack0x0000003c;
    puStack_120 = (uint *)0x2;
    uStack_12c = 0x94b16e;
    piStack_124 = piStack_128;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17146 ; VA 0x0094b190 ; FUN_0094b190 */

void FUN_0094b190(uint param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 in_stack_00000024;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = in_stack_00000024;
  puStack_c = &LAB_017cb360;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01256300(in_stack_00000024);
  FUN_0094c6b0(&uStack_1c,uVar3,uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  FUN_00948fa0(uStack_1c,piStack_18);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = 2;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17147 ; VA 0x0094b260 ; FUN_0094b260 */

undefined4 FUN_0094b260(undefined4 param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  int *in_stack_0000001c;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  int *in_stack_00000030;
  undefined auStack_4c [24];
  undefined auStack_34 [12];
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = in_stack_0000001c;
  puStack_c = &LAB_017cb3c1;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  piStack_28 = in_stack_0000001c;
  ExceptionList = &pvStack_10;
  if (in_stack_0000001c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *in_stack_0000001c = *in_stack_0000001c + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  if ((in_stack_0000001c == (int *)0x0) || (in_stack_0000001c[2] == 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Script that implemented this callback has been destroyed");
  }
  piVar2 = (int *)in_stack_00000030[5];
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piVar2 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  piStack_18 = piVar2;
  if ((piVar2 == (int *)0x0) || (piVar2[2] == 0)) {
    FUN_01255e10(in_stack_0000001c[2],1);
    uVar4 = FUN_012565c0(piVar1[2]);
    puVar3 = (undefined4 *)FUN_009462d0(uVar4);
    piVar7 = (int *)*puVar3;
    *puVar3 = 0;
    piStack_18 = piVar7;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piVar2,0x10);
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = *piStack_1c;
      *piStack_1c = *piStack_1c + -1;
      UNLOCK();
      if ((iVar5 == 1) && (piStack_1c != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(piStack_1c,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    FUN_01257280(piVar1[2],0xfffffffe);
    cStack_11 = '\x01';
  }
  else {
    cStack_11 = '\0';
    piVar7 = piVar2;
  }
  FUN_00d892f0(piVar1[2],&stack0x00000008);
  if (piVar7 == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = piVar7[2];
  }
  FUN_01257960(piVar1[2],iVar5,1);
  if (piVar7 == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = piVar7[2];
  }
  piStack_1c = (int *)FUN_01256300(iVar5);
  if (piVar7 == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = piVar7[2];
  }
  uVar4 = FUN_009d5c60(in_stack_00000028,iVar5);
  if (piVar7 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  iStack_24 = FUN_0095aba0(piVar7,uVar4,0);
  if (iStack_24 != 1) {
    if (iStack_24 != 2) {
      if (piVar7 == (int *)0x0) {
        iVar5 = 0;
      }
      else {
        iVar5 = piVar7[2];
      }
      iVar5 = FUN_01256300(iVar5);
      if (piVar7 == (int *)0x0) {
        iVar6 = 0;
      }
      else {
        iVar6 = piVar7[2];
      }
      FUN_0094c6b0(param_1,iVar6,iVar5 + (1 - (int)piStack_1c));
      uStack_20 = 1;
      if (iStack_24 == 0) {
        if (piVar7 == (int *)0x0) {
          iVar5 = 0;
        }
        else {
          iVar5 = piVar7[2];
        }
        FUN_01257280(iVar5,0);
        if (cStack_11 != '\0') {
          if (piVar7 == (int *)0x0) {
            iVar5 = 0;
          }
          else {
            iVar5 = piVar7[2];
          }
          uVar4 = FUN_00d887b0(iVar5);
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          FUN_00d88cd0(uVar4);
          FUN_00d88aa0();
        }
      }
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piVar7,0x10);
        }
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piVar1,0x10);
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      FUN_00d88a30();
      piVar1 = in_stack_0000002c;
      if (in_stack_0000002c != (int *)0x0) {
        LOCK();
        iVar5 = in_stack_0000002c[1] + -1;
        in_stack_0000002c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*in_stack_0000002c)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar5 = *piVar2 + -1;
          *piVar2 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      if (in_stack_00000030 != (int *)0x0) {
        piVar1 = in_stack_00000030 + 1;
        LOCK();
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (((iVar5 == 1) && (piVar1 != (int *)0x0)) && (in_stack_00000030 != (int *)0x0)) {
          (**(code **)(*in_stack_00000030 + 4))(1);
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_0054db20();
    FUN_00d89650();
    uVar4 = FUN_00764410(0xffffffff);
    uVar4 = FUN_00881a60(uVar4);
    FUN_0054eff0(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_005500e0(auStack_4c);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_34,&DAT_01c17198);
  }
  FUN_0054db20();
  FUN_00d89650();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Callbacks cannot yield");
}



/* FUNCTION 17148 ; VA 0x0094b5d0 ; FUN_0094b5d0 */

undefined4
FUN_0094b5d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_50 [20];
  int *piStack_3c;
  undefined auStack_34 [24];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb3f0;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0094c800(auStack_50,param_2,param_3,param_4,&uStack_18);
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piStack_3c != (int *)0x0) {
    LOCK();
    *piStack_3c = *piStack_3c + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  if (piStack_3c == (int *)0x0) {
    iVar2 = 0;
  }
  else {
    iVar2 = piStack_3c[2];
  }
  uVar1 = FUN_009d5c60(param_5,iVar2);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    *piStack_3c = *piStack_3c + 1;
    UNLOCK();
  }
  iVar2 = FUN_0095aba0(piStack_3c,uVar1,0);
  if (iVar2 == 0) {
    if (piStack_3c == (int *)0x0) {
      iVar2 = 0;
    }
    else {
      iVar2 = piStack_3c[2];
    }
    uVar1 = FUN_01256300(iVar2);
    if (piStack_3c == (int *)0x0) {
      iVar2 = 0;
    }
    else {
      iVar2 = piStack_3c[2];
    }
    FUN_0094c6b0(param_1,iVar2,uVar1);
  }
  else {
    if ((iVar2 != 1) && (iVar2 == 2)) {
      uVar1 = FUN_00764410(0xffffffff);
      uVar1 = FUN_00881a60(uVar1);
      FUN_0054eff0(uVar1);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_005500e0(auStack_34);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    param_4 = 0;
    FUN_0088db90(param_1,&param_4);
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = *piStack_3c;
    *piStack_3c = *piStack_3c + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piStack_3c,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  FUN_00d88aa0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17149 ; VA 0x0094b750 ; FUN_0094b750 */

undefined4 * FUN_0094b750(undefined4 *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  code *pcStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb42f;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_2 + 0x14);
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  piStack_18 = piVar2;
  if ((piVar2 != (int *)0x0) && (piVar2[2] != 0)) {
    FUN_01255e10();
    FUN_012565c0();
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    uStack_8._0_1_ = 1;
    piStack_1c = (int *)FUN_01674e20();
    uStack_8._0_1_ = 2;
    if (piStack_1c == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)FUN_00d88510();
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      *piVar4 = *piVar4 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    piStack_1c = piVar4;
    FUN_01257280();
    FUN_00d892f0();
    uStack_24 = 0;
    uStack_20 = 0;
    puStack_28 = &uStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    pcStack_2c = FUN_00956dc0;
    FUN_00585a40(&pcStack_2c);
    if (piVar4 != (int *)0x0) {
      LOCK();
      *piVar4 = *piVar4 + 1;
      UNLOCK();
    }
    FUN_0095b4a0(piVar4,param_3);
    uVar3 = uStack_24;
    uStack_24 = 0;
    *param_1 = uVar3;
    param_1[1] = uStack_20;
    uStack_20 = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_00d88950();
        FUN_01674ea0();
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0();
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return param_1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 17150 ; VA 0x0094b920 ; FUN_0094b920 */

undefined4 FUN_0094b920(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_1;
  piVar1 = (int *)(iVar2 + 0xc);
  *piVar1 = *piVar1 + -1;
  return CONCAT31((int3)((uint)iVar2 >> 8),*piVar1 == 0);
}



/* FUNCTION 17151 ; VA 0x0094b940 ; FUN_0094b940 */

void __fastcall FUN_0094b940(int param_1)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  void **ppvVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  puVar4 = *(undefined4 **)(param_1 + 0x198);
  piVar2 = (int *)(param_1 + 0x198);
  puVar5 = (undefined4 *)*puVar4;
  ppvVar8 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar8, puVar5 != puVar4) {
    if (puVar5[5] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[5] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_009ecea0(puVar5[4],puVar5[5]);
    puVar6 = (undefined4 *)puVar5[2];
    ppvVar8 = (void **)ExceptionList;
    if (*(char *)((int)puVar6 + 0xd) == '\0') {
      cVar3 = *(char *)((int)*puVar6 + 0xd);
      puVar5 = puVar6;
      puVar6 = (undefined4 *)*puVar6;
      while (cVar3 == '\0') {
        cVar3 = *(char *)((int)*puVar6 + 0xd);
        puVar5 = puVar6;
        puVar6 = (undefined4 *)*puVar6;
      }
    }
    else {
      cVar3 = *(char *)((int)puVar5[1] + 0xd);
      puVar9 = (undefined4 *)puVar5[1];
      puVar6 = puVar5;
      while ((puVar5 = puVar9, cVar3 == '\0' && (puVar6 == (undefined4 *)puVar5[2]))) {
        cVar3 = *(char *)((int)puVar5[1] + 0xd);
        puVar9 = (undefined4 *)puVar5[1];
        puVar6 = puVar5;
      }
    }
  }
  uStack_8 = 0;
  iVar7 = *piVar2;
  FUN_00949f40(*(undefined4 *)(iVar7 + 4));
  *(int *)(*piVar2 + 4) = iVar7;
  *(int *)*piVar2 = iVar7;
  *(int *)(*piVar2 + 8) = iVar7;
  *(undefined4 *)(param_1 + 0x19c) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17152 ; VA 0x0094ba20 ; FUN_0094ba20 */

/* WARNING: Removing unreachable block (ram,0x0094bb6f) */
/* WARNING: Removing unreachable block (ram,0x0094bb82) */
/* WARNING: Removing unreachable block (ram,0x0094bb89) */
/* WARNING: Removing unreachable block (ram,0x0094bb90) */

void __fastcall FUN_0094ba20(int param_1)

{
  uint *puVar1;
  undefined4 *puVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  uint *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796188;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00587410();
  uStack_8 = 0;
  puVar4 = (uint *)(param_1 + 0xf8);
  puStack_14 = puVar4;
  if ((uint *)(param_1 + 0x78) != puVar4) {
    puVar6 = (uint *)(param_1 + 0xb4);
    do {
      iVar3 = iStack_18;
      uVar7 = *puVar6 ^ (uint)puVar6;
      if ((uVar7 != 0) &&
         (iVar5 = param_1 + 0x305 + (uint)*(byte *)(param_1 + 0x304),
         FUN_00606ea0(&iStack_1c,(*(uint *)(uVar7 + 0x10) >> 3) + *(int *)(uVar7 + 0x10),
                      uVar7 + 0x10,-(uint)(iVar5 != 0) & iVar5 + 1U), puVar4 = puStack_14,
         param_1 = iVar3, iStack_1c != 0)) {
        FUN_01255e10(uVar7,2);
        iVar3 = FUN_00948040((*puVar6 ^ (uint)puVar6) + 0x10);
        puVar2 = *(undefined4 **)(iVar3 + 8);
        param_1 = iStack_18;
        puVar4 = puStack_14;
        for (puVar8 = *(undefined4 **)(iVar3 + 4); iStack_18 = param_1, puStack_14 = puVar4,
            puVar8 != puVar2; puVar8 = puVar8 + 1) {
          FUN_01258350(*puVar6 ^ (uint)puVar6,0xffffd8f0,*puVar8);
          param_1 = iStack_18;
          puVar4 = puStack_14;
        }
      }
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 0x10;
    } while (puVar1 != puVar4);
  }
  if (*(int *)(param_1 + 0x30c) != 0) {
    FUN_0094d130(*(int *)(param_1 + 0x318) + *(int *)(param_1 + 0x308) * 4,0);
    puVar8 = *(undefined4 **)(param_1 + 0x318);
    puVar2 = puVar8 + *(int *)(param_1 + 0x308);
    for (; puVar8 != puVar2; puVar8 = puVar8 + 1) {
      *puVar8 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17153 ; VA 0x0094bbb0 ; FUN_0094bbb0 */

void FUN_0094bbb0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb440;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x6c);
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00d89140();
  for (puVar1 = *(undefined4 **)(*(int *)(iVar2 + 0xc) + 0xc); puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)*puVar1) {
    FUN_00d89170();
  }
  FUN_00d89140();
  FUN_0094bc2f();
  return;
}



/* FUNCTION 17154 ; VA 0x0094bc0b ; Catch@0094bc0b */

undefined * Catch_0094bc0b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0086f2f0(3,"Exception thrown while erasing Lua refs: %s",uVar1);
  return &DAT_0094bc29;
}



/* FUNCTION 17155 ; VA 0x0094bc2f ; FUN_0094bc2f */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0094bc2f(void)

{
  int unaff_EBP;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_00d89140();
  FUN_012590d0();
  FUN_00d89140();
  LOCK();
  _DAT_01ee2aac = _DAT_01ee2aac + -1;
  UNLOCK();
  if (unaff_EDI != 0) {
    FUN_009495f0(1);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 17156 ; VA 0x0094bc70 ; FUN_0094bc70 */

void __fastcall FUN_0094bc70(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb450;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x181) = 1;
  *(undefined *)(param_1 + 0x290) = 1;
  FUN_00d89650();
  FUN_0094b940();
  iVar7 = *(int *)(param_1 + 0x17c);
  uStack_8 = 0;
  if ((iVar7 != 0) && (DAT_01d65193 != '\0')) {
    uVar3 = FUN_00d9e600();
    FUN_016774b0(DAT_01d65193,"ScriptContext::closeState -- YieldEvent->waiterCount=%d",uVar3);
    iVar7 = *(int *)(param_1 + 0x17c);
  }
  *(undefined4 *)(param_1 + 0x17c) = 0;
  if (iVar7 != 0) {
    FUN_00948ed0(iVar7);
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x340) != 0) {
    if (*(int *)(param_1 + 0x344) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x344) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628910(*(undefined4 *)(param_1 + 0x340),*(undefined4 *)(param_1 + 0x344));
    *(undefined4 *)(param_1 + 0x340) = 0;
    piVar1 = *(int **)(param_1 + 0x344);
    *(undefined4 *)(param_1 + 0x344) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0x348) != 0) {
    if (*(int *)(param_1 + 0x34c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x34c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628910(*(undefined4 *)(param_1 + 0x348),*(undefined4 *)(param_1 + 0x34c));
    *(undefined4 *)(param_1 + 0x348) = 0;
    piVar1 = *(int **)(param_1 + 0x34c);
    *(undefined4 *)(param_1 + 0x34c) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0x350) != 0) {
    if (*(int *)(param_1 + 0x354) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x354) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628910(*(undefined4 *)(param_1 + 0x350),*(undefined4 *)(param_1 + 0x354));
    *(undefined4 *)(param_1 + 0x350) = 0;
    piVar1 = *(int **)(param_1 + 0x354);
    *(undefined4 *)(param_1 + 0x354) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0x358) != 0) {
    if (*(int *)(param_1 + 0x35c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x35c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628910(*(undefined4 *)(param_1 + 0x358),*(undefined4 *)(param_1 + 0x35c));
    *(undefined4 *)(param_1 + 0x358) = 0;
    piVar1 = *(int **)(param_1 + 0x35c);
    *(undefined4 *)(param_1 + 0x35c) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (DAT_01d65193 != '\0') {
    FUN_016774b0(DAT_01d65193,"ScriptContext::closeState -- waitingThreads.size()=%d",
                 *(undefined4 *)(param_1 + 0x14c));
  }
  puVar8 = (uint *)(param_1 + 0x150);
  do {
    LOCK();
    uVar6 = *puVar8;
    *puVar8 = *puVar8 | 1;
    UNLOCK();
  } while ((uVar6 & 1) != 0);
  FUN_00949fb0();
  *puVar8 = 0;
  puVar8 = (uint *)(param_1 + 0x168);
  do {
    LOCK();
    uVar6 = *puVar8;
    *puVar8 = *puVar8 | 1;
    UNLOCK();
  } while ((uVar6 & 1) != 0);
  FUN_00949fb0();
  iVar7 = param_1 + 0x78;
  *puVar8 = 0;
  if (iVar7 != param_1 + 0xf8) {
    puVar8 = (uint *)(param_1 + 0xb4);
    do {
      uVar6 = *puVar8;
      uVar4 = uVar6 ^ (uint)puVar8;
      if (uVar4 != 0) {
        if (DAT_01d65193 != '\0') {
          if (uVar4 == 0) {
            iVar5 = 0;
          }
          else {
            iVar5 = *(int *)(uVar4 + 0x6c);
          }
          FUN_016774b0(DAT_01d65193,"ScriptContext::closeState -- state thread count %d",
                       **(undefined4 **)(iVar5 + 0xc));
          uVar6 = *puVar8;
        }
        FUN_0094bbb0((uint)puVar8 ^ uVar6);
        *puVar8 = (uint)puVar8;
      }
      iVar7 = iVar7 + 0x40;
      puVar8 = puVar8 + 0x10;
    } while (iVar7 != param_1 + 0xf8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17157 ; VA 0x0094bda7 ; Catch@0094bda7 */

undefined * Catch_0094bda7(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0086f2f0(3,"Exception thrown while cleaning up Lua: %s",uVar1);
  return &DAT_0094bdc5;
}



/* FUNCTION 17158 ; VA 0x0094c070 ; FUN_0094c070 */

undefined4 FUN_0094c070(undefined4 param_1)

{
  byte bVar1;
  code *pcVar2;
  byte *pbVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  byte *pbVar7;
  bool bVar8;
  
  pbVar3 = (byte *)FUN_01257ce0(param_1,1,0);
  pbVar7 = &DAT_018d46cc;
  do {
    bVar1 = *pbVar3;
    bVar8 = bVar1 < *pbVar7;
    if (bVar1 != *pbVar7) {
LAB_0094c0b0:
      uVar4 = -(uint)bVar8 | 1;
      goto LAB_0094c0b5;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar3[1];
    bVar8 = bVar1 < pbVar7[1];
    if (bVar1 != pbVar7[1]) goto LAB_0094c0b0;
    pbVar3 = pbVar3 + 2;
    pbVar7 = pbVar7 + 2;
  } while (bVar1 != 0);
  uVar4 = 0;
LAB_0094c0b5:
  if (uVar4 == 0) {
    iVar5 = FUN_01256000(param_1,3,0);
    FUN_012569a0(param_1,(double)iVar5);
    return 1;
  }
  FUN_01257dd0(param_1,"collectgarbage must be called with \'count\'; use gcinfo() instead");
  pcVar2 = (code *)swi(3);
  uVar6 = (*pcVar2)();
  return uVar6;
}



/* FUNCTION 17159 ; VA 0x0094c0f0 ; FUN_0094c0f0 */

undefined4 FUN_0094c0f0(undefined4 param_1,int param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_b0 [160];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb473;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uVar4 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = param_3 - param_2 >> 0x1f;
  if ((param_3 - param_2) / 0x18 + iVar3 != iVar3) {
    iVar3 = 0;
    do {
      if (uVar4 != 0) {
        FUN_00558890(auStack_b0,&DAT_018c0cc8);
      }
      piVar2 = (int *)(iVar3 + param_2);
      piVar1 = piVar2 + 4;
      if (0xf < *(uint *)(iVar3 + 0x14 + param_2)) {
        piVar2 = (int *)*piVar2;
      }
      FUN_0055b3b0(auStack_b0,piVar2,*piVar1);
      uVar4 = uVar4 + 1;
      iVar3 = iVar3 + 0x18;
    } while (uVar4 < (uint)((param_3 - param_2) / 0x18));
  }
  FUN_0058c420(param_1);
  FUN_005705c0();
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17160 ; VA 0x0094c1f0 ; FUN_0094c1f0 */

undefined4 * __thiscall
FUN_0094c1f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb4b1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0094da20;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17161 ; VA 0x0094c390 ; FUN_0094c390 */

undefined4 * __thiscall
FUN_0094c390(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb4f1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0094dce0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17162 ; VA 0x0094c530 ; FUN_0094c530 */

void __fastcall FUN_0094c530(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x30);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    *(undefined8 *)(puVar1 + 10) = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_005cf430(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 17163 ; VA 0x0094c590 ; FUN_0094c590 */

void __fastcall FUN_0094c590(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x30);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    *(undefined8 *)(puVar1 + 10) = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00942f90(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 17164 ; VA 0x0094c5f0 ; FUN_0094c5f0 */

undefined4 FUN_0094c5f0(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  
  puVar4 = &DAT_018bc9b8;
  iVar2 = FUN_01256300(param_1);
  if (0 < iVar2) {
    puVar4 = (undefined1 *)FUN_01257440(param_1,1,0);
    if (puVar4 == (undefined1 *)0x0) {
      FUN_01257dd0(param_1,"Failed to convert the 1st argument to string");
      pcVar1 = (code *)swi(3);
      uVar3 = (*pcVar1)();
      return uVar3;
    }
  }
  FUN_01675310(&DAT_0191e450,puVar4);
  return 0;
}



/* FUNCTION 17165 ; VA 0x0094c640 ; FUN_0094c640 */

undefined4 * FUN_0094c640(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0055e950(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 17166 ; VA 0x0094c6b0 ; FUN_0094c6b0 */

int * FUN_0094c6b0(int *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb528;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  uVar2 = param_3;
  uStack_8 = 1;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3[1] = 1;
    puVar3[2] = 1;
    *puVar3 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(param_3,(int)&param_3 + 3);
  }
  *param_1 = (int)(puVar3 + 3);
  param_1[1] = (int)puVar3;
  uVar5 = 0;
  uStack_8 = 0;
  if (uVar2 != 0) {
    iVar6 = 0;
    do {
      param_3 = *(int *)*param_1;
      if ((uint)((int)(((int *)*param_1)[1] - param_3) / 0xd0) <= uVar5) {
        FUN_00577c40();
        pcVar1 = (code *)swi(3);
        piVar4 = (int *)(*pcVar1)();
        return piVar4;
      }
      uVar5 = uVar5 + 1;
      FUN_009d1bf0(param_2,uVar5,param_3 + iVar6,1);
      iVar6 = iVar6 + 0xd0;
    } while (uVar5 < uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17167 ; VA 0x0094c7a0 ; FUN_0094c7a0 */

void FUN_0094c7a0(undefined4 param_1)

{
  FUN_01255f00(param_1,0,0);
  FUN_01255f00(param_1,0,0);
  FUN_00880890(param_1,0xffffffff);
  FUN_01256930(param_1,&DAT_0191c860,7);
  FUN_01256aa0(param_1,0xffffd8ee);
  FUN_01257230(param_1,0xfffffffd);
  FUN_012570b0(param_1,0xfffffffe);
  return;
}



/* FUNCTION 17168 ; VA 0x0094c800 ; FUN_0094c800 */

undefined4 * __thiscall
FUN_0094c800(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,char *param_5,
            undefined4 *param_6)

{
  char cVar1;
  uint *puVar2;
  undefined4 uVar3;
  undefined4 *****pppppuVar4;
  int iVar5;
  char *pcVar6;
  uint uVar7;
  int *piVar8;
  bool bVar9;
  undefined auStack_80 [4];
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  undefined4 ****appppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined auStack_34 [12];
  undefined auStack_28 [4];
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017cb591;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_2[1] = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  *param_2 = RBX::Lua::WeakThreadRef::vftable;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  uStack_8 = 0;
  uStack_18 = 1;
  iStack_14 = param_1;
  FUN_01255470(4,0,0,0);
  cVar1 = FUN_01255530(param_3,auStack_34);
  piVar8 = *(int **)(param_1 + 0x70);
  iStack_1c = param_1 + 0x5c;
  if (piVar8 == (int *)0x0) {
    bVar9 = true;
  }
  else {
    bVar9 = piVar8[2] == 0;
  }
  if (cVar1 == '\0') {
    if (DAT_01d644e8 == '\0') {
      cVar1 = FUN_01255580(param_3,5);
      puVar2 = (uint *)(iStack_14 + 0xb4 + (uint)(cVar1 != '\0') * 0x40);
      uVar7 = *puVar2 ^ (uint)puVar2;
    }
    else {
      uVar7 = FUN_0094ff40(param_3,param_6);
    }
    piVar8 = (int *)param_6[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)param_6[1];
    }
    uStack_24 = *param_6;
    uStack_8 = 4;
    piStack_20 = piVar8;
    FUN_009511c0(param_2,uVar7,param_3,&uStack_24);
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = piVar8[1] + -1;
      piVar8[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar5 = piVar8[2] + -1;
        piVar8[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  else {
    if (bVar9) {
      FUN_01255470(4,0,0,0);
      cVar1 = FUN_01255580(auStack_64,5);
      puVar2 = (uint *)(iStack_14 + 0xb4 + (uint)(cVar1 != '\0') * 0x40);
      uVar7 = *puVar2 ^ (uint)puVar2;
      piVar8 = (int *)param_6[1];
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = (int *)param_6[1];
      }
      uStack_24 = *param_6;
      uStack_8 = 1;
      piStack_20 = piVar8;
      FUN_01255470(4,0,0,0);
      FUN_009511c0(iStack_1c,uVar7,auStack_7c,&uStack_24);
      uStack_8 = uStack_8 & 0xffffff00;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar5 = piVar8[1] + -1;
        piVar8[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar5 = piVar8[2] + -1;
          piVar8[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      FUN_01257280(uVar7,0xfffffffe);
      piVar8 = *(int **)(iStack_14 + 0x70);
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    if (piVar8 != (int *)0x0) {
      LOCK();
      *piVar8 = *piVar8 + 1;
      UNLOCK();
    }
    uStack_8 = 2;
    if (piVar8 == (int *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = piVar8[2];
    }
    uVar3 = FUN_012565c0(uVar7);
    FUN_00d887b0(uVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00d88cd0(auStack_80);
    FUN_00d88aa0();
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piVar8,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
  }
  piVar8 = (int *)param_2[5];
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piVar8 != (int *)0x0) {
    LOCK();
    *piVar8 = *piVar8 + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  if (piVar8 == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = piVar8[2];
  }
  FUN_012571e0(iVar5,0xffffd8ee,1);
  FUN_01257280(uVar7,0xfffffffe);
  uStack_3c = 0;
  uStack_38 = 0xf;
  appppuStack_4c[0] = (undefined4 ****)((uint)appppuStack_4c[0] & 0xffffff00);
  FUN_005542c0(&DAT_0191bf9c,1);
  uStack_8._0_1_ = 6;
  pcVar6 = param_5;
  if (param_5 == (char *)0x0) {
    param_5 = (char *)FUN_00f86fc0(3);
    pcVar6 = param_5;
    do {
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
  }
  else {
    do {
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
  }
  FUN_00554150(param_5,(int)pcVar6 - (int)(param_5 + 1));
  pppppuVar4 = appppuStack_4c;
  if (0xf < uStack_38) {
    pppppuVar4 = (undefined4 *****)appppuStack_4c[0];
  }
  if (piVar8 == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = piVar8[2];
  }
  iVar5 = FUN_009edf40(iVar5,param_4,pppppuVar4);
  if (iVar5 == 0) {
    if (0xf < uStack_38) {
      uVar7 = uStack_38 + 1;
      pppppuVar4 = (undefined4 *****)appppuStack_4c[0];
      if (0xfff < uVar7) {
        pppppuVar4 = (undefined4 *****)appppuStack_4c[0][-1];
        uVar7 = uStack_38 + 0x24;
        if (0x1f < (uint)((int)appppuStack_4c[0] + (-4 - (int)pppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar4,uVar7);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    appppuStack_4c[0] = (undefined4 ****)((uint)appppuStack_4c[0] & 0xffffff00);
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piVar8,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar3 = FUN_00764410(0xffffffff);
  uVar3 = FUN_00881a60(uVar3);
  FUN_0054eff0(uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uVar3 = FUN_00764410(0xfffffffe);
  FUN_01257280(uVar3);
  FUN_005500e0(auStack_7c);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_28,&DAT_01c17198);
}



/* FUNCTION 17169 ; VA 0x0094cc40 ; FUN_0094cc40 */

void FUN_0094cc40(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x70;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 17170 ; VA 0x0094cc80 ; FUN_0094cc80 */

undefined4 FUN_0094cc80(int param_1)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb5b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01255560();
  cVar3 = FUN_01255580(uVar4,1);
  if (cVar3 == '\0') {
    FUN_01255600(1,"DebuggerManager()");
  }
  if (param_1 == 0) {
    iVar5 = 0;
  }
  else {
    iVar5 = *(int *)(param_1 + 0x6c);
  }
  FUN_008f7870(*(undefined4 *)(*(int *)(iVar5 + 0xc) + 4));
  uVar4 = FUN_008fbd40();
  uVar4 = FUN_00ec6540(uVar4);
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar4);
  uStack_18 = *puVar6;
  piStack_14 = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  uStack_8 = 1;
  FUN_00da3620(param_1,&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17171 ; VA 0x0094cda0 ; FUN_0094cda0 */

int * __thiscall FUN_0094cda0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar3 = *(undefined4 **)(param_1 + 0x284);
  if (*(undefined4 **)(param_1 + 0x288) != puVar3) {
    *puVar3 = 0;
    puVar3[1] = 0;
    *puVar3 = param_2;
    puVar3[1] = param_3;
    *(int *)(param_1 + 0x284) = *(int *)(param_1 + 0x284) + 8;
    return param_3;
  }
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_00603a30(puVar3,&param_2);
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar5 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar5 = (int *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 17172 ; VA 0x0094ce50 ; FUN_0094ce50 */

undefined4 FUN_0094ce50(int param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  float10 fVar4;
  int *piStack_28;
  double dStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb5ef;
  pvStack_10 = ExceptionList;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01674e20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar2 == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3 = (int *)FUN_00d88510();
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  iVar2 = FUN_01256300();
  if (iVar2 < 2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  fVar4 = (float10)FUN_01257500(param_1,1,0);
  dStack_20 = (double)fVar4;
  iVar2 = FUN_0095c9f0();
  if ((dStack_20 < *(double *)(iVar2 + 0x58)) || (cVar1 = FUN_00c94370(), cVar1 != '\0')) {
    iVar2 = FUN_0095c9f0();
    dStack_20 = *(double *)(iVar2 + 0x58);
  }
  FUN_012565c0();
  FUN_00d887b0();
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piStack_28 != (int *)0x0) {
    LOCK();
    *piStack_28 = *piStack_28 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_01256aa0(param_1,2);
  if (piStack_28 == (int *)0x0) {
    iVar2 = 0;
  }
  else {
    iVar2 = piStack_28[2];
  }
  FUN_01257960(param_1,iVar2,1);
  if (DAT_01d644e8 == '\0') {
    if (param_1 == 0) {
      iVar2 = 0;
    }
    else {
      iVar2 = *(int *)(param_1 + 0x6c);
    }
    if (*(int *)(*(int *)(*(int *)(iVar2 + 0xc) + 4) + 0x17c) != 0) {
      if (piStack_28 == (int *)0x0) {
        iVar2 = 0;
      }
      else {
        iVar2 = piStack_28[2];
      }
      FUN_00d9e200(iVar2,dStack_20);
    }
  }
  else {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      *piStack_28 = *piStack_28 + 1;
      UNLOCK();
    }
    FUN_00956580(piStack_28,dStack_20);
  }
  FUN_01257280(param_1,0xfffffffe);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = *piStack_28;
    *piStack_28 = *piStack_28 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piStack_28,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  FUN_00d88aa0();
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piVar3,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17173 ; VA 0x0094d070 ; FUN_0094d070 */

/* WARNING: Removing unreachable block (ram,0x0094d0ba) */
/* WARNING: Removing unreachable block (ram,0x0094d114) */

void __fastcall FUN_0094d070(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = (int *)(param_1 + 0x280);
  FUN_005596d0(*piVar1,*(undefined4 *)(param_1 + 0x284),piVar1);
  iVar2 = *piVar1;
  *(int *)(param_1 + 0x284) = iVar2;
  if (DAT_01d62bf0 == '\0') {
    if ((*(int *)(param_1 + 0x288) - iVar2 >> 3 != 0) && (*(int *)(param_1 + 0x288) != iVar2)) {
      FUN_00577ac0();
      return;
    }
  }
  else if (*(uint *)(param_1 + 0x28c) < (uint)(*(int *)(param_1 + 0x288) - iVar2 >> 3)) {
    if (*(int *)(param_1 + 0x288) != iVar2) {
      FUN_00577ac0();
    }
    iVar2 = *(int *)(param_1 + 0x288);
    if ((uint)(iVar2 - *piVar1 >> 3) < 0x400) {
      FUN_00777ed0(0x400);
      iVar2 = *(int *)(param_1 + 0x288);
    }
    *(int *)(param_1 + 0x28c) = iVar2 - *piVar1 >> 3;
    return;
  }
  return;
}



/* FUNCTION 17174 ; VA 0x0094d130 ; FUN_0094d130 */

int __thiscall FUN_0094d130(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_006d0070(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x18);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 17175 ; VA 0x0094d190 ; FUN_0094d190 */

undefined4 FUN_0094d190(int param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb627;
  pvStack_10 = ExceptionList;
  if (DAT_01d644e8 != '\0') {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_008f7870();
    if (param_1 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = *(int *)(param_1 + 0x6c);
    }
    *(undefined *)(iVar5 + 0x30) = 1;
    if ((iVar1 == 0) || (*(char *)(iVar1 + 0xd0) == '\0')) {
      piVar2 = (int *)FUN_01674e20();
      if (piVar2 == (int *)0x0) {
        piVar2 = (int *)0x0;
      }
      else {
        piVar2[1] = 1;
        piVar2[2] = 1;
        *piVar2 = (int)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
        piVar2[3] = 0;
        piVar2[4] = 0;
        piVar2[5] = 0;
      }
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + 1;
      UNLOCK();
      iStack_8._0_1_ = 2;
      iStack_8._1_3_ = 0;
      iVar1 = FUN_01674e20(0x10);
      iStack_8._0_1_ = 3;
      if (iVar1 == 0) {
        piVar3 = (int *)0x0;
      }
      else {
        piVar3 = (int *)FUN_00d88510(param_1);
      }
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_0095c220();
      uVar4 = FUN_01258cc0();
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[1] + -1;
        piVar2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar3 = piVar2 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar4;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17176 ; VA 0x0094d320 ; FUN_0094d320 */

void FUN_0094d320(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  if (param_1[0x35] != 0) {
    if (DAT_01ee4208 != '\0') {
      piVar4 = (int *)param_1[10];
      if (0xf < (uint)piVar4[5]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_01677650(DAT_01ee4208,"ScriptContext::disassociateState -- %s",piVar4);
    }
    iVar5 = (**(code **)(*param_1 + 0xac))();
    if (*(int *)(iVar5 + 0x10) != 0) {
      iVar6 = FUN_00947b60(iVar5);
      puVar7 = *(undefined4 **)(iVar6 + 0x1c);
      puVar8 = *(undefined4 **)(iVar6 + 0x18);
      if (*(undefined4 **)(iVar6 + 0x18) != puVar7) {
LAB_0094d3a0:
        puVar9 = puVar8 + 2;
        if ((int *)*puVar8 != param_1) goto code_r0x0094d3a7;
        if (puVar9 != puVar7) {
          do {
            uVar1 = *puVar9;
            uVar2 = puVar9[1];
            *puVar9 = 0;
            puVar9[1] = 0;
            puVar9[-2] = uVar1;
            piVar4 = (int *)puVar9[-1];
            puVar9[-1] = uVar2;
            if (piVar4 != (int *)0x0) {
              LOCK();
              iVar3 = piVar4[1] + -1;
              piVar4[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piVar4)();
                LOCK();
                iVar3 = piVar4[2] + -1;
                piVar4[2] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar4 + 4))();
                }
              }
            }
            puVar9 = puVar9 + 2;
          } while (puVar9 != puVar7);
          puVar7 = *(undefined4 **)(iVar6 + 0x1c);
        }
        piVar4 = (int *)puVar7[-1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar3 = piVar4[1] + -1;
          piVar4[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar3 = piVar4[2] + -1;
            piVar4[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        *(int *)(iVar6 + 0x1c) = *(int *)(iVar6 + 0x1c) + -8;
        if (*(int *)(iVar6 + 0x18) == *(int *)(iVar6 + 0x1c)) {
          FUN_0094e280(iVar5);
        }
      }
    }
LAB_0094d453:
    FUN_00d89170();
    piVar4 = (int *)param_1[0x35];
    param_1[0x35] = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_00d889a0();
        FUN_01674ea0(piVar4,8);
      }
    }
    FUN_006eccd0();
  }
  return;
code_r0x0094d3a7:
  puVar8 = puVar9;
  if (puVar9 == puVar7) goto LAB_0094d453;
  goto LAB_0094d3a0;
}



/* FUNCTION 17177 ; VA 0x0094d4b0 ; FUN_0094d4b0 */

undefined4 FUN_0094d4b0(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 ***pppuVar3;
  undefined4 *puVar4;
  char *pcVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 ****ppppuVar8;
  char *pcVar9;
  uint uVar10;
  int iVar11;
  undefined8 uVar12;
  undefined4 ***apppuStack_8c [4];
  char *pcStack_7c;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  char *pcStack_34;
  uint uStack_30;
  int iStack_2c;
  char *pcStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 ***pppuStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb688;
  pvStack_10 = ExceptionList;
  iStack_2c = 0;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2b20) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee2b20), DAT_01ee2b20 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Systems","print",0xffffffff);
    DAT_01ee2b1c = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01ee2b18 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ee2b20);
  }
  uStack_40 = DAT_01ee2b18;
  uStack_74 = DAT_01ee2b18;
  uStack_3c = DAT_01ee2b1c;
  uStack_70 = DAT_01ee2b1c;
  uStack_6c = FUN_0152d930(DAT_01ee2b18,DAT_01ee2b1c);
  pcStack_7c = (char *)0x0;
  puStack_78 = (undefined4 *)&DAT_0000000f;
  apppuStack_8c[0] = (undefined4 ***)((uint)apppuStack_8c[0] & 0xffffff00);
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_8 = 3;
  if (DAT_01d64520 == '\0') {
    iVar11 = FUN_01256300(param_1);
    iStack_38 = iVar11;
    FUN_012561a0(param_1,0xffffd8ee,"tostring");
    iStack_2c = 1;
    if (0 < iVar11) {
      do {
        iVar11 = iStack_2c;
        if (1 < iStack_2c) {
          FUN_005558a0(0x20);
        }
        FUN_01256aa0(param_1,0xffffffff);
        FUN_01256aa0(param_1,iVar11);
        FUN_01255dd0(param_1,1,1);
        iStack_1c = FUN_01257440(param_1,0xffffffff,&uStack_30);
        uVar7 = uStack_30;
        if (iStack_1c == 0) goto LAB_0094d9fa;
        uStack_20 = uStack_30;
        pcStack_28 = pcStack_7c;
        puStack_24 = puStack_78;
        if ((uint)((int)puStack_78 - (int)pcStack_7c) < uStack_30) {
          if (0x7fffffffU - (int)pcStack_7c < uStack_30) {
            FUN_00554040();
            goto LAB_0094da09;
          }
          pcStack_34 = pcStack_7c + uStack_30;
          puVar4 = (undefined4 *)((uint)pcStack_34 | 0xf);
          if (puVar4 < &DAT_80000000) {
            if ((undefined4 *)(0x7fffffff - ((uint)puStack_78 >> 1)) < puStack_78) {
              puVar4 = (undefined4 *)0x7fffffff;
            }
            else {
              puVar1 = (undefined4 *)((int)puStack_78 + ((uint)puStack_78 >> 1));
              if (puVar4 < puVar1) {
                puVar4 = puVar1;
              }
            }
          }
          else {
            puVar4 = (undefined4 *)0x7fffffff;
          }
          pppuStack_18 = (undefined4 ***)FUN_00554060((int)puVar4 + 1);
          pcVar5 = pcStack_28;
          pppuVar3 = apppuStack_8c[0];
          pcStack_7c = pcStack_34;
          puStack_78 = puVar4;
          if (puStack_24 < &DAT_00000010) {
            FUN_0170c6f0(pppuStack_18,apppuStack_8c,pcStack_28);
            pcVar5 = pcVar5 + (int)pppuStack_18;
            FUN_0170c6f0(pcVar5,iStack_1c,uVar7);
            pcVar5[uVar7] = '\0';
          }
          else {
            FUN_0170c6f0(pppuStack_18,apppuStack_8c[0],pcStack_28);
            pcVar5 = pcVar5 + (int)pppuStack_18;
            FUN_0170c6f0(pcVar5,iStack_1c,uStack_20);
            puVar4 = (undefined4 *)((int)puStack_24 + 1);
            pcVar5[uStack_20] = '\0';
            ppppuVar8 = (undefined4 ****)pppuVar3;
            if ((undefined4 *)0xfff < puVar4) {
              ppppuVar8 = (undefined4 ****)pppuVar3[-1];
              puVar4 = puStack_24 + 9;
              if ((undefined *)0x1f < (undefined *)((int)pppuVar3 + (-4 - (int)ppppuVar8)))
              goto LAB_0094da09;
            }
            FUN_01674ea0(ppppuVar8,puVar4);
          }
          apppuStack_8c[0] = pppuStack_18;
        }
        else {
          ppppuVar8 = apppuStack_8c;
          if (&DAT_0000000f < puStack_78) {
            ppppuVar8 = (undefined4 ****)apppuStack_8c[0];
          }
          pcVar5 = (char *)((int)ppppuVar8 + (int)pcStack_7c);
          pcStack_7c = pcStack_7c + uStack_30;
          FUN_0170cc70(pcVar5,iStack_1c,uStack_30);
          pcVar5[uVar7] = '\0';
        }
        FUN_01257280(param_1,0xfffffffe);
        iStack_2c = iStack_2c + 1;
      } while (iStack_2c <= iStack_38);
    }
    if (DAT_01d64450 != '\0') {
      FUN_01257280(param_1,0xfffffffe);
    }
  }
  else {
    uStack_8 = 4;
    iStack_1c = FUN_01256300(param_1);
    puVar4 = (undefined4 *)FUN_00945690(iStack_1c,&uStack_11);
    iStack_2c = 1;
    puStack_24 = puVar4;
    FUN_012561a0(param_1,0xffffd8ee,"tostring");
    iVar11 = 1;
    if (0 < iStack_1c) {
      pppuStack_18 = (undefined4 ***)&DAT_00000018;
      do {
        FUN_01256aa0(param_1,0xffffffff);
        FUN_01256aa0(param_1,iVar11);
        FUN_01255dd0(param_1,1,1);
        pcVar5 = (char *)FUN_01257440(param_1,0xffffffff,&iStack_38);
        if (pcVar5 == (char *)0x0) {
LAB_0094d9fa:
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("\'tostring\' must return a string to \'print\'");
        }
        pcStack_28 = pcVar5 + 1;
        pcVar9 = pcVar5;
        do {
          cVar2 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar2 != '\0');
        FUN_005542c0(pcVar5,(int)pcVar9 - (int)pcStack_28);
        FUN_01257280(param_1,0xfffffffe);
        pppuStack_18 = pppuStack_18 + 6;
        iVar11 = iVar11 + 1;
        puVar4 = puStack_24;
      } while (iVar11 <= iStack_1c);
    }
    FUN_01257280(param_1,0xfffffffe);
    if (&uStack_4c != puVar4) {
      FUN_00577a40();
      uStack_4c = *puVar4;
      uStack_48 = puVar4[1];
      uStack_44 = puVar4[2];
      *puVar4 = 0;
      puVar4[1] = 0;
      puVar4[2] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00577a40();
  }
  if (DAT_01d644c0 == '\0') {
    if (DAT_01d64520 == '\0') {
      FUN_0086ed30(*param_2,apppuStack_8c,6);
    }
    else {
      FUN_00637260(&uStack_4c);
      uVar6 = FUN_0094c0f0(auStack_64);
      uStack_8._0_1_ = 5;
      FUN_0086ed30(*param_2,uVar6,6);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (0xf < uStack_50) {
        uVar10 = uStack_50 + 1;
        uVar7 = auStack_64[0];
        if (0xfff < uVar10) {
          uVar7 = *(uint *)(auStack_64[0] - 4);
          uVar10 = uStack_50 + 0x24;
          if (0x1f < (auStack_64[0] - uVar7) - 4) {
LAB_0094da09:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar10);
      }
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = auStack_64[0] & 0xffffff00;
    }
  }
  else if (DAT_01d64520 == '\0') {
    FUN_0054ef60(apppuStack_8c);
    FUN_009497f0();
  }
  else {
    FUN_00955da0(&uStack_4c,param_1,param_2);
  }
  FUN_00577a40();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (&DAT_0000000f < puStack_78) {
    puVar4 = (undefined4 *)((int)puStack_78 + 1);
    ppppuVar8 = (undefined4 ****)apppuStack_8c[0];
    if ((undefined4 *)0xfff < puVar4) {
      ppppuVar8 = (undefined4 ****)apppuStack_8c[0][-1];
      puVar4 = puStack_78 + 9;
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_8c[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,puVar4);
  }
  pcStack_7c = (char *)0x0;
  puStack_78 = (undefined4 *)0xf;
  apppuStack_8c[0] = (undefined4 ***)((uint)apppuStack_8c[0] & 0xffffff00);
  uStack_8 = 6;
  FUN_0152dda0(uStack_40,uStack_3c,uStack_6c);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17178 ; VA 0x0094da20 ; FUN_0094da20 */

int FUN_0094da20(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  int in_stack_00000040;
  uint in_stack_00000054;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb715;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 4;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  uStack_430 = FUN_0088cb40();
  uStack_42c = 0;
  FUN_0054ef60(&param_2);
  uStack_42c = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_360 = FUN_0088cb40();
  uStack_35c = 0;
  FUN_0054ef60(&stack0x00000020);
  uStack_35c = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  uStack_288 = in_stack_00000038;
  piStack_284 = in_stack_0000003c;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 7;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&stack0x00000040);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 8;
  FUN_005c13a0(&stack0x00000058);
  uStack_8._0_1_ = 9;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_430,&uStack_20,pcVar3);
  uStack_8._0_1_ = 10;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 0xb;
  FUN_00577b20();
  uStack_8._0_1_ = 4;
  FUN_016f32d1(&uStack_430,0xd0,5,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  iVar6 = FUN_01675290(uVar5);
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    uVar8 = param_2;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(param_2 - 4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar8,uVar7);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    uVar7 = in_stack_00000034 + 1;
    uVar8 = in_stack_00000020;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(in_stack_00000020 - 4);
      uVar7 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar8,uVar7);
  }
  piVar4 = in_stack_0000003c;
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_0000003c + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000054) {
    uVar8 = in_stack_00000054 + 1;
    iVar6 = in_stack_00000040;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(in_stack_00000040 + -4);
      uVar8 = in_stack_00000054 + 0x24;
      if (0x1f < (in_stack_00000040 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 17179 ; VA 0x0094dce0 ; FUN_0094dce0 */

int FUN_0094dce0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb777;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_2);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&stack0x00000020);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_00000038;
  piStack_e4 = in_stack_0000003c;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 7;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 3;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar6 = FUN_01675290(uVar5);
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    uVar7 = param_2;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_2 - 4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    uVar8 = in_stack_00000034 + 1;
    uVar7 = in_stack_00000020;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(in_stack_00000020 - 4);
      uVar8 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  piVar4 = in_stack_0000003c;
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_0000003c + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 17180 ; VA 0x0094df20 ; FUN_0094df20 */

void __thiscall FUN_0094df20(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  int *piVar11;
  
  iVar6 = *(int *)(param_3 + 4);
  puVar10 = (undefined4 *)(iVar6 + 8);
  uVar3 = FUN_005702d0(puVar10);
  uVar5 = *(uint *)(param_1 + 4);
  uVar9 = uVar3 % uVar5;
  if (*(int *)(param_1 + 8) == 0) {
    piVar11 = (int *)0x0;
  }
  else {
    puVar7 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar7 == (undefined4 *)0x0) {
      piVar11 = (int *)0x0;
    }
    else {
      piVar11 = (int *)*puVar7;
    }
    if (piVar11 == (int *)0x0) goto LAB_0094dfcc;
    do {
      if (uVar3 == piVar11[1]) {
        piVar4 = piVar11 + 2;
        if (0xf < (uint)piVar11[7]) {
          piVar4 = (int *)*piVar4;
        }
        puVar7 = puVar10;
        if (0xf < *(uint *)(iVar6 + 0x1c)) {
          puVar7 = (undefined4 *)*puVar10;
        }
        cVar2 = FUN_0055c360(puVar7,*(undefined4 *)(iVar6 + 0x18),piVar4,piVar11[6]);
        if (cVar2 != '\0') break;
        uVar5 = *(uint *)(param_1 + 4);
      }
      else if ((uint)piVar11[1] % uVar5 != uVar9) goto LAB_0094dfcc;
      piVar11 = (int *)*piVar11;
    } while (piVar11 != (int *)0x0);
  }
  if (piVar11 != (int *)0x0) {
    *param_2 = piVar11;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_0094dfcc:
  uVar9 = *(uint *)(param_1 + 8);
  uVar5 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005c9310(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    uVar8 = uVar9 >> 1;
    if (uVar8 + uVar9 <= uVar5) {
      uVar8 = 1;
    }
    iVar6 = FUN_005c9310(uVar8 + uVar9);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar10;
      while (puVar7 != (undefined4 *)0x0) {
        uVar5 = (uint)puVar7[1] % *(uint *)(param_1 + 4);
        piVar11 = (int *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4) == 0) {
          *piVar11 = (int)puVar10;
          puVar10 = puVar7;
        }
        else {
          *puVar10 = *puVar7;
          *puVar7 = *(undefined4 *)*piVar11;
          *(undefined4 **)*piVar11 = puVar7;
        }
        puVar7 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4 = *(int **)(param_3 + 4);
  *(undefined4 *)(param_3 + 4) = 0;
  piVar4[1] = uVar3;
  uVar3 = uVar3 % *(uint *)(param_1 + 4);
  puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  piVar11 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  if (puVar10 == (undefined4 *)0x0) {
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar1 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *piVar11 = (int)piVar1;
    *piVar4 = *piVar1;
    *piVar1 = (int)piVar4;
  }
  else {
    *piVar4 = *puVar10;
    *(int **)*piVar11 = piVar4;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar4;
  *(undefined *)(param_2 + 1) = 1;
  return;
}



/* FUNCTION 17181 ; VA 0x0094e0d0 ; FUN_0094e0d0 */

void FUN_0094e0d0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc0e8;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  if (iVar3 != param_1[1]) {
    do {
      piVar2 = *(int **)(iVar3 + 0x14);
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + 1;
      UNLOCK();
      if (piVar2 != (int *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      uStack_8 = 0;
      if ((piVar2 != (int *)0x0) && (piVar2[2] != 0)) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
        FUN_0095aba0(piVar2,0,param_2);
      }
      uStack_8 = 0xffffffff;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piVar2,0x10);
        }
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      iVar3 = iVar3 + 0x1c;
    } while (iVar3 != param_1[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17182 ; VA 0x0094e1b0 ; FUN_0094e1b0 */

void __thiscall FUN_0094e1b0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00949e00(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar3 = FUN_00553830(param_3);
    FUN_00946840();
    FUN_01674ea0(uVar3,0x4c);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17183 ; VA 0x0094e280 ; FUN_0094e280 */

int __thiscall FUN_0094e280(int *param_1,int *param_2)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piStack_10;
  
  param_1 = (int *)*param_1;
  piVar8 = param_1 + 1;
  piStack_10 = (int *)*piVar8;
  cVar1 = *(char *)((int)piStack_10 + 0xd);
  piVar3 = param_1;
  puVar7 = param_2;
  while (puVar9 = param_2, param_2 = puVar9, cVar1 == '\0') {
    piVar5 = piStack_10 + 4;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    uVar2 = piStack_10[9];
    iVar6 = piStack_10[8];
    piVar10 = piVar5;
    if (0xf < uVar2) {
      piVar10 = (int *)*piVar5;
    }
    iVar4 = FUN_0055c2d0(piVar10,iVar6,puVar7,puVar9[4]);
    if (iVar4 < 0) {
      piVar5 = (int *)piStack_10[2];
      piStack_10 = piVar3;
    }
    else {
      if (*(char *)((int)param_1 + 0xd) != '\0') {
        if (0xf < uVar2) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = puVar9;
        if (0xf < (uint)puVar9[5]) {
          puVar7 = (undefined4 *)*puVar9;
        }
        iVar6 = FUN_0055c2d0(puVar7,puVar9[4],piVar5,iVar6);
        if (iVar6 < 0) {
          param_1 = piStack_10;
        }
      }
      piVar5 = (int *)*piStack_10;
    }
    piVar3 = piStack_10;
    piStack_10 = piVar5;
    puVar7 = puVar9;
    cVar1 = *(char *)((int)piVar5 + 0xd);
  }
  if (*(char *)((int)param_1 + 0xd) == '\0') {
    piVar8 = param_1;
  }
  cVar1 = *(char *)(*piVar8 + 0xd);
  piVar8 = (int *)*piVar8;
  while (cVar1 == '\0') {
    piVar5 = piVar8 + 4;
    if (0xf < (uint)piVar8[9]) {
      piVar5 = (int *)*piVar5;
    }
    puVar9 = puVar7;
    if (0xf < (uint)puVar7[5]) {
      puVar9 = (undefined4 *)*puVar7;
    }
    iVar6 = FUN_0055c2d0(puVar9,puVar7[4],piVar5,piVar8[8]);
    if (iVar6 < 0) {
      piVar5 = (int *)*piVar8;
      param_1 = piVar8;
    }
    else {
      piVar5 = (int *)piVar8[2];
    }
    piVar8 = piVar5;
    cVar1 = *(char *)((int)piVar5 + 0xd);
  }
  iVar6 = 0;
  param_2 = piVar3;
  while (param_2 != param_1) {
    iVar6 = iVar6 + 1;
    FUN_00551320();
  }
  FUN_0094e1b0(&param_2,piVar3,param_1);
  return iVar6;
}



/* FUNCTION 17184 ; VA 0x0094e3b0 ; FUN_0094e3b0 */

void __thiscall FUN_0094e3b0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar3 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar3 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00949f40(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar3, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar4 = FUN_00553830(param_3);
    piVar1 = *(int **)(iVar4 + 0x14);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(iVar4,0x18);
    ppvVar3 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17185 ; VA 0x0094e480 ; FUN_0094e480 */

int __thiscall FUN_0094e480(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  
  puVar4 = (undefined4 *)*param_1;
  puVar1 = (undefined4 *)puVar4[1];
  puVar5 = puVar4;
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    puVar2 = puVar1;
    do {
      if ((uint)puVar2[5] < *(uint *)((int)param_2 + 4)) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        if ((*(char *)((int)puVar5 + 0xd) != '\0') &&
           (*(uint *)((int)param_2 + 4) < (uint)puVar2[5])) {
          puVar5 = puVar2;
        }
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  }
  if (*(char *)((int)puVar5 + 0xd) == '\0') {
    puVar1 = (undefined4 *)*puVar5;
  }
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    do {
      if (*(uint *)((int)param_2 + 4) < (uint)puVar1[5]) {
        puVar2 = (undefined4 *)*puVar1;
        puVar5 = puVar1;
      }
      else {
        puVar2 = (undefined4 *)puVar1[2];
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  iVar6 = 0;
  param_2 = puVar4;
  while (param_2 != puVar5) {
    iVar6 = iVar6 + 1;
    FUN_00551320();
  }
  FUN_0094e3b0(&param_2,puVar4,puVar5);
  return iVar6;
}



/* FUNCTION 17186 ; VA 0x0094e520 ; FUN_0094e520 */

void __thiscall FUN_0094e520(uint param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  piVar4 = (int *)(-(uint)(param_2 != 0) & param_2 + 0x10U);
  piVar3 = (int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 0x28);
  *piVar3 = *piVar3 + -1;
  puVar1 = (undefined4 *)piVar4[1];
  piVar3 = *(int **)(*piVar4 + 4);
  piVar2 = (int *)*puVar1;
  if (piVar3 == piVar4) {
    *(undefined4 **)(*piVar4 + 4) = puVar1;
    piVar3 = (int *)piVar4[1];
    if (piVar2 != piVar4) {
      piVar3 = (int *)*piVar3;
    }
  }
  else if (piVar2 == piVar4) {
    *piVar3 = (int)puVar1;
    piVar3 = (int *)piVar4[1];
  }
  else {
    *piVar3 = 0;
    *(int *)(*piVar4 + 4) = piVar4[1];
    piVar3 = *(int **)piVar4[1];
  }
  *piVar3 = *piVar4;
  FUN_0056e380();
  FUN_0056e380();
  FUN_01674ea0(param_2,0x18);
  return;
}



/* FUNCTION 17187 ; VA 0x0094e5a0 ; FUN_0094e5a0 */

void __thiscall FUN_0094e5a0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_3;
  *(int *)param_3[1] = *param_3;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  piVar3 = (int *)param_3[4];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_01674ea0(param_3,0x14);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 17188 ; VA 0x0094e610 ; FUN_0094e610 */

undefined4 *
FUN_0094e610(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4,char *param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined *param_12,undefined8 param_13,
            int *param_14,int *param_15,uint *param_16)

{
  int *piVar1;
  char cVar2;
  uint *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  char *pcVar7;
  undefined4 *****pppppuVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  char *pcVar12;
  uint uVar13;
  int *piVar14;
  bool bVar15;
  uint auStack_b0 [2];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined ***pppuStack_a0;
  int *piStack_9c;
  undefined8 uStack_98;
  undefined **ppuStack_88;
  undefined4 uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [4];
  undefined auStack_68 [24];
  undefined4 ****appppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [12];
  undefined auStack_2c [4];
  undefined auStack_28 [8];
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb804;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_84 = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_88 = RBX::Lua::WeakThreadRef::vftable;
  uStack_7c = 0;
  uStack_78 = 0;
  piStack_74 = (int *)0x0;
  uStack_70 = 0;
  uStack_98 = 0;
  piStack_9c = (int *)0x0;
  pppuStack_a0 = (undefined ***)&DAT_00000004;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  uStack_a4 = 0x94e686;
  ExceptionList = &pvStack_10;
  FUN_01255470();
  uStack_98 = CONCAT44(appppuStack_50,param_2);
  piStack_9c = (int *)0x94e693;
  cVar2 = FUN_01255530();
  piVar11 = *(int **)(iStack_14 + 0x70);
  if (piVar11 == (int *)0x0) {
    bVar15 = true;
  }
  else {
    bVar15 = piVar11[2] == 0;
  }
  if (cVar2 == '\0') {
    piVar11 = param_14;
    if (param_14 == (int *)0x0) {
      if (DAT_01d644e8 == '\0') {
        uStack_98 = CONCAT44(5,param_2);
        piStack_9c = (int *)0x94e845;
        cVar2 = FUN_01255580();
        puVar3 = (uint *)(iStack_14 + 0xb4 + (uint)(cVar2 != '\0') * 0x40);
        piVar11 = (int *)(*puVar3 ^ (uint)puVar3);
      }
      else {
        uStack_98 = CONCAT44(param_3,param_2);
        piStack_9c = (int *)0x94e872;
        piVar11 = (int *)FUN_0094ff40();
      }
    }
    piVar14 = (int *)param_3[1];
    if (piVar14 != (int *)0x0) {
      LOCK();
      piVar14[1] = piVar14[1] + 1;
      UNLOCK();
      piVar14 = (int *)param_3[1];
    }
    iStack_20 = *param_3;
    uStack_8._0_1_ = 6;
    uStack_98 = CONCAT44(&iStack_20,param_2);
    pppuStack_a0 = &ppuStack_88;
    uStack_a4 = 0x94e8ab;
    piStack_9c = piVar11;
    piStack_1c = piVar14;
    FUN_009511c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    param_2 = piVar11;
    if (piVar14 != (int *)0x0) {
      LOCK();
      iVar9 = piVar14[1] + -1;
      piVar14[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_98 = CONCAT44(0x94e8cd,(undefined4)uStack_98);
        (**(code **)*piVar14)();
        LOCK();
        iVar9 = piVar14[2] + -1;
        piVar14[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          uStack_98 = CONCAT44(0x94e8e1,(undefined4)uStack_98);
          (**(code **)(*piVar14 + 4))();
        }
      }
    }
  }
  else {
    if (bVar15) {
      uStack_98 = 0;
      piStack_9c = (int *)0x0;
      pppuStack_a0 = (undefined ***)0x4;
      uStack_a4 = 0x94e6d2;
      FUN_01255470();
      uStack_98 = CONCAT44(5,appppuStack_50);
      piStack_9c = (int *)0x94e6df;
      cVar2 = FUN_01255580();
      puVar3 = (uint *)(iStack_14 + 0xb4 + (uint)(cVar2 != '\0') * 0x40);
      uVar13 = *puVar3 ^ (uint)puVar3;
      piVar11 = (int *)param_3[1];
      if (piVar11 != (int *)0x0) {
        LOCK();
        piVar11[1] = piVar11[1] + 1;
        UNLOCK();
        piVar11 = (int *)param_3[1];
      }
      iStack_20 = *param_3;
      uStack_98 = 0;
      piStack_9c = (int *)0x0;
      pppuStack_a0 = (undefined ***)0x4;
      uStack_8._0_1_ = 3;
      uStack_a4 = 0x94e725;
      piStack_1c = piVar11;
      FUN_01255470();
      uStack_98 = CONCAT44(&iStack_20,auStack_38);
      pppuStack_a0 = (undefined ***)(iStack_14 + 0x5c);
      uStack_a4 = 0x94e73a;
      piStack_9c = (int *)uVar13;
      FUN_009511c0();
      uStack_8._0_1_ = 2;
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar9 = piVar11[1] + -1;
        piVar11[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          uStack_98 = CONCAT44(0x94e752,(undefined4)uStack_98);
          (**(code **)*piVar11)();
          LOCK();
          iVar9 = piVar11[2] + -1;
          piVar11[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            uStack_98 = CONCAT44(0x94e763,(undefined4)uStack_98);
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      uStack_98 = CONCAT44(0xfffffffe,uVar13);
      piStack_9c = (int *)0x94e76b;
      FUN_01257280();
      piVar11 = *(int **)(iStack_14 + 0x70);
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    if (piVar11 != (int *)0x0) {
      LOCK();
      *piVar11 = *piVar11 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
    if (piVar11 == (int *)0x0) {
      param_2 = (int *)0x0;
    }
    else {
      param_2 = (int *)piVar11[2];
    }
    uStack_98 = CONCAT44(param_2,0x94e7a5);
    param_14 = piVar11;
    uVar4 = FUN_012565c0();
    uStack_98 = CONCAT44(uVar4,0x94e7b1);
    FUN_00d887b0();
    uStack_8._0_1_ = 5;
    uStack_98 = CONCAT44(auStack_6c,0x94e7c4);
    FUN_00d88cd0();
    uStack_98 = CONCAT44(0x94e7cc,(undefined4)uStack_98);
    FUN_00d88aa0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar9 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        uStack_98 = CONCAT44(0x94e7e7,(undefined4)uStack_98);
        FUN_00d88950();
        uStack_98 = CONCAT44(0x10,piVar11);
        piStack_9c = (int *)0x94e7ef;
        FUN_01674ea0();
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
  }
  *param_1 = 0;
  uStack_18 = 1;
  if ((char)param_16 != '\0') {
    if (piStack_74 == (int *)0x0) {
      iVar9 = 0;
    }
    else {
      iVar9 = piStack_74[2];
    }
    uStack_98 = CONCAT44(iVar9,&param_16);
    piStack_9c = (int *)0x94e8f2;
    puVar5 = (undefined4 *)FUN_00d890b0();
    uVar4 = *puVar5;
    *puVar5 = 0;
    piVar11 = (int *)*param_1;
    *param_1 = uVar4;
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar9 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        uStack_98 = CONCAT44(0x94e91a,(undefined4)uStack_98);
        FUN_00d889a0();
        uStack_98 = CONCAT44(8,piVar11);
        piStack_9c = (int *)0x94e922;
        FUN_01674ea0();
      }
    }
    piVar11 = (int *)param_16;
    if (param_16 != (uint *)0x0) {
      LOCK();
      iVar9 = *param_16;
      *param_16 = *param_16 + -1;
      UNLOCK();
      if ((iVar9 == 1) && (param_16 != (uint *)0x0)) {
        uStack_98 = CONCAT44(0x94e942,(undefined4)uStack_98);
        FUN_00d889a0();
        uStack_98 = CONCAT44(8,piVar11);
        piStack_9c = (int *)0x94e94a;
        FUN_01674ea0();
      }
    }
  }
  piVar11 = piStack_74;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  param_14 = piStack_74;
  if (piStack_74 != (int *)0x0) {
    LOCK();
    *piStack_74 = *piStack_74 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  if ((piStack_74 == (int *)0x0) || (piStack_9c = (int *)piStack_74[2], piStack_9c == (int *)0x0)) {
    uStack_98._4_4_ = 6;
    uStack_98._0_4_ = 2;
    piStack_9c = (int *)0x94ec9a;
    uVar4 = FUN_00f86fc0();
    uStack_98 = CONCAT44(uStack_98._4_4_,uVar4);
    piStack_9c = (int *)0x3;
    pppuStack_a0 = (undefined ***)0x94eca5;
    FUN_0086edd0();
    pppuStack_a0 = (undefined ***)0x2;
    uStack_a4 = 0x94ecac;
    uVar4 = FUN_00f86fc0();
    uStack_98 = CONCAT44(uVar4,0x94ecb8);
    FUN_00550130();
    uStack_98 = CONCAT44(&DAT_01c17198,auStack_2c);
                    /* WARNING: Subroutine does not return */
    piStack_9c = (int *)0x94ecc6;
    FUN_0170c2a8();
  }
  if ((param_15 != (int *)0x0) && (piVar14 = *(int **)*param_15, piVar14 != (int *)*param_15)) {
    do {
      uStack_98 = CONCAT44(piVar14 + 10,piVar11[2]);
      piStack_9c = (int *)0x94e99d;
      FUN_00da3620();
      piVar6 = piVar14 + 4;
      if (0xf < (uint)piVar14[9]) {
        piVar6 = (int *)*piVar6;
      }
      uStack_98 = CONCAT44(piVar6,0xffffd8ee);
      piStack_9c = (int *)piVar11[2];
      pppuStack_a0 = (undefined ***)0x94e9b9;
      FUN_01257030();
      piVar6 = (int *)piVar14[2];
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar2 = *(char *)(*piVar6 + 0xd);
        piVar14 = piVar6;
        piVar6 = (int *)*piVar6;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*piVar6 + 0xd);
          piVar14 = piVar6;
          piVar6 = (int *)*piVar6;
        }
      }
      else {
        cVar2 = *(char *)(piVar14[1] + 0xd);
        piVar1 = (int *)piVar14[1];
        piVar6 = piVar14;
        while ((piVar14 = piVar1, cVar2 == '\0' && (piVar6 == (int *)piVar14[2]))) {
          cVar2 = *(char *)(piVar14[1] + 0xd);
          piVar1 = (int *)piVar14[1];
          piVar6 = piVar14;
        }
      }
    } while (piVar14 != (int *)*param_15);
    piStack_9c = (int *)piVar11[2];
  }
  uStack_98 = 0x1ffffd8ee;
  pppuStack_a0 = (undefined ***)0x94ea13;
  FUN_012571e0();
  iStack_20 = 1;
  piStack_1c = param_2;
  uStack_98 = 0x10191bf9c;
  uStack_8._0_1_ = 8;
  uStack_40 = 0;
  uStack_3c = 0xf;
  appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
  piStack_9c = (int *)0x94ea48;
  FUN_005542c0();
  uStack_8._0_1_ = 9;
  if (param_5 == (char *)0x0) {
    uStack_98 = 0x30094ea6c;
    pcVar7 = (char *)FUN_00f86fc0();
    pcVar12 = pcVar7;
    do {
      cVar2 = *pcVar12;
      pcVar12 = pcVar12 + 1;
    } while (cVar2 != '\0');
    uStack_98 = CONCAT44((int)pcVar12 - (int)(pcVar7 + 1),pcVar7);
  }
  else {
    pcVar12 = param_5;
    do {
      cVar2 = *pcVar12;
      pcVar12 = pcVar12 + 1;
    } while (cVar2 != '\0');
    uStack_98 = CONCAT44((int)pcVar12 - (int)(param_5 + 1),param_5);
  }
  piStack_9c = (int *)0x94ea87;
  FUN_00554150();
  pppppuVar8 = appppuStack_50;
  if (0xf < uStack_3c) {
    pppppuVar8 = (undefined4 *****)appppuStack_50[0];
  }
  uStack_98 = CONCAT44(pppppuVar8,param_4);
  piStack_9c = (int *)piVar11[2];
  pppuStack_a0 = (undefined ***)0x94ea9e;
  iVar9 = FUN_009edf40();
  if (iVar9 != 0) {
    uStack_98._4_4_ = 0xffffffff;
    uStack_98._0_4_ = 0x94ecd0;
    uVar4 = FUN_00764410();
    uStack_98 = CONCAT44(uStack_98._4_4_,uVar4);
    piStack_9c = (int *)0x94ecd6;
    uVar4 = FUN_00881a60();
    uStack_98 = CONCAT44(uVar4,0x94ece2);
    FUN_0054eff0();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    uStack_98._4_4_ = 0xfffffffe;
    uStack_98._0_4_ = 0x94ecf0;
    uVar4 = FUN_00764410();
    uStack_98 = CONCAT44(uStack_98._4_4_,uVar4);
    piStack_9c = (int *)0x94ecf6;
    FUN_01257280();
    uStack_98 = CONCAT44(auStack_68,0x94ed05);
    FUN_005500e0();
    uStack_98 = CONCAT44(&DAT_01c17198,auStack_2c);
                    /* WARNING: Subroutine does not return */
    piStack_9c = (int *)0x94ed13;
    FUN_0170c2a8();
  }
  uStack_98 = CONCAT44(iStack_14,0x94eab1);
  iVar9 = FUN_008f7870();
  param_15 = (int *)iVar9;
  if (iVar9 != 0) {
    uStack_98 = CONCAT44(0x94eac4,(undefined4)uStack_98);
    cVar2 = FUN_008f2030();
    if (cVar2 == '\0') {
      param_16 = (uint *)&DAT_00000010;
      uStack_98 = CONCAT44(iVar9 + 0x1e0,0x94eade);
      iVar10 = FUN_016dee6d();
      if (iVar10 != 0) {
        uStack_98 = CONCAT44(iVar10,0x94eaeb);
        FUN_016df3c9();
      }
      uStack_98 = CONCAT44(&param_16,&param_16);
      piStack_9c = (int *)auStack_28;
      uStack_8._0_1_ = 0xb;
      pppuStack_a0 = (undefined ***)0x94eb09;
      FUN_00687eb0();
      DAT_01ee04b4 = DAT_01ee04b4 | (uint)param_16;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      uStack_98 = CONCAT44(iVar9 + 0x1e0,0x94eb1c);
      iVar9 = FUN_016deec8();
      if (iVar9 != 0) {
        uStack_98 = CONCAT44(iVar9,0x94eb29);
        FUN_016df3c9();
      }
      uStack_8._0_1_ = 9;
    }
  }
  if (*param_3 != 0) {
    if (DAT_01d63564 != '\0') {
      uStack_98 = CONCAT44(iStack_14,0x94eb4a);
      FUN_008ed2c0();
      uStack_98 = CONCAT44(param_1,0x94eb5d);
      FUN_009479b0();
    }
    uStack_98 = CONCAT44(piVar11[2],0x94eb6d);
    FUN_005e6780();
  }
  param_16 = auStack_b0;
  auStack_b0[0] = 0;
  puVar3 = auStack_b0;
  if (param_7 != 0) {
    auStack_b0[0] = param_7;
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_a8,0);
      puVar3 = param_16;
    }
    else {
      uStack_a8 = param_9;
      uStack_a4 = param_10;
      pppuStack_a0 = (undefined ***)param_11;
      piStack_9c = (int *)param_12;
      uStack_98 = param_13;
      puVar3 = auStack_b0;
    }
  }
  param_16 = puVar3;
  LOCK();
  *piVar11 = *piVar11 + 1;
  UNLOCK();
  FUN_0095b4a0(piVar11,param_6);
  uStack_8._0_1_ = 8;
  if (0xf < uStack_3c) {
    uVar13 = uStack_3c + 1;
    pppppuVar8 = (undefined4 *****)appppuStack_50[0];
    if (0xfff < uVar13) {
      pppppuVar8 = (undefined4 *****)appppuStack_50[0][-1];
      uVar13 = uStack_3c + 0x24;
      if (0x1f < (uint)((int)appppuStack_50[0] + (-4 - (int)pppppuVar8))) {
        uStack_98 = CONCAT44(&UNK_0094ed18,(undefined4)uStack_98);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_98 = CONCAT44(uVar13,pppppuVar8);
    piStack_9c = (int *)0x94ebff;
    FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  appppuStack_50[0] = (undefined4 ****)((uint)appppuStack_50[0] & 0xffffff00);
  uStack_98 = CONCAT44(0xfffffffe,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  piStack_9c = (int *)0x94ec22;
  FUN_01257280();
  LOCK();
  iVar9 = *piVar11;
  *piVar11 = *piVar11 + -1;
  UNLOCK();
  if (iVar9 == 1) {
    uStack_98 = CONCAT44(0x94ec38,(undefined4)uStack_98);
    FUN_00d88950();
    uStack_98 = CONCAT44(0x10,piVar11);
    piStack_9c = (int *)0x94ec40;
    FUN_01674ea0();
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_98 = CONCAT44(0x94ec55,(undefined4)uStack_98);
  FUN_00d88aa0();
  uStack_8 = 0x10;
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    piStack_9c = &param_9;
    uStack_98 = CONCAT44(2,piStack_9c);
    pppuStack_a0 = (undefined ***)0x94ec79;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17189 ; VA 0x0094ed20 ; FUN_0094ed20 */

undefined4 *
FUN_0094ed20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  char cVar2;
  undefined *puVar3;
  undefined4 uStack_28;
  undefined4 uStack_24;
  code *pcStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb831;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_14 = 1;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 1;
  pcStack_20 = FUN_00956dc0;
  puStack_1c = param_1;
  cVar2 = FUN_00585a40(&pcStack_20);
  if (cVar2 == '\0') {
    puVar3 = &DAT_01934d11;
  }
  else {
    puVar3 = (undefined *)0x0;
  }
  FUN_0094e610(&piStack_18,param_2,&uStack_28,param_3,param_4,param_5,puVar3);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar1 = *piStack_18;
    *piStack_18 = *piStack_18 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piStack_18 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piStack_18,8);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17190 ; VA 0x0094ee10 ; FUN_0094ee10 */

void FUN_0094ee10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb850;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0094e610(&piStack_14,param_1,&uStack_1c,param_2,param_3,&uStack_28,0);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = *piStack_14;
    *piStack_14 = *piStack_14 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piStack_14 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piStack_14,8);
    }
  }
  uStack_8 = 2;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17191 ; VA 0x0094eed0 ; FUN_0094eed0 */

undefined4 __thiscall FUN_0094eed0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  float10 fVar2;
  
  iVar1 = FUN_01256300();
  fVar2 = (float10)FUN_009d0880(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))((double)fVar2);
  return 0;
}



/* FUNCTION 17192 ; VA 0x0094ef20 ; FUN_0094ef20 */

undefined4 FUN_0094ef20(undefined4 param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_2e8 [272];
  undefined auStack_1d8 [160];
  int iStack_138;
  undefined4 uStack_134;
  undefined4 uStack_12c;
  int iStack_128;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb86b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_4 = -1;
  puVar3 = (undefined4 *)FUN_00587490(auStack_18);
  uVar6 = *puVar3;
  uVar1 = puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  *param_3 = uVar6;
  piVar2 = (int *)param_3[1];
  param_3[1] = uVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_00565940(3,1);
  uStack_8 = 0;
  iVar4 = FUN_01259b40(param_2,0,&iStack_138);
  if (iVar4 != 0) {
    iVar4 = 0;
    do {
      iVar5 = FUN_01259a20(param_2,&DAT_019347e0,&iStack_138);
      if (iVar5 != 0) {
        if (iVar4 == 0) {
          *param_4 = iStack_128;
        }
        if (-1 < iStack_128) {
          FUN_01259c20(auStack_2e8,uStack_12c,0x100);
          if (iStack_138 == 0) {
            uVar6 = FUN_00558890(auStack_1d8,auStack_2e8,", line ");
            FUN_00558890(uVar6);
            uVar6 = FUN_005af260(iStack_128);
            FUN_00562ba0(uVar6);
          }
          else {
            uVar6 = FUN_00558890(auStack_1d8,auStack_2e8,", line ");
            FUN_00558890(uVar6);
            uVar6 = FUN_005af260(iStack_128,&DAT_019347e8,uStack_134,&DAT_018c0cc8,iStack_138);
            uVar6 = FUN_00558890(uVar6);
            uVar6 = FUN_00558890(uVar6);
            uVar6 = FUN_00558890(uVar6);
            uVar6 = FUN_00558890(uVar6);
            FUN_00562ba0(uVar6);
          }
        }
      }
      iVar4 = iVar4 + 1;
      iVar5 = FUN_01259b40(param_2,iVar4,&iStack_138);
    } while ((iVar5 != 0) && (iVar4 < 0xc));
  }
  FUN_0058c420(param_1);
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17193 ; VA 0x0094f140 ; FUN_0094f140 */

void FUN_0094f140(int param_1,int *param_2,int *param_3,undefined4 *param_4,int *param_5)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  undefined auStack_2b8 [176];
  undefined auStack_208 [160];
  int aiStack_168 [4];
  int iStack_158;
  undefined auStack_151 [265];
  int iStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar4 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb8a6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_5 = -1;
  puVar5 = (undefined4 *)FUN_00587490(&uStack_18);
  uVar7 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *param_4 = uVar7;
  piVar3 = (int *)param_4[1];
  param_4[1] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar10 = piVar3[1] + -1;
    piVar3[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar10 = piVar3[2] + -1;
      piVar3[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_14[1] + -1;
    piStack_14[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00565940(3,1);
  uStack_8 = 0;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  piStack_14 = (int *)((uint)piStack_14 & 0xffffff00);
  FUN_0060e8c0(0,&uStack_18,(int)&param_1 + 3);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_4 = (undefined4 *)DAT_01d643ec;
  param_1 = 0;
  if (0 < DAT_01d643ec) {
    do {
      iVar10 = param_1;
      iVar6 = FUN_01259b40(uVar4,param_1,aiStack_168);
      if (iVar6 == 0) break;
      iVar6 = FUN_01259a20(uVar4,&DAT_019347f4,aiStack_168);
      if (iVar6 != 0) {
        if (iVar10 == 0) {
          *param_5 = iStack_158;
        }
        if (-1 < iStack_158) {
          if (aiStack_168[0] == 0) {
            uVar7 = FUN_00558890(auStack_2b8,auStack_151,", line ");
            FUN_00558890(uVar7);
            uVar7 = FUN_005af260(iStack_158);
            FUN_00562ba0(uVar7);
          }
          else {
            uVar7 = FUN_00558890(auStack_2b8,auStack_151,", line ");
            FUN_00558890(uVar7);
            uVar7 = FUN_005af260(iStack_158,&DAT_019347e8,aiStack_168[0]);
            uVar7 = FUN_00558890(uVar7);
            uVar7 = FUN_00558890(uVar7);
            FUN_00562ba0(uVar7);
          }
          iVar6 = FUN_01255e10(uVar4,1);
          if (iVar6 != 0) {
            iVar6 = 1;
            iVar8 = FUN_01259980(uVar4,aiStack_168,1);
            iVar10 = param_1;
            while (iVar8 != 0) {
              param_1 = iVar10;
              if (iVar6 == 1) {
                FUN_00558890(auStack_208,"arguments[");
                uVar7 = FUN_005af260(param_1,&DAT_019347f8);
                uVar7 = FUN_00558890(uVar7);
                FUN_00562ba0(uVar7);
              }
              puVar9 = (undefined4 *)FUN_00956680(&iStack_30,uVar4,0xffffffff,&iStack_48);
              puVar5 = puVar9 + 4;
              uStack_8._0_1_ = 3;
              if (0xf < (uint)puVar9[5]) {
                puVar9 = (undefined4 *)*puVar9;
              }
              uVar7 = FUN_0055b3b0(auStack_208,puVar9,*puVar5);
              uVar7 = FUN_00558890(uVar7,&DAT_018bf378);
              FUN_00562ba0(uVar7);
              uStack_8 = CONCAT31(uStack_8._1_3_,2);
              if (0xf < uStack_1c) {
                uVar12 = uStack_1c + 1;
                iVar10 = iStack_30;
                if (0xfff < uVar12) {
                  iVar10 = *(int *)(iStack_30 + -4);
                  uVar12 = uStack_1c + 0x24;
                  if (0x1f < (iStack_30 - iVar10) - 4U) goto LAB_0094f5dd;
                }
                FUN_01674ea0(iVar10,uVar12);
              }
              FUN_01257280(uVar4,0xfffffffe);
              iVar6 = iVar6 + 1;
              iVar8 = FUN_01259980(uVar4,aiStack_168,iVar6);
              iVar10 = param_1;
            }
          }
        }
      }
      param_1 = iVar10 + 1;
    } while (param_1 < (int)param_4);
  }
  FUN_0058c420(&iStack_30);
  piVar3 = param_2;
  if (param_2 == &iStack_30) {
    if (0xf < uStack_1c) {
      uVar12 = uStack_1c + 1;
      iVar10 = iStack_30;
      if (0xfff < uVar12) {
        iVar10 = *(int *)(iStack_30 + -4);
        uVar12 = uStack_1c + 0x24;
        if (0x1f < (iStack_30 - iVar10) - 4U) goto LAB_0094f5dd;
      }
      FUN_01674ea0(iVar10,uVar12);
    }
  }
  else {
    uVar12 = param_2[5];
    if (0xf < uVar12) {
      iVar10 = *param_2;
      uVar11 = uVar12 + 1;
      iVar6 = iVar10;
      if (0xfff < uVar11) {
        iVar6 = *(int *)(iVar10 + -4);
        uVar11 = uVar12 + 0x24;
        if (0x1f < (iVar10 - iVar6) - 4U) goto LAB_0094f5dd;
      }
      FUN_01674ea0(iVar6,uVar11);
    }
    *piVar3 = iStack_30;
    piVar3[1] = iStack_2c;
    piVar3[2] = iStack_28;
    piVar3[3] = iStack_24;
    *(ulonglong *)(piVar3 + 4) = CONCAT44(uStack_1c,uStack_20);
  }
  FUN_0058c420(&iStack_30);
  piVar3 = param_3;
  if (param_3 == &iStack_30) {
    if (0xf < uStack_1c) {
      uVar12 = uStack_1c + 1;
      iVar10 = iStack_30;
      if (0xfff < uVar12) {
        iVar10 = *(int *)(iStack_30 + -4);
        uVar12 = uStack_1c + 0x24;
        if (0x1f < (iStack_30 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar10,uVar12);
    }
  }
  else {
    uVar12 = param_3[5];
    if (0xf < uVar12) {
      iVar10 = *param_3;
      uVar11 = uVar12 + 1;
      iVar6 = iVar10;
      if (0xfff < uVar11) {
        iVar6 = *(int *)(iVar10 + -4);
        uVar11 = uVar12 + 0x24;
        if (0x1f < (iVar10 - iVar6) - 4U) {
LAB_0094f5dd:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar11);
    }
    *piVar3 = iStack_30;
    piVar3[1] = iStack_2c;
    piVar3[2] = iStack_28;
    piVar3[3] = iStack_24;
    *(ulonglong *)(piVar3 + 4) = CONCAT44(uStack_1c,uStack_20);
  }
  if (iStack_48 != 0) {
    uVar12 = iStack_40 - iStack_48 & 0xfffffff8;
    iVar10 = iStack_48;
    if (0xfff < uVar12) {
      iVar10 = *(int *)(iStack_48 + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iStack_48 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar12);
    iStack_48 = 0;
    uStack_44 = 0;
    iStack_40 = 0;
  }
  FUN_005705c0();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17194 ; VA 0x0094f5f0 ; FUN_0094f5f0 */

void FUN_0094f5f0(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar2 = param_2;
  if ((*(int *)(param_2 + 0x14) != 0) && (iVar7 = 0, 0 < *(int *)(param_2 + 0x34))) {
    do {
      iVar1 = *(int *)(*(int *)(iVar2 + 0xc) + iVar7 * 4);
      if ((char)iVar1 == 'E') {
        iVar3 = FUN_012597f0(iVar2,iVar7);
        iVar4 = iVar3 + -1;
        iVar6 = *param_1;
        param_2 = iVar6;
        if (param_1[1] - iVar6 >> 2 <= iVar4) {
          param_2 = -1;
          FUN_005f87c0(iVar3,param_1,&param_2);
          iVar6 = *param_1;
        }
        iVar3 = *(int *)(iVar6 + iVar4 * 4);
        iVar5 = 0;
        if (-1 < iVar3) {
          iVar5 = iVar3;
        }
        *(int *)(iVar6 + iVar4 * 4) = iVar5 + (iVar1 >> 8);
      }
      iVar7 = iVar7 + 1;
    } while (iVar7 < *(int *)(iVar2 + 0x34));
  }
  iVar7 = 0;
  if (0 < *(int *)(iVar2 + 0x38)) {
    do {
      FUN_0094f5f0(param_1,*(undefined4 *)(*(int *)(iVar2 + 0x10) + iVar7 * 4));
      iVar7 = iVar7 + 1;
    } while (iVar7 < *(int *)(iVar2 + 0x38));
  }
  return;
}



/* FUNCTION 17195 ; VA 0x0094f6a0 ; FUN_0094f6a0 */

int * __thiscall FUN_0094f6a0(int param_1,int *param_2,byte *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193) * 8;
  puVar3 = *(undefined4 **)(iVar1 + *(int *)(param_1 + 0xc));
  puVar5 = puVar3;
  while( true ) {
    puVar4 = puVar2;
    if (puVar3 != puVar2) {
      puVar4 = (undefined4 *)**(undefined4 **)(iVar1 + *(int *)(param_1 + 0xc) + 4);
    }
    if (puVar5 == puVar4) break;
    if (puVar5[2] == *(int *)param_3) {
      *param_2 = (int)puVar5;
      return param_2;
    }
    puVar5 = (undefined4 *)*puVar5;
  }
  *param_2 = (int)puVar2;
  return param_2;
}



/* FUNCTION 17196 ; VA 0x0094f740 ; FUN_0094f740 */

/* WARNING: Removing unreachable block (ram,0x0094f8fa) */
/* WARNING: Removing unreachable block (ram,0x0094f89a) */
/* WARNING: Removing unreachable block (ram,0x0094f939) */
/* WARNING: Removing unreachable block (ram,0x0094f854) */
/* WARNING: Removing unreachable block (ram,0x0094f934) */
/* WARNING: Removing unreachable block (ram,0x0094f846) */
/* WARNING: Removing unreachable block (ram,0x0094f868) */
/* WARNING: Removing unreachable block (ram,0x0094f88c) */
/* WARNING: Removing unreachable block (ram,0x0094f8ae) */
/* WARNING: Removing unreachable block (ram,0x0094f8d1) */
/* WARNING: Removing unreachable block (ram,0x0094f8dd) */
/* WARNING: Removing unreachable block (ram,0x0094f8eb) */
/* WARNING: Removing unreachable block (ram,0x0094f908) */
/* WARNING: Removing unreachable block (ram,0x0094f93e) */
/* WARNING: Removing unreachable block (ram,0x0094f918) */

undefined4
FUN_0094f740(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
            undefined4 param_21,undefined4 param_22)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb8d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009490c0(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,
                       param_10,param_11,CONCAT44(param_13,param_12),param_14,param_15,param_16,
                       param_17,param_18,param_19,CONCAT44(param_21,param_20),param_22);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 17197 ; VA 0x0094f950 ; FUN_0094f950 */

/* WARNING: Removing unreachable block (ram,0x0094fa71) */
/* WARNING: Removing unreachable block (ram,0x0094fadc) */
/* WARNING: Removing unreachable block (ram,0x0094fa2b) */
/* WARNING: Removing unreachable block (ram,0x0094fad7) */
/* WARNING: Removing unreachable block (ram,0x0094fa1d) */
/* WARNING: Removing unreachable block (ram,0x0094fa3f) */
/* WARNING: Removing unreachable block (ram,0x0094fa63) */
/* WARNING: Removing unreachable block (ram,0x0094fa81) */
/* WARNING: Removing unreachable block (ram,0x0094faa4) */
/* WARNING: Removing unreachable block (ram,0x0094fab0) */
/* WARNING: Removing unreachable block (ram,0x0094fabe) */

undefined4
FUN_0094f950(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb8f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00949320(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,
                       param_10,param_11,CONCAT44(param_13,param_12),param_14,param_15);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 17198 ; VA 0x0094faf0 ; FUN_0094faf0 */

void FUN_0094faf0(undefined4 param_1,undefined4 param_2)

{
  FUN_009441d0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 17199 ; VA 0x0094fb10 ; FUN_0094fb10 */

void FUN_0094fb10(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb920;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  iVar4 = *(int *)(iVar1 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cdc0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar1 + 0x1a8;
  if (*(int *)(iVar1 + 0x1a4) == 0) {
    iVar4 = 0;
  }
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar3 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  iVar1 = *param_2;
  uStack_8 = 0;
  iVar4 = *(int *)(iVar1 + 0xd0);
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    iVar4 = iVar1 + 0xd8;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      iVar4 = 0;
    }
    FUN_0054ef60(iVar4);
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar1 = *param_2;
    iVar4 = FUN_0088cb40();
    if (iVar1 == iVar4) {
      piVar3 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar3 = (int *)0x0;
      }
      FUN_0054ef60(piVar3);
      uStack_8 = 0xffffffff;
      FUN_0094f950(param_1);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 17200 ; VA 0x0094fc20 ; FUN_0094fc20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0094fc20(int param_1)

{
  if (param_1 != 0) {
    return *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x6c) + 0xc) + 4);
  }
  return *(undefined4 *)(_DAT_0000000c + 4);
}



/* FUNCTION 17201 ; VA 0x0094fc40 ; FUN_0094fc40 */

int * __thiscall FUN_0094fc40(int param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  uint *puVar5;
  int iVar6;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_34;
  undefined4 **ppuStack_30;
  uint *puStack_2c;
  undefined4 *puStack_28;
  undefined4 **ppuStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb950;
  pvStack_10 = ExceptionList;
  if (DAT_01d644b8 == '\0') {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("ScriptContext:GetCoverageStats() is not enabled");
  }
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  ExceptionList = &pvStack_10;
  uStack_50 = FUN_00575b50(0,0);
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_8 = 1;
  uStack_54 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = 2;
  puStack_18 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_18 == (undefined4 *)0x0) {
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 1;
    puStack_18[2] = 1;
    *puStack_18 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_18[3] = 0;
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    puStack_1c = puStack_18;
  }
  puStack_20 = puStack_1c + 3;
  iVar1 = *(int *)(param_1 + 0x39c);
  puStack_28 = &uStack_54;
  iVar6 = *(int *)(param_1 + 0x398);
  ppuStack_24 = &puStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  for (; iVar6 != iVar1; iVar6 = iVar6 + 0x40) {
    FUN_009482c0(iVar6);
  }
  uVar4 = FUN_01255560();
  cVar3 = FUN_01255580(uVar4,5);
  puVar5 = (uint *)(param_1 + 0xb4 + (uint)(cVar3 != '\0') * 0x40);
  uStack_14 = *puVar5 ^ (uint)puVar5;
  FUN_008f7870(param_1);
  puStack_34 = &uStack_54;
  ppuStack_30 = &puStack_28;
  puStack_2c = &uStack_14;
  FUN_00944360(&puStack_34);
  puVar2 = puStack_20;
  puStack_20 = (undefined4 *)0x0;
  *param_2 = (int)puVar2;
  param_2[1] = (int)puStack_1c;
  puStack_1c = (undefined4 *)0x0;
  FUN_0070a3d0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17202 ; VA 0x0094fde0 ; FUN_0094fde0 */

uint __thiscall FUN_0094fde0(int param_1,undefined4 param_2)

{
  char cVar1;
  uint *puVar2;
  
  cVar1 = FUN_01255580(param_2,5);
  puVar2 = (uint *)(param_1 + 0xb4 + (uint)(cVar1 != '\0') * 0x40);
  return *puVar2 ^ (uint)puVar2;
}



/* FUNCTION 17203 ; VA 0x0094fe20 ; FUN_0094fe20 */

uint FUN_0094fe20(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  
  if (DAT_01d644f0 != '\0') {
    return *(uint *)(*(int *)(param_1 + 0x10) + 0xe8);
  }
  if (param_1 == 0) {
    iVar4 = 0;
  }
  else {
    iVar4 = *(int *)(param_1 + 0x6c);
  }
  iVar4 = *(int *)(*(int *)(iVar4 + 0xc) + 4);
  puVar2 = *(undefined4 **)(iVar4 + 0xfc);
  puVar3 = (undefined4 *)*puVar2;
  DAT_01d644f0 = 0;
  while( true ) {
    if (puVar3 == puVar2) {
      iVar6 = iVar4 + 0x78;
      if (iVar6 != iVar4 + 0xf8) {
        puVar5 = (uint *)(iVar4 + 0xb4);
        do {
          if (((*puVar5 ^ (uint)puVar5) != 0) &&
             (*(int *)((*puVar5 ^ (uint)puVar5) + 0x10) == *(int *)(param_1 + 0x10))) {
            return *(uint *)(iVar6 + 0x3c) ^ iVar6 + 0x3cU;
          }
          iVar6 = iVar6 + 0x40;
          puVar5 = puVar5 + 0x10;
        } while (iVar6 != iVar4 + 0xf8);
      }
      return 0;
    }
    piVar7 = (int *)puVar3[4];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = (int *)puVar3[4];
    }
    uVar8 = *(uint *)(puVar3[3] + 0x3c) ^ (uint)(puVar3[3] + 0x3c);
    if (*(int *)(uVar8 + 0x10) == *(int *)(param_1 + 0x10)) break;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar6 = piVar7[1] + -1;
      piVar7[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar6 = piVar7[2] + -1;
        piVar7[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    puVar3 = (undefined4 *)*puVar3;
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar4 = piVar7[1] + -1;
    piVar7[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  return uVar8;
}



/* FUNCTION 17204 ; VA 0x0094ff40 ; FUN_0094ff40 */

uint __thiscall FUN_0094ff40(int param_1,int param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb978;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*param_3 != 0) &&
     (ExceptionList = &pvStack_10, param_3 = (int *)FUN_009432b0(), param_3 != (int *)0x0)) {
    FUN_0094f6a0(&param_2,&param_3);
    if (param_2 == *(int *)(param_1 + 0xfc)) {
      if (DAT_01d64528 == '\0') {
        if (DAT_01d64530 == '\0') {
          FUN_00943970(&iStack_18);
          uStack_8 = 2;
          FUN_009547a0(iStack_18);
          piVar7 = &iStack_18;
          FUN_00948230(&param_3);
          FUN_0056ecd0(piVar7);
          uVar5 = *(uint *)(iStack_18 + 0x3cU);
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return uVar5 ^ iStack_18 + 0x3cU;
        }
        if (*(int *)(param_1 + 0x130) == 0) {
          FUN_00943970(&iStack_18);
          uStack_8 = 1;
          FUN_009547a0(iStack_18);
          iVar4 = iStack_14;
          *(int *)(param_1 + 0x128) = iStack_18;
          piVar7 = *(int **)(param_1 + 300);
          iStack_18 = 0;
          iStack_14 = 0;
          *(int *)(param_1 + 300) = iVar4;
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar4 = piVar7[1] + -1;
            piVar7[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              piVar6 = piVar7 + 2;
              iVar4 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          uStack_8 = 0xffffffff;
          FUN_00550b30();
        }
        piVar7 = (int *)(param_1 + 0x128);
        FUN_00948230(&param_3);
        FUN_0056ecd0(piVar7);
        iVar4 = *(int *)(param_1 + 0x128);
        *(uint *)(param_1 + 0x130) = (*(int *)(param_1 + 0x130) + 1U) % DAT_01d64440;
      }
      else {
        iVar2 = FUN_0152ff20();
        iVar4 = *(int *)(param_1 + 0x118);
        uVar5 = iVar2 * DAT_01d64434;
        if ((uint)(*(int *)(param_1 + 0x11c) - iVar4 >> 3) < uVar5) {
          FUN_00943970(&iStack_18);
          uStack_8 = 0;
          FUN_009547a0(iStack_18);
          piVar7 = *(int **)(param_1 + 0x11c);
          if (*(int **)(param_1 + 0x120) == piVar7) {
            FUN_0077c2a0(piVar7,&iStack_18);
          }
          else {
            *piVar7 = iStack_18;
            piVar7[1] = iStack_14;
            *(int *)(param_1 + 0x11c) = *(int *)(param_1 + 0x11c) + 8;
            iStack_18 = 0;
            iStack_14 = 0;
          }
          uStack_8 = 0xffffffff;
          FUN_00550b30();
          iVar4 = *(int *)(param_1 + 0x118);
        }
        piVar7 = (int *)(iVar4 + *(int *)(param_1 + 0x124) * 8);
        piVar6 = piVar7;
        FUN_00948230(&param_3);
        FUN_0056ecd0(piVar6);
        *(uint *)(param_1 + 0x124) = (*(int *)(param_1 + 0x124) + 1U) % uVar5;
        iVar4 = *piVar7;
      }
    }
    else {
      iVar4 = *(int *)(param_2 + 0xc);
    }
    ExceptionList = pvStack_10;
    return *(uint *)(iVar4 + 0x3c) ^ iVar4 + 0x3cU;
  }
  cVar1 = FUN_01255580(param_2,5);
  puVar3 = (uint *)(param_1 + 0xb4 + (uint)(cVar1 != '\0') * 0x40);
  ExceptionList = pvStack_10;
  return *puVar3 ^ (uint)puVar3;
}



/* FUNCTION 17205 ; VA 0x009501e0 ; FUN_009501e0 */

undefined __fastcall FUN_009501e0(int param_1)

{
  return *(undefined *)(param_1 + 0x5c);
}



/* FUNCTION 17206 ; VA 0x009501f0 ; FUN_009501f0 */

int * FUN_009501f0(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  code *pcVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cb998;
  pvStack_10 = ExceptionList;
  bVar4 = false;
  bVar3 = false;
  uStack_1c = 0;
  uStack_8 = 0;
  uStack_14 = 0;
  iStack_18 = *param_2;
  iVar6 = param_2[1] - iStack_18 >> 3;
  ExceptionList = &pvStack_10;
  if (iVar6 != 0) {
    ExceptionList = &pvStack_10;
    if (iVar6 == 0) {
      ExceptionList = &pvStack_10;
      FUN_00577c40();
      pcVar2 = (code *)swi(3);
      piVar10 = (int *)(*pcVar2)();
      return piVar10;
    }
    do {
      iVar6 = *(int *)(iStack_18 + uStack_14 * 8);
      if (iVar6 == 0) {
LAB_00950292:
        piStack_20 = (int *)0x0;
        puVar8 = &uStack_24;
        bVar3 = true;
        iStack_18 = 0;
      }
      else {
        iVar6 = *(int *)(iVar6 + 0xc);
        iVar7 = FUN_009ec190();
        if ((uint)*(ushort *)(iVar7 + 0x1da) <
            (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) goto LAB_00950292;
        iVar6 = *(int *)(iStack_18 + uStack_14 * 8);
        piStack_28 = *(int **)(iStack_18 + 4 + uStack_14 * 8);
        if (piStack_28 != (int *)0x0) {
          LOCK();
          piStack_28[1] = piStack_28[1] + 1;
          UNLOCK();
          piStack_28 = *(int **)(iStack_18 + 4 + uStack_14 * 8);
        }
        bVar4 = true;
        puVar8 = &uStack_2c;
        iStack_18 = iVar6;
      }
      piVar10 = (int *)puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      piVar1 = piStack_20;
      if (bVar3) {
        bVar3 = false;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_20[1] + -1;
          piStack_20[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar9 = piVar1 + 2;
            iVar6 = *piVar9 + -1;
            *piVar9 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
      }
      piVar1 = piStack_28;
      if (bVar4) {
        bVar4 = false;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_28[1] + -1;
          piStack_28[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar9 = piVar1 + 2;
            iVar6 = *piVar9 + -1;
            *piVar9 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
      }
      iVar6 = iStack_18;
      if (iStack_18 != 0) {
        piVar9 = *(int **)(iStack_18 + 0x28);
        piVar1 = piVar9 + 4;
        if (0xf < (uint)piVar9[5]) {
          piVar9 = (int *)*piVar9;
        }
        cVar5 = FUN_0055c360(piVar9,*piVar1,"MainModule",10);
        if (cVar5 != '\0') {
          *param_1 = iVar6;
          param_1[1] = (int)piVar10;
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar6 = param_3[1] + -1;
            param_3[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*param_3)();
              LOCK();
              piVar10 = param_3 + 2;
              iVar6 = *piVar10;
              *piVar10 = *piVar10 + -1;
              UNLOCK();
              if (iVar6 == 1) {
                (**(code **)(*param_3 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return param_1;
        }
      }
      if (piVar10 != (int *)0x0) {
        LOCK();
        iVar6 = piVar10[1] + -1;
        piVar10[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar10)();
          LOCK();
          iVar6 = piVar10[2] + -1;
          piVar10[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
        }
      }
      uStack_14 = uStack_14 + 1;
      iStack_18 = *param_2;
    } while (uStack_14 < (uint)(param_2[1] - iStack_18 >> 3));
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar6 = param_3[1] + -1;
    param_3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar10 = param_3 + 2;
      iVar6 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17207 ; VA 0x00950420 ; FUN_00950420 */

void FUN_00950420(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  byte *pbVar3;
  undefined4 uVar4;
  int iVar5;
  byte ******ppppppbVar6;
  uint uVar7;
  int *piVar8;
  bool bVar9;
  undefined auStack_50 [24];
  byte *****pppppbStack_38;
  byte ****ppppbStack_34;
  byte ****ppppbStack_30;
  byte ****ppppbStack_2c;
  undefined8 uStack_28;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb9d0;
  pvStack_10 = ExceptionList;
  if (param_2 == (int *)0x0) {
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)(*param_2 + 0xac))();
  FUN_0054ef60(uVar4);
  uStack_8 = 0;
  if ((uint)uStack_28 == 0) {
    iVar1 = param_2[3];
    iVar5 = FUN_00b73900();
    piVar8 = (int *)0x0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      piVar8 = param_2;
    }
    if (piVar8 != (int *)0x0) {
      (**(code **)(*piVar8 + 0xb4))(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar4 = FUN_00a33fa0();
      ppppppbVar6 = (byte ******)FUN_00b74b30(auStack_50,uVar4);
      if (&pppppbStack_38 != ppppppbVar6) {
        FUN_005507b0();
        pppppbStack_38 = *ppppppbVar6;
        ppppbStack_34 = (byte ****)ppppppbVar6[1];
        ppppbStack_30 = (byte ****)ppppppbVar6[2];
        ppppbStack_2c = (byte ****)ppppppbVar6[3];
        uStack_28 = *(undefined8 *)(ppppppbVar6 + 4);
        ppppppbVar6[4] = (byte *****)0x0;
        ppppppbVar6[5] = (byte *****)0xf;
        *(undefined *)ppppppbVar6 = 0;
      }
      FUN_005507b0();
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_00946ed0();
    }
  }
  ppppppbVar6 = &pppppbStack_38;
  if (0xf < uStack_28._4_4_) {
    ppppppbVar6 = (byte ******)pppppbStack_38;
  }
  if ((uint)uStack_28 != DAT_01d64544) goto LAB_009506a6;
  pbVar3 = PTR_DAT_01d64540;
  uVar7 = DAT_01d64544;
  if (DAT_01d64544 != 0) {
    while (uVar2 = uVar7 - 4, 3 < uVar7) {
      if (*ppppppbVar6 != *(byte ******)pbVar3) goto LAB_00950566;
      ppppppbVar6 = ppppppbVar6 + 1;
      pbVar3 = pbVar3 + 4;
      uVar7 = uVar2;
    }
    if (uVar2 == 0xfffffffc) {
LAB_0095059a:
      uVar7 = 0;
    }
    else {
LAB_00950566:
      bVar9 = *(byte *)ppppppbVar6 < *pbVar3;
      if ((*(byte *)ppppppbVar6 == *pbVar3) &&
         ((uVar2 == 0xfffffffd ||
          ((bVar9 = *(byte *)((int)ppppppbVar6 + 1) < pbVar3[1],
           *(byte *)((int)ppppppbVar6 + 1) == pbVar3[1] &&
           ((uVar2 == 0xfffffffe ||
            ((bVar9 = *(byte *)((int)ppppppbVar6 + 2) < pbVar3[2],
             *(byte *)((int)ppppppbVar6 + 2) == pbVar3[2] &&
             ((uVar2 == 0xffffffff ||
              (bVar9 = *(byte *)((int)ppppppbVar6 + 3) < pbVar3[3],
              *(byte *)((int)ppppppbVar6 + 3) == pbVar3[3])))))))))))) goto LAB_0095059a;
      uVar7 = -(uint)bVar9 | 1;
    }
    if (uVar7 != 0) goto LAB_009506a6;
  }
  iVar1 = param_2[3];
  iVar5 = FUN_00b73900();
  piVar8 = (int *)0x0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
      (uint)*(ushort *)(iVar5 + 0x1da)) {
    piVar8 = param_2;
  }
  if (piVar8 == (int *)0x0) {
    iVar1 = param_2[3];
    iVar5 = FUN_009ec190();
    piVar8 = (int *)0x0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      piVar8 = param_2;
    }
    if (piVar8 != (int *)0x0) {
      FUN_009ed300(auStack_18);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uVar4 = FUN_00a33fa0();
      uVar4 = FUN_00b74b30(auStack_50,uVar4);
      FUN_005511f0(uVar4);
      FUN_005507b0();
      FUN_0056e380();
      FUN_0056e380();
    }
  }
  else {
    (**(code **)(*piVar8 + 0xb4))(auStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = FUN_00a33fa0();
    ppppppbVar6 = (byte ******)FUN_00b74b30(auStack_50,uVar4);
    if (&pppppbStack_38 != ppppppbVar6) {
      FUN_005507b0();
      pppppbStack_38 = *ppppppbVar6;
      ppppbStack_34 = (byte ****)ppppppbVar6[1];
      ppppbStack_30 = (byte ****)ppppppbVar6[2];
      ppppbStack_2c = (byte ****)ppppppbVar6[3];
      uStack_28 = *(undefined8 *)(ppppppbVar6 + 4);
      ppppppbVar6[4] = (byte *****)0x0;
      ppppppbVar6[5] = (byte *****)0xf;
      *(undefined *)ppppppbVar6 = 0;
    }
    FUN_005507b0();
    FUN_00946ed0();
  }
LAB_009506a6:
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = (int)pppppbStack_38;
  param_1[1] = (int)ppppbStack_34;
  param_1[2] = (int)ppppbStack_30;
  param_1[3] = (int)ppppbStack_2c;
  *(undefined8 *)(param_1 + 4) = uStack_28;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17208 ; VA 0x009506e0 ; FUN_009506e0 */

void __thiscall FUN_009506e0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint *puVar4;
  int *piVar5;
  uint uVar6;
  bool bVar7;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cba02;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar3 = FUN_01255580(&stack0x00000008,5);
  iStack_1c = (uint)(cVar3 != '\0') * 0x1c;
  iStack_18 = param_1 + 0x3ac + iStack_1c;
  iVar1 = *(int *)(iStack_1c + 0x3c0 + param_1);
  if (iVar1 == 0) {
    bVar7 = true;
  }
  else {
    bVar7 = *(int *)(iVar1 + 8) == 0;
  }
  if (bVar7) {
    cVar3 = FUN_01255580(&stack0x00000008,5);
    puVar4 = (uint *)(param_1 + 0xb4 + (uint)(cVar3 != '\0') * 0x40);
    uVar6 = *puVar4 ^ (uint)puVar4;
    piVar5 = (int *)FUN_01674e20(0xec);
    uStack_8 = 0;
    piStack_20 = piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5[1] = 1;
      piVar5[2] = 1;
      *piVar5 = (int)std::_Ref_count_obj<class_RBX::BaseScript>::vftable;
      FUN_00b74410();
    }
    if ((piVar5 + 3 != (int *)0x0) && ((piVar5[5] == 0 || (*(int *)(piVar5[5] + 4) == 0)))) {
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
        }
      }
      piVar5[4] = (int)(piVar5 + 3);
      piVar2 = (int *)piVar5[5];
      piVar5[5] = (int)piVar5;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar1 = piVar5[1] + -1;
        piVar5[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar1 = piVar5[2] + -1;
          piVar5[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    piStack_24 = piVar5 + 3;
    uStack_8 = 2;
    piStack_20 = piVar5;
    FUN_009511c0(iStack_18,uVar6,&stack0x00000008,&piStack_24);
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01257280(uVar6,0xfffffffe);
    param_1 = iStack_14;
  }
  piVar5 = *(int **)(iStack_1c + 0x3c0 + param_1);
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  *param_2 = piVar5;
  if (piVar5 != (int *)0x0) {
    LOCK();
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17209 ; VA 0x009508c0 ; FUN_009508c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009508c0(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  undefined4 ******ppppppuVar5;
  undefined4 *****pppppuVar6;
  int iVar7;
  uint uVar8;
  uint *puVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined4 ******ppppppuVar14;
  uint *puVar15;
  int *piVar16;
  uint uVar17;
  uint uVar18;
  uint uStack_c0;
  uint uStack_bc;
  uint uStack_b8;
  uint uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  uint *puStack_98;
  int iStack_94;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined8 uStack_68;
  uint uStack_60;
  int iStack_5c;
  int iStack_58;
  double dStack_50;
  uint uStack_48;
  undefined4 *****pppppuStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined4 *****pppppuStack_2c;
  undefined4 *****pppppuStack_28;
  int *piStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cba36;
  pvStack_10 = ExceptionList;
  piStack_9c = *(int **)(param_1 + 400);
  iStack_94 = param_1;
  if (piStack_9c == (int *)0x0) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Script stats collection is not enabled");
  }
  piStack_24 = *(int **)*piStack_9c;
  ExceptionList = &pvStack_10;
  if (piStack_24 != (int *)*piStack_9c) {
    do {
      piVar16 = piStack_24;
      uStack_18 = piStack_24[8];
      puStack_14 = (uint *)(piStack_24 + 4);
      uStack_30 = 0;
      pppppuStack_2c = (undefined4 ******)0x0;
      if (0xf < (uint)piStack_24[9]) {
        puStack_14 = (uint *)*puStack_14;
      }
      if (uStack_18 < 0x10) {
        ppppppuVar14 = (undefined4 ******)*puStack_14;
        uStack_3c = puStack_14[1];
        uStack_38 = puStack_14[2];
        uStack_34 = puStack_14[3];
        pppppuStack_2c = (undefined4 *****)&DAT_0000000f;
        pppppuStack_40 = ppppppuVar14;
      }
      else {
        pppppuStack_28 = (undefined4 *****)(uStack_18 | 0xf);
        if ((undefined4 ******)0x7fffffff < pppppuStack_28) {
          pppppuStack_28 = (undefined4 ******)0x7fffffff;
        }
        ppppppuVar14 = (undefined4 ******)((int)pppppuStack_28 + 1);
        if (ppppppuVar14 < &DAT_00001000) {
          if (ppppppuVar14 == (undefined4 ******)0x0) {
            ppppppuVar14 = (undefined4 ******)0x0;
          }
          else {
            ppppppuVar14 = (undefined4 ******)FUN_01674e20(ppppppuVar14);
          }
        }
        else {
          ppppppuVar5 = (undefined4 ******)pppppuStack_28 + 9;
          if (ppppppuVar5 <= ppppppuVar14) {
            ppppppuVar5 = (undefined4 ******)0xffffffff;
          }
          pppppuVar6 = (undefined4 *****)FUN_01674e20(ppppppuVar5);
          if (pppppuVar6 == (undefined4 *****)0x0) goto LAB_00950fae;
          ppppppuVar14 = (undefined4 ******)((int)pppppuVar6 + 0x23U & 0xffffffe0);
          ppppppuVar14[-1] = pppppuVar6;
        }
        pppppuStack_40 = ppppppuVar14;
        FUN_0170c6f0(ppppppuVar14,puStack_14,uStack_18 + 1);
        pppppuStack_2c = pppppuStack_28;
      }
      uStack_80 = 0;
      uStack_7c = 0xf;
      auStack_90[0] = auStack_90[0] & 0xffffff00;
      uStack_68 = 0xf00000000;
      uStack_78 = uStack_78 & 0xffffff00;
      uStack_60 = 0;
      iStack_5c = 0;
      iStack_58 = 0;
      uStack_8 = 1;
      ppppppuVar5 = &pppppuStack_40;
      if (&DAT_0000000f < pppppuStack_2c) {
        ppppppuVar5 = ppppppuVar14;
      }
      uStack_30 = uStack_18;
      FUN_005542c0(ppppppuVar5,uStack_18);
      iVar7 = iStack_94;
      FUN_005875d0(&puStack_98,&pppppuStack_40);
      puVar9 = puStack_98;
      puStack_14 = *(uint **)(iVar7 + 0x3a4);
      pppppuStack_28 = pppppuStack_40;
      if (puStack_98 == puStack_14) {
LAB_00950a89:
        puVar9 = puStack_14;
      }
      else {
        puVar15 = puStack_98 + 4;
        if (0xf < puStack_98[9]) {
          puVar15 = (uint *)*puVar15;
        }
        ppppppuVar14 = &pppppuStack_40;
        if (&DAT_0000000f < pppppuStack_2c) {
          ppppppuVar14 = (undefined4 ******)pppppuStack_40;
        }
        iVar7 = FUN_0055c2d0(ppppppuVar14,uStack_30,puVar15,puStack_98[8]);
        if (iVar7 < 0) goto LAB_00950a89;
      }
      if (puVar9 == puStack_14) {
        FUN_005542c0("[Unknown]",9);
      }
      else {
        puStack_14 = puVar9 + 10;
        uStack_18 = puVar9[0xe];
        if (0xf < puVar9[0xf]) {
          puStack_14 = (uint *)*puStack_14;
        }
        if (uStack_18 < 0x10) {
          uVar8 = *puStack_14;
          uStack_b0 = 0xf;
          uVar13 = puStack_14[1];
          uVar17 = puStack_14[2];
          uVar18 = puStack_14[3];
        }
        else {
          uStack_1c = uStack_18 | 0xf;
          if (0x7fffffff < uStack_1c) {
            uStack_1c = 0x7fffffff;
          }
          uVar8 = FUN_00554060(uStack_1c + 1);
          FUN_0170c6f0(uVar8,puStack_14,uStack_18 + 1);
          uStack_b0 = uStack_1c;
          uVar13 = uStack_c0;
          uVar17 = uStack_bc;
          uVar18 = uStack_b8;
        }
        uVar3 = uStack_18;
        if (0xf < uStack_68._4_4_) {
          uVar12 = uStack_68._4_4_ + 1;
          uVar11 = uStack_78;
          if (0xfff < uVar12) {
            uVar11 = *(uint *)(uStack_78 - 4);
            uVar12 = uStack_68._4_4_ + 0x24;
            if (0x1f < (uStack_78 - uVar11) - 4) goto LAB_00950fae;
          }
          FUN_01674ea0(uVar11,uVar12);
        }
        uStack_68 = CONCAT44(uStack_b0,uVar3);
        uStack_78 = uVar8;
        uStack_74 = uVar13;
        uStack_70 = uVar17;
        uStack_6c = uVar18;
        if (&uStack_60 != puVar9 + 0x10) {
          uStack_18 = puVar9[0x11];
          puStack_14 = (uint *)puVar9[0x10];
          puVar15 = (uint *)((int)(uStack_18 - (int)puStack_14) >> 3);
          puStack_20 = (uint *)((int)(iStack_58 - uStack_60) >> 3);
          puVar9 = (uint *)((int)(iStack_5c - uStack_60) >> 3);
          if (puStack_20 < puVar15) {
            if ((uint *)0x1fffffff < puVar15) {
                    /* WARNING: Subroutine does not return */
              FUN_00577c30();
            }
            uStack_1c = (uint)puStack_20 >> 1;
            puVar9 = puVar15;
            if ((puStack_20 <= (uint *)(0x1fffffff - uStack_1c)) &&
               (puVar9 = (uint *)(uStack_1c + (int)puStack_20),
               (uint *)(uStack_1c + (int)puStack_20) < puVar15)) {
              puVar9 = puVar15;
            }
            if (uStack_60 != 0) {
              FUN_005596d0(uStack_60,iStack_5c,&uStack_60);
              FUN_0057d330(uStack_60,puStack_20);
            }
            FUN_00575930(puVar9);
            iStack_5c = FUN_0055c480(puStack_14,uStack_18,uStack_60);
          }
          else if (puVar9 < puVar15) {
            puVar9 = puStack_14 + (int)puVar9 * 2;
            FUN_00602d30(puStack_14,puVar9,uStack_60);
            iStack_5c = FUN_0055c480(puVar9,uStack_18,iStack_5c);
          }
          else {
            iVar7 = uStack_60 + (int)puVar15 * 8;
            FUN_00602d30(puStack_14,uStack_18,uStack_60);
            FUN_005596d0(iVar7,iStack_5c,&uStack_60);
            iStack_5c = iVar7;
          }
        }
      }
      iVar7 = piVar16[10];
      FUN_01682800(&uStack_a4);
      if ((NAN(*(double *)(iVar7 + 0x818)) || NAN((double)CONCAT44(uStack_a0,uStack_a4))) ==
          (*(double *)(iVar7 + 0x818) == (double)CONCAT44(uStack_a0,uStack_a4))) {
        *(undefined4 *)(iVar7 + 0x818) = uStack_a4;
        *(undefined4 *)(iVar7 + 0x81c) = uStack_a0;
        puStack_14 = (uint *)FUN_016f3eb1();
        LOCK();
        puVar9 = *(uint **)(iVar7 + 0x800);
        *(uint **)(iVar7 + 0x800) = puStack_14;
        UNLOCK();
        if (puVar9 < puStack_14) {
          iVar2 = *(int *)(iVar7 + 0x804);
          puStack_20 = (uint *)((int)puVar9 + 1);
          for (puVar9 = puStack_20; puVar9 <= puStack_14; puVar9 = (uint *)((int)puVar9 + 1)) {
            iVar10 = (int)*(char *)(((uint)puVar9 & 0x7ff) + iVar7);
            if (0 < iVar10) {
              do {
                LOCK();
                *(int *)(iVar7 + 0x808) = *(int *)(iVar7 + 0x808) + -1;
                UNLOCK();
                iVar10 = iVar10 + -1;
              } while (iVar10 != 0);
            }
            *(char *)(((uint)puVar9 & 0x7ff) + iVar7) = (char)iVar2;
            if (0 < iVar2) {
              iVar10 = iVar2;
              do {
                LOCK();
                *(int *)(iVar7 + 0x808) = *(int *)(iVar7 + 0x808) + 1;
                UNLOCK();
                iVar10 = iVar10 + -1;
              } while (iVar10 != 0);
            }
            piVar16 = piStack_24;
          }
        }
      }
      uVar8 = piVar16[0xc];
      dStack_50 = (double)*(int *)(iVar7 + 0x808) * _DAT_01934dd8 * DAT_018ce318;
      uStack_1c = uVar8;
      FUN_01682800(&uStack_ac);
      if ((NAN(*(double *)(uVar8 + 0x810)) || NAN((double)CONCAT44(uStack_a8,uStack_ac))) ==
          (*(double *)(uVar8 + 0x810) == (double)CONCAT44(uStack_a8,uStack_ac))) {
        *(undefined4 *)(uVar8 + 0x810) = uStack_ac;
        *(undefined4 *)(uVar8 + 0x814) = uStack_a8;
        puStack_20 = (uint *)FUN_016f3eb1();
        LOCK();
        puVar9 = *(uint **)(uVar8 + 0x800);
        *(uint **)(uVar8 + 0x800) = puStack_20;
        UNLOCK();
        if (((DAT_01d6fa38 == '\0') || (puVar9 != puStack_20)) && (puVar9 < puStack_20)) {
          while (puVar9 = (uint *)((int)puVar9 + 1), puVar9 <= puStack_20) {
            iVar7 = (int)*(char *)(uStack_1c + ((uint)puVar9 & 0x7ff));
            if (0 < iVar7) {
              do {
                LOCK();
                *(int *)(uStack_1c + 0x804) = *(int *)(uStack_1c + 0x804) + -1;
                UNLOCK();
                iVar7 = iVar7 + -1;
              } while (iVar7 != 0);
            }
            *(undefined *)(uStack_1c + ((uint)puVar9 & 0x7ff)) = 0;
            uVar8 = uStack_1c;
            piVar16 = piStack_24;
          }
        }
      }
      uStack_48 = *(int *)(uVar8 + 0x804) / 2;
      puVar9 = *(uint **)(param_2 + 4);
      if (*(uint **)(param_2 + 8) == puVar9) {
        FUN_0093f7a0(puVar9,auStack_90);
      }
      else {
        puStack_20 = puVar9;
        FUN_0054ef60(auStack_90);
        uStack_8._0_1_ = 2;
        FUN_0054ef60(&uStack_78);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_00569460(&uStack_60);
        puVar9[0x12] = uStack_48;
        *(double *)(puVar9 + 0x10) = dStack_50;
        *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 0x50;
      }
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_00577ac0();
      if (0xf < uStack_68._4_4_) {
        uVar13 = uStack_68._4_4_ + 1;
        uVar8 = uStack_78;
        if (0xfff < uVar13) {
          uVar8 = *(uint *)(uStack_78 - 4);
          uVar13 = uStack_68._4_4_ + 0x24;
          if (0x1f < (uStack_78 - uVar8) - 4) goto LAB_00950fae;
        }
        FUN_01674ea0(uVar8,uVar13);
      }
      if (0xf < uStack_7c) {
        uVar13 = uStack_7c + 1;
        uVar8 = auStack_90[0];
        if (0xfff < uVar13) {
          uVar8 = *(uint *)(auStack_90[0] - 4);
          uVar13 = uStack_7c + 0x24;
          if (0x1f < (auStack_90[0] - uVar8) - 4) goto LAB_00950fae;
        }
        FUN_01674ea0(uVar8,uVar13);
      }
      uStack_8 = 0xffffffff;
      if (&DAT_0000000f < pppppuStack_2c) {
        ppppppuVar14 = (undefined4 ******)((int)pppppuStack_2c + 1);
        ppppppuVar5 = (undefined4 ******)pppppuStack_28;
        if ((undefined4 ******)0xfff < ppppppuVar14) {
          ppppppuVar5 = (undefined4 ******)pppppuStack_28[-1];
          ppppppuVar14 = (undefined4 ******)(pppppuStack_2c + 9);
          if ((undefined *)0x1f < (undefined *)((int)pppppuStack_28 + (-4 - (int)ppppppuVar5))) {
LAB_00950fae:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppppuVar5,ppppppuVar14);
      }
      piStack_24 = (int *)piVar16[2];
      if (*(char *)((int)piStack_24 + 0xd) == '\0') {
        cVar1 = *(char *)(*piStack_24 + 0xd);
        piVar16 = (int *)*piStack_24;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar16 + 0xd);
          piStack_24 = piVar16;
          piVar16 = (int *)*piVar16;
        }
      }
      else {
        cVar1 = *(char *)(piVar16[1] + 0xd);
        piVar4 = (int *)piVar16[1];
        while ((piStack_24 = piVar4, cVar1 == '\0' && (piVar16 == (int *)piStack_24[2]))) {
          cVar1 = *(char *)(piStack_24[1] + 0xd);
          piVar4 = (int *)piStack_24[1];
          piVar16 = piStack_24;
        }
      }
    } while (piStack_24 != (int *)*piStack_9c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17210 ; VA 0x00950fc0 ; FUN_00950fc0 */

int __fastcall FUN_00950fc0(int param_1)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = param_1 + 0x78;
  iVar3 = 0;
  if (iVar2 != param_1 + 0xf8) {
    puVar1 = (uint *)(param_1 + 0xb4);
    do {
      if ((uint *)*puVar1 != puVar1) {
        iVar3 = iVar3 + **(int **)(*(int *)((*puVar1 ^ (uint)puVar1) + 0x6c) + 0xc);
      }
      iVar2 = iVar2 + 0x40;
      puVar1 = puVar1 + 0x10;
    } while (iVar2 != param_1 + 0xf8);
  }
  return iVar3;
}



/* FUNCTION 17211 ; VA 0x00951000 ; FUN_00951000 */

int __thiscall FUN_00951000(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1db68e4);
  if (iVar1 == 0) {
    return param_1 + 0x10;
  }
  return 0;
}



/* FUNCTION 17212 ; VA 0x00951030 ; FUN_00951030 */

int FUN_00951030(int param_1,int param_2)

{
  return param_1 - param_2;
}



/* FUNCTION 17213 ; VA 0x00951040 ; FUN_00951040 */

int FUN_00951040(uint param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  int iVar6;
  int iStack_8;
  
  uVar2 = 0;
  iVar3 = 0;
  uVar1 = 0;
  uVar5 = 0;
  iStack_8 = 0;
  if (param_1 < param_1 + param_2) {
    iVar6 = (((param_1 + param_2) - param_1) - 1 >> 4) + 1;
    pcVar4 = (char *)(param_1 + 2);
    do {
      uVar2 = pcVar4[-2] + param_3 ^ ~uVar2;
      uVar2 = (uVar2 << 0xf | uVar2 >> 0x11) + uVar5;
      iVar3 = ~(-iStack_8 ^ pcVar4[-1] - param_3) - uVar1;
      uVar1 = ((int)*pcVar4 + ~uVar1) - param_3;
      uVar1 = iVar3 - (uVar1 * 0x400 | uVar1 >> 0x16);
      uVar5 = (uVar5 << 0xf | uVar5 >> 0x11) + (param_3 - pcVar4[1]);
      uVar5 = (uVar5 >> 0x18 | (uVar5 & 0xff0000) >> 8 | (uVar5 & 0xff00) << 8 | uVar5 * 0x1000000)
              + uVar2;
      iVar6 = iVar6 + -1;
      pcVar4 = pcVar4 + 0x10;
      iStack_8 = iVar3;
    } while (iVar6 != 0);
  }
  return ((uVar1 - uVar5) - iVar3) + uVar2 + param_4;
}



/* FUNCTION 17214 ; VA 0x009510e0 ; FUN_009510e0 */

undefined4 FUN_009510e0(undefined4 param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cba53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_011605b0(DAT_018e2380);
  FUN_00565940(3,1);
  uStack_8 = 0;
  GetCurrentThreadId();
  FUN_0056ef60();
  FUN_0058c420(apppuStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_012569c0(param_1,ppppuVar1);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_28[0][-1];
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17215 ; VA 0x009511c0 ; FUN_009511c0 */

void FUN_009511c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cba70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_012565c0(param_2);
  FUN_00d887b0(uVar2);
  uStack_8 = 0;
  FUN_00d88cd0(auStack_2c);
  FUN_00d88aa0();
  piVar1 = *(int **)(param_1 + 0x14);
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piVar1 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (piVar1 == (int *)0x0) {
    iVar3 = 0;
  }
  else {
    iVar3 = piVar1[2];
  }
  FUN_0095c750(iVar3,param_3,param_4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piVar1,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17216 ; VA 0x00951290 ; FUN_00951290 */

void __thiscall FUN_00951290(int *param_1,int *param_2)

{
  int iVar1;
  
  if ((int *)param_2[1] != param_1) {
    if ((int *)param_2[1] != (int *)0x0) {
      if ((int *)param_2[2] != (int *)0x0) {
        *(int *)param_2[2] = *param_2;
      }
      if (*param_2 != 0) {
        *(int *)(*param_2 + 8) = param_2[2];
      }
      *(int *)param_2[1] = *(int *)param_2[1] + -1;
      *param_2 = 0;
      param_2[2] = 0;
      param_2[1] = 0;
    }
    iVar1 = param_1[1];
    if (iVar1 != 0) {
      *param_2 = iVar1;
      *(int **)(iVar1 + 8) = param_2;
    }
    param_1[1] = (int)param_2;
    param_2[2] = (int)(param_1 + 1);
    param_2[1] = (int)param_1;
    *param_1 = *param_1 + 1;
  }
  return;
}



/* FUNCTION 17217 ; VA 0x009512f0 ; FUN_009512f0 */

uint * __thiscall FUN_009512f0(int *param_1,uint *param_2)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = (param_1[1] - *param_1 >> 4) - 1;
  uVar1 = *param_2;
  uVar4 = 0;
  uVar3 = uVar1;
  while( true ) {
    uVar3 = uVar3 & uVar5;
    puVar2 = (uint *)(uVar3 * 0x10 + *param_1);
    if (*puVar2 == param_1[4]) {
      *puVar2 = uVar1;
      param_1[3] = param_1[3] + 1;
      return puVar2;
    }
    if (*puVar2 == uVar1) break;
    uVar3 = uVar3 + 1 + uVar4;
    uVar4 = uVar4 + 1;
    if (uVar5 < uVar4) {
      return (uint *)0x0;
    }
  }
  return puVar2;
}



/* FUNCTION 17218 ; VA 0x00951360 ; FUN_00951360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00951360(int param_1)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined auStack_14 [8];
  double dStack_c;
  
  if (param_1 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x6c);
  }
  iVar2 = *(int *)(*(int *)(iVar2 + 0xc) + 4);
  FUN_0151da60(auStack_14);
  FUN_016830f0(&dStack_c);
  piVar3 = (int *)FUN_01255560();
  if ((*piVar3 != 2) && (*piVar3 != 3)) {
    return 0;
  }
  if ((*(char *)(iVar2 + 0x1b8) == '\0') || (dStack_c < *(double *)(iVar2 + 0x1c0))) {
    if (*(double *)(iVar2 + 0x1a8) <= _PTR_018c6f48) {
      return 0;
    }
    if (dStack_c - *(double *)(iVar2 + 0x390) <= *(double *)(iVar2 + 0x1a8)) {
      return 0;
    }
  }
  else {
    FUN_00959660(param_1);
    FUN_01255e10(param_1,0x14);
    FUN_01257dd0(param_1,"Script timeout: shutdown deadline reached");
  }
  FUN_00959660(param_1);
  FUN_01255e10(param_1,0x14);
  FUN_01257dd0(param_1,"Script timeout: exhausted allowed execution time");
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 17219 ; VA 0x00951420 ; FUN_00951420 */

void FUN_00951420(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  
  piVar1 = *(int **)(param_1 + 8);
  for (piVar4 = *(int **)(param_1 + 4); piVar4 != piVar1; piVar4 = piVar4 + 3) {
    if (*piVar4 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = *(undefined4 *)(*piVar4 + 8);
    }
    uVar3 = FUN_009d5c60(piVar4[1],uVar3);
    piVar2 = (int *)*piVar4;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_0095aba0(piVar2,uVar3,0);
  }
  return;
}



/* FUNCTION 17220 ; VA 0x00951480 ; FUN_00951480 */

void FUN_00951480(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  
  puVar2 = (undefined4 *)*param_1;
  uVar3 = puVar2[0x13];
  pcVar4 = (code *)*puVar2;
  uVar5 = puVar2[0x12];
  uVar6 = puVar2[0x10];
  uVar7 = puVar2[0xe];
  uVar8 = puVar2[6];
  if (puVar2[5] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar9 = puVar2[4];
  uVar10 = puVar2[5];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar4)(puVar2[2],puVar2[3],uVar9,uVar10,uVar8,puVar2 + 8,uVar7,uVar6,uVar5,uVar3);
  return;
}



/* FUNCTION 17221 ; VA 0x00951500 ; FUN_00951500 */

void FUN_00951500(int *param_1)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined8 uStack_14;
  
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uVar3 = puVar1[4];
  if (uVar3 != 0) {
    if ((uVar3 & 1) != 0) {
      uStack_24 = puVar1[6];
      uStack_20 = puVar1[7];
      uStack_1c = puVar1[8];
      uStack_18 = puVar1[9];
      uStack_14 = *(undefined8 *)(puVar1 + 10);
      (*pcVar2)(puVar1 + 2);
      return;
    }
    (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 6,&uStack_24,0);
  }
  (*pcVar2)(puVar1 + 2);
  return;
}



/* FUNCTION 17222 ; VA 0x00951570 ; FUN_00951570 */

void FUN_00951570(int *param_1)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uStack_3c = 0;
  uVar3 = puVar1[0xc];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_3c = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = puVar1 + 0xe;
      uStack_4c = 0x9515d9;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_34 = puVar1[0xe];
      uStack_30 = puVar1[0xf];
      uStack_2c = puVar1[0x10];
      uStack_28 = puVar1[0x11];
      uStack_24 = *(undefined8 *)(puVar1 + 0x12);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = puVar1[4];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 6,&uStack_54,0);
    }
    else {
      uStack_54 = puVar1[6];
      uStack_50 = puVar1[7];
      uStack_4c = puVar1[8];
      puStack_48 = (undefined4 *)puVar1[9];
      uStack_44 = *(ulonglong *)(puVar1 + 10);
    }
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(puVar1 + 2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17223 ; VA 0x00951650 ; FUN_00951650 */

void FUN_00951650(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uVar3 = puVar1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) != 0) {
      uStack_20 = puVar1[4];
      uStack_1c = puVar1[5];
      uStack_18 = puVar1[6];
      uStack_14 = puVar1[7];
      uStack_10 = *(undefined8 *)(puVar1 + 8);
      (*pcVar2)(param_2);
      return;
    }
    (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 4,&uStack_20,0);
  }
  (*pcVar2)(param_2);
  return;
}



/* FUNCTION 17224 ; VA 0x009516c0 ; FUN_009516c0 */

void FUN_009516c0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = (code *)*param_1;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2],param_2);
  return;
}



/* FUNCTION 17225 ; VA 0x00951700 ; FUN_00951700 */

void FUN_00951700(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  code *pcVar3;
  
  uVar2 = param_1[3];
  pcVar3 = (code *)*param_1;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(param_1[1],param_1[2],param_2,uVar2);
  return;
}



/* FUNCTION 17226 ; VA 0x00951740 ; FUN_00951740 */

void FUN_00951740(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  (*(code *)*param_1)(param_1[1],param_2,param_3);
  return;
}



/* FUNCTION 17227 ; VA 0x00951760 ; FUN_00951760 */

int FUN_00951760(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puVar3 = (undefined4 *)*param_1;
  uVar4 = puVar3[0xf];
  pcVar5 = (code *)*puVar3;
  uVar6 = puVar3[0xe];
  uVar7 = puVar3[0xc];
  uVar8 = puVar3[10];
  uVar9 = puVar3[2];
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar10 = (*pcVar5)(param_2,param_3,param_4,uVar9,puVar3 + 4,uVar8,uVar7,uVar6,uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar10 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar10 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar10 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar10 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar10 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar10 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 17228 ; VA 0x00951830 ; FUN_00951830 */

uint FUN_00951830(void)

{
  int iVar1;
  
  iVar1 = FUN_0093f0f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 17229 ; VA 0x00951850 ; FUN_00951850 */

uint FUN_00951850(void)

{
  int iVar1;
  
  iVar1 = FUN_0093f0f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 17230 ; VA 0x00951870 ; FUN_00951870 */

void FUN_00951870(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_34 [20];
  int *piStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cba98;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0094c800(auStack_34,param_1,param_2,param_3,&uStack_18);
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piStack_20 != (int *)0x0) {
    LOCK();
    *piStack_20 = *piStack_20 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_20 == (int *)0x0) {
    iVar1 = 0;
  }
  else {
    iVar1 = piStack_20[2];
  }
  uVar2 = FUN_009d5c60(param_4,iVar1);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    *piStack_20 = *piStack_20 + 1;
    UNLOCK();
  }
  FUN_0095aba0(piStack_20,uVar2,0);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = *piStack_20;
    *piStack_20 = *piStack_20 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0(piStack_20,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  FUN_00d88aa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17231 ; VA 0x00951950 ; FUN_00951950 */

int FUN_00951950(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  undefined **ppuVar7;
  undefined4 *puVar8;
  undefined **ppuVar9;
  uint uVar10;
  undefined4 ****ppppuVar11;
  int iVar12;
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined2 auStack_8c [8];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 ***apppuStack_5c [4];
  int iStack_4c;
  uint uStack_48;
  undefined auStack_44 [4];
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 ***apppuStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbb40;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00554b40();
  if (cVar4 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("This method is not available");
  }
  if (param_1 != 0) {
    uStack_64 = 0;
    uStack_60 = 7;
    uStack_74 = (uint)uStack_74._2_2_ << 0x10;
    uStack_8._0_1_ = 1;
    iStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    FUN_005542c0("modules",7);
    uStack_8._0_1_ = 2;
    if (iStack_18 != 0) {
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      iVar12 = (int)ppppuVar6 + iStack_18;
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      uVar5 = FUN_01686580();
      FUN_01685950(ppppuVar6,iVar12,&uStack_74,uVar5);
    }
    uStack_8._0_1_ = 1;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar10) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0][-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar6))) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar10);
    }
    uStack_7c = 0;
    uStack_78 = 7;
    auStack_8c[0] = 0;
    uStack_8._0_1_ = 4;
    iStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    FUN_005542c0("internalscripts",0xf);
    uStack_8._0_1_ = 5;
    if (iStack_18 != 0) {
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      iVar12 = (int)ppppuVar6 + iStack_18;
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      uVar5 = FUN_01686580();
      FUN_01685950(ppppuVar6,iVar12,auStack_8c,uVar5);
    }
    uStack_8._0_1_ = 4;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar10) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0][-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar6))) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar10);
    }
    iStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    uStack_8._0_1_ = 6;
    uVar5 = FUN_01518d10(auStack_a4,0,3,0);
    uStack_8._0_1_ = 7;
    uVar5 = FUN_005514a0(auStack_bc,uVar5,auStack_8c);
    uStack_8._0_1_ = 8;
    FUN_005514a0(apppuStack_5c,uVar5,&uStack_74);
    FUN_00550800();
    FUN_00550800();
    FUN_00550800();
    FUN_00550800();
    if (DAT_01d64410 != '\0') {
      uStack_8._0_1_ = 0xe;
      iStack_18 = 0;
      uStack_14 = 0xf;
      apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
      uStack_2c = 1;
      if (iStack_4c != 0) {
        ppppuVar6 = apppuStack_5c;
        if (7 < uStack_48) {
          ppppuVar6 = (undefined4 ****)apppuStack_5c[0];
        }
        ppppuVar11 = apppuStack_5c;
        if (7 < uStack_48) {
          ppppuVar11 = (undefined4 ****)apppuStack_5c[0];
        }
        uVar5 = FUN_01686580();
        FUN_01685a20(ppppuVar11,(int)ppppuVar6 + iStack_4c * 2,apppuStack_28,uVar5);
      }
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_01677520(DAT_01d64410,"Loading internal modules in folder %s",ppppuVar6);
      uStack_8._0_1_ = 0xd;
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
        if (0xfff < uVar10) {
          ppppuVar6 = (undefined4 ****)apppuStack_28[0][-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar6,uVar10);
      }
    }
    auStack_44[0] = 0;
    uStack_2c = 0xb;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_2c);
    ppuVar9 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar9 = ppuVar7;
    }
    puStack_40 = *ppuVar9;
    uStack_3c = 0;
    uStack_38 = 0x3f800000;
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_8._0_1_ = 0x10;
    uVar5 = FUN_005569d0(auStack_a4);
    uStack_8._0_1_ = 0x11;
    FUN_0063acc0(uVar5,apppuStack_5c,auStack_44);
    uStack_8._0_1_ = 0x10;
    FUN_005507b0();
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    FUN_0063b3f0(auStack_44,param_1,param_2);
    if (DAT_01d64410 != '\0') {
      puVar8 = (undefined4 *)FUN_008a2380(&uStack_74);
      uStack_8._0_1_ = 0x12;
      if (0xf < (uint)puVar8[5]) {
        puVar8 = (undefined4 *)*puVar8;
      }
      FUN_01677520(DAT_01d64410,"Internal RCC Modules loaded into %s",puVar8);
      if (0xf < uStack_60) {
        uVar10 = uStack_60 + 1;
        iVar12 = uStack_74;
        if (0xfff < uVar10) {
          iVar12 = *(int *)(uStack_74 + -4);
          uVar10 = uStack_60 + 0x24;
          if (0x1f < (uStack_74 - iVar12) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar12,uVar10);
      }
    }
    FUN_00637710();
    iVar12 = FUN_00550800();
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar1 = param_2 + 1;
      iVar2 = *piVar1;
      iVar12 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar12 = (**(code **)*param_2)();
        LOCK();
        piVar1 = param_2 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar12 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar12;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid parent to set as parent of loaded modules");
}



/* FUNCTION 17232 ; VA 0x00951db0 ; FUN_00951db0 */

undefined4 FUN_00951db0(undefined4 param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbb60;
  pvStack_10 = ExceptionList;
  if (DAT_01d644d8 == '\0') {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("debug.loadmodule is not enabled.");
  }
  uStack_1c = 0;
  uStack_18 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00da4680(param_1,0xffffffff,&uStack_1c);
  if (cVar1 != '\0') {
    FUN_009431c0(&iStack_24,&uStack_1c);
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    if (iStack_24 != 0) {
      if (iStack_20 != 0) {
        LOCK();
        *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 1;
        UNLOCK();
      }
      uVar2 = FUN_00951e90(param_1,iStack_24,iStack_20);
      FUN_00550b30();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return uVar2;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00550b30();
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Attempted to call loadmodule with invalid argument(s).");
}



/* FUNCTION 17233 ; VA 0x00951e90 ; FUN_00951e90 */

undefined4 FUN_00951e90(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined auStack_98 [56];
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 ***apppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbbb9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_008a2380(auStack_60);
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_0191bf9c,1);
  uStack_8._0_1_ = 2;
  FUN_00558ba0(apppuStack_48,auStack_28,uVar4);
  uStack_8._0_1_ = 4;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8._0_1_ = 5;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_4c) {
    uVar7 = uStack_4c + 1;
    uVar8 = auStack_60[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_60[0] - 4);
      uVar7 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  ppppuVar6 = apppuStack_48;
  if (0xf < uStack_34) {
    ppppuVar6 = (undefined4 ****)apppuStack_48[0];
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  uVar4 = FUN_009ed300(auStack_30);
  uStack_8._0_1_ = 6;
  iVar5 = FUN_009edf40(param_1,uVar4,ppppuVar6);
  uStack_8._0_1_ = 5;
  FUN_0056e380();
  FUN_0056e380();
  if (iVar5 == 0) {
    FUN_0094c7a0(param_1);
    FUN_012571e0(param_1,0xffffffff,1);
    FUN_012569c0(param_1,"script");
    FUN_01256aa0(param_1,0xfffffffc);
    FUN_01257230(param_1,0xfffffffd);
    FUN_01256f80(param_1,0xfffffffe);
    if (DAT_01d644b8 != '\0') {
      if (param_1 == 0) {
        iVar5 = 0;
      }
      else {
        iVar5 = *(int *)(param_1 + 0x6c);
      }
      iVar5 = *(int *)(*(int *)(iVar5 + 0xc) + 4);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      uStack_a0 = param_2;
      piStack_9c = param_3;
      uStack_8._0_1_ = 7;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar2 = param_3[1] + -1;
        param_3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*param_3)();
          LOCK();
          iVar2 = param_3[2] + -1;
          param_3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
      FUN_008a2380(auStack_98);
      uStack_8._0_1_ = 8;
      FUN_00d886a0(param_1,0xffffffff);
      uStack_8._0_1_ = 9;
      if (*(int *)(iVar5 + 0x3a0) == *(int *)(iVar5 + 0x39c)) {
        FUN_0093fbb0(*(int *)(iVar5 + 0x39c),&uStack_a0);
      }
      else {
        FUN_00942ca0(iVar5 + 0x398);
        *(int *)(iVar5 + 0x39c) = *(int *)(iVar5 + 0x39c) + 0x40;
      }
      FUN_00947650();
    }
    uVar4 = 1;
  }
  else {
    FUN_01256980();
    FUN_01256380(param_1,0xfffffffe);
    uVar4 = 2;
  }
  if (0xf < uStack_34) {
    uVar8 = uStack_34 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_48[0];
    if (0xfff < uVar8) {
      ppppuVar6 = (undefined4 ****)apppuStack_48[0][-1];
      uVar8 = uStack_34 + 0x24;
      if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar8);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 17234 ; VA 0x009521a0 ; FUN_009521a0 */

undefined4 FUN_009521a0(int param_1)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  code *apcStack_30 [2];
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbbe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d644c8 != '\0') {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01255560();
    cVar2 = FUN_01255580(uVar3,5);
    if (cVar2 != '\0') {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("loadstring() is not available in RobloxScript context.");
    }
  }
  if (param_1 == 0) {
    iVar7 = 0;
  }
  else {
    iVar7 = *(int *)(param_1 + 0x6c);
  }
  iStack_18 = FUN_008f7870(*(undefined4 *)(*(int *)(iVar7 + 0xc) + 4));
  if (iStack_18 != 0) {
    iVar7 = iStack_18 + 0xc;
    cVar2 = FUN_0098c5a0(iVar7,1);
    if (cVar2 == '\0') {
      cVar2 = FUN_00973950(iVar7,1);
      if (((cVar2 == '\0') || (cVar2 = FUN_00983210(iVar7), cVar2 != '\0')) &&
         (cVar2 = FUN_00554b40(), cVar2 != '\0')) goto LAB_0095230b;
    }
    else if (iVar7 != 0) {
      FUN_005789c0(&DAT_01eaddc4,&LAB_00670cf0);
      uVar3 = FUN_00676030();
      piVar4 = (int *)FUN_008aa140(uVar3);
      piStack_14 = piVar4;
      if (*piVar4 == 0) {
        uVar3 = FUN_00b624e0();
        piVar5 = (int *)FUN_008a9ba0(&iStack_28,uVar3);
        iVar7 = *piVar5;
        iVar1 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar7;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar1;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar7 = piVar5[1] + -1;
          piVar5[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar7 = piVar5[2] + -1;
            piVar5[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_24[1] + -1;
          piStack_24[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar4 = piStack_24 + 2;
            iVar7 = *piVar4;
            *piVar4 = *piVar4 + -1;
            UNLOCK();
            if (iVar7 == 1) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      if ((*piStack_14 != 0) && (*(char *)(*piStack_14 + 0x5c) != '\0')) {
        apcStack_30[0] = FUN_0095c400;
        piStack_24 = *(int **)(iStack_18 + 0x43c);
        iStack_28 = *piStack_24 - (int)piStack_24;
        piStack_24 = (int *)(piStack_24[1] - (int)piStack_24);
        FUN_00942b20(&DAT_01ee2b0c,apcStack_30);
        goto LAB_0095230b;
      }
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("loadstring() is not available");
  }
LAB_0095230b:
  uVar3 = FUN_01257ce0(param_1,1,&uStack_20);
  uVar6 = FUN_01257ff0(param_1,2,uVar3,0);
  FUN_012571e0(param_1,0xffffd8ef,0);
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0(uVar3,uStack_20);
  uStack_8 = 0;
  uVar3 = FUN_00886c00(auStack_1c,auStack_48);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar7 = FUN_009edf40(param_1,uVar3,uVar6);
  FUN_0056e380();
  FUN_0056e380();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_34) {
    uVar9 = uStack_34 + 1;
    uVar8 = auStack_48[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_48[0] - 4);
      uVar9 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (iVar7 != 0) {
    FUN_01256980(param_1);
    FUN_01256380(param_1,0xfffffffe);
    ExceptionList = pvStack_10;
    return 2;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17235 ; VA 0x00952460 ; FUN_00952460 */

undefined4 FUN_00952460(int param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbbf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ee2a6c);
  uStack_8 = 0;
  if ((((DAT_01d644a0 != '\0') && (param_1 != 0)) && (*(int *)(param_1 + 0x6c) != 0)) &&
     ((iVar3 = FUN_008f7870(*(undefined4 *)(*(int *)(*(int *)(param_1 + 0x6c) + 0xc) + 4)),
      iVar3 != 0 && (cVar1 = FUN_008f2030(), cVar1 == '\0')))) {
    FUN_01675310("UnsynchronizedLuaHeap",&DAT_018bc9b8);
  }
  if (param_5 == 0) {
    FUN_01674ea0(param_3);
    uVar4 = 0;
  }
  else if (param_4 == 0) {
    uVar4 = FUN_01674f30();
  }
  else {
    uVar4 = FUN_01675190(param_3,param_5);
  }
  uStack_8 = 3;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 17236 ; VA 0x00952540 ; FUN_00952540 */

undefined4 FUN_00952540(undefined4 param_1)

{
  FUN_01258200(param_1,"debug",&PTR_s_traceback_019bf470);
  return 1;
}



/* FUNCTION 17237 ; VA 0x00952560 ; FUN_00952560 */

undefined4 FUN_00952560(undefined4 param_1)

{
  FUN_01260a70(param_1);
  FUN_01258200(param_1,0,&PTR_s_noise_019bf448);
  return 1;
}



/* FUNCTION 17238 ; VA 0x00952590 ; FUN_00952590 */

undefined4 FUN_00952590(undefined4 param_1)

{
  FUN_012600d0(param_1);
  FUN_01258200(param_1,0,&PTR_s_graphemes_019bf498);
  return 1;
}



/* FUNCTION 17239 ; VA 0x009525c0 ; FUN_009525c0 */

void FUN_009525c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      FUN_00945610(param_1 + 1);
      param_2[4] = param_1[4];
      if (param_3 == 1) {
        FUN_0094a0d0();
        return;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_0094a0d0();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1db6940);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_3b96e9a6eb8c66847319cfabd9e0b6e4>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17240 ; VA 0x00952660 ; FUN_00952660 */

void FUN_00952660(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1db6e14);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<struct_RBX::Reflection::Tuple>&,struct_lua_State*,unsigned_int),class_boost::_bi::list3<class_boost::reference_wrapper<class_std::shared_ptr<struct_RBX::Reflection::Tuple>_>,struct_boost::arg<1>,struct_boost::arg<2>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17241 ; VA 0x009526d0 ; FUN_009526d0 */

void FUN_009526d0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00944900(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00946a50();
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db72a4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::Lua::ThreadRef&,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list2<class_boost::_bi::value<class_RBX::Lua::ThreadRef>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17242 ; VA 0x00952820 ; FUN_00952820 */

void FUN_00952820(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00944b60(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x30);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x38,iVar4 + 0x38,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x30) = 0;
        }
        FUN_00946a50();
        FUN_01674ea0(iVar4,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1db73e4);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::Lua::ThreadRef&,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list3<class_boost::_bi::value<class_RBX::Lua::ThreadRef>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17243 ; VA 0x009529b0 ; FUN_009529b0 */

void FUN_009529b0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db75b4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(struct_lua_State*,class_boost::function<void___cdecl(char_const*,char_const*,class_std::shared_ptr<class_RBX::LuaSourceContainer>,int)>),class_boost::_bi::list2<struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(char_const*,char_const*,class_std::shared_ptr<class_RBX::LuaSourceContainer>,int)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17244 ; VA 0x00952b20 ; FUN_00952b20 */

void FUN_00952b20(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db76bc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(struct_lua_State*,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>),class_boost::_bi::list2<struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17245 ; VA 0x00952c90 ; FUN_00952c90 */

void FUN_00952c90(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db6ef4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,struct_lua_State*),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17246 ; VA 0x00952e00 ; FUN_00952e00 */

void FUN_00952e00(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db7014);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,struct_lua_State*),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17247 ; VA 0x00952f70 ; FUN_00952f70 */

void FUN_00952f70(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00944dc0(puVar1 + 2);
        *param_2 = (int)puVar2;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        FUN_0056b650();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db6b74);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::shared_ptr<class_RBX::ModuleScript>,class_RBX::ScriptContext&,class_RBX::Security::Identity_const&,struct_lua_State*,struct_RBX::ScriptContext::AssetModuleInfo*,__int64),class_boost::_bi::list7<class_boost::_bi::value<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::ModuleScript>_>,class_boost::reference_wrapper<class_RBX::ScriptContext>,class_boost::_bi::value<class_RBX::Security::Identity>,class_boost::_bi::value<struct_lua_State*>,class_boost::_bi::value<struct_RBX::ScriptContext::AssetModuleInfo*>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17248 ; VA 0x00953050 ; FUN_00953050 */

int * FUN_00953050(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00953132. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009530a6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1db7114);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::ModuleScript>,struct_lua_State*),class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ModuleScript>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17249 ; VA 0x00953150 ; FUN_00953150 */

int * FUN_00953150(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00953238. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009531a6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1db71d4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::ModuleScript>,struct_lua_State*,int),class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ModuleScript>_>,struct_boost::arg<1>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}


