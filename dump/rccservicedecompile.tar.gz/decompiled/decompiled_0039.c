/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 9750 ; VA 0x006fb1d0 ; FUN_006fb1d0 */

void __thiscall FUN_006fb1d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aab70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedPingItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9751 ; VA 0x006fb23e ; Catch_All@006fb23e */

void Catch_All_006fb23e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9752 ; VA 0x006fb260 ; FUN_006fb260 */

int __thiscall FUN_006fb260(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aab80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::StatsService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9753 ; VA 0x006fb332 ; Catch_All@006fb332 */

void Catch_All_006fb332(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9754 ; VA 0x006fb350 ; FUN_006fb350 */

undefined4 * FUN_006fb350(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aabc3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb580();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x108);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009fe510();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fb260(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9755 ; VA 0x006fb410 ; FUN_006fb410 */

int FUN_006fb410(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aabd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
  uVar2 = FUN_005cf480();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009fb760();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006fb350(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
      uVar2 = FUN_005cf480();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9756 ; VA 0x006fb5a0 ; FUN_006fb5a0 */

undefined4 * __thiscall
FUN_006fb5a0(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  uint uVar9;
  float10 fVar10;
  float fVar11;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aac2a;
  pvStack_10 = ExceptionList;
  uVar9 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  param_1[0xd] = param_4;
  *param_1 = RBX::Network::Replicator::PingItem::vftable;
  param_1[0x11] = param_5;
  iVar4 = *(int *)(param_2 + 0xc);
  uStack_8 = 0;
  iVar3 = FUN_005edd10();
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar6 = param_2;
  }
  if (iVar6 == 0) {
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_008f7870(param_2);
  iVar4 = FUN_006fb410();
  if (iVar4 == 0) {
LAB_006fb690:
    iVar4 = 0;
  }
  else {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("FrameRateManager",0x10);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar9 = 1;
    uStack_14 = 1;
    iVar4 = FUN_008a1240(auStack_30);
    if ((iVar4 == 0) ||
       (iVar6 = *(int *)(iVar4 + 0xc), iVar3 = FUN_009fb200(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) goto LAB_006fb690;
  }
  uStack_8 = 0;
  if (uVar9 != 0) {
    uVar9 = 0;
    FUN_005507b0();
  }
  if (iVar4 == 0) {
LAB_006fb70c:
    piVar5 = (int *)0x0;
  }
  else {
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = 0;
    FUN_005542c0("AverageFPS",10);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar9 = uVar9 | 2;
    uStack_14 = uVar9;
    piVar5 = (int *)FUN_008a1240(auStack_48);
    if ((piVar5 == (int *)0x0) ||
       (iVar4 = piVar5[3], iVar6 = FUN_009fb200(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) goto LAB_006fb70c;
  }
  uStack_8 = 0;
  if ((uVar9 & 2) != 0) {
    FUN_005507b0();
  }
  if (piVar5 == (int *)0x0) {
    fVar11 = 0.0;
  }
  else {
    (**(code **)(*piVar5 + 0xa4))();
    fVar11 = (float)*(double *)(piVar5 + 0x16);
  }
  puVar2 = puStack_18;
  puStack_18[0xe] = fVar11;
  iVar4 = *(int *)(param_2 + 0x34);
  if ((iVar4 != 0) && (param_2 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
    param_2 = FUN_005c8ac0();
  }
  if ((param_2 == 0) ||
     (iVar4 = *(int *)(param_2 + 0xc), iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    iVar4 = 0;
  }
  else {
    FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
    uVar7 = FUN_00560d40();
    piVar5 = (int *)FUN_008aa140(uVar7);
    if (*piVar5 == 0) {
      uVar7 = FUN_00995770();
      piVar8 = (int *)FUN_008a9ba0(&param_3,uVar7);
      iVar4 = *piVar8;
      iVar6 = piVar8[1];
      *piVar8 = 0;
      piVar8[1] = 0;
      *piVar5 = iVar4;
      piVar8 = (int *)piVar5[1];
      piVar5[1] = iVar6;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar4 = piVar8[1] + -1;
        piVar8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar4 = piVar8[2] + -1;
          piVar8[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar8 = param_4;
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar4 = param_4[1] + -1;
        param_4[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_4)();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    iVar4 = *piVar5;
    if (iVar4 != 0) {
      fVar10 = (float10)FUN_00999e90();
      fVar11 = (float)fVar10;
      goto LAB_006fb84c;
    }
  }
  fVar11 = 0.0;
LAB_006fb84c:
  puVar2[0xf] = fVar11;
  fVar11 = 0.0;
  if (iVar4 != 0) {
    fVar10 = (float10)FUN_00999eb0();
    fVar11 = (float)fVar10;
  }
  puVar2[0x10] = fVar11;
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 9757 ; VA 0x006fb8a0 ; FUN_006fb8a0 */

undefined4 * __thiscall FUN_006fb8a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 9758 ; VA 0x006fb8d0 ; FUN_006fb8d0 */

undefined4 FUN_006fb8d0(void)

{
  return 5;
}



/* FUNCTION 9759 ; VA 0x006fb8e0 ; FUN_006fb8e0 */

undefined __fastcall FUN_006fb8e0(undefined4 param_1)

{
  FUN_00626ec0(param_1);
  return 1;
}



/* FUNCTION 9760 ; VA 0x006fb900 ; FUN_006fb900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_006fb900(undefined4 *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  byte bVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  float10 fVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aac48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x38);
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 5;
    puVar6[2] = 1;
    puVar6[3] = 0;
    *puVar6 = RBX::Network::DeserializedPingItem::vftable;
    puVar6[8] = 0;
    puVar6[9] = 0;
    puVar6[10] = 0;
    puVar6[0xc] = 0;
  }
  FUN_006fb1d0(puVar6,param_2);
  uStack_8 = 0;
  iVar1 = *(int *)(param_3 + 0x20);
  bVar4 = FUN_006abe40();
  if (DAT_01d5bcb0 == '\0') {
    param_3._0_1_ = ~(bVar4 >> 1) & 1;
  }
  else {
    iVar2 = param_2[3];
    iVar7 = FUN_005ee350();
    param_3._0_1_ = 1;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
        (uint)*(ushort *)(iVar7 + 0x1da)) {
      param_3._0_1_ = bVar4 & 1;
    }
  }
  DAT_00000010 = bVar4;
  _DAT_00000018 = FUN_006ace60();
  if ((byte)param_3 == 0) {
    fVar8 = (float10)FUN_006ac3c0();
    _DAT_00000020 = (float)fVar8;
    fVar8 = (float10)FUN_006ac3c0();
    fRam00000024 = (float)fVar8;
    fVar8 = (float10)FUN_006ac3c0();
    fRam00000028 = (float)fVar8;
  }
  uRam0000002c = FUN_006ace40();
  uRam00000030 = FUN_006ace40();
  if ((_DAT_00000018 & 0x20) != 0) {
    cVar5 = (**(code **)(*param_2 + 0x124))();
    if (cVar5 == '\0') {
      uRam00000030 = ~uRam00000030;
    }
  }
  if (*(char *)(param_2[0x7dc] + 0x5b) != '\0') {
    FUN_006b86c0(2);
    FUN_006b8900(2,*(int *)(iVar3 + 0x20) - iVar1);
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9761 ; VA 0x006fbab0 ; FUN_006fbab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_006fbab0(uint param_1,int *param_2)

{
  float fVar1;
  ushort uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  byte bVar7;
  uint uVar8;
  undefined auStack_88 [8];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined auStack_70 [4];
  undefined4 uStack_6c;
  undefined auStack_68 [4];
  uint uStack_64;
  undefined auStack_60 [4];
  undefined4 uStack_5c;
  undefined auStack_58 [4];
  undefined4 uStack_54;
  undefined auStack_50 [4];
  float fStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  byte abStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aac68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_48 = param_1;
  puStack_20 = (uint *)FUN_01674e20(4);
  if (puStack_20 == (uint *)0x0) {
    puStack_20 = (uint *)0x0;
  }
  else {
    *puStack_20 = 0;
  }
  uStack_8 = 0;
  uStack_40 = DAT_01eaf554;
  uStack_28 = 0x2ed9f7c;
  uStack_3c = DAT_01eaf558;
  puStack_78 = puStack_20;
  puStack_74 = puStack_20;
  FUN_008f7870(*(undefined4 *)(param_1 + 0x10));
  uVar4 = FUN_008ee4a0();
  uStack_44 = uVar4 | DAT_01ee04b4 | _DAT_01ee04b0 | _DAT_01f6ab38;
  uStack_38 = DAT_01f02898;
  uStack_34 = DAT_01f02ac0;
  uStack_30 = DAT_01f02ad0;
  uStack_2c = DAT_01ee5a00;
  uStack_18 = DAT_01f04018;
  uStack_1c = DAT_01f04240;
  uStack_28 = 0x322747c;
  uStack_24 = DAT_01f047d4 | DAT_01f046b0 | DAT_01f046ac | DAT_01f02658 | DAT_01f046a8 |
              DAT_01eec540 | DAT_01f04698 | DAT_01f04240 | DAT_01f04018 | DAT_01ee5a00 |
              DAT_01f02ad0 | DAT_01f02ac0 | DAT_01f02898 | uStack_3c | uStack_40 | uStack_44;
  *puStack_20 = uStack_24;
  uStack_44 = (**(code **)(*param_2 + 8))();
  uVar4 = uStack_48;
  FUN_006b2070(param_2,5);
  iVar6 = *(int *)(*(int *)(uVar4 + 0x10) + 0xc);
  iVar5 = FUN_005ee350();
  uVar2 = *(ushort *)(iVar5 + 0x1da);
  uVar8 = (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8);
  abStack_14[0] = -(uVar2 < uVar8) & 2;
  FUN_006ad5e0(abStack_14,1);
  uStack_80 = *(undefined4 *)(uVar4 + 0x30);
  uStack_7c = *(undefined4 *)(uVar4 + 0x34);
  FUN_006a5c10(&uStack_80,auStack_88,8);
  FUN_006ad5e0(auStack_88,8);
  if (uVar2 < uVar8) {
    uStack_48 = *(uint *)(uVar4 + 0x30);
    iVar6 = *(int *)(uVar4 + 0x34);
    fStack_4c = *(float *)(uVar4 + 0x38);
    uStack_18 = uStack_48 >> 0x10 | iVar6 << 0x10;
    if ((((NAN(fStack_4c) || NAN((float)(int)fStack_4c)) == (fStack_4c == (float)(int)fStack_4c)) &&
        (fVar1 = *(float *)(uVar4 + 0x40),
        (NAN(fVar1) || NAN((float)(int)fVar1)) == (fVar1 == (float)(int)fVar1))) &&
       (fVar1 = *(float *)(uVar4 + 0x3c),
       (NAN(fVar1) || NAN((float)(int)fVar1)) == (fVar1 == (float)(int)fVar1))) {
      uStack_28._0_1_ = (byte)(uStack_48 >> 8);
      *(byte *)(uVar4 + 0x38) =
           (*(char *)(uVar4 + 0x3a) - *(char *)(uVar4 + 0x3b)) + (char)DAT_01eaf54c ^
           (byte)uStack_28;
      bVar7 = (byte)(uStack_48 >> 0x10);
      *(byte *)(uVar4 + 0x3c) =
           (*(char *)(uVar4 + 0x3f) - DAT_01eaf54c._1_1_) + *(char *)(uVar4 + 0x3e) ^ bVar7;
      uStack_1c._0_1_ = (byte)(uStack_48 >> 0x18);
      *(byte *)(uVar4 + 0x40) =
           (*(char *)(uVar4 + 0x42) - *(char *)(uVar4 + 0x43)) + DAT_01eaf54c._2_1_ ^
           (byte)uStack_1c;
      *(char *)(uVar4 + 0x39) = ((char)uStack_48 - DAT_01eaf54c._3_1_) + *(char *)(uVar4 + 0x38);
      *(byte *)(uVar4 + 0x3d) = (DAT_01eaf550 - (byte)uStack_28) + *(char *)(uVar4 + 0x3c);
      *(byte *)(uVar4 + 0x41) = (*(char *)(uVar4 + 0x40) - DAT_01eaf551) + bVar7;
      fStack_4c = *(float *)(uVar4 + 0x38);
    }
    uStack_28 = uStack_48 >> 8 | iVar6 << 0x18;
    uStack_1c = uStack_48 >> 0x18 | iVar6 << 8;
    FUN_006a5c10(&fStack_4c,auStack_50,4);
    FUN_006ad5e0(auStack_50,4);
    uStack_54 = *(undefined4 *)(uVar4 + 0x3c);
    FUN_006a5c10(&uStack_54,auStack_58,4);
    FUN_006ad5e0(auStack_58,4);
    uStack_5c = *(undefined4 *)(uVar4 + 0x40);
    FUN_006a5c10(&uStack_5c,auStack_60,4);
    FUN_006ad5e0(auStack_60,4);
  }
  uStack_64 = uStack_24;
  FUN_006a5c10(&uStack_64,auStack_68,4);
  FUN_006ad5e0(auStack_68,4);
  uStack_6c = *(undefined4 *)(uVar4 + 0x44);
  FUN_006a5c10(&uStack_6c,auStack_70,4);
  FUN_006ad5e0(auStack_70,4);
  if (*(char *)(*(int *)(*(int *)(uVar4 + 0x10) + 0x1f70) + 0x5b) != '\0') {
    FUN_006b87f0(2);
    iVar6 = (**(code **)(*param_2 + 8))();
    FUN_006b8ae0(2,iVar6 - uStack_44);
  }
  puVar3 = puStack_20;
  if (*puStack_20 != uStack_24) {
    iVar6 = FUN_016dee6d(&DAT_01f6aba0);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
    _DAT_01f6ab88 = _DAT_01f6ab88 | 0x80000;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar6 = FUN_016deec8(&DAT_01f6aba0);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
  }
  FUN_01674ea0(puVar3,4);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9762 ; VA 0x006fbf50 ; FUN_006fbf50 */

undefined4 * __thiscall FUN_006fbf50(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aac96;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00610b20("Replicator ProcessPackets",param_2,7,2);
  *param_1 = RBX::Network::Replicator::ProcessPacketsJob::vftable;
  uStack_8 = 0;
  param_1[0x4c] = 0;
  FUN_0151f360(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[0x54] = 0;
  FUN_00a361f0();
  param_1[0x4c] = 1;
  *(undefined *)(param_1 + 0x4d) = 0;
  uVar1 = FUN_008f7870(param_2);
  param_1[0x4f] = uVar1;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9763 ; VA 0x006fc000 ; FUN_006fc000 */

int __thiscall FUN_006fc000(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_0151f390();
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x158);
  }
  return param_1;
}



/* FUNCTION 9764 ; VA 0x006fc070 ; FUN_006fc070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_006fc070(int param_1,int param_2)

{
  double dVar1;
  double dVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  double *pdVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  float10 fVar10;
  float fVar11;
  double dVar12;
  undefined8 uVar13;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [8];
  undefined auStack_68 [8];
  double dStack_60;
  double dStack_58;
  double dStack_50;
  double dStack_48;
  double dStack_40;
  double dStack_38;
  undefined4 uStack_30;
  double dStack_2c;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017aacc7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01eadc98);
  iStack_8 = 0;
  uStack_30 = uVar4;
  if ((((DAT_01d63544 != '\0') && (*(int **)(param_1 + 0x128) != (int *)0x0)) &&
      (cVar3 = (**(code **)(**(int **)(param_1 + 0x128) + 0xd4))(), cVar3 == '\0')) &&
     ((*(int *)(param_1 + 0x13c) != 0 && (*(char *)(*(int *)(param_1 + 0x13c) + 0x278) == '\0')))) {
    iVar5 = thunk_FUN_014e71b0();
    dStack_2c = (double)iVar5 + (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)];
    uStack_78 = 0;
    uStack_74 = 0xf;
    auStack_88[0] = 0;
    uStack_1c = (double)CONCAT44(*(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 100) + 8),
                                 (uint)uStack_1c);
    FUN_005542c0("Total Bytes Received",0x14);
    iStack_8._0_1_ = 1;
    fVar10 = (float10)(*uStack_1c._4_4_)(auStack_88);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    uStack_24 = (double)fVar10;
    FUN_005507b0();
    dVar1 = *(double *)(param_1 + 0x140);
    if ((NAN(dVar1) == (dVar1 == 0.0)) &&
       ((dVar2 = *(double *)(param_1 + 0x148), NAN(dVar2) == (dVar2 == 0.0) &&
        (DAT_01ee04af != '\0')))) {
      dVar12 = *(double *)(param_2 + 8) * _DAT_018e2368;
      FUN_01677520(DAT_01ee04af,"%f, %f, %f, %f",*(double *)(param_2 + 8) * DAT_018c0d70,
                   (dStack_2c - dVar1) / dVar12,(uStack_24 - dVar2) / dVar12,
                   (((uStack_24 + dStack_2c) - dVar1) - dVar2) / dVar12);
    }
    *(double *)(param_1 + 0x140) = dStack_2c;
    *(double *)(param_1 + 0x148) = uStack_24;
  }
  if ((*(int *)(param_1 + 0x128) != 0) && (iVar5 = FUN_00620890(), iVar5 != 0)) {
    iVar5 = *(int *)(param_1 + 0x128);
    if (iVar5 == 0) {
      uVar7 = 0;
      goto LAB_006fc6eb;
    }
    if (DAT_01eace38 != '\0') {
      FUN_016774b0(DAT_01eace38,"ProcessPacketsJob running",0);
      iVar5 = *(int *)(param_1 + 0x128);
    }
    FUN_008e9840(iVar5);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    fVar10 = (float10)FUN_00a36320((int)*(undefined8 *)(param_2 + 8),
                                   (int)((ulonglong)*(undefined8 *)(param_2 + 8) >> 0x20),
                                   (int)DAT_018cf108,(int)((ulonglong)DAT_018cf108 >> 0x20),
                                   (float)DAT_01d5bcc0,(float)DAT_01d5bcc8);
    uStack_1c._4_4_ = (code *)(float)fVar10;
    iVar5 = FUN_00620890();
    if ((float)uStack_1c._4_4_ <= DAT_018ce2f8) {
      uStack_1c._4_4_ = (code *)DAT_018ce2f8;
    }
    iVar8 = 5;
    if (iVar5 < 5) {
      iVar8 = iVar5;
    }
    uStack_24 = (double)CONCAT44((float)DAT_01d5bcd0,(undefined4)uStack_24);
    pdVar6 = (double *)FUN_01682800(auStack_68);
    fVar11 = (float)iVar8 * (float)uStack_1c._4_4_;
    if (uStack_24._4_4_ <= (float)iVar8 * (float)uStack_1c._4_4_) {
      fVar11 = uStack_24._4_4_;
    }
    dStack_58 = (double)fVar11 * DAT_018e2370 + *pdVar6;
    if (DAT_01eace38 != '\0') {
      FUN_01677490(DAT_01eace38,
                   "ProcessPacketsJob: StepOnce, processAllPackets: %d, packets in Queue: %d",
                   *(undefined *)(*(int *)(param_1 + 0x128) + 0x1f58),
                   *(undefined4 *)(*(int *)(param_1 + 0x128) + 0x1f20),0);
    }
    pdVar6 = (double *)FUN_01682800(auStack_70);
    dStack_50 = (double)DAT_01ee4210 * DAT_018e2378 + *pdVar6;
    FUN_01682800(&dStack_38);
    fVar10 = (float10)FUN_006208b0(&dStack_38);
    iVar8 = 0;
    dStack_60 = (double)fVar10;
    uStack_1c = (double)(ulonglong)(uint)uStack_1c;
    iVar5 = (*(int **)(param_1 + 0x128))[0x685];
    dStack_48 = DAT_018ce330;
    dStack_40 = DAT_018ce330;
    cStack_12 = (**(code **)(**(int **)(param_1 + 0x128) + 0x124))();
    if (*(char *)(*(int *)(param_1 + 0x13c) + 0x1df) == '\0') {
      do {
        cVar3 = FUN_00624e20();
        if (cVar3 == '\0') break;
        iVar8 = iVar8 + 1;
        FUN_01682800(&uStack_24);
        if (*(char *)(*(int *)(param_1 + 0x128) + 0x1f58) == '\0') {
          if (dStack_58 < uStack_24) {
            fVar10 = (float10)FUN_006208b0(param_2);
            uStack_1c = (double)fVar10;
            if (uStack_1c <= (double)((float)DAT_01eaf580 / DAT_018ce324)) break;
            uStack_1c = uStack_24 - dStack_38;
            if ((uStack_1c <= DAT_018e2380) ||
               (cVar3 = (**(code **)(**(int **)(param_1 + 0x128) + 0xd4))(), cVar3 == '\0')) {
              cVar3 = DAT_01d5bd30;
              if (uStack_1c <= _PTR_018cf0f8) goto LAB_006fc5a3;
            }
            else {
              cStack_11 = '\0';
              fVar10 = (float10)FUN_006208b0(&uStack_24);
              dStack_48 = (double)((float10)dStack_60 - fVar10);
              iVar9 = FUN_00620890();
              dStack_40 = ((double)iVar9 + (double)(&DAT_018c0d90)[-(iVar9 >> 0x1f)]) *
                          (uStack_1c / ((double)iVar8 + (double)(&DAT_018c0d90)[-(iVar8 >> 0x1f)]));
              cVar3 = cStack_11;
              if (((iVar5 != 0) && (dStack_48 < (double)DAT_01eaf584 / DAT_018ce318)) &&
                 (0 < DAT_01d5bce0)) {
                *(int *)(param_1 + 0x150) = *(int *)(param_1 + 0x150) + DAT_01d5bce0;
                cVar3 = '\x01';
              }
              if (((iVar5 != 0) && ((double)DAT_01d5bcfc < dStack_40)) && (0 < DAT_01d5bcd8)) {
                *(int *)(param_1 + 0x150) = *(int *)(param_1 + 0x150) + DAT_01d5bcd8;
                cVar3 = '\x01';
              }
              if (DAT_018e2388 < uStack_1c) break;
            }
            if (cVar3 != '\0') break;
          }
        }
        else if ((DAT_01ee4210 != 0) && (dStack_50 < uStack_24)) break;
LAB_006fc5a3:
      } while (*(char *)(*(int *)(param_1 + 0x13c) + 0x1df) == '\0');
      uStack_1c = (double)CONCAT44(iVar8,(uint)uStack_1c);
    }
    if (DAT_01d5a058 != '\0') {
      iVar5 = *(int *)(param_1 + 0x128);
      iVar9 = 0;
      if (0 < *(int *)(iVar5 + 0x388c) - *(int *)(iVar5 + 0x3888) >> 2) {
        do {
          if (*(int *)(*(int *)(iVar5 + 0x3888) + iVar9 * 4) != 0) {
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01eaf5e0) && (FUN_016f3809(&DAT_01eaf5e0), DAT_01eaf5e0 == -1)) {
              iStack_8._0_1_ = 4;
              uVar13 = FUN_0152da50(&DAT_018c5904);
              DAT_01eaf5dc = (undefined4)((ulonglong)uVar13 >> 0x20);
              DAT_01eaf5d8 = (undefined4)uVar13;
              iStack_8 = CONCAT31(iStack_8._1_3_,3);
              FUN_016f37bf(&DAT_01eaf5e0);
            }
            uVar4 = *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3888) + iVar9 * 4);
            uVar7 = FUN_006b1c10(iVar9);
            FUN_0152d760(DAT_01eaf5d8,DAT_01eaf5dc,"%s : %d",uVar7,uVar4);
            *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3888) + iVar9 * 4) = 0;
            iVar5 = *(int *)(param_1 + 0x128);
          }
          iVar9 = iVar9 + 1;
        } while (iVar9 < *(int *)(iVar5 + 0x388c) - *(int *)(iVar5 + 0x3888) >> 2);
        iVar8 = (int)uStack_1c._4_4_;
      }
    }
    iVar5 = *(int *)(param_1 + 0x150) - DAT_01d5bce8;
    if (iVar5 < 1) {
      iVar5 = 0;
    }
    *(int *)(param_1 + 0x150) = iVar5;
    if ((cStack_12 == '\0') && (DAT_01d5bcf0 < iVar5)) {
      (**(code **)(**(int **)(param_1 + 0x128) + 0x204))
                (SUB84(dStack_48,0),(int)((ulonglong)dStack_48 >> 0x20),SUB84(dStack_40,0),
                 (int)((ulonglong)dStack_40 >> 0x20),iVar8);
    }
    (**(code **)(**(int **)(param_1 + 0x128) + 0xc0))();
    FUN_008eb130();
    uVar4 = uStack_30;
  }
  uVar7 = 1;
LAB_006fc6eb:
  iStack_8 = 6;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 9765 ; VA 0x006fc760 ; FUN_006fc760 */

undefined4 * __thiscall
FUN_006fc760(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aacf3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::ReferencePropertyChangedItem::vftable;
  param_1[0xc] = param_3;
  param_1[0xd] = param_4;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = *param_5;
  param_1[0xf] = param_5[1];
  param_1[0x10] = 0xffffffff;
  param_1[0x11] = 0;
  uStack_8 = 1;
  iVar3 = (**(code **)(*param_3 + 0x44))(*param_5);
  if (iVar3 != 0) {
    iVar2 = *(int *)(iVar3 + 0xc);
    iVar4 = thunk_FUN_00897b90();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      param_1[0x10] = *(undefined4 *)(iVar3 + 0x18);
      param_1[0x11] = *(undefined4 *)(iVar3 + 0x1c);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9766 ; VA 0x006fc830 ; FUN_006fc830 */

undefined4 * __thiscall FUN_006fc830(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0xf];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9767 ; VA 0x006fc8a0 ; FUN_006fc8a0 */

void __thiscall FUN_006fc8a0(int param_1,undefined4 param_2)

{
  FUN_006fc8d0(*(undefined4 *)(param_1 + 0x10),param_2,*(undefined4 *)(param_1 + 0x30),
               *(undefined4 *)(param_1 + 0x34),param_1 + 0x38,param_1 + 0x40);
  return;
}



/* FUNCTION 9768 ; VA 0x006fc8d0 ; FUN_006fc8d0 */

undefined4
FUN_006fc8d0(int *param_1,int param_2,uint param_3,ushort *param_4,undefined4 *param_5,
            undefined4 *param_6)

{
  int *piVar1;
  undefined4 uVar2;
  ushort *puVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = param_5;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aad10;
  pvStack_10 = ExceptionList;
  uStack_28 = *param_6;
  uStack_24 = param_6[1];
  iStack_20 = *(undefined4 *)(param_3 + 4);
  if (0xf < *(uint *)(iStack_20 + 0x14)) {
    iStack_20 = *(int *)iStack_20;
  }
  ExceptionList = &pvStack_10;
  FUN_006f57e0(param_1,param_3,param_4,param_5);
  uVar2 = *puVar4;
  uStack_8 = 0;
  FUN_006b20a0(param_1,param_2,3);
  param_5 = *(undefined4 **)(param_2 + 0x18);
  FUN_006b9320(param_2,uVar2);
  param_3 = (uint)*param_4;
  FUN_006a5c10(&param_3,&param_6,2);
  FUN_006ad5e0(&param_6,2);
  (**(code **)(*param_1 + 0x134))(param_2,uVar2,*param_4,*(undefined4 *)(param_4 + 8));
  puVar3 = param_4;
  iStack_1c = 0;
  iStack_18 = 0;
  iStack_14 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  FUN_0060aac0(param_2,param_4 + 2,1,&uStack_28,0,&iStack_1c,&uStack_38);
  FUN_00632400(param_2,&iStack_1c);
  if (DAT_01d59fb8 != '\0') {
    FUN_006283d0(*(undefined4 *)(puVar3 + 8),*(int *)(param_2 + 0x18) - (int)param_5);
  }
  iVar5 = iStack_18;
  iVar7 = iStack_1c;
  if (iStack_1c != 0) {
    for (; iVar7 != iVar5; iVar7 = iVar7 + 4) {
      FUN_00615780(0);
    }
    uVar6 = iStack_14 - iStack_1c & 0xfffffffc;
    iVar7 = iStack_1c;
    if (0xfff < uVar6) {
      iVar7 = *(int *)(iStack_1c + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iStack_1c - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar6);
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9769 ; VA 0x006fcaa0 ; FUN_006fcaa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_006fcaa0(undefined4 *param_1,undefined8 *param_2)

{
  int iVar1;
  void *pvVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088ca00();
  iVar1 = _tls_index;
  *param_1 = uVar3;
  param_1[1] = 0;
  pvVar2 = ThreadLocalStoragePointer;
  *(undefined8 *)(param_1 + 2) = *param_2;
  if (*(int *)(*(int *)((int)pvVar2 + iVar1 * 4) + 0x34) < DAT_01ead488) {
    FUN_016f3809(&DAT_01ead488);
    if (DAT_01ead488 == -1) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
  }
  param_1[1] = &DAT_01ead47c;
  return param_1;
}



/* FUNCTION 9770 ; VA 0x006fcb40 ; FUN_006fcb40 */

undefined * __thiscall FUN_006fcb40(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  pcVar2 = (char *)*param_2;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar4 = pcVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
  uStack_8 = 0;
  uVar5 = FUN_0088c8c0();
  iVar3 = _tls_index;
  *(undefined4 *)(param_1 + 0x18) = uVar5;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar3 * 4) + 0x34) < DAT_01ea8c18) {
    FUN_016f3809(&DAT_01ea8c18);
    if (DAT_01ea8c18 == -1) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
  }
  *(code ***)(param_1 + 0x1c) = &DAT_01ea8c0c;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9771 ; VA 0x006fcc30 ; FUN_006fcc30 */

void __thiscall FUN_006fcc30(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aad20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedStatsItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9772 ; VA 0x006fcc9e ; Catch_All@006fcc9e */

void Catch_All_006fcc9e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9773 ; VA 0x006fccc0 ; FUN_006fccc0 */

int __thiscall FUN_006fccc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aad30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedStatsItem<float>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9774 ; VA 0x006fcd92 ; Catch_All@006fcd92 */

void Catch_All_006fcd92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9775 ; VA 0x006fcdb0 ; FUN_006fcdb0 */

int __thiscall FUN_006fcdb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aad40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedStatsItem<double>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9776 ; VA 0x006fce82 ; Catch_All@006fce82 */

void Catch_All_006fce82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9777 ; VA 0x006fcea0 ; FUN_006fcea0 */

int __thiscall FUN_006fcea0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aad50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedStatsItem<unsigned___int64>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9778 ; VA 0x006fcf72 ; Catch_All@006fcf72 */

void Catch_All_006fcf72(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9779 ; VA 0x006fcf90 ; FUN_006fcf90 */

int __thiscall FUN_006fcf90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aad60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedStatsItem<bool>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9780 ; VA 0x006fd062 ; Catch_All@006fd062 */

void Catch_All_006fd062(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9781 ; VA 0x006fd080 ; FUN_006fd080 */

int __thiscall FUN_006fd080(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aad70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::RakStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9782 ; VA 0x006fd152 ; Catch_All@006fd152 */

void Catch_All_006fd152(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9783 ; VA 0x006fd180 ; FUN_006fd180 */

undefined4 * FUN_006fd180(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aadbb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<float>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018e2e61;
    }
    else {
      puVar5[0x1e] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fccc0(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9784 ; VA 0x006fd2d0 ; FUN_006fd2d0 */

undefined4 * FUN_006fd2d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aae0b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<double>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018e2ecd;
    }
    else {
      puVar5[0x1e] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fcdb0(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9785 ; VA 0x006fd420 ; FUN_006fd420 */

undefined4 * FUN_006fd420(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aae5b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<unsigned___int64>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018e2edd;
    }
    else {
      puVar5[0x1e] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fcea0(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9786 ; VA 0x006fd570 ; FUN_006fd570 */

undefined4 * FUN_006fd570(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aaeab;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009fb200();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_18 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    puStack_1c = puVar5;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar5 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar6 = FUN_009fb200();
    puVar5[3] = uVar6;
    *(undefined8 *)(puVar5 + 0x16) = 0;
    puVar5[0x1c] = 0;
    puVar5[0x1d] = 0xf;
    *(undefined *)(puVar5 + 0x18) = 0;
    *puVar5 = RBX::Stats::TypedStatsItem<bool>::vftable;
    puVar5[0x1e] = 0;
    pcStack_20 = FUN_0054db60;
    puStack_1c = (undefined4 *)uVar1;
    cVar2 = FUN_00585a40(&pcStack_20);
    if (cVar2 == '\0') {
      puVar5[0x20] = pcStack_20;
      puVar5[0x21] = puStack_1c;
      puVar5[0x1e] = &DAT_018e2ed5;
    }
    else {
      puVar5[0x1e] = 0;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fcf90(puVar5,param_1);
  uStack_14 = 1;
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9787 ; VA 0x006fd6c0 ; FUN_006fd6c0 */

undefined4 * FUN_006fd6c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aaf0b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Network::RakStatsItem::vftable;
    puVar4[0x1e] = uVar1;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Stats",5);
    uStack_8._0_1_ = 5;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 4;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      uVar6 = auStack_34[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_34[0] - 4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fd080(puVar4,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 9;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9788 ; VA 0x006fd830 ; FUN_006fd830 */

undefined4 * FUN_006fd830(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_006fd2d0(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9789 ; VA 0x006fd980 ; FUN_006fd980 */

undefined4 * FUN_006fd980(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_006fd420(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9790 ; VA 0x006fdad0 ; FUN_006fdad0 */

undefined4 * FUN_006fdad0(undefined4 *param_1,char *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4131;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_006fd570(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  param_3 = param_2 + 1;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)param_3);
  uStack_8 = 1;
  (*pcVar3)(auStack_38);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9791 ; VA 0x006fdc20 ; FUN_006fdc20 */

undefined4 FUN_006fdc20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaf2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf634) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaf634);
    if (DAT_01eaf634 == -1) {
      uStack_8 = 0;
      DAT_01eaf630 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaf634);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaf630;
}



/* FUNCTION 9792 ; VA 0x006fdca0 ; FUN_006fdca0 */

void __thiscall FUN_006fdca0(int param_1,undefined4 *param_2,byte *param_3,int param_4)

{
  uint *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  byte *pbVar10;
  byte *pbVar11;
  undefined4 *puVar12;
  bool bVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaf48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005702d0(param_3);
  puVar1 = (uint *)(param_1 + 4);
  uVar9 = uVar5 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar7 = (int *)0x0;
  }
  else {
    puVar12 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar12 == (undefined4 *)0x0) {
      piVar7 = (int *)0x0;
    }
    else {
      piVar7 = (int *)*puVar12;
    }
    if (piVar7 == (int *)0x0) goto LAB_006fdddb;
    do {
      if (uVar5 == piVar7[1]) {
        pbVar10 = (byte *)(piVar7 + 2);
        if (0xf < (uint)piVar7[7]) {
          pbVar10 = *(byte **)pbVar10;
        }
        uVar6 = *(uint *)(param_3 + 0x10);
        pbVar11 = param_3;
        if (0xf < *(uint *)(param_3 + 0x14)) {
          pbVar11 = *(byte **)param_3;
        }
        if (uVar6 == piVar7[6]) {
          while (uVar8 = uVar6 - 4, 3 < uVar6) {
            if (*(int *)pbVar11 != *(int *)pbVar10) goto LAB_006fdd66;
            pbVar11 = pbVar11 + 4;
            pbVar10 = pbVar10 + 4;
            uVar6 = uVar8;
          }
          if (uVar8 == 0xfffffffc) {
LAB_006fdd9a:
            uVar6 = 0;
          }
          else {
LAB_006fdd66:
            bVar13 = *pbVar11 < *pbVar10;
            if ((*pbVar11 == *pbVar10) &&
               ((uVar8 == 0xfffffffd ||
                ((bVar13 = pbVar11[1] < pbVar10[1], pbVar11[1] == pbVar10[1] &&
                 ((uVar8 == 0xfffffffe ||
                  ((bVar13 = pbVar11[2] < pbVar10[2], pbVar11[2] == pbVar10[2] &&
                   ((uVar8 == 0xffffffff ||
                    (bVar13 = pbVar11[3] < pbVar10[3], pbVar11[3] == pbVar10[3]))))))))))))
            goto LAB_006fdd9a;
            uVar6 = -(uint)bVar13 | 1;
          }
          if (uVar6 == 0) break;
        }
      }
      else if ((uint)piVar7[1] % *(uint *)(param_1 + 4) != uVar9) goto LAB_006fdddb;
      piVar7 = (int *)*piVar7;
    } while (piVar7 != (int *)0x0);
  }
  if (piVar7 != (int *)0x0) {
    *(undefined *)(param_2 + 1) = 0;
    *param_2 = piVar7;
    ExceptionList = pvStack_10;
    return;
  }
LAB_006fdddb:
  uStack_8 = 0;
  piVar7 = (int *)FUN_01674e20(0x28);
  *piVar7 = 0;
  piVar7[1] = 0;
  piVar7[2] = 0;
  piVar7[3] = 0;
  piVar7[4] = 0;
  piVar7[5] = 0;
  piVar7[6] = 0;
  piVar7[7] = 0;
  piVar7[8] = 0;
  piVar7[9] = 0;
  FUN_0054ef60(param_4);
  *(undefined8 *)(piVar7 + 8) = *(undefined8 *)(param_4 + 0x18);
  uVar6 = *(uint *)(param_1 + 8);
  uVar9 = uVar6 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *puVar1) {
      uVar9 = *puVar1;
    }
    FUN_005d2b00(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uVar8 = uVar6 >> 1;
    if (uVar6 + (uVar6 >> 1) <= uVar9) {
      uVar8 = 1;
    }
    uVar9 = FUN_005d6bb0(uVar8 + uVar6);
    if (uVar9 != *puVar1) {
      FUN_005d2b00(uVar9);
      puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar2 = (undefined4 *)*puVar12;
      while (puVar2 != (undefined4 *)0x0) {
        piVar4 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *puVar1) * 4) == 0) {
          *piVar4 = (int)puVar12;
          puVar12 = puVar2;
        }
        else {
          *puVar12 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar12;
      }
    }
  }
  piVar7[1] = uVar5;
  uVar9 = *puVar1;
  iVar3 = *(int *)(param_1 + 0x14);
  piVar4 = *(int **)(iVar3 + (uVar5 % uVar9) * 4);
  puVar12 = (undefined4 *)(iVar3 + (uVar5 % uVar9) * 4);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)(iVar3 + uVar9 * 4);
    if (*piVar4 != 0) {
      *(int **)(iVar3 + (*(uint *)(*piVar4 + 4) % uVar9) * 4) = piVar7;
    }
    *puVar12 = piVar4;
    *piVar7 = *piVar4;
    *piVar4 = (int)piVar7;
  }
  else {
    *piVar7 = *piVar4;
    *(int **)*puVar12 = piVar7;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar7;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9793 ; VA 0x006fdf60 ; FUN_006fdf60 */

int FUN_006fdf60(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eaf628,&LAB_006fd170);
  uVar3 = FUN_006fdc20();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00cce470();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 9794 ; VA 0x006fe020 ; FUN_006fe020 */

undefined4 * __thiscall FUN_006fe020(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798678;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
  uVar2 = FUN_009fb200();
  param_1[3] = uVar2;
  *(undefined8 *)(param_1 + 0x16) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  *param_1 = RBX::Network::Replicator::Stats::vftable;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x78] = *param_2;
  param_1[0x79] = param_2[1];
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9795 ; VA 0x006fe460 ; FUN_006fe460 */

void __fastcall FUN_006fe460(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_006fe4e0();
        iVar2 = iVar2 + 0x50;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x50) * 0x50;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9796 ; VA 0x006fe4e0 ; FUN_006fe4e0 */

void __fastcall FUN_006fe4e0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  
  iVar6 = param_1[0xc];
  if (iVar6 != 0) {
    iVar3 = param_1[0xd];
    if (iVar6 != iVar3) {
      do {
        piVar1 = *(int **)(iVar6 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar6 = iVar6 + 8;
      } while (iVar6 != iVar3);
      iVar6 = param_1[0xc];
    }
    uVar4 = param_1[0xe] - iVar6 & 0xfffffff8;
    iVar3 = iVar6;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar6 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar6 - iVar3) - 4U) goto LAB_006fe603;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0xc] = 0;
    param_1[0xd] = 0;
    param_1[0xe] = 0;
  }
  uVar4 = param_1[0xb];
  if (0xf < uVar4) {
    iVar6 = param_1[6];
    uVar5 = uVar4 + 1;
    iVar3 = iVar6;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar6 + -4);
      uVar5 = uVar4 + 0x24;
      if (0x1f < (iVar6 - iVar3) - 4U) goto LAB_006fe603;
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar4 = param_1[5];
  if (0xf < uVar4) {
    iVar6 = *param_1;
    uVar5 = uVar4 + 1;
    iVar3 = iVar6;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar6 + -4);
      uVar5 = uVar4 + 0x24;
      if (0x1f < (iVar6 - iVar3) - 4U) {
LAB_006fe603:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 9797 ; VA 0x006fe610 ; FUN_006fe610 */

int * __thiscall FUN_006fe610(int *param_1,byte *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  byte *pbVar9;
  byte *pbVar10;
  bool bVar11;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaf70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  uStack_18 = FUN_005702d0(param_2);
  uStack_14 = uStack_18 % *(uint *)((int)param_1 + 4);
  if (*(int *)((int)param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)((int)param_1 + 0x14) + uStack_14 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uStack_18 == puVar6[1]) {
        pbVar9 = (byte *)(puVar6 + 2);
        if (0xf < (uint)puVar6[7]) {
          pbVar9 = *(byte **)pbVar9;
        }
        uVar3 = *(uint *)(param_2 + 0x10);
        pbVar10 = param_2;
        if (0xf < *(uint *)(param_2 + 0x14)) {
          pbVar10 = *(byte **)param_2;
        }
        param_1 = piStack_1c;
        if (uVar3 == puVar6[6]) {
          while (uVar2 = uVar3 - 4, 3 < uVar3) {
            if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_006fe6c6;
            pbVar10 = pbVar10 + 4;
            pbVar9 = pbVar9 + 4;
            uVar3 = uVar2;
          }
          if (uVar2 == 0xfffffffc) {
LAB_006fe6fa:
            uVar3 = 0;
          }
          else {
LAB_006fe6c6:
            bVar11 = *pbVar10 < *pbVar9;
            if ((*pbVar10 == *pbVar9) &&
               ((uVar2 == 0xfffffffd ||
                ((bVar11 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
                 ((uVar2 == 0xfffffffe ||
                  ((bVar11 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                   ((uVar2 == 0xffffffff ||
                    (bVar11 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3]))))))))))))
            goto LAB_006fe6fa;
            uVar3 = -(uint)bVar11 | 1;
          }
          if (uVar3 == 0) {
            if (puVar6 != (undefined4 *)0x0) {
              ExceptionList = pvStack_10;
              return puVar6 + 2;
            }
            break;
          }
        }
      }
      else if ((uint)puVar6[1] % *(uint *)((int)param_1 + 4) != uStack_14) break;
    }
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (int *)0xfffffffd) & (int)param_1 + 4U;
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar4 = (int *)FUN_01674e20(0x40);
  piStack_1c = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_24 = piVar4;
  FUN_0170d1f0(piStack_1c,0,0x38);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  FUN_0054ef60(aiStack_40);
  piVar4[0xc] = 0;
  piVar4[0xd] = 0;
  piVar4[0xe] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  piVar4[8] = 0;
  piVar4[9] = 0;
  piVar4[10] = 0;
  piVar4[0xb] = 0;
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar3) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
  }
  uVar2 = *(uint *)((int)param_1 + 8);
  uVar3 = uVar2 + 1;
  if (*(int *)((int)param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar3);
    if (uVar3 <= *(uint *)((int)param_1 + 4)) {
      uVar3 = *(uint *)((int)param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)((int)param_1 + 0x10) < uVar3) {
    uVar7 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar3) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar2);
    if (iVar5 != *(int *)((int)param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar6 = (undefined4 *)(*(int *)((int)param_1 + 0x14) + *(int *)((int)param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar6;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)((int)param_1 + 4);
        piVar8 = (int *)(*(int *)((int)param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)((int)param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar8 = (int)puVar6;
          puVar6 = puVar1;
        }
        else {
          *puVar6 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar4[1] = uStack_18;
  uStack_18 = uStack_18 % *(uint *)((int)param_1 + 4);
  piVar8 = *(int **)(*(int *)((int)param_1 + 0x14) + uStack_18 * 4);
  puVar6 = (undefined4 *)(*(int *)((int)param_1 + 0x14) + uStack_18 * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)((int)param_1 + 0x14) + *(uint *)((int)param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)((int)param_1 + 0x14) +
               (*(uint *)(*piVar8 + 4) % *(uint *)((int)param_1 + 4)) * 4) = piVar4;
    }
    *puVar6 = piVar8;
    *piVar4 = *piVar8;
  }
  else {
    *piVar4 = *piVar8;
    piVar8 = (int *)*puVar6;
  }
  *piVar8 = (int)piVar4;
  *(int *)((int)param_1 + 8) = *(int *)((int)param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 9798 ; VA 0x006fe910 ; FUN_006fe910 */

undefined4 * __thiscall FUN_006fe910(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::DeserializedStatsItem::vftable;
  piVar2 = (int *)param_1[5];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 9799 ; VA 0x006fe970 ; FUN_006fe970 */

int __thiscall FUN_006fe970(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 9800 ; VA 0x006fe9e0 ; FUN_006fe9e0 */

undefined4 __thiscall FUN_006fe9e0(undefined4 param_1,byte param_2)

{
  FUN_00678c10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1f0);
  }
  return param_1;
}



/* FUNCTION 9801 ; VA 0x006fea10 ; FUN_006fea10 */

void FUN_006fea10(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_006fe4e0();
      param_1 = param_1 + 0x50;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 9802 ; VA 0x006fea40 ; FUN_006fea40 */

double * FUN_006fea40(int *param_1,int *param_2,double *param_3)

{
  int iVar1;
  int iVar2;
  double *pdVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar1 = param_1[3];
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  piVar4 = (int *)0x0;
  if ((double *)((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) <=
      (double *)(uint)*(ushort *)(iVar2 + 0x1da)) {
    piVar4 = param_1;
  }
  pdVar3 = (double *)(uint)*(ushort *)(iVar2 + 0x1da);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0xa4))();
    *param_3 = *(double *)(piVar4 + 0x16) + *param_3;
    pdVar3 = param_3;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar4 = param_2 + 1;
    iVar1 = *piVar4;
    pdVar3 = (double *)*piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pdVar3 = (double *)(**(code **)*param_2)();
      LOCK();
      piVar4 = param_2 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        pdVar3 = (double *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pdVar3;
}



/* FUNCTION 9803 ; VA 0x006feae0 ; FUN_006feae0 */

int FUN_006feae0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaf90;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + param_3 * 0x18;
  ExceptionList = &pvStack_10;
  FUN_009fd9f0(auStack_20,param_2,iVar4);
  param_1 = param_1 + param_3 * 0x28;
  uStack_8 = 0;
  FUN_009fdb40(auStack_28,&DAT_018dbc90,param_1 + 0x210);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_24[1] + -1;
    piStack_24[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_009fd9f0(auStack_18,param_2,iVar4 + 0x108);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar4 = FUN_009fdb40(auStack_28,&DAT_018dbc90,param_1 + 0x3c8);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_24 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar2 = piStack_24 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 9804 ; VA 0x006fec30 ; FUN_006fec30 */

void FUN_006fec30(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x50;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 9805 ; VA 0x006fec70 ; FUN_006fec70 */

int __thiscall FUN_006fec70(undefined4 param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  undefined uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined auStack_48 [4];
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aafd1;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_006fd980(auStack_28,"messageDataBytesSentPerSec",param_2);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"messageTotalBytesSentPerSec",param_2 + 8);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"messageDataBytesResentPerSec",param_2 + 0x10);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"messagesBytesReceivedPerSec",param_2 + 0x18);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"messagesBytesReceivedAndIgnoredPerSec",param_2 + 0x20);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"bytesSentPerSec",param_2 + 0x28);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"bytesReceivedPerSec",param_2 + 0x30);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"totalMessageBytesPushed",param_2 + 0x38);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_28,"totalMessageBytesSent",param_2 + 0x40);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piStack_24 = (int *)(param_2 + 0x48);
  FUN_006fd980(auStack_20,"totalMessageBytesResent",piStack_24);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"totalMessagesBytesReceived",param_2 + 0x50);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"totalMessagesBytesReceivedAndIgnored",param_2 + 0x58);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"totalBytesSent",param_2 + 0x60);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"totalBytesReceived",param_2 + 0x68);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"connectionStartTime",param_2 + 0x70);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"outgoingBandwidthLimitBytesPerSecond",param_2 + 0x90);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fdad0(auStack_20,"isLimitedByOutgoingBandwidthLimit",param_2 + 0x88);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"congestionControlLimitBytesPerSecond",param_2 + 0x80);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fdad0(auStack_20,"isLimitedByCongestionControl",param_2 + 0x78);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_009ff040(auStack_38,"messageSendBuffer");
  uStack_8 = 0;
  FUN_006756e0(auStack_20,"IMMEDIATE_PRIORITY",param_2 + 0x98);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006756e0(auStack_20,"HIGH_PRIORITY",param_2 + 0x9c);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006756e0(auStack_20,"MEDIUM_PRIORITY",param_2 + 0xa0);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006756e0(auStack_20,"LOW_PRIORITY",param_2 + 0xa4);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_009ff040(auStack_30,"bytesInSendBuffer");
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_006fd830(auStack_20,"IMMEDIATE_PRIORITY",param_2 + 0xa8);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd830(auStack_20,"HIGH_PRIORITY",param_2 + 0xb0);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd830(auStack_20,"MEDIUM_PRIORITY",param_2 + 0xb8);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd830(auStack_20,"LOW_PRIORITY",param_2 + 0xc0);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006756e0(auStack_20,"messagesInResendQueue",param_2 + 200);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fd980(auStack_20,"bytesInResendQueue",param_2 + 0xd0);
  piStack_14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_14[2] + -1;
      piStack_14[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piStack_14 = (int *)(param_2 + 0xd8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar6 = (undefined4 *)FUN_006fd180(auStack_48,&piStack_14);
  piVar2 = piStack_44;
  uStack_18 = 1;
  piStack_40 = (int *)*puVar6;
  piStack_3c = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piStack_1c = piStack_3c;
  piStack_14 = piStack_40;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_44[1] + -1;
    piStack_44[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  pcVar4 = *(code **)(*piStack_14 + 0x38);
  FUN_005542c0("packetlossLastSecond",0x14);
  uStack_8._0_1_ = 3;
  (*pcVar4)(auStack_60);
  uStack_8._0_1_ = 2;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_4c) {
    uVar9 = uStack_4c + 1;
    uVar8 = auStack_60[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_60[0] - 4);
      uVar9 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  FUN_008a65e0(param_1,0);
  piVar2 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar7 = FUN_006fd980(auStack_48,"packetlossTotal",piStack_24);
  piVar2 = piStack_44;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_44 + 1;
    iVar3 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar7 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (DAT_01d5b280 != '\0') {
    FUN_006756e0(auStack_48,"numberOfUnsplitMessages",param_2 + 0x158);
    piVar2 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_44[1] + -1;
      piStack_44[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar7 = *piVar1 + -1;
        *piVar1 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    iVar7 = FUN_006756e0(auStack_48,"numberOfSplitMessages",param_2 + 0x15c);
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_44 + 1;
      iVar3 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        piVar2 = piStack_44 + 2;
        iVar3 = *piVar2;
        iVar7 = *piVar2;
        *piVar2 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar7 = (**(code **)(*piStack_44 + 4))();
        }
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 1;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar2 = piStack_2c + 2;
      iVar3 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar7 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_34 + 1;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)*piStack_34)();
      LOCK();
      piVar2 = piStack_34 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar7 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 9806 ; VA 0x006ff610 ; FUN_006ff610 */

int __thiscall FUN_006ff610(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaff0;
  pvStack_10 = ExceptionList;
  iVar7 = *param_2;
  iVar8 = iVar7 + 0xa0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,&DAT_018c5ca8);
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x90) = uVar6;
  piStack_14 = *(int **)(param_1 + 0x94);
  *(undefined4 *)(param_1 + 0x94) = uVar3;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_28,"Data Ping",iVar7 + 0x970);
  piStack_14 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_006fdad0(auStack_28,"StreamingEnabled",*param_2 + 0x37f8);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = (int *)(iVar7 + 0xf10);
  FUN_006fd6c0(auStack_28,&param_2);
  uStack_8 = 0;
  FUN_008a65e0(param_1,0);
  uStack_8 = 0xffffffff;
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_006fd830(auStack_20,"Send kBps",iVar7 + 0x808);
  uStack_8 = 1;
  if (DAT_01d5b280 == '\0') {
    FUN_00675590(auStack_28,"Unsplit Messages",iVar7 + 0x968);
    param_2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = param_2[2] + -1;
        param_2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    FUN_00675590(auStack_28,"Split Messages",iVar7 + 0x96c);
    param_2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = param_2[2] + -1;
        param_2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
  }
  piStack_14 = (int *)(iVar7 + 0x810);
  puVar5 = (undefined4 *)FUN_006fd830(auStack_28,"Send Buffer Health",piStack_14);
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xa8) = uVar6;
  param_2 = *(int **)(param_1 + 0xac);
  *(undefined4 *)(param_1 + 0xac) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"BandwidthExceeded");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xb0) = uVar6;
  param_2 = *(int **)(param_1 + 0xb4);
  *(undefined4 *)(param_1 + 0xb4) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"CongestionControlExceeded");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xb8) = uVar6;
  param_2 = *(int **)(param_1 + 0xbc);
  *(undefined4 *)(param_1 + 0xbc) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_006fd830(auStack_28,"Receive kBps",iVar7 + 0x620);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Packet Queue");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x78) = uVar6;
  param_2 = *(int **)(param_1 + 0x7c);
  *(undefined4 *)(param_1 + 0x7c) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Sent Data Packets");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xd0) = uVar6;
  param_2 = *(int **)(param_1 + 0xd4);
  *(undefined4 *)(param_1 + 0xd4) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_28,&DAT_018dbc90,iVar7 + 0x880);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Throttle");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xe0) = uVar6;
  param_2 = *(int **)(param_1 + 0xe4);
  *(undefined4 *)(param_1 + 0xe4) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Queue Size");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x88) = uVar6;
  param_2 = *(int **)(param_1 + 0x8c);
  *(undefined4 *)(param_1 + 0x8c) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Time In Queue");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x100) = uVar6;
  param_2 = *(int **)(param_1 + 0x104);
  *(undefined4 *)(param_1 + 0x104) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_28,"New Items Per Sec",iVar7 + 0x8d0);
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x108) = uVar6;
  param_2 = *(int **)(param_1 + 0x10c);
  *(undefined4 *)(param_1 + 0x10c) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_28,"Items Sent Per Sec",iVar7 + 0x8e8);
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x110) = uVar6;
  param_2 = *(int **)(param_1 + 0x114);
  *(undefined4 *)(param_1 + 0x114) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"OutPhysicsDetails");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x1a0) = uVar6;
  param_2 = *(int **)(param_1 + 0x1a4);
  *(undefined4 *)(param_1 + 0x1a4) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_006b82c0(*(undefined4 *)(param_1 + 0x1a0));
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"InPhysicsDetails");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x1a8) = uVar6;
  param_2 = *(int **)(param_1 + 0x1ac);
  *(undefined4 *)(param_1 + 0x1ac) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_006b82c0(*(undefined4 *)(param_1 + 0x1a8));
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Send Data Types");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xd8) = uVar6;
  param_2 = *(int **)(param_1 + 0xdc);
  *(undefined4 *)(param_1 + 0xdc) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Received Data Types");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0xf8) = uVar6;
  param_2 = *(int **)(param_1 + 0xfc);
  *(undefined4 *)(param_1 + 0xfc) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_006feae0(iVar8,PTR_DAT_01d5b440,0);
  FUN_006feae0(iVar8,PTR_DAT_01d5b444,1);
  FUN_006feae0(iVar8,PTR_DAT_01d5b448,2);
  FUN_006feae0(iVar8,PTR_DAT_01d5b44c,3);
  FUN_006feae0(iVar8,PTR_s_Behavior_01d5b450,4);
  FUN_006feae0(iVar8,PTR_s_State_01d5b454,5);
  FUN_006feae0(iVar8,PTR_s_Appearance_01d5b458,6);
  FUN_006feae0(iVar8,PTR_DAT_01d5b45c,7);
  FUN_006feae0(iVar8,PTR_s_Video_01d5b460,8);
  FUN_006feae0(iVar8,PTR_s_Control_01d5b464,9);
  FUN_006feae0(iVar8,PTR_s_Events_01d5b468,10);
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Sent Physics Packets");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x148) = uVar6;
  param_2 = *(int **)(param_1 + 0x14c);
  *(undefined4 *)(param_1 + 0x14c) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar8 = param_2[1] + -1;
    param_2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_28,&DAT_018dbc90,iVar7 + 0xa78);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Throttle");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x150) = uVar6;
  param_2 = *(int **)(param_1 + 0x154);
  *(undefined4 *)(param_1 + 0x154) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar8 = param_2[1] + -1;
    param_2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"Smoothed");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x158) = uVar6;
  param_2 = *(int **)(param_1 + 0x15c);
  *(undefined4 *)(param_1 + 0x15c) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar8 = param_2[1] + -1;
    param_2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fdb40(auStack_28,"Items Per Packet",iVar7 + 0xaa0);
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x160) = uVar6;
  param_2 = *(int **)(param_1 + 0x164);
  *(undefined4 *)(param_1 + 0x164) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar8 = param_2[1] + -1;
    param_2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009ff040(auStack_28,"SentTouchPackets");
  uVar6 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x130) = uVar6;
  param_2 = *(int **)(param_1 + 0x134);
  *(undefined4 *)(param_1 + 0x134) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar8 = param_2[1] + -1;
    param_2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_28,&DAT_018dbc90,iVar7 + 0xb08);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_28,"WaitingTouches",iVar7 + 0xb30);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Received Packets");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Received Data Packets");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Queue Size");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Instance Size");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Waiting Refs");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,&DAT_018dbc90);
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Received Physics Packets");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Average Lag");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Average Buffer Seek");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Max Buffer Seek");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Wrong Order");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,&DAT_018dbc90);
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Sent Cluster Packets");
  FUN_005587e0(uVar6);
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar8 = param_2[2] + -1;
      param_2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_28,&DAT_018dbc90,iVar7 + 0x940);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Received Cluster Packets");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,&DAT_018dbc90);
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"Received Touch Packets");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,&DAT_018dbc90);
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"MtuSize");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"ElapsedTime");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"MaxPacketLoss");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"TotalInDataBW");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"TotalOutDataBW");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"TotalRakIn");
  FUN_005587e0(uVar6);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar6 = FUN_009ff040(auStack_28,"TotalRakOut");
  FUN_005587e0(uVar6);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_24[1] + -1;
    piStack_24[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar7 = piStack_24[2] + -1;
      piStack_24[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  iVar7 = FUN_006fd830(auStack_18,"OutBufferHealth",piStack_14);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar8 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar7 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar8 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar7 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar7 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 9807 ; VA 0x00700b60 ; FUN_00700b60 */

float10 FUN_00700b60(undefined4 *param_1)

{
  float *pfVar1;
  
  pfVar1 = (float *)(*(code *)*param_1)(param_1[1]);
  return (float10)*pfVar1;
}



/* FUNCTION 9808 ; VA 0x00700b80 ; FUN_00700b80 */

float10 FUN_00700b80(undefined4 *param_1)

{
  double *pdVar1;
  
  pdVar1 = (double *)(*(code *)*param_1)(param_1[1]);
  return (float10)*pdVar1;
}



/* FUNCTION 9809 ; VA 0x00700ba0 ; FUN_00700ba0 */

undefined8 FUN_00700ba0(undefined4 *param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)(*(code *)*param_1)(param_1[1]);
  return *puVar1;
}



/* FUNCTION 9810 ; VA 0x00700bc0 ; FUN_00700bc0 */

undefined FUN_00700bc0(undefined4 *param_1)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(*(code *)*param_1)(param_1[1]);
  return *puVar1;
}



/* FUNCTION 9811 ; VA 0x00700be0 ; FUN_00700be0 */

void FUN_00700be0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9d5e4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<float_const&,float_const&_(__cdecl*)(float_const*),class_boost::_bi::list1<class_boost::_bi::value<float_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9812 ; VA 0x00700c50 ; FUN_00700c50 */

void FUN_00700c50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9d714);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<double_const&,double_const&_(__cdecl*)(double_const*),class_boost::_bi::list1<class_boost::_bi::value<double_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9813 ; VA 0x00700cc0 ; FUN_00700cc0 */

void FUN_00700cc0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9d644);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<unsigned___int64_const&,unsigned___int64_const&_(__cdecl*)(unsigned___int64_const*),class_boost::_bi::list1<class_boost::_bi::value<unsigned___int64_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9814 ; VA 0x00700d30 ; FUN_00700d30 */

void FUN_00700d30(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9d6ac);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<bool_const&,bool_const&_(__cdecl*)(bool_const*),class_boost::_bi::list1<class_boost::_bi::value<bool_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9815 ; VA 0x00700da0 ; FUN_00700da0 */

void __thiscall FUN_00700da0(int param_1,undefined4 param_2,int param_3)

{
  FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    FUN_006fec70(*(undefined4 *)(param_1 + 0x78));
  }
  return;
}



/* FUNCTION 9816 ; VA 0x00700dd0 ; FUN_00700dd0 */

int FUN_00700dd0(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab008;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008a4210(param_1,param_2);
  if (param_2 != 0) {
    iVar3 = FUN_00587490(&iStack_18);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      iVar3 = FUN_006ff610(&iStack_18);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 9817 ; VA 0x00700e60 ; FUN_00700e60 */

undefined4 __thiscall FUN_00700e60(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      if (*(int *)(param_1 + 0x14) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_006ecbd0(*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
    }
  }
  return 1;
}



/* FUNCTION 9818 ; VA 0x00700ed0 ; FUN_00700ed0 */

void FUN_00700ed0(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_5c [36];
  undefined auStack_38 [24];
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab030;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 0x11;
    puVar6[2] = 1;
    puVar6[3] = 0;
    *puVar6 = RBX::Network::DeserializedStatsItem::vftable;
    puVar6[4] = 0;
    puVar6[5] = 0;
  }
  iStack_18 = 0;
  iStack_14 = 0;
  FUN_006fcc30(puVar6,param_2);
  uStack_8 = 0;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar7 = FUN_005edd10();
    iVar5 = iStack_18;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
        (uint)*(ushort *)(iVar7 + 0x1da)) {
      puVar6 = (undefined4 *)FUN_006f22f0(auStack_20,param_3);
      uVar2 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(iVar5 + 0x10) = uVar2;
      piVar4 = *(int **)(iVar5 + 0x14);
      *(undefined4 *)(iVar5 + 0x14) = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[1] + -1;
        piVar4[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar4 = piStack_1c + 2;
          iVar1 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      param_1[1] = iStack_14;
      *param_1 = iVar5;
      ExceptionList = pvStack_10;
      return;
    }
  }
  FUN_0054eff0("Server does not receive this item.");
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_005f8ef0(auStack_38);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c27108);
}



/* FUNCTION 9819 ; VA 0x00701040 ; FUN_00701040 */

int FUN_00701040(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_110 [232];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  char *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab08a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_006abd90();
  if ((char)iVar3 != '\0') {
    uVar4 = FUN_006ac4d0();
    uVar5 = FUN_006ac4d0();
    uStack_1c = FUN_006ac4d0();
    uStack_20 = FUN_006ac4d0();
    uStack_24 = FUN_006ac4d0();
    uStack_28 = FUN_006ac4d0();
    pcStack_18 = "GetAsync";
    uStack_14 = uVar4;
    FUN_006fcb40(&pcStack_18);
    uStack_8._0_1_ = 1;
    FUN_006eb500(&pcStack_18,auStack_110,auStack_110);
    uStack_8._0_1_ = 0;
    FUN_0056cb40();
    pcStack_18 = "Set & IncrementAsync";
    uStack_14 = uVar5;
    FUN_006fcb40(&pcStack_18);
    uStack_8._0_1_ = 2;
    FUN_006eb500(&pcStack_18,auStack_110,auStack_110);
    uStack_8._0_1_ = 0;
    FUN_0056cb40();
    uStack_14 = uStack_1c;
    pcStack_18 = "UpdateAsync";
    FUN_006fcb40(&pcStack_18);
    uStack_8._0_1_ = 3;
    FUN_006eb500(&pcStack_18,auStack_110,auStack_110);
    uStack_8._0_1_ = 0;
    FUN_0056cb40();
    pcStack_18 = "GetSortedAsync";
    uStack_14 = uStack_20;
    FUN_006fcb40(&pcStack_18);
    uStack_8._0_1_ = 4;
    FUN_006eb500(&pcStack_18,auStack_110,auStack_110);
    uStack_8._0_1_ = 0;
    FUN_0056cb40();
    uStack_14 = uStack_24;
    pcStack_18 = "SetIncrementSortedAsync";
    FUN_006fcb40(&pcStack_18);
    uStack_8._0_1_ = 5;
    FUN_006eb500(&pcStack_18,auStack_110,auStack_110);
    uStack_8._0_1_ = 0;
    FUN_0056cb40();
    uStack_14 = uStack_28;
    pcStack_18 = "OnUpdate";
    FUN_006fcb40(&pcStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_006eb500(&pcStack_18,auStack_110,auStack_110);
    iVar3 = FUN_0056cb40();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 9820 ; VA 0x00701290 ; FUN_00701290 */

int FUN_00701290(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  float10 fVar10;
  uint uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined8 uStack_144;
  int iStack_138;
  undefined auStack_134 [200];
  undefined auStack_6c [8];
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  double dStack_4c;
  double dStack_44;
  int aiStack_3c [2];
  char *pcStack_34;
  char *pcStack_30;
  undefined8 uStack_2c;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ab150;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  fVar10 = (float10)FUN_006ac2c0();
  uStack_2c = (double)fVar10;
  pcStack_34 = "totalServerMemory";
  uStack_144 = 0xf00000000;
  uStack_154 = uStack_154 & 0xffffff00;
  uStack_24 = uStack_2c;
  FUN_005542c0("totalServerMemory",0x11);
  iStack_8._0_1_ = 1;
  FUN_006fcaa0(&uStack_2c);
  iStack_8._0_1_ = 2;
  FUN_006eb500(&dStack_44,&uStack_154,&uStack_154);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0056cb40();
  iVar3 = FUN_006ac4d0();
  puVar4 = (undefined *)FUN_01674e20(0x18);
  puStack_14 = puVar4;
  if (puVar4 == (undefined *)0x0) {
    puVar4 = (undefined *)0x0;
  }
  else {
    *puVar4 = 0;
    uVar5 = FUN_00588320(0xb);
    *(undefined4 *)(puVar4 + 4) = uVar5;
    *(undefined4 *)(puVar4 + 8) = 0;
    *(undefined4 *)(puVar4 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar4 + 0x10) = 0;
    *(undefined4 *)(puVar4 + 0x14) = 0;
  }
  uStack_24 = 0.0;
  FUN_005c1af0(puVar4,param_3);
  iVar9 = 0;
  iStack_8._0_1_ = 3;
  if (0 < iVar3) {
    do {
      FUN_006acbd0(aiStack_3c);
      iStack_8._0_1_ = 4;
      fVar10 = (float10)FUN_006ac2c0();
      uStack_1c = (double)fVar10;
      FUN_0054ef60(aiStack_3c);
      uStack_154 = uStack_64;
      dStack_4c = uStack_1c;
      uStack_64 = uStack_64 & 0xffffff00;
      uStack_150 = uStack_60;
      uStack_14c = uStack_5c;
      uStack_148 = uStack_58;
      uStack_144 = CONCAT44(uStack_50,uStack_54);
      uStack_54 = 0;
      uStack_50 = 0xf;
      iStack_8._0_1_ = 6;
      FUN_006fcaa0(&dStack_4c);
      iStack_8._0_1_ = 7;
      FUN_006eb500(&dStack_44,&uStack_154,&uStack_154);
      iStack_8._0_1_ = 8;
      if (iStack_138 != 0) {
        (**(code **)(iStack_138 + 8))(auStack_134);
      }
      iStack_8._0_1_ = 5;
      if (0xf < uStack_144._4_4_) {
        uVar7 = uStack_144._4_4_ + 1;
        uVar8 = uStack_154;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_154 - 4);
          uVar7 = uStack_144._4_4_ + 0x24;
          if (0x1f < (uStack_154 - uVar8) - 4) goto LAB_007018ae;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_144 = 0xf00000000;
      uStack_154 = uStack_154 & 0xffffff00;
      iStack_8._0_1_ = 4;
      if (0xf < uStack_50) {
        uVar7 = uStack_50 + 1;
        uVar8 = uStack_64;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_64 - 4);
          uVar7 = uStack_50 + 0x24;
          if (0x1f < (uStack_64 - uVar8) - 4) goto LAB_007018ae;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      iStack_8._0_1_ = 3;
      if (0xf < uStack_2c._4_4_) {
        uVar8 = (int)uStack_2c._4_4_ + 1;
        iVar6 = aiStack_3c[0];
        if (0xfff < uVar8) {
          iVar6 = *(int *)(aiStack_3c[0] + -4);
          uVar8 = (int)uStack_2c._4_4_ + 0x24;
          if (0x1f < (aiStack_3c[0] - iVar6) - 4U) goto LAB_007018ae;
        }
        FUN_01674ea0(iVar6,uVar8);
      }
      iVar9 = iVar9 + 1;
    } while (iVar9 < iVar3);
  }
  if (uStack_24._4_4_ != (int *)0x0) {
    LOCK();
    *(int *)((int)uStack_24._4_4_ + 4) = *(int *)((int)uStack_24._4_4_ + 4) + 1;
    UNLOCK();
  }
  pcStack_30 = "developerTags";
  uStack_2c = uStack_24;
  uStack_1c = 0.0;
  iStack_8._0_1_ = 10;
  FUN_006ea510(&pcStack_30);
  iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
  FUN_006eb500(&dStack_44,&uStack_154,&uStack_154);
  FUN_0056cb40();
  piVar2 = uStack_2c._4_4_;
  if (uStack_2c._4_4_ != (int *)0x0) {
    LOCK();
    iVar3 = uStack_2c._4_4_[1] + -1;
    uStack_2c._4_4_[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*uStack_2c._4_4_)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  puStack_14 = (undefined *)FUN_006ac4d0();
  puVar4 = (undefined *)FUN_01674e20(0x18);
  uStack_1c = (double)CONCAT44(puVar4,(undefined4)uStack_1c);
  if (puVar4 == (undefined *)0x0) {
    puVar4 = (undefined *)0x0;
  }
  else {
    *puVar4 = 0;
    uVar5 = FUN_00588320(0xb);
    *(undefined4 *)(puVar4 + 4) = uVar5;
    *(undefined4 *)(puVar4 + 8) = 0;
    *(undefined4 *)(puVar4 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar4 + 0x10) = 0;
    *(undefined4 *)(puVar4 + 0x14) = 0;
  }
  uStack_1c = 0.0;
  FUN_005c1af0(puVar4,param_3);
  iVar3 = 0;
  iStack_8._0_1_ = 0xc;
  if (0 < (int)puStack_14) {
    do {
      FUN_006acbd0(aiStack_3c);
      iStack_8._0_1_ = 0xd;
      fVar10 = (float10)FUN_006ac2c0();
      dStack_44 = (double)fVar10;
      FUN_0054ef60(aiStack_3c);
      uStack_154 = uStack_64;
      dStack_4c = dStack_44;
      uStack_64 = uStack_64 & 0xffffff00;
      uStack_150 = uStack_60;
      uStack_14c = uStack_5c;
      uStack_148 = uStack_58;
      uStack_144 = CONCAT44(uStack_50,uStack_54);
      uStack_54 = 0;
      uStack_50 = 0xf;
      iStack_8._0_1_ = 0xf;
      FUN_006fcaa0(&dStack_4c);
      iStack_8._0_1_ = 0x10;
      FUN_006eb500(auStack_6c,&uStack_154,&uStack_154);
      iStack_8._0_1_ = 0x11;
      if (iStack_138 != 0) {
        (**(code **)(iStack_138 + 8))(auStack_134);
      }
      iStack_8._0_1_ = 0xe;
      if (0xf < uStack_144._4_4_) {
        uVar7 = uStack_144._4_4_ + 1;
        uVar8 = uStack_154;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_154 - 4);
          uVar7 = uStack_144._4_4_ + 0x24;
          if (0x1f < (uStack_154 - uVar8) - 4) {
LAB_007018ae:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_144 = 0xf00000000;
      uStack_154 = uStack_154 & 0xffffff00;
      iStack_8._0_1_ = 0xd;
      if (0xf < uStack_50) {
        uVar7 = uStack_50 + 1;
        uVar8 = uStack_64;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_64 - 4);
          uVar7 = uStack_50 + 0x24;
          if (0x1f < (uStack_64 - uVar8) - 4) goto LAB_007018ae;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      iStack_8._0_1_ = 0xc;
      if (0xf < uStack_2c._4_4_) {
        uVar8 = (int)uStack_2c._4_4_ + 1;
        iVar9 = aiStack_3c[0];
        if (0xfff < uVar8) {
          iVar9 = *(int *)(aiStack_3c[0] + -4);
          uVar8 = (int)uStack_2c._4_4_ + 0x24;
          if (0x1f < (aiStack_3c[0] - iVar9) - 4U) goto LAB_007018ae;
        }
        FUN_01674ea0(iVar9,uVar8);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < (int)puStack_14);
  }
  piVar2 = uStack_1c._4_4_;
  puStack_14 = (undefined *)param_2;
  if (uStack_1c._4_4_ != (int *)0x0) {
    LOCK();
    uStack_1c._4_4_[1] = uStack_1c._4_4_[1] + 1;
    UNLOCK();
  }
  pcStack_30 = "internalCategories";
  uStack_2c._0_4_ = SUB84(uStack_1c,0);
  uStack_2c._4_4_ = uStack_1c._4_4_;
  dStack_44 = 0.0;
  iStack_8._0_1_ = 0x13;
  FUN_006ea510(&pcStack_30);
  iStack_8 = CONCAT31(iStack_8._1_3_,0x14);
  FUN_006eb500(auStack_6c,&uStack_154,&uStack_154);
  iVar3 = FUN_0056cb40();
  if (uStack_2c._4_4_ != (int *)0x0) {
    LOCK();
    piVar1 = uStack_2c._4_4_ + 1;
    iVar9 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*uStack_2c._4_4_)();
      LOCK();
      piVar1 = uStack_2c._4_4_ + 2;
      iVar9 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        iVar3 = (**(code **)(*uStack_2c._4_4_ + 4))();
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar9 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar9 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = uStack_24._4_4_;
  if (uStack_24._4_4_ != (int *)0x0) {
    LOCK();
    piVar1 = uStack_24._4_4_ + 1;
    iVar9 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*uStack_24._4_4_)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar9 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar9 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar9 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 9821 ; VA 0x007018c0 ; FUN_007018c0 */

void __fastcall FUN_007018c0(int param_1)

{
  undefined4 uVar1;
  float10 fVar2;
  float fStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab168;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    pcStack_14 = *(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4);
    ExceptionList = &pvStack_10;
    fVar2 = (float10)(*pcStack_14)(param_1 + 0x80);
    fStack_18 = (float)fVar2;
    FUN_009fde50(&fStack_18);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 9822 ; VA 0x00701930 ; FUN_00701930 */

void __fastcall FUN_00701930(int param_1)

{
  undefined4 uVar1;
  float10 fVar2;
  double dStack_1c;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab188;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    pcStack_14 = *(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4);
    ExceptionList = &pvStack_10;
    fVar2 = (float10)(*pcStack_14)(param_1 + 0x80);
    dStack_1c = (double)fVar2;
    FUN_009fde80(&dStack_1c);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 9823 ; VA 0x007019a0 ; FUN_007019a0 */

void __fastcall FUN_007019a0(int param_1)

{
  undefined4 uVar1;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab168;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    uStack_18 = (**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))(param_1 + 0x80);
    FUN_009fdeb0(&uStack_18);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 9824 ; VA 0x00701a10 ; FUN_00701a10 */

void __fastcall FUN_00701a10(int param_1)

{
  undefined4 uVar1;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4f98;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    uStack_11 = (**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))(param_1 + 0x80);
    FUN_009fdee0(&uStack_11);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 9825 ; VA 0x00701a80 ; FUN_00701a80 */

int __fastcall FUN_00701a80(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  float10 fVar7;
  double dVar8;
  undefined8 uStack_30;
  int iStack_28;
  int *piStack_24;
  undefined8 uStack_20;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab1b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar5 = FUN_00587490();
  iVar2 = iStack_28;
  iStack_8 = 0;
  if (iStack_28 != 0) {
    FUN_009ffc10();
    FUN_009ffc10();
    dVar8 = *(double *)(iVar2 + 0x868);
    FUN_009ffd50(*(undefined4 *)(param_1 + 0xe0),SUB84(dVar8,0),(int)((ulonglong)dVar8 >> 0x20),
                 "%.1f%%",dVar8 * DAT_018ce318);
    FUN_009ffc10();
    uStack_20 = *(undefined8 *)(iVar2 + 0x6b8);
    FUN_009fde80();
    iVar5 = *(int *)(param_1 + 0xd8);
    uStack_30 = 0;
    puVar6 = *(undefined4 **)(iVar5 + 0x2c);
    if (puVar6 != (undefined4 *)0x0) {
      piStack_18 = *(int **)(iVar5 + 0x30);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
        piStack_18 = *(int **)(iVar5 + 0x30);
        puVar6 = *(undefined4 **)(iVar5 + 0x2c);
      }
      puVar3 = (undefined4 *)puVar6[1];
      puVar6 = (undefined4 *)*puVar6;
      iStack_8._0_1_ = 1;
      param_1 = iStack_14;
      for (; iStack_14 = param_1, puVar6 != puVar3; puVar6 = puVar6 + 2) {
        if (puVar6[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar6[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_006fea40(*puVar6,puVar6[1],&uStack_30);
        param_1 = iStack_14;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_18[1] + -1;
        piStack_18[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar5 = piStack_18[2] + -1;
          piStack_18[2] = iVar5;
          UNLOCK();
          param_1 = iStack_14;
          if (iVar5 == 0) {
            (**(code **)(*piStack_18 + 4))();
            param_1 = iStack_14;
          }
        }
      }
    }
    FUN_009fde80();
    iVar5 = *(int *)(param_1 + 0xf8);
    uStack_30 = 0;
    puVar6 = *(undefined4 **)(iVar5 + 0x2c);
    if (puVar6 != (undefined4 *)0x0) {
      piStack_18 = *(int **)(iVar5 + 0x30);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
        piStack_18 = *(int **)(iVar5 + 0x30);
        puVar6 = *(undefined4 **)(iVar5 + 0x2c);
      }
      puVar3 = (undefined4 *)puVar6[1];
      puVar6 = (undefined4 *)*puVar6;
      iStack_8._0_1_ = 2;
      for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
        if (puVar6[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar6[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_006fea40(*puVar6,puVar6[1],&uStack_30);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      param_1 = iStack_14;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_18[1] + -1;
        piStack_18[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar5 = piStack_18[2] + -1;
          piStack_18[2] = iVar5;
          UNLOCK();
          param_1 = iStack_14;
          if (iVar5 == 0) {
            (**(code **)(*piStack_18 + 4))();
            param_1 = iStack_14;
          }
        }
      }
    }
    FUN_009fde80();
    iVar2 = iStack_28;
    FUN_009ffc10();
    FUN_009ffc10();
    FUN_009fde80();
    FUN_009ffc10();
    dVar8 = *(double *)(iVar2 + 0xa60);
    FUN_009ffd50(*(undefined4 *)(param_1 + 0x150),SUB84(dVar8,0),(int)((ulonglong)dVar8 >> 0x20),
                 "%.1f%%",dVar8 * DAT_018ce318);
    FUN_009ffc10();
    FUN_009ffc10();
    FUN_009fde80();
    if (DAT_01d5be00 != '\0') {
      FUN_009fde80();
    }
    FUN_009ffc10();
    FUN_009ffc10();
    iVar5 = FUN_009fde80();
    if (*(int *)(iVar2 + 0x6c) != 0) {
      uVar4 = *(undefined4 *)(param_1 + 0xb0);
      fVar7 = (float10)FUN_006af930(*(undefined4 *)(iStack_28 + 0x74),
                                    *(undefined4 *)(iStack_28 + 0x78),
                                    *(undefined4 *)(iStack_28 + 0x7c),
                                    *(undefined4 *)(iStack_28 + 0x80),
                                    *(undefined4 *)(iStack_28 + 0x84),
                                    *(undefined4 *)(iStack_28 + 0x88),
                                    *(undefined4 *)(iStack_28 + 0x8c),
                                    *(undefined4 *)(iStack_28 + 0x90));
      FUN_009ffd50(uVar4,(double)fVar7,"%.1f%%",(double)fVar7 * DAT_018ce318);
      uVar4 = *(undefined4 *)(param_1 + 0xb8);
      fVar7 = (float10)FUN_006afa80(*(undefined4 *)(iStack_28 + 0x74),
                                    *(undefined4 *)(iStack_28 + 0x78),
                                    *(undefined4 *)(iStack_28 + 0x7c),
                                    *(undefined4 *)(iStack_28 + 0x80),
                                    *(undefined4 *)(iStack_28 + 0x84),
                                    *(undefined4 *)(iStack_28 + 0x88),
                                    *(undefined4 *)(iStack_28 + 0x8c),
                                    *(undefined4 *)(iStack_28 + 0x90));
      FUN_009ffd50(uVar4,(double)fVar7,"%.1f%%",(double)fVar7 * DAT_018ce318);
      dVar8 = (double)*(int *)(iStack_28 + 0xe30);
      FUN_009ffd50(*(undefined4 *)(param_1 + 0x90),dVar8,"%d avg:%d best:%d",
                   *(int *)(iStack_28 + 0xe30),*(undefined4 *)(iStack_28 + 0xe2c),
                   *(undefined4 *)(iStack_28 + 0xe34));
      FUN_009fdde0();
      FUN_006a6920();
      FUN_016f3fe0();
      piStack_18 = (int *)((float)dVar8 / DAT_018d0938);
      FUN_009fde50();
      piStack_18 = (int *)FUN_00620890();
      FUN_009fde10();
      piStack_18 = (int *)FUN_0054db20();
      FUN_009fde10();
      FUN_009fde80();
      piStack_18 = *(int **)(iStack_28 + 0x1f20);
      FUN_009fde10();
      FUN_009ff7e0();
      FUN_009fde50();
      FUN_009fdeb0();
      FUN_009fdeb0();
      FUN_009fdeb0();
      iVar5 = FUN_009fdeb0();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9826 ; VA 0x00702070 ; FUN_00702070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00702070(int param_1,float param_2)

{
  int *piVar1;
  short sVar2;
  int iVar3;
  double *pdVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined4 uVar9;
  int iVar10;
  float fVar11;
  float fVar12;
  double dVar13;
  undefined4 uVar14;
  double dVar15;
  undefined auStack_a8 [8];
  undefined auStack_a0 [8];
  undefined auStack_98 [8];
  undefined auStack_90 [8];
  undefined auStack_88 [8];
  int aiStack_80 [5];
  uint uStack_6c;
  double dStack_68;
  double dStack_60;
  undefined8 uStack_58;
  double dStack_50;
  undefined8 uStack_48;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  undefined8 uStack_1c;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab1d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_006b2070(param_2,0x11);
  iVar10 = *(int *)(param_1 + 0x10);
  fVar11 = 0.0;
  uVar9 = 0;
  fVar12 = 0.0;
  uVar14 = 0;
  fStack_38 = 0.0;
  fStack_3c = 0.0;
  fStack_2c = 0.0;
  fStack_34 = 0.0;
  fStack_40 = 0.0;
  fStack_30 = 0.0;
  piVar8 = *(int **)(*(int *)(iVar10 + 0x34) + 0x2c);
  dStack_68 = 0.0;
  cStack_12 = '\x01';
  dStack_60 = 0.0;
  piVar1 = (int *)piVar8[1];
  piVar8 = (int *)*piVar8;
  cStack_11 = '\x01';
  if (piVar8 != piVar1) {
    do {
      iVar10 = *piVar8;
      uStack_1c = (double)CONCAT44(iVar10,(undefined4)uStack_1c);
      if ((iVar10 != 0) &&
         (iVar10 = *(int *)(iVar10 + 0xc), iVar3 = FUN_005ee170(),
         (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        pdVar4 = (double *)FUN_016827a0(auStack_88);
        iVar10 = uStack_1c._4_4_;
        dVar15 = *pdVar4 - *(double *)(uStack_1c._4_4_ + 0x9d0);
        uStack_28 = *(double *)(uStack_1c._4_4_ + 0x9f0);
        if (((*(char **)(uStack_1c._4_4_ + 0xa08) == (char *)0x0) ||
            (**(char **)(uStack_1c._4_4_ + 0xa08) == '\0')) && (uStack_28 + uStack_28 < dVar15)) {
          uStack_28 = dVar15;
        }
        dVar13 = 0.0;
        if (0.0 < uStack_28) {
          dVar13 = DAT_018c0d60 / uStack_28;
        }
        fStack_38 = (float)dVar13 + fStack_38;
        uStack_1c = dVar15;
        pdVar4 = (double *)FUN_016827a0(auStack_90);
        uStack_48 = *(double *)(iVar10 + 0x838);
        dVar15 = *pdVar4 - *(double *)(iVar10 + 0x818);
        if (((*(char **)(iVar10 + 0x850) == (char *)0x0) || (**(char **)(iVar10 + 0x850) == '\0'))
           && (uStack_48 + uStack_48 < dVar15)) {
          uStack_48 = dVar15;
        }
        dVar15 = 0.0;
        if (0.0 < uStack_48) {
          dVar15 = DAT_018c0d60 / uStack_48;
        }
        fStack_3c = (float)dVar15 + fStack_3c;
        uStack_58 = (double)(float)*(double *)(iVar10 + 0x890);
        uStack_1c = uStack_58;
        sVar2 = FUN_017265ed(&uStack_58);
        if (sVar2 < 1) {
          if (cStack_11 == '\0') {
            dStack_60 = dStack_60 * _DAT_018e2ee8 + uStack_1c * DAT_018ce300;
          }
          else {
            dStack_60 = uStack_1c;
          }
          cStack_11 = '\0';
        }
        pdVar4 = (double *)FUN_016827a0(auStack_98);
        dStack_50 = *(double *)(iVar10 + 0x9f0);
        dVar15 = *pdVar4 - *(double *)(iVar10 + 0x9d0);
        if (((*(char **)(iVar10 + 0xa08) == (char *)0x0) || (**(char **)(iVar10 + 0xa08) == '\0'))
           && (dStack_50 + dStack_50 < dVar15)) {
          dStack_50 = dVar15;
        }
        dVar15 = 0.0;
        if (0.0 < dStack_50) {
          dVar15 = DAT_018c0d60 / dStack_50;
        }
        fStack_2c = (float)dVar15 + fStack_2c;
        uStack_58 = (double)(float)*(double *)(iVar10 + 0xa88);
        uStack_1c = uStack_58;
        sVar2 = FUN_017265ed(&uStack_58);
        if (sVar2 < 1) {
          if (cStack_12 == '\0') {
            dStack_68 = dStack_68 * _DAT_018e2ee8 + uStack_1c * DAT_018ce300;
          }
          else {
            dStack_68 = uStack_1c;
          }
          cStack_12 = '\0';
        }
        fStack_34 = (float)*(double *)(iVar10 + 0x980) + fStack_34;
        pdVar4 = (double *)FUN_016827a0(auStack_a0);
        if (*(double *)(iVar10 + 0x8d8) < *pdVar4 - *(double *)(iVar10 + 0x8d0)) {
          iVar3 = 0;
        }
        else {
          iVar3 = *(int *)(iVar10 + 0x8e0);
        }
        fStack_40 = (float)iVar3 + fStack_40;
        pdVar4 = (double *)FUN_016827a0(auStack_a8);
        if (*(double *)(iVar10 + 0x8f0) < *pdVar4 - *(double *)(iVar10 + 0x8e8)) {
          iVar10 = 0;
        }
        else {
          iVar10 = *(int *)(iVar10 + 0x8f8);
        }
        fVar11 = (float)iVar10 + fStack_30;
        uVar9 = 0;
        fStack_30 = fVar11;
      }
      piVar8 = piVar8 + 2;
    } while (piVar8 != piVar1);
    iVar10 = *(int *)(iStack_20 + 0x10);
    param_1 = iStack_20;
    fVar12 = fVar11;
    uVar14 = uVar9;
  }
  piVar1 = *(int **)(*(int *)(iVar10 + 0x34) + 0x2c);
  if (piVar1 == (int *)0x0) {
    iVar3 = 0;
  }
  else {
    iVar3 = piVar1[1] - *piVar1 >> 3;
  }
  uVar5 = FUN_008f7870(iVar10);
  iVar10 = *(int *)(param_1 + 0x30);
  uStack_28 = (double)CONCAT44(uVar5,(undefined4)uStack_28);
  uVar9 = param_2;
  if (2 < iVar10) {
    uStack_1c = (double)CONCAT44(iVar10,(undefined4)uStack_1c);
    FUN_006a5c10((int)&uStack_1c + 4,(int)&uStack_48 + 4,4);
    uVar9 = param_2;
    FUN_006ad5e0((int)&uStack_48 + 4,4);
    iVar10 = *(int *)(iStack_20 + 0x30);
  }
  if (iVar10 < 5) {
    if (iVar10 == 4) {
      FUN_01522960();
      FUN_016f3fe0();
      uStack_58 = (double)CONCAT44(uVar14,fVar12);
      FUN_006a5c10(&uStack_58,&dStack_50,8);
      FUN_006ad5e0(&dStack_50,8);
      uStack_48 = (double)CONCAT44(0x16,(undefined4)uStack_48);
      FUN_006a5c10((int)&uStack_48 + 4,(int)&uStack_1c + 4,4);
      FUN_006ad5e0((int)&uStack_1c + 4,4);
      FUN_00ccdf90();
      iVar10 = 0;
      do {
        if (iVar10 != 0) {
          iVar6 = FUN_00cce020(iVar10);
          FUN_00cce030(aiStack_80,iVar10);
          uStack_8 = 0;
          FUN_006ae570(aiStack_80);
          uStack_58 = (double)iVar6 + (double)(&DAT_018c0d90)[-(iVar6 >> 0x1f)];
          FUN_006a5c10(&uStack_58,&dStack_50,8);
          FUN_006ad5e0(&dStack_50,8);
          uStack_8 = 0xffffffff;
          if (0xf < uStack_6c) {
            uVar7 = uStack_6c + 1;
            iVar6 = aiStack_80[0];
            if (0xfff < uVar7) {
              iVar6 = *(int *)(aiStack_80[0] + -4);
              uVar7 = uStack_6c + 0x24;
              if (0x1f < (aiStack_80[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar6,uVar7);
          }
        }
        iVar10 = iVar10 + 1;
      } while (iVar10 < 0x17);
      uVar5 = uStack_28._4_4_;
    }
  }
  else {
    FUN_00702b20(uVar9);
  }
  uVar14 = param_2;
  iVar10 = *(int *)(iStack_20 + 0x30);
  if (2 < iVar10) {
    FUN_00702710(uVar5,param_2);
    iVar10 = *(int *)(iStack_20 + 0x30);
  }
  if (1 < iVar10) {
    FUN_00702e90(uVar5,uVar14);
    FUN_00702900(uVar5,uVar14);
    iVar10 = *(int *)(iStack_20 + 0x30);
  }
  if (0 < iVar10) {
    param_2 = fStack_34 / (float)iVar3;
    FUN_006a5c10(&param_2,(int)&uStack_28 + 4,4);
    FUN_006ad5e0((int)&uStack_28 + 4,4);
    param_2 = fStack_38 / (float)iVar3;
    FUN_006a5c10(&param_2,(int)&uStack_28 + 4,4);
    FUN_006ad5e0((int)&uStack_28 + 4,4);
    param_2 = ((float)dStack_60 * fStack_3c) / DAT_018ce324;
    FUN_006a5c10(&param_2,(int)&uStack_28 + 4,4);
    FUN_006ad5e0((int)&uStack_28 + 4,4);
    param_2 = ((float)dStack_68 * fStack_2c) / DAT_018ce324;
    FUN_006a5c10(&param_2,(int)&uStack_28 + 4,4);
    FUN_006ad5e0((int)&uStack_28 + 4,4);
    fStack_30 = fStack_30 / fStack_40;
    FUN_006a5c10(&fStack_30,&fStack_2c,4);
    FUN_006ad5e0(&fStack_2c,4);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9827 ; VA 0x00702710 ; FUN_00702710 */

void FUN_00702710(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined auStack_8 [4];
  
  FUN_005789c0(&DAT_01eaf628,&LAB_006fd170);
  uVar3 = FUN_006fdc20();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00cce470();
    piVar5 = (int *)FUN_008a9ba0(auStack_10,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_c[1] + -1;
      piStack_c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar5 = piStack_c + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
  }
  if (*piVar4 != 0) {
    param_1 = CONCAT31(param_1._1_3_,1);
    FUN_006ad5e0(&param_1,1);
    param_1 = FUN_00cd4820(0);
    FUN_006a5c10(&param_1,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    param_1 = FUN_00cd4820(1);
    FUN_006a5c10(&param_1,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    param_1 = FUN_00cd4820(2);
    FUN_006a5c10(&param_1,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    param_1 = FUN_00cd4820(3);
    FUN_006a5c10(&param_1,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    param_1 = FUN_00cd4820(4);
    FUN_006a5c10(&param_1,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    param_1 = FUN_00cd4820(5);
    FUN_006a5c10(&param_1,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    return;
  }
  param_1 = (uint)param_1._1_3_ << 8;
  FUN_006ad5e0(&param_1,1);
  return;
}



/* FUNCTION 9828 ; VA 0x00702900 ; FUN_00702900 */

void FUN_00702900(float param_1)

{
  double *pdVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  double *pdVar8;
  double *pdStack_28;
  double *pdStack_24;
  int iStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab200;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
  uVar4 = FUN_00560dc0();
  piVar5 = (int *)FUN_008aa140(uVar4);
  if (*piVar5 == 0) {
    uVar4 = FUN_0093f210();
    piVar6 = (int *)FUN_008a9ba0(auStack_1c,uVar4);
    iVar2 = *piVar6;
    iVar3 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    *piVar5 = iVar2;
    piVar6 = (int *)piVar5[1];
    piVar5[1] = iVar3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar5 = piStack_18 + 2;
        iVar2 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  uStack_8 = 0;
  FUN_0095c4a0(1);
  pdStack_28 = (double *)0x0;
  pdStack_24 = (double *)0x0;
  iStack_20 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_009508c0(&pdStack_28);
  if (pdStack_28 != pdStack_24) {
    pdVar8 = pdStack_28 + 8;
    do {
      param_1 = (float)((uint)param_1 & 0xffffff00);
      FUN_006ad5e0(&param_1,1);
      FUN_006ae570(pdVar8 + -5);
      param_1 = (float)*pdVar8;
      FUN_006a5c10(&param_1,auStack_14,4);
      FUN_006ad5e0(auStack_14,4);
      param_1 = *(float *)(pdVar8 + 1);
      FUN_006a5c10(&param_1,&piStack_18,4);
      FUN_006ad5e0(&piStack_18,4);
      pdVar1 = pdVar8 + 2;
      pdVar8 = pdVar8 + 10;
    } while (pdVar1 != pdStack_24);
  }
  param_1 = (float)CONCAT31(param_1._1_3_,1);
  FUN_006ad5e0(&param_1,1);
  pdVar1 = pdStack_24;
  pdVar8 = pdStack_28;
  if (pdStack_28 != (double *)0x0) {
    for (; pdVar8 != pdVar1; pdVar8 = pdVar8 + 10) {
      FUN_006fe4e0();
    }
    uVar7 = ((iStack_20 - (int)pdStack_28) / 0x50) * 0x50;
    pdVar8 = pdStack_28;
    if (0xfff < uVar7) {
      pdVar8 = *(double **)((int)pdStack_28 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)pdStack_28 + (-4 - (int)pdVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pdVar8,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9829 ; VA 0x00702b20 ; FUN_00702b20 */

void FUN_00702b20(void)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  double in_XMM0_Qa;
  uint uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  double dStack_88;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  double dStack_68;
  undefined8 uStack_60;
  undefined auStack_58 [8];
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined uStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017ab23b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01522960();
  FUN_016f3fe0();
  uStack_18 = in_XMM0_Qa;
  FUN_006a5c10(&uStack_18,auStack_20,8);
  FUN_006ad5e0(auStack_20,8);
  uStack_1c = 0x16;
  FUN_006a5c10(&uStack_1c,(int)&uStack_18 + 4,4);
  FUN_006ad5e0((int)&uStack_18 + 4,4);
  FUN_00ccdf90();
  iVar10 = 0;
  do {
    if (iVar10 != 0) {
      iVar3 = FUN_00cce020(iVar10);
      FUN_00cce030(auStack_50,iVar10);
      uStack_8 = 0;
      FUN_006ae570(auStack_50);
      uStack_18 = (double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)];
      FUN_006a5c10(&uStack_18,auStack_20,8);
      FUN_006ad5e0(auStack_20,8);
      uStack_8._0_1_ = 0xff;
      uStack_8._1_3_ = 0xffffff;
      if (0xf < uStack_3c) {
        uVar6 = uStack_3c + 1;
        uVar8 = auStack_50[0];
        if (0xfff < uVar6) {
          uVar8 = *(uint *)(auStack_50[0] - 4);
          uVar6 = uStack_3c + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (auStack_50[0] - uVar8) - 4) goto LAB_00702e84;
        }
        FUN_01674ea0(uVar8,uVar6);
      }
    }
    iVar10 = iVar10 + 1;
  } while (iVar10 < 0x17);
  uStack_38 = 0;
  iStack_34 = FUN_00588320(0xb);
  iStack_30 = 0;
  uStack_2c = 0x3f800000;
  uStack_28 = 0;
  iStack_24 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar8 = 0;
  iVar10 = FUN_01675020();
  if (iVar10 != 0) {
    do {
      iVar10 = FUN_01675030(uVar8);
      if (iVar10 == 0) {
        pcVar4 = (char *)FUN_01675050(uVar8);
        uStack_40 = 0;
        uStack_3c = 0xf;
        auStack_50[0] = auStack_50[0] & 0xffffff00;
        pcVar5 = pcVar4;
        do {
          cVar1 = *pcVar5;
          pcVar5 = pcVar5 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(pcVar4,(int)pcVar5 - (int)(pcVar4 + 1));
        uStack_8._0_1_ = 2;
        iVar10 = FUN_016750a0(uVar8);
        uStack_18 = (double)iVar10 + (double)(&DAT_018c0d90)[-(iVar10 >> 0x1f)];
        FUN_0054ef60(auStack_50);
        uStack_a0 = uStack_80;
        dStack_68 = uStack_18;
        uStack_80 = uStack_80 & 0xffffff00;
        dStack_88 = uStack_18;
        uStack_9c = uStack_7c;
        uStack_98 = uStack_78;
        uStack_94 = uStack_74;
        uStack_90 = CONCAT44(uStack_6c,uStack_70);
        uStack_70 = 0;
        uStack_6c = 0xf;
        uStack_8._0_1_ = 4;
        FUN_006fdca0(auStack_58,&uStack_a0,&uStack_a0);
        uStack_8._0_1_ = 3;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 3;
        if (0xf < uStack_90._4_4_) {
          uVar7 = uStack_90._4_4_ + 1;
          uVar6 = uStack_a0;
          if (0xfff < uVar7) {
            uVar6 = *(uint *)(uStack_a0 - 4);
            uVar7 = uStack_90._4_4_ + 0x24;
            if (0x1f < (uStack_a0 - uVar6) - 4) {
LAB_00702e84:
              uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar6,uVar7);
        }
        uStack_8._0_1_ = 1;
        if (0xf < uStack_3c) {
          uVar7 = uStack_3c + 1;
          uVar6 = auStack_50[0];
          if (0xfff < uVar7) {
            uVar6 = *(uint *)(auStack_50[0] - 4);
            uVar7 = uStack_3c + 0x24;
            uVar2 = (undefined)uStack_8;
            if (0x1f < (auStack_50[0] - uVar6) - 4) goto LAB_00702e84;
          }
          FUN_01674ea0(uVar6,uVar7);
        }
      }
      uVar8 = uVar8 + 1;
      uVar6 = FUN_01675020();
    } while (uVar8 < uVar6);
  }
  uStack_18 = (double)CONCAT44(iStack_30,(undefined4)uStack_18);
  FUN_006a5c10((int)&uStack_18 + 4,&uStack_1c,4);
  FUN_006ad5e0(&uStack_1c,4);
  if (iStack_30 == 0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(iStack_24 + iStack_34 * 4);
  }
  for (; puVar9 != (undefined4 *)0x0; puVar9 = (undefined4 *)*puVar9) {
    FUN_006ae570(puVar9 + 2);
    uStack_60 = *(undefined8 *)(puVar9 + 8);
    FUN_006a5c10(&uStack_60,auStack_58,8);
    FUN_006ad5e0(auStack_58,8);
  }
  FUN_00640d60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9830 ; VA 0x00702e90 ; FUN_00702e90 */

/* WARNING: Removing unreachable block (ram,0x00702ffb) */

void FUN_00702e90(int param_1)

{
  float *pfVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  float *pfVar5;
  bool bVar6;
  float10 fVar7;
  float *pfStack_38;
  float *pfStack_34;
  int iStack_30;
  float fStack_2c;
  int *piStack_28;
  undefined8 uStack_24;
  undefined auStack_1c [4];
  float fStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab268;
  pvStack_10 = ExceptionList;
  pfStack_38 = (float *)0x0;
  pfStack_34 = (float *)0x0;
  iStack_30 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0151da40(&pfStack_38);
  FUN_00588320(0xb);
  uStack_8._0_1_ = 1;
  if (pfStack_38 != pfStack_34) {
    pfVar5 = pfStack_38;
    do {
      piVar4 = (int *)pfVar5[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = (int *)pfVar5[1];
      }
      fStack_2c = *pfVar5;
      uStack_8._0_1_ = 2;
      piStack_28 = piVar4;
      fStack_18 = fStack_2c;
      if (*(uint *)((int)fStack_2c + 0x28) == (-(uint)(param_1 != 0) & param_1 + 8U)) {
        iVar2 = FUN_006fe610((int)fStack_2c + 0x10);
        fVar7 = (float10)FUN_01523050();
        uStack_24 = (double)fVar7;
        *(double *)(iVar2 + 0x18) = uStack_24 + *(double *)(iVar2 + 0x18);
        fVar7 = (float10)FUN_01523100();
        uStack_24 = (double)fVar7;
        *(double *)(iVar2 + 0x20) = uStack_24 + *(double *)(iVar2 + 0x20);
        fVar7 = (float10)FUN_015230f0();
        *(int *)(iVar2 + 0x30) = *(int *)(iVar2 + 0x30) + 1;
        uStack_8._0_1_ = 1;
        uStack_24 = (double)fVar7;
        *(double *)(iVar2 + 0x28) = uStack_24 + *(double *)(iVar2 + 0x28);
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar2 = piVar4[1] + -1;
          piVar4[1] = iVar2;
          UNLOCK();
          goto joined_r0x00702fcd;
        }
      }
      else {
        uStack_8._0_1_ = 1;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar2 = piVar4[1] + -1;
          piVar4[1] = iVar2;
          UNLOCK();
joined_r0x00702fcd:
          uStack_8._0_1_ = 1;
          if (iVar2 == 0) {
            uStack_8._0_1_ = 1;
            (**(code **)*piVar4)();
            LOCK();
            iVar2 = piVar4[2] + -1;
            piVar4[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      pfVar5 = pfVar5 + 2;
    } while (pfVar5 != pfStack_34);
  }
  piVar4 = (int *)0x0;
  bVar6 = false;
  while (bVar6) {
    auStack_14[0] = 0;
    FUN_006ad5e0(auStack_14,1);
    FUN_006ae570(piVar4 + 2);
    fStack_18 = (float)(*(double *)(piVar4 + 8) / (double)piVar4[0xe]);
    FUN_006a5c10(&fStack_18,auStack_1c,4);
    FUN_006ad5e0(auStack_1c,4);
    fStack_18 = (float)(*(double *)(piVar4 + 10) / (double)piVar4[0xe]);
    FUN_006a5c10(&fStack_18,(int)&uStack_24 + 4,4);
    FUN_006ad5e0((int)&uStack_24 + 4,4);
    fStack_18 = (float)(*(double *)(piVar4 + 0xc) / (double)piVar4[0xe]);
    FUN_006a5c10(&fStack_18,&piStack_28,4);
    FUN_006ad5e0(&piStack_28,4);
    piVar4 = (int *)*piVar4;
    bVar6 = piVar4 != (int *)0x0;
  }
  auStack_14[0] = 1;
  FUN_006ad5e0(auStack_14,1);
  FUN_006784e0();
  pfVar1 = pfStack_34;
  pfVar5 = pfStack_38;
  if (pfStack_38 != (float *)0x0) {
    for (; pfVar5 != pfVar1; pfVar5 = pfVar5 + 2) {
      piVar4 = (int *)pfVar5[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar2 = piVar4[2] + -1;
          piVar4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    uVar3 = iStack_30 - (int)pfStack_38 & 0xfffffff8;
    pfVar5 = pfStack_38;
    if (0xfff < uVar3) {
      pfVar5 = (float *)pfStack_38[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)pfStack_38 + (-4 - (int)pfVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pfVar5,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9831 ; VA 0x00703190 ; FUN_00703190 */

void __thiscall FUN_00703190(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab280;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedTagItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9832 ; VA 0x007031fe ; Catch_All@007031fe */

void Catch_All_007031fe(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9833 ; VA 0x00703220 ; FUN_00703220 */

undefined4 * __thiscall
FUN_00703220(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab2a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::Replicator::TagItem::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[0xe] = 0;
  if (param_4 != 0) {
    param_1[0xe] = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,param_1 + 0x10,0);
    }
    else {
      param_1[0x10] = param_6;
      param_1[0x11] = param_7;
      param_1[0x12] = param_8;
      param_1[0x13] = param_9;
      *(undefined8 *)(param_1 + 0x14) = param_10;
    }
  }
  uStack_8 = 2;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9834 ; VA 0x007032e0 ; FUN_007032e0 */

undefined4 * __thiscall FUN_007032e0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[0xe];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    param_1[0xe] = 0;
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9835 ; VA 0x00703360 ; FUN_00703360 */

undefined4 __thiscall FUN_00703360(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_006f35a0(param_1);
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  FUN_0054eff0("Server does not receive this item.");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 9836 ; VA 0x00703400 ; FUN_00703400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00703400(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab2b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 0x10;
    puVar1[2] = 1;
    puVar1[3] = 0;
    *puVar1 = RBX::Network::DeserializedTagItem::vftable;
  }
  FUN_00703190(puVar1,param_1);
  uStack_8 = 0;
  _DAT_00000010 = FUN_006ac4d0();
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9837 ; VA 0x007034a0 ; FUN_007034a0 */

undefined __thiscall FUN_007034a0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(uint *)(param_1 + 0x38) != 0) &&
     (ExceptionList = &pvStack_10,
     cVar1 = (**(code **)((*(uint *)(param_1 + 0x38) & 0xfffffffe) + 4))(param_1 + 0x40),
     cVar1 == '\0')) {
    ExceptionList = pvStack_10;
    return 0;
  }
  iVar2 = *(int *)(param_1 + 0x30);
  if ((iVar2 != 0xe) && ((*(int *)(*(int *)(param_1 + 0x10) + 0x1de4) == 0 || (iVar2 != 0xf)))) {
    FUN_006b2070(param_2,0x10);
    if ((DAT_01d5aed0 != '\0') && (*(int *)(param_1 + 0x30) == 0xd)) {
      *(undefined *)(param_1 + 0x20) = 1;
    }
    uStack_14 = *(undefined4 *)(param_1 + 0x30);
    FUN_006a5c10(&uStack_14,auStack_18,4);
    FUN_006ad5e0(auStack_18,4);
    iVar2 = *(int *)(param_1 + 0x30);
  }
  (**(code **)(**(int **)(param_1 + 0x10) + 0x184))(iVar2);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9838 ; VA 0x00703570 ; FUN_00703570 */

undefined4 * __fastcall FUN_00703570(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798678;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Network::Marker,class_RBX::Instance>::vftable;
  uVar1 = FUN_005eded0();
  param_1[3] = uVar1;
  *param_1 = RBX::Network::Marker::vftable;
  LOCK();
  UNLOCK();
  iVar2 = DAT_01eaf690 + 1;
  DAT_01eaf690 = DAT_01eaf690 + 1;
  param_1[0x15] = iVar2;
  param_1[0x16] = 0;
  *(undefined *)((int)param_1 + 0x22) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9839 ; VA 0x007035e0 ; FUN_007035e0 */

undefined4 __thiscall FUN_007035e0(undefined4 param_1,byte param_2)

{
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 9840 ; VA 0x00703610 ; FUN_00703610 */

undefined4 * __thiscall
FUN_00703610(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab301;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_007037b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9841 ; VA 0x007037b0 ; FUN_007037b0 */

void FUN_007037b0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab320;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  piStack_20 = (int *)0x0;
  piStack_1c = (int *)0x0;
  iStack_18 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_14 = uVar2;
  (**(code **)(**(int **)(param_1 + 0x18) + 4))(&piStack_20);
  piVar5 = piStack_1c;
  if (piStack_20 != (int *)0x0) {
    if (piStack_20 != piStack_1c) {
      piVar4 = piStack_20 + 1;
      do {
        uStack_8._0_1_ = 2;
        if (*piVar4 != 0) {
          (**(code **)(*piVar4 + 8))(piVar4 + 1);
        }
        piVar1 = piVar4 + 0x33;
        piVar4 = piVar4 + 0x34;
      } while (piVar1 != piVar5);
    }
    uStack_8._0_1_ = 0;
    uVar3 = ((iStack_18 - (int)piStack_20) / 0xd0) * 0xd0;
    piVar5 = piStack_20;
    if (0xfff < uVar3) {
      piVar5 = (int *)piStack_20[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)piStack_20 + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar5,uVar3);
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    iStack_18 = 0;
  }
  uStack_8 = 3;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9842 ; VA 0x007038e0 ; FUN_007038e0 */

void FUN_007038e0(void)

{
  FUN_006eccd0();
  return;
}



/* FUNCTION 9843 ; VA 0x00703900 ; FUN_00703900 */

void FUN_00703900(void)

{
  FUN_006eccd0();
  return;
}



/* FUNCTION 9844 ; VA 0x00703910 ; thunk_FUN_005ee490 */

void thunk_FUN_005ee490(void)

{
  int iVar1;
  
  if (DAT_01ea9f54 == 0) {
    iVar1 = FUN_005eded0();
    DAT_01ea9f54 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 9845 ; VA 0x00703920 ; FUN_00703920 */

int __thiscall FUN_00703920(int *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab338;
  pvStack_10 = ExceptionList;
  iVar8 = (int)param_2 - *param_1 >> 4;
  iVar3 = param_1[1] - *param_1 >> 4;
  if (iVar3 == 0xfffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar7 = param_1[2] - *param_1 >> 4;
  uVar4 = uVar1;
  if ((uVar7 <= 0xfffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar1)) {
    uVar4 = uVar1;
  }
  uVar7 = uVar4 << 4;
  if (uVar4 < 0x10000000) {
    if (0xfff < uVar7) goto LAB_007039b5;
    if (uVar7 == 0) {
      puVar10 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar10 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_007039b5:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar5);
    if (iVar3 == 0) goto LAB_00703b4f;
    puVar10 = (undefined4 *)(iVar3 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar3;
  }
  puVar11 = puVar10 + iVar8 * 4;
  *puVar11 = 0;
  puVar11[1] = 0;
  puVar11[2] = 0;
  puVar11[3] = 0;
  puVar11[2] = 0;
  puVar11[3] = 0;
  puVar11[1] = 0;
  puVar2 = (undefined4 *)param_1[1];
  uStack_8 = 0;
  if (param_2 == puVar2) {
    puVar11 = (undefined4 *)*param_1;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    puVar9 = puVar10;
    for (; puVar11 != puVar2; puVar11 = puVar11 + 4) {
      *puVar9 = *puVar11;
      FUN_006d0520(puVar11 + 1);
      puVar9 = puVar9 + 4;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00602e50(puVar9,puVar9,param_1);
  }
  else {
    FUN_00704000(*param_1,param_2,puVar10);
    FUN_00704000(param_2,param_1[1],puVar11 + 4);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00602e50(*param_1,param_1[1],param_1);
    iVar3 = *param_1;
    uVar7 = param_1[2] - iVar3 & 0xfffffff0;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) {
LAB_00703b4f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + uVar1 * 4);
  param_1[2] = (int)(puVar10 + uVar4 * 4);
  ExceptionList = pvStack_10;
  return *param_1 + iVar8 * 0x10;
}



/* FUNCTION 9846 ; VA 0x00703b25 ; Catch_All@00703b25 */

void Catch_All_00703b25(void)

{
  int unaff_EBP;
  
  FUN_00616f20(*(undefined4 *)(unaff_EBP + -0x28),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0061a3e0(*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9847 ; VA 0x00703b60 ; FUN_00703b60 */

int __thiscall FUN_00703b60(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar7 = *param_1;
  iVar3 = (int)(param_1[1] - *param_1) / 0x18;
  if (iVar3 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - *param_1) / 0x18;
  uVar4 = uVar1;
  if ((uVar5 <= 0xaaaaaaa - (uVar5 >> 1)) && (uVar4 = (uVar5 >> 1) + uVar5, uVar4 < uVar1)) {
    uVar4 = uVar1;
  }
  uVar5 = uVar4 * 0x18;
  if (uVar4 < 0xaaaaaab) {
    uVar4 = uVar5;
    if (0xfff < uVar5) goto LAB_00703bfc;
    if (uVar5 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar4 = 0xffffffff;
LAB_00703bfc:
    uVar2 = uVar4 + 0x23;
    if (uVar2 <= uVar4) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00703d4c;
    uVar4 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar4 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar7) / 0x18) * 0x18;
  FUN_00703d60(param_1,uVar4 + iVar3,param_3);
  uVar7 = param_1[1];
  uVar2 = *param_1;
  if (param_2 == uVar7) {
    for (; uVar2 != uVar7; uVar2 = uVar2 + 0x18) {
      FUN_00703ee0(uVar2);
    }
  }
  else {
    if (uVar2 != param_2) {
      do {
        FUN_00703ee0(uVar2);
        uVar2 = uVar2 + 0x18;
      } while (uVar2 != param_2);
      uVar7 = param_1[1];
    }
    if (param_2 != uVar7) {
      do {
        FUN_00703ee0(param_2);
        param_2 = param_2 + 0x18;
      } while (param_2 != uVar7);
    }
  }
  uVar7 = *param_1;
  if (uVar7 != 0) {
    uVar2 = param_1[1];
    if (uVar7 != uVar2) {
      do {
        FUN_0056b650();
        uVar7 = uVar7 + 0x18;
      } while (uVar7 != uVar2);
      uVar7 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar7) / 0x18) * 0x18;
    uVar2 = uVar7;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar7 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar7 - uVar2) - 4) {
LAB_00703d4c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar4;
  param_1[1] = uVar4 + uVar1 * 0x18;
  param_1[2] = uVar5 + uVar4;
  return *param_1 + iVar3;
}



/* FUNCTION 9848 ; VA 0x00703d60 ; FUN_00703d60 */

void FUN_00703d60(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  
  *param_2 = 0;
  param_2[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = 0;
  param_2[3] = 0;
  if (param_3[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[2] = param_3[2];
  param_2[3] = param_3[3];
  param_2[4] = param_3[4];
  param_2[5] = param_3[5];
  return;
}



/* FUNCTION 9849 ; VA 0x00703dc0 ; FUN_00703dc0 */

undefined4 * __fastcall FUN_00703dc0(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  return param_1;
}



/* FUNCTION 9850 ; VA 0x00703e40 ; FUN_00703e40 */

undefined4 * __thiscall FUN_00703e40(undefined4 *param_1,undefined4 param_2,undefined param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined auStack_1c [8];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab363;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  *(undefined *)((int)param_1 + 9) = param_3;
  *(undefined *)(param_1 + 2) = 0;
  param_1[3] = param_2;
  *(undefined8 *)(param_1 + 4) = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  uStack_8 = 1;
  *(undefined *)(param_1 + 9) = 0;
  puStack_14 = param_1;
  puVar2 = (undefined4 *)FUN_016830f0(auStack_1c);
  uVar1 = puVar2[1];
  param_1[4] = *puVar2;
  param_1[5] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9851 ; VA 0x00703ee0 ; FUN_00703ee0 */

undefined4 * __thiscall FUN_00703ee0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 9852 ; VA 0x00703f50 ; FUN_00703f50 */

undefined4 * __thiscall
FUN_00703f50(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_3;
  param_1[3] = param_3[1];
  param_1[4] = param_4;
  param_1[5] = param_5;
  return param_1;
}



/* FUNCTION 9853 ; VA 0x00703fc0 ; FUN_00703fc0 */

void __fastcall FUN_00703fc0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00602e50(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9854 ; VA 0x00704000 ; FUN_00704000 */

undefined4 * __thiscall
FUN_00704000(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab378;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      *param_4 = *param_2;
      FUN_006d0520(param_2 + 1);
      param_4 = param_4 + 4;
      param_2 = param_2 + 4;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 1;
  FUN_00602e50(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 9855 ; VA 0x00704090 ; FUN_00704090 */

void __thiscall FUN_00704090(int param_1,int param_2)

{
  double dVar1;
  float fVar2;
  int iVar3;
  short sVar4;
  float10 fVar5;
  float fVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dStack_c;
  
  if ((*(char *)(*(int *)(param_1 + 0xc) + 0x3920) != '\0') && (*(char *)(param_2 + 0x228) == '\0'))
  {
    fVar5 = (float10)FUN_00c15e40();
    fVar2 = (float)fVar5;
    if ((NAN(fVar2) || NAN(DAT_018ce2f0)) == (fVar2 == DAT_018ce2f0)) {
      fVar6 = *(float *)(*(int *)(param_1 + 0xc) + 0x39d0);
      if (fVar6 <= fVar2) {
        fVar6 = fVar2;
      }
      *(float *)(*(int *)(param_1 + 0xc) + 0x39d0) = fVar6;
      iVar3 = *(int *)(param_1 + 0xc);
      dStack_c = (double)fVar2;
      sVar4 = FUN_017265ed(&dStack_c);
      if (sVar4 < 1) {
        dVar1 = *(double *)(iVar3 + 0x39d8);
        dVar9 = DAT_018c0d60 - dVar1;
        dVar7 = (double)fVar2;
        dVar8 = dVar7;
        if (*(char *)(iVar3 + 0x39f8) == '\0') {
          dVar8 = *(double *)(iVar3 + 0x39e8) * dVar9 + dVar7 * dVar1;
        }
        *(float *)(iVar3 + 0x39e0) = fVar2;
        *(undefined *)(iVar3 + 0x39f8) = 0;
        *(double *)(iVar3 + 0x39e8) = dVar8;
        *(double *)(iVar3 + 0x39f0) =
             (dVar7 - dVar8) * (dVar7 - dVar8) * dVar1 + *(double *)(iVar3 + 0x39f0) * dVar9;
      }
    }
  }
  return;
}



/* FUNCTION 9856 ; VA 0x00704190 ; FUN_00704190 */

undefined FUN_00704190(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined auStack_44 [4];
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab3a8;
  pvStack_10 = ExceptionList;
  piVar7 = (int *)0x0;
  iStack_34 = 0;
  piStack_30 = (int *)0x0;
  piStack_3c = (int *)0x0;
  piStack_14 = (int *)0x0;
  piStack_38 = (int *)0x0;
  iStack_2c = 0;
  piStack_28 = (int *)0x0;
  piStack_20 = (int *)0x0;
  uStack_8 = 2;
  uStack_24 = 0xffffffff;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_006b9040(param_1,&iStack_2c,&uStack_24);
  if ((cVar4 == '\0') || (iStack_2c != 0)) {
    piVar5 = (int *)FUN_0068f3e0(&uStack_24,&iStack_2c);
    piVar1 = piStack_20;
    iStack_34 = *piVar5;
    piVar7 = (int *)piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    piStack_30 = piVar7;
    iStack_1c = iStack_34;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar5 = piVar1 + 2;
        iVar3 = *piVar5 + -1;
        *piVar5 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    uStack_24 = 0xffffffff;
    piStack_20 = (int *)0x0;
    FUN_006b9040(param_1,&iStack_2c,&uStack_24);
    puVar6 = (undefined4 *)FUN_0068f3e0(auStack_44,&iStack_2c);
    piStack_3c = (int *)*puVar6;
    piStack_38 = (int *)puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    piStack_20 = piStack_3c;
    piStack_14 = piStack_38;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_40[1] + -1;
      piStack_40[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar3 = piStack_40[2] + -1;
        piStack_40[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_40 + 4))();
        }
      }
    }
    cVar4 = FUN_006abd90();
    if ((iStack_1c != 0) && (piStack_20 != (int *)0x0)) {
      iVar3 = *(int *)(*(int *)(uStack_18 + 0xc) + 0x94);
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
      }
      uStack_18 = (uint)(cVar4 == '\0');
      *param_3 = iStack_1c;
      piVar1 = (int *)param_3[1];
      param_3[1] = (int)piVar7;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_3[2] = (int)piStack_20;
      piVar1 = (int *)param_3[3];
      param_3[3] = (int)piStack_14;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_3[4] = uStack_18;
      param_3[5] = iVar3;
      FUN_0056b650();
    }
    param_3._3_1_ = 1;
  }
  else {
    param_3._3_1_ = 0;
  }
  piVar1 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar3 = *piVar5 + -1;
      *piVar5 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar3 = *piVar5 + -1;
      *piVar5 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar3 = piVar7[1] + -1;
    piVar7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_3._3_1_;
}



/* FUNCTION 9857 ; VA 0x00704450 ; FUN_00704450 */

void FUN_00704450(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab3c8;
  pvStack_10 = ExceptionList;
  iStack_28 = 0;
  piStack_24 = (int *)0x0;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_14 = 0xffffffff;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00704190(param_1,param_2,&iStack_28);
  while (cVar4 != '\0') {
    if ((iStack_28 != 0) && (iStack_20 != 0)) {
      iVar2 = *param_3;
      if (*(int *)(iVar2 + 0x18) == *(int *)(iVar2 + 0x14)) {
        FUN_00703b60(*(int *)(iVar2 + 0x14),&iStack_28);
      }
      else {
        FUN_00703d60(iVar2 + 0x10);
        *(int *)(iVar2 + 0x14) = *(int *)(iVar2 + 0x14) + 0x18;
      }
    }
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_14 = 0xffffffff;
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    uStack_8 = 0;
    cVar4 = FUN_00704190(param_1,param_2,&iStack_28);
  }
  iVar2 = *param_3;
  *(int *)(iVar2 + 8) = (*(int *)(iVar2 + 0x14) - *(int *)(iVar2 + 0x10)) / 0x18;
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9858 ; VA 0x007045a0 ; FUN_007045a0 */

void __fastcall FUN_007045a0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01674ea0(*(undefined4 *)(iVar1 + -0xc));
  *(undefined4 *)(iVar1 + -0xc) = 0;
  *(undefined4 *)(iVar1 + -8) = 0;
  *(undefined4 *)(iVar1 + -4) = 0;
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -0x10;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9859 ; VA 0x00704600 ; FUN_00704600 */

undefined __thiscall FUN_00704600(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (*(int *)(param_2 + 0x3858) == 0) {
    return 1;
  }
  iVar1 = *(int *)(param_1 + 0x14);
  for (iVar2 = *(int *)(param_1 + 0x10); iVar2 != iVar1; iVar2 = iVar2 + 0x18) {
    FUN_00704650(iVar2);
  }
  return 1;
}



/* FUNCTION 9860 ; VA 0x00704650 ; FUN_00704650 */

void __thiscall FUN_00704650(int *param_1,int param_2)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  undefined auStack_10 [4];
  undefined auStack_c [7];
  char cStack_5;
  
  cVar3 = FUN_00b09c40(param_2);
  if (cVar3 == '\0') {
    return;
  }
  cVar3 = FUN_00b09c40(param_2 + 8);
  if (cVar3 == '\0') {
    return;
  }
  cVar3 = (**(code **)(*(int *)param_1[3] + 0xd4))();
  if (cVar3 != '\0') {
    iVar4 = (**(code **)(*(int *)param_1[3] + 0xb8))();
    if (iVar4 == 0) {
      return;
    }
    FUN_00927d30(auStack_c);
    uVar5 = FUN_00c15700();
    piStack_14 = (int *)FUN_00b06640(uVar5);
    uVar5 = FUN_00c15700();
    iVar4 = FUN_00b06640(uVar5);
    if (piStack_14 != (int *)0x0) {
      FUN_00b07ca0(&piStack_18);
      cVar3 = FUN_00a33d60(auStack_c);
      if (cVar3 != '\0') goto LAB_0070478d;
    }
    if (iVar4 != 0) {
      FUN_00b07ca0(&piStack_18);
      cVar3 = FUN_00a33d60(auStack_c);
      if (cVar3 != '\0') goto LAB_0070478d;
    }
    piStack_18 = (int *)FUN_00b06660(auStack_c);
    if ((piStack_14 == (int *)0x0) || (piStack_18 != (int *)piStack_14[0x3b])) {
LAB_00704758:
      cStack_5 = '\0';
    }
    else {
      cVar3 = FUN_00b09c10();
      cStack_5 = '\x01';
      if (cVar3 != '\0') goto LAB_00704758;
    }
    if (((iVar4 == 0) || (piStack_18 != *(int **)(iVar4 + 0xec))) ||
       (cVar3 = FUN_00b09c10(), cVar3 != '\0')) {
      bVar2 = false;
    }
    else {
      bVar2 = true;
    }
    if ((cStack_5 == '\0') && (!bVar2)) {
      return;
    }
  }
LAB_0070478d:
  if (*(int *)(param_2 + 0x10) == 0) {
    FUN_00b0c3d0(param_2 + 8);
  }
  else {
    FUN_00b0c4d0(param_2 + 8);
  }
  if (*param_1 != 0) goto LAB_00704902;
  iVar4 = param_1[3];
  if (iVar4 == 0) {
LAB_007048a7:
    iVar4 = 0;
  }
  else {
    iVar6 = *(int *)(iVar4 + 0x34);
    if ((iVar6 != 0) && (iVar4 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 == 0) ||
       (iVar4 = *(int *)(iVar4 + 0xc), iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) goto LAB_007048a7;
    FUN_005789c0(&DAT_01eaef08,&LAB_006c41e0);
    uVar5 = FUN_006c4340();
    piVar7 = (int *)FUN_008aa140(uVar5);
    piStack_14 = piVar7;
    if (*piVar7 == 0) {
      uVar5 = FUN_00c9ab50();
      piVar8 = (int *)FUN_008a9ba0(auStack_1c,uVar5);
      piVar7 = piStack_14;
      iVar4 = *piVar8;
      iVar6 = piVar8[1];
      *piVar8 = 0;
      piVar8[1] = 0;
      *piStack_14 = iVar4;
      piVar8 = (int *)piStack_14[1];
      piStack_14[1] = iVar6;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar4 = piVar8[1] + -1;
        piVar8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar4 = piVar8[2] + -1;
          piVar8[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar8 = piStack_18;
      if (piStack_18 == (int *)0x0) goto LAB_007048a3;
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 != 0) goto LAB_007048a3;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 != 0) goto LAB_007048a3;
      (**(code **)(*piVar8 + 4))();
      iVar4 = *piVar7;
    }
    else {
LAB_007048a3:
      iVar4 = *piVar7;
    }
  }
  piVar7 = (int *)FUN_0060dcd0(auStack_10,iVar4);
  iVar4 = *piVar7;
  iVar6 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  *param_1 = iVar4;
  piVar7 = (int *)param_1[1];
  param_1[1] = iVar6;
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar4 = piVar7[1] + -1;
    piVar7[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar8 = piVar7 + 2;
      iVar4 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  FUN_00550b30();
LAB_00704902:
  FUN_00c9e160(param_2);
  return;
}



/* FUNCTION 9861 ; VA 0x00704920 ; FUN_00704920 */

void __thiscall
FUN_00704920(int param_1,uint param_2,int param_3,undefined4 param_4,undefined4 param_5,uint param_6
            )

{
  byte bVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  double *pdVar5;
  int *piVar6;
  int iVar7;
  float10 fVar8;
  undefined auStack_c4 [48];
  undefined auStack_94 [24];
  undefined auStack_7c [48];
  undefined auStack_4c [24];
  double dStack_34;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab3e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  FUN_00703dc0();
  iStack_20 = 0;
  uStack_1c = 0;
  uStack_24 = 0;
  uStack_8 = 0;
  if ((DAT_01d5b828 == '\0') || (*(char *)(param_1 + 9) == '\0')) {
    puVar2 = &uStack_24;
  }
  else {
    iVar3 = *(int *)(param_1 + 0xc);
    puVar2 = *(undefined4 **)(iVar3 + 0x192c);
    if (*(undefined4 **)(iVar3 + 0x1930) == puVar2) {
      FUN_00703920();
      puVar2 = (undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 0x192c) + -0xc);
    }
    else {
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[1] = 0;
      *(int *)(iVar3 + 0x192c) = *(int *)(iVar3 + 0x192c) + 0x10;
      puVar2 = (undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 0x192c) + -0xc);
    }
  }
  FUN_00705120(param_2,puVar2);
  if ((param_3 != 0) &&
     (iVar3 = *(int *)(*(int *)(param_3 + 0xa8) + 0x2c),
     piVar6 = (int *)(-(uint)(iVar3 != 0) & iVar3 - 8U), piVar6 != (int *)0x0)) {
    (**(code **)(*piVar6 + 0x28))();
  }
  if ((((char)param_6 != '\0') || (param_3 == 0)) ||
     (iVar3 = (**(code **)(**(int **)(param_1 + 0xc) + 0x14c))(), iVar3 == 1)) {
    if (DAT_01eafc10 != '\0') {
      FUN_01677520(DAT_01eafc10,
                   "ignore or null root part or filtered or grounded, skipping framebuffers");
    }
    if (*(char *)(param_1 + 9) == '\0') {
      FUN_00703dc0();
      param_6 = FUN_006abe40();
      for (param_6 = param_6 & 0xff; param_6 != 0; param_6 = param_6 - 1) {
        FUN_006ac3c0();
        FUN_00704e20(param_2,auStack_c4);
        FUN_007055a0(param_2,auStack_94);
        FUN_006b8fd0(&dStack_34,param_2);
      }
    }
    else {
      FUN_00704e20(param_2,auStack_7c);
      FUN_007055a0(param_2,auStack_4c);
      FUN_006b8fd0(&dStack_34,param_2);
      if (DAT_01d5b828 != '\0') {
        iVar7 = *(int *)(param_1 + 0xc);
        iVar3 = *(int *)(iVar7 + 0x192c);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_01674ea0();
        *(undefined4 *)(iVar3 + -0xc) = 0;
        *(undefined4 *)(iVar3 + -8) = 0;
        *(undefined4 *)(iVar3 + -4) = 0;
        piVar6 = (int *)(iVar7 + 0x192c);
        *piVar6 = *piVar6 + -0x10;
      }
    }
    uStack_8 = 2;
    goto LAB_00704e01;
  }
  param_6 = *(uint *)(param_3 + 0xa8);
  if (DAT_01d5be10 == '\0') {
    if (iStack_20 != 0) {
      if ((DAT_01d5b828 == '\0') || (*(char *)(param_1 + 9) == '\0')) goto LAB_00704aae;
      if (*(char *)(param_6 + 0x228) == '\0') goto LAB_00704a7a;
      *(uint *)(*(int *)(*(int *)(param_1 + 0xc) + 0x192c) + -0x10) = param_6;
      goto LAB_00704b18;
    }
    if (DAT_01d5b828 == '\0') goto LAB_00704b18;
    if (*(char *)(param_1 + 9) != '\0') goto LAB_00704b13;
LAB_00704c16:
    uStack_18 = param_4;
    uStack_14 = param_5;
    dStack_34 = 0.0;
    FUN_00703dc0();
    bVar1 = FUN_006abe40();
    param_2 = (uint)bVar1;
    if (bVar1 != 0) {
      param_6 = *(uint *)(param_3 + 0xa8);
      do {
        fVar8 = (float10)FUN_006ac3c0();
        FUN_00704e20(iVar7,auStack_c4);
        FUN_007055a0(iVar7,auStack_94);
        FUN_006b8fd0(&uStack_2c,iVar7);
        dStack_34 = (double)CONCAT44(uStack_14,uStack_18) - (double)(float)fVar8;
        if ((*(char *)(param_1 + 9) == '\0') &&
           (((*(int *)(param_6 + 0x1a0) == 0 ||
             (*(double *)(*(int *)(param_6 + 0x1a0) + 0xb8) <= dStack_34)) &&
            (FUN_00c14280(auStack_c4,&dStack_34,*(undefined4 *)(param_1 + 0x10),
                          *(undefined4 *)(param_1 + 0x14),0,uStack_2c,iStack_28,0),
            *(char *)(*(int *)(param_1 + 0xc) + 0x3920) != '\0')))) {
          FUN_00704090();
        }
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
  }
  else {
    if ((DAT_01d5b828 == '\0') || (*(char *)(param_1 + 9) == '\0')) {
      if (iStack_20 != 0) {
LAB_00704aae:
        FUN_00c155c0();
        uVar4 = FUN_00c157b0();
        FUN_00ca1fa0(&uStack_24,uVar4);
      }
    }
    else {
      iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x192c);
      if ((0xf < (uint)(iVar3 - *(int *)(*(int *)(param_1 + 0xc) + 0x1928))) &&
         (*(int *)(iVar3 + -8) != 0)) {
        if (*(char *)(param_6 + 0x228) != '\0') {
          *(uint *)(iVar3 + -0x10) = param_6;
          goto LAB_00704b18;
        }
LAB_00704a7a:
        FUN_00c155c0();
        uVar4 = FUN_00c157b0();
        FUN_00ca1fa0(*(int *)(*(int *)(param_1 + 0xc) + 0x192c) + -0xc,uVar4);
      }
LAB_00704b13:
      FUN_007045a0();
    }
LAB_00704b18:
    if (*(char *)(param_1 + 9) == '\0') goto LAB_00704c16;
    if (DAT_01d5be08 == '\0') {
      FUN_00704e20(param_2,auStack_7c);
      FUN_007055a0(param_2,auStack_4c);
      FUN_006b8fd0(&uStack_18,param_2);
      iVar7 = 0;
    }
    else {
      iVar7 = *(int *)(param_2 + 0x18);
      iVar3 = *(int *)(param_2 + 0x20);
      FUN_00704e20(param_2,auStack_7c);
      FUN_007055a0(param_2,auStack_4c);
      param_1 = iStack_28;
      iVar7 = (*(int *)(param_2 + 0x20) - *(int *)(param_2 + 0x18)) + (iVar7 - iVar3);
      FUN_006b8fd0(&uStack_18,param_2);
    }
    FUN_00c14280(auStack_7c,&param_4,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14)
                 ,0,uStack_18,uStack_14,iVar7);
    if (DAT_01d5a028 != '\0') {
      FUN_00624390();
      pdVar5 = (double *)FUN_016830f0();
      FUN_0062b990((*pdVar5 - (double)CONCAT44(param_5,param_4)) * DAT_018c0d70);
    }
    if (*(char *)(*(int *)(param_1 + 0xc) + 0x3920) != '\0') {
      FUN_00704090();
    }
  }
  uStack_8 = 3;
LAB_00704e01:
  FUN_01674ea0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9862 ; VA 0x00704e20 ; FUN_00704e20 */

void FUN_00704e20(int param_1,int param_2)

{
  double dVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  double *pdVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dStack_14;
  undefined8 uStack_c;
  
  iVar6 = *(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x20);
  FUN_00722ea0(param_1,param_2 + 0x24);
  iVar3 = (iVar6 - *(int *)(param_1 + 0x18)) + *(int *)(param_1 + 0x20);
  FUN_00722c40(param_1,param_2);
  iVar6 = ((iVar6 - *(int *)(param_1 + 0x18)) - iVar3) + *(int *)(param_1 + 0x20);
  if ((DAT_01d5be00 != '\0') && (*(char *)(uStack_c._4_4_ + 0x24) != '\0')) {
    iVar4 = FUN_00624390();
    pdVar5 = (double *)FUN_016827a0(&dStack_14);
    if (*(double *)(iVar4 + 0xd8) <= *pdVar5 - *(double *)(iVar4 + 0xd0)) {
      *(undefined4 *)(iVar4 + 0xe0) = *(undefined4 *)(iVar4 + 0xe4);
      *(undefined4 *)(iVar4 + 0xe4) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar4 + 0xd0) = (undefined4)uStack_c;
      *(int *)(iVar4 + 0xd4) = uStack_c._4_4_;
    }
    *(int *)(iVar4 + 0xe4) = *(int *)(iVar4 + 0xe4) + 1;
    iVar4 = FUN_00624390();
    uStack_c = (double)iVar3;
    sVar2 = FUN_017265ed(&uStack_c);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar4 + 0xe8);
      dVar9 = DAT_018c0d60 - dVar1;
      dVar7 = (double)iVar3;
      dVar8 = dVar7;
      if (*(char *)(iVar4 + 0x108) == '\0') {
        dVar8 = *(double *)(iVar4 + 0xf8) * dVar9 + dVar7 * dVar1;
      }
      *(int *)(iVar4 + 0xf0) = iVar3;
      *(double *)(iVar4 + 0xf8) = dVar8;
      *(undefined *)(iVar4 + 0x108) = 0;
      *(double *)(iVar4 + 0x100) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar1 + *(double *)(iVar4 + 0x100) * dVar9;
    }
    iVar4 = FUN_00624390();
    pdVar5 = (double *)FUN_016827a0(&dStack_14);
    if (*(double *)(iVar4 + 0x118) <= *pdVar5 - *(double *)(iVar4 + 0x110)) {
      *(undefined4 *)(iVar4 + 0x120) = *(undefined4 *)(iVar4 + 0x124);
      *(undefined4 *)(iVar4 + 0x124) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar4 + 0x110) = (undefined4)uStack_c;
      *(int *)(iVar4 + 0x114) = uStack_c._4_4_;
    }
    *(int *)(iVar4 + 0x124) = *(int *)(iVar4 + 0x124) + 1;
    iVar4 = FUN_00624390();
    dStack_14 = (double)iVar6;
    uStack_c = dStack_14;
    sVar2 = FUN_017265ed(&dStack_14);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar4 + 0x128);
      dVar7 = DAT_018c0d60 - dVar1;
      dVar8 = uStack_c;
      if (*(char *)(iVar4 + 0x148) == '\0') {
        dVar8 = *(double *)(iVar4 + 0x138) * dVar7 + uStack_c * dVar1;
      }
      *(int *)(iVar4 + 0x130) = iVar6;
      *(double *)(iVar4 + 0x138) = dVar8;
      *(undefined *)(iVar4 + 0x148) = 0;
      *(double *)(iVar4 + 0x140) =
           (uStack_c - dVar8) * (uStack_c - dVar8) * dVar1 + dVar7 * *(double *)(iVar4 + 0x140);
    }
    iVar4 = FUN_00624390();
    pdVar5 = (double *)FUN_016827a0(&dStack_14);
    if (*(double *)(iVar4 + 0x58) <= *pdVar5 - *(double *)(iVar4 + 0x50)) {
      *(undefined4 *)(iVar4 + 0x60) = *(undefined4 *)(iVar4 + 100);
      *(undefined4 *)(iVar4 + 100) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar4 + 0x50) = (undefined4)uStack_c;
      *(int *)(iVar4 + 0x54) = uStack_c._4_4_;
    }
    *(int *)(iVar4 + 100) = *(int *)(iVar4 + 100) + 1;
    iVar4 = FUN_00624390();
    dStack_14 = (double)(iVar3 + iVar6);
    uStack_c = dStack_14;
    sVar2 = FUN_017265ed(&dStack_14);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar4 + 0x68);
      dVar7 = DAT_018c0d60 - dVar1;
      dVar8 = uStack_c;
      if (*(char *)(iVar4 + 0x88) == '\0') {
        dVar8 = *(double *)(iVar4 + 0x78) * dVar7 + uStack_c * dVar1;
      }
      *(int *)(iVar4 + 0x70) = iVar3 + iVar6;
      *(double *)(iVar4 + 0x78) = dVar8;
      *(undefined *)(iVar4 + 0x88) = 0;
      *(double *)(iVar4 + 0x80) =
           (uStack_c - dVar8) * (uStack_c - dVar8) * dVar1 + dVar7 * *(double *)(iVar4 + 0x80);
    }
  }
  return;
}



/* FUNCTION 9863 ; VA 0x00705120 ; FUN_00705120 */

void FUN_00705120(int param_1,undefined4 *param_2)

{
  double dVar1;
  int iVar2;
  short sVar3;
  uint uVar4;
  int iVar5;
  double *pdVar6;
  int iVar7;
  undefined4 *puVar8;
  double dVar9;
  double dVar10;
  undefined auStack_c0 [36];
  undefined auStack_9c [36];
  undefined auStack_78 [8];
  undefined auStack_70 [12];
  undefined auStack_64 [20];
  undefined4 uStack_50;
  double dStack_4c;
  double dStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  uint uStack_28;
  double dStack_24;
  int iStack_1c;
  double *pdStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ed8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006abc60(&uStack_28,param_1);
  if (0x10000 < uStack_28) {
    FUN_0054eff0("numMotors is excessive.");
    uStack_8 = 0;
    FUN_00610c20(auStack_64);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_9c,&DAT_01c2a510);
  }
  FUN_006de000(uStack_28,1);
  puVar8 = (undefined4 *)*param_2;
  puStack_2c = puVar8 + param_2[1] * 7;
  if (puVar8 != puStack_2c) {
    do {
      uStack_50 = 0;
      *puVar8 = 0;
      puVar8[1] = 0;
      puVar8[2] = 0;
      puVar8[3] = 0;
      *(undefined8 *)(puVar8 + 4) = 0;
      puVar8[6] = 0;
      uVar4 = FUN_006abe40();
      if ((uVar4 & 1) != 0) {
        iStack_1c = *(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x20);
        FUN_00722ea0(param_1,puVar8 + 4);
        if ((DAT_01d5be00 != '\0') && (*(char *)(iStack_14 + 0x24) != '\0')) {
          iVar5 = FUN_00624390();
          pdStack_18 = (double *)(iVar5 + 0xd0);
          pdVar6 = (double *)FUN_016827a0(auStack_70);
          if (pdStack_18[1] <= *pdVar6 - *pdStack_18) {
            *(undefined4 *)(pdStack_18 + 2) = *(undefined4 *)((int)pdStack_18 + 0x14);
            *(undefined4 *)((int)pdStack_18 + 0x14) = 0;
            FUN_016827a0(&uStack_34);
            *(undefined4 *)pdStack_18 = uStack_34;
            *(undefined4 *)((int)pdStack_18 + 4) = uStack_30;
          }
          *(int *)((int)pdStack_18 + 0x14) = *(int *)((int)pdStack_18 + 0x14) + 1;
          iVar5 = FUN_00624390();
          pdStack_18 = (double *)(iVar5 + 0xe8);
          iStack_1c = (*(int *)(param_1 + 0x20) - *(int *)(param_1 + 0x18)) + iStack_1c;
          dStack_44 = (double)iStack_1c;
          dStack_24 = dStack_44;
          sVar3 = FUN_017265ed(&dStack_44);
          if (sVar3 < 1) {
            dVar1 = *pdStack_18;
            dVar10 = dStack_24;
            if (*(char *)(pdStack_18 + 4) == '\0') {
              dVar10 = (DAT_018c0d60 - dVar1) * pdStack_18[2] + dVar1 * dStack_24;
            }
            dVar9 = DAT_018c0d60 - dVar1;
            pdStack_18[2] = dVar10;
            *(int *)(pdStack_18 + 1) = iStack_1c;
            *(undefined *)(pdStack_18 + 4) = 0;
            pdStack_18[3] =
                 (dStack_24 - dVar10) * (dStack_24 - dVar10) * dVar1 + dVar9 * pdStack_18[3];
          }
        }
        uVar4 = uVar4 & 0xff;
      }
      if ((uVar4 & 2) != 0) {
        iVar5 = *(int *)(param_1 + 0x18);
        iVar2 = *(int *)(param_1 + 0x20);
        FUN_00722da0(param_1,auStack_c0);
        FUN_01162b60(puVar8,puVar8 + 3);
        if ((DAT_01d5be00 != '\0') && (*(char *)(iStack_14 + 0x24) != '\0')) {
          iVar7 = FUN_00624390();
          pdVar6 = (double *)FUN_016827a0(auStack_78);
          if (*(double *)(iVar7 + 0x118) <= *pdVar6 - *(double *)(iVar7 + 0x110)) {
            *(undefined4 *)(iVar7 + 0x120) = *(undefined4 *)(iVar7 + 0x124);
            *(undefined4 *)(iVar7 + 0x124) = 0;
            FUN_016827a0(&uStack_3c);
            *(undefined4 *)(iVar7 + 0x110) = uStack_3c;
            *(undefined4 *)(iVar7 + 0x114) = uStack_38;
          }
          *(int *)(iVar7 + 0x124) = *(int *)(iVar7 + 0x124) + 1;
          iVar7 = FUN_00624390();
          iVar5 = (*(int *)(param_1 + 0x20) - *(int *)(param_1 + 0x18)) + (iVar5 - iVar2);
          dStack_4c = (double)iVar5;
          dStack_24 = dStack_4c;
          sVar3 = FUN_017265ed(&dStack_4c);
          if (sVar3 < 1) {
            dVar1 = *(double *)(iVar7 + 0x128);
            dVar10 = dStack_24;
            if (*(char *)(iVar7 + 0x148) == '\0') {
              dVar10 = (DAT_018c0d60 - dVar1) * *(double *)(iVar7 + 0x138) + dVar1 * dStack_24;
            }
            dVar9 = DAT_018c0d60 - dVar1;
            *(double *)(iVar7 + 0x138) = dVar10;
            *(int *)(iVar7 + 0x130) = iVar5;
            *(undefined *)(iVar7 + 0x148) = 0;
            *(double *)(iVar7 + 0x140) =
                 (dStack_24 - dVar10) * (dStack_24 - dVar10) * dVar1 +
                 dVar9 * *(double *)(iVar7 + 0x140);
          }
        }
      }
      puVar8 = puVar8 + 7;
    } while (puVar8 != puStack_2c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9864 ; VA 0x00705490 ; FUN_00705490 */

int FUN_00705490(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab3c8;
  pvStack_10 = ExceptionList;
  iVar5 = 0;
  uStack_14 = 0xffffffff;
  iStack_28 = 0;
  piStack_24 = (int *)0x0;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00704190(param_1,param_2,&iStack_28);
  while (cVar4 != '\0') {
    if ((iStack_28 != 0) && (iStack_20 != 0)) {
      iVar5 = iVar5 + 1;
      FUN_00704650(&iStack_28);
    }
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_14 = 0xffffffff;
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    uStack_8 = 0;
    cVar4 = FUN_00704190(param_1,param_2,&iStack_28);
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9865 ; VA 0x007055a0 ; FUN_007055a0 */

void FUN_007055a0(int param_1,int param_2)

{
  double dVar1;
  int iVar2;
  short sVar3;
  int iVar4;
  double *pdVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  undefined8 uStack_10;
  int iStack_8;
  
  iVar6 = *(int *)(param_1 + 0x18);
  iVar2 = *(int *)(param_1 + 0x20);
  FUN_00723140(param_1,param_2);
  FUN_00723140(param_1,param_2 + 0xc);
  if ((DAT_01d5be00 != '\0') && (*(char *)(iStack_8 + 0x24) != '\0')) {
    iVar4 = FUN_00624390();
    pdVar5 = (double *)FUN_016827a0(&uStack_10);
    if (*(double *)(iVar4 + 0x158) <= *pdVar5 - *(double *)(iVar4 + 0x150)) {
      *(undefined4 *)(iVar4 + 0x160) = *(undefined4 *)(iVar4 + 0x164);
      *(undefined4 *)(iVar4 + 0x164) = 0;
      FUN_016827a0(&uStack_10);
      *(undefined4 *)(iVar4 + 0x150) = (undefined4)uStack_10;
      *(undefined4 *)(iVar4 + 0x154) = uStack_10._4_4_;
    }
    *(int *)(iVar4 + 0x164) = *(int *)(iVar4 + 0x164) + 1;
    iVar4 = FUN_00624390();
    iVar6 = ((iVar6 - iVar2) - *(int *)(param_1 + 0x18)) + *(int *)(param_1 + 0x20);
    uStack_10 = (double)iVar6;
    sVar3 = FUN_017265ed(&uStack_10);
    if (sVar3 < 1) {
      dVar1 = *(double *)(iVar4 + 0x168);
      dVar9 = DAT_018c0d60 - dVar1;
      dVar7 = (double)iVar6;
      dVar8 = dVar7;
      if (*(char *)(iVar4 + 0x188) == '\0') {
        dVar8 = *(double *)(iVar4 + 0x178) * dVar9 + dVar7 * dVar1;
      }
      *(int *)(iVar4 + 0x170) = iVar6;
      *(double *)(iVar4 + 0x178) = dVar8;
      *(undefined *)(iVar4 + 0x188) = 0;
      *(double *)(iVar4 + 0x180) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar1 + *(double *)(iVar4 + 0x180) * dVar9;
    }
  }
  return;
}



/* FUNCTION 9866 ; VA 0x007056e0 ; FUN_007056e0 */

void __thiscall
FUN_007056e0(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  double dVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  char cVar6;
  short sVar7;
  int iVar8;
  int iVar9;
  double *pdVar10;
  double dVar11;
  double dVar12;
  undefined auStack_64 [36];
  undefined auStack_40 [24];
  undefined8 uStack_28;
  undefined8 uStack_20;
  int iStack_18;
  byte bStack_12;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab410;
  pvStack_10 = ExceptionList;
  iStack_18 = *(int *)(param_2 + 0x18) - *(int *)(param_2 + 0x20);
  ExceptionList = &pvStack_10;
  cVar6 = FUN_006abe60((int)&param_2 + 3,1);
  iVar9 = param_3;
  if (cVar6 != '\0') {
    bStack_11 = param_2._3_1_ & 0x1f;
    bStack_12 = param_2._3_1_ >> 5 & 1;
    if ((param_3 != 0) && (iVar8 = FUN_00c155c0(), iVar8 != 0)) {
      *(byte *)(iVar8 + 0x38) = bStack_11;
    }
    FUN_00704920(iVar4,iVar9,param_4,param_5,0,0);
    param_3 = 1;
    dVar2 = uStack_28;
    if (bStack_12 == 0) {
      uStack_28 = 0.0;
      uStack_8 = 1;
      cVar6 = FUN_00705c60(&uStack_28,iVar4);
      dVar2 = uStack_28;
      while (uStack_28 = dVar2, cVar6 != '\0') {
        uStack_28._0_4_ = SUB84(dVar2,0);
        uVar5 = (undefined4)uStack_28;
        FUN_00704920(iVar4,uVar5,param_4,param_5,0,0);
        piVar1 = uStack_28._4_4_;
        param_3 = param_3 + 1;
        uStack_28 = 0.0;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar9 = piVar1[1] + -1;
          piVar1[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar9 = piVar1[2] + -1;
            piVar1[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        cVar6 = FUN_00705c60(&uStack_28,iVar4);
        dVar2 = uStack_28;
      }
      uStack_28._4_4_ = (int *)((ulonglong)dVar2 >> 0x20);
      uStack_8 = 0xffffffff;
      uStack_20 = (double)CONCAT44(uStack_28._4_4_,(undefined4)uStack_20);
      if (uStack_28._4_4_ != (undefined4 *)0x0) {
        LOCK();
        iVar9 = uStack_28._4_4_[1] + -1;
        uStack_28._4_4_[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          puVar3 = (undefined4 *)*uStack_28._4_4_;
          (*(code *)*puVar3)();
          LOCK();
          piVar1 = uStack_20._4_4_ + 2;
          iVar9 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          dVar2 = uStack_28;
          if (iVar9 == 1) {
            (**(code **)(*uStack_20._4_4_ + 4))();
            dVar2 = uStack_28;
          }
        }
      }
    }
    uStack_28 = dVar2;
    if ((DAT_01d5be00 != '\0') && (*(char *)(param_1 + 0x24) != '\0')) {
      iVar9 = FUN_00624390();
      pdVar10 = (double *)FUN_016827a0(&uStack_28);
      if (*(double *)(iVar9 + 0x98) <= *pdVar10 - *(double *)(iVar9 + 0x90)) {
        *(undefined4 *)(iVar9 + 0xa0) = *(undefined4 *)(iVar9 + 0xa4);
        *(undefined4 *)(iVar9 + 0xa4) = 0;
        FUN_016827a0(&uStack_28);
        *(undefined4 *)(iVar9 + 0x90) = (undefined4)uStack_28;
        *(int **)(iVar9 + 0x94) = uStack_28._4_4_;
      }
      *(int *)(iVar9 + 0xa4) = *(int *)(iVar9 + 0xa4) + 1;
      iVar9 = FUN_00624390();
      iStack_18 = (iStack_18 - *(int *)(iVar4 + 0x18)) + *(int *)(iVar4 + 0x20);
      uStack_28 = (double)iStack_18;
      uStack_20 = uStack_28;
      sVar7 = FUN_017265ed(&uStack_20);
      if (sVar7 < 1) {
        dVar2 = *(double *)(iVar9 + 0xa8);
        dVar11 = uStack_28;
        if (*(char *)(iVar9 + 200) == '\0') {
          dVar11 = (DAT_018c0d60 - dVar2) * *(double *)(iVar9 + 0xb8) + dVar2 * uStack_28;
        }
        dVar12 = DAT_018c0d60 - dVar2;
        *(double *)(iVar9 + 0xb8) = dVar11;
        *(int *)(iVar9 + 0xb0) = iStack_18;
        *(undefined *)(iVar9 + 200) = 0;
        *(double *)(iVar9 + 0xc0) =
             (uStack_28 - dVar11) * (uStack_28 - dVar11) * dVar2 +
             dVar12 * *(double *)(iVar9 + 0xc0);
      }
    }
    FUN_00620960(0x1d,param_3);
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0054eff0("readFast past end for uint8_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_64,&DAT_01c27108);
}



/* FUNCTION 9867 ; VA 0x00705990 ; FUN_00705990 */

void __thiscall FUN_00705990(int param_1,undefined4 param_2)

{
  int *piVar1;
  double dVar2;
  int iVar3;
  double dVar4;
  int *piVar5;
  char cVar6;
  short sVar7;
  double *pdVar8;
  double dVar9;
  undefined8 uVar10;
  double dStack_38;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab43c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf6d0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf6d0), DAT_01eaf6d0 == -1)) {
    uStack_8 = 0;
    uVar10 = FUN_0152dab0(&DAT_018c5904,"PhysicsReceiverS2::receivePacket",0xffffffff);
    DAT_01eaf6cc = (undefined4)((ulonglong)uVar10 >> 0x20);
    DAT_01eaf6c8 = (undefined4)uVar10;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaf6d0);
  }
  uStack_28 = DAT_01eaf6c8;
  uStack_24 = DAT_01eaf6cc;
  uVar10 = FUN_0152d930(DAT_01eaf6c8,DAT_01eaf6cc);
  uStack_8 = 1;
  pdVar8 = (double *)FUN_00626680(&dStack_38,&stack0x00000008);
  uStack_20 = *(undefined4 *)pdVar8;
  uStack_1c = *(undefined4 *)((int)pdVar8 + 4);
  uStack_30 = *pdVar8;
  if (DAT_01d5be00 != '\0') {
    pdVar8 = (double *)FUN_00624390();
    dStack_38 = (*(double *)(param_1 + 0x10) - uStack_30) * DAT_018c0d70;
    uStack_30 = dStack_38;
    sVar7 = FUN_017265ed(&dStack_38);
    dVar4 = DAT_018c0d60;
    if (sVar7 < 1) {
      dVar2 = *pdVar8;
      dVar9 = uStack_30;
      if (*(char *)(pdVar8 + 4) == '\0') {
        dVar9 = (DAT_018c0d60 - dVar2) * pdVar8[2] + dVar2 * uStack_30;
      }
      pdVar8[1] = uStack_30;
      pdVar8[2] = dVar9;
      *(undefined *)(pdVar8 + 4) = 0;
      pdVar8[3] = (dVar4 - dVar2) * pdVar8[3] + dVar2 * (uStack_30 - dVar9) * (uStack_30 - dVar9);
    }
  }
  do {
    uStack_30 = 0.0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    cStack_11 = FUN_00705c60(&uStack_30,param_2);
    if ((int)uStack_30 != 0) {
      FUN_00c155c0();
      cVar6 = FUN_00ca0f40();
      if (cVar6 == '\0') {
        cVar6 = (**(code **)(**(int **)(param_1 + 0xc) + 0xa4))((int)uStack_30);
        if (cVar6 != '\0') goto LAB_00705b5d;
      }
      piVar5 = uStack_30._4_4_;
      uStack_30 = 0.0;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar3 = piVar5[2] + -1;
          piVar5[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
LAB_00705b5d:
    if (cStack_11 == '\0') {
      piVar5 = uStack_30._4_4_;
      if (uStack_30._4_4_ != (int *)0x0) {
        LOCK();
        iVar3 = uStack_30._4_4_[1] + -1;
        uStack_30._4_4_[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*uStack_30._4_4_)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      uStack_8 = 3;
      FUN_0152dda0(uStack_28,uStack_24,uVar10);
      ExceptionList = pvStack_10;
      return;
    }
    FUN_007056e0(param_2,(int)uStack_30,uStack_20,uStack_1c);
    piVar5 = uStack_30._4_4_;
    param_1 = iStack_18;
    if (uStack_30._4_4_ != (int *)0x0) {
      LOCK();
      iVar3 = uStack_30._4_4_[1] + -1;
      uStack_30._4_4_[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*uStack_30._4_4_)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        param_1 = iStack_18;
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
          param_1 = iStack_18;
        }
      }
    }
  } while( true );
}



/* FUNCTION 9868 ; VA 0x00705c60 ; FUN_00705c60 */

undefined __thiscall FUN_00705c60(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined auStack_40 [24];
  undefined auStack_28 [8];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ab470;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  iStack_8 = 0;
  uStack_20 = 0xffffffff;
  uStack_1c = 0;
  if (DAT_01d5b828 == '\0') {
    ExceptionList = &pvStack_10;
    cVar4 = FUN_006b9040(param_3,&iStack_18,&uStack_20);
    if (cVar4 != '\0') goto joined_r0x00705d44;
    if (*(char *)(*(int *)(*(int *)(param_1 + 0xc) + 0x1f70) + 0x58) != '\0') {
      puVar6 = (undefined4 *)FUN_009c93d0(auStack_40,4);
      iStack_8._0_1_ = 2;
      goto LAB_00705d6e;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar4 = (**(code **)(**(int **)(param_1 + 0xc) + 0xd4))();
    if (cVar4 == '\0') {
      cVar4 = FUN_006b9040(param_3,&iStack_18,&uStack_20);
    }
    else {
      cVar4 = FUN_006b90a0(param_3,&iStack_18,&uStack_20);
    }
    if (cVar4 == '\0') {
      if (*(char *)(*(int *)(*(int *)(param_1 + 0xc) + 0x1f70) + 0x58) != '\0') {
        puVar6 = (undefined4 *)FUN_009c93d0(auStack_40,4);
        iStack_8._0_1_ = 1;
LAB_00705d6e:
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_0086f2f0(2,"Physics-in of unidentified %s",puVar6);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
    }
    else {
joined_r0x00705d44:
      if (iStack_18 == 0) {
        uVar7 = 0;
        goto LAB_00705dee;
      }
      uVar5 = FUN_0068f3e0(auStack_28,&iStack_18);
      FUN_005587e0(uVar5);
      FUN_00550b30();
    }
  }
  if ((*param_2 != 0) && (cVar4 = FUN_00b09c40(param_2), cVar4 == '\0')) {
    if (*(char *)(*(int *)(*(int *)(param_1 + 0xc) + 0x1f70) + 0x58) != '\0') {
      puVar6 = (undefined4 *)FUN_009c93d0(auStack_40,4);
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_0086f2f0(1,"Physics-in of part not in workspace %s",puVar6);
      FUN_005507b0();
    }
    FUN_0058a2b0();
  }
  uVar7 = 1;
LAB_00705dee:
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 9869 ; VA 0x00705e30 ; FUN_00705e30 */

void __thiscall FUN_00705e30(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(undefined4 *)(param_1 + 0x14) = param_3;
  return;
}



/* FUNCTION 9870 ; VA 0x00705e50 ; FUN_00705e50 */

undefined4 * __thiscall
FUN_00705e50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab498;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_018e33c8;
  cVar3 = FUN_007065a0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
    if (param_8 != (int *)0x0) {
      LOCK();
      iVar2 = param_8[1] + -1;
      param_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_8)();
        LOCK();
        iVar2 = param_8[2] + -1;
        param_8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_8 + 4))();
        }
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9871 ; VA 0x00705fc0 ; FUN_00705fc0 */

undefined * FUN_00705fc0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab4bc;
  pvStack_10 = ExceptionList;
  if (DAT_01eaf6fc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf908) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaf908);
      if (DAT_01eaf908 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ClusterPacketCache",1,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_0187e8b0);
        FUN_016f37bf(&DAT_01eaf908);
      }
    }
    DAT_01eaf6fc = &DAT_01eaf700;
  }
  ExceptionList = pvStack_10;
  return DAT_01eaf6fc;
}



/* FUNCTION 9872 ; VA 0x007060a0 ; FUN_007060a0 */

void FUN_007060a0(void)

{
  int iVar1;
  
  if (DAT_01eaf90c == 0) {
    iVar1 = FUN_00705fc0();
    DAT_01eaf90c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 9873 ; VA 0x007060c0 ; FUN_007060c0 */

int __thiscall FUN_007060c0(int *param_1,uint *param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab4d8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar5 = (int)param_2 - iVar2 >> 5;
  iVar6 = param_1[1] - iVar2 >> 5;
  if (iVar6 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = param_1[2] - iVar2 >> 5;
  uVar7 = uVar1;
  if ((uVar9 <= 0x7ffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar9 = uVar7 << 5;
  if (uVar7 < 0x8000000) {
    if (0xfff < uVar9) goto LAB_00706151;
    if (uVar9 == 0) {
      puVar11 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (uint *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_00706151:
    uVar8 = uVar9 + 0x23;
    if (uVar8 <= uVar9) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01674e20(uVar8);
    if (uVar9 == 0) goto LAB_00706319;
    puVar11 = (uint *)(uVar9 + 0x23 & 0xffffffe0);
    puVar11[-1] = uVar9;
  }
  uStack_8 = 0;
  FUN_00706770(param_1,puVar11 + iVar5 * 8,param_3);
  puVar3 = (uint *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (uint *)*param_1;
    uStack_8._0_1_ = 1;
    puVar10 = puVar11;
    while (puVar12 != puVar3) {
      *puVar10 = 0;
      uVar9 = *puVar12;
      if (uVar9 == 0) {
LAB_00706232:
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
      else {
        *puVar10 = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
          goto LAB_00706232;
        }
        uVar9 = puVar12[3];
        uVar8 = puVar12[4];
        uVar4 = puVar12[5];
        puVar10[2] = puVar12[2];
        puVar10[3] = uVar9;
        puVar10[4] = uVar8;
        puVar10[5] = uVar4;
        uVar9 = puVar12[7];
        puVar10[6] = puVar12[6];
        puVar10[7] = uVar9;
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_006ce110(puVar10,puVar10,param_1);
  }
  else {
    FUN_006d4080(*param_1,param_2,puVar11);
    FUN_006d4080(param_2,param_1[1],puVar11 + iVar5 * 8 + 8);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar2 = *param_1;
    uVar9 = param_1[2] - iVar2 & 0xffffffe0;
    iVar6 = iVar2;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_00706319:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 8);
  param_1[2] = (int)(puVar11 + uVar7 * 8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5 * 0x20;
}



/* FUNCTION 9874 ; VA 0x007062ef ; Catch_All@007062ef */

void Catch_All_007062ef(void)

{
  int unaff_EBP;
  
  FUN_006d3e10(*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9875 ; VA 0x00706320 ; FUN_00706320 */

int __thiscall FUN_00706320(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  
  iVar6 = *param_1;
  iVar3 = (param_1[1] - *param_1) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = (param_1[2] - *param_1) / 0xc;
  uVar7 = uVar1;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar5 = uVar7 * 0xc;
  if (uVar7 < 0x15555556) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_007063bb;
    if (uVar5 == 0) {
      puVar9 = (undefined8 *)0x0;
    }
    else {
      puVar9 = (undefined8 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_007063bb:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00706505;
    puVar9 = (undefined8 *)(iVar3 + 0x23U & 0xffffffe0);
    *(int *)((int)puVar9 + -4) = iVar3;
  }
  iVar6 = (((int)param_2 - iVar6) / 0xc) * 0xc;
  *(undefined8 *)(iVar6 + (int)puVar9) = *param_3;
  *(undefined4 *)(iVar6 + 8 + (int)puVar9) = *(undefined4 *)(param_3 + 1);
  puVar11 = (undefined8 *)param_1[1];
  puVar4 = (undefined8 *)*param_1;
  puVar8 = puVar9;
  if (param_2 == puVar11) {
    for (; puVar4 != puVar11; puVar4 = (undefined8 *)((int)puVar4 + 0xc)) {
      *puVar8 = *puVar4;
      *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar4 + 1);
      puVar8 = (undefined8 *)((int)puVar8 + 0xc);
    }
  }
  else {
    if (puVar4 != param_2) {
      do {
        *puVar8 = *puVar4;
        puVar11 = puVar4 + 1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
        *(undefined4 *)(puVar8 + 1) = *(undefined4 *)puVar11;
        puVar8 = (undefined8 *)((int)puVar8 + 0xc);
      } while (puVar4 != param_2);
      puVar11 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar11) {
      puVar4 = (undefined8 *)(iVar6 + 0xc + (int)puVar9);
      do {
        *puVar4 = *param_2;
        puVar8 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)(puVar4 + 1) = *(undefined4 *)puVar8;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      } while (param_2 != puVar11);
    }
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar7 = ((param_1[2] - iVar3) / 0xc) * 0xc;
    iVar10 = iVar3;
    if (0xfff < uVar7) {
      iVar10 = *(int *)(iVar3 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar3 - iVar10) - 4U) {
LAB_00706505:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar7);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)puVar9 + uVar1 * 0xc;
  param_1[2] = uVar5 + (int)puVar9;
  return *param_1 + iVar6;
}



/* FUNCTION 9876 ; VA 0x00706510 ; FUN_00706510 */

void __thiscall FUN_00706510(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab4f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Network::PerReplicatorCacheState>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9877 ; VA 0x0070657e ; Catch_All@0070657e */

void Catch_All_0070657e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00707120(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9878 ; VA 0x007065a0 ; FUN_007065a0 */

undefined FUN_007065a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,int *param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  undefined4 *puVar7;
  undefined uVar8;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ab518;
  pvStack_10 = ExceptionList;
  uStack_3c = param_1;
  uStack_38 = param_2;
  uStack_34 = param_3;
  uStack_30 = param_4;
  uStack_2c = param_5;
  ExceptionList = &pvStack_10;
  if (param_7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  uStack_28 = param_6;
  piStack_24 = param_7;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar6 = FUN_00585a40(&uStack_3c);
  piVar2 = piStack_24;
  uVar5 = uStack_38;
  uVar4 = uStack_3c;
  if (cVar6 == '\0') {
    uStack_14 = uStack_34;
    uStack_18 = uStack_30;
    uStack_1c = uStack_2c;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    uStack_20 = uStack_28;
    uStack_8 = 2;
    puVar7 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7[2] = uStack_14;
      puVar7[3] = uStack_18;
      *puVar7 = uVar4;
      puVar7[1] = uVar5;
      puVar7[4] = uStack_1c;
      puVar7[5] = 0;
      puVar7[6] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      puVar7[5] = uStack_20;
      puVar7[6] = piVar2;
    }
    *param_8 = (int)puVar7;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar8 = 1;
  }
  else {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar8 = 0;
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar3 = param_7[1] + -1;
    param_7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar2 = param_7 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 9879 ; VA 0x00706770 ; FUN_00706770 */

void FUN_00706770(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = param_3[5];
  uVar2 = param_3[6];
  param_3[5] = 0;
  param_3[6] = 0;
  FUN_00705e50(*param_3,param_3[1],param_3[2],param_3[3],param_3[4],uVar1,uVar2,0);
  return;
}



/* FUNCTION 9880 ; VA 0x007067d0 ; FUN_007067d0 */

int __thiscall FUN_007067d0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_00706510(param_2,param_2);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 9881 ; VA 0x00706840 ; FUN_00706840 */

undefined4 * __thiscall FUN_00706840(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_2[6] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[6] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  return param_1;
}



/* FUNCTION 9882 ; VA 0x00706890 ; FUN_00706890 */

undefined4 * __fastcall FUN_00706890(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab604;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Network::ClusterPacketCache,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_00705fc0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  param_1[0x16] = RBX::Voxel2::GridListener::vftable;
  *param_1 = RBX::Network::ClusterPacketCache::vftable;
  param_1[0x16] = RBX::Network::ClusterPacketCache::vftable;
  *(undefined *)(param_1 + 0x17) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x18] = uVar1;
  param_1[0x19] = 0;
  param_1[0x1a] = 0x3f800000;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  *(undefined *)(param_1 + 0x1d) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x1e] = uVar1;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  uStack_8._0_1_ = 4;
  iVar2 = CreateSemaphoreA(0,0,0x7fffffff,0);
  if (iVar2 == 0) {
    uVar1 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar1);
  }
  param_1[0x24] = iVar2;
  iVar2 = CreateSemaphoreA(0,0,0x7fffffff,0);
  param_1[0x25] = iVar2;
  if (iVar2 == 0) {
    FUN_006ddd60(param_1[0x24],0x7fffffff);
    uVar1 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar1);
  }
  iVar2 = CreateSemaphoreA(0,0,0x7fffffff,0);
  param_1[0x26] = iVar2;
  if (iVar2 == 0) {
    FUN_006ddd60(param_1[0x24],0x7fffffff);
    FUN_006ddd60(param_1[0x25],0x7fffffff);
    uVar1 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar1);
  }
  param_1[0x23] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  uStack_8._0_1_ = 10;
  param_1[0x2b] = 0;
  FUN_016f4053(param_1 + 0x2c,8,2,FUN_005502b0,FUN_00550b30);
  uStack_8._0_1_ = 0xb;
  FUN_016f4053(param_1 + 0x30,0x18,2,FUN_00706f50,FUN_00706d60);
  uStack_8._0_1_ = 0xc;
  FUN_016f4053(param_1 + 0x3c,0x18,2,FUN_00706f50,FUN_00706d60);
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  uStack_8._0_1_ = 0xe;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("ClusterPacketCache",0x12);
  uStack_8._0_1_ = 0xf;
  FUN_008a6520(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (DAT_01d5be48 == '\0') {
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_14 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 0;
      puStack_14[2] = 0;
      puStack_14[3] = 0;
      puStack_14[4] = 0;
      puStack_14[5] = 0;
      puStack_14[6] = 0;
      puStack_14[7] = 0;
      puStack_14[8] = 0;
      *(undefined *)(puStack_14 + 9) = 0;
      puVar3 = puStack_14;
    }
  }
  else {
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_14 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 0;
      puStack_14[2] = 0;
      puStack_14[3] = 0;
      puStack_14[4] = 0;
      puStack_14[5] = 0;
      puStack_14[6] = 0;
      puStack_14[7] = 0;
      puStack_14[8] = 0;
      *(undefined *)(puStack_14 + 9) = 0;
      puVar3 = puStack_14;
    }
    FUN_007067d0(puVar3);
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_14 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 0;
      puStack_14[2] = 0;
      puStack_14[3] = 0;
      puStack_14[4] = 0;
      puStack_14[5] = 0;
      puStack_14[6] = 0;
      puStack_14[7] = 0;
      puStack_14[8] = 0;
      *(undefined *)(puStack_14 + 9) = 1;
      puVar3 = puStack_14;
    }
  }
  FUN_007067d0(puVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9883 ; VA 0x00706c80 ; FUN_00706c80 */

void __fastcall FUN_00706c80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00706ca9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 9884 ; VA 0x00706cb0 ; FUN_00706cb0 */

void __fastcall FUN_00706cb0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if ((*(char *)(param_1 + 9) != '\0') && (*(undefined4 **)(iVar1 + 0x18) != (undefined4 *)0x0)) {
      (**(code **)**(undefined4 **)(iVar1 + 0x18))(1);
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 9885 ; VA 0x00706ce0 ; FUN_00706ce0 */

void __fastcall FUN_00706ce0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00707c60(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9886 ; VA 0x00706d60 ; FUN_00706d60 */

void __fastcall FUN_00706d60(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00707c60(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9887 ; VA 0x00706d70 ; FUN_00706d70 */

int * __thiscall FUN_00706d70(byte *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined8 *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_00ca2680(param_2);
  FUN_006e16e0(&param_2,uVar5,puVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (undefined8 *)0x0) {
    uVar1 = *puVar4;
    iVar8 = *(int *)(puVar4 + 1);
    uStack_8 = 0;
    piVar6 = (int *)FUN_01674e20(0x1c);
    *piVar6 = 0;
    piVar6[1] = 0;
    piVar6[5] = 0;
    piVar6[6] = 0;
    *(undefined8 *)(piVar6 + 2) = uVar1;
    piVar6[4] = iVar8;
    *(undefined *)(piVar6 + 5) = 1;
    piVar6[6] = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar7 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005d6bb0(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      param_2 = (undefined8 *)0x1;
      uVar9 = uVar2 >> 1;
      if (uVar2 + (uVar2 >> 1) <= uVar7) {
        uVar9 = 1;
      }
      iVar8 = FUN_005d6bb0(uVar9 + uVar2);
      if (iVar8 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar8);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar11;
        while (puVar3 != (undefined4 *)0x0) {
          piVar10 = (int *)(*(int *)(param_1 + 0x14) +
                           ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar10 = (int)puVar11;
            puVar11 = puVar3;
          }
          else {
            *puVar11 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar10;
            *(undefined4 **)*piVar10 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar6[1] = uVar5;
    uVar5 = uVar5 % *(uint *)(param_1 + 4);
    piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (piVar10 == (int *)0x0) {
      piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar10 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar6;
      }
      *puVar11 = piVar10;
      *piVar6 = *piVar10;
    }
    else {
      *piVar6 = *piVar10;
      piVar10 = (int *)*puVar11;
    }
    *piVar10 = (int)piVar6;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar6 + 2;
  }
  ExceptionList = pvStack_10;
  return (int *)(param_2 + 1);
}



/* FUNCTION 9888 ; VA 0x00706f43 ; FUN_00706f43 */

void FUN_00706f43(void)

{
  FUN_00706fc0();
  return;
}



/* FUNCTION 9889 ; VA 0x00706f50 ; FUN_00706f50 */

void __fastcall FUN_00706f50(undefined *param_1)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return;
}



/* FUNCTION 9890 ; VA 0x00706f90 ; FUN_00706f90 */

undefined4 __thiscall FUN_00706f90(undefined4 param_1,byte param_2)

{
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 9891 ; VA 0x00706fc0 ; FUN_00706fc0 */

undefined4 * __thiscall FUN_00706fc0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::ClusterPacketCache::vftable;
  param_1[0x16] = RBX::Network::ClusterPacketCache::vftable;
  piVar2 = (int *)param_1[0x49];
  uStack_8 = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x3c,0x18,2,FUN_00706d60);
  FUN_016f32d1(param_1 + 0x30,0x18,2,FUN_00706d60);
  FUN_016f32d1(param_1 + 0x2c,8,2,FUN_00550b30);
  piVar2 = (int *)param_1[0x2a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x28];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  CloseHandle(param_1[0x26]);
  CloseHandle(param_1[0x24]);
  CloseHandle(param_1[0x25]);
  FUN_00706ce0();
  FUN_00706ce0();
  param_1[0x16] = RBX::Voxel2::GridListener::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x128);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9892 ; VA 0x00707120 ; FUN_00707120 */

undefined4 __thiscall FUN_00707120(undefined4 param_1,byte param_2)

{
  FUN_00577ac0();
  FUN_00617ad0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 9893 ; VA 0x00707150 ; FUN_00707150 */

void __fastcall FUN_00707150(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00577ac0();
    FUN_00617ad0();
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 9894 ; VA 0x00707180 ; FUN_00707180 */

void __thiscall FUN_00707180(int param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  undefined uVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  uint uVar13;
  int iVar14;
  int iStack_8c;
  undefined auStack_84 [8];
  int *piStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined2 uStack_68;
  undefined2 uStack_66;
  int *piStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  int *piStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab650;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_00a70e60(&iStack_40);
  iStack_20 = 0;
  uStack_8 = 0;
  if (*(char *)(param_2 + 0x37f8) != '\0') {
    iStack_20 = 3;
  }
  if (DAT_01d5be48 == '\0') {
    iVar8 = 0x120;
  }
  else {
    piStack_14 = *(int **)(param_2 + 0x380c);
    if (((*(uint *)(param_2 + 0x3808) & 0x2000000) == 0) ||
       (iVar8 = 0xb8, (*(uint *)(param_2 + 0x3808) & 0x20000000) == 0)) {
      iVar8 = 0xb0;
    }
  }
  piVar9 = (int *)(iVar8 + param_1);
  iVar8 = iStack_3c - iStack_40 >> 0x1f;
  piStack_24 = piVar9;
  if ((iStack_3c - iStack_40) / 0x18 + iVar8 == iVar8) {
    *(undefined *)(param_2 + 0x18fc) = 1;
    goto LAB_0070769b;
  }
  iVar8 = ((int *)*piVar9)[8];
  if ((iVar8 != 0) && (iStack_20 == *(int *)*piVar9)) {
    FUN_0056ecd0(piVar9);
    *(undefined *)(param_2 + 0x18fc) = 0;
    goto LAB_0070769b;
  }
  if (DAT_01d5be48 == '\0') {
    if (iVar8 != 0) {
      piStack_14 = (int *)FUN_01674e20(0x28);
      if (piStack_14 == (int *)0x0) {
        piVar10 = (int *)0x0;
      }
      else {
        *piStack_14 = 0;
        piStack_14[1] = 0;
        piStack_14[2] = 0;
        piStack_14[3] = 0;
        piStack_14[4] = 0;
        piStack_14[5] = 0;
        piStack_14[6] = 0;
        piStack_14[7] = 0;
        piStack_14[8] = 0;
        *(undefined *)(piStack_14 + 9) = 0;
        piVar10 = piStack_14;
      }
      goto LAB_0070733e;
    }
  }
  else if (iVar8 != 0) {
    piVar10 = (int *)FUN_01674e20(0x28);
    piStack_14 = piVar10;
    if (piVar10 == (int *)0x0) {
      piVar9 = piStack_24;
      piVar10 = (int *)0x0;
    }
    else {
      uVar7 = FUN_0061f4f0();
      *piVar10 = 0;
      piVar10[1] = 0;
      piVar10[2] = 0;
      piVar10[3] = 0;
      piVar10[4] = 0;
      piVar10[5] = 0;
      piVar10[6] = 0;
      piVar10[7] = 0;
      piVar10[8] = 0;
      *(undefined *)(piVar10 + 9) = uVar7;
      piVar9 = piStack_24;
    }
LAB_0070733e:
    FUN_007067d0(piVar10);
  }
  iVar8 = DAT_01d59f08 << ((char)iStack_20 * '\x03' & 0x1fU);
  if (iVar8 == 0) {
    iVar8 = 1;
  }
  *(int *)*piVar9 = iStack_20;
  *(undefined4 *)(*piVar9 + 0x20) = 1;
  FUN_0056ecd0(piVar9);
  *(undefined *)(param_2 + 0x18fc) = 0;
  iStack_34 = 0;
  iStack_30 = 0;
  iStack_2c = 0;
  uStack_8._0_1_ = 1;
  uStack_28 = 0;
  piVar9 = (int *)0x0;
  iVar14 = 0;
  piStack_44 = (int *)0x0;
  iVar5 = iStack_3c - iStack_40 >> 0x1f;
  if ((iStack_3c - iStack_40) / 0x18 + iVar5 != iVar5) {
    piStack_4c = (int *)0x0;
LAB_007073c4:
    FUN_00a70da0(&uStack_78,4);
    iVar5 = uStack_70._4_4_;
    uStack_5c = CONCAT44(uStack_74,uStack_78);
    puStack_60 = &uStack_78;
    uVar6 = CONCAT26(uStack_66,CONCAT24(uStack_68,uStack_70._4_4_));
    piStack_54 = (int *)uStack_70;
    piStack_14 = piStack_64;
    do {
      if ((int)uStack_5c == iVar5) {
        iStack_8c = (int)((ulonglong)uVar6 >> 0x20);
        if ((uStack_5c._4_4_ == iStack_8c) && (piStack_54 == piStack_14)) goto LAB_00707486;
      }
      iVar2 = *piStack_24;
      puVar3 = *(undefined8 **)(iVar2 + 8);
      piStack_7c = piStack_54;
      if (*(undefined8 **)(iVar2 + 0xc) == puVar3) {
        FUN_00706320(puVar3,auStack_84);
      }
      else {
        *puVar3 = uStack_5c;
        *(int **)(puVar3 + 1) = piStack_54;
        *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 0xc;
      }
      iVar14 = iVar14 + 1;
      piVar9 = (int *)((int)piVar9 + 1);
      if (iVar14 == iVar8) {
        FUN_00707a30(param_3,piStack_44,iVar14,iVar8,iStack_20,param_2,&iStack_34);
        iVar14 = 0;
        piStack_44 = piVar9;
      }
      FUN_00a6e100();
    } while( true );
  }
LAB_007074d4:
  if (*(int *)(iStack_1c + 0xa4) == 0) {
    uStack_74 = 0;
    uStack_78 = 0;
    uStack_68 = 1;
    uStack_70 = (double)DAT_01d59f10 * DAT_018e0008;
    uVar11 = FUN_008f7870(param_2);
    FUN_005c4330(&iStack_48,uVar11);
    piVar9 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piStack_44[1] = piStack_44[1] + 1;
      UNLOCK();
    }
    if (iStack_48 == 0) {
      iStack_18 = 0;
    }
    else {
      iStack_18 = iStack_48 + 8;
    }
    piStack_14 = piStack_44;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar12 = (undefined4 *)FUN_0151d9e0(auStack_50,&iStack_18,8,&uStack_78);
    uVar11 = *puVar12;
    uVar4 = puVar12[1];
    *puVar12 = 0;
    puVar12[1] = 0;
    *(undefined4 *)(iStack_1c + 0xa4) = uVar11;
    piVar10 = *(int **)(iStack_1c + 0xa8);
    *(undefined4 *)(iStack_1c + 0xa8) = uVar4;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar8 = piVar10[1] + -1;
      piVar10[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar8 = piVar10[2] + -1;
        piVar10[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    piVar10 = piStack_4c;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    piVar10 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_14[1] + -1;
      piStack_14[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 1;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar8 = piVar9[1] + -1;
      piVar9[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        piVar10 = piVar9 + 2;
        iVar8 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  FUN_006c74e0(iStack_34,(iStack_30 - iStack_34 & 0xffffffe0U) + iStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_34 != 0) {
    FUN_006ce110(iStack_34,iStack_30,&iStack_34);
    uVar13 = iStack_2c - iStack_34 & 0xffffffe0;
    iVar8 = iStack_34;
    if (0xfff < uVar13) {
      iVar8 = *(int *)(iStack_34 + -4);
      uVar13 = uVar13 + 0x23;
      if (0x1f < (iStack_34 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar13);
  }
LAB_0070769b:
  if (iStack_40 != 0) {
    uVar13 = ((iStack_38 - iStack_40) / 0x18) * 0x18;
    iVar8 = iStack_40;
    if (0xfff < uVar13) {
      iVar8 = *(int *)(iStack_40 + -4);
      uVar13 = uVar13 + 0x23;
      if (0x1f < (iStack_40 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
LAB_00707486:
  uStack_28 = uStack_28 + 1;
  piStack_4c = piStack_4c + 6;
  if ((uint)((iStack_3c - iStack_40) / 0x18) <= uStack_28) goto code_r0x007074b0;
  goto LAB_007073c4;
code_r0x007074b0:
  if (iVar14 != 0) {
    FUN_00707a30(param_3,piStack_44,iVar14,iVar8,iStack_20,param_2,&iStack_34);
  }
  goto LAB_007074d4;
}



/* FUNCTION 9895 ; VA 0x00707700 ; FUN_00707700 */

void * FUN_00707700(uint param_1,int param_2,uint param_3,int param_4,int *param_5,
                   undefined4 param_6,int param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined1 *puVar5;
  void *pvVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined auStack_a8 [16];
  int iStack_98;
  int *piStack_94;
  undefined8 uStack_90;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  undefined **appuStack_6c [3];
  int iStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ab683;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  pvVar6 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_28 = 0;
    uStack_24 = 0xf;
    uStack_38 = uStack_38 & 0xffffff00;
    uStack_8 = 1;
    uStack_7 = 0;
    ExceptionList = &pvStack_10;
    FUN_006ab530();
    uStack_8 = 2;
    uVar4 = uStack_8;
    uStack_8 = 2;
    iVar10 = (*(int *)(param_4 + 8) - *(int *)(param_4 + 4)) / 0xc - param_1;
    if (param_2 < iVar10) {
      iVar10 = param_2;
    }
    if (0 < iVar10) {
      iStack_20 = 4 - param_7;
      iVar7 = param_1 * 0xc;
      do {
        iVar3 = iStack_20;
        uStack_1c = *(undefined8 *)(*(int *)(param_4 + 4) + iVar7);
        iStack_14 = *(int *)(*(int *)(param_4 + 4) + 8 + iVar7);
        FUN_006bd680(iStack_20,param_7,&uStack_1c,appuStack_6c);
        iStack_78 = (int)uStack_1c * 0x10;
        iStack_84 = iStack_78 + 0x10;
        iStack_74 = uStack_1c._4_4_ * 0x10;
        iStack_80 = iStack_74 + 0x10;
        uStack_90 = CONCAT44(iStack_74,iStack_78);
        iStack_88 = iStack_14 * 0x10;
        iStack_7c = iStack_88 + 0x10;
        FUN_00a71760(auStack_a8,&uStack_90,param_7,1);
        _uStack_8 = CONCAT31(uStack_7,3);
        if (DAT_01eace39 != '\0') {
          puVar5 = &DAT_018bdf50;
          if (iStack_98 != 0) {
            puVar5 = &DAT_018bdf48;
          }
          FUN_01677520(DAT_01eace39,"Cluster initial cache line created for (%d,%d,%d) isEmpty=%s",
                       (int)uStack_1c,uStack_1c._4_4_,iStack_14,puVar5);
        }
        FUN_006bd630(iVar3,auStack_a8,appuStack_6c);
        if (*(char *)(param_4 + 0x24) != '\0') {
          FUN_006bd8f0(0,appuStack_6c);
        }
        piVar2 = piStack_94;
        uStack_8 = 2;
        if (piStack_94 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_94[1] + -1;
          piStack_94[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_94)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar3 = *piVar1 + -1;
            *piVar1 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        iVar7 = iVar7 + 0xc;
        iVar10 = iVar10 + -1;
      } while (iVar10 != 0);
      FUN_00619a10(appuStack_6c,*(undefined4 *)(*(int *)(param_4 + 0x14) + (param_1 / param_3) * 8),
                   DAT_01d59e64);
      uVar4 = uStack_8;
    }
    uStack_8 = uVar4;
    LOCK();
    *(int *)(param_4 + 0x10) = *(int *)(param_4 + 0x10) + 1;
    UNLOCK();
    pvVar6 = (void *)(*(int *)(param_4 + 0x18) - *(int *)(param_4 + 0x14) >> 3);
    if (*(void **)(param_4 + 0x10) == pvVar6) {
      *(undefined4 *)(param_4 + 0x20) = 2;
    }
    if (iStack_60 != 0) {
      uVar8 = iStack_58 - iStack_60;
      iVar10 = iStack_60;
      if (0xfff < uVar8) {
        iVar10 = *(int *)(iStack_60 + -4);
        uVar8 = uVar8 + 0x23;
        if (0x1f < (iStack_60 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      pvVar6 = (void *)FUN_01674ea0(iVar10,uVar8);
      iStack_60 = 0;
      uStack_5c = 0;
      iStack_58 = 0;
    }
    appuStack_6c[0] = RakNet::AbstractBitStream::vftable;
    if (0xf < uStack_24) {
      uVar9 = uStack_24 + 1;
      uVar8 = uStack_38;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_38 - 4);
        uVar9 = uStack_24 + 0x24;
        if (0x1f < (uStack_38 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      pvVar6 = (void *)FUN_01674ea0(uVar8,uVar9);
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar2 = param_5 + 1;
    iVar10 = *piVar2;
    pvVar6 = (void *)*piVar2;
    *piVar2 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      pvVar6 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar10 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        pvVar6 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 9896 ; VA 0x007079f0 ; FUN_007079f0 */

void __fastcall FUN_007079f0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  if (*(int *)(param_1 + 8) != 0) {
    FUN_00707c60(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4,0);
    puVar2 = *(undefined4 **)(param_1 + 0x14);
    puVar1 = puVar2 + *(int *)(param_1 + 4);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  return;
}



/* FUNCTION 9897 ; VA 0x00707a30 ; FUN_00707a30 */

int __thiscall
FUN_00707a30(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,int param_7,int param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_7;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab6b7;
  pvStack_10 = ExceptionList;
  if (DAT_01d5be48 == '\0') {
    iVar5 = 0x120;
  }
  else {
    piStack_20 = *(int **)(param_7 + 0x380c);
    if (((*(uint *)(param_7 + 0x3808) & 0x2000000) == 0) ||
       (iVar5 = 0xb8, (*(uint *)(param_7 + 0x3808) & 0x20000000) == 0)) {
      iVar5 = 0xb0;
    }
  }
  piVar2 = (int *)(iVar5 + param_1);
  ExceptionList = &pvStack_10;
  param_7 = FUN_01674e20(0x28);
  uStack_8 = 0;
  if (param_7 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_006ab530();
  }
  uStack_8 = 0xffffffff;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_00604a80(uVar6,param_2);
  piVar7 = (int *)piVar2[1];
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = (int *)piVar2[1];
  }
  iStack_24 = *piVar2;
  uStack_8 = 2;
  param_7._0_1_ = 0x8d;
  piStack_20 = piVar7;
  iStack_14 = iStack_24;
  FUN_006ad5e0(&param_7,1);
  FUN_006b9320(uStack_1c,param_2);
  if (((*(uint *)(iVar3 + 0x380c) & 2) != 0) && (*(char *)(iVar3 + 0x37f8) != '\0')) {
    param_7._0_1_ = 1;
    FUN_006ad5e0(&param_7,1);
  }
  iVar3 = *piVar2;
  puVar4 = *(undefined4 **)(iVar3 + 0x18);
  if (*(undefined4 **)(iVar3 + 0x1c) == puVar4) {
    FUN_005c1970(puVar4,&uStack_1c);
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    *puVar4 = uStack_1c;
    puVar4[1] = piStack_18;
    *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 8;
  }
  piVar2 = piStack_18;
  iVar3 = param_8;
  uStack_40 = param_2;
  uStack_3c = param_3;
  uStack_38 = param_4;
  uStack_34 = param_5;
  uStack_30 = param_6;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  iStack_2c = iStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piStack_28 = piVar7;
  if (*(int *)(param_8 + 8) == *(int *)(param_8 + 4)) {
    iVar5 = FUN_007060c0(*(int *)(param_8 + 4),&uStack_40);
  }
  else {
    iVar5 = FUN_00706770(param_8);
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0x20;
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar7 = piVar2 + 1;
    iVar3 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piVar2)();
      LOCK();
      piVar7 = piVar2 + 2;
      iVar3 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9898 ; VA 0x00707c60 ; FUN_00707c60 */

int __thiscall FUN_00707c60(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    if ((undefined4 *)puVar1[6] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)puVar1[6])(1);
    }
    FUN_01674ea0(puVar1,0x1c);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 9899 ; VA 0x00707cb0 ; FUN_00707cb0 */

uint __thiscall
FUN_00707cb0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,byte *param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  uint *puVar9;
  uint uVar10;
  undefined auStack_34 [8];
  int iStack_2c;
  undefined uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab6e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar1 = FUN_01675290(DAT_01eadc98);
  iStack_2c = param_1 + 0x8c;
  uStack_8 = 0;
  uStack_28 = 0;
  uStack_1c = uVar1;
  if (iStack_2c == 0) {
    uVar1 = FUN_0056aeb0(1,"boost shared_lock has no mutex");
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar1);
  }
  uStack_24 = 0xffffffff;
  uStack_20 = 0x7fffffff;
  uStack_14 = 0xffffffff;
  FUN_005672c0(&uStack_14,&uStack_24);
  FUN_006dfe10(auStack_34);
  uStack_28 = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (DAT_01d5be48 == '\0') {
    iVar5 = 0x74;
    if ((char)param_5 == '\0') {
      iVar5 = 0x5c;
    }
  }
  else {
    iVar5 = FUN_00707eb0(param_2);
    if ((char)param_5 == '\0') {
      iVar5 = iVar5 * 3 + 0x18;
    }
    else {
      iVar5 = iVar5 * 3 + 0x1e;
    }
    iVar5 = iVar5 * 8;
  }
  uVar3 = param_3;
  param_5 = (byte *)(iVar5 + param_1);
  pbVar8 = param_5 + *param_5 + 1;
  uVar2 = FUN_00ca2680(param_3);
  FUN_006e16e0(&param_2,uVar2,uVar3,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  iVar5 = param_2;
  if ((param_2 == 0) || (*(char *)(param_2 + 0x14) != '\0')) {
    param_5 = (byte *)((uint)param_5 & 0xffffff);
  }
  else {
    uVar3 = (**(code **)(**(int **)(param_2 + 0x18) + 8))();
    uVar2 = (**(code **)(**(int **)(iVar5 + 0x18) + 4))();
    FUN_006ad5e0(uVar2,uVar3);
    param_5 = (byte *)CONCAT13(1,param_5._0_3_);
  }
  puVar9 = (uint *)(iStack_18 + 0x8c);
  uStack_8 = uStack_8 & 0xffffff00;
  uVar4 = *puVar9;
  do {
    uVar7 = uVar4;
    uVar6 = (uVar7 - 1 ^ uVar7) & 0x7ff ^ uVar7;
    uVar10 = uVar6 & 0x7ff;
    if (uVar10 == 0) {
      if ((uVar6 & 0x800000) == 0) {
        if ((uVar7 >> 0x18 & 0x7f) != 0) {
          uVar6 = uVar6 & 0xffffff | ((uVar7 >> 0x18) - 1 & 0x7f) << 0x18;
        }
        uVar6 = uVar6 & 0xffc007ff;
      }
      else {
        uVar6 = uVar6 & 0xff7fffff | 0x400000;
      }
    }
    LOCK();
    uVar4 = *puVar9;
    if (uVar7 == uVar4) {
      *puVar9 = uVar6;
      uVar4 = uVar7;
    }
    UNLOCK();
  } while (uVar4 != uVar7);
  if (uVar10 == 0) {
    if ((uVar7 & 0x800000) == 0) {
      FUN_006ddd80(uVar7);
    }
    else {
      ReleaseSemaphore(*(undefined4 *)(iStack_18 + 0x98),1,0);
    }
  }
  uStack_8 = 5;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return (uint)param_5 >> 0x18;
}



/* FUNCTION 9900 ; VA 0x00707eb0 ; FUN_00707eb0 */

undefined4 FUN_00707eb0(int param_1)

{
  if (((*(uint *)(param_1 + 0x3808) & 0x2000000) != 0) &&
     ((*(uint *)(param_1 + 0x3808) & 0x20000000) != 0)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 9901 ; VA 0x00707f00 ; FUN_00707f00 */

void FUN_00707f00(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  puVar2 = (undefined4 *)*param_1;
  uVar3 = puVar2[4];
  uVar4 = puVar2[3];
  uVar5 = *puVar2;
  uVar6 = puVar2[2];
  uVar7 = puVar2[1];
  if (puVar2[6] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[6] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00707700(uVar7,uVar6,uVar4,puVar2[5],puVar2[6],uVar5,uVar3);
  return;
}



/* FUNCTION 9902 ; VA 0x00707f60 ; FUN_00707f60 */

void FUN_00707f60(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x1c);
      if (iVar2 != 0) {
        iVar3 = FUN_00706840(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0x18);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar3,0x1c);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9dcfc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&<lambda_c48f7e8b175de40bc368d7aa6c25d3ec>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9903 ; VA 0x00708050 ; FUN_00708050 */

void __thiscall FUN_00708050(int param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  
  if (param_2 != 0) {
    if (DAT_01d5be48 == '\0') {
      FUN_007079f0();
      FUN_007079f0();
    }
    else {
      piVar5 = (int *)(param_1 + 0xc4);
      iVar4 = 2;
      do {
        if (piVar5[1] != 0) {
          FUN_00707c60(piVar5[4] + *piVar5 * 4,0);
          puVar3 = (undefined4 *)piVar5[4];
          puVar2 = puVar3 + *piVar5;
          for (; puVar3 != puVar2; puVar3 = puVar3 + 1) {
            *puVar3 = 0;
          }
        }
        if (piVar5[0xd] != 0) {
          FUN_00707c60(piVar5[0x10] + piVar5[0xc] * 4,0);
          puVar3 = (undefined4 *)piVar5[0x10];
          puVar2 = puVar3 + piVar5[0xc];
          for (; puVar3 != puVar2; puVar3 = puVar3 + 1) {
            *puVar3 = 0;
          }
        }
        piVar5 = piVar5 + 6;
        iVar4 = iVar4 + -1;
      } while (iVar4 != 0);
    }
    if (*(int *)(param_1 + 0x9c) != 0) {
      FUN_00a6f530(param_1 + 0x58);
      *(undefined4 *)(param_1 + 0x9c) = 0;
      piVar5 = *(int **)(param_1 + 0xa0);
      *(undefined4 *)(param_1 + 0xa0) = 0;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    if (*(int *)(param_1 + 0xa4) != 0) {
      FUN_0153a3f0();
      *(undefined4 *)(param_1 + 0xa4) = 0;
      piVar5 = *(int **)(param_1 + 0xa8);
      *(undefined4 *)(param_1 + 0xa8) = 0;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 9904 ; VA 0x007081c0 ; FUN_007081c0 */

void __thiscall FUN_007081c0(int param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  undefined8 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined8 uStack_58;
  int iStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  undefined8 uStack_3c;
  undefined8 *puStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  undefined8 uStack_20;
  int iStack_18;
  undefined8 uStack_14;
  int iStack_c;
  undefined4 *puStack_8;
  
  if (DAT_01d5be48 == '\0') {
    if ((*(int *)(param_1 + 200) != 0) && (*(int *)(*(int *)(param_1 + 200) + 0x20) != 0)) {
      puStack_8 = (undefined4 *)FUN_01674e20(0x28);
      if (puStack_8 == (undefined4 *)0x0) {
        puVar3 = (undefined4 *)0x0;
      }
      else {
        *puStack_8 = 0;
        puStack_8[1] = 0;
        puStack_8[2] = 0;
        puStack_8[3] = 0;
        puStack_8[4] = 0;
        puStack_8[5] = 0;
        puStack_8[6] = 0;
        puStack_8[7] = 0;
        puStack_8[8] = 0;
        *(undefined *)(puStack_8 + 9) = 0;
        puVar3 = puStack_8;
      }
      FUN_007067d0(puVar3);
    }
  }
  else {
    piVar6 = (int *)(param_1 + 0x58);
    iVar7 = 2;
    do {
      if ((*piVar6 != 0) && (*(int *)(*piVar6 + 0x20) != 0)) {
        puStack_8 = (undefined4 *)FUN_01674e20(0x28);
        if (puStack_8 == (undefined4 *)0x0) {
          puVar3 = (undefined4 *)0x0;
        }
        else {
          uVar1 = *(undefined *)(*piVar6 + 0x24);
          *puStack_8 = 0;
          puStack_8[1] = 0;
          puStack_8[2] = 0;
          puStack_8[3] = 0;
          puStack_8[4] = 0;
          puStack_8[5] = 0;
          puStack_8[6] = 0;
          puStack_8[7] = 0;
          puStack_8[8] = 0;
          *(undefined *)(puStack_8 + 9) = uVar1;
          puVar3 = puStack_8;
        }
        FUN_007067d0(puVar3);
      }
      piVar6 = piVar6 + 2;
      iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
  }
  if (param_3 == 0) {
    FUN_00a70da0(&uStack_58,4);
    if (DAT_01d5be48 == '\0') {
      puStack_30 = &uStack_58;
      uStack_3c = uStack_4c;
      uVar2 = uStack_3c;
      uStack_3c._4_4_ = (int)((ulonglong)uStack_4c >> 0x20);
      iVar7 = uStack_3c._4_4_;
      uStack_2c = uStack_58;
      iStack_24 = iStack_50;
      uStack_3c = uVar2;
      while( true ) {
        if ((((int)uStack_2c == (int)uStack_3c) && (uStack_2c._4_4_ == iVar7)) &&
           (iStack_24 == iStack_44)) break;
        uStack_20 = uStack_2c;
        iStack_18 = iStack_24;
        iVar5 = FUN_00706d70(&uStack_20);
        *(undefined *)(iVar5 + 0xc) = 1;
        iStack_c = iStack_24;
        uStack_14 = uStack_2c;
        iVar5 = FUN_00706d70(&uStack_14);
        *(undefined *)(iVar5 + 0xc) = 1;
        FUN_00a6e100();
      }
    }
    else {
      param_3 = 2;
      do {
        iVar7 = iStack_44;
        puStack_30 = &uStack_58;
        uStack_3c = uStack_4c;
        uVar2 = uStack_3c;
        uStack_3c._4_4_ = (int)((ulonglong)uStack_4c >> 0x20);
        iVar5 = uStack_3c._4_4_;
        uStack_2c = uStack_58;
        iStack_24 = iStack_50;
        uStack_3c = uVar2;
        while( true ) {
          if ((((int)uStack_2c == (int)uStack_3c) && (uStack_2c._4_4_ == iVar5)) &&
             (iStack_24 == iVar7)) break;
          uStack_14 = uStack_2c;
          iStack_c = iStack_24;
          iVar4 = FUN_00706d70(&uStack_14);
          *(undefined *)(iVar4 + 0xc) = 1;
          iStack_18 = iStack_24;
          uStack_20 = uStack_2c;
          iVar4 = FUN_00706d70(&uStack_20);
          *(undefined *)(iVar4 + 0xc) = 1;
          FUN_00a6e100();
        }
        param_3 = param_3 + -1;
      } while (param_3 != 0);
    }
  }
  return;
}



/* FUNCTION 9905 ; VA 0x00708420 ; FUN_00708420 */

void __thiscall FUN_00708420(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x9c) == 0) {
    FUN_00a6e300(param_1 + 0x58);
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x9c) = uVar1;
    piVar3 = *(int **)(param_1 + 0xa0);
    *(undefined4 *)(param_1 + 0xa0) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return;
}



/* FUNCTION 9906 ; VA 0x007084d0 ; FUN_007084d0 */

undefined4 __thiscall
FUN_007084d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_30 [8];
  int iStack_28;
  undefined uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab727;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01eafe0c);
  iStack_28 = param_1 + 0x8c;
  uStack_8 = 0;
  uStack_24 = 0;
  uStack_18 = uVar2;
  if (iStack_28 != 0) {
    uStack_20 = 0xffffffff;
    uStack_1c = 0x7fffffff;
    uStack_14 = 0xffffffff;
    FUN_005672c0(&uStack_14,&uStack_20);
    FUN_006dfad0(auStack_30);
    uStack_24 = 1;
    uStack_8._0_1_ = 3;
    if (DAT_01d5be48 != '\0') {
      FUN_00707eb0(param_2);
    }
    iVar3 = FUN_00706d70(param_3);
    if (*(int *)(iVar3 + 0x10) == 0) {
      iVar4 = FUN_01674e20(0x28);
      uStack_8._0_1_ = 4;
      if (iVar4 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_006ab530();
      }
      puVar1 = *(undefined4 **)(iVar3 + 0x10);
      uStack_8._0_1_ = 3;
      *(undefined4 *)(iVar3 + 0x10) = uVar5;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
    }
    FUN_006ab670();
    FUN_006add40(param_4,param_5);
    *(undefined *)(iVar3 + 0xc) = 0;
    FUN_006e00b0();
    uStack_8 = 5;
    FUN_01675290(uVar2);
    ExceptionList = pvStack_10;
    return 1;
  }
  uVar2 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar2);
}



/* FUNCTION 9907 ; VA 0x00708640 ; FUN_00708640 */

int FUN_00708640(undefined4 param_1,undefined4 param_2,undefined8 *param_3,undefined4 *param_4,
                undefined *param_5)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_0070ad60(param_1,param_2);
  uVar1 = *param_5;
  uVar2 = *param_4;
  uVar3 = *(undefined4 *)(param_3 + 1);
  *(undefined8 *)(iVar4 + 8) = *param_3;
  *(undefined *)(iVar4 + 0x18) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar3;
  *(undefined4 *)(iVar4 + 0x14) = uVar2;
  return iVar4;
}



/* FUNCTION 9908 ; VA 0x00708680 ; FUN_00708680 */

void FUN_00708680(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  
  iVar1 = FUN_0070ad30(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *(undefined4 *)*param_4;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  return;
}



/* FUNCTION 9909 ; VA 0x007086b0 ; FUN_007086b0 */

void FUN_007086b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  
  iVar1 = FUN_005e9aa0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *(undefined4 *)*param_4;
  *(undefined4 *)(iVar1 + 0xc) = 0;
  return;
}



/* FUNCTION 9910 ; VA 0x007086e0 ; FUN_007086e0 */

int __thiscall FUN_007086e0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  
  iVar2 = *param_1;
  iVar3 = param_1[1] - iVar2 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar7 = param_1[2] - iVar2 >> 3;
  uVar8 = uVar1;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar8 = (uVar7 >> 1) + uVar7, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  iVar4 = FUN_00578020(uVar8);
  iVar2 = (param_2 - iVar2 >> 3) * 8;
  *(undefined4 *)(iVar2 + iVar4) = 0;
  *(undefined4 *)(iVar2 + 4 + iVar4) = 0;
  *(undefined4 *)(iVar2 + iVar4) = *param_3;
  *(undefined4 *)(iVar2 + 4 + iVar4) = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  iVar6 = param_1[1];
  iVar3 = *param_1;
  iVar5 = iVar4;
  if (param_2 != iVar6) {
    FUN_005c23f0(iVar3,param_2,iVar4,param_1);
    iVar6 = param_1[1];
    iVar5 = iVar2 + 8 + iVar4;
    iVar3 = param_2;
  }
  FUN_005c23f0(iVar3,iVar6,iVar5,param_1);
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar3 = *param_1;
    uVar7 = param_1[2] - iVar3 & 0xfffffff8;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + uVar1 * 8;
  param_1[2] = iVar4 + uVar8 * 8;
  return *param_1 + iVar2;
}



/* FUNCTION 9911 ; VA 0x00708820 ; FUN_00708820 */

void __thiscall FUN_00708820(int *param_1,int *param_2,byte *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  undefined4 *puVar6;
  byte *pbVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  bool bVar11;
  undefined4 *puStack_18;
  undefined4 *puStack_8;
  
  puStack_18 = (undefined4 *)*param_1;
  puVar6 = puStack_18 + 1;
  puStack_8 = puStack_18;
  if (*(char *)((int)puStack_18[1] + 0xd) == '\0') {
    uVar1 = *(uint *)(param_3 + 0x10);
    puVar8 = (undefined4 *)puStack_18[1];
    do {
      pbVar7 = (byte *)(puVar8 + 4);
      pbVar5 = param_3;
      if (0xf < *(uint *)(param_3 + 0x14)) {
        pbVar5 = *(byte **)param_3;
      }
      pbVar10 = pbVar7;
      if (0xf < (uint)puVar8[9]) {
        pbVar10 = *(byte **)pbVar7;
      }
      uVar3 = puVar8[8];
      if (*(uint *)(param_3 + 0x10) < (uint)puVar8[8]) {
        uVar3 = *(uint *)(param_3 + 0x10);
      }
      while (uVar4 = uVar3 - 4, 3 < uVar3) {
        if (*(int *)pbVar10 != *(int *)pbVar5) goto LAB_00708898;
        pbVar10 = pbVar10 + 4;
        pbVar5 = pbVar5 + 4;
        uVar3 = uVar4;
      }
      if (uVar4 == 0xfffffffc) {
LAB_007088cc:
        uVar3 = 0;
      }
      else {
LAB_00708898:
        bVar11 = *pbVar10 < *pbVar5;
        if ((*pbVar10 == *pbVar5) &&
           ((uVar4 == 0xfffffffd ||
            ((bVar11 = pbVar10[1] < pbVar5[1], pbVar10[1] == pbVar5[1] &&
             ((uVar4 == 0xfffffffe ||
              ((bVar11 = pbVar10[2] < pbVar5[2], pbVar10[2] == pbVar5[2] &&
               ((uVar4 == 0xffffffff || (bVar11 = pbVar10[3] < pbVar5[3], pbVar10[3] == pbVar5[3])))
               ))))))))) goto LAB_007088cc;
        uVar3 = -(uint)bVar11 | 1;
      }
      if (uVar3 == 0) {
        uVar3 = puVar8[8];
        if (uVar3 < uVar1) {
          puVar9 = (undefined4 *)puVar8[2];
        }
        else {
LAB_007088f4:
          if (*(char *)((int)puStack_8 + 0xd) != '\0') {
            if (0xf < (uint)puVar8[9]) {
              pbVar7 = *(byte **)pbVar7;
            }
            pbVar5 = param_3;
            if (0xf < *(uint *)(param_3 + 0x14)) {
              pbVar5 = *(byte **)param_3;
            }
            uVar4 = uVar1;
            if (uVar3 < uVar1) {
              uVar4 = uVar3;
            }
            while (uVar2 = uVar4 - 4, 3 < uVar4) {
              if (*(int *)pbVar5 != *(int *)pbVar7) goto LAB_00708938;
              pbVar5 = pbVar5 + 4;
              pbVar7 = pbVar7 + 4;
              uVar4 = uVar2;
            }
            if (uVar2 == 0xfffffffc) {
LAB_0070896c:
              uVar4 = 0;
            }
            else {
LAB_00708938:
              bVar11 = *pbVar5 < *pbVar7;
              if ((*pbVar5 == *pbVar7) &&
                 ((uVar2 == 0xfffffffd ||
                  ((bVar11 = pbVar5[1] < pbVar7[1], pbVar5[1] == pbVar7[1] &&
                   ((uVar2 == 0xfffffffe ||
                    ((bVar11 = pbVar5[2] < pbVar7[2], pbVar5[2] == pbVar7[2] &&
                     ((uVar2 == 0xffffffff ||
                      (bVar11 = pbVar5[3] < pbVar7[3], pbVar5[3] == pbVar7[3]))))))))))))
              goto LAB_0070896c;
              uVar4 = -(uint)bVar11 | 1;
            }
            if (uVar4 == 0) {
              if (*(uint *)(param_3 + 0x10) < uVar3) {
LAB_0070897e:
                puStack_8 = puVar8;
              }
            }
            else if ((int)uVar4 < 0) goto LAB_0070897e;
          }
          puVar9 = (undefined4 *)*puVar8;
          puStack_18 = puVar8;
        }
      }
      else {
        if (-1 < (int)uVar3) {
          uVar3 = puVar8[8];
          goto LAB_007088f4;
        }
        puVar9 = (undefined4 *)puVar8[2];
      }
      puVar8 = puVar9;
    } while (*(char *)((int)puVar9 + 0xd) == '\0');
  }
  if (*(char *)((int)puStack_8 + 0xd) == '\0') {
    puVar6 = puStack_8;
  }
  if (*(char *)((int)*puVar6 + 0xd) == '\0') {
    uVar1 = *(uint *)(param_3 + 0x10);
    puVar6 = (undefined4 *)*puVar6;
    do {
      pbVar7 = (byte *)(puVar6 + 4);
      uVar3 = puVar6[8];
      if (0xf < (uint)puVar6[9]) {
        pbVar7 = *(byte **)pbVar7;
      }
      pbVar5 = param_3;
      if (0xf < *(uint *)(param_3 + 0x14)) {
        pbVar5 = *(byte **)param_3;
      }
      uVar4 = uVar1;
      if (uVar3 < uVar1) {
        uVar4 = uVar3;
      }
      while (uVar2 = uVar4 - 4, 3 < uVar4) {
        if (*(int *)pbVar5 != *(int *)pbVar7) goto LAB_007089fa;
        pbVar5 = pbVar5 + 4;
        pbVar7 = pbVar7 + 4;
        uVar4 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_00708a2e:
        uVar4 = 0;
      }
      else {
LAB_007089fa:
        bVar11 = *pbVar5 < *pbVar7;
        if ((*pbVar5 == *pbVar7) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar11 = pbVar5[1] < pbVar7[1], pbVar5[1] == pbVar7[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar11 = pbVar5[2] < pbVar7[2], pbVar5[2] == pbVar7[2] &&
               ((uVar2 == 0xffffffff || (bVar11 = pbVar5[3] < pbVar7[3], pbVar5[3] == pbVar7[3])))))
              ))))))) goto LAB_00708a2e;
        uVar4 = -(uint)bVar11 | 1;
      }
      if (uVar4 == 0) {
        if (uVar3 <= uVar1) goto LAB_00708a3b;
LAB_00708a64:
        puVar8 = (undefined4 *)*puVar6;
        puStack_8 = puVar6;
      }
      else {
        if ((int)uVar4 < 0) goto LAB_00708a64;
LAB_00708a3b:
        puVar8 = (undefined4 *)puVar6[2];
      }
      puVar6 = puVar8;
    } while (*(char *)((int)puVar8 + 0xd) == '\0');
  }
  *param_2 = (int)puStack_18;
  param_2[1] = (int)puStack_8;
  return;
}



/* FUNCTION 9912 ; VA 0x00708a70 ; FUN_00708a70 */

void __thiscall FUN_00708a70(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  float *pfStack_24;
  undefined auStack_20 [4];
  uint uStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab740;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  fVar3 = param_1[1];
  uStack_8 = 0;
  uStack_1c = (uint)param_1[6] &
              ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^
               (uint)param_3[2]) * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar4 = *(float *)((int)param_1[3] + uStack_1c * 8);
  pfStack_18 = param_1;
  if (fVar3 != fVar4) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uStack_1c * 8);
    while (fVar3 != fVar4) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffd0;
        FUN_0070cfc0(&pfStack_24,param_4);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_24 = param_4;
  fVar4 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar4) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar4;
    **(float **)((int)fVar4 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar4 + 4);
    *(float *)((int)fVar4 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar4 = param_1[3];
  fVar1 = *(float *)((int)fVar4 + uStack_1c * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar4 + uStack_1c * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uStack_1c * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar4 + uStack_1c * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar4 + 4 + uStack_1c * 8);
    *(float **)((int)fVar4 + 4 + uStack_1c * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uStack_1c * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uStack_1c * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar4 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar4 && fVar4 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar4 = *(float *)param_1[1];
        FUN_00708a70(auStack_20,(int)fVar4 + 8,fVar4);
      } while (fVar4 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9913 ; VA 0x00708c46 ; Catch_All@00708c46 */

void Catch_All_00708c46(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x20));
  FUN_00709790(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9914 ; VA 0x00708c6c ; Catch_All@00708c6c */

void Catch_All_00708c6c(void)

{
  int unaff_EBP;
  
  FUN_0070ae70(*(undefined4 *)(unaff_EBP + 0x10));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9915 ; VA 0x00708c90 ; FUN_00708c90 */

void __thiscall FUN_00708c90(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab750;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        puStack_14 = &stack0xffffffd0;
        FUN_01674ea0(param_4,0x10);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00708c90(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9916 ; VA 0x00708e76 ; Catch_All@00708e76 */

void Catch_All_00708e76(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_007097b0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9917 ; VA 0x00708ea0 ; FUN_00708ea0 */

void __thiscall FUN_00708ea0(int param_1,int *param_2,byte *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab760;
  pvStack_10 = ExceptionList;
  piVar7 = *(int **)(param_1 + 4);
  iVar6 = (*(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193) * 8;
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + iVar6);
  piVar9 = piVar7;
  if (piVar1 != piVar7) {
    piVar9 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar6);
  }
  do {
    if (piVar9 == piVar1) {
      iVar2 = *piVar7;
      uStack_8 = 0xffffffff;
      puVar3 = *(undefined4 **)(iVar2 + 4);
      ExceptionList = &pvStack_10;
      uVar5 = FUN_00602bf0(iVar2,puVar3,param_3);
      if (*(int *)(param_1 + 8) == 0x15555554) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *(undefined4 *)(iVar2 + 4) = uVar5;
      *puVar3 = uVar5;
      piVar7 = *(int **)(param_1 + 4);
      puVar3 = (undefined4 *)*piVar7;
      piVar1 = (int *)*puVar3;
      if (piVar9 != piVar1) {
        *(int **)puVar3[1] = piVar1;
        *(int **)piVar1[1] = piVar9;
        *(undefined4 **)piVar9[1] = puVar3;
        iVar2 = piVar9[1];
        piVar9[1] = piVar1[1];
        piVar1[1] = puVar3[1];
        puVar3[1] = iVar2;
        piVar7 = *(int **)(param_1 + 4);
      }
      puVar8 = (undefined4 *)(iVar6 + *(int *)(param_1 + 0xc));
      if ((int *)*puVar8 == piVar7) {
        *puVar8 = puVar3;
        *(undefined4 **)(iVar6 + 4 + *(int *)(param_1 + 0xc)) = puVar3;
      }
      else if ((int *)*puVar8 == piVar9) {
        *puVar8 = puVar3;
      }
      else {
        puVar4 = *(undefined4 **)puVar8[1];
        puVar8[1] = puVar4;
        if (puVar4 != puVar3) {
          iVar6 = iVar6 + *(int *)(param_1 + 0xc);
          *(undefined4 *)(iVar6 + 4) = *(undefined4 *)(*(int *)(iVar6 + 4) + 4);
        }
      }
      uStack_8 = 2;
      FUN_0070ad90();
      *param_2 = (int)puVar3;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    piVar9 = (int *)piVar9[1];
  } while (*(int *)param_3 != piVar9[2]);
  *param_2 = (int)piVar9;
  *(undefined *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9918 ; VA 0x00709028 ; Catch_All@00709028 */

void Catch_All_00709028(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0070cbb0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9919 ; VA 0x00709060 ; FUN_00709060 */

void __thiscall FUN_00709060(int param_1,int *param_2,byte *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab770;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar6 = *(int *)(param_1 + 4);
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193) * 8;
  iVar2 = *(int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (iVar6 != iVar2) {
    iVar6 = **(int **)(*(int *)(param_1 + 0xc) + 4 + iVar1);
    while (iVar6 != iVar2) {
      iVar6 = *(int *)(iVar6 + 4);
      if (*(int *)param_3 == *(int *)(iVar6 + 8)) {
        ExceptionList = &pvStack_10;
        *(int *)param_4[1] = *param_4;
        *(int *)(*param_4 + 4) = param_4[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        FUN_01674ea0(param_4,0xc);
        *param_2 = iVar6;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  iVar2 = *param_4;
  ExceptionList = &pvStack_10;
  if (iVar6 != iVar2) {
    ExceptionList = &pvStack_10;
    *(int *)param_4[1] = iVar2;
    **(int **)(iVar2 + 4) = iVar6;
    **(undefined4 **)(iVar6 + 4) = param_4;
    iVar3 = *(int *)(iVar6 + 4);
    *(undefined4 *)(iVar6 + 4) = *(undefined4 *)(iVar2 + 4);
    *(int *)(iVar2 + 4) = param_4[1];
    param_4[1] = iVar3;
  }
  piVar5 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (*piVar5 == *(int *)(param_1 + 4)) {
    *piVar5 = (int)param_4;
    *(int **)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = param_4;
  }
  else if (*piVar5 == iVar6) {
    *piVar5 = (int)param_4;
  }
  else {
    piVar4 = *(int **)piVar5[1];
    piVar5[1] = (int)piVar4;
    if (piVar4 != param_4) {
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) =
           *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar1) + 4);
    }
  }
  uStack_8 = 2;
  FUN_0070ad90();
  *param_2 = (int)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9920 ; VA 0x007091c1 ; Catch_All@007091c1 */

void Catch_All_007091c1(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_0070cbb0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9921 ; VA 0x007091f0 ; FUN_007091f0 */

undefined4 * __thiscall
FUN_007091f0(int *param_1,undefined4 *param_2,int *param_3,int *param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  bool bVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab780;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_005f8250(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar5 = (int *)*param_1;
  if (param_3 == (int *)*piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_005f8250(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(int *)(piVar5[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_005f8250(param_2,0,piVar5[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    iVar1 = *param_4;
    iVar2 = param_3[4];
    bVar7 = SBORROW4(iVar2,iVar1);
    iVar3 = iVar2 - iVar1;
    ExceptionList = &pvStack_10;
    puVar4 = &stack0xffffffd4;
    if (iVar1 < iVar2) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar5 = (int *)FUN_0056f560();
      iVar3 = *param_4;
      if (*(int *)(*piVar5 + 0x10) < iVar3) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_005f8250(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_005f8250(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar7 = SBORROW4(param_3[4],iVar3);
      iVar3 = param_3[4] - iVar3;
      puVar4 = puStack_14;
    }
    puStack_14 = puVar4;
    if (bVar7 != iVar3 < 0) {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      if ((*piVar5 == *param_1) || (*param_4 < piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_005f8250(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_005f8250(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00709400(auStack_20,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9922 ; VA 0x007093dd ; Catch_All@007093dd */

void Catch_All_007093dd(void)

{
  int unaff_EBP;
  
  FUN_005f0c20(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9923 ; VA 0x00709400 ; FUN_00709400 */

void __thiscall
FUN_00709400(int *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  bool bVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_4;
  puStack_c = &LAB_017ab790;
  pvStack_10 = ExceptionList;
  bVar4 = true;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 0;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar3[1];
    do {
      puVar3 = puVar2;
      if (param_3 == '\0') {
        bVar4 = *param_4 < (int)puVar3[4];
      }
      else {
        bVar4 = *param_4 <= (int)puVar3[4];
      }
      if (bVar4 == false) {
        puVar2 = (undefined4 *)puVar3[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar3;
      }
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar4 != false) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar4 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00709484;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  puVar2 = _param_3;
  if (*piVar1 <= (int)_param_3[4]) {
    FUN_01674ea0(param_5,0x18);
    *param_2 = puVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00709484:
  puVar3 = (undefined4 *)FUN_005f8250(&param_3,bVar4,puVar3,piVar1,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9924 ; VA 0x007094f3 ; Catch_All@007094f3 */

void Catch_All_007094f3(void)

{
  int unaff_EBP;
  
  FUN_005f0c20(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9925 ; VA 0x00709510 ; FUN_00709510 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00709510(int param_1,undefined4 *param_2,byte *param_3,int param_4)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  bool bVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab7a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005702d0(param_3);
  uVar8 = uVar3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar11 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar11;
    }
    if (piVar6 == (int *)0x0) goto LAB_00709640;
    do {
      if (uVar3 == piVar6[1]) {
        pbVar9 = (byte *)(piVar6 + 2);
        if (0xf < (uint)piVar6[7]) {
          pbVar9 = *(byte **)pbVar9;
        }
        uVar4 = *(uint *)(param_3 + 0x10);
        pbVar10 = param_3;
        if (0xf < *(uint *)(param_3 + 0x14)) {
          pbVar10 = *(byte **)param_3;
        }
        if (uVar4 == piVar6[6]) {
          while (uVar7 = uVar4 - 4, 3 < uVar4) {
            if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_007095cd;
            pbVar10 = pbVar10 + 4;
            pbVar9 = pbVar9 + 4;
            uVar4 = uVar7;
          }
          if (uVar7 == 0xfffffffc) {
LAB_00709601:
            uVar4 = 0;
          }
          else {
LAB_007095cd:
            bVar12 = *pbVar10 < *pbVar9;
            if ((*pbVar10 == *pbVar9) &&
               ((uVar7 == 0xfffffffd ||
                ((bVar12 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
                 ((uVar7 == 0xfffffffe ||
                  ((bVar12 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                   ((uVar7 == 0xffffffff ||
                    (bVar12 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3]))))))))))))
            goto LAB_00709601;
            uVar4 = -(uint)bVar12 | 1;
          }
          if (uVar4 == 0) break;
        }
      }
      else if ((uint)piVar6[1] % *(uint *)(param_1 + 4) != uVar8) goto LAB_00709640;
      piVar6 = (int *)*piVar6;
    } while (piVar6 != (int *)0x0);
  }
  if (piVar6 != (int *)0x0) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00709640:
  uStack_8 = 0;
  FUN_005d2a40();
  FUN_0054ef60(param_4);
  _DAT_00000020 = *(undefined4 *)(param_4 + 0x18);
  uVar4 = *(uint *)(param_1 + 8);
  uVar8 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005d6bb0(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar7 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar8) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar4);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar11;
      while (puVar1 != (undefined4 *)0x0) {
        uVar8 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar8 * 4) == 0) {
          *piVar6 = (int)puVar11;
          puVar11 = puVar1;
        }
        else {
          *puVar11 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar11;
      }
    }
  }
  uVar8 = *(uint *)(param_1 + 4);
  iVar5 = *(int *)(param_1 + 0x14);
  puVar1 = *(undefined4 **)(iVar5 + (uVar3 % uVar8) * 4);
  puVar11 = (undefined4 *)(iVar5 + (uVar3 % uVar8) * 4);
  _DAT_00000004 = uVar3;
  if (puVar1 == (undefined4 *)0x0) {
    iVar2 = *(int *)(iVar5 + uVar8 * 4);
    puVar1 = (undefined4 *)(iVar5 + uVar8 * 4);
    if (iVar2 != 0) {
      *(undefined4 *)(iVar5 + (*(uint *)(iVar2 + 4) % uVar8) * 4) = 0;
    }
    *puVar11 = puVar1;
    _DAT_00000000 = *puVar1;
    *puVar1 = 0;
  }
  else {
    _DAT_00000000 = *puVar1;
    *(undefined4 *)*puVar11 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9926 ; VA 0x00709790 ; FUN_00709790 */

undefined4 FUN_00709790(undefined4 param_1,undefined4 param_2)

{
  FUN_0070c660(param_1,param_2);
  return param_1;
}



/* FUNCTION 9927 ; VA 0x007097b0 ; FUN_007097b0 */

undefined4 FUN_007097b0(undefined4 param_1,undefined4 param_2)

{
  FUN_0070c8f0(param_1,param_2);
  return param_1;
}



/* FUNCTION 9928 ; VA 0x007097d0 ; FUN_007097d0 */

int FUN_007097d0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 9929 ; VA 0x00709810 ; FUN_00709810 */

undefined4 __thiscall FUN_00709810(int *param_1,byte *param_2,undefined8 *param_3)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  uStack_14 = 0;
  iStack_c = param_1[1];
  if (iStack_c <= param_1[4]) {
    do {
      iStack_8 = param_1[2];
      iStack_18 = iStack_c;
      if (iStack_8 <= param_1[5]) {
        do {
          iVar3 = *param_1;
          if (iVar3 <= param_1[3]) {
            do {
              uStack_28 = CONCAT44(iStack_18,iVar3);
              bVar1 = *param_2;
              iStack_20 = iStack_8;
              iStack_1c = iVar3;
              uVar2 = FUN_00ca2680(&uStack_28);
              FUN_006e16e0(&iStack_10,uVar2,&uStack_28,
                           -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) &
                           (uint)(param_2 + bVar1 + 1 + 1));
              if (iStack_10 != 0) {
                if (param_3 != (undefined8 *)0x0) {
                  *param_3 = uStack_28;
                  *(int *)(param_3 + 1) = iStack_20;
                }
                return 1;
              }
              iVar3 = iVar3 + 1;
            } while (iVar3 <= param_1[3]);
          }
          iStack_8 = iStack_8 + 1;
        } while (iStack_8 <= param_1[5]);
      }
      iStack_c = iStack_c + 1;
    } while (iStack_c <= param_1[4]);
  }
  return 0;
}



/* FUNCTION 9930 ; VA 0x00709900 ; FUN_00709900 */

void * __thiscall FUN_00709900(int param_1,void *param_2)

{
  int iVar1;
  void *pvVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9308;
  piVar4 = *(int **)(param_1 + 0x2c);
  pvVar2 = ExceptionList;
  if (piVar4 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(param_1 + 0x30);
      piVar4 = *(int **)(param_1 + 0x2c);
    }
    iVar1 = piVar4[1];
    iVar5 = *piVar4;
    uStack_8 = 0;
    pvVar2 = pvStack_10;
    for (; iVar5 != iVar1; iVar5 = iVar5 + 8) {
      FUN_00709c60((int)param_2 + 4);
      FUN_006f42e0();
      FUN_00709900(param_2);
      pvVar2 = param_2;
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      pvVar2 = (void *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar2 = (void *)(**(code **)*piVar3)();
        LOCK();
        piVar4 = piVar3 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar2 = (void *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 9931 ; VA 0x007099d0 ; FUN_007099d0 */

void * __thiscall FUN_007099d0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_0070afb0(*puVar6,puVar6[1]);
      pvVar4 = (void *)FUN_007099d0(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 9932 ; VA 0x00709ab0 ; FUN_00709ab0 */

int * __thiscall FUN_00709ab0(int *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab7e7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bfd64;
    param_1[0x1a] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  FUN_00565490(param_1 + 1,0,0);
  uStack_8 = 1;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_0054ee60();
  param_1[1] = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  param_1[4] = (int)(param_1 + 2);
  param_1[5] = (int)(param_1 + 3);
  param_1[8] = (int)(param_1 + 6);
  param_1[9] = (int)(param_1 + 7);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xd] = (int)(param_1 + 0xb);
  *(undefined *)(param_1 + 0x13) = 0;
  *(undefined *)((int)param_1 + 0x41) = 0;
  param_1[3] = 0;
  *(undefined4 *)param_1[9] = 0;
  *(undefined4 *)param_1[0xd] = 0;
  *(undefined4 *)param_1[4] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  param_1[0x14] = 0;
  param_1[0x11] = DAT_01e90d08;
  param_1[0x12] = DAT_01e90d0c;
  param_1[0xf] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9933 ; VA 0x00709bd0 ; FUN_00709bd0 */

undefined4 * __fastcall FUN_00709bd0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab816;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00575b50(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9934 ; VA 0x00709c60 ; FUN_00709c60 */

int * __thiscall FUN_00709c60(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar5 = param_2[1] - *param_2 >> 3;
  if (uVar5 != 0) {
    if (0x1fffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00578020(uVar5);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar5 * 8;
    puVar2 = (undefined4 *)param_2[1];
    puVar6 = (undefined4 *)*param_1;
    for (puVar4 = (undefined4 *)*param_2; puVar4 != puVar2; puVar4 = puVar4 + 2) {
      *puVar6 = 0;
      puVar6[1] = 0;
      if (puVar4[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar4[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6 = puVar6 + 2;
    }
    FUN_005596d0(puVar6,puVar6,param_1);
    param_1[1] = (int)puVar6;
  }
  return param_1;
}



/* FUNCTION 9935 ; VA 0x00709d10 ; FUN_00709d10 */

undefined8 * __thiscall FUN_00709d10(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  *(undefined4 *)param_1 = 0;
  *(undefined4 *)((int)param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((int)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
  *(undefined8 *)((int)param_1 + 0xc) = *param_3;
  *(undefined4 *)((int)param_1 + 0x14) = *(undefined4 *)(param_3 + 1);
  return param_1;
}



/* FUNCTION 9936 ; VA 0x00709d70 ; FUN_00709d70 */

undefined4 * __thiscall FUN_00709d70(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_3;
  return param_1;
}



/* FUNCTION 9937 ; VA 0x00709da0 ; FUN_00709da0 */

undefined4 * __thiscall FUN_00709da0(undefined4 *param_1,undefined8 *param_2)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  *(undefined8 *)(param_1 + 9) = *param_2;
  param_1[0xb] = *(undefined4 *)(param_2 + 1);
  return param_1;
}



/* FUNCTION 9938 ; VA 0x00709e00 ; FUN_00709e00 */

undefined4 * __thiscall FUN_00709e00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab8d2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00610b20("Replicator GC Job",param_2,1,4);
  param_1[0x4c] = RBX::Collision::SpatialHashBase::MovementCallback::vftable;
  param_1[0x4d] = RBX::PrimitiveMovementCallback::vftable;
  param_1[0x4e] = RBX::Network::StreamingInterface::vftable;
  *param_1 = RBX::Network::ClientReplicator::GCJob::vftable;
  param_1[0x4c] = RBX::Network::ClientReplicator::GCJob::vftable;
  param_1[0x4d] = RBX::Network::ClientReplicator::GCJob::vftable;
  param_1[0x4e] = RBX::Network::ClientReplicator::GCJob::vftable;
  uStack_8 = 0;
  *(undefined *)(param_1 + 0x52) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x53] = uVar1;
  param_1[0x54] = 0;
  param_1[0x55] = 0x3f800000;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  uStack_8._0_1_ = 1;
  FUN_0070a2c0();
  uVar1 = DAT_018c45c4;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0x3f800000;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0x3f800000;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0x3f800000;
  *(ulonglong *)(param_1 + 0x6b) = CONCAT44(uVar1,uVar1);
  param_1[0x6d] = 0x7f7fffff;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0xffffffff;
  param_1[0x70] = 0;
  param_1[0x71] = 0xffffffff;
  param_1[0x72] = 0x400;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  *(undefined2 *)(param_1 + 0x75) = 0x7fff;
  param_1[0x76] = 1;
  param_1[0x77] = 0;
  uStack_8._0_1_ = 2;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  uVar1 = FUN_0070ad30(0,0);
  param_1[0x78] = uVar1;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  uStack_8._0_1_ = 4;
  param_1[0x77] = 0x3f800000;
  FUN_005cb500(8);
  *(undefined2 *)(param_1 + 0x7f) = 0;
  *(undefined8 *)(param_1 + 0x80) = 0x7fffffff7fffffff;
  param_1[0x82] = 0x7fffffff;
  *(undefined8 *)(param_1 + 0x83) = 0x7fffffff7fffffff;
  param_1[0x85] = 0x7fffffff;
  *(undefined8 *)(param_1 + 0x86) = 0x7fffffff7fffffff;
  param_1[0x88] = 0x7fffffff;
  *(undefined8 *)(param_1 + 0x89) = 0x7fffffff7fffffff;
  param_1[0x8b] = 0x7fffffff;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  param_1[0x92] = 0;
  uStack_8._0_1_ = 5;
  param_1[0x93] = 0;
  param_1[0x94] = 0;
  uVar1 = FUN_0070ad60(0,0);
  param_1[0x93] = uVar1;
  uStack_8._0_1_ = 6;
  FUN_01682800(param_1 + 0x96);
  param_1[0x98] = 0;
  FUN_01682800(param_1 + 0x9a);
  FUN_01682800(param_1 + 0x9c);
  FUN_01682800(param_1 + 0x9e);
  FUN_01682800(param_1 + 0xa0);
  param_1[0xa2] = 0;
  param_1[0xa3] = 0;
  param_1[0xa4] = 0;
  uStack_8._0_1_ = 7;
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0;
  uVar1 = FUN_005e9aa0(0,0);
  param_1[0xa6] = uVar1;
  param_1[0xa8] = 0;
  param_1[0xa9] = 0;
  param_1[0xaa] = 0;
  uStack_8._0_1_ = 9;
  param_1[0xa5] = 0x3f800000;
  FUN_005cb500(8);
  uStack_8._0_1_ = 10;
  FUN_00709bd0();
  uStack_8._0_1_ = 0xb;
  FUN_00709bd0();
  uStack_8._0_1_ = 0xc;
  FUN_0070a2c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  FUN_00a361f0();
  iVar2 = FUN_005c3ac0(param_2);
  if ((iVar2 != 0) && (iVar2 = *(int *)(iVar2 + 0x1b4), iVar2 != 0)) {
    param_1[0x51] = *(undefined4 *)(iVar2 + 0x6d0);
    FUN_00bb8d70(1);
    if (DAT_01d69070 == '\0') {
      param_1[0x50] = *(undefined4 *)(*(int *)(iVar2 + 0x6ac) + 0x154);
    }
    else {
      param_1[0x4f] = *(int *)(iVar2 + 0x6ac);
      FUN_007c8c00(param_1 + 0x4d);
    }
  }
  if ((DAT_01d69070 == '\0') && ((int *)param_1[0x50] != (int *)0x0)) {
    (**(code **)(*(int *)param_1[0x50] + 0x58))(param_1 + 0x4c,5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9939 ; VA 0x0070a2c0 ; FUN_0070a2c0 */

undefined4 * __fastcall FUN_0070a2c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab8f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uVar1 = FUN_00601dc0();
  *param_1 = uVar1;
  uStack_8 = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  uVar1 = FUN_00601dc0();
  param_1[2] = uVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = FUN_00601dc0();
  param_1[4] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9940 ; VA 0x0070a350 ; FUN_0070a350 */

void FUN_0070a350(void)

{
  FUN_00641040();
  return;
}



/* FUNCTION 9941 ; VA 0x0070a360 ; FUN_0070a360 */

void __fastcall FUN_0070a360(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0070b5b0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x30);
  return;
}



/* FUNCTION 9942 ; VA 0x0070a3d0 ; FUN_0070a3d0 */

void __fastcall FUN_0070a3d0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0056c7e0();
  return;
}



/* FUNCTION 9943 ; VA 0x0070a430 ; FUN_0070a430 */

void __fastcall FUN_0070a430(undefined4 *param_1)

{
  FUN_0070b5b0();
  FUN_01674ea0(*param_1,0x30);
  return;
}



/* FUNCTION 9944 ; VA 0x0070a450 ; FUN_0070a450 */

void __fastcall FUN_0070a450(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x1c);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x1c);
  return;
}



/* FUNCTION 9945 ; VA 0x0070a4a0 ; FUN_0070a4a0 */

void __fastcall FUN_0070a4a0(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0070ce30(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9946 ; VA 0x0070a4f0 ; FUN_0070a4f0 */

void __fastcall FUN_0070a4f0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0070b5b0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x30);
  return;
}



/* FUNCTION 9947 ; VA 0x0070a500 ; thunk_FUN_0070a3d0 */

void __fastcall thunk_FUN_0070a3d0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0056c7e0();
  return;
}



/* FUNCTION 9948 ; VA 0x0070a510 ; FUN_0070a510 */

void __fastcall FUN_0070a510(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0070ce30(&puStack_14,*(undefined4 *)param_1[4],(undefined4 *)param_1[4]);
  FUN_01674ea0(param_1[4],0x18);
  uStack_8 = 1;
  FUN_0070ce30(&puStack_14,*(undefined4 *)param_1[2],(undefined4 *)param_1[2]);
  FUN_01674ea0(param_1[2],0x18);
  uStack_8 = 2;
  FUN_0070ce30(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9949 ; VA 0x0070a5b0 ; FUN_0070a5b0 */

int * __thiscall FUN_0070a5b0(int *param_1,undefined8 param_2)

{
  uint uVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  uint uStack_38;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab918;
  pvStack_10 = ExceptionList;
  iVar7 = *param_1;
  piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar7 = *param_1;
  }
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) {
    piVar5 = *(int **)(*(int *)(*(int *)(iVar7 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    (**(code **)(*piVar5 + 4))();
    uStack_8._0_1_ = 3;
    piVar3 = (int *)FUN_00564aa0();
    uStack_8._0_1_ = 4;
    if ((piVar5 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piVar5 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)();
    }
    uStack_38 = uStack_38 & 0xffffff00;
    iVar7 = *(int *)(*param_1 + 4) + (int)param_1;
    uStack_1c = CONCAT31((int3)((uint)piVar5 >> 8),
                         *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
    uVar8 = *(undefined4 *)(iVar7 + 0x38);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    (**(code **)(*piVar3 + 0x14))
              (&param_2,uStack_38,uVar8,iVar7,uStack_1c,CONCAT71(param_2._1_7_,(undefined)param_2));
    piVar5 = (int *)FUN_0070a6e5(uStack_38,uVar8);
    return piVar5;
  }
  uVar1 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar1 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar1;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 7;
  cVar2 = thunk_FUN_0170e3b7();
  if (cVar2 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9950 ; VA 0x0070a6c6 ; Catch_All@0070a6c6 */

undefined * Catch_All_0070a6c6(void)

{
  FUN_005565b0(4,1);
  return &DAT_0070a6df;
}



/* FUNCTION 9951 ; VA 0x0070a6e5 ; FUN_0070a6e5 */

void FUN_0070a6e5(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 8;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 9952 ; VA 0x0070a750 ; FUN_0070a750 */

int * __thiscall FUN_0070a750(int *param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  undefined *puVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  uint uStack_38;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab948;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  iVar7 = *param_1;
  piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  puVar2 = &stack0xffffffbc;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar7 = *param_1;
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) {
    piStack_20 = *(int **)(*(int *)(*(int *)(iVar7 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_1c = piStack_20;
    (**(code **)(*piStack_20 + 4))();
    uStack_8._0_1_ = 3;
    piStack_20 = (int *)FUN_00564aa0(auStack_24);
    uStack_8._0_1_ = 4;
    if ((piStack_1c != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_1c + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    iVar7 = *(int *)(*param_1 + 4) + (int)param_1;
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,
                                 *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
    uVar8 = *(undefined4 *)(iVar7 + 0x38);
    uStack_38 = uStack_38 & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    (**(code **)(*piStack_20 + 0x18))(&param_2,uStack_38,uVar8,iVar7,piStack_1c,param_2,param_3);
    piVar5 = (int *)FUN_0070a87e(uStack_38,uVar8);
    return piVar5;
  }
  uVar1 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar1 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar1;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9953 ; VA 0x0070a85f ; Catch_All@0070a85f */

undefined * Catch_All_0070a85f(void)

{
  FUN_005565b0(4,1);
  return &DAT_0070a878;
}



/* FUNCTION 9954 ; VA 0x0070a87e ; FUN_0070a87e */

void FUN_0070a87e(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 8;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 9955 ; VA 0x0070a8f0 ; FUN_0070a8f0 */

int * __thiscall FUN_0070a8f0(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_8;
  
  puVar4 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    puVar1 = (undefined4 *)puVar4[1];
    do {
      if ((int)puVar1[4] < *param_2) {
        puVar2 = (undefined4 *)puVar1[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    if ((puVar4 != (undefined4 *)*param_1) && ((int)puVar4[4] <= *param_2)) {
      return puVar4 + 5;
    }
  }
  piStack_8 = param_2;
  iVar3 = FUN_005f81a0(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_007091f0(&param_2,puVar4,iVar3 + 0x10,iVar3);
  return param_2 + 5;
}



/* FUNCTION 9956 ; VA 0x0070a970 ; FUN_0070a970 */

int * __thiscall FUN_0070a970(int param_1,byte *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int *piStack_10;
  byte *pbStack_c;
  int iStack_8;
  
  piVar1 = *(int **)(param_1 + 4);
  uVar7 = *(uint *)(param_1 + 0x18) &
          ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + uVar7 * 8);
  piVar6 = piVar2;
  while( true ) {
    piVar8 = piVar1;
    if (piVar2 != piVar1) {
      piVar8 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + uVar7 * 8 + 4);
    }
    if (piVar6 == piVar8) goto LAB_0070a9e6;
    if (piVar6[2] == *(int *)param_2) break;
    piVar6 = (int *)*piVar6;
  }
  if (piVar6 == piVar1) {
LAB_0070a9e6:
    iVar3 = *piVar1;
    pbStack_c = param_2;
    puVar4 = *(undefined4 **)(iVar3 + 4);
    iStack_8 = param_1;
    uVar5 = FUN_00708680(iVar3,puVar4,&DAT_018bdeda,&pbStack_c,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0x5555554) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar3 + 4) = uVar5;
    *puVar4 = uVar5;
    FUN_00708a70(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    piVar6 = piStack_10;
  }
  return piVar6 + 4;
}



/* FUNCTION 9957 ; VA 0x0070aa60 ; FUN_0070aa60 */

int * __thiscall FUN_0070aa60(int param_1,byte *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int *piStack_10;
  byte *pbStack_c;
  int iStack_8;
  
  piVar1 = *(int **)(param_1 + 4);
  uVar7 = *(uint *)(param_1 + 0x18) &
          ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + uVar7 * 8);
  piVar6 = piVar2;
  while( true ) {
    piVar8 = piVar1;
    if (piVar2 != piVar1) {
      piVar8 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + uVar7 * 8 + 4);
    }
    if (piVar6 == piVar8) goto LAB_0070aad6;
    if (piVar6[2] == *(int *)param_2) break;
    piVar6 = (int *)*piVar6;
  }
  if (piVar6 == piVar1) {
LAB_0070aad6:
    iVar3 = *piVar1;
    pbStack_c = param_2;
    puVar4 = *(undefined4 **)(iVar3 + 4);
    iStack_8 = param_1;
    uVar5 = FUN_007086b0(iVar3,puVar4,&DAT_018bdeda,&pbStack_c,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar3 + 4) = uVar5;
    *puVar4 = uVar5;
    FUN_00708c90(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    piVar6 = piStack_10;
  }
  return piVar6 + 3;
}



/* FUNCTION 9958 ; VA 0x0070ab50 ; FUN_0070ab50 */

undefined4 * __thiscall FUN_0070ab50(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::ClientReplicator::GCJob::vftable;
  param_1[0x4c] = RBX::Network::ClientReplicator::GCJob::vftable;
  param_1[0x4d] = RBX::Network::ClientReplicator::GCJob::vftable;
  param_1[0x4e] = RBX::Network::ClientReplicator::GCJob::vftable;
  iVar3 = FUN_005c3ac0(param_1[0x4a]);
  if ((iVar3 != 0) && (*(int *)(iVar3 + 0x1b4) != 0)) {
    if (DAT_01d69070 == '\0') {
      piVar2 = *(int **)(*(int *)(*(int *)(iVar3 + 0x1b4) + 0x6ac) + 0x154);
      param_1[0x50] = piVar2;
      if (piVar2 != (int *)0x0) {
        (**(code **)(*piVar2 + 0x5c))(param_1 + 0x4c);
      }
    }
    else {
      FUN_00bbd5e0(param_1 + 0x4d);
    }
  }
  FUN_0070a510();
  FUN_0070a3d0();
  FUN_0070a3d0();
  FUN_005e61c0();
  FUN_00641040();
  FUN_0070a450();
  FUN_0070a360();
  FUN_0070a510();
  FUN_0056d250();
  piVar2 = (int *)param_1[0x4b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x310);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9959 ; VA 0x0070acb0 ; FUN_0070acb0 */

undefined4 * __thiscall FUN_0070acb0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[0xf];
  if (iVar1 != 0) {
    uVar3 = param_1[0x11] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0xf] = 0;
    param_1[0x10] = 0;
    param_1[0x11] = 0;
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9960 ; VA 0x0070ad30 ; FUN_0070ad30 */

void FUN_0070ad30(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x30);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 9961 ; VA 0x0070ad60 ; FUN_0070ad60 */

void FUN_0070ad60(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x1c);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 9962 ; VA 0x0070ad90 ; FUN_0070ad90 */

void __fastcall FUN_0070ad90(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_005cb500(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_00709060(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 9963 ; VA 0x0070ae30 ; FUN_0070ae30 */

void __thiscall FUN_0070ae30(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_70a9e9fdf6e7f68ee772c64181adb6d6>,bool,class_std::shared_ptr<class_RBX::Instance>_>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 9964 ; VA 0x0070ae50 ; FUN_0070ae50 */

void __thiscall FUN_0070ae50(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_d9bcc031b686e87c6a372abe6f2045ed>,bool,class_std::shared_ptr<class_RBX::Instance>_>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 9965 ; VA 0x0070ae70 ; FUN_0070ae70 */

void FUN_0070ae70(undefined4 param_1)

{
  undefined auStack_8 [4];
  
  FUN_0070cfc0(auStack_8,param_1);
  return;
}



/* FUNCTION 9966 ; VA 0x0070ae90 ; FUN_0070ae90 */

undefined4 __thiscall FUN_0070ae90(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = *param_2;
  if (iVar4 != 0) {
    iVar1 = *(int *)(iVar4 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_0070aec7;
  }
  iVar4 = 0;
LAB_0070aec7:
  if (iVar4 != 0) {
    param_2 = (int *)iVar4;
    piVar3 = (int *)FUN_0070aa60(&param_2);
    if (0 < *piVar3) {
      FUN_0070de60(*(undefined4 *)(param_1 + 4),1);
    }
    return 0;
  }
  return 1;
}



/* FUNCTION 9967 ; VA 0x0070af10 ; FUN_0070af10 */

undefined4 __thiscall FUN_0070af10(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = *param_2;
  if (iVar4 != 0) {
    iVar1 = *(int *)(iVar4 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_0070af47;
  }
  iVar4 = 0;
LAB_0070af47:
  if (iVar4 != 0) {
    param_2 = (int *)iVar4;
    piVar3 = (int *)FUN_0070aa60(&param_2);
    if (0 < *piVar3) {
      FUN_0070b640(*(undefined4 *)(param_1 + 4),1);
    }
    return 0;
  }
  return 1;
}



/* FUNCTION 9968 ; VA 0x0070af90 ; FUN_0070af90 */

TypeDescriptor * FUN_0070af90(void)

{
  return &<lambda_70a9e9fdf6e7f68ee772c64181adb6d6>::RTTI_Type_Descriptor;
}



/* FUNCTION 9969 ; VA 0x0070afa0 ; FUN_0070afa0 */

TypeDescriptor * FUN_0070afa0(void)

{
  return &<lambda_d9bcc031b686e87c6a372abe6f2045ed>::RTTI_Type_Descriptor;
}



/* FUNCTION 9970 ; VA 0x0070afb0 ; FUN_0070afb0 */

undefined __thiscall FUN_0070afb0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined uVar5;
  int iVar6;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  iVar2 = *(int *)(param_1 + 0x40);
  iVar6 = *(int *)(param_1 + 0x3c);
  uStack_8 = 0;
  uStack_1c = *(undefined4 *)(param_2 + 0x18);
  uStack_18 = *(undefined4 *)(param_2 + 0x1c);
  iStack_14 = param_1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while ((iVar6 != iVar2 && (cVar4 = FUN_009c8f50(&uStack_1c), cVar4 == '\0'))) {
    iVar6 = iVar6 + 8;
  }
  if (iVar6 == *(int *)(iStack_14 + 0x40)) {
    puVar3 = *(undefined4 **)(param_1 + 0x40);
    if (*(undefined4 **)(param_1 + 0x44) == puVar3) {
      FUN_00559ce0(puVar3,&uStack_1c);
      uVar5 = 1;
    }
    else {
      *puVar3 = uStack_1c;
      uVar5 = 1;
      puVar3[1] = uStack_18;
      *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 8;
    }
  }
  else {
    uVar5 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 9971 ; VA 0x0070b080 ; FUN_0070b080 */

void FUN_0070b080(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01eaf994);
  uStack_8 = 0;
  piVar2 = (int *)FUN_0070a8f0(param_1);
  *piVar2 = *piVar2 + 1;
  piVar2 = (int *)FUN_0070a8f0(param_1 + 4);
  *piVar2 = *piVar2 + 1;
  piVar2 = (int *)FUN_0070a8f0(param_1 + 8);
  *piVar2 = *piVar2 + 1;
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9972 ; VA 0x0070b110 ; FUN_0070b110 */

void __thiscall FUN_0070b110(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = 0;
  piVar1 = (int *)*param_1;
  uVar3 = param_1[1] - (int)piVar1 >> 2;
  if (uVar3 != 0) {
    do {
      if (*piVar1 != param_1[4]) break;
      uVar2 = uVar2 + 1;
      piVar1 = piVar1 + 1;
    } while (uVar2 < uVar3);
  }
  *param_2 = param_1;
  param_2[1] = uVar2;
  return;
}



/* FUNCTION 9973 ; VA 0x0070b150 ; FUN_0070b150 */

int __thiscall FUN_0070b150(int *param_1,byte *param_2,int *param_3)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  bool bVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  int *piVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  undefined8 uStack_64;
  int iStack_5c;
  undefined8 uStack_58;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int *piStack_c;
  char cStack_6;
  char cStack_5;
  
  iStack_34 = param_1[2];
  iStack_2c = param_1[1];
  iStack_3c = param_3[1];
  iStack_40 = param_3[2];
  iStack_38 = *param_3;
  iVar12 = iStack_2c;
  if (iStack_3c <= iStack_2c) {
    iVar12 = iStack_3c;
  }
  iStack_18 = *param_1;
  iStack_24 = iStack_18;
  if (iStack_38 <= iStack_18) {
    iStack_24 = iStack_38;
  }
  iStack_30 = param_1[5];
  iVar11 = iStack_34;
  if (param_3[2] <= iStack_34) {
    iVar11 = param_3[2];
  }
  iVar13 = iStack_30;
  if (iStack_30 <= param_3[5]) {
    iVar13 = param_3[5];
  }
  iVar10 = param_1[4];
  iVar14 = param_3[4];
  iVar2 = param_3[3];
  iStack_28 = iVar10;
  if (iVar10 <= iVar14) {
    iStack_28 = iVar14;
  }
  iVar3 = param_1[3];
  iStack_1c = iVar3;
  if (iVar3 <= iVar2) {
    iStack_1c = iVar2;
  }
  fVar17 = (float)(iStack_28 - iVar12) * (float)(iStack_28 - iVar12) +
           (float)(iStack_1c - iStack_24) * (float)(iStack_1c - iStack_24) +
           (float)(iVar13 - iVar11) * (float)(iVar13 - iVar11);
  iVar4 = *(int *)(param_2 + 8);
  fVar16 = (float)(iVar10 - iStack_2c) * (float)(iVar10 - iStack_2c) +
           (float)(iVar3 - iStack_18) * (float)(iVar3 - iStack_18) +
           (float)(iStack_30 - iStack_34) * (float)(iStack_30 - iStack_34) +
           (float)(iVar14 - iStack_3c) * (float)(iVar14 - iStack_3c) +
           (float)(iVar2 - iStack_38) * (float)(iVar2 - iStack_38) +
           (float)(param_3[5] - iStack_40) * (float)(param_3[5] - iStack_40);
  fVar15 = (float)((double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)]) *
           (float)((double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)]);
  if ((fVar15 < fVar17) && (fVar15 < fVar16)) {
    iVar12 = 0;
    if (iVar4 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    for (; puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
      if (*(char *)(puVar7 + 5) != '\0') {
        iVar11 = puVar7[2];
        if (((((iVar11 < iStack_18) || (param_1[3] < iVar11)) || ((int)puVar7[3] < param_1[1])) ||
            ((param_1[4] < (int)puVar7[3] || ((int)puVar7[4] < param_1[2])))) ||
           (param_1[5] < (int)puVar7[4])) {
          bVar5 = false;
        }
        else {
          bVar5 = true;
        }
        if (((iVar11 < *param_3) || (param_3[3] < iVar11)) ||
           (((int)puVar7[3] < param_3[1] ||
            (((param_3[4] < (int)puVar7[3] || ((int)puVar7[4] < param_3[2])) ||
             (param_3[5] < (int)puVar7[4])))))) {
          bVar6 = false;
        }
        else {
          bVar6 = true;
        }
        if (bVar5) {
          if (!bVar6) {
            iVar12 = iVar12 + -1;
          }
        }
        else if (bVar6) {
          iVar12 = iVar12 + 1;
        }
      }
    }
    return iVar12;
  }
  iStack_20 = iVar13;
  iStack_14 = iVar11;
  piStack_c = param_1;
  if (fVar17 < fVar16) {
    iStack_18 = 0;
    iVar10 = 0;
    if (iVar12 <= iStack_28) {
      do {
        iVar10 = iStack_1c;
        iVar14 = iVar11;
        iStack_48 = iVar12;
        iStack_10 = iVar12;
        if (iVar11 <= iVar13) {
          do {
            piVar9 = piStack_c;
            iVar13 = iStack_24;
            if (iStack_24 <= iVar10) {
              do {
                if (((iVar13 < *piVar9) || (piVar9[3] < iVar13)) ||
                   (((iVar12 < piVar9[1] || ((piVar9[4] < iVar12 || (iVar11 < piVar9[2])))) ||
                    (cStack_6 = '\x01', piVar9[5] < iVar11)))) {
                  cStack_6 = '\0';
                }
                iVar12 = *param_3;
                if ((((iVar13 < iVar12) || (param_3[3] < iVar13)) || (iStack_10 < param_3[1])) ||
                   (((piVar9 = piStack_c, param_3[4] < iStack_10 || (iVar11 < param_3[2])) ||
                    (cStack_5 = '\x01', param_3[5] < iVar11)))) {
                  cStack_5 = '\0';
                }
                iStack_4c = iVar13;
                if (cStack_6 == '\0') {
                  if (cStack_5 == '\0') {
                    if (iVar12 <= *piVar9) {
                      iVar12 = *piVar9;
                    }
                    bVar5 = iVar13 < iVar12;
                    iVar13 = iStack_1c;
                    if (bVar5) {
                      iVar13 = iVar12 + -1;
                    }
                  }
                  else {
                    bVar1 = *param_2;
                    uStack_58 = CONCAT44(iStack_48,iVar13);
                    iStack_50 = iVar11;
                    uVar8 = FUN_00ca2680(&uStack_58);
                    FUN_006e16e0(&iStack_40,uVar8,&uStack_58,
                                 -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) &
                                 (uint)(param_2 + bVar1 + 1 + 1));
                    piVar9 = piStack_c;
                    if ((iStack_40 != 0) && (*(char *)(iStack_40 + 0x14) != '\0')) {
                      iStack_18 = iStack_18 + 1;
                    }
                  }
                }
                else if (cStack_5 == '\0') {
                  bVar1 = *param_2;
                  uStack_64 = CONCAT44(iStack_48,iVar13);
                  iStack_5c = iVar11;
                  uVar8 = FUN_00ca2680(&uStack_64);
                  FUN_006e16e0(&iStack_3c,uVar8,&uStack_64,
                               -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) &
                               (uint)(param_2 + bVar1 + 1 + 1));
                  piVar9 = piStack_c;
                  if ((iStack_3c != 0) && (*(char *)(iStack_3c + 0x14) != '\0')) {
                    iStack_18 = iStack_18 + -1;
                  }
                }
                else {
                  iVar13 = param_3[3];
                  if (piVar9[3] <= param_3[3]) {
                    iVar13 = piVar9[3];
                  }
                }
                iVar13 = iVar13 + 1;
                iVar12 = iStack_10;
                iVar10 = iStack_1c;
              } while (iVar13 <= iStack_1c);
            }
            iVar11 = iVar11 + 1;
            iVar13 = iStack_20;
            iVar14 = iStack_14;
          } while (iVar11 <= iStack_20);
        }
        iVar12 = iVar12 + 1;
        iVar10 = iStack_18;
        iVar11 = iVar14;
      } while (iVar12 <= iStack_28);
    }
    return iVar10;
  }
  iStack_10 = iVar12;
  iVar12 = FUN_0070ec50(param_2);
  iVar11 = FUN_0070ec50(param_2);
  return iVar12 - iVar11;
}



/* FUNCTION 9974 ; VA 0x0070b540 ; FUN_0070b540 */

void __fastcall FUN_0070b540(int param_1)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 4);
  piVar2 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
  *(undefined4 *)(param_1 + 8) = 0;
  if (piVar2 != *(int **)(param_1 + 4)) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_01674ea0(piVar2,0xc);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*(int *)(param_1 + 4));
  }
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9975 ; VA 0x0070b5b0 ; FUN_0070b5b0 */

void __fastcall FUN_0070b5b0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  piVar3 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar3 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar3;
      uVar2 = piVar3[4];
      uStack_8 = 0;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(piVar3 + 6,piVar3 + 6,2);
          }
        }
        piVar3[4] = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(piVar3,0x30);
      piVar3 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9976 ; VA 0x0070b640 ; FUN_0070b640 */

void FUN_0070b640(uint param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined auStack_18 [4];
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  int iStack_8;
  
  uVar6 = param_1;
  iVar8 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00aff8c0();
  param_1 = 0;
  if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    param_1 = uVar6;
  }
  if (param_1 == 0) {
    if (*(int *)(uVar6 + 0x34) != 0) {
      FUN_0070b640(*(int *)(uVar6 + 0x34),param_2);
    }
    return;
  }
  piVar3 = (int *)FUN_0070aa60(&param_1);
  if (*piVar3 == param_2) {
    if (*(int *)(uVar6 + 0x34) != 0) {
      FUN_0070b640(*(int *)(uVar6 + 0x34),1);
    }
    puVar1 = *(undefined4 **)(iStack_8 + 0x2b8);
    uVar6 = *(uint *)(iStack_8 + 0x2cc) &
            ((((param_1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ param_1 >> 8 & 0xff) * 0x1000193 ^
             param_1 >> 0x10 & 0xff) * 0x1000193 ^ param_1 >> 0x18) * 0x1000193;
    puStack_c = *(undefined4 **)(*(int *)(iStack_8 + 0x2c0) + uVar6 * 8);
    puStack_10 = (undefined4 *)(*(int *)(iStack_8 + 0x2c0) + uVar6 * 8 + 4);
    puVar4 = puStack_c;
    while( true ) {
      puVar5 = puVar1;
      if (puStack_c != puVar1) {
        puVar5 = *(undefined4 **)*puStack_10;
      }
      if (puVar4 == puVar5) goto LAB_0070b756;
      puVar5 = puVar4;
      if (puVar4[2] == param_1) break;
      puVar4 = (undefined4 *)*puVar4;
    }
    while( true ) {
      puVar7 = puVar1;
      if (puStack_c != puVar1) {
        puVar7 = *(undefined4 **)*puStack_10;
      }
      if ((puVar5 == puVar7) || (param_1 != puVar5[2])) break;
      puVar5 = (undefined4 *)*puVar5;
    }
    puStack_14 = puVar4;
    if (puVar4 == puVar5) {
LAB_0070b756:
      puVar5 = puVar1;
      puVar4 = puVar1;
    }
    iVar8 = 0;
    if (puVar4 != puVar5) {
      do {
        puVar4 = (undefined4 *)*puVar4;
        iVar8 = iVar8 + 1;
      } while (puVar4 != puVar5);
      if (iVar8 != 0) {
        FUN_00708ea0(auStack_18,&param_1,param_2);
      }
    }
  }
  piVar3 = (int *)FUN_0070aa60(&param_1);
  *piVar3 = *piVar3 - param_2;
  return;
}



/* FUNCTION 9977 ; VA 0x0070b7c0 ; FUN_0070b7c0 */

int FUN_0070b7c0(int *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint *puVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  int *piStack_4c;
  undefined8 uStack_48;
  uint uStack_3c;
  uint uStack_38;
  uint *puStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  uint uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ab977;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  FUN_005edd10();
  uVar2 = FUN_01675290(DAT_01eaf994);
  iVar10 = iStack_24;
  iStack_14 = 0;
  uStack_28 = 0;
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_30 = uVar2;
  if ((DAT_01d5bf20 == '\0') && ((*(uint *)(*(int *)(iStack_24 + 0x128) + 0x380c) & 2) == 0)) {
    if (*(int *)(iStack_24 + 0x150) != 0) {
      uStack_3c = FUN_00ca2680(param_1);
      uStack_48 = CONCAT44((uint *)(iVar10 + 0x14c),(undefined4)uStack_48);
      uStack_28 = *(uint *)(iVar10 + 0x14c);
      puStack_34 = (uint *)(uStack_3c % uStack_28);
      piStack_4c = (int *)((int)puStack_34 * 4);
      piStack_2c = *(int **)((int)piStack_4c + *(int *)(iVar10 + 0x15c));
      if ((piStack_2c != (int *)0x0) &&
         (piVar7 = (int *)*piStack_2c, (int *)*piStack_2c != (int *)0x0)) {
        while (piVar9 = piVar7, (uint *)((uint)piVar9[1] % uStack_28) == puStack_34) {
          if ((((piVar9[1] == uStack_3c) && (*param_1 == piVar9[2])) && (param_1[1] == piVar9[3]))
             && (param_1[2] == piVar9[4])) {
            uStack_28 = FUN_0057d5a0(piStack_2c,*piVar9);
            if (*piStack_2c != 0) {
              puVar5 = (uint *)(*(uint *)(*piStack_2c + 4) % *uStack_48._4_4_);
              uVar2 = uStack_30;
              if (puStack_34 == puVar5) goto LAB_0070b904;
              *(int **)(*(int *)(iVar10 + 0x15c) + (int)puVar5 * 4) = piStack_2c;
            }
            puVar3 = (undefined4 *)(*(int *)(iVar10 + 0x15c) + (int)piStack_4c);
            if ((int *)*puVar3 == piStack_2c) {
              *puVar3 = 0;
            }
            goto LAB_0070b904;
          }
          piVar7 = (int *)*piVar9;
          piStack_2c = piVar9;
          if ((int *)*piVar9 == (int *)0x0) break;
        }
      }
    }
    uStack_28 = 0;
LAB_0070b904:
    if (uStack_28 == 0) goto LAB_0070bb37;
  }
  else {
    iVar8 = iStack_24 + *(byte *)(iStack_24 + 0x148) + 0x149;
    uVar4 = FUN_00ca2680(param_1);
    iVar10 = iStack_24;
    FUN_006e16e0(&piStack_4c,uVar4,param_1,-(uint)(iVar8 != 0) & iVar8 + 1U);
    if (piStack_4c == (int *)0x0) goto LAB_0070bb37;
    uStack_38 = CONCAT31(uStack_38._1_3_,*(undefined *)(piStack_4c + 5));
    puStack_34 = (uint *)(iVar10 + 0x14c);
    uStack_28 = (uint)piStack_4c[1] % *puStack_34;
    piVar7 = *(int **)(*(int *)(iVar10 + 0x15c) + uStack_28 * 4);
    for (piVar9 = (int *)*piVar7; piVar1 = (int *)*piStack_4c, piStack_2c = piVar7,
        piVar9 != piStack_4c; piVar9 = (int *)*piVar9) {
      piVar7 = piVar9;
    }
    do {
      piStack_4c = piVar1;
      *piVar7 = *piVar9;
      FUN_01674ea0(piVar9,0x18);
      *(int *)(iStack_24 + 0x150) = *(int *)(iStack_24 + 0x150) + -1;
      uVar6 = uStack_28;
      if (*piVar7 == 0) {
LAB_0070ba2d:
        if (*(int **)(*(int *)(iStack_24 + 0x15c) + uStack_28 * 4) == piVar7) {
          *(undefined4 *)(*(int *)(iStack_24 + 0x15c) + uStack_28 * 4) = 0;
        }
      }
      else {
        uVar6 = *(uint *)(*piVar7 + 4) % *puStack_34;
        piVar7 = piStack_2c;
        if (uStack_28 != uVar6) {
          *(int **)(*(int *)(iStack_24 + 0x15c) + uVar6 * 4) = piStack_2c;
          goto LAB_0070ba2d;
        }
      }
      piVar9 = (int *)*piVar7;
      piVar1 = piStack_4c;
      uStack_28 = uVar6;
    } while (piVar9 != piStack_4c);
    uStack_28 = 1;
    uVar2 = uStack_30;
    iVar10 = iStack_24;
  }
  if (((*(char *)(iVar10 + 0x178) == '\0') && (*param_1 == *(int *)(iVar10 + 0x20c))) &&
     ((param_1[1] == *(int *)(iVar10 + 0x210) &&
      ((param_1[2] == *(int *)(iVar10 + 0x214) &&
       (*(undefined *)(iVar10 + 0x178) = 1, DAT_01ee1b70 != '\0')))))) {
    FUN_016774b0(DAT_01ee1b70,"characterOutsideStreamedArea changed to true.",0);
  }
  piStack_4c = (int *)FUN_01674e20(0x48);
  iStack_14._0_1_ = 2;
  if (piStack_4c == (int *)0x0) {
    piStack_2c = (int *)0x0;
  }
  else {
    uStack_48 = *(undefined8 *)param_1;
    iVar10 = param_1[2];
    piStack_2c = piStack_4c;
    FUN_006b1a30(*(undefined4 *)(iStack_24 + 0x128));
    *(undefined8 *)(piStack_2c + 0xc) = uStack_48;
    piStack_2c[0xe] = iVar10;
    *piStack_2c = (int)RBX::Network::ClientReplicator::GCJob::RegionRemovalItem::vftable;
    piStack_2c[0xf] = 0;
    piStack_2c[0x10] = 0;
    piStack_2c[0x11] = 0;
  }
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_0070d350(param_1,piStack_2c,uStack_38);
  FUN_006b1f50(piStack_2c);
LAB_0070bb37:
  iStack_14 = 3;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_1c;
  return uStack_28;
}



/* FUNCTION 9978 ; VA 0x0070bb60 ; FUN_0070bb60 */

/* WARNING: Type propagation algorithm not settling */

void FUN_0070bb60(undefined4 *param_1)

{
  int iVar1;
  undefined uVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  undefined1 *puVar11;
  undefined4 *******pppppppuVar12;
  char *pcVar13;
  uint uVar14;
  char *pcVar15;
  uint uVar16;
  uint uVar17;
  int iVar18;
  float10 fVar19;
  ulonglong uVar20;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  char in_stack_0000001c;
  uint uStack_164;
  uint uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  uint uStack_150;
  uint uStack_14c;
  undefined **appuStack_148 [3];
  uint uStack_13c;
  undefined ***pppuStack_138;
  uint *puStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 *puStack_128;
  undefined4 *puStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 *puStack_118;
  undefined4 *puStack_114;
  int aiStack_110 [2];
  undefined uStack_107;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined uStack_fc;
  int iStack_f8;
  undefined **appuStack_e0 [18];
  undefined uStack_98;
  int iStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  int iStack_84;
  undefined4 *******pppppppuStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  undefined8 uStack_70;
  undefined4 *******apppppppuStack_68 [4];
  int iStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined4 *******pppppppuStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aba59;
  pvStack_10 = ExceptionList;
  appuStack_148[0] = &PTR_018bfd64;
  appuStack_e0[0] = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 1;
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_00565490(appuStack_148 + 1,0,0);
  uStack_8 = 2;
  *(undefined ***)((int)appuStack_148 + (int)appuStack_148[0][1]) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&uStack_14c + (int)appuStack_148[0][1]) = appuStack_148[0][1] + -0x68;
  FUN_0054ee60();
  pppuStack_138 = appuStack_148 + 2;
  appuStack_148[1] = std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  puStack_134 = &uStack_13c;
  puStack_128 = &uStack_130;
  puStack_124 = &uStack_12c;
  puStack_118 = &uStack_120;
  puStack_114 = &uStack_11c;
  uStack_104 = DAT_01e90d08;
  uStack_fc = 0;
  uStack_107 = 0;
  uStack_13c = 0;
  uStack_12c = 0;
  uStack_11c = 0;
  appuStack_148[2] = (undefined **)0x0;
  uStack_130 = 0;
  uStack_120 = 0;
  iStack_f8 = 0;
  uStack_100 = DAT_01e90d0c;
  aiStack_110[1] = 0;
  uStack_70 = 3.18299368644791e-313;
  pppppppuStack_80 = (undefined4 *******)((uint)pppppppuStack_80 & 0xffffff00);
  uStack_8._0_1_ = 4;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf9a4) &&
     (FUN_016f3809(&DAT_01eaf9a4), DAT_01eaf9a4 == -1)) {
    uStack_8._0_1_ = 5;
    DAT_01eaf99c = FUN_00575b30();
    FUN_016f3654(FUN_0187e920);
    uStack_8._0_1_ = 4;
    FUN_016f37bf(&DAT_01eaf9a4);
  }
  puVar5 = (undefined4 *)FUN_01518d10(&uStack_160,1,0,&DAT_018c0e28);
  uStack_54 = 0xf;
  iStack_58 = 0;
  apppppppuStack_68[0] = (undefined4 *******)((uint)apppppppuStack_68[0] & 0xffffff00);
  iVar18 = puVar5[4];
  uStack_8._0_1_ = 7;
  uStack_14 = 3;
  if (iVar18 != 0) {
    puVar6 = puVar5;
    if (7 < (uint)puVar5[5]) {
      puVar6 = (undefined4 *)*puVar5;
    }
    if (7 < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    uVar7 = FUN_01686580();
    FUN_01685a20(puVar5,(int)puVar6 + iVar18 * 2,apppppppuStack_68,uVar7);
  }
  uStack_8._0_1_ = 8;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = uStack_4c & 0xffffff00;
  uStack_14 = 7;
  FUN_0058a190(iStack_58 + 0xb);
  pppppppuVar12 = apppppppuStack_68;
  if (0xf < uStack_54) {
    pppppppuVar12 = apppppppuStack_68[0];
  }
  FUN_00554150(pppppppuVar12,iStack_58);
  FUN_00554150("/MemoryDump",0xb);
  puVar5 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar5 = param_1;
  }
  puVar5 = (undefined4 *)FUN_00554150(puVar5,in_stack_00000014);
  uStack_14 = 0xf;
  pppppppuStack_34 = (undefined4 *******)*puVar5;
  uStack_30 = puVar5[1];
  uStack_2c = puVar5[2];
  uStack_28 = puVar5[3];
  uStack_24 = *(undefined8 *)(puVar5 + 4);
  puVar5[4] = 0;
  puVar5[5] = 0xf;
  *(undefined *)puVar5 = 0;
  uStack_8._0_1_ = 9;
  piVar8 = (int *)FUN_00554150(&DAT_018e36d0,4);
  pppppppuVar12 = (undefined4 *******)*piVar8;
  iVar18 = piVar8[1];
  iVar9 = piVar8[2];
  iVar1 = piVar8[3];
  uStack_1c = *(double *)(piVar8 + 4);
  piVar8[4] = 0;
  piVar8[5] = 0xf;
  *(undefined *)piVar8 = 0;
  FUN_005507b0();
  uStack_8._0_1_ = 8;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  uStack_70 = uStack_1c;
  pppppppuStack_80 = pppppppuVar12;
  iStack_7c = iVar18;
  iStack_78 = iVar9;
  iStack_74 = iVar1;
  if (0xf < uStack_24._4_4_) {
    uVar16 = uStack_24._4_4_ + 1;
    pppppppuVar12 = pppppppuStack_34;
    if (0xfff < uVar16) {
      pppppppuVar12 = (undefined4 *******)pppppppuStack_34[-1];
      uVar16 = uStack_24._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_34 + (-4 - (int)pppppppuVar12))) {
LAB_0070c637:
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar12,uVar16);
  }
  uStack_24 = 0xf00000000;
  pppppppuStack_34 = (undefined4 *******)((uint)pppppppuStack_34 & 0xffffff00);
  uStack_8._0_1_ = 7;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_38) {
    uVar17 = uStack_38 + 1;
    uVar16 = uStack_4c;
    if (0xfff < uVar17) {
      uVar16 = *(uint *)(uStack_4c - 4);
      uVar17 = uStack_38 + 0x24;
      if (0x1f < (uStack_4c - uVar16) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar16,uVar17);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = uStack_4c & 0xffffff00;
  uStack_8._0_1_ = 6;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_54) {
    uVar16 = uStack_54 + 1;
    pppppppuVar12 = apppppppuStack_68[0];
    if (0xfff < uVar16) {
      pppppppuVar12 = (undefined4 *******)apppppppuStack_68[0][-1];
      uVar16 = uStack_54 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_68[0] + (-4 - (int)pppppppuVar12))) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar12,uVar16);
  }
  iStack_58 = 0;
  uStack_54 = 0xf;
  apppppppuStack_68[0] = (undefined4 *******)((uint)apppppppuStack_68[0] & 0xffffff00);
  uStack_8._0_1_ = 4;
  if (7 < uStack_14c) {
    uVar16 = uStack_14c * 2 + 2;
    uVar17 = uStack_160;
    if (0xfff < uVar16) {
      uVar17 = *(uint *)(uStack_160 - 4);
      uVar16 = uStack_14c * 2 + 0x25;
      if (0x1f < (uStack_160 - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar17,uVar16);
  }
  FUN_00708820(&uStack_1c,&param_1);
  iVar18 = 0;
  piVar8 = (int *)uStack_1c;
  while (piVar8 != uStack_1c._4_4_) {
    piVar10 = (int *)piVar8[2];
    iVar18 = iVar18 + 1;
    if (*(char *)((int)piVar10 + 0xd) == '\0') {
      cVar4 = *(char *)(*piVar10 + 0xd);
      piVar8 = piVar10;
      piVar10 = (int *)*piVar10;
      while (cVar4 == '\0') {
        cVar4 = *(char *)(*piVar10 + 0xd);
        piVar8 = piVar10;
        piVar10 = (int *)*piVar10;
      }
    }
    else {
      cVar4 = *(char *)(piVar8[1] + 0xd);
      piVar3 = (int *)piVar8[1];
      piVar10 = piVar8;
      while ((piVar8 = piVar3, cVar4 == '\0' && (piVar10 == (int *)piVar8[2]))) {
        cVar4 = *(char *)(piVar8[1] + 0xd);
        piVar3 = (int *)piVar8[1];
        piVar10 = piVar8;
      }
    }
  }
  pppppppuVar12 = &pppppppuStack_80;
  if (0xf < uStack_70._4_4_) {
    pppppppuVar12 = pppppppuStack_80;
  }
  if ((iStack_f8 == 0) &&
     (iVar9 = FUN_016de719(pppppppuVar12,(iVar18 == 0) * '\b' + '\n',0x40), iVar9 != 0)) {
    FUN_00553bc0(iVar9,1);
    uStack_8._0_1_ = 10;
    piVar8 = *(int **)(aiStack_110[0] + 4);
    uStack_1c = (double)CONCAT44(piVar8,(int *)uStack_1c);
    (**(code **)(*piVar8 + 4))();
    uStack_14 = 0x39;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    piVar10 = (int *)FUN_0054e680(&uStack_1c);
    uStack_1c = (double)CONCAT44(piVar10,(int *)uStack_1c);
    cVar4 = (**(code **)(*piVar10 + 0xc))();
    if (cVar4 == '\0') {
      aiStack_110[1] = (int)uStack_1c._4_4_;
      FUN_00553ca0();
    }
    else {
      aiStack_110[1] = 0;
    }
    uStack_8._0_1_ = 0xc;
    if ((piVar8 != (int *)0x0) &&
       (puVar5 = (undefined4 *)(**(code **)(*piVar8 + 8))(), puVar5 != (undefined4 *)0x0)) {
      (**(code **)*puVar5)(1);
    }
    uStack_8._0_1_ = 4;
    uVar16 = 4;
    if (*(int *)((int)aiStack_110 + (int)appuStack_148[0][1]) != 0) {
      uVar16 = 0;
    }
  }
  else {
    uStack_14 = 0x19;
    uVar16 = (uint)(*(int *)((int)aiStack_110 + (int)appuStack_148[0][1]) == 0) * 4 + 2 |
             *(uint *)((int)&uStack_13c + (int)appuStack_148[0][1]);
  }
  FUN_00554460(uVar16,0);
  if (iVar18 == 0) {
    FUN_0055b0f0(&uStack_1c,0,&param_1,uStack_1c._4_4_);
  }
  uVar20 = FUN_01522960();
  FUN_00558890(appuStack_148,"Total MB, ");
  uVar7 = FUN_0070a750(uVar20 >> 0x14);
  FUN_00562ba0(uVar7);
  FUN_00558890(appuStack_148,"Free MB, ");
  uVar20 = FUN_015228f0();
  uVar7 = FUN_0070a750(uVar20 >> 0x14);
  FUN_00562ba0(uVar7);
  FUN_00558890(appuStack_148,"Time, ");
  fVar19 = (float10)FUN_01683110();
  uStack_1c = (double)fVar19;
  uVar7 = FUN_0070a5b0(uStack_1c);
  FUN_00562ba0(uVar7);
  puVar11 = &DAT_018bdf50;
  if (in_stack_0000001c == '\0') {
    puVar11 = &DAT_018bdf48;
  }
  uVar7 = FUN_00558890(appuStack_148,"GCHappened, ",puVar11);
  uVar7 = FUN_00558890(uVar7);
  FUN_00562ba0(uVar7);
  FUN_00ccdf90();
  iVar18 = 0;
  do {
    if (iVar18 != 0) {
      uVar16 = FUN_00cce020(iVar18);
      FUN_00cce030(&pppppppuStack_34,iVar18);
      uStack_8._0_1_ = 0xd;
      if (0x7d000000 < (uVar16 & 0xfff00000)) {
        uVar16 = 0;
      }
      pppppppuVar12 = &pppppppuStack_34;
      if (0xf < uStack_24._4_4_) {
        pppppppuVar12 = pppppppuStack_34;
      }
      uVar7 = FUN_0055b3b0(appuStack_148,pppppppuVar12,(undefined4)uStack_24);
      FUN_00558890(uVar7," MB, ");
      uVar7 = FUN_0056ef60(uVar16 >> 0x14);
      FUN_00562ba0(uVar7);
      uStack_8._0_1_ = 4;
      if (0xf < uStack_24._4_4_) {
        uVar16 = uStack_24._4_4_ + 1;
        pppppppuVar12 = pppppppuStack_34;
        if (0xfff < uVar16) {
          pppppppuVar12 = (undefined4 *******)pppppppuStack_34[-1];
          uVar16 = uStack_24._4_4_ + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (uint)((int)pppppppuStack_34 + (-4 - (int)pppppppuVar12))) goto LAB_0070c637;
        }
        FUN_01674ea0(pppppppuVar12,uVar16);
      }
    }
    iVar18 = iVar18 + 1;
  } while (iVar18 < 0x17);
  uStack_98 = 0;
  iStack_94 = FUN_00588320(0xb);
  iStack_90 = 0;
  uStack_8c = 0x3f800000;
  uStack_88 = 0;
  iStack_84 = 0;
  uStack_8._0_1_ = 0xe;
  uVar16 = 0;
  iVar18 = FUN_01675020();
  if (iVar18 != 0) {
    do {
      uVar17 = uStack_164;
      iVar18 = FUN_01675030(uVar16);
      if (iVar18 == 0) {
        pcVar13 = (char *)FUN_01675050(uVar16);
        uStack_24 = 0xf00000000;
        pppppppuStack_34 = (undefined4 *******)((uint)pppppppuStack_34 & 0xffffff00);
        pcVar15 = pcVar13;
        do {
          cVar4 = *pcVar15;
          pcVar15 = pcVar15 + 1;
        } while (cVar4 != '\0');
        FUN_005542c0(pcVar13,(int)pcVar15 - (int)(pcVar13 + 1));
        uStack_8._0_1_ = 0xf;
        uVar14 = FUN_016750a0(uVar16);
        FUN_0054ef60(&pppppppuStack_34);
        uStack_14 = uStack_14 | 0x40;
        uStack_164 = uStack_164 & 0xffffff00;
        uStack_50 = uVar17;
        uStack_4c = uStack_160;
        uStack_48 = uStack_15c;
        uStack_44 = uStack_158;
        uStack_40 = uStack_154;
        uStack_3c = uStack_150;
        uStack_154 = 0;
        uStack_150 = 0xf;
        uStack_8._0_1_ = 0x11;
        uStack_14c = uVar14;
        uStack_38 = uVar14;
        FUN_00709510(&uStack_1c,&uStack_50,&uStack_50);
        uStack_8._0_1_ = 0x10;
        if (0xf < uStack_3c) {
          uVar14 = uStack_3c + 1;
          uVar17 = uStack_50;
          if (0xfff < uVar14) {
            uVar17 = *(uint *)(uStack_50 - 4);
            uVar14 = uStack_3c + 0x24;
            uVar2 = (undefined)uStack_8;
            if (0x1f < (uStack_50 - uVar17) - 4) goto LAB_0070c637;
          }
          FUN_01674ea0(uVar17,uVar14);
        }
        uStack_8._0_1_ = 0xe;
        if (0xf < uStack_24._4_4_) {
          uVar17 = uStack_24._4_4_ + 1;
          pppppppuVar12 = pppppppuStack_34;
          if (0xfff < uVar17) {
            pppppppuVar12 = (undefined4 *******)pppppppuStack_34[-1];
            uVar17 = uStack_24._4_4_ + 0x24;
            uVar2 = (undefined)uStack_8;
            if (0x1f < (uint)((int)pppppppuStack_34 + (-4 - (int)pppppppuVar12))) goto LAB_0070c637;
          }
          FUN_01674ea0(pppppppuVar12,uVar17);
        }
      }
      uVar16 = uVar16 + 1;
      uVar17 = FUN_01675020();
    } while (uVar16 < uVar17);
  }
  if (iStack_90 == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5 = *(undefined4 **)(iStack_84 + iStack_94 * 4);
  }
  for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
    piVar8 = puVar5 + 2;
    if (0x7d000000 < (puVar5[8] & 0xfff00000)) {
      puVar5[8] = 0;
    }
    if (0xf < (uint)puVar5[7]) {
      piVar8 = (int *)*piVar8;
    }
    uVar7 = FUN_0055b3b0(appuStack_148,piVar8,puVar5[6]);
    FUN_00558890(uVar7," MB, ");
    uVar7 = FUN_0056ef60((uint)puVar5[8] >> 0x14);
    FUN_00562ba0(uVar7);
  }
  iVar18 = FUN_005548a0();
  if (iVar18 == 0) {
    FUN_00554460((uint)(*(int *)((int)aiStack_110 + (int)appuStack_148[0][1]) == 0) * 4 + 2 |
                 *(uint *)((int)&uStack_13c + (int)appuStack_148[0][1]),0);
  }
  FUN_005d1280();
  uStack_8._0_1_ = 3;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_70._4_4_) {
    uVar16 = uStack_70._4_4_ + 1;
    pppppppuVar12 = pppppppuStack_80;
    if (0xfff < uVar16) {
      pppppppuVar12 = (undefined4 *******)pppppppuStack_80[-1];
      uVar16 = uStack_70._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_80 + (-4 - (int)pppppppuVar12))) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar12,uVar16);
  }
  uStack_70 = 3.18299368644791e-313;
  pppppppuStack_80 = (undefined4 *******)((uint)pppppppuStack_80 & 0xffffff00);
  *(undefined ***)((int)appuStack_148 + (int)appuStack_148[0][1]) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&uStack_14c + (int)appuStack_148[0][1]) = appuStack_148[0][1] + -0x68;
  FUN_00550570();
  *(undefined ***)((int)appuStack_148 + (int)appuStack_148[0][1]) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&uStack_14c + (int)appuStack_148[0][1]) = appuStack_148[0][1] + -8;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  appuStack_e0[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_e0);
  if (0xf < in_stack_00000018) {
    uVar16 = in_stack_00000018 + 1;
    puVar5 = param_1;
    if (0xfff < uVar16) {
      puVar5 = (undefined4 *)param_1[-1];
      uVar16 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar16);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9979 ; VA 0x0070c660 ; FUN_0070c660 */

undefined4 __thiscall FUN_0070c660(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xc) + iVar1);
  puVar3 = (undefined4 *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((undefined4 *)puVar3[1] == param_3) {
    if (puVar2 == param_3) {
      *puVar3 = *(undefined4 *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      puVar3[1] = param_3[1];
    }
  }
  else if (puVar2 == param_3) {
    *puVar3 = *param_3;
  }
  FUN_0070cfc0(param_2,param_3);
  return param_2;
}



/* FUNCTION 9980 ; VA 0x0070c700 ; FUN_0070c700 */

int __thiscall FUN_0070c700(int param_1,byte *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(param_1 + 0xc);
  uVar3 = ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 & *(uint *)(param_1 + 0x18);
  piStack_1c = *(int **)(iVar6 + uVar3 * 8);
  iStack_20 = uVar3 * 8 + 4;
  piVar1 = *(int **)(param_1 + 4);
  piVar7 = piStack_1c;
  while( true ) {
    piVar4 = piVar1;
    if (piStack_1c != piVar1) {
      piVar4 = (int *)**(undefined4 **)(iStack_20 + iVar6);
    }
    if (piVar7 == piVar4) goto LAB_0070c7d7;
    piVar4 = piVar7;
    if (piVar7[2] == *(int *)param_2) break;
    piVar7 = (int *)*piVar7;
  }
  while( true ) {
    piVar5 = piVar1;
    if (piStack_1c != piVar1) {
      piVar5 = (int *)**(undefined4 **)(iStack_20 + iVar6);
    }
    if ((piVar4 == piVar5) || (*(int *)param_2 != piVar4[2])) break;
    piVar4 = (int *)*piVar4;
  }
  if (piVar7 == piVar4) {
LAB_0070c7d7:
    piVar4 = piVar1;
    piVar7 = piVar1;
  }
  iVar6 = 0;
  for (piVar5 = piVar7; piVar5 != piVar4; piVar5 = (int *)*piVar5) {
    iVar6 = iVar6 + 1;
  }
  iStack_18 = iVar6;
  iStack_14 = param_1;
  if ((piVar7 == (int *)*piVar1) && (piVar4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_0070b5b0();
    FUN_005cb500(8);
  }
  else {
    ExceptionList = &pvStack_10;
    if (piVar7 != piVar4) {
      do {
        piVar1 = (int *)*piVar7;
        iVar6 = (((((*(byte *)(piVar7 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                   (uint)*(byte *)((int)piVar7 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar7 + 10)
                  ) * 0x1000193 ^ (uint)*(byte *)((int)piVar7 + 0xb)) * 0x1000193 &
                *(uint *)(iStack_14 + 0x18)) * 8;
        iVar2 = *(int *)(iStack_14 + 0xc);
        if (*(int **)(iVar6 + 4 + iVar2) == piVar7) {
          if (*(int **)(iVar6 + iVar2) == piVar7) {
            *(undefined4 *)(iVar6 + iVar2) = *(undefined4 *)(iStack_14 + 4);
            *(undefined4 *)(iVar6 + 4 + *(int *)(iStack_14 + 0xc)) = *(undefined4 *)(param_1 + 4);
          }
          else {
            *(int *)(iVar6 + 4 + iVar2) = piVar7[1];
          }
        }
        else if (*(int **)(iVar6 + iVar2) == piVar7) {
          *(int **)(iVar6 + iVar2) = piVar1;
        }
        FUN_0070cfc0(&iStack_20,piVar7);
        piVar7 = piVar1;
      } while (piVar1 != piVar4);
      ExceptionList = pvStack_10;
      return iStack_18;
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 9981 ; VA 0x0070c8f0 ; FUN_0070c8f0 */

void __thiscall FUN_0070c8f0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_01674ea0(param_3,0x10);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 9982 ; VA 0x0070c9a0 ; FUN_0070c9a0 */

int __thiscall FUN_0070c9a0(int param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  piVar2 = *(int **)(param_1 + 4);
  uVar4 = ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 & *(uint *)(param_1 + 0x18);
  piVar8 = *(int **)(iVar1 + uVar4 * 8);
  iVar7 = uVar4 * 8 + 4;
  piVar10 = piVar8;
  while( true ) {
    piVar5 = piVar2;
    if (piVar8 != piVar2) {
      piVar5 = (int *)**(undefined4 **)(iVar7 + iVar1);
    }
    if (piVar10 == piVar5) goto LAB_0070ca7d;
    piVar5 = piVar10;
    if (piVar10[2] == *(int *)param_2) break;
    piVar10 = (int *)*piVar10;
  }
  while( true ) {
    piVar6 = piVar2;
    if (piVar8 != piVar2) {
      piVar6 = (int *)**(undefined4 **)(iVar7 + iVar1);
    }
    if ((piVar5 == piVar6) || (*(int *)param_2 != piVar5[2])) break;
    piVar5 = (int *)*piVar5;
  }
  if (piVar10 == piVar5) {
LAB_0070ca7d:
    piVar5 = piVar2;
    piVar10 = piVar2;
  }
  iVar7 = 0;
  for (piVar8 = piVar10; piVar8 != piVar5; piVar8 = (int *)*piVar8) {
    iVar7 = iVar7 + 1;
  }
  piVar8 = (int *)*piVar2;
  ppvVar3 = &pvStack_10;
  if ((piVar10 == piVar8) && (piVar5 == piVar2)) {
    ExceptionList = &pvStack_10;
    *piVar2 = (int)piVar2;
    uStack_8 = 0;
    *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
    *(undefined4 *)(param_1 + 8) = 0;
    if (piVar8 != *(int **)(param_1 + 4)) {
      do {
        piVar2 = (int *)*piVar8;
        FUN_01674ea0(piVar8,0x10);
        piVar8 = piVar2;
      } while (piVar2 != *(int **)(param_1 + 4));
    }
    FUN_005cb500(8);
  }
  else {
    while (ExceptionList = ppvVar3, piVar10 != piVar5) {
      piVar2 = (int *)*piVar10;
      iVar1 = (((((*(byte *)(piVar10 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar10 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar10 + 10)
                ) * 0x1000193 ^ (uint)*(byte *)((int)piVar10 + 0xb)) * 0x1000193 &
              *(uint *)(param_1 + 0x18)) * 8;
      puVar9 = (undefined4 *)(iVar1 + *(int *)(param_1 + 0xc));
      if ((int *)puVar9[1] == piVar10) {
        if ((int *)*puVar9 == piVar10) {
          *puVar9 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar9[1] = piVar10[1];
        }
      }
      else if ((int *)*puVar9 == piVar10) {
        *puVar9 = piVar2;
      }
      *(int *)piVar10[1] = *piVar10;
      *(int *)(*piVar10 + 4) = piVar10[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar10,0x10);
      piVar10 = piVar2;
      ppvVar3 = (void **)ExceptionList;
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 9983 ; VA 0x0070cbb0 ; FUN_0070cbb0 */

void __thiscall FUN_0070cbb0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_01674ea0(param_3,0xc);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 9984 ; VA 0x0070cc60 ; FUN_0070cc60 */

int __thiscall FUN_0070cc60(int param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  
  piVar2 = *(int **)(param_1 + 4);
  uVar4 = ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 & *(uint *)(param_1 + 0x18);
  piVar3 = *(int **)(*(int *)(param_1 + 0xc) + uVar4 * 8);
  puVar5 = (undefined4 *)(uVar4 * 8 + 4 + *(int *)(param_1 + 0xc));
  piVar9 = piVar3;
  while( true ) {
    piVar6 = piVar2;
    if (piVar3 != piVar2) {
      piVar6 = *(int **)*puVar5;
    }
    if (piVar9 == piVar6) goto LAB_0070cd1a;
    piVar6 = piVar9;
    if (piVar9[2] == *(int *)param_2) break;
    piVar9 = (int *)*piVar9;
  }
  while( true ) {
    piVar7 = piVar2;
    if (piVar3 != piVar2) {
      piVar7 = *(int **)*puVar5;
    }
    if ((piVar6 == piVar7) || (*(int *)param_2 != piVar6[2])) break;
    piVar6 = (int *)*piVar6;
  }
  if (piVar9 == piVar6) {
LAB_0070cd1a:
    piVar6 = piVar2;
    piVar9 = piVar2;
  }
  iVar8 = 0;
  for (piVar3 = piVar9; piVar3 != piVar6; piVar3 = (int *)*piVar3) {
    iVar8 = iVar8 + 1;
  }
  if ((piVar9 == (int *)*piVar2) && (piVar6 == piVar2)) {
    FUN_0070b540();
    return iVar8;
  }
  if (piVar9 != piVar6) {
    do {
      piVar2 = (int *)*piVar9;
      iVar1 = (((((*(byte *)(piVar9 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar9 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 10))
                * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 0xb)) * 0x1000193 &
              *(uint *)(param_1 + 0x18)) * 8;
      puVar5 = (undefined4 *)(iVar1 + *(int *)(param_1 + 0xc));
      if ((int *)puVar5[1] == piVar9) {
        if ((int *)*puVar5 == piVar9) {
          *puVar5 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar5[1] = piVar9[1];
        }
      }
      else if ((int *)*puVar5 == piVar9) {
        *puVar5 = piVar2;
      }
      *(int *)piVar9[1] = *piVar9;
      *(int *)(*piVar9 + 4) = piVar9[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar9,0xc);
      piVar9 = piVar2;
    } while (piVar2 != piVar6);
    return iVar8;
  }
  return iVar8;
}



/* FUNCTION 9985 ; VA 0x0070ce30 ; FUN_0070ce30 */

void __thiscall FUN_0070ce30(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    piVar3 = piVar1;
    piVar5 = (int *)piVar1[1];
    ExceptionList = &pvStack_10;
    if (*(char *)(piVar1[1] + 0xd) == '\0') {
      do {
        FUN_00601e60(piVar5[2]);
        piVar3 = (int *)*piVar5;
        FUN_01674ea0(piVar5,0x18);
        piVar5 = piVar3;
      } while (*(char *)((int)piVar3 + 0xd) == '\0');
      piVar3 = (int *)*param_1;
    }
    piVar3[1] = (int)piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar4 = FUN_00553830(param_3);
    FUN_01674ea0(uVar4,0x18);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9986 ; VA 0x0070cf20 ; FUN_0070cf20 */

int __thiscall FUN_0070cf20(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  
  puVar4 = (undefined4 *)*param_1;
  puVar1 = (undefined4 *)puVar4[1];
  puVar5 = puVar4;
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    puVar2 = puVar1;
    do {
      if ((int)puVar2[4] < *param_2) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        if ((*(char *)((int)puVar5 + 0xd) != '\0') && (*param_2 < (int)puVar2[4])) {
          puVar5 = puVar2;
        }
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  }
  if (*(char *)((int)puVar5 + 0xd) == '\0') {
    puVar1 = (undefined4 *)*puVar5;
  }
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    do {
      if (*param_2 < (int)puVar1[4]) {
        puVar2 = (undefined4 *)*puVar1;
        puVar5 = puVar1;
      }
      else {
        puVar2 = (undefined4 *)puVar1[2];
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  iVar6 = 0;
  param_2 = puVar4;
  while (param_2 != puVar5) {
    iVar6 = iVar6 + 1;
    FUN_00551320();
  }
  FUN_0070ce30(&param_2,puVar4,puVar5);
  return iVar6;
}



/* FUNCTION 9987 ; VA 0x0070cfc0 ; FUN_0070cfc0 */

void __thiscall FUN_0070cfc0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  *(int *)param_3[1] = *param_3;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  uVar2 = param_3[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_3 + 6,param_3 + 6,2);
      }
    }
    param_3[4] = 0;
  }
  FUN_01674ea0(param_3,0x30);
  *param_2 = iVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9988 ; VA 0x0070d050 ; FUN_0070d050 */

undefined8 * FUN_0070d050(undefined8 *param_1,int *param_2)

{
  int iVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  int iVar5;
  int iVar6;
  
  bVar2 = (byte)DAT_01d5bec8;
  iVar5 = *param_2 << (bVar2 & 0x1f);
  bVar3 = (byte)DAT_01d5becc;
  iVar6 = param_2[1] << (bVar3 & 0x1f);
  bVar4 = (byte)DAT_01d5bed0;
  iVar1 = param_2[2] << (bVar4 & 0x1f);
  *param_1 = CONCAT44((float)iVar6,(float)iVar5);
  *(float *)(param_1 + 1) = (float)iVar1;
  *(ulonglong *)((int)param_1 + 0xc) =
       CONCAT44((float)((1 << (bVar3 & 0x1f)) + iVar6),(float)((1 << (bVar2 & 0x1f)) + iVar5));
  *(float *)((int)param_1 + 0x14) = (float)((1 << (bVar4 & 0x1f)) + iVar1);
  return param_1;
}



/* FUNCTION 9989 ; VA 0x0070d110 ; FUN_0070d110 */

uint FUN_0070d110(int param_1,int *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar4 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00aff8c0();
  uVar6 = (uint)*(ushort *)(iVar5 + 0x1da);
  iStack_14 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= uVar6) {
    iStack_14 = param_1;
  }
  if (iStack_14 != 0) {
    FUN_0070c9a0(&iStack_14);
    FUN_0070cc60(&iStack_14);
    uVar6 = FUN_0070cc60(&iStack_14);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_2 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 9990 ; VA 0x0070d1d0 ; FUN_0070d1d0 */

void __thiscall FUN_0070d1d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  char cVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aba80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  puVar7 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_2);
  puVar8 = *(undefined4 **)(param_1 + 0x28c);
  uStack_8 = 0;
  if (*(undefined4 **)(param_1 + 0x290) == puVar8) {
    FUN_007086e0(puVar8,puVar7);
  }
  else {
    *puVar8 = 0;
    puVar8[1] = 0;
    *puVar8 = *puVar7;
    puVar8[1] = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(int *)(param_1 + 0x28c) = *(int *)(param_1 + 0x28c) + 8;
  }
  piVar2 = piStack_18;
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  puVar8 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_2);
  uStack_8 = 1;
  uVar3 = *puVar8;
  uVar4 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  cVar6 = FUN_0070afb0(uVar3,uVar4);
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (cVar6 != '\0') {
    FUN_007099d0(&param_3);
    FUN_005edd10();
    FUN_006f4440(param_2,0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9991 ; VA 0x0070d350 ; FUN_0070d350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0070d350(int param_1,uint *param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined auVar2 [16];
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined (*pauVar8) [12];
  int iVar9;
  uint uVar10;
  byte *pbVar11;
  int iVar12;
  int iVar13;
  bool bVar14;
  undefined auVar15 [16];
  float fVar16;
  int iVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar22;
  float fVar23;
  undefined in_XMM2 [16];
  undefined auVar21 [16];
  uint uVar24;
  uint uVar25;
  float fVar26;
  float fVar28;
  float fVar29;
  float fVar30;
  undefined auVar27 [16];
  float fVar31;
  float fVar32;
  undefined auStack_a8 [8];
  int iStack_a0;
  int iStack_9c;
  int iStack_94;
  int iStack_90;
  uint uStack_8c;
  uint uStack_88;
  int iStack_84;
  int aiStack_80 [5];
  uint uStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  int iStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined uStack_41;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  byte *pbStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017abab8;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  FUN_0060e810(0,&uStack_18,&uStack_41);
  uStack_5c = 0;
  iStack_58 = 0;
  iStack_8 = 0;
  if (DAT_01d69070 == '\0') {
    pcVar1 = *(code **)(**(int **)(param_1 + 0x140) + 0x44);
    uVar4 = FUN_0070d050(aiStack_80,param_2);
    (*pcVar1)(uVar4,&iStack_68);
    param_1 = iStack_28;
  }
  else {
    uVar4 = FUN_0070d050(aiStack_80,param_2);
    FUN_00ce48e0(uVar4,&iStack_68);
  }
  uVar10 = 0;
  uVar5 = iStack_64 - iStack_68 >> 2;
  uStack_1c = 0;
  if (uVar5 != 0) {
    do {
      uStack_1c = uVar10;
      if (*(int *)(iStack_68 + uVar10 * 4) != iStack_58) break;
      uVar10 = uVar10 + 1;
      uStack_1c = uVar10;
    } while (uVar10 < uVar5);
  }
LAB_0070d414:
  bVar14 = uStack_1c == uVar5;
  while (uVar10 = uStack_1c, !bVar14) {
    uStack_14 = FUN_00b06640(*(undefined4 *)(iStack_68 + uStack_1c * 4));
    if ((DAT_01d5bf10 == '\0') || (cVar3 = FUN_00621090(uStack_14), cVar3 != '\0')) {
      if (DAT_01d5bf20 == '\0') {
        pauVar8 = (undefined (*) [12])FUN_00c15960();
        fVar26 = SUB164(_DAT_018e0060,0);
        fVar28 = SUB164(_DAT_018e0060,4);
        fVar29 = SUB164(_DAT_018e0060,8);
        fVar30 = SUB164(_DAT_018e0060,0xc);
        auVar21 = rcpps(in_XMM2,_DAT_018e0060);
        fVar22 = auVar21._0_4_;
        fVar23 = auVar21._4_4_;
        fVar31 = auVar21._8_4_;
        fVar32 = auVar21._12_4_;
        fVar16 = (_DAT_018e0050 - fVar22 * fVar26) * fVar22;
        fVar18 = (_UNK_018e0054 - fVar23 * fVar28) * fVar23;
        fVar19 = (_UNK_018e0058 - fVar31 * fVar29) * fVar31;
        fVar20 = (_UNK_018e005c - fVar32 * fVar30) * fVar32;
        uVar5 = -(uint)((float)(~DAT_018c4ea0 & (uint)fVar16) < _DAT_018e0080) &
                ((uint)fVar16 ^ (uint)fVar22) ^ (uint)fVar22;
        uVar10 = -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar18) < _UNK_018e0084) &
                 ((uint)fVar18 ^ (uint)fVar23) ^ (uint)fVar23;
        uVar24 = -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar19) < _UNK_018e0088) &
                 ((uint)fVar19 ^ (uint)fVar31) ^ (uint)fVar31;
        uVar25 = -(uint)((float)(~_UNK_018c4eac & (uint)fVar20) < _UNK_018e008c) &
                 ((uint)fVar20 ^ (uint)fVar32) ^ (uint)fVar32;
        fVar31 = (float)(((uint)fVar26 & DAT_018c4ea0 ^ uVar5) &
                         -(uint)((float)(~DAT_018c4ea0 & (uint)fVar26) == _DAT_018e0080) ^ uVar5);
        fVar32 = (float)(((uint)fVar28 & _UNK_018c4ea4 ^ uVar10) &
                         -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar28) == _UNK_018e0084) ^ uVar10);
        fVar26 = (float)(((uint)fVar29 & _UNK_018c4ea8 ^ uVar24) &
                         -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar29) == _UNK_018e0088) ^ uVar24);
        auVar27._0_8_ = CONCAT44(0.0 - SUB164(_DAT_018e0070,4),0.0 - SUB164(_DAT_018e0070,0));
        auVar27._8_4_ = 0.0 - SUB164(_DAT_018e0070,8);
        auVar27._12_4_ = 0.0 - SUB164(_DAT_018e0070,0xc);
        auVar15._8_4_ = auVar27._8_4_;
        auVar15._0_8_ = auVar27._0_8_;
        auVar15._12_4_ = auVar27._12_4_;
        auVar21._12_4_ = 0;
        auVar21._0_12_ = *pauVar8;
        auVar21 = maxps(auVar15,auVar21);
        auVar21 = minps(_DAT_018e0070,auVar21);
        fVar20 = auVar21._0_4_ * fVar31;
        fVar22 = auVar21._4_4_ * fVar32;
        fVar23 = auVar21._8_4_ * fVar26;
        fVar16 = (float)(int)fVar20;
        fVar18 = (float)(int)fVar22;
        fVar19 = (float)(int)fVar23;
        iVar17 = (int)(fVar16 - (float)(_DAT_018e0040 & -(uint)(fVar20 < fVar16)));
        iStack_4c = (int)(fVar18 - (float)(_UNK_018e0044 & -(uint)(fVar22 < fVar18)));
        uStack_38 = (uint)(fVar19 - (float)(_UNK_018e0048 & -(uint)(fVar23 < fVar19)));
        auVar2._4_4_ = *(undefined4 *)(pauVar8[1] + 4);
        auVar2._0_4_ = *(undefined4 *)pauVar8[1];
        auVar2._8_4_ = *(undefined4 *)(pauVar8[1] + 8);
        auVar2._12_4_ = 0;
        auVar21 = maxps(auVar27,auVar2);
        auVar21 = minps(_DAT_018e0070,auVar21);
        in_XMM2._0_4_ = auVar21._0_4_ * fVar31;
        in_XMM2._4_4_ = auVar21._4_4_ * fVar32;
        in_XMM2._8_4_ = auVar21._8_4_ * fVar26;
        in_XMM2._12_4_ =
             auVar21._12_4_ *
             (float)(((uint)fVar30 & _UNK_018c4eac ^ uVar25) &
                     -(uint)((float)(~_UNK_018c4eac & (uint)fVar30) == _UNK_018e008c) ^ uVar25);
        iStack_34 = (int)((float)(-(uint)((float)(int)in_XMM2._0_4_ < in_XMM2._0_4_) & _DAT_018e0040
                                 ) + (float)(int)in_XMM2._0_4_);
        iStack_30 = (int)((float)(-(uint)((float)(int)in_XMM2._4_4_ < in_XMM2._4_4_) & _UNK_018e0044
                                 ) + (float)(int)in_XMM2._4_4_);
        iStack_2c = (int)((float)(-(uint)((float)(int)in_XMM2._8_4_ < in_XMM2._8_4_) & _UNK_018e0048
                                 ) + (float)(int)in_XMM2._8_4_);
        iStack_24 = iStack_2c;
        if (((iVar17 < iStack_34) && (iStack_4c < iStack_30)) && ((int)uStack_38 < iStack_2c)) {
          iStack_9c = iStack_30 + -1;
          iStack_24 = iStack_2c + -1;
          iStack_a0 = iStack_34 + -1;
          iStack_34 = iStack_a0;
          iStack_30 = iStack_9c;
        }
        iStack_50 = 0;
        uStack_48 = 0;
        iVar9 = iStack_24;
        iVar12 = iStack_34;
        iVar13 = iStack_30;
        iStack_40 = iVar17;
        iStack_3c = iStack_4c;
        if (iStack_4c <= iStack_30) {
          do {
            uStack_18 = uStack_38;
            if ((int)uStack_38 <= iVar9) {
              do {
                iStack_50 = iVar17;
                if (iVar17 <= iVar12) {
                  pbStack_20 = (byte *)(iStack_28 + 0x148);
                  iVar13 = iVar17;
                  do {
                    pbVar11 = pbStack_20 + *pbStack_20 + 1;
                    iStack_90 = iStack_4c;
                    iStack_94 = iVar13;
                    uStack_8c = uStack_18;
                    iStack_50 = iVar13;
                    uVar4 = FUN_00ca2680(&iStack_94);
                    FUN_006e16e0(&iStack_84,uVar4,&iStack_94,
                                 -(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
                    uVar10 = uStack_1c;
                    param_1 = iStack_28;
                    if (iStack_84 != 0) goto LAB_0070d9bf;
                    iVar13 = iVar13 + 1;
                    iVar17 = iStack_40;
                    iVar9 = iStack_24;
                    iVar12 = iStack_34;
                    iStack_50 = iVar13;
                  } while (iVar13 <= iStack_34);
                }
                uStack_18 = uStack_18 + 1;
                iVar13 = iStack_30;
              } while ((int)uStack_18 <= iVar9);
            }
            iStack_4c = iStack_4c + 1;
          } while (iStack_4c <= iVar13);
        }
        param_1 = iStack_28;
        cVar3 = FUN_00620f10(uStack_14);
        uVar10 = uStack_1c;
        if (cVar3 == '\0') {
          if (DAT_01eaf35c != '\0') {
            uStack_18 = param_2[2];
            pbStack_20 = (byte *)param_2[1];
            uStack_88 = *param_2;
            puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
            iStack_8._0_1_ = 3;
            if (0xf < (uint)puVar6[5]) {
              puVar6 = (undefined4 *)*puVar6;
            }
            FUN_01677520(DAT_01eaf35c,
                         "GCing instance %s as part of gcing region (%d,%d,%d), extents=(%d,%d,%d)-(%d,%d,%d)"
                         ,puVar6,uStack_88,pbStack_20,uStack_18,iStack_40,iStack_3c,uStack_38,iVar12
                         ,iStack_30,iStack_24);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            if (0xf < uStack_6c) {
              uVar5 = uStack_6c + 1;
              iVar17 = aiStack_80[0];
              if (0xfff < uVar5) {
                iVar17 = *(int *)(aiStack_80[0] + -4);
                uVar5 = uStack_6c + 0x24;
                if (0x1f < (aiStack_80[0] - iVar17) - 4U) goto LAB_0070dab9;
              }
              FUN_01674ea0(iVar17,uVar5);
            }
          }
          uVar5 = uStack_14;
          (**(code **)(**(int **)(param_1 + 0x128) + 0xe4))
                    (*(undefined4 *)(uStack_14 + 0x18),*(undefined4 *)(uStack_14 + 0x1c));
          FUN_0070d1d0(uVar5,param_3);
          uVar10 = uStack_1c;
        }
      }
      else {
        if ((char)param_4 != '\0') {
          FUN_0070b640(uStack_14,1);
        }
        uStack_18 = uStack_14;
        piVar7 = (int *)FUN_0070aa60(&uStack_18);
        if (*piVar7 == 0) {
          if (DAT_01eaf35c != '\0') {
            uStack_18 = param_2[2];
            pbStack_20 = (byte *)param_2[1];
            uStack_1c = *param_2;
            puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
            iStack_8._0_1_ = 1;
            if (0xf < (uint)puVar6[5]) {
              puVar6 = (undefined4 *)*puVar6;
            }
            FUN_01677520(DAT_01eaf35c,"GCing instance %s as part of gcing region (%d,%d,%d)",puVar6,
                         uStack_1c,pbStack_20,uStack_18);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            if (0xf < uStack_6c) {
              uVar5 = uStack_6c + 1;
              iVar17 = aiStack_80[0];
              if (0xfff < uVar5) {
                iVar17 = *(int *)(aiStack_80[0] + -4);
                uVar5 = uStack_6c + 0x24;
                if (0x1f < (aiStack_80[0] - iVar17) - 4U) goto LAB_0070dab9;
              }
              FUN_01674ea0(iVar17,uVar5);
            }
          }
          (**(code **)(**(int **)(param_1 + 0x128) + 0xe4))
                    (*(undefined4 *)(uStack_14 + 0x18),*(undefined4 *)(uStack_14 + 0x1c));
          FUN_0070cc60(&uStack_14);
          cVar3 = FUN_00620f10(uStack_14);
          if (cVar3 == '\0') {
            FUN_0070d1d0(uStack_14,param_3);
          }
        }
        else {
          if (DAT_01eaf35c != '\0') {
            puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
            iStack_8._0_1_ = 2;
            if (0xf < (uint)puVar6[5]) {
              puVar6 = (undefined4 *)*puVar6;
            }
            FUN_01677520(DAT_01eaf35c,
                         "Part %s would be GC\'d but blocked by descendants or region occupancy",
                         puVar6);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            if (0xf < uStack_6c) {
              uVar5 = uStack_6c + 1;
              iVar17 = aiStack_80[0];
              if (0xfff < uVar5) {
                iVar17 = *(int *)(aiStack_80[0] + -4);
                uVar5 = uStack_6c + 0x24;
                if (0x1f < (aiStack_80[0] - iVar17) - 4U) goto LAB_0070dab9;
              }
              FUN_01674ea0(iVar17,uVar5);
            }
          }
          FUN_00708ea0(auStack_a8,&uStack_14,param_2);
        }
      }
    }
    else if (DAT_01eaf35c != '\0') {
      puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
      iStack_8._0_1_ = 4;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01677520(DAT_01eaf35c,"Skipping GC of local part %s",puVar6);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_6c) {
        uVar5 = uStack_6c + 1;
        iVar17 = aiStack_80[0];
        if (0xfff < uVar5) {
          iVar17 = *(int *)(aiStack_80[0] + -4);
          uVar5 = uStack_6c + 0x24;
          if (0x1f < (aiStack_80[0] - iVar17) - 4U) goto LAB_0070dab9;
        }
        FUN_01674ea0(iVar17,uVar5);
      }
    }
LAB_0070d9bf:
    uVar5 = iStack_64 - iStack_68 >> 2;
    while( true ) {
      uVar10 = uVar10 + 1;
      bVar14 = uVar10 == uVar5;
      uStack_1c = uVar10;
      if (uVar5 <= uVar10) break;
      if (*(int *)(iStack_68 + uVar10 * 4) != iStack_58) goto LAB_0070d414;
    }
  }
  (**(code **)(**(int **)(param_1 + 0x128) + 0xe4))(0xffffffff,0);
  if (((*(uint *)(*(int *)(param_1 + 0x128) + 0x380c) & 2) == 0) ||
     (cVar3 = FUN_0070e2b0(param_2,1), cVar3 != '\0')) {
    FUN_005edd10();
    FUN_006f48e0(param_2);
  }
  else if ((*(uint *)(*(int *)(param_1 + 0x128) + 0x380c) & 2) != 0) {
    FUN_0070e1f0(param_2,param_4);
  }
  if (iStack_68 != 0) {
    uVar5 = iStack_60 - iStack_68 & 0xfffffffc;
    iVar17 = iStack_68;
    if (0xfff < uVar5) {
      iVar17 = *(int *)(iStack_68 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_68 - iVar17) - 4U) {
LAB_0070dab9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar17,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9992 ; VA 0x0070dac0 ; FUN_0070dac0 */

void FUN_0070dac0(float *param_1,undefined4 param_2,int param_3)

{
  float fVar1;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  
  FUN_0070d050(&fStack_28,param_2);
  fVar1 = (float)(param_3 << 6);
  *param_1 = fStack_28 - fVar1;
  param_1[1] = fStack_24 - fVar1;
  param_1[2] = fStack_20 - fVar1;
  param_1[3] = fVar1 + fStack_1c;
  *(ulonglong *)(param_1 + 4) = CONCAT44(fVar1 + fStack_14,fVar1 + fStack_18);
  return;
}



/* FUNCTION 9993 ; VA 0x0070db60 ; FUN_0070db60 */

uint __thiscall
FUN_0070db60(undefined4 *param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  int iStack_4c;
  int iStack_48;
  int iStack_40;
  int iStack_3c;
  int iStack_34;
  int iStack_30;
  int iStack_28;
  int iStack_24;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  
  puVar5 = param_2;
  if (((param_1[1] != 0) && (param_1[3] != 0)) && (param_1[5] != 0)) {
    iStack_c = *(int *)(*(int *)*param_1 + 0x10);
    iStack_10 = *(int *)(*(int *)param_1[2] + 0x10);
    iVar2 = *(int *)(*(int *)param_1[4] + 0x10);
    iStack_14 = iVar2;
    puVar6 = (undefined8 *)FUN_0070dd60(&iStack_4c);
    iStack_28 = 0;
    iStack_24 = 0;
    iVar3 = *(int *)(puVar6 + 1);
    iStack_30 = 0;
    param_2 = (undefined8 *)0x0;
    uVar1 = *puVar5;
    iVar4 = *(int *)(puVar5 + 1);
    iStack_4c = (int)uVar1;
    iStack_40 = (int)*puVar6;
    uVar7 = iStack_4c - iStack_c >> 0x1f;
    uVar7 = (iStack_4c - iStack_c ^ uVar7) - uVar7;
    uVar8 = iStack_4c - iStack_40 >> 0x1f;
    uVar8 = (iStack_4c - iStack_40 ^ uVar8) - uVar8;
    iStack_3c = (int)((ulonglong)*puVar6 >> 0x20);
    if ((uVar7 < 0x80000000) || (iVar10 = 0, uVar11 = 0xffffffff, -1 < (int)uVar8)) {
      iStack_28 = iStack_c;
      if ((int)uVar7 <= (int)uVar8) {
        iStack_28 = iStack_40;
      }
      iStack_30 = iStack_3c;
      iStack_24 = iStack_10;
      iVar10 = iVar2;
      uVar11 = uVar7;
      param_2 = (undefined8 *)iVar3;
      if ((int)uVar7 <= (int)uVar8) {
        uVar11 = uVar8;
      }
    }
    iStack_48 = (int)((ulonglong)uVar1 >> 0x20);
    uVar8 = iStack_48 - iStack_10 >> 0x1f;
    uVar8 = (iStack_48 - iStack_10 ^ uVar8) - uVar8;
    uVar7 = iStack_48 - iStack_3c >> 0x1f;
    uVar7 = (iStack_48 - iStack_3c ^ uVar7) - uVar7;
    if (((int)uVar11 < (int)uVar8) || (iStack_34 = iStack_28, (int)uVar11 < (int)uVar7)) {
      uVar11 = uVar8;
      iStack_30 = iStack_10;
      if ((int)uVar8 <= (int)uVar7) {
        uVar11 = uVar7;
        iStack_30 = iStack_3c;
      }
      iStack_28 = iStack_c;
      iStack_34 = iStack_40;
      iVar10 = iStack_14;
      param_2 = (undefined8 *)iVar3;
      iStack_24 = iStack_30;
    }
    uVar7 = iVar4 - iStack_14;
    uVar9 = (int)uVar7 >> 0x1f;
    uVar8 = iVar4 - iVar3;
    uVar9 = (uVar7 ^ uVar9) - uVar9;
    uVar7 = (int)uVar8 >> 0x1f;
    uVar7 = (uVar8 ^ uVar7) - uVar7;
    if (((int)uVar11 < (int)uVar9) || ((int)uVar11 < (int)uVar7)) {
      param_2 = (undefined8 *)iVar3;
      if ((int)uVar7 < (int)uVar9) {
        param_2 = (undefined8 *)iStack_14;
      }
      iStack_28 = iStack_c;
      iStack_34 = iStack_40;
      iStack_24 = iStack_10;
      iStack_30 = iStack_3c;
      iVar10 = (int)param_2;
      uVar11 = uVar9;
      if ((int)uVar9 <= (int)uVar7) {
        uVar11 = uVar7;
      }
    }
    *param_3 = CONCAT44(iStack_24,iStack_28);
    *(int *)(param_3 + 1) = iVar10;
    *param_4 = CONCAT44(iStack_30,iStack_34);
    *(undefined8 **)(param_4 + 1) = param_2;
    return uVar11;
  }
  *param_3 = *param_2;
  *(undefined4 *)(param_3 + 1) = *(undefined4 *)(param_2 + 1);
  *param_4 = *param_2;
  *(undefined4 *)(param_4 + 1) = *(undefined4 *)(param_2 + 1);
  return 0;
}



/* FUNCTION 9994 ; VA 0x0070dd40 ; FUN_0070dd40 */

uint __fastcall FUN_0070dd40(int param_1)

{
  uint uVar1;
  
  uVar1 = DAT_01eaf914;
  if (DAT_01eaf914 == 0) {
    uVar1 = (uint)*(ushort *)(param_1 + 0x1d4);
  }
  return uVar1;
}



/* FUNCTION 9995 ; VA 0x0070dd60 ; FUN_0070dd60 */

void __thiscall FUN_0070dd60(int *param_1,undefined8 *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar1 = param_1[4];
  FUN_0056f560();
  iVar2 = param_1[2];
  FUN_0056f560();
  iVar3 = *param_1;
  FUN_0056f560();
  uVar4 = *(undefined4 *)(iVar1 + 0x10);
  *param_2 = CONCAT44(*(undefined4 *)(iVar2 + 0x10),*(undefined4 *)(iVar3 + 0x10));
  *(undefined4 *)(param_2 + 1) = uVar4;
  return;
}



/* FUNCTION 9996 ; VA 0x0070ddc0 ; FUN_0070ddc0 */

undefined4 __fastcall FUN_0070ddc0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x150);
}



/* FUNCTION 9997 ; VA 0x0070ddd0 ; FUN_0070ddd0 */

float10 FUN_0070ddd0(float *param_1,float *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00c9ecc0(param_2);
  switch(uVar1) {
  case 0:
    return (float10)param_1[3] - (float10)*param_2;
  case 1:
    return (float10)param_1[4] - (float10)param_2[1];
  case 2:
    return (float10)param_1[5] - (float10)param_2[2];
  case 3:
    return (float10)*param_2 - (float10)*param_1;
  case 4:
    return (float10)param_2[1] - (float10)param_1[1];
  case 5:
    return (float10)param_2[2] - (float10)param_1[2];
  default:
    return (float10)1;
  }
}



/* FUNCTION 9998 ; VA 0x0070de60 ; FUN_0070de60 */

void FUN_0070de60(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar2 = param_1;
  iVar1 = *(int *)(param_1 + 0xc);
  iVar3 = FUN_00aff8c0();
  param_1 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    param_1 = iVar2;
  }
  if (param_1 != 0) {
    piVar4 = (int *)FUN_0070aa60(&param_1);
    if ((*piVar4 == 0) && (*(int *)(iVar2 + 0x34) != 0)) {
      FUN_0070de60(*(int *)(iVar2 + 0x34),1);
    }
    piVar4 = (int *)FUN_0070aa60(&param_1);
    *piVar4 = *piVar4 + param_2;
    return;
  }
  if (*(int *)(iVar2 + 0x34) != 0) {
    FUN_0070de60(*(int *)(iVar2 + 0x34),param_2);
  }
  return;
}



/* FUNCTION 9999 ; VA 0x0070df00 ; FUN_0070df00 */

void __thiscall FUN_0070df00(int param_1,ulonglong *param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  uint uVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  bool bVar7;
  int iStack_50;
  int iStack_4c;
  undefined8 uStack_48;
  int iStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [12];
  uint uStack_2c;
  undefined4 *puStack_28;
  undefined2 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abae8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar2 = FUN_01675290(DAT_01eaf994);
  uStack_8 = 0;
  uStack_48 = *param_2;
  iStack_40 = *(int *)(param_2 + 1);
  uStack_3c = CONCAT31(uStack_3c._1_3_,(byte)param_3);
  uStack_20 = uVar2;
  uStack_14 = FUN_00ca2680(&uStack_48);
  iVar5 = param_1 + 0x149 + (uint)*(byte *)(param_1 + 0x148);
  FUN_006e16e0(&iStack_1c,uStack_14,&uStack_48,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (iStack_1c == 0) {
    puStack_28 = (undefined4 *)0x0;
    uStack_2c = -(uint)(param_1 != -0x14b) & param_1 + 0x14cU;
    uStack_8._0_1_ = 1;
    uStack_24 = 0;
    puStack_28 = (undefined4 *)FUN_01674e20(0x18);
    uStack_24 = 0x101;
    *puStack_28 = 0;
    puStack_28[1] = 0;
    puStack_28[2] = 0;
    puStack_28[3] = 0;
    puStack_28[4] = 0;
    puStack_28[5] = 0;
    puStack_28[2] = (int)uStack_48;
    puStack_28[3] = uStack_48._4_4_;
    puStack_28[4] = iStack_40;
    puStack_28[5] = uStack_3c;
    FUN_005d99d0(*(int *)(param_1 + 0x150) + 1);
    FUN_005c5550(&iStack_1c,&uStack_2c,uStack_14);
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (puStack_28 != (undefined4 *)0x0) {
      FUN_01674ea0(puStack_28,0x18);
    }
    FUN_0070b080(param_2);
    if (DAT_01d5bf20 == '\0') goto LAB_0070e1bf;
    cVar4 = (byte)param_3;
  }
  else {
    if (((DAT_01d5bf20 == '\0') || ((byte)param_3 == 0)) || (*(char *)(iStack_1c + 0x14) != '\0')) {
      cVar4 = '\0';
    }
    else {
      cVar4 = '\x01';
    }
    *(byte *)(iStack_1c + 0x14) = *(byte *)(iStack_1c + 0x14) | (byte)param_3;
  }
  if (cVar4 != '\0') {
    iStack_1c = 0;
    FUN_0060e810(0,&iStack_1c,(int)&param_3 + 3);
    uStack_48 = uStack_48 & 0xffffffff;
    iStack_40 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (DAT_01d69070 == '\0') {
      pcVar1 = *(code **)(**(int **)(param_1 + 0x140) + 0x44);
      uVar2 = FUN_0070d050(auStack_38,param_2);
      (*pcVar1)(uVar2,&iStack_50);
    }
    else {
      uVar2 = FUN_0070d050(auStack_38,param_2);
      FUN_00ce48e0(uVar2,&iStack_50);
    }
    uVar6 = 0;
    uVar3 = iStack_4c - iStack_50 >> 2;
    if (uVar3 != 0) {
      do {
        if (*(int *)(iStack_50 + uVar6 * 4) != iStack_40) break;
        uVar6 = uVar6 + 1;
      } while (uVar6 < uVar3);
    }
LAB_0070e110:
    bVar7 = uVar6 == uVar3;
    while (uVar2 = uStack_20, !bVar7) {
      param_3 = FUN_00b06640(*(undefined4 *)(iStack_50 + uVar6 * 4));
      if (param_3 != 0) {
        FUN_0070de60(param_3,1);
        FUN_0070cc60(&param_3);
        FUN_0070cc60(&param_3);
      }
      uVar3 = iStack_4c - iStack_50 >> 2;
      while( true ) {
        uVar6 = uVar6 + 1;
        bVar7 = uVar6 == uVar3;
        if (uVar3 <= uVar6) break;
        if (*(int *)(iStack_50 + uVar6 * 4) != iStack_40) goto LAB_0070e110;
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (iStack_50 != 0) {
      uVar3 = ((int)uStack_48 - iStack_50 >> 2) * 4;
      iVar5 = iStack_50;
      if (0xfff < uVar3) {
        iVar5 = *(int *)(iStack_50 + -4);
        uVar3 = uVar3 + 0x23;
        if (0x1f < (iStack_50 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar3);
      iStack_50 = 0;
      iStack_4c = 0;
      uStack_48 = uStack_48 & 0xffffffff00000000;
    }
  }
LAB_0070e1bf:
  uStack_8 = 3;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}


