/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 7500 ; VA 0x00655110 ; FUN_00655110 */

void __thiscall FUN_00655110(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_26b0ae1fe61d12916a6d1ea3a6dcb870>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 7501 ; VA 0x00655150 ; FUN_00655150 */

void __thiscall FUN_00655150(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_2d70a72d3d46abb802d07f235c5eb683>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 7502 ; VA 0x00655190 ; FUN_00655190 */

void __thiscall FUN_00655190(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_9c20dbf068eda0ddbac7172c77152787>,void,enum_RBX::Player::CanManageStatus>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 7503 ; VA 0x006551d0 ; FUN_006551d0 */

bool FUN_006551d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00655930(10,0x7fffffff);
  return iVar1 != 0x7fffffff;
}



/* FUNCTION 7504 ; VA 0x006551f0 ; FUN_006551f0 */

void __thiscall FUN_006551f0(undefined4 param_1,char param_2)

{
  FUN_006511a0();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x24);
  }
  return;
}



/* FUNCTION 7505 ; VA 0x00655220 ; FUN_00655220 */

void __thiscall FUN_00655220(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 8);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0xc);
  }
  return;
}



/* FUNCTION 7506 ; VA 0x00655260 ; FUN_00655260 */

void __fastcall FUN_00655260(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_006518c0();
    FUN_01674ea0(iVar1,0xb8);
  }
  return;
}



/* FUNCTION 7507 ; VA 0x00655280 ; FUN_00655280 */

void __fastcall FUN_00655280(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0151f7f0();
    FUN_01674ea0(iVar1,0x38);
  }
  return;
}



/* FUNCTION 7508 ; VA 0x006552a0 ; FUN_006552a0 */

void FUN_006552a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  FUN_01674ea0(param_1,0x28);
  return;
}



/* FUNCTION 7509 ; VA 0x00655300 ; FUN_00655300 */

void FUN_00655300(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if (param_1 != param_2) {
    do {
      if (param_1 == (undefined4 *)0x0) {
        return;
      }
      puVar1 = (undefined4 *)param_1[3];
      param_1[3] = 0;
      (**(code **)*param_1)(1);
      param_1 = puVar1;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 7510 ; VA 0x00655330 ; FUN_00655330 */

void __fastcall FUN_00655330(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)*param_1;
  while (puVar2 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar2[3];
    puVar2[3] = 0;
    (**(code **)*puVar2)(1);
    puVar2 = puVar1;
  }
  *param_1 = 0;
  return;
}



/* FUNCTION 7511 ; VA 0x00655360 ; FUN_00655360 */

void __fastcall FUN_00655360(undefined4 *param_1)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  char *pcVar7;
  int iVar8;
  int iVar9;
  undefined4 *puStack_c;
  
  iVar2 = param_1[10];
  cVar4 = FUN_00654140();
  if (cVar4 == '\0') {
    if (param_1[0x13] != 0x7c) {
      return;
    }
    uVar5 = FUN_00657270(8);
    FUN_00656740(uVar5);
  }
  puStack_c = (undefined4 *)FUN_01674e20(0x14);
  if (puStack_c == (undefined4 *)0x0) {
    puStack_c = (undefined4 *)0x0;
  }
  else {
    puStack_c[1] = 0x11;
    puStack_c[2] = 0;
    puStack_c[3] = 0;
    puStack_c[4] = 0;
    *puStack_c = std::_Node_endif::vftable;
  }
  puStack_c[4] = param_1[10];
  iVar9 = param_1[10];
  if (*(int *)(iVar9 + 0xc) != 0) {
    puStack_c[3] = *(int *)(iVar9 + 0xc);
    *(undefined4 **)(*(int *)(param_1[10] + 0xc) + 0x10) = puStack_c;
    iVar9 = param_1[10];
  }
  *(undefined4 **)(iVar9 + 0xc) = puStack_c;
  param_1[10] = puStack_c;
  puVar6 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 0x10;
    puVar6[2] = 0;
    puVar6[3] = 0;
    puVar6[4] = 0;
    *puVar6 = std::_Node_if::vftable;
    puVar6[5] = puStack_c;
    puVar6[6] = 0;
  }
  iVar9 = *(int *)(iVar2 + 0xc);
  *(undefined4 **)(*(int *)(iVar9 + 0x10) + 0xc) = puVar6;
  puVar6[4] = *(undefined4 *)(iVar9 + 0x10);
  *(undefined4 **)(iVar9 + 0x10) = puVar6;
  puVar6[3] = iVar9;
  iVar9 = param_1[0x13];
  while (iVar9 == 0x7c) {
    pcVar7 = (char *)*param_1;
    if (pcVar7 != (char *)param_1[2]) {
      if (((*pcVar7 == '\\') && (pcVar1 = pcVar7 + 1, pcVar1 != (char *)param_1[2])) &&
         ((((param_1[0x14] & 8) == 0 && ((*pcVar1 == '(' || (*pcVar1 == ')')))) ||
          (((param_1[0x14] & 0x10) == 0 && ((*pcVar1 == '{' || (*pcVar1 == '}')))))))) {
        pcVar7 = pcVar1;
      }
      *param_1 = pcVar7 + 1;
    }
    FUN_006576b0();
    cVar4 = FUN_00654140();
    if (cVar4 == '\0') {
      iVar8 = FUN_00657270(8);
      iVar9 = *(int *)(iVar8 + 4);
      if (iVar9 == 8) {
        iVar9 = 9;
      }
      else if (iVar9 == 10) {
        iVar9 = 0xc;
      }
      else {
        iVar9 = (uint)(iVar9 != 0xb) * 2 + 0xc;
      }
      puVar6 = (undefined4 *)FUN_01674e20(0x18);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        puVar6[1] = iVar9;
        puVar6[2] = 0;
        puVar6[3] = 0;
        puVar6[4] = 0;
        *puVar6 = std::_Node_end_group::vftable;
        puVar6[5] = iVar8;
      }
      puVar6[4] = param_1[10];
      iVar9 = param_1[10];
      if (*(int *)(iVar9 + 0xc) != 0) {
        puVar6[3] = *(int *)(iVar9 + 0xc);
        *(undefined4 **)(*(int *)(param_1[10] + 0xc) + 0x10) = puVar6;
        iVar9 = param_1[10];
      }
      *(undefined4 **)(iVar9 + 0xc) = puVar6;
      param_1[10] = puVar6;
    }
    iVar9 = puStack_c[3];
    iVar8 = *(int *)(iVar2 + 0xc);
    puStack_c[3] = 0;
    iVar3 = param_1[10];
    param_1[10] = puStack_c;
    puStack_c[3] = 0;
    *(undefined4 **)(iVar3 + 0xc) = puStack_c;
    for (iVar3 = *(int *)(iVar8 + 0x18); iVar3 != 0; iVar3 = *(int *)(iVar3 + 0x18)) {
      iVar8 = iVar3;
    }
    puVar6 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6[1] = 0x10;
      puVar6[2] = 0;
      puVar6[3] = 0;
      puVar6[4] = 0;
      *puVar6 = std::_Node_if::vftable;
      puVar6[5] = puStack_c;
      puVar6[6] = 0;
    }
    *(undefined4 **)(iVar8 + 0x18) = puVar6;
    puVar6[3] = iVar9;
    *(undefined4 *)(iVar9 + 0x10) = *(undefined4 *)(iVar8 + 0x18);
    iVar9 = param_1[0x13];
  }
  return;
}



/* FUNCTION 7512 ; VA 0x006555f0 ; FUN_006555f0 */

void __thiscall FUN_006555f0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00654510(param_2);
  FUN_00655360();
  FUN_00656740(uVar1);
  *(undefined4 *)(param_1 + 0x28) = uVar1;
  return;
}



/* FUNCTION 7513 ; VA 0x00655620 ; FUN_00655620 */

void __thiscall FUN_00655620(int param_1,undefined4 *param_2)

{
  FUN_0151f9c0("canManage",*param_2);
  FUN_01520d20(param_1 + 0xc,DAT_01d5a720,0);
  return;
}



/* FUNCTION 7514 ; VA 0x00655660 ; FUN_00655660 */

void FUN_00655660(undefined4 *param_1,undefined4 param_2)

{
  FUN_006523b0(*param_1,param_2);
  return;
}



/* FUNCTION 7515 ; VA 0x00655680 ; FUN_00655680 */

void __thiscall FUN_00655680(int param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796e78;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  if ((iVar1 != 0) || (*(int *)(param_3 + 0xc) != 200)) {
    ExceptionList = &pvStack_10;
    if (DAT_01ead7a0 != '\0') {
      if (*(int *)(param_3 + 0x84) == 0) {
        puVar3 = (undefined4 *)&DAT_018d4608;
      }
      else {
        puVar3 = (undefined4 *)(param_3 + 0x74);
        if (0xf < *(uint *)(param_3 + 0x88)) {
          puVar3 = (undefined4 *)*puVar3;
        }
      }
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01ead7a0,
                   "Error incrementing flood check counters - Error code: %d, Error msg: %s",iVar1,
                   puVar3);
    }
    if (DAT_01d5aca0 != '\0') {
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("FloodChecker_IncrementFailure",0x1d);
      uStack_8 = 0;
      FUN_008783f0(auStack_28,1,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    if (DAT_01d5aca8 != '\0') {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 1;
      FUN_0151f850(&DAT_018c7ed0,"inc-error");
      FUN_0151f9c0(&DAT_018d4684,iVar1);
      FUN_0151f9c0(&DAT_018d4688,*(undefined4 *)(param_3 + 0xc));
      if (*(int *)(param_3 + 0x84) != 0) {
        FUN_0151f950(&DAT_018d4690,param_3 + 0x74);
      }
      uVar2 = DAT_01ead7fc;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0("dynip-blacklist",0xf);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_01520d20(auStack_40,uVar2,0);
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    if (DAT_01d5acd0 != '\0') {
      FUN_00659e70(param_1 + 4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7516 ; VA 0x00655830 ; FUN_00655830 */

int FUN_00655830(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1a70;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&piStack_18);
  uStack_8 = 0;
  if ((piStack_18 != (int *)0x0) && (iVar3 == 2)) {
    (**(code **)(*piStack_18 + 0x290))(&DAT_018d4b68,0x1b,DAT_01d5aa38 != '\0',"Exploit Detected",0)
    ;
    pcVar6 = "ExploitsDetection-Respond-Disconnect";
    uStack_20 = 0;
    if (DAT_01d5aa38 == '\0') {
      pcVar6 = "ExploitsDetection-Respond-ReportOnly";
    }
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    pcVar5 = pcVar6;
    do {
      cVar2 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(pcVar6,(int)pcVar5 - (int)(pcVar6 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_008783f0(auStack_30,1,0);
    iVar4 = FUN_005507b0();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7517 ; VA 0x00655930 ; FUN_00655930 */

int __thiscall FUN_00655930(undefined4 *param_1,int param_2,int param_3)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  
  param_1[0x11] = 0;
  if (param_3 == 0) {
    return 0;
  }
  do {
    cVar2 = *(char *)(param_1 + 0x12);
    if (param_2 == 8) {
      if (7 < (byte)(cVar2 - 0x30U)) {
        return param_3;
      }
LAB_0065598d:
      iVar4 = cVar2 + -0x30;
    }
    else {
      if (('/' < cVar2) && (cVar2 < ':')) goto LAB_0065598d;
      if (param_2 != 0x10) {
        return param_3;
      }
      if ((byte)(cVar2 + 0x9fU) < 6) {
        iVar4 = cVar2 + -0x57;
      }
      else {
        if (5 < (byte)(cVar2 + 0xbfU)) {
          return param_3;
        }
        iVar4 = cVar2 + -0x37;
      }
    }
    if (iVar4 == -1) {
      return param_3;
    }
    param_3 = param_3 + -1;
    param_1[0x11] = param_1[0x11] * param_2 + iVar4;
    pcVar3 = (char *)*param_1;
    if (pcVar3 != (char *)param_1[2]) {
      if (((*pcVar3 == '\\') && (pcVar1 = pcVar3 + 1, pcVar1 != (char *)param_1[2])) &&
         ((((param_1[0x14] & 8) == 0 && ((*pcVar1 == '(' || (*pcVar1 == ')')))) ||
          (((param_1[0x14] & 0x10) == 0 && ((*pcVar1 == '{' || (*pcVar1 == '}')))))))) {
        pcVar3 = pcVar1;
      }
      *param_1 = pcVar3 + 1;
    }
    FUN_006576b0();
    if (param_3 == 0) {
      return 0;
    }
  } while( true );
}



/* FUNCTION 7518 ; VA 0x00655a10 ; FUN_00655a10 */

void __thiscall FUN_00655a10(int *param_1,int param_2)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  short sVar6;
  char *pcVar7;
  int iVar8;
  bool bVar9;
  
  iVar5 = param_2;
  if (param_2 == 0x3a) {
    param_2 = 1;
  }
  else if (param_2 == 0x3d) {
    param_2 = 0;
  }
  else {
    bVar9 = param_2 == 0x2e;
    param_2 = 0xe;
    if (bVar9) {
      param_2 = 0;
    }
  }
  iVar3 = *param_1;
  iVar8 = 0;
  iVar2 = param_1[0x13];
  while ((((iVar2 != 0x3a && (iVar2 != 0x3d)) && (iVar2 != 0x2e)) && (iVar2 != -1))) {
    pcVar7 = (char *)*param_1;
    if (pcVar7 != (char *)param_1[2]) {
      if (((*pcVar7 == '\\') && (pcVar1 = pcVar7 + 1, pcVar1 != (char *)param_1[2])) &&
         ((((param_1[0x14] & 8U) == 0 && ((*pcVar1 == '(' || (*pcVar1 == ')')))) ||
          (((param_1[0x14] & 0x10U) == 0 && ((*pcVar1 == '{' || (*pcVar1 == '}')))))))) {
        pcVar7 = pcVar1;
      }
      *param_1 = (int)(pcVar7 + 1);
    }
    FUN_006576b0();
    iVar8 = iVar8 + 1;
    iVar2 = param_1[0x13];
  }
  if (iVar2 == iVar5) {
    if (iVar5 != 0x3a) {
      if (iVar5 == 0x3d) {
        if (iVar3 == *param_1) goto LAB_00655b69;
        FUN_00653840(iVar3,*param_1,iVar8);
      }
      else if (iVar5 == 0x2e) {
        if (iVar3 == *param_1) goto LAB_00655b69;
        FUN_006549e0(iVar3,*param_1,iVar8,param_1[10] + 0x14);
      }
LAB_00655b39:
      FUN_006572e0();
      if (param_1[0x13] == 0x5d) {
        FUN_006572e0();
        return;
      }
      goto LAB_00655b56;
    }
    sVar6 = FUN_0064f780(iVar3,*param_1,(uint)param_1[0x10] >> 8 & 0xffffff01);
    if (sVar6 != 0) {
      FUN_00653b30(sVar6,0);
      goto LAB_00655b39;
    }
  }
  else {
LAB_00655b56:
    FUN_006567e0(param_2);
  }
  FUN_006567e0(1);
LAB_00655b69:
  FUN_006567e0(0);
  pcVar4 = (code *)swi(3);
  (*pcVar4)();
  return;
}



/* FUNCTION 7519 ; VA 0x00655b80 ; FUN_00655b80 */

undefined __thiscall FUN_00655b80(int param_1,char param_2)

{
  if (param_2 == 'f') {
    *(undefined4 *)(param_1 + 0x44) = 0xc;
    return 1;
  }
  if (param_2 == 'n') {
    *(undefined4 *)(param_1 + 0x44) = 10;
    return 1;
  }
  if (param_2 == 'r') {
    *(undefined4 *)(param_1 + 0x44) = 0xd;
    return 1;
  }
  if (param_2 == 't') {
    *(undefined4 *)(param_1 + 0x44) = 9;
    return 1;
  }
  if (param_2 == 'v') {
    *(undefined4 *)(param_1 + 0x44) = 0xb;
    return 1;
  }
  return 0;
}



/* FUNCTION 7520 ; VA 0x00655bf0 ; FUN_00655bf0 */

undefined4 __thiscall FUN_00655bf0(int param_1,char param_2)

{
  if (param_2 == 'a') {
    *(undefined4 *)(param_1 + 0x44) = 7;
    return 1;
  }
  if (param_2 == 'b') {
    *(undefined4 *)(param_1 + 0x44) = 8;
    return 1;
  }
  return 0;
}



/* FUNCTION 7521 ; VA 0x00655c20 ; FUN_00655c20 */

undefined __thiscall FUN_00655c20(int *param_1,uint param_2)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined uVar7;
  uint *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  int iVar12;
  int aiStack_74 [4];
  int iStack_64;
  uint uStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined auStack_50 [12];
  int iStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_13;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1aa0;
  pvStack_10 = ExceptionList;
  iStack_54 = *param_1;
  piVar10 = param_1 + 1;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  piStack_18 = piVar10;
  FUN_00650440(piVar10);
  iStack_44 = param_1[4];
  puVar8 = (uint *)(param_1 + 5);
  uStack_8 = 0;
  FUN_006504d0(puVar8);
  uStack_8 = 1;
  for (uVar11 = param_2; param_2 = uVar11, uVar11 != 0; uVar11 = *(uint *)(uVar11 + 0x18)) {
    *piStack_1c = iStack_54;
    FUN_006521b0(auStack_50);
    if (puVar8 != &uStack_40) {
      uVar6 = *puVar8;
      uStack_20 = uStack_3c;
      uStack_24 = uStack_3c - uStack_40;
      uVar9 = (int)uStack_24 >> 3;
      uVar5 = (int)(param_1[7] - uVar6) >> 3;
      uVar2 = (int)(param_1[6] - uVar6) >> 3;
      if (uVar5 < uVar9) {
        if (0x1fffffff < uVar9) goto LAB_00656112;
        param_2 = uVar5 >> 1;
        uVar2 = uVar9;
        if ((uVar5 <= 0x1fffffff - param_2) && (uVar2 = param_2 + uVar5, param_2 + uVar5 < uVar9)) {
          uVar2 = uVar9;
        }
        if (uVar6 != 0) {
          uVar5 = uVar5 * 8;
          uVar9 = uVar6;
          if (0xfff < uVar5) {
            uVar9 = *(uint *)(uVar6 - 4);
            uVar5 = uVar5 + 0x23;
            param_2 = uVar9;
            if (0x1f < (uVar6 - uVar9) - 4) goto LAB_0065610d;
          }
          FUN_01674ea0(uVar9,uVar5);
        }
        FUN_00616bd0(uVar2);
        uVar6 = *puVar8;
        FUN_0055b6b0(&uStack_11,&param_2,&param_2);
        FUN_0170cc70(uVar6,uStack_40,uStack_24);
        param_1[6] = uStack_24 + uVar6;
        piVar10 = piStack_18;
      }
      else if (uVar2 < uVar9) {
        iVar3 = uStack_40 + uVar2 * 8;
        FUN_0170cc70(uVar6,uStack_40,iVar3 - uStack_40);
        iVar4 = param_1[6];
        FUN_0055b6b0(&uStack_12,&uStack_34,&uStack_34);
        uStack_20 = uStack_20 - iVar3;
        FUN_0170cc70(iVar4,iVar3,uStack_20);
        param_1[6] = uStack_20 + iVar4;
        piVar10 = piStack_18;
        uVar11 = param_2;
      }
      else {
        FUN_0170cc70(uVar6,uStack_40,uStack_24);
        param_1[6] = uVar6 + uVar9 * 8;
        piVar10 = piStack_18;
      }
    }
    cVar1 = FUN_00656c90(*(undefined4 *)(uVar11 + 0xc));
    if (cVar1 != '\0') {
      if (*(char *)(piStack_1c + 0x1b) == '\0') {
        uVar7 = 1;
        goto LAB_00655dde;
      }
      aiStack_74[0] = *piStack_1c;
      FUN_00650440(piVar10);
      iStack_64 = piVar10[3];
      uStack_8._0_1_ = 2;
      FUN_006504d0(puVar8);
      iStack_28 = *(int *)(uVar11 + 0x18);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uVar11 = *piStack_1c - iStack_54;
      uStack_20 = uVar11;
      if (iStack_28 == 0) goto LAB_006560f3;
      piVar10 = piStack_1c + 1;
      goto LAB_00655e50;
    }
  }
  uVar7 = 0;
  goto LAB_00655dde;
  while( true ) {
    cVar1 = FUN_00656c90(*(undefined4 *)(iStack_28 + 0xc));
    if (cVar1 != '\0') {
      uStack_34 = *piStack_1c - iStack_54;
      if ((int)uVar11 < (int)uStack_34) {
        aiStack_74[0] = *piStack_1c;
        FUN_006521b0(piVar10);
        uVar11 = uStack_60;
        if (&uStack_60 != puVar8) {
          iStack_2c = param_1[6];
          uStack_24 = *puVar8;
          uStack_30 = iStack_2c - uStack_24;
          uVar5 = (int)uStack_30 >> 3;
          uVar2 = (int)(iStack_58 - uStack_60) >> 3;
          uVar6 = (int)(iStack_5c - uStack_60) >> 3;
          if (uVar2 < uVar5) {
            if (0x1fffffff < uVar5) goto LAB_00656112;
            uVar11 = uVar5;
            if ((uVar2 <= 0x1fffffff - (uVar2 >> 1)) &&
               (uVar11 = uVar2 + (uVar2 >> 1), uVar11 < uVar5)) {
              uVar11 = uVar5;
            }
            if (uStack_60 != 0) {
              FUN_0057d330(uStack_60,uVar2);
            }
            FUN_00616bd0(uVar11);
            FUN_0055b6b0(&uStack_11,&iStack_2c,&iStack_2c);
            uVar6 = uStack_30;
            uVar11 = uStack_60;
            FUN_0170cc70(uStack_60,uStack_24,uStack_30);
            iStack_5c = uVar11 + uVar6;
            piVar10 = piStack_18;
          }
          else if (uVar6 < uVar5) {
            iVar4 = uVar6 * 8;
            iVar3 = uStack_24 + iVar4;
            FUN_0170cc70(uStack_60,uStack_24,iVar4);
            FUN_0055b6b0(&uStack_13,&uStack_30,&uStack_30);
            iVar4 = iStack_5c;
            iVar12 = iStack_2c - iVar3;
            FUN_0170cc70(iStack_5c,iVar3,iVar12);
            iStack_5c = iVar4 + iVar12;
            piVar10 = piStack_18;
          }
          else {
            FUN_0170cc70(uStack_60,uStack_24,uStack_30);
            iStack_5c = uVar11 + uVar5 * 8;
            piVar10 = piStack_18;
          }
        }
        uStack_20 = uStack_34;
        uVar11 = uStack_34;
      }
    }
    iStack_28 = *(int *)(iStack_28 + 0x18);
    if (iStack_28 == 0) break;
LAB_00655e50:
    *piStack_1c = iStack_54;
    FUN_006521b0(auStack_50);
    if (puVar8 != &uStack_40) {
      iStack_2c = uStack_3c - uStack_40;
      uStack_30 = *puVar8;
      uStack_24 = uStack_3c;
      uVar2 = iStack_2c >> 3;
      uVar6 = (int)(param_1[7] - uStack_30) >> 3;
      uVar11 = (int)(param_1[6] - uStack_30) >> 3;
      if (uVar6 < uVar2) {
        if (0x1fffffff < uVar2) {
LAB_00656112:
                    /* WARNING: Subroutine does not return */
          FUN_00577c30();
        }
        uVar11 = uVar2;
        if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar11 = uVar6 + (uVar6 >> 1), uVar11 < uVar2))
        {
          uVar11 = uVar2;
        }
        if (uStack_30 != 0) {
          uVar6 = uVar6 * 8;
          uVar2 = uStack_30;
          if (0xfff < uVar6) {
            uVar2 = *(uint *)(uStack_30 - 4);
            uVar6 = uVar6 + 0x23;
            if (0x1f < (uStack_30 - uVar2) - 4) {
LAB_0065610d:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar2,uVar6);
        }
        *puVar8 = 0;
        param_1[6] = 0;
        param_1[7] = 0;
        if (uVar11 != 0) {
          if (0x1fffffff < uVar11) goto LAB_00656112;
          uVar6 = FUN_00578020(uVar11);
          *puVar8 = uVar6;
          param_1[6] = uVar6;
          param_1[7] = *puVar8 + uVar11 * 8;
        }
        uVar11 = *puVar8;
        FUN_0055b6b0((int)&param_2 + 3,&uStack_34,&uStack_34);
        iVar3 = iStack_2c;
        FUN_0170cc70(uVar11,uStack_40,iStack_2c);
        iVar3 = uVar11 + iVar3;
      }
      else if (uVar11 < uVar2) {
        iVar4 = uStack_40 + uVar11 * 8;
        FUN_0170cc70(uStack_30,uStack_40,iVar4 - uStack_40);
        iVar3 = param_1[6];
        FUN_0055b6b0(&uStack_12,&uStack_34,&uStack_34);
        uStack_24 = uStack_24 - iVar4;
        FUN_0170cc70(iVar3,iVar4,uStack_24);
        iVar3 = uStack_24 + iVar3;
      }
      else {
        FUN_0170cc70(uStack_30,uStack_40,iStack_2c);
        iVar3 = uStack_30 + uVar2 * 8;
      }
      param_1[6] = iVar3;
      uVar11 = uStack_20;
      piVar10 = piStack_18;
    }
  }
LAB_006560f3:
  FUN_00651f30(aiStack_74);
  uVar7 = 1;
  FUN_00651510();
LAB_00655dde:
  FUN_00651510();
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 7522 ; VA 0x00656120 ; FUN_00656120 */

char __thiscall FUN_00656120(int *param_1,int param_2,char param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint *puVar9;
  int iStack_74;
  uint uStack_70;
  int iStack_6c;
  uint uStack_64;
  int aiStack_54 [4];
  int iStack_44;
  uint uStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined uStack_15;
  undefined uStack_14;
  undefined uStack_13;
  undefined uStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1ad0;
  pvStack_10 = ExceptionList;
  iVar7 = 0;
  iStack_74 = *param_1;
  puVar9 = (uint *)(param_1 + 1);
  iStack_1c = 0;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  FUN_00650440(puVar9);
  uStack_64 = param_1[4];
  uStack_8 = 0;
  FUN_006504d0(param_1 + 5);
  uStack_8 = 1;
  if (0 < *(int *)(param_2 + 0x14)) {
    iVar4 = *param_1;
    do {
      cVar1 = FUN_00656c90(*(undefined4 *)(param_2 + 0xc));
      if (cVar1 == '\0') {
        FUN_00651f30(&iStack_74);
        cVar1 = '\0';
        goto LAB_0065656a;
      }
      iVar7 = *(int *)(param_2 + 0x14) + -1;
      if (iVar4 != *param_1) {
        iVar7 = iStack_1c;
      }
      iVar7 = iVar7 + 1;
      iVar4 = *param_1;
      iStack_1c = iVar7;
    } while (iVar7 < *(int *)(param_2 + 0x14));
  }
  aiStack_54[0] = *param_1;
  FUN_00650440(puVar9);
  iStack_44 = param_1[4];
  uStack_8._0_1_ = 2;
  FUN_006504d0(param_1 + 5);
  iStack_2c = *param_1;
  cStack_11 = '\0';
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  cVar1 = FUN_00656c90(*(undefined4 *)(*(int *)(param_2 + 0x1c) + 0xc));
  iVar4 = iStack_2c;
  if (cVar1 != '\0') {
    if (param_3 == '\0') {
LAB_00656546:
      cVar1 = '\x01';
      goto LAB_00656562;
    }
    FUN_00651f30(param_1);
    cStack_11 = '\x01';
    iVar4 = iStack_2c;
  }
  do {
    iStack_2c = iVar4;
    if ((*(int *)(param_2 + 0x18) != -1) &&
       (iStack_1c = iVar7 + 1, *(int *)(param_2 + 0x18) <= iVar7)) break;
    *param_1 = iStack_2c;
    if (puVar9 != &uStack_70) {
      iStack_24 = iStack_6c - uStack_70;
      uStack_28 = *puVar9;
      uVar8 = iStack_24 >> 2;
      uVar6 = (int)(puVar9[2] - uStack_28) >> 2;
      uVar2 = (int)(puVar9[1] - uStack_28) >> 2;
      if (uVar6 < uVar8) {
        if (0x3fffffff < uVar8) {
LAB_0065658c:
                    /* WARNING: Subroutine does not return */
          FUN_00577c30();
        }
        uVar3 = uVar6 >> 1;
        uVar2 = uVar8;
        if ((uVar6 <= 0x3fffffff - uVar3) && (uVar2 = uVar3 + uVar6, uVar3 + uVar6 < uVar8)) {
          uVar2 = uVar8;
        }
        if (uStack_28 != 0) {
          uVar6 = uVar6 * 4;
          uVar8 = uStack_28;
          if (0xfff < uVar6) {
            uVar8 = *(uint *)(uStack_28 - 4);
            uVar6 = uVar6 + 0x23;
            iVar7 = uStack_28 - uVar8;
            uStack_28 = uVar8;
            uVar3 = uVar8;
            if (0x1f < iVar7 - 4U) goto LAB_00656587;
          }
          uStack_28 = uVar3;
          FUN_01674ea0(uVar8,uVar6);
          uVar3 = uStack_28;
        }
        uStack_28 = uVar3;
        *puVar9 = 0;
        puVar9[1] = 0;
        puVar9[2] = 0;
        if (uVar2 != 0) {
          if (0x3fffffff < uVar2) goto LAB_0065658c;
          uVar6 = FUN_00577ed0(uVar2);
          *puVar9 = uVar6;
          puVar9[1] = uVar6;
          puVar9[2] = *puVar9 + uVar2 * 4;
        }
        uVar2 = *puVar9;
        FUN_0055b6b0(&uStack_12,&iStack_34,&iStack_34);
        FUN_0170cc70(uVar2,uStack_70,iStack_24);
        uVar2 = iStack_24 + uVar2;
      }
      else if (uVar2 < uVar8) {
        iVar7 = uStack_70 + uVar2 * 4;
        FUN_0170cc70(uStack_28,uStack_70,iVar7 - uStack_70);
        uVar2 = puVar9[1];
        FUN_0055b6b0(&uStack_13,&iStack_34,&iStack_34);
        iVar4 = iStack_6c - iVar7;
        FUN_0170cc70(uVar2,iVar7,iVar4);
        uVar2 = iVar4 + uVar2;
        puVar9 = (uint *)(piStack_20 + 1);
        param_1 = piStack_20;
      }
      else {
        FUN_0170cc70(uStack_28,uStack_70,iStack_24);
        uVar2 = uStack_28 + uVar8 * 4;
      }
      puVar9[1] = uVar2;
      puVar9[3] = uStack_64;
    }
    cVar1 = FUN_00656c90(*(undefined4 *)(param_2 + 0xc));
    if (cVar1 == '\0') break;
    iStack_34 = *param_1;
    cVar1 = FUN_00656c90(*(undefined4 *)(*(int *)(param_2 + 0x1c) + 0xc));
    if (cVar1 != '\0') {
      if (param_3 == '\0') goto LAB_00656546;
      aiStack_54[0] = *param_1;
      FUN_006521b0(puVar9);
      uVar2 = uStack_40;
      if (&uStack_40 != (uint *)(param_1 + 5)) {
        iStack_24 = param_1[6];
        uStack_28 = param_1[5];
        iStack_30 = iStack_24 - uStack_28;
        uVar3 = iStack_30 >> 3;
        uVar8 = (int)(iStack_38 - uStack_40) >> 3;
        uVar6 = (int)(iStack_3c - uStack_40) >> 3;
        if (uVar8 < uVar3) {
          if (0x1fffffff < uVar3) {
LAB_00656591:
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          uVar2 = uVar3;
          if ((uVar8 <= 0x1fffffff - (uVar8 >> 1)) && (uVar2 = uVar8 + (uVar8 >> 1), uVar2 < uVar3))
          {
            uVar2 = uVar3;
          }
          if (uStack_40 != 0) {
            uVar8 = uVar8 * 8;
            uVar6 = uStack_40;
            if (0xfff < uVar8) {
              uVar6 = *(uint *)(uStack_40 - 4);
              uVar8 = uVar8 + 0x23;
              if (0x1f < (uStack_40 - uVar6) - 4) {
LAB_00656587:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar6,uVar8);
          }
          uStack_40 = 0;
          iStack_3c = 0;
          iStack_38 = 0;
          if (uVar2 != 0) {
            if (0x1fffffff < uVar2) goto LAB_00656591;
            uStack_40 = FUN_00578020(uVar2);
            iStack_38 = uStack_40 + uVar2 * 8;
          }
          uVar2 = uStack_40;
          FUN_0055b6b0(&uStack_14,&iStack_24,&iStack_24);
          iVar7 = iStack_30;
          FUN_0170cc70(uVar2,uStack_28,iStack_30);
          iStack_3c = iVar7 + uVar2;
          param_1 = piStack_20;
        }
        else if (uVar6 < uVar3) {
          iVar4 = uVar6 * 8;
          iVar7 = uStack_28 + iVar4;
          FUN_0170cc70(uStack_40,uStack_28,iVar4);
          FUN_0055b6b0(&uStack_15,&iStack_30,&iStack_30);
          iVar4 = iStack_3c;
          iStack_24 = iStack_24 - iVar7;
          FUN_0170cc70(iStack_3c,iVar7,iStack_24);
          iStack_3c = iVar4 + iStack_24;
          param_1 = piStack_20;
        }
        else {
          FUN_0170cc70(uStack_40,uStack_28,iStack_30);
          iStack_3c = uVar2 + uVar3 * 8;
          param_1 = piStack_20;
        }
      }
      cStack_11 = '\x01';
    }
    iVar7 = iStack_1c;
    iVar4 = iStack_34;
  } while (iStack_2c != iStack_34);
  piVar5 = aiStack_54;
  if (cStack_11 == '\0') {
    piVar5 = &iStack_74;
  }
  FUN_00651f30(piVar5);
  cVar1 = cStack_11;
LAB_00656562:
  FUN_00651510();
LAB_0065656a:
  FUN_00651510();
  ExceptionList = pvStack_10;
  return cVar1;
}



/* FUNCTION 7523 ; VA 0x006565a0 ; FUN_006565a0 */

char __thiscall FUN_006565a0(int *param_1,int param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int aiStack_40 [4];
  int iStack_30;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1af0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 0x24) == 1) {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_00656120(param_2,param_3);
    ExceptionList = pvStack_10;
    return cVar3;
  }
  aiStack_40[0] = *param_1;
  param_2._3_1_ = '\0';
  ExceptionList = &pvStack_10;
  FUN_00650440(param_1 + 1);
  iStack_30 = param_1[4];
  uStack_8 = 0;
  FUN_006504d0(param_1 + 5);
  piStack_20 = *(int **)(param_1[0x10] + 4 + *(int *)(iVar2 + 0x20) * 8);
  piVar1 = (int *)(param_1[0x10] + *(int *)(iVar2 + 0x20) * 8);
  iStack_1c = *piVar1;
  iStack_18 = *param_1;
  uStack_8 = 1;
  if ((param_4 == 0) || (*piStack_20 != iStack_18)) {
    cStack_11 = '\x01';
  }
  else {
    cStack_11 = '\0';
  }
  if ((*(int *)(iVar2 + 0x18) < 0) || (param_4 < *(int *)(iVar2 + 0x18))) {
    if (param_4 < *(int *)(iVar2 + 0x14)) {
      if (cStack_11 == '\0') goto LAB_006566f0;
      *piVar1 = param_4 + 1;
      piVar1[1] = (int)&iStack_18;
      uVar4 = *(undefined4 *)(iVar2 + 0xc);
      goto LAB_006566f6;
    }
    if ((char)param_3 != '\0') {
      if (cStack_11 == '\0') {
        if (1 < param_4) goto LAB_00656702;
      }
      else {
        *piVar1 = param_4 + 1;
        piVar1[1] = (int)&iStack_18;
        param_2._3_1_ = FUN_00656c90(*(undefined4 *)(iVar2 + 0xc));
        if (param_2._3_1_ != '\0') goto LAB_0065670d;
      }
      *piVar1 = iStack_1c;
      piVar1[1] = (int)piStack_20;
      FUN_00651f30(aiStack_40);
      goto LAB_006566f0;
    }
    param_2._3_1_ = FUN_00656c90(*(undefined4 *)(*(int *)(iVar2 + 0x1c) + 0xc));
    if (param_2._3_1_ != '\0') goto LAB_0065670d;
    if (cStack_11 != '\0') {
      FUN_00651f30(aiStack_40);
      *piVar1 = param_4 + 1;
      piVar1[1] = (int)&iStack_18;
      uVar4 = *(undefined4 *)(iVar2 + 0xc);
      goto LAB_006566f6;
    }
  }
  else {
LAB_006566f0:
    uVar4 = *(undefined4 *)(*(int *)(iVar2 + 0x1c) + 0xc);
LAB_006566f6:
    param_2._3_1_ = FUN_00656c90(uVar4);
    if (param_2._3_1_ != '\0') goto LAB_0065670d;
  }
LAB_00656702:
  FUN_00651f30(aiStack_40);
LAB_0065670d:
  *piVar1 = iStack_1c;
  piVar1[1] = (int)piStack_20;
  FUN_00651510();
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 7524 ; VA 0x00656740 ; FUN_00656740 */

void __thiscall FUN_00656740(int param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_2 + 4);
  if (iVar2 == 8) {
    iVar2 = 9;
  }
  else if (iVar2 == 10) {
    iVar2 = 0xc;
  }
  else {
    iVar2 = (uint)(iVar2 != 0xb) * 2 + 0xc;
  }
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = iVar2;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    *puVar1 = std::_Node_end_group::vftable;
    puVar1[5] = param_2;
  }
  puVar1[4] = *(undefined4 *)(param_1 + 4);
  iVar2 = *(int *)(param_1 + 4);
  if (*(int *)(iVar2 + 0xc) != 0) {
    puVar1[3] = *(int *)(iVar2 + 0xc);
    *(undefined4 **)(*(int *)(*(int *)(param_1 + 4) + 0xc) + 0x10) = puVar1;
    iVar2 = *(int *)(param_1 + 4);
  }
  *(undefined4 **)(iVar2 + 0xc) = puVar1;
  *(undefined4 **)(param_1 + 4) = puVar1;
  return;
}



/* FUNCTION 7525 ; VA 0x006567e0 ; FUN_006567e0 */

void FUN_006567e0(undefined4 param_1)

{
  code *pcVar1;
  
  FUN_016ddd19(param_1);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 7526 ; VA 0x006567f0 ; FUN_006567f0 */

undefined4 FUN_006567f0(int *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 ***pppuVar5;
  char *pcVar6;
  uint *puVar7;
  char *pcVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined4 **ppuStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint auStack_4c [4];
  int iStack_3c;
  uint uStack_38;
  undefined4 *puStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1b41;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_18 = 0;
  if ((param_1 != (int *)0x0) && (*param_1 == 0)) {
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)FUN_01674e20(0x10);
    puStack_34 = puVar3;
    uStack_8 = 0;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      iVar2 = *(int *)(param_2 + 4);
      if (iVar2 == 0) {
        iStack_3c = iVar2;
        uStack_38 = 0xf;
        auStack_4c[0] = auStack_4c[0] & 0xffffff00;
        puVar7 = auStack_4c;
        uStack_8 = 1;
        uVar4 = 4;
      }
      else {
        pcVar8 = *(char **)(iVar2 + 0x18);
        if (pcVar8 == (char *)0x0) {
          pcVar8 = (char *)(iVar2 + 0x1c);
        }
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = auStack_30[0] & 0xffffff00;
        pcVar6 = pcVar8;
        do {
          cVar1 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(pcVar8,(int)pcVar6 - (int)(pcVar8 + 1));
        puVar7 = auStack_30;
        uVar4 = 8;
      }
      ppuStack_64 = (undefined4 **)*puVar7;
      uStack_60 = puVar7[1];
      uStack_5c = puVar7[2];
      uStack_58 = puVar7[3];
      uStack_54 = *(undefined8 *)(puVar7 + 4);
      puVar7[4] = 0;
      puVar7[5] = 0xf;
      *(undefined *)puVar7 = 0;
      uVar9 = uVar4 | 0x10;
      if ((uVar4 & 8) != 0) {
        uStack_14 = uVar4 & 0xfffffff7 | 0x10;
        uVar9 = uStack_14;
        if (0xf < uStack_1c) {
          uVar9 = uStack_1c + 1;
          uVar4 = auStack_30[0];
          if (0xfff < uVar9) {
            uVar4 = *(uint *)(auStack_30[0] - 4);
            uVar9 = uStack_1c + 0x24;
            if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar4,uVar9);
          uVar9 = uStack_14;
        }
      }
      uStack_8 = 0;
      if ((uVar9 & 4) != 0) {
        uStack_14 = uVar9 & 0xfffffffb;
        uVar9 = uStack_14;
        if (0xf < uStack_38) {
          uVar9 = uStack_38 + 1;
          uVar4 = auStack_4c[0];
          if (0xfff < uVar9) {
            uVar4 = *(uint *)(auStack_4c[0] - 4);
            uVar9 = uStack_38 + 0x24;
            if (0x1f < (auStack_4c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar4,uVar9);
          uVar9 = uStack_14;
        }
      }
      uStack_18 = uVar9 | 1;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      pppuVar5 = &ppuStack_64;
      if (0xf < uStack_54._4_4_) {
        pppuVar5 = (undefined4 ***)ppuStack_64;
      }
      FUN_0054f870(pppuVar5);
      uStack_14 = uVar9 | 3;
      puVar3[1] = 0;
      *puVar3 = std::collate<char>::vftable;
      uVar10 = FUN_016dfe7e();
      *(undefined8 *)(puVar3 + 2) = uVar10;
    }
    *param_1 = (int)puVar3;
    if ((uStack_14 & 2) != 0) {
      uStack_14 = uStack_14 & 0xfffffffd;
      FUN_00550e70();
    }
    if ((uStack_14 & 1) != 0) {
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 7527 ; VA 0x006569f0 ; FUN_006569f0 */

void FUN_006569f0(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  
  iVar2 = FUN_00655930(0x10,param_1);
  if (iVar2 == 0) {
    return;
  }
  FUN_006567e0(2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 7528 ; VA 0x00656a20 ; FUN_00656a20 */

undefined4 * __thiscall
FUN_00656a20(int *param_1,undefined4 *param_2,int param_3,int param_4,uint param_5,char *param_6)

{
  int iVar1;
  code *pcVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  undefined auStack_34 [8];
  undefined auStack_2c [12];
  uint uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  uint *puStack_14;
  int *piStack_10;
  uint *puStack_c;
  int iStack_8;
  
  uVar6 = (param_3 - *param_1 >> 2) * 0x20 + param_4;
  uStack_20 = uVar6;
  if (param_5 != 0) {
    piStack_10 = param_1;
    if (0x7fffffffU - param_1[3] < param_5) {
      FUN_00657a00();
      pcVar2 = (code *)swi(3);
      puVar3 = (undefined4 *)(*pcVar2)();
      return puVar3;
    }
    iStack_8 = 0;
    FUN_005f87c0(param_5 + 0x1f + param_1[3] >> 5,param_1,&iStack_8);
    if (param_1[3] == 0) {
      param_1[3] = param_5;
      uStack_20 = uVar6;
    }
    else {
      FUN_0065a980(&puStack_c);
      param_1[3] = param_1[3] + param_5;
      puVar3 = (undefined4 *)FUN_0065a980(auStack_2c);
      uStack_18 = 0;
      puStack_14 = (uint *)*puVar3;
      uVar7 = puVar3[1];
      iStack_1c = *piStack_10;
      piVar4 = (int *)FUN_00652350(auStack_34,uVar6);
      puVar5 = (uint *)*piVar4;
      iVar1 = piVar4[1];
      while ((puVar5 != puStack_c || (param_1 = piStack_10, iVar1 != iStack_8))) {
        if (iStack_8 == 0) {
          iStack_8 = 0x1f;
          puStack_c = puStack_c + -1;
        }
        else {
          iStack_8 = iStack_8 + -1;
        }
        if (uVar7 == 0) {
          uVar7 = 0x1f;
          puStack_14 = puStack_14 + -1;
        }
        else {
          uVar7 = uVar7 - 1;
        }
        if ((*puStack_c & 1 << ((byte)iStack_8 & 0x1f)) == 0) {
          *puStack_14 = *puStack_14 & ~(1 << (uVar7 & 0x1f));
        }
        else {
          *puStack_14 = *puStack_14 | 1 << (uVar7 & 0x1f);
        }
      }
    }
  }
  if (((int)uStack_20 < 0) && (uStack_20 != 0)) {
    iVar1 = -((~uStack_20 >> 5) * 4 + 4);
  }
  else {
    iVar1 = (uStack_20 >> 5) * 4;
  }
  puVar5 = (uint *)(*param_1 + iVar1);
  uStack_20 = uStack_20 & 0x1f;
  *param_2 = puVar5;
  param_2[1] = uStack_20;
  if (((int)param_5 < 0) && (uStack_20 < -param_5)) {
    iVar1 = -((~(param_5 + uStack_20) >> 5) * 4 + 4);
  }
  else {
    iVar1 = (param_5 + uStack_20 >> 5) * 4;
  }
  puVar8 = (uint *)((int)puVar5 + iVar1);
  param_5 = param_5 + uStack_20;
  while ((puVar5 != puVar8 || (uStack_20 != (param_5 & 0x1f)))) {
    if (*param_6 == '\0') {
      uVar6 = *puVar5 & ~(1 << (uStack_20 & 0x1f));
    }
    else {
      uVar6 = *puVar5 | 1 << (uStack_20 & 0x1f);
    }
    *puVar5 = uVar6;
    if (uStack_20 < 0x1f) {
      uStack_20 = uStack_20 + 1;
    }
    else {
      uStack_20 = 0;
      puVar5 = puVar5 + 1;
    }
  }
  return param_2;
}



/* FUNCTION 7529 ; VA 0x00656be0 ; FUN_00656be0 */

uint __fastcall FUN_00656be0(int *param_1)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(*param_1 + 1);
  if (pcVar2 != (char *)param_1[2]) {
    if (((param_1[0x14] & 8U) == 0) && ((*pcVar2 == '(' || (*pcVar2 == ')')))) {
LAB_00656c0b:
      return CONCAT31((int3)((uint)pcVar2 >> 8),1);
    }
    if ((param_1[0x14] & 0x10U) == 0) {
      cVar1 = *pcVar2;
      pcVar2 = (char *)CONCAT31((int3)((uint)pcVar2 >> 8),cVar1);
      if ((cVar1 == '{') || (cVar1 == '}')) goto LAB_00656c0b;
    }
  }
  return (uint)pcVar2 & 0xffffff00;
}



/* FUNCTION 7530 ; VA 0x00656c20 ; FUN_00656c20 */

uint __fastcall FUN_00656c20(undefined4 *param_1)

{
  byte *pbVar1;
  uint uVar2;
  
  uVar2 = param_1[0x18];
  if (((uVar2 & 0x100) == 0) && (pbVar1 = (byte *)*param_1, pbVar1 == (byte *)param_1[0x13])) {
    if (pbVar1 == (byte *)param_1[0x14]) {
      return CONCAT31((int3)(uVar2 >> 8),(uVar2 & 0xc) == 0);
    }
    if (((uVar2 & 4) == 0) && (uVar2 = (uint)*pbVar1, *(char *)((int)&PTR_018d1830 + uVar2) != '\0')
       ) {
      return 1;
    }
  }
  else {
    pbVar1 = (byte *)*param_1;
    if (pbVar1 != (byte *)param_1[0x14]) {
      return (uint)(*(char *)((int)&PTR_018d1830 + (uint)pbVar1[-1]) !=
                   *(char *)((int)&PTR_018d1830 + (uint)*pbVar1));
    }
    if (((uVar2 & 8) == 0) &&
       (uVar2 = (uint)pbVar1[-1], *(char *)((int)&PTR_018d1830 + uVar2) != '\0')) {
      return 1;
    }
  }
  return uVar2 & 0xffffff00;
}



/* FUNCTION 7531 ; VA 0x00656c90 ; FUN_00656c90 */

undefined * __thiscall FUN_00656c90(int *param_1,int param_2)

{
  uint *puVar1;
  int iVar2;
  code *pcVar3;
  byte bVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  undefined *puVar8;
  int iVar9;
  uint uVar10;
  undefined *puVar11;
  char *pcVar12;
  undefined3 uVar13;
  undefined4 extraout_ECX;
  undefined *puVar14;
  undefined2 uVar15;
  char cVar16;
  int unaff_EBX;
  undefined *unaff_ESI;
  uint uVar17;
  int in_GS_OFFSET;
  undefined auStack_2c [12];
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar15 = (undefined2)unaff_EBX;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1b58;
  pvStack_10 = ExceptionList;
  iVar9 = param_1[0x1f];
  ExceptionList = &pvStack_10;
  if (0 < iVar9) {
    iVar9 = iVar9 + -1;
    ExceptionList = &pvStack_10;
    param_1[0x1f] = iVar9;
    if (iVar9 < 1) {
LAB_006570c3:
      uVar15 = (undefined2)unaff_EBX;
      FUN_016ddd19(0xc);
      goto LAB_006570ca;
    }
  }
  if (0 < param_1[0x1e]) {
    iVar7 = param_1[0x1e] + -1;
    param_1[0x1e] = iVar7;
    if (iVar7 < 1) {
LAB_006570ca:
      uVar10 = FUN_016ddd19(0xb);
      iVar9 = in(0x656d);
      *param_1 = iVar9;
      unaff_ESI[in_GS_OFFSET] = unaff_ESI[in_GS_OFFSET] + 'e';
      iVar9 = in(0x656d);
      param_1[1] = iVar9;
      (&stack0x00000069)[in_GS_OFFSET] = (&stack0x00000069)[in_GS_OFFSET] + 'm';
      pcVar12 = (char *)(in_GS_OFFSET + (int)&stack0xfffffffc * 3 + 0x65);
      cVar6 = (char)((uint)extraout_ECX >> 8);
      *pcVar12 = *pcVar12 + cVar6;
      *(char *)(uVar10 + 0xdd00656d) = *(char *)(uVar10 + 0xdd00656d) + 'm';
      iVar9 = in(0x656d);
      param_1[2] = iVar9;
      cVar16 = (char)((ushort)uVar15 >> 8);
      *(char *)(in_GS_OFFSET + -0x40ff3526) = *(char *)(in_GS_OFFSET + -0x40ff3526) + cVar16;
      iVar9 = in(0x656d);
      param_1[3] = iVar9;
      pcVar12 = (char *)((int)param_1 + in_GS_OFFSET + -0x50ff9a82);
      *pcVar12 = *pcVar12 + cVar6;
      out(*unaff_ESI,0x656d);
      cVar16 = cVar16 * '\x02';
      out(*(undefined4 *)(unaff_ESI + 1),0x656d);
      *(char *)(in_GS_OFFSET + 0x5600656f) = *(char *)(in_GS_OFFSET + 0x5600656f) + (char)uVar15;
      out(*(undefined4 *)(unaff_ESI + 5),0x656d);
      *(char *)(in_GS_OFFSET + -0x11ff3524) = *(char *)(in_GS_OFFSET + -0x11ff3524) + 'm';
      out(*(undefined4 *)(unaff_ESI + 9),0x656d);
      pcVar12 = (char *)(in_GS_OFFSET + 0xb00cada);
      cVar6 = *pcVar12;
      *pcVar12 = *pcVar12 + cVar16;
      if (SCARRY1(cVar6,cVar16)) {
        pcVar12 = (char *)(uVar10 | 199);
        *pcVar12 = *pcVar12 + (char)pcVar12;
        *pcVar12 = *pcVar12 + (char)pcVar12;
        FUN_0054ef60(extraout_ECX);
        ExceptionList = (void *)CONCAT13(puStack_c._0_1_,pvStack_10._1_3_);
        return unaff_ESI + 0xd;
      }
      DAT_ba006570 = DAT_ba006570 + (char)uVar15;
      iVar9 = in(0x656d);
      param_1[4] = iVar9;
      pcVar12 = (char *)(in_GS_OFFSET + uVar10 + 0x65 + (int)(unaff_ESI + 0xd) * 2);
      *pcVar12 = *pcVar12 + (char)uVar10;
      pcVar3 = (code *)swi(3);
      puVar11 = (undefined *)(*pcVar3)();
      return puVar11;
    }
  }
  uVar10 = (uint)param_1 & 0xffffff00;
  uStack_14 = uVar10;
  if (param_2 != 0) {
LAB_00656cea:
    iVar9 = *(int *)(param_2 + 4);
    unaff_ESI = (undefined *)0x1;
    uVar13 = (undefined3)(uVar10 >> 8);
    switch(iVar9 + -1) {
    case 0:
    case 7:
    case 8:
    case 0x10:
    case 0x13:
      break;
    case 1:
      uStack_14 = param_1[0x18];
      if (((uStack_14 & 0x100) == 0) && (*param_1 == param_1[0x13])) {
        uStack_14 = uStack_14 & 0xffffff01;
        uVar10 = uStack_14;
      }
      else {
        uStack_14 = CONCAT31((int3)(uStack_14 >> 8),*(char *)(*param_1 + -1) != '\n');
        uVar10 = uStack_14;
      }
      break;
    case 2:
      if ((char *)*param_1 == (char *)param_1[0x14]) {
        uStack_14 = CONCAT31((uint3)((uint)param_1[0x18] >> 9),(char)((uint)param_1[0x18] >> 1)) &
                    0xffffff01;
        uVar10 = uStack_14;
      }
      else {
        uStack_14 = CONCAT31(uVar13,*(char *)*param_1 != '\n');
        uVar10 = uStack_14;
      }
      break;
    case 3:
      bVar4 = FUN_00656c20();
      uStack_14 = (uint)(bVar4 == ((byte)*(undefined4 *)(param_2 + 8) & 1));
      uVar10 = uStack_14;
      break;
    case 4:
      pcVar12 = (char *)*param_1;
      if (((pcVar12 == (char *)param_1[0x14]) || (*pcVar12 == '\n')) || (*pcVar12 == '\r'))
      goto LAB_00657095;
      *param_1 = (int)(pcVar12 + 1);
      break;
    case 5:
      iVar9 = FUN_0064bd80(*param_1,param_1[0x14],*(int *)(param_2 + 0x1c),
                           *(int *)(param_2 + 0x18) + *(int *)(param_2 + 0x1c),param_1[0x1c],
                           param_1[0x17]);
      if (iVar9 == *param_1) goto LAB_00657095;
      *param_1 = iVar9;
      uVar10 = uStack_14;
      break;
    case 6:
      puVar11 = (undefined *)*param_1;
      if (puVar11 != (undefined *)param_1[0x14]) {
        uStack_18 = CONCAT31(uStack_18._1_3_,*puVar11);
        if ((param_1[0x17] & 0x100U) != 0) {
          uVar5 = (**(code **)(**(int **)(param_1[0x1c] + 4) + 0x10))(uStack_18);
          puVar11 = (undefined *)*param_1;
          uStack_18 = CONCAT31(uStack_18._1_3_,uVar5);
        }
        puVar14 = puVar11 + 1;
        if ((*(int *)(param_2 + 0x14) == 0) ||
           (puVar8 = (undefined *)FUN_0064cbf0(puVar11,param_1[0x14],*(int *)(param_2 + 0x14)),
           puVar8 == puVar11)) {
          iVar9 = *(int *)(param_2 + 0x20);
          if (iVar9 != 0) {
            if ((param_1[0x17] & 0x800U) == 0) {
              uVar10 = uStack_18 & 0xff;
            }
            else {
              uVar10 = FUN_0066cac0(uStack_18);
            }
            cVar6 = FUN_0064cc60(uVar10 & 0xff,iVar9);
            if (cVar6 != '\0') {
              uVar10 = 1;
              goto LAB_00656e95;
            }
          }
          if ((*(int *)(param_2 + 0x18) == 0) ||
             ((*(byte *)((uint)((byte)uStack_18 >> 3) + *(int *)(param_2 + 0x18)) &
              (byte)(1 << ((byte)uStack_18 & 7))) == 0)) {
            uVar10 = 0;
          }
          else {
            uVar10 = 1;
          }
        }
        else {
          uVar10 = 1;
          puVar14 = puVar8;
        }
LAB_00656e95:
        if (uVar10 == (*(uint *)(param_2 + 8) & 1)) goto LAB_00657095;
        uVar10 = 0;
        *param_1 = (int)puVar14;
        uStack_14 = uVar10;
        goto LAB_00656dc2;
      }
LAB_00657095:
      uVar10 = 1;
LAB_00657097:
      iVar9 = param_1[0x1f];
      goto LAB_0065709b;
    case 9:
    case 10:
      iVar7 = *param_1;
      iStack_1c = iVar7;
      FUN_00650440(param_1 + 1);
      iStack_20 = param_1[4];
      uStack_8 = 0;
      cVar6 = FUN_00656c90(*(undefined4 *)(param_2 + 0x14));
      if ((bool)cVar6 == (iVar9 == 0xb)) {
        *param_1 = iVar7;
        FUN_006521b0(auStack_2c);
        uStack_14 = 1;
      }
      else {
        *param_1 = iStack_1c;
      }
      uStack_8 = 0xffffffff;
      FUN_006513e0();
      uVar10 = uStack_14;
      break;
    case 0xb:
      goto switchD_00656cfe_caseD_b;
    case 0xc:
      *(int *)(param_1[5] + *(int *)(param_2 + 0x14) * 8) = *param_1;
      uVar17 = param_1[4];
      uVar10 = uStack_14;
      if (*(uint *)(param_2 + 0x14) < uVar17) {
        do {
          uVar17 = uVar17 - 1;
          puVar1 = (uint *)(param_1[1] + (uVar17 >> 5) * 4);
          *puVar1 = *puVar1 & ~(1 << (uVar17 & 0x1f));
        } while (*(uint *)(param_2 + 0x14) < uVar17);
      }
      break;
    case 0xd:
      iVar9 = *(int *)(param_2 + 0x14);
      if ((*(char *)((int)param_1 + 0x65) != '\0') || (*(int *)(iVar9 + 0x14) != 0)) {
        puVar1 = (uint *)(param_1[1] + (*(uint *)(iVar9 + 0x14) >> 5) * 4);
        *puVar1 = *puVar1 | 1 << (*(uint *)(iVar9 + 0x14) & 0x1f);
        *(int *)(param_1[5] + 4 + *(int *)(iVar9 + 0x14) * 8) = *param_1;
        uVar10 = uStack_14;
      }
      break;
    case 0xe:
      uVar10 = uStack_14;
      if ((*(uint *)(param_1[1] + (*(uint *)(param_2 + 0x14) >> 5) * 4) &
          1 << ((byte)*(undefined4 *)(param_2 + 0x14) & 0x1f)) != 0) {
        iVar9 = *param_1;
        iVar7 = *(int *)(param_1[5] + *(int *)(param_2 + 0x14) * 8);
        iVar2 = *(int *)(param_1[5] + 4 + *(int *)(param_2 + 0x14) * 8);
        if ((iVar7 != iVar2) &&
           (iVar9 = FUN_0064bd80(iVar9,param_1[0x14],iVar7,iVar2,param_1[0x1c],param_1[0x17]),
           iVar9 == *param_1)) goto LAB_00657095;
        *param_1 = iVar9;
        uVar10 = uStack_14;
      }
      break;
    case 0xf:
      cVar6 = FUN_00655c20(param_2);
      goto LAB_00656ff1;
    case 0x11:
      cVar6 = FUN_006565a0(param_2,(byte)(*(uint *)(param_2 + 8) >> 1) & 1,0);
LAB_00656ff1:
      uVar10 = uStack_14 & 0xff;
      uStack_14 = uVar10;
      if (cVar6 == '\0') {
        uVar10 = 1;
        uStack_14 = uVar10;
      }
switchD_00656cfe_caseD_b:
      param_2 = 0;
      break;
    case 0x12:
      iVar9 = *(int *)(param_2 + 0x14);
      if (*(int *)(iVar9 + 0x24) == 0) {
        cVar6 = FUN_006565a0(iVar9,(byte)(*(uint *)(iVar9 + 8) >> 1) & 1,
                             *(undefined4 *)(param_1[0x10] + *(int *)(iVar9 + 0x20) * 8));
        goto LAB_00656ff1;
      }
LAB_0065708b:
      param_2 = 0;
      uVar10 = uStack_14;
      break;
    case 0x14:
      if ((((param_1[0x18] & 0x2020U) == 0) || (param_1[0x13] != *param_1)) &&
         ((*(char *)(param_1 + 0x1d) == '\0' || (*param_1 == param_1[0x14])))) {
        if ((*(char *)(param_1 + 0x19) == '\0') || (cVar6 = FUN_00654690(), cVar6 != '\0')) {
          FUN_00651f30(param_1);
          *(undefined *)(param_1 + 0x19) = 1;
        }
        goto LAB_0065708b;
      }
      uStack_14 = CONCAT31(uVar13,1);
      param_2 = 0;
      uVar10 = uStack_14;
      break;
    default:
      FUN_016ddd19(0xd);
      unaff_EBX = param_2;
      goto LAB_006570c3;
    }
    if ((char)uVar10 != '\0') goto LAB_00657097;
LAB_00656dc2:
    if ((param_2 == 0) || (param_2 = *(int *)(param_2 + 0xc), param_2 == 0)) goto LAB_00657097;
    goto LAB_00656cea;
  }
LAB_0065709b:
  if (0 < iVar9) {
    param_1[0x1f] = iVar9 + 1;
  }
  ExceptionList = pvStack_10;
  return (undefined *)(uint)((char)uVar10 == '\0');
}



/* FUNCTION 7532 ; VA 0x00657130 ; FUN_00657130 */

undefined4 * __thiscall FUN_00657130(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1b78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_164973690c42fed5077c700689324862>,void,enum_RBX::Player::CanManageStatus>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 0xc);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7533 ; VA 0x006571b0 ; FUN_006571b0 */

void __thiscall FUN_006571b0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_26b0ae1fe61d12916a6d1ea3a6dcb870>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 7534 ; VA 0x006571f0 ; FUN_006571f0 */

void __thiscall FUN_006571f0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_2d70a72d3d46abb802d07f235c5eb683>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 7535 ; VA 0x00657230 ; FUN_00657230 */

void __thiscall FUN_00657230(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_9c20dbf068eda0ddbac7172c77152787>,void,enum_RBX::Player::CanManageStatus>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 7536 ; VA 0x00657270 ; FUN_00657270 */

undefined4 * __thiscall FUN_00657270(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    *puVar1 = std::_Node_base::vftable;
    puVar1[1] = param_2;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
  }
  puVar1[4] = *(undefined4 *)(param_1 + 4);
  iVar2 = *(int *)(param_1 + 4);
  if (*(int *)(iVar2 + 0xc) != 0) {
    puVar1[3] = *(int *)(iVar2 + 0xc);
    *(undefined4 **)(*(int *)(*(int *)(param_1 + 4) + 0xc) + 0x10) = puVar1;
    iVar2 = *(int *)(param_1 + 4);
  }
  *(undefined4 **)(iVar2 + 0xc) = puVar1;
  *(undefined4 **)(param_1 + 4) = puVar1;
  return puVar1;
}



/* FUNCTION 7537 ; VA 0x006572e0 ; FUN_006572e0 */

void __fastcall FUN_006572e0(undefined4 *param_1)

{
  char *pcVar1;
  char *pcVar2;
  uint uVar3;
  
  pcVar2 = (char *)*param_1;
  if (pcVar2 == (char *)param_1[2]) goto LAB_0065732d;
  if ((*pcVar2 == '\\') && (pcVar1 = pcVar2 + 1, pcVar1 != (char *)param_1[2])) {
    uVar3 = param_1[0x14];
    if ((uVar3 & 8) == 0) {
      uVar3 = param_1[0x14];
      if ((*pcVar1 != '(') && (*pcVar1 != ')')) goto LAB_00657316;
    }
    else {
LAB_00657316:
      if (((uVar3 & 0x10) != 0) || ((*pcVar1 != '{' && (*pcVar1 != '}')))) goto LAB_0065732a;
    }
    pcVar2 = pcVar1;
  }
LAB_0065732a:
  *param_1 = pcVar2 + 1;
LAB_0065732d:
  FUN_006576b0();
  return;
}



/* FUNCTION 7538 ; VA 0x00657340 ; FUN_00657340 */

void __fastcall FUN_00657340(undefined4 *param_1)

{
  char *pcVar1;
  code *pcVar2;
  char cVar3;
  char *pcVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iStack_9;
  
  iVar7 = 0;
  iVar8 = -1;
  iVar5 = param_1[0x13];
  if (iVar5 != 0x2a) {
    if (iVar5 == 0x2b) {
      iVar7 = 1;
    }
    else if (iVar5 == 0x3f) {
      iVar8 = 1;
    }
    else {
      if (iVar5 != 0x7b) {
        return;
      }
      FUN_006572e0();
      iVar7 = FUN_00655930(10,0x7fffffff);
      if (iVar7 == 0x7fffffff) goto LAB_00657478;
      iVar5 = param_1[0x13];
      iVar7 = param_1[0x11];
      iVar9 = iVar7;
      if (iVar5 == 0x2c) {
        FUN_006572e0();
        if (param_1[0x13] != 0x7d) {
          cVar3 = FUN_006551d0();
          if (cVar3 == '\0') goto LAB_00657478;
          iVar5 = param_1[0x13];
          iVar9 = param_1[0x11];
          goto LAB_00657449;
        }
      }
      else {
LAB_00657449:
        iVar8 = iVar9;
        if (iVar5 != 0x7d) goto LAB_00657478;
      }
      if ((iVar8 != -1) && (iVar8 < iVar7)) {
LAB_00657478:
        FUN_006567e0(7);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
      }
    }
  }
  *(uint *)(param_1[10] + 8) = *(uint *)(param_1[10] + 8) | 4;
  pcVar4 = (char *)*param_1;
  if (pcVar4 == (char *)param_1[2]) goto LAB_006573b1;
  if ((*pcVar4 == '\\') && (pcVar1 = pcVar4 + 1, pcVar1 != (char *)param_1[2])) {
    uVar6 = param_1[0x14];
    if ((uVar6 & 8) == 0) {
      uVar6 = param_1[0x14];
      if ((*pcVar1 != '(') && (*pcVar1 != ')')) goto LAB_0065739b;
    }
    else {
LAB_0065739b:
      if (((uVar6 & 0x10) != 0) || ((*pcVar1 != '{' && (*pcVar1 != '}')))) goto LAB_006573ae;
    }
    pcVar4 = pcVar1;
  }
LAB_006573ae:
  *param_1 = pcVar4 + 1;
LAB_006573b1:
  FUN_006576b0();
  if (((param_1[0x14] & 0x400) != 0) && (param_1[0x13] == 0x3f)) {
    iStack_9 = (uint)iStack_9._1_3_ << 8;
    FUN_006572e0();
    FUN_00653e30(iVar7,iVar8,iStack_9);
    return;
  }
  iStack_9 = CONCAT31(iStack_9._1_3_,1);
  FUN_00653e30(iVar7,iVar8,iStack_9);
  return;
}



/* FUNCTION 7539 ; VA 0x00657490 ; FUN_00657490 */

char * __thiscall FUN_00657490(int param_1,char *param_2,char *param_3,char *param_4)

{
  int iVar1;
  char cVar2;
  char cVar3;
  char *pcVar4;
  uint uVar5;
  int iVar6;
  
  iVar6 = (int)param_4;
  if (param_4 == (char *)0x0) {
    iVar6 = *(int *)(param_1 + 0x58);
  }
  if (param_2 != param_3) {
    while (iVar6 != 0) {
      switch(*(undefined4 *)(iVar6 + 4)) {
      case 1:
      case 8:
      case 9:
      case 0xd:
      case 0xe:
      case 0x14:
        iVar6 = *(int *)(iVar6 + 0xc);
        break;
      case 2:
        if (param_2[-1] == '\n') {
          return param_2;
        }
        param_4 = (char *)0xa;
        pcVar4 = (char *)FUN_0064e5b0(param_2,param_3,&param_4);
        if (pcVar4 == param_3) {
          return pcVar4;
        }
        return pcVar4 + 1;
      case 3:
        goto switchD_006574c4_caseD_3;
      default:
        goto switchD_006574c4_caseD_4;
      case 6:
        goto switchD_006574c4_caseD_6;
      case 7:
        goto switchD_006574c4_caseD_7;
      case 0xc:
      case 0x15:
        iVar6 = 0;
        break;
      case 0x10:
        goto switchD_006574c4_caseD_10;
      }
    }
  }
switchD_006574c4_caseD_4:
  return param_2;
switchD_006574c4_caseD_7:
  cVar3 = *param_2;
  param_4 = (char *)CONCAT13(cVar3,param_4._0_3_);
  cVar2 = cVar3;
  if (*(int *)(iVar6 + 0x14) == 0) {
LAB_0065757e:
    iVar1 = *(int *)(iVar6 + 0x20);
    if (iVar1 != 0) {
      if ((*(uint *)(param_1 + 0x5c) & 0x800) != 0) {
        cVar2 = FUN_0066cac0(cVar3);
      }
      cVar3 = FUN_0064cc60(cVar2,iVar1);
      if (cVar3 != '\0') {
        uVar5 = 1;
        goto LAB_006575e3;
      }
    }
    if ((*(int *)(iVar6 + 0x18) == 0) ||
       ((*(byte *)((uint)(param_4._3_1_ >> 3) + *(int *)(iVar6 + 0x18)) &
        (byte)(1 << (param_4._3_1_ & 7))) == 0)) {
      uVar5 = 0;
    }
    else {
      uVar5 = 1;
    }
  }
  else {
    pcVar4 = (char *)FUN_0064cbf0(param_2,param_2 + 1,*(int *)(iVar6 + 0x14));
    if (pcVar4 == param_2) {
      cVar2 = param_4._3_1_;
      goto LAB_0065757e;
    }
    uVar5 = 1;
  }
LAB_006575e3:
  if (uVar5 != (*(uint *)(iVar6 + 8) & 1)) {
    return param_2;
  }
  param_2 = param_2 + 1;
  if (param_2 == param_3) {
    return param_2;
  }
  goto switchD_006574c4_caseD_7;
switchD_006574c4_caseD_10:
  do {
    if (iVar6 == 0) {
      return param_3;
    }
    param_3 = (char *)FUN_00657490(param_2,param_3,*(undefined4 *)(iVar6 + 0xc));
    iVar6 = *(int *)(iVar6 + 0x18);
  } while (param_2 != param_3);
  return param_3;
switchD_006574c4_caseD_6:
  do {
    param_4 = param_2 + 1;
    pcVar4 = (char *)FUN_0064bd80(param_2,param_4,*(int *)(iVar6 + 0x1c),*(int *)(iVar6 + 0x1c) + 1,
                                  *(undefined4 *)(param_1 + 0x70),*(undefined4 *)(param_1 + 0x5c));
    if (pcVar4 != param_2) {
      return param_2;
    }
    param_2 = param_4;
  } while (param_4 != param_3);
  return param_4;
switchD_006574c4_caseD_3:
  do {
    if (*param_2 == '\n') {
      return param_2;
    }
    param_2 = param_2 + 1;
  } while (param_2 != param_3);
  return param_2;
}



/* FUNCTION 7540 ; VA 0x00657670 ; FUN_00657670 */

TypeDescriptor * FUN_00657670(void)

{
  return &<lambda_164973690c42fed5077c700689324862>::RTTI_Type_Descriptor;
}



/* FUNCTION 7541 ; VA 0x00657680 ; FUN_00657680 */

TypeDescriptor * FUN_00657680(void)

{
  return &<lambda_26b0ae1fe61d12916a6d1ea3a6dcb870>::RTTI_Type_Descriptor;
}



/* FUNCTION 7542 ; VA 0x00657690 ; FUN_00657690 */

TypeDescriptor * FUN_00657690(void)

{
  return &<lambda_2d70a72d3d46abb802d07f235c5eb683>::RTTI_Type_Descriptor;
}



/* FUNCTION 7543 ; VA 0x006576a0 ; FUN_006576a0 */

TypeDescriptor * FUN_006576a0(void)

{
  return &<lambda_9c20dbf068eda0ddbac7172c77152787>::RTTI_Type_Descriptor;
}



/* FUNCTION 7544 ; VA 0x006576b0 ; FUN_006576b0 */

void __fastcall FUN_006576b0(int *param_1)

{
  char cVar1;
  int iVar2;
  bool bVar3;
  
  if ((char *)*param_1 == (char *)param_1[2]) {
    *(undefined *)(param_1 + 0x12) = 0xff;
    iVar2 = -1;
  }
  else {
    cVar1 = *(char *)*param_1;
    *(char *)(param_1 + 0x12) = cVar1;
    iVar2 = FUN_0170dbd0(&DAT_018d4e28,(int)cVar1);
    if (iVar2 == 0) {
      iVar2 = 0;
    }
    else {
      iVar2 = (int)*(char *)(param_1 + 0x12);
    }
  }
  param_1[0x13] = iVar2;
  switch(*(undefined *)(param_1 + 0x12)) {
  case 10:
    if ((*(byte *)(param_1 + 0x14) & 4) == 0) {
      return;
    }
    if (param_1[4] != 0) {
      return;
    }
    param_1[0x13] = 0x7c;
    return;
  default:
    goto switchD_006576ff_caseD_b;
  case 0x24:
    if ((param_1[0x14] & 0x2000000U) == 0) {
      return;
    }
    if ((char *)(*param_1 + 1) == (char *)param_1[2]) {
      return;
    }
    if (*(char *)(*param_1 + 1) == '\n') {
      return;
    }
    param_1[0x13] = 0;
    return;
  case 0x28:
  case 0x29:
    bVar3 = (*(byte *)(param_1 + 0x14) & 8) == 0;
    break;
  case 0x2a:
    if ((param_1[0x14] & 0x4000000U) == 0) {
      return;
    }
    cVar1 = FUN_006544d0();
    if (cVar1 == '\0') {
      return;
    }
    param_1[0x13] = 0;
    return;
  case 0x2b:
  case 0x3f:
    bVar3 = (*(byte *)(param_1 + 0x14) & 1) == 0;
    break;
  case 0x5c:
    cVar1 = FUN_00656be0();
    if (cVar1 == '\0') {
      return;
    }
    cVar1 = *(char *)(*param_1 + 1);
    *(char *)(param_1 + 0x12) = cVar1;
    param_1[0x13] = (int)cVar1;
    return;
  case 0x5e:
    if ((param_1[0x14] & 0x2000000U) == 0) {
      return;
    }
    cVar1 = FUN_006544d0();
    bVar3 = cVar1 == '\0';
    break;
  case 0x7b:
  case 0x7d:
    bVar3 = (*(byte *)(param_1 + 0x14) & 0x10) == 0;
    break;
  case 0x7c:
    bVar3 = (*(byte *)(param_1 + 0x14) & 2) == 0;
  }
  if (bVar3) {
    param_1[0x13] = 0;
  }
switchD_006576ff_caseD_b:
  return;
}



/* FUNCTION 7545 ; VA 0x00657850 ; FUN_00657850 */

void __thiscall FUN_00657850(int *param_1,uint param_2)

{
  uint *puVar1;
  int iVar2;
  code *pcVar3;
  uint uVar4;
  
  if (param_2 < 0x80000000) {
    uVar4 = param_2 + 0x1f >> 5;
    if ((uVar4 < (uint)(param_1[1] - *param_1 >> 2)) &&
       (iVar2 = *param_1 + uVar4 * 4, iVar2 != param_1[1])) {
      param_1[1] = iVar2;
    }
    param_1[3] = param_2;
    if ((param_2 & 0x1f) != 0) {
      puVar1 = (uint *)(*param_1 + uVar4 * 4 + -4);
      *puVar1 = *puVar1 & (1 << (sbyte)(param_2 & 0x1f)) - 1U;
    }
    return;
  }
  FUN_00657a00();
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}



/* FUNCTION 7546 ; VA 0x006578b0 ; FUN_006578b0 */

int __thiscall FUN_006578b0(undefined4 param_1,int param_2,int param_3,int param_4)

{
  if (param_2 != param_3) {
    do {
      FUN_0064e2a0(param_1,param_4,param_2);
      param_2 = param_2 + 0x38;
      param_4 = param_4 + 0x38;
    } while (param_2 != param_3);
  }
  return param_4;
}



/* FUNCTION 7547 ; VA 0x00657900 ; FUN_00657900 */

undefined4 __fastcall FUN_00657900(int param_1)

{
  uint *puVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  if (((*(uint *)(param_1 + 0x50) & 0x8000000) == 0) && (*(int *)(param_1 + 0x4c) == 0x29)) {
    FUN_006567e0(5);
LAB_006579f1:
    FUN_006567e0(0xe);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
  }
  if (((*(uint *)(param_1 + 0x50) & 0x20) == 0) || (*(int *)(param_1 + 0x4c) != 0x3f)) {
    if ((*(uint *)(param_1 + 0x40) & 0x200) == 0) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
      iVar4 = FUN_00654610(*(undefined4 *)(param_1 + 0xc));
      FUN_00655360();
      FUN_00656740(iVar4);
      FUN_0066b930(*(int *)(param_1 + 0xc) + 1,0);
      puVar1 = (uint *)(*(int *)(param_1 + 0x14) + (*(uint *)(iVar4 + 0x14) >> 5) * 4);
      *puVar1 = *puVar1 | 1 << (*(uint *)(iVar4 + 0x14) & 0x1f);
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
      return 1;
    }
  }
  else {
    FUN_006572e0();
    iVar4 = *(int *)(param_1 + 0x4c);
    FUN_006572e0();
    if (iVar4 != 0x3a) {
      if (iVar4 == 0x21) {
        FUN_006555f0(1);
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
        return 0;
      }
      if (iVar4 == 0x3d) {
        FUN_006555f0(0);
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
        return 0;
      }
      goto LAB_006579f1;
    }
  }
  uVar3 = FUN_00657270(8);
  FUN_00655360();
  FUN_00656740(uVar3);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
  return 1;
}



/* FUNCTION 7548 ; VA 0x00657a00 ; FUN_00657a00 */

void FUN_00657a00(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("vector<bool> too long");
}



/* FUNCTION 7549 ; VA 0x00657a10 ; FUN_00657a10 */

undefined4 __fastcall FUN_00657a10(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  int *piStack_8;
  
  if ((DAT_01eadc5c & 0x11) != 0) {
    if (param_1 != 0) {
      iVar1 = *(int *)(param_1 + 0x34);
      iVar2 = param_1;
      if ((iVar1 != 0) && (iVar2 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
        iVar2 = FUN_005c8ac0();
      }
      if ((iVar2 != 0) &&
         (iVar1 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da))) {
        FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
        uVar3 = FUN_00560c40();
        piStack_8 = (int *)FUN_008aa140(uVar3);
        if (*piStack_8 == 0) {
          uVar3 = FUN_00961660();
          piVar4 = (int *)FUN_008a9ba0(auStack_10,uVar3);
          iVar1 = *piVar4;
          iVar2 = piVar4[1];
          *piVar4 = 0;
          piVar4[1] = 0;
          *piStack_8 = iVar1;
          piVar4 = (int *)piStack_8[1];
          piStack_8[1] = iVar2;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar1 = piVar4[1] + -1;
            piVar4[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar1 = piVar4[2] + -1;
              piVar4[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          if (piStack_c != (int *)0x0) {
            LOCK();
            iVar1 = piStack_c[1] + -1;
            piStack_c[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_c)();
              LOCK();
              piVar4 = piStack_c + 2;
              iVar1 = *piVar4;
              *piVar4 = *piVar4 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                (**(code **)(*piStack_c + 4))();
              }
            }
          }
        }
        if ((*piStack_8 != 0) &&
           (*(uint *)(param_1 + 0x3f44) < (uint)(*(int *)(*piStack_8 + 0xfc) * 2))) {
          *(uint *)(param_1 + 0x3f44) = *(uint *)(param_1 + 0x3f44) + 1;
          return 1;
        }
      }
    }
    if (((DAT_01eadc5c & 0x11) != 0) && (*(char *)(param_1 + 0x3f64) == '\0')) {
      *(undefined *)(param_1 + 0x3f64) = 1;
      FUN_0087c450(&DAT_018c5f98,"NetworkTest","ReportAbuseSpam",0,0,0);
    }
    if ((DAT_01eadc5c & 1) != 0) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 7550 ; VA 0x00657b90 ; FUN_00657b90 */

void __fastcall FUN_00657b90(int param_1)

{
  uint *puVar1;
  byte bVar2;
  uint uVar3;
  char *pcVar4;
  int iVar5;
  char cVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  char *pcStack_20;
  uint uStack_1c;
  uint uStack_18;
  byte bStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1ba0;
  pvStack_10 = ExceptionList;
  cStack_11 = '\0';
  pcVar7 = (char *)&DAT_01d5ab10;
  if (0xf < DAT_01d5ab24) {
    pcVar7 = DAT_01d5ab10;
  }
  uVar10 = 0;
  uStack_18 = 0x80000000;
  uVar11 = 0;
  do {
    bVar2 = pcVar7[uVar10];
    if (bVar2 == 0) {
LAB_00657c1d:
      cStack_11 = '\x01';
      uVar3 = 0;
      break;
    }
    if (uVar10 % 5 == 4) {
      uVar3 = uVar11;
      if (0x37 < bVar2) goto LAB_00657c1d;
    }
    else {
      uVar3 = uStack_18 | uVar11;
      uStack_18 = uStack_18 >> 1;
      if (bVar2 != 0x62) {
        uVar3 = uVar11;
      }
    }
    uVar10 = uVar10 + 1;
    uVar11 = uVar3;
  } while (uVar10 < 0x28);
  uStack_1c = 0x80000000;
  uStack_18 = 0;
  pcStack_20 = (char *)&DAT_01d5ab10;
  if (0xf < DAT_01d5ab24) {
    pcStack_20 = DAT_01d5ab10;
  }
  uVar11 = 0;
  do {
    bStack_12 = pcStack_20[uVar11];
    iStack_24 = param_1;
    if (bStack_12 == 0) goto LAB_00657ca5;
    if (uVar11 % 5 == 4) {
      uVar10 = uStack_18;
      if (0x37 < bStack_12) goto LAB_00657ca5;
    }
    else {
      uVar10 = uStack_1c | uStack_18;
      uStack_1c = uStack_1c >> 1;
      if (bStack_12 != 0x72) {
        uVar10 = uStack_18;
      }
    }
    uStack_18 = uVar10;
    uVar11 = uVar11 + 1;
  } while (uVar11 < 0x28);
  uStack_18 = uStack_18 | uVar3;
  ExceptionList = &pvStack_10;
  uVar3 = uStack_18;
  if (cStack_11 != '\0') {
LAB_00657ca5:
    uStack_18 = uVar3;
    ExceptionList = &pvStack_10;
    FUN_006688b0("PlayerVerificationConfig");
  }
  uVar10 = 0;
  uVar11 = uStack_18;
  do {
    uVar3 = *(uint *)((int)&DAT_018d0a58 + uVar10);
    if ((uVar11 & uVar3) != 0) {
      pcVar4 = (char *)FUN_00658300(uVar3);
      uStack_44 = 0;
      uStack_40 = 0xf;
      auStack_54[0] = auStack_54[0] & 0xffffff00;
      pcStack_20 = pcVar4 + 1;
      pcVar7 = pcVar4;
      do {
        cVar6 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar6 != '\0');
      FUN_005542c0(pcVar4,(int)pcVar7 - (int)pcStack_20);
      uStack_8 = 0;
      if (uVar3 == (*(uint *)(iStack_24 + 0x3f74) & uVar3)) {
        cVar6 = (uVar3 != (*(uint *)(iStack_24 + 0x3f78) & uVar3)) + '\x01';
      }
      else {
        cVar6 = '\0';
      }
      if (cVar6 == '\0') {
        pcVar7 = "Unknown";
      }
      else if (cVar6 == '\x01') {
        pcVar7 = "True";
      }
      else if (cVar6 == '\x02') {
        pcVar7 = "False";
      }
      else {
        pcVar7 = "WrongBotCheckStatus";
      }
      uStack_2c = 0;
      uStack_28 = 0xf;
      uStack_3c = uStack_3c & 0xffffff00;
      pcVar4 = pcVar7;
      do {
        cVar6 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar6 != '\0');
      FUN_005542c0(pcVar7,(int)pcVar4 - (int)(pcVar7 + 1));
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar5 = FUN_005d15d0(auStack_54);
      puVar1 = (uint *)(iVar5 + 0x18);
      uVar11 = uStack_28;
      if (puVar1 != &uStack_3c) {
        uVar11 = *(uint *)(iVar5 + 0x2c);
        if (0xf < uVar11) {
          uVar3 = *puVar1;
          uVar8 = uVar11 + 1;
          uVar9 = uVar3;
          if (0xfff < uVar8) {
            uVar9 = *(uint *)(uVar3 - 4);
            uVar8 = uVar11 + 0x24;
            if (0x1f < (uVar3 - uVar9) - 4) goto LAB_00657e87;
          }
          FUN_01674ea0(uVar9,uVar8);
        }
        *(undefined4 *)(iVar5 + 0x28) = 0;
        *(undefined4 *)(iVar5 + 0x2c) = 0xf;
        *puVar1 = uStack_3c;
        *(undefined4 *)(iVar5 + 0x1c) = uStack_38;
        *(undefined4 *)(iVar5 + 0x20) = uStack_34;
        *(undefined4 *)(iVar5 + 0x24) = uStack_30;
        uStack_3c = uStack_3c & 0xffffff00;
        *(undefined4 *)(iVar5 + 0x28) = uStack_2c;
        *(uint *)(iVar5 + 0x2c) = uStack_28;
        uVar11 = 0xf;
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uVar11) {
        uVar9 = uVar11 + 1;
        uVar3 = uStack_3c;
        if (0xfff < uVar9) {
          uVar3 = *(uint *)(uStack_3c - 4);
          uVar9 = uVar11 + 0x24;
          if (0x1f < (uStack_3c - uVar3) - 4) goto LAB_00657e87;
        }
        FUN_01674ea0(uVar3,uVar9);
      }
      uStack_8 = 0xffffffff;
      uVar11 = uStack_18;
      if (0xf < uStack_40) {
        uVar3 = uStack_40 + 1;
        uVar11 = auStack_54[0];
        if (0xfff < uVar3) {
          uVar11 = *(uint *)(auStack_54[0] - 4);
          uVar3 = uStack_40 + 0x24;
          if (0x1f < (auStack_54[0] - uVar11) - 4) {
LAB_00657e87:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar3);
        uVar11 = uStack_18;
      }
    }
    uVar10 = uVar10 + 4;
    if (0x37 < uVar10) {
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 7551 ; VA 0x00657e90 ; FUN_00657e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00657e90(int param_1,int param_2)

{
  float fVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  float10 fVar8;
  undefined4 *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1bc0;
  pvStack_10 = ExceptionList;
  fVar1 = *(float *)(param_2 + 0xc);
  puVar7 = *(undefined4 **)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  *(float *)(param_1 + 0xc) = fVar1;
  if (puVar7 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    fVar8 = (float10)FUN_01725160(((double)*(int *)(param_1 + 4) +
                                  (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 4) >> 0x1f)]) *
                                  (double)fVar1);
    if ((double)fVar8 < _DAT_018c4e98) {
      uVar4 = FUN_016f3eb1();
    }
    else {
      uVar4 = 0xffffffff;
    }
  }
  *(uint *)(param_1 + 0x10) = uVar4;
  if ((*(int *)(param_1 + 8) != 0) || (*(int *)(param_2 + 8) != 0)) {
    if (*(uint *)(param_2 + 8) < uVar4) {
      puVar3 = puVar7 + *(int *)(param_1 + 4);
      for (; puVar7 != puVar3; puVar7 = puVar7 + 1) {
        *puVar7 = 0;
      }
    }
    else {
      FUN_005d6bb0();
      FUN_005d2b00();
    }
    puStack_24 = (undefined4 *)0x0;
    if (*(int *)(param_1 + 8) != 0) {
      puStack_24 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
    }
    iStack_8 = 0;
    if (*(int *)(param_2 + 8) == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar3 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar7 != (undefined4 *)0x0) {
      if (puStack_24 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)FUN_01674e20(0x38);
        *puVar5 = 0;
        puVar5[1] = 0;
        FUN_0170d1f0(puVar5 + 2,0,0x30);
        puVar6 = puStack_24;
      }
      else {
        puVar6 = (undefined4 *)*puStack_24;
        *puStack_24 = 0;
        FUN_00560a10(-(uint)(param_1 != -3) & param_1 + 4U,puStack_24 + 2);
        puVar5 = puStack_24;
      }
      FUN_0054ef60(puVar7 + 2);
      iStack_8._0_1_ = 1;
      FUN_0054ef60(puVar7 + 8);
      puVar5[1] = puVar7[1];
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      *puVar3 = puVar5;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar2 = (undefined4 *)*puVar3;
      puVar7 = (undefined4 *)*puVar7;
      uVar4 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
      puStack_24 = puVar6;
      if (*(int *)(*(int *)(param_1 + 0x14) + uVar4 * 4) == 0) {
        *puVar5 = puVar3;
        puVar3 = puVar2;
      }
      else {
        *puVar3 = *puVar2;
        *puVar2 = *(undefined4 *)*puVar5;
        *(undefined4 **)*puVar5 = puVar2;
      }
    }
    FUN_00651640();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7552 ; VA 0x006580e0 ; FUN_006580e0 */

undefined4 * FUN_006580e0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined **ppuStack_d0;
  undefined auStack_cc [52];
  undefined4 auStack_98 [5];
  undefined4 uStack_84;
  undefined **appuStack_80 [18];
  uint uStack_38;
  undefined4 ***apppuStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1c07;
  pvStack_10 = ExceptionList;
  ppuStack_d0 = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_80[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_84 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(auStack_cc,0);
  uStack_8 = 2;
  *(undefined ***)(auStack_cc + (int)(ppuStack_d0[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_cc + (int)(ppuStack_d0[1] + -8)) = ppuStack_d0[1] + -0x50;
  FUN_005658e0(2);
  uStack_8 = 3;
  uStack_18 = 0;
  uStack_38 = uStack_38 & 0xffffff00;
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  puVar1 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar1 = (undefined4 *)*param_2;
  }
  FUN_0064ea30(&param_2,puVar1,param_2[4] + (int)puVar3,uStack_38,
               *(undefined4 *)((int)auStack_98 + (int)ppuStack_d0[1]),&uStack_18);
  FUN_0058c420(apppuStack_30);
  ppppuVar2 = apppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
  }
  ppppuVar4 = apppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar4 = (undefined4 ****)apppuStack_30[0];
  }
  uStack_8._0_1_ = 4;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_0064d1e0(ppppuVar4,iStack_20 + (int)ppppuVar2,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar5);
  }
  iStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  *(undefined ***)(auStack_cc + (int)(ppuStack_d0[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_cc + (int)(ppuStack_d0[1] + -8)) = ppuStack_d0[1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(auStack_cc + (int)(ppuStack_d0[1] + -4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(auStack_cc + (int)(ppuStack_d0[1] + -8)) = ppuStack_d0[1] + -8;
  uStack_8 = 5;
  appuStack_80[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_80);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7553 ; VA 0x00658300 ; FUN_00658300 */

char * FUN_00658300(uint param_1)

{
  if (param_1 < 0x81) {
    if (param_1 == 0x80) {
      return "SpoofedPing";
    }
    switch(param_1) {
    case 1:
      return "EqualMachineUuid";
    case 2:
      return "DataPingTimeout";
    case 4:
      return "DynLuaChallenge";
    case 8:
      return "SimRadiusMissing";
    case 0x10:
      return "SuspiciousOsVersion";
    case 0x20:
      return "InferredCrash";
    case 0x40:
      return "SpoofedPlatform";
    }
  }
  else if (param_1 < 0x801) {
    if (param_1 == 0x800) {
      return "SpoofedPlatformMobile";
    }
    if (param_1 == 0x100) {
      return "ChatThenLeave";
    }
    if (param_1 == 0x200) {
      return "SuspiciousModule";
    }
    if (param_1 == 0x400) {
      return "MainWindowCount";
    }
  }
  else {
    if (param_1 == 0x1000) {
      return "DynBlacklistedIp";
    }
    if (param_1 == 0x2000) {
      return "MissingJsonOnJoin";
    }
  }
  return "UnknownBotSignal";
}



/* FUNCTION 7554 ; VA 0x00658420 ; FUN_00658420 */

bool FUN_00658420(void)

{
  uint uVar1;
  
  if (DAT_01d5ad18 == 0xffffffff) {
    uVar1 = FUN_01679ce0();
    DAT_01d5ad18 = uVar1 % 10000;
  }
  return (int)DAT_01d5ad18 < DAT_01ead7b8;
}



/* FUNCTION 7555 ; VA 0x00658450 ; FUN_00658450 */

undefined __fastcall FUN_00658450(int param_1)

{
  return *(undefined *)(param_1 + 0x3e58);
}



/* FUNCTION 7556 ; VA 0x00658460 ; FUN_00658460 */

undefined4 __fastcall FUN_00658460(int param_1)

{
  if (((*(double *)(param_1 + 0x3c90) <= (double)*(byte *)(param_1 + 0x3f38) &&
        (double)*(byte *)(param_1 + 0x3f38) != *(double *)(param_1 + 0x3c90)) &&
      (*(double *)(param_1 + 0x3cb8) <= (double)*(byte *)(param_1 + 0x3f39) &&
       (double)*(byte *)(param_1 + 0x3f39) != *(double *)(param_1 + 0x3cb8))) &&
     (*(double *)(param_1 + 0x3ce0) <= (double)*(byte *)(param_1 + 0x3f3a) &&
      (double)*(byte *)(param_1 + 0x3f3a) != *(double *)(param_1 + 0x3ce0))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 7557 ; VA 0x006584c0 ; FUN_006584c0 */

undefined4 __fastcall FUN_006584c0(int param_1)

{
  if ((((double)*(byte *)(param_1 + 0x3f3b) < *(double *)(param_1 + 0x3c90)) &&
      ((double)*(byte *)(param_1 + 0x3f3c) < *(double *)(param_1 + 0x3cb8))) &&
     ((double)*(byte *)(param_1 + 0x3f3d) < *(double *)(param_1 + 0x3ce0))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 7558 ; VA 0x00658520 ; FUN_00658520 */

void __fastcall FUN_00658520(int param_1)

{
  *(int *)(param_1 + 0x3e90) = *(int *)(param_1 + 0x3e90) + 1;
  return;
}



/* FUNCTION 7559 ; VA 0x00658530 ; FUN_00658530 */

void __thiscall FUN_00658530(int *param_1,uint param_2,int param_3)

{
  int iVar1;
  bool bVar2;
  char cVar3;
  double *pdVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *******pppppppuVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_174 [160];
  undefined auStack_d4 [56];
  undefined auStack_9c [56];
  undefined auStack_64 [24];
  undefined4 ******appppppuStack_4c [5];
  uint uStack_38;
  undefined auStack_34 [4];
  undefined4 *puStack_30;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_12;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1c51;
  pvStack_10 = ExceptionList;
  if (param_1[0xf03] == 0) {
    return;
  }
  if (DAT_01d65328 != '\0') {
    return;
  }
  ExceptionList = &pvStack_10;
  if ((((*(char *)(param_1 + 0xf5c) != '\0') && (ExceptionList = &pvStack_10, DAT_01d5aa10 != '\0'))
      && (ExceptionList = &pvStack_10, *(char *)((int)param_1 + 0x3f3e) == '\x01')) &&
     (ExceptionList = &pvStack_10, pdVar4 = (double *)FUN_016830f0(auStack_34),
     DAT_01d5a688 < (int)(*pdVar4 - *(double *)(param_1 + 0xf94)))) {
    (**(code **)(*param_1 + 0x290))(&DAT_018d49d4,0x21,DAT_01d5aa08 != '\0',"DynamicLuaTimeout",0);
  }
  if (*(char *)(param_1 + 0xe00) == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  uVar11 = 0;
  pdVar4 = (double *)FUN_016830f0(auStack_34);
  bStack_11 = DAT_01d5a660 < (int)(*pdVar4 - *(double *)(param_1 + 0xef0));
  if ((DAT_01d5a660 < (int)(*pdVar4 - *(double *)(param_1 + 0xef0))) &&
     (*(char *)((int)param_1 + 0x3f62) == '\0')) {
    uVar11 = 0x40;
  }
  puStack_30 = (undefined4 *)(param_2 - param_1[0x41c]);
  uStack_1c = (param_3 - param_1[0x41d]) - (uint)(param_2 < (uint)param_1[0x41c]);
  uStack_28 = param_2 - param_1[0x41e];
  uStack_24 = (param_3 - param_1[0x41f]) - (uint)(param_2 < (uint)param_1[0x41e]);
  uStack_18 = param_2 - param_1[0x420];
  uStack_20 = (param_3 - param_1[0x421]) - (uint)(param_2 < (uint)param_1[0x420]);
  iVar1 = param_1[0xfbb];
  if (((iVar1 == 0x4beda921) || (iVar1 == 0x752fab0b)) ||
     (puVar5 = DAT_01d5a678, iVar1 == 0x443921d5)) {
    puVar5 = DAT_01d5a668;
  }
  if ((uStack_1c < (uint)((int)puVar5 >> 0x1f)) ||
     ((uStack_1c <= (uint)((int)puVar5 >> 0x1f) && (puStack_30 <= puVar5)))) {
    uVar10 = 0;
  }
  else {
    uVar10 = 0x80;
  }
  cStack_12 = *(char *)((int)param_1 + 0x37fe);
  uVar10 = uVar10 | uVar11;
  uVar11 = (int)DAT_01d5a670 >> 0x1f;
  if (cStack_12 == '\0') {
    if ((uStack_24 < uVar11) || ((uStack_24 <= uVar11 && (uStack_28 <= DAT_01d5a670)))) {
      uVar6 = 0;
    }
    else {
      uVar6 = 1;
    }
    if (((bool)bStack_11) && (DAT_01d5a640 < (int)(uint)*(byte *)((int)param_1 + 0x3de2))) {
      uVar9 = DAT_01d5a640 * 500 >> 0x1f;
      if ((uStack_24 < uVar9) || ((uStack_24 <= uVar9 && (uStack_28 <= (uint)(DAT_01d5a640 * 500))))
         ) goto LAB_006586f6;
      uVar9 = 2;
    }
    else {
LAB_006586f6:
      uVar9 = 0;
    }
    uVar10 = uVar10 | uVar6 | uVar9;
  }
  cVar3 = *(char *)((int)param_1 + 0x37ff);
  if (cVar3 == '\0') {
    if ((uStack_20 < uVar11) || ((uStack_20 <= uVar11 && (uStack_18 <= DAT_01d5a670)))) {
      uVar11 = 0;
    }
    else {
      uVar11 = 4;
    }
    uVar10 = uVar10 | uVar11;
    if (((bool)bStack_11) && (DAT_01d5a648 < (int)(uint)*(byte *)((int)param_1 + 0x3de1))) {
      uVar11 = DAT_01d5a648 * 500 >> 0x1f;
      if ((uVar11 <= uStack_20) &&
         ((uVar11 < uStack_20 || ((uint)(DAT_01d5a648 * 500) < uStack_18)))) {
        uVar10 = uVar10 | 8;
        cVar3 = *(char *)((int)param_1 + 0x37ff);
        goto LAB_0065876e;
      }
    }
    cVar3 = *(char *)((int)param_1 + 0x37ff);
  }
LAB_0065876e:
  if ((cStack_12 == '\0') && (cVar3 == '\0')) {
    if (!(bool)bStack_11) goto LAB_0065880b;
    if (DAT_01d5a650 < (int)(uint)*(byte *)((int)param_1 + 0x3de3)) {
      uVar11 = DAT_01d5a650 * 3000 >> 0x1f;
      if ((uStack_20 < uVar11) ||
         ((uStack_20 <= uVar11 && (uStack_18 <= (uint)(DAT_01d5a650 * 3000))))) goto LAB_006587ab;
      uVar11 = 0x10;
    }
    else {
LAB_006587ab:
      uVar11 = 0;
    }
    if (DAT_01d5a658 < (int)(uint)*(byte *)(param_1 + 0xf79)) {
      uVar6 = DAT_01d5a658 * 8000 >> 0x1f;
      if ((uStack_24 < uVar6) ||
         ((uStack_24 <= uVar6 && (uStack_28 <= (uint)(DAT_01d5a658 * 8000))))) goto LAB_006587da;
      uVar6 = 0x20;
    }
    else {
LAB_006587da:
      uVar6 = 0;
    }
    uVar10 = uVar10 | uVar11 | uVar6;
  }
  if ((bool)bStack_11) {
    FUN_00662010(puStack_30,uStack_1c,uStack_28,uStack_24,uStack_18,uStack_20,
                 *(undefined *)((int)param_1 + 0x3de2),*(undefined *)((int)param_1 + 0x3de1));
  }
LAB_0065880b:
  bVar2 = false;
  uVar10 = uVar10 & ~param_1[0xf73];
  if (uVar10 != 0) {
    uStack_1c = 0x80000000;
    uStack_18 = 0;
    puStack_30 = &DAT_01d5aac8;
    if (0xf < DAT_01d5aadc) {
      puStack_30 = DAT_01d5aac8;
    }
    uVar11 = 0;
    do {
      bStack_11 = *(byte *)((int)puStack_30 + uVar11);
      if (bStack_11 == 0) {
LAB_00658891:
        bVar2 = true;
        uStack_18 = 0;
        break;
      }
      if (uVar11 % 5 == 4) {
        uVar6 = uStack_18;
        if (0x37 < bStack_11) goto LAB_00658891;
      }
      else {
        uVar6 = uStack_1c | uStack_18;
        uStack_1c = uStack_1c >> 1;
        if (bStack_11 != 0x2e) {
          uVar6 = uStack_18;
        }
      }
      uStack_18 = uVar6;
      uVar11 = uVar11 + 1;
    } while (uVar11 < 0x28);
    cStack_12 = '\0';
    if ((uVar10 & uStack_18) != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0058ccc0(auStack_34,0xb,"H:%08X",uVar10);
      FUN_0151f850(&DAT_018d20dc,auStack_34);
      (**(code **)(*param_1 + 0x290))("hector",10,1,"Timeout",auStack_9c);
      cStack_12 = '\x01';
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    uStack_20 = 0x80000000;
    uStack_1c = 0;
    puStack_30 = &DAT_01d5aac8;
    if (0xf < DAT_01d5aadc) {
      puStack_30 = DAT_01d5aac8;
    }
    uVar11 = 0;
    do {
      bStack_11 = *(byte *)((int)puStack_30 + uVar11);
      if (bStack_11 == 0) {
LAB_0065898e:
        bVar2 = true;
        uVar6 = 0;
        break;
      }
      if (uVar11 % 5 == 4) {
        uVar6 = uStack_1c;
        if (0x37 < bStack_11) goto LAB_0065898e;
      }
      else {
        uVar6 = uStack_20 | uStack_1c;
        uStack_20 = uStack_20 >> 1;
        if (bStack_11 != 0x72) {
          uVar6 = uStack_1c;
        }
      }
      uStack_1c = uVar6;
      uVar11 = uVar11 + 1;
      uVar6 = uStack_1c;
    } while (uVar11 < 0x28);
    uVar11 = (uStack_18 | uVar6) & uVar10;
    if (uVar11 != 0) {
      FUN_00565940(3,1);
      uStack_8 = 1;
      FUN_00558890(auStack_174,"TimeoutError: ");
      FUN_0056f100(FUN_00585a70);
      FUN_0056ef60(uVar11);
      FUN_0058c420(appppppuStack_4c);
      pppppppuVar7 = appppppuStack_4c;
      if (0xf < uStack_38) {
        pppppppuVar7 = (undefined4 *******)appppppuStack_4c[0];
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0087c450(&DAT_018c5f98,"SecurityException",pppppppuVar7,0,0,0);
      if (DAT_01d5a060 != '\0') {
        FUN_0066b780(uVar10);
      }
      if (cStack_12 == '\0') {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 3;
        uVar8 = FUN_01675640(auStack_64,"H:%08X",uVar10);
        uStack_8._0_1_ = 4;
        FUN_0151f950(&DAT_018d20dc,uVar8);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_005507b0();
        (**(code **)(*param_1 + 0x290))("hector",10,0,"Timeout",auStack_d4);
        FUN_0151f7f0();
      }
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_005705c0();
    }
    if (bVar2) {
      FUN_006688b0("US30605p7");
    }
  }
  uVar11 = param_1[0xf73];
  param_1[0xf73] = uVar11 | uVar10;
  if ((*(byte *)(param_1 + 0xfdd) & 2) == 0) {
    if (param_1[0xfa4] == 0) {
      if (-1 < (char)(uVar11 | uVar10)) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar8 = 1;
    }
    else {
      uVar8 = 0;
    }
    FUN_0066cb30(2,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7560 ; VA 0x00658b20 ; FUN_00658b20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00658b20(int param_1)

{
  int iVar1;
  int *****pppppiVar2;
  char cVar3;
  double *pdVar4;
  undefined4 *puVar5;
  int *piVar6;
  int ******ppppppiVar7;
  int iVar8;
  int ******ppppppiVar9;
  int *****pppppiStack_c8;
  int iStack_c4;
  int *****pppppiStack_c0;
  int *****pppppiStack_bc;
  int *****apppppiStack_6c [4];
  int iStack_5c;
  uint uStack_58;
  int *****apppppiStack_54 [4];
  int iStack_44;
  uint uStack_40;
  int *****apppppiStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  undefined *puStack_20;
  int *****pppppiStack_1c;
  int *****pppppiStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1c93;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((NAN(*(double *)(param_1 + 0x68)) || NAN(_PTR_018c6f48)) ==
      (*(double *)(param_1 + 0x68) == _PTR_018c6f48)) {
    pppppiStack_bc = (int *****)auStack_24;
    pppppiStack_c0 = (int *****)0x658b5f;
    ExceptionList = &pvStack_10;
    pdVar4 = (double *)FUN_016830f0();
    if (*pdVar4 - *(double *)(param_1 + 0x68) < (double)*(int *)(param_1 + 0x60)) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  pppppiStack_bc = (int *****)auStack_24;
  pppppiStack_c0 = (int *****)0x658b87;
  puVar5 = (undefined4 *)FUN_016830f0();
  pppppiStack_bc = *(int ******)(param_1 + 0x44);
  *(undefined4 *)(param_1 + 0x68) = *puVar5;
  *(undefined4 *)(param_1 + 0x6c) = puVar5[1];
  pppppiStack_c0 = (int *****)0x658ba0;
  FUN_0054ef60();
  ppppppiVar9 = (int ******)apppppiStack_3c[0];
  ppppppiVar7 = (int ******)(param_1 + 0x48);
  pppppiStack_c0 = (int *****)apppppiStack_3c;
  if (0xf < uStack_28) {
    pppppiStack_c0 = apppppiStack_3c[0];
  }
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  pppppiStack_c8 = (int *****)ppppppiVar7;
  if (0xf < *(uint *)(param_1 + 0x5c)) {
    pppppiStack_c8 = *ppppppiVar7;
  }
  pppppiStack_bc = (int *****)uStack_2c;
  iStack_c4 = *(int *)(param_1 + 0x58);
  cVar3 = FUN_0055c360();
  if (cVar3 == '\0') {
    if (ppppppiVar7 != apppppiStack_3c) {
      pppppiStack_bc = (int *****)uStack_2c;
      pppppiStack_c0 = (int *****)apppppiStack_3c;
      if (0xf < uStack_28) {
        pppppiStack_c0 = (int *****)ppppppiVar9;
      }
      iStack_c4 = 0x658bf2;
      FUN_005542c0();
    }
    iVar1 = *(int *)(param_1 + 0x3c);
    iVar8 = *(int *)(param_1 + 0x38);
    if (iVar8 != iVar1) {
      do {
        pppppiStack_bc = (int *****)0x658c07;
        FUN_00651cc0();
        iVar8 = iVar8 + 0x38;
      } while (iVar8 != iVar1);
      iVar8 = *(int *)(param_1 + 0x38);
    }
    pppppiStack_bc = (int *****)(param_1 + 0x48);
    *(int *)(param_1 + 0x3c) = iVar8;
    pppppiStack_c0 = (int *****)apppppiStack_54;
    iStack_c4 = 0x658c24;
    FUN_0065a090();
    uStack_8._0_1_ = 1;
    if (iStack_44 != 0) {
      pppppiStack_18 = (int *****)0x0;
      uStack_14 = 0;
      pppppiStack_bc = (int *****)0x658c4b;
      pppppiStack_18 = (int *****)FUN_00575b30();
      pppppiStack_bc = (int *****)0x1;
      uStack_8._0_1_ = 2;
      FUN_0064f1d0(&pppppiStack_c8,param_1 + 0x70);
      FUN_0064f970(&pppppiStack_18,apppppiStack_54);
      pppppiVar2 = pppppiStack_18;
      pppppiStack_1c = (int *****)*pppppiStack_18;
      ppppppiVar7 = (int ******)pppppiStack_18;
      while (pppppiStack_18 = (int *****)ppppppiVar7, pppppiStack_1c != pppppiVar2) {
        pppppiStack_bc = (int *****)((int ******)pppppiStack_1c + 4);
        pppppiStack_c0 = (int *****)0x658c92;
        FUN_0054ef60();
        pppppiStack_bc = (int *****)0x1;
        uStack_8._0_1_ = 4;
        pppppiStack_c0 = (int *****)0x658c9d;
        piVar6 = (int *)FUN_016de181();
        puStack_20 = (undefined *)&iStack_c4;
        iStack_c4 = CONCAT22(iStack_c4._2_2_,0x48);
        uStack_8._0_1_ = 6;
        pppppiStack_c8 = (int *****)0x658cc0;
        pppppiStack_bc = (int *****)piVar6;
        (**(code **)(*piVar6 + 4))();
        pppppiStack_c8 = (int *****)apppppiStack_6c;
        uStack_8._0_1_ = 5;
        FUN_0064fad0();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        pppppiStack_bc = (int *****)0x658cdb;
        puVar5 = (undefined4 *)(**(code **)(*piVar6 + 8))();
        if (puVar5 != (undefined4 *)0x0) {
          pppppiStack_bc = (int *****)0x1;
          pppppiStack_c0 = (int *****)0x658ce9;
          (**(code **)*puVar5)();
        }
        uStack_8._0_1_ = 3;
        if (iStack_5c != 0) {
          pppppiStack_bc = (int *****)apppppiStack_6c;
          pppppiStack_c0 = (int *****)0x658d02;
          pppppiStack_bc = (int *****)FUN_00650b60();
          pppppiStack_c0 = *(int ******)(param_1 + 0x3c);
          uStack_8._0_1_ = 8;
          if (*(int *******)(param_1 + 0x40) == (int ******)pppppiStack_c0) {
            iStack_c4 = 0x658d26;
            FUN_0064c2a0();
          }
          else {
            pppppiStack_c8 = (int *****)0x658d16;
            iStack_c4 = param_1 + 0x38;
            FUN_0064e2a0();
            *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 0x38;
          }
          pppppiStack_bc = (int *****)0x658d31;
          FUN_00651cc0();
        }
        uStack_8._0_1_ = 2;
        if (0xf < uStack_58) {
          pppppiStack_bc = (int *****)(uStack_58 + 1);
          ppppppiVar7 = (int ******)apppppiStack_6c[0];
          if (0xfff < pppppiStack_bc) {
            ppppppiVar7 = (int ******)apppppiStack_6c[0][-1];
            pppppiStack_bc = (int *****)(uStack_58 + 0x24);
            if (0x1f < (uint)((int)apppppiStack_6c[0] + (-4 - (int)ppppppiVar7))) goto LAB_00658e38;
          }
          iStack_c4 = 0x658d66;
          pppppiStack_c0 = (int *****)ppppppiVar7;
          FUN_01674ea0();
        }
        pppppiStack_bc = (int *****)0x658d71;
        FUN_00551320();
        ppppppiVar7 = (int ******)pppppiStack_18;
      }
      pppppiStack_bc = ppppppiVar7[1];
      uStack_8._0_1_ = 9;
      pppppiStack_c0 = (int *****)0x658d8e;
      FUN_00576720();
      pppppiStack_bc = (int *****)0x28;
      pppppiStack_18[1] = (int ****)ppppppiVar7;
      *pppppiStack_18 = (int ****)ppppppiVar7;
      pppppiStack_18[2] = (int ****)ppppppiVar7;
      pppppiStack_c0 = pppppiStack_18;
      uStack_14 = 0;
      iStack_c4 = 0x658db0;
      FUN_01674ea0();
    }
    if (0xf < uStack_40) {
      pppppiStack_bc = (int *****)(uStack_40 + 1);
      ppppppiVar7 = (int ******)apppppiStack_54[0];
      if (0xfff < pppppiStack_bc) {
        ppppppiVar7 = (int ******)apppppiStack_54[0][-1];
        pppppiStack_bc = (int *****)(uStack_40 + 0x24);
        if (0x1f < (uint)((int)apppppiStack_54[0] + (-4 - (int)ppppppiVar7))) {
LAB_00658e38:
                    /* WARNING: Subroutine does not return */
          pppppiStack_bc = (int *****)0x658e3d;
          FUN_017167a3();
        }
      }
      iStack_c4 = 0x658de0;
      pppppiStack_c0 = (int *****)ppppppiVar7;
      FUN_01674ea0();
    }
    iStack_44 = 0;
    uStack_40 = 0xf;
    apppppiStack_54[0] = (int *****)((uint)apppppiStack_54[0] & 0xffffff00);
    ppppppiVar9 = (int ******)apppppiStack_3c[0];
  }
  if (0xf < uStack_28) {
    pppppiStack_bc = (int *****)(uStack_28 + 1);
    ppppppiVar7 = ppppppiVar9;
    if (0xfff < pppppiStack_bc) {
      ppppppiVar7 = (int ******)ppppppiVar9[-1];
      pppppiStack_bc = (int *****)(uStack_28 + 0x24);
      if (0x1f < (uint)((int)ppppppiVar9 + (-4 - (int)ppppppiVar7))) {
                    /* WARNING: Subroutine does not return */
        pppppiStack_bc = (int *****)&UNK_00658e42;
        FUN_017167a3();
      }
    }
    iStack_c4 = 0x658e24;
    pppppiStack_c0 = (int *****)ppppppiVar7;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7561 ; VA 0x00658e50 ; FUN_00658e50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00658e50(int param_1)

{
  int *****pppppiVar1;
  int *****pppppiVar2;
  int *****pppppiVar3;
  char cVar4;
  double *pdVar5;
  undefined4 *puVar6;
  int *piVar7;
  int ******ppppppiVar8;
  int *****pppppiStack_a8;
  undefined4 uStack_a4;
  int *****pppppiStack_a0;
  int *****pppppiStack_9c;
  int *****pppppiStack_90;
  uint uStack_7c;
  int *****apppppiStack_78 [4];
  int iStack_68;
  uint uStack_64;
  int *****apppppiStack_60 [4];
  int iStack_50;
  uint uStack_4c;
  int *****apppppiStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int *piStack_2c;
  int *****pppppiStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  undefined *puStack_1c;
  int *****pppppiStack_18;
  int *****pppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1cd3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((NAN(*(double *)(param_1 + 0x68)) || NAN(_PTR_018c6f48)) ==
      (*(double *)(param_1 + 0x68) == _PTR_018c6f48)) {
    pppppiStack_9c = (int *****)auStack_20;
    pppppiStack_a0 = (int *****)0x658e8e;
    ExceptionList = &pvStack_10;
    pdVar5 = (double *)FUN_016830f0();
    if (*pdVar5 - *(double *)(param_1 + 0x68) < (double)*(int *)(param_1 + 0x60)) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  pppppiStack_9c = (int *****)auStack_20;
  pppppiStack_a0 = (int *****)0x658eb6;
  puVar6 = (undefined4 *)FUN_016830f0();
  pppppiStack_9c = *(int ******)(param_1 + 0x44);
  *(undefined4 *)(param_1 + 0x68) = *puVar6;
  *(undefined4 *)(param_1 + 0x6c) = puVar6[1];
  pppppiStack_a0 = (int *****)0x658ecf;
  FUN_0054ef60();
  ppppppiVar8 = (int ******)(param_1 + 0x48);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  pppppiStack_a0 = (int *****)apppppiStack_48;
  if (0xf < uStack_34) {
    pppppiStack_a0 = apppppiStack_48[0];
  }
  pppppiStack_a8 = (int *****)ppppppiVar8;
  if (0xf < *(uint *)(param_1 + 0x5c)) {
    pppppiStack_a8 = *ppppppiVar8;
  }
  pppppiStack_9c = (int *****)uStack_38;
  uStack_a4 = *(undefined4 *)(param_1 + 0x58);
  cVar4 = FUN_0055c360();
  if (cVar4 == '\0') {
    if (ppppppiVar8 != apppppiStack_48) {
      pppppiStack_9c = (int *****)uStack_38;
      pppppiStack_a0 = (int *****)apppppiStack_48;
      if (0xf < uStack_34) {
        pppppiStack_a0 = apppppiStack_48[0];
      }
      uStack_a4 = 0x658f20;
      FUN_005542c0();
    }
    puVar6 = (undefined4 *)(param_1 + 0x38);
    pppppiStack_a0 = *(int ******)(param_1 + 0x3c);
    uStack_a4 = *puVar6;
    pppppiStack_a8 = (int *****)0x658f2e;
    pppppiStack_9c = (int *****)puVar6;
    FUN_00559570();
    *(undefined4 *)(param_1 + 0x3c) = *puVar6;
    pppppiStack_a8 = (int *****)(param_1 + 0x48);
    FUN_0065a090(apppppiStack_60);
    uStack_8._0_1_ = 1;
    if (iStack_50 != 0) {
      pppppiStack_28 = (int *****)0x0;
      uStack_24 = 0;
      pppppiStack_9c = (int *****)0x658f67;
      pppppiStack_28 = (int *****)FUN_00575b30();
      pppppiStack_9c = (int *****)0x1;
      uStack_8._0_1_ = 2;
      FUN_0064f1d0(&pppppiStack_a8,param_1 + 0x70);
      FUN_0064f970(&pppppiStack_28,apppppiStack_60);
      pppppiStack_18 = pppppiStack_28;
      pppppiStack_14 = (int *****)*pppppiStack_28;
      if (pppppiStack_14 != pppppiStack_28) {
        do {
          pppppiStack_9c = pppppiStack_14 + 4;
          pppppiStack_a0 = (int *****)0x658fb1;
          FUN_0054ef60();
          pppppiStack_9c = (int *****)0x1;
          uStack_8._0_1_ = 4;
          pppppiStack_a0 = (int *****)0x658fbc;
          piVar7 = (int *)FUN_016de181();
          puStack_1c = (undefined *)&uStack_a4;
          uStack_a4 = CONCAT22(uStack_a4._2_2_,0x48);
          uStack_8._0_1_ = 6;
          pppppiStack_a8 = (int *****)0x658fdf;
          pppppiStack_9c = (int *****)piVar7;
          piStack_2c = piVar7;
          (**(code **)(*piVar7 + 4))();
          pppppiStack_a8 = (int *****)apppppiStack_78;
          uStack_8._0_1_ = 5;
          FUN_0064fad0();
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          pppppiStack_9c = (int *****)0x658ffc;
          puVar6 = (undefined4 *)(**(code **)(*piVar7 + 8))();
          if (puVar6 != (undefined4 *)0x0) {
            pppppiStack_9c = (int *****)0x1;
            pppppiStack_a0 = (int *****)0x65900a;
            (**(code **)*puVar6)();
          }
          uStack_8._0_1_ = 3;
          if (iStack_68 != 0) {
            pppppiStack_9c = (int *****)apppppiStack_78;
            pppppiStack_a0 = (int *****)0x659027;
            pppppiStack_9c = (int *****)FUN_0054ef60();
            ppppppiVar8 = *(int *******)(param_1 + 0x3c);
            uStack_8._0_1_ = 8;
            if (*(int *******)(param_1 + 0x40) == ppppppiVar8) {
              uStack_a4 = 0x659071;
              pppppiStack_a0 = (int *****)ppppppiVar8;
              FUN_0058d0a0();
            }
            else {
              ppppppiVar8[4] = (int *****)0x0;
              ppppppiVar8[5] = (int *****)0x0;
              pppppiVar1 = (int *****)((int *)pppppiStack_9c)[1];
              pppppiVar2 = (int *****)((int *)pppppiStack_9c)[2];
              pppppiVar3 = (int *****)((int *)pppppiStack_9c)[3];
              *ppppppiVar8 = (int *****)*pppppiStack_9c;
              ppppppiVar8[1] = pppppiVar1;
              ppppppiVar8[2] = pppppiVar2;
              ppppppiVar8[3] = pppppiVar3;
              *(undefined8 *)(ppppppiVar8 + 4) = *(undefined8 *)((int *)pppppiStack_9c + 4);
              ((int *)pppppiStack_9c)[4] = 0;
              ((int *)pppppiStack_9c)[5] = 0xf;
              *(undefined *)pppppiStack_9c = 0;
              *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 0x18;
            }
            uStack_8._0_1_ = 3;
            if (0xf < uStack_7c) {
              pppppiStack_9c = (int *****)(uStack_7c + 1);
              ppppppiVar8 = (int ******)pppppiStack_90;
              if (0xfff < pppppiStack_9c) {
                ppppppiVar8 = (int ******)pppppiStack_90[-1];
                pppppiStack_9c = (int *****)(uStack_7c + 0x24);
                if (0x1f < (uint)((int)pppppiStack_90 + (-4 - (int)ppppppiVar8))) goto LAB_006591b3;
              }
              uStack_a4 = 0x6590a9;
              pppppiStack_a0 = (int *****)ppppppiVar8;
              FUN_01674ea0();
            }
          }
          uStack_8._0_1_ = 2;
          if (0xf < uStack_64) {
            pppppiStack_9c = (int *****)(uStack_64 + 1);
            ppppppiVar8 = (int ******)apppppiStack_78[0];
            if (0xfff < pppppiStack_9c) {
              ppppppiVar8 = (int ******)apppppiStack_78[0][-1];
              pppppiStack_9c = (int *****)(uStack_64 + 0x24);
              if (0x1f < (uint)((int)apppppiStack_78[0] + (-4 - (int)ppppppiVar8)))
              goto LAB_006591b3;
            }
            uStack_a4 = 0x6590e1;
            pppppiStack_a0 = (int *****)ppppppiVar8;
            FUN_01674ea0();
          }
          pppppiStack_9c = (int *****)0x6590ec;
          FUN_00551320();
        } while (pppppiStack_14 != pppppiStack_18);
      }
      pppppiVar1 = pppppiStack_28;
      pppppiStack_9c = (int *****)pppppiStack_28[1];
      uStack_8._0_1_ = 9;
      pppppiStack_a0 = (int *****)0x65910a;
      FUN_00576720();
      pppppiStack_9c = (int *****)0x28;
      pppppiStack_28[1] = (int ****)pppppiVar1;
      *pppppiStack_28 = (int ****)pppppiVar1;
      pppppiStack_28[2] = (int ****)pppppiVar1;
      pppppiStack_a0 = pppppiStack_28;
      uStack_24 = 0;
      uStack_a4 = 0x65912c;
      FUN_01674ea0();
    }
    if (0xf < uStack_4c) {
      pppppiStack_9c = (int *****)(uStack_4c + 1);
      ppppppiVar8 = (int ******)apppppiStack_60[0];
      if (0xfff < pppppiStack_9c) {
        ppppppiVar8 = (int ******)apppppiStack_60[0][-1];
        pppppiStack_9c = (int *****)(uStack_4c + 0x24);
        if (0x1f < (uint)((int)apppppiStack_60[0] + (-4 - (int)ppppppiVar8))) {
LAB_006591b3:
                    /* WARNING: Subroutine does not return */
          pppppiStack_9c = (int *****)0x6591b8;
          FUN_017167a3();
        }
      }
      uStack_a4 = 0x65915c;
      pppppiStack_a0 = (int *****)ppppppiVar8;
      FUN_01674ea0();
    }
    iStack_50 = 0;
    uStack_4c = 0xf;
    apppppiStack_60[0] = (int *****)((uint)apppppiStack_60[0] & 0xffffff00);
  }
  if (0xf < uStack_34) {
    pppppiStack_9c = (int *****)(uStack_34 + 1);
    ppppppiVar8 = (int ******)apppppiStack_48[0];
    if (0xfff < pppppiStack_9c) {
      ppppppiVar8 = (int ******)apppppiStack_48[0][-1];
      pppppiStack_9c = (int *****)(uStack_34 + 0x24);
      if (0x1f < (uint)((int)apppppiStack_48[0] + (-4 - (int)ppppppiVar8))) {
                    /* WARNING: Subroutine does not return */
        pppppiStack_9c = (int *****)&UNK_006591bd;
        FUN_017167a3();
      }
    }
    uStack_a4 = 0x6591a0;
    pppppiStack_a0 = (int *****)ppppppiVar8;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7562 ; VA 0x006591c0 ; FUN_006591c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_006591c0(int param_1)

{
  int *****pppppiVar1;
  char cVar2;
  double *pdVar3;
  undefined4 *puVar4;
  int *piVar5;
  int ******ppppppiVar6;
  int ******ppppppiVar7;
  int *****pppppiStack_94;
  undefined4 uStack_90;
  int *****pppppiStack_8c;
  int *****pppppiStack_88;
  int *****apppppiStack_78 [4];
  int iStack_68;
  uint uStack_64;
  int *****apppppiStack_60 [4];
  int iStack_50;
  uint uStack_4c;
  int *****apppppiStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int *piStack_2c;
  int ****ppppiStack_28;
  int ****ppppiStack_24;
  int *****pppppiStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  int *****pppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((NAN(*(double *)(param_1 + 0x68)) || NAN(_PTR_018c6f48)) ==
      (*(double *)(param_1 + 0x68) == _PTR_018c6f48)) {
    pppppiStack_88 = &ppppiStack_28;
    pppppiStack_8c = (int *****)0x6591fc;
    ExceptionList = &pvStack_10;
    pdVar3 = (double *)FUN_016830f0();
    if (*pdVar3 - *(double *)(param_1 + 0x68) < (double)*(int *)(param_1 + 0x60)) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  pppppiStack_88 = &ppppiStack_28;
  pppppiStack_8c = (int *****)0x659224;
  puVar4 = (undefined4 *)FUN_016830f0();
  pppppiStack_88 = *(int ******)(param_1 + 0x44);
  *(undefined4 *)(param_1 + 0x68) = *puVar4;
  *(undefined4 *)(param_1 + 0x6c) = puVar4[1];
  pppppiStack_8c = (int *****)0x65923d;
  FUN_0054ef60();
  ppppppiVar7 = (int ******)apppppiStack_48[0];
  ppppppiVar6 = (int ******)(param_1 + 0x48);
  pppppiStack_8c = (int *****)apppppiStack_48;
  if (0xf < uStack_34) {
    pppppiStack_8c = apppppiStack_48[0];
  }
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  pppppiStack_94 = (int *****)ppppppiVar6;
  if (0xf < *(uint *)(param_1 + 0x5c)) {
    pppppiStack_94 = *ppppppiVar6;
  }
  pppppiStack_88 = (int *****)uStack_38;
  uStack_90 = *(undefined4 *)(param_1 + 0x58);
  cVar2 = FUN_0055c360();
  if (cVar2 == '\0') {
    if (ppppppiVar6 != apppppiStack_48) {
      pppppiStack_88 = (int *****)uStack_38;
      pppppiStack_8c = (int *****)apppppiStack_48;
      if (0xf < uStack_34) {
        pppppiStack_8c = (int *****)ppppppiVar7;
      }
      uStack_90 = 0x65928f;
      FUN_005542c0();
    }
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x38);
    pppppiStack_8c = (int *****)apppppiStack_60;
    uStack_90 = 0x6592a2;
    pppppiStack_88 = (int *****)ppppppiVar6;
    FUN_0065a090();
    uStack_8._0_1_ = 1;
    if (iStack_50 != 0) {
      pppppiStack_20 = (int *****)0x0;
      uStack_1c = 0;
      pppppiStack_88 = (int *****)0x6592c9;
      pppppiStack_20 = (int *****)FUN_00575b30();
      pppppiStack_88 = (int *****)0x1;
      uStack_8._0_1_ = 2;
      FUN_0064f1d0(&pppppiStack_94,param_1 + 0x70);
      FUN_0064f970(&pppppiStack_20,apppppiStack_60);
      pppppiVar1 = pppppiStack_20;
      pppppiStack_14 = (int *****)*pppppiStack_20;
      ppppppiVar6 = (int ******)pppppiStack_20;
      while (pppppiStack_20 = (int *****)ppppppiVar6, pppppiStack_14 != pppppiVar1) {
        pppppiStack_88 = (int *****)((int ******)pppppiStack_14 + 4);
        pppppiStack_8c = (int *****)0x659310;
        FUN_0054ef60();
        pppppiStack_88 = (int *****)0x1;
        uStack_8._0_1_ = 4;
        pppppiStack_8c = (int *****)0x65931b;
        piVar5 = (int *)FUN_016de181();
        puStack_18 = (undefined *)&uStack_90;
        uStack_90 = CONCAT22(uStack_90._2_2_,0x48);
        uStack_8._0_1_ = 6;
        pppppiStack_94 = (int *****)0x65933e;
        pppppiStack_88 = (int *****)piVar5;
        piStack_2c = piVar5;
        (**(code **)(*piVar5 + 4))();
        pppppiStack_94 = (int *****)apppppiStack_78;
        uStack_8._0_1_ = 5;
        FUN_0064fad0();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        pppppiStack_88 = (int *****)0x659359;
        puVar4 = (undefined4 *)(**(code **)(*piVar5 + 8))();
        if (puVar4 != (undefined4 *)0x0) {
          pppppiStack_88 = (int *****)0x1;
          pppppiStack_8c = (int *****)0x659367;
          (**(code **)*puVar4)();
        }
        uStack_8._0_1_ = 3;
        if (iStack_68 != 0) {
          pppppiStack_88 = (int *****)apppppiStack_78;
          pppppiStack_8c = &ppppiStack_28;
          uStack_90 = 0x659380;
          FUN_006615e0();
          ppppppiVar6 = *(int *******)(param_1 + 0x3c);
          if (*(int *******)(param_1 + 0x40) == ppppppiVar6) {
            pppppiStack_88 = &ppppiStack_28;
            uStack_90 = 0x6593a5;
            pppppiStack_8c = (int *****)ppppppiVar6;
            FUN_0064c050();
          }
          else {
            *ppppppiVar6 = (int *****)ppppiStack_28;
            ppppppiVar6[1] = (int *****)ppppiStack_24;
            *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 8;
          }
        }
        uStack_8._0_1_ = 2;
        if (0xf < uStack_64) {
          pppppiStack_88 = (int *****)(uStack_64 + 1);
          ppppppiVar6 = (int ******)apppppiStack_78[0];
          if (0xfff < pppppiStack_88) {
            ppppppiVar6 = (int ******)apppppiStack_78[0][-1];
            pppppiStack_88 = (int *****)(uStack_64 + 0x24);
            if (0x1f < (uint)((int)apppppiStack_78[0] + (-4 - (int)ppppppiVar6))) goto LAB_006594ac;
          }
          uStack_90 = 0x6593da;
          pppppiStack_8c = (int *****)ppppppiVar6;
          FUN_01674ea0();
        }
        pppppiStack_88 = (int *****)0x6593e5;
        FUN_00551320();
        ppppppiVar6 = (int ******)pppppiStack_20;
      }
      pppppiStack_88 = ppppppiVar6[1];
      uStack_8._0_1_ = 8;
      pppppiStack_8c = (int *****)0x659402;
      FUN_00576720();
      pppppiStack_88 = (int *****)0x28;
      pppppiStack_20[1] = (int ****)ppppppiVar6;
      *pppppiStack_20 = (int ****)ppppppiVar6;
      pppppiStack_20[2] = (int ****)ppppppiVar6;
      pppppiStack_8c = pppppiStack_20;
      uStack_1c = 0;
      uStack_90 = 0x659424;
      FUN_01674ea0();
    }
    if (0xf < uStack_4c) {
      pppppiStack_88 = (int *****)(uStack_4c + 1);
      ppppppiVar6 = (int ******)apppppiStack_60[0];
      if (0xfff < pppppiStack_88) {
        ppppppiVar6 = (int ******)apppppiStack_60[0][-1];
        pppppiStack_88 = (int *****)(uStack_4c + 0x24);
        if (0x1f < (uint)((int)apppppiStack_60[0] + (-4 - (int)ppppppiVar6))) {
LAB_006594ac:
                    /* WARNING: Subroutine does not return */
          pppppiStack_88 = (int *****)0x6594b1;
          FUN_017167a3();
        }
      }
      uStack_90 = 0x659454;
      pppppiStack_8c = (int *****)ppppppiVar6;
      FUN_01674ea0();
    }
    iStack_50 = 0;
    uStack_4c = 0xf;
    apppppiStack_60[0] = (int *****)((uint)apppppiStack_60[0] & 0xffffff00);
    ppppppiVar7 = (int ******)apppppiStack_48[0];
  }
  if (0xf < uStack_34) {
    pppppiStack_88 = (int *****)(uStack_34 + 1);
    ppppppiVar6 = ppppppiVar7;
    if (0xfff < pppppiStack_88) {
      ppppppiVar6 = (int ******)ppppppiVar7[-1];
      pppppiStack_88 = (int *****)(uStack_34 + 0x24);
      if (0x1f < (uint)((int)ppppppiVar7 + (-4 - (int)ppppppiVar6))) {
                    /* WARNING: Subroutine does not return */
        pppppiStack_88 = (int *****)&UNK_006594b6;
        FUN_017167a3();
      }
    }
    uStack_90 = 0x659498;
    pppppiStack_8c = (int *****)ppppppiVar6;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7563 ; VA 0x006594c0 ; FUN_006594c0 */

undefined4 __fastcall FUN_006594c0(int *param_1)

{
  undefined uVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1d38;
  pvStack_10 = ExceptionList;
  if (((DAT_01d59b70 == '\0') || (DAT_01d5a9e0 == '\0')) || (param_1[0xfbe] == -0x206aca7f)) {
    if ((param_1[0xfbb] == -0x18b424a5) ||
       (ExceptionList = &pvStack_10, param_1[0xfbb] == -0x6c72d79)) {
      uStack_14 = CONCAT31(uStack_14._1_3_,param_1[0xfbc] == 0x644bcfdd);
      ExceptionList = &pvStack_10;
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8 = 0;
      puVar3 = (undefined4 *)FUN_006b1620(auStack_2c,param_1 + 0x1d,1,0x7c);
      iStack_8._0_1_ = 1;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_0151f850("clientIp",puVar3);
      iStack_8._0_1_ = 0;
      uVar1 = (undefined)iStack_8;
      iStack_8._0_1_ = 0;
      if (0xf < uStack_18) {
        uVar7 = uStack_18 + 1;
        uVar6 = auStack_2c[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_2c[0] - 4);
          uVar7 = uStack_18 + 0x24;
          if (0x1f < (auStack_2c[0] - uVar6) - 4) {
            iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      FUN_0151fbb0("userId",param_1[0xf64],param_1[0xf65]);
      FUN_0151fcf0("studio",uStack_14);
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = auStack_2c[0] & 0xffffff00;
      FUN_005542c0("DevLogin",8);
      iStack_8._0_1_ = 2;
      FUN_01520d20(auStack_2c,10000,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_18) {
        uVar7 = uStack_18 + 1;
        uVar6 = auStack_2c[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_2c[0] - 4);
          uVar7 = uStack_18 + 0x24;
          if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = auStack_2c[0] & 0xffffff00;
      if ((param_1[0xfbb] == -0x18b424a5) || (DAT_01d5a4c0 == '\0')) {
        FUN_0151f7f0();
        ExceptionList = pvStack_10;
        return 0;
      }
      iStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    if ((param_1[0xfbc] == 0x557bb5d7) ||
       ((param_1[0xfbc] == 0x644bcfdd &&
        ((param_1[0xfbb] == 0x4beda921 || (param_1[0xfbb] == 0x752fab0b)))))) {
      cVar2 = (**(code **)(*param_1 + 0x124))();
      if ((param_1[0xfbc] == 0x644bcfdd) == (bool)cVar2) {
        if (param_1[0xfbc] == 0x557bb5d7) {
          iVar4 = FUN_0065b470();
          if ((*(byte *)((int)param_1 + 0x3d72) & 8) == 0) {
            uVar6 = param_1[0xfbd] >> 4;
          }
          else {
            uVar6 = (uint)param_1[0xfbd] >> 1 & 0x7fff;
          }
          if (DAT_01d5a584 < iVar4) {
            ExceptionList = pvStack_10;
            return 2;
          }
          uVar7 = param_1[0xfbb];
          if (uVar7 < 0x71375636) {
            if (uVar7 == 0x71375635) {
              if ((int)uVar6 < DAT_01ead7bc) {
                ExceptionList = pvStack_10;
                return 1;
              }
            }
            else if (uVar7 == 0xc57b823) {
              if ((int)uVar6 < DAT_01ead7c0) {
                ExceptionList = pvStack_10;
                return 1;
              }
            }
            else if (uVar7 == 0x443921d5) {
              if ((int)uVar6 < DAT_01ead7c4) {
                ExceptionList = pvStack_10;
                return 1;
              }
            }
            else {
              if (uVar7 != 0x4beda921) goto LAB_006597d5;
              if ((int)uVar6 < DAT_01ead7d0) {
                ExceptionList = pvStack_10;
                return 1;
              }
            }
          }
          else if (uVar7 == 0x752fab0b) {
            if ((int)uVar6 < DAT_01ead7cc) {
              ExceptionList = pvStack_10;
              return 1;
            }
          }
          else {
            if (uVar7 != 0x9d49834b) {
LAB_006597d5:
              uVar5 = 2;
              if (DAT_01d5a4c0 != '\0') {
                uVar5 = 0;
              }
              ExceptionList = pvStack_10;
              return uVar5;
            }
            if ((int)uVar6 < DAT_01ead7c8) {
              ExceptionList = pvStack_10;
              return 1;
            }
          }
        }
        ExceptionList = pvStack_10;
        return 0;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 2;
}



/* FUNCTION 7564 ; VA 0x00659850 ; FUN_00659850 */

undefined4 FUN_00659850(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  char *pcVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_8 = 0;
  switch(param_2) {
  case 2:
    uVar3 = 8;
    pcVar2 = "[Roblox]";
    break;
  case 3:
    uVar3 = 8;
    pcVar2 = "[WinDir]";
    break;
  case 4:
    uVar3 = 8;
    pcVar2 = "[System]";
    break;
  case 5:
    uVar3 = 0xe;
    pcVar2 = "[ProgramFiles]";
    break;
  default:
    goto switchD_006598a0_caseD_6;
  case 7:
    uVar3 = 0xd;
    pcVar2 = "[UserProfile]";
    break;
  case 8:
    uVar3 = 0xd;
    pcVar2 = "[UserAppData]";
    break;
  case 9:
    uVar3 = 0xd;
    pcVar2 = "[UserDesktop]";
    break;
  case 10:
    uVar3 = 0xf;
    pcVar2 = "[UserDownloads]";
    break;
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    uVar3 = 6;
    pcVar2 = "[Temp]";
  }
  FUN_005542c0(pcVar2,uVar3);
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_00554150(param_3,*puVar1);
switchD_006598a0_caseD_6:
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7565 ; VA 0x00659960 ; FUN_00659960 */

undefined4 __thiscall FUN_00659960(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1d58;
  pvStack_10 = ExceptionList;
  uStack_1c = *param_2;
  piVar1 = param_1 + 2;
  ExceptionList = &pvStack_10;
  uStack_18 = uStack_1c;
  piStack_14 = piVar1;
  iVar3 = FUN_016dee6d(piVar1);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  uStack_8 = 0;
  FUN_006591c0();
  iVar3 = param_1[0xf];
  iVar4 = param_1[0xe];
  while( true ) {
    if (iVar4 == iVar3) {
      uStack_8 = 2;
      iVar3 = FUN_016deec8(piVar1);
      if (iVar3 != 0) {
        FUN_016df3c9(iVar3);
      }
      ExceptionList = pvStack_10;
      return 0;
    }
    cVar2 = (**(code **)(*param_1 + 4))(&uStack_1c,iVar4);
    if (cVar2 != '\0') break;
    iVar4 = iVar4 + 8;
  }
  uStack_8 = 1;
  iVar3 = FUN_016deec8(piVar1);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 7566 ; VA 0x00659a40 ; FUN_00659a40 */

uint __thiscall FUN_00659a40(int *param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint in_EAX;
  int iVar4;
  
  iVar2 = *param_1;
  if (iVar2 != param_1[1]) {
    iVar1 = iVar2;
    iVar4 = param_1[1] - iVar2 >> 3;
    while (iVar3 = iVar4, 0 < iVar3) {
      iVar4 = iVar3 >> 1;
      in_EAX = iVar1 + iVar4 * 8;
      if (*(uint *)(iVar1 + iVar4 * 8) <= param_2) {
        iVar1 = in_EAX + 8;
        in_EAX = -iVar4 - 1;
        iVar4 = iVar3 + in_EAX;
      }
    }
    if ((((iVar1 != iVar2) && (in_EAX = *(uint *)(iVar1 + -8), in_EAX <= param_2)) &&
        (param_2 <= *(uint *)(iVar1 + -4))) && ((in_EAX != *(uint *)(iVar1 + -4) || (in_EAX != 0))))
    {
      return CONCAT31((int3)(in_EAX >> 8),1);
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 7567 ; VA 0x00659ab0 ; FUN_00659ab0 */

undefined4 __thiscall FUN_00659ab0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  
  if (DAT_01d5acf0 == '\0') {
    uVar1 = *(undefined4 *)(param_1 + 0x78);
  }
  else {
    uVar1 = FUN_005f77e0();
  }
  uVar2 = Ordinal_14(uVar1);
  if (DAT_01d5a7d8 < 0x20) {
    iVar3 = DAT_01d5a7d8;
    if (DAT_01d5a7d8 < 0x19) {
      iVar3 = 0x18;
    }
  }
  else {
    iVar3 = 0x20;
  }
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_01675640(param_2,"%s_%x",param_3,*(uint *)(&UNK_018d0948 + iVar3 * 4) & uVar2);
  return param_2;
}



/* FUNCTION 7568 ; VA 0x00659b20 ; FUN_00659b20 */

undefined4 FUN_00659b20(undefined4 param_1,undefined4 *param_2,uint param_3)

{
  int iVar1;
  
  if (DAT_01d5a7d8 < 0x20) {
    iVar1 = DAT_01d5a7d8;
    if (DAT_01d5a7d8 < 0x19) {
      iVar1 = 0x18;
    }
  }
  else {
    iVar1 = 0x20;
  }
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_01675640(param_1,"%s_%x",param_2,param_3 & *(uint *)(&UNK_018d0948 + iVar1 * 4));
  return param_1;
}



/* FUNCTION 7569 ; VA 0x00659b70 ; FUN_00659b70 */

void __thiscall FUN_00659b70(int *param_1,uint *param_2)

{
  int *piVar1;
  uint *puVar2;
  double dVar3;
  short sVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  double dVar8;
  double dVar9;
  double dVar10;
  double dStack_c;
  
  uVar7 = (int)(param_2[2] - param_2[1]) >> 2;
  if (DAT_01d5a060 != '\0') {
    iVar5 = FUN_006a6900();
    iVar5 = iVar5 - param_1[0x41e];
    dStack_c = (double)iVar5;
    sVar4 = FUN_017265ed(&dStack_c);
    if (sVar4 < 1) {
      dVar3 = *(double *)(param_1 + 0x43c);
      dVar10 = DAT_018c0d60 - dVar3;
      dVar8 = (double)iVar5;
      dVar9 = dVar8;
      if (*(char *)(param_1 + 0x444) == '\0') {
        dVar9 = *(double *)(param_1 + 0x440) * dVar10 + dVar8 * dVar3;
      }
      param_1[0x43e] = iVar5;
      *(double *)(param_1 + 0x440) = dVar9;
      *(undefined *)(param_1 + 0x444) = 0;
      *(double *)(param_1 + 0x442) =
           (dVar8 - dVar9) * (dVar8 - dVar9) * dVar3 + *(double *)(param_1 + 0x442) * dVar10;
    }
    if (param_1[0x446] < iVar5) {
      param_1[0x446] = iVar5;
    }
    if (iVar5 < param_1[0x447]) {
      param_1[0x447] = iVar5;
    }
  }
  iVar5 = FUN_006a6900();
  param_1[0xfa2] = param_1[0xfa2] + 1;
  param_1[0x41e] = iVar5;
  param_1[0x41f] = 0;
  if (((byte)uVar7 < 0x26) ||
     ((uVar7 = uVar7 & 0xff, *(char *)(param_1 + 0xf6b) != '\0' &&
      (uVar7 != param_1[0xf69] - param_1[0xf68] >> 2)))) {
    (**(code **)(*param_1 + 0x290))("jesper",0xc,1,"WrongNumberHashes",0);
    FUN_0087c450(&DAT_018c5f98,"SecurityException","invalid number of hashes",0,0,0);
  }
  else {
    for (iVar5 = uVar7 - 2; iVar5 != 0; iVar5 = iVar5 + -1) {
      puVar2 = (uint *)(param_2[1] + iVar5 * 4);
      *puVar2 = *puVar2 ^ *(uint *)((param_2[1] - 4) + iVar5 * 4);
    }
    *(uint *)param_2[1] = *(uint *)param_2[1] ^ *param_2;
    *param_2 = *param_2 ^ *(uint *)((param_2[1] - 4) + uVar7 * 4);
    uVar7 = param_2[2];
    uVar6 = param_2[1];
    if (0x25 < (uint)((int)(uVar7 - uVar6) >> 2)) {
      *(int *)(uVar6 + 0x90) = *(int *)(uVar6 + 0x90) - *(int *)(uVar6 + 0x18);
      piVar1 = (int *)(param_2[1] + 0x90);
      *piVar1 = *piVar1 - *(int *)(param_2[1] + 0x24);
      piVar1 = (int *)(param_2[1] + 0x94);
      *piVar1 = *piVar1 - *(int *)(param_2[1] + 0x1c);
      piVar1 = (int *)(param_2[1] + 0x94);
      *piVar1 = *piVar1 - *(int *)(param_2[1] + 0x20);
      uVar7 = param_2[2];
      uVar6 = param_2[1];
    }
    if (0x22 < (uint)((int)(uVar7 - uVar6) >> 2)) {
      uVar7 = FUN_00bc3f90(*param_2 + 0x23ee08fd);
      uVar6 = 0x24;
      do {
        puVar2 = (uint *)((uVar6 - 0xc) + param_2[1]);
        *puVar2 = *puVar2 ^ uVar7;
        puVar2 = (uint *)((uVar6 - 8) + param_2[1]);
        *puVar2 = *puVar2 ^ uVar7;
        puVar2 = (uint *)((uVar6 - 4) + param_2[1]);
        *puVar2 = *puVar2 ^ uVar7;
        *(uint *)(param_2[1] + uVar6) = *(uint *)(param_2[1] + uVar6) ^ uVar7;
        puVar2 = (uint *)(uVar6 + 4 + param_2[1]);
        *puVar2 = *puVar2 ^ uVar7;
        puVar2 = (uint *)(uVar6 + 8 + param_2[1]);
        *puVar2 = *puVar2 ^ uVar7;
        uVar6 = uVar6 + 0x18;
      } while (uVar6 < 0x9c);
      return;
    }
  }
  return;
}



/* FUNCTION 7570 ; VA 0x00659dc0 ; FUN_00659dc0 */

void FUN_00659dc0(uint *param_1)

{
  code *pcVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint *puVar6;
  undefined auStack_14 [16];
  
  puVar6 = (uint *)param_1[1];
  uVar2 = (int)(param_1[2] - (int)puVar6) >> 2;
  if ((byte)uVar2 < 2) {
    uVar2 = *param_1;
  }
  else {
    uVar2 = uVar2 & 0xff;
    iVar5 = uVar2 - 2;
    if (iVar5 != 0) {
      do {
        puVar6 = (uint *)(param_1[1] + iVar5 * 4);
        *puVar6 = *puVar6 ^ puVar6[-1];
        iVar5 = iVar5 + -1;
      } while (iVar5 != 0);
      puVar6 = (uint *)param_1[1];
    }
    *puVar6 = *puVar6 ^ *param_1;
    uVar2 = *(uint *)((param_1[1] - 4) + uVar2 * 4) ^ *param_1;
  }
  *param_1 = uVar2 + 0x23ee08fd;
  iVar3 = FUN_00717e80(auStack_14);
  iVar5 = (int)(param_1[2] - param_1[1]) >> 2;
  pcVar1 = *(code **)(iVar3 + 8);
  while (iVar5 = iVar5 + -1, -1 < iVar5) {
    uVar4 = (*pcVar1)(*(undefined4 *)(param_1[1] + iVar5 * 4),*param_1);
    *(undefined4 *)(param_1[1] + iVar5 * 4) = uVar4;
    *param_1 = *param_1 + 0x23ee08fd;
  }
  return;
}



/* FUNCTION 7571 ; VA 0x00659e70 ; FUN_00659e70 */

int FUN_00659e70(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1d78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    iStack_20 = FUN_008f7870(iStack_20);
    iStack_14 = iStack_20;
    if (iStack_20 != 0) {
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
        piVar4 = (int *)param_1[1];
      }
      uVar3 = *param_1;
      piVar1 = piVar4 + 2;
      if (piVar4 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_0064b970(uVar3,piVar4,0);
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      iStack_20 = FUN_0090ca30();
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar4 = piStack_1c + 1;
    iVar2 = *piVar4;
    iStack_20 = *piVar4;
    *piVar4 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_20 = (**(code **)*piStack_1c)();
      LOCK();
      piVar4 = piStack_1c + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_20 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_20;
}



/* FUNCTION 7572 ; VA 0x00659f50 ; FUN_00659f50 */

undefined * FUN_00659f50(undefined *param_1,int param_2)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  undefined8 uVar5;
  char *pcStack_1c;
  char *pcStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1d98;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 0x10) == 0) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    return param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_006580e0(&pcStack_1c,param_2);
  uStack_8 = 0;
  if ((pcStack_1c != pcStack_18) && (((int)pcStack_18 - (int)pcStack_1c & 7U) == 0)) {
    uVar4 = (uint)((int)pcStack_18 - (int)pcStack_1c) >> 3;
    uVar3 = 0;
    if (uVar4 != 0) {
      do {
        uVar5 = FUN_01255890(*(undefined4 *)(pcStack_1c + uVar3 * 8),
                             *(undefined4 *)(pcStack_1c + uVar3 * 8 + 4));
        *(int *)(pcStack_1c + uVar3 * 8) = (int)uVar5;
        *(int *)(pcStack_1c + uVar3 * 8 + 4) = (int)((ulonglong)uVar5 >> 0x20);
        uVar3 = uVar3 + 1;
      } while (uVar3 < uVar4);
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    pcVar2 = pcStack_1c;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcStack_1c,(int)pcVar2 - (int)(pcStack_1c + 1));
    if (pcStack_1c != (char *)0x0) {
      uVar3 = iStack_14 - (int)pcStack_1c;
      pcVar2 = pcStack_1c;
      if (0xfff < uVar3) {
        pcVar2 = *(char **)(pcStack_1c + -4);
        uVar3 = uVar3 + 0x23;
        if ((char *)0x1f < pcStack_1c + (-4 - (int)pcVar2)) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pcVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_0056d2d0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7573 ; VA 0x0065a090 ; FUN_0065a090 */

undefined * FUN_0065a090(undefined *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined uVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  int iVar8;
  undefined **ppuStack_d4;
  undefined auStack_d0 [52];
  undefined4 auStack_9c [5];
  undefined4 uStack_88;
  undefined **appuStack_84 [18];
  undefined4 ***apppuStack_3c [4];
  int iStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1def;
  pvStack_10 = ExceptionList;
  ppuStack_d4 = &PTR_018be314;
  uStack_8 = 0;
  uStack_20 = 2;
  appuStack_84[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_88 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(auStack_d0,0);
  uStack_8 = 2;
  *(undefined ***)(auStack_d0 + (int)(ppuStack_d4[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_d0 + (int)(ppuStack_d4[1] + -8)) = ppuStack_d4[1] + -0x50;
  FUN_005658e0(2);
  uStack_8 = 3;
  uStack_24 = 0;
  uStack_18 = uStack_18 & 0xffffff00;
  puVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar5 = (undefined4 *)*param_2;
  }
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_0064ea30(&param_2,puVar3,param_2[4] + (int)puVar5,uStack_18,
               *(undefined4 *)((int)auStack_9c + (int)ppuStack_d4[1]),&uStack_24);
  FUN_0058c420(apppuStack_3c);
  ppppuVar4 = apppuStack_3c;
  if (0xf < uStack_28) {
    ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
  }
  uStack_8._0_1_ = 4;
  ppppuVar6 = apppuStack_3c;
  if (0xf < uStack_28) {
    ppppuVar6 = (undefined4 ****)apppuStack_3c[0];
  }
  iStack_1c = 0;
  uStack_18 = 0;
  iStack_14 = 0;
  FUN_0064d1e0(ppppuVar6,iStack_2c + (int)ppppuVar4,param_2);
  iVar1 = iStack_1c;
  uVar7 = 0;
  param_2 = (undefined4 *)(uStack_18 - iStack_1c);
  uStack_8._0_1_ = 5;
  if (param_2 != (undefined4 *)0x0) {
    do {
      *(byte *)(iStack_1c + uVar7) = *(byte *)(iStack_1c + uVar7) ^ (&DAT_018d1b3c)[uVar7 & 0xf];
      uVar7 = uVar7 + 1;
    } while (uVar7 < param_2);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_0058a190(param_2);
  FUN_0064be90(iVar1,uStack_18,param_2);
  uStack_8._0_1_ = 4;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (iVar1 != 0) {
    uVar7 = iStack_14 - iVar1;
    iVar8 = iVar1;
    if (0xfff < uVar7) {
      iVar8 = *(int *)(iVar1 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar1 - iVar8) - 4U) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar7);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < uStack_28) {
    uVar7 = uStack_28 + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
    if (0xfff < uVar7) {
      ppppuVar4 = (undefined4 ****)apppuStack_3c[0][-1];
      uVar7 = uStack_28 + 0x24;
      if (0x1f < (uint)((int)apppuStack_3c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar7);
  }
  iStack_2c = 0;
  uStack_28 = 0xf;
  apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
  *(undefined ***)(auStack_d0 + (int)(ppuStack_d4[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_d0 + (int)(ppuStack_d4[1] + -8)) = ppuStack_d4[1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(auStack_d0 + (int)(ppuStack_d4[1] + -4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(auStack_d0 + (int)(ppuStack_d4[1] + -8)) = ppuStack_d4[1] + -8;
  uStack_8 = 6;
  appuStack_84[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_84);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7574 ; VA 0x0065a330 ; FUN_0065a330 */

undefined4 FUN_0065a330(int *param_1,undefined4 *param_2)

{
  int iVar1;
  bool bVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined auStack_20 [16];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_1;
  bVar2 = false;
  uStack_8 = 0;
  if (*param_1 != 0) {
    puVar5 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar5 = (undefined4 *)*param_2;
    }
    cVar4 = FUN_0055c360(puVar5,param_2[4],"Windows_Universal",0x11);
    if (cVar4 != '\0') {
      uStack_10 = 0;
      uStack_c = 0xf;
      auStack_20[0] = 0;
      FUN_005542c0("DisplayName",0xb);
      piVar6 = (int *)FUN_00580040(&param_1,auStack_20);
      iVar1 = *piVar6;
      FUN_005507b0();
      if (iVar1 == 0) {
        return 1;
      }
      uStack_10 = 0;
      uStack_c = 0xf;
      auStack_20[0] = 0;
      FUN_005542c0("LocaleIdInternal",0x10);
      piVar6 = (int *)FUN_00580040(&param_1,auStack_20);
      iVar1 = *piVar6;
      FUN_005507b0();
      if (iVar1 == 0) {
        return 1;
      }
      uStack_10 = 0;
      uStack_c = 0xf;
      auStack_20[0] = 0;
      FUN_005542c0("Locale2IdRef",0xc);
      FUN_00580040(&param_1,auStack_20);
      FUN_005507b0();
      if (param_1 == (int *)0x0) {
LAB_0065a45e:
        param_1 = (int *)((uint)param_1 & 0xffffff);
      }
      else {
        puVar7 = (undefined4 *)FUN_00563690(auStack_20);
        bVar2 = true;
        puVar5 = puVar7 + 4;
        if (0xf < (uint)puVar7[5]) {
          puVar7 = (undefined4 *)*puVar7;
        }
        cVar4 = FUN_0055c360(puVar7,*puVar5,"RBXE5F42E08403C42E58AFA15210C7EBE64",0x23);
        param_1 = (int *)CONCAT13(1,param_1._0_3_);
        if (cVar4 == '\0') goto LAB_0065a45e;
      }
      if (bVar2) {
        FUN_005507b0();
      }
      if (param_1._3_1_ != '\0') {
        return 1;
      }
    }
  }
  bVar2 = false;
  if (DAT_01d5ad00 == '\0') {
    return 0;
  }
  if (*piVar3 == 0) {
    return 0;
  }
  uStack_10 = 0;
  uStack_c = 0xf;
  auStack_20[0] = 0;
  FUN_005542c0("Locale2IdRef",0xc);
  FUN_00580040(&param_1,auStack_20);
  FUN_005507b0();
  if (param_1 != (int *)0x0) {
    puVar7 = (undefined4 *)FUN_00563690(auStack_20);
    bVar2 = true;
    puVar5 = puVar7 + 4;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar4 = FUN_0055c360(puVar7,*puVar5,"RBXE5F42E08403C42E58AFA15210C7EBE64",0x23);
    param_1 = (int *)CONCAT13(1,param_1._0_3_);
    if (cVar4 != '\0') goto LAB_0065a509;
  }
  param_1 = (int *)((uint)param_1 & 0xffffff);
LAB_0065a509:
  if (bVar2) {
    FUN_005507b0();
  }
  if (param_1._3_1_ == '\0') {
    return 0;
  }
  return 1;
}



/* FUNCTION 7575 ; VA 0x0065a530 ; FUN_0065a530 */

void __thiscall
FUN_0065a530(int param_1,uint param_2,uint param_3,char *param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  byte bVar1;
  char cVar2;
  bool bVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  char *pcVar7;
  uint uVar8;
  bool bVar9;
  float10 fVar10;
  double dVar11;
  uint uStack_8;
  
  bVar3 = false;
  if ((param_2 & param_3) != 0) {
    param_2 = 0x80000000;
    uStack_8 = 0;
    puVar6 = &DAT_01d5a848;
    if (0xf < DAT_01d5a85c) {
      puVar6 = DAT_01d5a848;
    }
    uVar8 = 0;
    uVar5 = 0;
    do {
      bVar1 = *(byte *)((int)puVar6 + uVar8);
      if (bVar1 == 0) {
LAB_0065a5b9:
        bVar3 = true;
        uStack_8 = 0;
        break;
      }
      if (uVar8 % 5 == 4) {
        uVar4 = uVar5;
        if (0x37 < bVar1) goto LAB_0065a5b9;
      }
      else {
        uVar4 = param_2 | uVar5;
        param_2 = param_2 >> 1;
        uStack_8 = uVar4;
        if (bVar1 != 0x2e) {
          uVar4 = uVar5;
          uStack_8 = uVar5;
        }
      }
      uVar8 = uVar8 + 1;
      uVar5 = uVar4;
    } while (uVar8 < 0x28);
    param_2 = param_2 & 0xffffff;
    if ((param_3 & uStack_8) != 0) {
      bVar9 = DAT_01d5ac48 == '\0';
      param_2 = CONCAT31(param_2._1_3_,bVar9);
      pcVar7 = param_4;
      do {
        cVar2 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar2 != '\0');
      FUN_005542c0(param_4,(int)pcVar7 - (int)(param_4 + 1));
      uVar5 = FUN_01679ce0();
      dVar11 = (double)(uVar5 & 0x7f) + DAT_018c0d90;
      fVar10 = (float10)FUN_01683110();
      *(double *)(param_1 + 0x3e18) = (double)(fVar10 + (float10)DAT_018cf108 + (float10)dVar11);
      FUN_0066a8c0(param_7,param_2);
      FUN_0066aa10(1,param_6,param_2,param_8);
      if (bVar9) {
        FUN_00668a20(&DAT_018d2790,param_6);
      }
      param_2 = 0x1000000;
    }
    param_4 = (char *)0x80000000;
    puVar6 = &DAT_01d5a848;
    if (0xf < DAT_01d5a85c) {
      puVar6 = DAT_01d5a848;
    }
    uVar8 = 0;
    uVar5 = 0;
    do {
      bVar1 = *(byte *)((int)puVar6 + uVar8);
      if (bVar1 == 0) {
LAB_0065a6c8:
        uVar4 = 0;
        bVar3 = true;
        break;
      }
      if (uVar8 % 5 == 4) {
        uVar4 = uVar5;
        if (0x37 < bVar1) goto LAB_0065a6c8;
      }
      else {
        uVar4 = (uint)param_4 | uVar5;
        param_4 = (char *)((uint)param_4 >> 1);
        if (bVar1 != 0x72) {
          uVar4 = uVar5;
        }
      }
      uVar8 = uVar8 + 1;
      uVar5 = uVar4;
    } while (uVar8 < 0x28);
    if ((param_3 & (uVar4 | uStack_8)) != 0) {
      FUN_0087c450(&DAT_018c5f98,"SecurityException",param_5,0,0,0);
      if (param_2._3_1_ == '\0') {
        FUN_0066a8c0(param_7,0);
        FUN_0066aa10(1,param_6,0,param_8);
      }
    }
    if (bVar3) {
      FUN_006688b0("US30605p1");
    }
  }
  return;
}



/* FUNCTION 7576 ; VA 0x0065a730 ; FUN_0065a730 */

void __thiscall
FUN_0065a730(int *param_1,uint param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  undefined4 uStack_8;
  
  uStack_8 = (uint)param_1 & 0xffffff;
  if ((param_2 & param_3) != 0) {
    uVar1 = FUN_0065b3d0(param_9,0x2e,(int)&uStack_8 + 3);
    bVar3 = (param_3 & uVar1) != 0;
    if (bVar3) {
      (**(code **)(*param_1 + 0x290))(param_4,param_7,1,param_6,param_8);
    }
    uVar2 = FUN_0065b3d0(param_9,0x72,(int)&uStack_8 + 3);
    if (((param_3 & (uVar2 | uVar1)) != 0) &&
       (FUN_0087c450(&DAT_018c5f98,"SecurityException",param_5,0,0,0), !bVar3)) {
      (**(code **)(*param_1 + 0x290))(param_4,param_7,0,param_6,param_8);
    }
    if (uStack_8._3_1_ != '\0') {
      if (0xf < (uint)param_9[5]) {
        param_9 = (undefined4 *)*param_9;
      }
      FUN_006688b0(param_9);
    }
  }
  return;
}



/* FUNCTION 7577 ; VA 0x0065a800 ; FUN_0065a800 */

uint __thiscall
FUN_0065a800(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  
  iVar1 = FUN_016dfe9f(param_2,param_3,param_4,param_5,param_1 + 8);
  if (iVar1 < 0) {
    return 0xffffffff;
  }
  return (uint)(iVar1 != 0);
}



/* FUNCTION 7578 ; VA 0x0065a840 ; FUN_0065a840 */

uint FUN_0065a840(int param_1,int param_2)

{
  byte *pbVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0x811c9dc5;
  uVar2 = 0;
  if (param_2 != param_1) {
    do {
      pbVar1 = (byte *)(uVar2 + param_1);
      uVar2 = uVar2 + 1;
      uVar3 = (*pbVar1 ^ uVar3) * 0x1000193;
    } while (uVar2 < (uint)(param_2 - param_1));
  }
  return uVar3;
}



/* FUNCTION 7579 ; VA 0x0065a880 ; FUN_0065a880 */

undefined4 * __thiscall FUN_0065a880(int param_1,undefined4 *param_2,int param_3,int param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uStack_8 = 0;
  uVar1 = param_4 - param_3;
  if (uVar1 != 0) {
    uVar4 = param_2[4];
    do {
      if (uVar4 < uVar1) {
        FUN_00578160(uVar1 - uVar4,0);
      }
      else {
        puVar2 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar2 = (undefined4 *)*param_2;
        }
        param_2[4] = uVar1;
        *(undefined *)((int)puVar2 + uVar1) = 0;
      }
      puVar2 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar2 = (undefined4 *)*param_2;
      }
      puVar3 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar3 = (undefined4 *)*param_2;
      }
      uVar1 = FUN_016dff32(puVar3,param_2[4] + (int)puVar2,param_3,param_4,param_1 + 8);
      uVar4 = param_2[4];
    } while ((uVar4 < uVar1) && (uVar1 != 0));
  }
  if ((uint)param_2[4] < uVar1) {
    FUN_00578160(uVar1 - param_2[4],0);
  }
  else {
    puVar2 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar2 = (undefined4 *)*param_2;
    }
    param_2[4] = uVar1;
    *(undefined *)((int)puVar2 + uVar1) = 0;
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7580 ; VA 0x0065a980 ; FUN_0065a980 */

void __thiscall FUN_0065a980(int *param_1,int *param_2)

{
  uint uVar1;
  
  uVar1 = param_1[3];
  if (((int)uVar1 < 0) && (uVar1 != 0)) {
    *param_2 = *param_1 - ((~uVar1 >> 5) * 4 + 4);
    param_2[1] = uVar1 & 0x1f;
    return;
  }
  *param_2 = *param_1 + (uVar1 >> 5) * 4;
  param_2[1] = uVar1 & 0x1f;
  return;
}



/* FUNCTION 7581 ; VA 0x0065a9d0 ; FUN_0065a9d0 */

/* WARNING: Removing unreachable block (ram,0x0065ab04) */
/* WARNING: Removing unreachable block (ram,0x0065aa68) */
/* WARNING: Removing unreachable block (ram,0x0065aa6f) */
/* WARNING: Removing unreachable block (ram,0x0065aa88) */
/* WARNING: Removing unreachable block (ram,0x0065aa75) */
/* WARNING: Removing unreachable block (ram,0x0065aa96) */
/* WARNING: Removing unreachable block (ram,0x0065aaa2) */
/* WARNING: Removing unreachable block (ram,0x0065aaa7) */
/* WARNING: Removing unreachable block (ram,0x0065aaab) */
/* WARNING: Removing unreachable block (ram,0x0065aabd) */
/* WARNING: Removing unreachable block (ram,0x0065aab8) */
/* WARNING: Removing unreachable block (ram,0x0065aac0) */
/* WARNING: Removing unreachable block (ram,0x0065aaca) */
/* WARNING: Removing unreachable block (ram,0x0065aac7) */
/* WARNING: Removing unreachable block (ram,0x0065aacf) */
/* WARNING: Removing unreachable block (ram,0x0065aada) */
/* WARNING: Removing unreachable block (ram,0x0065aad7) */
/* WARNING: Removing unreachable block (ram,0x0065aae1) */
/* WARNING: Removing unreachable block (ram,0x0065ab0a) */

void __thiscall
FUN_0065a9d0(int *param_1,int *param_2,int param_3,int param_4,int param_5,int param_6)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (param_1[3] != 0) {
    FUN_00652880((param_3 - iVar1 >> 2) * 0x20 + param_4);
    FUN_00652880((param_5 - iVar1 >> 2) * 0x20 + param_6);
  }
  *param_2 = iVar1;
  param_2[1] = 0;
  return;
}



/* FUNCTION 7582 ; VA 0x0065ab50 ; FUN_0065ab50 */

undefined __thiscall FUN_0065ab50(int param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  undefined uVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dbc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016dee6d(param_1 + 8);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_8 = 0;
  FUN_00658b20();
  piVar5 = *(int **)(param_1 + 0x38);
  piVar1 = *(int **)(param_1 + 0x3c);
  if (piVar5 != piVar1) {
    piVar9 = piVar5 + 2;
    do {
      if ((*piVar5 == 0 && piVar5[1] == 0) || ((*param_2 == *piVar5 && (param_2[1] == piVar5[1]))))
      {
        uVar2 = piVar9[5];
        piVar6 = piVar9;
        if (0xf < uVar2) {
          piVar6 = (int *)*piVar9;
        }
        cVar3 = FUN_0055c360(piVar6,piVar9[4],&DAT_018c0df0,1);
        if (cVar3 == '\0') {
          piVar7 = param_2 + 2;
          piVar6 = piVar9;
          if (0xf < uVar2) {
            piVar6 = (int *)*piVar9;
          }
          if (0xf < (uint)param_2[7]) {
            piVar7 = (int *)*piVar7;
          }
          cVar3 = FUN_0055c360(piVar7,param_2[6],piVar6,piVar9[4]);
          if (cVar3 == '\0') goto LAB_0065ac6e;
        }
        piVar6 = piVar9 + 6;
        piVar7 = piVar6;
        if (0xf < (uint)piVar9[0xb]) {
          piVar7 = (int *)*piVar6;
        }
        cVar3 = FUN_0055c360(piVar7,piVar9[10],&DAT_018c0df0,1);
        if (cVar3 == '\0') {
          piVar7 = param_2 + 8;
          if (0xf < (uint)piVar9[0xb]) {
            piVar6 = (int *)*piVar6;
          }
          if (0xf < (uint)param_2[0xd]) {
            piVar7 = (int *)*piVar7;
          }
          cVar3 = FUN_0055c360(piVar7,param_2[0xc],piVar6,piVar9[10]);
          if (cVar3 == '\0') goto LAB_0065ac6e;
        }
        uVar8 = 1;
        goto LAB_0065ac85;
      }
LAB_0065ac6e:
      piVar9 = piVar9 + 0xe;
      piVar5 = piVar5 + 0xe;
    } while (piVar5 != piVar1);
  }
  uVar8 = 0;
LAB_0065ac85:
  uStack_8 = 1;
  iVar4 = FUN_016deec8(param_1 + 8);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 7583 ; VA 0x0065acc0 ; FUN_0065acc0 */

void __fastcall FUN_0065acc0(int param_1)

{
  uint uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_006ace40();
  *(uint *)(param_1 + 0x3ef4) = uVar1;
  if ((uVar1 & 0xc) == 0) {
    FUN_006ace40();
  }
  uVar2 = FUN_006ace40();
  *(undefined4 *)(param_1 + 0x3ef0) = uVar2;
  if ((*(uint *)(param_1 + 0x3ef4) & 0x50) == 0) {
    FUN_006ace40();
  }
  uVar2 = FUN_006ace40();
  *(undefined4 *)(param_1 + 0x3eec) = uVar2;
  if ((*(byte *)(param_1 + 0x3ef4) & 0xa0) == 0) {
    FUN_006ace40();
  }
  FUN_006ace40();
  if ((*(uint *)(param_1 + 0x3ef4) & 0x900) == 0) {
    FUN_006ace40();
  }
  uVar2 = FUN_006ace40();
  *(undefined4 *)(param_1 + 0x3ef8) = uVar2;
  return;
}



/* FUNCTION 7584 ; VA 0x0065ad50 ; FUN_0065ad50 */

void __thiscall FUN_0065ad50(int *param_1,int *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)puVar2[1];
  puVar4 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      cVar1 = FUN_00570370(puVar3 + 4,param_3);
      if (cVar1 == '\0') {
        puVar2 = (undefined4 *)*puVar3;
        puVar4 = puVar3;
      }
      else {
        puVar2 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    puVar2 = (undefined4 *)*param_1;
  }
  if (puVar4 != puVar2) {
    cVar1 = FUN_00570370(param_3,puVar4 + 4);
    if (cVar1 == '\0') {
      *param_2 = (int)puVar4;
      return;
    }
  }
  *param_2 = *param_1;
  return;
}



/* FUNCTION 7585 ; VA 0x0065adc0 ; FUN_0065adc0 */

undefined4 __fastcall FUN_0065adc0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x3c0c);
}



/* FUNCTION 7586 ; VA 0x0065add0 ; FUN_0065add0 */

bool __fastcall FUN_0065add0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  
  if (DAT_01d5acd0 != '\0') {
    if (((DAT_01d5ac70 != '\0') && (*(int *)(param_1 + 0x3e5c) < DAT_01ead804)) &&
       ((cVar1 = FUN_005f77c0(), cVar1 == '\x04' ||
        ((DAT_01d5acf0 != '\0' && (cVar1 = FUN_005f7830(), cVar1 != '\0')))))) {
      if (DAT_01d5acf0 == '\0') {
        uVar2 = *(undefined4 *)(param_1 + 0x78);
      }
      else {
        uVar2 = FUN_005f77e0();
      }
      uVar3 = Ordinal_14(uVar2);
      uVar4 = FUN_00644540();
      return (uVar3 & 0xff) <= uVar4;
    }
    return false;
  }
  if ((DAT_01d5ac70 != '\0') && (*(int *)(param_1 + 0x3e5c) < DAT_01ead804)) {
    cVar1 = FUN_005f77c0();
    if (cVar1 == '\x04') {
      return true;
    }
    if ((DAT_01d5acf0 != '\0') && (cVar1 = FUN_005f7830(), cVar1 != '\0')) {
      return true;
    }
  }
  return false;
}



/* FUNCTION 7587 ; VA 0x0065aeb0 ; FUN_0065aeb0 */

void __thiscall FUN_0065aeb0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x430);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x430);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x42c);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 7588 ; VA 0x0065af00 ; thunk_FUN_005ee530 */

void thunk_FUN_005ee530(void)

{
  int iVar1;
  
  if (DAT_01eaa384 == 0) {
    iVar1 = FUN_005ee350();
    DAT_01eaa384 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 7589 ; VA 0x0065af10 ; FUN_0065af10 */

void __fastcall FUN_0065af10(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0065af12. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x10))();
  return;
}



/* FUNCTION 7590 ; VA 0x0065af20 ; FUN_0065af20 */

undefined __fastcall FUN_0065af20(int *param_1)

{
  char cVar1;
  int iVar2;
  
  iVar2 = (**(code **)(*param_1 + 0x224))();
  if (iVar2 != 0) {
    return 2;
  }
  cVar1 = (**(code **)(*param_1 + 0x220))();
  return cVar1 != '\0';
}



/* FUNCTION 7591 ; VA 0x0065af50 ; FUN_0065af50 */

undefined4 __fastcall FUN_0065af50(int param_1)

{
  return *(undefined4 *)(param_1 + 0x3f6c);
}



/* FUNCTION 7592 ; VA 0x0065af60 ; FUN_0065af60 */

undefined4 __thiscall FUN_0065af60(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x458);
  return param_2;
}



/* FUNCTION 7593 ; VA 0x0065af90 ; FUN_0065af90 */

void FUN_0065af90(undefined4 param_1,uint *param_2,uint *param_3,uint *param_4,uint *param_5,
                 undefined4 param_6)

{
  uint uVar1;
  
  if (DAT_01d5ac40 != '\0') {
    uVar1 = FUN_0065b3d0(param_1,0x3a,param_6);
    *param_2 = uVar1;
    uVar1 = FUN_0065b3d0(param_1,0x67,param_6);
    *param_3 = uVar1 | *param_2;
    uVar1 = FUN_0065b3d0(param_1,0x2e,param_6);
    *param_4 = uVar1 | *param_3;
    uVar1 = FUN_0065b3d0(param_1,0x72,param_6);
    *param_5 = uVar1 | *param_4;
    *param_2 = 0;
    return;
  }
  uVar1 = FUN_0065b3d0(param_1,0x3a,param_6);
  *param_2 = uVar1;
  uVar1 = FUN_0065b3d0(param_1,0x67,param_6);
  *param_3 = uVar1 | *param_2;
  uVar1 = FUN_0065b3d0(param_1,0x2e,param_6);
  *param_4 = uVar1 | *param_3;
  uVar1 = FUN_0065b3d0(param_1,0x72,param_6);
  *param_5 = uVar1 | *param_4;
  return;
}



/* FUNCTION 7594 ; VA 0x0065b040 ; FUN_0065b040 */

undefined4 __thiscall FUN_0065b040(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x288);
  return param_2;
}



/* FUNCTION 7595 ; VA 0x0065b060 ; FUN_0065b060 */

void __fastcall FUN_0065b060(int param_1)

{
  FUN_009edf10(*(undefined4 *)(param_1 + 0x3ef4),*(undefined *)(param_1 + 0x3c2b));
  return;
}



/* FUNCTION 7596 ; VA 0x0065b080 ; FUN_0065b080 */

undefined4 __fastcall FUN_0065b080(int param_1)

{
  return *(undefined4 *)(param_1 + 0x3eec);
}



/* FUNCTION 7597 ; VA 0x0065b090 ; FUN_0065b090 */

char __thiscall FUN_0065b090(int param_1,uint param_2)

{
  if (param_2 != (*(uint *)(param_1 + 0x3f74) & param_2)) {
    return '\0';
  }
  return (param_2 != (*(uint *)(param_1 + 0x3f78) & param_2)) + '\x01';
}



/* FUNCTION 7598 ; VA 0x0065b0c0 ; FUN_0065b0c0 */

undefined * __thiscall FUN_0065b0c0(int param_1,undefined *param_2,uint param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  if (param_3 == (*(uint *)(param_1 + 0x3f74) & param_3)) {
    cVar1 = (param_3 != (*(uint *)(param_1 + 0x3f78) & param_3)) + '\x01';
  }
  else {
    cVar1 = '\0';
  }
  if (cVar1 == '\0') {
    pcVar3 = "Unknown";
  }
  else if (cVar1 == '\x01') {
    pcVar3 = "True";
  }
  else if (cVar1 == '\x02') {
    pcVar3 = "False";
  }
  else {
    pcVar3 = "WrongBotCheckStatus";
  }
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  return param_2;
}



/* FUNCTION 7599 ; VA 0x0065b150 ; FUN_0065b150 */

int FUN_0065b150(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  undefined8 uVar7;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1e08;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar1 != 0) && (param_1 = iVar1, ExceptionList = &pvStack_10, *(int *)(iVar1 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
      uVar3 = FUN_00560e40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      piStack_14 = piVar4;
      if (*piVar4 == 0) {
        uVar3 = FUN_005ee510();
        piVar5 = (int *)FUN_008a9ba0(auStack_24,uVar3);
        piVar4 = piStack_14;
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piStack_14 = iVar1;
        piVar5 = (int *)piStack_14[1];
        piStack_14[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_20[1] + -1;
          piStack_20[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            iVar1 = piStack_20[2] + -1;
            piStack_20[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
        }
      }
      if (*piVar4 != 0) {
        uVar7 = FUN_00928340();
        FUN_00644d90(&iStack_1c,uVar7);
        uStack_8 = 0;
        if (iStack_1c == 0) {
          iVar2 = 0;
        }
        else {
          iVar1 = *(int *)(iStack_1c + 0xc);
          iVar6 = FUN_005ee350();
          iVar2 = 0;
          if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            iVar2 = iStack_1c;
          }
        }
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_18[1] + -1;
          piStack_18[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar4 = piStack_18 + 2;
            iVar1 = *piVar4;
            *piVar4 = *piVar4 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_18 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return iVar2;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 7600 ; VA 0x0065b310 ; FUN_0065b310 */

void __thiscall FUN_0065b310(int param_1,double *param_2,double *param_3,double *param_4)

{
  double dVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_016830f0(&uStack_c);
  if ((*(char *)(param_1 + 0x3c32) != '\0') || (*(char *)(param_1 + 0x3c31) != '\0')) {
    *(double *)(param_1 + 0x1098) =
         ((double)CONCAT44(uStack_8,uStack_c) - *(double *)(param_1 + 0x1090)) +
         *(double *)(param_1 + 0x1098);
    *(undefined4 *)(param_1 + 0x1090) = uStack_c;
    *(undefined4 *)(param_1 + 0x1094) = uStack_8;
  }
  *param_2 = (double)CONCAT44(uStack_8,uStack_c) - *(double *)(param_1 + 0x3bc0);
  dVar1 = *(double *)(param_1 + 0x1098);
  *param_3 = dVar1;
  if (DAT_018c0d60 < *param_2) {
    *param_4 = (dVar1 * DAT_018ce318) / *param_2;
    return;
  }
  *param_4 = DAT_018ce318;
  return;
}



/* FUNCTION 7601 ; VA 0x0065b3d0 ; FUN_0065b3d0 */

uint FUN_0065b3d0(undefined4 *param_1,byte param_2,undefined *param_3)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar2 = 0;
  uVar3 = 0;
  uVar5 = 0x80000000;
  while (bVar1 = *(byte *)((int)param_1 + uVar2), bVar1 != 0) {
    if (uVar2 % 5 == 4) {
      uVar4 = uVar3;
      uVar6 = uVar5;
      if (0x37 < bVar1) break;
    }
    else {
      uVar6 = uVar5 >> 1;
      uVar4 = uVar5 | uVar3;
      if (bVar1 != param_2) {
        uVar4 = uVar3;
      }
    }
    uVar2 = uVar2 + 1;
    uVar3 = uVar4;
    uVar5 = uVar6;
    if (0x27 < uVar2) {
      return uVar4;
    }
  }
  if (param_3 != (undefined *)0x0) {
    *param_3 = 1;
  }
  return 0;
}



/* FUNCTION 7602 ; VA 0x0065b450 ; FUN_0065b450 */

void __thiscall FUN_0065b450(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x94);
  return;
}



/* FUNCTION 7603 ; VA 0x0065b470 ; FUN_0065b470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall FUN_0065b470(int param_1)

{
  if ((*(byte *)(param_1 + 0x3d72) & 8) != 0) {
    return (*(uint *)(param_1 + 0x3ef4) >> 1 & 0x7fff) - DAT_018c8aac;
  }
  return (int)(*(uint *)(param_1 + 0x3ef4) - _DAT_018c8ab0) >> 4;
}



/* FUNCTION 7604 ; VA 0x0065b4a0 ; FUN_0065b4a0 */

void __thiscall FUN_0065b4a0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_47c [1084];
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1e58;
  pvStack_10 = ExceptionList;
  switch(param_2) {
  case 0:
    if (DAT_01d5acd8 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0066cb30(0x1000,0);
      ExceptionList = pvStack_10;
      return;
    }
    break;
  case 1:
    ExceptionList = &pvStack_10;
    if (DAT_01d5acd8 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0066cb30(0x1000,1);
    }
    if (DAT_01d5aca0 != '\0') {
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("FloodChecker_BlacklistFlooded",0x1d);
      uStack_8 = 0;
      FUN_008783f0(auStack_28,1,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    if (DAT_01d5ac78 != '\0') {
      (**(code **)(*param_1 + 0x290))("fc-bl",0x22,DAT_01d5ac80 != '\0',"DynIpBlacklistedIP",0);
    }
    if (DAT_01d5acb0 != '\0') {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 1;
      FUN_0151f850(&DAT_018c7ed0,&DAT_018d46dc);
      FUN_005f7b20(1,auStack_47c,0x401,0x7c);
      FUN_0151f850(&DAT_018d48ac,auStack_47c);
      if (DAT_01d5ad10 != '\0') {
        FUN_0151fbb0("expiry",DAT_01d5a7b4,DAT_01d5a7b4 >> 0x1f);
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0(&DAT_018c6ae4,1);
        uStack_8._0_1_ = 2;
        uVar1 = FUN_00659ab0(auStack_40,auStack_28);
        uStack_8._0_1_ = 3;
        FUN_0151f950(&DAT_018d46b8,uVar1);
        FUN_005507b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
      uVar1 = DAT_01ead800;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("dynip-blacklist-ip",0x12);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_01520d20(auStack_28,uVar1,0);
      FUN_005507b0();
      FUN_0151f7f0();
      ExceptionList = pvStack_10;
      return;
    }
    break;
  case 2:
    ExceptionList = &pvStack_10;
    if (DAT_01d5acd8 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0066cb30(0x1000,1);
    }
    if (DAT_01d5aca0 != '\0') {
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("FloodChecker_BotFlooded",0x17);
      uStack_8 = 5;
      FUN_008783f0(auStack_28,1,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    FUN_0065bb30(0,0,0,0,1,0);
    (**(code **)(*param_1 + 0x290))("fc-bot",0x23,DAT_01d5ac80 != '\0',"DynIpBot",0);
    ExceptionList = pvStack_10;
    return;
  case 3:
    ExceptionList = &pvStack_10;
    if (DAT_01d5acd8 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0066cb30(0x1000,0);
    }
    if (DAT_01d5aca0 != '\0') {
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0("FloodChecker_BotHumanFlooded",0x1c);
      uStack_8 = 6;
      FUN_008783f0(auStack_40,1,0);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7605 ; VA 0x0065b800 ; FUN_0065b800 */

void __thiscall
FUN_0065b800(int *param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
            undefined4 param_6)

{
  char cVar1;
  bool bVar2;
  undefined4 uVar3;
  byte bVar4;
  char *pcVar5;
  undefined4 ****ppppuVar6;
  char *pcVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  undefined auStack_60 [24];
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 ***apppuStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar8 = uStack_14;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1e88;
  pvStack_10 = ExceptionList;
  iStack_20 = param_1[0xf03];
  if (iStack_20 == 0) {
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_1c = 0xf;
    ExceptionList = &pvStack_10;
    FUN_005542c0("PlayerlessOther:",0x10);
    uStack_8 = 0;
    pcVar5 = (char *)FUN_0065d750(param_3);
    pcVar7 = pcVar5;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_00554150(pcVar5,(int)pcVar7 - (int)(pcVar5 + 1));
    ppppuVar6 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar6 = (undefined4 ****)apppuStack_30[0];
    }
    (**(code **)(*param_1 + 0x294))(0x10f,ppppuVar6,param_3,param_4,0,0);
    if (0xf < uStack_1c) {
      uVar8 = uStack_1c + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar8) {
        ppppuVar6 = (undefined4 ****)apppuStack_30[0][-1];
        uVar8 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar8);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    bVar2 = false;
    uStack_14 = uStack_14 & 0xffffff00;
    if ((param_4 == 2) || ((param_4 == 1 && (DAT_01d5ac48 == '\0')))) {
      bVar2 = true;
      uStack_14 = CONCAT31(SUB43(uVar8,1),1);
    }
    ExceptionList = &pvStack_10;
    uVar10 = FUN_00928340();
    uVar9 = (undefined4)((ulonglong)uVar10 >> 0x20);
    uStack_18 = (undefined4)uVar10;
    bVar4 = FUN_0065d270(param_3);
    uVar8 = uStack_14;
    if (bVar2) {
      cVar1 = *(char *)((int)param_1 + 0x3f5b);
    }
    else {
      cVar1 = *(char *)(param_1 + 0xfd7);
    }
    if (cVar1 == '\0') {
      FUN_0066a8c0(param_3,uStack_14);
      FUN_0066aa10(bVar4 ^ 1,param_5,uVar8,param_6);
      if (!bVar2) {
        *(undefined *)(param_1 + 0xfd7) = 1;
        ExceptionList = pvStack_10;
        return;
      }
      pcVar7 = "DuringJoin";
      if (bVar4 == 0) {
        pcVar7 = "AfterJoin";
      }
      FUN_00668a20(pcVar7,param_5);
      *(undefined *)((int)param_1 + 0x3f5b) = 1;
    }
    uVar3 = uStack_18;
    if (bVar2) {
      if ((param_3 != 10) && (param_3 != 0x21)) {
        FUN_0054eff0(param_2);
        uStack_8 = 1;
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = 0;
        FUN_005542c0("1920x1200",9);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00988ac0(uStack_18,uVar9,auStack_48,auStack_60,1,0);
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0086f2f0(1,"Security Timeout for userid %lld.",uStack_18,uVar9);
      FUN_00978d80(uVar3,uVar9,0x10a);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7606 ; VA 0x0065ba80 ; FUN_0065ba80 */

void __thiscall
FUN_0065ba80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,char param_7)

{
  char cVar1;
  bool bVar2;
  undefined4 uStack_8;
  
  bVar2 = false;
  uStack_8 = 0;
  if ((param_5 == 2) || ((param_5 == 1 && (DAT_01d5ac48 == '\0')))) {
    cVar1 = *(char *)(param_1 + 0x3f5b);
    bVar2 = true;
    uStack_8 = 1;
  }
  else {
    cVar1 = *(char *)(param_1 + 0x3f5c);
  }
  if (cVar1 == '\0') {
    FUN_0066a8c0(param_4,uStack_8);
    FUN_0066aa10(0,param_3,uStack_8,param_6);
    if (!bVar2) {
      *(undefined *)(param_1 + 0x3f5c) = 1;
      return;
    }
    FUN_00668a20("DuringJoin",param_3);
    *(undefined *)(param_1 + 0x3f5b) = 1;
  }
  if (bVar2) {
    if (param_7 != '\0') {
      FUN_0062b590(param_2);
      return;
    }
    FUN_0062b370(param_2);
  }
  return;
}



/* FUNCTION 7607 ; VA 0x0065bb30 ; FUN_0065bb30 */

void FUN_0065bb30(int param_1,int *param_2,int param_3,int param_4,int param_5,int param_6)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_158 [120];
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  uint auStack_c8 [4];
  undefined4 uStack_b8;
  uint uStack_b4;
  uint auStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined **ppuStack_98;
  int iStack_94;
  int *piStack_90;
  uint auStack_88 [4];
  undefined4 uStack_78;
  undefined ***pppuStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  undefined auStack_54 [4];
  int *piStack_50;
  int iStack_4c;
  int iStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1f45;
  pvStack_10 = ExceptionList;
  iStack_48 = DAT_01d5a7b4 >> 0x1f;
  iStack_4c = DAT_01d5a7b4;
  iStack_64 = DAT_01d5a7bc >> 0x1f;
  iStack_68 = DAT_01d5a7bc;
  iStack_6c = DAT_01d5a7c4 >> 0x1f;
  iStack_70 = DAT_01d5a7c4;
  ExceptionList = &pvStack_10;
  FUN_0167e9f0();
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  FUN_01681c30();
  FUN_01681d10("operations");
  FUN_01681c10();
  iVar4 = param_3;
  iVar3 = param_1;
  if (((0 < (int)param_2) || ((-1 < (int)param_2 && (param_1 != 0)))) ||
     ((-1 < param_4 && ((0 < param_4 || (param_3 != 0)))))) {
    FUN_01681c30();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("humans",6);
    uStack_8._0_1_ = 1;
    uVar6 = FUN_00659ab0(auStack_44,auStack_28);
    uStack_8._0_1_ = 2;
    FUN_01681e50(&DAT_018d46b8,uVar6);
    FUN_016816e0("expiry",iStack_4c,iStack_48);
    FUN_016816e0("limit",iStack_68,iStack_64);
    FUN_016816e0(&DAT_018d46cc,iVar3,param_2);
    FUN_01681200();
    uStack_8._0_1_ = 1;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar8 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8._0_1_ = 0;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    FUN_01681c30();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018d46d4,4);
    uStack_8._0_1_ = 3;
    uVar6 = FUN_00659ab0(auStack_44,auStack_28);
    uStack_8._0_1_ = 4;
    FUN_01681e50(&DAT_018d46b8,uVar6);
    FUN_016816e0("expiry",iStack_4c,iStack_48);
    FUN_016816e0("limit",iStack_70,iStack_6c);
    FUN_016816e0(&DAT_018d46cc,iVar4,param_4);
    FUN_01681200();
    uStack_8._0_1_ = 3;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar8 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8._0_1_ = 0;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
  }
  iVar4 = param_6;
  iVar3 = param_5;
  if ((-1 < param_6) && ((0 < param_6 || (param_5 != 0)))) {
    FUN_01681c30();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018d46dc,9);
    uStack_8._0_1_ = 5;
    uVar6 = FUN_00659ab0(auStack_44,auStack_28);
    uStack_8._0_1_ = 6;
    FUN_01681e50(&DAT_018d46b8,uVar6);
    FUN_016816e0("expiry",iStack_4c,iStack_48);
    FUN_016816e0("limit",1,0);
    FUN_016816e0(&DAT_018d46cc,iVar3,iVar4);
    FUN_01681200();
    uStack_8._0_1_ = 5;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar8 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
  }
  FUN_016811a0();
  FUN_01681200();
  FUN_014c9d60(auStack_54,0);
  uStack_8._0_1_ = 7;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 8;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 9;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  auStack_c8[0] = auStack_c8[0] & 0xffffff00;
  FUN_005542c0("floodchecker/v1/increment",0x19);
  uStack_8._0_1_ = 10;
  uVar6 = FUN_0151ec70(auStack_88);
  uStack_8._0_1_ = 0xb;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  auStack_b0[0] = auStack_b0[0] & 0xffffff00;
  FUN_005542c0("https",5);
  uStack_8._0_1_ = 0xc;
  FUN_0151bcc0(auStack_158,auStack_b0,uVar6,auStack_c8,auStack_28,auStack_44);
  uStack_8._0_1_ = 0xd;
  puVar7 = (undefined4 *)FUN_0151bb70(auStack_e0);
  puVar1 = puVar7 + 4;
  uStack_8._0_1_ = 0xe;
  if (0xf < (uint)puVar7[5]) {
    puVar7 = (undefined4 *)*puVar7;
  }
  FUN_014cbbc0(puVar7,*puVar1);
  uStack_8._0_1_ = 0xd;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (0xf < uStack_cc) {
    uVar9 = uStack_cc + 1;
    uVar8 = auStack_e0[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_e0[0] - 4);
      uVar9 = uStack_cc + 0x24;
      if (0x1f < (auStack_e0[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = auStack_e0[0] & 0xffffff00;
  FUN_0056d9d0();
  uStack_8._0_1_ = 0xb;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_9c) {
    uVar9 = uStack_9c + 1;
    uVar8 = auStack_b0[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_b0[0] - 4);
      uVar9 = uStack_9c + 0x24;
      if (0x1f < (auStack_b0[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_a0 = 0;
  uStack_9c = 0xf;
  auStack_b0[0] = auStack_b0[0] & 0xffffff00;
  uStack_8._0_1_ = 10;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < pppuStack_74) {
    uVar9 = (int)pppuStack_74 + 1;
    uVar8 = auStack_88[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_88[0] - 4);
      uVar9 = (int)pppuStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_78 = 0;
  pppuStack_74 = (undefined ***)0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  uStack_8._0_1_ = 9;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_b4) {
    uVar9 = uStack_b4 + 1;
    uVar8 = auStack_c8[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_c8[0] - 4);
      uVar9 = uStack_b4 + 0x24;
      if (0x1f < (auStack_c8[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  auStack_c8[0] = auStack_c8[0] & 0xffffff00;
  uStack_8._0_1_ = 8;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8._0_1_ = 7;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    uVar8 = auStack_44[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_44[0] - 4);
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  FUN_014cba60();
  uVar6 = FUN_01681c50(auStack_88);
  uStack_8._0_1_ = 0xf;
  FUN_014cb780(uVar6,0);
  uStack_8._0_1_ = 7;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < pppuStack_74) {
    uVar9 = (int)pppuStack_74 + 1;
    uVar8 = auStack_88[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_88[0] - 4);
      uVar9 = (int)pppuStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  FUN_0060e0c0(&param_1,uStack_2c);
  piVar2 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  iStack_94 = param_1;
  pppuStack_74 = &ppuStack_98;
  ppuStack_98 = std::
                _Func_impl_no_alloc<class_<lambda_2d70a72d3d46abb802d07f235c5eb683>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_90 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  FUN_014cb530(pppuStack_74);
  if (pppuStack_74 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_74)[4])(pppuStack_74 != &ppuStack_98);
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_50[1] + -1;
    piStack_50[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar2 = piStack_50 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  FUN_0167ec80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7608 ; VA 0x0065c390 ; FUN_0065c390 */

void __fastcall FUN_0065c390(int *param_1)

{
  undefined *puVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  double *pdVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined4 in_stack_ffffff48;
  undefined4 in_stack_ffffff4c;
  undefined4 *in_stack_ffffff50;
  uint uVar10;
  undefined auStack_94 [16];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined auStack_54 [12];
  undefined auStack_48 [12];
  undefined auStack_3c [12];
  undefined auStack_30 [4];
  undefined4 auStack_2c [2];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1f8a;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff60;
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  puVar1 = &stack0xffffff60;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eada98) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(), puVar1 = puStack_14, DAT_01eada98 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0(&DAT_018c5904,"Install Remote Player",0xffffffff);
    DAT_01eada94 = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01eada90 = (undefined4)uVar9;
    in_stack_ffffff50 = &DAT_01eada98;
    uStack_8 = 0xffffffff;
    in_stack_ffffff4c = 0x65c8d3;
    FUN_016f37bf(&DAT_01eada98);
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  uVar5 = DAT_01eada94;
  uVar7 = DAT_01eada90;
  uVar9 = CONCAT44(DAT_01eada94,DAT_01eada90);
  uStack_20 = DAT_01eada90;
  uStack_64 = DAT_01eada90;
  uStack_1c = DAT_01eada94;
  uStack_60 = DAT_01eada94;
  uVar10 = 0x65c3f8;
  uStack_5c = FUN_0152d930(DAT_01eada90,DAT_01eada94);
  if (*(char *)((int)param_1 + 0x3c2a) != '\0') {
    uStack_8 = 2;
    goto LAB_0065c41d;
  }
  cStack_15 = *(char *)((int)param_1 + 0x3d71) == '\0';
  uStack_8 = 3;
  if (DAT_01ee420a != 0) {
    uVar8 = FUN_00928340();
    auStack_2c[0] = (undefined4)((ulonglong)uVar8 >> 0x20);
    uVar10 = (uint)DAT_01ee420a;
    uVar9 = CONCAT44((int)uVar8,"ServerReplicator:InstallRemotePlayer. UserID: %lld");
    in_stack_ffffff50 = (undefined4 *)0x65c472;
    FUN_016774b0(uVar10,"ServerReplicator:InstallRemotePlayer. UserID: %lld",(int)uVar8);
  }
  FUN_0054ef60(param_1 + 0xf10);
  FUN_00933940(in_stack_ffffff48,in_stack_ffffff4c,in_stack_ffffff50,uVar10,uVar9);
  if (*(int *)(param_1[0xf03] + 0x34) == param_1[0x770]) {
    cStack_15 = '\0';
  }
  else {
    if (DAT_01d59fd0 != '\0') {
      cVar2 = (**(code **)(*param_1 + 0x11c))();
      if (cVar2 == '\0') goto LAB_0065c61e;
    }
    cVar2 = (**(code **)(*param_1 + 0x11c))();
    if (cVar2 == '\0') {
      cVar2 = FUN_00644850();
      if (cVar2 != '\0') {
        uVar9 = FUN_00928340();
        piVar3 = (int *)FUN_0097fc00(auStack_30,uVar9);
        iVar4 = *piVar3;
        FUN_00550b30();
        if (iVar4 != 0) {
          if (DAT_01d84e8e != '\0') {
            FUN_016774b0(DAT_01d84e8e,"ServerReplicator:InstallRemotePlayer - DuplicatePlayer",0);
          }
          uVar9 = FUN_00928340();
          FUN_0086f2f0(2,"Player %lld is already in the world",uVar9);
          (**(code **)(*param_1 + 0x294))(0x108,"DuplicatePlayer",4,2,0,0);
          iVar4 = FUN_0064e5e0();
          if (iVar4 != 0) {
            uStack_84 = 0;
            uStack_80 = 0xf;
            auStack_94[0] = 0;
            FUN_005542c0(&DAT_018bc9b8,0);
            uStack_8._0_1_ = 4;
            uStack_6c = 0;
            uStack_68 = 0xf;
            auStack_7c[0] = 0;
            FUN_005542c0("Authenticate-DupePlayer",0x17);
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            uVar5 = FUN_008cd320();
            FUN_00936dd0(uVar5,auStack_7c,auStack_94,0,0);
            FUN_005507b0();
            FUN_005507b0();
          }
          uStack_8 = 6;
          uVar5 = uStack_1c;
          goto LAB_0065c41d;
        }
      }
    }
  }
LAB_0065c61e:
  if (DAT_01d5a4c0 == '\0') {
    uVar9 = FUN_00928340();
    if ((param_1[0xf64] != (int)uVar9) || (param_1[0xf65] != (int)((ulonglong)uVar9 >> 0x20))) {
      FUN_016756b0(auStack_3c,"userId has morphed");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_3c,&DAT_01c17198);
    }
  }
  if (DAT_01d64728 == '\0') {
    cVar2 = FUN_00644850();
    if (cVar2 != '\0') goto LAB_0065c662;
  }
  else {
LAB_0065c662:
    if (param_1[0xf61] == 0) {
      if (DAT_01d84e8e != '\0') {
        FUN_016774b0(DAT_01d84e8e,"ServerReplicator:InstallRemotePlayer - MissingTicket",0);
      }
      FUN_016756b0(auStack_48,"missing ticket");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_48,&DAT_01c17198);
    }
    iVar4 = param_1[0xf07];
    piVar3 = (int *)FUN_0065ad50(auStack_2c,param_1 + 0xf5d);
    if (*piVar3 != *(int *)(iVar4 + 0x47c)) {
      if (DAT_01d84e8e != '\0') {
        FUN_016774b0(DAT_01d84e8e,"ServerReplicator:InstallRemotePlayer - DuplicateTicket",0);
      }
      uVar7 = FUN_005543f0();
      FUN_016756b0(auStack_54,"ticket has already been used: %s",uVar7);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_54,&DAT_01c17198);
    }
    FUN_0055b0f0(auStack_30,0,param_1 + 0xf5d,auStack_2c[0]);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0066cf60();
    uVar7 = uStack_20;
  }
  uStack_8 = 1;
  if (DAT_01d5b208 != '\0') {
    *(bool *)(param_1[0xf03] + 0x4c7) = (param_1[0xe02] & 0x40U) != 0;
  }
  if (cStack_15 != '\0') {
    FUN_008a65e0(param_1[0x770],0);
    FUN_0092ad20();
  }
  if (DAT_01ee420a != 0) {
    FUN_016774b0(DAT_01ee420a,"ServerReplicator:InstallRemotePlayer - PlayerInstalled",0);
  }
  *(undefined *)((int)param_1 + 0x3c2a) = 1;
  pdVar6 = (double *)FUN_016830f0();
  FUN_0151fb00("PlayerInstalled",*pdVar6 - *(double *)(param_1 + 0xef0));
  FUN_00682800();
  *(undefined *)(param_1[0xf03] + 0xaa) = 1;
  uStack_8 = 0xc;
  uVar5 = uStack_1c;
LAB_0065c41d:
  FUN_0152dda0(uVar7,uVar5,uStack_5c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7609 ; VA 0x0065c787 ; Catch@0065c787 */

void Catch_0065c787(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  iVar2 = *(int *)(unaff_EBP + -0x20);
  *(undefined *)(iVar2 + 0x3d71) = 1;
  if (*(char *)(iVar2 + 0x3f5b) == '\0') {
    FUN_0066a8c0(0x19,1);
    FUN_0066aa10(0,"AuthenticateTicket",1,0);
    FUN_00668a20("DuringJoin","AuthenticateTicket");
  }
  *(undefined *)(iVar2 + 0x3f5b) = 1;
  iVar2 = FUN_0064e5e0(iVar2);
  piVar1 = *(int **)(unaff_EBP + -0x24);
  if (iVar2 != 0) {
    uVar3 = (**(code **)(*piVar1 + 4))();
    FUN_0054eff0(uVar3);
    *(undefined *)(unaff_EBP + -4) = 10;
    *(undefined4 *)(unaff_EBP + -0x80) = 0;
    *(undefined4 *)(unaff_EBP + -0x7c) = 0xf;
    *(undefined *)(unaff_EBP + -0x90) = 0;
    FUN_005542c0("Authenticate-TicketFail",0x17);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    uVar3 = FUN_008cd320(unaff_EBP + -0x90,unaff_EBP + -0x78,0,0);
    FUN_00936dd0(uVar3);
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 9;
    FUN_005507b0();
  }
  if (DAT_01ee420a != '\0') {
    uVar3 = (**(code **)(*piVar1 + 4))();
    FUN_01677650(DAT_01ee420a,"ServerReplicator:InstallRemotePlayer - Authenticate-TicketFail: %s",
                 uVar3);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7610 ; VA 0x0065c978 ; Catch@0065c978 */

void Catch_0065c978(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("ticket signature not verified. (installRemotePlayer)");
}



/* FUNCTION 7611 ; VA 0x0065c990 ; FUN_0065c990 */

int FUN_0065c990(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1fa8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00643370();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 7612 ; VA 0x0065ca10 ; FUN_0065ca10 */

int FUN_0065ca10(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1d78;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    iVar3 = FUN_0065add0();
    if ((char)iVar3 != '\0') {
      if (*(char *)(iVar2 + 0xa1) == '\0') {
        uStack_18 = 0;
        uStack_18._4_4_ = 0;
        uStack_18._0_4_ = 0;
        uVar5 = (uint)uStack_18;
        iVar3 = uStack_18._4_4_;
      }
      else {
        uVar5 = *(uint *)(iVar2 + 0x98);
        iVar3 = *(int *)(iVar2 + 0x9c);
      }
      if ((iVar3 < (int)DAT_01d5a7cc >> 0x1f) ||
         ((iVar3 <= (int)DAT_01d5a7cc >> 0x1f && (uVar5 < DAT_01d5a7cc)))) {
        if ((*(char *)(iVar2 + 0x31) == '\0') || (*(char *)(iVar2 + 0x30) == '\0')) {
          uVar4 = 0;
        }
        else if ((*(char *)(iVar2 + 0x69) == '\0') || (*(char *)(iVar2 + 0x68) == '\0')) {
          uVar4 = 2;
        }
        else {
          uVar4 = 3;
        }
      }
      else {
        uVar4 = 1;
      }
      iVar3 = FUN_0065b4a0(uVar4);
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 7613 ; VA 0x0065cb00 ; FUN_0065cb00 */

undefined4 __fastcall FUN_0065cb00(int param_1)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2024;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1;
  if (DAT_01d5acf0 == '\0') {
    uVar3 = *(undefined4 *)(param_1 + 0x78);
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005f77e0();
  }
  iVar4 = Ordinal_14(uVar3);
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  iStack_14 = iVar4;
  if ((*(int *)(iVar1 + 0x34) < DAT_01eadb50) && (FUN_016f3809(&DAT_01eadb50), DAT_01eadb50 == -1))
  {
    iVar5 = DAT_01d5a738;
    if (DAT_01d5a738 < 0x3c) {
      iVar5 = 0x3c;
    }
    FUN_00650fe0(&DAT_01d5a990,iVar5);
    FUN_016f3654(&LAB_0187d790);
    FUN_016f37bf(&DAT_01eadb50);
  }
  if ((*(int *)(iVar1 + 0x34) < DAT_01eadbd0) && (FUN_016f3809(&DAT_01eadbd0), DAT_01eadbd0 == -1))
  {
    iVar5 = DAT_01d5a738;
    if (DAT_01d5a738 < 0x3c) {
      iVar5 = 0x3c;
    }
    FUN_00650fe0(&DAT_01d5a978,iVar5);
    FUN_016f3654(&LAB_0187d7b0);
    FUN_016f37bf(&DAT_01eadbd0);
  }
  cVar2 = FUN_00659960(&iStack_14);
  if (cVar2 != '\0') {
    ExceptionList = pvStack_10;
    return 1;
  }
  cVar2 = FUN_00659960(&iStack_14);
  if ((cVar2 == '\0') && (DAT_01ead7f4 != 0)) {
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadbe0) && (FUN_016f3809(&DAT_01eadbe0), DAT_01eadbe0 == -1)
       ) {
      uStack_8 = 0;
      FUN_00651060(&PTR_s_3_0_0_0_15_01d5d1c8);
      FUN_016f3654(&LAB_0187d470);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadbe0);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadbf0) && (FUN_016f3809(&DAT_01eadbf0), DAT_01eadbf0 == -1)
       ) {
      uStack_8 = 1;
      FUN_00651060(&PTR_s_13_104_144_0_27_01d5d878);
      FUN_016f3654(&LAB_0187d4d0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadbf0);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadc00) && (FUN_016f3809(&DAT_01eadc00), DAT_01eadc00 == -1)
       ) {
      uStack_8 = 2;
      FUN_00651060(&PTR_s_8_34_208_0_20_01d60770);
      FUN_016f3654(&LAB_0187d590);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadc00);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadc10) && (FUN_016f3809(&DAT_01eadc10), DAT_01eadc10 == -1)
       ) {
      uStack_8 = 3;
      FUN_00651060(&PTR_s_5_101_104_0_22_01d5c278);
      FUN_016f3654(&LAB_0187d530);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadc10);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadc20) && (FUN_016f3809(&DAT_01eadc20), DAT_01eadc20 == -1)
       ) {
      uStack_8 = 4;
      FUN_00651060(&PTR_s_23_238_0_0_17_01d5ca58);
      FUN_016f3654(&LAB_0187d5f0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadc20);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadc30) && (FUN_016f3809(&DAT_01eadc30), DAT_01eadc30 == -1)
       ) {
      uStack_8 = 5;
      FUN_00651060(&PTR_s_23_94_12_0_24_01d5cb40);
      FUN_016f3654(&LAB_0187d6b0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadc30);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01eadc40) && (FUN_016f3809(&DAT_01eadc40), DAT_01eadc40 == -1)
       ) {
      uStack_8 = 6;
      FUN_00651060(&PTR_s_23_128_64_0_23_01d5cee0);
      FUN_016f3654(&LAB_0187d650);
      FUN_016f37bf(&DAT_01eadc40);
    }
    if (((DAT_01ead7f4 & 1) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (((DAT_01ead7f4 & 2) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (((DAT_01ead7f4 & 4) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (((DAT_01ead7f4 & 8) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (((DAT_01ead7f4 & 0x10) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (((DAT_01ead7f4 & 0x20) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (((DAT_01ead7f4 & 0x40) != 0) && (cVar2 = FUN_00659a40(iVar4), cVar2 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 7614 ; VA 0x0065d000 ; FUN_0065d000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_0065d000(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_40 [24];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2070;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadad0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadad0);
    if (DAT_01eadad0 == -1) {
      iVar2 = DAT_01d5a738;
      if (DAT_01d5a738 < 0x3c) {
        iVar2 = 0x3c;
      }
      FUN_016dee4c(&DAT_01d5ada0,2);
      _DAT_01d5add0 = 0;
      _DAT_01d5add4 = 0;
      if (iVar2 < 0x3c) {
        iVar2 = 0x3c;
      }
      _DAT_01d5add8 = 0;
      _DAT_01d5addc = &DAT_01d5ac08;
      _DAT_01d5adf0 = 0;
      _DAT_01d5adf4 = 0xf;
      DAT_01d5ade0 = 0;
      _DAT_01d5ae00 = 0;
      _DAT_01d5ae08 = &DAT_018d1b9c;
      PTR_vftable_01d5ad98 = (undefined *)ClientBlockRules::vftable;
      _DAT_01d5adf8 = iVar2;
      FUN_016f3654(&LAB_0187d860);
      FUN_016f37bf(&DAT_01eadad0);
    }
  }
  if (param_2 != 0) {
    if (DAT_01d5acf0 == '\0') {
      FUN_0054ef60(param_2 + 0x1cc);
      uStack_8 = 4;
      FUN_0054ef60(param_2 + 0x1b4);
      uStack_78 = *(undefined4 *)(param_1 + 0x78);
      uStack_8._0_1_ = 5;
      uStack_74 = 0;
      FUN_0054ef60(auStack_40);
      uStack_8._0_1_ = 6;
      FUN_0054ef60(auStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      cVar1 = FUN_0065ab50(&uStack_78);
      FUN_00651cc0();
      FUN_005507b0();
      FUN_005507b0();
      if (cVar1 != '\0') {
        ExceptionList = pvStack_10;
        return 1;
      }
    }
    else {
      FUN_0054ef60(param_2 + 0x1cc);
      uStack_8 = 0;
      FUN_0054ef60(param_2 + 0x1b4);
      uStack_8._0_1_ = 1;
      uStack_78 = FUN_005f77e0();
      uStack_74 = 0;
      FUN_0054ef60(auStack_28);
      uStack_8._0_1_ = 2;
      FUN_0054ef60(auStack_40);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      cVar1 = FUN_0065ab50(&uStack_78);
      FUN_00651cc0();
      FUN_005507b0();
      FUN_005507b0();
      if (cVar1 != '\0') {
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 7615 ; VA 0x0065d260 ; FUN_0065d260 */

undefined __fastcall FUN_0065d260(int param_1)

{
  return *(undefined *)(param_1 + 0x3f68);
}



/* FUNCTION 7616 ; VA 0x0065d270 ; FUN_0065d270 */

undefined4 FUN_0065d270(undefined4 param_1)

{
  switch(param_1) {
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 0x19:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
    return 1;
  default:
    return 0;
  }
}



/* FUNCTION 7617 ; VA 0x0065d2c0 ; FUN_0065d2c0 */

bool __thiscall FUN_0065d2c0(int param_1,uint param_2)

{
  return (*(uint *)(param_1 + 0x3f78) & param_2) != 0;
}



/* FUNCTION 7618 ; VA 0x0065d2e0 ; FUN_0065d2e0 */

int __thiscall FUN_0065d2e0(int param_1,uint param_2)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x3f74) & param_2;
  uVar2 = (uint3)(uVar1 >> 8);
  if ((param_2 == uVar1) && ((*(uint *)(param_1 + 0x3f78) & param_2) == 0)) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 7619 ; VA 0x0065d310 ; FUN_0065d310 */

void __thiscall FUN_0065d310(int param_1,undefined4 param_2)

{
  code *pcVar1;
  char cVar2;
  undefined uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined auStack_b0 [24];
  undefined auStack_98 [40];
  char acStack_70 [4];
  int iStack_6c;
  uint uStack_58;
  char cStack_54;
  int aiStack_50 [4];
  int iStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a20be;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff44;
  if (((DAT_01d5a9e8 != '\0') && (*(int *)(*(int *)(param_1 + 0x3c1c) + 0x124) != 2)) &&
     (ExceptionList = &pvStack_10, iStack_30 = param_1, cVar2 = FUN_00554b40(), cVar2 != '\0')) {
    if ((*(byte *)(param_1 + 0x3d72) & 8) == 0) {
      uVar4 = (int)*(uint *)(param_1 + 0x3ef4) >> 4;
    }
    else {
      uVar4 = *(uint *)(param_1 + 0x3ef4) >> 1 & 0x7fff;
    }
    if ((DAT_01d5a5c4 <= (int)uVar4) && (DAT_01d5aa00 == '\0')) {
      uStack_38 = 0;
      if (DAT_01d5b288 == '\0') {
        iVar5 = FUN_009edf00();
      }
      else {
        uVar4 = FUN_01679ce0();
        iVar5 = ((~((uVar4 >> 0x18) + (uVar4 >> 0x10) + (uVar4 >> 8)) + 1 & 0xff) +
                (uVar4 & 0xffffff00)) * 0x38e38e39;
      }
      uStack_8 = 0;
      uVar3 = FUN_00643700(&uStack_38,param_2,iVar5);
      param_2 = CONCAT13(uVar3,(undefined3)param_2);
      cVar2 = FUN_01519e70(uStack_38);
      if ((cVar2 == '\0') || (param_2._3_1_ == '\0')) {
        *(undefined *)(param_1 + 0x3f3e) = 2;
        uStack_1c = 0;
        uStack_18 = 0xf;
        auStack_2c[0] = 0;
        FUN_005542c0("DynLua-ServerError",0x12);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_008783f0(auStack_2c,1,0);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      uVar6 = FUN_016f3eb1();
      *(undefined4 *)(param_1 + 0x3f08) = uVar6;
      cStack_54 = '\0';
      uStack_8 = 4;
      FUN_00644760();
      if ((cStack_54 == '\0') || (iStack_40 == 0)) {
        *(undefined *)(param_1 + 0x3f3e) = 2;
        uStack_1c = 0;
        uStack_18 = 0xf;
        auStack_2c[0] = 0;
        FUN_005542c0("DynLua-ServerError",0x12);
        uStack_8._0_1_ = 5;
        FUN_008783f0(auStack_2c,1,0);
        FUN_005507b0();
      }
      else {
        *(undefined *)(param_1 + 0x3f3e) = 1;
        *(undefined *)(param_1 + 0x3f4b) = DAT_01d5a9f0;
        FUN_006ab530();
        uStack_8._0_1_ = 6;
        param_2 = CONCAT31(param_2._1_3_,0x9b);
        FUN_006ad5e0(&param_2,1);
        FUN_006323c0();
        FUN_006323c0();
        FUN_006ae570();
        if ((*(int *)(param_1 + 0x1dc4) != 0) && ((*(uint *)(param_1 + 0x3808) & 0x80000000) == 0))
        {
          FUN_00686d80(acStack_70,aiStack_50);
          uStack_8._0_1_ = 7;
          uVar3 = (undefined)uStack_8;
          uStack_8._0_1_ = 7;
          if (acStack_70[0] == '\0') {
            uStack_8._0_1_ = uVar3;
            if (DAT_01eae4ae != '\0') {
              FUN_016774b0(DAT_01eae4ae,
                           "SessionCrypto could not create tag for dynamic lua challenge.",0);
            }
            FUN_0054eff0();
            uStack_8._0_1_ = 8;
            FUN_008783f0(auStack_b0,1,0);
            uStack_8 = CONCAT31(uStack_8._1_3_,7);
            FUN_005507b0();
                    /* WARNING: Subroutine does not return */
            FUN_016757c0();
          }
          FUN_006ae570();
          uStack_8._0_1_ = 6;
          if ((acStack_70[0] != '\0') && (0xf < uStack_58)) {
            uVar4 = uStack_58 + 1;
            iVar5 = iStack_6c;
            if (0xfff < uVar4) {
              iVar5 = *(int *)(iStack_6c + -4);
              uVar4 = uStack_58 + 0x24;
              if (0x1f < (iStack_6c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar5,uVar4);
          }
        }
        piVar7 = (int *)FUN_0054db20();
        pcVar1 = *(code **)(*piVar7 + 0x4c);
        FUN_0060ed10(param_1 + 0x74);
        (*pcVar1)(auStack_98,2,3,0);
        FUN_00613200();
      }
      if (cStack_54 == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      if (uStack_3c < 0x10) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar4 = uStack_3c + 1;
      iVar5 = aiStack_50[0];
      if (0xfff < uVar4) {
        iVar5 = *(int *)(aiStack_50[0] + -4);
        uVar4 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar4);
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined *)(param_1 + 0x3f3e) = 2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7620 ; VA 0x0065d677 ; Catch_All@0065d677 */

undefined4 Catch_All_0065d677(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x18) = 0;
  *(undefined *)(*(int *)(unaff_EBP + -0x2c) + 0x3f3e) = 2;
  *(undefined4 *)(unaff_EBP + -0x14) = 0xf;
  *(undefined *)(unaff_EBP + -0x28) = 0;
  FUN_005542c0("DynLua-ServerError",0x12);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_008783f0(unaff_EBP + -0x28,1,0);
  FUN_005507b0();
  return 0x65d6cb;
}



/* FUNCTION 7621 ; VA 0x0065d750 ; FUN_0065d750 */

char * FUN_0065d750(undefined4 param_1)

{
  switch(param_1) {
  case 1:
    return "NewSecurityKeyDuringJoin";
  case 2:
    return "SecurityKeyDuringJoin";
  case 3:
    return "BadHashDuringJoin";
  case 4:
    return "DuplicateDuringJoin";
  case 5:
    return "PacketErrorDuringJoin";
  case 6:
    return "PlayerlessDuringJoin";
  case 7:
    return "MovedPlayerFe";
  case 8:
    return "ScornMisc";
  case 9:
    return "RemoteHashOld";
  case 10:
    return "Timeout";
  case 0xb:
    return "MiscRemoteTampering";
  case 0xc:
    return "HashMisc";
  case 0xd:
    return "HashNew";
  case 0xe:
    return "HashGold";
  case 0xf:
    return "MiscOldChecks";
  case 0x10:
    return "HumanoidChecks";
  case 0x11:
    return "CheatEngine";
  case 0x12:
    return "Debugger";
  case 0x13:
    return "VehChecks";
  case 0x14:
    return "HashLocal";
  case 0x15:
    return "ReturnChecks";
  case 0x16:
    return "OldLuaChecks";
  case 0x17:
    return "ConstChange";
  case 0x18:
    return "PlatformChecks";
  case 0x19:
    return "TicketCheck";
  case 0x1a:
    return "DosPrevention";
  case 0x1b:
    return "SuspiciousModule";
  case 0x1c:
    return "HooksCheck";
  case 0x1d:
    return "ThreadTamper";
  case 0x1e:
    return "SecurityPolicy";
  case 0x1f:
    return "BlockedIP";
  case 0x20:
    return "DynLuaChallenge";
  case 0x21:
    return "DynLuaChallengeTimeout";
  case 0x22:
    return "DynIpBlacklistedIP";
  case 0x23:
    return "DynIpBot";
  case 0x24:
    return "TupleTrick";
  case 0x25:
    return "NameFake";
  default:
    return "UnknownReason";
  }
}



/* FUNCTION 7622 ; VA 0x0065d910 ; FUN_0065d910 */

int * FUN_0065d910(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0065d9bb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0065d94e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d98084);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_bd0ecf31b315c692998691fa144e1377>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 7623 ; VA 0x0065d9d0 ; FUN_0065d9d0 */

void FUN_0065d9d0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a20e2;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0xb8);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_0064fec0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xb4);
        ExceptionList = &pvStack_10;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          ExceptionList = &pvStack_10;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_00651d50();
        FUN_01674ea0(iVar3,0xb8);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9804c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_c52279ee33afa36dbbf93dfb46ebb4b6>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 7624 ; VA 0x0065db40 ; FUN_0065db40 */

void FUN_0065db40(undefined4 param_1,undefined4 param_2)

{
  FUN_0065dbc0(param_2);
  return;
}



/* FUNCTION 7625 ; VA 0x0065db60 ; FUN_0065db60 */

undefined FUN_0065db60(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  
  uVar1 = param_2[4];
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar3,uVar1,&DAT_018c0df0,1);
  if (cVar2 == '\0') {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar3 = param_1 + 4;
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    cVar2 = FUN_0055c360(param_1,*puVar3,param_2,uVar1);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 7626 ; VA 0x0065dbc0 ; FUN_0065dbc0 */

undefined4 __thiscall FUN_0065dbc0(int *param_1,int *param_2)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  
  if ((*param_2 != 0 || param_2[1] != 0) && ((*param_1 != *param_2 || (param_1[1] != param_2[1]))))
  {
    return 0;
  }
  piVar4 = param_2 + 2;
  iVar1 = param_2[6];
  piVar3 = piVar4;
  if (0xf < (uint)param_2[7]) {
    piVar3 = (int *)*piVar4;
  }
  cVar2 = FUN_0055c360(piVar3,iVar1,&DAT_018c0df0,1);
  if (cVar2 == '\0') {
    piVar3 = param_1 + 2;
    if (0xf < (uint)param_2[7]) {
      piVar4 = (int *)*piVar4;
    }
    if (0xf < (uint)param_1[7]) {
      piVar3 = (int *)*piVar3;
    }
    cVar2 = FUN_0055c360(piVar3,param_1[6],piVar4,iVar1);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  piVar4 = param_2 + 8;
  iVar1 = param_2[0xc];
  piVar3 = piVar4;
  if (0xf < (uint)param_2[0xd]) {
    piVar3 = (int *)*piVar4;
  }
  cVar2 = FUN_0055c360(piVar3,iVar1,&DAT_018c0df0,1);
  if (cVar2 == '\0') {
    piVar3 = param_1 + 8;
    if (0xf < (uint)param_2[0xd]) {
      piVar4 = (int *)*piVar4;
    }
    if (0xf < (uint)param_1[0xd]) {
      piVar3 = (int *)*piVar3;
    }
    cVar2 = FUN_0055c360(piVar3,param_1[0xc],piVar4,iVar1);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 7627 ; VA 0x0065dca0 ; FUN_0065dca0 */

undefined4 FUN_0065dca0(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if ((((uVar1 != param_1[1]) || (uVar1 != 0)) && (*param_2 <= uVar1)) && (uVar1 <= param_2[1])) {
    return 1;
  }
  return 0;
}



/* FUNCTION 7628 ; VA 0x0065dcd0 ; FUN_0065dcd0 */

uint FUN_0065dcd0(undefined4 *param_1)

{
  undefined4 *puVar1;
  byte bVar2;
  char cVar3;
  byte *pbVar4;
  byte *pbVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  bool bVar10;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a20f8;
  pvStack_10 = ExceptionList;
  uStack_1c = param_1[4];
  uStack_14 = 0;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  puStack_2c = (undefined4 *)0x0;
  puStack_28 = (undefined4 *)0x0;
  iStack_24 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  FUN_01683a90(&puStack_2c,0x3b,0xffffffff,0);
  puVar1 = puStack_28;
  uVar8 = 0;
  puVar9 = puStack_2c;
  do {
    if (puVar9 == puVar1) {
      if (puStack_2c != (undefined4 *)0x0) {
        uVar6 = iStack_24 - (int)puStack_2c & 0xfffffff8;
        puVar9 = puStack_2c;
        if (0xfff < uVar6) {
          puVar9 = (undefined4 *)puStack_2c[-1];
          uVar6 = uVar6 + 0x23;
          if (0x1f < (uint)((int)puStack_2c + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar9,uVar6);
      }
      ExceptionList = pvStack_10;
      return uVar8;
    }
    piVar7 = (int *)*puVar9;
    if (puVar9[1] == 0xc) {
      pbVar4 = &DAT_018d1bb8;
      uVar8 = 8;
      do {
        if (*piVar7 != *(int *)pbVar4) {
          bVar2 = (byte)*piVar7;
          bVar10 = bVar2 < *pbVar4;
          if ((((bVar2 == *pbVar4) &&
               (bVar10 = *(byte *)((int)piVar7 + 1) < pbVar4[1],
               *(byte *)((int)piVar7 + 1) == pbVar4[1])) &&
              (bVar10 = *(byte *)((int)piVar7 + 2) < pbVar4[2],
              *(byte *)((int)piVar7 + 2) == pbVar4[2])) &&
             (bVar10 = *(byte *)((int)piVar7 + 3) < pbVar4[3],
             *(byte *)((int)piVar7 + 3) == pbVar4[3])) {
            uVar8 = 0;
          }
          else {
            uVar8 = -(uint)bVar10 | 1;
          }
          goto LAB_0065dd8c;
        }
        piVar7 = piVar7 + 1;
        pbVar4 = pbVar4 + 4;
        bVar10 = 3 < uVar8;
        uVar8 = uVar8 - 4;
      } while (bVar10);
      uVar8 = 0;
LAB_0065dd8c:
      if (uVar8 != 0) goto LAB_0065dd9b;
      uStack_14 = uStack_14 | 4;
    }
    else {
LAB_0065dd9b:
      pbVar4 = (byte *)*puVar9;
      if (puVar9[1] == 0x15) {
        pbVar5 = &DAT_018d1bc8;
        uVar8 = 0x11;
        do {
          if (*(int *)pbVar4 != *(int *)pbVar5) break;
          pbVar4 = pbVar4 + 4;
          pbVar5 = pbVar5 + 4;
          bVar10 = 3 < uVar8;
          uVar8 = uVar8 - 4;
        } while (bVar10);
        bVar10 = *pbVar4 < *pbVar5;
        if ((*pbVar4 == *pbVar5) &&
           ((uVar8 == 0xfffffffd ||
            (((bVar10 = pbVar4[1] < pbVar5[1], pbVar4[1] == pbVar5[1] &&
              (bVar10 = pbVar4[2] < pbVar5[2], pbVar4[2] == pbVar5[2])) &&
             (bVar10 = pbVar4[3] < pbVar5[3], pbVar4[3] == pbVar5[3])))))) {
          uVar8 = 0;
        }
        else {
          uVar8 = -(uint)bVar10 | 1;
        }
        if (uVar8 == 0) {
          uStack_14 = uStack_14 | 8;
          goto LAB_0065de87;
        }
      }
      pbVar4 = (byte *)*puVar9;
      if (puVar9[1] == 0x16) {
        pbVar5 = &DAT_018d1be0;
        uVar8 = 0x12;
        do {
          if (*(int *)pbVar4 != *(int *)pbVar5) break;
          pbVar4 = pbVar4 + 4;
          pbVar5 = pbVar5 + 4;
          bVar10 = 3 < uVar8;
          uVar8 = uVar8 - 4;
        } while (bVar10);
        bVar10 = *pbVar4 < *pbVar5;
        if (((*pbVar4 == *pbVar5) && (bVar10 = pbVar4[1] < pbVar5[1], pbVar4[1] == pbVar5[1])) &&
           ((uVar8 == 0xfffffffe ||
            ((bVar10 = pbVar4[2] < pbVar5[2], pbVar4[2] == pbVar5[2] &&
             (bVar10 = pbVar4[3] < pbVar5[3], pbVar4[3] == pbVar5[3])))))) {
          uVar8 = 0;
        }
        else {
          uVar8 = -(uint)bVar10 | 1;
        }
        if (uVar8 == 0) {
          uStack_14 = uStack_14 | 0x10;
          goto LAB_0065de87;
        }
      }
      cVar3 = FUN_006522d0(*puVar9,puVar9[1],"eval_suspicious",0xf);
      if (cVar3 != '\0') {
        uStack_14 = uStack_14 | 0x20;
      }
    }
LAB_0065de87:
    puVar9 = puVar9 + 2;
    uVar8 = uStack_14;
  } while( true );
}



/* FUNCTION 7629 ; VA 0x0065dee0 ; FUN_0065dee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0065dee0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,
                 undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined uVar4;
  undefined uVar5;
  char cVar6;
  uint *puVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  uint auStack_158 [4];
  undefined4 uStack_148;
  uint uStack_144;
  uint auStack_140 [4];
  undefined4 uStack_130;
  uint uStack_12c;
  uint auStack_128 [4];
  undefined4 uStack_118;
  uint uStack_114;
  uint auStack_110 [4];
  undefined4 uStack_100;
  uint uStack_fc;
  uint auStack_f8 [4];
  undefined4 uStack_e8;
  uint uStack_e4;
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  uint uStack_c8;
  uint uStack_c4;
  uint uStack_c0;
  uint uStack_bc;
  undefined8 uStack_b8;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  uint uStack_98;
  uint uStack_94;
  uint uStack_90;
  uint uStack_8c;
  undefined8 uStack_88;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  undefined8 uStack_70;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  int iStack_18;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a21c9;
  pvStack_10 = ExceptionList;
  uStack_b8 = 0xf00000000;
  uStack_c8 = uStack_c8 & 0xffffff00;
  uStack_a0 = 0xf00000000;
  uStack_b0 = uStack_b0 & 0xffffff00;
  uStack_88 = 0xf00000000;
  uStack_98 = uStack_98 & 0xffffff00;
  uStack_70 = 0xf00000000;
  uStack_80 = uStack_80 & 0xffffff00;
  uStack_58 = 0xf00000000;
  uStack_68 = uStack_68 & 0xffffff00;
  uStack_40 = 0xf00000000;
  uStack_50 = uStack_50 & 0xffffff00;
  uStack_8 = 5;
  uStack_11 = 0;
  uStack_12 = 0;
  ExceptionList = &pvStack_10;
  puVar7 = (uint *)FUN_006acbd0(aiStack_30);
  if (&uStack_c8 != puVar7) {
    FUN_005507b0();
    uStack_c8 = *puVar7;
    uStack_c4 = puVar7[1];
    uStack_c0 = puVar7[2];
    uStack_bc = puVar7[3];
    uStack_b8 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
  }
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    iVar8 = aiStack_30[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_30[0] + -4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  puVar7 = (uint *)FUN_006acbd0(aiStack_30);
  if (&uStack_b0 != puVar7) {
    FUN_005507b0();
    uStack_b0 = *puVar7;
    uStack_ac = puVar7[1];
    uStack_a8 = puVar7[2];
    uStack_a4 = puVar7[3];
    uStack_a0 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
  }
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    iVar8 = aiStack_30[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_30[0] + -4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  puVar7 = (uint *)FUN_006acbd0(aiStack_30);
  if (&uStack_98 != puVar7) {
    FUN_005507b0();
    uStack_98 = *puVar7;
    uStack_94 = puVar7[1];
    uStack_90 = puVar7[2];
    uStack_8c = puVar7[3];
    uStack_88 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
  }
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    iVar8 = aiStack_30[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_30[0] + -4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  puVar7 = (uint *)FUN_006acbd0(aiStack_30);
  if (&uStack_80 != puVar7) {
    FUN_005507b0();
    uStack_80 = *puVar7;
    uStack_7c = puVar7[1];
    uStack_78 = puVar7[2];
    uStack_74 = puVar7[3];
    uStack_70 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
  }
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    iVar8 = aiStack_30[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_30[0] + -4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  puVar7 = (uint *)FUN_006acbd0(aiStack_30);
  if (&uStack_68 != puVar7) {
    FUN_005507b0();
    uStack_68 = *puVar7;
    uStack_64 = puVar7[1];
    uStack_60 = puVar7[2];
    uStack_5c = puVar7[3];
    uStack_58 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
  }
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    iVar8 = aiStack_30[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_30[0] + -4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  puVar7 = (uint *)FUN_006acbd0(aiStack_30);
  if (&uStack_50 != puVar7) {
    FUN_005507b0();
    uStack_50 = *puVar7;
    uStack_4c = puVar7[1];
    uStack_48 = puVar7[2];
    uStack_44 = puVar7[3];
    uStack_40 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
  }
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    iVar8 = aiStack_30[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_30[0] + -4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  if (param_4 != 0) {
    uStack_11 = FUN_006abe40();
    uStack_12 = FUN_006abe40();
  }
  iVar8 = iStack_18;
  LOCK();
  *(int *)(iStack_18 + 0x3f6c) = *(int *)(iStack_18 + 0x3f6c) + 1;
  UNLOCK();
  FUN_00659f50(auStack_158,&uStack_c8);
  uStack_8._0_1_ = 6;
  FUN_00659f50(auStack_f8,&uStack_b0);
  uStack_8._0_1_ = 7;
  FUN_00659f50(auStack_e0,&uStack_98);
  uStack_8._0_1_ = 8;
  FUN_00659f50(auStack_140,&uStack_80);
  uStack_8._0_1_ = 9;
  FUN_00659f50(auStack_128,&uStack_68);
  uStack_8._0_1_ = 10;
  FUN_00659f50(auStack_110,&uStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (*(int *)(iVar8 + 0x3c0c) != 0) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eada9c)
       && (FUN_016f3809(&DAT_01eada9c), DAT_01eada9c == -1)) {
      iVar8 = DAT_01d5a738;
      if (DAT_01d5a738 < 0x3c) {
        iVar8 = 0x3c;
      }
      FUN_016dee4c(&DAT_01d5ad28,2);
      DAT_01d5ad58 = 0;
      DAT_01d5ad5c = 0;
      if (iVar8 < 0x3c) {
        iVar8 = 0x3c;
      }
      _DAT_01d5ad60 = 0;
      _DAT_01d5ad64 = &DAT_01d5a9a8;
      _DAT_01d5ad78 = 0;
      _DAT_01d5ad7c = 0xf;
      DAT_01d5ad68 = 0;
      _DAT_01d5ad88 = 0;
      _DAT_01d5ad90 = &DAT_018d1b9c;
      PTR_vftable_01d5ad20 = (undefined *)ClientCrashRules::vftable;
      _DAT_01d5ad80 = iVar8;
      FUN_016f3654(&LAB_0187d770);
      FUN_016f37bf(&DAT_01eada9c);
    }
    iVar8 = FUN_016dee6d(&DAT_01d5ad28);
    if (iVar8 != 0) {
      FUN_016df3c9(iVar8);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    FUN_00658e50();
    iVar2 = DAT_01d5ad5c;
    for (iVar8 = DAT_01d5ad58; iVar8 != iVar2; iVar8 = iVar8 + 0x18) {
      cVar6 = (**(code **)(PTR_vftable_01d5ad20 + 4))(auStack_e0,iVar8);
      if (cVar6 != '\0') {
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
        iVar8 = FUN_016deec8(&DAT_01d5ad28);
        if (iVar8 != 0) {
          FUN_016df3c9(iVar8);
        }
        uStack_8._0_1_ = 0xb;
        if (DAT_01d5ad18 == 0xffffffff) {
          uVar11 = FUN_01679ce0();
          DAT_01d5ad18 = uVar11 % 10000;
        }
        if ((int)DAT_01d5ad18 < DAT_01ead7b8) {
          iVar8 = FUN_01674e20(0x30);
          uStack_8._0_1_ = 0xf;
          if (iVar8 == 0) {
            uVar9 = 0;
          }
          else {
            uVar9 = FUN_0071a160(iStack_18);
          }
          uStack_8._0_1_ = 0xb;
          FUN_006b1f50(uVar9);
        }
        goto LAB_0065e3bd;
      }
    }
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    iVar8 = FUN_016deec8(&DAT_01d5ad28);
    if (iVar8 != 0) {
      FUN_016df3c9(iVar8);
    }
    uStack_8._0_1_ = 0xb;
LAB_0065e3bd:
    uVar5 = uStack_11;
    FUN_00668de0(uStack_11);
    uVar4 = uStack_12;
    FUN_006691b0(uStack_12);
    FUN_00669300(param_5,auStack_f8);
    piStack_34 = (int *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 0x10;
    if (piStack_34 == (int *)0x0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_0151f6f0(0xffffffff,0,0);
    }
    uStack_8._0_1_ = 0xb;
    uStack_38 = 0;
    piStack_34 = (int *)0x0;
    FUN_0064daf0(uVar9,param_5);
    uVar9 = uStack_38;
    uStack_8._0_1_ = 0x11;
    FUN_0151f950(&DAT_018d26f4,auStack_158);
    FUN_0151f950(&DAT_018d279c,auStack_f8);
    FUN_0151f950(&DAT_018d27a0,auStack_e0);
    FUN_0151f950(&DAT_018d27a4,auStack_140);
    FUN_0151f950(&DAT_018d27a8,auStack_128);
    FUN_0151f950(&DAT_018d27ec,auStack_110);
    uVar10 = FUN_005958a0(aiStack_30,uVar5);
    uStack_8._0_1_ = 0x12;
    FUN_0151f950(&DAT_018d27f0,uVar10);
    uStack_8._0_1_ = 0x11;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_1c) {
      uVar11 = uStack_1c + 1;
      iVar8 = aiStack_30[0];
      if (0xfff < uVar11) {
        iVar8 = *(int *)(aiStack_30[0] + -4);
        uVar11 = uStack_1c + 0x24;
        if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar11);
    }
    uVar10 = FUN_005958a0(aiStack_30,uVar4);
    uStack_8._0_1_ = 0x13;
    FUN_0151f950(&DAT_018d27f4,uVar10);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    if (0xf < uStack_1c) {
      uVar11 = uStack_1c + 1;
      iVar8 = aiStack_30[0];
      if (0xfff < uVar11) {
        iVar8 = *(int *)(aiStack_30[0] + -4);
        uVar11 = uStack_1c + 0x24;
        if (0x1f < (aiStack_30[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar11);
    }
    FUN_0151f850(&DAT_018d27f8,&DAT_018bc9b8);
    FUN_0151f850(&DAT_018d27fc,&DAT_018bc9b8);
    piVar3 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
    }
    FUN_0066d800(param_1,param_2,param_3,param_5,uVar9,piStack_34);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar8 = piVar3[1] + -1;
      piVar3[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  if (0xf < uStack_fc) {
    uVar12 = uStack_fc + 1;
    uVar11 = auStack_110[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_110[0] - 4);
      uVar12 = uStack_fc + 0x24;
      if (0x1f < (auStack_110[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_100 = 0;
  uStack_fc = 0xf;
  auStack_110[0] = auStack_110[0] & 0xffffff00;
  if (0xf < uStack_114) {
    uVar12 = uStack_114 + 1;
    uVar11 = auStack_128[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_128[0] - 4);
      uVar12 = uStack_114 + 0x24;
      if (0x1f < (auStack_128[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_118 = 0;
  uStack_114 = 0xf;
  auStack_128[0] = auStack_128[0] & 0xffffff00;
  if (0xf < uStack_12c) {
    uVar12 = uStack_12c + 1;
    uVar11 = auStack_140[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_140[0] - 4);
      uVar12 = uStack_12c + 0x24;
      if (0x1f < (auStack_140[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_130 = 0;
  uStack_12c = 0xf;
  auStack_140[0] = auStack_140[0] & 0xffffff00;
  if (0xf < uStack_cc) {
    uVar12 = uStack_cc + 1;
    uVar11 = auStack_e0[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_e0[0] - 4);
      uVar12 = uStack_cc + 0x24;
      if (0x1f < (auStack_e0[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = auStack_e0[0] & 0xffffff00;
  if (0xf < uStack_e4) {
    uVar12 = uStack_e4 + 1;
    uVar11 = auStack_f8[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_f8[0] - 4);
      uVar12 = uStack_e4 + 0x24;
      if (0x1f < (auStack_f8[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_e8 = 0;
  uStack_e4 = 0xf;
  auStack_f8[0] = auStack_f8[0] & 0xffffff00;
  if (0xf < uStack_144) {
    uVar12 = uStack_144 + 1;
    uVar11 = auStack_158[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_158[0] - 4);
      uVar12 = uStack_144 + 0x24;
      if (0x1f < (auStack_158[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_148 = 0;
  uStack_144 = 0xf;
  auStack_158[0] = auStack_158[0] & 0xffffff00;
  if (0xf < uStack_40._4_4_) {
    uVar12 = uStack_40._4_4_ + 1;
    uVar11 = uStack_50;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_50 - 4);
      uVar12 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uStack_50 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_40 = 0xf00000000;
  uStack_50 = uStack_50 & 0xffffff00;
  if (0xf < uStack_58._4_4_) {
    uVar12 = uStack_58._4_4_ + 1;
    uVar11 = uStack_68;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_68 - 4);
      uVar12 = uStack_58._4_4_ + 0x24;
      if (0x1f < (uStack_68 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_58 = 0xf00000000;
  uStack_68 = uStack_68 & 0xffffff00;
  if (0xf < uStack_70._4_4_) {
    uVar12 = uStack_70._4_4_ + 1;
    uVar11 = uStack_80;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_80 - 4);
      uVar12 = uStack_70._4_4_ + 0x24;
      if (0x1f < (uStack_80 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_70 = 0xf00000000;
  uStack_80 = uStack_80 & 0xffffff00;
  if (0xf < uStack_88._4_4_) {
    uVar12 = uStack_88._4_4_ + 1;
    uVar11 = uStack_98;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_98 - 4);
      uVar12 = uStack_88._4_4_ + 0x24;
      if (0x1f < (uStack_98 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_88 = 0xf00000000;
  uStack_98 = uStack_98 & 0xffffff00;
  if (0xf < uStack_a0._4_4_) {
    uVar12 = uStack_a0._4_4_ + 1;
    uVar11 = uStack_b0;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_b0 - 4);
      uVar12 = uStack_a0._4_4_ + 0x24;
      if (0x1f < (uStack_b0 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_a0 = 0xf00000000;
  uStack_b0 = uStack_b0 & 0xffffff00;
  if (0xf < uStack_b8._4_4_) {
    uVar12 = uStack_b8._4_4_ + 1;
    uVar11 = uStack_c8;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_c8 - 4);
      uVar12 = uStack_b8._4_4_ + 0x24;
      if (0x1f < (uStack_c8 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7630 ; VA 0x0065eb50 ; FUN_0065eb50 */

void __thiscall
FUN_0065eb50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 ***pppuVar5;
  int iVar6;
  undefined4 *puVar7;
  uint *puVar8;
  uint uVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  bool bVar13;
  undefined4 uStack00000018;
  undefined *puVar14;
  char *pcVar15;
  undefined1 *puVar16;
  undefined auStack_1e4 [24];
  undefined auStack_1cc [24];
  undefined auStack_1b4 [24];
  undefined auStack_19c [24];
  undefined auStack_184 [16];
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined auStack_16c [16];
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined auStack_154 [16];
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined auStack_13c [24];
  undefined auStack_124 [16];
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined auStack_10c [16];
  int iStack_fc;
  undefined4 uStack_f8;
  undefined auStack_f4 [16];
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 **appuStack_dc [4];
  undefined4 uStack_cc;
  uint uStack_c8;
  undefined auStack_c4 [12];
  undefined auStack_b8 [8];
  int *piStack_b0;
  undefined auStack_ac [4];
  undefined4 uStack_a8;
  undefined auStack_a4 [16];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined auStack_8c [8];
  undefined auStack_84 [4];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  uint uStack_78;
  undefined auStack_74 [24];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [8];
  undefined auStack_4c [8];
  undefined auStack_44 [8];
  undefined4 auStack_3c [2];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined auStack_1c [4];
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a239a;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe10;
  iStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_b0 = param_1;
  FUN_006acbd0(auStack_1cc);
  uStack_8 = 0;
  FUN_0054ef60(auStack_1cc);
  FUN_012559f0(auStack_1b4);
  uStack_8._0_1_ = 2;
  FUN_016819e0(auStack_c4,auStack_1b4);
  uStack_8._0_1_ = 3;
  cVar2 = FUN_016816d0();
  if (cVar2 != '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid JSON");
  }
  cVar2 = FUN_01681870();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Generic report should be object");
  }
  FUN_0167eea0(auStack_b8,&DAT_018c7ed0);
  cVar2 = FUN_0167e580();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("No \'type\' node");
  }
  uStack_94 = 0;
  uStack_90 = 0xf;
  auStack_a4[0] = 0;
  uStack_8._0_1_ = 4;
  puVar3 = (undefined4 *)FUN_01681580(auStack_124,auStack_a4);
  puVar7 = puVar3 + 4;
  if (0xf < (uint)puVar3[5]) {
    puVar3 = (undefined4 *)*puVar3;
  }
  cVar2 = FUN_0055c360(puVar3,*puVar7,"module",6);
  FUN_005507b0();
  uStack_8._0_1_ = 3;
  FUN_005507b0();
  if (cVar2 == '\0') {
    uStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = 0;
    uStack_8._0_1_ = 0x2a;
    puVar3 = (undefined4 *)FUN_01681580(auStack_13c,auStack_a4);
    puVar7 = puVar3 + 4;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar2 = FUN_0055c360(puVar3,*puVar7,"syscall",7);
    FUN_005507b0();
    uStack_8._0_1_ = 3;
    FUN_005507b0();
    if (cVar2 != '\0') {
      uStack_94 = 0;
      uStack_90 = 0xf;
      auStack_a4[0] = 0;
      FUN_005542c0("ExploitsDetection-ApiTamper-SysCall",0x23);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2b);
      FUN_008783f0(auStack_a4,1,0);
      FUN_005507b0();
      FUN_0167ec40();
      FUN_0065fb2d();
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unknown type");
  }
  FUN_0167eea0(auStack_8c,&DAT_018be4a0);
  cVar2 = FUN_01681870();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("No \'data\' node");
  }
  uStack_58 = 0;
  uStack_5c = 0;
  FUN_0167eea0(auStack_84,"detectMethod");
  cVar2 = FUN_01681850();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_84,"detectMethod");
    uStack_58 = FUN_0167e4a0();
  }
  FUN_0167eea0(auStack_84,"loadType");
  cVar2 = FUN_01681850();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_84,"loadType");
    uStack_5c = FUN_0167e4a0();
  }
  FUN_0167eea0(auStack_54,"fileattrs");
  cVar2 = FUN_01681870();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("No \'fileattrs\' node");
  }
  uStack_94 = 0;
  uStack_90 = 0xf;
  auStack_a4[0] = 0;
  uStack_cc = 0;
  uStack_c8 = 0xf;
  appuStack_dc[0] = (undefined4 **)((uint)appuStack_dc[0] & 0xffffff00);
  uStack_174 = 0;
  uStack_170 = 0xf;
  auStack_184[0] = 0;
  uStack_15c = 0;
  uStack_158 = 0xf;
  auStack_16c[0] = 0;
  iStack_fc = 0;
  uStack_f8 = 0xf;
  auStack_10c[0] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  uVar10 = 0;
  uStack_80 = 0;
  FUN_0167eea0(auStack_ac,"location");
  cVar2 = FUN_01681850();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_84,"location");
    uVar10 = FUN_0167e450();
    uStack_80 = uVar10;
  }
  FUN_0167eea0(auStack_ac,&DAT_018c7ed8);
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_ac,&DAT_018c7ed8);
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 10;
    uVar4 = FUN_01681580(auStack_74,&uStack_34);
    uStack_8._0_1_ = 0xb;
    uVar10 = FUN_00659850(auStack_19c,uVar10,uVar4);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_005507b0();
    pppuVar5 = appuStack_dc;
    if (0xf < uStack_c8) {
      pppuVar5 = (undefined4 ***)appuStack_dc[0];
    }
    iVar6 = FUN_0170dd00(pppuVar5,0x5c);
    bVar13 = iVar6 == 0;
    if (bVar13) {
      uVar10 = FUN_0054ef60(appuStack_dc);
    }
    else {
      uVar10 = FUN_0054eff0(iVar6 + 1);
    }
    FUN_005511f0(uVar10);
    if (bVar13) {
      FUN_005507b0();
    }
    uStack_8 = 9;
    if (!bVar13) {
      FUN_005507b0();
    }
  }
  FUN_0167eea0(auStack_1c,"company");
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"company");
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 0xd;
    uVar10 = FUN_01681580(auStack_74,&uStack_34);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_005507b0();
  }
  FUN_0167eea0(auStack_1c,"product");
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"product");
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 0xe;
    uVar10 = FUN_01681580(auStack_74,&uStack_34);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_005507b0();
  }
  FUN_0167eea0(auStack_1c,"matchedRules");
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"matchedRules");
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 0xf;
    uVar10 = FUN_01681580(auStack_74,&uStack_34);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_005507b0();
  }
  FUN_0167eea0(auStack_44,"scanresult");
  cVar2 = FUN_01681870();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("No \'scanresult\' node");
  }
  uStack00000018 = 0;
  uStack_7c = 0;
  uStack_a8 = 0;
  uStack_114 = 0;
  uStack_110 = 0xf;
  auStack_124[0] = 0;
  uStack_144 = 0;
  uStack_140 = 0xf;
  auStack_154[0] = 0;
  iStack_e4 = 0;
  uStack_e0 = 0xf;
  auStack_f4[0] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  FUN_0167eea0(auStack_1c,"mflags");
  cVar2 = FUN_01681850();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"mflags");
    uStack00000018 = FUN_0167e4a0();
  }
  FUN_0167eea0(auStack_1c,"memsize");
  cVar2 = FUN_01681850();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"memsize");
    uStack_7c = FUN_0167e4a0();
  }
  FUN_0167eea0(auStack_1c,"memregions");
  cVar2 = FUN_01681850();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"memregions");
    uStack_a8 = FUN_0167e4a0();
  }
  FUN_0167eea0(auStack_1c,"pehash");
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"pehash");
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 0x13;
    uVar10 = FUN_01681580(auStack_74,&uStack_34);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    FUN_005507b0();
  }
  FUN_0167eea0(auStack_1c,"strhash");
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"strhash");
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 0x14;
    uVar10 = FUN_01681580(auStack_74,&uStack_34);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    FUN_005507b0();
  }
  FUN_0167eea0(auStack_1c,"matchedRules");
  cVar2 = FUN_0167e580();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_1c,"matchedRules");
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 0x15;
    uVar10 = FUN_01681580(auStack_74,&uStack_34);
    FUN_005511f0(uVar10);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    FUN_005507b0();
  }
  if ((iStack_fc != 0) || (iStack_e4 != 0)) {
    LOCK();
    param_1[0xfdb] = param_1[0xfdb] + 1;
    UNLOCK();
  }
  iStack_18 = FUN_01674e20(0x38);
  uStack_8._0_1_ = 0x16;
  if (iStack_18 == 0) {
    uVar10 = 0;
  }
  else {
    uVar10 = FUN_0151f6f0(0xffffffff,0,0);
  }
  uStack_8._0_1_ = 0x12;
  FUN_0064bc40(uVar10);
  uStack_8._0_1_ = 0x17;
  FUN_0151f950(&DAT_018d26f4,auStack_a4);
  FUN_0151f950(&DAT_018d279c,appuStack_dc);
  FUN_0151f950(&DAT_018d27a0,auStack_154);
  FUN_0151f850(&DAT_018d27a4,&DAT_018bc9b8);
  FUN_0151f950(&DAT_018d27a8,auStack_184);
  FUN_0151f950(&DAT_018d27ec,auStack_16c);
  uVar10 = FUN_005958a0(auStack_74,uStack_58);
  uStack_8._0_1_ = 0x18;
  FUN_0151f950(&DAT_018d27f0,uVar10);
  uStack_8._0_1_ = 0x17;
  FUN_005507b0();
  uVar10 = FUN_005958a0(auStack_74,uStack_5c);
  uStack_8._0_1_ = 0x19;
  FUN_0151f950(&DAT_018d27f4,uVar10);
  uStack_8._0_1_ = 0x17;
  FUN_005507b0();
  FUN_0151f850(&DAT_018d27f8,&DAT_018bc9b8);
  puVar16 = &DAT_018bc9b8;
  puVar14 = &DAT_018d27fc;
  FUN_0151f850(&DAT_018d27fc,&DAT_018bc9b8);
  FUN_00557fc0(auStack_4c);
  FUN_0066d800(0,param_3,param_4,param_6,puVar14,puVar16);
  iStack_18 = FUN_01674e20(0x38);
  uStack_8._0_1_ = 0x1a;
  if (iStack_18 == 0) {
    uVar10 = 0;
  }
  else {
    uVar10 = FUN_0151f6f0(0xffffffff,0,0);
  }
  uStack_8._0_1_ = 0x17;
  FUN_0064bc40(uVar10);
  uStack_8._0_1_ = 0x1b;
  uVar10 = FUN_005958a0(auStack_74,uStack_58);
  uStack_8._0_1_ = 0x1c;
  FUN_0151f950("fileDetectMethod",uVar10);
  uStack_8._0_1_ = 0x1b;
  FUN_005507b0();
  uVar10 = FUN_005958a0(auStack_74,uStack_5c);
  uStack_8._0_1_ = 0x1d;
  FUN_0151f950("fileLoadType",uVar10);
  uStack_8._0_1_ = 0x1b;
  FUN_005507b0();
  FUN_0151f950("filePath",appuStack_dc);
  FUN_0151f950("fileCompany",auStack_184);
  FUN_0151f950("fileProduct",auStack_16c);
  FUN_0151f950("fileAttrsRules",auStack_10c);
  iStack_18 = auStack_3c[0];
  puVar3 = (undefined4 *)FUN_0058c590(auStack_13c,uStack00000018,0);
  uStack_8._0_1_ = 0x1e;
  uVar10 = FUN_0066b9e0(auStack_1e4,uStack00000018);
  uStack_8._0_1_ = 0x1f;
  puVar7 = (undefined4 *)FUN_00558c80(auStack_19c,uVar10,&DAT_018d2110);
  uStack_78 = puVar7[4];
  uVar11 = puVar3[4];
  uStack_8 = CONCAT31(uStack_8._1_3_,0x20);
  if ((puVar7[5] - uStack_78 < uVar11) && (uStack_78 <= puVar3[5] - uVar11)) {
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    puVar8 = (uint *)FUN_00585d40(0,puVar7,uStack_78);
  }
  else {
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    puVar8 = (uint *)FUN_00554150(puVar3,uVar11);
  }
  uStack_34 = *puVar8;
  uStack_30 = puVar8[1];
  uStack_2c = puVar8[2];
  uStack_28 = puVar8[3];
  uStack_24 = *(undefined8 *)(puVar8 + 4);
  puVar8[4] = 0;
  puVar8[5] = 0xf;
  *(undefined *)puVar8 = 0;
  uStack_8._0_1_ = 0x21;
  uVar10 = FUN_00558c80(auStack_74,&uStack_34,&DAT_018d2114);
  uStack_8._0_1_ = 0x22;
  FUN_0151f950("fileFlags",uVar10);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  uStack_8._0_1_ = 0x1b;
  FUN_005507b0();
  uVar10 = FUN_0058c590(auStack_13c,uStack_7c,0);
  uStack_8._0_1_ = 0x23;
  FUN_0151f950("fileMemSize",uVar10);
  uStack_8._0_1_ = 0x1b;
  FUN_005507b0();
  uVar10 = FUN_0058c590(auStack_13c,uStack_a8,0);
  uStack_8._0_1_ = 0x24;
  FUN_0151f950("fileMemRegions",uVar10);
  uStack_8._0_1_ = 0x1b;
  FUN_005507b0();
  FUN_0151f950("filePeHash",auStack_124);
  FUN_0151f950("fileStrHash",auStack_154);
  FUN_0151f950("fileStrHitRules",auStack_f4);
  uVar10 = 9;
  pcVar15 = "CsrModule";
  uStack_24 = 0xf00000000;
  uStack_34 = uStack_34 & 0xffffff00;
  FUN_005542c0("CsrModule",9);
  uStack_8._0_1_ = 0x25;
  FUN_00557fc0(auStack_3c);
  FUN_0066d2f0(&uStack_34,0,param_3,param_4,param_6,pcVar15,uVar10);
  uStack_8._0_1_ = 0x1b;
  FUN_005507b0();
  FUN_00668f80(uStack00000018);
  FUN_00668de0(uStack_58);
  FUN_006691b0(uStack_5c);
  FUN_00669cf0(uStack_7c);
  FUN_00669300(uStack_80,appuStack_dc);
  if (iStack_fc != 0) {
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    FUN_005542c0("FileAttrs",9);
    uStack_8._0_1_ = 0x26;
    FUN_00669610(&uStack_34,auStack_10c);
    uStack_8._0_1_ = 0x1b;
    FUN_005507b0();
  }
  if (iStack_e4 != 0) {
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    FUN_005542c0("FileContent",0xb);
    uStack_8._0_1_ = 0x27;
    FUN_00669610(&uStack_34,auStack_f4);
    uStack_8._0_1_ = 0x1b;
    FUN_005507b0();
  }
  if (DAT_01d5ac20 == '\0') goto LAB_0065f9c4;
  uVar12 = DAT_01ead7f8 & 0xfffffffc;
  uStack_24 = 0xf00000000;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_8._0_1_ = 0x28;
  uVar11 = DAT_01ead7f8 & 3;
  if (uVar11 == 0) {
LAB_0065f99d:
    FUN_005542c0("ExploitsDetection-Respond-ReportOnly",0x24);
  }
  else {
    uVar9 = FUN_0065dcd0(auStack_f4);
    if ((uVar9 & uVar12) != 0) {
      if (uVar11 == 1) {
        if (DAT_01d5ac28 == '\0') {
          FUN_005542c0("ExploitsDetection-Respond-Disconnect",0x24);
          (**(code **)(*piStack_b0 + 0x290))("ClientScan",0x1b,1,"Exploits",0);
        }
        else {
          FUN_005542c0("ExploitsDetection-Respond-DisconnectSimul",0x29);
        }
      }
      else if (uVar11 == 2) {
        cVar2 = FUN_00658420();
        if (cVar2 != '\0') {
          if (DAT_01d5ac28 == '\0') {
            FUN_005542c0("ExploitsDetection-Respond-Crash",0x1f);
            piVar1 = piStack_b0;
            iVar6 = FUN_01674e20(0x30);
            uStack_8._0_1_ = 0x29;
            if (iVar6 == 0) {
              uVar10 = 0;
            }
            else {
              uVar10 = FUN_0071a160(piVar1);
            }
            uStack_8._0_1_ = 0x28;
            FUN_006b1f50(uVar10);
          }
          else {
            FUN_005542c0("ExploitsDetection-Respond-CrashSimul",0x24);
          }
        }
      }
    }
    if ((int)uStack_24 == 0) goto LAB_0065f99d;
  }
  FUN_008783f0(&uStack_34,1,0);
  FUN_005507b0();
LAB_0065f9c4:
  FUN_00550b30();
  FUN_00550b30();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_0167ec40();
  FUN_0065fb2d();
  return;
}



/* FUNCTION 7631 ; VA 0x0065fb1d ; Catch@0065fb1d */

undefined * Catch_0065fb1d(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + 0x18) = 0;
  return &DAT_0065fb2a;
}



/* FUNCTION 7632 ; VA 0x0065fb2d ; FUN_0065fb2d */

void FUN_0065fb2d(void)

{
  int unaff_EBP;
  
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 7633 ; VA 0x0065fba0 ; FUN_0065fba0 */

int __thiscall
FUN_0065fba0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            int param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint *puVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  char *pcVar9;
  int aiStack_64 [4];
  int iStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a23ef;
  pvStack_10 = ExceptionList;
  uStack_24 = 0xf00000000;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    puVar4 = (uint *)FUN_006acbd0(aiStack_64);
    if (&uStack_34 != puVar4) {
      FUN_005507b0();
      uStack_34 = *puVar4;
      uStack_30 = puVar4[1];
      uStack_2c = puVar4[2];
      uStack_28 = puVar4[3];
      uStack_24 = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
    if (0xf < uStack_50) {
      uVar7 = uStack_50 + 1;
      iVar5 = aiStack_64[0];
      if (0xfff < uVar7) {
        iVar5 = *(int *)(aiStack_64[0] + -4);
        uVar7 = uStack_50 + 0x24;
        if (0x1f < (aiStack_64[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar7);
    }
  }
  iVar5 = FUN_00659f50(auStack_4c,&uStack_34);
  uStack_8._0_1_ = 1;
  if (*(int *)(param_1 + 0x3c0c) == 0) goto LAB_0065fded;
  pcVar9 = "Unknown";
  if (param_6 == 0) {
    iStack_54 = 0;
    pcVar9 = "LdrLoadDll";
    uStack_50 = 0xf;
    aiStack_64[0] = (uint)aiStack_64[0]._1_3_ << 8;
    FUN_005542c0("ExploitsDetection-ApiTamper-LdrLoadDll",0x26);
    uStack_8._0_1_ = 2;
LAB_0065fd0e:
    FUN_008783f0(aiStack_64,1,0);
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  else {
    if (param_6 == 1) {
      iStack_54 = 0;
      pcVar9 = "NtQueryVirtualMemory";
      uStack_50 = 0xf;
      aiStack_64[0] = (uint)aiStack_64[0]._1_3_ << 8;
      FUN_005542c0("ExploitsDetection-ApiTamper-NtQueryVirtualMemory",0x30);
      uStack_8._0_1_ = 3;
      goto LAB_0065fd0e;
    }
    if (param_6 + -2 == 0) {
      pcVar9 = "NtGetContextThread";
      uStack_50 = 0xf;
      aiStack_64[0] = (uint)aiStack_64[0]._1_3_ << 8;
      iStack_54 = param_6 + -2;
      FUN_005542c0("ExploitsDetection-ApiTamper-NtGetContextThread",0x2e);
      uStack_8._0_1_ = 4;
      goto LAB_0065fd0e;
    }
  }
  iVar5 = FUN_01674e20(0x38);
  uStack_8._0_1_ = 5;
  if (iVar5 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0151f6f0(0xffffffff,0,0);
  }
  uStack_8._0_1_ = 1;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_0064daf0(uVar6,iVar5);
  uStack_8._0_1_ = 6;
  FUN_0151f850(&DAT_018d26f4,pcVar9);
  FUN_0151f950(&DAT_018d279c,auStack_4c);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  iVar5 = FUN_0066d800(param_2,param_3,param_4,param_6,uStack_1c,piStack_18);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
LAB_0065fded:
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    uVar7 = auStack_4c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_4c[0] - 4);
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(uVar7,uVar8);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  if (0xf < uStack_24._4_4_) {
    uVar8 = uStack_24._4_4_ + 1;
    uVar7 = uStack_34;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(uStack_34 - 4);
      uVar8 = uStack_24._4_4_ + 0x24;
      if (0x1f < (uStack_34 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7634 ; VA 0x0065fe90 ; FUN_0065fe90 */

void __thiscall
FUN_0065fe90(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined3 param_7)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined *puVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int aiStack_e8 [5];
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  undefined auStack_2b [3];
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2486;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_58 = param_1;
  FUN_006acbd0(aiStack_e8);
  uStack_8 = 0;
  FUN_006acbd0(auStack_d0);
  uStack_8._0_1_ = 1;
  FUN_006acbd0(auStack_b8);
  uStack_8._0_1_ = 2;
  uVar4 = FUN_006abe40();
  _param_7 = CONCAT13(uVar4,param_7);
  uVar5 = FUN_006ace40();
  uStack_4c = FUN_006ace40();
  uStack_50 = FUN_006ace40();
  uStack_54 = FUN_006ace40();
  uVar6 = FUN_006ace40();
  FUN_00659f50(auStack_a0,aiStack_e8);
  uStack_8._0_1_ = 3;
  FUN_00659f50(auStack_88,auStack_d0);
  uStack_8._0_1_ = 4;
  FUN_00659f50(auStack_70,auStack_b8);
  uStack_8._0_1_ = 5;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (*(int *)(param_1 + 0x3c0c) != 0) {
    piStack_44 = (int *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 6;
    if (piStack_44 == (int *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_0151f6f0(0xffffffff,0,0);
    }
    uStack_8._0_1_ = 5;
    uStack_48 = 0;
    piStack_44 = (int *)0x0;
    FUN_0064daf0(uVar7,_param_7);
    uVar7 = uStack_48;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0151f950(&DAT_018d26f4,auStack_a0);
    FUN_0151f950(&DAT_018d279c,auStack_88);
    puVar8 = (undefined *)FUN_00591870(auStack_2b,uVar5);
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (puVar8 != auStack_2b) {
      FUN_005542c0(puVar8,(int)auStack_2b - (int)puVar8);
    }
    uStack_8._0_1_ = 8;
    FUN_0151f950(&DAT_018d27a0,auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar11 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    puVar8 = (undefined *)FUN_00591870(auStack_2b,uStack_4c);
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (puVar8 != auStack_2b) {
      FUN_005542c0(puVar8,(int)auStack_2b - (int)puVar8);
    }
    uStack_8._0_1_ = 9;
    FUN_0151f950(&DAT_018d27a4,auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar11 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    puVar8 = (undefined *)FUN_00591870(auStack_2b,uVar4);
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (puVar8 != auStack_2b) {
      FUN_005542c0(puVar8,(int)auStack_2b - (int)puVar8);
    }
    uStack_8._0_1_ = 10;
    FUN_0151f950(&DAT_018d27a8,auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar11 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    puVar8 = (undefined *)FUN_00591870(auStack_2b,uStack_50);
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (puVar8 != auStack_2b) {
      FUN_005542c0(puVar8,(int)auStack_2b - (int)puVar8);
    }
    uStack_8._0_1_ = 0xb;
    FUN_0151f950(&DAT_018d27ec,auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar11 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    puVar8 = (undefined *)FUN_00591870(auStack_2b,uStack_54);
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (puVar8 != auStack_2b) {
      FUN_005542c0(puVar8,(int)auStack_2b - (int)puVar8);
    }
    uStack_8._0_1_ = 0xc;
    FUN_0151f950(&DAT_018d27f0,auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar11 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    puVar8 = (undefined *)FUN_00591870(auStack_2b,uVar6);
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (puVar8 != auStack_2b) {
      FUN_005542c0(puVar8,(int)auStack_2b - (int)puVar8);
    }
    uStack_8._0_1_ = 0xd;
    FUN_0151f950(&DAT_018d27f4,auStack_28);
    uStack_8._0_1_ = 7;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar11 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    FUN_0151f950(&DAT_018d27f8,auStack_70);
    FUN_0151f850(&DAT_018d27fc,&DAT_018bc9b8);
    piVar2 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piStack_44[1] = piStack_44[1] + 1;
      UNLOCK();
    }
    FUN_0066d800(param_2,param_3,param_4,param_6,uVar7,piStack_44);
    uVar3 = (undefined)uStack_8;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar9 = piVar2[1] + -1;
      piVar2[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar9 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        uVar3 = (undefined)uStack_8;
        if (iVar9 == 1) {
          (**(code **)(*piVar2 + 4))();
          uVar3 = (undefined)uStack_8;
        }
      }
    }
  }
  uStack_8._0_1_ = uVar3;
  if (0xf < uStack_5c) {
    uVar10 = uStack_5c + 1;
    uVar11 = auStack_70[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_70[0] - 4);
      uVar10 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  if (0xf < uStack_74) {
    uVar10 = uStack_74 + 1;
    uVar11 = auStack_88[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_88[0] - 4);
      uVar10 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  if (0xf < uStack_8c) {
    uVar10 = uStack_8c + 1;
    uVar11 = auStack_a0[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_a0[0] - 4);
      uVar10 = uStack_8c + 0x24;
      if (0x1f < (auStack_a0[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = auStack_a0[0] & 0xffffff00;
  if (0xf < uStack_a4) {
    uVar10 = uStack_a4 + 1;
    uVar11 = auStack_b8[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_b8[0] - 4);
      uVar10 = uStack_a4 + 0x24;
      if (0x1f < (auStack_b8[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = auStack_b8[0] & 0xffffff00;
  if (0xf < uStack_bc) {
    uVar10 = uStack_bc + 1;
    uVar11 = auStack_d0[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_d0[0] - 4);
      uVar10 = uStack_bc + 0x24;
      if (0x1f < (auStack_d0[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  if (0xf < uStack_d4) {
    uVar11 = uStack_d4 + 1;
    iVar9 = aiStack_e8[0];
    if (0xfff < uVar11) {
      iVar9 = *(int *)(aiStack_e8[0] + -4);
      uVar11 = uStack_d4 + 0x24;
      if (0x1f < (aiStack_e8[0] - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar11);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7635 ; VA 0x00660580 ; FUN_00660580 */

void * __thiscall
FUN_00660580(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,int param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  void *pvVar5;
  char *pcVar6;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [16];
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a24bf;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    return ExceptionList;
  }
  pcVar6 = "Unknown";
  if (param_6 == 0) {
    uStack_3c = 0;
    pcVar6 = "Timeout";
    uStack_38 = 0xf;
    auStack_4c[0] = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ThreadTamper-Timeout",0x26);
    uStack_8 = 0;
LAB_0066065d:
    FUN_008783f0(auStack_4c,1,0);
  }
  else {
    if (param_6 == 1) {
      uStack_3c = 0;
      pcVar6 = "Suspended";
      uStack_38 = 0xf;
      auStack_4c[0] = 0;
      ExceptionList = &pvStack_10;
      FUN_005542c0("ExploitsDetection-ThreadTamper-Suspended",0x28);
      uStack_8 = 1;
      goto LAB_0066065d;
    }
    ExceptionList = &pvStack_10;
    if (param_6 + -2 != 0) goto LAB_0066067c;
    pcVar6 = "Exit Unexpectedly";
    uStack_20 = 0xf;
    auStack_34[0] = 0;
    ExceptionList = &pvStack_10;
    iStack_24 = param_6 + -2;
    FUN_005542c0("ExploitsDetection-ThreadTamper-Terminated",0x29);
    uStack_8 = 2;
    FUN_008783f0(auStack_34,1,0);
  }
  uStack_8 = 0xffffffff;
  FUN_005507b0();
LAB_0066067c:
  iStack_14 = FUN_01674e20(0x38);
  uStack_8 = 3;
  if (iStack_14 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0151f6f0(0xffffffff,0,0);
  }
  uStack_8 = 0xffffffff;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_0064daf0(uVar4,param_6);
  uStack_8 = 4;
  FUN_0151f850(&DAT_018d26f4,pcVar6);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  pvVar5 = (void *)FUN_0066d800(param_2,param_3,param_4,param_6,uStack_1c,piStack_18);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar5 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar5 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 7636 ; VA 0x00660750 ; FUN_00660750 */

uint __thiscall FUN_00660750(int *param_1,int *param_2)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined auStack_98 [112];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a24eb;
  pvStack_10 = ExceptionList;
  bVar1 = false;
  ExceptionList = &pvStack_10;
  if ((*(char *)((int)param_1 + 0x3f59) == '\0') &&
     (ExceptionList = &pvStack_10, (DAT_01ead7b0 & 0x10001) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850(&DAT_018c7ed0,"playerless");
    FUN_0151f850("subtype","terrain");
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850("instance",puVar3);
    uVar2 = DAT_01ead7ac;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("AnticheatReport",0xf);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,uVar2,0);
    FUN_005507b0();
    *(undefined *)((int)param_1 + 0x3f59) = 1;
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
    bVar1 = true;
  }
  uVar4 = DAT_01ead7b0 & 0x10000;
  if (uVar4 != 0) {
    bVar1 = true;
  }
  if (bVar1) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850(&DAT_018d20dc,puVar3);
    (**(code **)(*param_1 + 0x294))(0x10f,"PlayerlessCluster",6,uVar4 != 0,auStack_98,0);
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return DAT_01ead7b0 >> 8 & 1;
}



/* FUNCTION 7637 ; VA 0x00660910 ; FUN_00660910 */

uint __thiscall FUN_00660910(int *param_1,int *param_2)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined auStack_98 [112];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a24eb;
  pvStack_10 = ExceptionList;
  bVar1 = false;
  ExceptionList = &pvStack_10;
  if ((*(char *)(param_1 + 0xfd6) == '\0') &&
     (ExceptionList = &pvStack_10, (DAT_01ead7b0 & 0x20002) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850(&DAT_018c7ed0,"playerless");
    FUN_0151f850("subtype","delete");
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850("instance",puVar3);
    uVar2 = DAT_01ead7ac;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("AnticheatReport",0xf);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,uVar2,0);
    FUN_005507b0();
    *(undefined *)(param_1 + 0xfd6) = 1;
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
    bVar1 = true;
  }
  uVar4 = DAT_01ead7b0 & 0x20000;
  if (uVar4 != 0) {
    bVar1 = true;
  }
  if (bVar1) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850(&DAT_018d20dc,puVar3);
    (**(code **)(*param_1 + 0x294))(0x10f,"PlayerlessDelete",6,uVar4 != 0,auStack_98,0);
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return DAT_01ead7b0 >> 9 & 1;
}



/* FUNCTION 7638 ; VA 0x00660ad0 ; FUN_00660ad0 */

uint __thiscall FUN_00660ad0(int *param_1,int *param_2)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined auStack_98 [112];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a24eb;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1[0xf07] + 0x124) != 1) && (*(int *)(param_1[0xf07] + 0x124) != 2)) {
    bVar1 = false;
    ExceptionList = &pvStack_10;
    if ((*(char *)((int)param_1 + 0x3f57) == '\0') &&
       (ExceptionList = &pvStack_10, (DAT_01ead7b0 & 0x40004) != 0)) {
      ExceptionList = &pvStack_10;
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0151f850(&DAT_018c7ed0,"playerless");
      FUN_0151f850("subtype",&DAT_018d4a80);
      if (param_2 == (int *)0x0) {
        puVar3 = (undefined4 *)&DAT_018d4a30;
      }
      else {
        puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
        if (0xf < (uint)puVar3[5]) {
          puVar3 = (undefined4 *)*puVar3;
        }
      }
      FUN_0151f850("instance",puVar3);
      uVar2 = DAT_01ead7ac;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("AnticheatReport",0xf);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_01520d20(auStack_28,uVar2,0);
      FUN_005507b0();
      *(undefined *)((int)param_1 + 0x3f57) = 1;
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
      bVar1 = true;
    }
    uVar4 = DAT_01ead7b0 & 0x40000;
    if (uVar4 != 0) {
      bVar1 = true;
    }
    if (bVar1) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 2;
      if (param_2 == (int *)0x0) {
        puVar3 = (undefined4 *)&DAT_018d4a30;
      }
      else {
        puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
        if (0xf < (uint)puVar3[5]) {
          puVar3 = (undefined4 *)*puVar3;
        }
      }
      FUN_0151f850(&DAT_018d20dc,puVar3);
      (**(code **)(*param_1 + 0x294))(0x10f,"PlayerlessNew",6,uVar4 != 0,auStack_98,0);
      FUN_0151f7f0();
    }
    ExceptionList = pvStack_10;
    return DAT_01ead7b0 >> 10 & 1;
  }
  return 0;
}



/* FUNCTION 7639 ; VA 0x00660cc0 ; FUN_00660cc0 */

uint __thiscall FUN_00660cc0(int *param_1,int *param_2)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined auStack_98 [112];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a24eb;
  pvStack_10 = ExceptionList;
  bVar1 = false;
  ExceptionList = &pvStack_10;
  if ((*(char *)((int)param_1 + 0x3f56) != '\0') &&
     (ExceptionList = &pvStack_10, (DAT_01ead7b0 & 0x100010) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850(&DAT_018c7ed0,"playerless");
    FUN_0151f850("subtype","physics");
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850(&DAT_018cc3a4,puVar3);
    uVar2 = DAT_01ead7ac;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("AnticheatReport",0xf);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,uVar2,0);
    FUN_005507b0();
    *(undefined *)((int)param_1 + 0x3f56) = 1;
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
    bVar1 = true;
  }
  uVar4 = DAT_01ead7b0 & 0x100000;
  if (uVar4 != 0) {
    bVar1 = true;
  }
  if (bVar1) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850(&DAT_018d20dc,puVar3);
    (**(code **)(*param_1 + 0x294))(0x10f,"PlayerlessPhysics",6,uVar4 != 0,auStack_98,0);
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return DAT_01ead7b0 >> 0xc & 1;
}



/* FUNCTION 7640 ; VA 0x00660e80 ; FUN_00660e80 */

uint __thiscall FUN_00660e80(int *param_1,int *param_2,int param_3)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  undefined auStack_98 [112];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a24eb;
  pvStack_10 = ExceptionList;
  bVar1 = false;
  ExceptionList = &pvStack_10;
  if ((*(char *)((int)param_1 + 0x3f5a) == '\0') &&
     (ExceptionList = &pvStack_10, (DAT_01ead7b0 & 0x80008) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850(&DAT_018c7ed0,"playerless");
    FUN_0151f850("subtype",&DAT_018d4a94);
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850("instance",puVar3);
    piVar4 = *(int **)(param_3 + 4);
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    FUN_0151f850("property",piVar4);
    uVar2 = DAT_01ead7ac;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("AnticheatReport",0xf);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,uVar2,0);
    FUN_005507b0();
    *(undefined *)((int)param_1 + 0x3f5a) = 1;
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
    bVar1 = true;
  }
  uVar5 = DAT_01ead7b0 & 0x80000;
  if (uVar5 != 0) {
    bVar1 = true;
  }
  if (bVar1) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    if (param_2 == (int *)0x0) {
      puVar3 = (undefined4 *)&DAT_018d4a30;
    }
    else {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 0x10))();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    FUN_0151f850(&DAT_018d20dc,puVar3);
    (**(code **)(*param_1 + 0x294))(0x10f,"PlayerlessProperty",6,uVar5 != 0,auStack_98,0);
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return DAT_01ead7b0 >> 0xb & 1;
}



/* FUNCTION 7641 ; VA 0x00661060 ; FUN_00661060 */

void __thiscall FUN_00661060(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  double *pdVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  double dStack_28;
  undefined8 uStack_20;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2523;
  pvStack_10 = ExceptionList;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    if (0 < DAT_01ead7b4) {
      ExceptionList = &pvStack_10;
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8 = 0;
      if (*(int *)(param_1 + 0x3c0c) == 0) {
        uVar6 = *(undefined8 *)(param_1 + 0x3d90);
      }
      else {
        uVar6 = FUN_00928340();
      }
      FUN_0151fbb0("chsr-id",uVar6);
      uVar2 = FUN_005f2c00();
      FUN_0151f850("platform",uVar2);
      FUN_0151fa60(&DAT_018d4c34,*(undefined4 *)(param_1 + 0x3efc));
      FUN_0151fa60(&DAT_018d4c38,*(undefined4 *)(param_1 + 0x3f00));
      uStack_14 = CONCAT31(uStack_14._1_3_,*(undefined *)(param_1 + 0x3c31));
      FUN_0151fcf0(&DAT_018d4c3c,uStack_14);
      if ((*(char *)(param_1 + 0x3c32) != '\0') ||
         (uStack_14 = uStack_14 & 0xffffff00, *(char *)(param_1 + 0x3c31) != '\0')) {
        uStack_14 = CONCAT31(uStack_14._1_3_,1);
      }
      FUN_0151fcf0(&DAT_018d4c40,uStack_14);
      FUN_0151fa60("rfail",*(undefined4 *)(param_1 + 0x3f24));
      FUN_0151fa60("pfail",*(undefined4 *)(param_1 + 0x3f28));
      FUN_0151fa60("hfail",*(undefined4 *)(param_1 + 0x3f2c));
      FUN_0151fa60("tfail",*(undefined4 *)(param_1 + 0x3cf8));
      FUN_0151fa60("zfail",*(undefined4 *)(param_1 + 0x3f30));
      FUN_0151fa60("vfail",*(undefined4 *)(param_1 + 0x3f34));
      FUN_0151f9c0(&DAT_018d4c78,*(undefined *)(param_1 + 0x3f38));
      FUN_0151f9c0(&DAT_018d4c7c,*(undefined *)(param_1 + 0x3f39));
      FUN_0151f9c0(&DAT_018d4c80,*(undefined *)(param_1 + 0x3f3a));
      FUN_0151f9c0(&DAT_018d4c84,*(undefined *)(param_1 + 0x3f3b));
      FUN_0151f9c0(&DAT_018d4c88,*(undefined *)(param_1 + 0x3f3c));
      FUN_0151f9c0(&DAT_018d4c8c,*(undefined *)(param_1 + 0x3f3d));
      FUN_0151fb00(&DAT_018d4c90,*(undefined8 *)(param_1 + 0x3c90));
      FUN_0151fb00(&DAT_018d4c98,*(undefined8 *)(param_1 + 0x3cb8));
      FUN_0151fb00(&DAT_018d4ca0,*(undefined8 *)(param_1 + 0x3ce0));
      FUN_0065b310(&uStack_18,&uStack_20,&dStack_28);
      FUN_0151fb00("totalTime",CONCAT44(uStack_14,uStack_18));
      FUN_0151fb00("botTime",uStack_20);
      FUN_0151fb00("percentage",dStack_28);
      iVar1 = DAT_01ead7b4;
      uStack_48 = 0;
      uStack_44 = 0xf;
      apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
      FUN_005542c0("HumanessReport",0xe);
      iStack_8._0_1_ = 1;
      FUN_01520d20(apppuStack_58,iVar1,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
      if (DAT_01d5a060 != '\0') {
        FUN_0066aff0();
      }
      iStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    FUN_006b1620(apppuStack_40,param_1 + 0x74,1,0x7c);
    iStack_8 = 3;
    pdVar3 = (double *)FUN_016830f0(&uStack_20);
    dStack_28 = *pdVar3 - *(double *)(param_1 + 0x3bc0);
    if (DAT_01d7a1f4 == '\0') {
      if (DAT_01d7a280 != '\0') {
        ppppuVar4 = apppuStack_40;
        if (0xf < uStack_2c) {
          ppppuVar4 = (undefined4 ****)apppuStack_40[0];
        }
        FUN_01677520(DAT_01d7a280,"RakNet disco: %s after %f",ppppuVar4,dStack_28);
      }
    }
    else if (DAT_01d7a280 != '\0') {
      ppppuVar4 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar4 = (undefined4 ****)apppuStack_40[0];
      }
      if (*(int *)(param_1 + 0x3c0c) == 0) {
        uVar6 = *(undefined8 *)(param_1 + 0x3d90);
      }
      else {
        uVar6 = FUN_00928340();
      }
      FUN_01677520(DAT_01d7a280,"RakNet disco(%lld): %s after %f",uVar6,ppppuVar4,dStack_28);
    }
    iStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar5 = uStack_2c + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_40[0];
      if (0xfff < uVar5) {
        ppppuVar4 = (undefined4 ****)apppuStack_40[0][-1];
        uVar5 = uStack_2c + 0x24;
        if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar4,uVar5);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_006b1620(apppuStack_58,param_1 + 0x74,1,0x7c);
    iStack_8 = 2;
    if (DAT_01d7a1f4 == '\0') {
      if (DAT_01d7a280 != '\0') {
        ppppuVar4 = apppuStack_58;
        if (0xf < uStack_44) {
          ppppuVar4 = (undefined4 ****)apppuStack_58[0];
        }
        FUN_01677650(DAT_01d7a280,"RakNet connect: %s",ppppuVar4);
      }
    }
    else if (DAT_01d7a280 != '\0') {
      ppppuVar4 = apppuStack_58;
      if (0xf < uStack_44) {
        ppppuVar4 = (undefined4 ****)apppuStack_58[0];
      }
      if (*(int *)(param_1 + 0x3c0c) == 0) {
        uVar6 = *(undefined8 *)(param_1 + 0x3d90);
      }
      else {
        uVar6 = FUN_00928340();
      }
      FUN_01677520(DAT_01d7a280,"RakNet connect(%lld): %s",uVar6,ppppuVar4);
    }
    iStack_8 = 0xffffffff;
    if (0xf < uStack_44) {
      uVar5 = uStack_44 + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_58[0];
      if (0xfff < uVar5) {
        ppppuVar4 = (undefined4 ****)apppuStack_58[0][-1];
        uVar5 = uStack_44 + 0x24;
        if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar4,uVar5);
    }
  }
  FUN_0067ea40(param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7642 ; VA 0x006615e0 ; FUN_006615e0 */

uint * FUN_006615e0(uint *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  int iStack_64;
  uint uStack_50;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***pppuStack_34;
  undefined4 **ppuStack_30;
  undefined4 **ppuStack_2c;
  undefined4 **ppuStack_28;
  undefined8 uStack_24;
  int *piStack_1c;
  undefined4 ***pppuStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar7 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a256a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  piVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  if ((*piVar1 == 0) ||
     (ExceptionList = &pvStack_10, iVar2 = FUN_0170db20(param_2,0x2f,*piVar1), iVar2 == 0)) {
    uVar8 = 0xffffffff;
  }
  else {
    uVar8 = iVar2 - (int)param_2;
  }
  if (uVar8 == 0xffffffff) {
    ppppuVar3 = (undefined4 ****)FUN_0054ef60(puVar7);
    param_2 = (undefined4 *)0x1;
  }
  else {
    uStack_3c = 0;
    uVar6 = uVar8;
    if ((uint)puVar7[4] < uVar8) {
      uVar6 = puVar7[4];
    }
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    puVar4 = puVar7;
    if (0xf < (uint)puVar7[5]) {
      puVar4 = (undefined4 *)*puVar7;
    }
    FUN_005542c0(puVar4,uVar6);
    ppppuVar3 = apppuStack_4c;
    param_2 = (undefined4 *)0xa;
  }
  uStack_24 = 0;
  pppuStack_34 = *ppppuVar3;
  ppuStack_30 = ppppuVar3[1];
  ppuStack_2c = ppppuVar3[2];
  ppuStack_28 = ppppuVar3[3];
  uStack_24 = *(undefined8 *)(ppppuVar3 + 4);
  ppppuVar3[4] = (undefined4 ***)0x0;
  ppppuVar3[5] = (undefined4 ***)0xf;
  *(undefined *)ppppuVar3 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((((uint)param_2 & 2) != 0) &&
     (param_2 = (undefined4 *)((uint)param_2 & 0xfffffffd), 0xf < uStack_38)) {
    uVar6 = uStack_38 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_4c[0];
    if (0xfff < uVar6) {
      ppppuVar3 = (undefined4 ****)apppuStack_4c[0][-1];
      uVar6 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar3))) goto LAB_006618f4;
    }
    FUN_01674ea0(ppppuVar3,uVar6);
  }
  uStack_8._0_1_ = 2;
  if ((((uint)param_2 & 1) != 0) &&
     (param_2 = (undefined4 *)((uint)param_2 & 0xfffffffe), 0xf < uStack_50)) {
    uVar6 = uStack_50 + 1;
    iVar2 = iStack_64;
    if (0xfff < uVar6) {
      iVar2 = *(int *)(iStack_64 + -4);
      uVar6 = uStack_50 + 0x24;
      if (0x1f < (iStack_64 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar6);
  }
  if (uVar8 != 0xffffffff) {
    uVar8 = uVar8 + 1;
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    if ((uint)puVar7[4] < uVar8) {
      FUN_00554050();
    }
    else {
      iVar5 = puVar7[4] - uVar8;
      iVar2 = -1;
      if (iVar5 != -1) {
        iVar2 = iVar5;
      }
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_005542c0((int)puVar7 + uVar8,iVar2);
      param_2 = (undefined4 *)((uint)param_2 | 0x14);
      uStack_8._0_1_ = 3;
      uStack_14 = (uint)param_2;
      piStack_1c = (int *)FUN_0171689d();
      ppppuVar3 = apppuStack_4c;
      if (0xf < uStack_38) {
        ppppuVar3 = (undefined4 ****)apppuStack_4c[0];
      }
      *piStack_1c = 0;
      iVar2 = FUN_0171d785(ppppuVar3,&pppuStack_18,10);
      if (ppppuVar3 != (undefined4 ****)pppuStack_18) {
        if (*piStack_1c == 0x22) {
          FUN_016ddcf9("stoi argument out of range");
LAB_006618f4:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        goto LAB_006617f1;
      }
    }
    FUN_016ddcb9("invalid stoi argument");
LAB_0066190d:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  iVar2 = 0x20;
LAB_006617f1:
  if ((((uint)param_2 & 4) != 0) && (0xf < uStack_38)) {
    uVar8 = uStack_38 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_4c[0];
    if (0xfff < uVar8) {
      ppppuVar3 = (undefined4 ****)apppuStack_4c[0][-1];
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar3))) goto LAB_0066190d;
    }
    FUN_01674ea0(ppppuVar3,uVar8);
  }
  if (iVar2 - 1U < 0x20) {
    ppppuVar3 = &pppuStack_34;
    if (0xf < uStack_24._4_4_) {
      ppppuVar3 = (undefined4 ****)pppuStack_34;
    }
    iVar5 = Ordinal_11(ppppuVar3);
    if (iVar5 == -1) {
      *param_1 = 0;
      param_1[1] = 0;
    }
    else {
      uVar6 = Ordinal_14(iVar5);
      uVar8 = *(uint *)(&UNK_018d0948 + iVar2 * 4);
      uVar6 = uVar8 & uVar6;
      *param_1 = uVar6;
      param_1[1] = ~uVar8 | uVar6;
    }
    FUN_005507b0();
  }
  else {
    *param_1 = 0;
    param_1[1] = 0;
    if (0xf < uStack_24._4_4_) {
      uVar8 = uStack_24._4_4_ + 1;
      ppppuVar3 = (undefined4 ****)pppuStack_34;
      if (0xfff < uVar8) {
        ppppuVar3 = (undefined4 ****)pppuStack_34[-1];
        uVar8 = uStack_24._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppuStack_34 + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar8);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7643 ; VA 0x00661920 ; FUN_00661920 */

undefined FUN_00661920(undefined4 param_1,undefined4 param_2,undefined4 ****param_3)

{
  undefined4 ***pppuVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uVar10;
  char *pcVar11;
  undefined auStack_138 [8];
  undefined auStack_130 [8];
  undefined auStack_128 [8];
  undefined auStack_120 [8];
  undefined auStack_118 [8];
  undefined auStack_110 [8];
  undefined auStack_108 [16];
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined auStack_f0 [16];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  uint auStack_d8 [4];
  undefined4 uStack_c8;
  uint uStack_c4;
  undefined auStack_c0 [8];
  undefined auStack_b8 [8];
  undefined4 ***apppuStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined4 ***apppuStack_98 [4];
  undefined4 uStack_88;
  uint uStack_84;
  undefined auStack_80 [12];
  undefined4 ***apppuStack_74 [5];
  uint uStack_60;
  undefined auStack_5c [8];
  undefined auStack_54 [4];
  undefined auStack_50 [4];
  undefined auStack_4c [8];
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a25ff;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_80,param_1);
  uStack_8 = 0;
  cVar2 = FUN_016816d0();
  if ((cVar2 == '\0') && (cVar2 = FUN_01681870(), cVar2 != '\0')) {
    FUN_0167eea0(auStack_b8,"results");
    cVar2 = FUN_01681830();
    if (cVar2 != '\0') {
      uStack_34 = 0;
      uStack_30 = 0xf;
      apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
      FUN_005542c0(&DAT_018d46dc,9);
      uStack_8._0_1_ = 1;
      FUN_00659b20(apppuStack_b0,apppuStack_44,param_2);
      uStack_8._0_1_ = 3;
      FUN_005507b0();
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
      FUN_005542c0(&DAT_018d46d4,4);
      uStack_8._0_1_ = 4;
      FUN_00659b20(auStack_d8,auStack_2c,param_2);
      uStack_8._0_1_ = 6;
      FUN_005507b0();
      uStack_e0 = 0;
      uStack_dc = 0xf;
      auStack_f0[0] = 0;
      FUN_005542c0("humans",6);
      uStack_8._0_1_ = 7;
      FUN_00659b20(apppuStack_98,auStack_f0,param_2);
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      FUN_005507b0();
      FUN_016810c0(auStack_50);
      FUN_01680ea0(auStack_14);
      FUN_01681140(auStack_54);
      cVar2 = FUN_005e0cd0(auStack_54);
      while (cVar2 != '\0') {
        FUN_0167efb0(auStack_4c);
        FUN_0167eea0(auStack_c0,&DAT_018d46b8);
        cVar2 = FUN_0167e580();
        if (cVar2 == '\0') {
          if (DAT_01ead7a0 != '\0') {
            FUN_016774b0(DAT_01ead7a0,"Key missing for entry in flood checker response",0);
          }
        }
        else {
          uStack_f8 = 0;
          uStack_f4 = 0xf;
          auStack_108[0] = 0;
          uStack_8._0_1_ = 10;
          FUN_01681580(apppuStack_44,auStack_108);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          FUN_005507b0();
          uVar8 = uStack_30;
          pppuVar1 = apppuStack_44[0];
          ppppuVar7 = apppuStack_b0;
          if (0xf < uStack_9c) {
            ppppuVar7 = (undefined4 ****)apppuStack_b0[0];
          }
          ppppuVar5 = apppuStack_44;
          if (0xf < uStack_30) {
            ppppuVar5 = (undefined4 ****)apppuStack_44[0];
          }
          cVar2 = FUN_0055c360(ppppuVar5,uStack_34,ppppuVar7,uStack_a0);
          if (cVar2 == '\0') {
            ppppuVar7 = apppuStack_98;
            if (0xf < uStack_84) {
              ppppuVar7 = (undefined4 ****)apppuStack_98[0];
            }
            ppppuVar5 = apppuStack_44;
            if (0xf < uVar8) {
              ppppuVar5 = (undefined4 ****)pppuVar1;
            }
            cVar2 = FUN_0055c360(ppppuVar5,uStack_34,ppppuVar7,uStack_88);
            if (cVar2 != '\0') {
              ppppuVar7 = param_3 + 0xe;
              goto LAB_00661bff;
            }
            cVar2 = FUN_00558b30(apppuStack_44,auStack_d8);
            ppppuVar7 = param_3;
            if (cVar2 != '\0') goto LAB_00661bff;
            if (DAT_01ead7a0 != '\0') {
              ppppuVar7 = apppuStack_44;
              if (0xf < uVar8) {
                ppppuVar7 = (undefined4 ****)pppuVar1;
              }
              FUN_01677650(DAT_01ead7a0,"Unknown key (%s) in flood checker response",ppppuVar7);
            }
          }
          else {
            ppppuVar7 = param_3 + 0x1c;
LAB_00661bff:
            FUN_0167eea0(auStack_5c,"status");
            cVar2 = FUN_01681870();
            if (cVar2 == '\0') {
              if (ppppuVar7 != apppuStack_44) {
                ppppuVar5 = apppuStack_44;
                if (0xf < uStack_30) {
                  ppppuVar5 = (undefined4 ****)apppuStack_44[0];
                }
                FUN_005542c0(ppppuVar5,uStack_34);
              }
              FUN_0167eea0(auStack_120,"flooded");
              uVar3 = FUN_01681470();
              *(undefined *)(ppppuVar7 + 0xc) = uVar3;
              FUN_0167eea0(auStack_128,"expiry");
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8._0_1_ = 0x10;
              puVar6 = (undefined4 *)FUN_01681580(apppuStack_74,auStack_2c);
              if (0xf < (uint)puVar6[5]) {
                puVar6 = (undefined4 *)*puVar6;
              }
              uVar10 = FUN_0171d7b1(puVar6,0,0);
              *(undefined8 *)(ppppuVar7 + 6) = uVar10;
              FUN_005507b0();
              uStack_8._0_1_ = 0xc;
              FUN_005507b0();
              FUN_0167eea0(auStack_130,"limit");
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8._0_1_ = 0x11;
              puVar6 = (undefined4 *)FUN_01681580(apppuStack_74,auStack_2c);
              if (0xf < (uint)puVar6[5]) {
                puVar6 = (undefined4 *)*puVar6;
              }
              uVar10 = FUN_0171d7b1(puVar6,0,0);
              *(undefined8 *)(ppppuVar7 + 8) = uVar10;
              FUN_005507b0();
              uStack_8._0_1_ = 0xc;
              FUN_005507b0();
              FUN_0167eea0(auStack_138,&DAT_018d46cc);
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
              puVar6 = (undefined4 *)FUN_01681580(apppuStack_74,auStack_2c);
              if (0xf < (uint)puVar6[5]) {
                puVar6 = (undefined4 *)*puVar6;
              }
              uVar10 = FUN_0171d7b1(puVar6,0,0);
              *(undefined8 *)(ppppuVar7 + 10) = uVar10;
              FUN_005507b0();
              FUN_005507b0();
              *(undefined *)((int)ppppuVar7 + 0x31) = 1;
            }
            else {
              FUN_0167eea0(auStack_110,&DAT_018d4688);
              iVar4 = FUN_0167e400(0);
              FUN_0167eea0(auStack_118,"message");
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8._0_1_ = 0xd;
              FUN_01681580(apppuStack_74,auStack_2c);
              uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
              FUN_005507b0();
              if ((iVar4 != 0x65) && (DAT_01ead7a0 != '\0')) {
                ppppuVar7 = apppuStack_74;
                if (0xf < uStack_60) {
                  ppppuVar7 = (undefined4 ****)apppuStack_74[0];
                }
                FUN_01677520(DAT_01ead7a0,"Error in flood check response: %d (%s)",iVar4,ppppuVar7);
              }
              FUN_005507b0();
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
          FUN_005507b0();
        }
        FUN_0167f070();
        cVar2 = FUN_005e0cd0(auStack_54);
      }
      uVar3 = 1;
      if (0xf < uStack_84) {
        uVar8 = uStack_84 + 1;
        ppppuVar7 = (undefined4 ****)apppuStack_98[0];
        if (0xfff < uVar8) {
          ppppuVar7 = (undefined4 ****)((undefined4 ****)apppuStack_98[0])[-1];
          uVar8 = uStack_84 + 0x24;
          if (0x1f < (uint)((int)apppuStack_98[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar7,uVar8);
      }
      uStack_88 = 0;
      uStack_84 = 0xf;
      apppuStack_98[0] = (undefined4 ***)((uint)apppuStack_98[0] & 0xffffff00);
      if (0xf < uStack_c4) {
        uVar9 = uStack_c4 + 1;
        uVar8 = auStack_d8[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_d8[0] - 4);
          uVar9 = uStack_c4 + 0x24;
          if (0x1f < (auStack_d8[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar9);
      }
      uStack_c8 = 0;
      uStack_c4 = 0xf;
      auStack_d8[0] = auStack_d8[0] & 0xffffff00;
      if (0xf < uStack_9c) {
        uVar8 = uStack_9c + 1;
        ppppuVar7 = (undefined4 ****)apppuStack_b0[0];
        if (0xfff < uVar8) {
          ppppuVar7 = (undefined4 ****)apppuStack_b0[0][-1];
          uVar8 = uStack_9c + 0x24;
          if (0x1f < (uint)((int)apppuStack_b0[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar7,uVar8);
      }
      uStack_a0 = 0;
      uStack_9c = 0xf;
      apppuStack_b0[0] = (undefined4 ***)((uint)apppuStack_b0[0] & 0xffffff00);
      goto LAB_00661fda;
    }
    if (DAT_01ead7a0 != '\0') {
      pcVar11 = "Error parsing flood check results";
      goto LAB_00661fcc;
    }
  }
  else if (DAT_01ead7a0 != '\0') {
    pcVar11 = "Error parsing flood check response";
LAB_00661fcc:
    FUN_016774b0(DAT_01ead7a0,pcVar11,0);
  }
  uVar3 = 0;
LAB_00661fda:
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 7644 ; VA 0x00662010 ; FUN_00662010 */

void __thiscall
FUN_00662010(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,int param_5,uint param_6
            ,undefined4 *param_7,int param_8,uint param_9)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined8 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2637;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  cStack_12 = *(char *)(param_1 + 0x37fe);
  if (cStack_12 == '\0') {
    uStack_1c = (uint)((ulonglong)param_4 * 100);
    uVar11 = param_5 * 100 + (int)((ulonglong)param_4 * 100 >> 0x20);
    uVar8 = DAT_01d5a670 * DAT_01d5a62c >> 0x1f;
    if ((uVar11 < uVar8) ||
       ((uVar11 <= uVar8 && (uStack_1c <= (uint)(DAT_01d5a670 * DAT_01d5a62c))))) {
      uStack_18 = 0;
    }
    else {
      uStack_18 = 1;
    }
    uVar8 = DAT_01d5a640 * DAT_01d5a62c;
    if (((uint)(param_8 * 100) < uVar8 || param_8 * 100 - uVar8 == 0) ||
       ((uVar11 == 0 && (uStack_1c <= uVar8 * 500)))) {
      uVar8 = 0;
    }
    else {
      uVar8 = 2;
    }
    uStack_18 = uStack_18 | uVar8;
  }
  cVar2 = *(char *)(param_1 + 0x37ff);
  if (cVar2 == '\0') {
    uStack_1c = (uint)((ulonglong)param_6 * 100);
    uVar8 = (int)param_7 * 100 + (int)((ulonglong)param_6 * 100 >> 0x20);
    uVar11 = DAT_01d5a670 * DAT_01d5a62c >> 0x1f;
    if ((uVar8 < uVar11) ||
       ((uVar8 <= uVar11 && (uStack_1c <= (uint)(DAT_01d5a670 * DAT_01d5a62c))))) {
      uVar11 = 0;
    }
    else {
      uVar11 = 4;
    }
    uVar9 = DAT_01d5a648 * DAT_01d5a62c;
    if ((param_9 * 100 < uVar9 || param_9 * 100 - uVar9 == 0) ||
       ((uVar8 == 0 && (uStack_1c <= uVar9 * 500)))) {
      uVar8 = 0;
    }
    else {
      uVar8 = 8;
    }
    uStack_18 = uStack_18 | uVar11 | uVar8;
    cVar2 = *(char *)(param_1 + 0x37ff);
  }
  if ((cStack_12 != '\0') || (cVar2 != '\0')) goto LAB_006621f0;
  iVar10 = DAT_01d5a650 * DAT_01d5a62c;
  iVar3 = (uint)*(byte *)(param_1 + 0x3de3) * 100;
  if (iVar3 - iVar10 == 0 || iVar3 < iVar10) {
LAB_00662196:
    uVar8 = 0;
  }
  else {
    uVar11 = iVar10 * 3000 >> 0x1f;
    uVar8 = (int)param_7 * 100 + (int)((ulonglong)param_6 * 100 >> 0x20);
    if ((uVar8 < uVar11) ||
       ((uVar8 <= uVar11 && ((uint)((ulonglong)param_6 * 100) <= (uint)(iVar10 * 3000)))))
    goto LAB_00662196;
    uVar8 = 0x10;
  }
  iVar10 = DAT_01d5a658 * DAT_01d5a62c;
  iVar3 = (uint)*(byte *)(param_1 + 0x3de4) * 100;
  if (iVar3 - iVar10 == 0 || iVar3 < iVar10) {
LAB_006621e9:
    uVar11 = 0;
  }
  else {
    uVar9 = iVar10 * 8000 >> 0x1f;
    uVar11 = param_5 * 100 + (int)((ulonglong)param_4 * 100 >> 0x20);
    if ((uVar11 < uVar9) ||
       ((uVar11 <= uVar9 && ((uint)((ulonglong)param_4 * 100) <= (uint)(iVar10 * 8000)))))
    goto LAB_006621e9;
    uVar11 = 0x20;
  }
  uStack_18 = uStack_18 | uVar8 | uVar11;
LAB_006621f0:
  uVar8 = uStack_18;
  if (uStack_18 != 0) {
    param_9 = 0x80000000;
    param_7 = &DAT_01d5aae0;
    if (0xf < DAT_01d5aaf4) {
      param_7 = DAT_01d5aae0;
    }
    uVar9 = 0;
    uVar11 = 0;
    do {
      bVar1 = *(byte *)((int)param_7 + uVar9);
      if (bVar1 == 0) {
LAB_00662263:
        uVar4 = 0;
        break;
      }
      if (uVar9 % 5 == 4) {
        uVar4 = uVar11;
        if (0x37 < bVar1) goto LAB_00662263;
      }
      else {
        uVar4 = param_9 | uVar11;
        param_9 = param_9 >> 1;
        if (bVar1 != 0x72) {
          uVar4 = uVar11;
        }
      }
      uVar9 = uVar9 + 1;
      uVar11 = uVar4;
    } while (uVar9 < 0x28);
    if ((*(char *)(param_1 + 0x3801) == '\0') && ((uStack_18 & uVar4) != 0)) {
      ExceptionList = &pvStack_10;
      iStack_20 = param_1;
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8 = 0;
      FUN_0151fb00(&DAT_018d3e5c,*(undefined8 *)(param_1 + 0x620));
      FUN_0151fb00(&DAT_018d3e60,*(undefined8 *)(param_1 + 0x808));
      FUN_0151fb00(&DAT_018d3e64,*(undefined8 *)(param_1 + 0x810));
      FUN_0151fb00(&DAT_018d49e8,*(undefined8 *)(param_1 + 0x980));
      puVar5 = (undefined8 *)FUN_00626680(&param_6,param_1 + 0x1070);
      FUN_0151fb00(&DAT_018d49ec,*puVar5);
      puVar5 = (undefined8 *)FUN_00626680(&param_6,param_1 + 0x1078);
      FUN_0151fb00(&DAT_018d49f0,*puVar5);
      puVar5 = (undefined8 *)FUN_00626680(&param_6,param_1 + 0x1080);
      FUN_0151fb00(&DAT_018d49f4,*puVar5);
      param_6 = FUN_006a6900();
      param_7 = (undefined4 *)0x0;
      puVar5 = (undefined8 *)FUN_00626680(&param_4,&param_6);
      FUN_0151fb00(&DAT_018d3eec,*puVar5);
      FUN_0151fbb0(&DAT_018c1fd8,*(undefined4 *)(param_1 + 0x3d90),*(undefined4 *)(param_1 + 0x3d94)
                  );
      puVar6 = (undefined4 *)FUN_01675640(auStack_38,"0h%04X",uVar8);
      iStack_8._0_1_ = 1;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_0151f850(&DAT_018d49f8,puVar6);
      iStack_8._0_1_ = 0;
      FUN_005507b0();
      FUN_0151fb00(&DAT_018d3ef0,*(undefined8 *)(param_1 + 0x3ed0));
      FUN_0151fa60(&DAT_018d49fc,*(undefined4 *)(param_1 + 0x3ee8));
      FUN_0151fa60(&DAT_018d4a00,param_8);
      FUN_0151f9c0(&DAT_018d4a04,*(undefined *)(param_1 + 0x3de4));
      FUN_0151fb00(&DAT_018d3ef4,*(undefined8 *)(param_1 + 0x3ea8));
      FUN_0151fb00(&DAT_018d3ef8,*(undefined8 *)(param_1 + 0x3ed8));
      uVar7 = FUN_005f2c00();
      FUN_0151f850(&DAT_018d3efc,uVar7);
      uVar7 = DAT_01d5b9e4;
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0("RccDebugTimeout3",0x10);
      iStack_8._0_1_ = 2;
      FUN_01520d20(auStack_38,uVar7,0);
      iStack_8._0_1_ = 0;
      FUN_005507b0();
      *(undefined *)(param_1 + 0x3801) = 1;
      param_8 = FUN_01674e20();
      iStack_8._0_1_ = 3;
      if (param_8 != 0) {
        FUN_0071a290();
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_006b1f50();
      FUN_0151f7f0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7645 ; VA 0x00662560 ; FUN_00662560 */

void __thiscall FUN_00662560(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_3c [12];
  undefined auStack_30 [16];
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a2660;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar2 = &stack0xffffff88;
  if (DAT_01d64728 == '\0') {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_00644850();
    puVar2 = puStack_14;
    if (cVar3 == '\0') goto LAB_006625fc;
  }
  puStack_14 = puVar2;
  if (*(int *)(param_1 + 0x3d84) == 0) {
    if (DAT_01d84e8e != '\0') {
      FUN_016774b0(DAT_01d84e8e,"ServerReplicator:preauthenticatePlayer - MissingTicket",0);
    }
    FUN_016756b0(auStack_30,"missing ticket");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_30,&DAT_01c17198);
  }
  iVar1 = *(int *)(param_1 + 0x3c1c);
  piVar4 = (int *)FUN_0065ad50(auStack_1c,param_1 + 0x3d74);
  if (*piVar4 != *(int *)(iVar1 + 0x484)) {
    if (DAT_01d84e8e != '\0') {
      FUN_016774b0(DAT_01d84e8e,"ServerReplicator:preauthenticatePlayer - DuplicateTicket",0);
    }
    uVar6 = FUN_005543f0();
    FUN_016756b0(auStack_3c,"ticket has already been used: %s",uVar6);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_3c,&DAT_01c17198);
  }
  FUN_0055b0f0(auStack_20,0,param_1 + 0x3d74,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0066cf60();
LAB_006625fc:
  *(undefined4 *)(param_1 + 0x3d90) = param_2;
  *(undefined4 *)(param_1 + 0x3d94) = param_3;
  uStack_8 = 0xffffffff;
  *(undefined *)(param_1 + 0x3d70) = 1;
  puVar5 = (undefined4 *)FUN_016830f0(&param_2);
  *(undefined4 *)(param_1 + 0x3e50) = *puVar5;
  *(undefined4 *)(param_1 + 0x3e54) = puVar5[1];
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7646 ; VA 0x0066264c ; Catch@0066264c */

undefined4 Catch_0066264c(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  iVar1 = *(int *)(unaff_EBP + -0x14);
  *(undefined *)(iVar1 + 0x3d71) = 1;
  if (*(char *)(iVar1 + 0x3f5b) == '\0') {
    FUN_0066a8c0(0x19,1);
    FUN_0066aa10(0,"PreauthenticateTicket",1,0);
    FUN_00668a20("DuringJoin","PreauthenticateTicket");
  }
  *(undefined *)(iVar1 + 0x3f5b) = 1;
  iVar1 = FUN_0064e5e0(iVar1);
  if (iVar1 != 0) {
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x20) + 4))();
    FUN_0054eff0(uVar2);
    *(undefined *)(unaff_EBP + -4) = 4;
    *(undefined4 *)(unaff_EBP + -0x40) = 0;
    *(undefined4 *)(unaff_EBP + -0x3c) = 0xf;
    *(undefined *)(unaff_EBP + -0x50) = 0;
    FUN_005542c0("Preauthenticate-TicketFail",0x1a);
    *(undefined *)(unaff_EBP + -4) = 5;
    uVar2 = FUN_008cd320(unaff_EBP + -0x50,unaff_EBP + -0x68,0,0);
    FUN_00936dd0(uVar2);
    FUN_005507b0();
    FUN_005507b0();
  }
  return 0x662639;
}



/* FUNCTION 7647 ; VA 0x0066278d ; Catch@0066278d */

void Catch_0066278d(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("ticket signature not verified. (preauthenticatePlayer)");
}



/* FUNCTION 7648 ; VA 0x006627a0 ; FUN_006627a0 */

void __thiscall FUN_006627a0(int param_1,int param_2)

{
  int *piVar1;
  bool bVar2;
  int *piVar3;
  undefined uVar4;
  undefined4 uVar5;
  int iVar6;
  uint *puVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  undefined8 uVar12;
  uint auStack_6c [5];
  uint uStack_58;
  int iStack_54;
  undefined4 ***apppuStack_50 [4];
  uint uStack_40;
  uint uStack_3c;
  undefined auStack_38 [8];
  undefined4 uStack_30;
  int *piStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2714;
  pvStack_10 = ExceptionList;
  piStack_2c = (int *)0x0;
  ExceptionList = &pvStack_10;
  iStack_54 = param_1;
  FUN_006acbd0(apppuStack_50);
  uVar9 = 0;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  bVar2 = true;
  if (uStack_40 != 0) {
    do {
      ppppuVar8 = apppuStack_50;
      if (0xf < uStack_3c) {
        ppppuVar8 = (undefined4 ****)apppuStack_50[0];
      }
      *(byte *)((int)ppppuVar8 + uVar9) = *(byte *)((int)ppppuVar8 + uVar9) ^ 0xaa;
      ppppuVar8 = apppuStack_50;
      if (0xf < uStack_3c) {
        ppppuVar8 = (undefined4 ****)apppuStack_50[0];
      }
      if (0x80 < *(byte *)((int)ppppuVar8 + uVar9)) {
        bVar2 = false;
        break;
      }
      uVar9 = uVar9 + 1;
    } while (uVar9 < uStack_40);
  }
  if (DAT_01eada7c == 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ROBLOX",6);
    uStack_8._0_1_ = 1;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Roblox",6);
    uStack_8._0_1_ = 2;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ROBLOX Crash",0xc);
    uStack_8._0_1_ = 3;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Default IME",0xb);
    uStack_8._0_1_ = 4;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("MsftTimer",9);
    uStack_8._0_1_ = 5;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("MSCTFIME UI",0xb);
    uStack_8._0_1_ = 6;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("UiHubMouseHiderWindow",0x15);
    uStack_8._0_1_ = 7;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 8;
    FUN_0064e3a0(auStack_38,auStack_28,auStack_28);
    uStack_8._0_1_ = 0;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
  }
  if (bVar2) {
    uVar9 = (uint)DAT_01eada74;
    uVar5 = FUN_005702d0(apppuStack_50);
    FUN_00562fc0(&param_2,uVar5,apppuStack_50,-(uint)(uVar9 != 0xfe15258b) & uVar9 + 0x1eada76);
    if (param_2 == 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8._0_1_ = 9;
      iVar6 = FUN_008f7870(param_1);
      if (iVar6 == 0) {
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = auStack_28[0] & 0xffffff00;
        FUN_005542c0(&DAT_018bc9b8,0);
        puVar7 = auStack_28;
        uStack_8 = 0xb;
        uVar9 = 2;
      }
      else {
        FUN_0054ef60(iVar6 + 0x288);
        puVar7 = auStack_6c;
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
        uVar9 = 5;
      }
      piStack_2c = (int *)uVar9;
      FUN_0151f950("jobid",puVar7);
      uStack_8 = 10;
      if ((uVar9 & 2) != 0) {
        uVar9 = uVar9 & 0xfffffffd;
        if (0xf < uStack_14) {
          uVar11 = uStack_14 + 1;
          uVar10 = auStack_28[0];
          if (0xfff < uVar11) {
            uVar10 = *(uint *)(auStack_28[0] - 4);
            uVar11 = uStack_14 + 0x24;
            if (0x1f < (auStack_28[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar10,uVar11);
        }
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = auStack_28[0] & 0xffffff00;
      }
      uStack_8 = 9;
      if (((uVar9 & 1) != 0) && (0xf < uStack_58)) {
        uVar10 = uStack_58 + 1;
        uVar9 = auStack_6c[0];
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(auStack_6c[0] - 4);
          uVar10 = uStack_58 + 0x24;
          if (0x1f < (auStack_6c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      ppppuVar8 = apppuStack_50;
      if (0xf < uStack_3c) {
        ppppuVar8 = (undefined4 ****)apppuStack_50[0];
      }
      FUN_0151f850("title",ppppuVar8);
      if (*(int *)(param_1 + 0x3c0c) == 0) {
        uVar12 = 0x8000000000000000;
      }
      else {
        uVar12 = FUN_00928340();
      }
      FUN_0151fbb0("userid",uVar12);
      uVar5 = DAT_01d5a710;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      FUN_005542c0("AddedAntiCheatReport",0x14);
      uStack_8._0_1_ = 0xc;
      FUN_01520d20(auStack_28,uVar5,0);
      uStack_8._0_1_ = 9;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 9;
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        uVar9 = auStack_28[0];
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(auStack_28[0] - 4);
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (auStack_28[0] - uVar9) - 4) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      param_2 = FUN_01674e20(0x38);
      uStack_8._0_1_ = 0xd;
      if (param_2 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_0151f6f0(0xffffffff,0,0);
      }
      uStack_8._0_1_ = 9;
      uStack_30 = 0;
      piStack_2c = (int *)0x0;
      FUN_0064daf0(uVar5,param_2);
      uVar5 = uStack_30;
      uStack_8._0_1_ = 0xe;
      FUN_0151f950(&DAT_018d26f4,apppuStack_50);
      piVar3 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[1] = piStack_2c[1] + 1;
        UNLOCK();
      }
      FUN_0066d800(3,0,0,0,uVar5,piStack_2c);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar6 = piVar3[1] + -1;
        piVar3[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_0151f7f0();
    }
  }
  if (0xf < uStack_3c) {
    uVar9 = uStack_3c + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_50[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_50[0][-1];
      uVar9 = uStack_3c + 0x24;
      if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7649 ; VA 0x00662f00 ; FUN_00662f00 */

void __thiscall FUN_00662f00(int *param_1,uint param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  bool bVar8;
  int aiStack_174 [40];
  undefined auStack_d4 [56];
  undefined auStack_9c [56];
  undefined auStack_64 [24];
  undefined auStack_4c [12];
  undefined4 ***apppuStack_40 [5];
  uint uStack_2c;
  undefined4 *puStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2751;
  pvStack_10 = ExceptionList;
  cStack_11 = '\0';
  param_2 = ~param_1[0xf6f] & param_2;
  uStack_24 = param_2;
  piStack_20 = param_1;
  if (param_3 != 0) {
    if (((DAT_01d5ab50 != '\0') || (DAT_01d5ab58 != '\0')) &&
       (*(char *)((int)param_1 + 0x3f4f) == '\0')) {
      ExceptionList = &pvStack_10;
      FUN_0087c450(&DAT_018c5f98,"SecurityException","Api Token Tamper",0,0,0);
      (**(code **)(*param_1 + 0x290))(&DAT_018d3948,0xb,DAT_01d5ab58 != '\0',"ApiTokenTamper",0);
    }
    *(undefined *)((int)param_1 + 0x3f4f) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2 != 0) {
    param_3 = 0x80000000;
    puStack_18 = &DAT_01d5aa68;
    if (0xf < DAT_01d5aa7c) {
      puStack_18 = DAT_01d5aa68;
    }
    uVar6 = 0;
    uVar7 = 0;
    do {
      bVar1 = *(byte *)((int)puStack_18 + uVar6);
      if (bVar1 == 0) {
LAB_00663023:
        cStack_11 = '\x01';
        uVar2 = 0;
        break;
      }
      if (uVar6 % 5 == 4) {
        uVar2 = uVar7;
        if (0x37 < bVar1) goto LAB_00663023;
      }
      else {
        uVar2 = param_3 | uVar7;
        param_3 = param_3 >> 1;
        if (bVar1 != 0x2e) {
          uVar2 = uVar7;
        }
      }
      uVar6 = uVar6 + 1;
      uVar7 = uVar2;
    } while (uVar6 < 0x28);
    bVar8 = (param_2 & uVar2) != 0;
    ExceptionList = &pvStack_10;
    if (bVar8) {
      ExceptionList = &pvStack_10;
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0058ccc0(auStack_4c,0xb,"H:%08X",param_2);
      FUN_0151f850(&DAT_018d20dc,auStack_4c);
      (**(code **)(*piStack_20 + 0x290))(&DAT_018d3958,8,1,"ApiStats",auStack_9c);
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    uVar7 = uStack_24;
    puStack_18 = (undefined4 *)0x80000000;
    uStack_1c = 0;
    puStack_28 = &DAT_01d5aa68;
    if (0xf < DAT_01d5aa7c) {
      puStack_28 = DAT_01d5aa68;
    }
    uVar6 = 0;
    do {
      bVar1 = *(byte *)((int)puStack_28 + uVar6);
      if (bVar1 == 0) {
LAB_00663119:
        cStack_11 = '\x01';
        uVar3 = 0;
        break;
      }
      if (uVar6 % 5 == 4) {
        uVar3 = uStack_1c;
        if (0x37 < bVar1) goto LAB_00663119;
      }
      else {
        uVar3 = (uint)puStack_18 | uStack_1c;
        puStack_18 = (undefined4 *)((uint)puStack_18 >> 1);
        if (bVar1 != 0x72) {
          uVar3 = uStack_1c;
        }
      }
      uStack_1c = uVar3;
      uVar6 = uVar6 + 1;
      uVar3 = uStack_1c;
    } while (uVar6 < 0x28);
    if ((uStack_24 & (uVar2 | uVar3)) != 0) {
      FUN_00565940(3,1);
      uStack_8 = 1;
      FUN_00558890(aiStack_174,"ApiStats: ");
      FUN_00585a70((int)aiStack_174 + *(int *)(aiStack_174[0] + 4));
      FUN_0056ef60(uVar7);
      FUN_0058c420(apppuStack_40);
      ppppuVar4 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar4 = (undefined4 ****)apppuStack_40[0];
      }
      uStack_8._0_1_ = 2;
      FUN_0087c450(&DAT_018c5f98,"SecurityException",ppppuVar4,0,0,0);
      if (!bVar8) {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 3;
        uVar5 = FUN_01675640(auStack_64,"H:%08X",uVar7);
        uStack_8._0_1_ = 4;
        FUN_0151f950(&DAT_018d20dc,uVar5);
        uStack_8._0_1_ = 3;
        FUN_005507b0();
        (**(code **)(*piStack_20 + 0x290))(&DAT_018d3958,8,0,"ApiStats",auStack_d4);
        FUN_0151f7f0();
      }
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_005705c0();
    }
    piStack_20[0xf6f] = piStack_20[0xf6f] | uVar7;
    if (cStack_11 != '\0') {
      FUN_006688b0("US30605p3");
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7650 ; VA 0x00663280 ; FUN_00663280 */

void __thiscall FUN_00663280(int *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  
  cVar1 = FUN_006abe40();
  if (cVar1 == '\0') {
    FUN_006abe40();
    FUN_006abe40();
    if (0 < DAT_01ead7f0) {
      FUN_0087c450(&DAT_018c5f98,"SecurityException","Hooks are removed",0,0,0);
      (**(code **)(*param_1 + 0x290))(&DAT_018d2720,0x1c,1 < DAT_01ead7f0,"RbxHooksAreRemoved",0);
      return;
    }
  }
  else {
    uVar6 = FUN_006ace60();
    uVar2 = FUN_006ace40();
    uVar3 = FUN_006ace40();
    uVar4 = FUN_006ace40();
    if (param_1[0xf03] != 0) {
      FUN_00933b20(2);
    }
    uVar5 = 0;
    switch(uVar2) {
    case 0:
      FUN_0065dee0(0,uVar6,uVar3,uVar4,param_2);
      FUN_0066a8c0(0x1b,0);
      return;
    case 1:
      FUN_0065fba0(1,uVar6,uVar3,uVar4,param_2);
      FUN_0066a8c0(0x1c,0);
      return;
    case 2:
      FUN_00660580(2,uVar6,uVar3,uVar4,param_2);
      FUN_0066a8c0(0x1d,0);
      return;
    case 7:
      FUN_0065fe90(7,uVar6,uVar3,uVar4,param_2);
      FUN_0066a8c0(0,0);
      return;
    case 9:
      *(undefined *)(param_1 + 0xfda) = 1;
      FUN_0066a8c0(0,0);
      return;
    case 10:
      uVar5 = FUN_0065eb50(10,uVar6,uVar3,uVar4,param_2);
    }
    FUN_0066a8c0(uVar5,0);
  }
  return;
}



/* FUNCTION 7651 ; VA 0x00663470 ; FUN_00663470 */

void __thiscall FUN_00663470(int param_1,int param_2)

{
  byte bVar1;
  char cVar2;
  char cVar7;
  undefined4 uVar3;
  undefined2 extraout_var;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  undefined2 uVar9;
  undefined3 uVar8;
  uint uVar4;
  int iVar5;
  double *pdVar6;
  byte bVar10;
  char cVar11;
  char cVar13;
  uint uVar12;
  char cVar14;
  uint3 uVar16;
  uint uVar15;
  bool bVar17;
  float10 fVar18;
  float fVar19;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_24;
  undefined auStack_20 [4];
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2770;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0067f880(param_2);
  *(char *)(param_1 + 0x3de2) = *(char *)(param_1 + 0x3de2) + '\x01';
  *(char *)(param_1 + 0x3de1) = *(char *)(param_1 + 0x3de1) + '\x01';
  uVar3 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0x1088) = uVar3;
  *(undefined4 *)(param_1 + 0x108c) = 0;
  if (*(float *)(param_2 + 0x20) <= (float)*(byte *)(param_1 + 0x3f38) &&
      (float)*(byte *)(param_1 + 0x3f38) != *(float *)(param_2 + 0x20)) {
    *(int *)(param_1 + 0x3f24) = *(int *)(param_1 + 0x3f24) + 1;
  }
  if (*(float *)(param_2 + 0x24) <= (float)*(byte *)(param_1 + 0x3f39) &&
      (float)*(byte *)(param_1 + 0x3f39) != *(float *)(param_2 + 0x24)) {
    *(int *)(param_1 + 0x3f28) = *(int *)(param_1 + 0x3f28) + 1;
  }
  fVar19 = *(float *)(param_2 + 0x28);
  if (fVar19 < (float)*(byte *)(param_1 + 0x3f3a)) {
    *(int *)(param_1 + 0x3f2c) = *(int *)(param_1 + 0x3f2c) + 1;
    fVar19 = *(float *)(param_2 + 0x28);
  }
  if ((NAN(fVar19) != (fVar19 == 0.0)) &&
     (NAN(*(float *)(param_2 + 0x24)) != (*(float *)(param_2 + 0x24) == 0.0))) {
    *(int *)(param_1 + 0x3f30) = *(int *)(param_1 + 0x3f30) + 1;
  }
  bVar1 = ~(*(byte *)(param_2 + 0x10) >> 1) & 1;
  bVar10 = *(byte *)(param_2 + 0x10) & 1;
  if ((bVar10 == 0) && (bVar1 != 0)) {
    *(int *)(param_1 + 0x3f34) = *(int *)(param_1 + 0x3f34) + 1;
  }
  uStack_14 = uStack_14 & 0xffffff00;
  if ((bVar1 != 0) || (bVar10 != 0)) goto LAB_00663839;
  iVar5 = *(int *)(param_2 + 0x1c);
  uVar4 = *(uint *)(param_2 + 0x18);
  uStack_24 = uVar4 >> 0x18 | iVar5 << 8;
  uStack_1c = uVar4 >> 0x10 | iVar5 << 0x10;
  uStack_18 = uVar4 >> 8 | iVar5 << 0x18;
  fVar18 = (float10)FUN_017268ab(*(undefined4 *)(param_2 + 0x20));
  uVar9 = extraout_var;
  if (((NAN(*(float *)(param_2 + 0x20)) || NAN((float)fVar18)) !=
       (*(float *)(param_2 + 0x20) == (float)fVar18)) ||
     ((fVar18 = (float10)FUN_017268ab(*(undefined4 *)(param_2 + 0x28)), uVar9 = extraout_var_00,
      (NAN(*(float *)(param_2 + 0x28)) || NAN((float)fVar18)) !=
      (*(float *)(param_2 + 0x28) == (float)fVar18) ||
      (fVar18 = (float10)FUN_017268ab(*(undefined4 *)(param_2 + 0x24)), uVar9 = extraout_var_01,
      (NAN(*(float *)(param_2 + 0x24)) || NAN((float)fVar18)) !=
      (*(float *)(param_2 + 0x24) == (float)fVar18))))) {
    fVar19 = *(float *)(param_2 + 0x20);
    if ((NAN(fVar19) || NAN(*(float *)(param_2 + 0x24))) == (fVar19 == *(float *)(param_2 + 0x24)))
    {
LAB_0066360e:
      uStack_14 = uStack_14 & 0xffffff00;
    }
    else {
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
      if ((NAN(fVar19) || NAN(*(float *)(param_2 + 0x28))) == (fVar19 == *(float *)(param_2 + 0x28))
         ) goto LAB_0066360e;
    }
    if (DAT_01d5ab30 == '\0') goto LAB_00663839;
  }
  bVar1 = *(byte *)(param_2 + 0x28) ^ (byte)uStack_24;
  cVar14 = ((char)uVar4 - *(char *)(param_2 + 0x21)) + *(char *)(param_2 + 0x20);
  uStack_24 = CONCAT31((int3)(uVar4 >> 8),cVar14);
  cVar13 = ((*(byte *)(param_2 + 0x20) ^ (byte)uStack_18) - *(char *)(param_2 + 0x22)) +
           *(char *)(param_2 + 0x23);
  cVar2 = *(byte *)(param_2 + 0x28) - *(char *)(param_2 + 0x29);
  cVar11 = (*(char *)(param_2 + 0x27) - (*(byte *)(param_2 + 0x24) ^ (byte)uStack_1c)) +
           *(char *)(param_2 + 0x26);
  cVar7 = (bVar1 - *(char *)(param_2 + 0x2a)) + *(char *)(param_2 + 0x2b);
  uVar8 = (undefined3)(CONCAT22(uVar9,CONCAT11(cVar7,cVar2)) >> 8);
  cVar2 = cVar2 + (byte)uStack_1c;
  uVar4 = CONCAT31(uVar8,cVar2);
  uStack_14 = uStack_14 & 0xffffff00;
  uVar16 = (uint3)(byte)((*(char *)(param_2 + 0x25) - *(byte *)(param_2 + 0x24)) + (byte)uStack_18);
  if ((((cVar13 == '3') && (cVar14 == 'U')) && (cVar7 == -0x56)) && (cVar11 == -0x34)) {
    uVar4 = CONCAT31(uVar8,cVar2) & 0xffffff03;
    bVar17 = false;
    uVar12 = CONCAT31(uVar16,1);
    if ((char)uVar4 != '\x03') goto LAB_006636ac;
    uVar4 = CONCAT31((int3)(uVar4 >> 8),1);
  }
  else {
    uVar12 = (uint)uVar16 << 8;
    if (((cVar13 == '3') && (cVar11 == 'U')) && ((cVar7 == -0x56 && (cVar14 == -0x34)))) {
      bVar17 = true;
    }
    else {
      bVar17 = false;
    }
LAB_006636ac:
    uVar4 = uVar4 & 0xffffff00;
  }
  FUN_0066cb30(0x10,uVar4);
  bVar1 = (byte)(uVar12 >> 8);
  if (((char)uVar12 == '\0') || (bVar1 != 1)) {
    uVar3 = 0;
  }
  else {
    uVar3 = 1;
  }
  FUN_0066cb30(0x20,uVar3);
  if (((uVar12 & 0xff) == (uint)(*(int *)(param_1 + 0x3eec) == 0x4beda921)) &&
     (bVar17 == (*(int *)(param_1 + 0x3eec) == 0x443921d5))) {
    uVar3 = 0;
  }
  else {
    uVar3 = 1;
  }
  uVar4 = FUN_0066cb30(0x40,uVar3);
  if ((char)uVar12 != '\0') {
    uVar12 = (uint)CONCAT11(bVar1 >> 3,bVar1 >> 1);
    uVar15 = uVar12 & 0xffffff03;
    cVar2 = (char)uVar15;
    bVar1 = (byte)(uVar15 >> 8);
    if (((cVar2 == '\0') || (cVar2 == '\x03')) || (1 < bVar1)) {
      uVar4 = 1;
    }
    else {
      uVar4 = uVar4 & 0xffffff00;
    }
    FUN_0066cb30(0x400,uVar4);
    if ((*(char *)(param_1 + 0x3f67) == '\0') && (cVar2 != '\x01')) {
      iVar5 = FUN_008f7870(param_1);
      if (iVar5 == 0) {
        uVar3 = 0xffffffff;
      }
      else {
        uVar3 = *(undefined4 *)(iVar5 + 0x440);
      }
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8 = 0;
      FUN_0151fa60("count2b",uVar12 & 3);
      FUN_0151fa60("countLg",bVar1);
      FUN_0151fa60("unvId",uVar3);
      uVar3 = DAT_01ead7e8;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      FUN_005542c0("MainWindowCountReport",0x15);
      iStack_8._0_1_ = 1;
      FUN_01520d20(auStack_40,uVar3,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_2c) {
        uVar12 = uStack_2c + 1;
        uVar4 = auStack_40[0];
        if (0xfff < uVar12) {
          uVar4 = *(uint *)(auStack_40[0] - 4);
          uVar12 = uStack_2c + 0x24;
          if (0x1f < (auStack_40[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar12);
      }
      iStack_8 = 0xffffffff;
      FUN_0151f7f0();
      *(undefined *)(param_1 + 0x3f67) = 1;
    }
  }
LAB_00663839:
  if ((*(char *)(param_1 + 0x3d70) != '\0') &&
     (pdVar6 = (double *)FUN_016830f0(auStack_20),
     DAT_01d5a690 < (int)(*pdVar6 - *(double *)(param_1 + 0x3e50)))) {
    FUN_0066cb30(0x80,uStack_14);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7652 ; VA 0x00663890 ; FUN_00663890 */

void __thiscall FUN_00663890(int *param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  float10 fVar2;
  undefined8 uVar3;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2790;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)((int)param_1 + 0x3f63) == '\0') {
    ExceptionList = &pvStack_10;
    FUN_0087c450(&DAT_018c5f98,"SecurityException","DOS Detection",0,0,0);
    *(undefined *)((int)param_1 + 0x3f63) = 1;
    FUN_0151f6f0(0xffffffff,0,0);
    iStack_8 = 0;
    FUN_0151f9c0("EtrFill",DAT_01d5bcd8);
    FUN_0151f9c0("PmFill",DAT_01d5bce0);
    FUN_0151f9c0(&DAT_018d4af8,DAT_01d5bce8);
    FUN_0151f9c0(&DAT_018d4b00,DAT_01d5bcf0);
    FUN_0151f9c0("EtrThresh",DAT_01d5bcfc);
    FUN_0151f9c0("PmThresh",DAT_01eaf584);
    FUN_01682800();
    fVar2 = (float10)FUN_006208b0();
    FUN_0151fb00("hTime",(double)fVar2);
    uVar1 = FUN_00620890();
    FUN_0151fc50(&DAT_018d4b24,uVar1,0);
    FUN_0151fc50(&DAT_018d4b28,param_4,0);
    FUN_0151fb00("progress",param_2);
    FUN_0151fb00(&DAT_018d4b3c,param_3);
    uVar3 = FUN_00928340();
    FUN_0151fbb0("chsr-id",uVar3);
    uVar1 = DAT_01d5a750;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("DosDebug2",9);
    iStack_8._0_1_ = 1;
    FUN_01520d20(auStack_30,uVar1,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      if (0xfff < uStack_1c + 1) {
        if (0x1f < (auStack_30[0] - *(int *)(auStack_30[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0();
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    iStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
  if (DAT_01d5ac30 != '\0') {
    (**(code **)(*param_1 + 0x290))("billy",0x1a,2,"DosPrevention",0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7653 ; VA 0x00663ad0 ; FUN_00663ad0 */

void __thiscall FUN_00663ad0(int *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  bool bVar6;
  undefined8 uVar7;
  int iStack_64;
  int iStack_5c;
  undefined auStack_48 [24];
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a27b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab380(*(undefined4 *)(param_2 + 0x38),*(undefined4 *)(param_2 + 0x30),0);
  uStack_8 = 0;
  FUN_006ab660(1);
  iVar1 = FUN_006ace40();
  iStack_28 = iVar1;
  iStack_24 = FUN_006ace40();
  if (param_1[0xf07] == 0) {
    param_2 = 0;
  }
  else {
    param_2 = *(undefined4 *)(param_1[0xf07] + 0x45c);
  }
  uStack_20 = 0x5f;
  if (DAT_01ead6c4 == 2) {
    uStack_20 = 0xdf;
  }
  if (iVar1 != param_1[0xfc1]) {
    *(undefined *)((int)param_1 + 0x3f3e) = 3;
    (**(code **)(*param_1 + 0x290))
              (&DAT_018d2648,0x20,*(char *)((int)param_1 + 0x3f4b) != '\0',
               "DynLua Invalid Challenge",0);
    goto LAB_00663cae;
  }
  if ((param_1[0xfc2] == iStack_24) && (*(char *)((int)param_1 + 0x3f3e) == '\x01')) {
    uStack_1c = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_1c);
    if (0 < DAT_01ead7e4) {
      if (param_1[0xf03] == 0) {
        uStack_1c = 0xffffffffffffffff;
      }
      else {
        uStack_1c = FUN_00928340();
      }
      iVar1 = FUN_008f7870(param_1);
      if (iVar1 == 0) {
        uVar3 = 0xffffffff;
        uStack_14 = 0xffffffff;
      }
      else {
        uVar3 = *(undefined4 *)(iVar1 + 0x440);
        uStack_14 = *(undefined4 *)(iVar1 + 0x444);
      }
      iStack_2c = param_1[0xfbb];
      if ((*(byte *)((int)param_1 + 0x3d72) & 8) == 0) {
        uVar5 = param_1[0xfbd] >> 4;
      }
      else {
        uVar5 = (uint)param_1[0xfbd] >> 1 & 0x7fff;
      }
      iStack_30 = param_1[0xfc2];
      if (DAT_01d5b288 == '\0') {
        uVar2 = FUN_009edf00();
      }
      else {
        uVar2 = 1;
      }
      FUN_00668c40(param_2,iStack_28,uVar2,iStack_24,iStack_30,uVar5,uStack_1c,iStack_2c,1,uStack_20
                   ,uVar3,uStack_14);
    }
  }
  else {
    if (0 < DAT_01ead7e0) {
      if (param_1[0xf03] == 0) {
        uVar7 = 0xffffffffffffffff;
      }
      else {
        uVar7 = FUN_00928340();
      }
      uStack_1c._4_4_ = (undefined4)((ulonglong)uVar7 >> 0x20);
      uStack_14 = (undefined4)uVar7;
      iVar1 = FUN_008f7870(param_1);
      if (iVar1 == 0) {
        uVar3 = 0xffffffff;
        uStack_1c._0_4_ = 0xffffffff;
      }
      else {
        uVar3 = *(undefined4 *)(iVar1 + 0x440);
        uStack_1c._0_4_ = *(undefined4 *)(iVar1 + 0x444);
      }
      iStack_30 = param_1[0xfbb];
      if ((*(byte *)((int)param_1 + 0x3d72) & 8) == 0) {
        uVar5 = param_1[0xfbd] >> 4;
      }
      else {
        uVar5 = (uint)param_1[0xfbd] >> 1 & 0x7fff;
      }
      iStack_2c = param_1[0xfc2];
      if (DAT_01d5b288 == '\0') {
        uVar2 = FUN_009edf00();
      }
      else {
        uVar2 = 1;
      }
      FUN_00668c40(param_2,iStack_28,uVar2,iStack_24,iStack_2c,uVar5,uStack_14,uStack_1c._4_4_,
                   iStack_30,0,uStack_20,uVar3,(undefined4)uStack_1c);
    }
    if ((*(byte *)((int)param_1 + 0x3d72) & 8) == 0) {
      uVar5 = param_1[0xfbd] >> 4;
    }
    else {
      uVar5 = (uint)param_1[0xfbd] >> 1 & 0x7fff;
    }
    uStack_1c = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_1c);
    if (DAT_01d5a5cc <= (int)uVar5) {
      if (5 < DAT_01d5aa28) {
        uVar5 = param_1[0xfbb];
        if (uVar5 < 0x71375636) {
          if (uVar5 == 0x71375635) {
            pcVar4 = (char *)&DAT_01d5aa18;
            if (0xf < DAT_01d5aa2c) {
              pcVar4 = DAT_01d5aa18;
            }
            bVar6 = *pcVar4 == '.';
          }
          else if (uVar5 == 0xc57b823) {
            pcVar4 = (char *)&DAT_01d5aa18;
            if (0xf < DAT_01d5aa2c) {
              pcVar4 = DAT_01d5aa18;
            }
            bVar6 = pcVar4[2] == '.';
          }
          else if (uVar5 == 0x443921d5) {
            pcVar4 = (char *)&DAT_01d5aa18;
            if (0xf < DAT_01d5aa2c) {
              pcVar4 = DAT_01d5aa18;
            }
            bVar6 = pcVar4[3] == '.';
          }
          else {
            if (uVar5 != 0x4beda921) goto LAB_00663ebe;
            pcVar4 = (char *)&DAT_01d5aa18;
            if (0xf < DAT_01d5aa2c) {
              pcVar4 = DAT_01d5aa18;
            }
            bVar6 = pcVar4[1] == '.';
          }
LAB_00663eb3:
          bVar6 = !bVar6;
        }
        else {
          if (uVar5 == 0x752fab0b) {
            pcVar4 = (char *)&DAT_01d5aa18;
            if (0xf < DAT_01d5aa2c) {
              pcVar4 = DAT_01d5aa18;
            }
            bVar6 = pcVar4[5] == '.';
            goto LAB_00663eb3;
          }
          if (uVar5 == 0x9d49834b) {
            pcVar4 = (char *)&DAT_01d5aa18;
            if (0xf < DAT_01d5aa2c) {
              pcVar4 = DAT_01d5aa18;
            }
            bVar6 = pcVar4[4] == '.';
            goto LAB_00663eb3;
          }
          bVar6 = uVar5 == 0xe74bdb5b;
        }
        uStack_1c = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_1c);
        if (bVar6) goto LAB_00663c73;
      }
LAB_00663ebe:
      *(undefined *)((int)param_1 + 0x3f3e) = 3;
      (**(code **)(*param_1 + 0x290))
                (&DAT_018d2668,0x20,*(char *)((int)param_1 + 0x3f4b) != '\0',
                 "DynLua Invalid Response",0);
      goto LAB_00663cae;
    }
  }
LAB_00663c73:
  *(undefined *)((int)param_1 + 0x3f3e) = 2;
  uVar3 = FUN_005f2c00(param_1[0xfbb]);
  uVar3 = FUN_01675640(auStack_48,"DynLua-Pass-%s",uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008783f0(uVar3,1,0);
  FUN_005507b0();
LAB_00663cae:
  if (iStack_64 != 0) {
    uVar5 = iStack_5c - iStack_64;
    iVar1 = iStack_64;
    if (0xfff < uVar5) {
      iVar1 = *(int *)(iStack_64 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_64 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7654 ; VA 0x00663f10 ; FUN_00663f10 */

void __thiscall FUN_00663f10(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined auStack_5c [8];
  int iStack_54;
  int iStack_50;
  undefined4 **ppuStack_4c;
  undefined4 *puStack_48;
  undefined4 **ppuStack_44;
  undefined4 **appuStack_34 [5];
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a27d8;
  pvStack_10 = ExceptionList;
  if ((*(char *)(param_1 + 0xf5c) != '\0') && (iVar1 = param_1[0xf16], iVar1 != 0)) {
    if (DAT_01d5ace8 != '\0') {
      iStack_18 = param_1[0xf17];
      ExceptionList = &pvStack_10;
      if (iStack_18 != 0) {
        LOCK();
        ExceptionList = &pvStack_10;
        *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
        UNLOCK();
        iVar1 = param_1[0xf16];
        iStack_18 = param_1[0xf17];
      }
      uStack_8 = 0;
      iStack_1c = iVar1;
      if (iVar1 != 0) {
        ppuStack_44 = appuStack_34;
        puStack_48 = (undefined4 *)0x663f94;
        puStack_48 = (undefined4 *)FUN_00927520();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (0xf < (uint)puStack_48[5]) {
          puStack_48 = (undefined4 *)*puStack_48;
        }
        ppuStack_4c = *(undefined4 ***)(iVar1 + 0x28);
        if (0xf < (uint)((int *)ppuStack_4c)[5]) {
          ppuStack_4c = (undefined4 **)*ppuStack_4c;
        }
        ppuStack_44 = (undefined4 **)(param_1 + 0x1d);
        iStack_50 = param_1[0xf65];
        iStack_54 = param_1[0xf64];
        FUN_005817f0(auStack_5c);
        FUN_00644e80(param_2);
        ppuStack_44 = (undefined4 **)0x663fdc;
        FUN_005507b0();
      }
      ppuStack_44 = (undefined4 **)0x663fe4;
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (DAT_01d5af18 != '\0') {
      ppuStack_44 = *(undefined4 ***)(iVar1 + 0x28);
      puStack_48 = (undefined4 *)0x66400b;
      ExceptionList = &pvStack_10;
      FUN_0054ef60();
      uStack_8 = 2;
      ppuStack_44 = (undefined4 **)0x664022;
      ppuStack_44 = (undefined4 **)(**(code **)(*param_1 + 0x214))();
      puStack_48 = (undefined4 *)0x664028;
      puStack_48 = (undefined4 *)FUN_005f2c00();
      ppuStack_44 = (undefined4 **)(param_1 + 0x1d);
      ppuStack_4c = appuStack_34;
      if (0xf < uStack_20) {
        ppuStack_4c = appuStack_34[0];
      }
      iStack_50 = param_1[0xf65];
      iStack_54 = param_1[0xf64];
      FUN_005817f0(auStack_5c);
      FUN_00644e80(param_2);
      ppuStack_44 = (undefined4 **)0x66406b;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    ppuStack_44 = (undefined4 **)0x66408c;
    ExceptionList = &pvStack_10;
    ppuStack_44 = (undefined4 **)(**(code **)(*param_1 + 0x214))();
    puStack_48 = (undefined4 *)0x664092;
    puStack_48 = (undefined4 *)FUN_005f2c00();
    ppuStack_44 = (undefined4 **)(param_1 + 0x1d);
    ppuStack_4c = (undefined4 **)&DAT_018bc9b8;
    iStack_50 = param_1[0xf65];
    iStack_54 = param_1[0xf64];
    FUN_005817f0(auStack_5c);
    FUN_00644e80(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7655 ; VA 0x006640e0 ; FUN_006640e0 */

void __thiscall FUN_006640e0(int *param_1,uint param_2)

{
  byte bVar1;
  bool bVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_174 [40];
  undefined auStack_d4 [56];
  undefined auStack_9c [56];
  undefined auStack_64 [24];
  undefined auStack_4c [12];
  undefined4 ***apppuStack_40 [5];
  uint uStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2751;
  pvStack_10 = ExceptionList;
  bVar2 = false;
  if ((*(char *)((int)param_1 + 0x37fe) == '\0') && (param_2 != 0)) {
    uStack_18 = 0;
    puVar3 = &DAT_01d5aa50;
    if (0xf < DAT_01d5aa64) {
      puVar3 = DAT_01d5aa50;
    }
    uVar6 = 0;
    uVar8 = 0x80000000;
    do {
      bVar1 = *(byte *)((int)puVar3 + uVar6);
      if (bVar1 == 0) {
LAB_00664180:
        bVar2 = true;
        uStack_18 = 0;
        break;
      }
      if (uVar6 % 5 == 4) {
        uVar7 = uVar8;
        uVar8 = uStack_18;
        if (0x37 < bVar1) goto LAB_00664180;
      }
      else {
        uVar7 = uVar8 >> 1;
        uVar8 = uVar8 | uStack_18;
        if (bVar1 != 0x2e) {
          uVar8 = uStack_18;
        }
      }
      uStack_18 = uVar8;
      uVar6 = uVar6 + 1;
      uVar8 = uVar7;
    } while (uVar6 < 0x28);
    uStack_20 = 0;
    puVar3 = &DAT_01d5aa50;
    if (0xf < DAT_01d5aa64) {
      puVar3 = DAT_01d5aa50;
    }
    uVar6 = 0;
    uVar8 = 0x80000000;
    do {
      bVar1 = *(byte *)((int)puVar3 + uVar6);
      if (bVar1 == 0) {
LAB_006641f0:
        uStack_20 = 0;
        bVar2 = true;
        break;
      }
      if (uVar6 % 5 == 4) {
        uVar7 = uVar8;
        uVar8 = uStack_20;
        if (0x37 < bVar1) goto LAB_006641f0;
      }
      else {
        uVar7 = uVar8 >> 1;
        uVar8 = uVar8 | uStack_20;
        if (bVar1 != 0x3a) {
          uVar8 = uStack_20;
        }
      }
      uStack_20 = uVar8;
      uVar6 = uVar6 + 1;
      uVar8 = uVar7;
    } while (uVar6 < 0x28);
    uStack_1c = 0x80000000;
    puStack_24 = &DAT_01d5aa50;
    if (0xf < DAT_01d5aa64) {
      puStack_24 = DAT_01d5aa50;
    }
    uVar6 = 0;
    uVar8 = 0;
    do {
      bVar1 = *(byte *)((int)puStack_24 + uVar6);
      if (bVar1 == 0) {
LAB_00664263:
        uVar7 = 0;
        bVar2 = true;
        break;
      }
      if (uVar6 % 5 == 4) {
        uVar7 = uVar8;
        if (0x37 < bVar1) goto LAB_00664263;
      }
      else {
        uVar7 = uStack_1c | uVar8;
        uStack_1c = uStack_1c >> 1;
        if (bVar1 != 0x67) {
          uVar7 = uVar8;
        }
      }
      uVar6 = uVar6 + 1;
      uVar8 = uVar7;
    } while (uVar6 < 0x28);
    uVar8 = uVar7 | uStack_20 | uStack_18;
    cStack_11 = '\0';
    ExceptionList = &pvStack_10;
    piStack_28 = param_1;
    if ((param_2 & uVar8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0058ccc0(auStack_4c,0xb,"H:%08X",param_2);
      FUN_0151f850(&DAT_018d20dc,auStack_4c);
      (**(code **)(*piStack_28 + 0x290))("hector",9,1,"HashStats",auStack_9c);
      cStack_11 = '\x01';
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    uStack_1c = 0x80000000;
    uStack_18 = 0;
    puStack_24 = &DAT_01d5aa50;
    if (0xf < DAT_01d5aa64) {
      puStack_24 = DAT_01d5aa50;
    }
    uVar6 = 0;
    do {
      bVar1 = *(byte *)((int)puStack_24 + uVar6);
      if (bVar1 == 0) {
LAB_0066435b:
        bVar2 = true;
        uVar7 = 0;
        break;
      }
      if (uVar6 % 5 == 4) {
        uVar7 = uStack_18;
        if (0x37 < bVar1) goto LAB_0066435b;
      }
      else {
        uVar7 = uStack_1c | uStack_18;
        uStack_1c = uStack_1c >> 1;
        if (bVar1 != 0x72) {
          uVar7 = uStack_18;
        }
      }
      uStack_18 = uVar7;
      uVar6 = uVar6 + 1;
      uVar7 = uStack_18;
    } while (uVar6 < 0x28);
    if ((param_2 & (uVar8 | uVar7)) != 0) {
      FUN_00565940(3,1);
      uStack_8 = 1;
      FUN_00558890(aiStack_174,"MemHashError: ");
      FUN_00585a70((int)aiStack_174 + *(int *)(aiStack_174[0] + 4));
      FUN_0056ef60(param_2);
      FUN_0058c420(apppuStack_40);
      ppppuVar4 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar4 = (undefined4 ****)apppuStack_40[0];
      }
      uStack_8._0_1_ = 2;
      FUN_0087c450(&DAT_018c5f98,"SecurityException",ppppuVar4,0,0,0);
      if (cStack_11 == '\0') {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 3;
        uVar5 = FUN_01675640(auStack_64,"H:%08X",param_2);
        uStack_8._0_1_ = 4;
        FUN_0151f950(&DAT_018d20dc,uVar5);
        uStack_8._0_1_ = 3;
        FUN_005507b0();
        (**(code **)(*piStack_28 + 0x290))("hector",9,0,"HashStats",auStack_d4);
        FUN_0151f7f0();
      }
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_005705c0();
    }
    if (bVar2) {
      FUN_006688b0("US30605p2");
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7656 ; VA 0x006644b0 ; FUN_006644b0 */

void __thiscall FUN_006644b0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_ec [160];
  undefined auStack_4c [24];
  undefined4 ***apppuStack_34 [5];
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2813;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  if (*(char *)(param_1 + 0xf6b) != '\0') {
    piVar1 = (int *)param_2[1];
    piVar2 = (int *)param_1[0xf68];
    uVar8 = -(uint)(piVar1[5] != piVar2[5]) & 0x20 | -(uint)(piVar1[3] != piVar2[3]) & 8 |
            -(uint)(piVar1[2] != piVar2[2]) & 4 | -(uint)(piVar1[1] != piVar2[1]) & 2 |
            (uint)(*piVar1 != *piVar2);
  }
  uStack_14 = *param_2;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_014ec030(*(undefined4 *)(param_2[1] + 0xc),*(undefined4 *)(param_2[1] + 0x10));
  uVar8 = uVar8 | -(uint)(7 < (iVar3 - uStack_14) * 0x54545455 + 3) & 0x10;
  if (*(char *)(param_1 + 0xf6b) != '\0') {
    uVar4 = (param_1[0xf67] - uStack_14) * 0x54545455;
    if ((uVar4 < 4) && (uVar4 != 0)) {
      uVar4 = 0;
    }
    else {
      uVar4 = 0x80;
    }
    uVar8 = uVar8 | uVar4;
  }
  if ((uint)(param_2[2] - param_2[1] >> 2) < 0x26) {
    if (((DAT_01d5abb8 != '\0') || (DAT_01d5abc0 != '\0')) &&
       (*(char *)((int)param_1 + 0x3f55) == '\0')) {
      *(undefined *)((int)param_1 + 0x3f55) = 1;
      FUN_0087c450(&DAT_018c5f98,"SecurityException","Incorrect Number of Hashes",0,0,0);
      (**(code **)(*param_1 + 0x290))("mhaster",0xc,DAT_01d5abc0 != '\0',"WrongNumberHashes",0);
    }
  }
  else {
    if (((DAT_01d5abc8 != '\0') && (*(char *)(param_1 + 0xfd5) == '\0')) &&
       ((param_1[0xf74] == 0 || (*(char *)(param_1[0xf74] + 0xa1) != '\0')))) {
      FUN_0065aeb0(&iStack_18);
      uStack_8 = 0;
      if (iStack_18 != 0) {
        FUN_00565940(3,1);
        uStack_8._0_1_ = 1;
        FUN_00558890(auStack_ec,"GsiFailedToLoad: ");
        if (param_1[0xf74] == 0) {
          FUN_00558890(auStack_ec,"AslrPmcNull");
        }
        else {
          uVar5 = FUN_00718110(auStack_4c,*(undefined4 *)(param_1[0xf74] + 8));
          uStack_8._0_1_ = 2;
          FUN_00558840(auStack_ec,uVar5);
          uStack_8._0_1_ = 1;
          FUN_005507b0();
        }
        FUN_0058c420(apppuStack_34);
        ppppuVar6 = apppuStack_34;
        if (0xf < uStack_20) {
          ppppuVar6 = (undefined4 ****)apppuStack_34[0];
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_0087c450(&DAT_018c5f98,"SecurityException",ppppuVar6,0,0,0);
        *(undefined *)(param_1 + 0xfd5) = 1;
        FUN_005507b0();
        FUN_005705c0();
      }
      uStack_8 = 0xffffffff;
      FUN_00550b30();
    }
    if (param_1[0xf74] != 0) {
      FUN_00716dc0(param_2[1] + 0x18,0x1e,0);
    }
  }
  if (param_1[0xf74] != 0) {
    FUN_00664c70();
  }
  iStack_1c = param_2[1];
  uVar4 = *(uint *)(iStack_1c + 0x90) & 0xb9a4b34a;
  uVar4 = uVar4 - (uVar4 >> 1 & 0x55555555);
  uVar7 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333);
  uVar4 = uVar8 | 0x200;
  if ((((uVar7 >> 4) + uVar7 & 0xff0f0f0f) * -0xfefeff & 0x1000000) == 0) {
    uVar4 = uVar8;
  }
  uVar8 = *(uint *)(iStack_1c + 0x90) & 0xc75cc383;
  uVar8 = uVar8 - (uVar8 >> 1 & 0x55555555);
  uVar7 = (uVar8 >> 2 & 0x33333333) + (uVar8 & 0x33333333);
  iVar3 = param_1[0xf74];
  uVar8 = uVar4 | 0x400;
  if ((((uVar7 >> 4) + uVar7 & 0xff0f0f0f) * -0xfefeff & 0x1000000) == 0) {
    uVar8 = uVar4;
  }
  uStack_14 = uVar8;
  if ((iVar3 == 0) ||
     ((uVar4 = *(uint *)(iStack_1c + 0x90) & 0x1050d751, uVar4 = uVar4 - (uVar4 >> 1 & 0x55555555),
      uVar4 = (uVar4 >> 2 & 0x33333333) + (uVar4 & 0x33333333),
      (((uVar4 >> 4) + uVar4 & 0xff0f0f0f) * -0xfefeff & 0x1000000) == 0 &&
      ((*(char *)(param_1 + 0xf78) == '\0' || (*(int *)(iStack_1c + 0x94) == param_1[0xf76])))))) {
    if (((iVar3 != 0) && (*(char *)(iVar3 + 0xa2) != '\0')) && (*(char *)(iVar3 + 0xa3) != '\0')) {
      param_1[0xf77] = param_1[0xf77] + 1;
    }
  }
  else {
    iVar3 = FUN_00717ff0();
    if (*(int *)(iStack_1c + 0x94) != iVar3) {
      uVar8 = uVar8 | 0x800;
    }
    param_1[0xf76] = *(int *)(param_2[1] + 0x94);
    FUN_007198d0();
    *(undefined *)(param_1 + 0xf78) = 1;
    param_1[0xf77] = 0;
  }
  iVar3 = param_2[1];
  if ((0x2000000 < *(uint *)(iVar3 + 0x9c)) &&
     (((DAT_01d5ab68 != '\0' || (DAT_01d5ab70 != '\0')) && (*(char *)(param_1 + 0xfd4) == '\0')))) {
    *(undefined *)(param_1 + 0xfd4) = 1;
    FUN_0087c450(&DAT_018c5f98,"SecurityException","VmpSize has been modified",0,0,0);
    (**(code **)(*param_1 + 0x290))(&DAT_018d3578,0xc,DAT_01d5ab70 != '\0',"WrongVmpSize",0);
    iVar3 = param_2[1];
  }
  if (((0x2000000 < *(uint *)(iVar3 + 0x98)) && ((DAT_01d5ab78 != '\0' || (DAT_01d5ab80 != '\0'))))
     && (*(char *)(param_1 + 0xfd4) == '\0')) {
    *(undefined *)(param_1 + 0xfd4) = 1;
    FUN_0087c450(&DAT_018c5f98,"SecurityException","TextSize has been modified",0,0,0);
    (**(code **)(*param_1 + 0x290))(&DAT_018d35a8,0xc,DAT_01d5ab80 != '\0',"WrongTextSize",0);
  }
  (**(code **)(*param_1 + 0x1a0))(~param_1[0xf6c] & uVar8);
  param_1[0xf6c] = param_1[0xf6c] | uVar8;
  *(char *)((int)param_1 + 0x3de3) = *(char *)((int)param_1 + 0x3de3) + '\x01';
  *(undefined *)((int)param_1 + 0x3de2) = 0;
  *(undefined *)(param_1 + 0xf79) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7657 ; VA 0x00664a10 ; FUN_00664a10 */

void __thiscall FUN_00664a10(int *param_1,undefined4 *param_2,int param_3)

{
  undefined8 uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  
  uVar1 = FUN_012556e0(*param_2,param_2[1]);
  if (*(char *)(param_1 + 0xf6b) == '\0') {
    param_1[0xf9c] = param_2[2];
    param_1[0xf9d] = param_2[3];
    return;
  }
  if ((int)((ulonglong)uVar1 >> 0x20) == 0) {
    if ((param_1[0xf6d] & (uint)uVar1) != 0) {
      (**(code **)(*param_1 + 0x19c))((uint)uVar1,0);
    }
  }
  else if (*(char *)(param_1 + 0xfd3) == '\0') {
    *(undefined *)(param_1 + 0xfd3) = 1;
    FUN_0087c450(&DAT_018c5f98,"SecurityException","FuzzyToken Tamper, v3",0,0,0);
    (**(code **)(*param_1 + 0x290))(&DAT_018d370c,0xb,DAT_01d5ab60 != '\0',"FuzzyTokenTamper",0);
  }
  if ((param_1[0xf67] - param_3) * 0x54545455 != 2) {
    if ((*(char *)((int)param_1 + 0x3f4e) == '\0') &&
       ((param_1[4000] != param_2[4] || (param_1[0xfa1] != param_2[5])))) {
      if ((DAT_01d5ab40 != '\0') || (DAT_01d5ab48 != '\0')) {
        FUN_0087c450(&DAT_018c5f98,"SecurityException","Api FakeSkip",0,0,0);
        (**(code **)(*param_1 + 0x290))(&DAT_018d370c,0xb,DAT_01d5ab48 != '\0',"ApiFakeSkip",0);
      }
      *(undefined *)((int)param_1 + 0x3f4e) = 1;
    }
    uVar1 = FUN_012556e0(param_2[2],param_2[3]);
    FUN_00662f00(uVar1);
    return;
  }
  uVar2 = FUN_012556e0(param_2[4],param_2[5]);
  uVar3 = FUN_012556e0(param_2[2],param_2[3]);
  FUN_00662f00(uVar2 | uVar3);
  return;
}



/* FUNCTION 7658 ; VA 0x00664bc0 ; FUN_00664bc0 */

void __fastcall FUN_00664bc0(int *param_1)

{
  int iVar1;
  int iVar2;
  char cStack00000007;
  
  iVar1 = FUN_006ace40();
  iVar2 = FUN_006ace40();
  cStack00000007 = iVar1 != param_1[0xfc1];
  iVar1 = FUN_005f2e60(iVar1,param_1[0xfbb],param_1[0xfbc],param_1[0xfbd]);
  if (((iVar1 != iVar2) || (cStack00000007 != '\0')) && (0 < DAT_01d5a5a8)) {
    FUN_0087c450(&DAT_018c5f98,"SecurityException","Fake Join Data",0,0,0);
    (**(code **)(*param_1 + 0x290))("challenger",0x18,1 < DAT_01d5a5a8,"IdChallengeError",0);
  }
  *(undefined *)((int)param_1 + 0x3f62) = 1;
  return;
}



/* FUNCTION 7659 ; VA 0x00664c70 ; FUN_00664c70 */

void __fastcall FUN_00664c70(int *param_1)

{
  bool bVar1;
  bool bVar2;
  char cVar3;
  uint uVar4;
  char *pcVar5;
  undefined4 uVar6;
  char *pcVar7;
  undefined *puVar8;
  undefined auStack_108 [80];
  undefined auStack_b8 [56];
  undefined auStack_80 [12];
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2905;
  pvStack_10 = ExceptionList;
  if (param_1[0xf74] == 0) {
    return;
  }
  if (*(int *)(param_1[0xf74] + 0x6c) == 0) {
    return;
  }
  uVar4 = 0;
  uStack_58 = 4;
  uStack_54 = 0;
  bVar2 = false;
  uStack_50 = 0;
  cStack_11 = '\0';
  cStack_12 = '\0';
  uStack_70 = 0xffffffff;
  uStack_48 = 0xffffffff;
  uStack_6c = 0xffffffff;
  uStack_74 = 0xffffffff;
  uStack_60 = 0xffffffff;
  uStack_68 = 0xffffffff;
  uStack_5c = 0xffffffff;
  uStack_64 = 0xffffffff;
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_20 = 0;
  uStack_44 = uStack_44 & 0xffffff00;
  uStack_28 = uStack_28 & 0xffffff00;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00718a10(&uStack_58);
  if (cVar3 != '\0') {
    do {
      switch(uStack_58) {
      case 0:
        uVar4 = uVar4 | 1 << (uStack_50 & 0x1f);
        break;
      case 1:
        uStack_1c = uStack_1c | 1 << (uStack_50 & 0x1f);
        break;
      default:
        bVar2 = true;
        break;
      case 3:
        uStack_44 = CONCAT31(uStack_44._1_3_,1);
        break;
      case 5:
        uStack_18 = uStack_18 | 1 << (uStack_50 & 0x1f);
        break;
      case 6:
        uStack_20 = uStack_20 | 1 << (uStack_50 & 0x1f);
      }
      cVar3 = FUN_00718a10(&uStack_58);
    } while (cVar3 != '\0');
    uStack_28 = CONCAT31(uStack_28._1_3_,bVar2);
    uStack_24 = uVar4;
  }
  cVar3 = '\0';
  if ((uStack_20 == 0) && ((uStack_18 & ~param_1[0xf72]) == 0)) {
LAB_0066509e:
    if ((uStack_1c != 0) || (uVar4 != 0)) {
      FUN_0065af90(&DAT_01d5aab0,&uStack_70,&uStack_48,&uStack_6c,&uStack_74,&cStack_11);
      if ((uStack_6c & ~param_1[0xf71] & uVar4) == 0) {
        if ((uStack_70 & uStack_1c) != 0) {
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 9;
          FUN_0058ccc0(auStack_80,0xb,"H:%08X",uStack_1c);
          FUN_0151f850(&DAT_018d20dc,auStack_80);
          pcVar7 = "GoldHash";
          uVar6 = 0xe;
          pcVar5 = "Goldilocks";
          goto LAB_006651a6;
        }
      }
      else {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8 = 8;
        FUN_0058ccc0(auStack_80,0xb,"H:%08X",uVar4);
        FUN_0151f850(&DAT_018d20dc,auStack_80);
        pcVar7 = "DiffHash";
        uVar6 = 0xd;
        pcVar5 = "Diva";
LAB_006651a6:
        (**(code **)(*param_1 + 0x290))(pcVar5,uVar6,1,pcVar7,auStack_b8);
        uStack_8 = 0xffffffff;
        cVar3 = '\x01';
        FUN_0151f7f0();
      }
      if ((uStack_74 & ~param_1[0xf71] & uVar4) == 0) {
        if ((uStack_48 & uStack_1c) != 0) {
          FUN_0087c450(&DAT_018c5f98,"SecurityException","GoldHashError",0,0,0);
          if (cVar3 == '\0') {
            FUN_0151f6f0(0xffffffff,0,0);
            uStack_8 = 0xd;
            uVar6 = FUN_01675640(auStack_40,"H:%08X",uStack_1c);
            uStack_8._0_1_ = 0xe;
            FUN_0151f950(&DAT_018d20dc,uVar6);
            uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
            FUN_005507b0();
            (**(code **)(*param_1 + 0x290))("Goldilocks",0xe,0,"GoldHash",auStack_b8);
            uStack_8 = 0xffffffff;
            FUN_0151f7f0();
LAB_00665360:
            bVar1 = false;
          }
          else {
            if (DAT_01d5ac48 != '\0') goto LAB_00665360;
            bVar1 = true;
          }
          pcVar5 = "kicked";
          if (!bVar1) {
            pcVar5 = "notKicked";
          }
          FUN_0054eff0(pcVar5);
          uStack_8 = 0xf;
          goto LAB_00665387;
        }
      }
      else {
        FUN_0087c450(&DAT_018c5f98,"SecurityException","DiffHashError",0,0,0);
        if (cVar3 == '\0') {
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 10;
          uVar6 = FUN_01675640(auStack_40,"H:%08X",uVar4);
          uStack_8._0_1_ = 0xb;
          FUN_0151f950(&DAT_018d20dc,uVar6);
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          FUN_005507b0();
          (**(code **)(*param_1 + 0x290))(&DAT_018d361c,0xd,0,"DiffHash",auStack_b8);
          uStack_8 = 0xffffffff;
          FUN_0151f7f0();
LAB_0066527b:
          bVar1 = false;
        }
        else {
          if (DAT_01d5ac48 != '\0') goto LAB_0066527b;
          bVar1 = true;
        }
        pcVar5 = "kicked";
        if (!bVar1) {
          pcVar5 = "notKicked";
        }
        FUN_0054eff0(pcVar5);
        uStack_8 = 0xc;
LAB_00665387:
        FUN_00719590(auStack_40);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        uVar4 = uStack_24;
      }
      param_1[0xf71] = param_1[0xf71] | uVar4;
      if (cVar3 != '\0') goto LAB_006654a2;
    }
    if ((char)uStack_44 != '\0') {
      if (((DAT_01d5abd0 != '\0') || (DAT_01d5abd8 != '\0')) &&
         (*(char *)((int)param_1 + 0x3f5d) == '\0')) {
        FUN_0087c450(&DAT_018c5f98,"SecurityException","Spoofed Hash Data",0,0,0);
        (**(code **)(*param_1 + 0x290))("Sprofessor",0xb,DAT_01d5abd8 != '\0',"SpoofedHash",0);
        cVar3 = DAT_01d5abd8;
      }
      *(undefined *)((int)param_1 + 0x3f5d) = 1;
      if (cVar3 != '\0') goto LAB_006654a2;
    }
    if (!bVar2) goto LAB_0066570d;
    if (((DAT_01d5abe0 != '\0') || (DAT_01d5abe8 != '\0')) &&
       (*(char *)((int)param_1 + 0x3f5e) == '\0')) {
      FUN_0087c450(&DAT_018c5f98,"SecurityException","Invalid Hash Data",0,0,0);
      (**(code **)(*param_1 + 0x290))("Invert",0xb,DAT_01d5abe8 != '\0',"InvalidHash",0);
      cVar3 = DAT_01d5abe8;
    }
    *(undefined *)((int)param_1 + 0x3f5e) = 1;
    if (cVar3 == '\0') goto LAB_0066570d;
  }
  else {
    FUN_0065af90(&DAT_01d5aaf8,&uStack_60,&uStack_68,&uStack_5c,&uStack_64,&cStack_12);
    if ((uStack_5c & ~param_1[0xf72] & uStack_18) == 0) {
      if ((uStack_60 & uStack_20) != 0) {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8 = 1;
        FUN_0058ccc0(auStack_80,0xb,"H:%08X",uStack_20);
        FUN_0151f850(&DAT_018d20dc,auStack_80);
        pcVar7 = "RandGoldHash";
        uVar6 = 0xe;
        pcVar5 = "Ruh-Roe";
        goto LAB_00664e8a;
      }
    }
    else {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0058ccc0(auStack_80,0xb,"H:%08X",uStack_18);
      FUN_0151f850(&DAT_018d20dc,auStack_80);
      pcVar7 = "RandDiffHash";
      uVar6 = 0xd;
      pcVar5 = "antiswag";
LAB_00664e8a:
      (**(code **)(*param_1 + 0x290))(pcVar5,uVar6,1,pcVar7,auStack_b8);
      uStack_8 = 0xffffffff;
      cVar3 = '\x01';
      FUN_0151f7f0();
    }
    if ((uStack_64 & ~param_1[0xf72] & uStack_18) == 0) {
      if ((uStack_68 & uStack_20) != 0) {
        FUN_0087c450(&DAT_018c5f98,"SecurityException","RandGoldHashError",0,0,0);
        if (cVar3 == '\0') {
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 5;
          uVar6 = FUN_01675640(auStack_40,"H:%08X",uStack_20);
          uStack_8._0_1_ = 6;
          FUN_0151f950(&DAT_018d20dc,uVar6);
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          FUN_005507b0();
          (**(code **)(*param_1 + 0x290))("Ruh-Roe",0xe,0,"RandGoldHash",auStack_b8);
          uStack_8 = 0xffffffff;
          FUN_0151f7f0();
LAB_00665049:
          bVar1 = false;
        }
        else {
          if (DAT_01d5ac48 != '\0') goto LAB_00665049;
          bVar1 = true;
        }
        pcVar5 = "kicked";
        if (!bVar1) {
          pcVar5 = "notKicked";
        }
        FUN_0054eff0(pcVar5);
        uStack_8 = 7;
        goto LAB_00665070;
      }
    }
    else {
      FUN_0087c450(&DAT_018c5f98,"SecurityException","RandDiffHashError",0,0,0);
      if (cVar3 == '\0') {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8 = 2;
        uVar6 = FUN_01675640(auStack_40,"H:%08X",uStack_18);
        uStack_8._0_1_ = 3;
        FUN_0151f950(&DAT_018d20dc,uVar6);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_005507b0();
        (**(code **)(*param_1 + 0x290))("antiswag",0xd,0,"RandDiffHash",auStack_b8);
        uStack_8 = 0xffffffff;
        FUN_0151f7f0();
LAB_00664f64:
        bVar1 = false;
      }
      else {
        if (DAT_01d5ac48 != '\0') goto LAB_00664f64;
        bVar1 = true;
      }
      pcVar5 = "kicked";
      if (!bVar1) {
        pcVar5 = "notKicked";
      }
      FUN_0054eff0(pcVar5);
      uStack_8 = 4;
LAB_00665070:
      FUN_00719590(auStack_40);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      uVar4 = uStack_24;
    }
    param_1[0xf72] = param_1[0xf72] | uStack_18;
    if (cVar3 == '\0') goto LAB_0066509e;
  }
LAB_006654a2:
  if (*(char *)((int)param_1 + 0x3f5f) == '\0') {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0x10;
    FUN_0151fa60(&DAT_018d36b0,uVar4);
    FUN_0151fa60(&DAT_018d36b4,uStack_1c);
    FUN_0151fa60(&DAT_018d36b8,uStack_18);
    FUN_0151fa60(&DAT_018d36bc,uStack_20);
    FUN_0151fcf0(&DAT_018d36c0,uStack_44);
    FUN_0151fcf0(&DAT_018d36c4,uStack_28);
    uVar6 = DAT_01d5a708;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0("AslrPmc",7);
    uStack_8._0_1_ = 0x11;
    FUN_01520d20(auStack_40,uVar6,0);
    uStack_8._0_1_ = 0x10;
    FUN_005507b0();
    *(undefined *)((int)param_1 + 0x3f5f) = 1;
    uStack_28 = FUN_01674e20(0x38);
    uStack_8._0_1_ = 0x12;
    if (uStack_28 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_0151f6f0(0xffffffff,0,0);
    }
    uStack_8._0_1_ = 0x10;
    uStack_4c = 0;
    uStack_48 = 0;
    FUN_0064daf0(uVar6,uStack_28);
    uStack_8._0_1_ = 0x13;
    uVar6 = FUN_005ed290(auStack_40,uStack_24);
    uStack_8._0_1_ = 0x14;
    FUN_0151f950(&DAT_018d26f4,uVar6);
    uStack_8._0_1_ = 0x13;
    FUN_005507b0();
    uVar6 = FUN_005ed290(auStack_40,uStack_1c);
    uStack_8._0_1_ = 0x15;
    FUN_0151f950(&DAT_018d279c,uVar6);
    uStack_8._0_1_ = 0x13;
    FUN_005507b0();
    uVar6 = FUN_005ed290(auStack_40,uStack_18);
    uStack_8._0_1_ = 0x16;
    FUN_0151f950(&DAT_018d27a0,uVar6);
    uStack_8._0_1_ = 0x13;
    FUN_005507b0();
    uVar6 = FUN_005ed290(auStack_108,uStack_20);
    uStack_8._0_1_ = 0x17;
    FUN_0151f950(&DAT_018d27a4,uVar6);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    FUN_005507b0();
    pcVar5 = "spoofed";
    if ((char)uStack_44 == '\0') {
      pcVar5 = "";
    }
    FUN_0151f850(&DAT_018d27a8,pcVar5);
    pcVar5 = "invalid";
    if (bVar2 == false) {
      pcVar5 = "";
    }
    puVar8 = &DAT_018d27ec;
    FUN_0151f850(&DAT_018d27ec,pcVar5);
    FUN_00557fc0(&uStack_4c);
    FUN_0066d800(4,0,0,0,puVar8,pcVar5);
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
LAB_0066570d:
  if (cStack_11 != '\0') {
    FUN_006688b0("US30605p6");
  }
  if (cStack_12 != '\0') {
    FUN_006688b0("US30605p8");
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7660 ; VA 0x00665760 ; FUN_00665760 */

void __fastcall FUN_00665760(int *param_1)

{
  undefined uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  uVar1 = FUN_006abe40();
  uVar3 = FUN_006ace40();
  uVar4 = FUN_006ace60();
  cVar2 = FUN_007194c0(uVar1);
  if ((cVar2 != '\0') && (*(char *)((int)param_1 + 0x3f51) == '\0')) {
    cVar2 = FUN_00716fa0(uVar1,uVar3,uVar4);
    if (cVar2 == '\0') {
      *(undefined *)((int)param_1 + 0x3f51) = 1;
      (**(code **)(*param_1 + 0x290))("WorldEdit",0xf,DAT_01d5aba8 != '\0',"NetPmcError",0);
      FUN_0087c450(&DAT_018c5f98,"SecurityException","NetPmc Error P2.",0,0,0);
    }
  }
  return;
}



/* FUNCTION 7661 ; VA 0x00665820 ; FUN_00665820 */

void __thiscall FUN_00665820(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  char *pcVar5;
  undefined4 uStack_50;
  undefined **ppuStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined ***pppuStack_24;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2957;
  pvStack_10 = ExceptionList;
  if (DAT_01d5aa48 == '\0') {
    if (*(char *)(param_1 + 0xf5c) == '\0') {
      return;
    }
    if (param_1[0xf16] == 0) {
      return;
    }
  }
  else {
    if (*(char *)(param_1 + 0xf5c) == '\0') {
      return;
    }
    if (param_1[0xf03] == 0) {
      return;
    }
  }
  ExceptionList = &pvStack_10;
  FUN_006ab380(*(undefined4 *)(param_2 + 0x38),*(undefined4 *)(param_2 + 0x30),0);
  iStack_8 = 0;
  FUN_006ab660(1);
  FUN_006ace60();
  lVar4 = FUN_006ace60();
  if ((0xffffffff < lVar4) || (-1 < lVar4)) goto LAB_00665bac;
  FUN_006ab6a0(uStack_50,0);
  piStack_14 = (int *)((uint)((ulonglong)lVar4 >> 0x20) & 0x7fffffff);
  uStack_18 = (int)lVar4;
  FUN_006a5c10(&uStack_18,auStack_20,8);
  FUN_006ad5e0(auStack_20,8);
  FUN_00668de0(4);
  if (DAT_01d5aa40 == '\0') {
LAB_0066593b:
    iVar2 = FUN_01674e20(0x38);
    iStack_8._0_1_ = 1;
    if (iVar2 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_0151f6f0(0xffffffff,0,0);
    }
    iStack_8._0_1_ = 0;
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    FUN_0064daf0(uVar3,iVar2);
    iStack_8._0_1_ = 2;
    uVar3 = FUN_005958a0(auStack_38,4);
    iStack_8._0_1_ = 3;
    FUN_0151f950("fileDetectMethod",uVar3);
    iStack_8._0_1_ = 2;
    FUN_005507b0();
    FUN_0151f850("fileLoadType",&DAT_018d4b70);
    FUN_0151f850("filePath",&DAT_018bc9b8);
    FUN_0151f850("fileCompany",&DAT_018bc9b8);
    FUN_0151f850("fileProduct",&DAT_018bc9b8);
    FUN_0151f850("fileAttrsRules","suspicious_path");
    FUN_0151f850("fileFlags","hpOL--M-RU---------------------5 (66383)");
    FUN_0151f850("fileMemSize",&DAT_018d0474);
    FUN_0151f850("fileMemRegions",&DAT_018c3554);
    FUN_0151f850("filePeHash","a2ed248b871fe53f9f0043941fae2e20cadde35e");
    FUN_0151f850("fileStrHash","a2ed248b871fe53f9f0043941fae2e20cadde35e");
    FUN_0151f850("fileStrHitRules",
                 "m-hpe;m-pe;m-trecent;p-vmp;f-pck;f-rbx;f-lua;e-synapse;eval_exploit");
    uVar3 = 9;
    pcVar5 = "CsrModule";
    uStack_28 = 0;
    pppuStack_24 = (undefined ***)&DAT_0000000f;
    auStack_38[0] = 0;
    FUN_005542c0("CsrModule",9);
    iStack_8._0_1_ = 4;
    FUN_00557fc0(&uStack_18);
    FUN_0066d2f0(auStack_38,0,0,0,0,pcVar5,uVar3);
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00550b30();
  }
  else if (*(char *)(param_1 + 0xfdc) == '\0') {
    *(undefined *)(param_1 + 0xfdc) = 1;
    goto LAB_0066593b;
  }
  if (DAT_01d5aa48 == '\0') {
    (**(code **)(*param_1 + 0x290))(&DAT_018d4b68,0x1b,DAT_01d5aa38 != '\0',"Exploit Detected",0);
    pcVar5 = "ExploitsDetection-Respond-Disconnect";
    if (DAT_01d5aa38 == '\0') {
      pcVar5 = "ExploitsDetection-Respond-ReportOnly";
    }
    FUN_0054eff0(pcVar5);
    iStack_8 = CONCAT31(iStack_8._1_3_,7);
    FUN_008783f0(auStack_38,1,0);
    FUN_005507b0();
  }
  else {
    uVar3 = FUN_0060dcd0(auStack_20,param_1);
    FUN_005587b0(uVar3);
    FUN_00550b30();
    piVar1 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    uStack_44 = uStack_18;
    pppuStack_24 = &ppuStack_48;
    ppuStack_48 = std::
                  _Func_impl_no_alloc<class_<lambda_9c20dbf068eda0ddbac7172c77152787>,void,enum_RBX::Player::CanManageStatus>
                  ::vftable;
    piStack_40 = piStack_14;
    iStack_8 = CONCAT31(iStack_8._1_3_,6);
    FUN_0091e690(pppuStack_24);
    if (pppuStack_24 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_24)[4])(pppuStack_24 != &ppuStack_48);
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
LAB_00665bac:
  FUN_00613200();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7662 ; VA 0x00665bd0 ; FUN_00665bd0 */

void __fastcall FUN_00665bd0(int param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 auStack_20 [3];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a298e;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x3dd0);
  if (iVar4 == 0) {
    return;
  }
  uVar2 = *(uint *)(param_1 + 0x3f40);
  if (3 < uVar2) {
    return;
  }
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x3f49) == '\0') {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00718400();
    if ((cVar1 == '\0') || (cVar1 = FUN_007181f0(param_1), cVar1 == '\0')) goto LAB_00665c9b;
    FUN_007184e0();
    uVar2 = *(uint *)(param_1 + 0x3f40);
    iVar4 = *(int *)(param_1 + 0x3dd0);
  }
  *(uint *)(param_1 + 0x3f40) = uVar2 + 1;
  uVar3 = FUN_00bc4040(*(undefined4 *)(iVar4 + 0x9c));
  iStack_14 = FUN_01674e20(0x38);
  uStack_8 = 0;
  if (iStack_14 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_0071a260(param_1,0,uVar3);
  }
  uStack_8 = 0xffffffff;
  FUN_006b1f50(uVar3);
  *(undefined *)(param_1 + 0x3f49) = 1;
LAB_00665c9b:
  if ((((DAT_01d5ac40 == '\0') && (DAT_01d5ab28 != '\0')) && (*(char *)(param_1 + 0x3f4a) == '\0'))
     && (cVar1 = FUN_00718330(), cVar1 != '\0')) {
    FUN_00717e80(auStack_20);
    uVar3 = FUN_00bc4040(auStack_20[0]);
    iStack_14 = FUN_01674e20(0x38);
    uStack_8 = 1;
    if (iStack_14 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_0071a260(param_1,1,uVar3);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar3);
    *(undefined *)(param_1 + 0x3f4a) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7663 ; VA 0x00665d30 ; FUN_00665d30 */

void __fastcall FUN_00665d30(int *param_1)

{
  (**(code **)(*param_1 + 0x290))("Guardian",0x1a,2,"QueueLimit",0);
  return;
}



/* FUNCTION 7664 ; VA 0x00665d50 ; FUN_00665d50 */

void __thiscall FUN_00665d50(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x3dd0) != 0) {
    FUN_00716dc0(*(int *)(param_2 + 4),*(int *)(param_2 + 8) - *(int *)(param_2 + 4) >> 2,1);
    FUN_00664c70();
  }
  return;
}



/* FUNCTION 7665 ; VA 0x00665d90 ; FUN_00665d90 */

/* WARNING: Removing unreachable block (ram,0x00665f32) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00665d90(int param_1,int *param_2)

{
  double dVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  short sVar5;
  undefined4 uVar6;
  int iVar7;
  undefined8 *puVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  undefined8 in_XMM0_Qa;
  double dVar16;
  double dVar17;
  int aiStack_74 [5];
  uint uStack_60;
  int iStack_5c;
  uint uStack_58;
  int aiStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a29b0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x37ff) == '\0') {
    ExceptionList = &pvStack_10;
    *(char *)(param_1 + 0x3de4) = *(char *)(param_1 + 0x3de4) + '\x01';
    *(undefined *)(param_1 + 0x3de3) = 0;
    *(undefined *)(param_1 + 0x3de1) = 0;
    iStack_18 = param_1;
    FUN_016f3fe0();
    *(undefined8 *)(param_1 + 0x3ed8) = in_XMM0_Qa;
    uVar6 = FUN_006a6900();
    *(int *)(param_1 + 0x3e8c) = *(int *)(param_1 + 0x3e8c) + 1;
    *(undefined4 *)(param_1 + 0x1080) = uVar6;
    *(undefined4 *)(param_1 + 0x1084) = 0;
    if (DAT_01d5a060 != '\0') {
      iVar7 = FUN_006a6900();
      iVar7 = (int)(((double)iVar7 + (double)(&DAT_018c0d90)[-(iVar7 >> 0x1f)]) -
                   *(double *)(param_1 + 0x3ed8));
      uStack_44 = (double)iVar7;
      uStack_3c = uStack_44;
      sVar5 = FUN_017265ed(&uStack_3c);
      dVar16 = DAT_018c0d60;
      if (sVar5 < 1) {
        dVar1 = *(double *)(param_1 + 0x10c0);
        dVar17 = uStack_44;
        if (*(char *)(param_1 + 0x10e0) == '\0') {
          dVar17 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0x10d0) + dVar1 * uStack_44;
        }
        *(double *)(param_1 + 0x10d0) = dVar17;
        *(int *)(param_1 + 0x10c8) = iVar7;
        *(undefined *)(param_1 + 0x10e0) = 0;
        *(double *)(param_1 + 0x10d8) =
             (dVar16 - dVar1) * *(double *)(param_1 + 0x10d8) +
             dVar1 * (uStack_44 - dVar17) * (uStack_44 - dVar17);
      }
      if (*(int *)(param_1 + 0x10e8) < iVar7) {
        *(int *)(param_1 + 0x10e8) = iVar7;
      }
      if (iVar7 < *(int *)(param_1 + 0x10ec)) {
        *(int *)(param_1 + 0x10ec) = iVar7;
      }
    }
    dVar16 = *(double *)(param_1 + 0x3ea8);
    if ((NAN(dVar16) || NAN(DAT_018ce330)) != (dVar16 == DAT_018ce330)) {
      FUN_016f3fe0();
      *(double *)(param_1 + 0x3ea8) = dVar16;
    }
    iVar7 = iStack_18;
    puVar2 = (undefined4 *)cpuid_Version_info(1);
    uStack_4c = *puVar2;
    uStack_48 = puVar2[1];
    uStack_44._0_4_ = puVar2[3];
    if (((uint)uStack_44 >> 0x17 & 1) != 0) {
      uVar12 = param_2[4];
      uVar10 = (uVar12 & 0xc124cfe9) - ((uVar12 & 0xc124cfe9) >> 1 & 0x55555555);
      uStack_44._4_4_ = (uVar10 >> 2 & 0x33333333) + (uVar10 & 0x33333333);
      uVar10 = (uVar12 & 0xc45979eb) - ((uVar12 & 0xc45979eb) >> 1 & 0x55555555);
      uVar10 = (uVar10 >> 2 & 0x33333333) + (uVar10 & 0x33333333);
      uStack_3c = (double)CONCAT44(uVar10,(undefined4)uStack_3c);
      uVar11 = (uVar12 & 0x2b99050c) - ((uVar12 & 0x2b99050c) >> 1 & 0x55555555);
      uStack_34 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0xd203172e) - ((uVar12 & 0xd203172e) >> 1 & 0x55555555);
      uStack_30 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0x11777d3e) - ((uVar12 & 0x11777d3e) >> 1 & 0x55555555);
      uStack_2c = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0x73531d65) - ((uVar12 & 0x73531d65) >> 1 & 0x55555555);
      uStack_28 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0x18df419e) - ((uVar12 & 0x18df419e) >> 1 & 0x55555555);
      uStack_24 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0x848d2984) - ((uVar12 & 0x848d2984) >> 1 & 0x55555555);
      uStack_20 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0xa73452e1) - ((uVar12 & 0xa73452e1) >> 1 & 0x55555555);
      uVar15 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0xa295c49f) - ((uVar12 & 0xa295c49f) >> 1 & 0x55555555);
      uVar14 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar11 = (uVar12 & 0xdc401163) - ((uVar12 & 0xdc401163) >> 1 & 0x55555555);
      uVar13 = (uVar11 >> 2 & 0x33333333) + (uVar11 & 0x33333333);
      uVar12 = (uVar12 & 0xfcee5d30) - ((uVar12 & 0xfcee5d30) >> 1 & 0x55555555);
      uVar11 = (uVar12 >> 2 & 0x33333333) + (uVar12 & 0x33333333);
      uVar12 = *(uint *)(iStack_18 + 0x3dc0);
      uStack_14 = (((((((((((((uVar11 >> 4) + uVar11 & 0xff0f0f0f) * -0xfefeff >> 1 & 0x800000 |
                            ((uVar13 >> 4) + uVar13 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                           ((uVar14 >> 4) + uVar14 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                          ((uVar15 >> 4) + uVar15 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                         ((uStack_20 >> 4) + uStack_20 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                        ((uStack_24 >> 4) + uStack_24 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                       ((uStack_28 >> 4) + uStack_28 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                      ((uStack_2c >> 4) + uStack_2c & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                     ((uStack_30 >> 4) + uStack_30 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 5 |
                    ((uStack_34 >> 4) + uStack_34 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                   ((uVar10 >> 4) + uVar10 & 0xff0f0f0f) * -0xfefeff & 0x1000000) >> 1 |
                  ((uStack_44._4_4_ >> 4) + uStack_44._4_4_ & 0xff0f0f0f) * -0xfefeff & 0x1000000)
                  >> 9 & ~uVar12;
      uStack_1c = uVar12;
      if (uStack_14 != 0) {
        iStack_5c = iStack_18;
        uStack_58 = uStack_14;
        FUN_0054ef60(&DAT_01d5aa80);
        uStack_8 = 0;
        FUN_0065a730(uStack_58,0x8000,&DAT_018d372c,"mcc VpCalled, 15","MccVpCalled",0x13,0,
                     aiStack_54);
        FUN_0065a730(uStack_58,0x4000,&DAT_018d372c,"mcc FakeFFlag, 14","MccFakeFFlag",0x13,0,
                     aiStack_54);
        FUN_0065a730(uStack_58,0x2000,&DAT_018d372c,"mcc FreeConsole, 13","MccFreeConsole",0xb,0,
                     aiStack_54);
        FUN_0065a730(uStack_58,0x20,&DAT_018d372c,"mcc VehUnhook, 5","MccVehUnhook",0x13,0,
                     aiStack_54);
        FUN_0065a730(uStack_58,0x10,&DAT_018d372c,"mcc GtxHook, 4","MccGtxHook",0x13,0,aiStack_54);
        FUN_0065a730(uStack_58,8,&DAT_018d372c,"mcc HwbpSet, 3","MccHwbp",0x12,0,aiStack_54);
        FUN_0065a730(uStack_58,4,&DAT_018d372c,"mcc BadRdataSection, 2","MccBadRdata",0x13,0,
                     aiStack_54);
        FUN_0065a730(uStack_58,2,&DAT_018d372c,"mcc BadVmpSection, 1","MccBadVmp",0x13,0,aiStack_54)
        ;
        FUN_0065a730(uStack_58,1,&DAT_018d372c,"mcc BadTextSection, 0","MccBadText",0x13,0,
                     aiStack_54);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_44._4_4_) {
          uVar12 = uStack_44._4_4_ + 1;
          iVar9 = aiStack_54[0];
          if (0xfff < uVar12) {
            iVar9 = *(int *)(aiStack_54[0] + -4);
            uVar12 = uStack_44._4_4_ + 0x24;
            if (0x1f < (aiStack_54[0] - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar9,uVar12);
        }
        uVar12 = *(uint *)(iVar7 + 0x3dc0);
      }
      *(uint *)(iVar7 + 0x3dc0) = uVar12 | uStack_14;
      puVar8 = (undefined8 *)FUN_016830f0(&uStack_3c);
      uStack_44 = (double)*puVar8;
      if ((NAN(*(double *)(iVar7 + 0x3ea8)) || NAN(_PTR_018c6f48)) !=
          (*(double *)(iVar7 + 0x3ea8) == _PTR_018c6f48)) {
        *(double *)(iVar7 + 0x3ea8) = uStack_44;
        *(double *)(iVar7 + 0x3ec8) = uStack_44;
        iVar9 = param_2[1];
        iVar3 = param_2[2];
        iVar4 = param_2[3];
        *(int *)(iVar7 + 0x3e94) = *param_2;
        *(int *)(iVar7 + 0x3e98) = iVar9;
        *(int *)(iVar7 + 0x3e9c) = iVar3;
        *(int *)(iVar7 + 0x3ea0) = iVar4;
        *(int *)(iVar7 + 0x3ea4) = param_2[4];
        iVar9 = param_2[1];
        iVar3 = param_2[2];
        iVar4 = param_2[3];
        *(int *)(iVar7 + 0x3eb0) = *param_2;
        *(int *)(iVar7 + 0x3eb4) = iVar9;
        *(int *)(iVar7 + 0x3eb8) = iVar3;
        *(int *)(iVar7 + 0x3ebc) = iVar4;
        *(int *)(iVar7 + 0x3ec0) = param_2[4];
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0054ef60(&DAT_01d5aa80);
      uStack_8 = 1;
      if (0x13 < (param_2[3] - *(int *)(iVar7 + 0x3ebc)) + 10U) {
        FUN_0065a730(0xffffffff,0x200,&DAT_018d372c,"mcc too long between badApp, 9","TimeoutBadApp"
                     ,10,0,aiStack_74);
      }
      if (0x13 < (*param_2 - *(int *)(iVar7 + 0x3eb0)) + 10U) {
        FUN_0065a730(0xffffffff,0x400,&DAT_018d372c,"mcc too long between memcheckRun, 10",
                     "TimeoutPmcMcc",10,0,aiStack_74);
      }
      if (0x13 < (param_2[2] - *(int *)(iVar7 + 0x3eb8)) + 10U) {
        FUN_0065a730(0xffffffff,0x800,&DAT_018d372c,"mcc too long between mcc run, 11","TimeoutMcc",
                     10,0,aiStack_74);
      }
      iVar9 = FUN_016f3eb1();
      if (0x13 < ((iVar9 + *(int *)(iVar7 + 0x3e94)) - *param_2) + 10U) {
        FUN_0065a730(0xffffffff,0x1000,&DAT_018d372c,"mcc time moving too fast, 12","TimeoutSpeed",
                     10,0,aiStack_74);
      }
      *(double *)(iVar7 + 0x3ec8) = uStack_44;
      iVar9 = param_2[1];
      iVar3 = param_2[2];
      iVar4 = param_2[3];
      *(int *)(iVar7 + 0x3eb0) = *param_2;
      *(int *)(iVar7 + 0x3eb4) = iVar9;
      *(int *)(iVar7 + 0x3eb8) = iVar3;
      *(int *)(iVar7 + 0x3ebc) = iVar4;
      *(int *)(iVar7 + 0x3ec0) = param_2[4];
      if (0xf < uStack_60) {
        uVar12 = uStack_60 + 1;
        iVar7 = aiStack_74[0];
        if (0xfff < uVar12) {
          iVar7 = *(int *)(aiStack_74[0] + -4);
          uVar12 = uStack_60 + 0x24;
          if (0x1f < (aiStack_74[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar12);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7666 ; VA 0x00666660 ; FUN_00666660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00666660(int *param_1,uint param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  float10 fVar3;
  
  uVar2 = ~param_1[0xf6d] & param_2;
  if (uVar2 != 0) {
    FUN_0065a730(uVar2,0x80000000,"impala","Impossible Error (31)","ImpossibleError",0xb,0,
                 &DAT_01d5a848);
    if (-1 < (int)uVar2) {
      FUN_0065a730(uVar2,0x40000000,"robert","New Return Checks (30)","NewReturnChecks",0x15,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x20000000,"moded_hype","Humanoid State Call Chain (29)","HsceCallChain",
                   0x10,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x10000000,"booing","Tried to modify hash function (28)","PmcModified",0x14
                   ,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x8000000,"bobby","Function Return Check Failed (27)","ReturnCheckFail",
                   0x15,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x4000000,&DAT_018d40d8,"Tried to get build tools (26)","BuildTools",0xf,0,
                   &DAT_01d5a848);
      FUN_0065a530(uVar2,0x2000000,"vegah","VEH used (25)",&DAT_018d40e0,0x13,0);
      FUN_0065a730(uVar2,0x1000000,"fisher","HumanoidState::computeEvent changed (24)","HsceChanged"
                   ,0x10,0,&DAT_01d5a848);
      FUN_0065a530(uVar2,0x800000,"dallas","DLL Injection (23)",&DAT_018d413c,0xf,0);
      FUN_0065a730(uVar2,0x400000,&DAT_018d417c,"Sandbox or VM detected (22)",&DAT_018d415c,0x12,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x200000,"usain","Speedhack. (21)","Speedhack",0xf,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x100000,"carol","Lua vm hooked (20)","LuaVmHooked",0x16,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x80000,"steven","OSX hash changed (19)","OsxHash",0x14,0,&DAT_01d5a848);
      FUN_0065a530(uVar2,0x40000,"larry","Our VEH hook removed (18)","VehRemoved",0x13,0);
      FUN_0065a730(uVar2,0x20000,&DAT_018d4240,"Any New CE Method (17)","CheatEngine",0x11,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x10000,&DAT_018d427c," HumanoidState::computeEvent changed ebx (16)",
                   "HsceEbx",0x10,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x8000,"terrance","Early null weak pointer (15)","DmPointerBroken",0x16,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x4000,"ursula","Lua hash changed (14)","LuaHashChanged",0x16,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x2000,"bruger","Speculative Call Check (13)","SpeculativeCall",0x15,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x1000,&DAT_018d433c,"SEH chain into dll (12)",&DAT_018d4320,0x15,0,
                   &DAT_01d5a848);
      FUN_0065a530(uVar2,0x800,"curly","Hooked API function (11)","HookedApi",0xf,0);
      FUN_0065a730(uVar2,0x400,"olivia","Debugger found (10)","Debugger",0x12,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x200,"norman","Lua script hash changed (9)","ScriptHashChanged",0x16,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x100,"mallory","Catch executable acccess violation (8)","AvCheck",0x13,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x80,"lance","Const Changed (7)","ConstChanged",0x17,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x40,&DAT_018d4454,"Invalid bytecode (6)","InvalidBytecode",0x16,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,0x20,"imogen","Memory hash changed (5)","OldPmc",0x14,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,0x10,&DAT_018d44a8,"Illegal scripts (4)","IllegalScripts",0x16,0,
                   &DAT_01d5a848);
      FUN_0065a730(uVar2,8,&DAT_018d44d8,"Bad signature (3)","BadFileSignature",0xf,0,&DAT_01d5a848)
      ;
      FUN_0065a530(uVar2,4,&DAT_018d44fc,"detected HWBP (2)",&DAT_018d44e0,0x12,0);
      FUN_0065a730(uVar2,2,"lafayette","xxhash broken (1)","XxhashBroken",0xf,0,&DAT_01d5a848);
      FUN_0065a730(uVar2,1,"murdle","Cheat Engine Stable Methods (0)","CheatEngineOld",0x11,0,
                   &DAT_01d5a848);
    }
    param_1[0xf6d] = param_1[0xf6d] | param_2;
  }
  uVar2 = ~param_1[0xf6e] & param_3;
  if (uVar2 != 0) {
    FUN_0065a730(uVar2,0xfff00000,"impala","Scorn Impossible Error (31:20)","ImpossibleError",0xb,0,
                 &DAT_01d5aa98);
    if ((uVar2 & 0xfff00000) == 0) {
      FUN_0065a730(uVar2,0xff000,"louka","Scorn Size (19:12)","SizeError",0xc,0,&DAT_01d5aa98);
      FUN_0065a730(uVar2,0xfff,"tochigi","Scorn Replication (11:0)","ReplicationCall",8,0,
                   &DAT_01d5aa98);
    }
    param_1[0xf6e] = param_1[0xf6e] | param_3;
  }
  if (_PTR_018c6f48 < *(double *)(param_1 + 0xf86)) {
    fVar3 = (float10)FUN_01683110();
    if (*(double *)(param_1 + 0xf86) <= (double)fVar3 &&
        (double)fVar3 != *(double *)(param_1 + 0xf86)) {
      piVar1 = param_1 + 0xf88;
      if (0xf < (uint)param_1[0xf8d]) {
        piVar1 = (int *)*piVar1;
      }
      (**(code **)(*param_1 + 0x290))(piVar1,0,1,"AlreadyReported",0);
    }
  }
  return;
}



/* FUNCTION 7667 ; VA 0x00666bf0 ; FUN_00666bf0 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00666bf0(int *param_1,int *param_2)

{
  char cVar1;
  byte bVar2;
  undefined uVar3;
  int iVar4;
  undefined4 *******pppppppuVar5;
  int iVar6;
  undefined4 *******pppppppuVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  byte *pbVar11;
  char *******pppppppcVar12;
  char *******pppppppcVar13;
  byte *pbVar14;
  uint uVar15;
  uint uVar16;
  code *pcVar17;
  bool bVar18;
  undefined8 uVar19;
  undefined4 in_stack_fffffe38;
  undefined2 uVar21;
  undefined4 uVar20;
  undefined4 in_stack_fffffe3c;
  undefined4 in_stack_fffffe40;
  undefined4 in_stack_fffffe44;
  undefined4 uVar22;
  char *pcVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  undefined4 uVar26;
  undefined4 uVar27;
  undefined *puVar28;
  undefined auStack_18c [16];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined auStack_174 [16];
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined auStack_15c [40];
  undefined auStack_134 [16];
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined auStack_10c [16];
  undefined auStack_fc [24];
  uint auStack_e4 [4];
  undefined4 uStack_d4;
  uint uStack_d0;
  undefined4 *******apppppppuStack_cc [4];
  uint uStack_bc;
  uint uStack_b8;
  int *piStack_b4;
  uint auStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  uint auStack_98 [4];
  undefined4 uStack_88;
  uint uStack_84;
  undefined4 *******apppppppuStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  uint auStack_68 [2];
  char cStack_60;
  char cStack_5f;
  char cStack_5e;
  char cStack_5d;
  char cStack_5c;
  char cStack_5b;
  char cStack_5a;
  char cStack_59;
  undefined8 uStack_58;
  int iStack_50;
  int iStack_4c;
  uint uStack_48;
  int iStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  char *******apppppppcStack_38 [4];
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  undefined4 *******pppppppuStack_1c;
  char acStack_16 [2];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar21 = (undefined2)((uint)in_stack_fffffe38 >> 0x10);
  puStack_c = &LAB_017a2b42;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe64;
  uStack_48 = 0;
  uStack_d4 = 0;
  uStack_d0 = 0xf;
  auStack_e4[0] = auStack_e4[0] & 0xffffff00;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  auStack_b0[0] = auStack_b0[0] & 0xffffff00;
  uStack_88 = 0;
  uStack_84 = 0xf;
  auStack_98[0] = auStack_98[0] & 0xffffff00;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  piStack_b4 = param_1;
  puVar28 = &stack0xfffffe64;
  if (DAT_01ee420a != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee420a,"ServerReplicator:processTicket",0);
    puVar28 = puStack_14;
  }
  puStack_14 = puVar28;
  if (param_1[0xf61] != 0) {
    (**(code **)(*param_1 + 0x294))(0x109,"DuplicateTicket",4,2,0);
    if (0xf < uStack_84) {
      uVar15 = uStack_84 + 1;
      uVar16 = auStack_98[0];
      if (0xfff < uVar15) {
        uVar16 = *(uint *)(auStack_98[0] - 4);
        uVar15 = uStack_84 + 0x24;
        if (0x1f < (auStack_98[0] - uVar16) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar16,uVar15);
    }
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = auStack_98[0] & 0xffffff00;
    if (0xf < uStack_9c) {
      uVar15 = uStack_9c + 1;
      uVar16 = auStack_b0[0];
      if (0xfff < uVar15) {
        uVar16 = *(uint *)(auStack_b0[0] - 4);
        uVar15 = uStack_9c + 0x24;
        if (0x1f < (auStack_b0[0] - uVar16) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar16,uVar15);
    }
    uStack_a0 = 0;
    uStack_9c = 0xf;
    auStack_b0[0] = auStack_b0[0] & 0xffffff00;
    if (uStack_d0 < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    uVar15 = uStack_d0 + 1;
    uVar16 = auStack_e4[0];
    if (0xfff < uVar15) {
      uVar16 = *(uint *)(auStack_e4[0] - 4);
      uVar15 = uStack_d0 + 0x24;
      if (0x1f < (auStack_e4[0] - uVar16) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar16,uVar15);
    ExceptionList = pvStack_10;
    return;
  }
  FUN_006ab380(*(undefined4 *)((int)param_2 + 0x38),*(undefined4 *)((int)param_2 + 0x30),0);
  uStack_8._0_1_ = 4;
  FUN_006ab660(1);
  iVar4 = FUN_008f7870(param_1);
  iVar4 = **(int **)(iVar4 + 0x43c) - (int)*(int **)(iVar4 + 0x43c);
  pppppppuVar7 = apppppppuStack_cc;
  pcVar23 = "%d%d%d%d";
  uVar22 = 0x666e14;
  FUN_01675640(pppppppuVar7,"%d%d%d%d",iVar4,param_1[0xfbd],param_1[0xfbb],param_1[0xfbc]);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (uStack_bc < 0x10) {
    FUN_00578160(0x10 - uStack_bc,0);
  }
  else {
    uStack_bc = 0x10;
    pppppppuVar5 = apppppppuStack_cc;
    if (0xf < uStack_b8) {
      pppppppuVar5 = apppppppuStack_cc[0];
    }
    *(undefined *)(pppppppuVar5 + 4) = 0;
  }
  pppppppuVar5 = apppppppuStack_cc;
  if (0xf < uStack_b8) {
    pppppppuVar5 = apppppppuStack_cc[0];
  }
  FUN_006c4a30(auStack_15c,pppppppuVar5);
  FUN_006ab860(&iStack_50,auStack_15c);
  FUN_006ab8e0(param_1 + 0xf5d,auStack_15c);
  FUN_006ab8e0(auStack_98,auStack_15c);
  iVar6 = FUN_006ac4d0();
  param_1[0xeee] = iVar6;
  *(undefined *)(param_1 + 0xf02) = 1;
  if (DAT_01ee420a != '\0') {
    iVar4 = 0x666ef3;
    FUN_016774b0(DAT_01ee420a,"ServerReplicator:processTicket - remoteProtocolVersion = %i",iVar6);
  }
  cVar1 = FUN_00646740(param_1[0xeee]);
  if (cVar1 == '\0') {
    *(undefined *)(param_1 + 0xf5c) = 0;
    FUN_006ab530();
    puVar10 = &param_2;
    uStack_8._0_1_ = 6;
    param_2 = (int *)CONCAT31(param_2._1_3_,0x8e);
    uVar25 = 0x666f39;
    FUN_006ad5e0(puVar10,1);
    uVar27 = 0;
    FUN_005f70a0();
    FUN_005f7140();
    uVar20 = CONCAT22(uVar21,DAT_01d5a828);
    uVar24 = DAT_01d5a820;
    uVar26 = DAT_01d5a824;
    FUN_005f7170(param_1 + 0x1d);
    FUN_00681340(auStack_10c,0,3,0,uVar24,uVar26,uVar20,in_stack_fffffe3c,in_stack_fffffe40,
                 in_stack_fffffe44,uVar22,pppppppuVar7,pcVar23,iVar4,uVar25,puVar10,uVar27);
    (**(code **)(*param_1 + 0x294))(0x102,"SecurityKey",2,2,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_00613200();
  }
  FUN_006ab8e0(auStack_e4,auStack_15c);
  uStack_124 = 0;
  uStack_120 = 0xf;
  auStack_134[0] = 0;
  uStack_17c = 0;
  uStack_178 = 0xf;
  auStack_18c[0] = 0;
  uStack_8._0_1_ = 8;
  uStack_70 = 0;
  uStack_6c = 0xf;
  apppppppuStack_80[0] = (undefined4 *******)((uint)apppppppuStack_80[0] & 0xffffff00);
  FUN_005542c0("valid",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar4 = FUN_005f0c40(auStack_e4,auStack_b0,param_1 + 0xfbd,param_1 + 0xfbc,param_1 + 0xfbb,
                       param_1 + 0xfbe,(int)param_1 + 0x3c2b,(int)param_1 + 0x3d72,param_1 + 0xfc3,
                       param_1 + 0xfbf,param_1 + 0xfc0);
  param_2 = (int *)0x0;
  if (iVar4 == 2) {
    if ((DAT_01d5a9d0 != '\0') || (DAT_01d5a9d8 != '\0')) {
      FUN_0087c450(&DAT_018c5f98,"SecurityException","New Join Missing",0,0,0);
      (**(code **)(*param_1 + 0x294))(0x110,"SecurityKey",1,DAT_01d5a9d8 != '\0',0,0);
      cVar1 = DAT_01d5a9d8;
LAB_006670ef:
      if ((cVar1 == '\0') || (DAT_01d5ac48 != '\0')) {
        uVar22 = 9;
        pcVar23 = "notKicked";
      }
      else {
        uVar22 = 6;
        *(undefined *)(param_1 + 0xf5c) = 0;
        pcVar23 = "kicked";
      }
      FUN_005542c0(pcVar23,uVar22);
    }
  }
  else if (((iVar4 == 1) ||
           ((iVar4 == 0 && (param_2 = (int *)FUN_006594c0(), param_2 != (int *)0x0)))) &&
          ((DAT_01d5a9c0 != '\0' || (DAT_01d5a9c8 != '\0')))) {
    if (iVar4 == 1) {
      FUN_0087c450(&DAT_018c5f98,"SecurityException","New Join Tamper",0,0,0);
    }
    else {
      if ((DAT_01d5a9c0 == '\0') && (DAT_01d5a9c8 == '\0')) goto LAB_006672d8;
      if (iVar4 == 0) {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 10;
        FUN_0151fa60("versionKey",param_1[0xfbd]);
        FUN_0151fa60("expectedKey",DAT_018c8aac);
        uVar22 = FUN_005f2c00(param_1[0xfbb]);
        FUN_0151f850("platform",uVar22);
        uVar22 = FUN_005f2ca0(param_1[0xfbc]);
        FUN_0151f850("product",uVar22);
        uVar22 = DAT_01d5a75c;
        uStack_58 = 3.18299368644791e-313;
        auStack_68[0] = auStack_68[0] & 0xffffff00;
        FUN_005542c0("NewJoinDebug",0xc);
        uStack_8._0_1_ = 0xb;
        FUN_01520d20(auStack_68,uVar22,0);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
        FUN_0087c450(&DAT_018c5f98,"SecurityException","New Join Not Good Enough",0,0,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        FUN_0151f7f0();
      }
    }
    if ((DAT_01d5a9c0 != '\0') || (DAT_01d5a9c8 != '\0')) {
      (**(code **)(*param_1 + 0x294))
                ((uint)(param_2 == (int *)0x1) * 8 + 0x110,"SecurityKey",1,DAT_01d5a9c8 != '\0',0,0)
      ;
      cVar1 = DAT_01d5a9c8;
      goto LAB_006670ef;
    }
  }
LAB_006672d8:
  iVar4 = FUN_01679ce0();
  param_1[0xfc1] = iVar4;
  param_2 = (int *)FUN_01674e20(0x38);
  uStack_8._0_1_ = 0xc;
  if (param_2 == (int *)0x0) {
    uVar22 = 0;
  }
  else {
    uVar22 = FUN_0071a190(param_1,param_1[0xfc1]);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_006b1f50(uVar22);
  FUN_006ab8e0(auStack_134,auStack_15c);
  FUN_006ab8e0(auStack_18c,auStack_15c);
  cVar1 = (**(code **)(*param_1 + 0x124))();
  pbVar11 = (byte *)((int)param_1 + 0x3d72);
  if ((cVar1 == '\0') && ((*pbVar11 & 1) != 0)) {
    FUN_006ab8e0(param_1 + 0xf8e,auStack_15c);
  }
  if (DAT_01d5ac50 != '\0') {
    if (param_1[0xf92] == 0) {
      uVar22 = FUN_005f2c00(param_1[0xfbb]);
      FUN_01675640(apppppppcStack_38,"AntiBot-FastFix-%s",uVar22);
      uStack_8._0_1_ = 0xd;
      uStack_58 = 3.18299368644791e-313;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      FUN_005542c0("AntiBot-FastFix",0xf);
      uStack_8._0_1_ = 0xe;
      FUN_008783f0(auStack_68,1,0);
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      FUN_005507b0();
    }
    if (((DAT_01d5ac50 != '\0') && (DAT_01d5ac58 != '\0')) && (param_1[0xf92] == 0)) {
      (**(code **)(*param_1 + 0x294))(0x104,"FastFix",5,1 < DAT_01ead7d4,0,0);
    }
  }
  iStack_44 = 0;
  param_2 = (int *)((uint)param_2 & 0xffffff);
  cVar1 = (**(code **)(*param_1 + 0x124))();
  if ((cVar1 == '\0') && ((*pbVar11 & 2) != 0)) {
    FUN_006abc60(&iStack_44,auStack_15c);
    piVar9 = param_1 + 0xf5d;
    if (0xf < (uint)param_1[0xf62]) {
      piVar9 = (int *)*piVar9;
    }
    piStack_3c = (int *)FUN_014ebd40(piVar9,param_1[0xf61],1);
    if ((0 < DAT_01ead7d4) &&
       (iVar4 = FUN_005f2d60(piStack_3c,param_1[0xfbb],param_1[0xfbc],param_1[0xfbd]),
       iStack_44 != iVar4)) {
      FUN_0087c450(&DAT_018c5f98,"SecurityException","Failed Device Check",0,0,0);
      (**(code **)(*param_1 + 0x294))(0x110,"DeviceCheck",1,1 < DAT_01ead7d4,0,0);
      if ((DAT_01ead7d4 < 2) || (DAT_01d5ac48 != '\0')) {
        pppppppuVar7 = apppppppuStack_80;
        if (0xf < uStack_6c) {
          pppppppuVar7 = apppppppuStack_80[0];
        }
        cVar1 = FUN_0055c360(pppppppuVar7,uStack_70,"valid",5);
        if (cVar1 != '\0') {
          FUN_005542c0("notKicked",9);
        }
      }
      else {
        FUN_005542c0("kicked",6);
        param_2 = (int *)CONCAT13(1,param_2._0_3_);
      }
    }
  }
  else {
    piStack_3c = param_2;
  }
  if (((2 < DAT_01ead7d4) && (cVar1 = (**(code **)(*param_1 + 0x124))(), cVar1 == '\0')) &&
     ((*pbVar11 & 2) == 0)) {
    FUN_0087c450(&DAT_018c5f98,"SecurityException","Missing Device Check",0,0,0);
    (**(code **)(*param_1 + 0x294))(0x110,"DeviceCheck",1,3 < DAT_01ead7d4,0,0);
    if ((DAT_01ead7d4 < 4) || (DAT_01d5ac48 != '\0')) {
      pppppppuVar7 = apppppppuStack_80;
      if (0xf < uStack_6c) {
        pppppppuVar7 = apppppppuStack_80[0];
      }
      cVar1 = FUN_0055c360(pppppppuVar7,uStack_70,"valid",5);
      if (cVar1 != '\0') {
        FUN_005542c0("notKicked",9);
      }
    }
    else {
      FUN_005542c0("kicked",6);
      param_2 = (int *)CONCAT13(1,param_2._0_3_);
    }
  }
  if ((*pbVar11 & 8) == 0) {
    iVar4 = param_1[0xfbd] - _DAT_018c8ab0 >> 4;
  }
  else {
    iVar4 = ((uint)param_1[0xfbd] >> 1 & 0x7fff) - DAT_018c8aac;
  }
  if (iVar4 < 1) {
    pppppppuStack_1c = apppppppuStack_80;
    if (0xf < uStack_6c) {
      pppppppuStack_1c = apppppppuStack_80[0];
    }
    uVar22 = FUN_005f2c00(param_1[0xfbb]);
    FUN_01675640(apppppppcStack_38,"SecurityKeyMismatch-%s-VersionDiff-%d-%s",uVar22,iVar4,
                 pppppppuStack_1c);
    uStack_8._0_1_ = 0xf;
    pppppppcVar12 = (char *******)apppppppcStack_38;
    if (0xf < uStack_24) {
      pppppppcVar12 = apppppppcStack_38[0];
    }
    uStack_58 = 3.18299368644791e-313;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
    pppppppcVar13 = pppppppcVar12;
    do {
      cVar1 = *(char *)pppppppcVar13;
      pppppppcVar13 = (char *******)((int)pppppppcVar13 + 1);
    } while (cVar1 != '\0');
    FUN_005542c0(pppppppcVar12,(int)pppppppcVar13 - (int)((int)pppppppcVar12 + 1));
    uStack_8._0_1_ = 0x10;
    FUN_008783f0(auStack_68,1,0);
    uStack_8._0_1_ = 0xf;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_58._4_4_) {
      uVar15 = uStack_58._4_4_ + 1;
      uVar16 = auStack_68[0];
      if (0xfff < uVar15) {
        uVar16 = *(uint *)(auStack_68[0] - 4);
        uVar15 = uStack_58._4_4_ + 0x24;
        if (0x1f < (auStack_68[0] - uVar16) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar16,uVar15);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if (0xf < uStack_24) {
      uVar16 = uStack_24 + 1;
      pppppppcVar12 = apppppppcStack_38[0];
      if (0xfff < uVar16) {
        pppppppcVar12 = (char *******)apppppppcStack_38[0][-1];
        uVar16 = uStack_24 + 0x24;
        if ((char *)0x1f < (char *)((int)apppppppcStack_38[0] + (-4 - (int)pppppppcVar12))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppcVar12,uVar16);
    }
  }
  cVar1 = (**(code **)(*param_1 + 0x124))();
  if ((cVar1 == '\0') && ((*(byte *)((int)param_1 + 0x3d72) & 4) != 0)) {
    pppppppuStack_1c = (undefined4 *******)0x0;
    FUN_006abc60(&pppppppuStack_1c,auStack_15c);
    *(bool *)((int)param_1 + 0x3c31) =
         (undefined4 *******)(iStack_44 + -0xbadf00d) != pppppppuStack_1c;
  }
  uStack_164 = 0;
  uStack_160 = 0xf;
  auStack_174[0] = 0;
  uStack_8._0_1_ = 0x11;
  cVar1 = (**(code **)(*param_1 + 0x124))();
  if (cVar1 == '\0') {
    pppppppuStack_1c = (undefined4 *******)0x0;
    bVar2 = *(byte *)((int)param_1 + 0x3d72) >> 4 & 1;
    if (bVar2 != 0) {
      FUN_006ab8a0(&pppppppuStack_1c,auStack_15c);
      bVar2 = 1;
    }
    pppppppuVar7 = pppppppuStack_1c;
    if (bVar2 == 0) {
      if (2 < DAT_01ead7d8) {
        uVar16 = param_1[0xfbd];
        bVar2 = *(byte *)((int)param_1 + 0x3d72) & 8;
        uVar8 = (int)uVar16 >> 4;
        uVar15 = uVar8;
        if (bVar2 != 0) {
          uVar15 = uVar16 >> 1 & 0x7fff;
        }
        if (DAT_01d5a5b8 < (int)uVar15) {
          if (param_1[0xfbb] == -0x62b67cb5) {
            if (bVar2 != 0) {
              uVar8 = uVar16 >> 1 & 0x7fff;
            }
            if ((int)uVar8 <= DAT_01ead7dc) goto LAB_00667923;
          }
          FUN_0087c450(&DAT_018c5f98,"SecurityException","Missing Lua Challenge",0,0,0);
          pcVar17 = *(code **)(*param_1 + 0x294);
          bVar18 = 3 < DAT_01ead7d8;
          pcVar23 = "Lua Challenge";
          goto LAB_0066791a;
        }
      }
    }
    else {
      uStack_58 = 0.0;
      cVar1 = FUN_00643920(&uStack_58,iStack_44,piStack_3c);
      if (((cVar1 != '\0') && ((undefined4 *******)(int)uStack_58 != pppppppuVar7)) &&
         (0 < DAT_01ead7d8)) {
        FUN_0087c450(&DAT_018c5f98,"SecurityException","Failed Lua Challenge",0,0,0);
        pcVar17 = *(code **)(*param_1 + 0x294);
        bVar18 = 1 < DAT_01ead7d8;
        pcVar23 = "LuaChallenge";
LAB_0066791a:
        (*pcVar17)(0x110,pcVar23,1,bVar18,0,0);
      }
    }
LAB_00667923:
    if (param_2._3_1_ == '\0') {
      FUN_0065d310(param_1[0xfc1]);
    }
    if (((*(byte *)((int)param_1 + 0x3d72) & 0x20) != 0) &&
       (FUN_006ab8e0(auStack_174,auStack_15c), DAT_01ea9468 != 0)) {
      FUN_005f1cf0(auStack_174,iStack_44,piStack_3c);
    }
  }
  FUN_006ab8e0(param_1 + 0xf10,auStack_15c);
  iVar4 = FUN_006ace40();
  param_1[0xf66] = iVar4;
  uVar22 = 0x6679a7;
  iVar6 = iStack_50;
  FUN_00662560(iStack_50,iStack_4c);
  iVar4 = *param_1;
  if (*(char *)((int)param_1 + 0x3d71) == '\0') {
    cVar1 = (**(code **)(iVar4 + 0x124))();
    if (((cVar1 == '\0') && ((*(byte *)((int)param_1 + 0x3d72) & 0x20) != 0)) &&
       ((DAT_01ea9468 != 0 && (param_1[0xf16] != 0)))) {
      puVar28 = auStack_174;
      FUN_00557fc0(param_1 + 0xf16);
      FUN_00652780(uVar22,iVar6,puVar28);
    }
    if (DAT_01d5aee0 != '\0') {
      acStack_16[1] = 0;
      param_2 = (int *)((uint)param_2 & 0xffffff);
      (**(code **)(*param_1 + 0xe8))(iStack_50,iStack_4c,acStack_16 + 1,(int)&param_2 + 3);
    }
    if (param_1[0xf16] != 0) {
      if (param_1[0xf64] != 0 || param_1[0xf65] != 0) {
        uVar19 = FUN_00928340();
        if ((param_1[0xf64] != (int)uVar19) || (param_1[0xf65] != (int)((ulonglong)uVar19 >> 0x20)))
        {
          FUN_0058a2b0();
          (**(code **)(*param_1 + 0x294))(0x102,"SecurityKey",2,2,0,0);
          if (DAT_01ee420a != '\0') {
            FUN_016774b0(DAT_01ee420a,"ServerReplicator:processTicket - Security key mismatch",0);
          }
          FUN_006ab530();
          uStack_8._0_1_ = 0x12;
          param_2 = (int *)CONCAT31(param_2._1_3_,0x95);
          FUN_006ad5e0(&param_2,1);
          FUN_0060ed10(param_1 + 0x1d);
          FUN_00681340(auStack_10c,0,3,0);
          FUN_00613200();
          goto LAB_006679d7;
        }
      }
      iVar4 = param_1[0xfbb];
      if ((((iVar4 == 0x71375635) || (iVar4 == 0xc57b823)) || (iVar4 == 0x752fab0b)) ||
         (iVar4 == -0x62b67cb5)) {
        FUN_0054ef60(param_1[0xf16] + 0x1cc);
        uStack_48 = 2;
        uStack_8._0_1_ = 0x13;
        if (uStack_28 < 0x23) {
          param_2 = (int *)CONCAT31(param_2._1_3_,1);
        }
        else {
          cVar1 = FUN_009c8fa0(apppppppcStack_38);
          if (cVar1 == '\0') {
            param_2 = (int *)CONCAT31(param_2._1_3_,1);
          }
          else {
            param_2 = (int *)CONCAT31(param_2._1_3_,
                                      (char)(cStack_60 + (char)uStack_58 +
                                             cStack_5c + uStack_58._4_1_ +
                                             cStack_5e + uStack_58._2_1_ +
                                             cStack_5a + uStack_58._6_1_ +
                                            cStack_5f + uStack_58._1_1_ +
                                            cStack_5b + uStack_58._5_1_ +
                                            cStack_5d + uStack_58._3_1_ +
                                            cStack_59 + uStack_58._7_1_) != '\0');
          }
        }
        FUN_0066cb30(0x800,param_2);
        uStack_8._0_1_ = 0x11;
        FUN_005507b0();
      }
      else if (DAT_01d5ad08 != '\0') {
        FUN_0066cb30(0x800,0);
      }
      if (DAT_01d5af20 != '\0') {
        uVar22 = FUN_00927520(apppppppcStack_38);
        uStack_8._0_1_ = 0x14;
        uVar22 = FUN_0065a330(param_1 + 0xf0d,uVar22);
        FUN_0066cb30(0x2000,uVar22);
        uStack_8._0_1_ = 0x11;
        FUN_005507b0();
      }
      if (DAT_01d5aee0 == '\0') {
        cVar1 = (**(code **)(*param_1 + 0x11c))();
        if (cVar1 == '\0') {
          uVar16 = uStack_48;
          if (DAT_01d5a4c0 == '\0') {
            param_2 = (int *)param_1[0x770];
            uVar19 = FUN_00928340();
            piVar9 = (int *)FUN_0097fc00(&uStack_58,uVar19);
            uVar16 = uStack_48 | 1;
            if (*piVar9 == 0) goto LAB_00667e85;
            param_2 = (int *)CONCAT13(1,param_2._0_3_);
          }
          else {
LAB_00667e85:
            param_2 = (int *)((uint)param_2 & 0xffffff);
          }
          if ((uVar16 & 1) != 0) {
            FUN_00550b30();
          }
          if (param_2._3_1_ != '\0') {
            (**(code **)(*param_1 + 0x294))(0x108,"DuplicatePlayer",4,2,0,0);
            FUN_0058a2b0();
            goto LAB_006679d7;
          }
        }
        else {
          acStack_16[1] = 0;
          param_2 = (int *)((uint)param_2 & 0xffffff);
          pcVar17 = *(code **)(*param_1 + 0xec);
          FUN_00557fc0(param_1 + 0xf16);
          (*pcVar17)();
        }
      }
      if (((*(char *)(param_1 + 0xdfe) == '\0') && ((param_1[0xe02] & 0x100U) != 0)) &&
         (DAT_01d5a970 != 0)) {
        uStack_28 = 0;
        uStack_24 = 0xf;
        apppppppcStack_38[0] = (char *******)((uint)apppppppcStack_38[0] & 0xffffff00);
        FUN_005542c0(&DAT_018bf378,1);
        uStack_8._0_1_ = 0x15;
        uVar22 = FUN_0058c590(auStack_68,iStack_50,iStack_4c);
        uStack_8._0_1_ = 0x16;
        uVar3 = FUN_0067d600(uVar22,&DAT_01d5a960,apppppppcStack_38);
        param_2 = (int *)CONCAT13(uVar3,param_2._0_3_);
        FUN_005507b0();
        uStack_8._0_1_ = 0x11;
        FUN_005507b0();
        if (param_2._3_1_ != '\0') {
          *(undefined *)(param_1 + 0xdfe) = 1;
          iVar4 = FUN_006d9080();
          if (iVar4 == 0) {
            uVar22 = FUN_008f7870(param_1);
            FUN_006d9900(uVar22);
            FUN_006d9080();
            thunk_FUN_0071dc50();
          }
          cVar1 = FUN_0061f5a0();
          if (cVar1 == '\0') {
            param_1[0x640] = 4;
          }
          param_2 = (int *)FUN_01674e20(0x3a0);
          uStack_8._0_1_ = 0x17;
          if (param_2 == (int *)0x0) {
            uVar22 = 0;
          }
          else {
            uVar22 = FUN_006e2000(param_1);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
          iStack_20 = 0;
          pppppppuStack_1c = (undefined4 *******)0x0;
          FUN_0064db80(uVar22,param_2);
          pppppppuVar7 = pppppppuStack_1c;
          param_1[0x779] = iStack_20;
          piVar9 = (int *)param_1[0x77a];
          iStack_20 = 0;
          pppppppuStack_1c = (undefined4 *******)0x0;
          param_1[0x77a] = (int)pppppppuVar7;
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar4 = piVar9[1] + -1;
            piVar9[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar4 = piVar9[2] + -1;
              piVar9[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          FUN_00550b30();
          piVar9 = (int *)FUN_01674e20(4);
          if (piVar9 == (int *)0x0) {
            piVar9 = (int *)0x0;
          }
          else {
            *piVar9 = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
            param_2 = piVar9;
            param_2 = (int *)FUN_01674e20(0x1c);
            if (param_2 == (undefined4 *)0x0) {
              puVar10 = (undefined4 *)0x0;
            }
            else {
              *param_2 = 0;
              param_2[1] = 0;
              param_2[2] = 0;
              param_2[3] = 0x4c;
              param_2[4] = 0x20;
              param_2[5] = 0x20;
              param_2[6] = 0;
              puVar10 = param_2;
            }
            iVar4 = *piVar9;
            *piVar9 = (int)puVar10;
            if (iVar4 != 0) {
              FUN_00615040(iVar4);
            }
          }
          param_2 = (int *)param_1[0x65b];
          uStack_8._0_1_ = 0x11;
          param_1[0x65b] = (int)piVar9;
          if (param_2 != (int *)0x0) {
            if (*param_2 != 0) {
              FUN_00615040(*param_2);
            }
            FUN_01674ea0(param_2,4);
          }
        }
      }
      if (DAT_01ee420a != '\0') {
        FUN_016774b0(DAT_01ee420a,"ServerReplicator:processTicket - sendTop",0);
      }
      FUN_006829b0();
      uVar22 = FUN_0054db20();
      FUN_00682aa0(uVar22);
      if (*(char *)((int)param_1 + 0x3d71) != '\0') {
        iVar4 = *param_1;
        goto LAB_006679b8;
      }
      if ((((DAT_01d5acf8 == '\0') || (cVar1 = FUN_005f77c0(), cVar1 == '\x04')) ||
          (cVar1 = FUN_005f7830(), cVar1 != '\0')) && (cVar1 = FUN_0065cb00(), cVar1 != '\0')) {
        (**(code **)(*param_1 + 0x294))(0x11a,"BlockedIP",0x1f,DAT_01d5ab38 == '\0',0,0);
        goto LAB_006679d7;
      }
      cVar1 = FUN_0065d000(param_1[0xf03]);
      iVar4 = *param_1;
      if (cVar1 != '\0') {
        uVar26 = 1;
        uVar24 = 0x1e;
        pcVar23 = "SecurityPolicy";
        uVar22 = 0x119;
        goto LAB_006679d1;
      }
      cVar1 = (**(code **)(iVar4 + 0x124))();
      if (((cVar1 == '\0') && (DAT_01d5ac38 != '\0')) &&
         (cVar1 = FUN_009818f0(auStack_98), cVar1 == '\0')) {
        *(undefined *)(param_1 + 0xf5c) = 0;
        (**(code **)(*param_1 + 0x294))(0x101,"BadHash",3,1,0,0);
        FUN_006ab530();
        uStack_8._0_1_ = 0x1a;
        param_2 = (int *)CONCAT31(param_2._1_3_,0x94);
        FUN_006ad5e0(&param_2,1);
        FUN_0060ed10(param_1 + 0x1d);
        FUN_00681340(auStack_10c,0,3,0);
        uStack_8._0_1_ = 0x11;
        FUN_00613200();
      }
      *(undefined2 *)((int)param_1 + 0x37fe) = 0x101;
      if (((param_1[0xfbb] == 0x4beda921) || (param_1[0xfbb] == -0x6c72d79)) &&
         (param_1[0xfbc] == 0x557bb5d7)) {
        *(undefined2 *)((int)param_1 + 0x37fe) = 0;
      }
      if (0 < (int)DAT_01ead7a8) {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 0x1b;
        FUN_0151fa60("versionKey",param_1[0xfbd]);
        FUN_0151fa60("expectedKey",DAT_018c8aac);
        FUN_0151f950(&DAT_018d2348,param_1 + 0xf8e);
        FUN_0151f950(&DAT_018d2350,auStack_98);
        FUN_0151f9c0("tVersion",*(undefined *)((int)param_1 + 0x3d72));
        FUN_0151f950(&DAT_018d2364,auStack_b0);
        uVar22 = FUN_0061eec0(apppppppcStack_38);
        uStack_8._0_1_ = 0x1c;
        FUN_0151f950(&DAT_018d236c,uVar22);
        uStack_8._0_1_ = 0x1b;
        FUN_005507b0();
        FUN_0151fbb0("chsr-id",param_1[0xf64],param_1[0xf65]);
        uVar22 = FUN_005f2c00(param_1[0xfbb]);
        FUN_0151f850("platform",uVar22);
        FUN_0054ef60(param_1[0xf16] + 0x1e4);
        uStack_8._0_1_ = 0x1d;
        FUN_0151f950("OsVersion",apppppppcStack_38);
        uStack_8._0_1_ = 0x1b;
        FUN_005507b0();
        param_2 = DAT_01ead7a8;
        uStack_28 = 0;
        uStack_24 = 0xf;
        apppppppcStack_38[0] = (char *******)((uint)apppppppcStack_38[0] & 0xffffff00);
        FUN_005542c0("ConnectReport",0xd);
        uStack_8._0_1_ = 0x1e;
        FUN_01520d20(apppppppcStack_38,param_2,0);
        FUN_005507b0();
        uStack_8._0_1_ = 0x11;
        FUN_0151f7f0();
      }
      FUN_0054ef60(param_1[0xf16] + 0x1e4);
      uStack_8._0_1_ = 0x1f;
      uVar22 = FUN_00927520(auStack_fc);
      uStack_8._0_1_ = 0x20;
      FUN_006686e0(uVar22,auStack_68);
      FUN_005507b0();
      uStack_8._0_1_ = 0x11;
      FUN_005507b0();
      FUN_0054ef60(param_1[0xf16] + 0x1e4);
      uStack_8._0_1_ = 0x21;
      pbVar11 = (byte *)FUN_00927520(auStack_fc);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
      if (uStack_28 == 0) {
LAB_00668426:
        piStack_3c = (int *)((uint)piStack_3c & 0xffffff00);
      }
      else {
        if (0xf < *(uint *)(pbVar11 + 0x14)) {
          pbVar11 = *(byte **)pbVar11;
        }
        pbVar14 = &DAT_018c1630;
        do {
          bVar2 = *pbVar11;
          bVar18 = bVar2 < *pbVar14;
          if (bVar2 != *pbVar14) {
LAB_006683e3:
            uVar16 = -(uint)bVar18 | 1;
            goto LAB_006683e8;
          }
          if (bVar2 == 0) break;
          bVar2 = pbVar11[1];
          bVar18 = bVar2 < pbVar14[1];
          if (bVar2 != pbVar14[1]) goto LAB_006683e3;
          pbVar11 = pbVar11 + 2;
          pbVar14 = pbVar14 + 2;
        } while (bVar2 != 0);
        uVar16 = 0;
LAB_006683e8:
        if (uVar16 != 0) goto LAB_00668426;
        pppppppcVar12 = (char *******)apppppppcStack_38;
        if (0xf < uStack_24) {
          pppppppcVar12 = apppppppcStack_38[0];
        }
        iVar4 = FUN_005bded0(pppppppcVar12,"%ld.%ld.%c",&pppppppuStack_1c,&uStack_48,
                             (int)&param_2 + 3);
        if ((iVar4 != 3) || (pppppppuStack_1c != (undefined4 *******)&DAT_00000006))
        goto LAB_00668426;
        piStack_3c = (int *)CONCAT31(piStack_3c._1_3_,1);
        if (param_2._3_1_ == '\x01') goto LAB_00668426;
      }
      FUN_0066cb30(0x10,piStack_3c);
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      FUN_005507b0();
      cVar1 = FUN_0065add0();
      if (cVar1 != '\0') {
        FUN_0066be20();
      }
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_00613200();
      uStack_8 = 2;
      FUN_0065aeb0(auStack_40);
      uStack_8._0_1_ = 0x24;
      acStack_16[0] = '\0';
      if ((*(char *)((int)param_1 + 0x37fe) == '\0') &&
         (param_2 = (int *)FUN_007163e0(param_1 + 0xfc3,acStack_16), param_2 != (int *)0x0)) {
        uVar22 = FUN_005f2c00(param_1[0xfbb]);
        FUN_0054eff0(uVar22);
        uStack_8._0_1_ = 0x25;
        uVar22 = 0x66850f;
        pppppppuStack_1c = (undefined4 *******)FUN_01674e20(0xb8);
        uStack_8._0_1_ = 0x26;
        if (pppppppuStack_1c == (undefined4 *******)0x0) {
          uVar22 = 0;
        }
        else {
          iVar4 = param_1[0xf66];
          uVar26 = 0x66852a;
          uVar24 = FUN_0065b470();
          FUN_00557fc0(auStack_40);
          uVar22 = FUN_00715940(param_2,uVar24,auStack_134,0x2a,iVar4,uVar22,uVar26);
          param_1 = piStack_b4;
        }
        uStack_8._0_1_ = 0x25;
        iStack_50 = 0;
        iStack_4c = 0;
        FUN_0064da00(uVar22,param_2);
        param_1[0xf74] = iStack_50;
        piVar9 = (int *)param_1[0xf75];
        param_1[0xf75] = iStack_4c;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar4 = piVar9[1] + -1;
          piVar9[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar4 = piVar9[2] + -1;
            piVar9[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        if (acStack_16[0] != '\0') {
          uStack_28 = 0;
          uStack_24 = 0xf;
          apppppppcStack_38[0] = (char *******)((uint)apppppppcStack_38[0] & 0xffffff00);
          FUN_005542c0("notValidated",0xc);
          uStack_8._0_1_ = 0x27;
          FUN_00719590(apppppppcStack_38);
          FUN_005507b0();
        }
        FUN_005507b0();
      }
      FUN_00550b30();
      goto LAB_00667a16;
    }
    (**(code **)(*param_1 + 0x294))(0x106,"PacketError",5,2,0,0);
    if (DAT_01ee420a != '\0') {
      FUN_016774b0(DAT_01ee420a,"ServerReplicator:Could not generate Player",0);
    }
  }
  else {
LAB_006679b8:
    uVar26 = 2;
    uVar24 = 3;
    pcVar23 = "BadHash";
    uVar22 = 0x101;
    *(undefined *)(param_1 + 0xf5c) = 0;
LAB_006679d1:
    (**(code **)(iVar4 + 0x294))(uVar22,pcVar23,uVar24,uVar26,0,0);
  }
LAB_006679d7:
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_00613200();
LAB_00667a16:
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7668 ; VA 0x00668611 ; Catch@00668611 */

undefined4 Catch_00668611(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d5a4c0 != '\0') {
    if (DAT_01ee420a == '\0') goto LAB_00668662;
    FUN_016774b0(DAT_01ee420a,
                 "!!! It looks like you are testing local rcc.  Make sure the placeid for the client matches the server!"
                 ,0);
  }
  if (DAT_01ee420a != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18c) + 4))();
    FUN_016774b0(DAT_01ee420a,"ServerReplicator::processTicket exception:  %s",uVar1);
  }
LAB_00668662:
  (**(code **)(**(int **)(unaff_EBP + -0xb0) + 0x294))(0x106,"ProcessTicketException",5,2,0,0);
  return 0x667a16;
}



/* FUNCTION 7669 ; VA 0x006686b0 ; FUN_006686b0 */

void __thiscall FUN_006686b0(int param_1,undefined *param_2)

{
  undefined *puVar1;
  
  puVar1 = *(undefined **)(param_1 + 4);
  if (*(undefined **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
    return;
  }
  FUN_0064c160(puVar1,param_2);
  return;
}



/* FUNCTION 7670 ; VA 0x006686e0 ; FUN_006686e0 */

void FUN_006686e0(byte *param_1,undefined4 *param_2)

{
  byte bVar1;
  byte *pbVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  undefined4 ****ppppuVar6;
  undefined4 uVar7;
  byte *pbVar8;
  char *pcVar9;
  undefined4 *puVar10;
  bool bVar11;
  undefined auStack_44 [24];
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2b60;
  pvStack_10 = ExceptionList;
  if (param_2[4] == 0) {
    return;
  }
  pbVar2 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pbVar2 = *(byte **)param_1;
  }
  pbVar8 = &DAT_018c1630;
  do {
    bVar1 = *pbVar2;
    bVar11 = bVar1 < *pbVar8;
    if (bVar1 != *pbVar8) {
LAB_00668740:
      uVar3 = -(uint)bVar11 | 1;
      goto LAB_00668745;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar2[1];
    bVar11 = bVar1 < pbVar8[1];
    if (bVar1 != pbVar8[1]) goto LAB_00668740;
    pbVar2 = pbVar2 + 2;
    pbVar8 = pbVar8 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
LAB_00668745:
  if (uVar3 != 0) {
    return;
  }
  puVar10 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar10 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_005bded0(puVar10,"%ld.%ld.%c",&iStack_14,&param_1,(int)&param_2 + 3);
  if (iVar4 != 3) {
    ExceptionList = pvStack_10;
    return;
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  if (iStack_14 == 10) {
    if (param_1 != (byte *)0x0) {
LAB_0066884d:
      uVar7 = 5;
      pcVar5 = "Other";
LAB_00668854:
      FUN_005542c0(pcVar5,uVar7);
      goto LAB_0066885c;
    }
    pcVar5 = "Windows10";
    pcVar9 = "WindowsServer2016";
  }
  else if (iStack_14 == 6) {
    if (param_1 == (byte *)0x3) {
      pcVar5 = "Windows81";
      pcVar9 = "WindowsServer2012R2";
    }
    else if (param_1 == (byte *)0x2) {
      pcVar5 = "Windows8";
      pcVar9 = "WindowsServer2012";
    }
    else if (param_1 == (byte *)0x1) {
      pcVar5 = "Windows7";
      pcVar9 = "WindowsServer2008R2";
    }
    else {
      if (param_1 != (byte *)0x0) goto LAB_0066884d;
      pcVar5 = "WindowsVista";
      pcVar9 = "WindowsServer2008";
    }
  }
  else {
    if (iStack_14 != 5) goto LAB_0066884d;
    if (param_1 != (byte *)0x2) {
      if (param_1 == (byte *)0x1) {
        uVar7 = 9;
        pcVar5 = "WindowsXP";
      }
      else {
        if (param_1 != (byte *)0x0) goto LAB_0066884d;
        uVar7 = 0xb;
        pcVar5 = "Windows2000";
      }
      goto LAB_00668854;
    }
    pcVar5 = "WindowsXP64BitEdition";
    pcVar9 = "WindowsServer2003";
  }
  if (param_2._3_1_ != '\x01') {
    pcVar5 = pcVar9;
  }
  FUN_00551260(pcVar5);
LAB_0066885c:
  ppppuVar6 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
  }
  uVar7 = FUN_01675640(auStack_44,"Win32ClientOsVersion-%s",ppppuVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008783f0(uVar7,1,0);
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7671 ; VA 0x006688b0 ; FUN_006688b0 */

void FUN_006688b0(undefined4 param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_e0 [160];
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2b8b;
  pvStack_10 = ExceptionList;
  if (DAT_01eada8f == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00565940(3,1);
    uStack_8 = 0;
    FUN_00558890(auStack_e0,"SecurityConfigError: ");
    FUN_00558890(auStack_e0,param_1);
    FUN_0058c420(apppuStack_28);
    ppppuVar1 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar1 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8._0_1_ = 1;
    FUN_0087c450(&DAT_018c5f98,"SecurityException",ppppuVar1,0,0,0);
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("ConfigMaskError",0xf);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00878480(auStack_40,0);
    if (0xf < uStack_2c) {
      uVar2 = uStack_2c + 1;
      uVar3 = auStack_40[0];
      if (0xfff < uVar2) {
        uVar3 = *(uint *)(auStack_40[0] - 4);
        uVar2 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar2);
    }
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar1 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar1 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar1,uVar3);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    FUN_005705c0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7672 ; VA 0x00668a20 ; FUN_00668a20 */

void __thiscall FUN_00668a20(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined2 uVar6;
  undefined auStack_50 [40];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dd60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((((*(int *)(param_1 + 0x3c0c) != 0) &&
       (ExceptionList = &pvStack_10, lVar3 = FUN_00928340(), lVar3 == DAT_01ead7ec)) &&
      (0 < DAT_01ead7ec)) || (DAT_01ead7ec < 0)) {
    FUN_01675640(aiStack_28,"%s,%s",param_2,param_3);
    uStack_8 = 0;
    FUN_006ab530();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_3 = CONCAT31(param_3._1_3_,0x98);
    FUN_006ad5e0(&param_3,1);
    FUN_006ae570(aiStack_28);
    FUN_005f70a0();
    FUN_005f7140();
    uVar4 = DAT_01d5a820;
    uVar5 = DAT_01d5a824;
    uVar6 = DAT_01d5a828;
    FUN_005f7170(param_1 + 0x74);
    FUN_00681340(auStack_50,0,3,0,uVar4,uVar5,uVar6);
    FUN_00613200();
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar2) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7673 ; VA 0x00668b60 ; FUN_00668b60 */

void __fastcall FUN_00668b60(int *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)((int)param_1 + 0x3f66) == '\0') {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_005f2c00(param_1[0xfbb]);
    uVar1 = FUN_01675640(auStack_28,"DynLua-Skip-%s",uVar1);
    uStack_8 = 0;
    FUN_008783f0(uVar1,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    *(undefined *)((int)param_1 + 0x3f66) = 1;
  }
  if (DAT_01d5a9f8 != '\0') {
    (**(code **)(*param_1 + 0x290))("DynLua",0x20,1,"DynLua Invalid Ordering",0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7674 ; VA 0x00668c40 ; FUN_00668c40 */

void FUN_00668c40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,char param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13)

{
  undefined4 uVar1;
  undefined *puVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151fa60(&DAT_018d25ec,param_1);
  FUN_0151fa60(&DAT_018c34b0,param_2);
  FUN_0151fa60(&DAT_018d25f4,param_3);
  FUN_0151fa60(&DAT_018d25f8,param_4);
  FUN_0151fa60(&DAT_018d25fc,param_5);
  FUN_0151fbb0("chsr-id",param_7,param_8);
  uVar1 = FUN_005f2c00(param_9);
  FUN_0151f850("platform",uVar1);
  FUN_0151f9c0(&DAT_018d2600,param_6);
  puVar2 = &DAT_018d2608;
  if (param_10 == '\0') {
    puVar2 = &DAT_018d2610;
  }
  FUN_0151f850(&DAT_018d2608,puVar2);
  FUN_0151f9c0("probe",param_11);
  FUN_0151fbb0("unvId",param_12,param_13);
  uStack_18 = 0;
  uVar1 = DAT_01ead7e0;
  if (param_10 != '\0') {
    uVar1 = DAT_01ead7e4;
  }
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("DlcReport",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7675 ; VA 0x00668de0 ; FUN_00668de0 */

void FUN_00668de0(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2bc8;
  pvStack_10 = ExceptionList;
  switch(param_1) {
  case 1:
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-DetectMethod-LdrLoadDllHook",0x2d);
    uStack_8 = 0;
    break;
  case 2:
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-DetectMethod-MemoryScan",0x29);
    uStack_8 = 1;
    break;
  case 3:
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-DetectMethod-HookRoutineCheck",0x2f);
    uStack_8 = 2;
    break;
  case 4:
    if (DAT_01d5aa30 == '\0') {
      return;
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-DetectMethod-SynHook",0x26);
    uStack_8 = 3;
    break;
  default:
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-DetectMethod-Unknown",0x26);
    uStack_8 = 4;
    FUN_008783f0(auStack_28,1,0);
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      uVar1 = auStack_28[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_28[0] - 4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar1,uVar2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  FUN_008783f0(auStack_40,1,0);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7676 ; VA 0x00668f80 ; FUN_00668f80 */

void FUN_00668f80(uint param_1)

{
  uint uVar1;
  uint uVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleScanFlags-NonZero",0x29);
    uStack_8 = 0;
    if ((param_1 & 1) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-Hidden",0x29);
    }
    if ((param_1 & 2) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-Packed",0x29);
    }
    if ((param_1 & 4) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-SingleRegion",0x2f);
    }
    if ((param_1 & 8) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-LargeFootprint",0x31);
    }
    if ((param_1 & 0x10) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-PeNotAccessible",0x32);
    }
    if ((param_1 & 0x20) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-PeNotFound",0x2d);
    }
    if ((param_1 & 0x40) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-PeIsMalformed",0x30);
    }
    if ((param_1 & 0x80) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-NoTextSection",0x30);
    }
    if ((param_1 & 0x2700) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-MatchKeyWords",0x30);
    }
    if ((param_1 & 0x100) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-HasRobloxKeywords",0x34);
    }
    if ((param_1 & 0x200) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-HasLuaKeywords",0x31);
    }
    if ((param_1 & 0x400) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-HasExploitsKeywords",0x36);
    }
    if ((param_1 & 0x2000) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-HasPackerKeywords",0x34);
    }
    if ((param_1 & 0x800) != 0) {
      FUN_00554150(",ExploitsDetection-ModuleScanFlags-HooksKeyAPIs",0x2f);
    }
    if ((param_1 & 0x10000) == 0) {
      if ((param_1 & 0x4000) == 0) {
        if ((param_1 & 0x8000) == 0) {
          uVar4 = 0x2a;
          pcVar3 = ",ExploitsDetection-ModuleScanFlags-Unknown";
        }
        else {
          uVar4 = 0x32;
          pcVar3 = ",ExploitsDetection-ModuleScanFlags-PossibleExploit";
        }
      }
      else {
        uVar4 = 0x2d;
        pcVar3 = ",ExploitsDetection-ModuleScanFlags-Suspicious";
      }
    }
    else {
      uVar4 = 0x2b;
      pcVar3 = ",ExploitsDetection-ModuleScanFlags-Exploits";
    }
    FUN_00554150(pcVar3,uVar4);
    FUN_00878480(auStack_28,0);
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      uVar1 = auStack_28[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_28[0] - 4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar1,uVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7677 ; VA 0x006691b0 ; FUN_006691b0 */

void FUN_006691b0(uint param_1)

{
  int iVar1;
  uint uVar2;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int aiStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2bf8;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    uStack_18 = param_1;
    uStack_14 = 0xf;
    aiStack_28[0] = (uint)aiStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleLoad-Normal",0x23);
    uStack_8 = param_1;
    FUN_008783f0(aiStack_28,1,0);
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar2) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar2);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if ((param_1 & 1) != 0) {
      uStack_18 = 0;
      uStack_14 = 0xf;
      aiStack_28[0] = (uint)aiStack_28[0]._1_3_ << 8;
      ExceptionList = &pvStack_10;
      FUN_005542c0("ExploitsDetection-ModuleLoad-Hidden",0x23);
      uStack_8 = 1;
      FUN_008783f0(aiStack_28,1,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    if ((param_1 & 2) != 0) {
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0("ExploitsDetection-ModuleLoad-NoPeHeader",0x27);
      uStack_8 = 2;
      FUN_008783f0(auStack_40,1,0);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7678 ; VA 0x00669300 ; FUN_00669300 */

void FUN_00669300(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  bool bVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  undefined4 uVar9;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2c37;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadab4) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eadab4), DAT_01eadab4 == -1)) {
    uStack_8 = 0;
    FUN_006501b0("(\\\\source[s]?\\\\)|(\\\\repo[s]?\\\\)|(\\\\project[s]?\\\\)",0x100);
    FUN_016f3654(FUN_0187d7e0);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eadab4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("ExploitsDetection-ModuleLocation-",0x21);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  switch(param_1) {
  case 1:
    uVar9 = 6;
    pcVar8 = "Others";
    break;
  case 2:
    uVar9 = 6;
    pcVar8 = "Roblox";
    break;
  case 3:
    uVar9 = 7;
    pcVar8 = "Windows";
    break;
  case 4:
    uVar9 = 6;
    pcVar8 = "System";
    break;
  case 5:
    uVar9 = 0xc;
    pcVar8 = "ProgramFiles";
    break;
  case 6:
    uVar9 = 0xb;
    pcVar8 = "ProgramData";
    break;
  case 7:
    uVar9 = 0xb;
    pcVar8 = "UserProfile";
    break;
  case 8:
    uVar9 = 0xb;
    pcVar8 = "UserAppData";
    break;
  case 9:
    uVar9 = 0xb;
    pcVar8 = "UserDesktop";
    break;
  case 10:
    uVar9 = 0xd;
    pcVar8 = "UserDownloads";
    break;
  case 0xb:
    uVar9 = 0xd;
    pcVar8 = "UserDocuments";
    break;
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
    uVar9 = 4;
    pcVar8 = "Temp";
    break;
  default:
    uVar9 = 7;
    pcVar8 = "Unknown";
  }
  FUN_00554150(pcVar8,uVar9);
  FUN_008783f0(auStack_28,1,0);
  piVar1 = param_2 + 4;
  if (*piVar1 != 0) {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar2 = (undefined4 *)(*piVar1 + (int)param_2);
    if (DAT_01eadaa0 != 0) {
      bVar3 = false;
      FUN_0064ff20(param_2,puVar2,&DAT_01eadaa4,DAT_01eadaa0,*(undefined4 *)(DAT_01eadaa0 + 0x1c),
                   *(undefined4 *)(DAT_01eadaa0 + 0x14),0x10);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      cVar4 = FUN_0064cca0(0,0);
      if (cVar4 == '\0') {
        if (param_2 != puVar2) {
          for (puVar5 = (undefined4 *)FUN_00657490((int)param_2 + 1,puVar2,0); puVar5 != puVar2;
              puVar5 = (undefined4 *)FUN_00657490((int)puVar5 + 1,puVar2,0)) {
            cVar4 = FUN_0064cca0(0,0);
            if (cVar4 != '\0') goto LAB_0066945e;
          }
          cVar4 = FUN_0064cca0(0,0);
          if (cVar4 != '\0') {
            bVar3 = true;
          }
        }
      }
      else {
LAB_0066945e:
        bVar3 = true;
      }
      uStack_8._0_1_ = 1;
      FUN_00651440();
      if (bVar3) {
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = 0;
        FUN_005542c0("ExploitsDetection-ModuleLocation-Developer",0x2a);
        uStack_8._0_1_ = 3;
        FUN_008783f0(auStack_40,1,0);
        FUN_005507b0();
      }
    }
  }
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7679 ; VA 0x00669610 ; FUN_00669610 */

void FUN_00669610(undefined4 *param_1,char *****param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  char *pcVar5;
  int *piVar6;
  char ****ppppcVar7;
  char *****pppppcVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined auStack_114 [8];
  undefined4 uStack_10c;
  undefined auStack_f8 [56];
  undefined4 uStack_c0;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined2 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  char ***apppcStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  undefined auStack_74 [16];
  int iStack_64;
  undefined4 uStack_60;
  char ****ppppcStack_5c;
  char ***pppcStack_58;
  char ***pppcStack_54;
  char ***pppcStack_50;
  uint uStack_4c;
  uint uStack_48;
  char ****ppppcStack_44;
  char ***pppcStack_40;
  char ***pppcStack_3c;
  char ***pppcStack_38;
  undefined8 uStack_34;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  char ***pppcStack_20;
  char cStack_19;
  char ****ppppcStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2c98;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadacc) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eadacc), DAT_01eadacc == -1)) {
    uStack_8 = 0;
    FUN_006501b0(".*\\.\\d*$",1);
    FUN_016f3654(FUN_0187d880);
    FUN_016f37bf(&DAT_01eadacc);
  }
  iStack_64 = 0;
  uStack_60 = 0xf;
  auStack_74[0] = 0;
  uStack_8 = 1;
  pppcStack_20 = (char ***)0x0;
  puStack_2c = (undefined4 *)0x0;
  uStack_28 = 0;
  puStack_2c = (undefined4 *)FUN_00575b30();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  ppppcVar7 = (char ****)0x0;
  do {
    ppppcStack_18 = (char ****)param_2;
    if ((char ****)0xf < param_2[5]) {
      ppppcStack_18 = *param_2;
    }
    uVar11 = (int)param_2[4] - (int)ppppcVar7;
    if ((ppppcVar7 < param_2[4]) &&
       (iVar4 = FUN_0170db20((char *)((int)ppppcStack_18 + (int)ppppcVar7),0x3b,uVar11), iVar4 != 0)
       ) {
      iVar4 = iVar4 - (int)ppppcStack_18;
    }
    else {
      iVar4 = -1;
    }
    if (iVar4 == -1) {
      uStack_4c = 0;
      uStack_48 = 0xf;
      ppppcStack_5c = (char ****)((uint)ppppcStack_5c & 0xffffff00);
      if (param_2[4] < pppcStack_20) {
LAB_00669ce1:
        FUN_00554050();
        goto LAB_00669ce6;
      }
      uVar12 = 0xffffffff;
      if (uVar11 != 0xffffffff) {
        uVar12 = uVar11;
      }
      pppppcVar8 = param_2;
      if ((char ****)0xf < param_2[5]) {
        pppppcVar8 = (char *****)*param_2;
      }
      FUN_005542c0((char *)((int)pppppcVar8 + (int)pppcStack_20),uVar12);
      pppppcVar8 = &ppppcStack_5c;
      uStack_24 = uStack_14 | 5;
    }
    else {
      uStack_7c = 0;
      uStack_78 = 0xf;
      apppcStack_8c[0] = (char ***)((uint)apppcStack_8c[0] & 0xffffff00);
      if (param_2[4] < pppcStack_20) goto LAB_00669ce1;
      uVar12 = iVar4 - (int)pppcStack_20;
      if (uVar11 < (uint)(iVar4 - (int)pppcStack_20)) {
        uVar12 = uVar11;
      }
      pppppcVar8 = param_2;
      if ((char ****)0xf < param_2[5]) {
        pppppcVar8 = (char *****)*param_2;
      }
      FUN_005542c0((char *)((int)pppppcVar8 + (int)pppcStack_20),uVar12);
      pppppcVar8 = (char *****)apppcStack_8c;
      uStack_24 = uStack_14 | 10;
    }
    uStack_14 = uStack_24;
    ppppcStack_44 = *pppppcVar8;
    pppcStack_40 = (char ***)pppppcVar8[1];
    pppcStack_3c = (char ***)pppppcVar8[2];
    pppcStack_38 = (char ***)pppppcVar8[3];
    uStack_34 = *(undefined8 *)(pppppcVar8 + 4);
    pppppcVar8[4] = (char ****)0x0;
    pppppcVar8[5] = (char ****)0xf;
    *(undefined *)pppppcVar8 = 0;
    uStack_8 = 4;
    if (((uStack_24 & 2) != 0) &&
       (uStack_24 = uStack_24 & 0xfffffffd, uStack_14 = uStack_24, 0xf < uStack_78)) {
      uVar11 = uStack_78 + 1;
      ppppcVar7 = (char ****)apppcStack_8c[0];
      if (0xfff < uVar11) {
        ppppcVar7 = (char ****)apppcStack_8c[0][-1];
        uVar11 = uStack_78 + 0x24;
        if (0x1f < (uint)((int)apppcStack_8c[0] + (-4 - (int)ppppcVar7))) goto LAB_00669ce6;
      }
      FUN_01674ea0(ppppcVar7,uVar11);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (((uStack_14 & 1) != 0) &&
       (uStack_24 = uStack_14 & 0xfffffffe, uStack_14 = uStack_24, 0xf < uStack_48)) {
      uVar11 = uStack_48 + 1;
      pppppcVar8 = (char *****)ppppcStack_5c;
      if (0xfff < uVar11) {
        pppppcVar8 = (char *****)ppppcStack_5c[-1];
        uVar11 = uStack_48 + 0x24;
        if ((char *)0x1f < (char *)((int)ppppcStack_5c + (-4 - (int)pppppcVar8))) goto LAB_00669ce6;
      }
      FUN_01674ea0(pppppcVar8,uVar11);
    }
    if (iVar4 == -1) {
      pppcStack_20 = (char ***)0xffffffff;
    }
    else {
      pppcStack_20 = (char ***)(iVar4 + 1);
    }
    ppppcStack_18 = (char ****)&ppppcStack_44;
    if (0xf < uStack_34._4_4_) {
      ppppcStack_18 = ppppcStack_44;
    }
    if ((uint)uStack_34 == 0) {
LAB_00669874:
      uVar11 = 0xffffffff;
    }
    else {
      iVar4 = -1;
      if ((uint)uStack_34 - 1 != -1) {
        iVar4 = (uint)uStack_34 - 1;
      }
      pppppcVar8 = (char *****)((int)ppppcStack_18 + iVar4);
      cVar3 = *(char *)pppppcVar8;
      while (cVar3 != ':') {
        if (pppppcVar8 == (char *****)ppppcStack_18) goto LAB_00669874;
        pppppcVar8 = (char *****)((int)pppppcVar8 + -1);
        cVar3 = *(char *)pppppcVar8;
      }
      uVar11 = (int)pppppcVar8 - (int)ppppcStack_18;
    }
    uVar12 = uStack_14;
    uVar13 = (uint)uStack_34;
    if (uVar11 != 0xffffffff) {
      uStack_4c = 0;
      uStack_48 = 0xf;
      if ((uint)uStack_34 < uVar11) {
        uVar11 = (uint)uStack_34;
      }
      ppppcStack_5c = (char ****)((uint)ppppcStack_5c & 0xffffff00);
      pppppcVar8 = &ppppcStack_44;
      if (0xf < uStack_34._4_4_) {
        pppppcVar8 = (char *****)ppppcStack_44;
      }
      FUN_005542c0(pppppcVar8,uVar11);
      uVar12 = uStack_14 | 0x10;
      uStack_24 = uVar12;
      uStack_14 = uVar12;
      if (0xf < uStack_34._4_4_) {
        uVar11 = uStack_34._4_4_ + 1;
        pppppcVar8 = (char *****)ppppcStack_44;
        if (0xfff < uVar11) {
          pppppcVar8 = (char *****)ppppcStack_44[-1];
          uVar11 = uStack_34._4_4_ + 0x24;
          if ((char *)0x1f < (char *)((int)ppppcStack_44 + (-4 - (int)pppppcVar8)))
          goto LAB_00669ce6;
        }
        FUN_01674ea0(pppppcVar8,uVar11);
      }
      ppppcStack_44 = ppppcStack_5c;
      pppcStack_40 = pppcStack_58;
      pppcStack_3c = pppcStack_54;
      pppcStack_38 = pppcStack_50;
      uStack_34 = CONCAT44(uStack_48,uStack_4c);
      uVar13 = uStack_4c;
    }
    ppppcStack_18 = (char ****)&ppppcStack_44;
    if (0xf < uStack_34._4_4_) {
      ppppcStack_18 = ppppcStack_44;
    }
    ppppcStack_18 = (char ****)((int)ppppcStack_18 + uVar13);
    pppppcVar8 = &ppppcStack_44;
    if (0xf < uStack_34._4_4_) {
      pppppcVar8 = (char *****)ppppcStack_44;
    }
    if (DAT_01eadab8 != 0) {
      FUN_0064ff20(pppppcVar8,ppppcStack_18,&DAT_01eadabc,DAT_01eadab8,
                   *(undefined4 *)(DAT_01eadab8 + 0x1c),*(undefined4 *)(DAT_01eadab8 + 0x14),0x10);
      uStack_8._0_1_ = 6;
      uStack_c0 = uStack_b8;
      uStack_10c = uStack_b8;
      FUN_0066b930(uStack_a4,0);
      FUN_0064d6d0(uStack_a4,auStack_f8);
      uStack_a8 = 0;
      uStack_98 = 1;
      uStack_94 = 10000000;
      uStack_90 = 1000;
      cVar3 = FUN_00656c90(uStack_b4);
      cStack_19 = cVar3 != '\0';
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_00651440();
      uVar13 = (uint)uStack_34;
      if (cStack_19 != '\0') {
        ppppcStack_18 = (char ****)&ppppcStack_44;
        if (0xf < uStack_34._4_4_) {
          ppppcStack_18 = ppppcStack_44;
        }
        if ((uint)uStack_34 == 0) {
LAB_00669a1e:
          uVar11 = 0xffffffff;
        }
        else {
          iVar4 = -1;
          if ((uint)uStack_34 - 1 != -1) {
            iVar4 = (uint)uStack_34 - 1;
          }
          pppppcVar8 = (char *****)((int)ppppcStack_18 + iVar4);
          cVar3 = *(char *)pppppcVar8;
          while (cVar3 != '.') {
            if (pppppcVar8 == (char *****)ppppcStack_18) goto LAB_00669a1e;
            pppppcVar8 = (char *****)((int)pppppcVar8 + -1);
            cVar3 = *(char *)pppppcVar8;
          }
          uVar11 = (int)pppppcVar8 - (int)ppppcStack_18;
        }
        if (uVar11 != 0xffffffff) {
          uStack_4c = 0;
          uStack_48 = 0xf;
          if ((uint)uStack_34 < uVar11) {
            uVar11 = (uint)uStack_34;
          }
          ppppcStack_5c = (char ****)((uint)ppppcStack_5c & 0xffffff00);
          pppppcVar8 = &ppppcStack_44;
          if (0xf < uStack_34._4_4_) {
            pppppcVar8 = (char *****)ppppcStack_44;
          }
          FUN_005542c0(pppppcVar8,uVar11);
          uStack_24 = uVar12 | 0x20;
          uStack_14 = uStack_24;
          if (0xf < uStack_34._4_4_) {
            uVar11 = uStack_34._4_4_ + 1;
            pppppcVar8 = (char *****)ppppcStack_44;
            if (0xfff < uVar11) {
              pppppcVar8 = (char *****)ppppcStack_44[-1];
              uVar11 = uStack_34._4_4_ + 0x24;
              if ((char *)0x1f < (char *)((int)ppppcStack_44 + (-4 - (int)pppppcVar8)))
              goto LAB_00669ce6;
            }
            FUN_01674ea0(pppppcVar8,uVar11);
          }
          ppppcStack_44 = ppppcStack_5c;
          pppcStack_40 = pppcStack_58;
          pppcStack_3c = pppcStack_54;
          pppcStack_38 = pppcStack_50;
          uStack_34 = CONCAT44(uStack_48,uStack_4c);
          uVar13 = uStack_4c;
        }
      }
    }
    if (uVar13 == 0) {
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_34._4_4_) {
        uVar11 = uStack_34._4_4_ + 1;
        pppppcVar8 = (char *****)ppppcStack_44;
        if (0xfff < uVar11) {
          pppppcVar8 = (char *****)ppppcStack_44[-1];
          pcVar5 = (char *)((int)ppppcStack_44 + (-4 - (int)pppppcVar8));
          uVar11 = uStack_34._4_4_;
joined_r0x00669b1d:
          uVar11 = uVar11 + 0x24;
          if ((char *)0x1f < pcVar5) {
LAB_00669ce6:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
LAB_00669b25:
        FUN_01674ea0(pppppcVar8,uVar11);
      }
    }
    else {
      FUN_0055b0f0(auStack_114,0,&ppppcStack_44,param_2);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_34._4_4_) {
        uVar11 = uStack_34._4_4_ + 1;
        pppppcVar8 = (char *****)ppppcStack_44;
        if (0xfff < uVar11) {
          pppppcVar8 = (char *****)ppppcStack_44[-1];
          pcVar5 = (char *)((int)ppppcStack_44 + (-4 - (int)pppppcVar8));
          uVar11 = uStack_34._4_4_;
          goto joined_r0x00669b1d;
        }
        goto LAB_00669b25;
      }
    }
    ppppcVar7 = (char ****)pppcStack_20;
    if ((char ****)pppcStack_20 == (char ****)0xffffffff) {
      FUN_005542c0("ExploitsDetection-RulesMatch-",0x1d);
      puVar9 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar9 = (undefined4 *)*param_1;
      }
      FUN_00554150(puVar9,param_1[4]);
      FUN_00554150("-Total",6);
      puVar1 = puStack_2c;
      puVar9 = (undefined4 *)*puStack_2c;
      while (puVar9 != puVar1) {
        piVar6 = puVar9 + 4;
        if (iStack_64 != 0) {
          FUN_00554150(&DAT_018bf378,1);
        }
        FUN_00554150("ExploitsDetection-RulesMatch-",0x1d);
        puVar10 = param_1;
        if (0xf < (uint)param_1[5]) {
          puVar10 = (undefined4 *)*param_1;
        }
        FUN_00554150(puVar10,param_1[4]);
        FUN_00554150(&DAT_018d3094,1);
        if (0xf < (uint)puVar9[9]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_00554150(piVar6,puVar9[8]);
        puVar10 = (undefined4 *)puVar9[2];
        if (*(char *)((int)puVar10 + 0xd) == '\0') {
          cVar3 = *(char *)((int)*puVar10 + 0xd);
          puVar9 = puVar10;
          puVar10 = (undefined4 *)*puVar10;
          while (cVar3 == '\0') {
            cVar3 = *(char *)((int)*puVar10 + 0xd);
            puVar9 = puVar10;
            puVar10 = (undefined4 *)*puVar10;
          }
        }
        else {
          cVar3 = *(char *)((int)puVar9[1] + 0xd);
          puVar2 = (undefined4 *)puVar9[1];
          puVar10 = puVar9;
          while ((puVar9 = puVar2, cVar3 == '\0' && (puVar10 == (undefined4 *)puVar9[2]))) {
            cVar3 = *(char *)((int)puVar9[1] + 0xd);
            puVar2 = (undefined4 *)puVar9[1];
            puVar10 = puVar9;
          }
        }
      }
      FUN_00878480(auStack_74,0);
      puVar9 = puStack_2c;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_00576720(puStack_2c[1]);
      puStack_2c[1] = puVar9;
      *puStack_2c = puVar9;
      puStack_2c[2] = puVar9;
      uStack_28 = 0;
      FUN_01674ea0(puStack_2c,0x28);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 7680 ; VA 0x00669cf0 ; FUN_00669cf0 */

void FUN_00669cf0(code *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2d10;
  pvStack_10 = ExceptionList;
  if (param_1 < (code *)0x100000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-0to1MB",0x26);
    uStack_8 = 0;
    FUN_008783f0(auStack_28,1,0);
    if (uStack_14 < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
    ExceptionList = pvStack_10;
    return;
  }
  if (param_1 < (code *)0xa00000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-1to10MB",0x27);
    uStack_8 = 1;
  }
  else if (param_1 < FUN_01400000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-10to20MB",0x28);
    uStack_8 = 2;
  }
  else if (param_1 < (code *)0x1e00000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-20to30MB",0x28);
    uStack_8 = 3;
  }
  else if (param_1 < (code *)0x2800000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-30to40MB",0x28);
    uStack_8 = 4;
  }
  else if (param_1 < (code *)0x3200000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-40to50MB",0x28);
    uStack_8 = 5;
  }
  else if (param_1 < (code *)0x3c00000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-50to60MB",0x28);
    uStack_8 = 6;
  }
  else if (param_1 < (code *)0x4600000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-60to70MB",0x28);
    uStack_8 = 7;
  }
  else if (param_1 < (code *)0x5000000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-70to80MB",0x28);
    uStack_8 = 8;
  }
  else if (param_1 < (code *)0x5a00000) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-80to90MB",0x28);
    uStack_8 = 9;
  }
  else {
    if ((code *)0x63fffff < param_1) {
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      ExceptionList = &pvStack_10;
      FUN_005542c0("ExploitsDetection-ModuleMemSize-Over100MB",0x29);
      uStack_8 = 0xb;
      FUN_008783f0(auStack_40,1,0);
      goto LAB_00669fe1;
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ExploitsDetection-ModuleMemSize-90to100MB",0x29);
    uStack_8 = 10;
  }
  FUN_008783f0(auStack_28,1,0);
LAB_00669fe1:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7681 ; VA 0x0066a000 ; FUN_0066a000 */

void __thiscall FUN_0066a000(int param_1,uint param_2)

{
  double dVar1;
  undefined uVar2;
  int iVar3;
  double *pdVar4;
  undefined4 uVar5;
  uint *puVar6;
  uint uVar7;
  uint uVar8;
  undefined8 uVar9;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined8 uStack_4c;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2de9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  iStack_8 = 0;
  FUN_00658300(param_2);
  FUN_0151f850();
  FUN_01675640(aiStack_44,"0h%04X",*(undefined4 *)(param_1 + 0x3f78));
  iStack_8._0_1_ = 1;
  FUN_0151f850();
  iStack_8._0_1_ = 0;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 0;
  if (0xf < uStack_30) {
    if ((0xfff < uStack_30 + 1) && (0x1f < (aiStack_44[0] - *(int *)(aiStack_44[0] + -4)) - 4U)) {
      iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  FUN_01675640(aiStack_44,"0h%04X",*(undefined4 *)(param_1 + 0x3f74));
  iStack_8._0_1_ = 2;
  FUN_0151f850();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_30) {
    if ((0xfff < uStack_30 + 1) && (0x1f < (aiStack_44[0] - *(int *)(aiStack_44[0] + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uVar9 = *(undefined8 *)(param_1 + 0x3d90);
  }
  else {
    uVar9 = FUN_00928340();
  }
  FUN_0151fbb0("chsr-id",uVar9);
  FUN_005f2c00(*(undefined4 *)(param_1 + 0x3eec));
  FUN_0151f850();
  iVar3 = FUN_008f7870(param_1);
  if (iVar3 == 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0();
    iStack_8 = 4;
    param_2 = 2;
  }
  else {
    FUN_0054ef60(iVar3 + 0x288);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    param_2 = 0x41;
  }
  uStack_14 = param_2;
  FUN_0151f950();
  iStack_8 = 3;
  if ((param_2 & 2) != 0) {
    param_2 = param_2 & 0xfffffffd;
    uStack_14 = param_2;
    if (0xf < uStack_18) {
      if ((0xfff < uStack_18 + 1) && (0x1f < (auStack_2c[0] - *(int *)(auStack_2c[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  iStack_8 = 0;
  if (((param_2 & 1) != 0) && (param_2 = param_2 & 0xfffffffe, uStack_14 = param_2, 0xf < uStack_30)
     ) {
    if ((0xfff < uStack_30 + 1) && (0x1f < (aiStack_44[0] - *(int *)(aiStack_44[0] + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  dVar1 = *(double *)(param_1 + 0x3bc0);
  pdVar4 = (double *)FUN_016830f0();
  FUN_0151fb00("duration",*pdVar4 - dVar1);
  uVar5 = FUN_0151b370();
  FUN_0151f950("baseurl",uVar5);
  uStack_4c = 0xf00000000;
  uStack_5c = uStack_5c & 0xffffff00;
  iStack_8 = CONCAT31(iStack_8._1_3_,5);
  if (DAT_01d5acf0 == '\0') {
    puVar6 = (uint *)FUN_0058c590(aiStack_44,*(undefined4 *)(param_1 + 0x78),0);
    if (&uStack_5c != puVar6) {
      FUN_005507b0();
      uStack_5c = *puVar6;
      uStack_58 = puVar6[1];
      uStack_54 = puVar6[2];
      uStack_50 = puVar6[3];
      uStack_4c = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    if (uStack_30 < 0x10) goto LAB_0066a401;
    uVar7 = uStack_30 + 1;
    iVar3 = aiStack_44[0];
    if (0xfff < uVar7) {
      iVar3 = *(int *)(aiStack_44[0] + -4);
      uVar7 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    uVar5 = FUN_005f77e0();
    puVar6 = (uint *)FUN_0058c590(aiStack_44,uVar5,0);
    if (&uStack_5c != puVar6) {
      FUN_005507b0();
      uStack_5c = *puVar6;
      uStack_58 = puVar6[1];
      uStack_54 = puVar6[2];
      uStack_50 = puVar6[3];
      uStack_4c = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    if (uStack_30 < 0x10) goto LAB_0066a401;
    uVar7 = uStack_30 + 1;
    iVar3 = aiStack_44[0];
    if (0xfff < uVar7) {
      iVar3 = *(int *)(aiStack_44[0] + -4);
      uVar7 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(iVar3,uVar7);
LAB_0066a401:
  FUN_00554150(&DAT_018d2110,2);
  FUN_006b1620(aiStack_44,param_1 + 0x74,0,0);
  iStack_8._0_1_ = 6;
  FUN_00554150();
  iStack_8._0_1_ = 5;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 5;
  if (0xf < uStack_30) {
    if ((0xfff < uStack_30 + 1) && (0x1f < (aiStack_44[0] - *(int *)(aiStack_44[0] + -4)) - 4U)) {
      iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  FUN_00554150();
  FUN_0151f950();
  FUN_0151f9c0();
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0();
    iStack_8 = 8;
    param_2 = param_2 | 8;
  }
  else {
    FUN_0054ef60(*(int *)(param_1 + 0x3c0c) + 0x1b4);
    iStack_8 = CONCAT31(iStack_8._1_3_,7);
    param_2 = param_2 | 0x84;
  }
  uStack_14 = param_2;
  FUN_0151f950();
  iStack_8 = 7;
  if ((param_2 & 8) != 0) {
    param_2 = param_2 & 0xfffffff7;
    uStack_14 = param_2;
    if (0xf < uStack_18) {
      if ((0xfff < uStack_18 + 1) && (0x1f < (auStack_2c[0] - *(int *)(auStack_2c[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  iStack_8 = 5;
  if (((param_2 & 4) != 0) && (param_2 = param_2 & 0xfffffffb, uStack_14 = param_2, 0xf < uStack_30)
     ) {
    if ((0xfff < uStack_30 + 1) && (0x1f < (aiStack_44[0] - *(int *)(aiStack_44[0] + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0();
    iStack_8 = 10;
    param_2 = param_2 | 0x20;
  }
  else {
    FUN_0054ef60(*(int *)(param_1 + 0x3c0c) + 0x1e4);
    iStack_8 = CONCAT31(iStack_8._1_3_,9);
    param_2 = param_2 | 0x110;
  }
  uStack_14 = param_2;
  FUN_0151f950();
  iStack_8 = 9;
  if ((param_2 & 0x20) != 0) {
    param_2 = param_2 & 0xffffffdf;
    if (0xf < uStack_18) {
      if ((0xfff < uStack_18 + 1) && (0x1f < (auStack_2c[0] - *(int *)(auStack_2c[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  iStack_8 = 5;
  if (((param_2 & 0x10) != 0) && (0xf < uStack_30)) {
    if ((0xfff < uStack_30 + 1) && (0x1f < (aiStack_44[0] - *(int *)(aiStack_44[0] + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uVar5 = DAT_01d5a77c;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0();
  iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
  FUN_01520d20(auStack_2c,uVar5,0);
  if (0xf < uStack_18) {
    uVar8 = uStack_18 + 1;
    uVar7 = auStack_2c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_2c[0] - 4);
      uVar8 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  if (0xf < uStack_4c._4_4_) {
    uVar8 = uStack_4c._4_4_ + 1;
    uVar7 = uStack_5c;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(uStack_5c - 4);
      uVar8 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uStack_5c - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_4c = 0xf00000000;
  uStack_5c = uStack_5c & 0xffffff00;
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7682 ; VA 0x0066a800 ; FUN_0066a800 */

void FUN_0066a800(void)

{
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0065b310(auStack_28,auStack_20,&uStack_18);
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0();
  uStack_8 = 0;
  FUN_00878cf0(auStack_40,uStack_18,0);
  if (0xf < uStack_2c) {
    if (0xfff < uStack_2c + 1) {
      if (0x1f < (auStack_40[0] - *(int *)(auStack_40[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7683 ; VA 0x0066a8c0 ; FUN_0066a8c0 */

void __thiscall FUN_0066a8c0(int param_1,int param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char ****ppppcVar4;
  char ****ppppcVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  char *pcVar9;
  char ***apppcStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    pcVar8 = "AntiCheat";
    if (param_3 == '\0') {
      pcVar8 = "AntiCheatNotKicked";
    }
    ExceptionList = &pvStack_10;
    cVar1 = FUN_0065d270(param_2);
    pcVar9 = "DuringJoin";
    if (cVar1 == '\0') {
      pcVar9 = "AfterJoin";
    }
    uVar2 = FUN_005f2c00(*(undefined4 *)(param_1 + 0x3eec));
    uVar3 = FUN_0065d750(param_2);
    FUN_01675640(apppcStack_40,"%s-%s,%s-%s,%s-%s",pcVar8,uVar3,pcVar8,uVar2,pcVar8,pcVar9);
    ppppcVar5 = apppcStack_40;
    if (0xf < uStack_2c) {
      ppppcVar5 = (char ****)apppcStack_40[0];
    }
    uStack_8 = 0;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ppppcVar4 = ppppcVar5;
    do {
      cVar1 = *(char *)ppppcVar4;
      ppppcVar4 = (char ****)((int)ppppcVar4 + 1);
    } while (cVar1 != '\0');
    FUN_005542c0(ppppcVar5,(int)ppppcVar4 - (int)((int)ppppcVar5 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00878480(auStack_28,0);
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    if (0xf < uStack_2c) {
      uVar7 = uStack_2c + 1;
      ppppcVar5 = (char ****)apppcStack_40[0];
      if (0xfff < uVar7) {
        ppppcVar5 = (char ****)apppcStack_40[0][-1];
        uVar7 = uStack_2c + 0x24;
        if ((char *)0x1f < (char *)((int)apppcStack_40[0] + (-4 - (int)ppppcVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar5,uVar7);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7684 ; VA 0x0066aa10 ; FUN_0066aa10 */

void __thiscall
FUN_0066aa10(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined *param_5)

{
  undefined4 *puVar1;
  undefined uVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  double *pdVar6;
  char *pcVar7;
  uint *puVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined auStack_a0 [24];
  undefined auStack_88 [24];
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined uStack_6b;
  double dStack_68;
  int aiStack_60 [5];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  char *pcStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2e97;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if ((char)param_4 == '\0') {
    if (*(char *)(param_1 + 0x3f61) != '\0') {
      return;
    }
  }
  else if (*(char *)(param_1 + 0x3f60) != '\0') {
    return;
  }
  if (param_2 == 0) {
    pcStack_18 = "DuringJoin";
  }
  else if (param_2 == 1) {
    pcStack_18 = "AfterJoin";
  }
  else {
    pcStack_18 = "Unknown";
  }
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  if (param_5 != (undefined *)0x0) {
    if (auStack_a0 != param_5) {
      FUN_00657e90(param_5,param_4);
    }
    piVar3 = (int *)(param_5 + 0x18);
    if ((int *)auStack_88 != piVar3) {
      if (0xf < *(uint *)(param_5 + 0x2c)) {
        piVar3 = (int *)*piVar3;
      }
      FUN_005542c0(piVar3,*(undefined4 *)(param_5 + 0x28));
    }
    uStack_70 = *(undefined4 *)(param_5 + 0x30);
    uStack_6c = param_5[0x34];
    uStack_6b = param_5[0x35];
  }
  FUN_0151f850(&DAT_018c7ed0,pcStack_18);
  FUN_0151f850("subtype",param_3);
  FUN_0151f8d0(&DAT_018d20dc,&DAT_018bc9b8,0);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uVar11 = *(undefined8 *)(param_1 + 0x3d90);
  }
  else {
    uVar11 = FUN_00928340();
  }
  FUN_0151fbb0("chsr-id",uVar11);
  uVar4 = FUN_005f2c00();
  FUN_0151f850("platform",uVar4);
  iVar5 = FUN_008f7870();
  if (iVar5 == 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    piVar3 = (int *)auStack_30;
    uStack_8 = 2;
    param_2 = 2;
  }
  else {
    FUN_0054ef60();
    piVar3 = aiStack_60;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_2 = 0x11;
  }
  uStack_14 = param_2;
  FUN_0151f950("jobid",piVar3);
  if ((param_2 & 2) != 0) {
    param_2 = param_2 & 0xfffffffd;
    uStack_14 = param_2;
    FUN_005507b0();
  }
  uStack_8 = 0;
  if ((param_2 & 1) != 0) {
    param_2 = param_2 & 0xfffffffe;
    uStack_14 = param_2;
    FUN_005507b0();
  }
  dStack_68 = *(double *)(param_1 + 0x3bc0);
  pdVar6 = (double *)FUN_016830f0();
  dStack_68 = *pdVar6 - dStack_68;
  FUN_0151fb00("duration",dStack_68);
  uVar4 = FUN_0151b370();
  FUN_0151f950("baseurl",uVar4);
  pcVar7 = "kicked";
  if ((char)param_4 == '\0') {
    pcVar7 = "notKicked";
  }
  FUN_0151f850("response",pcVar7);
  uStack_38 = 0xf00000000;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (DAT_01d5acf0 == '\0') {
    uVar4 = *(undefined4 *)(param_1 + 0x78);
  }
  else {
    uVar4 = FUN_005f77e0();
  }
  puVar8 = (uint *)FUN_0058c590(aiStack_60,uVar4);
  if (&uStack_48 != puVar8) {
    FUN_005507b0();
    uStack_48 = *puVar8;
    uStack_44 = puVar8[1];
    uStack_40 = puVar8[2];
    uStack_3c = puVar8[3];
    uStack_38 = *(undefined8 *)(puVar8 + 4);
    puVar8[4] = 0;
    puVar8[5] = 0xf;
    *(undefined *)puVar8 = 0;
  }
  FUN_005507b0();
  FUN_00554150(&DAT_018d2110,2);
  puVar9 = (undefined4 *)FUN_006b1620(aiStack_60,param_1 + 0x74,0,0);
  puVar1 = puVar9 + 4;
  uStack_8._0_1_ = 4;
  if (0xf < (uint)puVar9[5]) {
    puVar9 = (undefined4 *)*puVar9;
  }
  FUN_00554150(puVar9,*puVar1);
  uStack_8._0_1_ = 3;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_4c) {
    uVar10 = uStack_4c + 1;
    iVar5 = aiStack_60[0];
    if (0xfff < uVar10) {
      iVar5 = *(int *)(aiStack_60[0] + -4);
      uVar10 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar5) - 4U) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar10);
  }
  FUN_00554150(&DAT_018d2114,1);
  FUN_0151f950("cliaddr",&uStack_48);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x3c0c) + 0x454);
  }
  FUN_0151f9c0("accountAge",uVar4);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    piVar3 = (int *)auStack_30;
    uStack_8 = 6;
    param_2 = param_2 | 8;
  }
  else {
    FUN_0054ef60();
    piVar3 = aiStack_60;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    param_2 = param_2 | 0x24;
  }
  uStack_14 = param_2;
  FUN_0151f950("cliuuid",piVar3);
  if ((param_2 & 8) != 0) {
    param_2 = param_2 & 0xfffffff7;
    FUN_005507b0();
  }
  uStack_8 = 3;
  if ((param_2 & 4) != 0) {
    FUN_005507b0();
  }
  uVar4 = DAT_01ead7a4;
  iVar5 = *(int *)(*(int *)(param_1 + 0x3c1c) + 0x124);
  if ((iVar5 == 1) || (iVar5 == 2)) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("DisconnectReportTc",0x12);
    uStack_8._0_1_ = 7;
    uVar4 = 10000;
  }
  else {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("DisconnectReport3",0x11);
    uStack_8._0_1_ = 8;
  }
  FUN_01520d20(auStack_30,uVar4);
  uStack_8._0_1_ = 3;
  FUN_005507b0();
  if ((char)param_4 == '\0') {
    *(undefined *)(param_1 + 0x3f61) = 1;
  }
  else {
    *(undefined *)(param_1 + 0x3f60) = 1;
  }
  uVar4 = FUN_01520860();
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_0066d910(pcStack_18,param_3,uVar4,dStack_68,param_4);
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (aiStack_60[0] - *(int *)(aiStack_60[0] + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < uStack_38._4_4_) {
    if ((0xfff < uStack_38._4_4_ + 1) && (0x1f < (uStack_48 - *(int *)(uStack_48 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_38 = 0xf00000000;
  uStack_48 = uStack_48 & 0xffffff00;
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7685 ; VA 0x0066aff0 ; FUN_0066aff0 */

void __fastcall FUN_0066aff0(int param_1)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  uint *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined8 *puVar8;
  char *pcVar9;
  char ****ppppcVar10;
  undefined4 ****ppppuVar11;
  uint uVar12;
  char *pcVar13;
  char ****ppppcVar14;
  uint uVar15;
  undefined8 uVar16;
  char ***apppcStack_d0 [5];
  uint uStack_bc;
  uint auStack_b8 [5];
  uint uStack_a4;
  undefined4 ***apppuStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined auStack_48 [4];
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2f2e;
  pvStack_10 = ExceptionList;
  uStack_4c = 0;
  if (*(int *)(param_1 + 0x3dcc) == 0) {
    return;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_006a6900();
  iVar3 = iVar3 - *(int *)(param_1 + 0x1078);
  if (*(int *)(param_1 + 0x1118) < iVar3) {
    *(int *)(param_1 + 0x1118) = iVar3;
  }
  iVar3 = FUN_006a6900();
  iVar3 = iVar3 - *(int *)(param_1 + 0x1080);
  if (*(int *)(param_1 + 0x10e8) < iVar3) {
    *(int *)(param_1 + 0x10e8) = iVar3;
  }
  iVar3 = FUN_006a6900();
  iVar3 = iVar3 - *(int *)(param_1 + 0x1070);
  if (*(int *)(param_1 + 0x1148) < iVar3) {
    *(int *)(param_1 + 0x1148) = iVar3;
  }
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uVar16 = *(undefined8 *)(param_1 + 0x3d90);
  }
  else {
    uVar16 = FUN_00928340();
  }
  FUN_0151fbb0(&DAT_018c1fd8,uVar16);
  uStack_30 = 0xf00000000;
  uStack_40 = uStack_40 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (DAT_01d5acf0 == '\0') {
    uVar4 = *(undefined4 *)(param_1 + 0x78);
  }
  else {
    uVar4 = FUN_005f77e0();
  }
  puVar5 = (uint *)FUN_0058c590(auStack_b8,uVar4);
  if (&uStack_40 != puVar5) {
    FUN_005507b0();
    uStack_40 = *puVar5;
    uStack_3c = puVar5[1];
    uStack_38 = puVar5[2];
    uStack_34 = puVar5[3];
    uStack_30 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
  }
  FUN_005507b0();
  FUN_00554150(&DAT_018d2110,2);
  puVar6 = (undefined4 *)FUN_006b1620(auStack_28,param_1 + 0x74,0,0);
  puVar7 = puVar6 + 4;
  uStack_8._0_1_ = 2;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  FUN_00554150(puVar6,*puVar7);
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar12 = uStack_14 + 1;
    uVar15 = auStack_28[0];
    if (0xfff < uVar12) {
      uVar15 = *(uint *)(auStack_28[0] - 4);
      uVar12 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar12);
  }
  FUN_00554150(&DAT_018d2114,1);
  FUN_0151f950("cliaddr",&uStack_40);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x3c0c) + 0x454);
  }
  FUN_0151f9c0("accountAge",uVar4);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    puVar5 = auStack_28;
    uStack_8 = 4;
    uStack_4c = 2;
  }
  else {
    FUN_0054ef60();
    puVar5 = auStack_b8;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_4c = 5;
  }
  uStack_44 = uStack_4c;
  FUN_0151f950("cliuuid",puVar5);
  if ((uStack_44 & 2) != 0) {
    uStack_44 = uStack_44 & 0xfffffffd;
    FUN_005507b0();
  }
  uStack_8 = 1;
  if ((uStack_44 & 1) != 0) {
    FUN_005507b0();
  }
  FUN_0151fb00(&DAT_018d3e5c,*(undefined8 *)(param_1 + 0x620));
  FUN_0151fb00(&DAT_018d3e60,*(undefined8 *)(param_1 + 0x808));
  FUN_0151fb00(&DAT_018d3e64,*(undefined8 *)(param_1 + 0x810));
  FUN_0151fb00("avg_ping",*(undefined8 *)(param_1 + 0x1130));
  FUN_0151f9c0("max_ping",*(undefined4 *)(param_1 + 0x1148));
  FUN_0151f9c0("min_ping",*(undefined4 *)(param_1 + 0x114c));
  FUN_0151fa60("num_ping",*(undefined4 *)(param_1 + 0x3e90));
  FUN_0151fb00("avg_mcc",*(undefined8 *)(param_1 + 0x10d0));
  FUN_0151f9c0("max_mcc",*(undefined4 *)(param_1 + 0x10e8));
  FUN_0151f9c0("min_mcc",*(undefined4 *)(param_1 + 0x10ec));
  FUN_0151fa60("num_mcc",*(undefined4 *)(param_1 + 0x3e8c));
  FUN_0151fb00("avg_hash",*(undefined8 *)(param_1 + 0x1100));
  FUN_0151f9c0("max_hash",*(undefined4 *)(param_1 + 0x1118));
  FUN_0151f9c0("min_hash",*(undefined4 *)(param_1 + 0x111c));
  FUN_0151fa60("num_hash",*(undefined4 *)(param_1 + 0x3e88));
  puVar7 = (undefined4 *)FUN_01675640(auStack_b8,"0h%04X",*(undefined4 *)(param_1 + 0x3dcc));
  uStack_8._0_1_ = 5;
  if (0xf < (uint)puVar7[5]) {
    puVar7 = (undefined4 *)*puVar7;
  }
  FUN_0151f850(&DAT_018d3ee8,puVar7);
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_a4) {
    uVar12 = uStack_a4 + 1;
    uVar15 = auStack_b8[0];
    if (0xfff < uVar12) {
      uVar15 = *(uint *)(auStack_b8[0] - 4);
      uVar12 = uStack_a4 + 0x24;
      if (0x1f < (auStack_b8[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar12);
  }
  uStack_50 = FUN_006a6900();
  uStack_4c = 0;
  puVar8 = (undefined8 *)FUN_00626680(auStack_48,&uStack_50);
  FUN_0151fb00(&DAT_018d3eec,*puVar8);
  FUN_0151fb00(&DAT_018d3ef0,*(undefined8 *)(param_1 + 0x3ed0));
  FUN_0151fb00(&DAT_018d3ef4,*(undefined8 *)(param_1 + 0x3ea8));
  FUN_0151fb00(&DAT_018d3ef8,*(undefined8 *)(param_1 + 0x3ed8));
  uVar4 = FUN_005f2c00();
  FUN_0151f850(&DAT_018d3efc,uVar4);
  uVar4 = DAT_01d5b9e4;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("RccDebugTimeout4",0x10);
  uStack_8._0_1_ = 6;
  FUN_01520d20(auStack_28,uVar4,0);
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar12 = uStack_14 + 1;
    uVar15 = auStack_28[0];
    if (0xfff < uVar12) {
      uVar15 = *(uint *)(auStack_28[0] - 4);
      uVar12 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar12);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
  uVar15 = *(uint *)(param_1 + 0x3dcc);
  uStack_8._0_1_ = 7;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if ((char)uVar15 < '\0') {
    uVar16 = 0x4018c5e58;
  }
  else if ((uVar15 & 0xc) == 0xc) {
    pcVar13 = "both";
    if ((uVar15 & 3) != 3) {
      pcVar13 = "mcc";
    }
    pcVar9 = pcVar13;
    do {
      cVar1 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar1 != '\0');
    uVar16 = CONCAT44((int)pcVar9 - (int)(pcVar13 + 1),pcVar13);
  }
  else {
    if ((uVar15 & 3) != 3) goto LAB_0066b6f6;
    uVar16 = 0x4018d2350;
  }
  FUN_005542c0(uVar16);
  ppppuVar11 = apppuStack_68;
  if (0xf < uStack_54) {
    ppppuVar11 = (undefined4 ****)apppuStack_68[0];
  }
  uVar4 = FUN_005f2c00();
  FUN_01675640(apppcStack_d0,"TimeoutStatistics-%s-%s",uVar4,ppppuVar11);
  uStack_8._0_1_ = 8;
  ppppcVar14 = apppcStack_d0;
  if (0xf < uStack_bc) {
    ppppcVar14 = (char ****)apppcStack_d0[0];
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ppppcVar10 = ppppcVar14;
  do {
    cVar1 = *(char *)ppppcVar10;
    ppppcVar10 = (char ****)((int)ppppcVar10 + 1);
  } while (cVar1 != '\0');
  FUN_005542c0(ppppcVar14,(int)ppppcVar10 - (int)((int)ppppcVar14 + 1));
  uStack_8._0_1_ = 9;
  FUN_008783f0(auStack_28,1,0);
  FUN_005507b0();
  FUN_005507b0();
  uVar2 = (undefined)uStack_8;
  if (0xf < uStack_54) {
    uVar15 = uStack_54 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_68[0];
    if (0xfff < uVar15) {
      ppppuVar11 = (undefined4 ****)apppuStack_68[0][-1];
      uVar15 = uStack_54 + 0x24;
      if (0x1f < (uint)((int)apppuStack_68[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar11,uVar15);
    uVar2 = (undefined)uStack_8;
  }
LAB_0066b6f6:
  uStack_8._0_1_ = uVar2;
  uStack_58 = 0;
  uStack_54 = 0xf;
  apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
  if (0xf < uStack_30._4_4_) {
    if ((0xfff < uStack_30._4_4_ + 1) && (0x1f < (uStack_40 - *(int *)(uStack_40 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_30 = 0xf00000000;
  uStack_40 = uStack_40 & 0xffffff00;
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7686 ; VA 0x0066b780 ; FUN_0066b780 */

void __thiscall FUN_0066b780(int param_1,byte param_2)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  char ****ppppcVar4;
  char ****ppppcVar5;
  undefined4 ****ppppuVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  char ***apppcStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2f58;
  pvStack_10 = ExceptionList;
  pcVar7 = "ping";
  uStack_30 = 0;
  if ((param_2 & 0x80) == 0) {
    pcVar7 = "other";
  }
  uStack_2c = 0xf;
  apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  pcVar3 = pcVar7;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar7,(int)pcVar3 - (int)(pcVar7 + 1));
  ppppuVar6 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar6 = (undefined4 ****)apppuStack_40[0];
  }
  uStack_8 = 0;
  uVar2 = FUN_005f2c00(*(undefined4 *)(param_1 + 0x3eec));
  FUN_01675640(apppcStack_28,"AntiTimeout-%s-%s",uVar2,ppppuVar6);
  uStack_8._0_1_ = 1;
  ppppcVar5 = apppcStack_28;
  if (0xf < uStack_14) {
    ppppcVar5 = (char ****)apppcStack_28[0];
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  ppppcVar4 = ppppcVar5;
  do {
    cVar1 = *(char *)ppppcVar4;
    ppppcVar4 = (char ****)((int)ppppcVar4 + 1);
  } while (cVar1 != '\0');
  FUN_005542c0(ppppcVar5,(int)ppppcVar4 - (int)((int)ppppcVar5 + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008783f0(auStack_58,1,0);
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    uVar9 = auStack_58[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_58[0] - 4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    ppppcVar5 = (char ****)apppcStack_28[0];
    if (0xfff < uVar9) {
      ppppcVar5 = (char ****)apppcStack_28[0][-1];
      uVar9 = uStack_14 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_28[0] + (-4 - (int)ppppcVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar5,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppcStack_28[0] = (char ***)((uint)apppcStack_28[0] & 0xffffff00);
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar9) {
      ppppuVar6 = (undefined4 ****)apppuStack_40[0][-1];
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7687 ; VA 0x0066b920 ; FUN_0066b920 */

void __fastcall FUN_0066b920(int param_1)

{
  *(undefined4 *)(param_1 + 0x3de1) = 0;
  FUN_006812c0();
  return;
}



/* FUNCTION 7688 ; VA 0x0066b930 ; FUN_0066b930 */

void __thiscall FUN_0066b930(int *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  int aiStack_10 [2];
  int *piStack_8;
  
  uVar2 = param_1[3];
  piStack_8 = param_1;
  if (uVar2 < param_2) {
    if (((int)uVar2 < 0) && (uVar2 != 0)) {
      iVar1 = -((~uVar2 >> 5) * 4 + 4);
    }
    else {
      iVar1 = (uVar2 >> 5) * 4;
    }
    FUN_00656a20(aiStack_10,*param_1 + iVar1,uVar2 & 0x1f,param_2 - uVar2,&stack0x00000008);
    return;
  }
  if (param_2 < uVar2) {
    puVar5 = (undefined4 *)FUN_0065a980(auStack_18);
    aiStack_10[1] = 0;
    uVar3 = *puVar5;
    uVar4 = puVar5[1];
    aiStack_10[0] = *piStack_8;
    puVar5 = (undefined4 *)FUN_00652350(auStack_20,param_2);
    FUN_0065a9d0(aiStack_10,*puVar5,puVar5[1],uVar3,uVar4);
  }
  return;
}



/* FUNCTION 7689 ; VA 0x0066b9e0 ; FUN_0066b9e0 */

undefined * FUN_0066b9e0(undefined *param_1,uint param_2)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  char *pcStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2f78;
  pvStack_10 = ExceptionList;
  uStack_11 = 0x2d;
  ExceptionList = &pvStack_10;
  FUN_006503d0(0x20,&uStack_11,&uStack_12);
  uStack_8 = 0;
  uStack_11 = 0;
  if (puStack_18 == puStack_1c) {
    FUN_0064c160(puStack_1c,&uStack_11);
  }
  else {
    *puStack_1c = 0;
  }
  if ((param_2 & 1) != 0) {
    *pcStack_20 = 'h';
  }
  if ((param_2 & 2) != 0) {
    pcStack_20[1] = 'p';
  }
  if ((param_2 & 4) != 0) {
    pcStack_20[2] = 'O';
  }
  if ((param_2 & 8) != 0) {
    pcStack_20[3] = 'L';
  }
  if ((param_2 & 0x10) != 0) {
    pcStack_20[4] = 'C';
  }
  if ((param_2 & 0x20) != 0) {
    pcStack_20[5] = 'X';
  }
  if ((param_2 & 0x40) != 0) {
    pcStack_20[6] = 'M';
  }
  if ((char)param_2 < '\0') {
    pcStack_20[7] = 'T';
  }
  if ((param_2 & 0x100) != 0) {
    pcStack_20[8] = 'R';
  }
  if ((param_2 & 0x200) != 0) {
    pcStack_20[9] = 'U';
  }
  if ((param_2 & 0x400) != 0) {
    pcStack_20[10] = 'E';
  }
  if ((param_2 & 0x800) != 0) {
    pcStack_20[0xb] = 'H';
  }
  pcStack_20[0x1f] = '0';
  if ((param_2 & 0x4000) != 0) {
    pcStack_20[0x1f] = '3';
  }
  if ((param_2 & 0x8000) != 0) {
    pcStack_20[0x1f] = '4';
  }
  if ((param_2 & 0x10000) != 0) {
    pcStack_20[0x1f] = '5';
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar2 = pcStack_20;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcStack_20,(int)pcVar2 - (int)(pcStack_20 + 1));
  uVar3 = (int)puStack_18 - (int)pcStack_20;
  pcVar2 = pcStack_20;
  if (0xfff < uVar3) {
    pcVar2 = *(char **)(pcStack_20 + -4);
    uVar3 = uVar3 + 0x23;
    if ((char *)0x1f < pcStack_20 + (-4 - (int)pcVar2)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(pcVar2,uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7690 ; VA 0x0066bb50 ; FUN_0066bb50 */

void __fastcall FUN_0066bb50(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179209f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x30);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0071a130(param_1);
  }
  uStack_8 = 0xffffffff;
  FUN_006b1f50(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7691 ; VA 0x0066bbc0 ; FUN_0066bbc0 */

int FUN_0066bbc0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  uint *puVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2fe1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  piStack_1c = (int *)FUN_01674e20(0x38);
  uStack_8 = 0;
  if (piStack_1c == (int *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0151f6f0(0xffffffff,0,0);
  }
  uStack_8 = 0xffffffff;
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  FUN_0064daf0(uVar4,param_1);
  uVar4 = uStack_20;
  uStack_8 = 1;
  FUN_0151f950("jobid",param_1 + 8);
  uVar5 = FUN_0058c590(auStack_50,*(undefined4 *)(param_1 + 0x20),*(undefined4 *)(param_1 + 0x24));
  uStack_8._0_1_ = 2;
  FUN_0151f950(&DAT_018d26f4,uVar5);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_3c) {
    uVar9 = uStack_3c + 1;
    uVar11 = auStack_50[0];
    if (0xfff < uVar9) {
      uVar11 = *(uint *)(auStack_50[0] - 4);
      uVar9 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar11) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar9);
  }
  piVar6 = (int *)(param_1 + 0x30);
  if (*(uint *)(param_1 + 0x40) < 0x41) {
    puVar7 = (uint *)FUN_0054ef60(piVar6);
    uStack_8 = 4;
    uVar11 = 2;
  }
  else {
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    if (0xf < *(uint *)(param_1 + 0x44)) {
      piVar6 = (int *)*piVar6;
    }
    FUN_005542c0(piVar6,0x40);
    puVar7 = auStack_38;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uVar11 = 5;
  }
  uStack_14 = uVar11;
  FUN_0151f950(&DAT_018d279c,puVar7);
  uStack_8 = 3;
  if ((uVar11 & 2) != 0) {
    uVar11 = uVar11 & 0xfffffffd;
    if (0xf < uStack_3c) {
      uVar10 = uStack_3c + 1;
      uVar9 = auStack_50[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_50[0] - 4);
        uVar10 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
  }
  uStack_8 = 1;
  if (((uVar11 & 1) != 0) && (0xf < uStack_24)) {
    uVar9 = uStack_24 + 1;
    uVar11 = auStack_38[0];
    if (0xfff < uVar9) {
      uVar11 = *(uint *)(auStack_38[0] - 4);
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar9);
  }
  piVar6 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  iVar8 = FUN_0066d800(8,0,0,0,uVar4,piStack_1c);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 7692 ; VA 0x0066be20 ; FUN_0066be20 */

void FUN_0066be20(void)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined auStack_154 [120];
  uint auStack_dc [4];
  undefined4 uStack_cc;
  uint uStack_c8;
  uint auStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined **ppuStack_94;
  undefined4 uStack_90;
  int *piStack_8c;
  uint auStack_84 [4];
  undefined4 uStack_74;
  undefined ***pppuStack_70;
  int iStack_6c;
  undefined auStack_5c [4];
  int *piStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = DAT_01d5a7bc;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a308f;
  pvStack_10 = ExceptionList;
  iStack_44 = DAT_01d5a7b4 >> 0x1f;
  iStack_4c = DAT_01d5a7b4;
  iVar8 = DAT_01d5a7bc >> 0x1f;
  iStack_6c = (int)DAT_01d5a7c4 >> 0x1f;
  piStack_50 = DAT_01d5a7c4;
  ExceptionList = &pvStack_10;
  FUN_0167e9f0();
  uStack_8 = 0;
  FUN_01681c30();
  FUN_01681d10("operations");
  FUN_01681c10();
  FUN_01681c30();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("humans",6);
  uStack_8._0_1_ = 1;
  uVar5 = FUN_00659ab0(auStack_40,auStack_28);
  uStack_8._0_1_ = 2;
  FUN_01681e50(&DAT_018d46b8,uVar5);
  FUN_016816e0("expiry",iStack_4c,iStack_44);
  FUN_016816e0("limit",iVar3,iVar8);
  FUN_01681200();
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 0;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  FUN_01681c30();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018d46d4,4);
  uStack_8._0_1_ = 3;
  uVar5 = FUN_00659ab0(auStack_40,auStack_28);
  uStack_8._0_1_ = 4;
  FUN_01681e50(&DAT_018d46b8,uVar5);
  iVar3 = iStack_4c;
  FUN_016816e0("expiry",iStack_4c,iStack_44);
  FUN_016816e0("limit",piStack_50,iStack_6c);
  FUN_01681200();
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 0;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  FUN_01681c30();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018d46dc,9);
  uStack_8._0_1_ = 5;
  uVar5 = FUN_00659ab0(auStack_40,auStack_28);
  uStack_8._0_1_ = 6;
  FUN_01681e50(&DAT_018d46b8,uVar5);
  FUN_016816e0("expiry",iVar3,iStack_44);
  FUN_016816e0("limit",1,0);
  FUN_01681200();
  uStack_8._0_1_ = 5;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 0;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  FUN_016811a0();
  FUN_01681200();
  FUN_014c9d60(auStack_5c,0);
  uStack_8._0_1_ = 7;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 8;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 9;
  uStack_b4 = 0;
  uStack_b0 = 0xf;
  auStack_c4[0] = auStack_c4[0] & 0xffffff00;
  FUN_005542c0("floodchecker/v1/get",0x13);
  uStack_8._0_1_ = 10;
  uVar5 = FUN_0151ec70(auStack_84);
  uStack_8._0_1_ = 0xb;
  uStack_9c = 0;
  uStack_98 = 0xf;
  auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  FUN_005542c0("https",5);
  uStack_8._0_1_ = 0xc;
  FUN_0151bcc0(auStack_154,auStack_ac,uVar5,auStack_c4,auStack_28,auStack_40);
  uStack_8._0_1_ = 0xd;
  puVar6 = (undefined4 *)FUN_0151bb70(auStack_dc);
  puVar1 = puVar6 + 4;
  uStack_8._0_1_ = 0xe;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  FUN_014cbbc0(puVar6,*puVar1);
  uStack_8._0_1_ = 0xd;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (0xf < uStack_c8) {
    uVar9 = uStack_c8 + 1;
    uVar7 = auStack_dc[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_dc[0] - 4);
      uVar9 = uStack_c8 + 0x24;
      if (0x1f < (auStack_dc[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_cc = 0;
  uStack_c8 = 0xf;
  auStack_dc[0] = auStack_dc[0] & 0xffffff00;
  FUN_0056d9d0();
  uStack_8._0_1_ = 0xb;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_98) {
    uVar9 = uStack_98 + 1;
    uVar7 = auStack_ac[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_ac[0] - 4);
      uVar9 = uStack_98 + 0x24;
      if (0x1f < (auStack_ac[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_9c = 0;
  uStack_98 = 0xf;
  auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  uStack_8._0_1_ = 10;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < pppuStack_70) {
    uVar9 = (int)pppuStack_70 + 1;
    uVar7 = auStack_84[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_84[0] - 4);
      uVar9 = (int)pppuStack_70 + 0x24;
      if (0x1f < (auStack_84[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_74 = 0;
  pppuStack_70 = (undefined ***)0xf;
  auStack_84[0] = auStack_84[0] & 0xffffff00;
  uStack_8._0_1_ = 9;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_b0) {
    uVar9 = uStack_b0 + 1;
    uVar7 = auStack_c4[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_c4[0] - 4);
      uVar9 = uStack_b0 + 0x24;
      if (0x1f < (auStack_c4[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_b4 = 0;
  uStack_b0 = 0xf;
  auStack_c4[0] = auStack_c4[0] & 0xffffff00;
  uStack_8._0_1_ = 8;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8._0_1_ = 7;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  FUN_014cba60();
  uVar5 = FUN_01681c50(auStack_84);
  uStack_8._0_1_ = 0xf;
  FUN_014cb780(uVar5,0);
  uStack_8._0_1_ = 7;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < pppuStack_70) {
    uVar9 = (int)pppuStack_70 + 1;
    uVar7 = auStack_84[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_84[0] - 4);
      uVar9 = (int)pppuStack_70 + 0x24;
      if (0x1f < (auStack_84[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  FUN_0060e0c0(&uStack_54,uStack_48);
  piVar2 = piStack_50;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piStack_50[2] = piStack_50[2] + 1;
    UNLOCK();
  }
  uStack_90 = uStack_54;
  pppuStack_70 = &ppuStack_94;
  ppuStack_94 = std::
                _Func_impl_no_alloc<class_<lambda_26b0ae1fe61d12916a6d1ea3a6dcb870>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_8c = piStack_50;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  FUN_014cb530(pppuStack_70);
  if (pppuStack_70 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_70)[4])(pppuStack_70 != &ppuStack_94);
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_58[1] + -1;
    piStack_58[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      piVar2 = piStack_58 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  FUN_0167ec80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7693 ; VA 0x0066c600 ; FUN_0066c600 */

void __fastcall FUN_0066c600(int *param_1)

{
  char cVar1;
  undefined uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  double *pdVar6;
  undefined4 ****ppppuVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  int aiStack_114 [54];
  undefined4 ***apppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a30d2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(char *)((int)param_1 + 0x3f52) == '\0') &&
     (((*(char *)((int)param_1 + 0x3f51) == '\0' ||
       (ExceptionList = &pvStack_10, DAT_01d5aba8 == '\0')) &&
      (ExceptionList = &pvStack_10, cVar1 = FUN_007198c0(), cVar1 != '\0')))) {
    *(undefined *)((int)param_1 + 0x3f52) = 1;
    (**(code **)(*param_1 + 0x290))("Guardian",0xf,DAT_01d5abb0 != '\0',"NetPmcPending",0);
    FUN_0087c450(&DAT_018c5f98,"SecurityException","NetPmc Pending P7.",0,0,0);
    if (*(char *)((int)param_1 + 0x3f53) != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00565940();
    uStack_8 = 0;
    uVar3 = FUN_00717b70(param_1,&uStack_1c,&uStack_20,&uStack_24);
    uVar11 = 0;
    if (*(char *)((int)param_1 + 0x37fe) != '\0') {
      uVar11 = 0x10000;
    }
    cVar1 = FUN_007198c0();
    uVar10 = 0;
    if (DAT_01d5aba0 != '\0') {
      uVar10 = 0x40000;
    }
    uVar4 = 0;
    if (DAT_01d5abb0 != '\0') {
      uVar4 = 0x100000;
    }
    uVar5 = 0;
    if (DAT_01d5aba8 != '\0') {
      uVar5 = 0x80000;
    }
    FUN_00585a70((int)aiStack_114 + *(int *)(aiStack_114[0] + 4));
    FUN_0056ef60(uVar3 | uVar11 | -(uint)(cVar1 != '\0') & 0x20000 | uVar10 | uVar4 | uVar5);
    pdVar6 = (double *)FUN_016830f0();
    uStack_18 = (*pdVar6 - *(double *)(param_1 + 0xef0)) * DAT_018c0d70;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8._0_1_ = 1;
    FUN_0058c420();
    uStack_8._0_1_ = 2;
    ppppuVar7 = apppuStack_3c;
    if (0xf < uStack_28) {
      ppppuVar7 = (undefined4 ****)apppuStack_3c[0];
    }
    FUN_0151f850("flags",ppppuVar7);
    uStack_8._0_1_ = 1;
    FUN_005507b0();
    FUN_0151fa60(&DAT_018d49a4,uStack_1c);
    FUN_0151fa60(&DAT_018d49a8,uStack_20);
    FUN_0151fa60(&DAT_018d49ac,uStack_24);
    FUN_0151fb00(&DAT_018d49b0,uStack_18);
    uVar9 = DAT_01d5a6dc;
    uStack_2c = 0;
    uStack_28 = 0xf;
    apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
    FUN_005542c0("hashstats",9);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_01520d20(apppuStack_3c,uVar9,0);
    FUN_005507b0();
    *(undefined *)((int)param_1 + 0x3f53) = 1;
    FUN_0151f7f0();
    FUN_005705c0();
    ExceptionList = pvStack_10;
    return;
  }
  if (((DAT_01d5aba0 != '\0') && (*(char *)((int)param_1 + 0x37fe) == '\0')) &&
     (cVar1 = FUN_00716cc0(param_1), cVar1 != '\0')) {
    uVar2 = FUN_00718010();
    uStack_18._0_5_ = CONCAT14(uVar2,(undefined4)uStack_18);
    uVar9 = uStack_18._4_4_;
    FUN_00719720(uStack_18._4_4_);
    iVar8 = FUN_01674e20(0x38);
    uStack_18 = (double)CONCAT44(iVar8,(undefined4)uStack_18);
    uStack_8 = 4;
    if (iVar8 == 0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_0071a1f0(param_1,uVar9);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7694 ; VA 0x0066c920 ; FUN_0066c920 */

void __thiscall FUN_0066c920(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x3d70) = param_2;
  return;
}



/* FUNCTION 7695 ; VA 0x0066c930 ; FUN_0066c930 */

void __thiscall FUN_0066c930(int param_1,uint param_2)

{
  *(uint *)(param_1 + 0x3f74) = *(uint *)(param_1 + 0x3f74) | param_2;
  return;
}



/* FUNCTION 7696 ; VA 0x0066c940 ; FUN_0066c940 */

void __thiscall FUN_0066c940(int param_1,uint param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char ****ppppcVar4;
  char ****ppppcVar5;
  uint uVar6;
  uint uVar7;
  char ***apppcStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(uint *)(param_1 + 0x3f78) = *(uint *)(param_1 + 0x3f78) | param_2;
  if ((*(uint *)(param_1 + 0x3f7c) & param_2) == 0) {
    if (param_2 != 0) {
      uVar2 = FUN_005f2c00(*(undefined4 *)(param_1 + 0x3eec));
      uVar3 = FUN_00658300(param_2);
      FUN_01675640(apppcStack_40,"%s-%s,%s-%s","BotCheckStatus",uVar3,"BotCheckStatus",uVar2);
      iStack_8 = 0;
      ppppcVar5 = apppcStack_40;
      if (0xf < uStack_2c) {
        ppppcVar5 = (char ****)apppcStack_40[0];
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      ppppcVar4 = ppppcVar5;
      do {
        cVar1 = *(char *)ppppcVar4;
        ppppcVar4 = (char ****)((int)ppppcVar4 + 1);
      } while (cVar1 != '\0');
      FUN_005542c0(ppppcVar5,(int)ppppcVar4 - (int)((int)ppppcVar5 + 1));
      iStack_8._0_1_ = 1;
      FUN_00878480(auStack_28,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_14) {
        uVar6 = uStack_14 + 1;
        uVar7 = auStack_28[0];
        if (0xfff < uVar6) {
          uVar7 = *(uint *)(auStack_28[0] - 4);
          uVar6 = uStack_14 + 0x24;
          if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar6);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      iStack_8 = 0xffffffff;
      if (0xf < uStack_2c) {
        uVar7 = uStack_2c + 1;
        ppppcVar5 = (char ****)apppcStack_40[0];
        if (0xfff < uVar7) {
          ppppcVar5 = (char ****)apppcStack_40[0][-1];
          uVar7 = uStack_2c + 0x24;
          if ((char *)0x1f < (char *)((int)apppcStack_40[0] + (-4 - (int)ppppcVar5))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppcVar5,uVar7);
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      apppcStack_40[0] = (char ***)((uint)apppcStack_40[0] & 0xffffff00);
    }
    FUN_0066a000(param_2);
    *(uint *)(param_1 + 0x3f7c) = *(uint *)(param_1 + 0x3f7c) | param_2;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7697 ; VA 0x0066cac0 ; FUN_0066cac0 */

undefined __thiscall FUN_0066cac0(undefined4 *param_1,undefined param_2)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined uVar3;
  undefined4 ***apppuStack_1c [4];
  int iStack_c;
  uint uStack_8;
  
  (**(code **)(*(int *)*param_1 + 0x10))(apppuStack_1c,&param_2,&stack0x00000005);
  uVar3 = param_2;
  if (iStack_c == 1) {
    ppppuVar1 = apppuStack_1c;
    if (0xf < uStack_8) {
      ppppuVar1 = (undefined4 ****)apppuStack_1c[0];
    }
    uVar3 = *(undefined *)ppppuVar1;
  }
  if (0xf < uStack_8) {
    uVar2 = uStack_8 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_1c[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_1c[0][-1];
      uVar2 = uStack_8 + 0x24;
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_1c[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  return uVar3;
}



/* FUNCTION 7698 ; VA 0x0066cb30 ; FUN_0066cb30 */

void __thiscall FUN_0066cb30(int param_1,uint param_2,char param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a810;
  pvStack_10 = ExceptionList;
  if (DAT_01d5ac68 == '\0') {
    ExceptionList = &pvStack_10;
    *(uint *)(param_1 + 0x3f74) = *(uint *)(param_1 + 0x3f74) | param_2;
    if (param_3 == '\0') {
      *(uint *)(param_1 + 0x3f78) = *(uint *)(param_1 + 0x3f78) & ~param_2;
    }
    else {
      FUN_0066c940(param_2);
    }
  }
  else if (param_3 == '\0') {
    ExceptionList = &pvStack_10;
    *(uint *)(param_1 + 0x3f78) = *(uint *)(param_1 + 0x3f78) & ~param_2;
    *(uint *)(param_1 + 0x3f74) = *(uint *)(param_1 + 0x3f74) | param_2;
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0066c940(param_2);
    *(uint *)(param_1 + 0x3f74) = *(uint *)(param_1 + 0x3f74) | param_2;
  }
  if (DAT_01d5ace0 == '\0') {
    cVar1 = FUN_0065add0();
    if (cVar1 == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    if ((*(uint *)(param_1 + 0x3f74) & DAT_01d5a7e0) != DAT_01d5a7e0) {
      ExceptionList = pvStack_10;
      return;
    }
    if (*(char *)(param_1 + 0x3f80) != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    uVar2 = *(uint *)(param_1 + 0x3f78) & DAT_01d5a7e0;
    if ((uVar2 != 0) || (DAT_01d5ac90 != '\0')) {
      FUN_0065bb30(uVar2 == 0,0,uVar2 != 0,0,0,0);
    }
    if ((DAT_01d5aca0 == '\0') || (uVar2 == 0)) goto LAB_0066cd00;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0("FloodChecker_Bot",0x10);
    uStack_8 = 1;
    FUN_008783f0(auStack_40,1,0);
  }
  else {
    cVar1 = FUN_0065add0();
    if (cVar1 == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    if (*(char *)(param_1 + 0x3f80) != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    uVar2 = *(uint *)(param_1 + 0x3f74) & DAT_01d5a7e0;
    uVar3 = *(uint *)(param_1 + 0x3f78) & uVar2;
    if ((uVar2 != DAT_01d5a7e0) && (uVar3 == 0)) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0065bb30(uVar3 == 0,0,uVar3 != 0,0,0,0);
    if (uVar3 == 0) goto LAB_0066cd00;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("FloodChecker_Bot",0x10);
    uStack_8 = 0;
    FUN_008783f0(auStack_28,1,0);
  }
  FUN_005507b0();
LAB_0066cd00:
  *(undefined *)(param_1 + 0x3f80) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7699 ; VA 0x0066cd20 ; FUN_0066cd20 */

void __fastcall FUN_0066cd20(int *param_1)

{
  double *pdVar1;
  uint3 uVar4;
  int *piVar2;
  int iVar3;
  int *piVar5;
  bool bVar6;
  undefined auStack_28 [8];
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a3101;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (*(char *)(param_1 + 0xf5c) != '\0') {
    ExceptionList = &pvStack_10;
    pdVar1 = (double *)FUN_016830f0(&iStack_20);
    if (DAT_01d5a680 < (int)(*pdVar1 - *(double *)(param_1 + 0xf94))) {
      uVar4 = (uint3)((uint)(int)(*pdVar1 - *(double *)(param_1 + 0xf94)) >> 8);
      if ((*(char *)((int)param_1 + 0x3f4b) == '\0') || (*(char *)((int)param_1 + 0x3f3e) == '\x02')
         ) {
        iVar3 = (uint)uVar4 << 8;
      }
      else {
        iVar3 = CONCAT31(uVar4,1);
      }
      FUN_0066cb30(4,iVar3);
      piVar5 = (int *)param_1[0xf17];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)param_1[0xf17];
      }
      iStack_18 = param_1[0xf16];
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar3 = piVar5[2] + -1;
          piVar5[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = (int *)param_1[0xf17];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)param_1[0xf17];
      }
      iStack_20 = param_1[0xf16];
      uStack_8 = 0;
      piStack_1c = piVar5;
      if (iStack_20 == 0) {
        bVar6 = true;
      }
      else {
        piVar2 = (int *)FUN_00644500(auStack_28);
        uStack_14 = 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        bVar6 = *(char *)(*piVar2 + 0x269) == '\0';
      }
      FUN_0066cb30(8,bVar6);
      if ((uStack_14 & 1) != 0) {
        FUN_00550b30();
      }
      uStack_8 = 0xffffffff;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar2 = piVar5 + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      bVar6 = false;
      if (iStack_18 != 0) {
        bVar6 = *(char *)(iStack_18 + 0x26a) == '\x01';
      }
      FUN_0066cb30(0x100,bVar6);
      iVar3 = (**(code **)(*param_1 + 0x228))();
      if (iVar3 != 0) {
        iVar3 = (**(code **)(*param_1 + 0x228))();
        FUN_0066cb30(0x200,iVar3 == 2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7700 ; VA 0x0066cee0 ; FUN_0066cee0 */

void __thiscall FUN_0066cee0(int param_1,undefined4 *param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  
  uVar2 = (int)(param_2[2] - param_2[1]) >> 2;
  if (*(char *)(param_1 + 0x3dac) == '\0') {
    FUN_005f86c0(uVar2,(int *)(param_1 + 0x3da0));
    uVar1 = 0;
    if (uVar2 != 0) {
      do {
        *(undefined4 *)(*(int *)(param_1 + 0x3da0) + uVar1 * 4) =
             *(undefined4 *)(*(int *)(param_1 + 0x3d18) + uVar1 * 4);
        uVar1 = uVar1 + 1;
      } while (uVar1 < uVar2);
    }
    *(undefined *)(param_1 + 0x3dac) = 1;
  }
  *(undefined4 *)(param_1 + 0x3d9c) = *param_2;
  *(undefined4 *)(param_1 + 16000) = *(undefined4 *)(param_3 + 8);
  *(undefined4 *)(param_1 + 0x3e84) = *(undefined4 *)(param_3 + 0xc);
  return;
}



/* FUNCTION 7701 ; VA 0x0066cf60 ; FUN_0066cf60 */

void __fastcall FUN_0066cf60(int param_1)

{
  uint *puVar1;
  undefined uVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *****pppppuVar5;
  undefined4 *****pppppuVar6;
  undefined4 *****pppppuVar7;
  int iVar8;
  undefined4 *****pppppuVar9;
  undefined4 *unaff_FS_OFFSET;
  undefined auStack_13c [48];
  undefined auStack_10c [24];
  undefined auStack_f4 [24];
  undefined4 ****appppuStack_dc [5];
  uint uStack_c8;
  undefined4 ****appppuStack_c4 [5];
  uint uStack_b0;
  undefined4 ****appppuStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 ****appppuStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  undefined4 ****appppuStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 ****appppuStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  int iStack_4c;
  int iStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 ****ppppuStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 ****ppppuStack_18;
  uint *puStack_14;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a31a2;
  uStack_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &uStack_10;
  puStack_14 = (uint *)0x0;
  puStack_14 = (uint *)FUN_008f7870(param_1);
  iVar8 = *(int *)(param_1 + 0x3c0c);
  if (iVar8 == 0) {
    iVar8 = *(int *)(param_1 + 0x3c58);
  }
  iStack_4c = param_1 + 0x3d74;
  iStack_48 = *(int *)(param_1 + 0x3d84);
  if (0xf < *(uint *)(param_1 + 0x3d88)) {
    iStack_4c = *(int *)iStack_4c;
  }
  if (((puStack_14 != (uint *)0x0) && (iVar8 != 0)) && (iStack_48 - 4U < 0x7fd)) {
    iStack_24 = 0;
    iStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    FUN_01683a90(&iStack_24,0x3b,0xffffffff,1);
    if (iStack_20 - iStack_24 >> 3 == 4) {
      cVar3 = FUN_006522d0(*(undefined4 *)(iStack_24 + 0x18),*(undefined4 *)(iStack_24 + 0x1c),
                           &DAT_018d1c48,1);
      if (cVar3 != '\0') {
        FUN_0058c4f0(appppuStack_dc);
        uStack_8._0_1_ = 1;
        FUN_0054ef60(puStack_14 + 0xa2);
        uStack_8._0_1_ = 2;
        uStack_44 = FUN_00928340();
        puVar1 = *(uint **)(iVar8 + 0x28);
        uStack_3c = *(undefined4 *)(iVar8 + 0x180);
        uStack_38 = *(undefined4 *)(iVar8 + 0x184);
        uStack_34 = *(undefined4 *)(iVar8 + 0x2f8);
        uStack_30 = *(undefined4 *)(iVar8 + 0x2fc);
        uStack_2c = *(undefined4 *)(iVar8 + 0x454);
        puStack_14 = *(uint **)(iVar8 + 0x450);
        FUN_00920c80(appppuStack_ac,&puStack_14);
        uStack_8._0_1_ = 3;
        FUN_0054ef60(iVar8 + 0x458);
        puStack_14 = (uint *)0xc;
        uStack_8._0_1_ = 4;
        FUN_00927540(appppuStack_7c);
        uStack_8._0_1_ = 5;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 5;
        if (DAT_01d64700 == '\0') {
          uVar4 = FUN_00926df0(auStack_13c);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          ppppuStack_18 = (undefined4 ****)0xd;
        }
        else {
          uStack_8._0_1_ = uVar2;
          uVar4 = FUN_0054ef60(*(undefined4 *)(iVar8 + 0x28));
          uStack_8 = 7;
          ppppuStack_18 = (undefined4 ****)0xe;
        }
        puStack_14 = (uint *)ppppuStack_18;
        FUN_0054ef60(uVar4);
        uStack_8 = 8;
        if (((uint)ppppuStack_18 & 2) != 0) {
          ppppuStack_18 = (undefined4 ****)((uint)ppppuStack_18 & 0xfffffffd);
          FUN_005507b0();
        }
        uStack_8._0_1_ = 10;
        if (((uint)ppppuStack_18 & 1) != 0) {
          FUN_005507b0();
        }
        pppppuVar7 = appppuStack_64;
        if (0xf < uStack_50) {
          pppppuVar7 = (undefined4 *****)appppuStack_64[0];
        }
        pppppuVar9 = appppuStack_7c;
        if (0xf < uStack_68) {
          pppppuVar9 = (undefined4 *****)appppuStack_7c[0];
        }
        ppppuStack_18 = appppuStack_94;
        if (0xf < uStack_80) {
          ppppuStack_18 = appppuStack_94[0];
        }
        ppppuStack_28 = appppuStack_ac;
        if (0xf < uStack_98) {
          ppppuStack_28 = appppuStack_ac[0];
        }
        puStack_14 = puVar1;
        if (0xf < puVar1[5]) {
          puStack_14 = (uint *)*puVar1;
        }
        pppppuVar6 = appppuStack_c4;
        if (0xf < uStack_b0) {
          pppppuVar6 = (undefined4 *****)appppuStack_c4[0];
        }
        pppppuVar5 = appppuStack_dc;
        if (0xf < uStack_c8) {
          pppppuVar5 = (undefined4 *****)appppuStack_dc[0];
        }
        FUN_01675640(auStack_10c,
                     "%s\n%s\n%lld\n%lld\n%lld\n%d\n%c\n%d\n%s\n%d\n%s\n%d\n%s\n%d\n%s\n%d\n%s",
                     pppppuVar5,pppppuVar6,uStack_44,uStack_3c,uStack_38,uStack_34,uStack_30,
                     uStack_2c,0x66,puVar1[4],puStack_14,uStack_9c,ppppuStack_28,uStack_84,
                     ppppuStack_18,uStack_6c,pppppuVar9,uStack_54,pppppuVar7);
        uStack_8._0_1_ = 0xb;
        FUN_0058c4f0(auStack_f4);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        FUN_01531610(3,auStack_10c,auStack_f4);
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_0056d380();
        *unaff_FS_OFFSET = uStack_10;
        return;
      }
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("wrong sig version");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("invalid sig format");
}



/* FUNCTION 7702 ; VA 0x0066d2f0 ; FUN_0066d2f0 */

/* WARNING: Removing unreachable block (ram,0x0066d69b) */

int __thiscall
FUN_0066d2f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5,
            undefined4 param_6,int param_7,int *param_8)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  uint *puVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined *puVar8;
  longlong lVar9;
  undefined8 uVar10;
  int iStack_88;
  int *piStack_84;
  undefined auStack_80 [24];
  int aiStack_68 [4];
  undefined auStack_58 [16];
  undefined4 uStack_48;
  int *piStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3246;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  iVar7 = 0;
  ExceptionList = &pvStack_10;
  if (param_7 == 0) goto LAB_0066d7bc;
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    lVar9 = *(longlong *)(param_1 + 0x3d90);
    ExceptionList = &pvStack_10;
LAB_0066d35d:
    uStack_24 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    lVar9 = FUN_00928340();
    if (*(int *)(param_1 + 0x3c0c) == 0) goto LAB_0066d35d;
    uStack_24 = *(undefined4 *)(*(int *)(param_1 + 0x3c0c) + 0x450);
  }
  iStack_20 = (int)((ulonglong)lVar9 >> 0x20);
  iVar7 = iStack_20;
  if (lVar9 < 0) goto LAB_0066d7bc;
  iStack_28 = FUN_008f7870(param_1);
  FUN_0151fbb0("userid",(int)lVar9,iStack_20);
  FUN_0151f9c0("usermtype",uStack_24);
  uVar4 = FUN_005f2c00(*(undefined4 *)(param_1 + 0x3eec));
  FUN_0151f850("cliplatform",uVar4);
  uStack_30 = 0xf00000000;
  uStack_40 = uStack_40 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (DAT_01d5acf0 == '\0') {
    uVar4 = *(undefined4 *)(param_1 + 0x78);
  }
  else {
    uVar4 = FUN_005f77e0();
  }
  puVar5 = (uint *)FUN_0058c590(auStack_80,uVar4,0);
  if (&uStack_40 != puVar5) {
    FUN_005507b0();
    uStack_40 = *puVar5;
    uStack_3c = puVar5[1];
    uStack_38 = puVar5[2];
    uStack_34 = puVar5[3];
    uStack_30 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
  }
  FUN_005507b0();
  FUN_00554150(&DAT_018d2110,2);
  puVar6 = (undefined4 *)FUN_006b1620(auStack_80,param_1 + 0x74,0,0);
  puVar1 = puVar6 + 4;
  uStack_8._0_1_ = 2;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  FUN_00554150(puVar6,*puVar1);
  uStack_8._0_1_ = 1;
  FUN_005507b0();
  FUN_00554150(&DAT_018d2114,1);
  FUN_0151f950("cliaddr",&uStack_40);
  puVar6 = (undefined4 *)FUN_01520860(auStack_80,"jobid");
  puVar1 = puVar6 + 4;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  cStack_11 = FUN_0055c360(puVar6,*puVar1,&DAT_018bc9b8,0);
  FUN_005507b0();
  if (cStack_11 != '\0') {
    if (iStack_28 == 0) {
      uStack_48 = 0;
      piStack_44 = (int *)&DAT_0000000f;
      auStack_58[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      puVar8 = auStack_58;
      uStack_8 = 4;
      uStack_1c = 2;
    }
    else {
      FUN_0054ef60(iStack_28 + 0x288);
      puVar8 = auStack_80;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uStack_1c = 9;
    }
    uStack_18 = uStack_1c;
    FUN_0151f950("jobid",puVar8);
    if ((uStack_18 & 2) != 0) {
      uStack_18 = uStack_18 & 0xfffffffd;
      FUN_005507b0();
    }
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    if ((uStack_18 & 1) != 0) {
      uStack_18 = uStack_18 & 0xfffffffe;
      FUN_005507b0();
    }
  }
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    FUN_0151f850("cliuuid",&DAT_018bc9b8);
  }
  else {
    FUN_0054ef60(*(int *)(param_1 + 0x3c0c) + 0x1b4);
    uStack_18 = uStack_18 | 0x10;
    uStack_8._0_1_ = 5;
    FUN_0151f950("cliuuid",auStack_80);
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    FUN_0151f850("clisguid",&DAT_018bc9b8);
  }
  else {
    FUN_0054ef60(*(int *)(param_1 + 0x3c0c) + 0x1cc);
    uStack_18 = uStack_18 | 0x20;
    uStack_8._0_1_ = 6;
    FUN_0151f950("clisguid",auStack_80);
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  FUN_0151fa60("RType",param_3);
  uVar10 = CONCAT44(param_5,param_4);
  if ((param_4 == 0) && (uVar10 = CONCAT44(param_5,param_4), param_5 == 0)) {
    uVar10 = FUN_01682de0();
  }
  FUN_0151fc50("RTime",uVar10);
  FUN_0151fa60("RFlags",param_6);
  if (iStack_28 == 0) {
LAB_0066d6a6:
    uVar4 = 0;
  }
  else {
    iVar7 = FUN_008fbd60(auStack_80);
    uStack_1c = uStack_18 | 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    uStack_18 = uStack_1c;
    if ((*(int *)(iVar7 + 0x10) == 0) || (lVar9 = FUN_008fbdb0(), lVar9 < 1)) goto LAB_0066d6a6;
    uVar4 = 1;
  }
  uStack_8 = 1;
  if ((uStack_18 & 4) != 0) {
    FUN_005507b0();
  }
  FUN_0151f9c0("vipServer",uVar4);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x3c0c) + 0x454);
  }
  FUN_0151f9c0("accountAge",uVar4);
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    FUN_0151f9c0("canManage",0);
    FUN_01520d20(param_2,DAT_01d5a720,0);
  }
  else {
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    iStack_88 = param_7;
    piStack_84 = param_8;
    uStack_8._0_1_ = 8;
    FUN_0054ef60(param_2);
    piStack_44 = (int *)0x0;
    uStack_8._0_1_ = 10;
    piStack_44 = (int *)FUN_0064c550(&iStack_88);
    FUN_006511a0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_0091e690(aiStack_68);
    if (piStack_44 != (int *)0x0) {
      (**(code **)(*piStack_44 + 0x10))(piStack_44 != aiStack_68);
    }
  }
  iVar7 = FUN_005507b0();
LAB_0066d7bc:
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar2 = param_8 + 1;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar7 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 7703 ; VA 0x0066d800 ; FUN_0066d800 */

void * FUN_0066d800(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                   int param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3260;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar3 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ClientSecurityReport",0x14);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    pvVar3 = (void *)FUN_0066d2f0(auStack_2c,param_1,param_2,param_3,param_4,param_5,param_6);
    if (0xf < uStack_18) {
      uVar5 = uStack_18 + 1;
      uVar4 = auStack_2c[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_2c[0] - 4);
        uVar5 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      pvVar3 = (void *)FUN_01674ea0(uVar4,uVar5);
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 7704 ; VA 0x0066d910 ; FUN_0066d910 */

void * FUN_0066d910(byte *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
                   byte param_5)

{
  int *piVar1;
  byte bVar2;
  int *piVar3;
  byte *pbVar4;
  void *pvVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  byte *pbVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  bool bVar12;
  undefined4 ***apppuStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a328f;
  pvStack_10 = ExceptionList;
  if (param_5 == 0) {
    if (param_1 == (byte *)0x0) {
      return ExceptionList;
    }
    pbVar9 = &DAT_018d2790;
    pbVar4 = param_1;
    do {
      bVar2 = *pbVar4;
      bVar12 = bVar2 < *pbVar9;
      if (bVar2 != *pbVar9) {
LAB_0066d970:
        pvVar5 = (void *)(-(uint)bVar12 | 1);
        goto LAB_0066d975;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar4[1];
      bVar12 = bVar2 < pbVar9[1];
      if (bVar2 != pbVar9[1]) goto LAB_0066d970;
      pbVar4 = pbVar4 + 2;
      pbVar9 = pbVar9 + 2;
    } while (bVar2 != 0);
    pvVar5 = (void *)0x0;
LAB_0066d975:
    if (pvVar5 != (void *)0x0) {
      return pvVar5;
    }
  }
  ExceptionList = &pvStack_10;
  iVar6 = FUN_01674e20();
  uStack_8 = 0;
  if (iVar6 == 0) {
    uVar7 = 0;
  }
  else {
    uVar7 = FUN_0151f6f0(0xffffffff,0,0);
  }
  uStack_8 = 0xffffffff;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_0064daf0(uVar7,iVar6);
  uVar7 = uStack_1c;
  uStack_8 = 1;
  FUN_0151f850(&DAT_018d26f4,param_1);
  FUN_0151f850(&DAT_018d279c,param_2);
  FUN_0151f950(&DAT_018d27a0,param_3);
  iVar6 = FUN_0066db30(&DAT_018c5880,param_4);
  FUN_00565660(iVar6,0);
  ppppuVar10 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar10 = (undefined4 ****)apppuStack_34[0];
  }
  FUN_0058ccc0(ppppuVar10,iVar6 + 1,&DAT_018c5880,param_4);
  uStack_8._0_1_ = 2;
  FUN_0151f950(&DAT_018d27a4,apppuStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_20) {
    uVar11 = uStack_20 + 1;
    ppppuVar10 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar11) {
      ppppuVar10 = (undefined4 ****)apppuStack_34[0][-1];
      uVar11 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar10,uVar11);
  }
  uVar8 = FUN_0151b370();
  FUN_0151f950(&DAT_018d27a8,uVar8);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  pvVar5 = (void *)FUN_0066d800((param_5 ^ 1) + 5,0,0,0,uVar7,piStack_18);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar6 = *piVar1;
    pvVar5 = (void *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        pvVar5 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 7705 ; VA 0x0066db30 ; FUN_0066db30 */

int FUN_0066db30(undefined4 param_1)

{
  uint *puVar1;
  int iVar2;
  
  puVar1 = (uint *)FUN_005574c0(0,0,param_1,0,&stack0x00000008);
  iVar2 = FUN_0171d0ba(*puVar1 | 2,puVar1[1]);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  return iVar2;
}



/* FUNCTION 7706 ; VA 0x0066db60 ; FUN_0066db60 */

undefined4 * __thiscall
FUN_0066db60(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_018d625c;
  cVar3 = FUN_00670170(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7707 ; VA 0x0066dc80 ; FUN_0066dc80 */

int * __thiscall FUN_0066dc80(int *param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_34 [8];
  int *piStack_2c;
  int *piStack_24;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a32b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_00677660(param_2);
  uStack_8 = 0;
  iVar3 = FUN_00676fe0(auStack_34);
  *param_1 = iVar3;
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_24[2] + -1;
    piStack_24[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_24 + 4))();
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piStack_2c + 4))();
    }
  }
  cVar2 = FUN_0168a8f0();
  if (cVar2 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar4 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar4);
}



/* FUNCTION 7708 ; VA 0x0066dd30 ; FUN_0066dd30 */

undefined4 * __thiscall
FUN_0066dd30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_006708a0(param_2,param_3,param_4,param_5,param_6);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7709 ; VA 0x0066df60 ; thunk_FUN_00c00340 */

void thunk_FUN_00c00340(void)

{
  FUN_00c00340();
  return;
}



/* FUNCTION 7710 ; VA 0x0066dfb0 ; FUN_0066dfb0 */

int __thiscall
FUN_0066dfb0(int *param_1,undefined8 *param_2,undefined2 *param_3,undefined4 *param_4,
            undefined *param_5,undefined *param_6)

{
  uint uVar1;
  undefined uVar2;
  undefined uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  undefined8 *puVar13;
  int iVar14;
  undefined8 *puVar15;
  
  iVar11 = *param_1;
  iVar6 = (param_1[1] - *param_1) / 0xc;
  if (iVar6 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar10 = (param_1[2] - *param_1) / 0xc;
  uVar12 = uVar1;
  if ((uVar10 <= 0x15555555 - (uVar10 >> 1)) && (uVar12 = (uVar10 >> 1) + uVar10, uVar12 < uVar1)) {
    uVar12 = uVar1;
  }
  uVar10 = uVar12 * 0xc;
  if (uVar12 < 0x15555556) {
    uVar12 = uVar10;
    if (0xfff < uVar10) goto LAB_0066e049;
    if (uVar10 == 0) {
      puVar7 = (undefined8 *)0x0;
    }
    else {
      puVar7 = (undefined8 *)FUN_01674e20(uVar10);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_0066e049:
    uVar5 = uVar12 + 0x23;
    if (uVar5 <= uVar12) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_0066e1b5;
    puVar7 = (undefined8 *)(iVar6 + 0x23U & 0xffffffe0);
    *(int *)((int)puVar7 + -4) = iVar6;
  }
  iVar11 = (((int)param_2 - iVar11) / 0xc) * 0xc;
  puVar8 = (undefined8 *)((int)puVar7 + iVar11);
  uVar2 = *param_6;
  uVar3 = *param_5;
  uVar4 = *param_4;
  *(undefined2 *)puVar8 = *param_3;
  *(undefined *)(puVar8 + 1) = uVar3;
  *(undefined *)((int)puVar8 + 9) = uVar2;
  *(undefined4 *)((int)puVar8 + 4) = uVar4;
  puVar15 = (undefined8 *)param_1[1];
  puVar9 = (undefined8 *)*param_1;
  puVar13 = puVar7;
  if (param_2 == puVar15) {
    for (; puVar9 != puVar15; puVar9 = (undefined8 *)((int)puVar9 + 0xc)) {
      *puVar13 = *puVar9;
      *(undefined4 *)(puVar13 + 1) = *(undefined4 *)(puVar9 + 1);
      puVar13 = (undefined8 *)((int)puVar13 + 0xc);
    }
  }
  else {
    if (puVar9 != param_2) {
      do {
        *puVar13 = *puVar9;
        puVar15 = puVar9 + 1;
        puVar9 = (undefined8 *)((int)puVar9 + 0xc);
        *(undefined4 *)(puVar13 + 1) = *(undefined4 *)puVar15;
        puVar13 = (undefined8 *)((int)puVar13 + 0xc);
      } while (puVar9 != param_2);
      puVar15 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar15) {
      do {
        *(undefined8 *)((int)puVar8 + 0xc) = *param_2;
        puVar9 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)((int)puVar8 + 0x14) = *(undefined4 *)puVar9;
        puVar8 = (undefined8 *)((int)puVar8 + 0xc);
      } while (param_2 != puVar15);
    }
  }
  iVar6 = *param_1;
  if (iVar6 != 0) {
    uVar12 = ((param_1[2] - iVar6) / 0xc) * 0xc;
    iVar14 = iVar6;
    if (0xfff < uVar12) {
      iVar14 = *(int *)(iVar6 + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iVar6 - iVar14) - 4U) {
LAB_0066e1b5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar12);
  }
  *param_1 = (int)puVar7;
  param_1[1] = (int)puVar7 + uVar1 * 0xc;
  param_1[2] = uVar10 + (int)puVar7;
  return *param_1 + iVar11;
}



/* FUNCTION 7711 ; VA 0x0066e1c0 ; FUN_0066e1c0 */

void __thiscall FUN_0066e1c0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a32d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::PhysicsReceiverS2>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7712 ; VA 0x0066e22e ; Catch_All@0066e22e */

void Catch_All_0066e22e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00679780(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7713 ; VA 0x0066e250 ; FUN_0066e250 */

void __thiscall FUN_0066e250(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a32e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::PhysicsSenderS2>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7714 ; VA 0x0066e2be ; Catch_All@0066e2be */

void Catch_All_0066e2be(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00679830(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7715 ; VA 0x0066e2e0 ; FUN_0066e2e0 */

void __thiscall FUN_0066e2e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a32f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::PhysicsTouchSerializer>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7716 ; VA 0x0066e34e ; Catch_All@0066e34e */

void Catch_All_0066e34e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00679930(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7717 ; VA 0x0066e370 ; FUN_0066e370 */

int __thiscall FUN_0066e370(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3300;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::Replicator::SendStatsJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7718 ; VA 0x0066e444 ; Catch_All@0066e444 */

void Catch_All_0066e444(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7719 ; VA 0x0066e460 ; FUN_0066e460 */

int __thiscall FUN_0066e460(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3310;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedStatsItem<int>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7720 ; VA 0x0066e532 ; Catch_All@0066e532 */

void Catch_All_0066e532(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7721 ; VA 0x0066e550 ; FUN_0066e550 */

int __thiscall FUN_0066e550(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::TypedStatsItem<unsigned_int>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7722 ; VA 0x0066e622 ; Catch_All@0066e622 */

void Catch_All_0066e622(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7723 ; VA 0x0066e640 ; FUN_0066e640 */

int __thiscall FUN_0066e640(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3330;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AdService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7724 ; VA 0x0066e712 ; Catch_All@0066e712 */

void Catch_All_0066e712(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7725 ; VA 0x0066e730 ; FUN_0066e730 */

int __thiscall FUN_0066e730(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3340;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AnalyticsService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7726 ; VA 0x0066e802 ; Catch_All@0066e802 */

void Catch_All_0066e802(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7727 ; VA 0x0066e820 ; FUN_0066e820 */

int __thiscall FUN_0066e820(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3350;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ChatService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7728 ; VA 0x0066e8f2 ; Catch_All@0066e8f2 */

void Catch_All_0066e8f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7729 ; VA 0x0066e910 ; FUN_0066e910 */

int __thiscall FUN_0066e910(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3360;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::FriendService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7730 ; VA 0x0066e9e2 ; Catch_All@0066e9e2 */

void Catch_All_0066e9e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7731 ; VA 0x0066ea00 ; FUN_0066ea00 */

int __thiscall FUN_0066ea00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3370;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::JointsService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7732 ; VA 0x0066ead2 ; Catch_All@0066ead2 */

void Catch_All_0066ead2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7733 ; VA 0x0066eaf0 ; FUN_0066eaf0 */

int __thiscall FUN_0066eaf0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3380;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::LogService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7734 ; VA 0x0066ebc2 ; Catch_All@0066ebc2 */

void Catch_All_0066ebc2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7735 ; VA 0x0066ebe0 ; FUN_0066ebe0 */

int __thiscall FUN_0066ebe0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3390;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::MarketplaceService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7736 ; VA 0x0066ecb2 ; Catch_All@0066ecb2 */

void Catch_All_0066ecb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7737 ; VA 0x0066ecd0 ; FUN_0066ecd0 */

int __thiscall FUN_0066ecd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a33a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PermissionsService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7738 ; VA 0x0066eda2 ; Catch_All@0066eda2 */

void Catch_All_0066eda2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7739 ; VA 0x0066edc0 ; FUN_0066edc0 */

int __thiscall FUN_0066edc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a33b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PlayerEmulatorService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7740 ; VA 0x0066ee92 ; Catch_All@0066ee92 */

void Catch_All_0066ee92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7741 ; VA 0x0066eeb0 ; FUN_0066eeb0 */

int __thiscall FUN_0066eeb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a33c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PointsService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7742 ; VA 0x0066ef82 ; Catch_All@0066ef82 */

void Catch_All_0066ef82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7743 ; VA 0x0066efa0 ; FUN_0066efa0 */

int __thiscall FUN_0066efa0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a33d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PolicyService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7744 ; VA 0x0066f072 ; Catch_All@0066f072 */

void Catch_All_0066f072(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7745 ; VA 0x0066f090 ; FUN_0066f090 */

int __thiscall FUN_0066f090(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a33e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ProximityPromptService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7746 ; VA 0x0066f162 ; Catch_All@0066f162 */

void Catch_All_0066f162(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7747 ; VA 0x0066f180 ; FUN_0066f180 */

int __thiscall FUN_0066f180(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a33f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ReplicatedFirst*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7748 ; VA 0x0066f252 ; Catch_All@0066f252 */

void Catch_All_0066f252(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7749 ; VA 0x0066f270 ; FUN_0066f270 */

int __thiscall FUN_0066f270(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a3400;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ReplicatedScriptService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}


