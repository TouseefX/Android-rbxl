/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 8750 ; VA 0x006aea40 ; FUN_006aea40 */

void __thiscall FUN_006aea40(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6700;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RakNet::RakPeerInterface>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8751 ; VA 0x006aeaae ; Catch_All@006aeaae */

void Catch_All_006aeaae(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8752 ; VA 0x006aead0 ; FUN_006aead0 */

int __thiscall FUN_006aead0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6710;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8753 ; VA 0x006aeba4 ; Catch_All@006aeba4 */

void Catch_All_006aeba4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8754 ; VA 0x006aebc0 ; FUN_006aebc0 */

void __thiscall FUN_006aebc0(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_005f71d0(piVar4 + 2);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 8755 ; VA 0x006aec50 ; FUN_006aec50 */

undefined4 * __thiscall FUN_006aec50(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 *puVar9;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6796;
  pvStack_10 = ExceptionList;
  puStack_38 = (undefined4 *)param_3;
  puStack_3c = (undefined4 *)param_2;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_40 = 0x6aec8b;
  FUN_006aea40();
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = param_3;
  puStack_38 = param_1 + 10;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  puStack_3c = (undefined4 *)0x6aeccf;
  FUN_016830f0();
  puStack_3c = (undefined4 *)0x150;
  uStack_40 = 0x6aecd9;
  puVar5 = (undefined4 *)FUN_01674e20();
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    piVar8 = (int *)param_1[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)param_1[1];
    }
    uVar2 = *param_1;
    puStack_38 = (undefined4 *)0x9;
    uStack_8._0_1_ = 4;
    FUN_005c4330(&uStack_40,param_3);
    FUN_00a360a0("Net Peer Send",9,0);
    *puVar5 = RBX::Network::ConcurrentRakPeer::PacketJob::vftable;
    puVar9 = puVar5 + 0x4a;
    puStack_38 = (undefined4 *)0x8;
    uStack_8._0_1_ = 5;
    *puVar9 = 0;
    puVar5[0x4b] = 0;
    puVar5[0x4c] = 0;
    puVar5[0x4d] = 0;
    puVar5[0x4e] = 0;
    puStack_3c = (undefined4 *)0x6aed69;
    puVar6 = (undefined4 *)FUN_01674e20();
    *puVar9 = puVar6;
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 **)*puVar9 = puVar9;
    puVar5[0x4f] = 0;
    puVar5[0x52] = 0;
    puVar5[0x53] = 0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    puVar5[0x52] = uVar2;
    puVar5[0x53] = piVar8;
    uStack_8._0_1_ = 7;
    puStack_38 = (undefined4 *)0x6aedc1;
    FUN_00a361f0();
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar3 = piVar8[1] + -1;
      piVar8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_38 = (undefined4 *)0x6aedd7;
        (**(code **)*piVar8)();
        LOCK();
        iVar3 = piVar8[2] + -1;
        piVar8[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puStack_38 = (undefined4 *)0x6aede9;
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  puStack_38 = (undefined4 *)param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_40 = 0x6aee0e;
  puStack_3c = puVar5;
  FUN_006ae950();
  param_1[2] = 0;
  piVar8 = (int *)param_1[3];
  param_1[3] = 0;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar3 = piVar8[1] + -1;
    piVar8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_38 = (undefined4 *)0x6aee30;
      (**(code **)*piVar8)();
      LOCK();
      iVar3 = piVar8[2] + -1;
      piVar8[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_38 = (undefined4 *)0x6aee40;
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  puStack_38 = (undefined4 *)0x1a0;
  puStack_3c = (undefined4 *)0x6aee4a;
  puVar5 = (undefined4 *)FUN_01674e20();
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    piVar8 = (int *)param_1[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)param_1[1];
    }
    uVar2 = *param_1;
    puStack_38 = (undefined4 *)0x2;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_005c4330(&uStack_40,param_3);
    FUN_00a360a0("Net Peer Stats",9,0);
    *puVar5 = RBX::Network::ConcurrentRakPeer::StatsUpdateJob::vftable;
    puVar5[0x4a] = 0;
    puVar5[0x4b] = 0;
    puStack_38 = (undefined4 *)0xb;
    *(undefined *)(puVar5 + 0x4c) = 0;
    puStack_3c = (undefined4 *)0x6aeec2;
    uVar7 = FUN_00588320();
    puVar5[0x4d] = uVar7;
    puVar5[0x4e] = 0;
    puVar5[0x4f] = 0x3f800000;
    puVar5[0x50] = 0;
    puVar5[0x51] = 0;
    puStack_3c = (undefined4 *)0xb;
    *(undefined *)(puVar5 + 0x52) = 0;
    uStack_40 = 0x6aeefe;
    uVar7 = FUN_00588320();
    uVar4 = DAT_018ce300;
    puVar5[0x53] = uVar7;
    puVar5[0x54] = 0;
    puVar5[0x55] = 0x3f800000;
    puVar5[0x56] = 0;
    puVar5[0x57] = 0;
    *(undefined8 *)(puVar5 + 0x58) = uVar4;
    *(undefined8 *)(puVar5 + 0x5e) = 0;
    *(undefined *)(puVar5 + 0x60) = 1;
    puVar5[0x5a] = 0;
    puVar5[0x5b] = 0;
    puVar5[0x5c] = 0;
    puVar5[0x5d] = 0;
    puVar5[0x62] = 0;
    puVar5[99] = 0;
    puVar5[100] = 0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    uVar4 = DAT_018ce310;
    puVar5[99] = uVar2;
    puVar5[100] = piVar8;
    *(undefined8 *)(puVar5 + 0x66) = uVar4;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar3 = piVar8[1] + -1;
      piVar8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_38 = (undefined4 *)0x6aefb3;
        (**(code **)*piVar8)();
        LOCK();
        iVar3 = piVar8[2] + -1;
        piVar8[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puStack_38 = (undefined4 *)0x6aefc6;
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  puStack_38 = (undefined4 *)param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_40 = 0x6aefe8;
  puStack_3c = puVar5;
  FUN_006aead0();
  param_1[4] = 0;
  piVar8 = (int *)param_1[5];
  param_1[5] = 0;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar3 = piVar8[1] + -1;
    piVar8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_38 = (undefined4 *)0x6af00d;
      (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_38 = (undefined4 *)0x6af01c;
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (param_1[3] != 0) {
    LOCK();
    piVar8 = (int *)(param_1[3] + 4);
    *piVar8 = *piVar8 + 1;
    UNLOCK();
  }
  puStack_3c = (undefined4 *)param_1[2];
  puStack_38 = (undefined4 *)param_1[3];
  uStack_40 = 0x6af049;
  FUN_0151d950();
  if (param_1[5] != 0) {
    LOCK();
    piVar8 = (int *)(param_1[5] + 4);
    *piVar8 = *piVar8 + 1;
    UNLOCK();
  }
  puStack_3c = (undefined4 *)param_1[4];
  puStack_38 = (undefined4 *)param_1[5];
  uStack_40 = 0x6af073;
  FUN_0151d950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8756 ; VA 0x006af090 ; FUN_006af090 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_006af090(undefined4 *param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  uVar6 = _UNK_018db08c;
  uVar5 = _UNK_018db088;
  uVar4 = _UNK_018db084;
  uVar3 = _DAT_018db080;
  uVar2 = DAT_018db070;
  *param_1 = 0x5d4;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[8] = uVar3;
  param_1[9] = uVar4;
  param_1[10] = uVar5;
  param_1[0xb] = uVar6;
  *(undefined *)(param_1 + 0xe) = 1;
  uVar1 = DAT_018ce300;
  *(undefined8 *)(param_1 + 6) = uVar2;
  *(undefined8 *)(param_1 + 0xc) = 0;
  param_1[0x10] = 0;
  *(undefined8 *)(param_1 + 0x12) = uVar2;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  *(undefined *)(param_1 + 0x1a) = 1;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x1c) = uVar2;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  *(undefined *)(param_1 + 0x24) = 1;
  *(undefined8 *)(param_1 + 0x22) = 0;
  *(undefined8 *)(param_1 + 0x26) = uVar1;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  *(undefined *)(param_1 + 0x2e) = 1;
  *(undefined8 *)(param_1 + 0x2c) = 0;
  *(undefined8 *)(param_1 + 0x30) = uVar1;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  *(undefined *)(param_1 + 0x38) = 1;
  *(undefined8 *)(param_1 + 0x36) = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  return param_1;
}



/* FUNCTION 8757 ; VA 0x006af1a0 ; FUN_006af1a0 */

undefined4 * __fastcall FUN_006af1a0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_016830f0(param_1 + 2);
  return param_1;
}



/* FUNCTION 8758 ; VA 0x006af1c0 ; FUN_006af1c0 */

void __fastcall FUN_006af1c0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    piVar1 = *(int **)(*(int *)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4) + 4);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x40);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 8759 ; VA 0x006af2a0 ; FUN_006af2a0 */

void __fastcall FUN_006af2a0(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x270);
  }
  return;
}



/* FUNCTION 8760 ; VA 0x006af2c0 ; FUN_006af2c0 */

void __fastcall FUN_006af2c0(int param_1)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)(param_1 + 9) != '\0') {
      uVar2 = *(uint *)(iVar1 + 0x28);
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      if (uVar2 != 0) {
        ExceptionList = &pvStack_10;
        if ((uVar2 & 1) == 0) {
          ExceptionList = &pvStack_10;
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            ExceptionList = &pvStack_10;
            (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x30,iVar1 + 0x30,2);
          }
        }
        *(undefined4 *)(iVar1 + 0x28) = 0;
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x48);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8761 ; VA 0x006af340 ; FUN_006af340 */

void __fastcall FUN_006af340(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_006b0490(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 8762 ; VA 0x006af3c0 ; FUN_006af3c0 */

void __fastcall FUN_006af3c0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_006b04d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8763 ; VA 0x006af460 ; FUN_006af460 */

void __fastcall FUN_006af460(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    piVar1 = *(int **)(*(int *)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4) + 4);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x40);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 8764 ; VA 0x006af470 ; FUN_006af470 */

int __fastcall FUN_006af470(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0xc) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00628870(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  if (*(int *)(param_1 + 0x14) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00628870(*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
  piVar1 = *(int **)(param_1 + 0x14);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(param_1 + 4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 8765 ; VA 0x006af570 ; FUN_006af570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_006af570(byte *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  int *piVar15;
  undefined4 *puVar16;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar16 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a67a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar12 = FUN_005f7c20(param_2);
  FUN_006aebc0(&param_2,uVar12,puVar16,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  uVar4 = *puVar16;
  uVar5 = puVar16[1];
  uVar6 = puVar16[2];
  uVar7 = puVar16[3];
  uStack_8 = 0;
  uVar8 = puVar16[4];
  uVar9 = puVar16[5];
  uVar10 = puVar16[6];
  uVar11 = puVar16[7];
  FUN_006b03e0();
  uRam00000028 = 0;
  uVar2 = *(uint *)(param_1 + 8);
  uVar13 = uVar2 + 1;
  _DAT_00000008 = uVar4;
  _DAT_0000000c = uVar5;
  _DAT_00000010 = uVar6;
  _DAT_00000014 = uVar7;
  _DAT_00000018 = uVar8;
  _DAT_0000001c = uVar9;
  _DAT_00000020 = uVar10;
  uRam00000024 = uVar11;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar13 = FUN_005d6bb0(uVar13);
    if (uVar13 <= *(uint *)(param_1 + 4)) {
      uVar13 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar13);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar13) {
    param_2 = (uint *)0x1;
    uVar14 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar13) {
      uVar14 = 1;
    }
    uVar13 = FUN_005d6bb0(uVar14 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar13 != *param_2) {
      FUN_005d2b00(uVar13);
      puVar16 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar3 = (undefined4 *)*puVar16;
      while (puVar3 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *param_2) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *param_2) * 4) == 0) {
          *piVar1 = (int)puVar16;
          puVar16 = puVar3;
        }
        else {
          *puVar16 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar16;
      }
    }
  }
  uVar13 = *(uint *)(param_1 + 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar12 % uVar13) * 4);
  _DAT_00000004 = uVar12;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar15 = (int *)(*(int *)(param_1 + 0x14) + uVar13 * 4);
    if (*piVar15 != 0) {
      *(undefined4 *)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar15 + 4) % uVar13) * 4) = 0;
    }
    *piVar1 = (int)piVar15;
    _DAT_00000000 = *piVar15;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    piVar15 = (int *)*piVar1;
  }
  *piVar15 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 8766 ; VA 0x006af750 ; FUN_006af750 */

undefined4 * __thiscall FUN_006af750(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  int *piVar11;
  uint uStack_24;
  undefined4 *puStack_20;
  undefined2 uStack_1c;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar10 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a67c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005f7a90(param_2);
  FUN_006b0560(&param_2,uStack_14,puVar10);
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 10;
  }
  puStack_20 = (undefined4 *)0x0;
  uStack_24 = -(uint)(param_1 != -3) & param_1 + 4U;
  uVar2 = *puVar10;
  uVar3 = puVar10[1];
  uVar4 = puVar10[2];
  uVar5 = puVar10[3];
  uStack_8 = 0;
  uStack_1c = 0;
  uVar6 = puVar10[4];
  uVar7 = puVar10[5];
  uVar8 = puVar10[6];
  uVar9 = puVar10[7];
  puVar10 = (undefined4 *)FUN_01674e20(0x270);
  *puVar10 = 0;
  puVar10[1] = 0;
  puStack_20 = puVar10;
  FUN_0170d1f0(puVar10 + 10,0,0x248);
  uStack_1c = 0x101;
  puVar10[2] = uVar2;
  puVar10[3] = uVar3;
  puVar10[4] = uVar4;
  puVar10[5] = uVar5;
  puVar10[6] = uVar6;
  puVar10[7] = uVar7;
  puVar10[8] = uVar8;
  puVar10[9] = uVar9;
  FUN_006af090();
  FUN_005d99d0(*(int *)(param_1 + 8) + 1);
  piVar11 = (int *)FUN_005c5550(auStack_18,&uStack_24,uStack_14);
  iVar1 = *piVar11;
  if (puStack_20 != (undefined4 *)0x0) {
    FUN_01674ea0(puStack_20,0x270);
  }
  ExceptionList = pvStack_10;
  return (undefined4 *)(iVar1 + 0x28);
}



/* FUNCTION 8767 ; VA 0x006af870 ; FUN_006af870 */

int __thiscall FUN_006af870(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x14c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_006af1c0();
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x150);
  }
  return param_1;
}



/* FUNCTION 8768 ; VA 0x006af8c0 ; FUN_006af8c0 */

int __thiscall FUN_006af8c0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 400);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_006af3c0();
  FUN_006af340();
  LOCK();
  iVar2 = *(int *)(param_1 + 300);
  *(int *)(param_1 + 300) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1a0);
  }
  return param_1;
}



/* FUNCTION 8769 ; VA 0x006af930 ; FUN_006af930 */

/* WARNING: Removing unreachable block (ram,0x006af996) */
/* WARNING: Removing unreachable block (ram,0x006af9a9) */
/* WARNING: Removing unreachable block (ram,0x006af9b0) */
/* WARNING: Removing unreachable block (ram,0x006af9b7) */

float10 FUN_006af930(void)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aeb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  iVar1 = FUN_006af750(&stack0x00000004);
  ExceptionList = pvStack_10;
  return (float10)*(double *)(iVar1 + 0x58);
}



/* FUNCTION 8770 ; VA 0x006af9e0 ; FUN_006af9e0 */

/* WARNING: Removing unreachable block (ram,0x006afa33) */
/* WARNING: Removing unreachable block (ram,0x006afa46) */
/* WARNING: Removing unreachable block (ram,0x006afa4d) */
/* WARNING: Removing unreachable block (ram,0x006afa54) */

float10 __fastcall FUN_006af9e0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  ExceptionList = pvStack_10;
  return (float10)*(double *)(*(int *)(param_1 + 0x10) + 0x170);
}



/* FUNCTION 8771 ; VA 0x006afa80 ; FUN_006afa80 */

/* WARNING: Removing unreachable block (ram,0x006afae9) */
/* WARNING: Removing unreachable block (ram,0x006afafc) */
/* WARNING: Removing unreachable block (ram,0x006afb03) */
/* WARNING: Removing unreachable block (ram,0x006afb0a) */

float10 FUN_006afa80(void)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aeb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  iVar1 = FUN_006af750(&stack0x00000004);
  ExceptionList = pvStack_10;
  return (float10)*(double *)(iVar1 + 0x80);
}



/* FUNCTION 8772 ; VA 0x006afb30 ; FUN_006afb30 */

int __thiscall
FUN_006afb30(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,uint *param_16)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined2 uVar10;
  int *piStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined uStack_20;
  int *piStack_1c;
  int *piStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_16;
  puStack_c = &LAB_017a67f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = (**(code **)(*param_2 + 8))();
  if (puVar1 == (uint *)0x0) {
    puVar1 = param_1 + 8;
    uVar3 = *puVar1;
    *puVar1 = *puVar1 + uVar5;
    param_1[9] = param_1[9] + (uint)CARRY4(uVar3,uVar5);
  }
  else {
    uVar3 = *puVar1;
    *puVar1 = *puVar1 + uVar5;
    puVar1[1] = puVar1[1] + (uint)CARRY4(uVar3,uVar5);
  }
  if ((DAT_01d5b388 == '\0') || (DAT_01d5b380 == '\0')) {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_54 = param_2;
    uStack_4c = param_4;
    uStack_48 = param_5;
    uStack_40 = param_7;
    uStack_3c = param_8;
    uStack_38 = param_9;
    uStack_34 = param_10;
    uStack_44 = (undefined)param_6;
    piStack_50 = param_3;
    uStack_30 = param_11;
    uStack_2c = param_12;
    uStack_28 = param_13;
    uStack_24 = param_14;
    uStack_20 = (undefined)param_15;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar6 = FUN_006b06a0(&piStack_54);
    piVar7 = piStack_50;
  }
  else {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_1c = param_2;
    piStack_18 = param_3;
    param_16 = (uint *)*param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    pcStack_14 = *(code **)(*param_16 + 0x48);
    FUN_005f70a0();
    FUN_005f7140();
    uVar8 = DAT_01d5b370;
    uVar9 = DAT_01d5b374;
    uVar10 = DAT_01d5b378;
    FUN_005f7170(&param_7);
    iVar6 = (*pcStack_14)(&piStack_1c,param_4,param_5,param_6,uVar8,uVar9,uVar10);
    piVar7 = piStack_18;
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar2 = piVar7 + 1;
    iVar4 = *piVar2;
    iVar6 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar2 = piVar7 + 2;
      iVar4 = *piVar2;
      iVar6 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar6 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar7 = param_3 + 1;
    iVar4 = *piVar7;
    iVar6 = *piVar7;
    *piVar7 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar7 = param_3 + 2;
      iVar4 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 8773 ; VA 0x006afce0 ; FUN_006afce0 */

void __thiscall FUN_006afce0(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x3ffffff - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_006afebc:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_006afd44;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_006afd44:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006afebc;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_006afebc;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 8774 ; VA 0x006afed0 ; FUN_006afed0 */

void FUN_006afed0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 uint param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined8 param_15)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  undefined uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 auStack_2dc [4];
  undefined4 uStack_2cc;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 auStack_2bc [146];
  uint auStack_74 [2];
  undefined auStack_6c [24];
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined2 uStack_20;
  uint *puStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6848;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_006af090();
  auStack_2dc[0] = param_1;
  auStack_2dc[1] = param_2;
  auStack_2dc[2] = param_3;
  auStack_2dc[3] = param_4;
  uStack_2cc = param_5;
  uStack_2c8 = param_6;
  uStack_2c4 = param_7;
  uStack_2c0 = param_8;
  puVar8 = auStack_2bc;
  for (iVar7 = 0x92; iVar7 != 0; iVar7 = iVar7 + -1) {
    *puVar8 = *puVar5;
    puVar5 = puVar5 + 1;
    puVar8 = puVar8 + 1;
  }
  FUN_00587490(&puStack_1c);
  uStack_8._0_1_ = 1;
  if (puStack_1c != (uint *)0x0) {
    FUN_006b11a0(auStack_2dc,puStack_1c);
  }
  piVar3 = piStack_18;
  uStack_8._0_1_ = 0;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
  puStack_1c = (uint *)(*(int *)(iStack_14 + 0x10) + 0x128);
  FUN_00587410();
  iVar7 = *(int *)(iStack_14 + 0x10);
  iStack_34 = iVar7 + 0x130;
  uStack_8._0_1_ = 2;
  uStack_2c = FUN_005f7a90(auStack_2dc);
  FUN_006b0560(&iStack_30,uStack_2c,auStack_2dc);
  if (iStack_30 == 0) {
    puStack_24 = (undefined4 *)0x0;
    uStack_28 = -(uint)(iVar7 != -0x133) & iVar7 + 0x134U;
    uStack_8._0_1_ = 3;
    uStack_20 = 0;
    puStack_24 = (undefined4 *)FUN_01674e20(0x270);
    puVar5 = puStack_24 + 2;
    *puStack_24 = 0;
    puStack_24[1] = 0;
    FUN_0170d1f0(puVar5,0,0x268);
    uStack_20 = 0x101;
    puVar8 = auStack_2dc;
    for (iVar7 = 0x9a; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar5 = *puVar8;
      puVar8 = puVar8 + 1;
      puVar5 = puVar5 + 1;
    }
    FUN_005d99d0(*(int *)(iStack_34 + 8) + 1);
    FUN_005c5550(&uStack_2c,&uStack_28,uStack_2c);
    uStack_8._0_1_ = 2;
    if (puStack_24 != (undefined4 *)0x0) {
      FUN_01674ea0(puStack_24,0x270);
    }
  }
  iVar7 = FUN_006af570(&param_1);
  auStack_54[0] = 0;
  if (param_9 != 0) {
    auStack_54[0] = param_9;
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_4c,0);
    }
    else {
      uStack_4c = param_11;
      uStack_48 = param_12;
      uStack_44 = param_13;
      uStack_40 = param_14;
      uStack_3c = param_15;
    }
  }
  if ((uint *)(iVar7 + 0x20) != auStack_54) {
    auStack_74[0] = 0;
    uStack_8._0_1_ = 5;
    FUN_005880d0(auStack_54);
    FUN_005880d0((uint *)(iVar7 + 0x20));
    FUN_005880d0(auStack_74);
    uStack_8._0_1_ = 6;
    if (((auStack_74[0] != 0) && ((auStack_74[0] & 1) == 0)) &&
       (*(code **)(auStack_74[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_74[0] & 0xfffffffe))(auStack_6c,auStack_6c,2);
    }
  }
  uStack_8._0_1_ = 7;
  if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
     (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_54[0] & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  uStack_8._0_1_ = 2;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (param_9 == 0) {
    uStack_8._0_1_ = uVar4;
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  (**(code **)((param_9 & 0xfffffffe) + 4))(&param_11,auStack_2bc);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if ((char)piStack_18 != '\0') {
    LOCK();
    uVar2 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  uStack_8 = 10;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8775 ; VA 0x006b0200 ; FUN_006b0200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006b0200(int param_1,int param_2)

{
  short sVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dStack_c;
  
  if (*(int *)(param_1 + 0x188) < param_2) {
    dStack_c = 0.0;
    sVar1 = FUN_017265ed(&dStack_c);
    if (0 < sVar1) goto LAB_006b03c3;
    dVar5 = *(double *)(param_1 + 0x160);
    dVar4 = DAT_018c0d60 - dVar5;
    if (*(char *)(param_1 + 0x180) == '\0') {
      dVar3 = 0.0;
      dVar2 = *(double *)(param_1 + 0x170) * dVar4 + dVar5 * _PTR_018c6f48;
    }
    else {
      dVar3 = 0.0;
      dVar2 = 0.0;
    }
  }
  else {
    if (param_2 == 0) {
      dStack_c = DAT_018c0d60;
      sVar1 = FUN_017265ed(&dStack_c);
      dVar5 = DAT_018c0d60;
      if (sVar1 < 1) {
        dVar3 = *(double *)(param_1 + 0x160);
        dVar4 = DAT_018c0d60 - dVar3;
        dVar2 = DAT_018c0d60;
        if (*(char *)(param_1 + 0x180) == '\0') {
          dVar2 = *(double *)(param_1 + 0x170) * dVar4 + dVar3;
        }
        *(double *)(param_1 + 0x168) = DAT_018c0d60;
        *(double *)(param_1 + 0x170) = dVar2;
        *(undefined *)(param_1 + 0x180) = 0;
        *(double *)(param_1 + 0x178) =
             (dVar5 - dVar2) * (dVar5 - dVar2) * dVar3 + *(double *)(param_1 + 0x178) * dVar4;
        *(undefined4 *)(param_1 + 0x188) = 0;
        return;
      }
      goto LAB_006b03c3;
    }
    dStack_c = _PTR_018cf0f8;
    sVar1 = FUN_017265ed(&dStack_c);
    if (0 < sVar1) goto LAB_006b03c3;
    dVar5 = *(double *)(param_1 + 0x160);
    dVar4 = DAT_018c0d60 - dVar5;
    dVar3 = _PTR_018cf0f8;
    dVar2 = _PTR_018cf0f8;
    if (*(char *)(param_1 + 0x180) == '\0') {
      dVar2 = *(double *)(param_1 + 0x170) * dVar4 + dVar5 * _PTR_018cf0f8;
    }
  }
  *(double *)(param_1 + 0x168) = dVar3;
  *(double *)(param_1 + 0x178) =
       (dVar3 - dVar2) * (dVar3 - dVar2) * dVar5 + dVar4 * *(double *)(param_1 + 0x178);
  *(undefined *)(param_1 + 0x180) = 0;
  *(double *)(param_1 + 0x170) = dVar2;
LAB_006b03c3:
  *(int *)(param_1 + 0x188) = param_2;
  return;
}



/* FUNCTION 8776 ; VA 0x006b03e0 ; FUN_006b03e0 */

void __fastcall FUN_006b03e0(int param_1)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == 0) {
    ExceptionList = &pvStack_10;
    *(undefined2 *)(param_1 + 8) = 0;
    puVar3 = (undefined4 *)FUN_01674e20(0x48);
    *(undefined4 **)(param_1 + 4) = puVar3;
    *puVar3 = 0;
    puVar3[1] = 0;
    FUN_0170d1f0(puVar3 + 2,0,0x40);
    *(undefined *)(param_1 + 8) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  if (*(char *)(param_1 + 9) != '\0') {
    uVar2 = *(uint *)(iVar1 + 0x28);
    uStack_8 = 0;
    if (uVar2 != 0) {
      if ((uVar2 & 1) == 0) {
        if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
          ExceptionList = &pvStack_10;
          (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x30,iVar1 + 0x30,2);
        }
      }
      *(undefined4 *)(iVar1 + 0x28) = 0;
    }
    *(undefined *)(param_1 + 9) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8777 ; VA 0x006b0490 ; FUN_006b0490 */

int __thiscall FUN_006b0490(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_01674ea0(puVar1,0x270);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 8778 ; VA 0x006b04d0 ; FUN_006b04d0 */

int __thiscall FUN_006b04d0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar3 = 0;
  puVar2 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  do {
    *param_2 = *puVar2;
    uVar1 = puVar2[10];
    uStack_8 = 0;
    if (uVar1 != 0) {
      if ((uVar1 & 1) == 0) {
        if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar1 & 0xfffffffe))(puVar2 + 0xc,puVar2 + 0xc,2);
        }
      }
      puVar2[10] = 0;
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(puVar2,0x48);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar3 = iVar3 + 1;
    puVar2 = (undefined4 *)*param_2;
  } while (puVar2 != param_3);
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 8779 ; VA 0x006b0560 ; FUN_006b0560 */

void __thiscall FUN_006b0560(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_005f71d0(piVar4 + 2);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 8780 ; VA 0x006b05f0 ; FUN_006b05f0 */

undefined8 __fastcall FUN_006b05f0(undefined8 *param_1)

{
  undefined8 uVar1;
  undefined4 *puVar2;
  undefined auStack_c [8];
  
  uVar1 = *param_1;
  *(undefined4 *)param_1 = 0;
  *(undefined4 *)((int)param_1 + 4) = 0;
  puVar2 = (undefined4 *)FUN_016830f0(auStack_c);
  *(undefined4 *)(param_1 + 1) = *puVar2;
  *(undefined4 *)((int)param_1 + 0xc) = puVar2[1];
  return uVar1;
}



/* FUNCTION 8781 ; VA 0x006b0630 ; FUN_006b0630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 __fastcall FUN_006b0630(undefined4 *param_1)

{
  double dVar1;
  double dVar2;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_016830f0(&uStack_c);
  dVar1 = (double)CONCAT44(uStack_8,uStack_c) - *(double *)(param_1 + 2);
  if (_PTR_018c6f48 < dVar1) {
    dVar2 = dVar1;
    FUN_016f3fe0();
    param_1[2] = uStack_c;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[3] = uStack_8;
    return (float10)(dVar2 / dVar1);
  }
  return (float10)0;
}



/* FUNCTION 8782 ; VA 0x006b06a0 ; FUN_006b06a0 */

int __thiscall FUN_006b06a0(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  int *piVar2;
  undefined uVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  int iVar18;
  uint uVar19;
  int *piVar20;
  undefined4 uStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6878;
  pvStack_10 = ExceptionList;
  piVar20 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar20 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar20[1] = piVar20[1] + 1;
    UNLOCK();
    piVar20 = (int *)param_2[1];
  }
  uVar5 = *param_2;
  uVar9 = param_2[5];
  uVar10 = param_2[6];
  uVar11 = param_2[7];
  uVar12 = param_2[8];
  uVar6 = param_2[2];
  uVar7 = param_2[3];
  uVar3 = *(undefined *)(param_2 + 4);
  uVar13 = param_2[9];
  uVar14 = param_2[10];
  uVar15 = param_2[0xb];
  uVar16 = param_2[0xc];
  uVar4 = *(undefined *)(param_2 + 0xd);
  uStack_8 = 0;
  FUN_01682800(&uStack_1c);
  puVar1 = (uint *)(param_1 + 0x14);
  do {
    LOCK();
    uVar19 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar19 & 1) != 0);
  uStack_8 = 2;
  if (*(int *)(param_1 + 0x10) == 0) {
    *(ulonglong *)(param_1 + 0x18) = CONCAT44(iStack_18,uStack_1c);
  }
  uVar19 = *(uint *)(param_1 + 8);
  puStack_14 = puVar1;
  if (uVar19 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_006afce0(1);
    uVar19 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar19 - 1;
  uVar19 = *(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U;
  iVar18 = *(int *)(param_1 + 4);
  if (*(int *)(iVar18 + uVar19 * 4) == 0) {
    uVar17 = FUN_01674e20(0x40);
    *(undefined4 *)(*(int *)(param_1 + 4) + uVar19 * 4) = uVar17;
    iVar18 = *(int *)(param_1 + 4);
  }
  puVar8 = *(undefined4 **)(iVar18 + uVar19 * 4);
  *puVar8 = 0;
  puVar8[1] = 0;
  if (piVar20 != (int *)0x0) {
    LOCK();
    piVar20[1] = piVar20[1] + 1;
    UNLOCK();
  }
  *puVar8 = uVar5;
  puVar8[1] = piVar20;
  puVar8[2] = uVar6;
  puVar8[3] = uVar7;
  *(undefined *)(puVar8 + 4) = uVar3;
  puVar8[5] = uVar9;
  puVar8[6] = uVar10;
  puVar8[7] = uVar11;
  puVar8[8] = uVar12;
  puVar8[9] = uVar13;
  puVar8[10] = uVar14;
  puVar8[0xb] = uVar15;
  puVar8[0xc] = uVar16;
  *(undefined *)(puVar8 + 0xd) = uVar4;
  puVar8[0xe] = uStack_1c;
  puVar8[0xf] = iStack_18;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  *puVar1 = 0;
  if (piVar20 != (int *)0x0) {
    LOCK();
    piVar2 = piVar20 + 1;
    iVar18 = *piVar2;
    iStack_18 = *piVar2;
    *piVar2 = iVar18 + -1;
    UNLOCK();
    if (iVar18 + -1 == 0) {
      iStack_18 = (**(code **)*piVar20)();
      LOCK();
      piVar2 = piVar20 + 2;
      iVar18 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar18 == 1) {
        iStack_18 = (**(code **)(*piVar20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 8783 ; VA 0x006b0840 ; FUN_006b0840 */

/* WARNING: Removing unreachable block (ram,0x006b09e3) */
/* WARNING: Removing unreachable block (ram,0x006b09f6) */
/* WARNING: Removing unreachable block (ram,0x006b09fd) */
/* WARNING: Removing unreachable block (ram,0x006b0a04) */

undefined4 * __fastcall FUN_006b0840(undefined4 *param_1)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ae98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar1 = param_1[4];
  uStack_8 = 0;
  if (*(int *)(iVar1 + 0x138) != 0) {
    uVar3 = FUN_005f7a90(&stack0x00000004);
    uVar6 = uVar3 % *(uint *)(iVar1 + 0x134);
    piVar8 = *(int **)(uVar6 * 4 + *(int *)(iVar1 + 0x144));
    if ((piVar8 != (int *)0x0) && (iVar5 = *piVar8, iVar5 != 0)) {
      while (*(uint *)(iVar5 + 4) % *(uint *)(iVar1 + 0x134) == uVar6) {
        if ((*(uint *)(iVar5 + 4) == uVar3) && (cVar2 = FUN_005f71d0(iVar5 + 8), cVar2 != '\0')) {
          FUN_006b0490(piVar8,*(undefined4 *)*piVar8);
          if (*piVar8 != 0) {
            uVar3 = *(uint *)(*piVar8 + 4) % *(uint *)(iVar1 + 0x134);
            if (uVar6 == uVar3) break;
            *(int **)(*(int *)(iVar1 + 0x144) + uVar3 * 4) = piVar8;
          }
          puVar4 = (undefined4 *)(*(int *)(iVar1 + 0x144) + uVar6 * 4);
          if ((int *)*puVar4 == piVar8) {
            *puVar4 = 0;
          }
          break;
        }
        piVar8 = (int *)*piVar8;
        iVar5 = *piVar8;
        if (iVar5 == 0) break;
      }
    }
  }
  iVar1 = param_1[4];
  if (*(int *)(iVar1 + 0x150) != 0) {
    uVar3 = FUN_005f7c20(&stack0x00000004);
    uVar6 = uVar3 % *(uint *)(iVar1 + 0x14c);
    puVar4 = (undefined4 *)(uVar6 * 4);
    piVar8 = *(int **)((int)puVar4 + *(int *)(iVar1 + 0x15c));
    param_1 = puVar4;
    if ((piVar8 != (int *)0x0) && (iVar5 = *piVar8, iVar5 != 0)) {
      while( true ) {
        uVar7 = *(uint *)(iVar5 + 4);
        param_1 = (undefined4 *)(uVar7 / *(uint *)(iVar1 + 0x14c));
        if (uVar7 % *(uint *)(iVar1 + 0x14c) != uVar6) break;
        if ((uVar7 == uVar3) &&
           (param_1 = (undefined4 *)FUN_005f71d0(iVar5 + 8), (char)param_1 != '\0')) {
          FUN_006b04d0(piVar8,*(undefined4 *)*piVar8);
          if (*piVar8 != 0) {
            uVar3 = *(uint *)(*piVar8 + 4);
            uVar7 = uVar3 % *(uint *)(iVar1 + 0x14c);
            if (uVar6 == uVar7) {
              ExceptionList = pvStack_10;
              return (undefined4 *)(uVar3 / *(uint *)(iVar1 + 0x14c));
            }
            *(int **)(*(int *)(iVar1 + 0x15c) + uVar7 * 4) = piVar8;
          }
          puVar4 = (undefined4 *)(*(int *)(iVar1 + 0x15c) + (int)puVar4);
          if ((int *)*puVar4 != piVar8) {
            ExceptionList = pvStack_10;
            return puVar4;
          }
          *puVar4 = 0;
          ExceptionList = pvStack_10;
          return puVar4;
        }
        piVar8 = (int *)*piVar8;
        iVar5 = *piVar8;
        if (iVar5 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8784 ; VA 0x006b0a20 ; FUN_006b0a20 */

undefined4 __fastcall FUN_006b0a20(int param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  code *pcVar9;
  uint uVar10;
  int *piVar11;
  undefined8 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined2 uVar15;
  code *pcStack_74;
  undefined auStack_64 [32];
  undefined uStack_44;
  undefined3 uStack_43;
  int *piStack_40;
  int *piStack_3c;
  code *pcStack_38;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  uint *puStack_28;
  code *pcStack_24;
  code *pcStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a68b8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x138) != 0) {
    ExceptionList = &pvStack_10;
    piStack_14 = (int *)(param_1 + 0x128);
    FUN_00587490(&piStack_40);
    uStack_8 = 0;
    piStack_18 = piStack_40;
    if (piStack_40 == (int *)0x0) {
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar11 = piStack_3c + 2;
          iVar7 = *piVar11;
          *piVar11 = *piVar11 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piStack_3c + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 0;
    }
    pcStack_74 = (code *)0x0;
    uStack_8 = 1;
    FUN_005f7140();
    puVar1 = (uint *)(param_1 + 0x13c);
    piVar11 = (int *)(param_1 + 0x128);
    puStack_28 = puVar1;
    while( true ) {
      do {
        LOCK();
        uVar10 = *puVar1;
        *puVar1 = *puVar1 | 1;
        UNLOCK();
      } while ((uVar10 & 1) != 0);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (piVar11[4] == 0) break;
      if ((piVar11 == (int *)0x0) || ((int *)*piVar11 == (int *)0x0)) {
        iVar7 = 0;
      }
      else {
        iVar7 = *(int *)*piVar11;
      }
      puStack_1c = *(undefined4 **)
                    (*(int *)(iVar7 + 4) + (*(int *)(iVar7 + 8) - 1U & piVar11[3]) * 4);
      pcVar9 = (code *)puStack_1c[1];
      if (pcVar9 != (code *)0x0) {
        LOCK();
        *(int *)(pcVar9 + 4) = *(int *)(pcVar9 + 4) + 1;
        UNLOCK();
        pcVar9 = (code *)puStack_1c[1];
      }
      pcVar4 = (code *)*puStack_1c;
      pcStack_24 = pcStack_74;
      pcStack_30 = pcVar9;
      pcStack_2c = pcVar4;
      pcStack_20 = pcVar9;
      if (pcStack_74 != (code *)0x0) {
        LOCK();
        iVar7 = *(int *)(pcStack_74 + 4) + -1;
        *(int *)(pcStack_74 + 4) = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (*(code *)**(undefined4 **)pcStack_74)();
          LOCK();
          iVar7 = *(int *)(pcStack_24 + 8) + -1;
          *(int *)(pcStack_24 + 8) = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*(int *)pcStack_24 + 4))();
          }
        }
      }
      uVar5 = puStack_1c[2];
      uVar6 = puStack_1c[3];
      uVar3 = *(undefined *)(puStack_1c + 4);
      FUN_005f7170(puStack_1c + 5);
      _uStack_44 = CONCAT31(uStack_43,*(undefined *)(puStack_1c + 0xd));
      pcStack_24 = *(code **)(*(int *)(piVar11[1] + (piVar11[2] - 1U & piVar11[3]) * 4) + 4);
      if (pcStack_24 != (code *)0x0) {
        LOCK();
        iVar7 = *(int *)((int)pcStack_24 + 4) + -1;
        *(int *)((int)pcStack_24 + 4) = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (*(code *)**(undefined4 **)pcStack_24)();
          LOCK();
          iVar7 = *(int *)((int)pcStack_24 + 8) + -1;
          *(int *)((int)pcStack_24 + 8) = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*(int *)pcStack_24 + 4))();
          }
        }
      }
      piVar2 = piVar11 + 4;
      *piVar2 = *piVar2 + -1;
      if (*piVar2 == 0) {
        piVar11[3] = 0;
        uVar10 = 0;
      }
      else {
        piVar11[3] = piVar11[3] + 1;
        uVar10 = piVar11[3];
      }
      if (piVar11[4] == 0) {
        uVar12 = 0;
      }
      else {
        puVar8 = (undefined4 *)*piVar11;
        if (puVar8 != (undefined4 *)0x0) {
          puVar8 = (undefined4 *)*puVar8;
        }
        uVar12 = *(undefined8 *)(*(int *)(puVar8[1] + (puVar8[2] - 1 & uVar10) * 4) + 0x38);
      }
      *(undefined8 *)(piVar11 + 6) = uVar12;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      *puVar1 = 0;
      pcStack_74 = pcVar9;
      if (DAT_01d5b380 == '\0') {
        pcStack_20 = *(code **)(*piStack_18 + 0x4c);
        pcStack_24 = pcVar4;
        FUN_005f70a0();
        FUN_005f7140();
        uVar13 = DAT_01d5b370;
        uVar14 = DAT_01d5b374;
        uVar15 = DAT_01d5b378;
        FUN_005f7170(auStack_64);
        (*pcStack_20)(pcStack_24,uVar5,uVar6,uVar3,uVar13,uVar14,uVar15);
        piVar11 = piStack_14;
      }
      else {
        if (pcVar9 != (code *)0x0) {
          LOCK();
          *(int *)(pcVar9 + 4) = *(int *)(pcVar9 + 4) + 1;
          UNLOCK();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        pcStack_24 = *(code **)(*piStack_18 + 0x48);
        pcStack_38 = pcVar4;
        pcStack_34 = pcVar9;
        FUN_005f70a0();
        FUN_005f7140();
        uVar13 = DAT_01d5b370;
        uVar14 = DAT_01d5b374;
        uVar15 = DAT_01d5b378;
        FUN_005f7170(auStack_64);
        (*pcStack_24)(&pcStack_38,uVar5,uVar6,uVar3,uVar13,uVar14,uVar15);
        piVar11 = piStack_14;
        pcStack_24 = pcStack_34;
        if (pcStack_34 != (code *)0x0) {
          LOCK();
          iVar7 = *(int *)(pcStack_34 + 4) + -1;
          *(int *)(pcStack_34 + 4) = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (*(code *)**(undefined4 **)pcStack_34)();
            LOCK();
            iVar7 = *(int *)(pcStack_24 + 8) + -1;
            *(int *)(pcStack_24 + 8) = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*(int *)pcStack_24 + 4))();
            }
          }
        }
      }
    }
    *puVar1 = 0;
    if (pcStack_74 != (code *)0x0) {
      LOCK();
      iVar7 = *(int *)(pcStack_74 + 4) + -1;
      *(int *)(pcStack_74 + 4) = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (*(code *)**(undefined4 **)pcStack_74)();
        LOCK();
        iVar7 = *(int *)(pcStack_74 + 8) + -1;
        *(int *)(pcStack_74 + 8) = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*(int *)pcStack_74 + 4))();
        }
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar11 = piStack_3c + 2;
        iVar7 = *piVar11;
        *piVar11 = *piVar11 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piStack_3c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8785 ; VA 0x006b0dc0 ; FUN_006b0dc0 */

undefined4 __thiscall FUN_006b0dc0(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  float10 fVar6;
  undefined8 uStack_2c;
  uint *puStack_24;
  char cStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a68e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  fVar6 = (float10)FUN_00a36320(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x198),
                                0x3f800000,0x3f800000);
  uStack_2c = (double)fVar6;
  if (uStack_2c < DAT_018c0d60) {
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_00587490(&uStack_2c);
  uStack_8 = 0;
  if ((int)uStack_2c == 0) {
    piVar5 = uStack_2c._4_4_;
    if (uStack_2c._4_4_ != (int *)0x0) {
      LOCK();
      iVar4 = uStack_2c._4_4_[1] + -1;
      uStack_2c._4_4_[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*uStack_2c._4_4_)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  puStack_24 = (uint *)(param_1 + 0x128);
  cStack_20 = '\0';
  FUN_00587410();
  iVar4 = 0;
  uStack_8._0_1_ = 1;
  param_2 = 0;
  if (*(int *)(param_1 + 0x138) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5 = *(int **)(*(int *)(param_1 + 0x144) + *(int *)(param_1 + 0x134) * 4);
  }
  if (piVar5 != (int *)0x0) {
    iStack_18 = param_1 + 0x148;
    do {
      FUN_006b11a0(piVar5 + 2,SUB84(uStack_2c,0));
      iVar4 = param_2 + piVar5[0x6d] + piVar5[0x6c] + piVar5[0x6b] + piVar5[0x6a];
      param_1 = param_1 + *(byte *)(param_1 + 0x148) + 0x149;
      uVar3 = FUN_005f7c20();
      FUN_006aebc0(&iStack_1c,uVar3,piVar5 + 2,-(uint)(param_1 != 0) & param_1 + 1U);
      if (iStack_1c != 0) {
        if (*(uint *)(iStack_1c + 0x28) == 0) {
          FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0();
        }
        (**(code **)((*(uint *)(iStack_1c + 0x28) & 0xfffffffe) + 4))();
      }
      piVar5 = (int *)*piVar5;
      param_1 = iStack_14;
      param_2 = iVar4;
    } while (piVar5 != (int *)0x0);
  }
  FUN_006b0200(iVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (cStack_20 != '\0') {
    LOCK();
    uVar2 = *puStack_24;
    *puStack_24 = *puStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_24;
      *puStack_24 = *puStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  piVar5 = uStack_2c._4_4_;
  if (uStack_2c._4_4_ != (int *)0x0) {
    LOCK();
    iVar4 = uStack_2c._4_4_[1] + -1;
    uStack_2c._4_4_[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*uStack_2c._4_4_)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8786 ; VA 0x006b1010 ; FUN_006b1010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006b1010(int param_1,int param_2)

{
  short sVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dStack_c;
  
  if (*(int *)(param_1 + 0x40) < param_2) {
    dStack_c = 0.0;
    sVar1 = FUN_017265ed(&dStack_c);
    if (0 < sVar1) goto LAB_006b1190;
    dVar5 = *(double *)(param_1 + 0x18);
    dVar4 = DAT_018c0d60 - dVar5;
    if (*(char *)(param_1 + 0x38) == '\0') {
      dVar3 = 0.0;
      dVar2 = *(double *)(param_1 + 0x28) * dVar4 + dVar5 * _PTR_018c6f48;
    }
    else {
      dVar3 = 0.0;
      dVar2 = 0.0;
    }
  }
  else {
    if (param_2 == 0) {
      dStack_c = DAT_018c0d60;
      sVar1 = FUN_017265ed(&dStack_c);
      dVar5 = DAT_018c0d60;
      if (sVar1 < 1) {
        dVar3 = *(double *)(param_1 + 0x18);
        dVar4 = DAT_018c0d60 - dVar3;
        dVar2 = DAT_018c0d60;
        if (*(char *)(param_1 + 0x38) == '\0') {
          dVar2 = *(double *)(param_1 + 0x28) * dVar4 + dVar3;
        }
        *(double *)(param_1 + 0x20) = DAT_018c0d60;
        *(double *)(param_1 + 0x28) = dVar2;
        *(undefined *)(param_1 + 0x38) = 0;
        *(double *)(param_1 + 0x30) =
             (dVar5 - dVar2) * (dVar5 - dVar2) * dVar3 + *(double *)(param_1 + 0x30) * dVar4;
        *(undefined4 *)(param_1 + 0x40) = 0;
        return;
      }
      goto LAB_006b1190;
    }
    dStack_c = _PTR_018cf0f8;
    sVar1 = FUN_017265ed(&dStack_c);
    if (0 < sVar1) goto LAB_006b1190;
    dVar5 = *(double *)(param_1 + 0x18);
    dVar4 = DAT_018c0d60 - dVar5;
    dVar3 = _PTR_018cf0f8;
    dVar2 = _PTR_018cf0f8;
    if (*(char *)(param_1 + 0x38) == '\0') {
      dVar2 = *(double *)(param_1 + 0x28) * dVar4 + dVar5 * _PTR_018cf0f8;
    }
  }
  *(double *)(param_1 + 0x20) = dVar3;
  *(double *)(param_1 + 0x30) =
       (dVar3 - dVar2) * (dVar3 - dVar2) * dVar5 + dVar4 * *(double *)(param_1 + 0x30);
  *(undefined *)(param_1 + 0x38) = 0;
  *(double *)(param_1 + 0x28) = dVar2;
LAB_006b1190:
  *(int *)(param_1 + 0x40) = param_2;
  return;
}



/* FUNCTION 8787 ; VA 0x006b11a0 ; FUN_006b11a0 */

void FUN_006b11a0(undefined4 *param_1,int *param_2)

{
  code *pcVar1;
  short sVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  float fVar8;
  undefined4 uVar9;
  double dVar10;
  double dVar11;
  double dVar12;
  undefined2 uVar13;
  double dStack_1c;
  double dStack_14;
  double dStack_c;
  
  if (DAT_01eace3a != '\0') {
    FUN_016774b0(DAT_01eace3a,"updateStatsJob::updateStats running",0);
  }
  uVar3 = (**(code **)(*param_2 + 0xd8))
                    (*param_1,param_1[1],param_1[2],param_1[3],param_1[4],param_1[5],param_1[6],
                     param_1[7]);
  param_1[8] = uVar3;
  pcVar1 = *(code **)(*param_2 + 0x98);
  FUN_005f70a0();
  FUN_005f7140();
  uVar3 = DAT_01d5b370;
  uVar9 = DAT_01d5b374;
  uVar13 = DAT_01d5b378;
  FUN_005f7170(param_1);
  uVar3 = (*pcVar1)(uVar3,uVar9,uVar13);
  param_1[9] = uVar3;
  pcVar1 = *(code **)(*param_2 + 0x9c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar3 = DAT_01d5b370;
  uVar9 = DAT_01d5b374;
  uVar13 = DAT_01d5b378;
  FUN_005f7170(param_1);
  uVar3 = (*pcVar1)(uVar3,uVar9,uVar13);
  param_1[10] = uVar3;
  pcVar1 = *(code **)(*param_2 + 0xa0);
  FUN_005f70a0();
  FUN_005f7140();
  uVar3 = DAT_01d5b370;
  uVar9 = DAT_01d5b374;
  uVar13 = DAT_01d5b378;
  FUN_005f7170(param_1);
  uVar3 = (*pcVar1)(uVar3,uVar9,uVar13);
  param_1[0xb] = uVar3;
  puVar4 = (undefined4 *)
           (**(code **)(*param_2 + 0x134))
                     (*param_1,param_1[1],param_1[2],param_1[3],param_1[4],param_1[5],param_1[6],
                      param_1[7],0);
  if (puVar4 != (undefined4 *)0x0) {
    if (DAT_01eace3a != '\0') {
      FUN_016774b0(DAT_01eace3a,"updateStatsJob rakStats ACTUAL_BYTES_RECEIVE: %d",puVar4[0x1a]);
    }
    puVar6 = puVar4;
    puVar7 = param_1 + 0x42;
    for (iVar5 = 0x58; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar7 = *puVar6;
      puVar6 = puVar6 + 1;
      puVar7 = puVar7 + 1;
    }
    fVar8 = (float)puVar4[0x36];
    if ((float)puVar4[0x36] <= (float)param_1[0xc]) {
      fVar8 = (float)param_1[0xc];
    }
    param_1[0xc] = fVar8;
    uVar3 = 0;
    uVar9 = 0;
    dStack_14 = 0.0;
    if (*(char *)(puVar4 + 0x22) != '\0') {
      uVar3 = SUB84(DAT_018c0d60,0);
      uVar9 = (undefined4)((ulonglong)DAT_018c0d60 >> 0x20);
    }
    dStack_c = (double)CONCAT44(uVar9,uVar3);
    dStack_1c = (double)CONCAT44(uVar9,uVar3);
    sVar2 = FUN_017265ed(&dStack_1c);
    if (sVar2 < 1) {
      dVar12 = *(double *)(param_1 + 0x1a);
      dVar11 = DAT_018c0d60 - dVar12;
      dVar10 = dStack_c;
      if (*(char *)(param_1 + 0x22) == '\0') {
        dVar10 = *(double *)(param_1 + 0x1e) * dVar11 + dVar12 * dStack_c;
      }
      *(double *)(param_1 + 0x1c) = dStack_c;
      *(undefined *)(param_1 + 0x22) = 0;
      *(double *)(param_1 + 0x1e) = dVar10;
      *(double *)(param_1 + 0x20) =
           (dStack_c - dVar10) * (dStack_c - dVar10) * dVar12 + *(double *)(param_1 + 0x20) * dVar11
      ;
    }
    if (*(char *)(puVar4 + 0x1e) == '\0') {
      uVar3 = 0;
      uVar9 = 0;
    }
    else {
      uVar3 = SUB84(DAT_018c0d60,0);
      uVar9 = (undefined4)((ulonglong)DAT_018c0d60 >> 0x20);
      dStack_14 = DAT_018c0d60;
    }
    dStack_1c = (double)CONCAT44(uVar9,uVar3);
    sVar2 = FUN_017265ed(&dStack_1c);
    dVar12 = (double)CONCAT44(uVar9,uVar3);
    if (sVar2 < 1) {
      dVar10 = *(double *)(param_1 + 0x24);
      dVar12 = DAT_018c0d60 - dVar10;
      dVar11 = dStack_14;
      if (*(char *)(param_1 + 0x2c) == '\0') {
        dVar11 = *(double *)(param_1 + 0x28) * dVar12 + dVar10 * dStack_14;
      }
      *(double *)(param_1 + 0x26) = dStack_14;
      dVar12 = *(double *)(param_1 + 0x2a) * dVar12;
      *(undefined *)(param_1 + 0x2c) = 0;
      *(double *)(param_1 + 0x28) = dVar11;
      *(double *)(param_1 + 0x2a) = (dStack_14 - dVar11) * (dStack_14 - dVar11) * dVar10 + dVar12;
    }
    FUN_016f3fe0();
    dVar12 = (double)((float)dVar12 / DAT_018ce324);
    dStack_1c = dVar12;
    dStack_14 = dVar12;
    sVar2 = FUN_017265ed(&dStack_1c);
    if (sVar2 < 1) {
      dVar10 = *(double *)(param_1 + 0x2e);
      dVar12 = DAT_018c0d60 - dVar10;
      dVar11 = dStack_14;
      if (*(char *)(param_1 + 0x36) == '\0') {
        dVar11 = *(double *)(param_1 + 0x32) * dVar12 + dVar10 * dStack_14;
      }
      *(double *)(param_1 + 0x30) = dStack_14;
      dVar12 = *(double *)(param_1 + 0x34) * dVar12;
      *(undefined *)(param_1 + 0x36) = 0;
      *(double *)(param_1 + 0x32) = dVar11;
      *(double *)(param_1 + 0x34) = (dStack_14 - dVar11) * (dStack_14 - dVar11) * dVar10 + dVar12;
    }
    FUN_016f3fe0();
    dStack_1c = (double)((float)dVar12 / DAT_018ce324);
    dStack_14 = dStack_1c;
    sVar2 = FUN_017265ed(&dStack_1c);
    if (sVar2 < 1) {
      dVar12 = *(double *)(param_1 + 0x38);
      dVar11 = DAT_018c0d60 - dVar12;
      dVar10 = dStack_14;
      if (*(char *)(param_1 + 0x40) == '\0') {
        dVar10 = *(double *)(param_1 + 0x3c) * dVar11 + dVar12 * dStack_14;
      }
      *(undefined *)(param_1 + 0x40) = 0;
      *(double *)(param_1 + 0x3a) = dStack_14;
      *(double *)(param_1 + 0x3c) = dVar10;
      *(double *)(param_1 + 0x3e) =
           (dStack_14 - dVar10) * (dStack_14 - dVar10) * dVar12 +
           dVar11 * *(double *)(param_1 + 0x3e);
    }
    FUN_006b1010(puVar4[0x29] + puVar4[0x28] + puVar4[0x27] + puVar4[0x26]);
  }
  return;
}



/* FUNCTION 8788 ; VA 0x006b1620 ; FUN_006b1620 */

undefined *
FUN_006b1620(undefined *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  char *pcVar2;
  char acStack_408 [1028];
  
  if (DAT_01d5b1e4 == '\0') {
    FUN_005f7b20(param_3,acStack_408,0x401,param_4);
    pcVar2 = acStack_408;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
  }
  else {
    FUN_005f7b20(param_3,acStack_408,0x401,param_4);
    pcVar2 = acStack_408;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
  }
  FUN_005542c0(acStack_408,(int)pcVar2 - (int)(acStack_408 + 1));
  return param_1;
}



/* FUNCTION 8789 ; VA 0x006b16c0 ; FUN_006b16c0 */

undefined4 FUN_006b16c0(byte *param_1,int param_2,undefined4 *param_3)

{
  byte *pbVar1;
  uint uVar2;
  byte *pbVar3;
  int iVar4;
  byte *pbVar5;
  uint uVar6;
  byte *pbVar7;
  undefined4 uVar8;
  bool bVar9;
  undefined auStack_3c [8];
  undefined4 uStack_34;
  byte *pbStack_30;
  byte *pbStack_20;
  byte *pbStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_2;
  pbVar3 = param_1;
  puStack_c = &LAB_017a6908;
  pvStack_10 = ExceptionList;
  if (((*(int *)(param_1 + 0x10) == 0) || (*(int *)(param_2 + 0x10) == 0)) || (param_3[4] == 0)) {
    return 0xffffffff;
  }
  pbStack_20 = (byte *)0x0;
  pbStack_1c = (byte *)0x0;
  uStack_18 = 0;
  uStack_8 = 0;
  param_1 = (byte *)param_3;
  if (0xf < (uint)param_3[5]) {
    param_1 = (byte *)*param_3;
  }
  pbStack_30 = (byte *)0x1;
  ExceptionList = &pvStack_10;
  FUN_0064f1d0(auStack_3c,&param_1);
  FUN_0064fa20(&pbStack_20,iVar4);
  pbVar1 = pbStack_20;
  if ((((int)pbStack_1c - (int)pbStack_20) / 0x18 & 1U) == 0) {
    for (; pbVar1 != pbStack_1c; pbVar1 = pbVar1 + 0x30) {
      pbVar5 = pbVar3;
      if (0xf < *(uint *)(pbVar3 + 0x14)) {
        pbVar5 = *(byte **)pbVar3;
      }
      uVar6 = *(uint *)(pbVar1 + 0x10);
      pbVar7 = pbVar1;
      if (0xf < *(uint *)(pbVar1 + 0x14)) {
        pbVar7 = *(byte **)pbVar1;
      }
      if (uVar6 == *(uint *)(pbVar3 + 0x10)) {
        while (uVar2 = uVar6 - 4, 3 < uVar6) {
          if (*(int *)pbVar7 != *(int *)pbVar5) goto LAB_006b17a7;
          pbVar7 = pbVar7 + 4;
          pbVar5 = pbVar5 + 4;
          uVar6 = uVar2;
        }
        if (uVar2 == 0xfffffffc) {
LAB_006b17db:
          uVar6 = 0;
        }
        else {
LAB_006b17a7:
          bVar9 = *pbVar7 < *pbVar5;
          if ((*pbVar7 == *pbVar5) &&
             ((uVar2 == 0xfffffffd ||
              ((bVar9 = pbVar7[1] < pbVar5[1], pbVar7[1] == pbVar5[1] &&
               ((uVar2 == 0xfffffffe ||
                ((bVar9 = pbVar7[2] < pbVar5[2], pbVar7[2] == pbVar5[2] &&
                 ((uVar2 == 0xffffffff || (bVar9 = pbVar7[3] < pbVar5[3], pbVar7[3] == pbVar5[3]))))
                )))))))) goto LAB_006b17db;
          uVar6 = -(uint)bVar9 | 1;
        }
        if (uVar6 == 0) {
          pbStack_30 = pbVar1 + 0x18;
          if (0xf < *(uint *)(pbVar1 + 0x2c)) {
            pbStack_30 = *(byte **)pbStack_30;
          }
          uStack_34 = 0x6b1818;
          uVar8 = FUN_01717832();
          goto LAB_006b17ec;
        }
      }
    }
  }
  uVar8 = 0xffffffff;
LAB_006b17ec:
  pbStack_30 = (byte *)0x6b17f4;
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 8790 ; VA 0x006b1840 ; FUN_006b1840 */

undefined FUN_006b1840(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uStack_54;
  undefined4 ***pppuStack_50;
  undefined4 ***pppuStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = (int)param_2;
  puStack_c = &LAB_017a6928;
  pvStack_10 = ExceptionList;
  if ((*(int *)((int)param_2 + 0x10) == 0) || (param_3[4] == 0)) {
    return 0;
  }
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_8 = 0;
  param_2 = param_3;
  if (0xf < (uint)param_3[5]) {
    param_2 = (int *)*param_3;
  }
  pppuStack_48 = (undefined4 ***)0x1;
  ExceptionList = &pvStack_10;
  FUN_0064f1d0(&uStack_54,&param_2);
  FUN_0064fa20(&piStack_24,iVar1);
  piStack_18 = piStack_20;
  piVar3 = piStack_24;
  piVar5 = piStack_20;
  while( true ) {
    if (piVar3 == piVar5) {
      param_2 = (int *)((uint)param_2 & 0xffffff);
      pppuStack_48 = (undefined4 ***)0x6b19fc;
      FUN_00577a40();
      ExceptionList = pvStack_10;
      return param_2._3_1_;
    }
    uStack_14 = piVar3[4];
    uStack_2c = 0;
    uStack_28 = 0;
    param_2 = piVar3;
    if (0xf < (uint)piVar3[5]) {
      param_2 = (int *)*piVar3;
    }
    if (uStack_14 < 0x10) {
      pppuStack_3c = (undefined4 ***)*param_2;
      iStack_38 = param_2[1];
      iStack_34 = param_2[2];
      iStack_30 = param_2[3];
      uStack_28 = 0xf;
      pppuStack_48 = &pppuStack_3c;
    }
    else {
      uVar4 = uStack_14 | 0xf;
      if (0x7fffffff < uVar4) {
        uVar4 = 0x7fffffff;
      }
      pppuStack_48 = (undefined4 ***)(uVar4 + 1);
      pppuStack_4c = (undefined4 ***)0x6b192e;
      pppuStack_50 = (undefined4 ***)FUN_00554060();
      pppuStack_48 = (undefined4 ***)(uStack_14 + 1);
      pppuStack_4c = (undefined4 ***)param_2;
      uStack_54 = 0x6b193f;
      pppuStack_3c = pppuStack_50;
      FUN_0170c6f0();
      pppuStack_48 = &pppuStack_3c;
      piVar5 = piStack_18;
      uStack_28 = uVar4;
      if (0xf < uVar4) {
        pppuStack_48 = pppuStack_3c;
      }
    }
    pppuStack_4c = (undefined4 ****)0x6b195e;
    uStack_2c = uStack_14;
    iVar1 = FUN_01717832();
    if (iVar1 == *param_1) break;
    if (0xf < uStack_28) {
      pppuStack_48 = (undefined4 ***)(uStack_28 + 1);
      ppppuVar2 = (undefined4 ****)pppuStack_3c;
      if (0xfff < pppuStack_48) {
        ppppuVar2 = (undefined4 ****)pppuStack_3c[-1];
        pppuStack_48 = (undefined4 ***)(uStack_28 + 0x24);
        if (0x1f < (uint)((int)pppuStack_3c + (-4 - (int)ppppuVar2))) {
LAB_006b1a21:
                    /* WARNING: Subroutine does not return */
          pppuStack_48 = (undefined4 ***)&UNK_006b1a26;
          FUN_017167a3();
        }
      }
      pppuStack_50 = (undefined4 ****)0x6b1999;
      pppuStack_4c = ppppuVar2;
      FUN_01674ea0();
    }
    piVar3 = piVar3 + 6;
  }
  if (0xf < uStack_28) {
    pppuStack_48 = (undefined4 ***)(uStack_28 + 1);
    ppppuVar2 = (undefined4 ****)pppuStack_3c;
    if (0xfff < pppuStack_48) {
      ppppuVar2 = (undefined4 ****)pppuStack_3c[-1];
      pppuStack_48 = (undefined4 ***)(uStack_28 + 0x24);
      if (0x1f < (uint)((int)pppuStack_3c + (-4 - (int)ppppuVar2))) goto LAB_006b1a21;
    }
    pppuStack_50 = (undefined4 ****)0x6b19ce;
    pppuStack_4c = ppppuVar2;
    FUN_01674ea0();
  }
  param_2._3_1_ = 1;
  pppuStack_48 = (undefined4 ***)0x6b19dd;
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 8791 ; VA 0x006b1a30 ; FUN_006b1a30 */

undefined4 * __thiscall FUN_006b1a30(undefined4 *param_1,int param_2)

{
  int iVar1;
  
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = param_2;
  *param_1 = RBX::Network::Item::vftable;
  iVar1 = *(int *)(param_2 + 0x1db4);
  param_1[6] = *(undefined4 *)(iVar1 + 0x1f8);
  param_1[7] = *(undefined4 *)(iVar1 + 0x1fc);
  *(undefined *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 10) = 0;
  return param_1;
}



/* FUNCTION 8792 ; VA 0x006b1a80 ; FUN_006b1a80 */

undefined4 * __thiscall
FUN_006b1a80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = param_2;
  param_1[6] = param_3;
  param_1[7] = param_4;
  *param_1 = RBX::Network::Item::vftable;
  *(undefined *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 10) = 0;
  return param_1;
}



/* FUNCTION 8793 ; VA 0x006b1ac0 ; FUN_006b1ac0 */

undefined4 * __fastcall FUN_006b1ac0(undefined4 *param_1)

{
  undefined8 *puVar1;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6953;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined8 *)(param_1 + 1);
  ExceptionList = &pvStack_10;
  *puVar1 = 0;
  *param_1 = 0;
  *(undefined8 **)puVar1 = puVar1;
  param_1[2] = puVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  uStack_14 = 0;
  FUN_005f87c0(0x1b,param_1 + 3,&uStack_14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8794 ; VA 0x006b1b40 ; FUN_006b1b40 */

void __fastcall FUN_006b1b40(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)param_1[1];
  while (puVar2 != param_1 + 1) {
    puVar1 = (undefined4 *)*puVar2;
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2 = puVar1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 8795 ; VA 0x006b1b80 ; FUN_006b1b80 */

void __fastcall FUN_006b1b80(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar5 = param_1[5] - iVar1 & 0xfffffffc;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  puVar3 = (undefined4 *)param_1[1];
  while (puVar3 != param_1 + 1) {
    puVar2 = (undefined4 *)*puVar3;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3 = puVar2;
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 8796 ; VA 0x006b1c10 ; FUN_006b1c10 */

char * FUN_006b1c10(int param_1)

{
  if (param_1 < 0x1b) {
    switch(param_1) {
    case 0:
      return "End Item";
    case 1:
      return "Delete Items";
    case 2:
      return "New Items";
    case 3:
      return "Change Property Items";
    case 4:
      return "Marker Items";
    case 5:
    case 6:
    case 9:
    case 0x12:
      return "Other Items";
    case 7:
      return "Event Invocation Items";
    case 8:
      return "Request Character Items";
    case 10:
      return "CFrame Ack Items";
    case 0xb:
      return "Join Data Items";
    case 0xc:
      return "Client Quota Update Items";
    case 0xd:
      return "Stream Data Items";
    case 0xe:
      return "Region Removal Items";
    case 0xf:
      return "Instance Removal Items";
    case 0x10:
      return "Tag Items";
    case 0x11:
      return "Stats Items";
    case 0x13:
      return "Resolve Atomic Tree Items";
    case 0x14:
      return "Streaming Info Items";
    default:
      return "Unknown Items";
    case 0x16:
      return "Join Data Items V2";
    case 0x17:
      return "Stream Terrain Item";
    case 0x18:
      return "Stream Prefetch Info Items";
    }
  }
  if (param_1 == 0x1b) {
    return "Terrain";
  }
  if (param_1 == 0x1c) {
    return "Touches";
  }
  if (param_1 != 0x1d) {
    return "Unknown";
  }
  return "Physics Assemblies";
}



/* FUNCTION 8797 ; VA 0x006b1d60 ; FUN_006b1d60 */

void __fastcall FUN_006b1d60(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  
  if (DAT_01eaec1c != '\0') {
    FUN_016774b0(DAT_01eaec1c,"Items queued on destruction: %d",*param_1);
    cVar3 = DAT_01eaec1c;
    for (puVar1 = (undefined4 *)param_1[1]; puVar1 != param_1 + 1; puVar1 = (undefined4 *)*puVar1) {
      puVar2 = (undefined4 *)(-(uint)(puVar1 != (undefined4 *)0x0) & (uint)(puVar1 + -2));
      if (cVar3 != '\0') {
        FUN_01677490(cVar3,"Item %p, vtable %p",puVar2,*puVar2,0);
        cVar3 = DAT_01eaec1c;
      }
    }
  }
  return;
}



/* FUNCTION 8798 ; VA 0x006b1dd0 ; FUN_006b1dd0 */

void __fastcall FUN_006b1dd0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  
  while ((piVar3 = (int *)param_1[1], piVar3 != (int *)0x0 && (piVar3 != param_1 + 1))) {
    iVar2 = *piVar3;
    piVar5 = (int *)(-(uint)(piVar3 != (int *)0x0) & (uint)(piVar3 + -2));
    piVar1 = (int *)piVar3[1];
    *piVar1 = iVar2;
    *(int **)(iVar2 + 4) = piVar1;
    *param_1 = *param_1 + -1;
    *piVar3 = 0;
    piVar3[1] = 0;
    if (DAT_01d5b3d8 != '\0') {
      iVar2 = (**(code **)(*piVar5 + 8))();
      piVar3 = (int *)(param_1[3] + iVar2 * 4);
      *piVar3 = *piVar3 + -1;
    }
    if (piVar5 != (int *)0x0) {
      (**(code **)*piVar5)(1);
    }
  }
  if (DAT_01d5b3d8 != '\0') {
    piVar3 = (int *)param_1[3];
    uVar6 = 0;
    uVar4 = (param_1[4] - (int)piVar3) + 3U >> 2;
    if ((int *)param_1[4] < piVar3) {
      uVar4 = 0;
    }
    if (uVar4 != 0) {
      do {
        iVar2 = *piVar3;
        piVar3 = piVar3 + 1;
        uVar6 = uVar6 + 1;
        *(undefined4 *)(param_1[3] + iVar2 * 4) = 0;
      } while (uVar6 != uVar4);
    }
  }
  return;
}



/* FUNCTION 8799 ; VA 0x006b1e70 ; FUN_006b1e70 */

int __fastcall FUN_006b1e70(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 4);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if ((iVar1 != 0) && (iVar1 != param_1 + 4)) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31(uVar2,1);
}



/* FUNCTION 8800 ; VA 0x006b1e90 ; FUN_006b1e90 */

void FUN_006b1e90(undefined4 *param_1)

{
  *param_1 = 0;
  return;
}



/* FUNCTION 8801 ; VA 0x006b1ea0 ; FUN_006b1ea0 */

void __thiscall FUN_006b1ea0(int param_1,undefined8 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = *(int *)(param_1 + 4);
  if ((iVar1 != 0) && (iVar1 != param_1 + 4)) {
    puVar2 = (undefined4 *)(iVar1 + 0x20);
    if (iVar1 == 0) {
      puVar2 = (undefined4 *)0x28;
    }
    *(undefined4 *)param_2 = *puVar2;
    *(undefined4 *)((int)param_2 + 4) = puVar2[1];
    return;
  }
  *param_2 = 0;
  return;
}



/* FUNCTION 8802 ; VA 0x006b1ee0 ; FUN_006b1ee0 */

undefined4 __thiscall FUN_006b1ee0(int *param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar1 = (int *)param_1[1];
  if ((piVar1 != (int *)0x0) && (piVar1 != param_1 + 1)) {
    *param_2 = -(uint)(piVar1 != (int *)0x0) & (uint)(piVar1 + -2);
    piVar1 = (int *)param_1[1];
    piVar2 = (int *)piVar1[1];
    iVar3 = *piVar1;
    *piVar2 = iVar3;
    *(int **)(iVar3 + 4) = piVar2;
    *param_1 = *param_1 + -1;
    *piVar1 = 0;
    piVar1[1] = 0;
    if (DAT_01d5b3d8 != '\0') {
      iVar3 = (**(code **)(*(int *)*param_2 + 8))();
      piVar1 = (int *)(param_1[3] + iVar3 * 4);
      *piVar1 = *piVar1 + -1;
    }
    return 1;
  }
  return 0;
}



/* FUNCTION 8803 ; VA 0x006b1f50 ; FUN_006b1f50 */

void __thiscall FUN_006b1f50(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined auStack_c [8];
  
  piVar2 = (int *)FUN_01682800(auStack_c);
  piVar1 = param_2 + 2;
  param_2[10] = *piVar2;
  param_2[0xb] = piVar2[1];
  piVar2 = (int *)param_1[2];
  param_2[3] = (int)piVar2;
  *piVar1 = (int)(param_1 + 1);
  param_1[2] = (int)piVar1;
  *piVar2 = (int)piVar1;
  *param_1 = *param_1 + 1;
  if (DAT_01d5b3d8 != '\0') {
    iVar3 = (**(code **)(*param_2 + 8))();
    piVar1 = (int *)(param_1[3] + iVar3 * 4);
    *piVar1 = *piVar1 + 1;
  }
  return;
}



/* FUNCTION 8804 ; VA 0x006b1fb0 ; FUN_006b1fb0 */

void __thiscall FUN_006b1fb0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined auStack_c [8];
  
  piVar2 = (int *)FUN_01682800(auStack_c);
  piVar1 = param_2 + 2;
  param_2[10] = *piVar2;
  param_2[0xb] = piVar2[1];
  iVar3 = param_1[1];
  piVar2 = *(int **)(iVar3 + 4);
  param_2[3] = (int)piVar2;
  *piVar1 = iVar3;
  *(int **)(iVar3 + 4) = piVar1;
  *piVar2 = (int)piVar1;
  *param_1 = *param_1 + 1;
  if (DAT_01d5b3d8 != '\0') {
    iVar3 = (**(code **)(*param_2 + 8))();
    piVar1 = (int *)(param_1[3] + iVar3 * 4);
    *piVar1 = *piVar1 + 1;
  }
  return;
}



/* FUNCTION 8805 ; VA 0x006b2010 ; FUN_006b2010 */

void __thiscall FUN_006b2010(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar1 = param_2 + 2;
  iVar3 = param_1[1];
  piVar2 = *(int **)(iVar3 + 4);
  param_2[3] = (int)piVar2;
  *piVar1 = iVar3;
  *(int **)(iVar3 + 4) = piVar1;
  *piVar2 = (int)piVar1;
  *param_1 = *param_1 + 1;
  if (DAT_01d5b3d8 != '\0') {
    iVar3 = (**(code **)(*param_2 + 8))();
    piVar1 = (int *)(param_1[3] + iVar3 * 4);
    *piVar1 = *piVar1 + 1;
  }
  return;
}



/* FUNCTION 8806 ; VA 0x006b2050 ; FUN_006b2050 */

void FUN_006b2050(undefined4 param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = FUN_006abe40();
  *param_2 = uVar1 & 0xff;
  return;
}



/* FUNCTION 8807 ; VA 0x006b2070 ; FUN_006b2070 */

void FUN_006b2070(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = param_2;
  FUN_00620990(param_2);
  param_2 = CONCAT31(param_2._1_3_,(char)uVar1);
  FUN_006ad5e0(&param_2,1);
  return;
}



/* FUNCTION 8808 ; VA 0x006b20a0 ; FUN_006b20a0 */

void FUN_006b20a0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = param_3;
  FUN_00620990(param_3);
  param_3 = CONCAT31(param_3._1_3_,(char)uVar1);
  FUN_006ad5e0(&param_3,1);
  return;
}



/* FUNCTION 8809 ; VA 0x006b20d0 ; FUN_006b20d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_006b20d0(undefined4 *param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_00886600();
  iVar2 = _tls_index;
  *param_1 = uVar3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ead2b8) {
    FUN_016f3809(&DAT_01ead2b8);
    if (DAT_01ead2b8 == -1) {
      _DAT_01ead2ac = FUN_00619fa0;
      _DAT_01ead2b0 = FUN_00619fa0;
      _DAT_01ead2b4 = FUN_0061bd30;
      FUN_016f37bf(&DAT_01ead2b8);
    }
  }
  puVar1 = (undefined *)param_1[1];
  if (puVar1 == &DAT_01ead2ac) {
    FUN_00886840(param_2);
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  FUN_008866a0(param_2);
  param_1[1] = &DAT_01ead2ac;
  return param_1;
}



/* FUNCTION 8810 ; VA 0x006b2190 ; FUN_006b2190 */

void FUN_006b2190(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar1 = param_1[5];
      if (0xf < uVar1) {
        iVar2 = *param_1;
        uVar4 = uVar1 + 1;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar1 + 0x24;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      param_1[4] = 0;
      param_1[5] = 0xf;
      *(undefined *)param_1 = 0;
      param_1 = param_1 + 7;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 8811 ; VA 0x006b2200 ; FUN_006b2200 */

void FUN_006b2200(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  
  if (param_1 != param_2) {
    piVar5 = param_1 + 0xb;
    do {
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = *piVar5 - iVar2 & 0xfffffff8;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006b22b6;
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      iVar2 = piVar5[-8];
      if (iVar2 != 0) {
        uVar4 = piVar5[-6] - iVar2 & 0xfffffff8;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_006b22b6:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-8] = 0;
        piVar5[-7] = 0;
        piVar5[-6] = 0;
      }
      piVar1 = piVar5 + 4;
      piVar5 = piVar5 + 0xf;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 8812 ; VA 0x006b22c0 ; FUN_006b22c0 */

int __thiscall FUN_006b22c0(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar8 = *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0x1c;
  if (iVar1 == 0x9249249) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0x1c;
  uVar7 = uVar5;
  if ((uVar2 <= 0x9249249 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x1c;
  if (uVar7 < 0x924924a) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_006b2362;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006b2362:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006b24a9;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar8) / 0x1c) * 0x1c;
  iVar4 = iVar3 + uVar7;
  FUN_006b2f00(param_1,iVar4,param_3);
  uVar8 = param_1[1];
  uVar2 = *param_1;
  uVar6 = uVar7;
  if (param_2 == uVar8) {
    for (; uVar2 != uVar8; uVar2 = uVar2 + 0x1c) {
      FUN_006b2f00(param_1,uVar6,uVar2);
      uVar6 = uVar6 + 0x1c;
    }
  }
  else {
    FUN_006b3630(uVar2,param_2,uVar7);
    FUN_006b3630(param_2,param_1[1],iVar4 + 0x1c);
  }
  uVar8 = *param_1;
  if (uVar8 != 0) {
    uVar2 = param_1[1];
    if (uVar8 != uVar2) {
      do {
        FUN_006b3360();
        uVar8 = uVar8 + 0x1c;
      } while (uVar8 != uVar2);
      uVar8 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar8) / 0x1c) * 0x1c;
    uVar2 = uVar8;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar2) - 4) {
LAB_006b24a9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + (iVar1 + 1) * 0x1c;
  param_1[2] = uVar5 + uVar7;
  return *param_1 + iVar3;
}



/* FUNCTION 8813 ; VA 0x006b24c0 ; FUN_006b24c0 */

void __thiscall FUN_006b24c0(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  uVar4 = param_2;
  uVar2 = (param_1[1] - *param_1) / 0x18;
  uVar3 = (param_1[2] - *param_1) / 0x18;
  if (param_2 <= uVar3) {
    if (param_2 <= uVar2) {
      if (param_2 != uVar2) {
        iVar5 = *param_1 + param_2 * 0x18;
        FUN_00559570(iVar5,param_1[1],param_1);
        param_1[1] = iVar5;
      }
      return;
    }
    iVar5 = FUN_006b3400(param_1[1],param_2 - uVar2);
    param_1[1] = iVar5;
    return;
  }
  if (0xaaaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar3 <= 0xaaaaaaa - (uVar3 >> 1)) && (uVar1 = (uVar3 >> 1) + uVar3, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  iVar5 = FUN_00577fb0(param_2);
  FUN_006b3400(iVar5 + uVar2 * 0x18,uVar4 - uVar2);
  FUN_0055c6d0(*param_1,param_1[1],iVar5,param_1);
  FUN_00575cd0(iVar5,uVar4,param_2);
  return;
}



/* FUNCTION 8814 ; VA 0x006b25d0 ; FUN_006b25d0 */

void __thiscall FUN_006b25d0(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar2 = param_2;
  uVar7 = param_1[1];
  uVar1 = (int)(uVar7 - *param_1) / 0x14;
  uVar5 = (int)(param_1[2] - *param_1) / 0x14;
  if (param_2 <= uVar5) {
    if (param_2 <= uVar1) {
      if (param_2 != uVar1) {
        param_1[1] = *param_1 + param_2 * 0x14;
      }
      return;
    }
    if (param_2 - uVar1 == 0) {
      param_1[1] = uVar7;
      return;
    }
    iVar4 = (param_2 - uVar1) * 0x14;
    FUN_0170d1f0(uVar7,0,iVar4);
    param_1[1] = uVar7 + iVar4;
    return;
  }
  if (0xccccccc < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = param_2;
  if ((uVar5 <= 0xccccccc - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < param_2)) {
    uVar7 = param_2;
  }
  uVar5 = uVar7 * 0x14;
  if (uVar7 < 0xccccccd) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_006b2664;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006b2664:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_006b27a1;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  iVar4 = uVar2 - uVar1;
  if (iVar4 != 0) {
    FUN_0170d1f0(uVar7 + uVar1 * 0x14,0,iVar4 * 0x14);
  }
  uVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar7,uVar1,param_1[1] - uVar1);
  if (*param_1 != 0) {
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - *param_1) / 0x14) * 0x14;
    uVar3 = uVar1;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar3) - 4) {
LAB_006b27a1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar2 * 0x14;
  param_1[2] = uVar5 + uVar7;
  return;
}



/* FUNCTION 8815 ; VA 0x006b27b0 ; FUN_006b27b0 */

void __thiscall FUN_006b27b0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined2 *puVar8;
  undefined2 *puVar9;
  
  uVar5 = param_1[1];
  uVar3 = (int)(uVar5 - *param_1) / 0x14;
  uVar4 = (int)(param_1[2] - *param_1) / 0x14;
  if (param_2 <= uVar4) {
    if (uVar3 < param_2) {
      uVar5 = FUN_006b3440(uVar5,param_2 - uVar3);
      param_1[1] = uVar5;
      return;
    }
    if (param_2 != uVar3) {
      uVar3 = *param_1 + param_2 * 0x14;
      for (uVar4 = uVar3; uVar4 != uVar5; uVar4 = uVar4 + 0x14) {
        FUN_00617ad0();
      }
      param_1[1] = uVar3;
    }
    return;
  }
  if (0xccccccc < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar4 <= 0xccccccc - (uVar4 >> 1)) && (uVar5 = uVar4 + (uVar4 >> 1), uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar4 = uVar5 * 0x14;
  if (uVar5 < 0xccccccd) {
    uVar5 = uVar4;
    if (0xfff < uVar4) goto LAB_006b2844;
    if (uVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_006b2844:
    uVar1 = uVar5 + 0x23;
    if (uVar1 <= uVar5) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_006b29e6;
    uVar5 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar2;
  }
  FUN_006b3440(uVar5 + uVar3 * 0x14,param_2 - uVar3);
  puVar9 = (undefined2 *)param_1[1];
  puVar8 = (undefined2 *)*param_1;
  if (puVar8 != puVar9) {
    puVar6 = (undefined4 *)(uVar5 + 0xc);
    puVar7 = (undefined4 *)(puVar8 + 6);
    do {
      *(undefined2 *)(puVar6 + -3) = *puVar8;
      puVar6[-2] = 0;
      puVar8 = puVar8 + 10;
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar6[-2] = puVar7[-2];
      puVar6[-1] = puVar7[-1];
      *puVar6 = *puVar7;
      puVar7[-2] = 0;
      puVar7[-1] = 0;
      *puVar7 = 0;
      puVar6[1] = puVar7[1];
      puVar6 = puVar6 + 5;
      puVar7 = puVar7 + 5;
    } while (puVar8 != puVar9);
    puVar8 = (undefined2 *)*param_1;
  }
  if (puVar8 != (undefined2 *)0x0) {
    puVar9 = (undefined2 *)param_1[1];
    if (puVar8 != puVar9) {
      do {
        FUN_00617ad0();
        puVar8 = puVar8 + 10;
      } while (puVar8 != puVar9);
      puVar8 = (undefined2 *)*param_1;
    }
    uVar3 = ((int)(param_1[2] - (int)puVar8) / 0x14) * 0x14;
    puVar9 = puVar8;
    if (0xfff < uVar3) {
      puVar9 = *(undefined2 **)(puVar8 + -2);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)puVar8 + (-4 - (int)puVar9))) {
LAB_006b29e6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar9,uVar3);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + param_2 * 0x14;
  param_1[2] = uVar4 + uVar5;
  return;
}



/* FUNCTION 8816 ; VA 0x006b29f0 ; FUN_006b29f0 */

undefined2 * __thiscall FUN_006b29f0(int *param_1,uint param_2)

{
  undefined2 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined2 *puVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined2 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined2 *puVar12;
  undefined2 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6960;
  pvStack_10 = ExceptionList;
  uVar10 = (param_1[1] - *param_1) / 0x3c;
  puVar12 = (undefined2 *)((param_1[2] - *param_1) * -0x77777777);
  uVar7 = (param_1[2] - *param_1) / 0x3c;
  if (param_2 <= uVar7) {
    if (param_2 <= uVar10) {
      if (param_2 != uVar10) {
        iVar4 = *param_1 + param_2 * 0x3c;
        ExceptionList = &pvStack_10;
        puVar12 = (undefined2 *)FUN_006b2200(iVar4,param_1[1],param_1);
        param_1[1] = iVar4;
      }
      ExceptionList = pvStack_10;
      return puVar12;
    }
    ExceptionList = &pvStack_10;
    puVar12 = (undefined2 *)FUN_006b3490(param_1[1],param_2 - uVar10);
    param_1[1] = (int)puVar12;
    ExceptionList = pvStack_10;
    return puVar12;
  }
  if (0x4444444 < param_2) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = param_2;
  if ((uVar7 <= 0x4444444 - (uVar7 >> 1)) && (uVar2 = (uVar7 >> 1) + uVar7, uVar2 < param_2)) {
    uVar2 = param_2;
  }
  uVar7 = uVar2 * 0x3c;
  if (uVar2 < 0x4444445) {
    if (0xfff < uVar7) goto LAB_006b2aa2;
    if (uVar7 == 0) {
      puVar12 = (undefined2 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar12 = (undefined2 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006b2aa2:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_006b2cea;
    puVar12 = (undefined2 *)(iVar4 + 0x23U & 0xffffffe0);
    *(int *)(puVar12 + -2) = iVar4;
  }
  uStack_8 = 0;
  FUN_006b3490(puVar12 + uVar10 * 0x1e,param_2 - uVar10);
  puVar1 = (undefined2 *)param_1[1];
  puVar5 = (undefined2 *)*param_1;
  puVar9 = puVar12;
  if (puVar5 != puVar1) {
    puVar8 = (undefined4 *)(puVar5 + 10);
    puVar11 = (undefined4 *)(puVar12 + 10);
    puStack_18 = puVar12;
    do {
      puVar9 = puStack_18 + 0x1e;
      *puStack_18 = *puVar5;
      *(undefined2 *)((int)puVar11 + -0x12) = *(undefined2 *)((int)puVar8 + -0x12);
      *(undefined2 *)(puVar11 + -4) = *(undefined2 *)(puVar8 + -4);
      puVar11[-3] = puVar8[-3];
      puVar11[-2] = 0;
      puVar11[-1] = 0;
      *puVar11 = 0;
      puVar11[-2] = puVar8[-2];
      puVar11[-1] = puVar8[-1];
      *puVar11 = *puVar8;
      puVar8[-2] = 0;
      puVar8[-1] = 0;
      *puVar8 = 0;
      puVar11[1] = puVar8[1];
      puVar11[2] = puVar8[2];
      puVar11[4] = 0;
      puVar11[5] = 0;
      puVar11[6] = 0;
      puVar11[4] = puVar8[4];
      puVar11[5] = puVar8[5];
      puVar11[6] = puVar8[6];
      puVar8[4] = 0;
      puVar8[5] = 0;
      puVar8[6] = 0;
      puVar11[7] = puVar8[7];
      puVar11[8] = puVar8[8];
      puVar5 = puVar5 + 0x1e;
      puVar8 = puVar8 + 0xf;
      puVar11 = puVar11 + 0xf;
      puStack_18 = puVar9;
    } while (puVar5 != puVar1);
  }
  FUN_006b2200(puVar9,puVar9,param_1);
  if (*param_1 != 0) {
    FUN_006b2200(*param_1,param_1[1],param_1);
    iVar4 = *param_1;
    uVar10 = ((param_1[2] - *param_1) / 0x3c) * 0x3c;
    iVar6 = iVar4;
    if (0xfff < uVar10) {
      iVar6 = *(int *)(iVar4 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar4 - iVar6) - 4U) {
LAB_006b2cea:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  *param_1 = (int)puVar12;
  param_1[1] = (int)(puVar12 + param_2 * 0x1e);
  param_1[2] = (int)(puVar12 + uVar2 * 0x1e);
  ExceptionList = pvStack_10;
  return puVar12 + uVar2 * 0x1e;
}



/* FUNCTION 8817 ; VA 0x006b2cef ; Catch_All@006b2cef */

void Catch_All_006b2cef(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  FUN_006b3590(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x1c));
  uVar2 = *(undefined4 *)(unaff_EBP + -0x18);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0058ee20(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8818 ; VA 0x006b2d20 ; FUN_006b2d20 */

void __thiscall FUN_006b2d20(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar2 = param_2;
  uVar7 = param_1[1];
  uVar1 = (int)(uVar7 - *param_1) / 0xc;
  uVar5 = (int)(param_1[2] - *param_1) / 0xc;
  if (param_2 <= uVar5) {
    if (param_2 <= uVar1) {
      if (param_2 != uVar1) {
        param_1[1] = *param_1 + param_2 * 0xc;
      }
      return;
    }
    if (param_2 - uVar1 == 0) {
      param_1[1] = uVar7;
      return;
    }
    iVar4 = (param_2 - uVar1) * 0xc;
    FUN_0170d1f0(uVar7,0,iVar4);
    param_1[1] = uVar7 + iVar4;
    return;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = param_2;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < param_2)) {
    uVar7 = param_2;
  }
  uVar5 = uVar7 * 0xc;
  if (uVar7 < 0x15555556) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_006b2db2;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006b2db2:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_006b2eee;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  iVar4 = uVar2 - uVar1;
  if (iVar4 != 0) {
    FUN_0170d1f0(uVar7 + uVar1 * 0xc,0,iVar4 * 0xc);
  }
  uVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar7,uVar1,param_1[1] - uVar1);
  if (*param_1 != 0) {
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - *param_1) / 0xc) * 0xc;
    uVar3 = uVar1;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar3) - 4) {
LAB_006b2eee:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar2 * 0xc;
  param_1[2] = uVar5 + uVar7;
  return;
}



/* FUNCTION 8819 ; VA 0x006b2f00 ; FUN_006b2f00 */

void FUN_006b2f00(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  *param_2 = *param_3;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[1] = param_3[1];
  param_2[2] = param_3[2];
  param_2[3] = param_3[3];
  param_3[1] = 0;
  param_3[2] = 0;
  param_3[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  param_2[4] = param_3[4];
  param_2[5] = param_3[5];
  param_2[6] = param_3[6];
  param_3[4] = 0;
  param_3[5] = 0;
  param_3[6] = 0;
  return;
}



/* FUNCTION 8820 ; VA 0x006b2f90 ; FUN_006b2f90 */

int __thiscall FUN_006b2f90(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_34 [5];
  uint uStack_20;
  undefined2 uStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0054ef60(param_2);
  uStack_1c = 0;
  uStack_8 = 0;
  FUN_006b30f0(param_3,aiStack_34,&uStack_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_20) {
    uVar2 = uStack_20 + 1;
    iVar1 = aiStack_34[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_34[0] + -4);
      uVar2 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  FUN_0054ef60(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8821 ; VA 0x006b3040 ; FUN_006b3040 */

uint * __thiscall FUN_006b3040(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar7 = param_2 * 0x10;
    if (uVar7 < 0x1000) {
      if (uVar7 == 0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_01674e20(uVar7);
      }
    }
    else {
      uVar4 = uVar7 + 0x23;
      if (uVar4 <= uVar7) {
        uVar4 = 0xffffffff;
      }
      iVar5 = FUN_01674e20(uVar4);
      if (iVar5 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar4 = iVar5 + 0x23U & 0xffffffe0;
      *(int *)(uVar4 - 4) = iVar5;
    }
    *param_1 = uVar4;
    param_1[1] = uVar4;
    param_1[2] = *param_1 + uVar7;
    puVar6 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        uVar1 = param_3[1];
        uVar2 = param_3[2];
        uVar3 = param_3[3];
        *puVar6 = *param_3;
        puVar6[1] = uVar1;
        puVar6[2] = uVar2;
        puVar6[3] = uVar3;
        puVar6 = puVar6 + 4;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar6;
  }
  return param_1;
}



/* FUNCTION 8822 ; VA 0x006b30f0 ; FUN_006b30f0 */

uint * __thiscall FUN_006b30f0(uint *param_1,uint param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6998;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x9249249 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = param_2 * 0x1c;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    uVar3 = *param_1;
    uStack_8 = 1;
    for (; param_2 != 0; param_2 = param_2 - 1) {
      FUN_0054ef60(param_3);
      *(undefined2 *)(uVar3 + 0x18) = *(undefined2 *)(param_3 + 0x18);
      uVar3 = uVar3 + 0x1c;
    }
    FUN_006b2190(uVar3,uVar3,param_1);
    param_1[1] = uVar3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8823 ; VA 0x006b3200 ; Catch_All@006b3200 */

void Catch_All_006b3200(void)

{
  FUN_006b35b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8824 ; VA 0x006b3220 ; FUN_006b3220 */

void __fastcall FUN_006b3220(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  FUN_006b35b0();
  return;
}



/* FUNCTION 8825 ; VA 0x006b3280 ; FUN_006b3280 */

void __fastcall FUN_006b3280(undefined4 *param_1)

{
  FUN_006b2190(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 8826 ; VA 0x006b32a0 ; FUN_006b32a0 */

void __fastcall FUN_006b32a0(undefined4 *param_1)

{
  FUN_006b2200(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 8827 ; VA 0x006b32c0 ; thunk_FUN_006b35b0 */

void __fastcall thunk_FUN_006b35b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006b2190(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 8828 ; VA 0x006b32d0 ; FUN_006b32d0 */

void __fastcall FUN_006b32d0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_006b3360();
        iVar2 = iVar2 + 0x1c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x1c) * 0x1c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 8829 ; VA 0x006b3360 ; FUN_006b3360 */

void __fastcall FUN_006b3360(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x10);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x18) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006b33f5;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_006b33f5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 8830 ; VA 0x006b3400 ; FUN_006b3400 */

undefined * __thiscall FUN_006b3400(undefined4 *param_1,undefined *param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  if (param_3 != 0) {
    do {
      *(undefined4 *)(param_2 + 0x10) = 0;
      *(undefined4 *)(param_2 + 0x14) = 0xf;
      *param_2 = 0;
      param_2 = param_2 + 0x18;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_00559570(param_2,param_2,uVar1);
  return param_2;
}



/* FUNCTION 8831 ; VA 0x006b3440 ; FUN_006b3440 */

void FUN_006b3440(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = param_1 + 3;
    do {
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      param_1 = param_1 + 5;
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 5;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 8832 ; VA 0x006b3490 ; FUN_006b3490 */

undefined4 * __thiscall FUN_006b3490(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  void **ppvVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_28;
  undefined2 uStack_24;
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a69c3;
  pvStack_10 = ExceptionList;
  uStack_14 = *param_1;
  uStack_7 = 0;
  iVar2 = param_3;
  puVar3 = param_2;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_3 != 0) {
    do {
      uStack_8 = 0;
      *(undefined2 *)(puVar3 + 1) = 0xffff;
      uStack_1c = 0;
      *puVar3 = 0xffffffff;
      puVar3[2] = 0;
      uStack_20 = 0;
      puStack_18 = puVar3;
      FUN_0060e8c0(0,&uStack_20,(int)&param_3 + 3);
      puVar3[6] = 0;
      puVar3[7] = 0;
      uStack_8 = 1;
      uStack_24 = 0;
      uStack_28 = 0;
      FUN_0060e8c0(0,&uStack_28,(int)&param_2 + 3);
      puVar3[0xc] = 0;
      puVar3[0xd] = 0;
      puVar3 = puVar3 + 0xf;
      iVar2 = iVar2 + -1;
      ppvVar1 = (void **)ExceptionList;
    } while (iVar2 != 0);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 0;
  FUN_006b2200(puVar3,puVar3,uStack_14);
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 8833 ; VA 0x006b3590 ; FUN_006b3590 */

void __thiscall FUN_006b3590(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006b2200(param_2,param_3,param_1);
  return;
}



/* FUNCTION 8834 ; VA 0x006b35b0 ; FUN_006b35b0 */

void __fastcall FUN_006b35b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006b2190(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 8835 ; VA 0x006b3630 ; FUN_006b3630 */

int __thiscall FUN_006b3630(undefined4 param_1,int param_2,int param_3,int param_4)

{
  if (param_2 != param_3) {
    do {
      FUN_006b2f00(param_1,param_4,param_2);
      param_2 = param_2 + 0x1c;
      param_4 = param_4 + 0x1c;
    } while (param_2 != param_3);
  }
  return param_4;
}



/* FUNCTION 8836 ; VA 0x006b3680 ; FUN_006b3680 */

undefined4 FUN_006b3680(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_c18 [24];
  undefined auStack_c00 [16];
  undefined4 uStack_bf0;
  undefined4 uStack_bec;
  undefined uStack_be8;
  undefined4 uStack_bd8;
  undefined4 uStack_bd4;
  undefined uStack_bd0;
  undefined4 uStack_bc0;
  undefined4 uStack_bbc;
  undefined uStack_bb8;
  undefined4 uStack_ba8;
  undefined4 uStack_ba4;
  undefined uStack_ba0;
  undefined4 uStack_b90;
  undefined4 uStack_b8c;
  undefined uStack_b88;
  undefined4 uStack_b78;
  undefined4 uStack_b74;
  undefined uStack_b70;
  undefined4 uStack_b60;
  undefined4 uStack_b5c;
  undefined uStack_b58;
  undefined4 uStack_b48;
  undefined4 uStack_b44;
  undefined uStack_b40;
  undefined4 uStack_b30;
  undefined4 uStack_b2c;
  undefined uStack_b28;
  undefined4 uStack_b18;
  undefined4 uStack_b14;
  undefined uStack_b10;
  undefined4 uStack_b00;
  undefined4 uStack_afc;
  undefined uStack_af8;
  undefined4 uStack_ae8;
  undefined4 uStack_ae4;
  undefined uStack_ae0;
  undefined4 uStack_ad0;
  undefined4 uStack_acc;
  undefined uStack_ac8;
  undefined4 uStack_ab8;
  undefined4 uStack_ab4;
  undefined uStack_ab0;
  undefined4 uStack_aa0;
  undefined4 uStack_a9c;
  undefined uStack_a98;
  undefined4 uStack_a88;
  undefined4 uStack_a84;
  undefined uStack_a80;
  undefined4 uStack_a70;
  undefined4 uStack_a6c;
  undefined uStack_a68;
  undefined4 uStack_a58;
  undefined4 uStack_a54;
  undefined uStack_a50;
  undefined4 uStack_a40;
  undefined4 uStack_a3c;
  undefined uStack_a38;
  undefined4 uStack_a28;
  undefined4 uStack_a24;
  undefined uStack_a20;
  undefined4 uStack_a10;
  undefined4 uStack_a0c;
  undefined uStack_a08;
  undefined4 uStack_9f8;
  undefined4 uStack_9f4;
  undefined uStack_9f0;
  undefined4 uStack_9e0;
  undefined4 uStack_9dc;
  undefined uStack_9d8;
  undefined4 uStack_9c8;
  undefined4 uStack_9c4;
  undefined uStack_9c0;
  undefined4 uStack_9b0;
  undefined4 uStack_9ac;
  undefined uStack_9a8;
  undefined4 uStack_998;
  undefined4 uStack_994;
  undefined uStack_990;
  undefined4 uStack_980;
  undefined4 uStack_97c;
  undefined uStack_978;
  undefined4 uStack_968;
  undefined4 uStack_964;
  undefined uStack_960;
  undefined4 uStack_950;
  undefined4 uStack_94c;
  undefined uStack_948;
  undefined4 uStack_938;
  undefined4 uStack_934;
  undefined uStack_930;
  undefined4 uStack_920;
  undefined4 uStack_91c;
  undefined uStack_918;
  undefined4 uStack_908;
  undefined4 uStack_904;
  undefined uStack_900;
  undefined4 uStack_8f0;
  undefined4 uStack_8ec;
  undefined uStack_8e8;
  undefined4 uStack_8d8;
  undefined4 uStack_8d4;
  undefined uStack_8d0;
  undefined4 uStack_8c0;
  undefined4 uStack_8bc;
  undefined uStack_8b8;
  undefined4 uStack_8a8;
  undefined4 uStack_8a4;
  undefined uStack_8a0;
  undefined4 uStack_890;
  undefined4 uStack_88c;
  undefined uStack_888;
  undefined4 uStack_878;
  undefined4 uStack_874;
  undefined uStack_870;
  undefined4 uStack_860;
  undefined4 uStack_85c;
  undefined uStack_858;
  undefined4 uStack_848;
  undefined4 uStack_844;
  undefined uStack_840;
  undefined4 uStack_830;
  undefined4 uStack_82c;
  undefined uStack_828;
  undefined4 uStack_818;
  undefined4 uStack_814;
  undefined uStack_810;
  undefined4 uStack_800;
  undefined4 uStack_7fc;
  undefined uStack_7f8;
  undefined4 uStack_7e8;
  undefined4 uStack_7e4;
  undefined uStack_7e0;
  undefined4 uStack_7d0;
  undefined4 uStack_7cc;
  undefined uStack_7c8;
  undefined4 uStack_7b8;
  undefined4 uStack_7b4;
  undefined uStack_7b0;
  undefined4 uStack_7a0;
  undefined4 uStack_79c;
  undefined uStack_798;
  undefined4 uStack_788;
  undefined4 uStack_784;
  undefined uStack_780;
  undefined4 uStack_770;
  undefined4 uStack_76c;
  undefined uStack_768;
  undefined4 uStack_758;
  undefined4 uStack_754;
  undefined uStack_750;
  undefined4 uStack_740;
  undefined4 uStack_73c;
  undefined uStack_738;
  undefined4 uStack_728;
  undefined4 uStack_724;
  undefined uStack_720;
  undefined4 uStack_710;
  undefined4 uStack_70c;
  undefined uStack_708;
  undefined4 uStack_6f8;
  undefined4 uStack_6f4;
  undefined uStack_6f0;
  undefined4 uStack_6e0;
  undefined4 uStack_6dc;
  undefined uStack_6d8;
  undefined4 uStack_6c8;
  undefined4 uStack_6c4;
  undefined uStack_6c0;
  undefined4 uStack_6b0;
  undefined4 uStack_6ac;
  undefined uStack_6a8;
  undefined4 uStack_698;
  undefined4 uStack_694;
  undefined uStack_690;
  undefined4 uStack_680;
  undefined4 uStack_67c;
  undefined uStack_678;
  undefined4 uStack_668;
  undefined4 uStack_664;
  undefined uStack_660;
  undefined4 uStack_650;
  undefined4 uStack_64c;
  undefined uStack_648;
  undefined4 uStack_638;
  undefined4 uStack_634;
  undefined uStack_630;
  undefined4 uStack_620;
  undefined4 uStack_61c;
  undefined uStack_618;
  undefined4 uStack_608;
  undefined4 uStack_604;
  undefined uStack_600;
  undefined4 uStack_5f0;
  undefined4 uStack_5ec;
  undefined uStack_5e8;
  undefined4 uStack_5d8;
  undefined4 uStack_5d4;
  undefined uStack_5d0;
  undefined4 uStack_5c0;
  undefined4 uStack_5bc;
  undefined uStack_5b8;
  undefined4 uStack_5a8;
  undefined4 uStack_5a4;
  undefined uStack_5a0;
  undefined4 uStack_590;
  undefined4 uStack_58c;
  undefined uStack_588;
  undefined4 uStack_578;
  undefined4 uStack_574;
  undefined uStack_570;
  undefined4 uStack_560;
  undefined4 uStack_55c;
  undefined uStack_558;
  undefined4 uStack_548;
  undefined4 uStack_544;
  undefined uStack_540;
  undefined4 uStack_530;
  undefined4 uStack_52c;
  undefined uStack_528;
  undefined4 uStack_518;
  undefined4 uStack_514;
  undefined uStack_510;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  undefined uStack_4f8;
  undefined4 uStack_4e8;
  undefined4 uStack_4e4;
  undefined uStack_4e0;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  undefined uStack_4c8;
  undefined4 uStack_4b8;
  undefined4 uStack_4b4;
  undefined uStack_4b0;
  undefined4 uStack_4a0;
  undefined4 uStack_49c;
  undefined uStack_498;
  undefined4 uStack_488;
  undefined4 uStack_484;
  undefined uStack_480;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined uStack_468;
  undefined4 uStack_458;
  undefined4 uStack_454;
  undefined uStack_450;
  undefined4 uStack_440;
  undefined4 uStack_43c;
  undefined uStack_438;
  undefined4 uStack_428;
  undefined4 uStack_424;
  undefined uStack_420;
  undefined4 uStack_410;
  undefined4 uStack_40c;
  undefined uStack_408;
  undefined4 uStack_3f8;
  undefined4 uStack_3f4;
  undefined uStack_3f0;
  undefined4 uStack_3e0;
  undefined4 uStack_3dc;
  undefined uStack_3d8;
  undefined4 uStack_3c8;
  undefined4 uStack_3c4;
  undefined uStack_3c0;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  undefined uStack_3a8;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined uStack_390;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined uStack_378;
  undefined4 uStack_368;
  undefined4 uStack_364;
  undefined uStack_360;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined uStack_348;
  undefined4 uStack_338;
  undefined4 uStack_334;
  undefined uStack_330;
  undefined4 uStack_320;
  undefined4 uStack_31c;
  undefined uStack_318;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined uStack_300;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined uStack_2e8;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined uStack_2d0;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined uStack_2b8;
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  undefined uStack_2a0;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined uStack_288;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined uStack_270;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined uStack_258;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined uStack_240;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined uStack_228;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined uStack_210;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined uStack_1f8;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined uStack_1e0;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined uStack_1c8;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined uStack_1b0;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined uStack_198;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined uStack_180;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined uStack_168;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined uStack_150;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined uStack_138;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined uStack_120;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined uStack_108;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined uStack_d8;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined uStack_a8;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined uStack_90;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined uStack_78;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a7043;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_8 = 0;
  uStack_bf0 = 0;
  uStack_bec = 0xf;
  auStack_c00[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AccessoryWeld",0xd);
  uStack_8 = 1;
  uStack_bd8 = 0;
  uStack_bd4 = 0xf;
  uStack_be8 = 0;
  FUN_005542c0(&DAT_018db428,7);
  uStack_8._0_1_ = 2;
  uStack_bc0 = 0;
  uStack_bbc = 0xf;
  uStack_bd0 = 0;
  FUN_005542c0("Animation",9);
  uStack_8._0_1_ = 3;
  uStack_ba8 = 0;
  uStack_ba4 = 0xf;
  uStack_bb8 = 0;
  FUN_005542c0("Animation1",10);
  uStack_8._0_1_ = 4;
  uStack_b90 = 0;
  uStack_b8c = 0xf;
  uStack_ba0 = 0;
  FUN_005542c0("Animation2",10);
  uStack_8._0_1_ = 5;
  uStack_b78 = 0;
  uStack_b74 = 0xf;
  uStack_b88 = 0;
  FUN_005542c0("Animation3",10);
  uStack_8._0_1_ = 6;
  uStack_b60 = 0;
  uStack_b5c = 0xf;
  uStack_b70 = 0;
  FUN_005542c0("AvatarPartScaleType",0x13);
  uStack_8._0_1_ = 7;
  uStack_b48 = 0;
  uStack_b44 = 0xf;
  uStack_b58 = 0;
  FUN_005542c0("BodyBackAttachment",0x12);
  uStack_8._0_1_ = 8;
  uStack_b30 = 0;
  uStack_b2c = 0xf;
  uStack_b40 = 0;
  FUN_005542c0("BodyDepthScale",0xe);
  uStack_8._0_1_ = 9;
  uStack_b18 = 0;
  uStack_b14 = 0xf;
  uStack_b28 = 0;
  FUN_005542c0("BodyFrontAttachment",0x13);
  uStack_8._0_1_ = 10;
  uStack_b00 = 0;
  uStack_afc = 0xf;
  uStack_b10 = 0;
  FUN_005542c0("BodyHeightScale",0xf);
  uStack_8._0_1_ = 0xb;
  uStack_ae8 = 0;
  uStack_ae4 = 0xf;
  uStack_af8 = 0;
  FUN_005542c0("BodyProportionScale",0x13);
  uStack_8._0_1_ = 0xc;
  uStack_ad0 = 0;
  uStack_acc = 0xf;
  uStack_ae0 = 0;
  FUN_005542c0("BodyScales",10);
  uStack_8._0_1_ = 0xd;
  uStack_ab8 = 0;
  uStack_ab4 = 0xf;
  uStack_ac8 = 0;
  FUN_005542c0("BodyTypeScale",0xd);
  uStack_8._0_1_ = 0xe;
  uStack_aa0 = 0;
  uStack_a9c = 0xf;
  uStack_ab0 = 0;
  FUN_005542c0("BodyWidthScale",0xe);
  uStack_8._0_1_ = 0xf;
  uStack_a88 = 0;
  uStack_a84 = 0xf;
  uStack_a98 = 0;
  FUN_005542c0("CheerAnim",9);
  uStack_8._0_1_ = 0x10;
  uStack_a70 = 0;
  uStack_a6c = 0xf;
  uStack_a80 = 0;
  FUN_005542c0("ClimbAnim",9);
  uStack_8._0_1_ = 0x11;
  uStack_a58 = 0;
  uStack_a54 = 0xf;
  uStack_a68 = 0;
  FUN_005542c0("Climbing",8);
  uStack_8._0_1_ = 0x12;
  uStack_a40 = 0;
  uStack_a3c = 0xf;
  uStack_a50 = 0;
  FUN_005542c0(&DAT_018db520,4);
  uStack_8._0_1_ = 0x13;
  uStack_a28 = 0;
  uStack_a24 = 0xf;
  uStack_a38 = 0;
  FUN_005542c0("EmitterSize",0xb);
  uStack_8._0_1_ = 0x14;
  uStack_a10 = 0;
  uStack_a0c = 0xf;
  uStack_a20 = 0;
  FUN_005542c0("FaceCenterAttachment",0x14);
  uStack_8._0_1_ = 0x15;
  uStack_9f8 = 0;
  uStack_9f4 = 0xf;
  uStack_a08 = 0;
  FUN_005542c0("FaceFrontAttachment",0x13);
  uStack_8._0_1_ = 0x16;
  uStack_9e0 = 0;
  uStack_9dc = 0xf;
  uStack_9f0 = 0;
  FUN_005542c0("FallAnim",8);
  uStack_8._0_1_ = 0x17;
  uStack_9c8 = 0;
  uStack_9c4 = 0xf;
  uStack_9d8 = 0;
  FUN_005542c0("Fired",5);
  uStack_8._0_1_ = 0x18;
  uStack_9b0 = 0;
  uStack_9ac = 0xf;
  uStack_9c0 = 0;
  FUN_005542c0("FreeFalling",0xb);
  uStack_8._0_1_ = 0x19;
  uStack_998 = 0;
  uStack_994 = 0xf;
  uStack_9a8 = 0;
  FUN_005542c0("GettingUp",9);
  uStack_8._0_1_ = 0x1a;
  uStack_980 = 0;
  uStack_97c = 0xf;
  uStack_990 = 0;
  FUN_005542c0("HairAttachment",0xe);
  uStack_8._0_1_ = 0x1b;
  uStack_968 = 0;
  uStack_964 = 0xf;
  uStack_978 = 0;
  FUN_005542c0("Handle",6);
  uStack_8._0_1_ = 0x1c;
  uStack_950 = 0;
  uStack_94c = 0xf;
  uStack_960 = 0;
  FUN_005542c0("HandleAttachment",0x10);
  uStack_8._0_1_ = 0x1d;
  uStack_938 = 0;
  uStack_934 = 0xf;
  uStack_948 = 0;
  FUN_005542c0("HandleWeld",10);
  uStack_8._0_1_ = 0x1e;
  uStack_920 = 0;
  uStack_91c = 0xf;
  uStack_930 = 0;
  FUN_005542c0("HatAttachment",0xd);
  uStack_8._0_1_ = 0x1f;
  uStack_908 = 0;
  uStack_904 = 0xf;
  uStack_918 = 0;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_8._0_1_ = 0x20;
  uStack_8f0 = 0;
  uStack_8ec = 0xf;
  uStack_900 = 0;
  FUN_005542c0("Health",6);
  uStack_8._0_1_ = 0x21;
  uStack_8d8 = 0;
  uStack_8d4 = 0xf;
  uStack_8e8 = 0;
  FUN_005542c0("HumanoidRootPart",0x10);
  uStack_8._0_1_ = 0x22;
  uStack_8c0 = 0;
  uStack_8bc = 0xf;
  uStack_8d0 = 0;
  FUN_005542c0("JumpAnim",8);
  uStack_8._0_1_ = 0x23;
  uStack_8a8 = 0;
  uStack_8a4 = 0xf;
  uStack_8b8 = 0;
  FUN_005542c0("Jumping",7);
  uStack_8._0_1_ = 0x24;
  uStack_890 = 0;
  uStack_88c = 0xf;
  uStack_8a0 = 0;
  FUN_005542c0("Landing",7);
  uStack_8._0_1_ = 0x25;
  uStack_878 = 0;
  uStack_874 = 0xf;
  uStack_888 = 0;
  FUN_005542c0("LaughAnim",9);
  uStack_8._0_1_ = 0x26;
  uStack_860 = 0;
  uStack_85c = 0xf;
  uStack_870 = 0;
  FUN_005542c0("LeftAnkle",9);
  uStack_8._0_1_ = 0x27;
  uStack_848 = 0;
  uStack_844 = 0xf;
  uStack_858 = 0;
  FUN_005542c0("LeftAnkleRigAttachment",0x16);
  uStack_8._0_1_ = 0x28;
  uStack_830 = 0;
  uStack_82c = 0xf;
  uStack_840 = 0;
  FUN_005542c0("LeftCollarAttachment",0x14);
  uStack_8._0_1_ = 0x29;
  uStack_818 = 0;
  uStack_814 = 0xf;
  uStack_828 = 0;
  FUN_005542c0("LeftElbow",9);
  uStack_8._0_1_ = 0x2a;
  uStack_800 = 0;
  uStack_7fc = 0xf;
  uStack_810 = 0;
  FUN_005542c0("LeftElbowRigAttachment",0x16);
  uStack_8._0_1_ = 0x2b;
  uStack_7e8 = 0;
  uStack_7e4 = 0xf;
  uStack_7f8 = 0;
  FUN_005542c0("LeftFoot",8);
  uStack_8._0_1_ = 0x2c;
  uStack_7d0 = 0;
  uStack_7cc = 0xf;
  uStack_7e0 = 0;
  FUN_005542c0("LeftGripAttachment",0x12);
  uStack_8._0_1_ = 0x2d;
  uStack_7b8 = 0;
  uStack_7b4 = 0xf;
  uStack_7c8 = 0;
  FUN_005542c0("LeftHand",8);
  uStack_8._0_1_ = 0x2e;
  uStack_7a0 = 0;
  uStack_79c = 0xf;
  uStack_7b0 = 0;
  FUN_005542c0("LeftHip",7);
  uStack_8._0_1_ = 0x2f;
  uStack_788 = 0;
  uStack_784 = 0xf;
  uStack_798 = 0;
  FUN_005542c0(&DAT_018db6ac,0x14);
  uStack_8._0_1_ = 0x30;
  uStack_770 = 0;
  uStack_76c = 0xf;
  uStack_780 = 0;
  FUN_005542c0("LeftKnee",8);
  uStack_8._0_1_ = 0x31;
  uStack_758 = 0;
  uStack_754 = 0xf;
  uStack_768 = 0;
  FUN_005542c0("LeftKneeRigAttachment",0x15);
  uStack_8._0_1_ = 0x32;
  uStack_740 = 0;
  uStack_73c = 0xf;
  uStack_750 = 0;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_8._0_1_ = 0x33;
  uStack_728 = 0;
  uStack_724 = 0xf;
  uStack_738 = 0;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_8._0_1_ = 0x34;
  uStack_710 = 0;
  uStack_70c = 0xf;
  uStack_720 = 0;
  FUN_005542c0("LeftShoulder",0xc);
  uStack_8._0_1_ = 0x35;
  uStack_6f8 = 0;
  uStack_6f4 = 0xf;
  uStack_708 = 0;
  FUN_005542c0("LeftShoulderAttachment",0x16);
  uStack_8._0_1_ = 0x36;
  uStack_6e0 = 0;
  uStack_6dc = 0xf;
  uStack_6f0 = 0;
  FUN_005542c0("LeftShoulderRigAttachment",0x19);
  uStack_8._0_1_ = 0x37;
  uStack_6c8 = 0;
  uStack_6c4 = 0xf;
  uStack_6d8 = 0;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_8._0_1_ = 0x38;
  uStack_6b0 = 0;
  uStack_6ac = 0xf;
  uStack_6c0 = 0;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_8._0_1_ = 0x39;
  uStack_698 = 0;
  uStack_694 = 0xf;
  uStack_6a8 = 0;
  FUN_005542c0("LeftWrist",9);
  uStack_8._0_1_ = 0x3a;
  uStack_680 = 0;
  uStack_67c = 0xf;
  uStack_690 = 0;
  FUN_005542c0("LeftWristRigAttachment",0x16);
  uStack_8._0_1_ = 0x3b;
  uStack_668 = 0;
  uStack_664 = 0xf;
  uStack_678 = 0;
  FUN_005542c0("Looped",6);
  uStack_8._0_1_ = 0x3c;
  uStack_650 = 0;
  uStack_64c = 0xf;
  uStack_660 = 0;
  FUN_005542c0("LowerTorso",10);
  uStack_8._0_1_ = 0x3d;
  uStack_638 = 0;
  uStack_634 = 0xf;
  uStack_648 = 0;
  FUN_005542c0(&DAT_018db7a4,8);
  uStack_8._0_1_ = 0x3e;
  uStack_620 = 0;
  uStack_61c = 0xf;
  uStack_630 = 0;
  FUN_005542c0("MaterialTexture",0xf);
  uStack_8._0_1_ = 0x3f;
  uStack_608 = 0;
  uStack_604 = 0xf;
  uStack_618 = 0;
  FUN_005542c0("MaxDistance",0xb);
  uStack_8._0_1_ = 0x40;
  uStack_5f0 = 0;
  uStack_5ec = 0xf;
  uStack_600 = 0;
  FUN_005542c0(&DAT_018db7cc,4);
  uStack_8._0_1_ = 0x41;
  uStack_5d8 = 0;
  uStack_5d4 = 0xf;
  uStack_5e8 = 0;
  FUN_005542c0("NeckAttachment",0xe);
  uStack_8._0_1_ = 0x42;
  uStack_5c0 = 0;
  uStack_5bc = 0xf;
  uStack_5d0 = 0;
  FUN_005542c0("NeckRigAttachment",0x11);
  uStack_8._0_1_ = 0x43;
  uStack_5a8 = 0;
  uStack_5a4 = 0xf;
  uStack_5b8 = 0;
  FUN_005542c0("Object",6);
  uStack_8._0_1_ = 0x44;
  uStack_590 = 0;
  uStack_58c = 0xf;
  uStack_5a0 = 0;
  FUN_005542c0(&DAT_018db7f8,0x10);
  uStack_8._0_1_ = 0x45;
  uStack_578 = 0;
  uStack_574 = 0xf;
  uStack_588 = 0;
  FUN_005542c0(&DAT_018db80c,0xc);
  uStack_8._0_1_ = 0x46;
  uStack_560 = 0;
  uStack_55c = 0xf;
  uStack_570 = 0;
  FUN_005542c0(&DAT_018db81c,4);
  uStack_8._0_1_ = 0x47;
  uStack_548 = 0;
  uStack_544 = 0xf;
  uStack_558 = 0;
  FUN_005542c0("PlayEmote",9);
  uStack_8._0_1_ = 0x48;
  uStack_530 = 0;
  uStack_52c = 0xf;
  uStack_540 = 0;
  FUN_005542c0("PlaybackSpeed",0xd);
  uStack_8._0_1_ = 0x49;
  uStack_518 = 0;
  uStack_514 = 0xf;
  uStack_528 = 0;
  FUN_005542c0("PointAnim",9);
  uStack_8._0_1_ = 0x4a;
  uStack_500 = 0;
  uStack_4fc = 0xf;
  uStack_510 = 0;
  FUN_005542c0("RagdollBallSocketConstraint",0x1b);
  uStack_8._0_1_ = 0x4b;
  uStack_4e8 = 0;
  uStack_4e4 = 0xf;
  uStack_4f8 = 0;
  FUN_005542c0("RagdollNoCollisionConstraint",0x1c);
  uStack_8._0_1_ = 0x4c;
  uStack_4d0 = 0;
  uStack_4cc = 0xf;
  uStack_4e0 = 0;
  FUN_005542c0("RightAnkle",10);
  uStack_8._0_1_ = 0x4d;
  uStack_4b8 = 0;
  uStack_4b4 = 0xf;
  uStack_4c8 = 0;
  FUN_005542c0("RightAnkleRigAttachment",0x17);
  uStack_8._0_1_ = 0x4e;
  uStack_4a0 = 0;
  uStack_49c = 0xf;
  uStack_4b0 = 0;
  FUN_005542c0("RightCollarAttachment",0x15);
  uStack_8._0_1_ = 0x4f;
  uStack_488 = 0;
  uStack_484 = 0xf;
  uStack_498 = 0;
  FUN_005542c0("RightElbow",10);
  uStack_8._0_1_ = 0x50;
  uStack_470 = 0;
  uStack_46c = 0xf;
  uStack_480 = 0;
  FUN_005542c0("RightElbowRigAttachment",0x17);
  uStack_8._0_1_ = 0x51;
  uStack_458 = 0;
  uStack_454 = 0xf;
  uStack_468 = 0;
  FUN_005542c0("RightFoot",9);
  uStack_8._0_1_ = 0x52;
  uStack_440 = 0;
  uStack_43c = 0xf;
  uStack_450 = 0;
  FUN_005542c0("RightGrip",9);
  uStack_8._0_1_ = 0x53;
  uStack_428 = 0;
  uStack_424 = 0xf;
  uStack_438 = 0;
  FUN_005542c0("RightGripAttachment",0x13);
  uStack_8._0_1_ = 0x54;
  uStack_410 = 0;
  uStack_40c = 0xf;
  uStack_420 = 0;
  FUN_005542c0("RightHand",9);
  uStack_8._0_1_ = 0x55;
  uStack_3f8 = 0;
  uStack_3f4 = 0xf;
  uStack_408 = 0;
  FUN_005542c0("RightHip",8);
  uStack_8._0_1_ = 0x56;
  uStack_3e0 = 0;
  uStack_3dc = 0xf;
  uStack_3f0 = 0;
  FUN_005542c0(&DAT_018db914,0x15);
  uStack_8._0_1_ = 0x57;
  uStack_3c8 = 0;
  uStack_3c4 = 0xf;
  uStack_3d8 = 0;
  FUN_005542c0("RightKnee",9);
  uStack_8._0_1_ = 0x58;
  uStack_3b0 = 0;
  uStack_3ac = 0xf;
  uStack_3c0 = 0;
  FUN_005542c0("RightKneeRigAttachment",0x16);
  uStack_8._0_1_ = 0x59;
  uStack_398 = 0;
  uStack_394 = 0xf;
  uStack_3a8 = 0;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_8._0_1_ = 0x5a;
  uStack_380 = 0;
  uStack_37c = 0xf;
  uStack_390 = 0;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_8._0_1_ = 0x5b;
  uStack_368 = 0;
  uStack_364 = 0xf;
  uStack_378 = 0;
  FUN_005542c0("RightShoulder",0xd);
  uStack_8._0_1_ = 0x5c;
  uStack_350 = 0;
  uStack_34c = 0xf;
  uStack_360 = 0;
  FUN_005542c0("RightShoulderAttachment",0x17);
  uStack_8._0_1_ = 0x5d;
  uStack_338 = 0;
  uStack_334 = 0xf;
  uStack_348 = 0;
  FUN_005542c0("RightShoulderRigAttachment",0x1a);
  uStack_8._0_1_ = 0x5e;
  uStack_320 = 0;
  uStack_31c = 0xf;
  uStack_330 = 0;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_8._0_1_ = 0x5f;
  uStack_308 = 0;
  uStack_304 = 0xf;
  uStack_318 = 0;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_8._0_1_ = 0x60;
  uStack_2f0 = 0;
  uStack_2ec = 0xf;
  uStack_300 = 0;
  FUN_005542c0("RightWrist",10);
  uStack_8._0_1_ = 0x61;
  uStack_2d8 = 0;
  uStack_2d4 = 0xf;
  uStack_2e8 = 0;
  FUN_005542c0("RightWristRigAttachment",0x17);
  uStack_8._0_1_ = 0x62;
  uStack_2c0 = 0;
  uStack_2bc = 0xf;
  uStack_2d0 = 0;
  FUN_005542c0(&DAT_018db9f8,4);
  uStack_8._0_1_ = 99;
  uStack_2a8 = 0;
  uStack_2a4 = 0xf;
  uStack_2b8 = 0;
  FUN_005542c0("RootPart",8);
  uStack_8._0_1_ = 100;
  uStack_290 = 0;
  uStack_28c = 0xf;
  uStack_2a0 = 0;
  FUN_005542c0("RootRigAttachment",0x11);
  uStack_8._0_1_ = 0x65;
  uStack_278 = 0;
  uStack_274 = 0xf;
  uStack_288 = 0;
  FUN_005542c0("RunAnim",7);
  uStack_8._0_1_ = 0x66;
  uStack_260 = 0;
  uStack_25c = 0xf;
  uStack_270 = 0;
  FUN_005542c0("Running",7);
  uStack_8._0_1_ = 0x67;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = 0;
  FUN_005542c0("ScaleDampeningPercent",0x15);
  uStack_8._0_1_ = 0x68;
  uStack_230 = 0;
  uStack_22c = 0xf;
  uStack_240 = 0;
  FUN_005542c0("SeatAttach",10);
  uStack_8._0_1_ = 0x69;
  uStack_218 = 0;
  uStack_214 = 0xf;
  uStack_228 = 0;
  FUN_005542c0("SitAnim",7);
  uStack_8._0_1_ = 0x6a;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = 0;
  FUN_005542c0("Sound",5);
  uStack_8._0_1_ = 0x6b;
  uStack_1e8 = 0;
  uStack_1e4 = 0xf;
  uStack_1f8 = 0;
  FUN_005542c0(&DAT_018dba64,4);
  uStack_8._0_1_ = 0x6c;
  uStack_1d0 = 0;
  uStack_1cc = 0xf;
  uStack_1e0 = 0;
  FUN_005542c0("SwimIdle",8);
  uStack_8._0_1_ = 0x6d;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = 0;
  FUN_005542c0("Swimming",8);
  uStack_8._0_1_ = 0x6e;
  uStack_1a0 = 0;
  uStack_19c = 0xf;
  uStack_1b0 = 0;
  FUN_005542c0("TipAttachment",0xd);
  uStack_8._0_1_ = 0x6f;
  uStack_188 = 0;
  uStack_184 = 0xf;
  uStack_198 = 0;
  FUN_005542c0("UpperTorso",10);
  uStack_8._0_1_ = 0x70;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = 0;
  FUN_005542c0("Volume",6);
  uStack_8._0_1_ = 0x71;
  uStack_158 = 0;
  uStack_154 = 0xf;
  uStack_168 = 0;
  FUN_005542c0("Waist",5);
  uStack_8._0_1_ = 0x72;
  uStack_140 = 0;
  uStack_13c = 0xf;
  uStack_150 = 0;
  FUN_005542c0("WaistBackAttachment",0x13);
  uStack_8._0_1_ = 0x73;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = 0;
  FUN_005542c0("WaistCenterAttachment",0x15);
  uStack_8._0_1_ = 0x74;
  uStack_110 = 0;
  uStack_10c = 0xf;
  uStack_120 = 0;
  FUN_005542c0("WaistFrontAttachment",0x14);
  uStack_8._0_1_ = 0x75;
  uStack_f8 = 0;
  uStack_f4 = 0xf;
  uStack_108 = 0;
  FUN_005542c0("WaistRigAttachment",0x12);
  uStack_8._0_1_ = 0x76;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = 0;
  FUN_005542c0("WalkAnim",8);
  uStack_8._0_1_ = 0x77;
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  uStack_d8 = 0;
  FUN_005542c0("WaveAnim",8);
  uStack_8._0_1_ = 0x78;
  uStack_b0 = 0;
  uStack_ac = 0xf;
  uStack_c0 = 0;
  FUN_005542c0(&DAT_018dbb20,6);
  uStack_8._0_1_ = 0x79;
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_a8 = 0;
  FUN_005542c0("Welded",6);
  uStack_8._0_1_ = 0x7a;
  uStack_80 = 0;
  uStack_7c = 0xf;
  uStack_90 = 0;
  FUN_005542c0(&DAT_018dbb30,4);
  uStack_8._0_1_ = 0x7b;
  uStack_68 = 0;
  uStack_64 = 0xf;
  uStack_78 = 0;
  FUN_005542c0(&DAT_018dbb38,4);
  uStack_8._0_1_ = 0x7c;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  FUN_005542c0(&DAT_018dbb40,3);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x7d);
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = 0;
  FUN_005542c0(&DAT_018dbb44,4);
  uStack_8 = 0x7e;
  FUN_0060ec70(auStack_c00,auStack_30,&uStack_11);
  uStack_20 = 1;
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_016f32d1(auStack_c00,0x18,0x7e,FUN_005507b0);
  if (DAT_01d5b438 != 0) {
    FUN_0056a3e0(&DAT_01d5b428);
    while (iStack_18 != 0) {
      FUN_006b7760(auStack_30,0x3b);
      iStack_18 = iStack_24;
      if (iStack_2c != 0) {
        uVar1 = FUN_0058c4f0(auStack_c18);
        uStack_8 = 0x7f;
        FUN_0058d640(uVar1);
        uStack_8 = uStack_8 & 0xffffff00;
        FUN_005507b0();
        iStack_18 = iStack_24;
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8837 ; VA 0x006b4f70 ; FUN_006b4f70 */

void FUN_006b4f70(undefined8 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined8 *puVar4;
  byte bStack_f;
  undefined4 uStack_c;
  
  iVar2 = param_2;
  iVar3 = FUN_006b5480(&param_2);
  puVar4 = (undefined8 *)(-(uint)(iVar3 != 0) & iVar3 + 4U);
  if (puVar4 != (undefined8 *)0x0) {
    uVar1 = *(undefined4 *)(puVar4 + 1);
    *param_1 = *puVar4;
    *(undefined4 *)(param_1 + 1) = uVar1;
    return;
  }
  switch(*(undefined4 *)(iVar2 + 0x1c)) {
  case 1:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,9)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 2:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,10)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 3:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x2c)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 4:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0xb)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 5:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0xc)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 6:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,2)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  default:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,(ushort)bStack_f << 8));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 8:
  case 0x31:
  case 0x32:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x1c)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 10:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0xf)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0xb:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x15)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0xc:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x16)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0xd:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x18)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0xe:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x19)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0xf:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x28)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x10:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x1b)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x11:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x13)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x12:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x14)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x13:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0xd)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x14:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0xe)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x15:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x10)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x16:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x11)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x17:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x2a)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x18:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x2b)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x1b:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x29)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x1c:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x12)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x1d:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x22)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x1e:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,8)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x22:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x1d)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x23:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x1e)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x24:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x1f)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x25:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x20)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x29:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x26)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x2a:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x27)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x2b:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x25)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x2c:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x23)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x2d:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x24)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x30:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x21)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x3a:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x2d)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x3b:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,0x2e)));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  case 0x3c:
    *param_1 = CONCAT44(uStack_c,CONCAT22(0xffff,CONCAT11(bStack_f,-(DAT_01d5b420 != '\0')) & 0xff30
                                         ));
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  }
}



/* FUNCTION 8838 ; VA 0x006b5480 ; FUN_006b5480 */

uint * __thiscall FUN_006b5480(int *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  
  iVar1 = *param_1;
  if (iVar1 != param_1[1]) {
    uVar2 = *param_2;
    if (uVar2 != param_1[4]) {
      uVar4 = (uVar2 >> 3) + uVar2;
      uVar7 = (param_1[1] - iVar1 >> 4) - 1;
      uVar6 = 0;
      do {
        uVar4 = uVar4 & uVar7;
        puVar5 = (uint *)(uVar4 * 0x10 + iVar1);
        uVar3 = *puVar5;
        if (uVar3 == uVar2) {
          return puVar5;
        }
        if (uVar3 == param_1[4]) {
          return (uint *)0x0;
        }
        uVar4 = uVar4 + 1 + uVar6;
        uVar6 = uVar6 + 1;
      } while (uVar6 <= uVar7);
    }
  }
  return (uint *)0x0;
}



/* FUNCTION 8839 ; VA 0x006b54f0 ; FUN_006b54f0 */

void FUN_006b54f0(int param_1,int param_2)

{
  uint *puVar1;
  uint uVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined8 *puVar8;
  undefined4 uVar9;
  uint uVar10;
  int *piVar11;
  int *piVar12;
  short sVar13;
  int *piVar14;
  undefined auStack_dc [12];
  undefined4 uStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  uint uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b4 [12];
  int iStack_a8;
  int iStack_a0;
  undefined4 uStack_8c;
  int iStack_88;
  undefined4 uStack_84;
  int iStack_80;
  undefined8 uStack_7c;
  int iStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  char cStack_58;
  undefined uStack_57;
  undefined2 uStack_56;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  int *piStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  uint uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  char acStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7081;
  pvStack_10 = ExceptionList;
  uStack_d0 = CONCAT31(uStack_d0._1_3_,param_1 == 2);
  ExceptionList = &pvStack_10;
  FUN_006ab530();
  uStack_8 = 0;
  iStack_80 = 0;
  iStack_74 = 0;
  uStack_7c = 0;
  FUN_006b3040(0,&iStack_80,auStack_18);
  uStack_c0 = 0;
  uStack_bc = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_4c = (int *)FUN_009cb210();
  FUN_006ad4e0(piStack_4c,auStack_b4);
  FUN_009cb3c0(&piStack_24);
  piVar4 = (int *)FUN_009cb3e0(&piStack_2c);
  uVar10 = 0;
  sVar13 = 0;
  if (piStack_24 != (int *)*piVar4) {
    do {
      piStack_1c = (int *)*piStack_24;
      if ((uint)((iStack_c8 - iStack_cc >> 4) * 3) >> 2 <= uVar10) {
        FUN_006b7170();
      }
      iVar5 = FUN_006b6b20(&piStack_1c);
      *(short *)(iVar5 + 6) = sVar13;
      *(undefined *)(iVar5 + 4) = 7;
      FUN_006ad360(*(undefined4 *)(*piStack_24 + 4),auStack_b4);
      acStack_14[0] = *(char *)(iVar5 + 4);
      FUN_006ad5e0(acStack_14,1);
      piStack_24 = piStack_24 + 1;
      piVar4 = (int *)FUN_009cb3e0(&piStack_2c);
      uVar10 = uStack_c0;
      sVar13 = sVar13 + 1;
    } while (piStack_24 != (int *)*piVar4);
  }
  if (0xfffe < piStack_4c) {
    FUN_016756b0(&uStack_70,"Cannot construct schema, too many enum types");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_70,&DAT_01c17198);
  }
  piStack_24 = (int *)0x0;
  piStack_64 = (int *)0x0;
  piStack_60 = (int *)0x0;
  piStack_4c = (int *)0x0;
  piStack_5c = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar6 = (undefined4 *)FUN_00892910();
  piVar4 = (int *)*puVar6;
  iVar5 = FUN_00892910();
  if (piVar4 == *(int **)(iVar5 + 4)) {
    piVar4 = (int *)0x0;
  }
  else {
    do {
      iVar5 = *piVar4;
      iVar7 = FUN_00892e40(*(undefined4 *)(iVar5 + 4));
      piVar12 = piStack_60;
      if (((iVar7 != 0) && ((*(byte *)(iVar5 + 0x1d4) & 3) != 0)) ||
         ((*(uint *)(iVar5 + 0x1d4) >> 4 & 1) != 0)) {
        uStack_8c = 0;
        iStack_88 = 0;
        uStack_84 = 0;
        iStack_80 = 0;
        uStack_7c = 0;
        iStack_74 = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (piStack_4c == piStack_60) {
          FUN_006b22c0(piStack_60,&uStack_8c);
          piStack_4c = piStack_5c;
        }
        else {
          FUN_006b2f00(&piStack_64);
          piStack_60 = piVar12 + 7;
        }
        piVar12 = piStack_60;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if ((int)uStack_7c != 0) {
          uVar10 = (iStack_74 - (int)uStack_7c >> 2) * 4;
          iVar5 = (int)uStack_7c;
          if (0xfff < uVar10) {
            iVar5 = *(int *)((int)uStack_7c + -4);
            uVar10 = uVar10 + 0x23;
            if (0x1f < ((int)uStack_7c - iVar5) - 4U) goto LAB_006b5f60;
          }
          FUN_01674ea0(iVar5,uVar10);
          uStack_7c = 0;
          iStack_74 = 0;
        }
        if (iStack_88 != 0) {
          uVar10 = (iStack_80 - iStack_88 >> 2) * 4;
          iVar5 = iStack_88;
          if (0xfff < uVar10) {
            iVar5 = *(int *)(iStack_88 + -4);
            uVar10 = uVar10 + 0x23;
            if (0x1f < (iStack_88 - iVar5) - 4U) goto LAB_006b5f60;
          }
          FUN_01674ea0(iVar5,uVar10);
          iStack_88 = 0;
          uStack_84 = 0;
          iStack_80 = 0;
        }
        piVar12[-7] = *piVar4;
      }
      piVar4 = piVar4 + 1;
      iVar5 = FUN_00892910();
    } while (piVar4 != *(int **)(iVar5 + 4));
    piStack_24 = piStack_64;
    piVar4 = piStack_64;
  }
  piStack_28 = (int *)0x0;
  uStack_44 = 0;
  if (piVar4 != piStack_60) {
    piVar4 = piVar4 + 2;
    do {
      piStack_20 = (int *)piVar4[-2];
      piStack_1c = (int *)0x0;
      uStack_30 = 0;
      piVar12 = (int *)piStack_20[6];
      piStack_34 = (int *)((piStack_20[7] - (int)piVar12) + 3U >> 2);
      if ((int *)piStack_20[7] < piVar12) {
        piStack_34 = (int *)0;
      }
      piStack_48 = piVar4;
      if (piStack_34 != (int *)0x0) {
        do {
          piStack_2c = (int *)*piVar12;
          piStack_1c = piStack_2c;
          cVar3 = FUN_00618b80(uStack_d0,piStack_2c);
          if (cVar3 != '\0') {
            piVar14 = (int *)*piVar4;
            if ((int *)piVar4[1] == piVar14) {
              FUN_006030d0(piVar14,&piStack_2c);
            }
            else {
              *piVar14 = (int)piStack_1c;
              *piVar4 = *piVar4 + 4;
            }
            piStack_28 = (int *)((int)piStack_28 + 1);
          }
          piVar12 = piVar12 + 1;
          uStack_30 = uStack_30 + 1;
        } while ((int *)uStack_30 != piStack_34);
      }
      piVar4 = (int *)piStack_20[0x1d];
      piStack_2c = (int *)piStack_20[0x1c];
      piStack_34 = piVar4;
      if (piStack_2c != piVar4) {
        do {
          piVar12 = (int *)*piStack_2c;
          acStack_14[0] = '\x01';
          piVar14 = (int *)piVar12[10];
          uStack_30 = (uint)piVar12;
          piStack_20 = piVar14;
          piStack_1c = piVar12;
          if (piVar14 == (int *)piVar12[0xb]) {
LAB_006b58f2:
            piVar12 = piStack_2c;
            puVar1 = (uint *)piStack_48[3];
            if ((uint *)piStack_48[4] == puVar1) {
              FUN_006030d0(puVar1,&piStack_1c);
            }
            else {
              *puVar1 = uStack_30;
              piStack_48[3] = piStack_48[3] + 4;
            }
            uStack_44 = uStack_44 + 1;
          }
          else {
            do {
              puVar8 = (undefined8 *)FUN_006b4f70(&uStack_40,piVar14[1],&iStack_cc);
              uStack_70 = *puVar8;
              uStack_68 = *(undefined4 *)(puVar8 + 1);
              if ((acStack_14[0] == '\0') || ((char)uStack_70 == '\0')) {
                acStack_14[0] = '\0';
              }
              else {
                acStack_14[0] = '\x01';
              }
              piVar14 = piVar14 + 0x36;
            } while (piVar14 != (int *)piVar12[0xb]);
            piVar12 = piStack_2c;
            piVar4 = piStack_34;
            if (acStack_14[0] != '\0') goto LAB_006b58f2;
          }
          piStack_2c = piVar12 + 1;
        } while (piStack_2c != piVar4);
      }
      piVar4 = piStack_48 + 7;
      piVar12 = piStack_48 + 5;
      piStack_48 = piVar4;
    } while (piVar12 != piStack_60);
  }
  uVar2 = uStack_44;
  piStack_2c = (int *)0x0;
  uVar10 = ((int)piStack_60 - (int)piStack_24) / 0x1c;
  if (((0xfffe < uVar10) || ((int *)0xfffe < piStack_28)) ||
     (piVar4 = piStack_24, 0xfffe < uStack_44)) {
    FUN_016756b0(&uStack_70,"Cannot construct schema, too many classes, properties, or events");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_70,&DAT_01c17198);
  }
  for (; piVar4 != piStack_60; piVar4 = piVar4 + 7) {
    if (0xff < (uint)(piVar4[2] - piVar4[1] >> 2)) {
      uVar9 = FUN_005543f0();
      FUN_016756b0(&uStack_70,"Cannot construct schema, too many properties for %s",uVar9);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&uStack_70,&DAT_01c17198);
    }
  }
  FUN_006ad4e0(uVar10,auStack_b4);
  FUN_006ad4e0(piStack_28,auStack_b4);
  FUN_006ad4e0(uVar2,auStack_b4);
  if (piStack_24 != piStack_60) {
    piVar4 = piStack_24 + 5;
    do {
      piStack_28 = piVar4;
      FUN_006ad360(*(undefined4 *)(piVar4[-5] + 4),auStack_b4);
      FUN_006ad4e0(piVar4[-3] - piVar4[-4] >> 2,auStack_b4);
      piStack_1c = (int *)0xffff;
      piVar4 = (int *)piStack_28[-4];
      piStack_34 = (int *)piStack_28[-3];
      if (piVar4 != piStack_34) {
        do {
          piVar12 = piStack_1c;
          FUN_006ad360(*(undefined4 *)(*piVar4 + 4),auStack_b4);
          acStack_14[0] = '\0';
          piStack_20 = (int *)piStack_28[-5];
          iVar5 = *(int *)((undefined *)*piVar4 + 0x28);
          uStack_56 = 0xffff;
          switch(*(undefined4 *)(iVar5 + 0x1c)) {
          case 6:
            uStack_38 = uStack_50;
            if ((undefined *)*piVar4 == &DAT_0211a3a0) {
              cStack_58 = '1';
              uStack_40 = CONCAT44(uStack_54,CONCAT22(0xffff,CONCAT11(uStack_57,0x31)));
            }
            else {
              cStack_58 = '\x02';
              uStack_40 = CONCAT44(uStack_54,CONCAT22(0xffff,CONCAT11(uStack_57,2)));
            }
            break;
          case 7:
            acStack_14[0] = '\x01';
            if ((param_1 == 2) || (cVar3 = FUN_00554b40(), cVar3 == '\0')) {
              cStack_58 = '\x06';
              uStack_40 = CONCAT44(uStack_54,CONCAT22(uStack_56,CONCAT11(uStack_57,6)));
              uStack_38 = uStack_50;
            }
            else {
              uVar9 = FUN_00b73ae0();
              cVar3 = FUN_00892700(uVar9);
              cStack_58 = (-(cVar3 != '\0') & 0xd4U) + 0x2f;
              uStack_40 = CONCAT44(uStack_54,CONCAT22(uStack_56,CONCAT11(uStack_57,cStack_58)));
              uStack_38 = uStack_50;
            }
            break;
          default:
            puVar8 = (undefined8 *)FUN_006b4f70(auStack_dc,iVar5,&iStack_cc);
            uStack_40 = *puVar8;
            uStack_38 = *(undefined4 *)(puVar8 + 1);
            break;
          case 0xc:
            cStack_58 = '\x16';
            uStack_40 = CONCAT44(uStack_54,CONCAT22(0xffff,CONCAT11(uStack_57,0x16)));
            uStack_38 = uStack_50;
            break;
          case 0x10:
            cStack_58 = (param_1 != 2) + '\x1a';
            uStack_40 = CONCAT44(uStack_54,CONCAT22(0xffff,CONCAT11(uStack_57,cStack_58)));
            uStack_38 = uStack_50;
          }
          auStack_18[0] = (char)uStack_40;
          FUN_006ad5e0(auStack_18,1);
          if ((char)uStack_40 == '\a') {
            piStack_20 = (int *)(uint)uStack_40._2_2_;
            FUN_006a5c10(&piStack_20,&uStack_30,2);
            FUN_006ad5e0(&uStack_30,2);
          }
          if (acStack_14[0] != '\0') {
            if ((uint)((*(int *)(param_2 + 0x54) - *(int *)(param_2 + 0x50) >> 2) * 3) >> 2 <=
                *(uint *)(param_2 + 0x5c)) {
              FUN_006286d0();
            }
            FUN_00620c30(piStack_28 + -5);
            piVar12 = piStack_1c;
          }
          piStack_1c = piStack_2c;
          if ((undefined4 *)*piVar4 != &DAT_0212a430) {
            piStack_1c = piVar12;
          }
          piStack_1c = (int *)((uint)piStack_1c & 0xffff);
          piStack_2c = (int *)((int)piStack_2c + 1);
          piVar4 = piVar4 + 1;
        } while (piVar4 != piStack_34);
      }
      piStack_20 = piStack_1c;
      FUN_006a5c10(&piStack_20,&uStack_44,2);
      FUN_006ad5e0(&uStack_44,2);
      piVar12 = piStack_28;
      FUN_006ad4e0(*piStack_28 - piStack_28[-1] >> 2,auStack_b4);
      piStack_34 = (int *)*piVar12;
      piVar4 = (int *)piVar12[-1];
      piStack_1c = piVar4;
      if (piVar4 != piStack_34) {
        do {
          piStack_1c = piVar4;
          FUN_006ad360(*(undefined4 *)(*piVar4 + 4),auStack_b4);
          iVar5 = *piVar4;
          FUN_006ad4e0((*(int *)(iVar5 + 0x2c) - *(int *)(iVar5 + 0x28)) / 0xd8,auStack_b4);
          piVar14 = *(int **)(iVar5 + 0x2c);
          piStack_20 = piVar14;
          piVar12 = piStack_28;
          for (piVar11 = *(int **)(iVar5 + 0x28); piStack_28 = piVar12, piVar11 != piVar14;
              piVar11 = piVar11 + 0x36) {
            puVar8 = (undefined8 *)FUN_006b4f70(&uStack_7c,piVar11[1],&iStack_cc);
            uStack_70 = *puVar8;
            auStack_18[0] = (char)uStack_70;
            FUN_006ad5e0(auStack_18,1);
            piStack_20 = (int *)(uint)uStack_70._2_2_;
            FUN_006a5c10(&piStack_20,&piStack_48,2);
            FUN_006ad5e0(&piStack_48,2);
            piVar4 = piStack_1c;
            piVar12 = piStack_28;
          }
          piVar4 = piVar4 + 1;
          piStack_1c = piVar4;
        } while (piVar4 != piStack_34);
      }
      piVar4 = piVar12 + 7;
      piStack_28 = piVar4;
    } while (piVar12 + 2 != piStack_60);
  }
  FUN_006ad4e0((DAT_01eaec78 - DAT_01eaec74) / 0x18,auStack_b4);
  iVar7 = DAT_01eaec78;
  for (iVar5 = DAT_01eaec74; iVar5 != iVar7; iVar5 = iVar5 + 0x18) {
    FUN_006ad360(iVar5,auStack_b4);
  }
  FUN_006b3680(&uStack_40);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_006ad4e0((uStack_40._4_4_ - (int)uStack_40) / 0x18,auStack_b4);
  iVar7 = uStack_40._4_4_;
  for (iVar5 = (int)uStack_40; iVar5 != iVar7; iVar5 = iVar5 + 0x18) {
    FUN_006ad360(iVar5,auStack_b4);
  }
  uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577a40();
  iVar5 = param_2;
  param_1 = CONCAT31(param_1._1_3_,0x97);
  FUN_006ad5e0(&param_1,1);
  FUN_00619a10(auStack_b4,iVar5,DAT_01d5b3e0);
  piVar12 = piStack_60;
  piVar4 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    for (; piVar4 != piVar12; piVar4 = piVar4 + 7) {
      FUN_006b3360();
    }
    uVar10 = (((int)piStack_4c - (int)piStack_24) / 0x1c) * 0x1c;
    piVar4 = piStack_24;
    if (0xfff < uVar10) {
      piVar4 = (int *)piStack_24[-1];
      uVar10 = uVar10 + 0x23;
      if (0x1f < (uint)((int)piStack_24 + (-4 - (int)piVar4))) {
LAB_006b5f60:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar4,uVar10);
  }
  if (iStack_cc != 0) {
    uVar10 = iStack_c4 - iStack_cc & 0xfffffff0;
    iVar5 = iStack_cc;
    if (0xfff < uVar10) {
      iVar5 = *(int *)(iStack_cc + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iStack_cc - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar10);
  }
  if (iStack_a8 != 0) {
    uVar10 = iStack_a0 - iStack_a8;
    iVar5 = iStack_a8;
    if (0xfff < uVar10) {
      iVar5 = *(int *)(iStack_a8 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iStack_a8 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8840 ; VA 0x006b5f90 ; FUN_006b5f90 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_006b5f90(undefined *param_1,undefined4 *param_2,int param_3)

{
  undefined2 uVar1;
  bool bVar2;
  undefined *puVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  undefined4 *******pppppppuVar13;
  undefined *puVar14;
  double *pdVar15;
  uint uVar16;
  ushort uVar17;
  int *piVar18;
  double dStack_110;
  uint auStack_108 [4];
  undefined4 uStack_f8;
  uint uStack_f4;
  undefined auStack_f0 [36];
  undefined auStack_cc [4];
  uint uStack_c8;
  undefined auStack_c4 [24];
  int iStack_ac;
  undefined4 *puStack_a8;
  int *piStack_a4;
  undefined auStack_a0 [12];
  int iStack_94;
  int iStack_8c;
  int iStack_88;
  int iStack_80;
  undefined4 *******apppppppuStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint auStack_60 [6];
  undefined4 uStack_48;
  int *piStack_44;
  int iStack_40;
  uint uStack_3c;
  uint uStack_38;
  int *piStack_34;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a70f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_016827e0(&dStack_110);
  puVar9 = param_2;
  FUN_006abe40();
  FUN_006ab530();
  iStack_8 = 0;
  FUN_0061a740(puVar9,auStack_a0);
  FUN_006abc60(&piStack_18,auStack_a0);
  piVar7 = (int *)(param_1 + 0x4c);
  piStack_1c = piVar7;
  FUN_0055b820(piStack_18,piVar7);
  uVar5 = 0;
  if (piStack_18 != (int *)0x0) {
    do {
      uStack_f8 = 0;
      uStack_f4 = 0xf;
      auStack_108[0] = auStack_108[0] & 0xffffff00;
      iStack_8._0_1_ = 1;
      FUN_006ab8e0(auStack_108,auStack_a0);
      cVar4 = FUN_006abe60((int)&param_2 + 3,1);
      if (cVar4 == '\0') {
        FUN_0054eff0("readFast past end for uint8_t");
        iStack_8 = CONCAT31(iStack_8._1_3_,2);
        FUN_005f8ef0(auStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_f0,&DAT_01c27108);
      }
      iStack_40 = (uint)uVar5 * 4;
      *(undefined4 *)(iStack_40 + *piVar7) = 0;
      iVar6 = FUN_0086e830(auStack_108);
      param_1 = puStack_14;
      if (*(int *)(iVar6 + 0x10) != 0) {
        piVar7 = (int *)FUN_00888c80();
        param_1 = puStack_14;
        uVar16 = 0;
        uVar8 = piVar7[1] - *piVar7 >> 2;
        if (uVar8 != 0) {
          do {
            piVar18 = *(int **)(*piVar7 + uVar16 * 4);
            if (piVar18[1] == iVar6) goto LAB_006b60bf;
            uVar16 = uVar16 + 1;
          } while (uVar16 < uVar8);
        }
        piVar18 = (int *)0x0;
LAB_006b60bf:
        piVar7 = piStack_1c;
        piStack_44 = piVar18;
        if ((piVar18 != (int *)0x0) && (*(char *)((int)piVar18 + 0x22) != '\0')) {
          if ((uint)((*(int *)(puStack_14 + 8) - *(int *)(puStack_14 + 4) >> 4) * 3) >> 2 <=
              *(uint *)(puStack_14 + 0x10)) {
            FUN_006b7170();
          }
          iVar6 = FUN_006b6b20(&piStack_44);
          *(undefined *)(iVar6 + 4) = param_2._3_1_;
          *(ushort *)(iVar6 + 6) = uVar5;
          *(int **)(iVar6 + 8) = piVar18;
          *(int **)(iStack_40 + *(int *)(param_1 + 0x4c)) = piVar18;
          piVar7 = piStack_1c;
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_f4) {
        uVar16 = uStack_f4 + 1;
        uVar8 = auStack_108[0];
        if (0xfff < uVar16) {
          uVar8 = *(uint *)(auStack_108[0] - 4);
          uVar16 = uStack_f4 + 0x24;
          if (0x1f < (auStack_108[0] - uVar8) - 4) goto LAB_006b6b0e;
        }
        FUN_01674ea0(uVar8,uVar16);
      }
      uVar5 = uVar5 + 1;
    } while ((int *)(uint)uVar5 < piStack_18);
  }
  uStack_3c = 0;
  FUN_006abc60(&uStack_3c,auStack_a0);
  auStack_60[3] = 0;
  FUN_006abc60(auStack_60 + 3,auStack_a0);
  auStack_60[2] = 0;
  FUN_006abc60(auStack_60 + 2,auStack_a0);
  piVar7 = (int *)(param_1 + 0x58);
  piStack_44 = piVar7;
  FUN_006b29f0(uStack_3c,piVar7);
  piStack_a4 = (int *)(param_1 + 100);
  FUN_006b25d0(auStack_60[3] + 1,piStack_a4);
  puStack_a8 = (undefined4 *)(param_1 + 0x70);
  FUN_006b27b0(auStack_60[2],puStack_a8);
  uStack_64 = 0xf;
  uStack_30 = 0;
  uStack_24 = 0;
  uStack_68 = 0;
  apppppppuStack_78[0] = (undefined4 *******)((uint)apppppppuStack_78[0] & 0xffffff00);
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  auStack_60[4] = 0;
  if (uStack_3c != 0) {
    uVar8 = 0;
    do {
      uVar12 = uStack_24;
      uVar16 = auStack_60[4];
      FUN_006ab8e0(apppppppuStack_78,auStack_a0);
      piStack_1c = (int *)(uVar8 * 0xf);
      iStack_2c = *piStack_44;
      *(short *)(iStack_2c + uVar8 * 0x3c) = (short)uVar16;
      iVar6 = FUN_0086e830(apppppppuStack_78);
      if (*(int *)(iVar6 + 0x10) != 0) {
        puVar9 = (undefined4 *)FUN_00892910();
        piVar7 = (int *)*puVar9;
        iVar10 = FUN_00892910();
        for (; piVar7 != *(int **)(iVar10 + 4); piVar7 = piVar7 + 1) {
          iVar11 = *piVar7;
          if (*(int *)(iVar11 + 4) == iVar6) goto LAB_006b6270;
        }
      }
      iVar11 = 0;
LAB_006b6270:
      piVar7 = piStack_1c;
      piStack_18 = (int *)(iStack_2c + (int)piStack_1c * 4 + 8);
      *piStack_18 = iVar11;
      if (iVar11 != 0) {
        if ((uint)((*(int *)(puStack_14 + 0x20) - *(int *)(puStack_14 + 0x1c) >> 3) * 3) >> 2 <=
            *(uint *)(puStack_14 + 0x28)) {
          FUN_006b7040();
        }
        iVar6 = FUN_00620bc0(piStack_18);
        *(short *)(iVar6 + 4) = (short)auStack_60[4];
      }
      auStack_60[1] = 0;
      FUN_006abc60(auStack_60 + 1,auStack_a0);
      uVar17 = (ushort)uVar12;
      *(ushort *)(iStack_2c + 2 + (int)piVar7 * 4) = uVar17;
      uVar5 = (short)auStack_60[1] + uVar17;
      *(ushort *)(iStack_2c + 4 + (int)piVar7 * 4) = uVar5;
      if (uVar17 < uVar5) {
        do {
          FUN_006ab8e0(apppppppuStack_78,auStack_a0);
          cVar4 = FUN_006abe60(&uStack_48,1);
          if (cVar4 == '\0') {
            FUN_0054eff0("readFast past end for uint8_t");
            iStack_8 = CONCAT31(iStack_8._1_3_,4);
            FUN_005f8ef0(auStack_c4);
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_f0,&DAT_01c27108);
          }
          uStack_20 = 0xffff;
          if ((char)uStack_48 == '\a') {
            cVar4 = FUN_006abe60(&uStack_20,2);
            if (cVar4 == '\0') {
              FUN_0054eff0("readFast past end for uint16_t");
              iStack_8 = CONCAT31(iStack_8._1_3_,5);
              FUN_005f8ef0(auStack_c4);
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_f0,&DAT_01c27108);
            }
            uStack_20 = (uint)(ushort)((ushort)uStack_20 << 8 | (ushort)uStack_20 >> 8);
          }
          uVar8 = uVar12 & 0xffff;
          iVar6 = *piStack_a4;
          *(short *)(iVar6 + uVar8 * 0x14) = (short)uVar12;
          piStack_34 = (int *)(iVar6 + 0x10 + uVar8 * 0x14);
          *piStack_34 = 0;
          *(char *)(iVar6 + 4 + uVar8 * 0x14) = (char)uStack_48;
          *(ushort *)(iVar6 + 6 + uVar8 * 0x14) = (ushort)uStack_20;
          if ((ushort)uStack_20 == -1) {
            *(undefined4 *)(iVar6 + 8 + uVar8 * 0x14) = 0;
          }
          else {
            *(undefined4 *)(iVar6 + 8 + uVar8 * 0x14) =
                 *(undefined4 *)(*(int *)(puStack_14 + 0x4c) + uStack_20 * 4);
          }
          if (*piStack_18 != 0) {
            pppppppuVar13 = apppppppuStack_78;
            if (0xf < uStack_64) {
              pppppppuVar13 = apppppppuStack_78[0];
            }
            iVar10 = FUN_00892d20(pppppppuVar13);
            if (((iVar10 != 0) &&
                (cVar4 = FUN_006b6d40(*(undefined4 *)(iVar10 + 0x28),uStack_48,uStack_20,
                                      puStack_14 + 4,iVar6 + 0xc + uVar8 * 0x14), cVar4 != '\0')) &&
               (cVar4 = FUN_00618b80(param_3,iVar10), piVar7 = piStack_34, cVar4 != '\0')) {
              iVar6 = iStack_2c + (int)piStack_1c * 4;
              *piStack_34 = iVar10;
              if ((uint)((*(int *)(iVar6 + 0x10) - *(int *)(iVar6 + 0xc) >> 3) * 3) >> 2 <=
                  *(uint *)(iVar6 + 0x18)) {
                FUN_006b7040();
              }
              iVar6 = FUN_00620bc0(piVar7);
              *(short *)(iVar6 + 4) = (short)uStack_24;
            }
          }
          uVar12 = uStack_24 + 1;
          uStack_24 = uVar12;
        } while ((ushort)uVar12 < *(ushort *)(iStack_2c + 4 + (int)piStack_1c * 4));
      }
      cVar4 = FUN_006abe60(auStack_60,2);
      piVar7 = piStack_18;
      if (cVar4 == '\0') {
        FUN_0054eff0("readFast past end for uint16_t");
        iStack_8 = CONCAT31(iStack_8._1_3_,6);
        FUN_005f8ef0(auStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_f0,&DAT_01c27108);
      }
      uVar5 = (ushort)auStack_60[0] << 8 | (ushort)auStack_60[0] >> 8;
      auStack_60[0] = (uint)uVar5;
      if ((*piStack_18 != 0) && (uVar5 != 0xffff)) {
        if ((uint)((*(int *)(puStack_14 + 0x38) - *(int *)(puStack_14 + 0x34) >> 3) * 3) >> 2 <=
            *(uint *)(puStack_14 + 0x40)) {
          FUN_006b7040();
        }
        iVar6 = FUN_00620bc0(piVar7);
        *(ushort *)(iVar6 + 4) = uVar5;
      }
      iStack_40 = 0;
      FUN_006abc60(&iStack_40,auStack_a0);
      uStack_c8 = iStack_40 + uStack_30 & 0xffff;
      if ((ushort)uStack_30 < (ushort)(iStack_40 + uStack_30)) {
        do {
          uVar8 = uStack_30;
          FUN_006ab8e0(apppppppuStack_78,auStack_a0);
          uVar16 = uVar8 & 0xffff;
          iVar6 = uVar16 * 5;
          piVar18 = (int *)*puStack_a8;
          *(short *)(piVar18 + uVar16 * 5) = (short)uVar8;
          uStack_28 = 0;
          auStack_60[5] = iVar6;
          piStack_34 = piVar18;
          FUN_006abc60(&uStack_28,auStack_a0);
          piVar7 = piVar18 + iVar6 + 1;
          FUN_006b2d20(uStack_28,piVar7);
          uVar8 = 0;
          if (uStack_28 != 0) {
            iVar6 = 0;
            do {
              cVar4 = FUN_006abe60((int)&param_2 + 3,1);
              if (cVar4 == '\0') {
                FUN_0054eff0("readFast past end for uint8_t");
                iStack_8 = CONCAT31(iStack_8._1_3_,7);
                FUN_005f8ef0(auStack_c4);
                    /* WARNING: Subroutine does not return */
                FUN_0170c2a8(auStack_f0,&DAT_01c27108);
              }
              cVar4 = FUN_006abe60(&uStack_38,2);
              if (cVar4 == '\0') {
                FUN_0054eff0("readFast past end for uint16_t");
                iStack_8 = CONCAT31(iStack_8._1_3_,8);
                FUN_005f8ef0(auStack_c4);
                    /* WARNING: Subroutine does not return */
                FUN_0170c2a8(auStack_f0,&DAT_01c27108);
              }
              uVar5 = (ushort)uStack_38 << 8 | (ushort)uStack_38 >> 8;
              uStack_38 = (uint)uVar5;
              *(undefined *)(iVar6 + *piVar7) = param_2._3_1_;
              *(ushort *)(*piVar7 + 2 + iVar6) = uVar5;
              if (uVar5 == 0xffff) {
                *(undefined4 *)(*piVar7 + 4 + iVar6) = 0;
              }
              else {
                *(undefined4 *)(*piVar7 + 4 + iVar6) =
                     *(undefined4 *)(*(int *)(puStack_14 + 0x4c) + uStack_38 * 4);
              }
              uVar8 = uVar8 + 1;
              iVar6 = iVar6 + 0xc;
              piVar18 = piStack_34;
            } while (uVar8 < uStack_28);
          }
          piVar18[auStack_60[5] + 4] = 0;
          if (*piStack_18 != 0) {
            pppppppuVar13 = apppppppuStack_78;
            if (0xf < uStack_64) {
              pppppppuVar13 = apppppppuStack_78[0];
            }
            iStack_ac = FUN_00892d20(pppppppuVar13);
            if ((iStack_ac != 0) &&
               (iVar6 = *(int *)(iStack_ac + 0x28),
               uStack_28 == (*(int *)(iStack_ac + 0x2c) - iVar6) / 0xd8)) {
              bVar2 = true;
              iVar10 = 0;
              do {
                if (iVar6 == *(int *)(iStack_ac + 0x2c)) {
                  if (bVar2) {
                    piVar7 = piStack_34 + auStack_60[5] + 4;
                    *piVar7 = iStack_ac;
                    iVar6 = iStack_2c + (int)piStack_1c * 4;
                    if ((uint)((*(int *)(iVar6 + 0x28) - *(int *)(iVar6 + 0x24) >> 3) * 3) >> 2 <=
                        *(uint *)(iVar6 + 0x30)) {
                      FUN_006b7040();
                    }
                    iVar6 = FUN_00620bc0(piVar7);
                    *(short *)(iVar6 + 4) = (short)uStack_30;
                  }
                  break;
                }
                iVar11 = piStack_34[auStack_60[5] + 1];
                if ((bVar2) &&
                   (cVar4 = FUN_006b6d40(*(undefined4 *)(iVar6 + 4),*(undefined *)(iVar11 + iVar10),
                                         *(undefined2 *)(iVar11 + 2 + iVar10),puStack_14 + 4,
                                         iVar11 + 8 + iVar10), cVar4 != '\0')) {
                  bVar2 = true;
                }
                else {
                  bVar2 = false;
                }
                iVar6 = iVar6 + 0xd8;
                iVar10 = iVar10 + 0xc;
              } while (bVar2);
            }
          }
          uStack_30 = uStack_30 + 1;
        } while ((ushort)uStack_30 < (ushort)uStack_c8);
      }
      auStack_60[4] = auStack_60[4] + 1;
      uVar8 = auStack_60[4] & 0xffff;
      piVar7 = piStack_44;
    } while (uVar8 < uStack_3c);
  }
  uVar8 = uStack_24 & 0xffff;
  *(short *)(puStack_14 + 0x7c) = (short)uStack_24;
  iVar6 = *(int *)(puStack_14 + 100);
  *(short *)(iVar6 + uVar8 * 0x14) = (short)uStack_24;
  *(undefined4 **)(iVar6 + 0x10 + uVar8 * 0x14) = &DAT_0211a3d8;
  *(undefined *)(iVar6 + 4 + uVar8 * 0x14) = 0x1c;
  *(undefined2 *)(iVar6 + 6 + uVar8 * 0x14) = 0xffff;
  param_3 = piVar7[1];
  iVar6 = *piVar7;
  if (iVar6 != param_3) {
    param_2 = &DAT_0211a3d8;
    piVar7 = (int *)(iVar6 + 0xc);
    do {
      uVar1 = *(undefined2 *)(puStack_14 + 0x7c);
      if ((uint)((piVar7[1] - *piVar7 >> 3) * 3) >> 2 <= (uint)piVar7[3]) {
        FUN_006b7040();
      }
      iVar10 = FUN_00620bc0(&param_2);
      iVar6 = iVar6 + 0x3c;
      piVar7 = piVar7 + 0xf;
      *(undefined2 *)(iVar10 + 4) = uVar1;
    } while (iVar6 != param_3);
  }
  if (iStack_88 != iStack_80) {
    param_2 = (undefined4 *)0x0;
    FUN_006abc60(&param_2,auStack_a0);
    piVar7 = (int *)(puStack_14 + 0x80);
    FUN_006b24c0((int)param_2 + 1,piVar7);
    FUN_005542c0(&DAT_018bc9b8,0);
    puVar9 = (undefined4 *)0x0;
    if (param_2 != (undefined4 *)0x0) {
      iVar6 = 0;
      do {
        FUN_006ab8e0(*piVar7 + 0x18 + iVar6,auStack_a0);
        puVar9 = (undefined4 *)((int)puVar9 + 1);
        iVar6 = iVar6 + 0x18;
      } while (puVar9 < param_2);
    }
  }
  puVar14 = puStack_14;
  if (iStack_88 != iStack_80) {
    param_2 = (undefined4 *)0x0;
    FUN_006abc60(&param_2,auStack_a0);
    puVar3 = puStack_14;
    FUN_006b24c0(param_2,puStack_14 + 0xb8);
    puVar9 = (undefined4 *)0x0;
    puVar14 = puVar3;
    if (param_2 != (undefined4 *)0x0) {
      iVar6 = 0;
      do {
        FUN_006ab8e0(*(int *)(puVar14 + 0xb8) + iVar6,auStack_a0);
        param_3 = *(int *)(puStack_14 + 0xb8) + iVar6;
        if ((uint)(((*(int *)(puVar3 + 0x90) - *(int *)(puVar3 + 0x8c)) / 0x1c) * 3) >> 2 <=
            *(uint *)(puVar3 + 0x98)) {
          FUN_006b72d0();
        }
        iVar10 = FUN_006b6b90(param_3);
        iVar6 = iVar6 + 0x18;
        *(short *)(iVar10 + 0x18) = (short)puVar9;
        puVar9 = (undefined4 *)((int)puVar9 + 1);
        puVar14 = puStack_14;
      } while (puVar9 < param_2);
    }
  }
  if (DAT_01ee420a != '\0') {
    pdVar15 = (double *)FUN_016827e0(auStack_cc);
    FUN_016774d0(DAT_01ee420a,"Time taken to initialize schema = %f ms",
                 (float)((*pdVar15 - dStack_110) * DAT_018c0d70),0,0,0);
  }
  *puVar14 = 1;
  if (0xf < uStack_64) {
    uVar8 = uStack_64 + 1;
    pppppppuVar13 = apppppppuStack_78[0];
    if (0xfff < uVar8) {
      pppppppuVar13 = (undefined4 *******)apppppppuStack_78[0][-1];
      uVar8 = uStack_64 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_78[0] + (-4 - (int)pppppppuVar13))) {
LAB_006b6b0e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar13,uVar8);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  apppppppuStack_78[0] = (undefined4 *******)((uint)apppppppuStack_78[0] & 0xffffff00);
  if (iStack_94 != 0) {
    uVar8 = iStack_8c - iStack_94;
    iVar6 = iStack_94;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iStack_94 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iStack_94 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8841 ; VA 0x006b6b20 ; FUN_006b6b20 */

uint * __thiscall FUN_006b6b20(int *param_1,uint *param_2)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = (param_1[1] - *param_1 >> 4) - 1;
  uVar1 = *param_2;
  uVar3 = (uVar1 >> 3) + uVar1;
  uVar4 = 0;
  while( true ) {
    uVar3 = uVar3 & uVar5;
    puVar2 = (uint *)(uVar3 * 0x10 + *param_1);
    if (*puVar2 == param_1[4]) {
      *puVar2 = uVar1;
      param_1[3] = param_1[3] + 1;
      return puVar2;
    }
    if (*puVar2 == uVar1) break;
    uVar3 = uVar3 + 1 + uVar4;
    uVar4 = uVar4 + 1;
    if (uVar5 < uVar4) {
      return (uint *)0x0;
    }
  }
  return puVar2;
}



/* FUNCTION 8842 ; VA 0x006b6b90 ; FUN_006b6b90 */

byte * __thiscall FUN_006b6b90(int *param_1,byte *param_2)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  uint uVar8;
  byte *pbVar9;
  bool bVar10;
  uint uStack_c;
  
  iVar2 = *param_1;
  uVar8 = (param_1[1] - iVar2) / 0x1c - 1;
  uVar4 = FUN_005702d0(param_2);
  uStack_c = 0;
  do {
    uVar4 = uVar4 & uVar8;
    pbVar1 = (byte *)(iVar2 + uVar4 * 0x1c);
    pbVar7 = (byte *)(param_1 + 4);
    if (0xf < (uint)param_1[9]) {
      pbVar7 = (byte *)param_1[4];
    }
    uVar6 = *(uint *)(pbVar1 + 0x10);
    pbVar9 = pbVar1;
    if (0xf < *(uint *)(pbVar1 + 0x14)) {
      pbVar9 = *(byte **)pbVar1;
    }
    uVar5 = uVar6;
    if (uVar6 == param_1[8]) {
      while (uVar3 = uVar5 - 4, 3 < uVar5) {
        if (*(int *)pbVar9 != *(int *)pbVar7) goto LAB_006b6c36;
        pbVar9 = pbVar9 + 4;
        pbVar7 = pbVar7 + 4;
        uVar5 = uVar3;
      }
      if (uVar3 == 0xfffffffc) {
LAB_006b6c6a:
        uVar5 = 0;
      }
      else {
LAB_006b6c36:
        bVar10 = *pbVar9 < *pbVar7;
        if ((*pbVar9 == *pbVar7) &&
           ((uVar3 == 0xfffffffd ||
            ((bVar10 = pbVar9[1] < pbVar7[1], pbVar9[1] == pbVar7[1] &&
             ((uVar3 == 0xfffffffe ||
              ((bVar10 = pbVar9[2] < pbVar7[2], pbVar9[2] == pbVar7[2] &&
               ((uVar3 == 0xffffffff || (bVar10 = pbVar9[3] < pbVar7[3], pbVar9[3] == pbVar7[3])))))
              ))))))) goto LAB_006b6c6a;
        uVar5 = -(uint)bVar10 | 1;
      }
      if (uVar5 == 0) {
        if (pbVar1 != param_2) {
          pbVar7 = param_2 + 0x10;
          if (0xf < *(uint *)(param_2 + 0x14)) {
            param_2 = *(byte **)param_2;
          }
          FUN_005542c0(param_2,*(int *)pbVar7);
        }
        param_1[3] = param_1[3] + 1;
        return pbVar1;
      }
    }
    pbVar7 = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pbVar7 = *(byte **)param_2;
    }
    pbVar9 = pbVar1;
    if (0xf < *(uint *)(pbVar1 + 0x14)) {
      pbVar9 = *(byte **)pbVar1;
    }
    if (uVar6 == *(uint *)(param_2 + 0x10)) {
      while (uVar5 = uVar6 - 4, 3 < uVar6) {
        if (*(int *)pbVar9 != *(int *)pbVar7) goto LAB_006b6cae;
        pbVar9 = pbVar9 + 4;
        pbVar7 = pbVar7 + 4;
        uVar6 = uVar5;
      }
      if (uVar5 == 0xfffffffc) {
LAB_006b6ce2:
        uVar6 = 0;
      }
      else {
LAB_006b6cae:
        bVar10 = *pbVar9 < *pbVar7;
        if ((*pbVar9 == *pbVar7) &&
           ((uVar5 == 0xfffffffd ||
            ((bVar10 = pbVar9[1] < pbVar7[1], pbVar9[1] == pbVar7[1] &&
             ((uVar5 == 0xfffffffe ||
              ((bVar10 = pbVar9[2] < pbVar7[2], pbVar9[2] == pbVar7[2] &&
               ((uVar5 == 0xffffffff || (bVar10 = pbVar9[3] < pbVar7[3], pbVar9[3] == pbVar7[3])))))
              ))))))) goto LAB_006b6ce2;
        uVar6 = -(uint)bVar10 | 1;
      }
      if (uVar6 == 0) {
        return pbVar1;
      }
    }
    uVar4 = uVar4 + 1 + uStack_c;
    uStack_c = uStack_c + 1;
    if (uVar8 < uStack_c) {
      return (byte *)0x0;
    }
  } while( true );
}



/* FUNCTION 8843 ; VA 0x006b6d40 ; FUN_006b6d40 */

uint FUN_006b6d40(int param_1,byte param_2,short param_3,undefined4 param_4,undefined4 *param_5)

{
  int iVar1;
  byte bVar2;
  uint uVar3;
  undefined3 uVar4;
  byte *pbVar5;
  bool bVar6;
  
  bVar2 = param_2;
  uVar3 = param_2 - 2;
  iVar1 = *(int *)(param_1 + 0x1c);
  *param_5 = 0;
  uVar4 = (undefined3)(uVar3 >> 8);
  switch(uVar3) {
  case 0:
  case 0x2f:
    return CONCAT31(uVar4,iVar1 == 6);
  case 1:
  case 4:
  case 0x2d:
    return CONCAT31(uVar4,iVar1 == 7);
  default:
    goto switchD_006b6d62_caseD_2;
  case 5:
    _param_2 = param_1;
    uVar3 = FUN_006b5480(&param_2);
    pbVar5 = (byte *)(-(uint)(uVar3 != 0) & uVar3 + 4);
    if (((pbVar5 == (byte *)0x0) || (bVar2 != *pbVar5)) ||
       (uVar3 = CONCAT22((short)(uVar3 >> 0x10),param_3), param_3 != *(short *)(pbVar5 + 2)))
    goto switchD_006b6d62_caseD_2;
    goto LAB_006b6da7;
  case 6:
    if (iVar1 == 0x3b) {
      *param_5 = 3;
      return CONCAT31(uVar4,1);
    }
    bVar6 = iVar1 == 0x1e;
    break;
  case 7:
    return CONCAT31(uVar4,iVar1 == 1);
  case 8:
    if (iVar1 == 3) {
      *param_5 = 1;
      return CONCAT31(uVar4,1);
    }
    bVar6 = iVar1 == 2;
    break;
  case 9:
    return CONCAT31(uVar4,iVar1 == 4);
  case 10:
    return CONCAT31(uVar4,iVar1 == 5);
  case 0xb:
    return CONCAT31(uVar4,iVar1 == 0x13);
  case 0xc:
    return CONCAT31(uVar4,iVar1 == 0x14);
  case 0xd:
    return CONCAT31(uVar4,iVar1 == 10);
  case 0xe:
    return CONCAT31(uVar4,iVar1 == 0x15);
  case 0xf:
    return CONCAT31(uVar4,iVar1 == 0x16);
  case 0x10:
    return CONCAT31(uVar4,iVar1 == 0x1c);
  case 0x11:
    return CONCAT31(uVar4,iVar1 == 0x11);
  case 0x12:
    return CONCAT31(uVar4,iVar1 == 0x12);
  case 0x13:
    return CONCAT31(uVar4,iVar1 == 0xb);
  case 0x14:
  case 0x15:
    return CONCAT31(uVar4,iVar1 == 0xc);
  case 0x16:
    return CONCAT31(uVar4,iVar1 == 0xd);
  case 0x17:
    return CONCAT31(uVar4,iVar1 == 0xe);
  case 0x18:
  case 0x19:
    return CONCAT31(uVar4,iVar1 == 0x10);
  case 0x1a:
    if ((iVar1 == 0x31) || (iVar1 == 8)) goto LAB_006b6da7;
    bVar6 = iVar1 == 0x32;
    break;
  case 0x1b:
    return CONCAT31(uVar4,iVar1 == 0x22);
  case 0x1c:
    return CONCAT31(uVar4,iVar1 == 0x23);
  case 0x1d:
    return CONCAT31(uVar4,iVar1 == 0x24);
  case 0x1e:
    return CONCAT31(uVar4,iVar1 == 0x25);
  case 0x1f:
    return CONCAT31(uVar4,iVar1 == 0x30);
  case 0x20:
    return CONCAT31(uVar4,iVar1 == 0x1d);
  case 0x21:
    return CONCAT31(uVar4,iVar1 == 0x2c);
  case 0x22:
    return CONCAT31(uVar4,iVar1 == 0x2d);
  case 0x23:
    return CONCAT31(uVar4,iVar1 == 0x2b);
  case 0x24:
    return CONCAT31(uVar4,iVar1 == 0x29);
  case 0x25:
    return CONCAT31(uVar4,iVar1 == 0x2a);
  case 0x26:
    return CONCAT31(uVar4,iVar1 == 0xf);
  case 0x27:
    return CONCAT31(uVar4,iVar1 == 0x1b);
  case 0x28:
    return CONCAT31(uVar4,iVar1 == 0x17);
  case 0x29:
    return CONCAT31(uVar4,iVar1 == 0x18);
  case 0x2a:
    if (iVar1 == 2) {
      *param_5 = 2;
      return CONCAT31(uVar4,1);
    }
    bVar6 = iVar1 == 3;
    break;
  case 0x2b:
    return CONCAT31(uVar4,iVar1 == 0x3a);
  case 0x2c:
    if (iVar1 == 0x1e) {
      *param_5 = 4;
      return CONCAT31(uVar4,1);
    }
    bVar6 = iVar1 == 0x3b;
    break;
  case 0x2e:
    return CONCAT31(uVar4,iVar1 == 0x3c);
  }
  if (bVar6) {
LAB_006b6da7:
    return CONCAT31((int3)(uVar3 >> 8),1);
  }
switchD_006b6d62_caseD_2:
  return uVar3 & 0xffffff00;
}



/* FUNCTION 8844 ; VA 0x006b7040 ; FUN_006b7040 */

void __fastcall FUN_006b7040(int *param_1)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar5 = 0x10;
  }
  else {
    iVar5 = (param_1[1] - *param_1 >> 3) * 2;
  }
  iStack_18 = param_1[4];
  uStack_14 = uStack_14 & 0xffff0000;
  piStack_1c = param_1;
  FUN_0060e8c0(iVar5,&iStack_18,&uStack_5);
  uStack_14 = param_1[4];
  iVar5 = *param_1;
  uStack_10 = 0;
  if (param_1[1] - iVar5 >> 3 != 0) {
    do {
      uVar4 = *(uint *)(iVar5 + uStack_10 * 8);
      puStack_c = (uint *)(iVar5 + uStack_10 * 8);
      if (uVar4 != param_1[4]) {
        uVar2 = (uVar4 >> 3) + uVar4;
        uVar7 = (iStack_30 - iStack_34 >> 3) - 1;
        uVar6 = 0;
        do {
          uVar2 = uVar2 & uVar7;
          puVar3 = (uint *)(iStack_34 + uVar2 * 8);
          if (*puVar3 == uStack_14) {
            *puVar3 = uVar4;
            uVar4 = *puStack_c;
            goto LAB_006b70eb;
          }
          if (*puVar3 == uVar4) goto LAB_006b70eb;
          uVar2 = uVar2 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
        puVar3 = (uint *)0x0;
LAB_006b70eb:
        *puVar3 = uVar4;
        *(undefined2 *)(puVar3 + 1) = *(undefined2 *)(puStack_c + 1);
        iVar5 = *piStack_1c;
        param_1 = piStack_1c;
      }
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < (uint)(param_1[1] - iVar5 >> 3));
  }
  if (param_1 != &iStack_34) {
    *param_1 = iStack_34;
    param_1[1] = iStack_30;
    iVar1 = param_1[2];
    param_1[2] = iStack_2c;
    iStack_2c = iVar1;
    iStack_34 = iVar5;
  }
  if (iStack_34 != 0) {
    uVar4 = iStack_2c - iStack_34 & 0xfffffff8;
    iVar5 = iStack_34;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_34 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_34 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  return;
}



/* FUNCTION 8845 ; VA 0x006b7170 ; FUN_006b7170 */

void __fastcall FUN_006b7170(int *param_1)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int aiStack_2c [4];
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar5 = 0x10;
  }
  else {
    iVar5 = (param_1[1] - *param_1 >> 4) * 2;
  }
  aiStack_2c[0] = param_1[4];
  aiStack_2c[1] = 0;
  aiStack_2c[2] = 0;
  aiStack_2c[3] = 0;
  piStack_1c = param_1;
  FUN_006b3040(iVar5,aiStack_2c,&uStack_5);
  uStack_18 = param_1[4];
  iVar5 = *param_1;
  uStack_10 = 0;
  if (param_1[1] - iVar5 >> 4 != 0) {
    iStack_14 = 0;
    do {
      uVar4 = *(uint *)(iVar5 + iStack_14);
      puStack_c = (uint *)(iVar5 + iStack_14);
      if (uVar4 != param_1[4]) {
        uVar3 = (uVar4 >> 3) + uVar4;
        uVar7 = (iStack_40 - iStack_44 >> 4) - 1;
        uVar6 = 0;
        do {
          uVar3 = uVar3 & uVar7;
          puVar2 = (uint *)(uVar3 * 0x10 + iStack_44);
          if (*puVar2 == uStack_18) {
            *puVar2 = uVar4;
            uVar4 = *puStack_c;
            goto LAB_006b7231;
          }
          if (*puVar2 == uVar4) goto LAB_006b7231;
          uVar3 = uVar3 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
        puVar2 = (uint *)0x0;
LAB_006b7231:
        *puVar2 = uVar4;
        *(undefined8 *)(puVar2 + 1) = *(undefined8 *)(puStack_c + 1);
        puVar2[3] = puStack_c[3];
        iVar5 = *piStack_1c;
        param_1 = piStack_1c;
      }
      iStack_14 = iStack_14 + 0x10;
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < (uint)(param_1[1] - iVar5 >> 4));
  }
  if (param_1 != &iStack_44) {
    *param_1 = iStack_44;
    param_1[1] = iStack_40;
    iVar1 = param_1[2];
    param_1[2] = iStack_3c;
    iStack_3c = iVar1;
    iStack_44 = iVar5;
  }
  if (iStack_44 != 0) {
    uVar4 = iStack_3c - iStack_44 & 0xfffffff0;
    iVar5 = iStack_44;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_44 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_44 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  return;
}



/* FUNCTION 8846 ; VA 0x006b72d0 ; FUN_006b72d0 */

void __fastcall FUN_006b72d0(int *param_1)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  byte *pbVar8;
  byte *pbVar9;
  uint uVar10;
  undefined4 *puVar11;
  bool bVar12;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  uint uStack_38;
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7108;
  pvStack_10 = ExceptionList;
  if (*param_1 == param_1[1]) {
    iVar4 = 0x10;
  }
  else {
    iVar4 = ((param_1[1] - *param_1) / 0x1c) * 2;
  }
  ExceptionList = &pvStack_10;
  FUN_006b2f90(param_1 + 4,iVar4);
  iVar4 = *param_1;
  uStack_18 = 0;
  uStack_8 = 0;
  iVar2 = param_1[1] - iVar4 >> 0x1f;
  if ((param_1[1] - iVar4) / 0x1c + iVar2 != iVar2) {
    iStack_14 = 0;
    do {
      pbVar1 = (byte *)(iVar4 + iStack_14);
      pbVar9 = (byte *)(param_1 + 4);
      if (0xf < (uint)param_1[9]) {
        pbVar9 = (byte *)param_1[4];
      }
      uVar5 = *(uint *)(pbVar1 + 0x10);
      pbVar8 = pbVar1;
      if (0xf < *(uint *)(pbVar1 + 0x14)) {
        pbVar8 = *(byte **)pbVar1;
      }
      iStack_1c = iVar4;
      if (uVar5 == param_1[8]) {
        while (uVar10 = uVar5 - 4, 3 < uVar5) {
          if (*(int *)pbVar8 != *(int *)pbVar9) goto LAB_006b7398;
          pbVar8 = pbVar8 + 4;
          pbVar9 = pbVar9 + 4;
          uVar5 = uVar10;
        }
        if (uVar10 == 0xfffffffc) {
LAB_006b73cc:
          uVar5 = 0;
        }
        else {
LAB_006b7398:
          bVar12 = *pbVar8 < *pbVar9;
          if ((*pbVar8 == *pbVar9) &&
             ((uVar10 == 0xfffffffd ||
              ((bVar12 = pbVar8[1] < pbVar9[1], pbVar8[1] == pbVar9[1] &&
               ((uVar10 == 0xfffffffe ||
                ((bVar12 = pbVar8[2] < pbVar9[2], pbVar8[2] == pbVar9[2] &&
                 ((uVar10 == 0xffffffff || (bVar12 = pbVar8[3] < pbVar9[3], pbVar8[3] == pbVar9[3]))
                 )))))))))) goto LAB_006b73cc;
          uVar5 = -(uint)bVar12 | 1;
        }
        if (uVar5 != 0) goto LAB_006b73da;
      }
      else {
LAB_006b73da:
        puVar11 = (undefined4 *)(iStack_14 + iVar4);
        puVar6 = (undefined4 *)FUN_006b6b90(pbVar1);
        if (puVar6 != puVar11) {
          puVar7 = puVar11;
          if (0xf < (uint)puVar11[5]) {
            puVar7 = (undefined4 *)*puVar11;
          }
          FUN_005542c0(puVar7,puVar11[4]);
        }
        *(undefined2 *)(puVar6 + 6) = *(undefined2 *)(puVar11 + 6);
        iVar4 = *param_1;
      }
      uStack_18 = uStack_18 + 1;
      iStack_14 = iStack_14 + 0x1c;
    } while (uStack_18 < (uint)((param_1[1] - iVar4) / 0x1c));
  }
  if (param_1 != &iStack_48) {
    *param_1 = iStack_48;
    iVar2 = param_1[1];
    param_1[1] = iStack_44;
    iVar3 = param_1[2];
    param_1[2] = iStack_40;
    iStack_48 = iVar4;
    iStack_44 = iVar2;
    iStack_40 = iVar3;
  }
  if (0xf < uStack_24) {
    uVar10 = uStack_24 + 1;
    uVar5 = uStack_38;
    if (0xfff < uVar10) {
      uVar5 = *(uint *)(uStack_38 - 4);
      uVar10 = uStack_24 + 0x24;
      if (0x1f < (uStack_38 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar10);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  FUN_006b35b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8847 ; VA 0x006b74d0 ; FUN_006b74d0 */

void __thiscall FUN_006b74d0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7150;
  pvStack_10 = ExceptionList;
  iVar2 = param_1[3];
  if (iVar2 == 0) {
    puVar3 = (undefined4 *)*param_1;
    if (puVar3 == (undefined4 *)0x0) {
      if (param_1[1] == 0) {
        return;
      }
      ExceptionList = &pvStack_10;
      (**(code **)(**(int **)(param_1[1] + 0x34) + 0x10))(param_1[2],param_2);
      ExceptionList = pvStack_10;
      return;
    }
    ExceptionList = &pvStack_10;
    uVar4 = FUN_0088d4b0();
    *puVar3 = uVar4;
    iVar5 = FUN_00631310();
    iVar2 = puVar3[1];
    if (iVar2 != iVar5) {
      if (iVar2 != 0) {
        (**(code **)(iVar2 + 8))(puVar3 + 2);
        puVar3[1] = 0;
      }
      iVar2 = *param_2;
      puVar3[2] = iVar2;
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      puVar3[1] = iVar5;
      ExceptionList = pvStack_10;
      return;
    }
    iVar2 = *param_2;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    puVar3[2] = iVar2;
  }
  else {
    if (iVar2 == 4) {
      if (*param_1 != 0) {
        ExceptionList = &pvStack_10;
        uVar4 = FUN_00a33fa0();
        FUN_0054ef60(uVar4);
        uStack_50 = uStack_38;
        uStack_38 = uStack_38 & 0xffffff00;
        uStack_4c = uStack_34;
        uStack_48 = uStack_30;
        uStack_44 = uStack_2c;
        uStack_28 = 0;
        uStack_24 = 0xf;
        uStack_8 = 0;
        FUN_00632d90(&uStack_50);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      iVar2 = param_1[1];
      if (iVar2 == 0) {
        return;
      }
      ExceptionList = &pvStack_10;
      uVar4 = FUN_00a33fa0();
      FUN_0054ef60(uVar4);
      uStack_50 = uStack_38;
      uStack_38 = uStack_38 & 0xffffff00;
      uStack_4c = uStack_34;
      uStack_48 = uStack_30;
      uStack_44 = uStack_2c;
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_8 = 1;
      (**(code **)(**(int **)(iVar2 + 0x34) + 0x10))(param_1[2],&uStack_50);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    if (iVar2 == 5) {
      if (*param_1 == 0) {
        iVar2 = param_1[1];
        if (iVar2 == 0) {
          return;
        }
        ExceptionList = &pvStack_10;
        uVar4 = FUN_00886a70(auStack_18,param_2);
        uStack_8 = 3;
        (**(code **)(**(int **)(iVar2 + 0x34) + 0x10))(param_1[2],uVar4);
        FUN_0056cd30();
        goto LAB_006b773f;
      }
      ExceptionList = &pvStack_10;
      uVar4 = FUN_00886a70(auStack_18,param_2);
      uStack_8 = 2;
    }
    else {
      if (iVar2 != 6) {
        return;
      }
      if (*param_1 == 0) {
        iVar2 = param_1[1];
        if (iVar2 == 0) {
          return;
        }
        ExceptionList = &pvStack_10;
        uVar4 = FUN_00886b30(auStack_20,param_2);
        uStack_8 = 5;
        (**(code **)(**(int **)(iVar2 + 0x34) + 0x10))(param_1[2],uVar4);
        FUN_0056cd30();
        goto LAB_006b773f;
      }
      ExceptionList = &pvStack_10;
      uVar4 = FUN_00886b30(auStack_18,param_2);
      uStack_8 = 4;
    }
    FUN_006b20d0(uVar4);
    FUN_0056cd30();
  }
LAB_006b773f:
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8848 ; VA 0x006b7760 ; FUN_006b7760 */

int * __thiscall FUN_006b7760(int *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar2 = FUN_01683580(&param_3,1,0);
  if (uVar2 == 0xffffffff) {
    *param_2 = *param_1;
    param_2[1] = param_1[1];
    param_2[2] = 0;
    param_2[3] = 0;
    return param_2;
  }
  uVar6 = param_1[1];
  uVar4 = uVar6;
  if (uVar2 + 1 <= uVar6) {
    uVar4 = uVar2 + 1;
  }
  uVar3 = uVar4;
  if (uVar4 != 0xffffffff) {
    uVar3 = 0xffffffff;
  }
  iVar1 = *param_1;
  uVar5 = uVar6;
  if (uVar3 <= uVar6) {
    uVar5 = uVar3;
  }
  uVar2 = -(uint)(uVar2 != 0) & uVar2;
  *param_2 = iVar1;
  if (uVar2 <= uVar6) {
    uVar6 = uVar2;
  }
  param_2[1] = uVar6;
  param_2[2] = iVar1 + uVar4;
  param_2[3] = uVar5 - uVar4;
  return param_2;
}



/* FUNCTION 8849 ; VA 0x006b77f0 ; FUN_006b77f0 */

undefined8 * __thiscall FUN_006b77f0(int param_1,undefined8 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)FUN_006b4f70(auStack_10,*param_3,param_1 + 4);
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 8850 ; VA 0x006b7830 ; FUN_006b7830 */

int __fastcall FUN_006b7830(int param_1)

{
  undefined8 uVar1;
  
  FUN_016827a0(param_1);
  *(undefined8 *)(param_1 + 8) = DAT_018c0d60;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined8 *)(param_1 + 0x18) = uVar1;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined *)(param_1 + 0x38) = 1;
  FUN_016827a0(param_1 + 0x40);
  *(undefined8 *)(param_1 + 0x48) = DAT_018c0d60;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined8 *)(param_1 + 0x58) = uVar1;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined *)(param_1 + 0x78) = 1;
  FUN_016827a0(param_1 + 0x80);
  *(undefined8 *)(param_1 + 0x88) = DAT_018c0d60;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined8 *)(param_1 + 0x98) = uVar1;
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  *(undefined *)(param_1 + 0xb8) = 1;
  FUN_016827a0(param_1 + 0xc0);
  *(undefined8 *)(param_1 + 200) = DAT_018c0d60;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0xd0) = 0;
  *(undefined4 *)(param_1 + 0xd4) = 0;
  *(undefined8 *)(param_1 + 0xd8) = uVar1;
  *(undefined4 *)(param_1 + 0xe0) = 0;
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined *)(param_1 + 0xf8) = 1;
  FUN_016827a0(param_1 + 0x100);
  *(undefined8 *)(param_1 + 0x108) = DAT_018c0d60;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x110) = 0;
  *(undefined4 *)(param_1 + 0x114) = 0;
  *(undefined8 *)(param_1 + 0x118) = uVar1;
  *(undefined4 *)(param_1 + 0x120) = 0;
  *(undefined4 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 300) = 0;
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x134) = 0;
  *(undefined *)(param_1 + 0x138) = 1;
  return param_1;
}



/* FUNCTION 8851 ; VA 0x006b79c0 ; FUN_006b79c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall FUN_006b79c0(int param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  iVar6 = 0xb;
  do {
    FUN_006b8290();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  iVar6 = 0xb;
  do {
    FUN_006b8290();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  iVar6 = 0xb;
  do {
    FUN_006b8270();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  iVar6 = 0xb;
  do {
    FUN_006b8270();
    uVar1 = DAT_01d5b498;
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  *(undefined8 *)(param_1 + 0x580) = DAT_01d5b498;
  FUN_016827a0(param_1 + 0x588);
  *(undefined *)(param_1 + 0x590) = 1;
  *(undefined8 *)(param_1 + 0x598) = uVar1;
  *(undefined4 *)(param_1 + 0x5a0) = 0;
  *(undefined4 *)(param_1 + 0x5a4) = 0;
  *(undefined4 *)(param_1 + 0x5a8) = 0;
  *(undefined4 *)(param_1 + 0x5ac) = 0;
  *(undefined *)(param_1 + 0x5b8) = 1;
  *(undefined8 *)(param_1 + 0x5b0) = 0;
  uVar1 = DAT_01d5b498;
  *(undefined **)(param_1 + 0x5c0) = &DAT_01d5b46c;
  FUN_016827a0(param_1 + 0x5c8);
  *(undefined *)(param_1 + 0x5d0) = 1;
  *(undefined8 *)(param_1 + 0x5d8) = uVar1;
  uVar1 = DAT_018ce300;
  *(undefined4 *)(param_1 + 0x5e0) = 0;
  *(undefined4 *)(param_1 + 0x5e4) = 0;
  *(undefined4 *)(param_1 + 0x5e8) = 0;
  *(undefined4 *)(param_1 + 0x5ec) = 0;
  *(undefined *)(param_1 + 0x5f8) = 1;
  *(undefined8 *)(param_1 + 0x5f0) = 0;
  *(undefined **)(param_1 + 0x600) = &DAT_01d5b46c;
  *(undefined8 *)(param_1 + 0x608) = uVar1;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x610) = 0;
  *(undefined4 *)(param_1 + 0x614) = 0;
  *(undefined4 *)(param_1 + 0x618) = 0;
  *(undefined4 *)(param_1 + 0x61c) = 0;
  *(undefined *)(param_1 + 0x628) = 1;
  *(undefined8 *)(param_1 + 0x620) = 0;
  FUN_016827a0(param_1 + 0x630);
  *(undefined *)(param_1 + 0x638) = 1;
  *(undefined8 *)(param_1 + 0x640) = uVar1;
  uVar1 = DAT_018ce300;
  *(undefined4 *)(param_1 + 0x648) = 0;
  *(undefined4 *)(param_1 + 0x64c) = 0;
  *(undefined4 *)(param_1 + 0x650) = 0;
  *(undefined4 *)(param_1 + 0x654) = 0;
  *(undefined *)(param_1 + 0x660) = 1;
  *(undefined8 *)(param_1 + 0x658) = 0;
  *(undefined **)(param_1 + 0x668) = &DAT_01d5b46c;
  *(undefined8 *)(param_1 + 0x670) = uVar1;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x678) = 0;
  *(undefined4 *)(param_1 + 0x67c) = 0;
  *(undefined4 *)(param_1 + 0x680) = 0;
  *(undefined4 *)(param_1 + 0x684) = 0;
  *(undefined *)(param_1 + 0x690) = 1;
  *(undefined8 *)(param_1 + 0x688) = 0;
  FUN_016827a0(param_1 + 0x698);
  *(undefined *)(param_1 + 0x6a0) = 1;
  *(undefined8 *)(param_1 + 0x6a8) = uVar1;
  uVar1 = DAT_018ce300;
  *(undefined4 *)(param_1 + 0x6b0) = 0;
  *(undefined4 *)(param_1 + 0x6b4) = 0;
  *(undefined4 *)(param_1 + 0x6b8) = 0;
  *(undefined4 *)(param_1 + 0x6bc) = 0;
  *(undefined *)(param_1 + 0x6c8) = 1;
  *(undefined8 *)(param_1 + 0x6c0) = 0;
  *(undefined **)(param_1 + 0x6d0) = &DAT_01d5b46c;
  *(undefined8 *)(param_1 + 0x6d8) = uVar1;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x6e0) = 0;
  *(undefined4 *)(param_1 + 0x6e4) = 0;
  *(undefined4 *)(param_1 + 0x6e8) = 0;
  *(undefined4 *)(param_1 + 0x6ec) = 0;
  *(undefined *)(param_1 + 0x6f8) = 1;
  *(undefined8 *)(param_1 + 0x6f0) = 0;
  FUN_016827a0(param_1 + 0x700);
  *(undefined *)(param_1 + 0x708) = 1;
  *(undefined8 *)(param_1 + 0x710) = uVar1;
  *(undefined4 *)(param_1 + 0x718) = 0;
  *(undefined4 *)(param_1 + 0x71c) = 0;
  *(undefined4 *)(param_1 + 0x720) = 0;
  *(undefined4 *)(param_1 + 0x724) = 0;
  *(undefined *)(param_1 + 0x730) = 1;
  *(undefined8 *)(param_1 + 0x728) = 0;
  *(undefined4 *)(param_1 + 0x738) = 0;
  uVar4 = DAT_01d5b498;
  *(undefined8 *)(param_1 + 0x740) = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x748) = 0;
  *(undefined4 *)(param_1 + 0x74c) = 0;
  *(undefined4 *)(param_1 + 0x750) = 0;
  *(undefined4 *)(param_1 + 0x754) = 0;
  *(undefined *)(param_1 + 0x760) = 1;
  *(undefined8 *)(param_1 + 0x758) = 0;
  *(undefined8 *)(param_1 + 0x768) = uVar4;
  *(undefined8 *)(param_1 + 0x770) = DAT_018c0d60;
  FUN_016827a0(param_1 + 0x778);
  uVar1 = DAT_018ce300;
  *(undefined *)(param_1 + 0x780) = 1;
  *(undefined8 *)(param_1 + 0x788) = uVar4;
  uVar4 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x790) = 0;
  *(undefined4 *)(param_1 + 0x794) = 0;
  *(undefined4 *)(param_1 + 0x798) = 0;
  *(undefined4 *)(param_1 + 0x79c) = 0;
  *(undefined *)(param_1 + 0x7a8) = 1;
  *(undefined8 *)(param_1 + 0x7a0) = 0;
  *(undefined **)(param_1 + 0x7b0) = &DAT_01d5b46c;
  *(undefined8 *)(param_1 + 0x7b8) = uVar1;
  *(undefined4 *)(param_1 + 0x7c0) = 0;
  *(undefined4 *)(param_1 + 0x7c4) = 0;
  *(undefined4 *)(param_1 + 0x7c8) = 0;
  *(undefined4 *)(param_1 + 0x7cc) = 0;
  *(undefined *)(param_1 + 0x7d8) = 1;
  *(undefined8 *)(param_1 + 2000) = 0;
  *(undefined8 *)(param_1 + 0x7e0) = uVar4;
  *(undefined4 *)(param_1 + 0x7e8) = 0;
  *(undefined4 *)(param_1 + 0x7f0) = 0;
  *(undefined4 *)(param_1 + 0x7f4) = 0;
  *(undefined4 *)(param_1 + 0x7f8) = 0;
  *(undefined4 *)(param_1 + 0x7fc) = 0;
  *(undefined *)(param_1 + 0x800) = 1;
  *(undefined8 *)(param_1 + 0x808) = uVar1;
  *(undefined4 *)(param_1 + 0x810) = 0;
  *(undefined4 *)(param_1 + 0x814) = 0;
  *(undefined4 *)(param_1 + 0x818) = 0;
  *(undefined4 *)(param_1 + 0x81c) = 0;
  *(undefined *)(param_1 + 0x828) = 1;
  *(undefined8 *)(param_1 + 0x820) = 0;
  FUN_016827a0(param_1 + 0x830);
  *(undefined8 *)(param_1 + 0x838) = DAT_018c0d60;
  *(undefined4 *)(param_1 + 0x840) = 0;
  *(undefined4 *)(param_1 + 0x844) = 0;
  FUN_016827a0(param_1 + 0x848);
  *(undefined8 *)(param_1 + 0x850) = DAT_018c0d60;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x858) = 0;
  *(undefined4 *)(param_1 + 0x85c) = 0;
  FUN_016827a0(param_1 + 0x860);
  *(undefined *)(param_1 + 0x868) = 1;
  *(undefined8 *)(param_1 + 0x870) = uVar1;
  uVar4 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x878) = 0;
  *(undefined4 *)(param_1 + 0x87c) = 0;
  *(undefined4 *)(param_1 + 0x880) = 0;
  *(undefined4 *)(param_1 + 0x884) = 0;
  *(undefined *)(param_1 + 0x890) = 1;
  *(undefined8 *)(param_1 + 0x888) = 0;
  *(undefined **)(param_1 + 0x898) = &DAT_01d5b46c;
  *(undefined8 *)(param_1 + 0x8a0) = uVar4;
  *(undefined4 *)(param_1 + 0x8a8) = 0;
  *(undefined4 *)(param_1 + 0x8b0) = 0;
  *(undefined4 *)(param_1 + 0x8b4) = 0;
  *(undefined4 *)(param_1 + 0x8b8) = 0;
  *(undefined4 *)(param_1 + 0x8bc) = 0;
  *(undefined *)(param_1 + 0x8c0) = 1;
  *(undefined4 *)(param_1 + 0x8c8) = 0;
  *(undefined4 *)(param_1 + 0x8cc) = 0;
  *(undefined4 *)(param_1 + 0x8d8) = 0;
  *(undefined4 *)(param_1 + 0x8e0) = 0;
  *(undefined4 *)(param_1 + 0x8e4) = 0;
  *(undefined4 *)(param_1 + 0x8e8) = 0;
  *(undefined4 *)(param_1 + 0x8ec) = 0;
  *(undefined *)(param_1 + 0x8f0) = 1;
  uVar1 = DAT_018dbcc8;
  *(undefined8 *)(param_1 + 0x8d0) = DAT_018dbcc8;
  *(undefined4 *)(param_1 + 0x8f8) = 0;
  *(undefined4 *)(param_1 + 0x8fc) = 1000000;
  *(undefined8 *)(param_1 + 0x900) = uVar1;
  *(undefined4 *)(param_1 + 0x908) = 0;
  *(undefined4 *)(param_1 + 0x910) = 0;
  *(undefined4 *)(param_1 + 0x914) = 0;
  *(undefined4 *)(param_1 + 0x918) = 0;
  *(undefined4 *)(param_1 + 0x91c) = 0;
  *(undefined *)(param_1 + 0x920) = 1;
  *(undefined4 *)(param_1 + 0x928) = 0;
  *(undefined4 *)(param_1 + 0x92c) = 1000000;
  FUN_016827a0(param_1 + 0x930);
  *(undefined *)(param_1 + 0x938) = 1;
  *(undefined8 *)(param_1 + 0x940) = uVar4;
  *(undefined4 *)(param_1 + 0x948) = 0;
  *(undefined4 *)(param_1 + 0x94c) = 0;
  *(undefined4 *)(param_1 + 0x950) = 0;
  *(undefined4 *)(param_1 + 0x954) = 0;
  *(undefined *)(param_1 + 0x960) = 1;
  *(undefined8 *)(param_1 + 0x958) = 0;
  uVar4 = DAT_01d5b4a0;
  *(undefined4 *)(param_1 + 0x968) = 0;
  FUN_016827a0(param_1 + 0x970);
  uVar1 = DAT_018ce300;
  *(undefined *)(param_1 + 0x978) = 1;
  *(undefined8 *)(param_1 + 0x980) = uVar4;
  uVar4 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0x988) = 0;
  *(undefined4 *)(param_1 + 0x98c) = 0;
  *(undefined4 *)(param_1 + 0x990) = 0;
  *(undefined4 *)(param_1 + 0x994) = 0;
  *(undefined *)(param_1 + 0x9a0) = 1;
  *(undefined8 *)(param_1 + 0x998) = 0;
  *(undefined4 *)(param_1 + 0x9a8) = 0;
  *(undefined8 *)(param_1 + 0x9b0) = uVar1;
  *(undefined4 *)(param_1 + 0x9b8) = 0;
  *(undefined4 *)(param_1 + 0x9bc) = 0;
  *(undefined4 *)(param_1 + 0x9c0) = 0;
  *(undefined4 *)(param_1 + 0x9c4) = 0;
  *(undefined *)(param_1 + 0x9d0) = 1;
  *(undefined8 *)(param_1 + 0x9c8) = 0;
  *(undefined8 *)(param_1 + 0x9d8) = uVar4;
  *(undefined4 *)(param_1 + 0x9e0) = 0;
  *(undefined4 *)(param_1 + 0x9e8) = 0;
  *(undefined4 *)(param_1 + 0x9ec) = 0;
  *(undefined4 *)(param_1 + 0x9f0) = 0;
  *(undefined4 *)(param_1 + 0x9f4) = 0;
  *(undefined *)(param_1 + 0x9f8) = 1;
  *(undefined8 *)(param_1 + 0xa00) = uVar1;
  *(undefined4 *)(param_1 + 0xa08) = 0;
  *(undefined4 *)(param_1 + 0xa10) = 0;
  *(undefined4 *)(param_1 + 0xa14) = 0;
  *(undefined4 *)(param_1 + 0xa18) = 0;
  *(undefined4 *)(param_1 + 0xa1c) = 0;
  *(undefined *)(param_1 + 0xa20) = 1;
  FUN_016827a0(param_1 + 0xa28);
  *(undefined *)(param_1 + 0xa30) = 1;
  *(undefined8 *)(param_1 + 0xa38) = uVar4;
  uVar1 = DAT_01d5b498;
  *(undefined4 *)(param_1 + 0xa40) = 0;
  *(undefined4 *)(param_1 + 0xa44) = 0;
  *(undefined4 *)(param_1 + 0xa48) = 0;
  *(undefined4 *)(param_1 + 0xa4c) = 0;
  *(undefined *)(param_1 + 0xa58) = 1;
  *(undefined8 *)(param_1 + 0xa50) = 0;
  *(undefined4 *)(param_1 + 0xa60) = 0;
  *(undefined8 *)(param_1 + 0xa68) = uVar1;
  *(undefined4 *)(param_1 + 0xa70) = 0;
  *(undefined4 *)(param_1 + 0xa78) = 0;
  *(undefined4 *)(param_1 + 0xa7c) = 0;
  *(undefined4 *)(param_1 + 0xa80) = 0;
  *(undefined4 *)(param_1 + 0xa84) = 0;
  *(undefined *)(param_1 + 0xa88) = 1;
  *(undefined8 *)(param_1 + 0xa90) = uVar1;
  *(undefined4 *)(param_1 + 0xa98) = 0;
  *(undefined4 *)(param_1 + 0xaa0) = 0;
  *(undefined4 *)(param_1 + 0xaa4) = 0;
  *(undefined4 *)(param_1 + 0xaa8) = 0;
  *(undefined4 *)(param_1 + 0xaac) = 0;
  *(undefined *)(param_1 + 0xab0) = 1;
  FUN_006b7830();
  uVar1 = DAT_018ce300;
  *(undefined8 *)(param_1 + 0xbf8) = DAT_018ce300;
  *(undefined4 *)(param_1 + 0xc00) = 0;
  *(undefined4 *)(param_1 + 0xc04) = 0;
  *(undefined4 *)(param_1 + 0xc08) = 0;
  *(undefined4 *)(param_1 + 0xc0c) = 0;
  *(undefined *)(param_1 + 0xc18) = 1;
  *(undefined8 *)(param_1 + 0xc10) = 0;
  *(undefined8 *)(param_1 + 0xc20) = uVar1;
  *(undefined4 *)(param_1 + 0xc28) = 0;
  *(undefined4 *)(param_1 + 0xc2c) = 0;
  *(undefined4 *)(param_1 + 0xc30) = 0;
  *(undefined4 *)(param_1 + 0xc34) = 0;
  *(undefined *)(param_1 + 0xc40) = 1;
  *(undefined8 *)(param_1 + 0xc38) = 0;
  FUN_006b7830();
  uVar1 = DAT_018db070;
  *(undefined4 *)(param_1 + 0xd88) = 0x5d4;
  *(undefined4 *)(param_1 + 0xd8c) = 0;
  *(undefined4 *)(param_1 + 0xd90) = 0;
  *(undefined4 *)(param_1 + 0xd94) = 0;
  *(undefined4 *)(param_1 + 0xd98) = 0;
  uVar3 = _UNK_018db08c;
  uVar2 = _UNK_018db088;
  uVar5 = _UNK_018db084;
  *(undefined4 *)(param_1 + 0xda8) = _DAT_018db080;
  *(undefined4 *)(param_1 + 0xdac) = uVar5;
  *(undefined4 *)(param_1 + 0xdb0) = uVar2;
  *(undefined4 *)(param_1 + 0xdb4) = uVar3;
  *(undefined *)(param_1 + 0xdc0) = 1;
  *(undefined8 *)(param_1 + 0xda0) = uVar1;
  *(undefined8 *)(param_1 + 0xdb8) = 0;
  *(undefined4 *)(param_1 + 0xdc8) = 0;
  *(undefined8 *)(param_1 + 0xdd0) = uVar1;
  *(undefined4 *)(param_1 + 0xdd8) = 0;
  *(undefined4 *)(param_1 + 0xddc) = 0;
  *(undefined4 *)(param_1 + 0xde0) = 0;
  *(undefined4 *)(param_1 + 0xde4) = 0;
  *(undefined *)(param_1 + 0xdf0) = 1;
  *(undefined8 *)(param_1 + 0xde8) = 0;
  *(undefined8 *)(param_1 + 0xdf8) = uVar1;
  uVar1 = DAT_018ce300;
  *(undefined4 *)(param_1 + 0xe00) = 0;
  *(undefined4 *)(param_1 + 0xe04) = 0;
  *(undefined4 *)(param_1 + 0xe08) = 0;
  *(undefined4 *)(param_1 + 0xe0c) = 0;
  *(undefined *)(param_1 + 0xe18) = 1;
  *(undefined8 *)(param_1 + 0xe10) = 0;
  *(undefined8 *)(param_1 + 0xe20) = uVar1;
  *(undefined4 *)(param_1 + 0xe28) = 0;
  *(undefined4 *)(param_1 + 0xe2c) = 0;
  *(undefined4 *)(param_1 + 0xe30) = 0;
  *(undefined4 *)(param_1 + 0xe34) = 0;
  *(undefined *)(param_1 + 0xe40) = 1;
  *(undefined8 *)(param_1 + 0xe38) = 0;
  *(undefined8 *)(param_1 + 0xe48) = uVar1;
  *(undefined4 *)(param_1 + 0xe50) = 0;
  *(undefined4 *)(param_1 + 0xe54) = 0;
  *(undefined4 *)(param_1 + 0xe58) = 0;
  *(undefined4 *)(param_1 + 0xe5c) = 0;
  *(undefined *)(param_1 + 0xe68) = 1;
  *(undefined8 *)(param_1 + 0xe60) = 0;
  *(undefined4 *)(param_1 + 0xfa8) = 0;
  *(undefined4 *)(param_1 + 0xfac) = 0;
  *(undefined4 *)(param_1 + 0xfb0) = 0;
  *(undefined4 *)(param_1 + 0xfb4) = 0;
  *(undefined4 *)(param_1 + 0xfb8) = 0;
  *(undefined4 *)(param_1 + 0xfbc) = 0;
  *(undefined4 *)(param_1 + 0xfc0) = 0;
  *(undefined4 *)(param_1 + 0xfc4) = 0;
  uVar5 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0xfd0) = uVar5;
  *(undefined4 *)(param_1 + 0xfd4) = 0;
  uVar5 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0xfd8) = uVar5;
  *(undefined4 *)(param_1 + 0xfdc) = 0;
  uVar5 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0xfe0) = uVar5;
  *(undefined4 *)(param_1 + 0xfe4) = 0;
  uVar5 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0xfe8) = uVar5;
  *(undefined4 *)(param_1 + 0xfec) = 0;
  *(undefined4 *)(param_1 + 0xff0) = 0;
  *(undefined4 *)(param_1 + 0xff4) = 0;
  *(undefined4 *)(param_1 + 0xff8) = 0;
  *(undefined4 *)(param_1 + 0xffc) = 0;
  *(undefined8 *)(param_1 + 0x1000) = 0;
  *(undefined4 *)(&DAT_00001008 + param_1) = 0;
  *(undefined4 *)(param_1 + 0x100c) = 0;
  *(undefined4 *)(param_1 + 0x1010) = 0;
  *(undefined4 *)(param_1 + 0x1014) = 0xffffffff;
  FUN_016830f0(param_1 + 0x1018);
  uVar1 = DAT_018dbcc8;
  *(undefined8 *)(param_1 + 0x1020) = DAT_018dbcc8;
  *(undefined4 *)(param_1 + 0x1028) = 0;
  *(undefined4 *)(param_1 + 0x1030) = 0;
  *(undefined4 *)(param_1 + 0x1034) = 0;
  *(undefined4 *)(param_1 + 0x1038) = 0;
  *(undefined4 *)(param_1 + 0x103c) = 0;
  *(undefined *)(param_1 + 0x1040) = 1;
  iVar6 = 0x32;
  *(undefined4 *)(param_1 + 0x1048) = 0;
  *(undefined4 *)(param_1 + 0x104c) = 1000000;
  *(undefined8 *)(param_1 + 0x1050) = uVar1;
  *(undefined4 *)(param_1 + 0x1058) = 0;
  *(undefined4 *)(param_1 + 0x1060) = 0;
  *(undefined4 *)(param_1 + 0x1064) = 0;
  *(undefined4 *)(param_1 + 0x1068) = 0;
  *(undefined4 *)(param_1 + 0x106c) = 0;
  *(undefined *)(param_1 + 0x1070) = 1;
  *(undefined4 *)(param_1 + 0x1078) = 0;
  *(undefined4 *)(param_1 + 0x107c) = 1000000;
  *(undefined8 *)(param_1 + 0x1080) = uVar1;
  *(undefined4 *)(param_1 + 0x1088) = 0;
  *(undefined4 *)(param_1 + 0x1090) = 0;
  *(undefined4 *)(param_1 + 0x1094) = 0;
  *(undefined4 *)(param_1 + 0x1098) = 0;
  *(undefined4 *)(param_1 + 0x109c) = 0;
  *(undefined *)(param_1 + 0x10a0) = 1;
  *(undefined4 *)(param_1 + 0x10a8) = 0;
  *(undefined4 *)(param_1 + 0x10ac) = 1000000;
  do {
    FUN_006af1a0();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  iVar6 = 0x32;
  do {
    FUN_006af1a0();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  *(undefined8 *)(param_1 + 0x16f0) = 0;
  FUN_006af1a0();
  return param_1;
}



/* FUNCTION 8852 ; VA 0x006b8270 ; FUN_006b8270 */

void __fastcall FUN_006b8270(undefined8 *param_1)

{
  *param_1 = DAT_018ce300;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0;
  *(undefined *)(param_1 + 4) = 1;
  return;
}



/* FUNCTION 8853 ; VA 0x006b8290 ; FUN_006b8290 */

void __fastcall FUN_006b8290(int param_1)

{
  FUN_016827a0(param_1);
  *(undefined8 *)(param_1 + 8) = DAT_018c0d60;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return;
}



/* FUNCTION 8854 ; VA 0x006b82c0 ; FUN_006b82c0 */

int __fastcall FUN_006b82c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7168;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  piStack_28 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_24,"CFrameOnly",param_1);
  piVar3 = piStack_20;
  uStack_2c = *puVar5;
  piVar2 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  piStack_28 = piVar2;
  uStack_18 = uStack_2c;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_24,&DAT_018dbc90,iStack_14 + 0x18);
  piVar3 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_24,"Mechanism",iStack_14 + 0x40);
  uStack_2c = *puVar5;
  piStack_28 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  piStack_1c = piStack_28;
  uStack_18 = uStack_2c;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar6 = *piVar3 + -1;
      *piVar3 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = iStack_14;
  FUN_009fdb40(auStack_24,&DAT_018dbc90,iStack_14 + 0x58);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_34,"Translation",iVar6 + 0x80);
  piVar2 = piStack_1c;
  uStack_2c = *puVar5;
  piStack_28 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  piStack_20 = piStack_28;
  uStack_18 = uStack_2c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar6 = *piVar3 + -1;
      *piVar3 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar6 = *piVar3 + -1;
      *piVar3 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = iStack_14;
  FUN_009fdb40(auStack_34,&DAT_018dbc90,iStack_14 + 0x98);
  piVar2 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_30[1] + -1;
    piStack_30[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar4 = *piVar3 + -1;
      *piVar3 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_34,"Rotation",iVar6 + 0xc0);
  piVar3 = piStack_20;
  uStack_2c = *puVar5;
  piVar2 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  piStack_28 = piVar2;
  piStack_1c = (int *)uStack_2c;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009fdb40(auStack_34,&DAT_018dbc90,iStack_14 + 0xd8);
  piVar3 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_009fd9f0(auStack_34,"Velocity",iStack_14 + 0x100);
  uStack_2c = *puVar5;
  piVar3 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  piStack_28 = piVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = FUN_009fdb40(auStack_34,&DAT_018dbc90,iStack_14 + 0x118);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_30 + 1;
    iVar4 = *piVar2;
    iVar6 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar4 = *piVar2;
      iVar6 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar6 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 1;
    iVar4 = *piVar2;
    iVar6 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar6 = (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 8855 ; VA 0x006b86c0 ; FUN_006b86c0 */

void __thiscall FUN_006b86c0(int param_1,int param_2)

{
  int *piVar1;
  double *pdVar2;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  pdVar2 = (double *)FUN_016827a0(&uStack_c);
  if (*(double *)(param_1 + 0x110 + param_2 * 0x18) <=
      *pdVar2 - *(double *)(param_1 + 0x108 + param_2 * 0x18)) {
    *(undefined4 *)(param_1 + 0x118 + param_2 * 0x18) =
         *(undefined4 *)(param_1 + 0x11c + param_2 * 0x18);
    *(undefined4 *)(param_1 + 0x11c + param_2 * 0x18) = 0;
    FUN_016827a0(&uStack_c);
    *(undefined4 *)(param_1 + 0x108 + param_2 * 0x18) = uStack_c;
    *(undefined4 *)(param_1 + 0x10c + param_2 * 0x18) = uStack_8;
  }
  piVar1 = (int *)(param_1 + 0x11c + param_2 * 0x18);
  *piVar1 = *piVar1 + 1;
  return;
}



/* FUNCTION 8856 ; VA 0x006b8740 ; FUN_006b8740 */

void __thiscall FUN_006b8740(int param_1,undefined4 *param_2)

{
  int *piVar1;
  char *pcVar2;
  char cVar3;
  undefined4 *puVar4;
  double *pdVar5;
  char *pcVar6;
  uint uVar7;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uVar7 = 0;
  while( true ) {
    pcVar2 = (&PTR_DAT_01d5b440)[uVar7];
    pcVar6 = pcVar2;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    cVar3 = FUN_0055c360(puVar4,param_2[4],pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
    if (cVar3 != '\0') break;
    uVar7 = uVar7 + 1;
    if (10 < uVar7) {
      return;
    }
  }
  pdVar5 = (double *)FUN_016827a0(&uStack_c);
  if (*(double *)(param_1 + 8 + uVar7 * 0x18) <= *pdVar5 - *(double *)(param_1 + uVar7 * 0x18)) {
    *(undefined4 *)(param_1 + 0x10 + uVar7 * 0x18) = *(undefined4 *)(param_1 + 0x14 + uVar7 * 0x18);
    *(undefined4 *)(param_1 + 0x14 + uVar7 * 0x18) = 0;
    FUN_016827a0(&uStack_c);
    *(undefined4 *)(param_1 + uVar7 * 0x18) = uStack_c;
    *(undefined4 *)(param_1 + 4 + uVar7 * 0x18) = uStack_8;
  }
  piVar1 = (int *)(param_1 + 0x14 + uVar7 * 0x18);
  *piVar1 = *piVar1 + 1;
  return;
}



/* FUNCTION 8857 ; VA 0x006b87f0 ; FUN_006b87f0 */

void __thiscall FUN_006b87f0(int param_1,int param_2)

{
  int *piVar1;
  double *pdVar2;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  pdVar2 = (double *)FUN_016827a0(&uStack_c);
  if (*(double *)(param_1 + 8 + param_2 * 0x18) <= *pdVar2 - *(double *)(param_1 + param_2 * 0x18))
  {
    *(undefined4 *)(param_1 + 0x10 + param_2 * 0x18) =
         *(undefined4 *)(param_1 + 0x14 + param_2 * 0x18);
    *(undefined4 *)(param_1 + 0x14 + param_2 * 0x18) = 0;
    FUN_016827a0(&uStack_c);
    *(undefined4 *)(param_1 + param_2 * 0x18) = uStack_c;
    *(undefined4 *)(param_1 + 4 + param_2 * 0x18) = uStack_8;
  }
  piVar1 = (int *)(param_1 + 0x14 + param_2 * 0x18);
  *piVar1 = *piVar1 + 1;
  return;
}



/* FUNCTION 8858 ; VA 0x006b8860 ; FUN_006b8860 */

void __thiscall FUN_006b8860(int param_1,byte param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = (param_2 + 0x10b) * 0x10;
  puVar1 = (uint *)(iVar4 + param_1);
  uVar3 = *puVar1;
  *puVar1 = *puVar1 + 1;
  piVar2 = (int *)(iVar4 + 4 + param_1);
  *piVar2 = *piVar2 + (uint)(0xfffffffe < uVar3);
  return;
}



/* FUNCTION 8859 ; VA 0x006b8880 ; FUN_006b8880 */

void __thiscall FUN_006b8880(int param_1,byte param_2,double param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = (param_2 + 0x10b) * 0x10;
  puVar1 = (uint *)(iVar4 + param_1);
  uVar3 = *puVar1;
  *puVar1 = *puVar1 + 1;
  piVar2 = (int *)(iVar4 + 4 + param_1);
  *piVar2 = *piVar2 + (uint)(0xfffffffe < uVar3);
  iVar4 = (param_2 + 0x13d) * 0x10;
  puVar1 = (uint *)(iVar4 + param_1);
  uVar3 = *puVar1;
  *puVar1 = *puVar1 + 1;
  piVar2 = (int *)(iVar4 + 4 + param_1);
  *piVar2 = *piVar2 + (uint)(0xfffffffe < uVar3);
  if (*(double *)(param_1 + 0x16f0) <= param_3 && param_3 != *(double *)(param_1 + 0x16f0)) {
    *(double *)(param_1 + 0x16f0) = param_3;
  }
  return;
}



/* FUNCTION 8860 ; VA 0x006b88d0 ; FUN_006b88d0 */

void __fastcall FUN_006b88d0(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0xfd0) = uVar1;
  *(undefined4 *)(param_1 + 0xfd4) = 0;
  *(undefined4 *)(param_1 + 0xfd8) = uVar1;
  *(undefined4 *)(param_1 + 0xfdc) = 0;
  *(undefined4 *)(param_1 + 0xfe0) = uVar1;
  *(undefined4 *)(param_1 + 0xfe4) = 0;
  return;
}



/* FUNCTION 8861 ; VA 0x006b8900 ; FUN_006b8900 */

void __thiscall FUN_006b8900(int param_1,int param_2,int param_3)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dStack_c;
  
  dStack_c = (double)param_3;
  sVar2 = FUN_017265ed(&dStack_c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x3c8 + param_2 * 0x28);
    dVar5 = DAT_018c0d60 - dVar1;
    dVar3 = (double)param_3;
    dVar4 = dVar3;
    if (*(char *)(param_1 + 1000 + param_2 * 0x28) == '\0') {
      dVar4 = *(double *)(param_1 + 0x3d8 + param_2 * 0x28) * dVar5 + dVar3 * dVar1;
    }
    *(int *)(param_1 + 0x3d0 + param_2 * 0x28) = param_3;
    *(double *)(param_1 + 0x3d8 + param_2 * 0x28) = dVar4;
    *(undefined *)(param_1 + 1000 + param_2 * 0x28) = 0;
    *(double *)(param_1 + 0x3e0 + param_2 * 0x28) =
         (dVar3 - dVar4) * (dVar3 - dVar4) * dVar1 +
         *(double *)(param_1 + 0x3e0 + param_2 * 0x28) * dVar5;
  }
  return;
}



/* FUNCTION 8862 ; VA 0x006b89d0 ; FUN_006b89d0 */

void FUN_006b89d0(undefined4 *param_1,int param_2)

{
  double dVar1;
  char *pcVar2;
  char cVar3;
  short sVar4;
  undefined4 *puVar5;
  char *pcVar6;
  uint uVar7;
  double dVar8;
  double dVar9;
  double dVar10;
  double dStack_10;
  int iStack_8;
  
  uVar7 = 0;
  while( true ) {
    pcVar2 = (&PTR_DAT_01d5b440)[uVar7];
    pcVar6 = pcVar2;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    puVar5 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar5 = (undefined4 *)*param_1;
    }
    cVar3 = FUN_0055c360(puVar5,param_1[4],pcVar2,(int)pcVar6 - (int)(pcVar2 + 1));
    if (cVar3 != '\0') break;
    uVar7 = uVar7 + 1;
    if (10 < uVar7) {
      return;
    }
  }
  dStack_10 = (double)param_2;
  sVar4 = FUN_017265ed(&dStack_10);
  if (sVar4 < 1) {
    dVar8 = (double)param_2;
    dVar1 = *(double *)(iStack_8 + 0x210 + uVar7 * 0x28);
    dVar10 = DAT_018c0d60 - dVar1;
    dVar9 = dVar8;
    if (*(char *)(iStack_8 + 0x230 + uVar7 * 0x28) == '\0') {
      dVar9 = *(double *)(iStack_8 + 0x220 + uVar7 * 0x28) * dVar10 + dVar8 * dVar1;
    }
    *(int *)(iStack_8 + 0x218 + uVar7 * 0x28) = param_2;
    *(double *)(iStack_8 + 0x220 + uVar7 * 0x28) = dVar9;
    *(undefined *)(iStack_8 + 0x230 + uVar7 * 0x28) = 0;
    *(double *)(iStack_8 + 0x228 + uVar7 * 0x28) =
         (dVar8 - dVar9) * (dVar8 - dVar9) * dVar1 +
         *(double *)(iStack_8 + 0x228 + uVar7 * 0x28) * dVar10;
  }
  return;
}



/* FUNCTION 8863 ; VA 0x006b8ae0 ; FUN_006b8ae0 */

void __thiscall FUN_006b8ae0(int param_1,int param_2,int param_3)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dStack_c;
  
  dStack_c = (double)param_3;
  sVar2 = FUN_017265ed(&dStack_c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x210 + param_2 * 0x28);
    dVar5 = DAT_018c0d60 - dVar1;
    dVar3 = (double)param_3;
    dVar4 = dVar3;
    if (*(char *)(param_1 + 0x230 + param_2 * 0x28) == '\0') {
      dVar4 = *(double *)(param_1 + 0x220 + param_2 * 0x28) * dVar5 + dVar3 * dVar1;
    }
    *(int *)(param_1 + 0x218 + param_2 * 0x28) = param_3;
    *(double *)(param_1 + 0x220 + param_2 * 0x28) = dVar4;
    *(undefined *)(param_1 + 0x230 + param_2 * 0x28) = 0;
    *(double *)(param_1 + 0x228 + param_2 * 0x28) =
         (dVar3 - dVar4) * (dVar3 - dVar4) * dVar1 +
         *(double *)(param_1 + 0x228 + param_2 * 0x28) * dVar5;
  }
  return;
}



/* FUNCTION 8864 ; VA 0x006b8bb0 ; FUN_006b8bb0 */

int __thiscall FUN_006b8bb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7180;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::GuidRegistryService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8865 ; VA 0x006b8c82 ; Catch_All@006b8c82 */

void Catch_All_006b8c82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8866 ; VA 0x006b8cb0 ; FUN_006b8cb0 */

undefined4 * FUN_006b8cb0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a71c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005eddf0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00723e40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006b8bb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8867 ; VA 0x006b8d70 ; FUN_006b8d70 */

int FUN_006b8d70(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a71d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaecc4,&LAB_006b8ca0);
  uVar2 = FUN_006b8f00();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_005ee470();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_006b8cb0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaecc4,&LAB_006b8ca0);
      uVar2 = FUN_006b8f00();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 8868 ; VA 0x006b8f00 ; FUN_006b8f00 */

undefined4 FUN_006b8f00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a71fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaecd0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaecd0);
    if (DAT_01eaecd0 == -1) {
      uStack_8 = 0;
      DAT_01eaeccc = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaecd0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaeccc;
}



/* FUNCTION 8869 ; VA 0x006b8f80 ; FUN_006b8f80 */

undefined4 * __fastcall FUN_006b8f80(undefined4 *param_1)

{
  FUN_0089a7a0();
  *param_1 = RBX::Network::IdSerializer::vftable;
  param_1[0x15] = 0;
  param_1[0x16] = 0xffffffff;
  return param_1;
}



/* FUNCTION 8870 ; VA 0x006b8fb0 ; FUN_006b8fb0 */

undefined4 FUN_006b8fb0(int param_1)

{
  if (param_1 != 0) {
    FUN_00628590(param_1);
    return 1;
  }
  return 0;
}



/* FUNCTION 8871 ; VA 0x006b8fd0 ; FUN_006b8fd0 */

int * __thiscall FUN_006b8fd0(int param_1,int *param_2,undefined4 param_3)

{
  int iStack_c;
  int iStack_8;
  
  FUN_006ab810(&iStack_8,param_3,*(undefined4 *)(param_1 + 0x58));
  if (iStack_8 == -1) {
    *param_2 = -1;
    param_2[1] = 0;
    return param_2;
  }
  iStack_c = 0;
  FUN_006abe60(&iStack_c,4);
  *param_2 = iStack_8;
  param_2[1] = iStack_c;
  return param_2;
}



/* FUNCTION 8872 ; VA 0x006b9040 ; FUN_006b9040 */

void __thiscall FUN_006b9040(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  int iStack_c;
  int iStack_8;
  
  FUN_006ab810(&iStack_8,param_2,*(undefined4 *)(param_1 + 0x58));
  if (iStack_8 == -1) {
    iStack_8 = -1;
    iVar1 = 0;
  }
  else {
    iStack_c = 0;
    FUN_006abe60(&iStack_c,4);
    iVar1 = iStack_c;
  }
  *param_4 = iStack_8;
  param_4[1] = iVar1;
  FUN_00621ac0(param_4,param_3);
  return;
}



/* FUNCTION 8873 ; VA 0x006b90a0 ; FUN_006b90a0 */

bool __thiscall FUN_006b90a0(int param_1,int param_2,int *param_3,int *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_006ab810(&param_2,param_2,*(undefined4 *)(param_1 + 0x58));
  if (param_2 == -1) {
    iVar5 = -1;
    piVar3 = (int *)0x0;
  }
  else {
    piStack_8 = (int *)0x0;
    FUN_006abe60(&piStack_8,4);
    iVar5 = param_2;
    piVar3 = piStack_8;
  }
  piVar4 = param_4;
  *param_4 = iVar5;
  param_4[1] = (int)piVar3;
  if (*param_4 == -1) {
    *param_3 = 0;
    piVar3 = (int *)param_3[1];
    param_3[1] = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[1] + -1;
      piVar3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar4 = piVar3 + 2;
        iVar5 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    return true;
  }
  iVar5 = *(int *)(param_1 + 0x54) + 5 + (uint)*(byte *)(*(int *)(param_1 + 0x54) + 4);
  uVar2 = FUN_009c91f0(param_4);
  FUN_00607110(&param_2,uVar2,piVar4,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (param_2 == 0) {
    *param_3 = 0;
    piVar3 = (int *)param_3[1];
    param_3[1] = 0;
    piVar4 = param_3;
  }
  else {
    uVar2 = FUN_00587490(auStack_c);
    piVar4 = param_3;
    FUN_005587e0(uVar2);
    piVar3 = piStack_8;
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return *piVar4 != 0;
}



/* FUNCTION 8874 ; VA 0x006b91d0 ; FUN_006b91d0 */

undefined * FUN_006b91d0(undefined *param_1,int param_2)

{
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = 0xffffffff;
  *(undefined4 *)(param_1 + 8) = 0;
  if (param_2 != 0) {
    FUN_00628590(param_2);
    *(undefined4 *)(param_1 + 4) = *(undefined4 *)(param_2 + 0x18);
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 0x1c);
    *param_1 = 1;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 8875 ; VA 0x006b9220 ; FUN_006b9220 */

void __thiscall FUN_006b9220(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  
  *(undefined4 *)(param_1 + 0x54) = 0;
  FUN_00611620();
  FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    iVar2 = FUN_006b8d70();
    piVar1 = *(int **)(iVar2 + 0x58);
    if (piVar1 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *(int **)(param_1 + 0x54) = piVar1;
    FUN_00611620();
  }
  return;
}



/* FUNCTION 8876 ; VA 0x006b9280 ; FUN_006b9280 */

void __thiscall FUN_006b9280(int param_1,undefined4 param_2,char *param_3)

{
  char *pcVar1;
  
  pcVar1 = param_3;
  if (*param_3 != '\0') {
    FUN_006ad220(param_2,*(undefined4 *)(param_1 + 0x58),param_3 + 4);
    param_3 = *(char **)(pcVar1 + 8);
    FUN_006ad5e0(&param_3,4);
    return;
  }
  FUN_006ad4e0(0,param_2);
  return;
}



/* FUNCTION 8877 ; VA 0x006b92d0 ; FUN_006b92d0 */

void __thiscall FUN_006b92d0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  
  piVar1 = param_3;
  if (*param_3 == -1) {
    FUN_006ad4e0(0,param_2);
    return;
  }
  FUN_006ad220(param_2,*(undefined4 *)(param_1 + 0x58),param_3);
  param_3 = (int *)piVar1[1];
  FUN_006ad5e0(&param_3,4);
  return;
}



/* FUNCTION 8878 ; VA 0x006b9320 ; FUN_006b9320 */

void __thiscall FUN_006b9320(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int iStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  if (param_3 != 0) {
    FUN_00628590(param_3);
    iStack_c = *(int *)(iVar1 + 0x18);
    uStack_8 = *(undefined4 *)(iVar1 + 0x1c);
    if (iStack_c != -1) {
      FUN_006ad220(param_2,*(undefined4 *)(param_1 + 0x58),&iStack_c);
      param_2 = uStack_8;
      FUN_006ad5e0(&param_2,4);
      return;
    }
  }
  FUN_006ad4e0(0,param_2);
  return;
}



/* FUNCTION 8879 ; VA 0x006b9390 ; FUN_006b9390 */

void __thiscall FUN_006b9390(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar2 = param_3 - param_2;
  uVar3 = iVar2 >> 2;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar3 != 0) {
    if (0x3fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00577ed0(uVar3);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + uVar3 * 4;
    iVar1 = *param_1;
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar1,param_2,iVar2);
    param_1[1] = iVar1 + iVar2;
  }
  return;
}



/* FUNCTION 8880 ; VA 0x006b9410 ; FUN_006b9410 */

void __thiscall FUN_006b9410(int *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uStack_8;
  
  uVar2 = param_2;
  iVar1 = param_1[1];
  iVar3 = *param_1;
  uVar5 = iVar1 - iVar3 >> 2;
  uStack_8 = param_1[2] - iVar3 >> 2;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar5) {
      if (param_2 != uVar5) {
        param_1[1] = iVar3 + param_2 * 4;
      }
      return;
    }
    iVar3 = (param_2 - uVar5) * 4;
    FUN_0170d1f0(iVar1,0,iVar3);
    param_1[1] = iVar1 + iVar3;
    return;
  }
  if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x3fffffff - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar3 = FUN_00577ed0(uStack_8);
  FUN_0170d1f0(iVar3 + uVar5 * 4,0,(uVar2 - uVar5) * 4);
  iVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar3,iVar1,param_1[1] - iVar1);
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar5 = param_1[2] - iVar1 & 0xfffffffc;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *param_1 = iVar3;
  param_1[1] = iVar3 + uVar2 * 4;
  param_1[2] = iVar3 + uStack_8 * 4;
  return;
}



/* FUNCTION 8881 ; VA 0x006b9540 ; FUN_006b9540 */

void FUN_006b9540(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  uVar4 = 0;
  uVar2 = (uint)((int)param_2 + (3 - (int)param_1)) >> 2;
  if (param_2 < param_1) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    puVar5 = param_1;
    if (3 < uVar2) {
      uVar1 = *param_3;
      if ((param_3 < param_1) || (param_1 + (uVar2 - 1) < param_3)) {
        do {
          uVar4 = uVar4 + 4;
        } while (uVar4 != (uVar2 & 0xfffffffc));
        puVar5 = param_1 + (uVar2 & 0xfffffffc);
        for (uVar3 = uVar2 & 0x3ffffffc; uVar3 != 0; uVar3 = uVar3 - 1) {
          *param_1 = uVar1;
          param_1 = param_1 + 1;
        }
      }
    }
    for (; uVar4 != uVar2; uVar4 = uVar4 + 1) {
      *puVar5 = *param_3;
      puVar5 = puVar5 + 1;
    }
  }
  return;
}



/* FUNCTION 8882 ; VA 0x006b95c0 ; FUN_006b95c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall FUN_006b95c0(int param_1)

{
  int iVar1;
  undefined auStack_110 [16];
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined uStack_f8;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined auStack_e0 [16];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined uStack_c8;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined uStack_b0;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined uStack_98;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined uStack_80;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined uStack_50;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7575;
  pvStack_10 = ExceptionList;
  uStack_18 = 10000000;
  uStack_38 = _DAT_018dcb10;
  uStack_34 = _UNK_018dcb14;
  uStack_30 = _UNK_018dcb18;
  uStack_2c = _UNK_018dcb1c;
  uStack_28 = _DAT_018dcb20;
  uStack_24 = _UNK_018dcb24;
  uStack_20 = _UNK_018dcb28;
  uStack_1c = _UNK_018dcb2c;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  iStack_14 = param_1;
  FUN_006b9390(&uStack_38,&iStack_14,param_1);
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_100 = 0;
  uStack_fc = 0xf;
  auStack_110[0] = 0;
  FUN_005542c0("availableCapBpsLessThan10000Bps",0x1f);
  uStack_8._0_1_ = 2;
  uStack_e8 = 0;
  uStack_e4 = 0xf;
  uStack_f8 = 0;
  FUN_005542c0("availableCapBps10000BpsTo40000Bps",0x21);
  uStack_8._0_1_ = 3;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("availableCapBps40000BpsTo100000Bps",0x22);
  uStack_8._0_1_ = 4;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("availableCapBps10000BpsTo200000Bps",0x22);
  uStack_8._0_1_ = 5;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("availableCapBps20000BpsTo400000Bps",0x22);
  uStack_8._0_1_ = 6;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("availableCapBps400000BpsTo1000000Bps",0x24);
  uStack_8._0_1_ = 7;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("availableCapBps1000000BpsTo5000000Bps",0x25);
  uStack_8._0_1_ = 8;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("availableCapBps5000000BpsTo10000000Bps",0x26);
  uStack_8._0_1_ = 9;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("availableCapBps10000000BpsPlus",0x1e);
  uStack_8._0_1_ = 10;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  FUN_00604490(auStack_110,&uStack_38,iStack_14);
  uStack_8._0_1_ = 0xc;
  FUN_016f32d1(auStack_110,0x18,9,FUN_005507b0);
  uStack_20 = 2000;
  uStack_1c = 5000;
  uStack_30 = _DAT_018dcb00;
  uStack_2c = _UNK_018dcb04;
  uStack_28 = _UNK_018dcb08;
  uStack_24 = _UNK_018dcb0c;
  uStack_18 = 10000;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  FUN_006b9390(&uStack_30,&iStack_14,iStack_14);
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  uStack_8._0_1_ = 0xe;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("transmissionBandwidthLessThan100kbps",0x24);
  uStack_8._0_1_ = 0xf;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("transmissionBandwidth100kbpsTo500kbps",0x25);
  uStack_8._0_1_ = 0x10;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("transmissionBandwidth500kbpsTo1000kbps",0x26);
  uStack_8._0_1_ = 0x11;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("transmissionBandwidth1000kbpsTo2000kbps",0x27);
  uStack_8._0_1_ = 0x12;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("transmissionBandwidth2000kbpsTo5000kbps",0x27);
  uStack_8._0_1_ = 0x13;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("transmissionBandwidth5000kbpsTo10000kbps",0x28);
  uStack_8._0_1_ = 0x14;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("transmissionBandwidth10000kbpsPlus",0x22);
  uStack_8._0_1_ = 0x15;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  FUN_00604490(auStack_e0,&uStack_38,iStack_14);
  uStack_8._0_1_ = 0x17;
  FUN_016f32d1(auStack_e0,0x18,7,FUN_005507b0);
  uStack_20 = 2000;
  uStack_30 = _DAT_018dcb00;
  uStack_2c = _UNK_018dcb04;
  uStack_28 = _UNK_018dcb08;
  uStack_24 = _UNK_018dcb0c;
  uStack_1c = 5000;
  uStack_18 = 10000;
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  FUN_006b9390(&uStack_30,&iStack_14,iStack_14);
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0;
  uStack_8._0_1_ = 0x19;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("targetAckSpeedLessThan100kbps",0x1d);
  uStack_8._0_1_ = 0x1a;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("targetAckSpeed100kbpsTo500kbps",0x1e);
  uStack_8._0_1_ = 0x1b;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("targetAckSpeed500kbpsTo1000kbps",0x1f);
  uStack_8._0_1_ = 0x1c;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("targetAckSpeed1000kbpsTo2000kbps",0x20);
  uStack_8._0_1_ = 0x1d;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("targetAckSpeed2000kbpsTo5000kbps",0x20);
  uStack_8._0_1_ = 0x1e;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("targetAckSpeed5000kbpsTo10000kbps",0x21);
  uStack_8._0_1_ = 0x1f;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("targetAckSpeed10000kbpsPlus",0x1b);
  uStack_8._0_1_ = 0x20;
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  FUN_00604490(auStack_e0,&uStack_38,iStack_14);
  uStack_8._0_1_ = 0x22;
  FUN_016f32d1(auStack_e0,0x18,7,FUN_005507b0);
  uStack_20 = 500;
  uStack_1c = 1000;
  uStack_30 = _DAT_018dcae0;
  uStack_2c = _UNK_018dcae4;
  uStack_28 = _UNK_018dcae8;
  uStack_24 = _UNK_018dcaec;
  uStack_18 = 2000;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0xb8) = 0;
  FUN_006b9390(&uStack_30,&iStack_14,iStack_14);
  *(undefined4 *)(param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  *(undefined4 *)(param_1 + 0xc4) = 0;
  uStack_8._0_1_ = 0x24;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("targetRTTLessThan10ms",0x15);
  uStack_8._0_1_ = 0x25;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("targetRTT10msTo50ms",0x13);
  uStack_8._0_1_ = 0x26;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("targetRTT50msTo100ms",0x14);
  uStack_8._0_1_ = 0x27;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("targetRTT100msTo500ms",0x15);
  uStack_8._0_1_ = 0x28;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("targetRTT500msTo1000ms",0x16);
  uStack_8._0_1_ = 0x29;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("targetRTT1000msTo2000ms",0x17);
  uStack_8._0_1_ = 0x2a;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("targetRTT2000msPlus",0x13);
  uStack_8._0_1_ = 0x2b;
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0;
  *(undefined4 *)(param_1 + 0xd0) = 0;
  FUN_00604490(auStack_e0,&uStack_38,iStack_14);
  uStack_8._0_1_ = 0x2d;
  FUN_016f32d1(auStack_e0,0x18,7,FUN_005507b0);
  uStack_20 = 500;
  uStack_1c = 1000;
  uStack_30 = _DAT_018dcad0;
  uStack_2c = _UNK_018dcad4;
  uStack_28 = _UNK_018dcad8;
  uStack_24 = _UNK_018dcadc;
  uStack_18 = 5000;
  *(undefined4 *)(param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0;
  FUN_006b9390(&uStack_30,&iStack_14,iStack_14);
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0;
  uStack_8._0_1_ = 0x2f;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("bytesSentLessThan5kB",0x14);
  uStack_8._0_1_ = 0x30;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("bytesSent5kBTo25kB",0x12);
  uStack_8._0_1_ = 0x31;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("bytesSent25kBTo100kB",0x14);
  uStack_8._0_1_ = 0x32;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("bytesSent100kBTo500kB",0x15);
  uStack_8._0_1_ = 0x33;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("bytesSent500kBTo1000kB",0x16);
  uStack_8._0_1_ = 0x34;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("bytesSent1000kBTo5000kB",0x17);
  uStack_8._0_1_ = 0x35;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("bytesSent5000kBPlus",0x13);
  uStack_8._0_1_ = 0x36;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  *(undefined4 *)(param_1 + 0x100) = 0;
  *(undefined4 *)(param_1 + 0x104) = 0;
  FUN_00604490(auStack_e0,&uStack_38,iStack_14);
  uStack_8._0_1_ = 0x38;
  FUN_016f32d1(auStack_e0,0x18,7,FUN_005507b0);
  uStack_20 = 500;
  uStack_1c = 1000;
  uStack_30 = _DAT_018dcad0;
  uStack_2c = _UNK_018dcad4;
  uStack_28 = _UNK_018dcad8;
  uStack_24 = _UNK_018dcadc;
  uStack_18 = 5000;
  *(undefined4 *)(param_1 + 0x118) = 0;
  *(undefined4 *)(param_1 + 0x11c) = 0;
  *(undefined4 *)(param_1 + 0x120) = 0;
  FUN_006b9390(&uStack_30,&iStack_14,iStack_14);
  *(undefined4 *)(param_1 + 0x124) = 0;
  *(undefined4 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 300) = 0;
  uStack_8._0_1_ = 0x3a;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("bytesAckedLessThan5kB",0x15);
  uStack_8._0_1_ = 0x3b;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("bytesAcked5kBTo25kB",0x13);
  uStack_8._0_1_ = 0x3c;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("bytesAcked25kBTo100kB",0x15);
  uStack_8._0_1_ = 0x3d;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("bytesAcked100kBTo500kB",0x16);
  uStack_8._0_1_ = 0x3e;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("bytesAcked500kBTo1000kB",0x17);
  uStack_8._0_1_ = 0x3f;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("bytesAcked1000kBTo5000kB",0x18);
  uStack_8._0_1_ = 0x40;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("bytesAcked5000kBPlus",0x14);
  uStack_8._0_1_ = 0x41;
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x134) = 0;
  *(undefined4 *)(param_1 + 0x138) = 0;
  FUN_00604490(auStack_e0,&uStack_38,iStack_14);
  uStack_8._0_1_ = 0x43;
  FUN_016f32d1(auStack_e0,0x18,7,FUN_005507b0);
  uStack_30 = _DAT_018dcaf0;
  uStack_2c = _UNK_018dcaf4;
  uStack_28 = _UNK_018dcaf8;
  uStack_24 = _UNK_018dcafc;
  uStack_20 = 1000;
  uStack_1c = 5000;
  uStack_18 = 10000;
  *(undefined4 *)(param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x150) = 0;
  *(undefined4 *)(param_1 + 0x154) = 0;
  FUN_006b9390(&uStack_30,&iStack_14,iStack_14);
  iVar1 = iStack_14;
  *(undefined4 *)(param_1 + 0x158) = 0;
  *(undefined4 *)(param_1 + 0x15c) = 0;
  *(undefined4 *)(param_1 + 0x160) = 0;
  uStack_8._0_1_ = 0x45;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = 0;
  FUN_005542c0("bytesInFlightLessThan50B",0x18);
  uStack_8._0_1_ = 0x46;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  FUN_005542c0("bytesInFlight50BTo100B",0x16);
  uStack_8._0_1_ = 0x47;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  FUN_005542c0("bytesInFlight100BTo500B",0x17);
  uStack_8._0_1_ = 0x48;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("bytesInFlight500BTo1000B",0x18);
  uStack_8._0_1_ = 0x49;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("bytesInFlight1000BTo5000B",0x19);
  uStack_8._0_1_ = 0x4a;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0("bytesInFlight5000BTo10000B",0x1a);
  uStack_8._0_1_ = 0x4b;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0("bytesInFlight10000BPlus",0x17);
  uStack_8._0_1_ = 0x4c;
  *(undefined4 *)(iVar1 + 0x164) = 0;
  *(undefined4 *)(iVar1 + 0x168) = 0;
  *(undefined4 *)(iVar1 + 0x16c) = 0;
  FUN_00604490(auStack_e0,&uStack_38,iStack_14);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x4e);
  FUN_016f32d1(auStack_e0,0x18,7,FUN_005507b0);
  FUN_006b9410(*(int *)(iVar1 + 0x18) - *(int *)(iVar1 + 0x14) >> 2,iVar1 + 0x20);
  FUN_006b9410(*(int *)(iVar1 + 0x4c) - *(int *)(iVar1 + 0x48) >> 2,iVar1 + 0x54);
  FUN_006b9410(*(int *)(iVar1 + 0x80) - *(int *)(iVar1 + 0x7c) >> 2,iVar1 + 0x88);
  FUN_006b9410(*(int *)(iVar1 + 0xb4) - *(int *)(iVar1 + 0xb0) >> 2,iVar1 + 0xbc);
  FUN_006b9410(*(int *)(iVar1 + 0xe8) - *(int *)(iVar1 + 0xe4) >> 2,iVar1 + 0xf0);
  FUN_006b9410(*(int *)(iVar1 + 0x11c) - *(int *)(iVar1 + 0x118) >> 2,iVar1 + 0x124);
  FUN_006b9410(*(int *)(iVar1 + 0x150) - *(int *)(iVar1 + 0x14c) >> 2,
               (undefined4 *)(param_1 + 0x158));
  FUN_006baae0();
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 8883 ; VA 0x006ba480 ; FUN_006ba480 */

undefined4 * __thiscall FUN_006ba480(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined auStack_1c [8];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7599;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[2] = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  param_1[6] = 0;
  *(undefined8 *)(param_1 + 8) = 0;
  param_1[10] = 0;
  *(undefined8 *)(param_1 + 0xc) = 0;
  param_1[0xe] = 0;
  *(undefined8 *)(param_1 + 0x10) = 0;
  puStack_14 = param_1;
  FUN_01682800(param_1 + 0x14);
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x17] = 0;
  FUN_01682800(param_1 + 0x18);
  FUN_006b95c0();
  uStack_8 = 0;
  FUN_006b95c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar1 = (undefined4 *)FUN_01682800(auStack_1c);
  param_1[4] = *puVar1;
  param_1[5] = puVar1[1];
  puVar1 = (undefined4 *)FUN_01682800(auStack_1c);
  param_1[0x10] = *puVar1;
  param_1[0x11] = puVar1[1];
  puVar1 = (undefined4 *)FUN_01682800(auStack_1c);
  param_1[8] = *puVar1;
  param_1[9] = puVar1[1];
  puVar1 = (undefined4 *)FUN_01682800(auStack_1c);
  param_1[0xc] = *puVar1;
  param_1[0xd] = puVar1[1];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8884 ; VA 0x006ba580 ; FUN_006ba580 */

void __fastcall FUN_006ba580(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0x158);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x160) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x158) = 0;
    *(undefined4 *)(param_1 + 0x15c) = 0;
    *(undefined4 *)(param_1 + 0x160) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x14c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x154) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x14c) = 0;
    *(undefined4 *)(param_1 + 0x150) = 0;
    *(undefined4 *)(param_1 + 0x154) = 0;
  }
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0x124);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 300) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x124) = 0;
    *(undefined4 *)(param_1 + 0x128) = 0;
    *(undefined4 *)(param_1 + 300) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x118);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x120) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x118) = 0;
    *(undefined4 *)(param_1 + 0x11c) = 0;
    *(undefined4 *)(param_1 + 0x120) = 0;
  }
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0xf0);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xf8) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xf0) = 0;
    *(undefined4 *)(param_1 + 0xf4) = 0;
    *(undefined4 *)(param_1 + 0xf8) = 0;
  }
  iVar1 = *(int *)(param_1 + 0xe4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xec) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xe4) = 0;
    *(undefined4 *)(param_1 + 0xe8) = 0;
    *(undefined4 *)(param_1 + 0xec) = 0;
  }
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0xbc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc4) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xbc) = 0;
    *(undefined4 *)(param_1 + 0xc0) = 0;
    *(undefined4 *)(param_1 + 0xc4) = 0;
  }
  iVar1 = *(int *)(param_1 + 0xb0);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xb8) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xb0) = 0;
    *(undefined4 *)(param_1 + 0xb4) = 0;
    *(undefined4 *)(param_1 + 0xb8) = 0;
  }
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0x88);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x90) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x88) = 0;
    *(undefined4 *)(param_1 + 0x8c) = 0;
    *(undefined4 *)(param_1 + 0x90) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x7c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x84) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x7c) = 0;
    *(undefined4 *)(param_1 + 0x80) = 0;
    *(undefined4 *)(param_1 + 0x84) = 0;
  }
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0x54);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x5c) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x54) = 0;
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x5c) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x50) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x48) = 0;
    *(undefined4 *)(param_1 + 0x4c) = 0;
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  FUN_00577a40();
  iVar1 = *(int *)(param_1 + 0x20);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x28) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006baa7c;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x1c) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_006baa7c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  return;
}



/* FUNCTION 8885 ; VA 0x006baa90 ; FUN_006baa90 */

void FUN_006baa90(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d5b5b8 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_006bacb0();
  }
  FUN_006ba580();
  FUN_006ba580();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8886 ; VA 0x006baae0 ; FUN_006baae0 */

void __fastcall FUN_006baae0(undefined *param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = 0;
  *param_1 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0x20),*(undefined4 *)(param_1 + 0x24),&uStack_8);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x10) = 0x80000000;
  param_1[1] = 0;
  uStack_8 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0x54),*(undefined4 *)(param_1 + 0x58),&uStack_8);
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x44) = 0x80000000;
  uStack_8 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0x88),*(undefined4 *)(param_1 + 0x8c),&uStack_8);
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x78) = 0x80000000;
  uStack_8 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0xbc),*(undefined4 *)(param_1 + 0xc0),&uStack_8);
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0xac) = 0x80000000;
  uStack_8 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0xf0),*(undefined4 *)(param_1 + 0xf4),&uStack_8);
  *(undefined4 *)(param_1 + 0xd4) = 0;
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined4 *)(param_1 + 0xdc) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0xe0) = 0x80000000;
  uStack_8 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0x124),*(undefined4 *)(param_1 + 0x128),&uStack_8);
  *(undefined4 *)(param_1 + 0x108) = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x110) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x114) = 0x80000000;
  uStack_8 = 0;
  FUN_006b9540(*(undefined4 *)(param_1 + 0x158),*(undefined4 *)(param_1 + 0x15c),&uStack_8);
  *(undefined4 *)(param_1 + 0x13c) = 0;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x148) = 0x80000000;
  return;
}



/* FUNCTION 8887 ; VA 0x006bacb0 ; FUN_006bacb0 */

void __fastcall FUN_006bacb0(int param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a75d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x68) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0xbc);
    iStack_8 = 0;
    if (*(int *)(param_1 + 0xc0) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 200) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0xbc);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0xc0) - iVar3 >> 2));
    }
    FUN_0151f9c0("transmissionBandwidthMin",*(undefined4 *)(param_1 + 0xa8));
    FUN_0151f9c0("transmissionBandwidthMax",*(undefined4 *)(param_1 + 0xac));
    FUN_0151f9c0("transmissionBandwidthAvg",*(int *)(param_1 + 0xa4) / *(int *)(param_1 + 0xa0));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0xf0);
    if (*(int *)(param_1 + 0xf4) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0xfc) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0xf0);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0xf4) - iVar3 >> 2));
    }
    FUN_0151f9c0("targetAckSpeedMin",*(undefined4 *)(param_1 + 0xdc));
    FUN_0151f9c0("targetAckSpeedMax",*(undefined4 *)(param_1 + 0xe0));
    FUN_0151f9c0("targetAckSpeedAvg",*(int *)(param_1 + 0xd8) / *(int *)(param_1 + 0xd4));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x124);
    if (*(int *)(param_1 + 0x128) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x130) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x124);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x128) - iVar3 >> 2));
    }
    FUN_0151f9c0("targetRTTMin",*(undefined4 *)(param_1 + 0x110));
    FUN_0151f9c0("targetRTTMax",*(undefined4 *)(param_1 + 0x114));
    FUN_0151f9c0("targetRTTAvg",*(int *)(param_1 + 0x10c) / *(int *)(param_1 + 0x108));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x158);
    if (*(int *)(param_1 + 0x15c) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x164) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x158);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x15c) - iVar3 >> 2));
    }
    FUN_0151f9c0("bytesSentMin",*(undefined4 *)(param_1 + 0x144));
    FUN_0151f9c0("bytesSentMax",*(undefined4 *)(param_1 + 0x148));
    FUN_0151f9c0("bytesSentAvg",*(int *)(param_1 + 0x140) / *(int *)(param_1 + 0x13c));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x18c);
    if (*(int *)(param_1 + 400) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x198) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x18c);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 400) - iVar3 >> 2));
    }
    FUN_0151f9c0("bytesAckedMin",*(undefined4 *)(param_1 + 0x178));
    FUN_0151f9c0("bytesAckedMax",*(undefined4 *)(param_1 + 0x17c));
    FUN_0151f9c0("bytesAckedAvg",*(int *)(param_1 + 0x174) / *(int *)(param_1 + 0x170));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x1c0);
    if (*(int *)(param_1 + 0x1c4) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x1cc) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x1c0);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x1c4) - iVar3 >> 2));
    }
    FUN_0151f9c0("bytesInFlightMin",*(undefined4 *)(param_1 + 0x1ac));
    FUN_0151f9c0("bytesInFlightMax",*(undefined4 *)(param_1 + 0x1b0));
    FUN_0151f9c0("bytesInFlightAvg",*(int *)(param_1 + 0x1a8) / *(int *)(param_1 + 0x1a4));
    if ((DAT_01d5b5c0 != '\0') && (*(char *)(param_1 + 0x69) != '\0')) {
      uVar6 = 0;
      iVar3 = *(int *)(param_1 + 0x88);
      if (*(int *)(param_1 + 0x8c) - iVar3 >> 2 != 0) {
        iVar5 = 0;
        do {
          puVar2 = (undefined4 *)(*(int *)(param_1 + 0x94) + iVar5);
          if (0xf < (uint)puVar2[5]) {
            puVar2 = (undefined4 *)*puVar2;
          }
          FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
          uVar6 = uVar6 + 1;
          iVar3 = *(int *)(param_1 + 0x88);
          iVar5 = iVar5 + 0x18;
        } while (uVar6 < (uint)(*(int *)(param_1 + 0x8c) - iVar3 >> 2));
      }
      FUN_0151f9c0("availableCapBpsMin",*(undefined4 *)(param_1 + 0x74));
      FUN_0151f9c0("availableCapBpsMax",*(undefined4 *)(param_1 + 0x78));
      FUN_0151f9c0("availableCapBpsAvg",*(int *)(param_1 + 0x6c) / *(int *)(param_1 + 0x70));
    }
    FUN_0151f950("GameInstanceId",&DAT_01d79c68);
    uVar1 = DAT_01eaecd8;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("BandwidthManagerFeedbackAppLimited",0x22);
    iStack_8._0_1_ = 1;
    FUN_01520d20(auStack_30,uVar1,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar6 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar6 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar4);
    }
    FUN_006baae0();
    iStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
  if (*(char *)(param_1 + 0x1d8) != '\0') {
    FUN_0151f6f0(0xffffffff,0,0);
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x22c);
    iStack_8 = 2;
    if (*(int *)(param_1 + 0x230) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x238) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x22c);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x230) - iVar3 >> 2));
    }
    FUN_0151f9c0("transmissionBandwidthMin",*(undefined4 *)(param_1 + 0x218));
    FUN_0151f9c0("transmissionBandwidthMax",*(undefined4 *)(param_1 + 0x21c));
    FUN_0151f9c0("transmissionBandwidthAvg",*(int *)(param_1 + 0x214) / *(int *)(param_1 + 0x210));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x260);
    if (*(int *)(param_1 + 0x264) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x26c) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x260);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x264) - iVar3 >> 2));
    }
    FUN_0151f9c0("targetAckSpeedMin",*(undefined4 *)(param_1 + 0x24c));
    FUN_0151f9c0("targetAckSpeedMax",*(undefined4 *)(param_1 + 0x250));
    FUN_0151f9c0("targetAckSpeedAvg",*(int *)(param_1 + 0x248) / *(int *)(param_1 + 0x244));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x294);
    if (*(int *)(param_1 + 0x298) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x2a0) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x294);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x298) - iVar3 >> 2));
    }
    FUN_0151f9c0("targetRTTMin",*(undefined4 *)(param_1 + 0x280));
    FUN_0151f9c0("targetRTTMax",*(undefined4 *)(param_1 + 0x284));
    FUN_0151f9c0("targetRTTAvg",*(int *)(param_1 + 0x27c) / *(int *)(param_1 + 0x278));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x2c8);
    if (*(int *)(param_1 + 0x2cc) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x2d4) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x2c8);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x2cc) - iVar3 >> 2));
    }
    FUN_0151f9c0("bytesSentMin",*(undefined4 *)(param_1 + 0x2b4));
    FUN_0151f9c0("bytesSentMax",*(undefined4 *)(param_1 + 0x2b8));
    FUN_0151f9c0("bytesSentAvg",*(int *)(param_1 + 0x2b0) / *(int *)(param_1 + 0x2ac));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x2fc);
    if (*(int *)(param_1 + 0x300) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x308) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x2fc);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x300) - iVar3 >> 2));
    }
    FUN_0151f9c0("bytesAckedMin",*(undefined4 *)(param_1 + 0x2e8));
    FUN_0151f9c0("bytesAckedMax",*(undefined4 *)(param_1 + 0x2ec));
    FUN_0151f9c0("bytesAckedAvg",*(int *)(param_1 + 0x2e4) / *(int *)(param_1 + 0x2e0));
    uVar6 = 0;
    iVar3 = *(int *)(param_1 + 0x330);
    if (*(int *)(param_1 + 0x334) - iVar3 >> 2 != 0) {
      iVar5 = 0;
      do {
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x33c) + iVar5);
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
        uVar6 = uVar6 + 1;
        iVar3 = *(int *)(param_1 + 0x330);
        iVar5 = iVar5 + 0x18;
      } while (uVar6 < (uint)(*(int *)(param_1 + 0x334) - iVar3 >> 2));
    }
    FUN_0151f9c0("bytesInFlightMin",*(undefined4 *)(param_1 + 0x31c));
    FUN_0151f9c0("bytesInFlightMax",*(undefined4 *)(param_1 + 800));
    FUN_0151f9c0("bytesInFlightAvg",*(int *)(param_1 + 0x318) / *(int *)(param_1 + 0x314));
    if ((DAT_01d5b5c0 != '\0') && (*(char *)(param_1 + 0x1d9) != '\0')) {
      uVar6 = 0;
      iVar3 = *(int *)(param_1 + 0x1f8);
      if (*(int *)(param_1 + 0x1fc) - iVar3 >> 2 != 0) {
        iVar5 = 0;
        do {
          puVar2 = (undefined4 *)(*(int *)(param_1 + 0x204) + iVar5);
          if (0xf < (uint)puVar2[5]) {
            puVar2 = (undefined4 *)*puVar2;
          }
          FUN_0151f9c0(puVar2,*(undefined4 *)(iVar3 + uVar6 * 4));
          uVar6 = uVar6 + 1;
          iVar3 = *(int *)(param_1 + 0x1f8);
          iVar5 = iVar5 + 0x18;
        } while (uVar6 < (uint)(*(int *)(param_1 + 0x1fc) - iVar3 >> 2));
      }
      FUN_0151f9c0("availableCapBpsMin",*(undefined4 *)(param_1 + 0x1e4));
      FUN_0151f9c0("availableCapBpsMax",*(undefined4 *)(param_1 + 0x1e8));
      FUN_0151f9c0("availableCapBpsAvg",*(int *)(param_1 + 0x1dc) / *(int *)(param_1 + 0x1e0));
    }
    FUN_0151f950("GameInstanceId",&DAT_01d79c68);
    uVar1 = DAT_01eaecd8;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("BandwidthManagerFeedbackNotAppLimited",0x25);
    iStack_8._0_1_ = 3;
    FUN_01520d20(auStack_30,uVar1,0);
    iStack_8 = CONCAT31(iStack_8._1_3_,2);
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar6 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar6 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar4);
    }
    FUN_006baae0();
    iStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
  FUN_01682800(&uStack_18);
  *(undefined4 *)(param_1 + 0x60) = uStack_18;
  *(undefined4 *)(param_1 + 100) = uStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8888 ; VA 0x006bb6a0 ; FUN_006bb6a0 */

void __fastcall FUN_006bb6a0(int param_1)

{
  int iVar1;
  void *pvVar2;
  char cVar3;
  undefined8 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7604;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_006195c0();
  if ((cVar3 == '\0') || ((*(int *)(param_1 + 0x28) < 1 && (*(int *)(param_1 + 0x48) < 1)))) {
    if (DAT_01d5b598 != '\0') {
      cVar3 = FUN_006195c0();
      pvVar2 = ThreadLocalStoragePointer;
      iVar1 = _tls_index;
      if (cVar3 == '\0') {
        if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
            DAT_01eaedb0) {
          FUN_016f3809(&DAT_01eaedb0);
          if (DAT_01eaedb0 == -1) {
            iStack_8 = 3;
            uVar4 = FUN_0152da50(&DAT_018c5904);
            DAT_01eaedac = (undefined4)((ulonglong)uVar4 >> 0x20);
            DAT_01eaeda8 = (undefined4)uVar4;
            iStack_8 = 0xffffffff;
            FUN_016f37bf(&DAT_01eaedb0);
          }
        }
        FUN_0152d740(DAT_01eaeda8,DAT_01eaedac,"No cluster data to send");
      }
      if (*(int *)(param_1 + 0x28) < 0) {
        if (*(int *)(*(int *)((int)pvVar2 + iVar1 * 4) + 0x34) < DAT_01eaedc0) {
          FUN_016f3809(&DAT_01eaedc0);
          if (DAT_01eaedc0 == -1) {
            iStack_8 = 4;
            uVar4 = FUN_0152da50(&DAT_018c5904);
            DAT_01eaedbc = (undefined4)((ulonglong)uVar4 >> 0x20);
            DAT_01eaedb8 = (undefined4)uVar4;
            iStack_8 = 0xffffffff;
            FUN_016f37bf(&DAT_01eaedc0);
          }
        }
        FUN_0152d740(DAT_01eaedb8,DAT_01eaedbc,"No byte budget for ClusterSender");
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  iStack_8 = 0;
  if (DAT_01d5b598 != '\0') {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaeda0) {
      FUN_016f3809(&DAT_01eaeda0);
      if (DAT_01eaeda0 == -1) {
        iStack_8._0_1_ = 1;
        uVar4 = FUN_0152da50(&DAT_018c5904);
        DAT_01eaed9c = (undefined4)((ulonglong)uVar4 >> 0x20);
        DAT_01eaed98 = (undefined4)uVar4;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01eaeda0);
      }
    }
    FUN_0152d760(DAT_01eaed98,DAT_01eaed9c,"ClusterSender - Byte Budget : %d",
                 *(undefined4 *)(param_1 + 0x28));
  }
  cVar3 = FUN_00620ef0();
  if (cVar3 != '\0') {
    FUN_0062dad0(*(undefined4 *)(param_1 + 0x28));
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00619540(*(undefined4 *)(param_1 + 0x28));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8889 ; VA 0x006bb76a ; Catch@006bb76a */

undefined4 Catch_006bb76a(void)

{
  char *pcVar1;
  char *pcVar2;
  int unaff_EBP;
  
  pcVar1 = (char *)(**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  if (DAT_01d84e8e != '\0') {
    pcVar2 = "empty error string";
    if (pcVar1 != (char *)0x0) {
      pcVar2 = pcVar1;
    }
    FUN_01677520(DAT_01d84e8e,"runClusterSenderHelper: %s",pcVar2);
  }
  return 0x6bb81f;
}



/* FUNCTION 8890 ; VA 0x006bb920 ; FUN_006bb920 */

void __thiscall FUN_006bb920(int *param_1,undefined8 param_2)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined1 *puVar9;
  char *pcVar10;
  undefined4 uVar11;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7660;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar1 + 0x34) < DAT_01eaede0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaede0);
    if (DAT_01eaede0 == -1) {
      uVar11 = 0xffffffff;
      pcVar10 = "Data Senders";
      uStack_8 = 0;
      puVar9 = &DAT_018c5904;
      uVar7 = FUN_0152dab0();
      DAT_01eaeddc = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eaedd8 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eaede0,puVar9,pcVar10,uVar11);
    }
  }
  uVar11 = DAT_01eaedd8;
  uStack_14 = DAT_01eaeddc;
  uVar7 = FUN_0152d930(DAT_01eaedd8,DAT_01eaeddc);
  uStack_8 = 1;
  iVar5 = FUN_0054db20();
  if (iVar5 == 0) {
    iVar5 = FUN_0054db20();
    if ((iVar5 == 0) &&
       (piVar2 = (int *)*param_1, uVar3 = *(uint *)(piVar2[0x76d] + 0x1f8),
       uVar3 == piVar2[0xe04] &&
       *(int *)(piVar2[0x76d] + 0x1fc) - piVar2[0xe05] == (uint)(uVar3 < (uint)piVar2[0xe04]))) {
      cVar4 = (**(code **)(*piVar2 + 200))();
      if (cVar4 != '\0') {
        if (DAT_01d5b598 != '\0') {
          if (*(int *)(iVar1 + 0x34) < DAT_01eaee00) {
            FUN_016f3809(&DAT_01eaee00);
            if (DAT_01eaee00 == -1) {
              uStack_8._0_1_ = 3;
              uVar8 = FUN_0152da50(&DAT_018c5904);
              DAT_01eaedfc = (undefined4)((ulonglong)uVar8 >> 0x20);
              DAT_01eaedf8 = (undefined4)uVar8;
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              FUN_016f37bf(&DAT_01eaee00);
            }
          }
          FUN_0152d740();
          if (*(int *)(iVar1 + 0x34) < DAT_01eaee10) {
            FUN_016f3809(&DAT_01eaee10);
            if (DAT_01eaee10 == -1) {
              uStack_8._0_1_ = 4;
              uVar8 = FUN_0152da50(&DAT_018c5904);
              DAT_01eaee0c = (undefined4)((ulonglong)uVar8 >> 0x20);
              DAT_01eaee08 = (undefined4)uVar8;
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              FUN_016f37bf(&DAT_01eaee10);
            }
          }
          uVar6 = FUN_0054db20();
          FUN_0152d760(DAT_01eaee08,DAT_01eaee0c,"High Priority Pending Items: %zu",uVar6);
          if (*(int *)(iVar1 + 0x34) < DAT_01eaee20) {
            FUN_016f3809(&DAT_01eaee20);
            if (DAT_01eaee20 == -1) {
              uStack_8._0_1_ = 5;
              uVar8 = FUN_0152da50(&DAT_018c5904);
              DAT_01eaee1c = (undefined4)((ulonglong)uVar8 >> 0x20);
              DAT_01eaee18 = (undefined4)uVar8;
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              FUN_016f37bf(&DAT_01eaee20);
            }
          }
          uVar6 = FUN_0054db20();
          FUN_0152d760(DAT_01eaee18,DAT_01eaee1c,"Pending Items : %zu",uVar6);
          if (*(int *)(iVar1 + 0x34) < DAT_01eaee30) {
            FUN_016f3809(&DAT_01eaee30);
            if (DAT_01eaee30 == -1) {
              uStack_8._0_1_ = 6;
              uVar8 = FUN_0152da50(&DAT_018c5904);
              DAT_01eaee2c = (undefined4)((ulonglong)uVar8 >> 0x20);
              DAT_01eaee28 = (undefined4)uVar8;
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              FUN_016f37bf(&DAT_01eaee30);
            }
          }
          FUN_0152d760(DAT_01eaee28,DAT_01eaee2c,"Replicator Common Queue Items Left : %d",
                       *(int *)(*(int *)(*param_1 + 0x1db4) + 0x1f8) - *(int *)(*param_1 + 0x3810));
        }
        goto LAB_006bbb36;
      }
    }
  }
  iVar5 = param_1[6];
  if (0 < iVar5) {
    if (DAT_01d5b598 != '\0') {
      if (*(int *)(iVar1 + 0x34) < DAT_01eaedf0) {
        FUN_016f3809(&DAT_01eaedf0);
        if (DAT_01eaedf0 == -1) {
          uStack_8._0_1_ = 2;
          uVar8 = FUN_0152da50(&DAT_018c5904);
          DAT_01eaedec = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01eaede8 = (undefined4)uVar8;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_016f37bf(&DAT_01eaedf0);
        }
      }
      FUN_0152d760(DAT_01eaede8,DAT_01eaedec,"DataSender - Byte Budget : %d",param_1[6]);
      iVar5 = param_1[6];
    }
    FUN_0062fa10(param_2,iVar5,auStack_18);
  }
LAB_006bbb36:
  uStack_8 = 7;
  FUN_0152dda0(uVar11,uStack_14,uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8891 ; VA 0x006bbd30 ; FUN_006bbd30 */

int * __fastcall FUN_006bbd30(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7678;
  pvStack_10 = ExceptionList;
  if ((0 < param_1[2]) || (param_1[2] == -1)) {
    iVar2 = *param_1;
    piVar3 = *(int **)(iVar2 + 0x384c);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(iVar2 + 0x384c);
    }
    uStack_8 = 0;
    if (*(int *)(iVar2 + 0x3848) != 0) {
      param_1 = (int *)FUN_007207f0(param_1[2],1);
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      param_1 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_1 = (int *)(**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_1 = (int *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8892 ; VA 0x006bbdd0 ; FUN_006bbdd0 */

void FUN_006bbdd0(undefined8 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a76a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaedd0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaedd0);
    if (DAT_01eaedd0 == -1) {
      uStack_8 = 0;
      uVar3 = FUN_0152dab0(&DAT_018c5904,"StreamJob",0xffffffff);
      DAT_01eaedcc = (undefined4)((ulonglong)uVar3 >> 0x20);
      DAT_01eaedc8 = (undefined4)uVar3;
      uStack_8 = 0xffffffff;
      FUN_016f37bf();
    }
  }
  uVar2 = DAT_01eaedcc;
  uVar1 = DAT_01eaedc8;
  uVar3 = FUN_0152d930(DAT_01eaedc8,DAT_01eaedcc);
  uStack_8 = 1;
  FUN_006e8ca0(param_1);
  uStack_8 = 2;
  FUN_0152dda0(uVar1,uVar2,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8893 ; VA 0x006bbee0 ; FUN_006bbee0 */

void __fastcall FUN_006bbee0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a76e4;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar2 + 0x34) < DAT_01eaed70) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaed70);
    cVar4 = DAT_01d7ad48;
    if (DAT_01eaed70 == -1) {
      uStack_8 = 0;
      uVar8 = FUN_0152dab0(&DAT_018c5904,"Physics Send Touches",0xffffffff);
      if ((cVar4 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar8);
      }
      uStack_8 = 0xffffffff;
      DAT_01eaed68 = (int)uVar8;
      DAT_01eaed6c = (int)((ulonglong)uVar8 >> 0x20);
      FUN_016f37bf(&DAT_01eaed70);
    }
  }
  uVar6 = DAT_01eaed6c;
  uVar5 = DAT_01eaed68;
  cVar4 = DAT_01d7ad48;
  uVar8 = FUN_01532c80(DAT_01eaed68,DAT_01eaed6c);
  uStack_8 = 1;
  if (param_1[0xe] < 1) {
    if (DAT_01d5b598 != '\0') {
      if (*(int *)(iVar2 + 0x34) < DAT_01eaed90) {
        FUN_016f3809(&DAT_01eaed90);
        if (DAT_01eaed90 == -1) {
          uStack_8._0_1_ = 4;
          uVar9 = FUN_0152da50(&DAT_018c5904);
          DAT_01eaed8c = (undefined4)((ulonglong)uVar9 >> 0x20);
          DAT_01eaed88 = (undefined4)uVar9;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_016f37bf(&DAT_01eaed90);
        }
      }
      FUN_0152d740(DAT_01eaed88,DAT_01eaed8c,"Touch Sender - Not time up yet to send or no budget");
    }
  }
  else {
    iVar3 = *param_1;
    piVar7 = *(int **)(iVar3 + 0x3854);
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = *(int **)(iVar3 + 0x3854);
    }
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    if (*(int *)(iVar3 + 0x3850) != 0) {
      if (DAT_01d5b598 != '\0') {
        if (*(int *)(iVar2 + 0x34) < DAT_01eaed80) {
          FUN_016f3809(&DAT_01eaed80);
          if (DAT_01eaed80 == -1) {
            uStack_8._0_1_ = 3;
            uVar9 = FUN_0152da50(&DAT_018c5904);
            DAT_01eaed7c = (undefined4)((ulonglong)uVar9 >> 0x20);
            DAT_01eaed78 = (undefined4)uVar9;
            uStack_8._0_1_ = 2;
            FUN_016f37bf(&DAT_01eaed80);
          }
        }
        FUN_0152d760(DAT_01eaed78,DAT_01eaed7c,"Touch Sender - Byte Budget : %d",param_1[0xe]);
      }
      FUN_00722310(1,param_1[0xe]);
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar2 = piVar7[1] + -1;
      piVar7[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  uStack_8 = 5;
  FUN_0152dda0(uVar5,uVar6,uVar8);
  if ((cVar4 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar5,uVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8894 ; VA 0x006bc1a0 ; FUN_006bc1a0 */

int __fastcall FUN_006bc1a0(int *param_1)

{
  char cVar1;
  double *pdVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  double dVar9;
  double dVar10;
  int aiStack_54 [8];
  undefined8 uStack_34;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a76f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (DAT_01eaecd4 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01eaecd4,"NetworkBandwdithManager: Calculate Bandwidth for Replicator : %p",
                 *param_1);
  }
  aiStack_54[0] = 0;
  aiStack_54[1] = 0;
  aiStack_54[2] = 0;
  aiStack_54[3] = 0;
  aiStack_54[4] = 0;
  aiStack_54[5] = 0;
  aiStack_54[6] = 0;
  aiStack_54[7] = 0;
  if ((((DAT_01d59d28 != '\0') && (DAT_01d59d30 != '\0')) &&
      ((DAT_01d5b5c0 != '\0' || (DAT_01d5b5a0 != '\0')))) &&
     ((pdVar2 = (double *)FUN_01682800(&uStack_34),
      DAT_018c0d60 < *pdVar2 - *(double *)(param_1 + 0x14) || (*(char *)(param_1 + 0x16) == '\0'))))
  {
    piVar3 = (int *)FUN_0054db20();
    param_1 = piStack_14;
    iVar4 = *piStack_14;
    cVar1 = (**(code **)(*piVar3 + 0x13c))
                      (*(undefined4 *)(iVar4 + 0x74),*(undefined4 *)(iVar4 + 0x78),
                       *(undefined4 *)(iVar4 + 0x7c),*(undefined4 *)(iVar4 + 0x80),
                       *(undefined4 *)(iVar4 + 0x84),*(undefined4 *)(iVar4 + 0x88),
                       *(undefined4 *)(iVar4 + 0x8c),*(undefined4 *)(iVar4 + 0x90),aiStack_54);
    *(char *)(param_1 + 0x16) = cVar1;
    if (cVar1 != '\0') {
      param_1[0x17] = aiStack_54[0];
      FUN_01682800(&iStack_24);
      param_1[0x14] = iStack_24;
      param_1[0x15] = iStack_20;
    }
  }
  if (DAT_01d5b5b8 != '\0') {
    FUN_006bc710();
    pdVar2 = (double *)FUN_01682800(&uStack_34);
    if ((double)DAT_01d5b554 < *pdVar2 - *(double *)(param_1 + 0x18)) {
      FUN_006bacb0();
    }
  }
  iVar4 = (**(code **)(*(int *)*param_1 + 0x1ac))();
  if ((char)iVar4 == '\0') {
    ExceptionList = pvStack_10;
    return iVar4;
  }
  if (*(char *)(*param_1 + 0x1db8) != '\0') {
    ExceptionList = pvStack_10;
    return *param_1;
  }
  FUN_01682800(&iStack_2c);
  dVar9 = DAT_018c0d60;
  param_1[2] = 0;
  iVar4 = DAT_01d5b4e4;
  dVar10 = (double)CONCAT44(iStack_28,iStack_2c) - *(double *)(param_1 + 4);
  if (dVar9 / (double)DAT_01d5b504 < dVar10) {
    param_1[4] = iStack_2c;
    param_1[5] = iStack_28;
    if (DAT_01d5b5a8 == '\0') {
      if (((DAT_01d5b5a0 == '\0') || (DAT_01d59d28 == '\0')) || (*(char *)(param_1 + 0x16) == '\0'))
      {
        iVar7 = (iVar4 / DAT_01d5b504) * DAT_01d5b4fc;
        iVar4 = (int)((double)iVar4 * dVar10);
        if (iVar4 <= iVar7) {
          iVar7 = iVar4;
        }
      }
      else {
        iVar4 = DAT_01d5b4ec;
        if (DAT_01d5b4ec < DAT_01d5b4f4) {
          iStack_18 = param_1[0x17];
          if (DAT_01d5b4f4 < iStack_18) {
            piVar3 = &DAT_01d5b4f4;
          }
          else {
            piVar3 = &DAT_01d5b4ec;
            if (DAT_01d5b4ec <= iStack_18) {
              piVar3 = &iStack_18;
            }
          }
          iVar4 = *piVar3;
        }
        iVar7 = (int)((double)iVar4 * dVar10);
      }
      iVar4 = FUN_0061ea10(iVar7,1,1);
      param_1[2] = iVar4;
    }
    else {
      param_1[2] = -1;
    }
  }
  if (DAT_01d5b818 != '\0') {
    uStack_34 = (double)CONCAT44(iStack_28,iStack_2c) - *(double *)(param_1 + 8);
    iStack_1c = iStack_2c;
    iStack_20 = iStack_28;
    param_1[6] = 0;
    cVar1 = (**(code **)(*(int *)*param_1 + 200))();
    iStack_18 = DAT_01d5b4c8;
    if (cVar1 == '\0') {
      iStack_18 = DAT_01d5b4c4;
    }
    cVar1 = (**(code **)(*(int *)*param_1 + 200))();
    iVar4 = DAT_01d5b4c0;
    if (cVar1 == '\0') {
      iVar4 = DAT_01d5b4bc;
    }
    if (DAT_01d5b590 == '\0') {
      iVar7 = (int)(uStack_34 / (DAT_018c0d60 / (double)DAT_01d5b4b8));
      if ((iVar7 <= iVar4) && (iVar4 = iVar7, iVar7 < 1)) {
        iVar4 = 1;
      }
      iVar4 = (iStack_18 / DAT_01d5b4b8) * iVar4;
    }
    else {
      dVar9 = DAT_018c0d60 / (double)DAT_01d5b4b8;
      if (DAT_018c0d60 / (double)DAT_01d5b4b8 <= uStack_34) {
        dVar9 = uStack_34;
      }
      iVar7 = (int)((double)iStack_18 * dVar9);
      param_1[6] = iVar7;
      iVar4 = (iStack_18 / DAT_01d5b4b8) * iVar4;
      if (iVar7 <= iVar4) {
        iVar4 = iVar7;
      }
    }
    param_1[6] = iVar4;
    param_1[8] = iStack_1c;
    param_1[9] = iStack_20;
  }
  iStack_1c = iStack_2c;
  iStack_18 = iStack_28;
  uStack_34 = (double)CONCAT44(iStack_28,iStack_2c);
  cVar1 = FUN_00620ef0();
  iVar4 = DAT_01d5b4d4;
  if (cVar1 != '\0') {
    iVar4 = DAT_01d5b4cc;
  }
  cVar1 = FUN_00620ef0();
  iStack_20 = DAT_01d5b4d8;
  if (cVar1 != '\0') {
    iStack_20 = DAT_01d5b4d0;
  }
  uStack_34 = uStack_34 - *(double *)(param_1 + 0xc);
  param_1[0x12] = 0;
  param_1[10] = 0;
  iVar7 = FUN_0061e980();
  if (iVar7 != 0) {
    uVar6 = *(uint *)(*param_1 + 0x1dbc);
    uVar5 = FUN_0061e980();
    uVar6 = uVar6 / uVar5;
    dVar9 = (double)(int)uVar6 + (double)(&DAT_018c0d90)[-((int)uVar6 >> 0x1f)];
    if (DAT_018c0d60 < dVar9) goto LAB_006bc5c5;
  }
  dVar9 = DAT_018c0d60;
LAB_006bc5c5:
  piVar3 = piStack_14;
  dVar10 = dVar9 * uStack_34;
  if ((double)iStack_20 / DAT_018ce310 <= dVar9 * uStack_34) {
    dVar10 = (double)iStack_20 / DAT_018ce310;
  }
  iStack_20 = iStack_2c;
  piStack_14[0xe] = 0;
  piStack_14[10] = (int)(dVar10 * (double)iVar4);
  piStack_14[0xc] = iStack_1c;
  piStack_14[0xd] = iStack_18;
  iStack_18 = iStack_28;
  if (DAT_01d5b5b0 == '\0') {
    iVar4 = *piStack_14;
    piVar8 = *(int **)(iVar4 + 0x3854);
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = *(int **)(iVar4 + 0x3854);
    }
    uStack_34 = (double)CONCAT44(piVar8,*(int *)(iVar4 + 0x3850));
    uStack_8 = 0;
    if (*(int *)(iVar4 + 0x3850) != 0) {
      iStack_28 = FUN_00722090(iStack_2c,iStack_28);
      piVar3[0xe] = iStack_28;
      if (0 < iStack_28) {
        piVar3[0x10] = iStack_20;
        piVar3[0x11] = iStack_18;
        iStack_28 = iStack_18;
      }
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar3 = piVar8 + 1;
      iVar4 = *piVar3;
      iStack_28 = *piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iStack_28 = (**(code **)*piVar8)();
        LOCK();
        piVar3 = piVar8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          iStack_28 = (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  else {
    dVar9 = (double)CONCAT44(iStack_28,iStack_2c) - *(double *)(piStack_14 + 0x10);
    if (DAT_018db070 < dVar9) {
      dVar10 = (double)DAT_01d5b53c / DAT_018d8a10;
      if (dVar9 <= (double)DAT_01d5b53c / DAT_018d8a10) {
        dVar10 = dVar9;
      }
      dVar9 = (double)DAT_01d5b544;
      piStack_14[0x10] = iStack_2c;
      piStack_14[0xe] = (int)(dVar9 * dVar10);
      piStack_14[0x11] = iStack_28;
      ExceptionList = pvStack_10;
      return iStack_28;
    }
  }
  ExceptionList = pvStack_10;
  return iStack_28;
}



/* FUNCTION 8895 ; VA 0x006bc710 ; FUN_006bc710 */

void __fastcall FUN_006bc710(int *param_1)

{
  char cVar1;
  int *piVar2;
  uint *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  char cStack_8;
  
  iStack_10 = 0;
  iStack_c = 0;
  iStack_20 = 0;
  iStack_1c = 0;
  iStack_18 = 0;
  iStack_14 = 0;
  cStack_8 = '\0';
  piVar2 = (int *)FUN_0054db20();
  iVar6 = *param_1;
  cVar1 = (**(code **)(*piVar2 + 0x138))
                    (*(undefined4 *)(iVar6 + 0x74),*(undefined4 *)(iVar6 + 0x78),
                     *(undefined4 *)(iVar6 + 0x7c),*(undefined4 *)(iVar6 + 0x80),
                     *(undefined4 *)(iVar6 + 0x84),*(undefined4 *)(iVar6 + 0x88),
                     *(undefined4 *)(iVar6 + 0x8c),*(undefined4 *)(iVar6 + 0x90),&iStack_20);
  if (cVar1 != '\0') {
    if (cStack_8 != '\0') {
      *(undefined *)(param_1 + 0x1a) = 1;
      if ((DAT_01d5b5c0 != '\0') && (*(char *)(param_1 + 0x16) != '\0')) {
        iVar6 = (param_1[0x20] - param_1[0x1f] >> 2) + -1;
        if (-1 < iVar6) {
          puVar3 = (uint *)(param_1[0x1f] + iVar6 * 4);
          do {
            if (*puVar3 <= (uint)param_1[0x17]) break;
            puVar3 = puVar3 + -1;
            iVar6 = iVar6 + -1;
          } while (-1 < iVar6);
        }
        iVar5 = param_1[0x17];
        iVar4 = iVar5;
        if (param_1[0x1d] <= iVar5) {
          iVar4 = param_1[0x1d];
        }
        param_1[0x1d] = iVar4;
        iVar4 = iVar5;
        if (param_1[0x1e] <= iVar5) {
          iVar4 = param_1[0x1e];
        }
        param_1[0x1b] = param_1[0x1b] + iVar5;
        param_1[0x1c] = param_1[0x1c] + 1;
        param_1[0x1e] = iVar4;
        iVar5 = 0;
        if (-1 < iVar6) {
          iVar5 = iVar6;
        }
        piVar2 = (int *)(param_1[0x22] + iVar5 * 4);
        *piVar2 = *piVar2 + 1;
        *(undefined *)((int)param_1 + 0x69) = 1;
      }
      iVar6 = (param_1[0x2d] - param_1[0x2c] >> 2) + -1;
      if (-1 < iVar6) {
        piVar2 = (int *)(param_1[0x2c] + iVar6 * 4);
        do {
          if (*piVar2 <= iStack_20) break;
          piVar2 = piVar2 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      piVar2 = (int *)(param_1[0x2f] + iVar6 * 4);
      *piVar2 = *piVar2 + 1;
      param_1[0x28] = param_1[0x28] + 1;
      param_1[0x29] = param_1[0x29] + iStack_20;
      iVar6 = param_1[0x2a];
      if (iStack_20 < param_1[0x2a]) {
        iVar6 = iStack_20;
      }
      param_1[0x2a] = iVar6;
      iVar6 = param_1[0x2b];
      if (param_1[0x2b] < iStack_20) {
        iVar6 = iStack_20;
      }
      param_1[0x2b] = iVar6;
      iVar6 = (param_1[0x3a] - param_1[0x39] >> 2) + -1;
      if (-1 < iVar6) {
        piVar2 = (int *)(param_1[0x39] + iVar6 * 4);
        do {
          if (*piVar2 <= iStack_1c) break;
          piVar2 = piVar2 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      piVar2 = (int *)(param_1[0x3c] + iVar6 * 4);
      *piVar2 = *piVar2 + 1;
      param_1[0x35] = param_1[0x35] + 1;
      param_1[0x36] = param_1[0x36] + iStack_1c;
      iVar6 = param_1[0x37];
      if (iStack_1c < param_1[0x37]) {
        iVar6 = iStack_1c;
      }
      param_1[0x37] = iVar6;
      iVar6 = param_1[0x38];
      if (param_1[0x38] < iStack_1c) {
        iVar6 = iStack_1c;
      }
      param_1[0x38] = iVar6;
      iVar6 = (param_1[0x47] - param_1[0x46] >> 2) + -1;
      if (-1 < iVar6) {
        piVar2 = (int *)(param_1[0x46] + iVar6 * 4);
        do {
          if (*piVar2 <= iStack_18) break;
          piVar2 = piVar2 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      piVar2 = (int *)(param_1[0x49] + iVar6 * 4);
      *piVar2 = *piVar2 + 1;
      param_1[0x42] = param_1[0x42] + 1;
      param_1[0x43] = param_1[0x43] + iStack_18;
      iVar6 = param_1[0x44];
      if (iStack_18 < param_1[0x44]) {
        iVar6 = iStack_18;
      }
      param_1[0x44] = iVar6;
      iVar6 = param_1[0x45];
      if (param_1[0x45] < iStack_18) {
        iVar6 = iStack_18;
      }
      param_1[0x45] = iVar6;
      iVar6 = (param_1[0x54] - param_1[0x53] >> 2) + -1;
      if (-1 < iVar6) {
        piVar2 = (int *)(param_1[0x53] + iVar6 * 4);
        do {
          if (*piVar2 <= iStack_14) break;
          piVar2 = piVar2 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      piVar2 = (int *)(param_1[0x56] + iVar6 * 4);
      *piVar2 = *piVar2 + 1;
      param_1[0x4f] = param_1[0x4f] + 1;
      param_1[0x50] = param_1[0x50] + iStack_14;
      iVar6 = param_1[0x51];
      if (iStack_14 < param_1[0x51]) {
        iVar6 = iStack_14;
      }
      param_1[0x51] = iVar6;
      iVar6 = param_1[0x52];
      if (param_1[0x52] < iStack_14) {
        iVar6 = iStack_14;
      }
      param_1[0x52] = iVar6;
      iVar6 = (param_1[0x61] - param_1[0x60] >> 2) + -1;
      if (-1 < iVar6) {
        piVar2 = (int *)(param_1[0x60] + iVar6 * 4);
        do {
          if (*piVar2 <= iStack_10) break;
          piVar2 = piVar2 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      piVar2 = (int *)(param_1[99] + iVar6 * 4);
      *piVar2 = *piVar2 + 1;
      param_1[0x5c] = param_1[0x5c] + 1;
      param_1[0x5d] = param_1[0x5d] + iStack_10;
      iVar6 = param_1[0x5e];
      if (iStack_10 < param_1[0x5e]) {
        iVar6 = iStack_10;
      }
      param_1[0x5e] = iVar6;
      iVar6 = param_1[0x5f];
      if (param_1[0x5f] < iStack_10) {
        iVar6 = iStack_10;
      }
      param_1[0x5f] = iVar6;
      iVar6 = (param_1[0x6e] - param_1[0x6d] >> 2) + -1;
      if (-1 < iVar6) {
        piVar2 = (int *)(param_1[0x6d] + iVar6 * 4);
        do {
          if (*piVar2 <= iStack_c) break;
          piVar2 = piVar2 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      piVar2 = (int *)(param_1[0x70] + iVar6 * 4);
      *piVar2 = *piVar2 + 1;
      param_1[0x69] = param_1[0x69] + 1;
      param_1[0x6a] = param_1[0x6a] + iStack_c;
      iVar6 = param_1[0x6b];
      if (iStack_c < param_1[0x6b]) {
        iVar6 = iStack_c;
      }
      param_1[0x6b] = iVar6;
      iVar6 = param_1[0x6c];
      if (param_1[0x6c] < iStack_c) {
        iVar6 = iStack_c;
      }
      param_1[0x6c] = iVar6;
      return;
    }
    *(undefined *)(param_1 + 0x76) = 1;
    if ((DAT_01d5b5c0 != '\0') && (*(char *)(param_1 + 0x16) != '\0')) {
      iVar6 = (param_1[0x7c] - param_1[0x7b] >> 2) + -1;
      if (-1 < iVar6) {
        puVar3 = (uint *)(param_1[0x7b] + iVar6 * 4);
        do {
          if (*puVar3 <= (uint)param_1[0x17]) break;
          puVar3 = puVar3 + -1;
          iVar6 = iVar6 + -1;
        } while (-1 < iVar6);
      }
      iVar5 = param_1[0x17];
      iVar4 = iVar5;
      if (param_1[0x79] <= iVar5) {
        iVar4 = param_1[0x79];
      }
      param_1[0x79] = iVar4;
      iVar4 = iVar5;
      if (param_1[0x7a] <= iVar5) {
        iVar4 = param_1[0x7a];
      }
      param_1[0x77] = param_1[0x77] + iVar5;
      param_1[0x78] = param_1[0x78] + 1;
      param_1[0x7a] = iVar4;
      iVar5 = 0;
      if (-1 < iVar6) {
        iVar5 = iVar6;
      }
      piVar2 = (int *)(param_1[0x22] + iVar5 * 4);
      *piVar2 = *piVar2 + 1;
      *(undefined *)((int)param_1 + 0x69) = 1;
    }
    iVar6 = (param_1[0x89] - param_1[0x88] >> 2) + -1;
    if (-1 < iVar6) {
      piVar2 = (int *)(param_1[0x88] + iVar6 * 4);
      do {
        if (*piVar2 <= iStack_20) break;
        piVar2 = piVar2 + -1;
        iVar6 = iVar6 + -1;
      } while (-1 < iVar6);
    }
    piVar2 = (int *)(param_1[0x8b] + iVar6 * 4);
    *piVar2 = *piVar2 + 1;
    param_1[0x84] = param_1[0x84] + 1;
    param_1[0x85] = param_1[0x85] + iStack_20;
    iVar6 = param_1[0x86];
    if (iStack_20 < param_1[0x86]) {
      iVar6 = iStack_20;
    }
    param_1[0x86] = iVar6;
    iVar6 = param_1[0x87];
    if (param_1[0x87] < iStack_20) {
      iVar6 = iStack_20;
    }
    param_1[0x87] = iVar6;
    iVar6 = (param_1[0x96] - param_1[0x95] >> 2) + -1;
    if (-1 < iVar6) {
      piVar2 = (int *)(param_1[0x95] + iVar6 * 4);
      do {
        if (*piVar2 <= iStack_1c) break;
        piVar2 = piVar2 + -1;
        iVar6 = iVar6 + -1;
      } while (-1 < iVar6);
    }
    piVar2 = (int *)(param_1[0x98] + iVar6 * 4);
    *piVar2 = *piVar2 + 1;
    param_1[0x91] = param_1[0x91] + 1;
    param_1[0x92] = param_1[0x92] + iStack_1c;
    iVar6 = param_1[0x93];
    if (iStack_1c < param_1[0x93]) {
      iVar6 = iStack_1c;
    }
    param_1[0x93] = iVar6;
    iVar6 = param_1[0x94];
    if (param_1[0x94] < iStack_1c) {
      iVar6 = iStack_1c;
    }
    param_1[0x94] = iVar6;
    iVar6 = (param_1[0xa3] - param_1[0xa2] >> 2) + -1;
    if (-1 < iVar6) {
      piVar2 = (int *)(param_1[0xa2] + iVar6 * 4);
      do {
        if (*piVar2 <= iStack_18) break;
        piVar2 = piVar2 + -1;
        iVar6 = iVar6 + -1;
      } while (-1 < iVar6);
    }
    piVar2 = (int *)(param_1[0xa5] + iVar6 * 4);
    *piVar2 = *piVar2 + 1;
    param_1[0x9e] = param_1[0x9e] + 1;
    param_1[0x9f] = param_1[0x9f] + iStack_18;
    iVar6 = param_1[0xa0];
    if (iStack_18 < param_1[0xa0]) {
      iVar6 = iStack_18;
    }
    param_1[0xa0] = iVar6;
    iVar6 = param_1[0xa1];
    if (param_1[0xa1] < iStack_18) {
      iVar6 = iStack_18;
    }
    param_1[0xa1] = iVar6;
    iVar6 = (param_1[0xb0] - param_1[0xaf] >> 2) + -1;
    if (-1 < iVar6) {
      piVar2 = (int *)(param_1[0xaf] + iVar6 * 4);
      do {
        if (*piVar2 <= iStack_14) break;
        piVar2 = piVar2 + -1;
        iVar6 = iVar6 + -1;
      } while (-1 < iVar6);
    }
    piVar2 = (int *)(param_1[0xb2] + iVar6 * 4);
    *piVar2 = *piVar2 + 1;
    param_1[0xab] = param_1[0xab] + 1;
    param_1[0xac] = param_1[0xac] + iStack_14;
    iVar6 = param_1[0xad];
    if (iStack_14 < param_1[0xad]) {
      iVar6 = iStack_14;
    }
    param_1[0xad] = iVar6;
    iVar6 = param_1[0xae];
    if (param_1[0xae] < iStack_14) {
      iVar6 = iStack_14;
    }
    param_1[0xae] = iVar6;
    iVar6 = (param_1[0xbd] - param_1[0xbc] >> 2) + -1;
    if (-1 < iVar6) {
      piVar2 = (int *)(param_1[0xbc] + iVar6 * 4);
      do {
        if (*piVar2 <= iStack_10) break;
        piVar2 = piVar2 + -1;
        iVar6 = iVar6 + -1;
      } while (-1 < iVar6);
    }
    piVar2 = (int *)(param_1[0xbf] + iVar6 * 4);
    *piVar2 = *piVar2 + 1;
    param_1[0xb8] = param_1[0xb8] + 1;
    param_1[0xb9] = param_1[0xb9] + iStack_10;
    iVar6 = param_1[0xba];
    if (iStack_10 < param_1[0xba]) {
      iVar6 = iStack_10;
    }
    param_1[0xba] = iVar6;
    iVar6 = param_1[0xbb];
    if (param_1[0xbb] < iStack_10) {
      iVar6 = iStack_10;
    }
    param_1[0xbb] = iVar6;
    iVar6 = (param_1[0xca] - param_1[0xc9] >> 2) + -1;
    if (-1 < iVar6) {
      piVar2 = (int *)(param_1[0xc9] + iVar6 * 4);
      do {
        if (*piVar2 <= iStack_c) break;
        piVar2 = piVar2 + -1;
        iVar6 = iVar6 + -1;
      } while (-1 < iVar6);
    }
    piVar2 = (int *)(param_1[0xcc] + iVar6 * 4);
    *piVar2 = *piVar2 + 1;
    param_1[0xc5] = param_1[0xc5] + 1;
    param_1[0xc6] = param_1[0xc6] + iStack_c;
    iVar6 = param_1[199];
    if (iStack_c < param_1[199]) {
      iVar6 = iStack_c;
    }
    param_1[199] = iVar6;
    iVar6 = param_1[200];
    if (param_1[200] < iStack_c) {
      iVar6 = iStack_c;
    }
    param_1[200] = iVar6;
  }
  return;
}



/* FUNCTION 8896 ; VA 0x006bcd20 ; FUN_006bcd20 */

undefined4 * __fastcall FUN_006bcd20(undefined4 *param_1)

{
  *param_1 = RakNet::PluginInterface2::vftable;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 8897 ; VA 0x006bcd30 ; FUN_006bcd30 */

void __fastcall FUN_006bcd30(undefined4 *param_1)

{
  *param_1 = RakNet::PluginInterface2::vftable;
  return;
}



/* FUNCTION 8898 ; VA 0x006bcd40 ; FUN_006bcd40 */

undefined4 * __thiscall FUN_006bcd40(undefined4 *param_1,byte param_2)

{
  *param_1 = RakNet::PluginInterface2::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 8899 ; VA 0x006bcd70 ; FUN_006bcd70 */

void FUN_006bcd70(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 9;
    do {
      FUN_00612d60();
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piVar3 + 4;
      piVar3 = piVar3 + 0xd;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 8900 ; VA 0x006bcdd0 ; FUN_006bcdd0 */

int __thiscall FUN_006bcdd0(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7710;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  iVar3 = (int)(param_1[1] - uVar1) / 0x34;
  if (iVar3 == 0x4ec4ec4) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - uVar1) / 0x34;
  uVar8 = uVar7;
  if ((uVar5 <= 0x4ec4ec4 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar5 = uVar8 * 0x34;
  if (uVar8 < 0x4ec4ec5) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_006bce88;
    if (uVar5 == 0) {
      uVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_006bce88:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006bcfc6;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar1) / 0x34) * 0x34;
  uStack_8 = 0;
  iVar4 = iVar3 + uVar8;
  FUN_006bd150(param_1,iVar4,param_3);
  if (param_2 == param_1[1]) {
    FUN_006bd060(*param_1,param_1[1],uVar8,param_1);
  }
  else {
    FUN_006bd060(*param_1,param_2,uVar8,param_1);
    FUN_006bd060(param_2,param_1[1],iVar4 + 0x34,param_1);
  }
  if (*param_1 != 0) {
    FUN_006bcd70(*param_1,param_1[1],param_1);
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar1) / 0x34) * 0x34;
    uVar2 = uVar1;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar2) - 4) {
LAB_006bcfc6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar7 * 0x34 + uVar8;
  param_1[2] = uVar5 + uVar8;
  ExceptionList = pvStack_10;
  return *param_1 + iVar3;
}



/* FUNCTION 8901 ; VA 0x006bcf9d ; Catch_All@006bcf9d */

void Catch_All_006bcf9d(void)

{
  int unaff_EBP;
  
  FUN_006bd370(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_006bd430(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8902 ; VA 0x006bcfd0 ; FUN_006bcfd0 */

void __thiscall FUN_006bcfd0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7720;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedClusterItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8903 ; VA 0x006bd03e ; Catch_All@006bd03e */

void Catch_All_006bd03e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8904 ; VA 0x006bd060 ; FUN_006bd060 */

undefined *
FUN_006bd060(undefined4 *param_1,undefined4 *param_2,undefined *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  
  if (param_1 != param_2) {
    iVar4 = (int)param_3 - (int)param_1;
    puVar2 = param_1 + 9;
    puVar3 = (undefined4 *)(param_3 + 0x18);
    do {
      *param_3 = *(undefined *)(puVar2 + -9);
      param_3 = param_3 + 0x34;
      *(undefined *)((int)puVar3 + -0x17) = *(undefined *)((int)puVar2 + -0x23);
      *(undefined8 *)(puVar3 + -5) = *(undefined8 *)(puVar2 + -8);
      puVar3[-3] = puVar2[-6];
      puVar3[-2] = puVar2[-5];
      puVar3[-1] = puVar2[-4];
      *puVar3 = puVar2[-3];
      puVar3[1] = puVar2[-2];
      puVar3[2] = 0;
      *(undefined4 *)((int)puVar2 + iVar4) = 0;
      puVar3[2] = puVar2[-1];
      *(undefined4 *)((int)puVar2 + iVar4) = *puVar2;
      puVar2[-1] = 0;
      *puVar2 = 0;
      puVar3[4] = 0;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[4] = puVar2[1];
      puVar3[5] = puVar2[2];
      puVar3[6] = puVar2[3];
      puVar1 = puVar2 + 4;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2 = puVar2 + 0xd;
      puVar3 = puVar3 + 0xd;
    } while (puVar1 != param_2);
  }
  FUN_006bcd70(param_3,param_3,param_4);
  return param_3;
}



/* FUNCTION 8905 ; VA 0x006bd150 ; FUN_006bd150 */

void FUN_006bd150(undefined4 param_1,undefined *param_2,undefined *param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a773b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_3 + 4);
  *(undefined4 *)(param_2 + 0xc) = *(undefined4 *)(param_3 + 0xc);
  *(undefined4 *)(param_2 + 0x10) = *(undefined4 *)(param_3 + 0x10);
  *(undefined4 *)(param_2 + 0x14) = *(undefined4 *)(param_3 + 0x14);
  *(undefined4 *)(param_2 + 0x18) = *(undefined4 *)(param_3 + 0x18);
  *(undefined4 *)(param_2 + 0x1c) = *(undefined4 *)(param_3 + 0x1c);
  *(undefined4 *)(param_2 + 0x20) = 0;
  *(undefined4 *)(param_2 + 0x24) = 0;
  if (*(int *)(param_3 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_3 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_2 + 0x20) = *(undefined4 *)(param_3 + 0x20);
  *(undefined4 *)(param_2 + 0x24) = *(undefined4 *)(param_3 + 0x24);
  uStack_8 = 0;
  FUN_006bd1f0(param_3 + 0x28);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8906 ; VA 0x006bd1f0 ; FUN_006bd1f0 */

int * __thiscall FUN_006bd1f0(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = (param_2[1] - *param_2) / 0x18;
  if (uVar2 != 0) {
    if (0xaaaaaaa < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar6 = FUN_00577fb0(uVar2);
    *param_1 = iVar6;
    param_1[1] = iVar6;
    param_1[2] = *param_1 + uVar2 * 0x18;
    puVar1 = (undefined4 *)param_2[1];
    puVar8 = (undefined4 *)*param_1;
    for (puVar7 = (undefined4 *)*param_2; puVar7 != puVar1; puVar7 = puVar7 + 6) {
      uVar3 = puVar7[1];
      uVar4 = puVar7[2];
      uVar5 = puVar7[3];
      *puVar8 = *puVar7;
      puVar8[1] = uVar3;
      puVar8[2] = uVar4;
      puVar8[3] = uVar5;
      *(undefined8 *)(puVar8 + 4) = *(undefined8 *)(puVar7 + 4);
      puVar8 = puVar8 + 6;
    }
    param_1[1] = (int)puVar8;
  }
  return param_1;
}



/* FUNCTION 8907 ; VA 0x006bd280 ; FUN_006bd280 */

void __fastcall FUN_006bd280(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006bcd70(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x34) * 0x34;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 8908 ; VA 0x006bd300 ; FUN_006bd300 */

int __fastcall FUN_006bd300(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00612d60();
  piVar3 = *(int **)(param_1 + 0x24);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x006bd333. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 8909 ; VA 0x006bd340 ; FUN_006bd340 */

undefined4 * __thiscall FUN_006bd340(undefined4 *param_1,byte param_2)

{
  FUN_006bd280();
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 8910 ; VA 0x006bd370 ; FUN_006bd370 */

void __thiscall FUN_006bd370(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006bcd70(param_2,param_3,param_1);
  return;
}



/* FUNCTION 8911 ; VA 0x006bd390 ; FUN_006bd390 */

bool __thiscall FUN_006bd390(int param_1,int *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  
  uVar2 = FUN_00a6ce70(param_2);
  uVar4 = uVar2 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
LAB_006bd40f:
    piVar3 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3 = (int *)*puVar1;
    }
    if (piVar3 != (int *)0x0) {
      do {
        if (uVar2 == piVar3[1]) {
          if (((*param_2 == piVar3[2]) && (param_2[1] == piVar3[3])) && (param_2[2] == piVar3[4]))
          break;
        }
        else if ((uint)piVar3[1] % *(uint *)(param_1 + 4) != uVar4) goto LAB_006bd40f;
        piVar3 = (int *)*piVar3;
        if (piVar3 == (int *)0x0) {
          return false;
        }
      } while( true );
    }
  }
  return piVar3 != (int *)0x0;
}



/* FUNCTION 8912 ; VA 0x006bd430 ; FUN_006bd430 */

void FUN_006bd430(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x34;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 8913 ; VA 0x006bd470 ; FUN_006bd470 */

void FUN_006bd470(int *param_1,undefined4 param_2,uint param_3)

{
  short sVar1;
  char cVar2;
  undefined auStack_60 [36];
  undefined auStack_3c [24];
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  sVar1 = (short)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7768;
  pvStack_10 = ExceptionList;
  param_3._0_2_ = sVar1;
  if ((param_3 & 0x30) == 0) {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_006abe60((int)&param_3 + 3,1);
    if (cVar2 == '\0') {
      FUN_0054eff0("readFast past end for int8_t");
      uStack_8 = 0;
      FUN_005f8ef0(auStack_3c);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_60,&DAT_01c27108);
    }
    cVar2 = FUN_006abe60((int)&uStack_14 + 1,1);
    if (cVar2 != '\0') {
      cVar2 = FUN_006abe60((int)&uStack_18 + 1,1);
      if (cVar2 != '\0') {
        *param_1 = (int)param_3._3_1_;
        param_1[1] = (int)uStack_14._1_1_;
        param_1[2] = (int)uStack_18._1_1_;
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0054eff0("readFast past end for int8_t");
      uStack_8 = 2;
      FUN_005f8ef0(auStack_3c);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_60,&DAT_01c27108);
    }
    FUN_0054eff0("readFast past end for int8_t");
    uStack_8 = 1;
    FUN_005f8ef0(auStack_3c);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_60,&DAT_01c27108);
  }
  if (((byte)param_3 & 0x30) == 0x10) {
    ExceptionList = &pvStack_10;
    FUN_006aaf80(param_2,&param_3);
    FUN_006aaf80(param_2,&uStack_18);
    FUN_006aaf80(param_2,&uStack_14);
    *param_1 = (int)(short)param_3;
    param_1[1] = (int)uStack_18;
    param_1[2] = (int)uStack_14;
    ExceptionList = pvStack_10;
    return;
  }
  if (((byte)param_3 & 0x30) == 0x20) {
    ExceptionList = &pvStack_10;
    FUN_006ab010(param_2,&iStack_1c);
    FUN_006ab010(param_2,&iStack_20);
    FUN_006ab010(param_2,&iStack_24);
    *param_1 = iStack_1c;
    param_1[1] = iStack_20;
    param_1[2] = iStack_24;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unexpected chunk header");
}



/* FUNCTION 8914 ; VA 0x006bd630 ; FUN_006bd630 */

void __thiscall FUN_006bd630(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  bool bStack_8;
  undefined3 uStack_7;
  
  iVar1 = *(int *)(param_3 + 0x10);
  _bStack_8 = CONCAT31((int3)((uint)param_1 >> 8),iVar1 == 0);
  FUN_006ad5e0(&bStack_8,1);
  if (iVar1 != 0) {
    piVar2 = (int *)(param_1 + 0xc);
    FUN_00a71f60(piVar2);
    if (0xf < *(uint *)(param_1 + 0x20)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_006ad5e0(piVar2,*(undefined4 *)(param_1 + 0x1c));
  }
  return;
}



/* FUNCTION 8915 ; VA 0x006bd680 ; FUN_006bd680 */

void __thiscall FUN_006bd680(int *param_1,uint param_2,uint param_3,int *param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar2 = *param_4 - *param_1;
  uVar4 = param_4[2] - param_1[2];
  uVar3 = param_4[1] - param_1[1];
  *(undefined8 *)param_1 = *(undefined8 *)param_4;
  param_1[2] = param_4[2];
  uVar1 = param_2 | (param_3 & 3) << 6;
  param_2._0_1_ = (char)uVar1;
  param_4 = (int *)uVar2;
  if ((((int)(char)uVar2 == uVar2) && ((int)(char)uVar3 == uVar3)) && ((int)(char)uVar4 == uVar4)) {
    FUN_006ad5e0(&param_2,1);
    param_2._0_1_ = (char)param_4;
    FUN_006ad5e0(&param_2,1);
    param_2._0_1_ = (char)uVar3;
    FUN_006ad5e0(&param_2,1);
    param_2 = CONCAT31(param_2._1_3_,(char)uVar4);
    FUN_006ad5e0(&param_2,1);
    return;
  }
  if ((((int)(short)uVar2 == uVar2) && ((int)(short)uVar3 == uVar3)) && ((int)(short)uVar4 == uVar4)
     ) {
    param_2 = uVar1 | 0x10;
    FUN_006ad5e0(&param_2,1);
    param_5 = (uint)param_4 & 0xffff;
    FUN_006a5c10(&param_5,&param_2,2);
    FUN_006ad5e0(&param_2,2);
    param_5 = uVar3 & 0xffff;
    FUN_006a5c10(&param_5,&param_2,2);
    FUN_006ad5e0(&param_2,2);
    param_5 = uVar4 & 0xffff;
    FUN_006a5c10(&param_5,&param_2,2);
    FUN_006ad5e0(&param_2,2);
    return;
  }
  param_2 = uVar1 | 0x20;
  FUN_006ad5e0(&param_2,1);
  param_2 = (uint)param_4;
  FUN_006a5c10(&param_2,&param_5,4);
  FUN_006ad5e0(&param_5,4);
  param_2 = uVar3;
  FUN_006a5c10(&param_2,&param_5,4);
  FUN_006ad5e0(&param_5,4);
  param_2 = uVar4;
  FUN_006a5c10(&param_2,&param_5,4);
  FUN_006ad5e0(&param_5,4);
  return;
}



/* FUNCTION 8916 ; VA 0x006bd870 ; FUN_006bd870 */

void FUN_006bd870(byte *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  byte *pbVar3;
  
  pbVar3 = param_1;
  uVar1 = *(undefined4 *)(param_1 + 0x14);
  uVar2 = *(undefined4 *)(param_1 + 0x10);
  param_1._0_1_ = (param_1[0xc] - 1) * '\x10' | *param_1 & 0xf;
  FUN_006ad5e0(&param_1,1);
  param_1._0_1_ = ((char)uVar2 + -1) * '\x10' | pbVar3[4] & 0xf;
  FUN_006ad5e0(&param_1,1);
  param_1 = (byte *)CONCAT31(param_1._1_3_,((char)uVar1 + -1) * '\x10' | pbVar3[8] & 0xf);
  FUN_006ad5e0(&param_1,1);
  return;
}



/* FUNCTION 8917 ; VA 0x006bd8f0 ; FUN_006bd8f0 */

void FUN_006bd8f0(undefined param_1)

{
  FUN_006ad5e0(&param_1,1);
  return;
}



/* FUNCTION 8918 ; VA 0x006bd910 ; FUN_006bd910 */

undefined4 __thiscall FUN_006bd910(int param_1,int *param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  double *pdVar8;
  undefined4 *puVar9;
  byte bVar10;
  uint uVar11;
  byte *pbVar12;
  byte *pbVar13;
  undefined8 uStack_b8;
  uint uStack_b0;
  int iStack_ac;
  int iStack_a8;
  int iStack_a0;
  int iStack_9c;
  double dStack_94;
  int iStack_8c;
  undefined4 uStack_88;
  uint uStack_84;
  int iStack_80;
  int iStack_7c;
  uint uStack_78;
  undefined8 uStack_74;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int *piStack_5c;
  undefined8 uStack_58;
  uint uStack_50;
  undefined8 uStack_4c;
  byte *pbStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  byte *pbStack_30;
  int iStack_2c;
  int *piStack_28;
  char cStack_24;
  undefined3 uStack_23;
  int iStack_20;
  uint uStack_1c;
  byte *pbStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a779b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_016827e0(&dStack_94);
  if ((((param_2[0xe03] & 2U) != 0) && (*(char *)(param_1 + 0x10) == '\x05')) &&
     (*(char *)(param_1 + 0x11) == '\0')) {
    ExceptionList = pvStack_10;
    return 1;
  }
  if (DAT_01d59fb8 != '\0') {
    iVar6 = FUN_016f3cd0();
    param_2[0x61b] = param_2[0x61b] + iVar6;
  }
  iStack_2c = 0;
  piStack_28 = (int *)0x0;
  uStack_8 = 0;
  FUN_00621ac0(param_1 + 0x14,&iStack_2c);
  if ((iStack_2c == 0) ||
     (iVar6 = *(int *)(iStack_2c + 0xc), iVar7 = FUN_00af0010(),
     (uint)*(ushort *)(iVar7 + 0x1da) <
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
    iVar6 = 0;
  }
  else {
    iVar6 = iStack_2c;
    if (iStack_2c == param_2[0x686]) {
      cVar5 = (**(code **)(*param_2 + 0xf4))();
      if (cVar5 == '\0') {
        if (DAT_01eace39 != '\0') {
          FUN_016774b0(DAT_01eace39,"Skipping cluster packet for illegal terrain receive",0);
        }
      }
      else {
        iVar6 = 0;
        iStack_3c = 0;
        piStack_34 = (int *)0x0;
        piStack_38 = (int *)0x0;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        iVar7 = FUN_00606ab0();
        if (iVar7 != 0) {
          piStack_38 = *(int **)(iVar7 + 0x3b98);
          if (piStack_38 != (int *)0x0) {
            LOCK();
            piStack_38[1] = piStack_38[1] + 1;
            UNLOCK();
            piStack_38 = *(int **)(iVar7 + 0x3b98);
          }
          iVar6 = *(int *)(iVar7 + 0x3b94);
          iStack_3c = iVar6;
          piStack_34 = piStack_38;
        }
        uStack_40 = *(undefined4 *)(iStack_2c + 0x134);
        pbStack_44 = *(byte **)(iStack_20 + 0x20);
        pbStack_18 = *(byte **)(iStack_20 + 0x1c);
        if (pbStack_18 != pbStack_44) {
          pbVar13 = pbStack_18 + 0xc;
          do {
            cStack_11 = *(char *)(param_2 + 0x76c);
            *(char *)((int)param_2 + 0x1db1) = cStack_11;
            pbStack_30 = pbVar13;
            cVar5 = FUN_0061f5a0();
            if (cVar5 == '\0') {
              uStack_1c = param_2[0x640];
            }
            else {
              uStack_1c = 4;
            }
            cVar5 = FUN_0061f4f0();
            pbVar12 = pbVar13;
            if (cVar5 == '\0') {
              if (((cStack_11 == '\0') || ((uint)*pbStack_18 + (uint)pbVar13[-0xb] != uStack_1c)) ||
                 (iVar7 = FUN_006bd390(), iVar7 == 0)) {
                if (DAT_01eace39 != '\0') {
                  FUN_01677520(DAT_01eace39,"Applying cluster chunk (%d, %d, %d) isEmpty=%d",
                               *(undefined4 *)(pbVar13 + -8),*(undefined4 *)(pbVar13 + -4),
                               *(undefined4 *)pbVar13,*(int *)(pbVar13 + 0x14) == 0);
                }
                cVar5 = FUN_0061f4d0();
                if (((cVar5 != '\0') && (iVar6 != 0)) && (pbVar13[-0xb] == 0)) {
                  FUN_00712830(pbStack_18,*(undefined *)(iStack_20 + 0x10));
                }
                pbVar12 = pbStack_30;
                bVar10 = *pbStack_18 + pbVar13[-0xb];
                iStack_a0 = *(int *)(pbVar13 + -8) << (bVar10 & 0x1f);
                iStack_60 = 1 << (bVar10 & 0x1f);
                iStack_68 = iStack_a0 + iStack_60;
                iStack_9c = *(int *)(pbVar13 + -4) << (bVar10 & 0x1f);
                iStack_6c = *(int *)pbVar13 << (bVar10 & 0x1f);
                iStack_64 = iStack_60 + iStack_9c;
                iStack_60 = iStack_60 + iStack_6c;
                uStack_74 = CONCAT44(iStack_9c,iStack_a0);
                FUN_00a72960(&uStack_74,pbStack_30 + 4,pbVar13[-0xb]);
                iVar6 = iStack_3c;
              }
              else if (DAT_01eace39 != '\0') {
                FUN_006bd390();
                FUN_01677520(DAT_01eace39,
                             "Skipping cluster chunk (%d, %d, %d) debounce=%d size=%d smooth count=%zu"
                             ,*(undefined4 *)(pbVar13 + -8),*(undefined4 *)(pbVar13 + -4),
                             *(undefined4 *)pbVar13,*(undefined *)(param_2 + 0x76c));
              }
            }
            else {
              _cStack_24 = CONCAT31(uStack_23,cStack_11);
              cVar5 = FUN_0061f4d0();
              if (cVar5 != '\0') {
                _cStack_24 = CONCAT31(uStack_23,cStack_11);
                if ((iVar6 != 0) && (_cStack_24 = CONCAT31(uStack_23,cStack_11), pbVar13[-0xb] == 0)
                   ) {
                  FUN_00712830(pbStack_18,*(undefined *)(iStack_20 + 0x10));
                  _cStack_24 = CONCAT31(uStack_23,*(undefined *)(param_2 + 0x76c));
                }
              }
              FUN_006be630(pbStack_18,param_2 + 0x687,uStack_40);
            }
            *(undefined *)((int)param_2 + 0x1db1) = 0;
            if ((iVar6 != 0) && (pbVar12[-0xb] == 0)) {
              bVar10 = *pbStack_18;
              iStack_ac = *(int *)(pbVar12 + -8) << (bVar10 & 0x1f);
              iStack_60 = 1 << (bVar10 & 0x1f);
              iStack_a8 = *(int *)(pbVar12 + -4) << (bVar10 & 0x1f);
              iStack_68 = iStack_ac + iStack_60;
              iStack_6c = *(int *)pbVar12 << (bVar10 & 0x1f);
              uStack_74 = CONCAT44(iStack_a8,iStack_ac);
              iStack_64 = iStack_60 + iStack_a8;
              iStack_60 = iStack_60 + iStack_6c;
              FUN_00a70da0(&iStack_8c,4);
              iVar3 = iStack_7c;
              iVar7 = iStack_80;
              uStack_4c = CONCAT44(uStack_88,iStack_8c);
              piStack_5c = &iStack_8c;
              uStack_50 = uStack_84;
              uStack_1c = uStack_78;
              while (((uVar11 = uStack_50, uStack_58._0_4_ = (int)uStack_4c, (int)uStack_58 != iVar7
                      || (uStack_58._4_4_ = (int)((ulonglong)uStack_4c >> 0x20),
                         uStack_58._4_4_ != iVar3)) ||
                     (pbVar12 = pbStack_30, iVar6 = iStack_3c, uStack_50 != uStack_1c))) {
                uStack_58 = uStack_4c;
                cVar5 = FUN_0061f4d0();
                if ((cVar5 == '\0') || (*(char *)(iStack_20 + 0x10) == '\x03')) {
                  uStack_b8 = uStack_4c;
                  uStack_b0 = uVar11;
                  FUN_0070df00(&uStack_b8,1);
                }
                FUN_00a6e100();
                uStack_4c = uStack_58;
              }
            }
            pbVar13 = pbVar12 + 0x34;
            pbStack_18 = pbStack_18 + 0x34;
            pbStack_30 = pbVar13;
          } while (pbStack_18 != pbStack_44);
        }
        if (*(char *)(param_2 + 0xdfe) != '\0') {
          pcVar2 = *(code **)(*param_2 + 0xe0);
          pdVar8 = (double *)FUN_016827e0();
          (*pcVar2)(*pdVar8 - dStack_94);
        }
        if ((*(char *)(param_2[0x7dc] + 0x5a) != '\0') && (*(char *)(param_2 + 0xe00) == '\0')) {
          iVar6 = FUN_016f3cd0();
          param_2[0x604] = param_2[0x604] + iVar6;
        }
        piVar4 = piStack_34;
        if (piStack_34 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_34[1] + -1;
          piStack_34[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_34)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar6 = *piVar1 + -1;
            *piVar1 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      goto LAB_006bdeb8;
    }
  }
  if (DAT_01eace39 != '\0') {
    iVar7 = param_2[0x686];
    puVar9 = (undefined4 *)FUN_009c9510();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < (uint)puVar9[5]) {
      puVar9 = (undefined4 *)*puVar9;
    }
    FUN_01677520(DAT_01eace39,
                 "Skipping cluster packet for bad instance. Guid:%s instance:%p terrain:%p replicator.mci:%p"
                 ,puVar9,iStack_2c,iVar6,iVar7);
    if (0xf < uStack_78) {
      uVar11 = uStack_78 + 1;
      iVar6 = iStack_8c;
      if (0xfff < uVar11) {
        iVar6 = *(int *)(iStack_8c + -4);
        uVar11 = uStack_78 + 0x24;
        if (0x1f < (iStack_8c - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar11);
    }
  }
LAB_006bdeb8:
  piVar4 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_28[1] + -1;
    piStack_28[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8919 ; VA 0x006bdf00 ; FUN_006bdf00 */

int * FUN_006bdf00(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  double dVar2;
  int *piVar3;
  char cVar4;
  byte bVar5;
  short sVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  double dVar14;
  double dVar15;
  undefined8 uStack_e4;
  uint uStack_dc;
  int iStack_d8;
  int iStack_d4;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  byte bStack_c0;
  byte bStack_bf;
  undefined8 uStack_bc;
  int iStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  undefined4 *puStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined auStack_74 [8];
  int iStack_6c;
  int iStack_68;
  int iStack_60;
  uint uStack_5c;
  uint uStack_54;
  int iStack_4c;
  int iStack_48;
  undefined8 uStack_40;
  int iStack_38;
  int *piStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  int iStack_24;
  undefined8 uStack_20;
  int iStack_18;
  byte bStack_13;
  byte bStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a77d6;
  pvStack_10 = ExceptionList;
  uStack_20 = (double)CONCAT44(*(undefined4 *)(param_3 + 0x20),(undefined4)uStack_20);
  ExceptionList = &pvStack_10;
  puVar7 = (undefined4 *)FUN_01674e20(0x28);
  uStack_30 = (double)CONCAT44(puVar7,(undefined4)uStack_30);
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puVar7[1] = 0x1b;
    puVar7[2] = 1;
    puVar7[3] = 0;
    *puVar7 = RBX::Network::DeserializedClusterItem::vftable;
    *(undefined *)((int)puVar7 + 0x11) = 1;
    puVar7[5] = 0xffffffff;
    puVar7[6] = 0;
    puVar7[7] = 0;
    puVar7[8] = 0;
    puVar7[9] = 0;
  }
  iStack_38 = 0;
  piStack_34 = (int *)0x0;
  FUN_006bcfd0(puVar7,param_3);
  uStack_8 = 0;
  puVar7 = (undefined4 *)FUN_006b8fd0(&uStack_30,param_3);
  iVar13 = iStack_38;
  *(undefined4 *)(iStack_38 + 0x14) = *puVar7;
  *(undefined4 *)(iStack_38 + 0x18) = puVar7[1];
  if (((*(uint *)(param_2 + 0x380c) & 2) != 0) && (*(char *)(param_2 + 0x37f8) != '\0')) {
    cVar4 = FUN_006abe40();
    *(char *)(iVar13 + 0x10) = cVar4;
    if (cVar4 == '\x05') {
      iStack_18 = FUN_006ac4d0();
      iVar8 = FUN_00606ab0(param_2);
      if (iVar8 != 0) {
        cVar4 = FUN_0070ed20(&iStack_18);
        piVar3 = piStack_34;
        *(char *)(iVar13 + 0x11) = cVar4;
        if (cVar4 == '\0') {
          *param_1 = 0;
          param_1[1] = 0;
          if (piStack_34 != (int *)0x0) {
            LOCK();
            iVar13 = piStack_34[1] + -1;
            piStack_34[1] = iVar13;
            UNLOCK();
            if (iVar13 == 0) {
              (**(code **)*piStack_34)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar13 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar13 == 1) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return param_1;
        }
      }
    }
  }
  FUN_006ab530();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0061a740(param_3,auStack_74);
  uStack_28 = 0;
  iStack_18 = 0;
  iStack_24 = 0;
  uVar9 = uStack_28;
  iVar8 = iStack_18;
  if (uStack_54 < uStack_5c) {
    do {
      iStack_18 = iVar8;
      uStack_28 = uVar9;
      bStack_12 = FUN_006abe40();
      uStack_40._0_5_ = CONCAT14(bStack_12,(undefined4)uStack_40);
      bStack_13 = bStack_12 >> 6;
      bStack_12 = bStack_12 & 0xf;
      iVar13 = 1 << bStack_12;
      FUN_006bd470(&iStack_cc,auStack_74,uStack_40._4_4_);
      iStack_24 = iStack_24 + iStack_c4;
      iVar8 = iStack_c8 + iStack_18;
      uVar9 = iStack_cc + uStack_28;
      iStack_4c = uVar9;
      iStack_48 = iVar8;
      iStack_18 = iVar8;
      cStack_11 = FUN_006abe40();
      cVar4 = FUN_0061f4f0();
      if ((cVar4 == '\0') && (DAT_01eace39 != '\0')) {
        FUN_01677520(DAT_01eace39,"Cluster deserialize for (%d,%d,%d) isEmpty=%d",iStack_4c,
                     iStack_18,iStack_24,cStack_11);
      }
      FUN_00a6dbd0(iVar13,iVar13,iVar13);
      uStack_8._0_1_ = 2;
      if (cStack_11 == '\0') {
        uVar10 = FUN_00a6f140(iStack_6c + uStack_54,uStack_5c - uStack_54);
        FUN_006ab660(uVar10);
      }
      uStack_bc = CONCAT44(iStack_48,iStack_4c);
      bStack_c0 = bStack_12;
      bStack_bf = bStack_13;
      iStack_b4 = iStack_24;
      uStack_b0 = uStack_8c;
      uStack_ac = uStack_88;
      uStack_a8 = uStack_84;
      uStack_a4 = uStack_80;
      if (piStack_78 != (int *)0x0) {
        LOCK();
        piStack_78[1] = piStack_78[1] + 1;
        UNLOCK();
      }
      puVar7 = (undefined4 *)0x0;
      uStack_a0 = uStack_7c;
      piStack_9c = piStack_78;
      uStack_98 = 0;
      puStack_94 = (undefined4 *)0x0;
      puStack_90 = (undefined4 *)0x0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      cVar4 = FUN_0061f4f0();
      if (cVar4 != '\0') {
        uVar11 = FUN_006abe40();
        uVar12 = uVar11 & 0xff;
        uStack_30 = (double)(CONCAT44(uVar11,(undefined4)uStack_30) & 0xffffffffff);
        if (uVar12 != 0) {
          do {
            uStack_28 = uVar12;
            bStack_13 = FUN_006abe40();
            bStack_12 = FUN_006abe40();
            bVar5 = FUN_006abe40();
            iStack_d8 = (bStack_13 >> 4) + 1;
            uStack_e4 = (ulonglong)CONCAT14(bStack_12,(uint)bStack_13) & 0xf0000000f;
            uStack_dc = bVar5 & 0xf;
            iStack_d4 = (bStack_12 >> 4) + 1;
            iStack_d0 = (bVar5 >> 4) + 1;
            if (puStack_90 == puVar7) {
              FUN_00603350(puVar7,&uStack_e4);
            }
            else {
              uStack_e4._4_4_ = (undefined4)(uStack_e4 >> 0x20);
              *puVar7 = (undefined4)uStack_e4;
              puVar7[1] = uStack_e4._4_4_;
              puVar7[2] = uStack_dc;
              puVar7[3] = iStack_d8;
              *(ulonglong *)(puVar7 + 4) = CONCAT44(iStack_d0,iStack_d4);
              puStack_94 = puVar7 + 6;
            }
            puVar7 = puStack_94;
            uVar12 = uStack_28 - 1;
          } while (uStack_28 - 1 != 0);
          uStack_28 = 0;
          uVar12 = uStack_30._4_4_;
        }
        if (DAT_01eace39 != '\0') {
          FUN_01677520(DAT_01eace39,"Cluster deserialize for (%d,%d,%d) isEmpty=%d maskCount=%d",
                       iStack_4c,iStack_18,iStack_24,cStack_11,uVar12);
        }
      }
      iVar13 = iStack_38;
      if (*(int *)(iStack_38 + 0x24) == *(int *)(iStack_38 + 0x20)) {
        FUN_006bcdd0(*(int *)(iStack_38 + 0x20),&bStack_c0);
      }
      else {
        FUN_006bd150(iStack_38 + 0x1c);
        *(int *)(iVar13 + 0x20) = *(int *)(iVar13 + 0x20) + 0x34;
      }
      FUN_00612d60();
      piVar3 = piStack_9c;
      if (piStack_9c != (int *)0x0) {
        LOCK();
        iVar13 = piStack_9c[1] + -1;
        piStack_9c[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_9c)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar13 = *piVar1 + -1;
          *piVar1 = iVar13;
          UNLOCK();
          if (iVar13 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = piStack_78;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piStack_78 != (int *)0x0) {
        LOCK();
        iVar13 = piStack_78[1] + -1;
        piStack_78[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_78)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar13 = *piVar1 + -1;
          *piVar1 = iVar13;
          UNLOCK();
          if (iVar13 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      iVar13 = iStack_38;
    } while (uStack_54 < uStack_5c);
  }
  if (*(char *)(*(int *)(param_2 + 0x1f70) + 0x5a) != '\0') {
    iVar8 = *(int *)(param_3 + 0x20) - uStack_20._4_4_;
    *(float *)(iVar13 + 0xc) = (float)((double)iVar8 + (double)(&DAT_018c0d90)[-(iVar8 >> 0x1f)]);
  }
  *(int *)(iVar13 + 8) = (*(int *)(iVar13 + 0x20) - *(int *)(iVar13 + 0x1c)) / 0x34;
  if (*(char *)(param_2 + 0x740) == '\0') {
    FUN_016827a0(&uStack_20);
    uStack_40 = uStack_20 - *(double *)(param_2 + 0x738);
    *(undefined4 *)(param_2 + 0x738) = (undefined4)uStack_20;
    *(int *)(param_2 + 0x73c) = uStack_20._4_4_;
    uStack_30 = uStack_40;
    sVar6 = FUN_017265ed(&uStack_40);
    dVar2 = DAT_018c0d60;
    if (sVar6 < 1) {
      dVar14 = *(double *)(param_2 + 0x748);
      dVar15 = uStack_30;
      if (*(char *)(param_2 + 0x768) == '\0') {
        dVar15 = (DAT_018c0d60 - dVar14) * *(double *)(param_2 + 0x758) + dVar14 * uStack_30;
      }
      *(double *)(param_2 + 0x750) = uStack_30;
      *(double *)(param_2 + 0x758) = dVar15;
      *(undefined *)(param_2 + 0x768) = 0;
      *(double *)(param_2 + 0x760) =
           (uStack_30 - dVar15) * (uStack_30 - dVar15) * dVar14 +
           (dVar2 - dVar14) * *(double *)(param_2 + 0x760);
    }
  }
  else {
    FUN_016827a0(&uStack_20);
    *(undefined4 *)(param_2 + 0x738) = (undefined4)uStack_20;
    *(int *)(param_2 + 0x73c) = uStack_20._4_4_;
    *(undefined *)(param_2 + 0x740) = 0;
  }
  uStack_30 = (double)*(int *)(param_3 + 0x20) +
              (double)(&DAT_018c0d90)[-(*(int *)(param_3 + 0x20) >> 0x1f)];
  uStack_20 = uStack_30;
  sVar6 = FUN_017265ed(&uStack_30);
  if (sVar6 < 1) {
    dVar2 = *(double *)(param_2 + 0x778);
    dVar14 = uStack_20;
    if (*(char *)(param_2 + 0x798) == '\0') {
      dVar14 = (DAT_018c0d60 - dVar2) * *(double *)(param_2 + 0x788) + uStack_20 * dVar2;
    }
    *(double *)(param_2 + 0x780) = uStack_20;
    *(double *)(param_2 + 0x788) = dVar14;
    dVar15 = DAT_018c0d60 - dVar2;
    *(undefined *)(param_2 + 0x798) = 0;
    *(double *)(param_2 + 0x790) =
         (uStack_20 - dVar14) * (uStack_20 - dVar14) * dVar2 + dVar15 * *(double *)(param_2 + 0x790)
    ;
  }
  *param_1 = iVar13;
  param_1[1] = (int)piStack_34;
  if (iStack_68 != 0) {
    uVar9 = iStack_60 - iStack_68;
    iVar13 = iStack_68;
    if (0xfff < uVar9) {
      iVar13 = *(int *)(iStack_68 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iStack_68 - iVar13) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar9);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8920 ; VA 0x006be630 ; FUN_006be630 */

int * FUN_006be630(byte *param_1,int param_2,undefined4 param_3,char param_4,int *param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  char cVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  byte bVar8;
  undefined4 *puVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  undefined auStack_78 [24];
  undefined8 uStack_60;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined auStack_48 [12];
  int iStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  byte *pbStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a77f0;
  pvStack_10 = ExceptionList;
  bVar8 = *param_1 + param_1[1];
  iStack_54 = 1 << (bVar8 & 0x1f);
  iStack_38 = *(int *)(param_1 + 8) << (bVar8 & 0x1f);
  iStack_58 = *(int *)(param_1 + 0xc) << (bVar8 & 0x1f);
  iStack_3c = *(int *)(param_1 + 4) << (bVar8 & 0x1f);
  iStack_4c = iStack_58 + iStack_54;
  iStack_50 = iStack_38 + iStack_54;
  iStack_54 = iStack_54 + iStack_3c;
  uStack_60 = CONCAT44(iStack_38,iStack_3c);
  ExceptionList = &pvStack_10;
  uVar5 = FUN_00a6ce70(param_1 + 4);
  iStack_28 = *(int *)(param_2 + 0x1c);
  uVar5 = *(uint *)(param_2 + 0x28) & uVar5;
  puVar2 = *(undefined4 **)(param_2 + 0x14);
  piStack_18 = (int *)(iStack_28 + uVar5 * 8);
  iVar10 = uVar5 * 8 + 4;
  piVar7 = piStack_18;
  do {
    piVar7 = (int *)*piVar7;
    puVar9 = puVar2;
    if ((undefined4 *)*piStack_18 != puVar2) {
      puVar9 = (undefined4 *)**(undefined4 **)(iVar10 + iStack_28);
    }
    if (piVar7 == puVar9) goto LAB_006be74b;
    iStack_1c = *(int *)(param_1 + 4);
  } while (((piVar7[2] != iStack_1c) || (iStack_20 = *(int *)(param_1 + 8), piVar7[3] != iStack_20))
          || (iStack_24 = *(int *)(param_1 + 0xc), piVar6 = piVar7, piVar7[4] != iStack_24));
  while( true ) {
    puVar9 = puVar2;
    if ((undefined4 *)*piStack_18 != puVar2) {
      puVar9 = (undefined4 *)**(undefined4 **)(iVar10 + iStack_28);
    }
    if (((piVar6 == puVar9) || (iStack_1c != piVar6[2])) ||
       ((iStack_20 != piVar6[3] || (iStack_24 != piVar6[4])))) break;
    piVar6 = (undefined4 *)*piVar6;
  }
  iStack_30 = (int)piVar7;
  pbStack_2c = (byte *)piVar7;
  if (piVar7 == piVar6) {
LAB_006be74b:
    piVar6 = puVar2;
    piVar7 = puVar2;
  }
  iVar10 = 0;
  for (; piVar7 != piVar6; piVar7 = (int *)*piVar7) {
    iVar10 = iVar10 + 1;
  }
  bVar8 = param_1[1];
  iStack_14 = iVar10;
  if (bVar8 != 0) {
    if (param_4 != '\0') {
      piVar7 = (int *)((uint)*param_1 + (uint)bVar8);
      if ((piVar7 == param_5) && (iVar10 != 0)) {
        if (DAT_01eace39 == '\0') {
          ExceptionList = pvStack_10;
          return piVar7;
        }
        piVar7 = (int *)FUN_01677520(DAT_01eace39,
                                     "Skipping cluster chunk (%d, %d, %d) debounce=%d size=%d hasOutgoing=%d lod=%d"
                                     ,*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8),
                                     *(undefined4 *)(param_1 + 0xc),param_4,piVar7 == param_5,1,
                                     (uint)bVar8);
        ExceptionList = pvStack_10;
        return piVar7;
      }
    }
    if (DAT_01eace39 != '\0') {
      FUN_01677520(DAT_01eace39,"Applying cluster chunk (%d, %d, %d) isEmpty=%d lod=%d",
                   *(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8),
                   *(undefined4 *)(param_1 + 0xc),*(int *)(param_1 + 0x20) == 0,bVar8);
      bVar8 = param_1[1];
    }
    piVar7 = (int *)FUN_00a72960(&uStack_60,param_1 + 0x10,bVar8);
    ExceptionList = pvStack_10;
    return piVar7;
  }
  if (iVar10 == 0) {
    piStack_18 = (int *)0x0;
  }
  else {
    piVar7 = (int *)FUN_00614f50(param_1 + 4);
    piStack_18 = (int *)((piVar7[1] - *piVar7) / 0x18);
  }
  if (DAT_01eace39 != '\0') {
    FUN_01677520(DAT_01eace39,
                 "Applying cluster chunk (%d, %d, %d) applying debounceEnabled=%d hasOutgoing=%d incomingMaskCount=%zd outgoingMaskCount=%zd"
                 ,*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8),
                 *(undefined4 *)(param_1 + 0xc),param_4,iVar10 != 0,
                 (*(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28)) / 0x18,piStack_18);
  }
  iVar12 = *(int *)(param_1 + 0x2c);
  pbStack_2c = param_1 + 0x10;
  iVar11 = *(int *)(param_1 + 0x28);
  iStack_30 = iVar12;
  if (iVar11 == iVar12) {
    piVar7 = (int *)FUN_00a72960(&uStack_60,pbStack_2c,0);
  }
  else {
    do {
      FUN_00a716f0(auStack_78,&uStack_60);
      FUN_00a71340(auStack_48,iVar11);
      uStack_8 = 0;
      piVar7 = (int *)FUN_00a72960(auStack_78,auStack_48,0);
      piVar6 = piStack_34;
      uStack_8 = 0xffffffff;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_34 + 1;
        iVar10 = *piVar1;
        piVar7 = (int *)*piVar1;
        *piVar1 = iVar10 + -1;
        UNLOCK();
        if (iVar10 + -1 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar10 = *piVar1;
          piVar7 = (int *)*piVar1;
          *piVar1 = iVar10 + -1;
          UNLOCK();
          if (iVar10 + -1 == 0) {
            piVar7 = (int *)(**(code **)(*piVar6 + 4))();
          }
        }
      }
      iVar11 = iVar11 + 0x18;
      iVar10 = iStack_14;
    } while (iVar11 != iVar12);
  }
  if ((param_4 != '\0') && (iVar10 != 0)) {
    piVar7 = (int *)FUN_00614f50(param_1 + 4);
    if (*(int *)(param_1 + 0x28) == *(int *)(param_1 + 0x2c)) {
      piVar7[1] = *piVar7;
      ExceptionList = pvStack_10;
      return piVar7;
    }
    FUN_006bd1f0(piVar7);
    iVar11 = iStack_38;
    iVar10 = *(int *)(param_1 + 0x2c);
    iVar12 = *(int *)(param_1 + 0x28);
    uStack_8 = 1;
    while ((iVar12 != iVar10 && (iVar3 = iStack_3c, *piVar7 != piVar7[1]))) {
      for (; iVar3 != iVar11; iVar3 = iVar3 + 0x18) {
        cVar4 = FUN_00a714f0(iVar3);
        if (cVar4 != '\0') {
          FUN_0061ff50(piVar7,iVar12);
          break;
        }
      }
      iVar12 = iVar12 + 0x18;
    }
    piVar7 = (int *)FUN_00612d60();
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 8921 ; VA 0x006bea10 ; FUN_006bea10 */

int __thiscall FUN_006bea10(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  
  iVar6 = *param_1;
  iVar3 = (param_1[1] - *param_1) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = (param_1[2] - *param_1) / 0xc;
  uVar7 = uVar1;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar5 = uVar7 * 0xc;
  if (uVar7 < 0x15555556) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_006beaab;
    if (uVar5 == 0) {
      puVar9 = (undefined8 *)0x0;
    }
    else {
      puVar9 = (undefined8 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006beaab:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006bebf5;
    puVar9 = (undefined8 *)(iVar3 + 0x23U & 0xffffffe0);
    *(int *)((int)puVar9 + -4) = iVar3;
  }
  iVar6 = (((int)param_2 - iVar6) / 0xc) * 0xc;
  *(undefined8 *)(iVar6 + (int)puVar9) = *param_3;
  *(undefined4 *)(iVar6 + 8 + (int)puVar9) = *(undefined4 *)(param_3 + 1);
  puVar11 = (undefined8 *)param_1[1];
  puVar4 = (undefined8 *)*param_1;
  puVar8 = puVar9;
  if (param_2 == puVar11) {
    for (; puVar4 != puVar11; puVar4 = (undefined8 *)((int)puVar4 + 0xc)) {
      *puVar8 = *puVar4;
      *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar4 + 1);
      puVar8 = (undefined8 *)((int)puVar8 + 0xc);
    }
  }
  else {
    if (puVar4 != param_2) {
      do {
        *puVar8 = *puVar4;
        puVar11 = puVar4 + 1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
        *(undefined4 *)(puVar8 + 1) = *(undefined4 *)puVar11;
        puVar8 = (undefined8 *)((int)puVar8 + 0xc);
      } while (puVar4 != param_2);
      puVar11 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar11) {
      puVar4 = (undefined8 *)(iVar6 + 0xc + (int)puVar9);
      do {
        *puVar4 = *param_2;
        puVar8 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)(puVar4 + 1) = *(undefined4 *)puVar8;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      } while (param_2 != puVar11);
    }
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar7 = ((param_1[2] - iVar3) / 0xc) * 0xc;
    iVar10 = iVar3;
    if (0xfff < uVar7) {
      iVar10 = *(int *)(iVar3 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar3 - iVar10) - 4U) {
LAB_006bebf5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar7);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)puVar9 + uVar1 * 0xc;
  param_1[2] = uVar5 + (int)puVar9;
  return *param_1 + iVar6;
}



/* FUNCTION 8922 ; VA 0x006bec00 ; FUN_006bec00 */

int __thiscall FUN_006bec00(int *param_1,int param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined *puVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7800;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  puVar2 = (undefined *)((param_1[1] - iVar5) / 0xd8);
  if (puVar2 == &DAT_012f684b) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  puVar1 = puVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xd8;
  puVar7 = puVar1;
  if ((uVar3 <= (int)&DAT_012f684b - (uVar3 >> 1)) &&
     (puVar7 = (undefined *)((uVar3 >> 1) + uVar3), puVar7 < puVar1)) {
    puVar7 = puVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006180c0(puVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0xd8) * 0xd8;
  iVar6 = iVar5 + iVar4;
  FUN_006bf1d0(param_1,iVar6,param_3);
  if (param_2 == param_1[1]) {
    FUN_006bfba0(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_006bfb10(*param_1,param_2,iVar4);
    FUN_006bfb10(param_2,param_1[1],iVar6 + 0xd8);
  }
  uStack_8 = 0xffffffff;
  FUN_006bf9d0(iVar4,puVar2 + 1,puVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 8923 ; VA 0x006bed41 ; Catch_All@006bed41 */

void Catch_All_006bed41(void)

{
  int unaff_EBP;
  
  FUN_00616fa0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0061a420(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8924 ; VA 0x006bed70 ; FUN_006bed70 */

void __thiscall FUN_006bed70(int *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int iVar12;
  int iVar13;
  int *piVar14;
  
  uVar8 = (int)param_4 - (int)param_3 >> 2;
  iVar12 = (int)param_2 - *param_1 >> 2;
  if ((uVar8 == 1) && (param_2 == (int *)param_1[1])) {
    bVar4 = true;
  }
  else {
    bVar4 = false;
    if (uVar8 == 0) {
      return;
    }
  }
  piVar9 = (int *)param_1[1];
  if (uVar8 <= (uint)(param_1[2] - (int)piVar9 >> 2)) {
    if (uVar8 < (uint)((int)piVar9 - (int)param_2 >> 2)) {
      piVar10 = piVar9 + -uVar8;
      piVar14 = piVar9;
      for (piVar11 = piVar10; piVar11 != piVar9; piVar11 = piVar11 + 1) {
        iVar12 = *piVar11;
        *piVar14 = iVar12;
        LOCK();
        piVar1 = (int *)(iVar12 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        piVar14 = piVar14 + 1;
      }
      param_1[1] = (int)piVar14;
      while (piVar10 != param_2) {
        iVar12 = piVar10[-1];
        piVar9 = piVar9 + -1;
        piVar10 = piVar10 + -1;
        LOCK();
        piVar14 = (int *)(iVar12 + 0x28);
        *piVar14 = *piVar14 + 1;
        UNLOCK();
        *piVar9 = iVar12;
        FUN_0056cd30();
      }
      piVar9 = param_2;
      if (param_2 != param_2 + uVar8) {
        do {
          FUN_0056cd30();
          piVar9 = piVar9 + 1;
        } while (piVar9 != param_2 + uVar8);
      }
      if (param_3 != param_4) {
        do {
          iVar12 = *param_3;
          *param_2 = iVar12;
          LOCK();
          piVar9 = (int *)(iVar12 + 0x28);
          *piVar9 = *piVar9 + 1;
          UNLOCK();
          param_3 = param_3 + 1;
          param_2 = param_2 + 1;
        } while (param_3 != param_4);
        return;
      }
    }
    else {
      piVar11 = param_2 + uVar8;
      piVar14 = param_2;
      if (param_2 != piVar9) {
        do {
          iVar12 = *piVar14;
          *piVar11 = iVar12;
          LOCK();
          piVar10 = (int *)(iVar12 + 0x28);
          *piVar10 = *piVar10 + 1;
          UNLOCK();
          piVar14 = piVar14 + 1;
          piVar11 = piVar11 + 1;
        } while (piVar14 != piVar9);
      }
      param_1[1] = (int)piVar11;
      piVar14 = param_2;
      if (param_2 != piVar9) {
        do {
          FUN_0056cd30();
          piVar14 = piVar14 + 1;
        } while (piVar14 != piVar9);
      }
      if (param_3 != param_4) {
        do {
          iVar12 = *param_3;
          *param_2 = iVar12;
          LOCK();
          piVar9 = (int *)(iVar12 + 0x28);
          *piVar9 = *piVar9 + 1;
          UNLOCK();
          param_3 = param_3 + 1;
          param_2 = param_2 + 1;
        } while (param_3 != param_4);
      }
    }
    return;
  }
  iVar13 = (int)piVar9 - *param_1 >> 2;
  if (0x3fffffffU - iVar13 < uVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = iVar13 + uVar8;
  uVar5 = param_1[2] - *param_1 >> 2;
  uVar6 = uVar2;
  if ((uVar5 <= 0x3fffffff - (uVar5 >> 1)) && (uVar6 = uVar5 + (uVar5 >> 1), uVar6 < uVar2)) {
    uVar6 = uVar2;
  }
  uVar5 = uVar6 * 4;
  if (uVar6 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_006bee33;
    if (uVar5 == 0) {
      piVar9 = (int *)0x0;
    }
    else {
      piVar9 = (int *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_006bee33:
    uVar7 = uVar5 + 0x23;
    if (uVar7 <= uVar5) {
      uVar7 = 0xffffffff;
    }
    iVar13 = FUN_01674e20(uVar7);
    if (iVar13 == 0) goto LAB_006bf0a0;
    piVar9 = (int *)(iVar13 + 0x23U & 0xffffffe0);
    piVar9[-1] = iVar13;
  }
  if (param_3 != param_4) {
    iVar13 = iVar12 * 4 - (int)param_3;
    do {
      iVar3 = *param_3;
      *(int *)(iVar13 + (int)piVar9 + (int)param_3) = iVar3;
      LOCK();
      piVar14 = (int *)(iVar3 + 0x28);
      *piVar14 = *piVar14 + 1;
      UNLOCK();
      param_3 = param_3 + 1;
    } while (param_3 != param_4);
  }
  if (bVar4) {
    piVar11 = (int *)param_1[1];
    piVar14 = piVar9;
    for (piVar10 = (int *)*param_1; piVar10 != piVar11; piVar10 = piVar10 + 1) {
      iVar12 = *piVar10;
      *piVar14 = iVar12;
      LOCK();
      piVar1 = (int *)(iVar12 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      piVar14 = piVar14 + 1;
    }
  }
  else {
    FUN_00617ca0(*param_1,param_2,piVar9);
    FUN_00617ca0(param_2,param_1[1],piVar9 + iVar12 + uVar8);
  }
  iVar12 = *param_1;
  if (iVar12 != 0) {
    iVar13 = param_1[1];
    if (iVar12 != iVar13) {
      do {
        FUN_0056cd30();
        iVar12 = iVar12 + 4;
      } while (iVar12 != iVar13);
      iVar12 = *param_1;
    }
    uVar8 = param_1[2] - iVar12 & 0xfffffffc;
    iVar13 = iVar12;
    if (0xfff < uVar8) {
      iVar13 = *(int *)(iVar12 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar12 - iVar13) - 4U) {
LAB_006bf0a0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar8);
  }
  *param_1 = (int)piVar9;
  param_1[1] = (int)(piVar9 + uVar2);
  param_1[2] = (int)(piVar9 + uVar6);
  return;
}



/* FUNCTION 8925 ; VA 0x006bf0b0 ; FUN_006bf0b0 */

void __thiscall FUN_006bf0b0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7810;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedNewInstanceItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8926 ; VA 0x006bf11e ; Catch_All@006bf11e */

void Catch_All_006bf11e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8927 ; VA 0x006bf140 ; FUN_006bf140 */

void __thiscall FUN_006bf140(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7820;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedResolveNewInstanceAtomicTreeItem>::
              vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8928 ; VA 0x006bf1ae ; Catch_All@006bf1ae */

void Catch_All_006bf1ae(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8929 ; VA 0x006bf1d0 ; FUN_006bf1d0 */

void FUN_006bf1d0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a783b;
  pvStack_10 = ExceptionList;
  puVar1 = param_3 + 3;
  ExceptionList = &pvStack_10;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = 0;
  iVar2 = param_3[2];
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 4))(puVar1,param_2 + 3);
    iVar2 = param_3[2];
  }
  param_2[2] = iVar2;
  if (param_3[2] != 0) {
    (**(code **)(param_3[2] + 8))(puVar1);
    param_3[2] = 0;
  }
  uStack_8 = 0;
  uVar3 = FUN_00888530();
  param_3[1] = uVar3;
  if (param_3[2] != 0) {
    (**(code **)(param_3[2] + 8))(puVar1);
    param_3[2] = 0;
  }
  *(undefined *)(param_2 + 0x35) = *(undefined *)(param_3 + 0x35);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8930 ; VA 0x006bf290 ; FUN_006bf290 */

int __fastcall FUN_006bf290(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_008aa870();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 8931 ; VA 0x006bf2d0 ; FUN_006bf2d0 */

undefined4 * __thiscall FUN_006bf2d0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_1;
}



/* FUNCTION 8932 ; VA 0x006bf340 ; FUN_006bf340 */

undefined4 * __fastcall FUN_006bf340(undefined4 *param_1)

{
  param_1[1] = 2;
  param_1[2] = 1;
  param_1[3] = 0;
  *param_1 = RBX::Network::DeserializedNewInstanceItem::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  *(undefined2 *)(param_1 + 0x12) = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  return param_1;
}



/* FUNCTION 8933 ; VA 0x006bf3f0 ; FUN_006bf3f0 */

undefined4 * __thiscall
FUN_006bf3f0(undefined4 *param_1,int *param_2,undefined4 param_3,int param_4,int *param_5,
            undefined4 *param_6,undefined param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7876;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::NewInstanceItem::vftable;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[0xd] = param_4;
  param_1[0xe] = param_5;
  param_1[0xf] = 0xffffffff;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x11] = *param_6;
  param_1[0x12] = param_6[1];
  *(undefined *)(param_1 + 0x13) = param_7;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  cVar3 = (**(code **)(*param_2 + 0x114))(param_4);
  if (cVar3 != '\0') {
    FUN_006209c0(param_4);
    iVar2 = *(int *)(param_4 + 0x34);
    param_1[0xf] = *(undefined4 *)(iVar2 + 0x18);
    param_1[0x10] = *(undefined4 *)(iVar2 + 0x1c);
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8934 ; VA 0x006bf520 ; FUN_006bf520 */

undefined4 * __thiscall
FUN_006bf520(undefined4 *param_1,undefined4 param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::ResolveNewInstanceAtomicTreeItem::vftable;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  param_1[0xc] = param_3;
  param_1[0xd] = param_4;
  param_1[0xe] = 0xffffffff;
  param_1[0xf] = 0;
  iVar2 = *(int *)(param_3 + 0x34);
  param_1[0xe] = *(undefined4 *)(iVar2 + 0x18);
  param_1[0xf] = *(undefined4 *)(iVar2 + 0x1c);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8935 ; VA 0x006bf5f0 ; FUN_006bf5f0 */

void __fastcall FUN_006bf5f0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00577ac0();
      piVar3 = *(int **)(iVar2 + 0x14);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x24);
  }
  return;
}



/* FUNCTION 8936 ; VA 0x006bf650 ; FUN_006bf650 */

int __fastcall FUN_006bf650(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00577ac0();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x006bf683. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 8937 ; VA 0x006bf690 ; FUN_006bf690 */

void __fastcall FUN_006bf690(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        iVar2 = puVar7[8];
        if (iVar2 != 0) {
          uVar5 = puVar7[10] - iVar2 & 0xfffffff0;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar5 + 0x23;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006bf79f;
          }
          FUN_01674ea0(iVar3,uVar5);
          puVar7[8] = 0;
          puVar7[9] = 0;
          puVar7[10] = 0;
        }
        uVar5 = puVar7[7];
        if (0xf < uVar5) {
          iVar2 = puVar7[2];
          uVar6 = uVar5 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar6) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar6 = uVar5 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006bf79f;
          }
          FUN_01674ea0(iVar3,uVar6);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_006bf79f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 8938 ; VA 0x006bf7b0 ; FUN_006bf7b0 */

void __fastcall FUN_006bf7b0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        iVar2 = puVar7[8];
        if (iVar2 != 0) {
          uVar5 = puVar7[10] - iVar2 & 0xfffffff0;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar5 + 0x23;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006bf79f;
          }
          FUN_01674ea0(iVar3,uVar5);
          puVar7[8] = 0;
          puVar7[9] = 0;
          puVar7[10] = 0;
        }
        uVar5 = puVar7[7];
        if (0xf < uVar5) {
          iVar2 = puVar7[2];
          uVar6 = uVar5 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar6) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar6 = uVar5 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006bf79f;
          }
          FUN_01674ea0(iVar3,uVar6);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_006bf79f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 8939 ; VA 0x006bf7c0 ; FUN_006bf7c0 */

undefined4 * __thiscall FUN_006bf7c0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[5];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 8940 ; VA 0x006bf840 ; FUN_006bf840 */

undefined4 * __thiscall FUN_006bf840(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0x12];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xe];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 8941 ; VA 0x006bf8e0 ; FUN_006bf8e0 */

undefined4 * __thiscall FUN_006bf8e0(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0xd];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 8942 ; VA 0x006bf950 ; FUN_006bf950 */

void __thiscall FUN_006bf950(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0xc;
  param_1[2] = param_2 + param_4 * 0xc;
  return;
}



/* FUNCTION 8943 ; VA 0x006bf9d0 ; FUN_006bf9d0 */

void __thiscall FUN_006bf9d0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00602ed0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xd8) * 0xd8;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0xd8 + param_2;
  param_1[2] = param_4 * 0xd8 + param_2;
  return;
}



/* FUNCTION 8944 ; VA 0x006bfa60 ; FUN_006bfa60 */

void __thiscall FUN_006bfa60(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7880;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_006180c0(param_2);
  uStack_8 = 0;
  FUN_006bfba0(*param_1,param_1[1],uVar3);
  uStack_8 = 0xffffffff;
  FUN_006bf9d0(uVar3,(iVar1 - iVar2) / 0xd8,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8945 ; VA 0x006bfae3 ; Catch_All@006bfae3 */

void Catch_All_006bfae3(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + 8);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0061a420(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8946 ; VA 0x006bfb10 ; FUN_006bfb10 */

int __thiscall FUN_006bfb10(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7898;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      ExceptionList = ppvVar1;
      FUN_006bf1d0(param_1,param_4,param_2);
      param_4 = param_4 + 0xd8;
      param_2 = param_2 + 0xd8;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  uStack_8 = 1;
  FUN_00602ed0(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 8947 ; VA 0x006bfba0 ; FUN_006bfba0 */

void __thiscall FUN_006bfba0(undefined4 param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a78b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    piVar3 = param_2 + 2;
    ExceptionList = &pvStack_10;
    do {
      *param_4 = piVar3[-2];
      param_4[1] = piVar3[-1];
      param_4[2] = 0;
      puVar2 = (undefined4 *)*piVar3;
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)*puVar2)(piVar3 + 1,param_4 + 3);
        puVar2 = (undefined4 *)*piVar3;
      }
      param_4[2] = (int)puVar2;
      *(undefined *)(param_4 + 0x35) = *(undefined *)(piVar3 + 0x33);
      param_4 = param_4 + 0x36;
      piVar1 = piVar3 + 0x34;
      piVar3 = piVar3 + 0x36;
    } while (piVar1 != param_3);
  }
  uStack_8 = 1;
  FUN_00602ed0(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8948 ; VA 0x006bfc60 ; FUN_006bfc60 */

void __fastcall FUN_006bfc60(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  if (iVar2 != iVar1) {
    do {
      FUN_0056cd30();
      iVar2 = iVar2 + 4;
    } while (iVar2 != iVar1);
    param_1[1] = *param_1;
    return;
  }
  param_1[1] = iVar2;
  return;
}



/* FUNCTION 8949 ; VA 0x006bfc90 ; FUN_006bfc90 */

void __fastcall FUN_006bfc90(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00577ac0();
      piVar3 = *(int **)(iVar2 + 0x14);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x24);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  puVar4[2] = 0;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  *(undefined8 *)(puVar4 + 6) = 0;
  puVar4[8] = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 8950 ; VA 0x006bfd10 ; FUN_006bfd10 */

void __thiscall FUN_006bfd10(int param_1,int param_2,int param_3,ushort param_4,ushort param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined *puVar5;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a78db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_4 < param_5) {
    do {
      iVar2 = iStack_14;
      uStack_8 = 0xffffffff;
      iVar4 = *(int *)(*(int *)(param_2 + 0x19f4) + 100);
      if ((uint)param_4 < (uint)((*(int *)(*(int *)(param_2 + 0x19f4) + 0x68) - iVar4) / 0x14)) {
        iVar4 = iVar4 + (uint)param_4 * 0x14;
      }
      else {
        iVar4 = 0;
      }
      if (param_3 == 0) {
LAB_006bfdb7:
        iVar3 = iStack_14 + 0x10;
        if ((*(int *)(iStack_14 + 0x10) == *(int *)(iStack_14 + 0x14)) &&
           (puVar5 = (undefined *)
                     ((uint)*(ushort *)(*(int *)(iStack_14 + 0x2c) + 4) -
                     (uint)*(ushort *)(*(int *)(iStack_14 + 0x2c) + 2)),
           (undefined *)((*(int *)(iStack_14 + 0x18) - *(int *)(iStack_14 + 0x10)) / 0xd8) < puVar5)
           ) {
          if (&DAT_012f684b < puVar5) {
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          FUN_006bfa60(puVar5);
        }
        uStack_ec = 0;
        uStack_e8 = FUN_00888530();
        iStack_e4 = 0;
        uStack_18 = 0;
        uStack_8 = 0;
        if (*(int *)(iVar2 + 0x18) == *(int *)(iVar2 + 0x14)) {
          FUN_006bec00(*(int *)(iVar2 + 0x14),&uStack_ec);
        }
        else {
          FUN_006bf1d0(iVar3);
          *(int *)(iVar2 + 0x14) = *(int *)(iVar2 + 0x14) + 0xd8;
        }
        uStack_8 = 1;
        if (iStack_e4 != 0) {
          (**(code **)(iStack_e4 + 8))(auStack_e0);
        }
        iVar2 = *(int *)(iStack_14 + 0x14);
        *(undefined4 *)(iVar2 + -0xd8) = *(undefined4 *)(iVar4 + 0x10);
        *(undefined *)(iVar2 + -4) = 1;
      }
      else {
        cVar1 = *(char *)(iVar4 + 4);
        if (((((cVar1 == '!') || (cVar1 == '\x1c')) || (cVar1 == '\"')) ||
            ((cVar1 == '\x06' || (cVar1 == '/')))) || (iVar3 = 1, cVar1 == '\x03')) {
          iVar3 = 2;
        }
        if (iVar3 == param_3) goto LAB_006bfdb7;
      }
      param_4 = param_4 + 1;
    } while (param_4 < param_5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8951 ; VA 0x006bfec0 ; FUN_006bfec0 */

undefined4 FUN_006bfec0(void)

{
  return 2;
}



/* FUNCTION 8952 ; VA 0x006bfed0 ; FUN_006bfed0 */

undefined4 __thiscall FUN_006bfed0(int param_1,code *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  code *pcVar12;
  int *piVar13;
  code *pcVar14;
  undefined8 uVar15;
  undefined4 in_stack_ffffff20;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined auStack_a8 [20];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  int iStack_88;
  int iStack_78;
  undefined4 uStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  undefined auStack_60 [12];
  uint uStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  code *pcStack_3c;
  undefined4 uStack_38;
  code *pcStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  char cStack_22;
  char cStack_21;
  int iStack_20;
  undefined uStack_19;
  int *piStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar14 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a796e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (DAT_01d59fb8 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00628370(*(undefined4 *)(*(int *)(param_1 + 0x38) + 0xc),*(undefined4 *)(param_1 + 0xc));
  }
  piVar13 = (int *)(iStack_20 + 0x38);
  piStack_28 = piVar13;
  if (*(int *)(iStack_20 + 0x38) == 0) {
    uVar16 = FUN_009c93d0(auStack_60,4);
    uStack_8 = 0;
    FUN_00558d90(&iStack_78,"Replication: deserialized item contain null object ",uVar16);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_005507b0();
    uVar16 = FUN_005543f0(6);
    FUN_0086edd0(3,uVar16);
    FUN_005500e0(&iStack_78);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_48,&DAT_01c17198);
  }
  piStack_18 = (int *)(iStack_20 + 0x40);
  pcStack_34 = (code *)(iStack_20 + 0x10);
  cVar6 = (**(code **)(*(int *)pcVar14 + 0xf8))(*piVar13,*piStack_18,pcStack_34);
  cStack_11 = cVar6 == '\0';
  if (cVar6 != '\0') {
    puVar10 = *(undefined4 **)(*(int *)(*piVar13 + 0xc) + 0x1dc);
    uVar16 = DAT_01edf5b0;
    if (puVar10 != (undefined4 *)0x0) {
      uVar16 = *puVar10;
    }
    uStack_4c = (code *)FUN_01675290(uVar16);
    uStack_8 = 3;
    pcStack_3c = *(code **)(pcStack_34 + 4);
    pcVar12 = *(code **)pcStack_34;
    pcStack_34 = pcVar12;
    if (pcVar12 != pcStack_3c) {
      do {
        FUN_0062bbf0(*(undefined4 *)pcVar12,pcVar12 + 4,pcVar12[0xd4],
                     *(undefined4 *)(iStack_20 + 0x38));
        pcVar12 = pcVar12 + 0xd8;
      } while (pcVar12 != pcStack_3c);
    }
    uStack_8 = 4;
    FUN_01675290(uStack_4c);
    uStack_8 = 0xffffffff;
    piVar13 = piStack_28;
  }
  uVar16 = 0x6bfff7;
  iVar7 = FUN_0170d75d(*piVar13,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Service::RTTI_Type_Descriptor,0);
  uStack_19 = (code)(iVar7 != 0);
  if (((DAT_01d59fd0 == '\0') || (cVar6 = (**(code **)(*(int *)pcVar14 + 0x11c))(), cVar6 != '\0'))
     && (cVar6 = (**(code **)(*(int *)pcVar14 + 0x11c))(), cVar6 == '\0')) {
LAB_006c00ce:
    if (cStack_11 == '\0') {
      FUN_00562c90(&iStack_30,piVar13);
      uStack_8 = 6;
      if ((iStack_30 != 0) && (cVar6 = (**(code **)(*(int *)pcVar14 + 0xd4))(), cVar6 == '\0')) {
        if (*(int *)(*(int *)(pcVar14 + 0x1dc0) + 0xf4) == 0) {
          if (*(int *)(pcVar14 + 0x3ae8) != 0 || *(int *)(pcVar14 + 0x3aec) != 0) {
            uVar15 = FUN_00928340();
            if (((int)uVar15 != *(int *)(pcVar14 + 0x3ae8)) ||
               ((int)((ulonglong)uVar15 >> 0x20) != *(int *)(pcVar14 + 0x3aec))) {
              FUN_00550130("Received unexpected player instance!");
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(&uStack_48,&DAT_01c17198);
            }
          }
          uStack_38 = 0;
          pcStack_34 = (code *)0x0;
          uVar20 = 0;
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          uVar3 = *(undefined4 *)(iStack_20 + 0x2c);
          puVar10 = &uStack_38;
          uVar19 = 1;
          uVar18 = 1;
          uVar17 = 1;
          FUN_00557fc0(piStack_28);
          FUN_00617d00(uVar3,in_stack_ffffff20,uVar16,uVar17,uVar18,uVar19,puVar10,uVar20);
          FUN_00557fc0(&iStack_30);
          FUN_0098ccc0(puVar10,uVar20);
          FUN_00550b30();
          piVar13 = piStack_28;
        }
        cStack_11 = '\0';
      }
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar7 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
    }
  }
  else if (cStack_11 == '\0') {
    FUN_00562c90(&iStack_30,piVar13);
    uStack_8 = 5;
    if (iStack_30 != 0) {
      cStack_12 = '\0';
      uStack_4c = *(code **)(*(int *)pcVar14 + 0xec);
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[1] = piStack_2c[1] + 1;
        UNLOCK();
      }
      (*uStack_4c)(iStack_30,piStack_2c,&cStack_12,&cStack_11);
      if (cStack_12 != '\0') {
        *(undefined *)(iStack_30 + 0x4ca) = 1;
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar7 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    goto LAB_006c00ce;
  }
  cStack_22 = '\0';
  iStack_30 = 0;
  pcStack_3c = (code *)0x0;
  piStack_2c = (int *)0x0;
  uStack_8 = 8;
  if (uStack_19 == (code)0x0) {
    if (cStack_11 == '\0') {
      uStack_19 = pcVar14[0x1db8];
      iStack_44 = 0;
      uStack_40 = (code *)0x0;
      uStack_8._0_1_ = 9;
      uStack_8._1_3_ = 0;
      cStack_12 = '\0';
      cStack_21 = '\0';
      if ((((DAT_01d5b840 != '\0') || (DAT_01d5b820 != '\0')) &&
          (cVar6 = (**(code **)(*(int *)pcVar14 + 0xd4))(), cVar6 != '\0')) && (*piStack_18 != 0)) {
        iVar7 = *(int *)(*piStack_18 + 0xc);
        iVar8 = FUN_008aa870();
        if ((uint)*(ushort *)(iVar8 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) {
          iVar7 = FUN_006bf290();
        }
        else {
          iVar8 = *piStack_18;
          iVar4 = *(int *)(iVar8 + 0xc);
          iVar9 = FUN_008aa870();
          iVar7 = 0;
          pcVar14 = param_2;
          if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
              (uint)*(ushort *)(iVar9 + 0x1da)) {
            iVar7 = iVar8;
          }
        }
        if ((iVar7 == 0) || (*(char *)(iVar7 + 0x300) == '\0')) {
LAB_006c02d8:
          param_2 = (code *)((uint)param_2 & 0xffffff00);
        }
        else {
          cVar6 = (**(code **)(*(int *)pcVar14 + 0x11c))();
          param_2 = (code *)CONCAT31(param_2._1_3_,1);
          if (cVar6 != '\0') goto LAB_006c02d8;
        }
        piVar13 = piStack_28;
        pcStack_34 = (code *)CONCAT31(pcStack_34._1_3_,iVar7 != 0);
        if (DAT_01d5b840 != '\0') {
          cStack_12 = FUN_006de120(*piStack_28,pcStack_34,param_2);
        }
        if (DAT_01d5b820 != '\0') {
          cStack_21 = FUN_006d9c20(*piVar13,pcStack_34,param_2,*piStack_18);
        }
      }
      piVar13 = piStack_18;
      if ((DAT_01d5b278 != '\0') && (cVar6 = (**(code **)(*(int *)pcVar14 + 0xd4))(), cVar6 != '\0')
         ) {
        *(int *)(*piVar13 + 0x38) = *(int *)(*piVar13 + 0x38) + 1;
        FUN_006d7df0(piVar13);
      }
      if (((DAT_01d5b840 == '\0') || (cStack_12 == '\0')) ||
         (cVar6 = FUN_00620ea0(*piVar13), cVar6 == '\0')) {
        uVar16 = 0;
      }
      else {
        uVar16 = 1;
      }
      piVar13 = piStack_28;
      param_2 = *(code **)(iStack_20 + 0x2c);
      if (*(int *)(iStack_20 + 0x3c) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(iStack_20 + 0x3c) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00617d00(param_2,*piStack_28,*(undefined4 *)(iStack_20 + 0x3c),1,1,1,&iStack_44,uVar16);
      if ((DAT_01d5b820 != '\0') && (cStack_21 != '\0')) {
        FUN_006d9060();
        uVar16 = FUN_006d9e30(*piStack_28);
        FUN_006c9080(piStack_28,1,1,uVar16);
        piVar13 = piStack_28;
      }
      if (*piVar13 == *(int *)(pcVar14 + 0x1a18)) {
        pcVar14[0x3802] = (code)0x1;
      }
      cVar6 = (**(code **)(*(int *)pcVar14 + 0x11c))();
      if (cVar6 == '\0') {
        if ((*(uint *)(pcVar14 + 0x3808) & 0x40) == 0) {
          iVar7 = FUN_00676d50(*piStack_18);
        }
        else if ((*piStack_18 == 0) || (iVar7 = FUN_00676d50(*piStack_18), iVar7 == 0))
        goto LAB_006c0479;
        if (((*piStack_18 == iVar7) || (cVar6 = FUN_00620ec0(iVar7), cVar6 != '\0')) &&
           (uStack_19 == (code)0x0)) {
          FUN_006d66a0(pcVar14,piVar13);
        }
      }
LAB_006c0479:
      if (((DAT_01d5b7f8 == '\0') &&
          (cVar6 = (**(code **)(*(int *)pcVar14 + 0xd4))(), cVar6 != '\0')) && (*piStack_18 != 0)) {
        FUN_006e06e0(*piStack_18,*piVar13);
      }
      uVar11 = *(uint *)(pcVar14 + 0x3808);
      uStack_4c = *(code **)(pcVar14 + 0x380c);
      if (((*(uint *)(pcVar14 + 0x380c) & 1) != 0) &&
         (*(int *)(*(int *)(pcVar14 + 0x1db4) + 0x1c) == 0)) {
        FUN_006da7b0(piVar13);
        uStack_4c = *(code **)(pcVar14 + 0x380c);
        uVar11 = *(uint *)(pcVar14 + 0x3808);
      }
      if ((uVar11 & 0x40) == 0) {
LAB_006c0771:
        FUN_00618a10(*piVar13,*piStack_18);
      }
      else {
        if (*(char *)(iStack_20 + 0x49) == '\0') {
          if ((*piStack_18 != 0) && (iVar7 = FUN_008f7870(*piStack_18), iVar7 == 0)) {
            iVar7 = *piStack_18;
            if (*(int *)(iVar7 + 0x34) != 0) {
              iVar7 = FUN_005c8ac0();
            }
            FUN_0061de90(&param_2,iVar7 + 0x18);
            if (param_2 != (code *)0x0) {
              cStack_22 = '\x01';
              FUN_0056ecd0((int)param_2 + 0x10);
              pcStack_3c = (code *)piStack_2c;
            }
          }
          goto LAB_006c0771;
        }
        if (DAT_01ee420e != '\0') {
          puVar10 = (undefined4 *)FUN_009c9510(&iStack_78);
          uStack_8._0_1_ = 10;
          if (0xf < (uint)puVar10[5]) {
            puVar10 = (undefined4 *)*puVar10;
          }
          FUN_016774b0(DAT_01ee420e,"Atomic Replication started for %s",puVar10);
          uStack_8._0_1_ = 9;
          uVar5 = (undefined)uStack_8;
          uStack_8._0_1_ = 9;
          if (0xf < uStack_64) {
            uVar11 = uStack_64 + 1;
            iVar7 = iStack_78;
            if (0xfff < uVar11) {
              iVar7 = *(int *)(iStack_78 + -4);
              uVar11 = uStack_64 + 0x24;
              if (0x1f < (iStack_78 - iVar7) - 4U) {
                uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar7,uVar11);
          }
        }
        uStack_64 = 0;
        uStack_74 = 0;
        iStack_70 = 0;
        uStack_6c = 0;
        uStack_68 = 0;
        FUN_0056ecd0(piVar13);
        uStack_94 = *(undefined4 *)(iStack_20 + 0x1c);
        uStack_90 = *(undefined4 *)(iStack_20 + 0x20);
        param_2 = (code *)&uStack_8c;
        if (iStack_70 != 0) {
          LOCK();
          *(int *)(iStack_70 + 4) = *(int *)(iStack_70 + 4) + 1;
          UNLOCK();
        }
        uStack_8c = uStack_74;
        iStack_88 = iStack_70;
        uStack_8._0_1_ = 0xc;
        FUN_00569460(&uStack_6c);
        uStack_b0 = uStack_94;
        uStack_ac = uStack_90;
        FUN_006bf2d0(&uStack_8c);
        uStack_8._0_1_ = 0xe;
        param_2 = (code *)FUN_009c91f0(&uStack_b0);
        FUN_00607110(&uStack_4c,param_2,&uStack_b0,
                     -(uint)(pcVar14 + (byte)pcVar14[0x1ecc] + 0x1ecd != (code *)0x0) &
                     (uint)(pcVar14 + (byte)pcVar14[0x1ecc] + 0x1ecd + 1));
        if (uStack_4c == (code *)0x0) {
          iStack_50 = 0;
          uStack_4c = (code *)0x0;
          uStack_54 = -(uint)(pcVar14 != (code *)0xffffe131) & (uint)(pcVar14 + 0x1ed0);
          uStack_8._0_1_ = 0xf;
          FUN_006bfc90();
          *(undefined4 *)(iStack_50 + 8) = uStack_b0;
          *(undefined4 *)(iStack_50 + 0xc) = uStack_ac;
          FUN_006bf2d0(auStack_a8);
          uStack_4c._0_2_ = CONCAT11(1,(undefined)uStack_4c);
          FUN_0062b610(*(int *)(pcVar14 + 0x1ed4) + 1);
          FUN_005c5550(&param_2,&uStack_54,param_2);
          FUN_006bf5f0();
        }
        FUN_00611d80();
        FUN_006bf650();
        FUN_0056ecd0(piVar13);
        FUN_00612f30();
        pcStack_3c = (code *)piStack_2c;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      param_2 = uStack_40;
      if (uStack_40 != (code *)0x0) {
        LOCK();
        iVar7 = *(int *)(uStack_40 + 4) + -1;
        *(int *)(uStack_40 + 4) = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (*(code *)**(undefined4 **)uStack_40)();
          LOCK();
          iVar7 = *(int *)(param_2 + 8) + -1;
          *(int *)(param_2 + 8) = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*(int *)param_2 + 4))();
          }
        }
      }
    }
    else if (*(char *)(iStack_20 + 0x48) != '\0') {
      FUN_00631de0(-(uint)(*piVar13 != 0) & *piVar13 + 0x14U);
    }
  }
  if (cStack_11 != '\0') goto LAB_006c0867;
  pcVar12 = *(code **)(iStack_20 + 0x50);
  param_2 = *(code **)(iStack_20 + 0x4c);
  uStack_4c = pcVar12;
  if (param_2 != pcVar12) {
    do {
      if (pcVar14[0x1db8] == (code)0x0) {
        FUN_006e0360(*(undefined4 *)(*piVar13 + 0x18),*(undefined4 *)(*piVar13 + 0x1c),
                     *(int *)param_2,*(int *)(param_2 + 4),*(int *)(param_2 + 8));
        pcVar12 = uStack_4c;
      }
      param_2 = param_2 + 0xc;
    } while (param_2 != pcVar12);
  }
  if ((*(uint *)(pcVar14 + 0x3808) & 0x40) != 0) {
    if (cStack_22 != '\0') {
      pcVar12 = pcVar14 + 0x1ecc;
      param_2 = (code *)(iStack_30 + 0x18);
      pcStack_34 = pcVar12;
      piStack_18 = (int *)FUN_009c91f0(param_2);
      FUN_00607110(&uStack_4c,piStack_18,param_2,
                   -(uint)(pcVar12 + (byte)*pcVar12 + 1 != (code *)0x0) &
                   (uint)(pcVar12 + (byte)*pcVar12 + 1 + 1));
      pcVar12 = uStack_4c;
      if (uStack_4c == (code *)0x0) {
        iStack_44 = 0;
        uStack_40 = (code *)((uint)uStack_40 & 0xffff0000);
        uStack_48 = -(uint)(pcVar14 != (code *)0xffffe131) & (uint)(pcVar14 + 0x1ed0);
        uStack_8._0_1_ = 0x10;
        iVar7 = *(int *)param_2;
        iVar8 = *(int *)(param_2 + 4);
        FUN_006bfc90();
        *(int *)(iStack_44 + 8) = iVar7;
        *(int *)(iStack_44 + 0xc) = iVar8;
        *(undefined4 *)(iStack_44 + 0x14) = 0;
        *(undefined4 *)(iStack_44 + 0x18) = 0;
        *(undefined4 *)(iStack_44 + 0x1c) = 0;
        *(undefined4 *)(iStack_44 + 0x20) = 0;
        *(undefined4 *)(iStack_44 + 0x10) = 0;
        *(undefined4 *)(iStack_44 + 0x14) = 0;
        *(undefined4 *)(iStack_44 + 0x18) = 0;
        *(undefined4 *)(iStack_44 + 0x1c) = 0;
        *(undefined4 *)(iStack_44 + 0x20) = 0;
        uStack_40._0_2_ = CONCAT11(1,(undefined)uStack_40);
        FUN_0062b610(*(int *)(pcStack_34 + 8) + 1);
        puVar10 = (undefined4 *)FUN_005c5550(&param_2,&uStack_48,piStack_18);
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        pcVar12 = (code *)*puVar10;
        FUN_006bf5f0();
        piVar13 = piStack_28;
      }
      piVar1 = *(int **)(pcVar12 + 0x1c);
      if (*(int **)(pcVar12 + 0x20) == piVar1) {
        FUN_005c1970(piVar1,piVar13);
      }
      else {
        *piVar1 = 0;
        piVar1[1] = 0;
        if (*(int *)(iStack_20 + 0x3c) != 0) {
          LOCK();
          piVar2 = (int *)(*(int *)(iStack_20 + 0x3c) + 4);
          *piVar2 = *piVar2 + 1;
          UNLOCK();
        }
        *piVar1 = *piVar13;
        piVar1[1] = *(int *)(iStack_20 + 0x3c);
        *(int *)(pcVar12 + 0x1c) = *(int *)(pcVar12 + 0x1c) + 8;
      }
      goto LAB_006c0867;
    }
    if (*(char *)(iStack_20 + 0x49) != '\0') goto LAB_006c0867;
  }
  if (*(int *)(iStack_20 + 0x3c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iStack_20 + 0x3c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_006c15e0(pcVar14,*piVar13,*(undefined4 *)(iStack_20 + 0x3c));
LAB_006c0867:
  pcVar14 = pcStack_3c;
  if (pcStack_3c != (code *)0x0) {
    LOCK();
    iVar7 = *(int *)((int)pcStack_3c + 4) + -1;
    *(int *)((int)pcStack_3c + 4) = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (*(code *)**(undefined4 **)pcStack_3c)();
      LOCK();
      piVar13 = (int *)((int)pcVar14 + 8);
      iVar7 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*(int *)pcVar14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8953 ; VA 0x006c0a70 ; FUN_006c0a70 */

undefined4 __thiscall FUN_006c0a70(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined auStack_54 [24];
  undefined auStack_3c [24];
  undefined auStack_24 [12];
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (DAT_01d59fb8 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00628370(*(undefined4 *)(*(int *)(param_1 + 0x10) + 0xc),*(undefined4 *)(param_1 + 0xc));
  }
  if ((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 0x18) != 0)) {
    cVar3 = *(char *)(param_2 + 0x1db8);
    iVar6 = FUN_00676d50(*(int *)(param_1 + 0x18));
    if (((*(int *)(param_1 + 0x18) == iVar6) || (cVar5 = FUN_00620ec0(iVar6), cVar5 != '\0')) &&
       (cVar3 == '\0')) {
      FUN_006d66a0(param_2,param_1 + 0x10);
    }
    iVar6 = param_2 + 0x1ecd + (uint)*(byte *)(param_2 + 0x1ecc);
    uVar7 = FUN_009c91f0(param_1 + 0x20);
    FUN_00607110(&piStack_18,uVar7,param_1 + 0x20,-(uint)(iVar6 != 0) & iVar6 + 1U);
    piVar2 = piStack_18;
    if (piStack_18 == (int *)0x0) {
      uVar7 = FUN_009c93d0(auStack_54,4);
      uStack_8 = 0;
      FUN_00558d90(auStack_3c,"Deferred Replication Root not found ",uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      uVar7 = FUN_005543f0(6);
      FUN_0086edd0(3,uVar7);
      FUN_005500e0(auStack_3c);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    FUN_00618a10(*(undefined4 *)(uStack_14 + 0x10),*(undefined4 *)(uStack_14 + 0x18));
    if (piVar2[5] != 0) {
      LOCK();
      piVar1 = (int *)(piVar2[5] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_006c1550(param_2,piVar2[4],piVar2[5]);
    puVar4 = (undefined4 *)piVar2[7];
    puVar9 = (undefined4 *)piVar2[6];
    for (; puVar9 != puVar4; puVar9 = puVar9 + 2) {
      if (puVar9[1] != 0) {
        LOCK();
        piVar2 = (int *)(puVar9[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_006c1550(param_2,*puVar9,puVar9[1]);
      piVar2 = piStack_18;
    }
    piStack_18 = (int *)*piVar2;
    uStack_14 = (uint)piVar2[1] % *(uint *)(param_2 + 0x1ed0);
    piVar1 = *(int **)(*(int *)(param_2 + 0x1ee0) + uStack_14 * 4);
    for (piVar10 = (int *)*piVar1; piVar10 != piVar2; piVar10 = (int *)*piVar10) {
      piVar1 = piVar10;
    }
    do {
      *piVar1 = *piVar10;
      FUN_00577ac0();
      piVar2 = (int *)piVar10[5];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar6 = piVar2[1] + -1;
        piVar2[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar6 = piVar2[2] + -1;
          piVar2[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar10,0x24);
      *(int *)(param_2 + 0x1ed4) = *(int *)(param_2 + 0x1ed4) + -1;
      uVar8 = uStack_14;
      if (*piVar1 == 0) {
LAB_006c0c7b:
        if (*(int **)(*(int *)(param_2 + 0x1ee0) + uStack_14 * 4) == piVar1) {
          *(undefined4 *)(*(int *)(param_2 + 0x1ee0) + uStack_14 * 4) = 0;
        }
      }
      else {
        uVar8 = *(uint *)(*piVar1 + 4) % *(uint *)(param_2 + 0x1ed0);
        if (uStack_14 != uVar8) {
          *(int **)(*(int *)(param_2 + 0x1ee0) + uVar8 * 4) = piVar1;
          goto LAB_006c0c7b;
        }
      }
      piVar10 = (int *)*piVar1;
      uStack_14 = uVar8;
    } while (piVar10 != piStack_18);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8954 ; VA 0x006c0d20 ; FUN_006c0d20 */

int * FUN_006c0d20(int *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined **ppuVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined **ppuVar11;
  undefined auStack_bc [12];
  undefined auStack_b0 [24];
  undefined auStack_98 [12];
  undefined auStack_8c [4];
  undefined auStack_88 [4];
  int *piStack_84;
  undefined auStack_80 [24];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int aiStack_58 [2];
  undefined auStack_50 [4];
  undefined *puStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7a01;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_28 = (int *)FUN_01674e20(0x58);
  if (piStack_28 == (int *)0x0) {
    piVar8 = (int *)0x0;
  }
  else {
    piStack_28[1] = 2;
    piStack_28[2] = 1;
    piStack_28[3] = 0;
    *piStack_28 = (int)RBX::Network::DeserializedNewInstanceItem::vftable;
    piStack_28[4] = 0;
    piStack_28[5] = 0;
    piStack_28[6] = 0;
    piStack_28[7] = -1;
    piStack_28[8] = 0;
    piStack_28[9] = -1;
    piStack_28[10] = 0;
    piStack_28[0xb] = 0;
    piStack_28[0xc] = 0;
    piStack_28[0xd] = 0;
    piStack_28[0xe] = 0;
    piStack_28[0xf] = 0;
    piStack_28[0x10] = 0;
    piStack_28[0x11] = 0;
    *(undefined2 *)(piStack_28 + 0x12) = 0;
    piStack_28[0x13] = 0;
    piStack_28[0x14] = 0;
    piStack_28[0x15] = 0;
    piVar8 = piStack_28;
  }
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_006bf0b0(piVar8,piStack_28);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_006b8fd0(auStack_88,param_3);
  iVar5 = iStack_1c;
  *(undefined4 *)(iStack_1c + 0x1c) = *puVar3;
  *(undefined4 *)(iStack_1c + 0x20) = puVar3[1];
  cVar2 = FUN_006abe60(&uStack_38,2);
  if (cVar2 == '\0') {
    FUN_0054eff0("readFast past end for uint16_t");
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005f8ef0(auStack_80);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_bc,&DAT_01c27108);
  }
  uStack_38 = (uint)(ushort)((ushort)uStack_38 << 8 | (ushort)uStack_38 >> 8);
  iStack_24 = *(int *)(param_2[0x67d] + 0x58);
  if (((uint)((*(int *)(param_2[0x67d] + 0x5c) - iStack_24) / 0x3c) <= uStack_38) ||
     (iStack_24 = iStack_24 + uStack_38 * 0x3c, iStack_24 == 0)) {
    uVar7 = FUN_00615990();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Received invalid class network id for new class item. Read offset=%X bytes",uVar7)
    ;
  }
  *(int *)(iVar5 + 0x2c) = iStack_24;
  piVar8 = *(int **)(iStack_24 + 8);
  piStack_14 = piVar8;
  cVar2 = FUN_00621ac0(iVar5 + 0x1c,iVar5 + 0x38);
  if (cVar2 == '\0') {
    if (piVar8 != (int *)0x0) {
      puVar3 = (undefined4 *)FUN_00892e40(piVar8[1]);
      if (puVar3 == (undefined4 *)0x0) {
        uStack_34 = 0;
        piStack_30 = (int *)0x0;
      }
      else {
        puVar3 = (undefined4 *)(**(code **)*puVar3)(auStack_2c,0);
        piVar8 = piStack_28;
        piStack_30 = (int *)puVar3[1];
        uStack_34 = *puVar3;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          piStack_30[1] = piStack_30[1] + 1;
          UNLOCK();
          piStack_30 = (int *)puVar3[1];
        }
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_28[1] + -1;
          piStack_28[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar1 = piVar8 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      FUN_005587e0(&uStack_34);
      FUN_00550b30();
      piStack_20 = *(int **)(iVar5 + 0x38);
      if (piStack_20 == (int *)0x0) {
        uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Replication: Can\'t create object of type %s",uVar7);
      }
      piVar8 = piStack_20 + 5;
      piStack_14 = (int *)param_2[0x15];
      if (piStack_20[5] != 0) {
        FUN_00631de0(piVar8);
      }
      piStack_28 = piStack_20 + 6;
      piStack_20[6] = *(int *)(iVar5 + 0x1c);
      piStack_20[7] = *(int *)(iVar5 + 0x20);
      if (*piVar8 == 0) {
        piVar8 = piStack_14 + 7;
        piStack_30 = piVar8;
        iVar4 = FUN_016dee6d(piVar8);
        if (iVar4 != 0) {
          FUN_016df3c9(iVar4);
        }
        uStack_8._0_1_ = 6;
        if (piStack_20[5] == 0) {
          puVar3 = (undefined4 *)FUN_0060e0c0(auStack_88,piStack_20);
          uStack_8._0_1_ = 7;
          iVar5 = FUN_006149c0(piStack_28);
          uVar7 = *puVar3;
          uVar9 = puVar3[1];
          *puVar3 = 0;
          puVar3[1] = 0;
          *(undefined4 *)(iVar5 + 8) = uVar7;
          piVar1 = *(int **)(iVar5 + 0xc);
          *(undefined4 *)(iVar5 + 0xc) = uVar9;
          if (piVar1 != (int *)0x0) {
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
          if (piStack_84 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_84[2] + -1;
            piStack_84[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_84 + 4))();
            }
          }
          if (piStack_14 != (int *)0x0) {
            LOCK();
            *piStack_14 = *piStack_14 + 1;
            UNLOCK();
          }
          piStack_28 = (int *)piStack_20[5];
          piStack_20[5] = (int)piStack_14;
          FUN_00611620();
          iVar5 = iStack_1c;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        iVar4 = FUN_016deec8(piVar8);
        if (iVar4 != 0) {
          FUN_016df3c9(iVar4);
        }
        uStack_8 = uStack_8 & 0xffffff00;
      }
      (**(code **)(*piStack_20 + 0x18))();
      *(undefined *)(iVar5 + 0x48) = 1;
    }
  }
  else {
    if (*(int *)(iVar5 + 0x38) == 0) {
      FUN_0054db20();
      FUN_009c93d0(auStack_80,0x20);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("readInstanceNew got a null object (guid %s)",uVar7);
    }
    if (*(int *)(*(int *)(iVar5 + 0x38) + 0xc) != *(int *)(iStack_24 + 8)) {
      FUN_0054db20();
      FUN_009c93d0(auStack_80,4);
      uStack_8._0_1_ = 3;
      uVar7 = FUN_005543f0();
      FUN_0054db20();
      piVar8 = (int *)FUN_0054db20();
      (**(code **)(*piVar8 + 0x10))();
      uVar9 = FUN_005543f0();
      FUN_006b1620(auStack_98,param_2 + 0x1d,1,0x7c);
      uStack_8._0_1_ = 4;
      uVar10 = FUN_005543f0();
      FUN_0054db20();
      FUN_009c93d0(auStack_b0,4);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      uVar7 = FUN_005543f0(uVar10,uVar9,uVar7);
      uVar7 = FUN_005543f0(uVar7);
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Replication: Bad re-binding in deserialize new instance %s-%s << %s, %s-%s",
                   uVar7);
    }
  }
  FUN_006abd90();
  auStack_50[0] = 0;
  piStack_28 = (int *)0xb;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_28);
  ppuVar11 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar11 = ppuVar6;
  }
  puStack_4c = *ppuVar11;
  uStack_48 = 0;
  uStack_44 = 0x3f800000;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_8._0_1_ = 9;
  uVar7 = DAT_01eadc98;
  if (((*(char *)(iVar5 + 0x48) != '\0') && (*(int *)(iVar5 + 0x38) != 0)) &&
     (puVar3 = *(undefined4 **)(*(int *)(*(int *)(iVar5 + 0x38) + 0xc) + 0x1dc),
     uVar7 = DAT_01edf5b0, puVar3 != (undefined4 *)0x0)) {
    uVar7 = *puVar3;
  }
  uVar7 = FUN_01675290(uVar7);
  uStack_8._0_1_ = 10;
  piStack_30 = (int *)uVar7;
  FUN_006c1890(param_2,param_3,2,1,auStack_50,&uStack_68);
  FUN_006c1890(param_2,param_3,1,0,auStack_50,&uStack_68);
  uStack_8._0_1_ = 0xb;
  FUN_01675290(uVar7);
  uStack_8._0_1_ = 9;
  FUN_00627d20(param_3,auStack_50);
  FUN_006b8fd0(aiStack_58,param_3);
  if (((param_2[0xe02] & 0x40U) != 0) && (aiStack_58[0] == -1)) {
    cVar2 = (**(code **)(*param_2 + 0xd4))();
    if (cVar2 != '\0') {
      FUN_0054eff0("Client is trying to start an atomic replication transfer");
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      uVar7 = FUN_005543f0(6);
      FUN_0086edd0(3,uVar7);
      FUN_005500e0(auStack_80);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_8c,&DAT_01c17198);
    }
    *(undefined *)(iVar5 + 0x49) = 1;
  }
  FUN_00621ac0(aiStack_58,(int *)(iVar5 + 0x40));
  if (((*(int *)(iStack_24 + 8) != 0) && (*(int *)(iVar5 + 0x38) != 0)) &&
     ((*(int *)(iVar5 + 0x40) != 0 ||
      ((cVar2 = FUN_0061ef00(), cVar2 != '\0' && (*(char *)(iVar5 + 0x49) != '\0')))))) {
    param_1[1] = (int)piStack_18;
    *param_1 = iVar5;
    FUN_006bf690();
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006bf690();
  piVar8 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8955 ; VA 0x006c13f0 ; FUN_006c13f0 */

void FUN_006c13f0(int *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_44 [24];
  undefined auStack_2c [4];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7a20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = (**(code **)(*param_2 + 0xd4))();
  if (cVar2 == '\0') {
    puVar3 = (undefined4 *)FUN_01674e20(0x28);
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3[1] = 0x13;
      puVar3[2] = 1;
      puVar3[3] = 0;
      *puVar3 = RBX::Network::DeserializedResolveNewInstanceAtomicTreeItem::vftable;
      puVar3[4] = 0;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
      puVar3[8] = 0xffffffff;
      puVar3[9] = 0;
    }
    iStack_18 = 0;
    iStack_14 = 0;
    FUN_006bf140(puVar3,param_2);
    uStack_8 = 1;
    puVar4 = (undefined4 *)FUN_006b8fd0(auStack_28,param_3);
    iVar1 = iStack_18;
    puVar3 = (undefined4 *)(iStack_18 + 0x20);
    *puVar3 = *puVar4;
    *(undefined4 *)(iStack_18 + 0x24) = puVar4[1];
    FUN_006b8fd0(auStack_20,param_3);
    FUN_00621ac0(puVar3,iVar1 + 0x10);
    FUN_00621ac0(auStack_20,iVar1 + 0x18);
    param_1[1] = iStack_14;
    *param_1 = iVar1;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0054eff0("Replication: Server does not support atomic replication of subtrees");
  uStack_8 = 0;
  uVar5 = FUN_005543f0(6);
  FUN_0086edd0(3,uVar5);
  FUN_005500e0(auStack_44);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 8956 ; VA 0x006c1550 ; FUN_006c1550 */

int FUN_006c1550(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_006c15e0(param_1,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 8957 ; VA 0x006c15e0 ; FUN_006c15e0 */

int FUN_006c15e0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined **ppuVar4;
  int iVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  int *piVar8;
  int iVar9;
  undefined auStack_50 [4];
  undefined *puStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_38;
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7a50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  auStack_50[0] = 0;
  iStack_24 = 0xb;
  ExceptionList = &pvStack_10;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_24);
  ppuVar7 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar4;
  }
  puStack_4c = *ppuVar7;
  iStack_48 = 0;
  uStack_44 = 0x3f800000;
  uStack_40 = 0;
  iStack_3c = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((*(char *)(param_1 + 0x1db8) == '\0') &&
     (cVar3 = FUN_006d9010(param_2,auStack_50), cVar3 != '\0')) {
    if (iStack_48 == 0) {
      piVar8 = (int *)0x0;
    }
    else {
      piVar8 = *(int **)(iStack_3c + (int)puStack_4c * 4);
    }
    piStack_1c = piVar8;
    if (piVar8 != (int *)0x0) {
      do {
        iStack_38 = 0;
        piStack_34 = (int *)0x0;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        iVar9 = *(int *)(param_1 + 0x54);
        iStack_24 = iVar9;
        piStack_1c = piVar8;
        if (piVar8[2] == -1) {
          iVar9 = 0;
          iStack_14 = 0;
          iStack_38 = 0;
          piStack_18 = (int *)0x0;
          piStack_34 = (int *)0x0;
        }
        else {
          piStack_30 = (int *)(iVar9 + 0x1c);
          iVar5 = FUN_016dee6d(piStack_30);
          if (iVar5 != 0) {
            FUN_016df3c9(iVar5);
          }
          iVar9 = iVar9 + 5 + (uint)*(byte *)(iVar9 + 4);
          uStack_8._0_1_ = 3;
          uVar6 = FUN_009c91f0(piVar8 + 2);
          FUN_00607110(&iStack_28,uVar6,piVar8 + 2,-(uint)(iVar9 != 0) & iVar9 + 1U);
          iStack_2c = iStack_28;
          if (iStack_28 == 0) {
            iStack_14 = 0;
            piStack_18 = (int *)0x0;
          }
          else {
            iStack_20 = *(int *)(iStack_28 + 0x14);
            iStack_14 = 0;
            piStack_18 = (int *)0x0;
            if (iStack_20 != 0) {
              iVar9 = *(int *)(iStack_20 + 4);
              while (iVar9 != 0) {
                LOCK();
                iVar5 = *(int *)(iStack_20 + 4);
                if (iVar9 == iVar5) {
                  *(int *)(iStack_20 + 4) = iVar9 + 1;
                  iVar5 = iVar9;
                }
                UNLOCK();
                piVar8 = piStack_1c;
                if (iVar5 == iVar9) {
                  iStack_14 = *(int *)(iStack_28 + 0x10);
                  piStack_18 = *(int **)(iStack_28 + 0x14);
                  break;
                }
                iVar9 = *(int *)(iStack_20 + 4);
              }
            }
          }
          iVar9 = iStack_14;
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          iStack_38 = iStack_14;
          piStack_34 = piStack_18;
          iVar5 = FUN_016deec8(piStack_30);
          if (iVar5 != 0) {
            FUN_016df3c9(iVar5);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
        }
        piStack_30 = (int *)piVar8[4];
        if ((((iVar9 != 0) &&
             (cVar3 = FUN_006e0910(*(undefined4 *)(iVar9 + 0x18),*(undefined4 *)(iVar9 + 0x1c),
                                   *(undefined4 *)(param_2 + 0x18),*(undefined4 *)(param_2 + 0x1c),
                                   piStack_30), cVar3 != '\0')) &&
            (iVar9 = (**(code **)(*piStack_30 + 0x44))(iStack_14), iVar9 != param_2)) &&
           ((int *)piVar8[4] != (int *)0x0)) {
          (**(code **)(*(int *)piVar8[4] + 0x48))(iStack_14,param_2);
        }
        piVar2 = piStack_18;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar9 = piStack_18[1] + -1;
          piStack_18[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar8 = (int *)*piVar8;
      } while (piVar8 != (int *)0x0);
      piStack_1c = (int *)0x0;
    }
  }
  iVar9 = FUN_0061ac80();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar8 = param_3 + 1;
    iVar5 = *piVar8;
    iVar9 = *piVar8;
    *piVar8 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar9 = (**(code **)*param_3)();
      LOCK();
      piVar8 = param_3 + 2;
      iVar5 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar9 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 8958 ; VA 0x006c1890 ; FUN_006c1890 */

void __thiscall
FUN_006c1890(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  undefined8 *puVar2;
  char cVar3;
  ushort uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined2 *puVar8;
  undefined4 uStack_178;
  undefined4 uStack_174;
  int iStack_170;
  undefined auStack_16c [200];
  undefined uStack_a4;
  undefined auStack_a0 [36];
  undefined auStack_7c [36];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined2 uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined2 *puStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined2 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  uint uStack_1c;
  undefined2 *puStack_18;
  char cStack_12;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7a7b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_006abe60(&bStack_11,1);
  if (cVar3 == '\0') {
    FUN_0054eff0("readFast past end for uint8_t");
    uStack_8 = 0;
    FUN_005f8ef0(&puStack_40);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_7c,&DAT_01c27108);
  }
  uVar6 = (uint)*(ushort *)(*(int *)(param_1 + 0x2c) + 2);
  if (bStack_11 != DAT_018db186) {
    do {
      uVar4 = (ushort)bStack_11 + *(short *)(*(int *)(param_1 + 0x2c) + 2);
      uVar7 = (uint)uVar4;
      if ((*(ushort *)(*(int *)(param_1 + 0x2c) + 4) <= uVar4) || (uVar4 < (ushort)uVar6)) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Invalid property id: out of bounds or out of order");
      }
      cStack_12 = *(char *)(param_1 + 0x48);
      if (cStack_12 == '\0') {
        FUN_006bfd10(param_2,param_4,uVar6,uVar7);
        cStack_12 = *(char *)(param_1 + 0x48);
      }
      uStack_1c = uVar7 + 1 & 0xffff;
      iVar1 = *(int *)(*(int *)(param_2 + 0x19f4) + 100);
      if (uVar7 < (uint)((*(int *)(*(int *)(param_2 + 0x19f4) + 0x68) - iVar1) / 0x14)) {
        puVar8 = (undefined2 *)(iVar1 + uVar7 * 0x14);
      }
      else {
        puVar8 = (undefined2 *)0x0;
      }
      puStack_18 = puVar8;
      if ((cStack_12 == '\0') || (*(char *)(puVar8 + 2) == '\x1c')) {
        if ((*(int *)(param_1 + 0x10) == *(int *)(param_1 + 0x14)) &&
           (puStack_20 = (undefined *)
                         ((uint)*(ushort *)(*(int *)(param_1 + 0x2c) + 4) -
                         (uint)*(ushort *)(*(int *)(param_1 + 0x2c) + 2)),
           (undefined *)((*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x10)) / 0xd8) < puStack_20)
           ) {
          if (&DAT_012f684b < puStack_20) {
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          FUN_006bfa60(puStack_20);
        }
        uStack_178 = 0;
        uStack_174 = FUN_00888530();
        iStack_170 = 0;
        uStack_a4 = 0;
        uStack_8 = 1;
        if (*(int *)(param_1 + 0x18) == *(int *)(param_1 + 0x14)) {
          FUN_006bec00(*(int *)(param_1 + 0x14),&uStack_178);
        }
        else {
          FUN_006bf1d0(param_1 + 0x10);
          *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + 0xd8;
        }
        uStack_8 = 2;
        if (iStack_170 != 0) {
          (**(code **)(iStack_170 + 8))(auStack_16c);
        }
        iVar1 = *(int *)(param_1 + 0x14);
        uStack_8 = 0xffffffff;
        *(undefined4 *)(iVar1 + -0xd8) = *(undefined4 *)(puVar8 + 8);
        *(undefined *)(iVar1 + -4) = 0;
        uStack_2c = *puVar8;
        puStack_40 = puVar8 + 2;
        uStack_34 = *(undefined4 *)(param_1 + 0x38);
        uStack_38 = *(undefined4 *)(puStack_18 + 8);
        piStack_30 = &iStack_28;
        iStack_28 = -1;
        uStack_24 = 0;
        piStack_3c = (int *)(iVar1 + -0xd4);
        FUN_00609060(param_3,puStack_40,param_5,&puStack_40,0,param_6,param_7);
        iVar1 = *(int *)(iVar1 + -0xd4);
        iVar5 = FUN_00888530();
        if ((iVar1 == iVar5) && (iStack_28 != -1)) {
          iStack_4c = iStack_28;
          uStack_48 = uStack_24;
          uStack_44 = *(undefined4 *)(puStack_18 + 8);
          puVar2 = *(undefined8 **)(param_1 + 0x50);
          if (*(undefined8 **)(param_1 + 0x54) == puVar2) {
            FUN_006bea10(puVar2,&iStack_4c);
          }
          else {
            *puVar2 = CONCAT44(uStack_24,iStack_28);
            *(undefined4 *)(puVar2 + 1) = uStack_44;
            *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + 0xc;
          }
        }
      }
      else {
        uStack_58 = *(undefined4 *)(param_1 + 0x38);
        uStack_54 = *(undefined4 *)(puVar8 + 8);
        uStack_50 = *puVar8;
        FUN_00607c90(param_3,puVar8 + 2,param_5,&uStack_58,0,param_6,param_7);
      }
      cVar3 = FUN_006abe60(&bStack_11,1);
      if (cVar3 == '\0') {
        FUN_0054eff0("readFast past end for uint8_t");
        uStack_8 = 3;
        FUN_005f8ef0(&puStack_40);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_a0,&DAT_01c27108);
      }
      uVar6 = uStack_1c;
    } while (bStack_11 != DAT_018db186);
  }
  if (*(char *)(param_1 + 0x48) == '\0') {
    FUN_006bfd10(param_2,param_4,uVar6,*(undefined2 *)(*(int *)(param_1 + 0x2c) + 4));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8959 ; VA 0x006c1bf0 ; FUN_006c1bf0 */

void FUN_006c1bf0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5,
                 undefined4 param_6,int param_7,undefined4 param_8,undefined4 param_9)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  ushort uVar4;
  int iVar5;
  undefined4 uStack_14;
  int *piStack_10;
  ushort uStack_c;
  char acStack_8 [4];
  
  uVar4 = *(ushort *)(param_3 + 2);
  if (uVar4 < *(ushort *)(param_3 + 4)) {
    do {
      iVar5 = *(int *)(param_1[0x67d] + 100);
      if ((uint)uVar4 < (uint)((*(int *)(param_1[0x67d] + 0x68) - iVar5) / 0x14)) {
        iVar5 = iVar5 + (uint)uVar4 * 0x14;
      }
      else {
        iVar5 = 0;
      }
      if (param_5 == 0) {
LAB_006c1c73:
        piVar1 = *(int **)(iVar5 + 0x10);
        if (((piVar1 != (int *)0x0) &&
            (cVar2 = (**(code **)(*param_1 + 500))(param_4,piVar1), cVar2 == '\0')) &&
           ((param_7 == 0 || (cVar2 = (**(code **)(*piVar1 + 0x10))(param_4,param_7), cVar2 == '\0')
            ))) {
          acStack_8[0] = (char)uVar4 - *(char *)(param_3 + 2);
          FUN_006ad5e0(acStack_8,1);
          uStack_14 = param_4;
          piStack_10 = piVar1;
          uStack_c = uVar4;
          FUN_0060b720(param_2,iVar5 + 4,param_6,&uStack_14,0,param_8,param_9);
        }
      }
      else {
        cVar2 = *(char *)(iVar5 + 4);
        if (((((cVar2 == '!') || (cVar2 == '\x1c')) || (cVar2 == '\"')) ||
            ((cVar2 == '\x06' || (cVar2 == '/')))) || (iVar3 = 1, cVar2 == '\x03')) {
          iVar3 = 2;
        }
        if (iVar3 == param_5) goto LAB_006c1c73;
      }
      uVar4 = uVar4 + 1;
    } while (uVar4 < *(ushort *)(param_3 + 4));
  }
  param_3 = CONCAT31(param_3._1_3_,DAT_018db186);
  FUN_006ad5e0(&param_3,1);
  return;
}



/* FUNCTION 8960 ; VA 0x006c1d20 ; FUN_006c1d20 */

void __thiscall FUN_006c1d20(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 0x50);
  for (puVar2 = *(undefined4 **)(param_1 + 0x4c); puVar2 != puVar1; puVar2 = puVar2 + 3) {
    if (*(char *)(param_2 + 0x1db8) == '\0') {
      FUN_006e0360(*(undefined4 *)(*(int *)(param_1 + 0x38) + 0x18),
                   *(undefined4 *)(*(int *)(param_1 + 0x38) + 0x1c),*puVar2,puVar2[1],puVar2[2]);
    }
  }
  *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_1 + 0x4c);
  return;
}



/* FUNCTION 8961 ; VA 0x006c1d80 ; FUN_006c1d80 */

void __thiscall FUN_006c1d80(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = *(undefined *)(param_1 + 0x4c);
  uVar3 = *(undefined4 *)(param_1 + 0x30);
  uVar4 = *(undefined4 *)(param_1 + 0x10);
  if (*(int *)(param_1 + 0x38) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x38) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_006c1e20(uVar4,param_2,uVar3,*(undefined4 *)(param_1 + 0x34),*(undefined4 *)(param_1 + 0x38),
               param_1 + 0x44,uVar2,param_1 + 0x3c);
  return;
}



/* FUNCTION 8962 ; VA 0x006c1de0 ; FUN_006c1de0 */

undefined4 __thiscall FUN_006c1de0(int param_1,undefined4 param_2)

{
  FUN_006b2070(param_2,0x13);
  FUN_006b9320(param_2,*(undefined4 *)(param_1 + 0x30));
  FUN_006b92d0(param_2,param_1 + 0x38);
  return 1;
}



/* FUNCTION 8963 ; VA 0x006c1e20 ; FUN_006c1e20 */

undefined4
FUN_006c1e20(int *param_1,int *param_2,ushort *param_3,int param_4,int *param_5,int *param_6,
            char param_7,undefined4 *param_8)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint *puVar6;
  undefined4 *puVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  int aiStack_58 [5];
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7aa8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0061a940(param_4);
  if (cVar1 == '\0') goto LAB_006c2209;
  FUN_006b20a0(param_1,param_2,2);
  iStack_18 = param_2[6];
  FUN_006b9320(param_2,param_4);
  if (*(char *)(param_1[0x7dc] + 0x5b) != '\0') {
    FUN_006b87f0(0);
    iVar3 = (**(code **)(*param_2 + 8))();
    FUN_006b8ae0(0,iVar3 - iStack_18);
  }
  uStack_1c = (uint)*param_3;
  FUN_006a5c10(&uStack_1c,&uStack_14,2);
  FUN_006ad5e0(&uStack_14,2);
  uVar2 = FUN_006287e0(param_4);
  uStack_14 = CONCAT31(uStack_14._1_3_,uVar2);
  FUN_006ad5e0(&uStack_14,1);
  uStack_14 = FUN_0061ec80(*(undefined4 *)(*(int *)(param_3 + 4) + 4));
  iStack_30 = 0;
  iStack_2c = 0;
  iStack_28 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  FUN_006c1bf0(param_1,param_2,param_3,param_4,2,1,uStack_14,&iStack_30,&uStack_40);
  cVar1 = (**(code **)(*param_1 + 0x1f0))(param_4,param_3);
  if (cVar1 == '\0') {
LAB_006c207e:
    FUN_006c1bf0(param_1,param_2,param_3,param_4,1,0,uStack_14,&iStack_30,&uStack_40);
  }
  else {
    piVar10 = (int *)*param_6;
    if (*piVar10 != 1) {
      if (*piVar10 == 0) {
        puVar6 = (uint *)(piVar10 + 1);
        LOCK();
        uVar8 = *puVar6;
        *puVar6 = *puVar6 | 0x80000000;
        UNLOCK();
        if (-1 < (int)uVar8) {
          if (*(int *)*param_6 == 0) {
            FUN_006ab670();
            iStack_20 = *param_6;
            iVar3 = *(int *)(iStack_20 + 0x3c);
            iVar9 = *(int *)(iStack_20 + 0x38);
            if (iVar9 != iVar3) {
              do {
                FUN_0056cd30();
                iVar9 = iVar9 + 4;
              } while (iVar9 != iVar3);
              iVar9 = *(int *)(iStack_20 + 0x38);
            }
            *(int *)(iStack_20 + 0x3c) = iVar9;
            FUN_006c1bf0(param_1,*param_6 + 0x10,param_3,param_4,1,0,uStack_14,*param_6 + 0x38,
                         &uStack_40);
            *(undefined4 *)*param_6 = 1;
          }
          FUN_00556e00();
          uVar4 = (**(code **)(*(int *)(*param_6 + 0x10) + 8))();
          uVar5 = (**(code **)(*(int *)(*param_6 + 0x10) + 4))();
          FUN_006ad5e0(uVar5,uVar4);
          FUN_006bed70(iStack_2c,*(undefined4 *)(*param_6 + 0x38),*(undefined4 *)(*param_6 + 0x3c),
                       param_5);
          goto LAB_006c209b;
        }
      }
      goto LAB_006c207e;
    }
    uVar4 = (**(code **)(piVar10[4] + 8))();
    uVar5 = (**(code **)(*(int *)(*param_6 + 0x10) + 4))();
    FUN_006ad5e0(uVar5,uVar4);
    FUN_006bed70(iStack_2c,*(undefined4 *)(*param_6 + 0x38),*(undefined4 *)(*param_6 + 0x3c),param_5
                );
  }
LAB_006c209b:
  FUN_00632400(param_2,&iStack_30);
  if (((param_1[0xe02] & 0x40U) != 0) && (param_7 != '\0')) {
    param_8 = &uStack_24;
    uStack_24 = 0xffffffff;
    iStack_20 = 0;
  }
  FUN_006b92d0(param_2,param_8);
  if (param_4 == param_1[0x686]) {
    *(undefined *)((int)param_1 + 0x3802) = 1;
  }
  if (DAT_01d59fb8 != '\0') {
    FUN_00628370(*(undefined4 *)(param_3 + 4),
                 (float)((double)(param_2[6] - iStack_18) +
                        (double)(&DAT_018c0d90)[-(param_2[6] - iStack_18 >> 0x1f)]));
  }
  if (DAT_01ee420e != '\0') {
    iVar3 = param_2[6] - iStack_18;
    piVar10 = *(int **)(*(int *)(param_4 + 0xc) + 4);
    if (0xf < (uint)piVar10[5]) {
      piVar10 = (int *)*piVar10;
    }
    puVar7 = (undefined4 *)FUN_008a2380(aiStack_58);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    FUN_01677520(DAT_01ee420e,"NII %s,%s,%d",puVar7,piVar10,iVar3);
    if (0xf < uStack_44) {
      uVar8 = uStack_44 + 1;
      iVar3 = aiStack_58[0];
      if (0xfff < uVar8) {
        iVar3 = *(int *)(aiStack_58[0] + -4);
        uVar8 = uStack_44 + 0x24;
        if (0x1f < (aiStack_58[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar8);
    }
  }
  iVar9 = iStack_2c;
  iVar3 = iStack_30;
  if (iStack_30 != 0) {
    for (; iVar3 != iVar9; iVar3 = iVar3 + 4) {
      FUN_0056cd30();
    }
    uVar8 = iStack_28 - iStack_30 & 0xfffffffc;
    iVar3 = iStack_30;
    if (0xfff < uVar8) {
      iVar3 = *(int *)(iStack_30 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iStack_30 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar8);
    iStack_30 = 0;
    iStack_2c = 0;
    iStack_28 = 0;
  }
LAB_006c2209:
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar10 = param_5 + 2;
      iVar3 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8964 ; VA 0x006c2250 ; FUN_006c2250 */

void __thiscall FUN_006c2250(uint *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  uVar4 = (int)param_3 - (int)param_2 >> 2;
  uVar2 = param_1[1];
  uVar8 = *param_1;
  uVar9 = (int)(param_1[2] - uVar8) >> 2;
  uVar7 = (int)(uVar2 - uVar8) >> 2;
  if (uVar4 <= uVar9) {
    if (uVar4 <= uVar7) {
      FUN_006c2530(param_2,param_3,uVar8);
      uVar2 = param_1[1];
      uVar8 = uVar8 + uVar4 * 4;
      for (uVar4 = uVar8; uVar4 != uVar2; uVar4 = uVar4 + 4) {
        FUN_0056cd30();
      }
      param_1[1] = uVar8;
      return;
    }
    piVar5 = param_2 + uVar7;
    FUN_006c2530(param_2,piVar5,uVar8);
    piVar6 = (int *)param_1[1];
    for (; piVar5 != param_3; piVar5 = piVar5 + 1) {
      iVar3 = *piVar5;
      *piVar6 = iVar3;
      LOCK();
      piVar1 = (int *)(iVar3 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      piVar6 = piVar6 + 1;
    }
    param_1[1] = (uint)piVar6;
    return;
  }
  if (0x3fffffff < uVar4) {
LAB_006c2412:
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = uVar4;
  if ((uVar9 <= 0x3fffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar4)) {
    uVar7 = uVar4;
  }
  if (uVar8 != 0) {
    if (uVar8 != uVar2) {
      do {
        FUN_0056cd30();
        uVar8 = uVar8 + 4;
      } while (uVar8 != uVar2);
      uVar8 = *param_1;
    }
    FUN_0057d270(uVar8,uVar9);
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar7 != 0) {
    if (0x3fffffff < uVar7) goto LAB_006c2412;
    uVar7 = uVar7 * 4;
    if (uVar7 < 0x1000) {
      if (uVar7 == 0) {
        uVar8 = 0;
      }
      else {
        uVar8 = FUN_01674e20(uVar7);
      }
    }
    else {
      uVar8 = uVar7 + 0x23;
      if (uVar8 <= uVar7) {
        uVar8 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar8);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar8 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar8 - 4) = iVar3;
    }
    *param_1 = uVar8;
    param_1[1] = uVar8;
    param_1[2] = *param_1 + uVar7;
  }
  piVar5 = (int *)*param_1;
  if (param_2 != param_3) {
    do {
      iVar3 = *param_2;
      *piVar5 = iVar3;
      LOCK();
      piVar6 = (int *)(iVar3 + 0x28);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      param_2 = param_2 + 1;
      piVar5 = piVar5 + 1;
    } while (param_2 != param_3);
  }
  param_1[1] = (uint)piVar5;
  return;
}



/* FUNCTION 8965 ; VA 0x006c2420 ; FUN_006c2420 */

int FUN_006c2420(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = FUN_00616d10(param_1,param_2);
  *(undefined4 *)(iVar2 + 8) = 0;
  *(undefined4 *)(iVar2 + 0xc) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 8) = *param_3;
  *(undefined4 *)(iVar2 + 0xc) = param_3[1];
  *(undefined4 *)(iVar2 + 0x10) = param_3[2];
  *(undefined4 *)(iVar2 + 0x14) = param_3[3];
  *(undefined4 *)(iVar2 + 0x18) = param_3[4];
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  *(undefined4 *)(iVar2 + 0x20) = 0;
  if (param_3[6] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[6] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x1c) = param_3[5];
  *(undefined4 *)(iVar2 + 0x20) = param_3[6];
  return iVar2;
}



/* FUNCTION 8966 ; VA 0x006c24a0 ; FUN_006c24a0 */

undefined4
FUN_006c24a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 param_5,undefined4 *param_6)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  uVar6 = FUN_00616d10(param_1,param_2);
  uVar2 = param_4[1];
  uVar3 = *param_4;
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = *param_6;
  uVar5 = param_6[1];
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_006c2ae0(*param_3,param_3[1],uVar3,uVar2,param_5,uVar4,uVar5);
  return uVar6;
}



/* FUNCTION 8967 ; VA 0x006c2530 ; FUN_006c2530 */

int * FUN_006c2530(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    param_1 = param_1 - (int)param_3;
    do {
      iVar2 = *(int *)(param_1 + (int)param_3);
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      *param_3 = iVar2;
      FUN_0056cd30();
      param_3 = param_3 + 1;
    } while (param_1 + (int)param_3 != param_2);
  }
  return param_3;
}



/* FUNCTION 8968 ; VA 0x006c2580 ; FUN_006c2580 */

int __thiscall
FUN_006c2580(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined4 *puVar12;
  
  iVar6 = *param_1;
  iVar11 = (int)param_2 - iVar6 >> 3;
  iVar2 = param_1[1] - iVar6 >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar7 = param_1[2] - iVar6 >> 3;
  uVar4 = uVar3;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  uVar7 = uVar4 * 8;
  if (uVar4 < 0x20000000) {
    if (0xfff < uVar7) goto LAB_006c25f2;
    if (uVar7 == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006c25f2:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_006c270d;
    puVar9 = (undefined4 *)(iVar6 + 0x23U & 0xffffffe0);
    puVar9[-1] = iVar6;
  }
  puVar1 = puVar9 + iVar11 * 2;
  *puVar1 = *param_3;
  puVar1[1] = *param_4;
  puVar12 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar10 = puVar9;
  if (param_2 == puVar12) {
    for (; puVar8 != puVar12; puVar8 = puVar8 + 2) {
      *puVar10 = *puVar8;
      puVar10[1] = puVar8[1];
      puVar10 = puVar10 + 2;
    }
  }
  else {
    if (puVar8 != param_2) {
      do {
        *puVar10 = *puVar8;
        puVar12 = puVar8 + 1;
        puVar8 = puVar8 + 2;
        puVar10[1] = *puVar12;
        puVar10 = puVar10 + 2;
      } while (puVar8 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      do {
        puVar1[2] = *param_2;
        puVar8 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar1[3] = *puVar8;
        puVar1 = puVar1 + 2;
      } while (param_2 != puVar12);
    }
  }
  iVar6 = *param_1;
  if (iVar6 != 0) {
    uVar7 = param_1[2] - iVar6 & 0xfffffff8;
    iVar2 = iVar6;
    if (0xfff < uVar7) {
      iVar2 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar2) - 4U) {
LAB_006c270d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar7);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)(puVar9 + uVar3 * 2);
  param_1[2] = (int)(puVar9 + uVar4 * 2);
  return *param_1 + iVar11 * 8;
}



/* FUNCTION 8969 ; VA 0x006c2720 ; FUN_006c2720 */

void __thiscall FUN_006c2720(int *param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7af1;
  pvStack_10 = ExceptionList;
  puVar7 = (undefined4 *)param_1[1];
  uVar6 = ((int)puVar7 - *param_1) / 0x58;
  uStack_1c = (param_1[2] - *param_1) / 0x58;
  if (param_2 <= uStack_1c) {
    if (uVar6 < param_2) {
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_006c2ec0(puVar7,param_2 - uVar6);
    }
    else {
      if (param_2 == uVar6) {
        return;
      }
      puVar4 = (undefined4 *)(param_2 * 0x58 + *param_1);
      ExceptionList = &pvStack_10;
      for (puVar8 = puVar4; puVar8 != puVar7; puVar8 = puVar8 + 0x16) {
        (**(code **)*puVar8)(0);
      }
    }
    param_1[1] = (int)puVar4;
    ExceptionList = pvStack_10;
    return;
  }
  if (0x2e8ba2e < param_2) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x2e8ba2e - (uStack_1c >> 1) < uStack_1c) {
    uStack_1c = param_2;
  }
  else {
    uStack_1c = (uStack_1c >> 1) + uStack_1c;
    if (uStack_1c < param_2) {
      uStack_1c = param_2;
    }
  }
  uVar5 = uStack_1c * 0x58;
  if (uStack_1c < 0x2e8ba2f) {
    if (0xfff < uVar5) goto LAB_006c27cf;
    if (uVar5 == 0) {
      puVar7 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar7 = (undefined4 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_006c27cf:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006c2a11;
    puVar7 = (undefined4 *)(iVar3 + 0x23U & 0xffffffe0);
    puVar7[-1] = iVar3;
  }
  uStack_8 = 0;
  FUN_006c2ec0(puVar7 + uVar6 * 0x16,param_2 - uVar6);
  iVar3 = param_1[1];
  iVar9 = *param_1;
  puVar8 = puVar7;
  while( true ) {
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iVar9 == iVar3) break;
    *puVar8 = RBX::Network::DeserializedItem::vftable;
    puVar8[1] = *(undefined4 *)(iVar9 + 4);
    puVar8[2] = *(undefined4 *)(iVar9 + 8);
    puVar8[3] = *(undefined4 *)(iVar9 + 0xc);
    uStack_8._0_1_ = 2;
    *puVar8 = RBX::Network::DeserializedNewInstanceItem::vftable;
    FUN_0060eaf0(iVar9 + 0x10);
    puVar8[7] = *(undefined4 *)(iVar9 + 0x1c);
    puVar8[8] = *(undefined4 *)(iVar9 + 0x20);
    puVar8[9] = *(undefined4 *)(iVar9 + 0x24);
    puVar8[10] = *(undefined4 *)(iVar9 + 0x28);
    puVar8[0xb] = *(undefined4 *)(iVar9 + 0x2c);
    puVar8[0xc] = *(undefined4 *)(iVar9 + 0x30);
    puVar8[0xd] = *(undefined4 *)(iVar9 + 0x34);
    puVar8[0xe] = 0;
    puVar8[0xf] = 0;
    if (*(int *)(iVar9 + 0x3c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar9 + 0x3c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar8[0xe] = *(undefined4 *)(iVar9 + 0x38);
    puVar8[0xf] = *(undefined4 *)(iVar9 + 0x3c);
    puVar8[0x10] = 0;
    puVar8[0x11] = 0;
    if (*(int *)(iVar9 + 0x44) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar9 + 0x44) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar8[0x10] = *(undefined4 *)(iVar9 + 0x40);
    puVar8[0x11] = *(undefined4 *)(iVar9 + 0x44);
    *(undefined *)(puVar8 + 0x12) = *(undefined *)(iVar9 + 0x48);
    *(undefined *)((int)puVar8 + 0x49) = *(undefined *)(iVar9 + 0x49);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_0060ea20(iVar9 + 0x4c);
    puVar8 = puVar8 + 0x16;
    iVar9 = iVar9 + 0x58;
  }
  puVar8 = (undefined4 *)*param_1;
  if (puVar8 != (undefined4 *)0x0) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar8 != puVar4) {
      do {
        (**(code **)*puVar8)(0);
        puVar8 = puVar8 + 0x16;
      } while (puVar8 != puVar4);
      puVar8 = (undefined4 *)*param_1;
    }
    uVar6 = ((param_1[2] - (int)puVar8) / 0x58) * 0x58;
    puVar4 = puVar8;
    if (0xfff < uVar6) {
      puVar4 = (undefined4 *)puVar8[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)puVar8 + (-4 - (int)puVar4))) {
LAB_006c2a11:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar6);
  }
  *param_1 = (int)puVar7;
  param_1[1] = (int)(puVar7 + param_2 * 0x16);
  param_1[2] = (int)(puVar7 + uStack_1c * 0x16);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8970 ; VA 0x006c2a16 ; Catch_All@006c2a16 */

void Catch_All_006c2a16(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  FUN_00617010(*(undefined4 *)(unaff_EBP + -0x24),*(undefined4 *)(unaff_EBP + -0x1c));
  uVar2 = *(undefined4 *)(unaff_EBP + -0x18);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x28);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0061a4a0(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8971 ; VA 0x006c2a50 ; FUN_006c2a50 */

void __thiscall FUN_006c2a50(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7b00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedJoinDataItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8972 ; VA 0x006c2abe ; Catch_All@006c2abe */

void Catch_All_006c2abe(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8973 ; VA 0x006c2ae0 ; FUN_006c2ae0 */

undefined4 * __thiscall
FUN_006c2ae0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  param_1[4] = param_6;
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  param_1[5] = param_7;
  param_1[6] = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 8974 ; VA 0x006c2bb0 ; FUN_006c2bb0 */

void __fastcall FUN_006c2bb0(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  cVar4 = *(char *)(param_1 + 0x2a);
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::Replicator::JoinDataItem::vftable;
  if (cVar4 != '\0') {
    if (DAT_01d5bc08 != '\0') {
      FUN_0151f6f0(0xffffffff,0,0);
      FUN_0151fb00("JoinSnapShotTime",(double)*(float *)(param_1[4] + 0x3818));
      FUN_0151fb00("instanceWriteTime",(double)(float)param_1[0x14]);
      FUN_0151fa60("instanceWriteInvocation",param_1[0xf]);
      uVar3 = DAT_01eaee98;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("ReplicatorJoinDataItemStats",0x1b);
      FUN_01520d20(auStack_28,uVar3,0);
      FUN_005507b0();
      FUN_0151f7f0();
      cVar4 = *(char *)(param_1 + 0x2a);
    }
    if ((cVar4 != '\0') && (0 < DAT_01eaee9c)) {
      FUN_0151f6f0(0xffffffff,0,0);
      FUN_0151fa60(&DAT_018dd1f4,param_1[0x13]);
      FUN_0151fa60("Total",param_1[0x10]);
      iVar1 = DAT_01eaee9c;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0("ReplicatorJoinDataItemCacheEfficiency",0x25);
      FUN_01520d20(auStack_40,iVar1,0);
      FUN_005507b0();
      FUN_0151f7f0();
    }
  }
  if ((param_1[0x10] != 0) && (DAT_01ee4213 != '\0')) {
    piVar6 = param_1 + 0x24;
    if (0xf < (uint)param_1[0x29]) {
      piVar6 = (int *)*piVar6;
    }
    FUN_01677520(DAT_01ee4213,
                 "~%s handled %zu instances over %u invocations %fms. %u from cache %u bytes sent (%u bytes uncompressed %fms compress time)."
                 ,piVar6,param_1[0x10],param_1[0xf],(double)(float)param_1[0x14],param_1[0x13],
                 param_1[0x11],param_1[0x12],(double)(float)param_1[0x15]);
  }
  uVar8 = param_1[0x29];
  if (0xf < uVar8) {
    iVar1 = param_1[0x24];
    uVar7 = uVar8 + 1;
    iVar5 = iVar1;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar1 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar1 - iVar5) - 4U) goto LAB_006c2eb0;
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  param_1[0x28] = 0;
  param_1[0x29] = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  iVar1 = param_1[0x21];
  if (iVar1 != 0) {
    uVar8 = param_1[0x23] - iVar1 & 0xfffffff8;
    iVar5 = iVar1;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iVar1 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar1 - iVar5) - 4U) {
LAB_006c2eb0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
    param_1[0x21] = 0;
    param_1[0x22] = 0;
    param_1[0x23] = 0;
  }
  FUN_00613200();
  piVar6 = (int *)param_1[0xc];
  piVar9 = (int *)*piVar6;
  *piVar6 = (int)piVar6;
  *(undefined4 *)(param_1[0xc] + 4) = param_1[0xc];
  param_1[0xd] = 0;
  piVar6 = (int *)param_1[0xc];
  if (piVar9 != piVar6) {
    do {
      piVar2 = (int *)*piVar9;
      FUN_006130d0();
      FUN_01674ea0(piVar9,0x24);
      piVar6 = (int *)param_1[0xc];
      piVar9 = piVar2;
    } while (piVar2 != piVar6);
  }
  FUN_01674ea0(piVar6,0x24);
  *param_1 = RBX::Network::Item::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8975 ; VA 0x006c2ec0 ; FUN_006c2ec0 */

int FUN_006c2ec0(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179dbe8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    do {
      FUN_006bf340();
      param_1 = param_1 + 0x58;
      param_2 = param_2 + -1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8976 ; VA 0x006c2f30 ; FUN_006c2f30 */

void __thiscall FUN_006c2f30(int param_1,int *param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined auStack_38 [28];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7b18;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)param_1;
  if (((DAT_01d5b808 == '\0') || (ExceptionList = &pvStack_10, DAT_01d5b7f8 == '\0')) &&
     (ExceptionList = &pvStack_10, DAT_01d5b800 == '\0')) {
    ExceptionList = &pvStack_10;
    FUN_006209c0(*param_2);
  }
  uStack_1c = 0xffffffff;
  uStack_18 = 0;
  iVar2 = *(int *)(*param_2 + 0x34);
  if (iVar2 != 0) {
    uStack_1c = *(undefined4 *)(iVar2 + 0x18);
    uStack_18 = *(undefined4 *)(iVar2 + 0x1c);
  }
  if (DAT_01d5b670 != '\0') {
    iVar2 = *(int *)(param_1 + 0x30);
    puStack_14 = *(undefined4 **)(iVar2 + 4);
    uVar7 = FUN_006c24a0(iVar2,puStack_14,param_2,&uStack_1c,param_3,param_4);
    if (*(int *)(param_1 + 0x34) != 0x71c71c6) {
      *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x34) + 1;
      *(undefined4 *)(iVar2 + 4) = uVar7;
      *puStack_14 = uVar7;
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar7 = *param_4;
  uVar3 = param_4[1];
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_006c2ae0(*param_2,param_2[1],uStack_1c,uStack_18,param_3,uVar7,uVar3);
  puVar6 = puStack_14;
  uStack_8 = 0;
  iVar2 = *(int *)((int)puStack_14 + 0x30);
  puVar4 = *(undefined4 **)(iVar2 + 4);
  uVar7 = FUN_006c2420(iVar2,puVar4,auStack_38);
  iVar5 = *(int *)((int)puVar6 + 0x34);
  if (iVar5 != 0x71c71c6) {
    *(int *)((int)puVar6 + 0x34) = iVar5 + 1;
    *(undefined4 *)(iVar2 + 4) = uVar7;
    *puVar4 = uVar7;
    FUN_006130d0();
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 8977 ; VA 0x006c30d0 ; FUN_006c30d0 */

int * FUN_006c30d0(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  double dVar2;
  double dVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined **ppuVar7;
  int iVar8;
  double *pdVar9;
  undefined **ppuVar10;
  uint uVar11;
  int *piVar12;
  int iVar13;
  undefined auStack_7c [12];
  int iStack_70;
  int iStack_68;
  int iStack_64;
  int iStack_5c;
  undefined auStack_54 [4];
  undefined *puStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  double dStack_3c;
  int iStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7b57;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016827e0(&dStack_3c);
  piStack_28 = (int *)FUN_01674e20(0x1c);
  uStack_8 = 0;
  if (piStack_28 == (int *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00723fd0(0xb);
  }
  uStack_8 = 0xffffffff;
  iStack_34 = 0;
  piStack_30 = (int *)0x0;
  FUN_006c2a50(uVar4,piStack_28);
  uStack_8 = 1;
  iVar5 = FUN_006ace40();
  piVar12 = piStack_30;
  iStack_20 = iVar5;
  if (iVar5 == 0) {
    *param_1 = 0;
    param_1[1] = 0;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_30[1] + -1;
      piStack_30[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar12 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar12 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (*(char *)(*(int *)(param_2 + 0x1f70) + 0x5a) == '\0') {
    iStack_1c = 0;
  }
  else {
    iStack_1c = *(int *)(param_3 + 0x20);
  }
  FUN_006ab530();
  uStack_8._0_1_ = 2;
  FUN_0061a740(param_3,auStack_7c);
  iStack_14 = 0;
  fStack_18 = 0.0;
  if ((*(char *)(*(int *)(param_2 + 0x1f70) + 0x5a) != '\0') || (DAT_01d59fb8 != '\0')) {
    iVar6 = *(int *)(param_3 + 0x20) - iStack_1c;
    iStack_14 = iStack_5c;
    fStack_18 = (float)((double)iVar6 + (double)(&DAT_018c0d90)[-(iVar6 >> 0x1f)]) /
                (float)((double)iStack_64 + (double)(&DAT_018c0d90)[-(iStack_64 >> 0x1f)]);
  }
  piVar12 = (int *)(iStack_34 + 0x10);
  piStack_28 = piVar12;
  FUN_006c2720(iVar5,piVar12);
  auStack_54[0] = 0;
  uStack_24 = 0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_24);
  ppuVar10 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar10 = ppuVar7;
  }
  puStack_50 = *ppuVar10;
  uStack_4c = 0;
  uStack_48 = 0x3f800000;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iVar5 != 0) {
    iVar13 = 0;
    iVar6 = iStack_20;
    do {
      FUN_006c3470(param_2,auStack_7c,*(int *)(iStack_34 + 0x10) + iVar13,auStack_54);
      if ((*(char *)(*(int *)(param_2 + 0x1f70) + 0x5a) != '\0') || (DAT_01d59fb8 != '\0')) {
        *(float *)(*(int *)(iStack_34 + 0x10) + 0xc + iVar13) =
             (float)((double)(iStack_5c - iStack_14) +
                    (double)(&DAT_018c0d90)[-(iStack_5c - iStack_14 >> 0x1f)]) * fStack_18;
        iStack_14 = iStack_5c;
      }
      iVar13 = iVar13 + 0x58;
      iVar6 = iVar6 + -1;
      piVar12 = piStack_28;
      iVar5 = iStack_20;
    } while (iVar6 != 0);
  }
  FUN_00627d20(auStack_7c,auStack_54);
  iVar6 = iStack_34;
  if (*(char *)(*(int *)(param_2 + 0x1f70) + 0x5a) != '\0') {
    iVar13 = piVar12[1];
    dVar2 = (double)(&DAT_018c0d90)[-(iStack_5c - iStack_14 >> 0x1f)];
    dVar3 = (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)];
    for (iVar8 = *piVar12; iVar8 != iVar13; iVar8 = iVar8 + 0x58) {
      *(float *)(iVar8 + 0xc) =
           ((float)((double)(iStack_5c - iStack_14) + dVar2) / (float)((double)iVar5 + dVar3)) *
           fStack_18 + *(float *)(iVar8 + 0xc);
    }
    iVar5 = (*(int *)(param_3 + 0x20) - iStack_1c) + 4;
    *(float *)(iStack_34 + 0xc) = (float)((double)iVar5 + (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)])
    ;
  }
  if (DAT_01eace54 != 0) {
    pdVar9 = (double *)FUN_016827e0(auStack_2c);
    *(float *)(param_2 + 0x3828) =
         (float)((*pdVar9 - dStack_3c) * DAT_018c0d70) + *(float *)(param_2 + 0x3828);
  }
  *param_1 = iVar6;
  param_1[1] = (int)piStack_30;
  FUN_006bf690();
  if (iStack_70 != 0) {
    uVar11 = iStack_68 - iStack_70;
    iVar5 = iStack_70;
    if (0xfff < uVar11) {
      iVar5 = *(int *)(iStack_70 + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iStack_70 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8978 ; VA 0x006c3470 ; FUN_006c3470 */

undefined4 FUN_006c3470(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined auStack_7c [12];
  undefined auStack_70 [24];
  undefined auStack_58 [24];
  undefined auStack_40 [8];
  undefined auStack_38 [8];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7ba0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_006b8fd0(&uStack_28,param_2);
  *(undefined4 *)(param_3 + 0x1c) = *puVar3;
  *(undefined4 *)(param_3 + 0x20) = puVar3[1];
  cVar2 = FUN_006abe60(&uStack_14,2);
  if (cVar2 == '\0') {
    FUN_0054eff0("readFast past end for uint16_t");
    uStack_8 = 0;
    FUN_005f8ef0(auStack_38);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_7c,&DAT_01c27108);
  }
  uStack_14 = (uint)(ushort)((ushort)uStack_14 << 8 | (ushort)uStack_14 >> 8);
  iStack_20 = *(int *)(*(int *)(param_1 + 0x19f4) + 0x58);
  if (((uint)((*(int *)(*(int *)(param_1 + 0x19f4) + 0x5c) - iStack_20) / 0x3c) <= uStack_14) ||
     (iStack_20 = iStack_20 + uStack_14 * 0x3c, iStack_20 == 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Join data contained invalid class network id");
  }
  *(int *)(param_3 + 0x2c) = iStack_20;
  iStack_18 = *(int *)(iStack_20 + 8);
  cVar2 = FUN_00621ac0(param_3 + 0x1c,(int *)(param_3 + 0x38));
  if (cVar2 == '\0') {
    if (iStack_18 != 0) {
      puVar3 = (undefined4 *)FUN_00892e40(*(undefined4 *)(iStack_18 + 4));
      if (puVar3 == (undefined4 *)0x0) {
        uStack_1c = 0;
        iStack_18 = 0;
      }
      else {
        puVar3 = (undefined4 *)(**(code **)*puVar3)(&uStack_28,0);
        iStack_18 = puVar3[1];
        uStack_1c = *puVar3;
        if (iStack_18 != 0) {
          LOCK();
          *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
          UNLOCK();
          iStack_18 = puVar3[1];
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_24[1] + -1;
          piStack_24[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar1 = piStack_24[2] + -1;
            piStack_24[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      FUN_005587e0(&uStack_1c);
      FUN_00550b30();
      if (*(int *)(param_3 + 0x38) == 0) {
        uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Replication: Can\'t create object of type %s",uVar4);
      }
      FUN_006188a0(*(int *)(param_3 + 0x38),param_3 + 0x1c);
      *(undefined *)(param_3 + 0x48) = 1;
    }
  }
  else {
    iVar1 = *(int *)(param_3 + 0x38);
    if (iVar1 == 0) {
      FUN_009c93d0(auStack_38,0x20);
      uStack_8 = 1;
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("read join instance got a null object (guid %s)",uVar4);
    }
    if (*(int *)(iVar1 + 0xc) != *(int *)(iStack_20 + 8)) {
      FUN_009c93d0(auStack_38,4);
      uStack_8 = 2;
      iStack_20 = FUN_005543f0();
      piVar5 = (int *)FUN_0054db20();
      (**(code **)(*piVar5 + 0x10))();
      uVar4 = FUN_005543f0();
      FUN_006b1620(auStack_58,param_1 + 0x74,1,0x7c);
      uStack_8._0_1_ = 3;
      uVar6 = FUN_005543f0();
      FUN_009c93d0(auStack_70,4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uVar7 = FUN_005543f0();
      uVar8 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Replication: Bad re-binding in deserialize new instance %s-%s << %s, %s-%s",
                   uVar8,uVar7,uVar6,uVar4,iStack_20);
    }
  }
  FUN_006abd90();
  uVar4 = DAT_01eadc98;
  if (((*(char *)(param_3 + 0x48) != '\0') && (*(int *)(param_3 + 0x38) != 0)) &&
     (puVar3 = *(undefined4 **)(*(int *)(*(int *)(param_3 + 0x38) + 0xc) + 0x1dc),
     uVar4 = DAT_01edf5b0, puVar3 != (undefined4 *)0x0)) {
    uVar4 = *puVar3;
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 5;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  FUN_006c1890(param_1,param_2,0,0,param_4,&uStack_30);
  uStack_8 = 6;
  FUN_01675290(uVar4);
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_006b8fd0(auStack_40,param_2);
  *(undefined4 *)(param_3 + 0x24) = *puVar3;
  *(undefined4 *)(param_3 + 0x28) = puVar3[1];
  if (*(int *)(iStack_20 + 8) == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00621ac0((undefined4 *)(param_3 + 0x24),param_3 + 0x40);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8979 ; VA 0x006c3800 ; FUN_006c3800 */

bool __thiscall FUN_006c3800(int param_1,int param_2)

{
  *(undefined *)(param_2 + 4) = 1;
  *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 1;
  FUN_006b2070(param_2,0xb);
  FUN_006c3940(param_2);
  return *(int *)(param_1 + 0x34) == 0;
}



/* FUNCTION 8980 ; VA 0x006c3830 ; FUN_006c3830 */

void FUN_006c3830(int param_1,undefined4 param_2,ushort *param_3,uint param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  ushort *puVar3;
  undefined4 uVar4;
  undefined uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  iVar2 = param_1;
  if ((DAT_01eace39 != '\0') && (param_1 != 0)) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar6 = FUN_00af0010();
    if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
         (uint)*(ushort *)(iVar6 + 0x1da)) && (DAT_01eace39 != '\0')) {
      FUN_016774b0(DAT_01eace39,"Wrote join data item for megacluster",0);
    }
  }
  uVar4 = param_4;
  FUN_006b9320(param_4,iVar2);
  puVar3 = param_3;
  param_4 = (uint)*param_3;
  FUN_006a5c10(&param_4,&param_1,2);
  FUN_006ad5e0(&param_1,2);
  uVar5 = FUN_006287e0(iVar2);
  param_1 = CONCAT31(param_1._1_3_,uVar5);
  FUN_006ad5e0(&param_1,1);
  uVar7 = FUN_0061ec80(*(undefined4 *)(*(int *)(puVar3 + 4) + 4));
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  FUN_006c1bf0(*(undefined4 *)(iStack_8 + 0x10),uVar4,puVar3,iVar2,0,0,uVar7,param_5,&uStack_18);
  FUN_006b92d0(uVar4,param_2);
  return;
}



/* FUNCTION 8981 ; VA 0x006c3940 ; FUN_006c3940 */

float __thiscall FUN_006c3940(float param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  uint *puVar6;
  undefined4 *puVar7;
  double *pdVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  float fVar12;
  int iVar13;
  int *piVar14;
  undefined8 uVar15;
  undefined auStack_78 [8];
  undefined4 uStack_70;
  int iStack_6c;
  int iStack_64;
  int iStack_60;
  int iStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  double dStack_44;
  float fStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  undefined auStack_28 [4];
  float fStack_24;
  float fStack_20;
  int iStack_1c;
  float fStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7bc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  fStack_20 = param_1;
  FUN_016827e0();
  piVar5 = (int *)((int)param_1 + 0x5c);
  iStack_2c = *(int *)(param_2 + 0x18);
  FUN_006ab670();
  if (DAT_01d59fb8 != '\0') {
    *(undefined4 *)((int)param_1 + 0x88) = *(undefined4 *)((int)param_1 + 0x84);
  }
  FUN_006ab530();
  fStack_18 = 0.0;
  iStack_1c = 0;
  iStack_50 = 0;
  iStack_4c = 0;
  uStack_48 = 0;
  uStack_8 = 1;
  iVar9 = *(int *)((int)param_1 + 0x34);
  while ((iVar9 != 0 &&
         ((*(float *)((int)param_1 + 0x58) == 0.0 ||
          ((uint)fStack_18 < (uint)*(float *)((int)param_1 + 0x58)))))) {
    iVar9 = **(int **)((int)param_1 + 0x30);
    fVar12 = *(float *)(iVar9 + 8);
    fStack_38 = fVar12;
    cVar2 = FUN_0061a940();
    if (cVar2 == '\0') {
      piVar5 = (int *)**(int **)((int)param_1 + 0x30);
      *(int *)piVar5[1] = *piVar5;
      *(int *)(*piVar5 + 4) = piVar5[1];
      *(int *)((int)param_1 + 0x34) = *(int *)((int)param_1 + 0x34) + -1;
      FUN_006130d0();
      FUN_01674ea0(piVar5);
LAB_006c3a15:
      piVar5 = (int *)((int)param_1 + 0x5c);
    }
    else {
      iStack_30 = *(int *)((int)param_1 + 0x74);
      if (*(int *)((int)fVar12 + 0x34) == 0) {
LAB_006c3a47:
        cStack_11 = '\0';
      }
      else {
        cVar2 = FUN_009c8f50();
        cStack_11 = '\x01';
        if (cVar2 == '\0') goto LAB_006c3a47;
      }
      cVar2 = (**(code **)(**(int **)((int)param_1 + 0x10) + 0x1f0))
                        (fVar12,*(undefined4 *)(iVar9 + 0x18));
      if ((cVar2 == '\0') || (cStack_11 == '\0')) {
LAB_006c3b7e:
        FUN_006c3830(fVar12,iVar9 + 0x10,*(undefined4 *)(iVar9 + 0x18),(int)param_1 + 0x5c,
                     &iStack_50);
      }
      else {
        piVar5 = *(int **)(iVar9 + 0x1c);
        if (*piVar5 != 1) {
          if (*piVar5 == 0) {
            puVar6 = (uint *)(piVar5 + 1);
            LOCK();
            uVar10 = *puVar6;
            *puVar6 = *puVar6 | 0x80000000;
            UNLOCK();
            if (-1 < (int)uVar10) {
              piVar5 = *(int **)(iVar9 + 0x1c);
              if (*piVar5 == 0) {
                FUN_006ab670();
                FUN_006bfc60();
                FUN_006c3830(fVar12,iVar9 + 0x10,*(undefined4 *)(iVar9 + 0x18),
                             *(int *)(iVar9 + 0x1c) + 0x10,*(int *)(iVar9 + 0x1c) + 0x38);
                **(undefined4 **)(iVar9 + 0x1c) = 1;
                piVar5 = *(int **)(iVar9 + 0x1c);
              }
              puVar6 = (uint *)(piVar5 + 1);
              LOCK();
              uVar10 = *puVar6;
              *puVar6 = *puVar6 + 0x80000000;
              UNLOCK();
              if (((uVar10 & 0x40000000) == 0) && (-0x80000000 < (int)uVar10)) {
                LOCK();
                uVar10 = *puVar6;
                *puVar6 = *puVar6 | 0x40000000;
                UNLOCK();
                if ((uVar10 >> 0x1e & 1) == 0) {
                  FUN_00554e40();
                  SetEvent();
                }
              }
              uVar3 = (**(code **)(*(int *)(*(int *)(iVar9 + 0x1c) + 0x10) + 8))();
              uVar4 = (**(code **)(*(int *)(*(int *)(iVar9 + 0x1c) + 0x10) + 4))();
              FUN_006ad5e0(uVar4,uVar3);
              piVar5 = (int *)(*(int *)(iVar9 + 0x1c) + 0x38);
              if (&iStack_50 != piVar5) {
                FUN_006c2250(*piVar5,*(undefined4 *)(*(int *)(iVar9 + 0x1c) + 0x3c),param_2);
              }
              goto LAB_006c3b95;
            }
          }
          goto LAB_006c3b7e;
        }
        iStack_1c = iStack_1c + 1;
        uVar3 = (**(code **)(piVar5[4] + 8))();
        uVar4 = (**(code **)(*(int *)(*(int *)(iVar9 + 0x1c) + 0x10) + 4))();
        FUN_006ad5e0(uVar4,uVar3);
        piVar5 = (int *)(*(int *)(iVar9 + 0x1c) + 0x38);
        if (&iStack_50 != piVar5) {
          FUN_006c2250(*piVar5,*(undefined4 *)(*(int *)(iVar9 + 0x1c) + 0x3c),param_2);
        }
      }
LAB_006c3b95:
      FUN_00632400(auStack_78,&iStack_50);
      iVar1 = iStack_4c;
      for (iVar13 = iStack_50; iVar13 != iVar1; iVar13 = iVar13 + 4) {
        FUN_0056cd30();
        param_1 = fStack_20;
      }
      iStack_4c = iStack_50;
      if (DAT_01d59fb8 != '\0') {
        iStack_30 = *(int *)((int)param_1 + 0x74) - iStack_30;
        puVar7 = (undefined4 *)(*(int *)(iVar9 + 0x18) + 8);
        puVar11 = *(undefined4 **)((int)param_1 + 0x88);
        if (*(undefined4 **)((int)param_1 + 0x8c) == puVar11) {
          FUN_006c2580(puVar11,puVar7,&iStack_30);
        }
        else {
          *puVar11 = *puVar7;
          puVar11[1] = iStack_30;
          *(int *)((int)param_1 + 0x88) = *(int *)((int)param_1 + 0x88) + 8;
        }
      }
      fStack_18 = (float)((int)fStack_18 + 1);
      piVar5 = (int *)**(int **)((int)param_1 + 0x30);
      *(int *)piVar5[1] = *piVar5;
      *(int *)(*piVar5 + 4) = piVar5[1];
      *(int *)((int)param_1 + 0x34) = *(int *)((int)param_1 + 0x34) + -1;
      FUN_006130d0();
      FUN_01674ea0(piVar5);
      iVar9 = iStack_60;
      if (fStack_38 == *(float *)(*(int *)((int)param_1 + 0x10) + 0x1a18)) {
        *(undefined *)(*(int *)((int)param_1 + 0x10) + 0x3802) = 1;
      }
      if (*(int *)((int)param_1 + 0x38) < 1) goto LAB_006c3a15;
      piVar5 = (int *)((int)param_1 + 0x5c);
      iVar13 = (**(code **)(*(int *)((int)param_1 + 0x5c) + 8))();
      if (((float)DAT_01d5b6e4 / DAT_018ce320) * (float)*(int *)((int)param_1 + 0x38) <=
          (float)((double)(iVar13 + iVar9) + (double)(&DAT_018c0d90)[-(iVar13 + iVar9 >> 0x1f)]))
      break;
    }
    iVar9 = *(int *)((int)param_1 + 0x34);
  }
  fVar12 = fStack_18;
  fStack_38 = fStack_18;
  FUN_006a5c10(&fStack_38,&iStack_30,4);
  FUN_006ad5e0(&iStack_30,4);
  fStack_24 = 0.0;
  fStack_38 = *(float *)(param_2 + 0x18);
  if (fVar12 != 0.0) {
    FUN_006ad5e0(uStack_70,iStack_60);
    puVar11 = &uStack_34;
    FUN_016827e0();
    uVar15 = CONCAT44(puVar11,(uint)DAT_01d5be5c);
    iVar9 = param_2;
    piVar14 = piVar5;
    FUN_00619a10();
    pdVar8 = (double *)FUN_016827e0(auStack_28,piVar14,iVar9,uVar15);
    fStack_24 = (float)((*pdVar8 - (double)CONCAT44(iStack_30,uStack_34)) * DAT_018c0d70);
  }
  *(int *)((int)param_1 + 0x40) = *(int *)((int)param_1 + 0x40) + (int)fVar12;
  *(int *)((int)param_1 + 0x44) =
       *(int *)((int)param_1 + 0x44) + (*(int *)(param_2 + 0x18) - iStack_2c);
  *(int *)((int)param_1 + 0x48) = *(int *)((int)param_1 + 0x48) + *(int *)((int)param_1 + 0x74);
  *(int *)((int)param_1 + 0x4c) = *(int *)((int)param_1 + 0x4c) + iStack_1c;
  pdVar8 = (double *)FUN_016827e0();
  *(float *)((int)param_1 + 0x50) =
       (float)((*pdVar8 - dStack_44) * DAT_018c0d70) + *(float *)((int)param_1 + 0x50);
  *(float *)((int)param_1 + 0x54) = *(float *)((int)param_1 + 0x54) + fStack_24;
  if ((DAT_01d59fb8 != '\0') && (*(int *)((int)param_1 + 0x84) != *(int *)((int)param_1 + 0x88))) {
    iVar9 = *(int *)(param_2 + 0x18) - (int)fStack_38;
    fStack_20 = (float)((double)iVar9 + (double)(&DAT_018c0d90)[-(iVar9 >> 0x1f)]);
    iVar9 = (**(code **)(*piVar5 + 8))();
    puVar11 = *(undefined4 **)((int)param_1 + 0x88);
    puVar7 = *(undefined4 **)((int)param_1 + 0x84);
    fStack_20 = fStack_20 / (float)((double)iVar9 + (double)(&DAT_018c0d90)[-(iVar9 >> 0x1f)]);
    iVar9 = (int)puVar11 - (int)puVar7;
    fStack_38 = ((float)((double)iStack_60 + (double)(&DAT_018c0d90)[-(iStack_60 >> 0x1f)]) *
                fStack_20) /
                (float)((double)(iVar9 >> 3) + (double)(&DAT_018c0d90)[-(iVar9 >> 0x1f)]);
    fVar12 = fStack_18;
    for (; fStack_18 = fVar12, puVar7 != puVar11; puVar7 = puVar7 + 2) {
      FUN_00628370(*puVar7,(float)((double)(int)puVar7[1] +
                                  (double)(&DAT_018c0d90)[-((int)puVar7[1] >> 0x1f)]) * fStack_20 +
                           fStack_38);
      fVar12 = fStack_18;
    }
  }
  if ((fVar12 != 0.0) && (DAT_01ee4213 != '\0')) {
    uVar3 = *(undefined4 *)((int)param_1 + 0x74);
    pdVar8 = (double *)FUN_016827e0();
    puVar11 = (undefined4 *)((int)param_1 + 0x90);
    if (0xf < *(uint *)((int)param_1 + 0xa4)) {
      puVar11 = (undefined4 *)*puVar11;
    }
    FUN_01677520(DAT_01ee4213,
                 "%s Finished writing %u instances %u from cache %u bytes %fms (%u bytes uncompressed %fms compress time)"
                 ,puVar11,fVar12,iStack_1c,*(int *)(param_2 + 0x18) - iStack_2c,
                 (double)(float)((*pdVar8 - dStack_44) * DAT_018c0d70),uVar3,(double)fStack_24);
  }
  FUN_00612dd0();
  if (iStack_6c != 0) {
    uVar10 = iStack_64 - iStack_6c;
    iVar9 = iStack_6c;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iStack_6c + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iStack_6c - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  ExceptionList = pvStack_10;
  return fVar12;
}



/* FUNCTION 8982 ; VA 0x006c3f70 ; FUN_006c3f70 */

void __thiscall FUN_006c3f70(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7bd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::ConcurrentRakPeer>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8983 ; VA 0x006c3fde ; Catch_All@006c3fde */

void Catch_All_006c3fde(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_006c4750(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8984 ; VA 0x006c4000 ; FUN_006c4000 */

int __thiscall FUN_006c4000(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7be0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::PacketReceiveJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8985 ; VA 0x006c40d4 ; Catch_All@006c40d4 */

void Catch_All_006c40d4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8986 ; VA 0x006c40f0 ; FUN_006c40f0 */

int __thiscall FUN_006c40f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7bf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::PeerStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8987 ; VA 0x006c41c2 ; Catch_All@006c41c2 */

void Catch_All_006c41c2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8988 ; VA 0x006c41f0 ; FUN_006c41f0 */

undefined4 * FUN_006c41f0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7c3b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  puVar4 = (undefined4 *)FUN_01674e20(0xa0);
  uStack_8._0_1_ = 2;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    *puVar4 = RBX::Network::PeerStatsItem::vftable;
    puVar4[0x1e] = uVar1;
    puVar4[0x1f] = 0;
    puVar4[0x20] = 0;
    puVar4[0x21] = 0;
    puVar4[0x22] = 0;
    puVar4[0x23] = 0;
    puVar4[0x24] = 0;
    puVar4[0x25] = 0;
    puVar4[0x26] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006c40f0(puVar4,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8989 ; VA 0x006c4340 ; FUN_006c4340 */

undefined4 FUN_006c4340(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7c5c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaef14) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaef14);
    if (DAT_01eaef14 == -1) {
      uStack_8 = 0;
      DAT_01eaef10 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaef14);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaef10;
}



/* FUNCTION 8990 ; VA 0x006c43c0 ; FUN_006c43c0 */

undefined4 * __fastcall FUN_006c43c0(undefined4 *param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7ca7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Network::Peer,class_RBX::Instance>::vftable;
  uVar2 = FUN_005ee090();
  param_1[3] = uVar2;
  uStack_8 = 1;
  FUN_006bcd20();
  uVar1 = DAT_01d5b6b8;
  *param_1 = RBX::Network::Peer::vftable;
  param_1[0x15] = RBX::Network::Peer::vftable;
  *(undefined8 *)(param_1 + 0x18) = uVar1;
  uStack_8._0_1_ = 2;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  *(undefined *)(param_1 + 0x20) = 1;
  *(undefined8 *)(param_1 + 0x1e) = 0;
  FUN_016827a0(param_1 + 0x22);
  *(undefined *)(param_1 + 0x24) = 1;
  *(undefined8 *)(param_1 + 0x26) = uVar1;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  *(undefined *)(param_1 + 0x2e) = 1;
  *(undefined8 *)(param_1 + 0x2c) = 0;
  param_1[0x30] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_016799d0();
  param_1[0x3a] = 0;
  iVar3 = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  do {
    (&DAT_01eaeed0)[iVar3] = (char)iVar3 * '\a' ^ 0xfe;
    iVar3 = iVar3 + 1;
  } while (iVar3 < 0x10);
  param_1[0x34] = 0x24;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8991 ; VA 0x006c4520 ; FUN_006c4520 */

void __fastcall FUN_006c4520(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::Peer::vftable;
  param_1[0x15] = RBX::Network::Peer::vftable;
  if ((undefined4 *)param_1[0x3e] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x3e])(1);
  }
  piVar2 = (int *)param_1[0x3d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x3b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x36];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x33];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006bcd30();
  FUN_0089b230();
  return;
}



/* FUNCTION 8992 ; VA 0x006c4600 ; FUN_006c4600 */

void __fastcall FUN_006c4600(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x98);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x90);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x88);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x80);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x60);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 8993 ; VA 0x006c46fd ; FUN_006c46fd */

void FUN_006c46fd(void)

{
  FUN_006c47e0();
  return;
}



/* FUNCTION 8994 ; VA 0x006c4710 ; FUN_006c4710 */

int __thiscall FUN_006c4710(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 8995 ; VA 0x006c4750 ; FUN_006c4750 */

undefined4 __thiscall FUN_006c4750(undefined4 param_1,byte param_2)

{
  FUN_006af470();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 8996 ; VA 0x006c4780 ; FUN_006c4780 */

int __thiscall FUN_006c4780(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x134);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x140);
  }
  return param_1;
}



/* FUNCTION 8997 ; VA 0x006c47e0 ; FUN_006c47e0 */

undefined4 * __thiscall FUN_006c47e0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::Peer::vftable;
  param_1[0x15] = RBX::Network::Peer::vftable;
  if ((undefined4 *)param_1[0x3e] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x3e])(1);
  }
  piVar2 = (int *)param_1[0x3d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x3b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x36];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x33];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006bcd30();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x100);
  }
  return param_1;
}



/* FUNCTION 8998 ; VA 0x006c48e0 ; FUN_006c48e0 */

undefined4 __thiscall FUN_006c48e0(undefined4 param_1,byte param_2)

{
  FUN_006c4600();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa0);
  }
  return param_1;
}



/* FUNCTION 8999 ; VA 0x006c4910 ; FUN_006c4910 */

void __fastcall FUN_006c4910(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_006af470();
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}


