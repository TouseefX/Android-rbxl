/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 750 ; VA 0x004a9540 ; FUN_004a9540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9540(void)

{
  undefined4 uVar1;
  undefined auStack_390 [864];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8994;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,s_ScriptBatchCommit_021256dc,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02125464 = 0x94;
  iStack_8 = 0;
  _DAT_02125430 =
       RBX::Reflection::
       EventDesc<class_RBX::VersionControlService,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
       ::vftable;
  FUN_0086e3d0(s_scriptGuidTuple_021256cc);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_scriptHashBaseTuple_021256b8);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_scriptTextTuple_021256a8);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_commitMessage_02125698);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_390,&uStack_30,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_02125458 = uStack_1c;
  _DAT_0212545c = uStack_18;
  _DAT_02125460 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_390,0xd8,4,FUN_00688b10);
  _DAT_02125430 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
       ::vftable;
  _DAT_02125468 = 0;
  _DAT_0212546c = 0;
  FUN_016f3654(&LAB_018884d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 751 ; VA 0x004a9710 ; FUN_004a9710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9710(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d89ce;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,s_ScriptChangesSubmitted_02125714,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021254e4 = 0x6c;
  iStack_8 = 0;
  _DAT_021254b0 =
       RBX::Reflection::
       EventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>_RBX::VersionControlService::*>
       ::vftable;
  FUN_0086e3d0(s_scriptGuid_0212563c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_submitted_02125708);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021254d8 = uStack_1c;
  _DAT_021254dc = uStack_18;
  _DAT_021254e0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_021254b0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>_RBX::VersionControlService::*>
       ::vftable;
  _DAT_021254e8 = 0;
  _DAT_021254ec = 0;
  FUN_016f3654(&LAB_018884e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 752 ; VA 0x004a99e0 ; FUN_004a99e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a99e0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8a19;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,s_ScriptSubmitChanges_02125684,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02125424 = 0x8c;
  iStack_8 = 0;
  _DAT_021253f0 =
       RBX::Reflection::
       EventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
       ::vftable;
  FUN_0086e3d0(s_scriptGuid_0212563c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_scriptHashBase_02125674);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_scriptText_02125668);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02125418 = uStack_1c;
  _DAT_0212541c = uStack_18;
  _DAT_02125420 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_021253f0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
       ::vftable;
  _DAT_02125428 = 0;
  _DAT_0212542c = 0;
  FUN_016f3654(&LAB_01888530);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 753 ; VA 0x004a9ca0 ; FUN_004a9ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9ca0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9aba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fb580(uVar2,0);
  FUN_009cb790(uVar1,s_GetBrowserTrackerId_02125bac,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125858 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Stats::StatsService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02125890 = FUN_00a00130;
  _DAT_02125894 = 0;
  _DAT_0212587c = FUN_0088cb40();
  FUN_016f3654(&LAB_01888720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 754 ; VA 0x004a9d40 ; FUN_004a9d40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9d40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9af8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fb580(uVar2,0);
  FUN_009cb820(uVar1,s_GetPaginatedMemoryByTexture_02125b74,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02125788 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Stats::StatsService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(enum_RBX::Stats::TextureQueryType,int,int),3>
       ::vftable;
  _DAT_021257c0 = FUN_00a00310;
  _DAT_021257c4 = 0;
  DAT_021257c8 = 0;
  DAT_021257cc = 0;
  DAT_021257d0 = 0;
  uStack_8 = 3;
  FUN_009ff130(s_queryType_02125b68,s_pageIndex_02125b5c,s_pageSize_02125b50);
  FUN_016f3654(&LAB_01888730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 755 ; VA 0x004a9e10 ; FUN_004a9e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9e10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9b1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fb200(uVar2,0);
  FUN_009cb790(uVar1,s_GetValue_02125ba0,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125818 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Stats::Item,double___cdecl(void),0>::vftable;
  _DAT_02125850 = FUN_005d5820;
  _DAT_02125854 = 0;
  _DAT_0212583c = FUN_0088ca00();
  FUN_016f3654(&LAB_01888780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 756 ; VA 0x004a9eb0 ; FUN_004a9eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9eb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9b3a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fb200(uVar2,0);
  FUN_009cb790(uVar1,s_GetValueString_02125b90,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021257d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Stats::Item,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02125810 = FUN_00a006c0;
  _DAT_02125814 = 0;
  _DAT_021257fc = FUN_0088cb40();
  FUN_016f3654(&LAB_01888790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 757 ; VA 0x004a9f70 ; FUN_004a9f70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9f70(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9b9c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fb580();
  FUN_009cb790(uVar1,s_GetMemoryUsageMbForTag_02125c64,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125ac8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Stats::StatsService,float___cdecl(enum_RBX::Memory::DeveloperTag),1>
       ::vftable;
  _DAT_02125b00 = FUN_00a00280;
  _DAT_02125b04 = 0;
  DAT_02125b08 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02125aec = FUN_0088c960();
  puVar3 = DAT_02125b08;
  if (DAT_02125b08 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_005f31b0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005f37e0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_005f31b0();
  uVar2 = FUN_0086e3d0(&DAT_02125c60);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018888e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 758 ; VA 0x004aa110 ; FUN_004aa110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004aa110(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9bba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009fb580(uVar2,0);
  FUN_009cb790(uVar1,s_GetTotalMemoryUsageMb_02125c7c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125b10 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Stats::StatsService,float___cdecl(void),0>::vftable
  ;
  _DAT_02125b48 = FUN_00a006f0;
  _DAT_02125b4c = 0;
  _DAT_02125b34 = FUN_0088c960();
  FUN_016f3654(&LAB_01888900);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 759 ; VA 0x004ab250 ; FUN_004ab250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ab250(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined *puVar4;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined *puStack_38;
  code *apcStack_30 [6];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de219;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("zh-cjv",6);
  uStack_8 = 0;
  puStack_38 = (undefined *)0x0;
  FUN_00a46630(apcStack_30,apcStack_30,2);
  apcStack_30[0] = FUN_00a3fc90;
  puStack_38 = &DAT_01943011;
  uStack_8 = 1;
  _DAT_01ee7380 = 0;
  DAT_01ee7384 = (int *)0x0;
  DAT_01ee7388 = 0;
  DAT_01ee7384 = (int *)FUN_006a8fb0(0,0);
  _DAT_01ee738c = 0;
  _DAT_01ee7390 = 0;
  _DAT_01ee7394 = 0;
  uStack_8._0_1_ = 3;
  _DAT_01ee7380 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar4 = auStack_50;
  do {
    iVar1 = *DAT_01ee7384;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a36f80(iVar1,puVar2,puVar4);
    if (DAT_01ee7388 == 0x3fffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01ee7388 = DAT_01ee7388 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00a379f0(auStack_18,*DAT_01ee7384 + 8,*DAT_01ee7384);
    puVar4 = puVar4 + 0x38;
  } while (puVar4 != auStack_18);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_50,0x38,1,FUN_008c3170);
  FUN_016f3654(&LAB_018898f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 760 ; VA 0x004ab3d0 ; FUN_004ab3d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ab3d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb970(uVar1,s_AutoTranslateWillRun_021265e4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021261e4 = 0x80;
  _DAT_021261b0 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalizationService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::LocalizationService::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_021261d8 = 0;
  _DAT_021261dc = 0;
  _DAT_021261e0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_021261b0 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalizationService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::LocalizationService::*>
       ::vftable;
  FUN_016f3654(&LAB_01889900);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 761 ; VA 0x004ab4c0 ; FUN_004ab4c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ab4c0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017de269;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80();
  FUN_009cb970(uVar1,s_TextScraperClientMessageWithPlay_02126604,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212621c = 0x84;
  iStack_8 = 0;
  _DAT_021261e8 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalizationService,void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::LocalizationService::*>
       ::vftable;
  FUN_0086e3d0(s_version_021265fc);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02126210 = uStack_1c;
  _DAT_02126214 = uStack_18;
  _DAT_02126218 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_021261e8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LocalizationService,void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::LocalizationService::*>
       ::vftable;
  _DAT_02126220 = 0;
  _DAT_02126224 = 0;
  FUN_016f3654(&LAB_01889910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 762 ; VA 0x004ab670 ; FUN_004ab670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ab670(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de28a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb820(uVar1,s_PromptExportToCSVs_02126484,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125e60 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::LocalizationService,void___cdecl(void),0>::
       vftable;
  _DAT_02125e98 = FUN_00a4a1f0;
  _DAT_02125e9c = 0;
  _DAT_02125e84 = FUN_00888530();
  FUN_016f3654(&LAB_01889920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 763 ; VA 0x004ab710 ; FUN_004ab710 */

void FUN_004ab710(void)

{
  uint in_stack_ffffffe4;
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  uVar1 = in_stack_ffffffe4 & 0xffffff00;
  uStack_8 = 0;
  uVar2 = 0;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a3a8b0(FUN_00a429c0,0,s_GetTableEntries_0212663c,s_instance_02126630,0,0,0,uVar1,0);
  FUN_016f3654(&LAB_01889930,uVar1,uVar2,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 764 ; VA 0x004ab7b0 ; FUN_004ab7b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ab7b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de2aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb790(uVar1,s_GetCorescriptLocalizations_021263f8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125d08 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationService,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02125d40 = FUN_00a42e50;
  _DAT_02125d44 = 0;
  _DAT_02125d2c = FUN_0088cc80();
  FUN_016f3654(&LAB_01889980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 765 ; VA 0x004ab850 ; FUN_004ab850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ab850(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de30c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  FUN_009cb820(uVar2,s_GetCountryRegionForPlayerAsync_0212664c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02126270 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::LocalizationService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
       ::vftable;
  _DAT_021262a8 = FUN_00a42f40;
  _DAT_021262ac = 0;
  DAT_021262b0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02126294 = FUN_0088cb40();
  puVar4 = DAT_021262b0;
  if (DAT_021262b0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01889990);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 766 ; VA 0x004aba20 ; FUN_004aba20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004aba20(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de36c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  FUN_009cb820(uVar2,s_GetTranslatorForLocaleAsync_02126450,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125dd8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::LocalizationService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02125e10 = FUN_00a43ec0;
  _DAT_02125e14 = 0;
  DAT_02125e18 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02125dfc = FUN_0088cdc0();
  iVar1 = DAT_02125e18;
  if (DAT_02125e18 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_locale_02126448);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018899e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 767 ; VA 0x004abbd0 ; FUN_004abbd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004abbd0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de3cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  FUN_009cb790(uVar2,s_GetTranslatorForPlayer_02126414,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125d48 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
       ::vftable;
  _DAT_02125d80 = FUN_00a44090;
  _DAT_02125d84 = 0;
  DAT_02125d88 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02125d6c = FUN_0088cdc0();
  puVar4 = DAT_02125d88;
  if (DAT_02125d88 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01889a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 768 ; VA 0x004abda0 ; FUN_004abda0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004abda0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de42c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  FUN_009cb820(uVar2,s_GetTranslatorForPlayerAsync_0212642c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125d90 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::LocalizationService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
       ::vftable;
  _DAT_02125dc8 = FUN_00a441c0;
  _DAT_02125dcc = 0;
  DAT_02125dd0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02125db4 = FUN_0088cdc0();
  puVar4 = DAT_02125dd0;
  if (DAT_02125dd0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01889a50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 769 ; VA 0x004abf70 ; FUN_004abf70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004abf70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de44a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb820(uVar1,s_PromptImportFromCSVs_0212646c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125e20 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::LocalizationService,void___cdecl(void),0>::
       vftable;
  _DAT_02125e58 = FUN_00a4a3c0;
  _DAT_02125e5c = 0;
  _DAT_02125e44 = FUN_00888530();
  FUN_016f3654(&LAB_01889aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 770 ; VA 0x004ac010 ; FUN_004ac010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ac010(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de4ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  FUN_009cb820(uVar2,s_PromptDownloadGameTableToCSV_021264bc,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125ee0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::LocalizationService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
       ::vftable;
  _DAT_02125f18 = FUN_00a4a090;
  _DAT_02125f1c = 0;
  DAT_02125f20 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02125f04 = FUN_00888530();
  puVar4 = DAT_02125f20;
  if (DAT_02125f20 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_table_021264b4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01889ab0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 771 ; VA 0x004ac1e0 ; FUN_004ac1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ac1e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de4ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb820(uVar1,s_PromptUploadCSVToGameTable_02126498,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125ea0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::LocalizationService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02125ed8 = FUN_00a4a590;
  _DAT_02125edc = 0;
  _DAT_02125ec4 = FUN_0088cdc0();
  FUN_016f3654(&LAB_01889b00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 772 ; VA 0x004ac280 ; FUN_004ac280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ac280(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de52c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  FUN_009cb790(uVar2,s_SetRobloxLocaleId_02126500,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125fa8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02125fe0 = FUN_00a4d020;
  _DAT_02125fe4 = 0;
  DAT_02125fe8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02125fcc = FUN_00888530();
  iVar1 = DAT_02125fe8;
  if (DAT_02125fe8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_locale_02126448);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01889b10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 773 ; VA 0x004ac430 ; FUN_004ac430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ac430(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de54a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb790(uVar1,s_StartTextScraper_021264dc,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125f28 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LocalizationService,void___cdecl(void),0>::vftable;
  _DAT_02125f60 = FUN_00a4da20;
  _DAT_02125f64 = 0;
  _DAT_02125f4c = FUN_00888530();
  FUN_016f3654(&LAB_01889b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 774 ; VA 0x004ac4d0 ; FUN_004ac4d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ac4d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de56a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36d80(uVar2,0);
  FUN_009cb790(uVar1,s_StopTextScraper_021264f0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125f68 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LocalizationService,void___cdecl(void),0>::vftable;
  _DAT_02125fa0 = &LAB_00a4dcc0;
  _DAT_02125fa4 = 0;
  _DAT_02125f8c = FUN_00888530();
  FUN_016f3654(&LAB_01889b40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 775 ; VA 0x004acca0 ; FUN_004acca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004acca0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de5c6;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00a36e80();
  FUN_009cb790(uVar1,s_FormatByKey_02126674,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021262f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TranslatorInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Reflection::Variant_const&),2>
       ::vftable;
  _DAT_02126328 = &LAB_00a3d6e0;
  _DAT_0212632c = 0;
  _DAT_02126330 = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_02126334 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_02126334 = puVar2;
  }
  uStack_8._0_1_ = 5;
  FUN_00a402d0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 7;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(FUN_01889d40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 776 ; VA 0x004ace20 ; FUN_004ace20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ace20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de5ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36e80(uVar2,0);
  FUN_009cb790(uVar1,s_RobloxOnlyTranslate_0212669c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02126380 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TranslatorInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_021263b8 = FUN_00a4dd70;
  _DAT_021263bc = 0;
  DAT_021263c0 = 0;
  _DAT_021263c4 = 0;
  uStack_8 = 2;
  FUN_00a40500();
  FUN_016f3654(&LAB_01889db0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 777 ; VA 0x004acee0 ; FUN_004acee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004acee0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de61e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a36e80(uVar2,0);
  FUN_009cb790(uVar1,s_Translate_02126690,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126338 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TranslatorInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_02126370 = FUN_00a4dd50;
  _DAT_02126374 = 0;
  DAT_02126378 = 0;
  _DAT_0212637c = 0;
  uStack_8 = 2;
  FUN_00a40500();
  FUN_016f3654(&LAB_01889e10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 778 ; VA 0x004ad000 ; FUN_004ad000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad000(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_6c;
  undefined uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 auStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0051;
  pvStack_10 = ExceptionList;
  uStack_6c = 0;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Manifest",8);
  uStack_8 = 0;
  uStack_50 = 1;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  FUN_005542c0("SourceAsset",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_34 = 2;
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = 0;
  FUN_005542c0("LocaleAsset",0xb);
  uStack_8 = 2;
  _DAT_01ee7894 = 0;
  DAT_01ee7898 = (int *)0x0;
  DAT_01ee789c = 0;
  DAT_01ee7898 = (int *)FUN_00616d10(0,0);
  _DAT_01ee78a0 = 0;
  _DAT_01ee78a4 = 0;
  _DAT_01ee78a8 = 0;
  uStack_8._0_1_ = 4;
  _DAT_01ee7894 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar4 = &uStack_6c;
  do {
    iVar1 = *DAT_01ee7898;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a4e720(iVar1,puVar2,puVar4);
    if (DAT_01ee789c == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01ee789c = DAT_01ee789c + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00a4eef0(auStack_18,*DAT_01ee7898 + 8,*DAT_01ee7898);
    puVar4 = puVar4 + 7;
  } while (puVar4 != auStack_18);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_6c,0x1c,3,FUN_0056c780);
  FUN_016f3654(&LAB_01889e70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 779 ; VA 0x004ad2f0 ; FUN_004ad2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad2f0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0c89;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a56630();
  FUN_009cb970(uVar1,s_BadgeAwarded_02126940,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02126894 = 0xdc;
  iStack_8 = 0;
  _DAT_02126860 =
       RBX::Reflection::
       EventDesc<class_RBX::BadgeService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>_RBX::BadgeService::*>
       ::vftable;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_badgeId_021268e0);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02126888 = uStack_1c;
  _DAT_0212688c = uStack_18;
  _DAT_02126890 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02126860 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::BadgeService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>_RBX::BadgeService::*>
       ::vftable;
  _DAT_02126898 = 1;
  _DAT_0212689c = 1;
  FUN_016f3654(&LAB_0188a040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 780 ; VA 0x004ad4a0 ; FUN_004ad4a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad4a0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0cd9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a56630();
  FUN_009cb970(uVar1,s_OnBadgeAwarded_0212695c,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021268d4 = 0xe4;
  iStack_8 = 0;
  _DAT_021268a0 =
       RBX::Reflection::
       EventDesc<class_RBX::BadgeService,void___cdecl(__int64,__int64,__int64),class_rbx::remote_signal<void___cdecl(__int64,__int64,__int64)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,__int64)>_RBX::BadgeService::*>
       ::vftable;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_creatorId_02126950);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_badgeId_021268e0);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021268c8 = uStack_1c;
  _DAT_021268cc = uStack_18;
  _DAT_021268d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_021268a0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::BadgeService,void___cdecl(__int64,__int64,__int64),class_rbx::remote_signal<void___cdecl(__int64,__int64,__int64)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,__int64)>_RBX::BadgeService::*>
       ::vftable;
  _DAT_021268d8 = 1;
  _DAT_021268dc = 1;
  FUN_016f3654(&LAB_0188a050);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 781 ; VA 0x004ad650 ; FUN_004ad650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad650(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0d0e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a56630(uVar2,0);
  FUN_009cb820(uVar1,s_AwardBadge_02126920,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126788 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::BadgeService,bool___cdecl(__int64,__int64),2>
       ::vftable;
  _DAT_021267c0 = FUN_00a59b30;
  _DAT_021267c4 = 0;
  DAT_021267c8 = 0;
  DAT_021267cc = 0;
  uStack_8 = 2;
  FUN_00a5ac40();
  FUN_016f3654(&LAB_0188a060);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 782 ; VA 0x004ad710 ; FUN_004ad710 */

void FUN_004ad710(void)

{
  FUN_00a57e40(FUN_00a5cd30,0,s_IsDisabled_0212692c,s_badgeId_021268e0,0,1,0);
  FUN_016f3654(&LAB_0188a0a0);
  return;
}



/* FUNCTION 783 ; VA 0x004ad770 ; FUN_004ad770 */

void FUN_004ad770(void)

{
  FUN_00a57e40(FUN_00a5cf00,0,s_IsLegal_02126938,s_badgeId_021268e0,0,1,0);
  FUN_016f3654(&LAB_0188a0c0);
  return;
}



/* FUNCTION 784 ; VA 0x004ad7d0 ; FUN_004ad7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad7d0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0d3e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a56630(uVar2,0);
  FUN_009cb820(uVar1,s_UserHasBadge_021268e8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021266b0 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::BadgeService,bool___cdecl(__int64,__int64),2>
       ::vftable;
  _DAT_021266e8 = FUN_00a5d6c0;
  _DAT_021266ec = 0;
  DAT_021266f0 = 0;
  DAT_021266f4 = 0;
  uStack_8 = 2;
  FUN_00a5ac40();
  FUN_016f3654(&LAB_0188a0e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 785 ; VA 0x004ad890 ; FUN_004ad890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad890(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0d9c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a56630();
  FUN_009cb820(uVar1,s_GetBadgeInfoAsync_0212690c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02126740 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::BadgeService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02126778 = FUN_00a5bc50;
  _DAT_0212677c = 0;
  DAT_02126780 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02126764 = FUN_008881d0();
  puVar3 = DAT_02126780;
  if (DAT_02126780 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_badgeId_021268e0);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188a120);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 786 ; VA 0x004ada40 ; FUN_004ada40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ada40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0dce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a56630(uVar2,0);
  FUN_009cb820(uVar1,s_UserHasBadgeAsync_021268f8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021266f8 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::BadgeService,bool___cdecl(__int64,__int64),2>
       ::vftable;
  _DAT_02126730 = FUN_00a5d7f0;
  _DAT_02126734 = 0;
  DAT_02126738 = 0;
  DAT_0212673c = 0;
  uStack_8 = 2;
  FUN_00a5ac40();
  FUN_016f3654(&LAB_0188a140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 787 ; VA 0x004adc30 ; FUN_004adc30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004adc30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e177a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a5e070(uVar2,0);
  FUN_009cb790(uVar1,s_GetCanRedo_02126bf4,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02126b00 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ChangeHistoryService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02126b38 = FUN_00a62010;
  _DAT_02126b3c = 0;
  _DAT_02126b24 = FUN_0088cbe0();
  FUN_016f3654(&LAB_0188a260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 788 ; VA 0x004adcd0 ; FUN_004adcd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004adcd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e179a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a5e070(uVar2,0);
  FUN_009cb790(uVar1,s_GetCanUndo_02126be8,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02126ac0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ChangeHistoryService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02126af8 = FUN_00a62220;
  _DAT_02126afc = 0;
  _DAT_02126ae4 = FUN_0088cbe0();
  FUN_016f3654(&LAB_0188a270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 789 ; VA 0x004add70 ; FUN_004add70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004add70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e17ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a5e070(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02126bd8,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02126a40 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ChangeHistoryService,void___cdecl(void),0>::vftable
  ;
  _DAT_02126a78 = FUN_00a64570;
  _DAT_02126a7c = 0;
  _DAT_02126a64 = FUN_00888530();
  FUN_016f3654(&LAB_0188a280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 790 ; VA 0x004ade10 ; FUN_004ade10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ade10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e17da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a5e070(uVar2,0);
  FUN_009cb790(uVar1,s_ResetWaypoints_02126bc8,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02126a00 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ChangeHistoryService,void___cdecl(void),0>::vftable
  ;
  _DAT_02126a38 = FUN_00a65050;
  _DAT_02126a3c = 0;
  _DAT_02126a24 = FUN_00888530();
  FUN_016f3654(&LAB_0188a290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 791 ; VA 0x004adeb0 ; FUN_004adeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004adeb0(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e183c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a5e070();
  FUN_009cb790(uVar2,s_SetEnabled_02126bb0,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02126970 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ChangeHistoryService,void___cdecl(bool),1>::vftable
  ;
  _DAT_021269a8 = FUN_00a653e0;
  _DAT_021269ac = 0;
  DAT_021269b0 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02126994 = FUN_00888530();
  puVar1 = DAT_021269b0;
  if (DAT_021269b0 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_state_02123f08);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188a2a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 792 ; VA 0x004ae050 ; FUN_004ae050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ae050(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e189c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a5e070();
  FUN_009cb790(uVar2,s_SetWaypoint_02126bbc,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021269b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ChangeHistoryService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_021269f0 = FUN_00a64dc0;
  _DAT_021269f4 = 0;
  DAT_021269f8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021269dc = FUN_00888530();
  iVar1 = DAT_021269f8;
  if (DAT_021269f8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188a2c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 793 ; VA 0x004ae200 ; FUN_004ae200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ae200(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e18ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a5e070(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02126be0,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02126a80 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ChangeHistoryService,void___cdecl(void),0>::vftable
  ;
  _DAT_02126ab8 = FUN_00a65d80;
  _DAT_02126abc = 0;
  _DAT_02126aa4 = FUN_00888530();
  FUN_016f3654(&LAB_0188a2e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 794 ; VA 0x004ae440 ; FUN_004ae440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ae440(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e25aa;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a69c90();
  FUN_00a6ab70(uVar3,"Graphic","Appearance",0);
  uStack_8 = 0;
  DAT_01ee7de4 = RBX::Reflection::BoundProp<class_RBX::TextureId,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_RBX::TextureId,1>::
              BoundPropGetSet<class_RBX::ShirtGraphic>::vftable;
    puVar4[1] = &DAT_01ee7de4;
    puVar4[2] = 0x58;
    puVar4[4] = FUN_00a6bac0;
    puVar4[5] = 0;
  }
  if (DAT_01ee7e18 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_01ee7e18;
    DAT_01ee7e18 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_01ee7e18;
  }
  DAT_01ee7e18 = puVar4;
  cVar2 = (*(code *)DAT_01ee7de4[3])();
  if (cVar2 != '\0') {
    _DAT_01ee7e08 = _DAT_01ee7e08 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_01ee7de4[2])();
  if (cVar2 != '\0') {
    _DAT_01ee7e08 = _DAT_01ee7e08 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 795 ; VA 0x004af080 ; FUN_004af080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004af080(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e25ca;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a69d90();
  FUN_00918d20(uVar3,"SkinColor","Appearance",0);
  uStack_8 = 0;
  DAT_01ee7f6c = RBX::Reflection::BoundProp<class_RBX::BrickColor,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_RBX::BrickColor,1>::BoundPropGetSet<class_RBX::Skin>
              ::vftable;
    puVar4[1] = &DAT_01ee7f6c;
    puVar4[2] = 0x58;
    puVar4[4] = FUN_00a6bac0;
    puVar4[5] = 0;
  }
  if (DAT_01ee7fa0 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_01ee7fa0;
    DAT_01ee7fa0 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_01ee7fa0;
  }
  DAT_01ee7fa0 = puVar4;
  cVar2 = (*(code *)DAT_01ee7f6c[3])();
  if (cVar2 != '\0') {
    _DAT_01ee7f90 = _DAT_01ee7f90 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_01ee7f6c[2])();
  if (cVar2 != '\0') {
    _DAT_01ee7f90 = _DAT_01ee7f90 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 796 ; VA 0x004af210 ; FUN_004af210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004af210(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e266c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LowerTorso",10);
  DAT_01d661d8 = &DAT_01ee819c;
  uStack_8 = 0;
  _DAT_01d661ec = 0;
  _DAT_01d661f0 = 0xf;
  DAT_01d661dc = 0;
  FUN_005542c0("UpperTorso",10);
  _DAT_01d661f4 = &DAT_01ee819c;
  uStack_8._0_1_ = 1;
  _DAT_01d66208 = 0;
  _DAT_01d6620c = 0xf;
  DAT_01d661f8 = 0;
  FUN_005542c0(&DAT_018db5cc,4);
  _DAT_01d66210 = &DAT_01ee80f4;
  uStack_8._0_1_ = 2;
  _DAT_01d66224 = 0;
  _DAT_01d66228 = 0xf;
  DAT_01d66214 = 0;
  FUN_005542c0("RightUpperArm",0xd);
  _DAT_01d6622c = &DAT_01ee8164;
  uStack_8._0_1_ = 3;
  _DAT_01d66240 = 0;
  _DAT_01d66244 = 0xf;
  DAT_01d66230 = 0;
  FUN_005542c0("RightLowerArm",0xd);
  _DAT_01d66248 = &DAT_01ee8164;
  uStack_8._0_1_ = 4;
  _DAT_01d6625c = 0;
  _DAT_01d66260 = 0xf;
  DAT_01d6624c = 0;
  FUN_005542c0("RightHand",9);
  _DAT_01d66264 = &DAT_01ee8164;
  uStack_8._0_1_ = 5;
  _DAT_01d66278 = 0;
  _DAT_01d6627c = 0xf;
  DAT_01d66268 = 0;
  FUN_005542c0("LeftUpperArm",0xc);
  _DAT_01d66280 = &DAT_01ee812c;
  uStack_8._0_1_ = 6;
  _DAT_01d66294 = 0;
  _DAT_01d66298 = 0xf;
  DAT_01d66284 = 0;
  FUN_005542c0("LeftLowerArm",0xc);
  _DAT_01d6629c = &DAT_01ee812c;
  uStack_8._0_1_ = 7;
  _DAT_01d662b0 = 0;
  _DAT_01d662b4 = 0xf;
  DAT_01d662a0 = 0;
  FUN_005542c0("LeftHand",8);
  _DAT_01d662b8 = &DAT_01ee812c;
  uStack_8._0_1_ = 8;
  _DAT_01d662cc = 0;
  _DAT_01d662d0 = 0xf;
  DAT_01d662bc = 0;
  FUN_005542c0("RightUpperLeg",0xd);
  _DAT_01d662d4 = &DAT_01ee820c;
  uStack_8._0_1_ = 9;
  _DAT_01d662e8 = 0;
  _DAT_01d662ec = 0xf;
  DAT_01d662d8 = 0;
  FUN_005542c0("RightLowerLeg",0xd);
  _DAT_01d662f0 = &DAT_01ee820c;
  uStack_8._0_1_ = 10;
  _DAT_01d66304 = 0;
  _DAT_01d66308 = 0xf;
  DAT_01d662f4 = 0;
  FUN_005542c0("RightFoot",9);
  _DAT_01d6630c = &DAT_01ee820c;
  uStack_8._0_1_ = 0xb;
  _DAT_01d66320 = 0;
  _DAT_01d66324 = 0xf;
  DAT_01d66310 = 0;
  FUN_005542c0("LeftUpperLeg",0xc);
  _DAT_01d66328 = &DAT_01ee81d4;
  uStack_8._0_1_ = 0xc;
  _DAT_01d6633c = 0;
  _DAT_01d66340 = 0xf;
  DAT_01d6632c = 0;
  FUN_005542c0("LeftLowerLeg",0xc);
  _DAT_01d66344 = &DAT_01ee81d4;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  _DAT_01d66358 = 0;
  _DAT_01d6635c = 0xf;
  DAT_01d66348 = 0;
  FUN_005542c0("LeftFoot",8);
  _DAT_01d66360 = &DAT_01ee81d4;
  FUN_016f3654(&LAB_0188a5f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 797 ; VA 0x004af6a0 ; FUN_004af6a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004af6a0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("BubbleChatSettingsApi",0x15);
  _DAT_01eeaa1c = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 798 ; VA 0x004af7b0 ; FUN_004af7b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004af7b0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("EnableBubbleChatFromChatService",0x1f);
  _DAT_01eeaa14 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 799 ; VA 0x004afb90 ; FUN_004afb90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004afb90(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3dc9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb970(uVar1,s_Chatted_0211fe04,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02126ef4 = 0x84;
  iStack_8 = 0;
  _DAT_02126ec0 =
       RBX::Reflection::
       EventDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor)>_RBX::ChatService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02123e0c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_color_021270f0);
  FUN_00a8cb50();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02126ee8 = uStack_1c;
  _DAT_02126eec = uStack_18;
  _DAT_02126ef0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02126ec0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor)>_RBX::ChatService::*>
       ::vftable;
  _DAT_02126ef8 = 1;
  _DAT_02126efc = 1;
  FUN_016f3654(&LAB_0188a940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 800 ; VA 0x004afd40 ; FUN_004afd40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004afd40(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3e03;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb970(uVar1,s_BubbleChatSettingsChanged_021272f8,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212706c = 0x8c;
  iStack_8 = 0;
  _DAT_02127038 =
       RBX::Reflection::
       EventDesc<class_RBX::ChatService,void___cdecl(class_RBX::Reflection::Variant),class_rbx::signal<void___cdecl(class_RBX::Reflection::Variant)>,class_rbx::signal<void___cdecl(class_RBX::Reflection::Variant)>_RBX::ChatService::*>
       ::vftable;
  FUN_0086e3d0(s_settings_021272d4);
  FUN_00888410();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02127060 = uStack_1c;
  _DAT_02127064 = uStack_18;
  _DAT_02127068 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02127038 =
       RBX::Reflection::
       EventDesc<class_RBX::ChatService,void___cdecl(class_RBX::Reflection::Variant),class_rbx::signal<void___cdecl(class_RBX::Reflection::Variant)>,class_rbx::signal<void___cdecl(class_RBX::Reflection::Variant)>_RBX::ChatService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188a950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 801 ; VA 0x004afe90 ; FUN_004afe90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004afe90(void)

{
  undefined4 uVar1;
  undefined auStack_390 [864];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3e54;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb970(uVar1,s_ClientToServerReportUnfilteredSi_0212734c,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021270a4 = 0x90;
  iStack_8 = 0;
  _DAT_02127070 =
       RBX::Reflection::
       EventDesc<class_RBX::ChatService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChatService::*>
       ::vftable;
  FUN_0086e3d0(s_unfilteredText_0212733c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_match_02127334);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_instancePath_02127324);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_instanceType_02127314);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_390,&uStack_30,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_02127098 = uStack_1c;
  _DAT_0212709c = uStack_18;
  _DAT_021270a0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_390,0xd8,4,FUN_00688b10);
  _DAT_02127070 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::ChatService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChatService::*>
       ::vftable;
  _DAT_021270a8 = 0;
  _DAT_021270ac = 0;
  FUN_016f3654(&LAB_0188a960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 802 ; VA 0x004b0060 ; FUN_004b0060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0060(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3e99;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb970(uVar1,s_ClientToServerFilterMessageSigna_02127380,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021270e4 = 100;
  iStack_8 = 0;
  _DAT_021270b0 =
       RBX::Reflection::
       EventDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChatService::*>
       ::vftable;
  FUN_0086e3d0(s_sender_02127278);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_receiver_02127374);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_unfilteredMessage_02127264);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021270d8 = uStack_1c;
  _DAT_021270dc = uStack_18;
  _DAT_021270e0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_021270b0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChatService::*>
       ::vftable;
  _DAT_021270e8 = 0;
  _DAT_021270ec = 0;
  FUN_016f3654(&LAB_0188a970);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 803 ; VA 0x004b0210 ; FUN_004b0210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0210(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00a78420(0x58,s_ServerToClientUnderOver13Filtere_02127280,s_sender_02127278,
               s_unfilteredMessage_02127264,s_isError_0212725c,s_errorStr_02127250,
               s_under13_02127248,s_over13_02127240,6,uStack_14,0);
  _DAT_02126f40 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChatService::*>
       ::vftable;
  _DAT_02126f78 = 1;
  _DAT_02126f7c = 0;
  FUN_016f3654(&LAB_0188a980);
  return;
}



/* FUNCTION 804 ; VA 0x004b02a0 ; FUN_004b02a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b02a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3ece;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,0);
  FUN_009cb820(uVar1,s_FilterStringForBroadcast_02127150,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126d10 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ChatService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_02126d48 = FUN_00a845d0;
  _DAT_02126d4c = 0;
  _DAT_02126d50 = 0;
  DAT_02126d54 = 0;
  uStack_8 = 2;
  FUN_00a82680();
  FUN_016f3654(&LAB_0188a990);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 805 ; VA 0x004b0360 ; FUN_004b0360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0360(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3f2c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb820(uVar1,s_CanUserChatAsync_0212719c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02126da0 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::ChatService,bool___cdecl(__int64),1>::vftable;
  _DAT_02126dd8 = FUN_00a7f610;
  _DAT_02126ddc = 0;
  DAT_02126de0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02126dc4 = FUN_0088daf0();
  if (DAT_02126de0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02126de0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_0188a9f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 806 ; VA 0x004b04e0 ; FUN_004b04e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b04e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3f5e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,0);
  FUN_009cb820(uVar1,s_CanUsersChatAsync_021271c8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126de8 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::ChatService,bool___cdecl(__int64,__int64),2>::
       vftable;
  _DAT_02126e20 = FUN_00a7f8c0;
  _DAT_02126e24 = 0;
  DAT_02126e28 = 0;
  DAT_02126e2c = 0;
  uStack_8 = 2;
  FUN_00a828d0();
  FUN_016f3654(&LAB_0188aa10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 807 ; VA 0x004b05a0 ; FUN_004b05a0 */

void FUN_004b05a0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00a78300(FUN_00a7fc50,0,&DAT_02121488,s_partOrCharacter_021270f8,s_message_02119b14,
               s_color_021270f0,0,0,uStack_10,0);
  FUN_016f3654(&LAB_0188aa50);
  return;
}



/* FUNCTION 808 ; VA 0x004b0610 ; FUN_004b0610 */

void FUN_004b0610(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00a78300(FUN_00a80000,0,s_ChatLocal_02127108,s_partOrCharacter_021270f8,s_message_02119b14,
               s_color_021270f0,0,5,uStack_10,0);
  FUN_016f3654(&LAB_0188aa60);
  return;
}



/* FUNCTION 809 ; VA 0x004b0680 ; FUN_004b0680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0680(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3f8e;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02126cc0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,&DAT_02126cc0);
  FUN_009cb820(uVar1,s_FilterStringForPlayerAsync_02127180,0,CONCAT44(puVar3,uVar2),0);
  _DAT_02126d58 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ChatService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_02126d90 = FUN_00a84c70;
  _DAT_02126d94 = 0;
  _DAT_02126d98 = 0;
  DAT_02126d9c = 0;
  uStack_8 = 2;
  FUN_00a82680();
  FUN_016f3654(&LAB_0188aa70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 810 ; VA 0x004b0740 ; FUN_004b0740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0740(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3fc8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,0);
  FUN_009cb820(uVar1,s_FilterStringAsync_0212713c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126cc0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ChatService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),3>
       ::vftable;
  _DAT_02126cf8 = FUN_00a85070;
  _DAT_02126cfc = 0;
  _DAT_02126d00 = 0;
  _DAT_02126d04 = 0;
  _DAT_02126d08 = 0;
  uStack_8 = 3;
  FUN_00a82320(s_stringToFilter_0212712c,s_playerFrom_02127120,s_playerTo_02127114);
  FUN_016f3654(&LAB_0188aad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 811 ; VA 0x004b0810 ; FUN_004b0810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0810(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3fea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,0);
  FUN_009cb790(uVar1,s_GetShouldUseLuaChat_0212722c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02126f00 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ChatService,bool___cdecl(void),0>::vftable;
  _DAT_02126f38 = FUN_00554b40;
  _DAT_02126f3c = 0;
  _DAT_02126f24 = FUN_0088daf0();
  FUN_016f3654(&LAB_0188aae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 812 ; VA 0x004b08b0 ; FUN_004b08b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b08b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e401e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,0);
  FUN_009cb790(uVar1,s_InvokeChatCallback_02127218,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126e78 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ChatService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(enum_RBX::ChatService::ChatCallbackType,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_02126eb0 = FUN_00a89010;
  _DAT_02126eb4 = 0;
  _DAT_02126eb8 = 0;
  _DAT_02126ebc = 0;
  uStack_8 = 2;
  FUN_00a81aa0();
  FUN_016f3654(&LAB_0188aaf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 813 ; VA 0x004b0970 ; FUN_004b0970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0970(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e404e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310(uVar2,0);
  FUN_009cb790(uVar1,s_RegisterChatCallback_021271ec,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02126e30 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ChatService,void___cdecl(enum_RBX::ChatService::ChatCallbackType,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_02126e68 = FUN_00a8b200;
  _DAT_02126e6c = 0;
  DAT_02126e70 = 0;
  DAT_02126e74 = 0;
  uStack_8 = 2;
  FUN_00a82090();
  FUN_016f3654(&LAB_0188ab00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 814 ; VA 0x004b0a30 ; FUN_004b0a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0a30(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e40ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb790(uVar1,s_SetBubbleChatSettings_021272e0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02126ff0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ChatService,void___cdecl(class_RBX::Reflection::Variant),1>::vftable
  ;
  _DAT_02127028 = FUN_00a8c9d0;
  _DAT_0212702c = 0;
  DAT_02127030 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_02127014 = FUN_00888530();
  puVar4 = DAT_02127030;
  if (DAT_02127030 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = *DAT_02127030;
    puStack_ec = (undefined4 *)0x0;
    puVar2 = (undefined4 *)DAT_02127030[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)();
      puVar2 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
    puStack_ec = puVar2;
  }
  uVar1 = FUN_00888410();
  uVar3 = FUN_0086e3d0(s_settings_021272d4);
  FUN_00888b30(uVar3,uVar1,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(FUN_0188ab30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 815 ; VA 0x004b0be0 ; FUN_004b0be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0be0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e40dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a75310();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ChatService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ChatService::*)(void)const_,void_(__thiscall_RBX::ChatService::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00a88570;
    puVar3[3] = 0;
    puVar3[4] = FUN_00a8c9a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_BubbleChatEnabled_021272c0,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,0
              );
  DAT_02126fb8 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02126fec = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02126fdc = _DAT_02126fdc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02126fb8[2])();
    if (cVar1 != '\0') {
      _DAT_02126fdc = _DAT_02126fdc & 0xfffffff3;
    }
  }
  DAT_02126fb8 = RBX::Reflection::PropDescriptor<class_RBX::ChatService,bool>::vftable;
  FUN_016f3654(&LAB_0188ac00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 816 ; VA 0x004b0d10 ; FUN_004b0d10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b0d10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e410c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a75310();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ChatService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ChatService::*)(void)const_,void_(__thiscall_RBX::ChatService::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00a88580;
    puVar3[3] = 0;
    puVar3[4] = FUN_00a8ca70;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_LoadDefaultChat_021272b0,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,7,0);
  DAT_02126f80 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02126fb4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02126fa4 = _DAT_02126fa4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02126f80[2])();
    if (cVar1 != '\0') {
      _DAT_02126fa4 = _DAT_02126fa4 & 0xfffffff3;
    }
  }
  DAT_02126f80 = RBX::Reflection::PropDescriptor<class_RBX::ChatService,bool>::vftable;
  FUN_016f3654(&LAB_0188ac20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 817 ; VA 0x004b0ef0 ; FUN_004b0ef0 */

void FUN_004b0ef0(void)

{
  undefined4 uStack_14;
  
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_00a964d0(0xa96000,0,s_findPartOnRay_021278f8,&DAT_021278e4,
               s_ignoreDescendantsInstance_021278c8,s_terrainCellsAreCubes_021278b0,
               s_ignoreWater_021278a4,0,0,0,0,CONCAT44(&DAT_021273a8,uStack_14),0);
  FUN_016f3654(&LAB_0188ace0);
  return;
}



/* FUNCTION 818 ; VA 0x004b0f90 ; FUN_004b0f90 */

void FUN_004b0f90(void)

{
  undefined4 uStack_14;
  
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_00a966d0(0xa9c380,0,s_findPartsInRegion3_0212799c,s_region_02127980,
               s_ignoreDescendantsInstance_021278c8,s_maxParts_02127974,0x14,0,0,0,
               CONCAT44(&DAT_02127550,uStack_14),0);
  FUN_016f3654(&LAB_0188acf0);
  return;
}



/* FUNCTION 819 ; VA 0x004b1030 ; FUN_004b1030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b1030(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e610e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_ArePartsTouchingOthers_02127afc,0,uStack_1c,0);
  _DAT_02127860 = 0xa97570;
  _DAT_02127828 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,bool___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,float),2>
       ::vftable;
  _DAT_02127868 = 0;
  _DAT_0212786c = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02127870 = (undefined4 *)FUN_01674e20(4);
  if (_DAT_02127870 == (undefined4 *)0x0) {
    _DAT_02127870 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02127870 = 0x3951b717;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a99f10();
  FUN_016f3654(&LAB_0188ad00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 820 ; VA 0x004b1120 ; FUN_004b1120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b1120(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6148;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_BulkMoveTo_02127a7c,0,uStack_1c,0);
  _DAT_02127768 = 0xa976e0;
  _DAT_02127730 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::BulkMoveMode),3>
       ::vftable;
  _DAT_02127770 = 0;
  _DAT_02127774 = 0;
  _DAT_02127778 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  _DAT_0212777c = (undefined4 *)FUN_01674e20(4);
  if (_DAT_0212777c == (undefined4 *)0x0) {
    _DAT_0212777c = (undefined4 *)0x0;
  }
  else {
    *_DAT_0212777c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a99600(s_partList_02127a70,s_cframeList_02127a64,s_eventMode_02127a58);
  FUN_016f3654(&LAB_0188ad10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 821 ; VA 0x004b1220 ; FUN_004b1220 */

void FUN_004b1220(void)

{
  undefined4 uStack_14;
  
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_00a964d0(0xa96000,0,s_FindPartOnRay_021278e8,&DAT_021278e4,
               s_ignoreDescendantsInstance_021278c8,s_terrainCellsAreCubes_021278b0,
               s_ignoreWater_021278a4,0,0,0,0,CONCAT44(&DAT_021273a8,uStack_14),0);
  FUN_016f3654(&LAB_0188ad20);
  return;
}



/* FUNCTION 822 ; VA 0x004b12c0 ; FUN_004b12c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b12c0(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6192;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_FindPartOnRayWithIgnoreList_02127920,0,CONCAT44(&DAT_021273a8,uStack_1c),0);
  _DAT_021274e0 = 0xa95f50;
  _DAT_021274a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_RBX::RbxRay,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,bool,bool),4>
       ::vftable;
  _DAT_021274e8 = 0;
  _DAT_021274ec = 0;
  _DAT_021274f0 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  _DAT_021274f4 = (undefined *)FUN_01674e20(1);
  if (_DAT_021274f4 == (undefined *)0x0) {
    _DAT_021274f4 = (undefined *)0x0;
  }
  else {
    *_DAT_021274f4 = 0;
  }
  uStack_8._0_1_ = 3;
  _DAT_021274f8 = (undefined *)FUN_01674e20(1);
  if (_DAT_021274f8 == (undefined *)0x0) {
    _DAT_021274f8 = (undefined *)0x0;
  }
  else {
    *_DAT_021274f8 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00a980d0(&DAT_021278e4,s_ignoreDescendantsTable_02127908,s_terrainCellsAreCubes_021278b0,
               s_ignoreWater_021278a4);
  FUN_016f3654(&LAB_0188ad30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 823 ; VA 0x004b13e0 ; FUN_004b13e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b13e0(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e61c8;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_FindPartOnRayWithWhitelist_02127958,0,CONCAT44(&DAT_021273a8,uStack_1c),0);
  _DAT_02127538 = 0xa960b0;
  _DAT_02127500 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_RBX::RbxRay,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,bool),3>
       ::vftable;
  _DAT_02127540 = 0;
  _DAT_02127544 = 0;
  _DAT_02127548 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  _DAT_0212754c = (undefined *)FUN_01674e20(1);
  if (_DAT_0212754c == (undefined *)0x0) {
    _DAT_0212754c = (undefined *)0x0;
  }
  else {
    *_DAT_0212754c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a98450(&DAT_021278e4,s_whitelistDescendantsTable_0212793c,s_ignoreWater_021278a4);
  FUN_016f3654(&LAB_0188ad40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 824 ; VA 0x004b14e0 ; FUN_004b14e0 */

void FUN_004b14e0(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00a966d0(0xa9c380,0,s_FindPartsInRegion3_02127988,s_region_02127980,
               s_ignoreDescendantsInstance_021278c8,s_maxParts_02127974,0x14,0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_0188ad50);
  return;
}



/* FUNCTION 825 ; VA 0x004b1580 ; FUN_004b1580 */

void FUN_004b1580(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00a96610(0xa9c4c0,0,s_FindPartsInRegion3WithIgnoreList_021279b0,s_region_02127980,
               s_ignoreDescendantsTable_02127908,s_maxParts_02127974,0x14,0,uStack_10,0);
  FUN_016f3654(&LAB_0188ad60);
  return;
}



/* FUNCTION 826 ; VA 0x004b1610 ; FUN_004b1610 */

void FUN_004b1610(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00a96610(0xa9c590,0,s_FindPartsInRegion3WithWhiteList_021279d4,s_region_02127980,
               s_whitelistDescendantsTable_0212793c,s_maxParts_02127974,0x14,0,uStack_10,0);
  FUN_016f3654(&LAB_0188ad70);
  return;
}



/* FUNCTION 827 ; VA 0x004b16a0 ; FUN_004b16a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b16a0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e621c;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_IKMoveTo_02127ac4,1,uStack_1c,0);
  _DAT_021277b8 = 0xa9d410;
  _DAT_02127780 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame_const&,float,float,enum_RBX::IkDragCollisionsMode),5>
       ::vftable;
  _DAT_021277c0 = 0;
  _DAT_021277c4 = 0;
  _DAT_021277c8 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  _DAT_021277cc = (undefined4 *)FUN_01674e20(4);
  if (_DAT_021277cc == (undefined4 *)0x0) {
    _DAT_021277cc = (undefined4 *)0x0;
  }
  else {
    *_DAT_021277cc = 0x3f000000;
  }
  uStack_8._0_1_ = 3;
  _DAT_021277d0 = (undefined4 *)FUN_01674e20(4);
  if (_DAT_021277d0 == (undefined4 *)0x0) {
    _DAT_021277d0 = (undefined4 *)0x0;
  }
  else {
    *_DAT_021277d0 = 0x3f000000;
  }
  uStack_8._0_1_ = 4;
  _DAT_021277d4 = (undefined4 *)FUN_01674e20(4);
  if (_DAT_021277d4 == (undefined4 *)0x0) {
    _DAT_021277d4 = (undefined4 *)0x0;
  }
  else {
    *_DAT_021277d4 = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00a99980(&DAT_02123e0c,s_target_02127abc,s_translateStiffness_02127aa8,
               s_rotateStiffness_02127a98,s_collisionsMode_02127a88);
  FUN_016f3654(&LAB_0188ad80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 828 ; VA 0x004b17f0 ; FUN_004b17f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b17f0(void)

{
  undefined4 uVar1;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6256;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_IsRegion3Empty_02127a10,0,uStack_24,0);
  _DAT_021276c8 = 0xa9daa0;
  _DAT_02127690 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,bool___cdecl(class_RBX::Region3,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_021276d0 = 0;
  _DAT_021276d4 = 0;
  uStack_8._0_1_ = 2;
  _DAT_021276d8 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_021276d8 == (undefined4 *)0x0) {
    _DAT_021276d8 = (undefined4 *)0x0;
  }
  else {
    *_DAT_021276d8 = 0;
    _DAT_021276d8[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a9a2d0();
  FUN_016f3654(&LAB_0188ad90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 829 ; VA 0x004b18f0 ; FUN_004b18f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b18f0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e627e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_IsRegion3EmptyWithIgnoreList_02127a38,0,uStack_1c,0);
  _DAT_02127718 = 0xa9d950;
  _DAT_021276e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,bool___cdecl(class_RBX::Region3,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),2>
       ::vftable;
  _DAT_02127720 = 0;
  _DAT_02127724 = 0;
  _DAT_02127728 = 0;
  uStack_8 = 2;
  FUN_00a9a0f0();
  FUN_016f3654(&LAB_0188ada0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 830 ; VA 0x004b19c0 ; FUN_004b19c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b19c0(void)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined auStack_54 [4];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  undefined auStack_44 [24];
  undefined *puStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e62ed;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  puStack_2c = &LAB_00a9e2a0;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined *)FUN_00d89aa0();
  auStack_54[0] = *puVar2;
  puStack_14 = auStack_54;
  uStack_50 = *(undefined4 *)(puVar2 + 4);
  if (*(int *)(puVar2 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(puVar2 + 0xc) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_4c = *(undefined4 *)(puVar2 + 8);
  iStack_48 = *(int *)(puVar2 + 0xc);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(puVar2 + 0x10);
  uStack_8._0_1_ = 2;
  uVar3 = FUN_00a93fd0();
  FUN_009cb790(uVar3,s_Raycast_0212789c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021273e0 = CONCAT44(uStack_28,puStack_2c);
  _DAT_021273a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,class_RBX::LuaRaycastResult___cdecl(class_G3D::Vector3_const&,class_G3D::Vector3_const&,class_RBX::LuaRaycastParams_const&),3>
       ::vftable;
  _DAT_021273e8 = 0;
  DAT_021273ec = 0;
  DAT_021273f0 = 0;
  uStack_8._0_1_ = 5;
  puVar2 = (undefined *)FUN_01674e20(0x28);
  puStack_14 = puVar2;
  if (puVar2 == (undefined *)0x0) {
    DAT_021273f4 = (undefined *)0x0;
  }
  else {
    *puVar2 = auStack_54[0];
    *(undefined4 *)(puVar2 + 4) = uStack_50;
    *(undefined4 *)(puVar2 + 8) = 0;
    *(undefined4 *)(puVar2 + 0xc) = 0;
    if (iStack_48 != 0) {
      LOCK();
      *(int *)(iStack_48 + 4) = *(int *)(iStack_48 + 4) + 1;
      UNLOCK();
    }
    *(undefined4 *)(puVar2 + 8) = uStack_4c;
    *(int *)(puVar2 + 0xc) = iStack_48;
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_44);
    DAT_021273f4 = puVar2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_00a99080(s_origin_02127894,s_direction_02127888,s_raycastParams_02127878);
  FUN_0087dcc0();
  FUN_0087dcc0();
  FUN_016f3654(&LAB_0188adb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 831 ; VA 0x004b1b60 ; FUN_004b1b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b1b60(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e631e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,s_SetInsertPoint_02127adc,5,uStack_1c,0);
  _DAT_02127810 = 0xa9e6f0;
  _DAT_021277d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::WorldRoot,void___cdecl(class_G3D::Vector3_const&,bool),2>::vftable;
  _DAT_02127818 = 0;
  DAT_0212781c = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_02127820 = (undefined *)FUN_01674e20(1);
  if (DAT_02127820 == (undefined *)0x0) {
    DAT_02127820 = (undefined *)0x0;
  }
  else {
    *DAT_02127820 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a99420();
  FUN_016f3654(&LAB_0188ae00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 832 ; VA 0x004b1e00 ; FUN_004b1e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b1e00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e752a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00abe1a0(uVar2,0);
  FUN_009cb790(uVar1,s_GetEmulatedPolicyInfo_02127d34,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02127b88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerEmulatorService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02127bc0 = FUN_00abea50;
  _DAT_02127bc4 = 0;
  _DAT_02127bac = FUN_008881d0();
  FUN_016f3654(&LAB_0188af40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 833 ; VA 0x004b1ea0 ; FUN_004b1ea0 */

void FUN_004b1ea0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00abe2c0(FUN_00abf030,0,s_SetEmulatedPolicyInfo_02127d60,s_emulatedPolicyInfo_02127d4c,5,
               uStack_10,0);
  FUN_016f3654(&LAB_0188af50);
  return;
}



/* FUNCTION 834 ; VA 0x004b2000 ; FUN_004b2000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2000(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8c4e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70();
  FUN_009cb970(uVar1,s_TeleportInProgress_02128470,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212828c = 0xbc;
  iStack_8 = 0;
  _DAT_02128258 =
       RBX::Reflection::
       EventDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_trait...std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::TeleportService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_teleportInfo_02120120);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02128280 = uStack_1c;
  _DAT_02128284 = uStack_18;
  _DAT_02128288 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_02128258 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char...std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::TeleportService::*>
       ::vftable;
  _DAT_02128290 = 0;
  _DAT_02128294 = 0;
  FUN_016f3654(&LAB_0188b1d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 835 ; VA 0x004b21a0 ; FUN_004b21a0 */

void __fastcall FUN_004b21a0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(8,param_1);
  if (iVar1 == 0) {
    DAT_01eeb570 = 0;
  }
  else {
    *(int *)iVar1 = iVar1;
    *(int *)(iVar1 + 4) = iVar1;
    DAT_01eeb570 = iVar1;
  }
  FUN_016f3654(&LAB_0188b240,iVar1);
  return;
}



/* FUNCTION 836 ; VA 0x004b21e0 ; FUN_004b21e0 */

void __fastcall FUN_004b21e0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(4,param_1);
  if (iVar1 == 0) {
    DAT_01eeb574 = 0;
  }
  else {
    *(int *)iVar1 = iVar1;
    DAT_01eeb574 = iVar1;
  }
  FUN_016f3654(&LAB_0188b260,iVar1);
  return;
}



/* FUNCTION 837 ; VA 0x004b2220 ; FUN_004b2220 */

void __fastcall FUN_004b2220(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(8,param_1);
  if (iVar1 == 0) {
    DAT_01eeb54c = 0;
  }
  else {
    *(int *)iVar1 = iVar1;
    *(int *)(iVar1 + 4) = iVar1;
    DAT_01eeb54c = iVar1;
  }
  FUN_016f3654(&LAB_0188b280,iVar1);
  return;
}



/* FUNCTION 838 ; VA 0x004b22f0 ; FUN_004b22f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b22f0(void)

{
  undefined **ppuVar1;
  undefined4 uStack_8;
  
  uStack_8 = 0xb;
  ppuVar1 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_8)
  ;
  if (ppuVar1 == &boost::lock_error::vftable_meta_ptr) {
    ppuVar1 = (undefined **)&DAT_018be194;
  }
  _DAT_01eeb65c = *ppuVar1;
  _DAT_01eeb660 = 0;
  _DAT_01eeb664 = 0x3f800000;
  _DAT_01eeb668 = 0;
  _DAT_01eeb66c = 0;
  FUN_016f3654(FUN_0188b300);
  return;
}



/* FUNCTION 839 ; VA 0x004b25f0 ; FUN_004b25f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b25f0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8c8e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70();
  FUN_009cb970(uVar1,s_LocalPlayerArrivedFromTeleport_02128450,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02128254 = 0xb0;
  iStack_8 = 0;
  _DAT_02128220 =
       RBX::Reflection::
       EventDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant)>_RBX::TeleportService::*>
       ::vftable;
  FUN_0086e3d0(s_loadingGui_02128444);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_dataTable_02128438);
  FUN_00888410();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02128248 = uStack_1c;
  _DAT_0212824c = uStack_18;
  _DAT_02128250 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02128220 =
       RBX::Reflection::
       EventDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant)>_RBX::TeleportService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188b340);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 840 ; VA 0x004b2760 ; FUN_004b2760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2760(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8cd9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70();
  FUN_009cb970(uVar1,s_TeleportInitFailed_02128424,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02128214 = 0xb4;
  iStack_8 = 0;
  _DAT_021281e0 =
       RBX::Reflection::
       EventDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::TeleportService::TeleportResult,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::TeleportService::TeleportResult,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::TeleportService::TeleportResult,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::TeleportService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_teleportResult_02128414);
  FUN_00adb5f0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_errorMessage_02128404);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02128208 = uStack_1c;
  _DAT_0212820c = uStack_18;
  _DAT_02128210 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_021281e0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::TeleportService::TeleportResult,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::TeleportService::TeleportResult,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::TeleportService::TeleportResult,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::TeleportService::*>
       ::vftable;
  _DAT_02128218 = 0;
  _DAT_0212821c = 1;
  FUN_016f3654(&LAB_0188b350);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 841 ; VA 0x004b2910 ; FUN_004b2910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2910(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8cfa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70(uVar2,0);
  FUN_009cb790(uVar1,s_GetArrivingTeleportGui_02128378,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128058 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02128090 = FUN_00acb0e0;
  _DAT_02128094 = 0;
  _DAT_0212807c = FUN_0088cdc0();
  FUN_016f3654(&LAB_0188b360);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 842 ; VA 0x004b29b0 ; FUN_004b29b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b29b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8d1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70(uVar2,0);
  FUN_009cb790(uVar1,s_GetLocalPlayerTeleportData_021283d0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128168 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportService,class_RBX::Reflection::Variant___cdecl(void),0>::
       vftable;
  _DAT_021281a0 = FUN_00ad5a20;
  _DAT_021281a4 = 0;
  _DAT_0212818c = FUN_00888410();
  FUN_016f3654(&LAB_0188b370);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 843 ; VA 0x004b2a50 ; FUN_004b2a50 */

void FUN_004b2a50(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ac4bc0(FUN_00acb110,0,s_GetPlayerPlaceInstanceAsync_02128298,s_userId_0211fb64,0,uStack_10,0
              );
  FUN_016f3654(&LAB_0188b380);
  return;
}



/* FUNCTION 844 ; VA 0x004b2ab0 ; FUN_004b2ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2ab0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8d7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ac0f70();
  FUN_009cb790(uVar2,s_GetTeleportSetting_02128398,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02128098 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportService,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_021280d0 = FUN_00acb330;
  _DAT_021280d4 = 0;
  DAT_021280d8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021280bc = FUN_00888410();
  iVar1 = DAT_021280d8;
  if (DAT_021280d8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_setting_02128390);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188b3a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 845 ; VA 0x004b2c60 ; FUN_004b2c60 */

void FUN_004b2c60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00ac4bc0(FUN_00acc990,0,s_ReserveServer_0212830c,s_placeId_021200e8,0,uStack_10,0);
  FUN_016f3654(&LAB_0188b3c0);
  return;
}



/* FUNCTION 846 ; VA 0x004b2cc0 ; FUN_004b2cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2cc0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8ddc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ac0f70();
  FUN_009cb790(uVar2,s_SetTeleportGui_02128368,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02128010 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02128048 = FUN_00acd920;
  _DAT_0212804c = 0;
  DAT_02128050 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02128034 = FUN_00888530();
  puVar4 = DAT_02128050;
  if (DAT_02128050 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(&DAT_02128364);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188b3e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 847 ; VA 0x004b2e90 ; FUN_004b2e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2e90(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8e0e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70(uVar2,0);
  FUN_009cb790(uVar1,s_SetTeleportSetting_021283ac,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021280e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant),2>
       ::vftable;
  _DAT_02128118 = FUN_00acd990;
  _DAT_0212811c = 0;
  _DAT_02128120 = 0;
  DAT_02128124 = 0;
  uStack_8 = 2;
  FUN_0089f290();
  FUN_016f3654(FUN_0188b430);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 848 ; VA 0x004b2f50 ; FUN_004b2f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b2f50(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uStack_1e0;
  int iStack_1dc;
  undefined auStack_1d8 [200];
  undefined4 uStack_110;
  int iStack_10c;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  undefined4 uStack_38;
  int iStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8e8a;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_1e0 = FUN_00888530();
  iStack_1dc = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  puStack_14 = (undefined4 *)((uint)puStack_14 & 0xffffff00);
  uStack_8._0_1_ = 2;
  FUN_00abf7e0(puStack_14,&uStack_1e0,&uStack_1c);
  uStack_38 = 0;
  iStack_34 = 0;
  uStack_8._0_1_ = 3;
  uVar4 = FUN_00ac0f70();
  FUN_009cb790(uVar4,s_Teleport_02128300,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02127ed0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TeleportService,void___cdecl(__int64,class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant,class_std::shared_ptr<class_RBX::Instance>),4>
       ::vftable;
  _DAT_02127f08 = FUN_00acda40;
  _DAT_02127f0c = 0;
  _DAT_02127f10 = 0;
  uStack_8._0_1_ = 5;
  _DAT_02127f14 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_02127f14 == (undefined4 *)0x0) {
    _DAT_02127f14 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02127f14 = 0;
    _DAT_02127f14[1] = 0;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 4) = *(int *)(iStack_34 + 4) + 1;
      UNLOCK();
    }
    *_DAT_02127f14 = uStack_38;
    _DAT_02127f14[1] = iStack_34;
  }
  uStack_8._0_1_ = 6;
  puVar5 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 7;
  puStack_14 = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    _DAT_02127f18 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = uStack_108;
    puVar5[1] = 0;
    if (puStack_104 != (undefined4 *)0x0) {
      (*(code *)*puStack_104)();
    }
    puVar5[1] = puStack_104;
    _DAT_02127f18 = puVar5;
  }
  uStack_8._0_1_ = 8;
  _DAT_02127f1c = (undefined4 *)FUN_01674e20(8);
  if (_DAT_02127f1c == (undefined4 *)0x0) {
    _DAT_02127f1c = (undefined4 *)0x0;
  }
  else {
    *_DAT_02127f1c = 0;
    _DAT_02127f1c[1] = 0;
    if (iStack_10c != 0) {
      LOCK();
      *(int *)(iStack_10c + 4) = *(int *)(iStack_10c + 4) + 1;
      UNLOCK();
    }
    *_DAT_02127f1c = uStack_110;
    _DAT_02127f1c[1] = iStack_10c;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00ad31b0(s_placeId_021200e8,s_player_0211f800,s_teleportData_021282b4,
               s_customLoadingScreen_0212010c);
  FUN_00ac8a00();
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (iStack_1dc != 0) {
    (**(code **)(iStack_1dc + 8))(auStack_1d8);
  }
  FUN_016f3654(&LAB_0188b4a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 849 ; VA 0x004b31b0 ; FUN_004b31b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b31b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8eaa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70(uVar2,0);
  FUN_009cb790(uVar1,s_TeleportCancel_021283c0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128128 =
       RBX::Reflection::BoundFuncDesc<class_RBX::TeleportService,void___cdecl(void),0>::vftable;
  _DAT_02128160 = &LAB_00acdbb0;
  _DAT_02128164 = 0;
  _DAT_0212814c = FUN_00888530();
  FUN_016f3654(&LAB_0188b4b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 850 ; VA 0x004b3250 ; FUN_004b3250 */

void FUN_004b3250(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  undefined auStack_22c [240];
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined8 uStack_130;
  undefined *puStack_128;
  undefined4 uStack_11c;
  int iStack_118;
  undefined auStack_114 [200];
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e8eeb;
  pvStack_10 = ExceptionList;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_30 = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  uStack_8 = 1;
  uStack_7 = 0;
  puStack_128 = (undefined *)0x4b32ab;
  ExceptionList = &pvStack_10;
  uStack_11c = FUN_00888530();
  iStack_118 = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_130 = CONCAT44(uStack_30,uStack_34);
  uStack_8 = 3;
  uStack_134 = 0;
  puStack_20 = auStack_22c;
  puStack_128 = (undefined *)0x0;
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00abf7e0(uStack_14,&uStack_11c,&uStack_1c);
  uStack_8 = 4;
  FUN_0054ef60(auStack_4c);
  _uStack_8 = CONCAT31(uStack_7,3);
  uStack_13c = 0;
  uStack_138 = 0;
  FUN_00ac46c0(FUN_00acee80,0,s_TeleportToPlaceInstance_021282d0,s_placeId_021200e8,
               s_instanceId_021282c4,s_player_0211f800,s_spawnName_021200dc,s_teleportData_021282b4,
               s_customLoadingScreen_0212010c);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_128 = (undefined *)0x4b3380;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_128 = (undefined *)0x4b338f;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  _uStack_8 = CONCAT31(uStack_7,5);
  if (iStack_118 != 0) {
    puStack_128 = auStack_114;
    uStack_130 = CONCAT44(0x4b33a9,(undefined4)uStack_130);
    (**(code **)(iStack_118 + 8))();
  }
  if (0xf < uStack_38) {
    puStack_128 = (undefined *)(uStack_38 + 1);
    uVar4 = auStack_4c[0];
    if (0xfff < puStack_128) {
      uVar4 = *(uint *)(auStack_4c[0] - 4);
      puStack_128 = (undefined *)(uStack_38 + 0x24);
      if (0x1f < (auStack_4c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_128 = &UNK_004b33fe;
        FUN_017167a3();
      }
    }
    uStack_130 = CONCAT44(uVar4,0x4b33d9);
    FUN_01674ea0();
  }
  puStack_128 = &LAB_0188b4c0;
  uStack_130 = CONCAT44(0x4b33e6,(undefined4)uStack_130);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 851 ; VA 0x004b3400 ; FUN_004b3400 */

void FUN_004b3400(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  undefined auStack_21c [240];
  undefined4 uStack_12c;
  undefined8 uStack_128;
  undefined *puStack_120;
  undefined4 uStack_114;
  int iStack_110;
  undefined auStack_10c [200];
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8f23;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_8 = 0;
  puStack_120 = (undefined *)0x4b3449;
  ExceptionList = &pvStack_10;
  uStack_114 = FUN_00888530();
  iStack_110 = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_128 = CONCAT44(uStack_28,uStack_2c);
  uStack_8._0_1_ = 2;
  uStack_12c = 0;
  puStack_20 = auStack_21c;
  puStack_120 = (undefined *)0x0;
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00abf7e0(uStack_14,&uStack_114,&uStack_1c);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_44);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00ac4540(FUN_00acf060,0,s_TeleportToPrivateServer_02128338,s_placeId_021200e8,
               s_reservedServerAccessCode_0212831c,s_players_02121524,s_spawnName_021200dc,
               s_teleportData_021282b4,s_customLoadingScreen_0212010c);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_120 = (undefined *)0x4b350a;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_120 = (undefined *)0x4b3519;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_110 != 0) {
    puStack_120 = auStack_10c;
    uStack_128 = CONCAT44(0x4b3533,(undefined4)uStack_128);
    (**(code **)(iStack_110 + 8))();
  }
  if (0xf < uStack_30) {
    puStack_120 = (undefined *)(uStack_30 + 1);
    uVar4 = auStack_44[0];
    if (0xfff < puStack_120) {
      uVar4 = *(uint *)(auStack_44[0] - 4);
      puStack_120 = (undefined *)(uStack_30 + 0x24);
      if (0x1f < (auStack_44[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_120 = &UNK_004b3588;
        FUN_017167a3();
      }
    }
    uStack_128 = CONCAT44(uVar4,0x4b3563);
    FUN_01674ea0();
  }
  puStack_120 = &LAB_0188b4d0;
  uStack_128 = CONCAT44(0x4b3570,(undefined4)uStack_128);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 852 ; VA 0x004b3590 ; FUN_004b3590 */

void FUN_004b3590(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uStack_100;
  int iStack_fc;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8f4b;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_100 = FUN_00888530();
  iStack_fc = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = &stack0xfffffe00;
  FUN_00abf7e0(puStack_14,&uStack_100,&uStack_1c);
  FUN_00ac48b0(FUN_00acfcf0,0,s_TeleportToSpawnByName_021282e8,s_placeId_021200e8,
               s_spawnName_021200dc,s_player_0211f800,s_teleportData_021282b4,
               s_customLoadingScreen_0212010c);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_fc != 0) {
    (**(code **)(iStack_fc + 8))();
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 853 ; VA 0x004b36e0 ; FUN_004b36e0 */

void FUN_004b36e0(void)

{
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_100;
  undefined8 uStack_fc;
  undefined *puStack_f4;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8f73;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  puStack_f4 = (undefined *)0x4b370e;
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_00888530();
  iStack_ec = 0;
  uStack_fc = CONCAT44(uStack_1c,uStack_20);
  uStack_100 = 0;
  puStack_14 = (undefined *)&uStack_1d8;
  puStack_f4 = (undefined *)0x0;
  uStack_1d8 = 0;
  uStack_1d4 = 0;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  FUN_005caf00(&uStack_f0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00ac4a40(FUN_00adba80,0,s_TeleportPartyAsync_02128350,s_placeId_021200e8,s_players_02121524,
               s_teleportData_021282b4,s_customLoadingScreen_0212010c);
  iStack_8 = 2;
  if (iStack_ec != 0) {
    puStack_f4 = auStack_e8;
    uStack_fc = CONCAT44(0x4b37b2,(undefined4)uStack_fc);
    (**(code **)(iStack_ec + 8))();
  }
  puStack_f4 = &LAB_0188b4f0;
  uStack_fc = CONCAT44(0x4b37bf,(undefined4)uStack_fc);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 854 ; VA 0x004b37d0 ; FUN_004b37d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b37d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastOne",0x20);
  uStack_8 = 0;
  DAT_01d666e4 = 2;
  _DAT_01d666f8 = 0;
  _DAT_01d666fc = 0xf;
  DAT_01d666e8 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastTwo",0x20);
  uStack_8._0_1_ = 1;
  _DAT_01d66700 = 4;
  _DAT_01d66714 = 0;
  _DAT_01d66718 = 0xf;
  DAT_01d66704 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastFour",0x21);
  uStack_8._0_1_ = 2;
  _DAT_01d6671c = 8;
  _DAT_01d66730 = 0;
  _DAT_01d66734 = 0xf;
  DAT_01d66720 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastEight",0x22);
  uStack_8._0_1_ = 3;
  _DAT_01d66738 = 0xc;
  _DAT_01d6674c = 0;
  _DAT_01d66750 = 0xf;
  DAT_01d6673c = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastTwelve",0x23);
  uStack_8._0_1_ = 4;
  _DAT_01d66754 = 0x10;
  _DAT_01d66768 = 0;
  _DAT_01d6676c = 0xf;
  DAT_01d66758 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastSixteen",0x24);
  uStack_8._0_1_ = 5;
  _DAT_01d66770 = 0x14;
  _DAT_01d66784 = 0;
  _DAT_01d66788 = 0xf;
  DAT_01d66774 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastTwenty",0x23);
  uStack_8._0_1_ = 6;
  _DAT_01d6678c = 0x1e;
  _DAT_01d667a0 = 0;
  _DAT_01d667a4 = 0xf;
  DAT_01d66790 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastThirty",0x23);
  uStack_8._0_1_ = 7;
  _DAT_01d667a8 = 0x28;
  _DAT_01d667bc = 0;
  _DAT_01d667c0 = 0xf;
  DAT_01d667ac = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastForty",0x22);
  uStack_8._0_1_ = 8;
  _DAT_01d667c4 = 0x32;
  _DAT_01d667d8 = 0;
  _DAT_01d667dc = 0xf;
  DAT_01d667c8 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastFifty",0x22);
  uStack_8._0_1_ = 9;
  _DAT_01d667e0 = 0x3c;
  _DAT_01d667f4 = 0;
  _DAT_01d667f8 = 0xf;
  DAT_01d667e4 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastSixty",0x22);
  uStack_8._0_1_ = 10;
  _DAT_01d667fc = 0x50;
  _DAT_01d66810 = 0;
  _DAT_01d66814 = 0xf;
  DAT_01d66800 = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastEighty",0x23);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  _DAT_01d66818 = 100;
  _DAT_01d6682c = 0;
  _DAT_01d66830 = 0xf;
  DAT_01d6681c = 0;
  FUN_005542c0("GroupTeleportGroupSizeAtLeastOneHundred",0x27);
  FUN_016f3654(&LAB_0188b500);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 855 ; VA 0x004b3af0 ; FUN_004b3af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b3af0(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  undefined auStack_a0 [8];
  void *pvStack_98;
  char *pcStack_94;
  undefined4 uStack_90;
  char *pcStack_8c;
  undefined4 uStack_88;
  char *pcStack_84;
  undefined4 uStack_80;
  char *pcStack_7c;
  undefined4 uStack_78;
  char *pcStack_74;
  undefined4 uStack_70;
  char *pcStack_6c;
  undefined4 uStack_68;
  char *pcStack_64;
  undefined4 uStack_60;
  char *pcStack_5c;
  undefined4 uStack_58;
  char *pcStack_54;
  undefined4 uStack_50;
  char *pcStack_4c;
  undefined4 uStack_48;
  char *pcStack_44;
  undefined4 uStack_40;
  char *pcStack_3c;
  undefined4 uStack_38;
  char *pcStack_34;
  undefined4 uStack_30;
  char *pcStack_2c;
  undefined4 uStack_28;
  char *pcStack_24;
  undefined4 uStack_20;
  char *pcStack_1c;
  undefined4 uStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e902e;
  pvStack_10 = ExceptionList;
  pvStack_98 = (void *)0x0;
  pcStack_94 = "Waiting";
  uStack_90 = 1;
  pcStack_8c = "Loading";
  uStack_88 = 2;
  pcStack_84 = "Joining";
  uStack_80 = 3;
  pcStack_7c = "Disabled";
  uStack_78 = 4;
  pcStack_74 = "Error";
  uStack_70 = 5;
  pcStack_6c = "GameEnded";
  uStack_68 = 6;
  pcStack_64 = "GameFull";
  uStack_60 = 10;
  pcStack_5c = "UserLeft";
  uStack_58 = 0xb;
  pcStack_54 = "Restricted";
  uStack_50 = 0xc;
  pcStack_4c = "Unauthorized";
  uStack_48 = 0xd;
  pcStack_44 = "Flooded";
  uStack_40 = 0xe;
  pcStack_3c = "HashExpired";
  uStack_38 = 0xf;
  pcStack_34 = "HashException";
  uStack_30 = 0x10;
  pcStack_2c = "PartyCannotFit";
  uStack_28 = 0x11;
  pcStack_24 = "HttpError";
  uStack_20 = 0x62;
  pcStack_1c = "CustomMsg";
  uStack_18 = 99;
  pcStack_14 = "OtherError";
  ExceptionList = &pvStack_10;
  DAT_01eeb678 = (int *)FUN_005e9aa0(0,0);
  _DAT_01eeb680 = 0;
  _DAT_01eeb684 = 0;
  _DAT_01eeb688 = 0;
  uStack_8 = 1;
  _DAT_01eeb674 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = 2;
  ppvVar4 = &pvStack_98;
  do {
    iVar1 = *DAT_01eeb678;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_005e5370(iVar1,puVar2,ppvVar4);
    if (DAT_01eeb67c == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01eeb67c = DAT_01eeb67c + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00ac1070(auStack_a0,*DAT_01eeb678 + 8,*DAT_01eeb678);
    ppvVar4 = ppvVar4 + 2;
  } while (ppvVar4 != &pvStack_10);
  FUN_016f3654(&LAB_0188b660);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 856 ; VA 0x004b3d00 ; FUN_004b3d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b3d00(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9066;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_009cb3a0(auStack_34,0x15);
  uStack_24 = *puVar3;
  uStack_20 = puVar3[1];
  uStack_1c = puVar3[2];
  uStack_18 = puVar3[3];
  uVar4 = FUN_00ac0f70();
  puStack_14 = (undefined4 *)0x0;
  uStack_8 = 0;
  uVar5 = FUN_0088daf0();
  FUN_009ca670(uVar4,uVar5,s_CustomizedTeleportUI_021283ec,&DAT_021197d4,uStack_24,uStack_20,
               uStack_1c,uStack_18,0,0,0);
  DAT_021281dc = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021281a8 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_14 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puStack_14 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::TeleportService>::
                  vftable;
    puStack_14[1] = &DAT_021281a8;
    puStack_14[2] = 0xa8;
    puStack_14[4] = 0;
    puStack_14[5] = 0;
    puVar3 = puStack_14;
  }
  if (DAT_021281dc != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021281dc;
    DAT_021281dc = puVar3;
    (*(code *)*puVar1)(1);
    puVar3 = DAT_021281dc;
  }
  DAT_021281dc = puVar3;
  cVar2 = (*(code *)DAT_021281a8[3])();
  if (cVar2 != '\0') {
    _DAT_021281cc = _DAT_021281cc & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021281a8[2])();
  if (cVar2 != '\0') {
    _DAT_021281cc = _DAT_021281cc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188b670);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 857 ; VA 0x004b3ef0 ; FUN_004b3ef0 */

void FUN_004b3ef0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_02128568,0x17);
  FUN_00add250(s_MinDistance_02128ec0,&DAT_021197d4,FUN_00adf3b0,0,FUN_00ae0ba0,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0188b6c0);
  return;
}



/* FUNCTION 858 ; VA 0x004b3f50 ; FUN_004b3f50 */

void FUN_004b3f50(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_021284f8,0x17);
  FUN_00add250(s_Pitch_02128ea8,&DAT_021197d4,FUN_00adf3d0,0,FUN_00ae0c00,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0188b6e0);
  return;
}



/* FUNCTION 859 ; VA 0x004b3fb0 ; FUN_004b3fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b3fb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea8ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00add460();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Soundscape::Sound,class_RBX::Soundscape::SoundId>::
              GetSetImpl<class_RBX::Soundscape::SoundId_const&_(__thiscall_RBX::Soundscape::Sound::*)(void)const_,void_(__thiscall_RBX::Soundscape::Sound::*)(class_RBX::Soundscape::SoundId)>
              ::vftable;
    puVar3[2] = FUN_00adf5d0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ae1110;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_SoundId_02128e98,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02128488 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Soundscape::SoundId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021284bc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021284ac = _DAT_021284ac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02128488[2])();
    if (cVar1 != '\0') {
      _DAT_021284ac = _DAT_021284ac & 0xfffffff3;
    }
  }
  DAT_02128488 = RBX::Reflection::
                 PropDescriptor<class_RBX::Soundscape::Sound,class_RBX::Soundscape::SoundId>::
                 vftable;
  FUN_016f3654(&LAB_0188b700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 860 ; VA 0x004b4130 ; FUN_004b4130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b4130(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea90a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00add460();
  FUN_00684820(uVar3,s_PlayOnRemove_02128f80,s_Behavior_0211a8f8,0);
  uStack_8 = 0;
  DAT_021287d8 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Soundscape::Sound>::
              vftable;
    puVar4[1] = &DAT_021287d8;
    puVar4[2] = 0x1a8;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0212880c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0212880c;
    DAT_0212880c = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0212880c;
  }
  DAT_0212880c = puVar4;
  cVar2 = (*(code *)DAT_021287d8[3])();
  if (cVar2 != '\0') {
    _DAT_021287fc = _DAT_021287fc & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021287d8[2])();
  if (cVar2 != '\0') {
    _DAT_021287fc = _DAT_021287fc & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 861 ; VA 0x004b42e0 ; FUN_004b42e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b42e0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea943;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460();
  FUN_009cb970(uVar1,s_playbackActionSync_021290d0,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02128d24 = 0x17c;
  iStack_8 = 0;
  _DAT_02128cf0 =
       RBX::Reflection::
       EventDesc<class_RBX::Soundscape::Sound,void___cdecl(int),class_rbx::remote_signal<void___cdecl(int)>,class_rbx::remote_signal<void___cdecl(int)>_RBX::Soundscape::Sound::*>
       ::vftable;
  FUN_0086e3d0(s_action_0211cfc8);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02128d18 = uStack_1c;
  _DAT_02128d1c = uStack_18;
  _DAT_02128d20 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02128cf0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Soundscape::Sound,void___cdecl(int),class_rbx::remote_signal<void___cdecl(int)>,class_rbx::remote_signal<void___cdecl(int)>_RBX::Soundscape::Sound::*>
       ::vftable;
  _DAT_02128d28 = 1;
  _DAT_02128d2c = 0;
  FUN_016f3654(&LAB_0188b7c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 862 ; VA 0x004b4580 ; FUN_004b4580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b4580(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea970;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebd0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eebd0c,uVar3,0,0,0x1f);
    if (DAT_01eebd0c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01eebce8 = RBX::Reflection::RefType<class_RBX::Soundscape::SoundGroup*>::vftable;
      FUN_016f3654(&LAB_0188bbd0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eebd0c);
    }
  }
  uVar2 = FUN_00add460();
  FUN_009ca670(uVar2,&DAT_01eebce8,s_SoundGroup_02129020,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0
              );
  uStack_8 = 1;
  DAT_02128bb0 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::Soundscape::Sound,class_RBX::Soundscape::SoundGroup>::
                 vftable;
  _DAT_02128be4 =
       RBX::Reflection::
       RefPropDescriptor<class_RBX::Soundscape::Sound,class_RBX::Soundscape::SoundGroup>::vftable;
  DAT_02128be8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02128be8 == (undefined4 *)0x0) {
    DAT_02128be8 = (undefined4 *)0x0;
  }
  else {
    *DAT_02128be8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Soundscape::Sound,class_RBX::Soundscape::SoundGroup*>::
         GetSetImpl<class_RBX::Soundscape::SoundGroup*_(__thiscall_RBX::Soundscape::Sound::*)(void)const_,void_(__thiscall_RBX::Soundscape::Sound::*)(class_RBX::Soundscape::SoundGroup*)>
         ::vftable;
    DAT_02128be8[2] = FUN_00adf570;
    DAT_02128be8[3] = 0;
    DAT_02128be8[4] = FUN_00ae0f10;
    DAT_02128be8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02128bb0[3])();
  if (cVar1 != '\0') {
    _DAT_02128bd4 = _DAT_02128bd4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02128bb0[2])();
  if (cVar1 != '\0') {
    _DAT_02128bd4 = _DAT_02128bd4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188b830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 863 ; VA 0x004b4720 ; FUN_004b4720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b4720(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea98a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02128890;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,&DAT_02128890);
  FUN_009cb790(uVar1,s_pause_021290f4,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128db0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_02128de8 = FUN_00ae0700;
  _DAT_02128dec = 0;
  _DAT_02128dd4 = FUN_00888530();
  FUN_016f3654(&LAB_0188b8b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 864 ; VA 0x004b47c0 ; FUN_004b47c0 */

void FUN_004b47c0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_021285d8,0x1f);
  FUN_00add250(s_EmitterSize_02129108,&DAT_021197d4,FUN_00adf3b0,0,FUN_00ae0ba0,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0188b8c0);
  return;
}



/* FUNCTION 865 ; VA 0x004b4980 ; FUN_004b4980 */

void FUN_004b4980(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_02128610,0x13);
  FUN_00add250(s_MaxDistance_02129114,&DAT_021197d4,FUN_00adf390,0,FUN_00ae0b40,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0188b920);
  return;
}



/* FUNCTION 866 ; VA 0x004b4d00 ; FUN_004b4d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b4d00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea9b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ae1680();
  uVar3 = FUN_00add460();
  FUN_009ca670(uVar3,uVar2,s_RollOffMode_02128f24,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02128680 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Soundscape::Sound,enum_RBX::Soundscape::RollOffMode>
                 ::vftable;
  _DAT_021286b4 = uVar2;
  DAT_021286b8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021286b8 == (undefined4 *)0x0) {
    DAT_021286b8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021286b8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Soundscape::Sound,enum_RBX::Soundscape::RollOffMode>::
         GetSetImpl<enum_RBX::Soundscape::RollOffMode_(__thiscall_RBX::Soundscape::Sound::*)(void)const_,void_(__thiscall_RBX::Soundscape::Sound::*)(enum_RBX::Soundscape::RollOffMode)>
         ::vftable;
    DAT_021286b8[2] = &LAB_00adf400;
    DAT_021286b8[3] = 0;
    DAT_021286b8[4] = FUN_00ae0e40;
    DAT_021286b8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021286bc = FUN_00ae1680();
  cVar1 = (*(code *)DAT_02128680[3])();
  if (cVar1 != '\0') {
    _DAT_021286a4 = _DAT_021286a4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02128680[2])();
  if (cVar1 != '\0') {
    _DAT_021286a4 = _DAT_021286a4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188ba00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 867 ; VA 0x004b52b0 ; FUN_004b52b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b52b0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea9ee;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460();
  FUN_009cb970(uVar1,s_DidLoop_02128ff0,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02128a5c = 0x188;
  iStack_8 = 0;
  _DAT_02128a28 =
       RBX::Reflection::
       EventDesc<class_RBX::Soundscape::Sound,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>_RBX::Soundscape::Sound::*>
       ::vftable;
  FUN_0086e3d0(s_soundId_02128fe8);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_numOfTimesLooped_02128fd4);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02128a50 = uStack_1c;
  _DAT_02128a54 = uStack_18;
  _DAT_02128a58 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02128a28 =
       RBX::Reflection::
       EventDesc<class_RBX::Soundscape::Sound,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>_RBX::Soundscape::Sound::*>
       ::vftable;
  FUN_016f3654(&LAB_0188bb20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 868 ; VA 0x004b5420 ; FUN_004b5420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5420(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaa0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,0);
  FUN_009cb790(uVar1,s_Pause_02121eb8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128890 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_021288c8 = FUN_00ae0700;
  _DAT_021288cc = 0;
  _DAT_021288b4 = FUN_00888530();
  FUN_016f3654(&LAB_0188bb30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 869 ; VA 0x004b54f0 ; FUN_004b54f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b54f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaa2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02128f90,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128810 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_02128848 = FUN_00ae0730;
  _DAT_0212884c = 0;
  _DAT_02128834 = FUN_00888530();
  FUN_016f3654(&LAB_0188bb50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 870 ; VA 0x004b5590 ; FUN_004b5590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5590(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaa4a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02128810;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,&DAT_02128810);
  FUN_009cb790(uVar1,&DAT_021290ec,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128d70 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_02128da8 = FUN_00ae0730;
  _DAT_02128dac = 0;
  _DAT_02128d94 = FUN_00888530();
  FUN_016f3654(&LAB_0188bb60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 871 ; VA 0x004b5660 ; FUN_004b5660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5660(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaa6a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,0);
  FUN_009cb790(uVar1,s_Resume_02128f98,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128850 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_02128888 = FUN_00ae0a90;
  _DAT_0212888c = 0;
  _DAT_02128874 = FUN_00888530();
  FUN_016f3654(&LAB_0188bb80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 872 ; VA 0x004b5730 ; FUN_004b5730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5730(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaa8a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02121ec0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021288d0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_02128908 = FUN_00ae17f0;
  _DAT_0212890c = 0;
  _DAT_021288f4 = FUN_00888530();
  FUN_016f3654(&LAB_0188bba0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 873 ; VA 0x004b57d0 ; FUN_004b57d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b57d0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaaaa;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_021288d0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00add460(uVar2,&DAT_021288d0);
  FUN_009cb790(uVar1,&DAT_021290e4,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02128d30 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::Sound,void___cdecl(void),0>::vftable;
  _DAT_02128d68 = FUN_00ae17f0;
  _DAT_02128d6c = 0;
  _DAT_02128d54 = FUN_00888530();
  FUN_016f3654(&LAB_0188bbb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 874 ; VA 0x004b5940 ; FUN_004b5940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5940(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaf1c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ae2430();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::LuaSourceContainer,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = FUN_00ae4420;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ae6630;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,"ScriptGuid",&DAT_018dbc3c,uStack_24,0,0,0xe,0,0,0);
  DAT_01eebf14 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eebf48 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eebf38 = _DAT_01eebf38 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eebf14[2])();
    if (cVar1 != '\0') {
      _DAT_01eebf38 = _DAT_01eebf38 & 0xfffffff3;
    }
  }
  DAT_01eebf14 = RBX::Reflection::
                 PropDescriptor<class_RBX::LuaSourceContainer,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_0188bc60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 875 ; VA 0x004b5b30 ; FUN_004b5b30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5b30(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaf53;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae2430();
  FUN_009cb970(uVar1,"LockGrantedOrNot",0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_01eebe8c = 0x6c;
  iStack_8 = 0;
  _DAT_01eebe58 =
       RBX::Reflection::
       EventDesc<class_RBX::LuaSourceContainer,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::LuaSourceContainer::*>
       ::vftable;
  FUN_0086e3d0("granted");
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_01eebe80 = uStack_1c;
  _DAT_01eebe84 = uStack_18;
  _DAT_01eebe88 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_01eebe58 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LuaSourceContainer,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::LuaSourceContainer::*>
       ::vftable;
  _DAT_01eebe90 = 1;
  _DAT_01eebe94 = 0;
  FUN_016f3654(&LAB_0188bca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 876 ; VA 0x004b5cd0 ; FUN_004b5cd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5cd0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaf83;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae2430();
  FUN_009cb970(uVar1,"VerifyScriptHash",3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_01eebfc4 = 0x5c;
  iStack_8 = 0;
  _DAT_01eebf90 =
       RBX::Reflection::
       EventDesc<class_RBX::LuaSourceContainer,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::LuaSourceContainer::*>
       ::vftable;
  FUN_0086e3d0(&DAT_018d2350);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_01eebfb8 = uStack_1c;
  _DAT_01eebfbc = uStack_18;
  _DAT_01eebfc0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_01eebf90 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LuaSourceContainer,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::LuaSourceContainer::*>
       ::vftable;
  _DAT_01eebfc8 = 1;
  _DAT_01eebfcc = 0;
  FUN_016f3654(&LAB_0188bcc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 877 ; VA 0x004b5e40 ; FUN_004b5e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5e40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eafac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ae2430();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::LuaSourceContainer,class_RBX::ProtectedString>::
              GetSetImpl<class_RBX::ProtectedString_const&_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(class_RBX::ProtectedString_const&)>
              ::vftable;
    puVar3[2] = FUN_00ae4370;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ae61e0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00886600();
  FUN_009ca670(uVar2,uVar4,"CachedRemoteSource",&DAT_018dbc3c,uStack_24,0,0,0x22,0,0,0);
  DAT_01eebda8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ProtectedString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eebddc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eebdcc = _DAT_01eebdcc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eebda8[2])();
    if (cVar1 != '\0') {
      _DAT_01eebdcc = _DAT_01eebdcc & 0xfffffff3;
    }
  }
  DAT_01eebda8 = RBX::Reflection::
                 PropDescriptor<class_RBX::LuaSourceContainer,class_RBX::ProtectedString>::vftable;
  FUN_016f3654(&LAB_0188bd30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 878 ; VA 0x004b5f70 ; FUN_004b5f70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b5f70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eafdc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ae2430();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::LuaSourceContainer,int>::
              GetSetImpl<int_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00762f90;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ae6220;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,"CachedRemoteSourceLoadState",&DAT_018dbc3c,uStack_24,0,0,0x22,0,0,0);
  DAT_01eebde0 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eebe14 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eebe04 = _DAT_01eebe04 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eebde0[2])();
    if (cVar1 != '\0') {
      _DAT_01eebe04 = _DAT_01eebe04 & 0xfffffff3;
    }
  }
  DAT_01eebde0 = RBX::Reflection::PropDescriptor<class_RBX::LuaSourceContainer,int>::vftable;
  FUN_016f3654(&LAB_0188bd50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 879 ; VA 0x004b60a0 ; FUN_004b60a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b60a0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb010;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 3;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,3);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00ae2430();
  FUN_009ca670(uVar2,&DAT_01edf850,"CurrentEditor",&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01eebed8 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::LuaSourceContainer,class_RBX::Instance>::vftable;
  _DAT_01eebf0c =
       RBX::Reflection::RefPropDescriptor<class_RBX::LuaSourceContainer,class_RBX::Instance>::
       vftable;
  DAT_01eebf10 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01eebf10 == (undefined4 *)0x0) {
    DAT_01eebf10 = (undefined4 *)0x0;
  }
  else {
    *DAT_01eebf10 =
         RBX::Reflection::PropDescriptor<class_RBX::LuaSourceContainer,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_01eebf10[2] = FUN_00ae43a0;
    DAT_01eebf10[3] = 0;
    DAT_01eebf10[4] = FUN_00ae6250;
    DAT_01eebf10[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01eebed8[3])();
  if (cVar1 != '\0') {
    _DAT_01eebefc = _DAT_01eebefc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01eebed8[2])();
  if (cVar1 != '\0') {
    _DAT_01eebefc = _DAT_01eebefc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188bd70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 880 ; VA 0x004b6290 ; FUN_004b6290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6290(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb64a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae6b40(uVar2,0);
  FUN_009cb790(uVar1,s_GetPlayingAnimationTracks_02124190,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02129168 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Animator,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021291a0 = FUN_00aebf60;
  _DAT_021291a4 = 0;
  _DAT_0212918c = FUN_008882f0();
  FUN_016f3654(&LAB_0188bdc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 881 ; VA 0x004b6330 ; FUN_004b6330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6330(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb6ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ae6b40();
  FUN_009cb790(uVar2,s_LoadAnimation_02124170,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02129120 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Animator,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02129158 = FUN_00aec240;
  _DAT_0212915c = 0;
  DAT_02129160 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02129144 = FUN_0088cdc0();
  puVar4 = DAT_02129160;
  if (DAT_02129160 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_animation_02124164);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188bdd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 882 ; VA 0x004b6500 ; FUN_004b6500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6500(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb6e3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae6b40();
  FUN_009cb970(uVar1,s_AnimationPlayed_021241bc,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021291dc = 0xfc;
  iStack_8 = 0;
  _DAT_021291a8 =
       RBX::Reflection::
       EventDesc<class_RBX::Animator,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Animator::*>
       ::vftable;
  FUN_0086e3d0(s_animationTrack_021241ac);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021291d0 = uStack_1c;
  _DAT_021291d4 = uStack_18;
  _DAT_021291d8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021291a8 =
       RBX::Reflection::
       EventDesc<class_RBX::Animator,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Animator::*>
       ::vftable;
  FUN_016f3654(&LAB_0188be20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 883 ; VA 0x004b6650 ; FUN_004b6650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6650(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00ae7f40(0xf4,s_OnCombinedUpdate_021292f0,s_animation_02124164,s_playState_021292e4,
               s_fadeTime_021292d8,s_weight_021292d0,s_speed_02123e48,s_timePosition_021292c0,
               s_valuesUpdated_021292b0,6,uStack_14,0);
  _DAT_021291e0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Animator,void___cdecl(class_RBX::ContentId,bool,float,float,float,float,int),class_rbx::remote_signal<void___cdecl(class_RBX::ContentId,bool,float,float,float,float,int)>,class_rbx::remote_signal<void___cdecl(class_RBX::ContentId,bool,float,float,float,float,int)>_RBX::Animator::*>
       ::vftable;
  _DAT_02129218 = 1;
  _DAT_0212921c = 0;
  FUN_016f3654(&LAB_0188be30);
  return;
}



/* FUNCTION 884 ; VA 0x004b6800 ; FUN_004b6800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6800(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01eec260 = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 885 ; VA 0x004b68a0 ; FUN_004b68a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b68a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb73c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae6b40();
  FUN_009cb790(uVar1,s_ApplyJointVelocities_02129328,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02129268 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Animator,void___cdecl(class_RBX::Reflection::Variant_const&),1>::
       vftable;
  _DAT_021292a0 = &LAB_00aea700;
  _DAT_021292a4 = 0;
  DAT_021292a8 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_0212928c = FUN_00888530();
  puVar4 = DAT_021292a8;
  if (DAT_021292a8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = *DAT_021292a8;
    puStack_ec = (undefined4 *)0x0;
    puVar2 = (undefined4 *)DAT_021292a8[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)();
      puVar2 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
    puStack_ec = puVar2;
  }
  uVar1 = FUN_00888410();
  uVar3 = FUN_0086e3d0(s_motors_02129320);
  FUN_00888b30(uVar3,uVar1,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(FUN_0188be40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 886 ; VA 0x004b6a50 ; FUN_004b6a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6a50(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb79c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae6b40();
  FUN_009cb790(uVar1,s_StepAnimations_02129310,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02129220 = RBX::Reflection::BoundFuncDesc<class_RBX::Animator,void___cdecl(float),1>::vftable
  ;
  _DAT_02129258 = FUN_00aec5d0;
  _DAT_0212925c = 0;
  DAT_02129260 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02129244 = FUN_00888530();
  puVar3 = DAT_02129260;
  if (DAT_02129260 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00630820();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_deltaTime_02129304);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188beb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 887 ; VA 0x004b6d10 ; FUN_004b6d10 */

void FUN_004b6d10(void)

{
  FUN_00aefbc0(s_MaterialColors_0212a420,s_Appearance_02119800,0xafc0d0,0,0xafdd10,0,0,0,0,0xf,0);
  FUN_016f3654(&LAB_0188c030);
  return;
}



/* FUNCTION 888 ; VA 0x004b6e40 ; FUN_004b6e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6e40(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebff3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb970(uVar1,s_TerrainProgressUpdate_0212a2f8,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02129c40 = 0x100;
  _DAT_02129c44 = 0;
  iStack_8 = 0;
  _DAT_02129c08 =
       RBX::Reflection::
       EventDesc<class_RBX::MegaClusterInstance,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::MegaClusterInstance::*>
       ::vftable;
  FUN_0086e3d0(s_progressRatio_0212a2e8);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02129c30 = uStack_1c;
  _DAT_02129c34 = uStack_18;
  _DAT_02129c38 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02129c08 =
       RBX::Reflection::
       EventDesc<class_RBX::MegaClusterInstance,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::MegaClusterInstance::*>
       ::vftable;
  FUN_016f3654(&LAB_0188c050);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 889 ; VA 0x004b6fa0 ; FUN_004b6fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b6fa0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec00a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_CancelImportHeightmap_0212a2a0,5,uStack_1c,0);
  _DAT_02129b98 = 0xaf30c0;
  uStack_8 = 0;
  _DAT_02129b60 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(void),0>::vftable;
  _DAT_02129ba0 = 0;
  _DAT_02129b84 = FUN_00888530();
  FUN_016f3654(&LAB_0188c060);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 890 ; VA 0x004b7050 ; FUN_004b7050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7050(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec048;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_ImportHeightMap_0212a2d8,5,uStack_1c,0);
  _DAT_02129be0 = 0;
  _DAT_02129ba8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Region3),3>
       ::vftable;
  _DAT_02129be8 = 0;
  _DAT_02129bec = 0;
  _DAT_02129bf0 = 0;
  DAT_02129bf4 = 0;
  uStack_8 = 3;
  FUN_00af56f0(s_heightMapBinary_0212a2c8,s_colorMapBinary_0212a2b8,s_region_02127980);
  _DAT_02129bf8 = 0xaf3100;
  _DAT_02129ba8 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Region3),3>
       ::vftable;
  _DAT_02129c00 = 0;
  _DAT_02129bdc = 1;
  FUN_016f3654(&LAB_0188c070);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 891 ; VA 0x004b7170 ; FUN_004b7170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7170(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec092;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb820(uVar1,s_ImportHeightmap_0212a26c,5,uStack_1c,0);
  _DAT_02129af8 = 0xaf31b0;
  _DAT_02129ac0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3,class_RBX::ContentId,class_RBX::ContentId,enum_RBX::PartMaterial),4>
       ::vftable;
  _DAT_02129b00 = 0;
  DAT_02129b04 = 0;
  _DAT_02129b08 = 0;
  _DAT_02129b0c = 0;
  DAT_02129b10 = 0;
  uStack_8 = 4;
  FUN_00af7ba0(s_region_02127980,s_heightmapAssetId_0212a258,s_colormapAssetId_0212a248,
               s_defaultMaterial_0212a238);
  FUN_016f3654(&LAB_0188c0b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 892 ; VA 0x004b7260 ; FUN_004b7260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7260(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec0ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00af35e0;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  FUN_009cb790(uVar2,s_SetImportHeightmapPaused_0212a284,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02129b50 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02129b18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(bool),1>::vftable;
  _DAT_02129b58 = 0;
  DAT_02129b5c = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02129b3c = FUN_00888530();
  puVar1 = DAT_02129b5c;
  if (DAT_02129b5c == (undefined *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088daf0();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar1;
    iStack_f8 = FUN_005c9ef0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_paused_0212a27c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188c100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 893 ; VA 0x004b74c0 ; FUN_004b74c0 */

void FUN_004b74c0(void)

{
  FUN_00aefac0(s_ClusterGrid_0212a058,&DAT_021197d4,0,0xafdef0,0,0,0,0,4,0);
  FUN_016f3654(&LAB_0188c120);
  return;
}



/* FUNCTION 894 ; VA 0x004b7530 ; FUN_004b7530 */

void FUN_004b7530(void)

{
  FUN_00aefac0(s_ClusterGridV2_0212a064,&DAT_021197d4,0,0xafdf10,0,0,0,0,4,0);
  FUN_016f3654(&LAB_0188c140);
  return;
}



/* FUNCTION 895 ; VA 0x004b7660 ; FUN_004b7660 */

void FUN_004b7660(void)

{
  FUN_00aefbc0(s_PhysicsGrid_0212a090,&DAT_021197d4,0xafc3e0,0,0xafdf50,0,0,0,0,0xc,0);
  FUN_016f3654(&LAB_0188c180);
  return;
}



/* FUNCTION 896 ; VA 0x004b76f0 ; FUN_004b76f0 */

void FUN_004b76f0(void)

{
  FUN_00aefbc0(s_SmoothGrid_0212a084,&DAT_021197d4,0xafc450,0,0xafdf80,0,0,0,0,0xc,0);
  FUN_016f3654(&LAB_0188c1a0);
  return;
}



/* FUNCTION 897 ; VA 0x004b7780 ; FUN_004b7780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7780(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec11c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x8099c0;
    *(undefined8 *)(puVar3 + 6) = 0xafe1d0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::MegaClusterInstance,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::MegaClusterInstance::*)(void)const_,void_(__thiscall_RBX::MegaClusterInstance::*)(class_G3D::Color3_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,s_WaterColor_0212a398,s_Appearance_02119800,uStack_3c,0,0,0x1f,0,0,0);
  DAT_02129e38 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02129e6c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02129e5c = _DAT_02129e5c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02129e38[2])();
    if (cVar1 != '\0') {
      _DAT_02129e5c = _DAT_02129e5c & 0xfffffff3;
    }
  }
  DAT_02129e38 = RBX::Reflection::PropDescriptor<class_RBX::MegaClusterInstance,class_G3D::Color3>::
                 vftable;
  FUN_016f3654(&LAB_0188c1c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 898 ; VA 0x004b7b90 ; FUN_004b7b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7b90(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec13a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_Clear_0212a19c,0,uStack_1c,0);
  _DAT_02129888 = 0xaf3ac0;
  uStack_8 = 0;
  _DAT_02129850 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(void),0>::vftable;
  _DAT_02129890 = 0;
  _DAT_02129874 = FUN_00888530();
  FUN_016f3654(&LAB_0188c260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 899 ; VA 0x004b7c40 ; FUN_004b7c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7c40(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec15a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_ConvertToSmooth_0212a1ec,1,1,0);
  _DAT_021299e8 = 0xaf4120;
  uStack_8 = 0;
  _DAT_021299b0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(void),0>::vftable;
  _DAT_021299f0 = 0;
  _DAT_021299d4 = FUN_00888530();
  FUN_016f3654(&LAB_0188c270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 900 ; VA 0x004b7cf0 ; FUN_004b7cf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7cf0(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_AutowedgeCell_0212a118,0,1,0);
  _DAT_02129678 = 0x573f40;
  _DAT_02129640 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MegaClusterInstance,bool___cdecl(int,int,int),3>::
       vftable;
  _DAT_02129680 = 0;
  DAT_02129684 = 0;
  DAT_02129688 = 0;
  DAT_0212968c = 0;
  uStack_8 = 3;
  FUN_00af7890(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8);
  FUN_016f3654(&LAB_0188c280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 901 ; VA 0x004b7dd0 ; FUN_004b7dd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7dd0(void)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined8 uStack_f4;
  undefined4 uStack_ec;
  code *pcStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec1fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  pcStack_2c = FUN_006a6f60;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  FUN_009cb790(uVar2,s_AutowedgeCells_0212a128,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021296c8 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02129690 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3int16),1>::
       vftable;
  _DAT_021296d0 = 0;
  DAT_021296d4 = (undefined8 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021296b4 = FUN_00888530();
  puVar1 = DAT_021296d4;
  if (DAT_021296d4 == (undefined8 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_00b33940();
    iStack_f8 = 0;
    uStack_f4 = *puVar1;
    uStack_ec = *(undefined4 *)(puVar1 + 1);
    iStack_f8 = FUN_006312a0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_00b33940();
  uVar3 = FUN_0086e3d0(s_region_02127980);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188c2d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 902 ; VA 0x004b7fa0 ; FUN_004b7fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7fa0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec238;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_CellCenterToWorld_0212a14c,0,uStack_1c,0);
  _DAT_02129760 = 0xaf3a10;
  _DAT_02129728 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_G3D::Vector3___cdecl(int,int,int),3>::
       vftable;
  _DAT_02129768 = 0;
  DAT_0212976c = 0;
  DAT_02129770 = 0;
  DAT_02129774 = 0;
  uStack_8 = 3;
  FUN_00af48e0(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8);
  FUN_016f3654(&LAB_0188c2f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 903 ; VA 0x004b8080 ; FUN_004b8080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8080(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec278;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_CellCornerToWorld_0212a138,0,uStack_1c,0);
  _DAT_02129710 = 0xaf3a70;
  _DAT_021296d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_G3D::Vector3___cdecl(int,int,int),3>::
       vftable;
  _DAT_02129718 = 0;
  DAT_0212971c = 0;
  DAT_02129720 = 0;
  DAT_02129724 = 0;
  uStack_8 = 3;
  FUN_00af48e0(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8);
  FUN_016f3654(&LAB_0188c340);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 904 ; VA 0x004b8160 ; FUN_004b8160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8160(void)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined8 uStack_f4;
  undefined4 uStack_ec;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec2dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00af4290;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  FUN_009cb790(uVar2,s_CopyRegion_0212a1b0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02129918 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_021298e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_RBX::Region3int16),1>
       ::vftable;
  _DAT_02129920 = 0;
  DAT_02129924 = (undefined8 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02129904 = FUN_0088cdc0();
  puVar1 = DAT_02129924;
  if (DAT_02129924 == (undefined8 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_00b33940();
    iStack_f8 = 0;
    uStack_f4 = *puVar1;
    uStack_ec = *(undefined4 *)(puVar1 + 1);
    iStack_f8 = FUN_006312a0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_00b33940();
  uVar3 = FUN_0086e3d0(s_region_02127980);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188c390);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 905 ; VA 0x004b8320 ; FUN_004b8320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8320(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec2fa;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_CountCells_0212a1a4,0,uStack_1c,0);
  _DAT_021298d0 = 0xaf4310;
  uStack_8 = 0;
  _DAT_02129898 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MegaClusterInstance,int___cdecl(void),0>::vftable;
  _DAT_021298d8 = 0;
  _DAT_021298bc = FUN_0088c8c0();
  FUN_016f3654(&LAB_0188c3b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 906 ; VA 0x004b83d0 ; FUN_004b83d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b83d0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec338;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_FillBall_0212a350,0,uStack_1c,0);
  _DAT_02129d78 = 0xaf9e80;
  _DAT_02129d40 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_G3D::Vector3,float,enum_RBX::PartMaterial),3>
       ::vftable;
  _DAT_02129d80 = 0;
  DAT_02129d84 = 0;
  DAT_02129d88 = 0;
  DAT_02129d8c = 0;
  uStack_8 = 3;
  FUN_00af7370(s_center_0212a348,s_radius_0211fcac,s_material_0212a0d0);
  FUN_016f3654(&LAB_0188c3c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 907 ; VA 0x004b84b0 ; FUN_004b84b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b84b0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec378;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_FillBlock_0212a32c,0,uStack_1c,0);
  _DAT_02129cd0 = 0xafa320;
  _DAT_02129c98 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_G3D::CoordinateFrame,class_G3D::Vector3,enum_RBX::PartMaterial),3>
       ::vftable;
  _DAT_02129cd8 = 0;
  DAT_02129cdc = 0;
  DAT_02129ce0 = 0;
  DAT_02129ce4 = 0;
  uStack_8 = 3;
  FUN_00af6200(s_cframe_0212a324,&DAT_0212a31c,s_material_0212a0d0);
  FUN_016f3654(&LAB_0188c410);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 908 ; VA 0x004b8590 ; FUN_004b8590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8590(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec3c2;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_FillCylinder_0212a338,0,uStack_1c,0);
  _DAT_02129d20 = 0xafaa00;
  _DAT_02129ce8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_G3D::CoordinateFrame,float,float,enum_RBX::PartMaterial),4>
       ::vftable;
  _DAT_02129d28 = 0;
  DAT_02129d2c = 0;
  DAT_02129d30 = 0;
  DAT_02129d34 = 0;
  DAT_02129d38 = 0;
  uStack_8 = 4;
  FUN_00af5e10(s_cframe_0212a324,s_height_021191e0,s_radius_0211fcac,s_material_0212a0d0);
  FUN_016f3654(&LAB_0188c460);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 909 ; VA 0x004b8680 ; FUN_004b8680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8680(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec3f8;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_FillRegion_0212a310,0,uStack_1c,0);
  _DAT_02129c80 = 0xafafd0;
  _DAT_02129c48 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3,float,enum_RBX::PartMaterial),3>
       ::vftable;
  _DAT_02129c88 = 0;
  DAT_02129c8c = 0;
  DAT_02129c90 = 0;
  DAT_02129c94 = 0;
  uStack_8 = 3;
  FUN_00af6c70(s_region_02127980,s_resolution_0212a1fc,s_material_0212a0d0);
  FUN_016f3654(&LAB_0188c4c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 910 ; VA 0x004b8760 ; FUN_004b8760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8760(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec438;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_FillWedge_0212a35c,0,uStack_1c,0);
  _DAT_02129dc8 = 0xafb160;
  _DAT_02129d90 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_G3D::CoordinateFrame,class_G3D::Vector3,enum_RBX::PartMaterial),3>
       ::vftable;
  _DAT_02129dd0 = 0;
  DAT_02129dd4 = 0;
  DAT_02129dd8 = 0;
  DAT_02129ddc = 0;
  uStack_8 = 3;
  FUN_00af6200(s_cframe_0212a324,&DAT_0212a31c,s_material_0212a0d0);
  FUN_016f3654(&LAB_0188c510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 911 ; VA 0x004b8840 ; FUN_004b8840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8840(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec478;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_GetCell_0212a0b4,0,1,0);
  _DAT_021294c8 = 0xafbcc0;
  _DAT_02129490 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(int,int,int),3>
       ::vftable;
  _DAT_021294d0 = 0;
  DAT_021294d4 = 0;
  DAT_021294d8 = 0;
  DAT_021294dc = 0;
  uStack_8 = 3;
  FUN_00af43d0(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8);
  FUN_016f3654(&LAB_0188c560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 912 ; VA 0x004b8920 ; FUN_004b8920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8920(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 auStack_f4 [50];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec4dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00afc050;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_GetMaterialColor_0212a3f8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02129fc0 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02129f88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_G3D::Color3___cdecl(enum_RBX::PartMaterial),1>
       ::vftable;
  _DAT_02129fc8 = 0;
  DAT_02129fcc = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02129fac = FUN_0088d050();
  puVar3 = DAT_02129fcc;
  if (DAT_02129fcc == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar3 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = thunk_FUN_00896e70();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar3;
    iStack_f8 = FUN_008973b0();
    puVar3 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00896e70();
  uVar2 = FUN_0086e3d0(s_material_0212a0d0);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188c5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 913 ; VA 0x004b8ad0 ; FUN_004b8ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8ad0(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_GetWaterCell_0212a0f0,0,1,0);
  _DAT_021295d0 = 0xafc740;
  _DAT_02129598 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(int,int,int),3>
       ::vftable;
  _DAT_021295d8 = 0;
  DAT_021295dc = 0;
  DAT_021295e0 = 0;
  DAT_021295e4 = 0;
  uStack_8 = 3;
  FUN_00af43d0(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8);
  FUN_016f3654(&LAB_0188c5d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 914 ; VA 0x004b8bb0 ; FUN_004b8bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8bb0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec558;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_PasteRegion_0212a1d4,0,uStack_1c,0);
  _DAT_02129960 = 0xafcea0;
  _DAT_02129928 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::Vector3int16,bool),3>
       ::vftable;
  _DAT_02129968 = 0;
  _DAT_0212996c = 0;
  _DAT_02129970 = 0;
  _DAT_02129974 = 0;
  uStack_8 = 3;
  FUN_00af59f0(s_region_02127980,s_corner_0212a1cc,s_pasteEmptyCells_0212a1bc);
  FUN_016f3654(&LAB_0188c620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 915 ; VA 0x004b8c90 ; FUN_004b8c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8c90(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec58e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_ReadVoxels_0212a208,0,uStack_1c,0);
  _DAT_02129a30 = 0;
  _DAT_021299f8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_RBX::Region3,float),2>
       ::vftable;
  _DAT_02129a38 = 0;
  DAT_02129a3c = 0;
  DAT_02129a40 = 0;
  uStack_8 = 2;
  FUN_00af46e0();
  _DAT_02129a48 = 0xafcf60;
  _DAT_021299f8 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::MegaClusterInstance,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_RBX::Region3,float),2>
       ::vftable;
  _DAT_02129a50 = 0;
  _DAT_02129a2c = 1;
  FUN_016f3654(&LAB_0188c630);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 916 ; VA 0x004b8da0 ; FUN_004b8da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8da0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec5d2;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_ReplaceMaterial_0212a388,0,uStack_1c,0);
  _DAT_02129e18 = 0xafd530;
  _DAT_02129de0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3,float,enum_RBX::PartMaterial,enum_RBX::PartMaterial),4>
       ::vftable;
  _DAT_02129e20 = 0;
  DAT_02129e24 = 0;
  DAT_02129e28 = 0;
  DAT_02129e2c = 0;
  DAT_02129e30 = 0;
  uStack_8 = 4;
  FUN_00af6880(s_region_02127980,s_resolution_0212a1fc,s_sourceMaterial_0212a378,
               s_targetMaterial_0212a368);
  FUN_016f3654(&LAB_0188c670);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 917 ; VA 0x004b8e90 ; FUN_004b8e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8e90(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec626;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_SetCell_0212a0dc,0,1,0);
  _DAT_02129518 = 0xafd780;
  _DAT_021294e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(int,int,int,enum_RBX::Voxel::CellMaterial,enum_RBX::Voxel::CellBlock,enum_RBX::Voxel::CellOrientation),6>
       ::vftable;
  _DAT_02129520 = 0;
  _DAT_02129524 = 0;
  _DAT_02129528 = 0;
  _DAT_0212952c = 0;
  _DAT_02129530 = 0;
  _DAT_02129534 = 0;
  _DAT_02129538 = 0;
  uStack_8 = 6;
  FUN_00af4bf0(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8,s_material_0212a0d0,s_block_0212a0c8,
               s_orientation_0212a0bc);
  FUN_016f3654(&LAB_0188c6d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 918 ; VA 0x004b8fa0 ; FUN_004b8fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8fa0(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec662;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_SetCells_0212a0e4,0,1,0);
  _DAT_02129578 = 0xafd7f0;
  _DAT_02129540 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3int16,enum_RBX::Voxel::CellMaterial,enum_RBX::Voxel::CellBlock,enum_RBX::Voxel::CellOrientation),4>
       ::vftable;
  _DAT_02129580 = 0;
  DAT_02129584 = 0;
  DAT_02129588 = 0;
  DAT_0212958c = 0;
  DAT_02129590 = 0;
  uStack_8 = 4;
  FUN_00af6f60(s_region_02127980,s_material_0212a0d0,s_block_0212a0c8,s_orientation_0212a0bc);
  FUN_016f3654(&LAB_0188c6e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 919 ; VA 0x004b9090 ; FUN_004b9090 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b9090(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec68e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_SetMaterialColor_0212a40c,0,uStack_1c,0);
  _DAT_0212a008 = 0xafdb90;
  _DAT_02129fd0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(enum_RBX::PartMaterial,class_G3D::Color3),2>
       ::vftable;
  _DAT_0212a010 = 0;
  DAT_0212a014 = 0;
  DAT_0212a018 = 0;
  uStack_8 = 2;
  FUN_00af7660();
  FUN_016f3654(&LAB_0188c740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 920 ; VA 0x004b9160 ; FUN_004b9160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b9160(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec6dc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_SetWaterCell_0212a108,0,1,0);
  _DAT_02129620 = 0xafe160;
  _DAT_021295e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(int,int,int,enum_RBX::Voxel::WaterCellForce,enum_RBX::Voxel::WaterCellDirection),5>
       ::vftable;
  _DAT_02129628 = 0;
  _DAT_0212962c = 0;
  _DAT_02129630 = 0;
  _DAT_02129634 = 0;
  _DAT_02129638 = 0;
  _DAT_0212963c = 0;
  uStack_8 = 5;
  FUN_00af51f0(&DAT_0212a0b0,&DAT_0212a0ac,&DAT_0212a0a8,s_force_0212a100,s_direction_02127888);
  FUN_016f3654(&LAB_0188c780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 921 ; VA 0x004b9260 ; FUN_004b9260 */

void FUN_004b9260(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00af1a20(0xafea30,0,s_WorldToCell_0212a190,s_position_0211fd1c,0,uStack_10,0);
  FUN_016f3654(&LAB_0188c790);
  return;
}



/* FUNCTION 922 ; VA 0x004b92d0 ; FUN_004b92d0 */

void FUN_004b92d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00af1a20(0xafe990,0,s_WorldToCellPreferEmpty_0212a178,s_position_0211fd1c,0,uStack_10,0);
  FUN_016f3654(&LAB_0188c7b0);
  return;
}



/* FUNCTION 923 ; VA 0x004b9340 ; FUN_004b9340 */

void FUN_004b9340(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00af1a20(0xafe9e0,0,s_WorldToCellPreferSolid_0212a160,s_position_0211fd1c,0,uStack_10,0);
  FUN_016f3654(&LAB_0188c7d0);
  return;
}



/* FUNCTION 924 ; VA 0x004b93b0 ; FUN_004b93b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b93b0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec722;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,s_WriteVoxels_0212a22c,0,uStack_1c,0);
  _DAT_02129a90 = 0;
  _DAT_02129a58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3,float,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),4>
       ::vftable;
  _DAT_02129a98 = 0;
  _DAT_02129a9c = 0;
  _DAT_02129aa0 = 0;
  _DAT_02129aa4 = 0;
  _DAT_02129aa8 = 0;
  uStack_8 = 4;
  FUN_00af64d0(s_region_02127980,s_resolution_0212a1fc,s_materials_0212a220,s_occupancy_0212a214);
  _DAT_02129ab0 = 0xafee00;
  _DAT_02129a58 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::MegaClusterInstance,void___cdecl(class_RBX::Region3,float,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),4>
       ::vftable;
  _DAT_02129ab8 = 0;
  _DAT_02129a8c = 1;
  FUN_016f3654(&LAB_0188c7f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 925 ; VA 0x004b94e0 ; FUN_004b94e0 */

void FUN_004b94e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec73a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://terrain/materials.json",0x21);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d66a44);
  FUN_016f3654(&LAB_0188c800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 926 ; VA 0x004b9540 ; FUN_004b9540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b9540(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ec76c;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xafc2a0;
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::MegaClusterInstance,class_RBX::Region3int16>::
              GetImpl<class_RBX::Region3int16_const_(__thiscall_RBX::MegaClusterInstance::*)(void)const_>
              ::vftable;
    puVar3[4] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b33940();
  FUN_009ca670(uVar2,uVar4,s_MaxExtents_0212a09c,&DAT_021197d4,uStack_30,0,0,0x15,0,0,0);
  DAT_02129458 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Region3int16>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212948c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212947c = _DAT_0212947c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02129458[2])();
    if (cVar1 != '\0') {
      _DAT_0212947c = _DAT_0212947c & 0xfffffff3;
    }
  }
  DAT_02129458 = RBX::Reflection::
                 PropDescriptor<class_RBX::MegaClusterInstance,class_RBX::Region3int16>::vftable;
  FUN_016f3654(&LAB_0188c900);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 927 ; VA 0x004b9730 ; FUN_004b9730 */

void FUN_004b9730(void)

{
  FUN_00aff560(s_Rotation_0212a764,&DAT_021197d4,0xb019c8,0,0xb019c0,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_0188c9a0);
  return;
}



/* FUNCTION 928 ; VA 0x004b9870 ; FUN_004b9870 */

void FUN_004b9870(void)

{
  FUN_00aff4d0(s_AssemblyAngularVelocity_0212a7f4,PTR_DAT_01d66bdc,0xb06ae0,0,0xb0cf80,0,0,0,0,0x15,
               0);
  FUN_016f3654(&LAB_0188c9e0);
  return;
}



/* FUNCTION 929 ; VA 0x004b99e0 ; FUN_004b99e0 */

void FUN_004b99e0(void)

{
  FUN_00aff4d0(s_AssemblyLinearVelocity_0212a7dc,PTR_DAT_01d66bdc,0xb06cb0,0,0xb0d1e0,0,0,0,0,0x15,0
              );
  FUN_016f3654(&LAB_0188ca20);
  return;
}



/* FUNCTION 930 ; VA 0x004b9b50 ; FUN_004b9b50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b9b50(void)

{
  undefined *puVar1;
  char cVar2;
  undefined4 uVar3;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = PTR_DAT_01d66bdc;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed310;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar3 = FUN_00aff8c0();
  FUN_009ca670(uVar3,&DAT_01ee40e8,s_AssemblyRootPart_0212a80c,puVar1,uStack_30,0,0,0x15,0,0,0);
  uStack_8 = 1;
  DAT_0212a708 = RBX::Reflection::RefPropDescriptor<class_RBX::PartInstance,class_RBX::PartInstance>
                 ::vftable;
  _DAT_0212a73c =
       RBX::Reflection::RefPropDescriptor<class_RBX::PartInstance,class_RBX::PartInstance>::vftable;
  DAT_0212a740 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212a740 == (undefined4 *)0x0) {
    DAT_0212a740 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0212a740 + 2) = 0xb08600;
    *DAT_0212a740 =
         RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::PartInstance*>::
         GetImpl<class_RBX::PartInstance*_(__thiscall_RBX::PartInstance::*)(void)const_>::vftable;
    DAT_0212a740[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar2 = (*(code *)DAT_0212a708[3])();
  if (cVar2 != '\0') {
    _DAT_0212a72c = _DAT_0212a72c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0212a708[2])();
  if (cVar2 != '\0') {
    _DAT_0212a72c = _DAT_0212a72c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188ca60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 931 ; VA 0x004b9cf0 ; FUN_004b9cf0 */

void FUN_004b9cf0(void)

{
  FUN_00aff3c0("BrickColor","Appearance",0xb06ff0,0,0xb01990,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_0188ca80);
  return;
}



/* FUNCTION 932 ; VA 0x004b9d80 ; FUN_004b9d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b9d80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed33c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb077e0;
    *(undefined8 *)(puVar3 + 6) = 0xb0d880;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_const&_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,s_CFrame_0212a744,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,0);
  DAT_0212a430 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212a464 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212a454 = _DAT_0212a454 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212a430[2])();
    if (cVar1 != '\0') {
      _DAT_0212a454 = _DAT_0212a454 & 0xfffffff3;
    }
  }
  DAT_0212a430 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::CoordinateFrame>
                 ::vftable;
  FUN_016f3654(&LAB_0188caa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 933 ; VA 0x004ba1a0 ; FUN_004ba1a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ba1a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed36c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb06fd0;
    *(undefined8 *)(puVar3 + 6) = 0xb0d680;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Color3uint8>::
              GetSetImpl<class_G3D::Color3uint8_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_G3D::Color3uint8)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d0f0();
  FUN_009ca670(uVar2,uVar4,"Color3uint8","Appearance",uStack_3c,0,0,0xe,0,0,0);
  DAT_01eed370 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3uint8>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eed3a4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eed394 = _DAT_01eed394 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eed370[2])();
    if (cVar1 != '\0') {
      _DAT_01eed394 = _DAT_01eed394 & 0xfffffff3;
    }
  }
  DAT_01eed370 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Color3uint8>::
                 vftable;
  FUN_016f3654(&LAB_0188cb40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 934 ; VA 0x004ba2f0 ; FUN_004ba2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ba2f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed39c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb06fb0;
    *(undefined8 *)(puVar3 + 6) = 0xb0d620;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_G3D::Color3_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,&DAT_0194ebd8,"Appearance",uStack_3c,0,0,0x15,0,0,0);
  DAT_01eed338 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eed36c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eed35c = _DAT_01eed35c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eed338[2])();
    if (cVar1 != '\0') {
      _DAT_01eed35c = _DAT_01eed35c & 0xfffffff3;
    }
  }
  DAT_01eed338 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_G3D::Color3>::vftable
  ;
  FUN_016f3654(&LAB_0188cb60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 935 ; VA 0x004ba440 ; FUN_004ba440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ba440(void)

{
  undefined *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uStack_40;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = PTR_s_Part_01d66bd8;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed3cc;
  pvStack_10 = ExceptionList;
  uStack_40 = uStack_40 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00aff8c0();
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar4 + 2) = 0xb08330;
    *(undefined8 *)(puVar4 + 6) = 0xb01941;
    *puVar4 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::PhysicalProperties>
              ::
              GetSetImpl<class_RBX::PhysicalProperties_const&_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_RBX::PhysicalProperties_const&)>
              ::vftable;
    puVar4[4] = 0;
    puVar4[8] = 0;
  }
  uStack_8 = 0;
  uVar5 = FUN_0088d2d0();
  FUN_009ca670(uVar3,uVar5,"CustomPhysicalProperties",puVar1,uStack_40,0,0,0x1f,0,0,0);
  DAT_01eed290 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::PhysicalProperties>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eed2c4 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    cVar2 = FUN_005c9300();
    if (cVar2 != '\0') {
      _DAT_01eed2b4 = _DAT_01eed2b4 & 0xffffffeb;
    }
    cVar2 = (*(code *)DAT_01eed290[2])();
    if (cVar2 != '\0') {
      _DAT_01eed2b4 = _DAT_01eed2b4 & 0xfffffff3;
    }
  }
  DAT_01eed290 = RBX::Reflection::
                 PropDescriptor<class_RBX::PartInstance,class_RBX::PhysicalProperties>::vftable;
  FUN_016f3654(&LAB_0188cb80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 936 ; VA 0x004ba660 ; FUN_004ba660 */

void FUN_004ba660(void)

{
  FUN_00aff710("DraggingV1","Behavior",0xb07800,0,0xb0dac0,0,0,0,0,2,0);
  FUN_016f3654(&LAB_0188cbc0);
  return;
}



/* FUNCTION 937 ; VA 0x004ba6f0 ; FUN_004ba6f0 */

void FUN_004ba6f0(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  code *pcStack_1c;
  undefined4 uStack_18;
  undefined *puStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x14);
  puStack_10 = &LAB_00b01939;
  uStack_c = 0;
  pcStack_1c = FUN_00b07810;
  uStack_18 = 0;
  FUN_00aff680(&DAT_0191c7b0,PTR_s_Part_01d66bd8,0xb07810,0,0xb01939,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_0188cbe0);
  return;
}



/* FUNCTION 938 ; VA 0x004ba780 ; FUN_004ba780 */

void FUN_004ba780(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  code *pcStack_1c;
  undefined4 uStack_18;
  undefined *puStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x14);
  puStack_10 = &LAB_00b01931;
  uStack_c = 0;
  pcStack_1c = FUN_00b07820;
  uStack_18 = 0;
  FUN_00aff680(&DAT_0191c7a4,PTR_s_Part_01d66bd8,0xb07820,0,0xb01931,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_0188cc00);
  return;
}



/* FUNCTION 939 ; VA 0x004ba810 ; FUN_004ba810 */

void FUN_004ba810(void)

{
  FUN_00aff680("LocalTransparencyModifier",&DAT_018dbc3c,0x9d7b20,0,0xb0dcd0,0,0,0,0,0x10,0);
  FUN_016f3654(&LAB_0188cc20);
  return;
}



/* FUNCTION 940 ; VA 0x004baa00 ; FUN_004baa00 */

void FUN_004baa00(void)

{
  FUN_00aff710("NetworkIsSleeping",&DAT_018dbc3c,0xb07c90,0,0xb0de10,0,0,0,0,2,0);
  FUN_016f3654(&LAB_0188cc80);
  return;
}



/* FUNCTION 941 ; VA 0x004baa90 ; FUN_004baa90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004baa90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed3fc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb07ca0;
    *(undefined8 *)(puVar3 + 6) = 0xb0de70;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::SystemAddress>::
              GetSetImpl<class_RBX::SystemAddress_const_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(class_RBX::SystemAddress)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d550();
  FUN_009ca670(uVar2,uVar4,"NetworkOwnerV3",&DAT_018dbc3c,uStack_3c,0,0,2,0,0,0);
  DAT_01eed858 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SystemAddress>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eed88c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eed87c = _DAT_01eed87c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eed858[2])();
    if (cVar1 != '\0') {
      _DAT_01eed87c = _DAT_01eed87c & 0xfffffff3;
    }
  }
  DAT_01eed858 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::SystemAddress>::
                 vftable;
  FUN_016f3654(&LAB_0188cca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 942 ; VA 0x004babe0 ; FUN_004babe0 */

void FUN_004babe0(void)

{
  FUN_00aff560(s_Orientation_0212a770,&DAT_021197d4,0xb019d8,0,0xb019d0,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_0188ccc0);
  return;
}



/* FUNCTION 943 ; VA 0x004bac70 ; FUN_004bac70 */

void FUN_004bac70(void)

{
  FUN_00aff5f0(s_Position_0212a74c,&DAT_021197d4,0xb019b8,0,0xb019b0,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_0188cce0);
  return;
}



/* FUNCTION 944 ; VA 0x004bb080 ; FUN_004bb080 */

void FUN_004bb080(void)

{
  FUN_00aff5f0(&DAT_0194ea78,PTR_s_Part_01d66bd8,0xb08320,0,0xb019e0,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_0188cd80);
  return;
}



/* FUNCTION 945 ; VA 0x004bb120 ; FUN_004bb120 */

void FUN_004bb120(void)

{
  FUN_00aff4d0(&DAT_018dbc90,PTR_s_Part_01d66bd8,0xb082f0,0,0xb019a8,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_0188cda0);
  return;
}



/* FUNCTION 946 ; VA 0x004bb460 ; FUN_004bb460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bb460(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed424;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896e70();
  uVar3 = FUN_00aff8c0();
  FUN_009ca670(uVar3,uVar2,&DAT_018db7a4,"Appearance",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01eed418 = RBX::Reflection::EnumPropDescriptor<class_RBX::PartInstance,enum_RBX::PartMaterial>
                 ::vftable;
  _DAT_01eed44c = uVar2;
  DAT_01eed450 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01eed450 == (undefined4 *)0x0) {
    DAT_01eed450 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01eed450 + 2) = 0xb084e0;
    *(undefined8 *)(DAT_01eed450 + 6) = 0xb01961;
    *DAT_01eed450 =
         RBX::Reflection::PropDescriptor<class_RBX::PartInstance,enum_RBX::PartMaterial>::
         GetSetImpl<enum_RBX::PartMaterial_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::PartMaterial)>
         ::vftable;
    DAT_01eed450[4] = 0;
    DAT_01eed450[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01eed454 = FUN_00896e70();
  cVar1 = (*(code *)DAT_01eed418[3])();
  if (cVar1 != '\0') {
    _DAT_01eed43c = _DAT_01eed43c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01eed418[2])();
  if (cVar1 != '\0') {
    _DAT_01eed43c = _DAT_01eed43c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188ce20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 947 ; VA 0x004bb830 ; FUN_004bb830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bb830(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed43a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"breakJoints",0,CONCAT44(&DAT_01eeccf8,uStack_1c),0);
  _DAT_01eecd78 = 0xb01959;
  uStack_8 = 0;
  _DAT_01eecd40 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,void___cdecl(void),0>::vftable;
  _DAT_01eecd80 = 0;
  _DAT_01eecd64 = FUN_00888530();
  FUN_016f3654(&LAB_0188ce40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 948 ; VA 0x004bb8e0 ; FUN_004bb8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bb8e0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00b00c70(0xb07f50,0,"StoppedTouching","otherPart",0,CONCAT44(&DAT_01eed9f0,uStack_10),0);
  _DAT_01eeda38 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::LocalTouchedSignal,class_RBX::PartInstance::LocalTouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188ce50);
  return;
}



/* FUNCTION 949 ; VA 0x004bb960 ; FUN_004bb960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bb960(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00b00db0(0x9b5540,0,"touched","otherPart",0,CONCAT44(&DAT_01eed960,uStack_10),0);
  _DAT_01eed9a8 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::TouchedSignal,class_RBX::PartInstance::TouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188ce60);
  return;
}



/* FUNCTION 950 ; VA 0x004bb9e0 ; FUN_004bb9e0 */

void FUN_004bb9e0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b008e0(0xb026e0,0,"ApplyAngularImpulse","impulse",0,uStack_10,0);
  FUN_016f3654(&LAB_0188ce70);
  return;
}



/* FUNCTION 951 ; VA 0x004bba50 ; FUN_004bba50 */

void FUN_004bba50(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b008e0(0xb027e0,0,"ApplyImpulse","impulse",0,uStack_10,0);
  FUN_016f3654(&LAB_0188ce90);
  return;
}



/* FUNCTION 952 ; VA 0x004bbac0 ; FUN_004bbac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bbac0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed46e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"ApplyImpulseAtPosition",0,uStack_1c,0);
  _DAT_01eed7f8 = 0xb028e0;
  _DAT_01eed7c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,void___cdecl(class_G3D::Vector3,class_G3D::Vector3),2>
       ::vftable;
  _DAT_01eed800 = 0;
  DAT_01eed804 = 0;
  DAT_01eed808 = 0;
  uStack_8 = 2;
  FUN_00b045d0();
  FUN_016f3654(&LAB_0188ceb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 953 ; VA 0x004bbb90 ; FUN_004bbb90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bbb90(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed4cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00b02c50;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  FUN_009cb790(uVar2,"CanCollideWith",0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01eedba8 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_01eedb70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_01eedbb0 = 0;
  DAT_01eedbb4 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01eedb94 = FUN_0088daf0();
  puVar4 = DAT_01eedbb4;
  if (DAT_01eedbb4 == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(&DAT_018ddab8);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188cef0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 954 ; VA 0x004bbd70 ; FUN_004bbd70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bbd70(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed4ea;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"CanSetNetworkOwnership",0,uStack_1c,0);
  _DAT_01eed168 = 0xb02f10;
  uStack_8 = 0;
  _DAT_01eed130 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01eed170 = 0;
  _DAT_01eed154 = FUN_0088cbe0();
  FUN_016f3654(&LAB_0188cf40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 955 ; VA 0x004bbe20 ; FUN_004bbe20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bbe20(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed51e;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"resize",0,CONCAT44(&DAT_01eed690,uStack_1c),0);
  _DAT_01eed718 = 0xb019f0;
  _DAT_01eed6e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,bool___cdecl(enum_RBX::NormalId,int),2>::vftable;
  _DAT_01eed720 = 0;
  DAT_01eed724 = 0;
  DAT_01eed728 = 0;
  uStack_8 = 2;
  FUN_00b04810();
  FUN_016f3654(&LAB_0188cf50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 956 ; VA 0x004bbef0 ; FUN_004bbef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bbef0(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed57c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00b07020;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  FUN_009cb790(uVar2,"GetConnectedParts",0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01eecf28 = CONCAT44(uStack_28,pcStack_2c);
  uStack_8 = 0;
  _DAT_01eecef0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(bool),1>
       ::vftable;
  _DAT_01eecf30 = 0;
  DAT_01eecf34 = (undefined *)FUN_01674e20(1);
  if (DAT_01eecf34 == (undefined *)0x0) {
    DAT_01eecf34 = (undefined *)0x0;
  }
  else {
    *DAT_01eecf34 = 0;
  }
  uStack_8._0_1_ = 1;
  _DAT_01eecf14 = FUN_0088cc80();
  puVar1 = DAT_01eecf34;
  if (DAT_01eecf34 == (undefined *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088daf0();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar1;
    iStack_f8 = FUN_005c9ef0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0("recursive");
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188cf90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 957 ; VA 0x004bc0b0 ; FUN_004bc0b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc0b0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed59a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetJoints",0,uStack_1c,0);
  _DAT_01eecfb8 = 0xb07860;
  uStack_8 = 0;
  _DAT_01eecf80 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01eecfc0 = 0;
  _DAT_01eecfa4 = FUN_0088cc80();
  FUN_016f3654(&LAB_0188cfb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 958 ; VA 0x004bc160 ; FUN_004bc160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc160(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed5ba;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetMass",0,uStack_1c,0);
  _DAT_01eece50 = 0xb07bf0;
  uStack_8 = 0;
  _DAT_01eece18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,float___cdecl(void)const_,0>::vftable;
  _DAT_01eece58 = 0;
  _DAT_01eece3c = FUN_0088c960();
  FUN_016f3654(&LAB_0188cfc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 959 ; VA 0x004bc210 ; FUN_004bc210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc210(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed5da;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"getMass",0,uStack_1c,0);
  _DAT_01eece98 = 0xb07bf0;
  uStack_8 = 0;
  _DAT_01eece60 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,float___cdecl(void)const_,0>::vftable;
  _DAT_01eecea0 = 0;
  _DAT_01eece84 = FUN_0088c960();
  FUN_016f3654(&LAB_0188cfd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 960 ; VA 0x004bc2c0 ; FUN_004bc2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc2c0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed5fa;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetNetworkOwner",0,uStack_1c,0);
  _DAT_01eed090 = 0xb07cc0;
  uStack_8 = 0;
  _DAT_01eed058 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_01eed098 = 0;
  _DAT_01eed07c = FUN_0088cdc0();
  FUN_016f3654(&LAB_0188cfe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 961 ; VA 0x004bc370 ; FUN_004bc370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc370(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed61a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetNetworkOwnershipAuto",0,uStack_1c,0);
  _DAT_01eed120 = 0xb07e80;
  uStack_8 = 0;
  _DAT_01eed0e8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,bool___cdecl(void),0>::vftable;
  _DAT_01eed128 = 0;
  _DAT_01eed10c = FUN_0088daf0();
  FUN_016f3654(&LAB_0188cff0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 962 ; VA 0x004bc420 ; FUN_004bc420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc420(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed63a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetRenderCFrame",0,1,0);
  _DAT_01eed000 = 0xb084b0;
  uStack_8 = 0;
  _DAT_01eecfc8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_G3D::CoordinateFrame___cdecl(void),0>::vftable;
  _DAT_01eed008 = 0;
  _DAT_01eecfec = FUN_00b00260();
  FUN_016f3654(&LAB_0188d000);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 963 ; VA 0x004bc4d0 ; FUN_004bc4d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc4d0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed65a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetRootPart",0,uStack_1c,0);
  _DAT_01eecf70 = 0xb08550;
  uStack_8 = 0;
  _DAT_01eecf38 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_01eecf78 = 0;
  _DAT_01eecf5c = FUN_0088cdc0();
  FUN_016f3654(&LAB_0188d010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 964 ; VA 0x004bc580 ; FUN_004bc580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc580(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed67a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"IsGrounded",0,uStack_1c,0);
  _DAT_01eecee0 = 0xb09460;
  uStack_8 = 0;
  _DAT_01eecea8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,bool___cdecl(void),0>::vftable;
  _DAT_01eecee8 = 0;
  _DAT_01eececc = FUN_0088daf0();
  FUN_016f3654(&LAB_0188d020);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 965 ; VA 0x004bc630 ; FUN_004bc630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc630(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed69a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"MakeJoints",0,uStack_1c,0);
  _DAT_01eecdc0 = 0xb05fb0;
  uStack_8 = 0;
  _DAT_01eecd88 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,void___cdecl(void),0>::vftable;
  _DAT_01eecdc8 = 0;
  _DAT_01eecdac = FUN_00888530();
  FUN_016f3654(&LAB_0188d030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 966 ; VA 0x004bc6e0 ; FUN_004bc6e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc6e0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed6ba;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"makeJoints",0,uStack_1c,0);
  _DAT_01eece08 = 0xb05fb0;
  uStack_8 = 0;
  _DAT_01eecdd0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,void___cdecl(void),0>::vftable;
  _DAT_01eece10 = 0;
  _DAT_01eecdf4 = FUN_00888530();
  FUN_016f3654(&LAB_0188d040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 967 ; VA 0x004bc790 ; FUN_004bc790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc790(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed6ee;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"Resize",0,uStack_1c,0);
  _DAT_01eed6c8 = 0xb019f0;
  _DAT_01eed690 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,bool___cdecl(enum_RBX::NormalId,int),2>::vftable;
  _DAT_01eed6d0 = 0;
  DAT_01eed6d4 = 0;
  DAT_01eed6d8 = 0;
  uStack_8 = 2;
  FUN_00b04810();
  FUN_016f3654(&LAB_0188d050);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 968 ; VA 0x004bc860 ; FUN_004bc860 */

void FUN_004bc860(void)

{
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b006e0(0xb0e090,0,"SetNetworkOwner","playerInstance",0,0,0,uStack_1c,0);
  FUN_016f3654(&LAB_0188d090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 969 ; VA 0x004bc920 ; FUN_004bc920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bc920(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed70a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"SetNetworkOwnershipAuto",0,uStack_1c,0);
  _DAT_01eed0d8 = 0xb0e450;
  uStack_8 = 0;
  _DAT_01eed0a0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,void___cdecl(void),0>::vftable;
  _DAT_01eed0e0 = 0;
  _DAT_01eed0c4 = FUN_00888530();
  FUN_016f3654(&LAB_0188d0e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 970 ; VA 0x004bc9d0 ; FUN_004bc9d0 */

void FUN_004bc9d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b00a70(0xb0fb10,0,"SubtractAsync","parts","collisionfidelity","renderFidelity",0,0,0,
               uStack_10,0);
  FUN_016f3654(&LAB_0188d0f0);
  return;
}



/* FUNCTION 971 ; VA 0x004bca60 ; FUN_004bca60 */

void FUN_004bca60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b00a70(0xb0fcf0,0,"UnionAsync","parts","collisionfidelity","renderFidelity",0,0,0,uStack_10,
               0);
  FUN_016f3654(&LAB_0188d100);
  return;
}



/* FUNCTION 972 ; VA 0x004bcaf0 ; FUN_004bcaf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcaf0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed72a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"BreakJoints",0,uStack_1c,0);
  _DAT_01eecd30 = 0xb01959;
  uStack_8 = 0;
  _DAT_01eeccf8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PartInstance,void___cdecl(void),0>::vftable;
  _DAT_01eecd38 = 0;
  _DAT_01eecd1c = FUN_00888530();
  FUN_016f3654(&LAB_0188d110);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 973 ; VA 0x004bcba0 ; FUN_004bcba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcba0(void)

{
  FUN_00b00c70(0xb07f80,0,"LocalSimulationTouched",&DAT_018ddab8,0,0,0,0);
  _DAT_01eed918 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::LocalTouchedSignal,class_RBX::PartInstance::LocalTouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188d120);
  return;
}



/* FUNCTION 974 ; VA 0x004bcc10 ; FUN_004bcc10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcc10(void)

{
  undefined4 uVar1;
  undefined auStack_114 [216];
  uint uStack_3c;
  undefined4 uStack_38;
  code *pcStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed763;
  pvStack_10 = ExceptionList;
  pcStack_2c = FUN_00554e30;
  uStack_28 = 0;
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb970(uVar1,"NetworkOwnerChanged",3,CONCAT44(uStack_38,uStack_3c),0);
  _DAT_01eed8c8 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_01eed8d0 = 0;
  iStack_8 = 0;
  _DAT_01eed890 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(class_RBX::SystemAddress),class_rbx::remote_signal<void___cdecl(class_RBX::SystemAddress)>,class_rbx::remote_signal<void___cdecl(class_RBX::SystemAddress)>*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_0086e3d0("systemAddress");
  FUN_0088d550();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_114,&uStack_3c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_01eed8b8 = uStack_1c;
  _DAT_01eed8bc = uStack_18;
  _DAT_01eed8c0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_114,0xd8,1,FUN_00688b10);
  _DAT_01eed890 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::PartInstance,void___cdecl(class_RBX::SystemAddress),class_rbx::remote_signal<void___cdecl(class_RBX::SystemAddress)>,class_rbx::remote_signal<void___cdecl(class_RBX::SystemAddress)>*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  _DAT_01eed8d8 = 0;
  _DAT_01eed8dc = 0;
  FUN_016f3654(&LAB_0188d130);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 975 ; VA 0x004bcd90 ; FUN_004bcd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcd90(void)

{
  undefined4 uVar1;
  uint uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_28 = uStack_28 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb970(uVar1,"OutfitChanged",0,uStack_28,0);
  _DAT_01eedab8 = 0xb07fb0;
  _DAT_01eedac0 = 0;
  _DAT_01eeda80 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_01eedaa8 = 0;
  _DAT_01eedaac = 0;
  _DAT_01eedab0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_01eeda80 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188d140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 976 ; VA 0x004bcea0 ; FUN_004bcea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcea0(void)

{
  FUN_00b00db0(0xb07fe0,0,"TouchEnded","otherPart",0,0,0,0);
  _DAT_01eed9f0 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::TouchedSignal,class_RBX::PartInstance::TouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188d150);
  return;
}



/* FUNCTION 977 ; VA 0x004bcf10 ; FUN_004bcf10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcf10(void)

{
  FUN_00b00db0(0x9b5540,0,"Touched","otherPart",0,0,0,0);
  _DAT_01eed960 =
       RBX::Reflection::
       EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::TouchedSignal,class_RBX::PartInstance::TouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188d160);
  return;
}



/* FUNCTION 978 ; VA 0x004bcf80 ; FUN_004bcf80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bcf80(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed77a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00aff8c0();
  FUN_009cb790(uVar1,"GetTouchingParts",0,uStack_1c,0);
  _DAT_01eed768 = 0xa3d6e0;
  uStack_8 = 0;
  _DAT_01eed730 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PartInstance,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01eed770 = 0;
  _DAT_01eed754 = FUN_0088cc80();
  FUN_016f3654(&LAB_0188d170);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 979 ; VA 0x004bd090 ; FUN_004bd090 */

void FUN_004bd090(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  code *pcStack_1c;
  undefined4 uStack_18;
  undefined *puStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_2c,&DAT_01eed3a8,0x15);
  puStack_10 = &LAB_00b01990;
  uStack_c = 0;
  pcStack_1c = FUN_00b06ff0;
  uStack_18 = 0;
  FUN_00aff3c0("brickColor","Appearance",0xb06ff0,0,0xb01990,0,*puVar1,puVar1[1],puVar1[2],puVar1[3]
               ,0);
  FUN_016f3654(&LAB_0188d220);
  return;
}



/* FUNCTION 980 ; VA 0x004bd2b0 ; FUN_004bd2b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bd2b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed7ac;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aff8c0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb019a0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::Faces>::
              GetImpl<class_RBX::Faces_(__thiscall_RBX::PartInstance::*)(void)const_>::vftable;
    puVar3[4] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d230();
  FUN_009ca670(uVar2,uVar4,"ResizeableFaces","Behavior",uStack_30,0,0,0x15,0,0,0);
  DAT_01eed620 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Faces>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eed654 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eed644 = _DAT_01eed644 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eed620[2])();
    if (cVar1 != '\0') {
      _DAT_01eed644 = _DAT_01eed644 & 0xfffffff3;
    }
  }
  DAT_01eed620 = RBX::Reflection::PropDescriptor<class_RBX::PartInstance,class_RBX::Faces>::vftable;
  FUN_016f3654(&LAB_0188d280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 981 ; VA 0x004bd4b0 ; FUN_004bd4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bd4b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed7d4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b0f780();
  uVar3 = FUN_00aff8c0();
  FUN_009ca670(uVar3,uVar2,"NetworkOwnershipRule","Behavior",uStack_3c,0,0,2,0,0,1);
  uStack_8 = 0;
  DAT_01eed490 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PartInstance,enum_RBX::NetworkOwnership>::vftable;
  _DAT_01eed4c4 = uVar2;
  DAT_01eed4c8 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01eed4c8 == (undefined4 *)0x0) {
    DAT_01eed4c8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01eed4c8 + 2) = 0xb07f40;
    *(undefined8 *)(DAT_01eed4c8 + 6) = 0xb0e550;
    *DAT_01eed4c8 =
         RBX::Reflection::PropDescriptor<class_RBX::PartInstance,enum_RBX::NetworkOwnership>::
         GetSetImpl<enum_RBX::NetworkOwnership_(__thiscall_RBX::PartInstance::*)(void)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NetworkOwnership)>
         ::vftable;
    DAT_01eed4c8[4] = 0;
    DAT_01eed4c8[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01eed4cc = FUN_00b0f780();
  cVar1 = (*(code *)DAT_01eed490[3])();
  if (cVar1 != '\0') {
    _DAT_01eed4b4 = _DAT_01eed4b4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01eed490[2])();
  if (cVar1 != '\0') {
    _DAT_01eed4b4 = _DAT_01eed4b4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188d2c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 982 ; VA 0x004bd830 ; FUN_004bd830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bd830(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("PromptBundlePurchase",0x14);
  _DAT_01eee1b0 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 983 ; VA 0x004bd990 ; FUN_004bd990 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bd990(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef25a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_00f50070(uVar1,s_ProcessReceipt_0212bf9c,uStack_1c,0,0);
  uStack_8 = 0;
  _DAT_0212b7c8 =
       RBX::Reflection::
       BoundAsyncCallbackDesc<class_RBX::MarketplaceService,enum_RBX::MarketplaceService::ProductPurchaseDecision___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
       ::vftable;
  _DAT_0212b800 = 0x1b0;
  _DAT_0212b808 = FUN_00b2e110;
  _DAT_0212b80c = 0;
  _DAT_0212b7ec = FUN_00b319a0();
  uVar1 = FUN_008881d0();
  uVar2 = FUN_0086e3d0(s_receiptInfo_0212bf90);
  FUN_00888aa0(uVar2,uVar1);
  FUN_016f3654(&LAB_0188d300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 984 ; VA 0x004bda60 ; FUN_004bda60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bda60(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef293;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_ClientLuaDialogRequested_0212bd0c,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212b23c = 0x194;
  iStack_8 = 0;
  _DAT_0212b208 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_arguments_0212bd00);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212b230 = uStack_1c;
  _DAT_0212b234 = uStack_18;
  _DAT_0212b238 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0212b208 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212b240 = 0;
  _DAT_0212b244 = 1;
  FUN_016f3654(&LAB_0188d310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 985 ; VA 0x004bdcb0 ; FUN_004bdcb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bdcb0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef2d9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_NativePurchaseFinished_0212bbbc,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212aeb4 = 0x120;
  iStack_8 = 0;
  _DAT_0212ae80 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_productId_0212b810);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_wasPurchased_0212bb04);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0212aea8 = uStack_1c;
  _DAT_0212aeac = uStack_18;
  _DAT_0212aeb0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_0212ae80 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212aeb8 = 0;
  _DAT_0212aebc = 1;
  FUN_016f3654(&LAB_0188d350);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 986 ; VA 0x004bdeb0 ; FUN_004bdeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bdeb0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef313;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_PromptPremiumPurchaseRequested_0212be80,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212b5ac = 0x1f8;
  iStack_8 = 0;
  _DAT_0212b578 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212b5a0 = uStack_1c;
  _DAT_0212b5a4 = uStack_18;
  _DAT_0212b5a8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0212b578 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212b5b0 = 0;
  _DAT_0212b5b4 = 1;
  FUN_016f3654(&LAB_0188d370);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 987 ; VA 0x004be010 ; FUN_004be010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004be010(void)

{
  undefined4 uVar1;
  undefined auStack_390 [864];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef364;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_ThirdPartyPurchaseFinished_0212bc10,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212af84 = 0x130;
  iStack_8 = 0;
  _DAT_0212af50 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_productId_0212b810);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_receipt_0212bc08);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_wasPurchased_0212bb04);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_390,&uStack_30,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_0212af78 = uStack_1c;
  _DAT_0212af7c = uStack_18;
  _DAT_0212af80 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_390,0xd8,4,FUN_00688b10);
  _DAT_0212af50 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212af88 = 0;
  _DAT_0212af8c = 1;
  FUN_016f3654(&LAB_0188d380);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 988 ; VA 0x004be1e0 ; FUN_004be1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004be1e0(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef39e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_AssetTypePurchased_0212b8ec,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212a9dc = 0x1a4;
  iStack_8 = 0;
  _DAT_0212a9a8 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_assetType_0212b8c4);
  thunk_FUN_00b317b0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212a9d0 = uStack_1c;
  _DAT_0212a9d4 = uStack_18;
  _DAT_0212a9d8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_0212a9a8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212a9e0 = 0;
  _DAT_0212a9e4 = 0;
  FUN_016f3654(&LAB_0188d390);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 989 ; VA 0x004be370 ; FUN_004be370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004be370(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef3e9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_ClientPurchaseSuccess_0212b9c0,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212ab6c = 0x184;
  iStack_8 = 0;
  _DAT_0212ab38 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_ticket_0212b99c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_playerId_02119448);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_productId_0212b810);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0212ab60 = uStack_1c;
  _DAT_0212ab64 = uStack_18;
  _DAT_0212ab68 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_0212ab38 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212ab70 = 0;
  _DAT_0212ab74 = 1;
  FUN_016f3654(&LAB_0188d3a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 990 ; VA 0x004be520 ; FUN_004be520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004be520(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef42e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_LuaDialogCallbackSignal_0212bd28,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212b27c = 0x19c;
  iStack_8 = 0;
  _DAT_0212b248 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212b270 = uStack_1c;
  _DAT_0212b274 = uStack_18;
  _DAT_0212b278 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_0212b248 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212b280 = 0;
  _DAT_0212b284 = 0;
  FUN_016f3654(&LAB_0188d3b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 991 ; VA 0x004be840 ; FUN_004be840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004be840(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined auStack_2c8 [648];
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef479;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_009cba60(auStack_40,1,0);
  uStack_30 = *puVar1;
  uStack_2c = puVar1[1];
  uStack_28 = puVar1[2];
  uStack_24 = puVar1[3];
  uVar2 = FUN_00b12040();
  FUN_009cb970(uVar2,s_PromptProductPurchaseFinished_0212bca8,0,uStack_30,uStack_2c,uStack_28);
  _DAT_0212b174 = 0x148;
  iStack_8 = 0;
  _DAT_0212b140 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(__int64,__int64,bool),class_rbx::remote_signal<void___cdecl(__int64,__int64,bool)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  uVar2 = FUN_0086e3d0(s_userId_0211fb64);
  uVar3 = FUN_0088da50();
  FUN_00888740(uVar2,uVar3);
  iStack_8._0_1_ = 1;
  uVar2 = FUN_0086e3d0(s_productId_0212b810);
  uVar3 = FUN_0088da50();
  FUN_00888740(uVar2,uVar3);
  iStack_8._0_1_ = 2;
  uVar2 = FUN_0086e3d0(s_isPurchased_0212bc84);
  uVar3 = FUN_0088daf0();
  FUN_00888740(uVar2,uVar3);
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2c8,auStack_40,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0212b168 = uStack_1c;
  _DAT_0212b16c = uStack_18;
  _DAT_0212b170 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2c8,0xd8,3,FUN_00688b10);
  _DAT_0212b140 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(__int64,__int64,bool),class_rbx::remote_signal<void___cdecl(__int64,__int64,bool)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212b178 = 1;
  _DAT_0212b17c = uStack_24;
  FUN_016f3654(&LAB_0188d410);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 992 ; VA 0x004beb10 ; FUN_004beb10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004beb10(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef4be;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_PromptRobloxPurchaseRequested_0212bf70,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212b7c4 = 0x150;
  iStack_8 = 0;
  _DAT_0212b790 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(__int64,bool),class_rbx::signal<void___cdecl(__int64,bool)>,class_rbx::signal<void___cdecl(__int64,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_assetId_0211bf40);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_equipIfPurchased_0212b910);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212b7b8 = uStack_1c;
  _DAT_0212b7bc = uStack_18;
  _DAT_0212b7c0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212b790 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(__int64,bool),class_rbx::signal<void___cdecl(__int64,bool)>,class_rbx::signal<void___cdecl(__int64,bool)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188d450);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 993 ; VA 0x004bee10 ; FUN_004bee10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bee10(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef4f3;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,s_ServerPurchaseVerification_0212b9ec,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212abac = 0x18c;
  iStack_8 = 0;
  _DAT_0212ab78 =
       RBX::Reflection::
       EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::MarketplaceService::*>
       ::vftable;
  FUN_0086e3d0(s_serverResponseTable_0212b9d8);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212aba0 = uStack_1c;
  _DAT_0212aba4 = uStack_18;
  _DAT_0212aba8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0212ab78 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::MarketplaceService::*>
       ::vftable;
  _DAT_0212abb0 = 0;
  _DAT_0212abb4 = 1;
  FUN_016f3654(&LAB_0188d4b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 994 ; VA 0x004bef70 ; FUN_004bef70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bef70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef51e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_UserOwnsGamePassAsync_0212bdb0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b398 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MarketplaceService,bool___cdecl(__int64,__int64),2>::vftable;
  _DAT_0212b3d0 = FUN_00b31da0;
  _DAT_0212b3d4 = 0;
  DAT_0212b3d8 = 0;
  DAT_0212b3dc = 0;
  uStack_8 = 2;
  FUN_00a5ac40();
  FUN_016f3654(&LAB_0188d4c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 995 ; VA 0x004bf030 ; FUN_004bf030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf030(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef54e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptBundlePurchase_0212bcc8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b180 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_0212b1b8 = FUN_00b2ef90;
  _DAT_0212b1bc = 0;
  _DAT_0212b1c0 = 0;
  _DAT_0212b1c4 = 0;
  uStack_8 = 2;
  FUN_00b20160();
  FUN_016f3654(&LAB_0188d500);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 996 ; VA 0x004bf0f0 ; FUN_004bf0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf0f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef57e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptNativePurchase_0212bba4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212ae38 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0212ae70 = FUN_00b2f450;
  _DAT_0212ae74 = 0;
  DAT_0212ae78 = 0;
  _DAT_0212ae7c = 0;
  uStack_8 = 2;
  FUN_00b1fcc0();
  FUN_016f3654(&LAB_0188d510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 997 ; VA 0x004bf1b0 ; FUN_004bf1b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf1b0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef5dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b12040();
  FUN_009cb790(uVar2,s_PromptPremiumPurchase_0212beec,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212b678 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0212b6b0 = FUN_00b2f690;
  _DAT_0212b6b4 = 0;
  DAT_0212b6b8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212b69c = FUN_00888530();
  puVar4 = DAT_0212b6b8;
  if (DAT_0212b6b8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188d570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 998 ; VA 0x004bf380 ; FUN_004bf380 */

void FUN_004bf380(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b15870(FUN_00b2f890,0,s_PromptProductPurchase_0212bc6c,s_player_0211f800,
               s_productId_0212b810,s_equipIfPurchased_0212b910,s_currencyType_0212b900,0,1,0,
               uStack_10,0);
  FUN_016f3654(&LAB_0188d5c0);
  return;
}



/* FUNCTION 999 ; VA 0x004bf400 ; FUN_004bf400 */

void FUN_004bf400(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b15870(FUN_00b2fad0,0,s_PromptPurchase_0212bc5c,s_player_0211f800,s_assetId_0211bf40,
               s_equipIfPurchased_0212b910,s_currencyType_0212b900,0,1,0,uStack_10,0);
  FUN_016f3654(&LAB_0188d5d0);
  return;
}


